; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1 }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1, i1 }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i64, i64, i1, i64, i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/cond:Value" = type { i32, i64, double, i64, i64, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/names:Table" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, { i64, ptr }, ptr }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/check:opShape" = type { { i64, ptr }, i64, i1, i1 }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1 }
%"compiler/typed:Join" = type { ptr, i1, { i64, ptr } }
%"compiler/ast:JoinS" = type { i1, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/typed:If" = type { ptr, ptr, ptr }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/check:roDeepArg" = type { i64, ptr, i64, i64 }
define dso_local %"compiler/check:litv" @compiler_2fcheck_2eaddMag(i1 %a0, i64 %a1, i1 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i64
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l14 = alloca %"compiler/check:litv"
  %l16 = alloca i1
  %l20 = alloca %"compiler/check:litv"
  %l25 = alloca i1
  %l32 = alloca %"compiler/check:litv"
  %l37 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store i1 %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i1 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l0, !tbaa !21
  %t2 = load i1, ptr %l2, !tbaa !21
  %t5 = icmp eq i1 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l1, !tbaa !65
  %t8 = load i64, ptr %l3, !tbaa !65
  %t11 = add i64 %t7, %t8
  store i64 %t11, ptr %l4, !tbaa !65
  %t13 = load i64, ptr %l4, !tbaa !65
  %t14 = load i64, ptr %l1, !tbaa !65
  %t17 = icmp ult i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb2:
  br label %bb11
bb3:
  %t19 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t19, ptr %l14
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t20, ptr %rv
  br label %ret
bb6:
  %t21 = load i1, ptr %l0, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t23 = load i64, ptr %l4, !tbaa !65
  %t25 = icmp ne i64 %t23, 0
  store i1 %t25, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t27 = load i64, ptr %l4, !tbaa !65
  %t28 = load i1, ptr %l16, !tbaa !21
  %t30 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t28, i64 %t27)
  store %"compiler/check:litv" %t30, ptr %l20
  br label %bb10
bb10:
  %t31 = load %"compiler/check:litv", ptr %l20
  store %"compiler/check:litv" %t31, ptr %rv
  br label %ret
bb11:
  %t32 = load i64, ptr %l1, !tbaa !65
  %t33 = load i64, ptr %l3, !tbaa !65
  %t36 = icmp uge i64 %t32, %t33
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load i1, ptr %l0, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  %t40 = load i64, ptr %l1, !tbaa !65
  %t41 = load i64, ptr %l3, !tbaa !65
  %t44 = icmp ne i64 %t40, %t41
  store i1 %t44, ptr %l25, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i64, ptr %l1, !tbaa !65
  %t47 = load i64, ptr %l3, !tbaa !65
  %t50 = sub i64 %t46, %t47
  %t51 = load i1, ptr %l25, !tbaa !21
  %t53 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t51, i64 %t50)
  store %"compiler/check:litv" %t53, ptr %l32
  br label %bb17
bb17:
  %t54 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t54, ptr %rv
  br label %ret
bb18:
  %t55 = load i1, ptr %l2, !tbaa !21
  %t56 = load i64, ptr %l3, !tbaa !65
  %t57 = load i64, ptr %l1, !tbaa !65
  %t60 = sub i64 %t56, %t57
  %t63 = call %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %t55, i64 %t60)
  store %"compiler/check:litv" %t63, ptr %l37
  br label %bb19
bb19:
  %t64 = load %"compiler/check:litv", ptr %l37
  store %"compiler/check:litv" %t64, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l17 = alloca { i64, ptr }
  %l23 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l17, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  %t35 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t28, { i64, ptr } %a1)
  store i1 %t35, ptr %l23
  br label %bb8
bb8:
  %t36 = load i1, ptr %l23, !tbaa !21
  br i1 %t36, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb4
bb13:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ebangOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l13 = alloca { i64, ptr }
  %l18 = alloca i1
  %l25 = alloca i1
  %l32 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb24
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i8, ptr %t19, i64 %t16
  %t21 = load i8, ptr %t20, !tbaa !32
  store i8 %t21, ptr %l5, !tbaa !22
  %t23 = load i8, ptr %l5, !tbaa !22
  %t25 = icmp eq i8 %t23, 40
  br i1 %t25, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb6:
  %t27 = load i8, ptr %l5, !tbaa !22
  %t29 = icmp eq i8 %t27, 91
  store i1 %t29, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t31 = load i1, ptr %l18, !tbaa !21
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l1, !tbaa !24
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t36 = load i8, ptr %l5, !tbaa !22
  %t38 = icmp eq i8 %t36, 41
  br i1 %t38, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb13
bb12:
  %t40 = load i8, ptr %l5, !tbaa !22
  %t42 = icmp eq i8 %t40, 93
  store i1 %t42, ptr %l25, !tbaa !21
  br label %bb13
bb13:
  %t44 = load i1, ptr %l25, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = load i64, ptr %l1, !tbaa !24
  %t47 = sub i64 %t45, 1
  store i64 %t47, ptr %l1, !tbaa !24
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t49 = load i8, ptr %l5, !tbaa !22
  %t51 = icmp eq i8 %t49, 32
  br i1 %t51, label %bb17, label %bb18
bb17:
  %t53 = load i64, ptr %l1, !tbaa !24
  %t55 = icmp eq i64 %t53, 0
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb20, label %bb21
bb20:
  %t58 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d0 }, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = extractvalue { i64, ptr } %t58, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d1 }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb23:
  %t74 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l3, !tbaa !24
  br label %bb1
bb24:
  %t78 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = extractvalue { i64, ptr } %t78, 0
  %t82 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t80, i64 %t81)
  %t83 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecasePayload(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t13 = icmp sge i64 0, 0
  br i1 %t13, label %bb6, label %bb7
bb5:
  br label %bb10
bb6:
  %t15 = icmp sle i64 0, 1152921504606846975
  br i1 %t15, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_335172168044531c_a265ad00fca232a0)
  unreachable
bb8:
  %t17 = mul i64 0, 8
  %t18 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t17)
  %t19 = insertvalue { i64, ptr } undef, i64 0, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_335172168044531c_a265ad00fca232a0)
  unreachable
bb10:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/ast:TypeDecl", ptr %t22, i32 0, i32 3
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l2, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  store ptr %t27, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = icmp ne ptr %t28, null
  br i1 %t29, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load i64, ptr %t31
  %t34 = icmp eq i64 %t32, 1
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb12
bb12:
  %t35 = load i1, ptr %l16, !tbaa !21
  br i1 %t35, label %bb13, label %bb14
bb13:
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [6 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { { i64, ptr } }, ptr %t38, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39
  store { i64, ptr } %t40, ptr %l3, !tbaa !27
  br label %bb15
bb14:
  br label %bb23
bb15:
  %t42 = load i64, ptr %l1, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t48 = icmp slt i64 %t42, %t45
  br i1 %t48, label %bb16, label %bb17
bb16:
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l26, !tbaa !27
  %t51 = load i64, ptr %l1, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  %t58 = getelementptr %"compiler/ast:CaseDecl", ptr %t56, i32 0, i32 2
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l25, !tbaa !27
  br label %bb22
bb17:
  %t61 = icmp sge i64 0, 0
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = icmp sle i64 0, 1152921504606846975
  br i1 %t63, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_b70a8dfc847e84e9_67f505336baa0acd)
  unreachable
bb20:
  %t65 = mul i64 0, 8
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 0, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l25, !tbaa !27
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b70a8dfc847e84e9_67f505336baa0acd)
  unreachable
bb22:
  %t70 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t70, ptr %rv
  br label %ret
bb23:
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb24, label %bb25
bb24:
  %t73 = icmp sle i64 0, 1152921504606846975
  br i1 %t73, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_877bc023f9996aa_af9d54b66b552ace)
  unreachable
bb26:
  %t75 = mul i64 0, 8
  %t76 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 0, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %rv
  br label %ret
bb27:
  call void @__olang_check_failed(ptr @olang_loc_877bc023f9996aa_af9d54b66b552ace)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2echeckableAst(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l28 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i1
  %l51 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t2 = load ptr, ptr %l8, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l8, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l9, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fcheck_2echeckableAst(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l15
  br label %bb6
bb6:
  %t19 = load i1, ptr %l15, !tbaa !21
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb68
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t21 = load ptr, ptr %l16, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 5
  store i1 %t27, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t31, i32 0, i32 1
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l2
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t37, i32 0, i32 2
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l3, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr { i64, [5 x i64] }, ptr %t41, i32 0, i32 1
  %t44 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t43, i32 0, i32 3
  %t45 = load ptr, ptr %t44
  store ptr %t45, ptr %l4, !tbaa !29
  br label %bb12
bb11:
  br label %bb39
bb12:
  %t47 = load i32, ptr %l2
  %t49 = trunc i64 49 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb15
bb14:
  %t52 = load i32, ptr %l2
  %t54 = trunc i64 50 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t57 = load i1, ptr %l28, !tbaa !21
  br i1 %t57, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  %t58 = load i32, ptr %l2
  %t60 = trunc i64 51 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t63 = load i1, ptr %l31, !tbaa !21
  br i1 %t63, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb20:
  %t64 = load i32, ptr %l2
  %t66 = trunc i64 52 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t69 = load i1, ptr %l34, !tbaa !21
  br i1 %t69, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb23:
  %t70 = load i32, ptr %l2
  %t72 = trunc i64 53 to i32
  %t73 = icmp eq i32 %t70, %t72
  store i1 %t73, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t75 = load i1, ptr %l37, !tbaa !21
  br i1 %t75, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb26:
  %t76 = load i32, ptr %l2
  %t78 = trunc i64 86 to i32
  %t79 = icmp eq i32 %t76, %t78
  store i1 %t79, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t81 = load i1, ptr %l40, !tbaa !21
  br i1 %t81, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb30
bb29:
  %t82 = load i32, ptr %l2
  %t84 = trunc i64 87 to i32
  %t85 = icmp eq i32 %t82, %t84
  store i1 %t85, ptr %l43, !tbaa !21
  br label %bb30
bb30:
  %t87 = load i1, ptr %l43, !tbaa !21
  br i1 %t87, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb34
bb32:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2echeckableAst(ptr %v0, ptr %t88)
  store i1 %t90, ptr %l48
  br label %bb33
bb33:
  %t91 = load i1, ptr %l48, !tbaa !21
  store i1 %t91, ptr %l46, !tbaa !21
  br label %bb34
bb34:
  %t92 = load i1, ptr %l46, !tbaa !21
  br i1 %t92, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb38
bb36:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = call i1 @compiler_2fcheck_2echeckableAst(ptr %v0, ptr %t93)
  store i1 %t95, ptr %l51
  br label %bb37
bb37:
  %t96 = load i1, ptr %l51, !tbaa !21
  store i1 %t96, ptr %l49, !tbaa !21
  br label %bb38
bb38:
  %t97 = load i1, ptr %l49, !tbaa !21
  store i1 %t97, ptr %l7, !tbaa !21
  br label %bb68
bb39:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t99 = load ptr, ptr %l52, !tbaa !29
  %t100 = icmp ne ptr %t99, null
  br i1 %t100, label %bb40, label %bb41
bb40:
  %t102 = load ptr, ptr %l52, !tbaa !29
  %t103 = load i64, ptr %t102
  %t105 = icmp eq i64 %t103, 3
  store i1 %t105, ptr %l53, !tbaa !21
  br label %bb41
bb41:
  %t106 = load i1, ptr %l53, !tbaa !21
  br i1 %t106, label %bb42, label %bb43
bb42:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr { i64, [5 x i64] }, ptr %t107, i32 0, i32 1
  %t110 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t109, i32 0, i32 1
  %t111 = load i32, ptr %t110
  store i32 %t111, ptr %l5
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr { i64, [5 x i64] }, ptr %t113, i32 0, i32 1
  %t116 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t115, i32 0, i32 2
  %t117 = load ptr, ptr %t116
  store ptr %t117, ptr %l6, !tbaa !29
  br label %bb44
bb43:
  br label %bb49
bb44:
  %t119 = load i32, ptr %l5
  %t121 = trunc i64 50 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l62, !tbaa !21
  br label %bb48
bb46:
  %t124 = load ptr, ptr %l6, !tbaa !29
  %t126 = call i1 @compiler_2fcheck_2echeckableAst(ptr %v0, ptr %t124)
  store i1 %t126, ptr %l64
  br label %bb47
bb47:
  %t127 = load i1, ptr %l64, !tbaa !21
  store i1 %t127, ptr %l62, !tbaa !21
  br label %bb48
bb48:
  %t128 = load i1, ptr %l62, !tbaa !21
  store i1 %t128, ptr %l7, !tbaa !21
  br label %bb68
bb49:
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l65, !tbaa !29
  store i1 false, ptr %l66, !tbaa !21
  %t130 = load ptr, ptr %l65, !tbaa !29
  %t131 = icmp ne ptr %t130, null
  br i1 %t131, label %bb50, label %bb51
bb50:
  %t133 = load ptr, ptr %l65, !tbaa !29
  %t134 = load i64, ptr %t133
  %t136 = icmp eq i64 %t134, 16
  store i1 %t136, ptr %l66, !tbaa !21
  br label %bb51
bb51:
  %t137 = load i1, ptr %l66, !tbaa !21
  br i1 %t137, label %bb52, label %bb53
bb52:
  br label %bb62
bb53:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t139 = load ptr, ptr %l69, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb54, label %bb55
bb54:
  %t142 = load ptr, ptr %l69, !tbaa !29
  %t143 = load i64, ptr %t142
  %t145 = icmp eq i64 %t143, 17
  store i1 %t145, ptr %l70, !tbaa !21
  br label %bb55
bb55:
  %t146 = load i1, ptr %l70, !tbaa !21
  br i1 %t146, label %bb56, label %bb57
bb56:
  br label %bb62
bb57:
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l73, !tbaa !29
  store i1 false, ptr %l74, !tbaa !21
  %t148 = load ptr, ptr %l73, !tbaa !29
  %t149 = icmp ne ptr %t148, null
  br i1 %t149, label %bb58, label %bb59
bb58:
  %t151 = load ptr, ptr %l73, !tbaa !29
  %t152 = load i64, ptr %t151
  %t154 = icmp eq i64 %t152, 11
  store i1 %t154, ptr %l74, !tbaa !21
  br label %bb59
bb59:
  %t155 = load i1, ptr %l74, !tbaa !21
  br i1 %t155, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_39cc6def4be103fb_5346127ded5ad1ff)
  unreachable
bb68:
  %t156 = load i1, ptr %l7, !tbaa !21
  store i1 %t156, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedCall(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Call", ptr %t1, i32 0, i32 4
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/typed:Call", ptr %t6, i32 0, i32 2
  %t9 = load { i64, [2 x i64] }, ptr %t8
  %t11 = extractvalue { i64, [2 x i64] } %t9, 0
  %t12 = icmp eq i64 %t11, 0
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l4, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/typed:Call", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb7, label %bb8
bb7:
  %t27 = load ptr, ptr %l12, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 0
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb8
bb8:
  %t31 = load i1, ptr %l13, !tbaa !21
  br i1 %t31, label %bb9, label %bb10
bb9:
  br label %bb15
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  store ptr %t32, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = icmp ne ptr %t33, null
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t36 = load ptr, ptr %l16, !tbaa !29
  %t37 = load i64, ptr %t36
  %t39 = icmp eq i64 %t37, 3
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb12
bb12:
  %t40 = load i1, ptr %l17, !tbaa !21
  br i1 %t40, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Call", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = call i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %t44)
  store i1 %t46, ptr %l22
  br label %bb16
bb16:
  %t47 = load i1, ptr %l22, !tbaa !21
  store i1 %t47, ptr %rv
  br label %ret
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eErrorsOf(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
  store i32 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i32, ptr %l4, !tbaa !23
  store i32 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eadapter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca i32
  %l25 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i64
  %l50 = alloca i1
  %l52 = alloca ptr
  %l54 = alloca i64
  %l55 = alloca i64
  %l58 = alloca ptr
  %l59 = alloca i64
  %l60 = alloca i32
  %l61 = alloca %"compiler/source:Span"
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l71 = alloca i32
  %l75 = alloca i64
  %l79 = alloca i32
  %l82 = alloca ptr
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l110 = alloca i64
  %l113 = alloca i64
  %l133 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l139 = alloca i32
  %l141 = alloca { i64, ptr }
  %l144 = alloca i32
  %l145 = alloca i1
  %l149 = alloca { i64, ptr }
  %l153 = alloca i1
  %l154 = alloca i1
  %l156 = alloca { i64, ptr }
  %l159 = alloca i1
  %l160 = alloca i1
  %l162 = alloca { i64, ptr }
  %l165 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca ptr
  %l178 = alloca i32
  %l179 = alloca i32
  %l180 = alloca ptr
  %l185 = alloca i32
  %l186 = alloca i32
  %l187 = alloca i1
  %l192 = alloca i64
  %l194 = alloca ptr
  %l195 = alloca i64
  %l198 = alloca { i64, [3 x i64] }
  %l199 = alloca ptr
  %l203 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l209 = alloca %"compiler/check:roFn"
  %l212 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l216 = alloca %"compiler/source:Span"
  %l217 = alloca i32
  %l220 = alloca i32
  %l221 = alloca ptr
  %l225 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t451 = alloca { i64, [4 x i64] }, align 8
  %t463 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t2)
  store i32 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l18, !tbaa !29
  %t7 = load i32, ptr %l21, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l22
  br label %bb2
bb2:
  %t9 = load i32, ptr %l22, !tbaa !23
  store i32 %t9, ptr %l4, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t14, ptr %l25
  br label %bb3
bb3:
  %t15 = load i1, ptr %l25, !tbaa !21
  %t16 = xor i1 %t15, true
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l29, !tbaa !29
  %t23 = load i32, ptr %l4, !tbaa !23
  store i32 %t23, ptr %l30, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/load:Loader", ptr %t30, i32 0, i32 3
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t33, { i64, ptr } { i64 4, ptr @.d2 })
  store i32 %t35, ptr %l35
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l29, !tbaa !29
  %t37 = load i32, ptr %l30, !tbaa !23
  %t38 = load i32, ptr %l35, !tbaa !23
  %t39 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t36, i32 %t37, i32 %t38)
  store i64 %t39, ptr %l36
  br label %bb8
bb8:
  %t40 = load i64, ptr %l36, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = icmp slt i64 %t41, 0
  br i1 %t43, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  store ptr %t48, ptr %l40, !tbaa !29
  %t49 = load i32, ptr %l4, !tbaa !23
  store i32 %t49, ptr %l41, !tbaa !23
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 0
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/load:Loader", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s2, ptr %t59, { i64, ptr } { i64 4, ptr @.d3 })
  store i32 %t61, ptr %l46
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t62 = load ptr, ptr %l40, !tbaa !29
  %t63 = load i32, ptr %l41, !tbaa !23
  %t64 = load i32, ptr %l46, !tbaa !23
  %t65 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t62, i32 %t63, i32 %t64)
  store i64 %t65, ptr %l47
  br label %bb12
bb12:
  %t66 = load i64, ptr %l47, !tbaa !24
  store i64 %t66, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t67 = load i64, ptr %l5, !tbaa !24
  %t69 = icmp slt i64 %t67, 0
  br i1 %t69, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb18
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  store ptr %t74, ptr %l52, !tbaa !29
  %t75 = load i64, ptr %l5, !tbaa !24
  %t77 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t75)
  store i64 %t77, ptr %l54
  br label %bb16
bb16:
  %t78 = load ptr, ptr %l52, !tbaa !29
  %t79 = load i64, ptr %l54, !tbaa !24
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t78, i64 %t79)
  store i64 %t80, ptr %l55
  br label %bb17
bb17:
  %t81 = load i64, ptr %l55, !tbaa !24
  %t82 = icmp sgt i64 %t81, 0
  store i1 %t82, ptr %l50, !tbaa !21
  br label %bb18
bb18:
  %t84 = load i1, ptr %l50, !tbaa !21
  br i1 %t84, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l58, !tbaa !29
  %t87 = load i64, ptr %l5, !tbaa !24
  store i64 %t87, ptr %l59, !tbaa !24
  %t88 = load i32, ptr %l4, !tbaa !23
  store i32 %t88, ptr %l60, !tbaa !23
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l61
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load %"compiler/source:Span", ptr %l1
  %t94 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t90, %"compiler/source:Span" %t91)
  store { i64, ptr } %t94, ptr %l64
  br label %bb22
bb22:
  %t95 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t96 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s0, { i64, ptr } %t95)
  store { i64, ptr } %t96, ptr %l65
  br label %bb23
bb23:
  %t97 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = mul i64 %t98, 1
  %t101 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t100)
  call void @llvm.memcpy.p0.p0.i64(ptr %t101, ptr %t99, i64 %t100, i1 false)
  %t102 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  %t104 = load ptr, ptr %l58, !tbaa !29
  %t105 = load i64, ptr %l59, !tbaa !24
  %t106 = load i32, ptr %l60, !tbaa !23
  %t107 = load %"compiler/source:Span", ptr %l61
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t104, i64 %t105, i32 %t106, { i64, ptr } { i64 4, ptr @.d4 }, %"compiler/source:Span" %t107, { i64, ptr } %t103)
  store i1 %t109, ptr %l67
  br label %bb24
bb24:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load i64, ptr %l5, !tbaa !24
  %t117 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t113, i64 %t114)
  store i32 %t117, ptr %l71
  br label %bb25
bb25:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !29
  %t122 = load i64, ptr %l5, !tbaa !24
  %t125 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t121, i64 %t122, i32 0)
  store i64 %t125, ptr %l75
  br label %bb26
bb26:
  %t126 = load i64, ptr %l75, !tbaa !24
  store i64 %t126, ptr %l6, !tbaa !24
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t131 = load i64, ptr %l6, !tbaa !24
  %t134 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %t130, i64 %t131)
  store i32 %t134, ptr %l79
  br label %bb27
bb27:
  %t135 = load i32, ptr %l79, !tbaa !23
  store i32 %t135, ptr %l7, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  store ptr %t141, ptr %l82, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t144 = getelementptr %"compiler/check:Checker", ptr %t142, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !29
  %t147 = getelementptr %"compiler/generic:Program", ptr %t145, i32 0, i32 2
  %t148 = load i32, ptr %l7, !tbaa !23
  %t151 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t147, i32 %t148)
  store i32 %t151, ptr %l87
  br label %bb28
bb28:
  %t152 = load ptr, ptr %l82, !tbaa !29
  %t153 = load i32, ptr %l87, !tbaa !23
  %t154 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t152, i32 %t153)
  store { i64, ptr } %t154, ptr %l88
  br label %bb29
bb29:
  %t155 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t155, ptr %l8, !tbaa !27
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  store ptr %t161, ptr %l91, !tbaa !29
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/check:Checker", ptr %t162, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = getelementptr %"compiler/generic:Program", ptr %t165, i32 0, i32 2
  %t168 = load i32, ptr %l3, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t167, i32 %t168)
  store i32 %t171, ptr %l96
  br label %bb30
bb30:
  %t172 = load ptr, ptr %l91, !tbaa !29
  %t173 = load i32, ptr %l96, !tbaa !23
  %t174 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t172, i32 %t173)
  store { i64, ptr } %t174, ptr %l97
  br label %bb31
bb31:
  %t175 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t175, ptr %l9, !tbaa !27
  %t176 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t183 = add i64 %t181, 1
  %t186 = icmp ne i64 %t178, %t183
  br i1 %t186, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  store i64 0, ptr %l10, !tbaa !24
  %t189 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t189, 0
  store i64 %t191, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t193 = load i64, ptr %l11, !tbaa !24
  %t194 = load i64, ptr %l10, !tbaa !24
  %t197 = icmp sgt i64 %t193, %t194
  br i1 %t197, label %bb35, label %bb36
bb35:
  %t199 = load i64, ptr %l12, !tbaa !24
  %t201 = icmp sgt i64 %t199, 0
  br i1 %t201, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb40
bb37:
  %t203 = load i64, ptr %l11, !tbaa !24
  %t204 = load i64, ptr %l10, !tbaa !24
  %t207 = sub i64 %t203, %t204
  %t208 = load i64, ptr %l12, !tbaa !24
  %t211 = add i64 %t207, %t208
  %t213 = sub i64 %t211, 1
  %t214 = load i64, ptr %l12, !tbaa !24
  %t217 = sdiv i64 %t213, %t214
  store i64 %t217, ptr %l113, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l113, !tbaa !24
  br label %bb39
bb39:
  %t219 = load i64, ptr %l113, !tbaa !24
  store i64 %t219, ptr %l110, !tbaa !24
  br label %bb40
bb40:
  %t220 = load i64, ptr %l110, !tbaa !24
  store i64 %t220, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s6
  %t221 = load i64, ptr %l14, !tbaa !24
  %t222 = load i64, ptr %l13, !tbaa !24
  %t225 = icmp slt i64 %t221, %t222
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb64
bb43:
  br label %bb44
bb44:
  %t229 = load i64, ptr %l10, !tbaa !24
  %t230 = load i64, ptr %l14, !tbaa !24
  %t231 = load i64, ptr %l12, !tbaa !24
  %t234 = mul i64 %t230, %t231
  %t237 = add i64 %t229, %t234
  store i64 %t237, ptr %l15, !tbaa !24
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  store ptr %t244, ptr %l133, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t246, ptr %l135, !tbaa !27
  %t247 = load i64, ptr %l15, !tbaa !24
  %t249 = add i64 %t247, 1
  %t251 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = getelementptr i32, ptr %t252, i64 %t249
  %t254 = load i32, ptr %t253, !tbaa !33
  %t257 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t245, i32 %t254)
  store i32 %t257, ptr %l139
  br label %bb45
bb45:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t259, ptr %l141, !tbaa !27
  %t260 = load i64, ptr %l15, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr i32, ptr %t263, i64 %t260
  %t265 = load i32, ptr %t264, !tbaa !33
  %t268 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t258, i32 %t265)
  store i32 %t268, ptr %l144
  br label %bb46
bb46:
  %t269 = load ptr, ptr %l133, !tbaa !29
  %t270 = load i32, ptr %l139, !tbaa !23
  %t271 = load i32, ptr %l144, !tbaa !23
  %t272 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t269, i32 %t270, i32 %t271)
  store i1 %t272, ptr %l145
  br label %bb47
bb47:
  %t273 = load i1, ptr %l145, !tbaa !21
  %t274 = xor i1 %t273, true
  br i1 %t274, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t278, ptr %l149, !tbaa !27
  %t279 = load i64, ptr %l15, !tbaa !24
  %t281 = add i64 %t279, 1
  %t283 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i32, ptr %t284, i64 %t281
  %t286 = load i32, ptr %t285, !tbaa !33
  %t289 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t277, i32 %t286)
  store i1 %t289, ptr %l153
  br label %bb51
bb51:
  %t290 = load i1, ptr %l153, !tbaa !21
  br i1 %t290, label %bb52, label %bb53
bb52:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t292, ptr %l156, !tbaa !27
  %t293 = load i64, ptr %l15, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr i32, ptr %t296, i64 %t293
  %t298 = load i32, ptr %t297, !tbaa !33
  %t301 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t291, i32 %t298)
  store i1 %t301, ptr %l159
  br label %bb54
bb53:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb55
bb54:
  %t302 = load i1, ptr %l159, !tbaa !21
  store i1 %t302, ptr %l154, !tbaa !21
  br label %bb55
bb55:
  %t303 = load i1, ptr %l154, !tbaa !21
  br i1 %t303, label %bb56, label %bb57
bb56:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t305, ptr %l162, !tbaa !27
  %t306 = load i64, ptr %l15, !tbaa !24
  %t308 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !27
  %t310 = getelementptr i32, ptr %t309, i64 %t306
  %t311 = load i32, ptr %t310, !tbaa !33
  %t314 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t304, i32 %t311)
  store i1 %t314, ptr %l165
  br label %bb58
bb57:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb59
bb58:
  %t315 = load i1, ptr %l165, !tbaa !21
  %t316 = xor i1 %t315, true
  store i1 %t316, ptr %l160, !tbaa !21
  br label %bb59
bb59:
  %t318 = load i1, ptr %l160, !tbaa !21
  br i1 %t318, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s6)
  br label %bb63
bb63:
  %t320 = load i64, ptr %l14, !tbaa !24
  %t322 = add i64 %t320, 1
  store i64 %t322, ptr %l14, !tbaa !24
  br label %bb41
bb64:
  %t324 = load ptr, ptr %l0, !tbaa !29
  %t326 = getelementptr %"compiler/check:Checker", ptr %t324, i32 0, i32 1
  %t327 = load ptr, ptr %t326, !tbaa !29
  %t329 = getelementptr %"compiler/generic:Program", ptr %t327, i32 0, i32 2
  store ptr %t329, ptr %l172, !tbaa !29
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l173, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = getelementptr %"compiler/check:Checker", ptr %t331, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Program", ptr %t334, i32 0, i32 2
  %t337 = load i32, ptr %l7, !tbaa !23
  %t340 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t336, i32 %t337)
  store i32 %t340, ptr %l178
  br label %bb65
bb65:
  %t341 = load ptr, ptr %l173, !tbaa !29
  %t342 = load i32, ptr %l178, !tbaa !23
  %t343 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t341, i32 %t342)
  store i32 %t343, ptr %l179
  br label %bb66
bb66:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l180, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/generic:Program", ptr %t348, i32 0, i32 2
  %t351 = load i32, ptr %l3, !tbaa !23
  %t354 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t350, i32 %t351)
  store i32 %t354, ptr %l185
  br label %bb67
bb67:
  %t355 = load ptr, ptr %l180, !tbaa !29
  %t356 = load i32, ptr %l185, !tbaa !23
  %t357 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t355, i32 %t356)
  store i32 %t357, ptr %l186
  br label %bb68
bb68:
  %t358 = load ptr, ptr %l172, !tbaa !29
  %t359 = load i32, ptr %l179, !tbaa !23
  %t360 = load i32, ptr %l186, !tbaa !23
  %t361 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t358, i32 %t359, i32 %t360)
  store i1 %t361, ptr %l187
  br label %bb69
bb69:
  %t362 = load i1, ptr %l187, !tbaa !21
  %t363 = xor i1 %t362, true
  br i1 %t363, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i64, ptr %l6, !tbaa !24
  %t370 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t366, i64 %t367)
  store i64 %t370, ptr %l192
  br label %bb73
bb73:
  %t371 = load i64, ptr %l192, !tbaa !24
  store i64 %t371, ptr %l16, !tbaa !24
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr %"compiler/check:Checker", ptr %t372, i32 0, i32 59
  store ptr %t374, ptr %l194, !tbaa !29
  %t375 = load i64, ptr %l16, !tbaa !24
  store i64 %t375, ptr %l195, !tbaa !24
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load %"compiler/source:Span", ptr %l1
  %t380 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t376, %"compiler/source:Span" %t377)
  store { i64, [3 x i64] } %t380, ptr %l198
  br label %bb74
bb74:
  %t381 = load ptr, ptr %l0, !tbaa !29
  store ptr %t381, ptr %l199, !tbaa !29
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/check:Checker", ptr %t382, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !29
  %t386 = load i64, ptr %l5, !tbaa !24
  %t389 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t385, i64 %t386)
  store ptr %t389, ptr %l203
  br label %bb75
bb75:
  %t390 = load ptr, ptr %l203, !tbaa !29
  %t392 = getelementptr %"compiler/ast:Func", ptr %t390, i32 0, i32 2
  %t393 = load i32, ptr %t392, !tbaa !23
  %t394 = load ptr, ptr %l199, !tbaa !29
  %t396 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t394, i32 %t393)
  store { i64, ptr } %t396, ptr %l206
  br label %bb76
bb76:
  %t397 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t398 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t399 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t400 = extractvalue { i64, ptr } %t399, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = add i64 %t398, %t401
  %t403 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 1
  %t404 = extractvalue { i64, ptr } { i64 1, ptr @.d6 }, 0
  %t405 = add i64 %t402, %t404
  %t406 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t405)
  call void @olang_textcopy(ptr %t406, ptr %t397, i64 %t398)
  %t407 = getelementptr i8, ptr %t406, i64 %t398
  call void @olang_textcopy(ptr %t407, ptr %t400, i64 %t401)
  %t408 = getelementptr i8, ptr %t407, i64 %t401
  call void @olang_textcopy(ptr %t408, ptr %t403, i64 %t404)
  %t409 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t410 = insertvalue { i64, ptr } %t409, ptr %t406, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = extractvalue { i64, ptr } %t410, 1
  %t414 = mul i64 %t412, 1
  %t415 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t414)
  call void @llvm.memcpy.p0.p0.i64(ptr %t415, ptr %t413, i64 %t414, i1 false)
  %t416 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t417 = insertvalue { i64, ptr } %t416, ptr %t415, 1
  %t418 = load i64, ptr %l195, !tbaa !24
  %t419 = load { i64, [3 x i64] }, ptr %l198
  %t421 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t418, i64 1, { i64, [3 x i64] } %t419, { i64, ptr } %t417)
  store %"compiler/check:roFn" %t421, ptr %l209
  br label %bb77
bb77:
  %t422 = load ptr, ptr %l194, !tbaa !29
  %t423 = load %"compiler/check:roFn", ptr %l209
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t422, %"compiler/check:roFn" %t423)
  br label %bb78
bb78:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t425 = load ptr, ptr %l2, !tbaa !29
  %t426 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t426, ptr %l212, !tbaa !27
  %t427 = getelementptr { i64, ptr }, ptr %l212, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr i32, ptr %t428, i64 0
  %t430 = load i32, ptr %t429, !tbaa !33
  %t431 = load %"compiler/source:Span", ptr %l1
  %t436 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t424, ptr %t425, i32 %t430, %"compiler/source:Span" %t431)
  store ptr %t436, ptr %l215
  br label %bb79
bb79:
  %t437 = load ptr, ptr %l215, !tbaa !29
  %t438 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t438, ptr %l216
  %t439 = load i32, ptr %l3, !tbaa !23
  store i32 %t439, ptr %l217, !tbaa !23
  %t440 = load i64, ptr %l16, !tbaa !24
  %t442 = trunc i64 %t440 to i32
  store i32 %t442, ptr %l220, !tbaa !23
  store ptr %t437, ptr %l221, !tbaa !29
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load %"compiler/source:Span", ptr %l1
  %t450 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t445, i32 5, %"compiler/source:Span" %t446)
  store i32 %t450, ptr %l225
  br label %bb80
bb80:
  store { i64, [4 x i64] } zeroinitializer, ptr %t451
  %t452 = getelementptr { i64, [4 x i64] }, ptr %t451, i32 0, i32 0
  store i64 2, ptr %t452
  %t453 = load i32, ptr %l220, !tbaa !23
  %t454 = insertvalue { i32, ptr, i32 } undef, i32 %t453, 0
  %t455 = load ptr, ptr %l221, !tbaa !29
  %t456 = insertvalue { i32, ptr, i32 } %t454, ptr %t455, 1
  %t457 = load i32, ptr %l225, !tbaa !23
  %t458 = insertvalue { i32, ptr, i32 } %t456, i32 %t457, 2
  %t459 = getelementptr { i64, [4 x i64] }, ptr %t451, i32 0, i32 1
  store { i32, ptr, i32 } %t458, ptr %t459
  %t460 = load { i64, [4 x i64] }, ptr %t451
  %t462 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t460, ptr %t462
  store { i64, [5 x i64] } zeroinitializer, ptr %t463
  %t464 = getelementptr { i64, [5 x i64] }, ptr %t463, i32 0, i32 0
  store i64 15, ptr %t464
  %t465 = load %"compiler/source:Span", ptr %l216
  %t466 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t465, 0
  %t467 = load i32, ptr %l217, !tbaa !23
  %t468 = insertvalue { %"compiler/source:Span", i32, ptr } %t466, i32 %t467, 1
  %t470 = insertvalue { %"compiler/source:Span", i32, ptr } %t468, ptr %t462, 2
  %t471 = getelementptr { i64, [5 x i64] }, ptr %t463, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t470, ptr %t471
  %t472 = load { i64, [5 x i64] }, ptr %t463
  %t474 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t472, ptr %t474
  call void @__olang_scope_close(ptr %s0)
  store ptr %t474, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l21 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Alt", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t30, ptr %t31, ptr %t35)
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Alt", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t57, ptr %l37, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t63, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t66, ptr %t70)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb14:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb4
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Arm", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t83, ptr %t84, ptr %t88)
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Arm", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t92, ptr %t93, ptr %t97)
  br label %bb19
bb19:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Arm", ptr %t103, i32 0, i32 4
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l13 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a2)
  store ptr %t7, ptr %l13
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l13, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = getelementptr %"compiler/typed:Body", ptr %t9, i32 0, i32 11
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  br i1 %t14, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Body", ptr %t16, i32 0, i32 11
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_76c98d42818871e4_51853c380fcafc70)
  unreachable
bb6:
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t25 = getelementptr %"compiler/typed:Body", ptr %t23, i32 0, i32 11
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t29 = getelementptr %"compiler/typed:Block", ptr %t26, i32 0, i32 1
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !27
  store { i64, ptr } %t30, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb38
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr ptr, ptr %t48, i64 %t45
  %t50 = load ptr, ptr %t49, !tbaa !39
  store ptr %t50, ptr %l7, !tbaa !29
  %t52 = load ptr, ptr %l7, !tbaa !29
  store ptr %t52, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t53 = load ptr, ptr %l33, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 1
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb13
bb13:
  %t60 = load i1, ptr %l34, !tbaa !21
  br i1 %t60, label %bb14, label %bb15
bb14:
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l8, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t69 = getelementptr { i64, [3 x i64] }, ptr %t67, i32 0, i32 1
  %t70 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t69, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  store ptr %t71, ptr %l9, !tbaa !29
  br label %bb16
bb15:
  br label %bb30
bb16:
  %t73 = load ptr, ptr %l8, !tbaa !29
  store ptr %t73, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t74 = load ptr, ptr %l41, !tbaa !29
  %t75 = icmp ne ptr %t74, null
  br i1 %t75, label %bb17, label %bb18
bb17:
  %t77 = load ptr, ptr %l41, !tbaa !29
  %t78 = load i64, ptr %t77
  %t80 = icmp eq i64 %t78, 1
  store i1 %t80, ptr %l42, !tbaa !21
  br label %bb18
bb18:
  %t81 = load i1, ptr %l42, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t84 = load ptr, ptr %l9, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v0, ptr %t82, ptr %t83, ptr %t84)
  br label %bb22
bb22:
  br label %bb29
bb23:
  br i1 true, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t90 = load ptr, ptr %l1, !tbaa !29
  %t91 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t89, ptr %t90, ptr %t91)
  br label %bb27
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_5b6dfd884f12314a_d55d816e86cc2196)
  unreachable
bb29:
  br label %bb36
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t98 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v0, ptr %t96, ptr %t97, ptr %t98)
  br label %bb34
bb34:
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad)
  unreachable
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb37:
  %t103 = load i64, ptr %l5, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l5, !tbaa !24
  br label %bb8
bb38:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebang(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i1
  %lp10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l20 = alloca ptr
  %l24 = alloca ptr
  %l26 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i32
  %l35 = alloca i32
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca i1
  %l54 = alloca i1
  %l57 = alloca i32
  %l60 = alloca i1
  %l62 = alloca i1
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca %"compiler/msgs:Msg"
  %l75 = alloca i64
  %l78 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l85 = alloca i32
  %l87 = alloca ptr
  %l91 = alloca %"compiler/typed:Try"
  %l95 = alloca ptr
  %l99 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  %t171 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 25
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 17
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l6, !tbaa !24
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 16
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l7, !tbaa !24
  %t21 = load ptr, ptr %l4, !tbaa !29
  store ptr %t21, ptr %l20, !tbaa !29
  %t22 = load ptr, ptr %l20, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 15
  %t24 = load i64, ptr %t23, !tbaa !24
  %t26 = add i64 %t24, 1
  %t28 = load ptr, ptr %l20, !tbaa !29
  %t29 = getelementptr %"compiler/check:frame", ptr %t28, i32 0, i32 15
  store i64 %t26, ptr %t29, !tbaa !24
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/check:frame", ptr %t30, i32 0, i32 16
  store i64 0, ptr %t32, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l24, !tbaa !29
  store ptr %a2, ptr %l26, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l3, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l29
  br label %bb3
bb3:
  %t41 = load i1, ptr %l29, !tbaa !21
  br i1 %t41, label %bb4, label %bb5
bb4:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l35
  br label %bb6
bb5:
  %t52 = load i32, ptr %l3, !tbaa !23
  store i32 %t52, ptr %l30, !tbaa !23
  br label %bb7
bb6:
  %t54 = load i32, ptr %l35, !tbaa !23
  store i32 %t54, ptr %l30, !tbaa !23
  br label %bb7
bb7:
  %t55 = load ptr, ptr %l24, !tbaa !29
  %t56 = load ptr, ptr %l26, !tbaa !29
  %t57 = load i32, ptr %l30, !tbaa !23
  %t58 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t55, ptr %t56, i32 %t57)
  store ptr %t58, ptr %l37
  br label %bb8
bb8:
  %t59 = load ptr, ptr %l37, !tbaa !29
  store ptr %t59, ptr %l8, !tbaa !29
  %t60 = load ptr, ptr %l4, !tbaa !29
  store ptr %t60, ptr %l38, !tbaa !29
  %t61 = load ptr, ptr %l38, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t61, i32 0, i32 15
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = sub i64 %t63, 1
  %t67 = load ptr, ptr %l38, !tbaa !29
  %t68 = getelementptr %"compiler/check:frame", ptr %t67, i32 0, i32 15
  store i64 %t65, ptr %t68, !tbaa !24
  %t69 = load ptr, ptr %l4, !tbaa !29
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 16
  store i64 %t70, ptr %t73, !tbaa !24
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  store ptr %t79, ptr %l45, !tbaa !29
  %t80 = load ptr, ptr %l8, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t80)
  store i32 %t83, ptr %l48
  br label %bb9
bb9:
  %t84 = load ptr, ptr %l45, !tbaa !29
  %t85 = load i32, ptr %l48, !tbaa !23
  %t86 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l49
  br label %bb10
bb10:
  %t87 = load i1, ptr %l49, !tbaa !21
  store i1 %t87, ptr %l9, !tbaa !21
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 17
  %t91 = load i64, ptr %t90, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp eq i64 %t91, %t92
  br i1 %t95, label %bb11, label %bb12
bb11:
  %t97 = load ptr, ptr %l8, !tbaa !29
  %t100 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t97)
  store i32 %t100, ptr %l57
  br label %bb13
bb12:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb14
bb13:
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t102 = load i32, ptr %l57, !tbaa !23
  %t104 = icmp ne i32 %t102, %t101
  store i1 %t104, ptr %l54, !tbaa !21
  br label %bb14
bb14:
  %t106 = load i1, ptr %l54, !tbaa !21
  br i1 %t106, label %bb15, label %bb16
bb15:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %t107)
  store i1 %t109, ptr %l62
  br label %bb17
bb16:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb18
bb17:
  %t110 = load i1, ptr %l62, !tbaa !21
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %l60, !tbaa !21
  br label %bb18
bb18:
  %t113 = load i1, ptr %l60, !tbaa !21
  br i1 %t113, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s1
  %t114 = load i1, ptr %l9, !tbaa !21
  br i1 %t114, label %bb21, label %bb22
bb20:
  br label %bb29
bb21:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l1
  %t118 = load ptr, ptr %l8, !tbaa !29
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %t116, %"compiler/source:Span" %t117, ptr %t118)
  store ptr %t122, ptr %l68
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t123 = load ptr, ptr %l68, !tbaa !29
  store ptr %t123, ptr %rv
  br label %ret
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l69, !tbaa !29
  %t125 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t126 = load i32, ptr %t125, !tbaa !23
  %t128 = sub i32 %t126, 1
  %t129 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t130 = load i32, ptr %t129, !tbaa !23
  %t133 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t128, i32 %t130)
  store %"compiler/source:Span" %t133, ptr %l73
  br label %bb25
bb25:
  %t134 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %s1)
  store %"compiler/msgs:Msg" %t134, ptr %l74
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l69, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l73
  %t137 = load %"compiler/msgs:Msg", ptr %l74
  %t138 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t135, %"compiler/source:Span" %t136, %"compiler/msgs:Msg" %t137)
  store i64 %t138, ptr %l75
  br label %bb27
bb27:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l1
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t139, %"compiler/source:Span" %t140)
  store ptr %t143, ptr %l78
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s1)
  %t144 = load ptr, ptr %l78, !tbaa !29
  store ptr %t144, ptr %rv
  br label %ret
bb29:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t147 = getelementptr %"compiler/check:frame", ptr %t145, i32 0, i32 25
  %t148 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %t147, i64 %t148)
  br label %bb30
bb30:
  %t151 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t151, ptr %l82
  %t152 = load ptr, ptr %l8, !tbaa !29
  %t155 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t152)
  store i32 %t155, ptr %l85
  br label %bb31
bb31:
  %t156 = load ptr, ptr %l8, !tbaa !29
  store ptr %t156, ptr %l87, !tbaa !29
  %t158 = icmp sge i64 0, 0
  br i1 %t158, label %bb32, label %bb33
bb32:
  %t160 = icmp sle i64 0, 1152921504606846975
  br i1 %t160, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_77940e7aab679ede_bd13144cbc386012)
  unreachable
bb34:
  %t162 = mul i64 0, 8
  %t163 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t162)
  %t164 = insertvalue { i64, ptr } undef, i64 0, 0
  %t165 = insertvalue { i64, ptr } %t164, ptr %t163, 1
  %t166 = load ptr, ptr %l87, !tbaa !29
  %t168 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t166, { i64, ptr } %t165, i1 true, i1 false)
  store %"compiler/typed:Try" %t168, ptr %l91
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_77940e7aab679ede_bd13144cbc386012)
  unreachable
bb36:
  %t169 = load %"compiler/typed:Try", ptr %l91
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t169, ptr %t170
  store { i64, [5 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 0
  store i64 14, ptr %t172
  %t173 = load %"compiler/source:Span", ptr %l82
  %t174 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t173, 0
  %t175 = load i32, ptr %l85, !tbaa !23
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } %t174, i32 %t175, 1
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, ptr %t170, 2
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t171, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t178, ptr %t179
  %t180 = load { i64, [5 x i64] }, ptr %t171
  %t181 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t181, ptr %lp10
  %t183 = load ptr, ptr %lp10
  store { i64, [5 x i64] } %t180, ptr %t183
  %t184 = load i1, ptr %l9, !tbaa !21
  br i1 %t184, label %bb37, label %bb38
bb37:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  %t188 = load ptr, ptr %lp10
  %t192 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %t186, %"compiler/source:Span" %t187, ptr %t188)
  store ptr %t192, ptr %l99
  br label %bb39
bb38:
  %t193 = load ptr, ptr %lp10
  store ptr %t193, ptr %l95, !tbaa !29
  br label %bb40
bb39:
  %t195 = load ptr, ptr %l99, !tbaa !29
  store ptr %t195, ptr %l95, !tbaa !29
  br label %bb40
bb40:
  %t196 = load ptr, ptr %l95, !tbaa !29
  store ptr %t196, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t10)
  store ptr %t12, ptr %l12
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l12, !tbaa !29
  %t15 = getelementptr %"compiler/check:frame", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t19 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t17, i64 %t16)
  store ptr %t19, ptr %l15
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 6
  %t23 = load ptr, ptr %t22, !tbaa !29
  store ptr %t23, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = icmp eq ptr %t25, null
  br i1 %t27, label %bb3, label %bb4
bb3:
  call void @__olang_check_failed(ptr @olang_loc_37018c2ebf0da22a_371c8892c4c63a5e)
  unreachable
bb4:
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/source:Source", ptr %t29, i32 0, i32 1
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t35 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t38 = sext i32 %t36 to i64
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t42 = load i32, ptr %t41, !tbaa !23
  %t44 = sext i32 %t42 to i64
  %t47 = icmp slt i64 %t40, %t44
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load i64, ptr %l6, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t55 = icmp slt i64 %t49, %t52
  store i1 %t55, ptr %l29, !tbaa !21
  br label %bb9
bb8:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t57 = load i1, ptr %l29, !tbaa !21
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t58 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t58, ptr %l35, !tbaa !27
  %t59 = load i64, ptr %l6, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i8, ptr %t62, i64 %t59
  %t64 = load i8, ptr %t63, !tbaa !32
  %t66 = icmp eq i8 %t64, 32
  br i1 %t66, label %bb12, label %bb13
bb11:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb21
bb12:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb14
bb13:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i8, ptr %t72, i64 %t69
  %t74 = load i8, ptr %t73, !tbaa !32
  %t76 = icmp eq i8 %t74, 10
  store i1 %t76, ptr %l39, !tbaa !21
  br label %bb14
bb14:
  %t78 = load i1, ptr %l39, !tbaa !21
  br i1 %t78, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb17
bb16:
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t79, ptr %l45, !tbaa !27
  %t80 = load i64, ptr %l6, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i8, ptr %t83, i64 %t80
  %t85 = load i8, ptr %t84, !tbaa !32
  %t87 = icmp eq i8 %t85, 9
  store i1 %t87, ptr %l44, !tbaa !21
  br label %bb17
bb17:
  %t89 = load i1, ptr %l44, !tbaa !21
  br i1 %t89, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb20
bb19:
  %t90 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t90, ptr %l50, !tbaa !27
  %t91 = load i64, ptr %l6, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i8, ptr %t94, i64 %t91
  %t96 = load i8, ptr %t95, !tbaa !32
  %t98 = icmp eq i8 %t96, 41
  store i1 %t98, ptr %l49, !tbaa !21
  br label %bb20
bb20:
  %t100 = load i1, ptr %l49, !tbaa !21
  store i1 %t100, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t101 = load i1, ptr %l34, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s1)
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t104 = load i64, ptr %l6, !tbaa !24
  %t106 = add i64 %t104, 1
  store i64 %t106, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb25
bb25:
  br label %bb6
bb26:
  %t108 = load i64, ptr %l6, !tbaa !24
  %t110 = trunc i64 %t108 to i32
  %t111 = load i64, ptr %l6, !tbaa !24
  %t115 = add i64 %t111, %a3
  %t117 = trunc i64 %t115 to i32
  %t120 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t110, i32 %t117)
  store %"compiler/source:Span" %t120, ptr %l63
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t121 = load %"compiler/source:Span", ptr %l63
  store %"compiler/source:Span" %t121, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyKey(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l27 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l28 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 10
  %t7 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l9
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l9, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t24 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t22, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t24, ptr %l17
  br label %bb5
bb5:
  %t25 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t25, ptr %l12
  br label %bb17
bb6:
  %t26 = load { i64, [2 x i64] }, ptr %l2
  %t28 = extractvalue { i64, [2 x i64] } %t26, 0
  %t29 = icmp eq i64 %t28, 1
  br i1 %t29, label %bb7, label %bb8
bb7:
  %t31 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t32 = getelementptr { i32, i32 }, ptr %t31, i32 0, i32 0
  %t33 = load i32, ptr %t32
  store i32 %t33, ptr %l4, !tbaa !23
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t36 = getelementptr { i32, i32 }, ptr %t35, i32 0, i32 1
  %t37 = load i32, ptr %t36
  store i32 %t37, ptr %l5, !tbaa !23
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load i32, ptr %l4, !tbaa !23
  %t41 = sext i32 %t39 to i64
  %t43 = sub i64 -2, %t41
  %t44 = load i32, ptr %l5, !tbaa !23
  %t46 = sext i32 %t44 to i64
  %t49 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t43, i64 %t46)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t49, ptr %l27
  br label %bb10
bb10:
  %t50 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l27
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t50, ptr %l12
  br label %bb17
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 -1, i64 -1)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t51, ptr %l28
  br label %bb15
bb15:
  %t52 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l28
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t52, ptr %l12
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_f6343df54e321530_17a07bfc25de31ec)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t53, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %rv
  ret %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eborrowedSource(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i32
  %l20 = alloca i32
  %l23 = alloca i1
  %l24 = alloca i1
  %l29 = alloca i64
  %l33 = alloca i1
  %l37 = alloca i1
  %l40 = alloca ptr
  %l45 = alloca i32
  %l50 = alloca i64
  %l53 = alloca i32
  %l57 = alloca i64
  %l59 = alloca ptr
  %l62 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l65 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l71 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca i1
  %l79 = alloca ptr
  %rv = alloca i64
  %t159 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l9
  br label %bb1
bb1:
  %t5 = load i32, ptr %l9, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l3, !tbaa !23
  %t10 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t6, i32 %t7)
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t12 = load i32, ptr %l3, !tbaa !23
  store i32 %t12, ptr %l13, !tbaa !23
  br label %bb6
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l3, !tbaa !23
  %t21 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t19, i32 %t20, i64 %t21)
  store i32 %t25, ptr %l20
  br label %bb5
bb5:
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %l13, !tbaa !23
  br label %bb6
bb6:
  %t27 = load i32, ptr %l13, !tbaa !23
  store i32 %t27, ptr %l4, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l3, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t28, i32 %t29)
  store i1 %t32, ptr %l23
  br label %bb7
bb7:
  %t33 = load i1, ptr %l23, !tbaa !21
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l3, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l29
  br label %bb10
bb9:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t44 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t45 = load i64, ptr %l29, !tbaa !24
  %t47 = and i64 %t45, %t44
  %t49 = icmp ne i64 %t47, 0
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t52, ptr %t53)
  store i1 %t57, ptr %l37
  br label %bb14
bb13:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb15
bb14:
  %t58 = load i1, ptr %l37, !tbaa !21
  store i1 %t58, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l33, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  store ptr %t65, ptr %l40, !tbaa !29
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l3, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l45
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l3, !tbaa !23
  %t85 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t81, i32 %t82)
  store i64 %t85, ptr %l50
  br label %bb19
bb19:
  %t86 = load i64, ptr @G_2ecompiler_2ftypes_2eOwning, !tbaa !24
  %t87 = load i64, ptr %l50, !tbaa !24
  %t89 = and i64 %t87, %t86
  %t90 = load ptr, ptr %l40, !tbaa !29
  %t91 = load i32, ptr %l45, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t90, i32 %t91, i64 %t89)
  store i32 %t93, ptr %l53
  br label %bb20
bb20:
  %t94 = load i32, ptr %l53, !tbaa !23
  store i32 %t94, ptr %l4, !tbaa !23
  br label %bb21
bb21:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t97 = load i32, ptr %l4, !tbaa !23
  %t101 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, i32 %t97)
  store i64 %t101, ptr %l57
  br label %bb22
bb22:
  %t102 = load i64, ptr %l57, !tbaa !24
  store i64 %t102, ptr %l5, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 54
  store ptr %t105, ptr %l59, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l5, !tbaa !24
  %t110 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t106, i64 %t107)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t110, ptr %l62
  br label %bb23
bb23:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i32, ptr %l3, !tbaa !23
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t111, i32 %t112)
  store i1 %t115, ptr %l65
  br label %bb24
bb24:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb25, label %bb26
bb25:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l2, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v0, ptr %t117, ptr %t118)
  store i1 %t122, ptr %l70
  br label %bb27
bb26:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l71, !tbaa !29
  %t124 = load ptr, ptr %l2, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t124)
  store ptr %t126, ptr %l73
  br label %bb28
bb27:
  %t127 = load i1, ptr %l70, !tbaa !21
  store i1 %t127, ptr %l66, !tbaa !21
  br label %bb30
bb28:
  %t128 = load ptr, ptr %l71, !tbaa !29
  %t129 = load ptr, ptr %l73, !tbaa !29
  %t130 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v0, ptr %t128, ptr %t129)
  store i1 %t130, ptr %l74
  br label %bb29
bb29:
  %t131 = load i1, ptr %l74, !tbaa !21
  store i1 %t131, ptr %l66, !tbaa !21
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l59, !tbaa !29
  %t133 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l62
  %t134 = load i1, ptr %l66, !tbaa !21
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t132, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t133, i1 %t134)
  br label %bb31
bb31:
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load ptr, ptr %l2, !tbaa !29
  %t137 = load i32, ptr %l4, !tbaa !23
  %t138 = load %"compiler/source:Span", ptr %l1
  %t143 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t135, ptr %t136, i32 %t137, %"compiler/source:Span" %t138)
  store ptr %t143, ptr %l79
  br label %bb32
bb32:
  %t144 = load ptr, ptr %l79, !tbaa !29
  store ptr %t144, ptr %l6, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load i64, ptr %l5, !tbaa !24
  %t147 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v0, ptr %t145, i64 %t146, ptr %t147)
  br label %bb33
bb33:
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  %t154 = load i64, ptr %l5, !tbaa !24
  %t156 = trunc i64 %t154 to i32
  %t158 = load ptr, ptr %l6, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t159
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 0
  store i64 0, ptr %t160
  %t162 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t153, 0
  %t164 = insertvalue { %"compiler/source:Span", i32, ptr } %t162, i32 %t156, 1
  %t166 = insertvalue { %"compiler/source:Span", i32, ptr } %t164, ptr %t158, 2
  %t167 = getelementptr { i64, [3 x i64] }, ptr %t159, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t166, ptr %t167
  %t168 = load { i64, [3 x i64] }, ptr %t159
  %t170 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t168, ptr %t170
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t152, ptr %t170)
  br label %bb34
bb34:
  %t173 = load i64, ptr %l5, !tbaa !24
  store i64 %t173, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildConst(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca { %"compiler/cond:Value", i1 }
  %l4 = alloca %"compiler/cond:Value"
  %l5 = alloca i1
  %lp6 = alloca ptr
  %l8 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca { %"compiler/cond:Value", i1 }
  %l17 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { %"compiler/cond:Value", i1 }
  %l22 = alloca i32
  %l27 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l37 = alloca i64
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca i32
  %l48 = alloca i32
  %l50 = alloca i32
  %l52 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l64 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l79 = alloca i32
  %l81 = alloca i32
  %l83 = alloca ptr
  %l96 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t182 = alloca { i64, [2 x i64] }, align 8
  %t190 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 86
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t4)
  store ptr %t6, ptr %l10
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t9 = getelementptr %"compiler/check:frame", ptr %t7, i32 0, i32 0
  %t10 = load i64, ptr %t9, !tbaa !24
  %t11 = load ptr, ptr %l8, !tbaa !29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t11, i64 %t10, i1 true)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/load:Loader", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l17, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %a2)
  store { i64, ptr } %t27, ptr %l20
  br label %bb3
bb3:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t30 = call { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v0, ptr %t28, { i64, ptr } %t29)
  %t31 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t30, 1
  %t32 = extractvalue { i32, { %"compiler/cond:Value", i1 } } %t30, 0
  store i32 %t32, ptr %l22
  %t33 = icmp ne i32 %t32, 0
  br i1 %t33, label %bb5, label %ok.34
ok.34:
  store { %"compiler/cond:Value", i1 } %t31, ptr %l21
  br label %bb4
bb4:
  %t35 = load { %"compiler/cond:Value", i1 }, ptr %l21
  store { %"compiler/cond:Value", i1 } %t35, ptr %l13
  br label %bb9
bb5:
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t36, %"compiler/source:Span" %t37, { i64, ptr } { i64 32, ptr @.d7 })
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load ptr, ptr %l27, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { %"compiler/cond:Value", i1 }, ptr %l13
  store { %"compiler/cond:Value", i1 } %t46, ptr %l3
  %t47 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l3, i32 0, i32 0
  %t48 = load %"compiler/cond:Value", ptr %t47
  store %"compiler/cond:Value" %t48, ptr %l4
  %t50 = getelementptr { %"compiler/cond:Value", i1 }, ptr %l3, i32 0, i32 1
  %t51 = load i1, ptr %t50, !tbaa !21
  store i1 %t51, ptr %l5, !tbaa !21
  %t53 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t54 = load i32, ptr %t53
  %t56 = trunc i64 1 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb10, label %bb11
bb10:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l32, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t60, ptr %l33
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t61, ptr %l34, !tbaa !23
  %t62 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  %t65 = icmp ne i64 %t63, 0
  br i1 %t65, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  store i64 1, ptr %l37, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb14
bb14:
  %t67 = load ptr, ptr %l32, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l33
  %t69 = load i32, ptr %l34, !tbaa !23
  %t70 = load i64, ptr %l37, !tbaa !24
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, i32 %t69, i64 %t70)
  store ptr %t71, ptr %l38
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load ptr, ptr %l38, !tbaa !29
  store ptr %t72, ptr %rv
  br label %ret
bb16:
  %t73 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t74 = load i32, ptr %t73
  %t76 = trunc i64 2 to i32
  %t77 = icmp eq i32 %t74, %t76
  br i1 %t77, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t80, ptr %l42
  %t81 = load i1, ptr %l5, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb18:
  br label %bb25
bb19:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t90 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s3, ptr %t88, { i64, ptr } { i64 3, ptr @.d8 })
  store i32 %t90, ptr %l48
  br label %bb21
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t91)
  store i32 %t93, ptr %l50
  br label %bb22
bb21:
  %t94 = load i32, ptr %l48, !tbaa !23
  store i32 %t94, ptr %l44, !tbaa !23
  br label %bb23
bb22:
  %t95 = load i32, ptr %l50, !tbaa !23
  store i32 %t95, ptr %l44, !tbaa !23
  br label %bb23
bb23:
  %t96 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 1
  %t97 = load i64, ptr %t96, !tbaa !24
  %t98 = load ptr, ptr %l41, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l42
  %t100 = load i32, ptr %l44, !tbaa !23
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t100, i64 %t97)
  store ptr %t102, ptr %l52
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load ptr, ptr %l52, !tbaa !29
  store ptr %t103, ptr %rv
  br label %ret
bb25:
  %t104 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t105 = load i32, ptr %t104
  %t107 = trunc i64 3 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l55, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t111, ptr %l56
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 2
  %t119 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s4, ptr %t117, { i64, ptr } { i64 3, ptr @.d9 })
  store i32 %t119, ptr %l60
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t120 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 2
  %t121 = load double, ptr %t120, !tbaa !26
  %t123 = bitcast double %t121 to i64
  %t125 = load ptr, ptr %l55, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l56
  %t127 = load i32, ptr %l60, !tbaa !23
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t125, %"compiler/source:Span" %t126, i32 %t127, i64 %t123)
  store ptr %t129, ptr %l64
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load ptr, ptr %l64, !tbaa !29
  store ptr %t130, ptr %rv
  br label %ret
bb30:
  %t131 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 0
  %t132 = load i32, ptr %t131
  %t134 = trunc i64 4 to i32
  %t135 = icmp eq i32 %t132, %t134
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = getelementptr %"compiler/generic:Program", ptr %t140, i32 0, i32 0
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/load:Loader", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/cond:Consts", ptr %t146, i32 0, i32 6
  %t149 = getelementptr %"compiler/cond:Value", ptr %l4, i32 0, i32 3
  %t150 = load i64, ptr %t149, !tbaa !24
  %t153 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t148, i64 %t150)
  store { i64, ptr } %t153, ptr %l73
  br label %bb33
bb32:
  br label %bb37
bb33:
  %t154 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t154, ptr %lp6
  %t155 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t156 = load ptr, ptr %lp6
  store { i64, ptr } %t155, ptr %t156, !tbaa !27
  %t157 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t157, ptr %l74
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l77, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t164)
  store i32 %t166, ptr %l79
  br label %bb34
bb34:
  %t167 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t168 = load ptr, ptr %l77, !tbaa !29
  %t169 = load i32, ptr %l79, !tbaa !23
  %t171 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t168, i32 %t169, i64 %t167)
  store i32 %t171, ptr %l81
  br label %bb35
bb35:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t172)
  store ptr %t174, ptr %l83
  br label %bb36
bb36:
  %t175 = load ptr, ptr %l83, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 2
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = load ptr, ptr %lp6
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t182
  %t183 = getelementptr { i64, [2 x i64] }, ptr %t182, i32 0, i32 0
  store i64 1, ptr %t183
  %t185 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t180, 0
  %t186 = getelementptr { i64, [2 x i64] }, ptr %t182, i32 0, i32 1
  store { { i64, ptr } } %t185, ptr %t186
  %t187 = load { i64, [2 x i64] }, ptr %t182
  %t189 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t187, ptr %t189
  store { i64, [5 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 0
  store i64 1, ptr %t191
  %t192 = load %"compiler/source:Span", ptr %l74
  %t193 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t192, 0
  %t194 = load i32, ptr %l81, !tbaa !23
  %t195 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t193, i32 %t194, 1
  %t197 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t195, i64 %t178, 2
  %t199 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t197, ptr %t189, 3
  %t200 = getelementptr { i64, [5 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t199, ptr %t200
  %t201 = load { i64, [5 x i64] }, ptr %t190
  %t203 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t201, ptr %t203
  call void @__olang_scope_close(ptr %s0)
  store ptr %t203, ptr %rv
  br label %ret
bb37:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t205, %"compiler/source:Span" %t206, { i64, ptr } { i64 35, ptr @.d10 })
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load %"compiler/source:Span", ptr %l1
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t209, %"compiler/source:Span" %t210)
  store ptr %t213, ptr %l96
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t214 = load ptr, ptr %l96, !tbaa !29
  store ptr %t214, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildDefaulted(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 5
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l10
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l10, !tbaa !29
  store ptr %t14, ptr %l4, !tbaa !29
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/load:Module", ptr %t15, i32 0, i32 3
  %t18 = load i1, ptr %t17, !tbaa !21
  br i1 %t18, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t20 = load ptr, ptr %l4, !tbaa !29
  %t22 = getelementptr %"compiler/load:Module", ptr %t20, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 4, ptr @.d11 })
  store i1 %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l13, !tbaa !21
  br i1 %t27, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb9
bb7:
  %t30 = getelementptr %"compiler/ast:VarDecl", ptr %a3, i32 0, i32 2
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v1, ptr %t31)
  store i1 %t33, ptr %l20
  br label %bb8
bb8:
  %t34 = load i1, ptr %l20, !tbaa !21
  store i1 %t34, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t35 = load i1, ptr %l17, !tbaa !21
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 0
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/load:Loader", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  store ptr %t46, ptr %l25, !tbaa !29
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t47, i32 %a2)
  store { i64, ptr } %t51, ptr %l28
  br label %bb13
bb13:
  %t52 = load ptr, ptr %l25, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t54 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v0, ptr %t52, { i64, ptr } %t53)
  store i1 %t54, ptr %l29
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i1, ptr %l29, !tbaa !21
  store i1 %t55, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca { i64, [3 x i64] }
  %l29 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca { i64, [3 x i64] }
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca i1
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %lp47 = alloca ptr
  %l48 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l67 = alloca ptr
  %l72 = alloca i32
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l77 = alloca %"compiler/source:Span"
  %l81 = alloca i1
  %l85 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i64
  %l95 = alloca i64
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l101 = alloca i1
  %l103 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca %"compiler/source:Span"
  %l112 = alloca i64
  %l116 = alloca ptr
  %l117 = alloca ptr
  %l121 = alloca i32
  %l122 = alloca { i64, ptr }
  %l126 = alloca %"compiler/source:Span"
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l131 = alloca i64
  %l133 = alloca ptr
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l146 = alloca i64
  %l152 = alloca i1
  %l165 = alloca i1
  %l168 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca %"compiler/source:Span"
  %l174 = alloca %"compiler/msgs:Msg"
  %l175 = alloca i64
  %l181 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca %"compiler/source:Span"
  %l187 = alloca i64
  %l190 = alloca { i64, ptr }
  %l192 = alloca %"compiler/msgs:Msg"
  %l193 = alloca i64
  %l199 = alloca ptr
  %l204 = alloca i64
  %l207 = alloca i64
  %l229 = alloca i1
  %l234 = alloca { i64, ptr }
  %l237 = alloca %"compiler/source:Span"
  %l244 = alloca i1
  %l249 = alloca i1
  %l250 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l264 = alloca { i64, [3 x i64] }
  %l266 = alloca { i64, ptr }
  %l269 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l280 = alloca i1
  %l285 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l289 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca %"compiler/source:Span"
  %l295 = alloca i64
  %l296 = alloca i64
  %l299 = alloca i1
  %l300 = alloca { i64, ptr }
  %l302 = alloca i32
  %l305 = alloca i32
  %l306 = alloca ptr
  %l309 = alloca { i64, ptr }
  %l313 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l320 = alloca { i64, ptr }
  %l324 = alloca { i64, ptr }
  %l327 = alloca ptr
  %l331 = alloca ptr
  %l333 = alloca i32
  %l334 = alloca i32
  %l337 = alloca i1
  %l341 = alloca { i64, ptr }
  %l344 = alloca i32
  %l348 = alloca ptr
  %l350 = alloca { i64, ptr }
  %l353 = alloca %"compiler/source:Span"
  %l354 = alloca %"compiler/msgs:Msg"
  %l355 = alloca i64
  %l358 = alloca ptr
  %l361 = alloca { i64, ptr }
  %l364 = alloca i1
  %l365 = alloca i1
  %l366 = alloca ptr
  %l370 = alloca i1
  %l371 = alloca ptr
  %l372 = alloca ptr
  %l376 = alloca %"compiler/source:Span"
  %l377 = alloca %"compiler/msgs:Msg"
  %l378 = alloca i64
  %l379 = alloca ptr
  %l380 = alloca ptr
  %l383 = alloca ptr
  %l384 = alloca { i64, ptr }
  %l386 = alloca i32
  %l388 = alloca { i64, ptr }
  %l391 = alloca %"compiler/source:Span"
  %l392 = alloca ptr
  %l395 = alloca ptr
  %l400 = alloca { i64, [3 x i64] }
  %l404 = alloca ptr
  %l407 = alloca ptr
  %l410 = alloca ptr
  %l411 = alloca { i64, ptr }
  %l413 = alloca i32
  %l415 = alloca { i64, ptr }
  %l418 = alloca %"compiler/source:Span"
  %l419 = alloca ptr
  %l425 = alloca ptr
  %l427 = alloca ptr
  %l430 = alloca i64
  %l431 = alloca i64
  %l432 = alloca ptr
  %l433 = alloca %"compiler/source:Span"
  %l436 = alloca { i64, ptr }
  %l439 = alloca ptr
  %l453 = alloca ptr
  %l454 = alloca ptr
  %l455 = alloca %"compiler/source:Span"
  %l456 = alloca i64
  %l457 = alloca i64
  %l460 = alloca i1
  %l461 = alloca { i64, ptr }
  %l463 = alloca i32
  %l466 = alloca i32
  %l467 = alloca ptr
  %l471 = alloca i32
  %l475 = alloca i32
  %l480 = alloca { i64, ptr }
  %l483 = alloca i1
  %l485 = alloca ptr
  %l491 = alloca ptr
  %l492 = alloca %"compiler/source:Span"
  %l494 = alloca %"compiler/msgs:Msg"
  %l495 = alloca i64
  %l499 = alloca ptr
  %l500 = alloca %"compiler/source:Span"
  %l502 = alloca %"compiler/msgs:Msg"
  %l503 = alloca i64
  %l504 = alloca ptr
  %l505 = alloca %"compiler/source:Span"
  %l506 = alloca %"compiler/msgs:Msg"
  %l507 = alloca i64
  %l512 = alloca { i64, ptr }
  %l516 = alloca ptr
  %l517 = alloca ptr
  %l528 = alloca i32
  %l531 = alloca i1
  %l532 = alloca i1
  %l537 = alloca i64
  %l542 = alloca ptr
  %l547 = alloca i32
  %l552 = alloca i64
  %l555 = alloca i32
  %l560 = alloca i32
  %l565 = alloca ptr
  %l570 = alloca i32
  %l571 = alloca { i64, ptr }
  %l572 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l578 = alloca i64
  %l581 = alloca i64
  %l599 = alloca { i64, ptr }
  %l604 = alloca i1
  %l605 = alloca i1
  %l611 = alloca i64
  %l614 = alloca i1
  %l619 = alloca i64
  %l625 = alloca ptr
  %l630 = alloca i32
  %l635 = alloca i64
  %l638 = alloca i32
  %l646 = alloca ptr
  %l649 = alloca ptr
  %l651 = alloca { i64, ptr }
  %l652 = alloca i32
  %l653 = alloca i32
  %l660 = alloca { i64, ptr }
  %l664 = alloca i32
  %l665 = alloca %"compiler/source:Span"
  %l666 = alloca i32
  %l671 = alloca %"compiler/typed:Call"
  %l676 = alloca i64
  %l679 = alloca i1
  %l681 = alloca ptr
  %l685 = alloca i1
  %l688 = alloca i1
  %l699 = alloca ptr
  %l703 = alloca i64
  %l706 = alloca %"compiler/source:Span"
  %l707 = alloca i32
  %l711 = alloca { i64, ptr }
  %l713 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %s38 = alloca %olang.scope
  %rv = alloca ptr
  %t1287 = alloca { i64, [2 x i64] }, align 8
  %t1298 = alloca { i64, [5 x i64] }, align 8
  %t1390 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  store ptr %a6, ptr %l6
  store { i64, ptr } %a7, ptr %l7
  store { i64, ptr } %a8, ptr %l8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 42
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l9, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 42
  store { i64, ptr } { i64 0, ptr @.d12 }, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 41
  %t12 = load %"compiler/source:Span", ptr %t11
  store %"compiler/source:Span" %t12, ptr %l10
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l54, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t15, ptr %l55
  br label %bb1
bb1:
  %t16 = load %"compiler/source:Span", ptr %l55
  %t17 = load ptr, ptr %l54, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 41
  store %"compiler/source:Span" %t16, ptr %t18
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 36
  %t22 = load i1, ptr %t21, !tbaa !21
  store i1 %t22, ptr %l11, !tbaa !21
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 36
  store i1 false, ptr %t26, !tbaa !21
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t31 = icmp eq i32 %t27, %t28
  br i1 %t31, label %bb2, label %bb3
bb2:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t33, %"compiler/source:Span" %t34)
  store ptr %t37, ptr %l64
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load ptr, ptr %l64, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l67, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = getelementptr %"compiler/generic:Program", ptr %t48, i32 0, i32 2
  %t51 = load i32, ptr %l3, !tbaa !23
  %t54 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t50, i32 %t51)
  store i32 %t54, ptr %l72
  br label %bb6
bb6:
  %t55 = load ptr, ptr %l67, !tbaa !29
  %t56 = load i32, ptr %l72, !tbaa !23
  %t57 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t55, i32 %t56)
  store { i64, ptr } %t57, ptr %l73
  br label %bb7
bb7:
  %t58 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t58, ptr %l12, !tbaa !27
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 32
  %t63 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l76
  br label %bb8
bb8:
  %t64 = load i64, ptr %l76, !tbaa !24
  store i64 %t64, ptr %l13, !tbaa !24
  %t65 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 -1, i32 -1)
  store %"compiler/source:Span" %t65, ptr %l77
  br label %bb9
bb9:
  %t66 = load %"compiler/source:Span", ptr %l77
  store %"compiler/source:Span" %t66, ptr %l14
  %t67 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb10, label %bb11
bb10:
  %t73 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t77 = icmp sgt i64 %t75, 0
  store i1 %t77, ptr %l81, !tbaa !21
  br label %bb12
bb11:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb12
bb12:
  %t79 = load i1, ptr %l81, !tbaa !21
  br i1 %t79, label %bb13, label %bb14
bb13:
  %t80 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t84 = icmp eq i64 %t82, 1
  store i1 %t84, ptr %l85, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l85, !tbaa !21
  br label %bb15
bb15:
  %t86 = load i1, ptr %l85, !tbaa !21
  br i1 %t86, label %bb16, label %bb17
bb16:
  %t87 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t87, 0
  store i64 %t89, ptr %l91, !tbaa !24
  %t90 = load ptr, ptr %l6, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  %t94 = xor i1 %t92, true
  br i1 %t94, label %bb18, label %bb19
bb17:
  store i1 false, ptr %l89, !tbaa !21
  br label %bb21
bb18:
  store i64 1, ptr %l95, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l91, !tbaa !24
  %t97 = load i64, ptr %l95, !tbaa !24
  %t98 = sub i64 %t96, %t97
  %t100 = icmp sgt i64 %t98, 1
  store i1 %t100, ptr %l89, !tbaa !21
  br label %bb21
bb21:
  %t102 = load i1, ptr %l89, !tbaa !21
  br i1 %t102, label %bb22, label %bb23
bb22:
  %t103 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t103, ptr %l99, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr ptr, ptr %t105, i64 0
  %t107 = load ptr, ptr %t106, !tbaa !39
  %t109 = call i1 @compiler_2fcheck_2ecallLike(ptr %v1, ptr %t107)
  store i1 %t109, ptr %l101
  br label %bb24
bb23:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb25
bb24:
  %t110 = load i1, ptr %l101, !tbaa !21
  store i1 %t110, ptr %l98, !tbaa !21
  br label %bb25
bb25:
  %t111 = load i1, ptr %l98, !tbaa !21
  br i1 %t111, label %bb26, label %bb27
bb26:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t113, ptr %l103, !tbaa !27
  %t114 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !27
  %t116 = getelementptr ptr, ptr %t115, i64 0
  %t117 = load ptr, ptr %t116, !tbaa !39
  %t120 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espread(ptr %v0, ptr %v1, ptr %t112, ptr %t117)
  store { i64, ptr } %t120, ptr %l105
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t121 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t121, ptr %l8, !tbaa !27
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t123, ptr %l107, !tbaa !27
  %t124 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 0
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t130 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t122, ptr %t127)
  store %"compiler/source:Span" %t130, ptr %l109
  br label %bb29
bb29:
  %t131 = load %"compiler/source:Span", ptr %l109
  store %"compiler/source:Span" %t131, ptr %l14
  br label %bb30
bb30:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 31
  %t136 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t134)
  store i64 %t136, ptr %l112
  br label %bb31
bb31:
  %t137 = load i64, ptr %l112, !tbaa !24
  store i64 %t137, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t138 = load ptr, ptr %l6, !tbaa !29
  %t140 = icmp eq ptr %t138, null
  %t142 = xor i1 %t140, true
  br i1 %t142, label %bb32, label %bb33
bb32:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l116, !tbaa !29
  %t145 = load ptr, ptr %l6, !tbaa !29
  store ptr %t145, ptr %l117, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t150 = icmp sgt i64 %t148, 0
  br i1 %t150, label %bb34, label %bb35
bb33:
  br label %bb44
bb34:
  %t152 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t152, ptr %l122, !tbaa !27
  %t153 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 0
  %t156 = load i32, ptr %t155, !tbaa !33
  store i32 %t156, ptr %l121, !tbaa !23
  br label %bb36
bb35:
  %t158 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t158, ptr %l121, !tbaa !23
  br label %bb36
bb36:
  %t160 = load ptr, ptr %l6, !tbaa !29
  %t162 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l126
  br label %bb37
bb37:
  %t163 = load ptr, ptr %l116, !tbaa !29
  %t164 = load ptr, ptr %l117, !tbaa !29
  %t165 = load i32, ptr %l121, !tbaa !23
  %t166 = load %"compiler/source:Span", ptr %l126
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t163, ptr %t164, i32 %t165, %"compiler/source:Span" %t166)
  store ptr %t167, ptr %l127
  br label %bb38
bb38:
  %t168 = load ptr, ptr %l127, !tbaa !29
  store ptr %t168, ptr %l17, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l128, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t174 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v0, ptr %t170, ptr %t171)
  store i64 %t174, ptr %l131
  br label %bb39
bb39:
  %t175 = load ptr, ptr %l17, !tbaa !29
  store ptr %t175, ptr %l133, !tbaa !29
  %t177 = load ptr, ptr %l6, !tbaa !29
  %t179 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t177)
  store %"compiler/source:Span" %t179, ptr %l135
  br label %bb40
bb40:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l5, !tbaa !24
  %t184 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v0, ptr %t180, i64 %t181)
  store { i64, ptr } %t184, ptr %l138
  br label %bb41
bb41:
  %t185 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  %t192 = load ptr, ptr %l128, !tbaa !29
  %t193 = load i64, ptr %l131, !tbaa !24
  %t194 = load ptr, ptr %l133, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l135
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v0, ptr %v0, ptr %t192, i64 %t193, i64 0, ptr %t194, %"compiler/source:Span" %t195, { i64, ptr } %t191)
  br label %bb42
bb42:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 31
  %t200 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t199, ptr %t200)
  br label %bb43
bb43:
  store i64 1, ptr %l16, !tbaa !24
  br label %bb44
bb44:
  %t203 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t203, 0
  %t207 = icmp sgt i64 %t205, 0
  br i1 %t207, label %bb45, label %bb46
bb45:
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  store i64 %t211, ptr %l146, !tbaa !24
  br label %bb47
bb46:
  store i64 0, ptr %l146, !tbaa !24
  br label %bb47
bb47:
  %t213 = load i64, ptr %l146, !tbaa !24
  store i64 %t213, ptr %l18, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  %t218 = icmp sgt i64 %t216, 0
  br i1 %t218, label %bb48, label %bb49
bb48:
  %t220 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = load i64, ptr %l18, !tbaa !24
  %t226 = icmp sgt i64 %t222, %t223
  store i1 %t226, ptr %l152, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb50
bb50:
  %t228 = load i1, ptr %l152, !tbaa !21
  br i1 %t228, label %bb51, label %bb52
bb51:
  %t229 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  store i64 %t231, ptr %l18, !tbaa !24
  br label %bb53
bb52:
  br label %bb53
bb53:
  %t233 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = load i64, ptr %l16, !tbaa !24
  %t239 = sub i64 %t235, %t236
  store i64 %t239, ptr %l19, !tbaa !24
  %t241 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  %t244 = icmp sge i32 %t242, 0
  br i1 %t244, label %bb54, label %bb55
bb54:
  %t246 = load i64, ptr %l18, !tbaa !24
  %t248 = icmp sgt i64 %t246, 1
  store i1 %t248, ptr %l165, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb56
bb56:
  %t250 = load i1, ptr %l165, !tbaa !21
  br i1 %t250, label %bb57, label %bb58
bb57:
  %t251 = load i64, ptr %l18, !tbaa !24
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = icmp ne i64 %t251, %t252
  store i1 %t255, ptr %l168, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb59
bb59:
  %t257 = load i1, ptr %l168, !tbaa !21
  br i1 %t257, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s5
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l172, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t259, ptr %l173
  %t260 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadCount(ptr %s5)
  store %"compiler/msgs:Msg" %t260, ptr %l174
  br label %bb62
bb61:
  br label %bb66
bb62:
  %t261 = load ptr, ptr %l172, !tbaa !29
  %t262 = load %"compiler/source:Span", ptr %l173
  %t263 = load %"compiler/msgs:Msg", ptr %l174
  %t264 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t261, %"compiler/source:Span" %t262, %"compiler/msgs:Msg" %t263)
  store i64 %t264, ptr %l175
  br label %bb63
bb63:
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/check:Checker", ptr %t265, i32 0, i32 31
  %t268 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %t267, i64 %t268)
  br label %bb64
bb64:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l1
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t271, %"compiler/source:Span" %t272)
  store ptr %t275, ptr %l181
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t276 = load ptr, ptr %l181, !tbaa !29
  store ptr %t276, ptr %rv
  br label %ret
bb66:
  %t277 = load i64, ptr %l18, !tbaa !24
  %t278 = load i64, ptr %l19, !tbaa !24
  %t281 = icmp sgt i64 %t277, %t278
  br i1 %t281, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s6
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l185, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t284, ptr %l186
  %t285 = load i64, ptr %l19, !tbaa !24
  store i64 %t285, ptr %l187, !tbaa !24
  %t286 = load i64, ptr %l19, !tbaa !24
  %t288 = icmp eq i64 %t286, 1
  br i1 %t288, label %bb69, label %bb70
bb68:
  br label %bb76
bb69:
  store { i64, ptr } { i64 0, ptr @.d13 }, ptr %l190, !tbaa !27
  br label %bb71
bb70:
  store { i64, ptr } { i64 1, ptr @.d14 }, ptr %l190, !tbaa !27
  br label %bb71
bb71:
  %t290 = load i64, ptr %l18, !tbaa !24
  %t291 = load i64, ptr %l187, !tbaa !24
  %t292 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t294 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s6, ptr %s6, i64 %t291, { i64, ptr } %t292, i64 %t290)
  store %"compiler/msgs:Msg" %t294, ptr %l192
  br label %bb72
bb72:
  %t295 = load ptr, ptr %l185, !tbaa !29
  %t296 = load %"compiler/source:Span", ptr %l186
  %t297 = load %"compiler/msgs:Msg", ptr %l192
  %t298 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t295, %"compiler/source:Span" %t296, %"compiler/msgs:Msg" %t297)
  store i64 %t298, ptr %l193
  br label %bb73
bb73:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 31
  %t302 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %t301, i64 %t302)
  br label %bb74
bb74:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load %"compiler/source:Span", ptr %l1
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t305, %"compiler/source:Span" %t306)
  store ptr %t309, ptr %l199
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t310 = load ptr, ptr %l199, !tbaa !29
  store ptr %t310, ptr %rv
  br label %ret
bb76:
  store i64 0, ptr %l20, !tbaa !24
  %t311 = load i64, ptr %l18, !tbaa !24
  store i64 %t311, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t313 = load i64, ptr %l21, !tbaa !24
  %t314 = load i64, ptr %l20, !tbaa !24
  %t317 = icmp sgt i64 %t313, %t314
  br i1 %t317, label %bb77, label %bb78
bb77:
  %t319 = load i64, ptr %l22, !tbaa !24
  %t321 = icmp sgt i64 %t319, 0
  br i1 %t321, label %bb79, label %bb80
bb78:
  store i64 0, ptr %l204, !tbaa !24
  br label %bb82
bb79:
  %t323 = load i64, ptr %l21, !tbaa !24
  %t324 = load i64, ptr %l20, !tbaa !24
  %t327 = sub i64 %t323, %t324
  %t328 = load i64, ptr %l22, !tbaa !24
  %t331 = add i64 %t327, %t328
  %t333 = sub i64 %t331, 1
  %t334 = load i64, ptr %l22, !tbaa !24
  %t337 = sdiv i64 %t333, %t334
  store i64 %t337, ptr %l207, !tbaa !24
  br label %bb81
bb80:
  store i64 0, ptr %l207, !tbaa !24
  br label %bb81
bb81:
  %t339 = load i64, ptr %l207, !tbaa !24
  store i64 %t339, ptr %l204, !tbaa !24
  br label %bb82
bb82:
  %t340 = load i64, ptr %l204, !tbaa !24
  store i64 %t340, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s8
  %t341 = load i64, ptr %l24, !tbaa !24
  %t342 = load i64, ptr %l23, !tbaa !24
  %t345 = icmp slt i64 %t341, %t342
  %t347 = xor i1 %t345, true
  br i1 %t347, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s8)
  br label %bb184
bb85:
  br label %bb86
bb86:
  %t349 = load i64, ptr %l20, !tbaa !24
  %t350 = load i64, ptr %l24, !tbaa !24
  %t351 = load i64, ptr %l22, !tbaa !24
  %t354 = mul i64 %t350, %t351
  %t357 = add i64 %t349, %t354
  store i64 %t357, ptr %l25, !tbaa !24
  store ptr null, ptr %l26, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t359, ptr %l27
  %t361 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t363 = extractvalue { i64, ptr } %t361, 0
  %t365 = icmp sgt i64 %t363, 0
  br i1 %t365, label %bb87, label %bb88
bb87:
  %t367 = load i64, ptr %l25, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  %t373 = icmp slt i64 %t367, %t370
  store i1 %t373, ptr %l229, !tbaa !21
  br label %bb89
bb88:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb89
bb89:
  %t375 = load i1, ptr %l229, !tbaa !21
  br i1 %t375, label %bb90, label %bb91
bb90:
  %t376 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t376, ptr %l234, !tbaa !27
  %t377 = load i64, ptr %l25, !tbaa !24
  %t379 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t380 = load ptr, ptr %t379, !tbaa !27
  %t381 = getelementptr ptr, ptr %t380, i64 %t377
  %t382 = load ptr, ptr %t381, !tbaa !39
  %t384 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t382)
  store %"compiler/source:Span" %t384, ptr %l237
  br label %bb92
bb91:
  br label %bb93
bb92:
  %t385 = load %"compiler/source:Span", ptr %l237
  store %"compiler/source:Span" %t385, ptr %l27
  br label %bb93
bb93:
  %t386 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t387 = load i32, ptr %t386, !tbaa !23
  %t389 = icmp sge i32 %t387, 0
  br i1 %t389, label %bb94, label %bb95
bb94:
  %t391 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t391, ptr %l27
  br label %bb96
bb95:
  br label %bb96
bb96:
  %t393 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t393, 0
  %t397 = icmp sgt i64 %t395, 0
  br i1 %t397, label %bb97, label %bb98
bb97:
  %t399 = load i64, ptr %l25, !tbaa !24
  %t400 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  %t405 = icmp slt i64 %t399, %t402
  store i1 %t405, ptr %l244, !tbaa !21
  br label %bb99
bb98:
  store i1 false, ptr %l244, !tbaa !21
  br label %bb99
bb99:
  %t407 = load i1, ptr %l244, !tbaa !21
  br i1 %t407, label %bb100, label %bb101
bb100:
  %t408 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t408, ptr %l250, !tbaa !27
  %t409 = load i64, ptr %l25, !tbaa !24
  %t411 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr ptr, ptr %t412, i64 %t409
  %t414 = load ptr, ptr %t413, !tbaa !39
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 0
  %t418 = load ptr, ptr %t417, !tbaa !29
  %t421 = icmp eq ptr %t414, %t418
  %t423 = xor i1 %t421, true
  store i1 %t423, ptr %l249, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l249, !tbaa !21
  br label %bb102
bb102:
  %t425 = load i1, ptr %l249, !tbaa !21
  br i1 %t425, label %bb103, label %bb104
bb103:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t428 = getelementptr %"compiler/check:Checker", ptr %t426, i32 0, i32 9
  %t429 = load { i64, [3 x i64] }, ptr %t428
  store { i64, [3 x i64] } %t429, ptr %l28
  %t431 = load ptr, ptr %l0, !tbaa !29
  store ptr %t431, ptr %l259, !tbaa !29
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l4, !tbaa !29
  %t434 = load i64, ptr %l5, !tbaa !24
  %t435 = load i64, ptr %l16, !tbaa !24
  %t440 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamAt(ptr %v0, ptr %v0, ptr %t432, ptr %t433, i64 %t434, i64 %t435)
  store { i64, [3 x i64] } %t440, ptr %l264
  br label %bb105
bb104:
  %t441 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t445 = icmp sgt i64 %t443, 0
  br i1 %t445, label %bb107, label %bb108
bb105:
  %t447 = load { i64, [3 x i64] }, ptr %l264
  %t448 = load ptr, ptr %l259, !tbaa !29
  %t449 = getelementptr %"compiler/check:Checker", ptr %t448, i32 0, i32 9
  store { i64, [3 x i64] } %t447, ptr %t449
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t451, ptr %l266, !tbaa !27
  %t452 = load i64, ptr %l25, !tbaa !24
  %t454 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr ptr, ptr %t455, i64 %t452
  %t457 = load ptr, ptr %t456, !tbaa !39
  %t458 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t458, ptr %l269, !tbaa !27
  %t459 = load i64, ptr %l16, !tbaa !24
  %t461 = getelementptr { i64, ptr }, ptr %l269, i32 0, i32 1
  %t462 = load ptr, ptr %t461, !tbaa !27
  %t463 = getelementptr i32, ptr %t462, i64 %t459
  %t464 = load i32, ptr %t463, !tbaa !33
  %t465 = load %"compiler/source:Span", ptr %l27
  %t470 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t450, ptr %t457, i32 %t464, %"compiler/source:Span" %t465)
  store ptr %t470, ptr %l273
  br label %bb106
bb106:
  %t471 = load ptr, ptr %l273, !tbaa !29
  store ptr %t471, ptr %l26, !tbaa !29
  %t473 = load ptr, ptr %l0, !tbaa !29
  %t474 = load { i64, [3 x i64] }, ptr %l28
  %t477 = getelementptr %"compiler/check:Checker", ptr %t473, i32 0, i32 9
  store { i64, [3 x i64] } %t474, ptr %t477
  br label %bb175
bb107:
  %t478 = load i64, ptr %l25, !tbaa !24
  %t479 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t484 = icmp slt i64 %t478, %t481
  store i1 %t484, ptr %l280, !tbaa !21
  br label %bb109
bb108:
  store i1 false, ptr %l280, !tbaa !21
  br label %bb109
bb109:
  %t486 = load i1, ptr %l280, !tbaa !21
  br i1 %t486, label %bb110, label %bb111
bb110:
  store i1 false, ptr %l29, !tbaa !21
  %t487 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t487, ptr %l285, !tbaa !27
  %t488 = load i64, ptr %l25, !tbaa !24
  %t490 = getelementptr { i64, ptr }, ptr %l285, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = getelementptr ptr, ptr %t491, i64 %t488
  %t493 = load ptr, ptr %t492, !tbaa !39
  store ptr %t493, ptr %l288, !tbaa !29
  store i1 false, ptr %l289, !tbaa !21
  %t496 = load ptr, ptr %l288, !tbaa !29
  %t497 = icmp ne ptr %t496, null
  br i1 %t497, label %bb112, label %bb113
bb111:
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load %"compiler/source:Span", ptr %l27
  %t503 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t499, %"compiler/source:Span" %t500)
  store ptr %t503, ptr %l425
  br label %bb173
bb112:
  %t504 = load ptr, ptr %l288, !tbaa !29
  %t505 = load i64, ptr %t504
  %t507 = icmp eq i64 %t505, 26
  store i1 %t507, ptr %l289, !tbaa !21
  br label %bb113
bb113:
  %t508 = load i1, ptr %l289, !tbaa !21
  br i1 %t508, label %bb114, label %bb115
bb114:
  br label %bb116
bb115:
  br label %bb117
bb116:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb118
bb117:
  br label %bb118
bb118:
  %t509 = load i1, ptr %l29, !tbaa !21
  br i1 %t509, label %bb119, label %bb120
bb119:
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l293, !tbaa !29
  %t512 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t512, ptr %l294
  %t513 = load i64, ptr %l5, !tbaa !24
  store i64 %t513, ptr %l295, !tbaa !24
  %t514 = load i64, ptr %l16, !tbaa !24
  store i64 %t514, ptr %l296, !tbaa !24
  %t515 = load ptr, ptr %l6, !tbaa !29
  %t517 = icmp eq ptr %t515, null
  %t519 = xor i1 %t517, true
  store i1 %t519, ptr %l299, !tbaa !21
  %t520 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t520, ptr %l300, !tbaa !27
  %t521 = load i64, ptr %l16, !tbaa !24
  %t523 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t524 = load ptr, ptr %t523, !tbaa !27
  %t525 = getelementptr i32, ptr %t524, i64 %t521
  %t526 = load i32, ptr %t525, !tbaa !33
  store i32 %t526, ptr %l302, !tbaa !23
  %t527 = load ptr, ptr %l0, !tbaa !29
  %t528 = load ptr, ptr %l4, !tbaa !29
  %t531 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v0, ptr %t527, ptr %t528)
  store i32 %t531, ptr %l305
  br label %bb121
bb120:
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t533, ptr %l309, !tbaa !27
  %t534 = load i64, ptr %l25, !tbaa !24
  %t536 = getelementptr { i64, ptr }, ptr %l309, i32 0, i32 1
  %t537 = load ptr, ptr %t536, !tbaa !27
  %t538 = getelementptr ptr, ptr %t537, i64 %t534
  %t539 = load ptr, ptr %t538, !tbaa !39
  %t541 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t541, ptr %l313, !tbaa !27
  %t542 = load i64, ptr %l16, !tbaa !24
  %t544 = getelementptr { i64, ptr }, ptr %l313, i32 0, i32 1
  %t545 = load ptr, ptr %t544, !tbaa !27
  %t546 = getelementptr i32, ptr %t545, i64 %t542
  %t547 = load i32, ptr %t546, !tbaa !33
  %t551 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %t532, ptr %t539, i32 %t547)
  store ptr %t551, ptr %l316
  br label %bb123
bb121:
  %t552 = load ptr, ptr %l293, !tbaa !29
  %t553 = load %"compiler/source:Span", ptr %l294
  %t554 = load i64, ptr %l295, !tbaa !24
  %t555 = load i64, ptr %l296, !tbaa !24
  %t556 = load i1, ptr %l299, !tbaa !21
  %t557 = load i32, ptr %l302, !tbaa !23
  %t558 = load i32, ptr %l305, !tbaa !23
  %t559 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %t552, %"compiler/source:Span" %t553, i64 %t554, i64 %t555, i1 %t556, i32 %t557, i32 %t558)
  store ptr %t559, ptr %l306
  br label %bb122
bb122:
  %t560 = load ptr, ptr %l306, !tbaa !29
  store ptr %t560, ptr %l26, !tbaa !29
  br label %bb172
bb123:
  %t562 = load ptr, ptr %l316, !tbaa !29
  store ptr %t562, ptr %l26, !tbaa !29
  %t563 = load ptr, ptr %l26, !tbaa !29
  %t565 = icmp eq ptr %t563, null
  br i1 %t565, label %bb124, label %bb125
bb124:
  %t567 = load ptr, ptr %l0, !tbaa !29
  %t568 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t568, ptr %l320, !tbaa !27
  %t569 = load i64, ptr %l25, !tbaa !24
  %t571 = getelementptr { i64, ptr }, ptr %l320, i32 0, i32 1
  %t572 = load ptr, ptr %t571, !tbaa !27
  %t573 = getelementptr ptr, ptr %t572, i64 %t569
  %t574 = load ptr, ptr %t573, !tbaa !39
  %t576 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t576, ptr %l324, !tbaa !27
  %t577 = load i64, ptr %l16, !tbaa !24
  %t579 = getelementptr { i64, ptr }, ptr %l324, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !27
  %t581 = getelementptr i32, ptr %t580, i64 %t577
  %t582 = load i32, ptr %t581, !tbaa !33
  %t586 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t567, ptr %t574, i32 %t582)
  store ptr %t586, ptr %l327
  br label %bb126
bb125:
  br label %bb127
bb126:
  %t587 = load ptr, ptr %l327, !tbaa !29
  store ptr %t587, ptr %l26, !tbaa !29
  br label %bb127
bb127:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/check:Checker", ptr %t589, i32 0, i32 1
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t594 = getelementptr %"compiler/generic:Program", ptr %t592, i32 0, i32 2
  store ptr %t594, ptr %l331, !tbaa !29
  %t595 = load ptr, ptr %l26, !tbaa !29
  %t597 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t595)
  store i32 %t597, ptr %l333
  br label %bb128
bb128:
  %t598 = load ptr, ptr %l331, !tbaa !29
  %t599 = load i32, ptr %l333, !tbaa !23
  %t600 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t598, i32 %t599)
  store i32 %t600, ptr %l334
  br label %bb129
bb129:
  %t601 = load i32, ptr %l334
  %t603 = trunc i64 22 to i32
  %t604 = icmp eq i32 %t601, %t603
  br i1 %t604, label %bb130, label %bb131
bb130:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t608 = getelementptr %"compiler/check:Checker", ptr %t606, i32 0, i32 1
  %t609 = load ptr, ptr %t608, !tbaa !29
  %t611 = getelementptr %"compiler/generic:Program", ptr %t609, i32 0, i32 2
  %t612 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t612, ptr %l341, !tbaa !27
  %t613 = load i64, ptr %l16, !tbaa !24
  %t615 = getelementptr { i64, ptr }, ptr %l341, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !27
  %t617 = getelementptr i32, ptr %t616, i64 %t613
  %t618 = load i32, ptr %t617, !tbaa !33
  %t621 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t611, i32 %t618)
  store i32 %t621, ptr %l344
  br label %bb132
bb131:
  store i1 false, ptr %l337, !tbaa !21
  br label %bb133
bb132:
  %t622 = load i32, ptr %l344
  %t624 = trunc i64 22 to i32
  %t625 = icmp eq i32 %t622, %t624
  %t627 = xor i1 %t625, true
  store i1 %t627, ptr %l337, !tbaa !21
  br label %bb133
bb133:
  %t629 = load i1, ptr %l337, !tbaa !21
  br i1 %t629, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s19
  %t630 = load ptr, ptr %l0, !tbaa !29
  store ptr %t630, ptr %l348, !tbaa !29
  %t631 = load ptr, ptr %l0, !tbaa !29
  %t632 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t632, ptr %l350, !tbaa !27
  %t633 = load i64, ptr %l25, !tbaa !24
  %t635 = getelementptr { i64, ptr }, ptr %l350, i32 0, i32 1
  %t636 = load ptr, ptr %t635, !tbaa !27
  %t637 = getelementptr ptr, ptr %t636, i64 %t633
  %t638 = load ptr, ptr %t637, !tbaa !39
  %t641 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t631, ptr %t638)
  store %"compiler/source:Span" %t641, ptr %l353
  br label %bb136
bb135:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t643, ptr %l361, !tbaa !27
  %t644 = load i64, ptr %l16, !tbaa !24
  %t646 = getelementptr { i64, ptr }, ptr %l361, i32 0, i32 1
  %t647 = load ptr, ptr %t646, !tbaa !27
  %t648 = getelementptr i32, ptr %t647, i64 %t644
  %t649 = load i32, ptr %t648, !tbaa !33
  %t652 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t642, i32 %t649)
  store i1 %t652, ptr %l364
  br label %bb140
bb136:
  %t653 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTupleNotAValue(ptr %s19)
  store %"compiler/msgs:Msg" %t653, ptr %l354
  br label %bb137
bb137:
  %t654 = load ptr, ptr %l348, !tbaa !29
  %t655 = load %"compiler/source:Span", ptr %l353
  %t656 = load %"compiler/msgs:Msg", ptr %l354
  %t657 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t654, %"compiler/source:Span" %t655, %"compiler/msgs:Msg" %t656)
  store i64 %t657, ptr %l355
  br label %bb138
bb138:
  %t658 = load ptr, ptr %l0, !tbaa !29
  %t659 = load %"compiler/source:Span", ptr %l27
  %t662 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t658, %"compiler/source:Span" %t659)
  store ptr %t662, ptr %l358
  br label %bb139
bb139:
  %t663 = load ptr, ptr %l358, !tbaa !29
  store ptr %t663, ptr %l26, !tbaa !29
  call void @__olang_scope_close(ptr %s19)
  br label %bb171
bb140:
  %t665 = load i1, ptr %l364, !tbaa !21
  br i1 %t665, label %bb141, label %bb142
bb141:
  %t666 = load ptr, ptr %l0, !tbaa !29
  store ptr %t666, ptr %l366, !tbaa !29
  %t667 = load ptr, ptr %l26, !tbaa !29
  %t669 = icmp eq ptr %t667, null
  br i1 %t669, label %bb143, label %bb144
bb142:
  store i1 false, ptr %l365, !tbaa !21
  br label %bb147
bb143:
  call void @__olang_check_failed(ptr @olang_loc_7b3c05f45f3d8f68_d7530d71c92369a4)
  unreachable
bb144:
  br label %bb145
bb145:
  %t671 = load ptr, ptr %l26, !tbaa !29
  %t672 = load ptr, ptr %l366, !tbaa !29
  %t674 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v0, ptr %t672, ptr %t671)
  store i1 %t674, ptr %l370
  br label %bb146
bb146:
  %t675 = load i1, ptr %l370, !tbaa !21
  store i1 %t675, ptr %l365, !tbaa !21
  br label %bb147
bb147:
  %t676 = load i1, ptr %l365, !tbaa !21
  br i1 %t676, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s21
  %t677 = load ptr, ptr %l0, !tbaa !29
  store ptr %t677, ptr %l371, !tbaa !29
  %t678 = load ptr, ptr %l0, !tbaa !29
  store ptr %t678, ptr %l372, !tbaa !29
  %t679 = load ptr, ptr %l26, !tbaa !29
  %t681 = icmp eq ptr %t679, null
  br i1 %t681, label %bb150, label %bb151
bb149:
  br label %bb156
bb150:
  call void @__olang_check_failed(ptr @olang_loc_7b3c05f45f3d8f68_d7530d71c92369a4)
  unreachable
bb151:
  br label %bb152
bb152:
  %t683 = load ptr, ptr %l26, !tbaa !29
  %t684 = load ptr, ptr %l372, !tbaa !29
  %t686 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v0, ptr %t684, ptr %t683)
  store %"compiler/source:Span" %t686, ptr %l376
  br label %bb153
bb153:
  %t687 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %s21)
  store %"compiler/msgs:Msg" %t687, ptr %l377
  br label %bb154
bb154:
  %t688 = load ptr, ptr %l371, !tbaa !29
  %t689 = load %"compiler/source:Span", ptr %l376
  %t690 = load %"compiler/msgs:Msg", ptr %l377
  %t691 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s21, ptr %t688, %"compiler/source:Span" %t689, %"compiler/msgs:Msg" %t690)
  store i64 %t691, ptr %l378
  br label %bb155
bb155:
  call void @__olang_scope_close(ptr %s21)
  br label %bb156
bb156:
  %t692 = load ptr, ptr %l0, !tbaa !29
  store ptr %t692, ptr %l379, !tbaa !29
  %t693 = load ptr, ptr %l4, !tbaa !29
  store ptr %t693, ptr %l380, !tbaa !29
  %t694 = load ptr, ptr %l26, !tbaa !29
  %t696 = icmp eq ptr %t694, null
  br i1 %t696, label %bb157, label %bb158
bb157:
  call void @__olang_check_failed(ptr @olang_loc_460d09842f9fec87_8a34dc35fdcd1373)
  unreachable
bb158:
  br label %bb159
bb159:
  %t698 = load ptr, ptr %l26, !tbaa !29
  store ptr %t698, ptr %l383, !tbaa !29
  %t699 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t699, ptr %l384, !tbaa !27
  %t700 = load i64, ptr %l16, !tbaa !24
  %t702 = getelementptr { i64, ptr }, ptr %l384, i32 0, i32 1
  %t703 = load ptr, ptr %t702, !tbaa !27
  %t704 = getelementptr i32, ptr %t703, i64 %t700
  %t705 = load i32, ptr %t704, !tbaa !33
  store i32 %t705, ptr %l386, !tbaa !23
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t707 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t707, ptr %l388, !tbaa !27
  %t708 = load i64, ptr %l25, !tbaa !24
  %t710 = getelementptr { i64, ptr }, ptr %l388, i32 0, i32 1
  %t711 = load ptr, ptr %t710, !tbaa !27
  %t712 = getelementptr ptr, ptr %t711, i64 %t708
  %t713 = load ptr, ptr %t712, !tbaa !39
  %t716 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t706, ptr %t713)
  store %"compiler/source:Span" %t716, ptr %l391
  br label %bb160
bb160:
  %t717 = load ptr, ptr %l379, !tbaa !29
  %t718 = load ptr, ptr %l380, !tbaa !29
  %t719 = load ptr, ptr %l383, !tbaa !29
  %t720 = load i32, ptr %l386, !tbaa !23
  %t721 = load %"compiler/source:Span", ptr %l391
  %t722 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternArray(ptr %v0, ptr %v0, ptr %t717, ptr %t718, ptr %t719, i32 %t720, %"compiler/source:Span" %t721)
  store ptr %t722, ptr %l392
  br label %bb161
bb161:
  %t723 = load ptr, ptr %l392, !tbaa !29
  store ptr %t723, ptr %l31, !tbaa !29
  %t724 = load ptr, ptr %l0, !tbaa !29
  %t726 = getelementptr %"compiler/check:Checker", ptr %t724, i32 0, i32 9
  %t727 = load { i64, [3 x i64] }, ptr %t726
  store { i64, [3 x i64] } %t727, ptr %l32
  %t729 = load ptr, ptr %l0, !tbaa !29
  store ptr %t729, ptr %l395, !tbaa !29
  %t730 = load ptr, ptr %l0, !tbaa !29
  %t731 = load ptr, ptr %l4, !tbaa !29
  %t732 = load i64, ptr %l5, !tbaa !24
  %t733 = load i64, ptr %l16, !tbaa !24
  %t738 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamAt(ptr %v0, ptr %v0, ptr %t730, ptr %t731, i64 %t732, i64 %t733)
  store { i64, [3 x i64] } %t738, ptr %l400
  br label %bb162
bb162:
  %t739 = load { i64, [3 x i64] }, ptr %l400
  %t740 = load ptr, ptr %l395, !tbaa !29
  %t741 = getelementptr %"compiler/check:Checker", ptr %t740, i32 0, i32 9
  store { i64, [3 x i64] } %t739, ptr %t741
  %t742 = load ptr, ptr %l31, !tbaa !29
  %t744 = icmp eq ptr %t742, null
  %t746 = xor i1 %t744, true
  br i1 %t746, label %bb163, label %bb164
bb163:
  %t748 = load ptr, ptr %l31, !tbaa !29
  store ptr %t748, ptr %l404, !tbaa !29
  br label %bb170
bb164:
  %t751 = load ptr, ptr %l0, !tbaa !29
  store ptr %t751, ptr %l407, !tbaa !29
  %t752 = load ptr, ptr %l26, !tbaa !29
  %t754 = icmp eq ptr %t752, null
  br i1 %t754, label %bb165, label %bb166
bb165:
  call void @__olang_check_failed(ptr @olang_loc_1a2fe83b02404856_98942d3dbe0d9432)
  unreachable
bb166:
  br label %bb167
bb167:
  %t756 = load ptr, ptr %l26, !tbaa !29
  store ptr %t756, ptr %l410, !tbaa !29
  %t757 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t757, ptr %l411, !tbaa !27
  %t758 = load i64, ptr %l16, !tbaa !24
  %t760 = getelementptr { i64, ptr }, ptr %l411, i32 0, i32 1
  %t761 = load ptr, ptr %t760, !tbaa !27
  %t762 = getelementptr i32, ptr %t761, i64 %t758
  %t763 = load i32, ptr %t762, !tbaa !33
  store i32 %t763, ptr %l413, !tbaa !23
  %t764 = load ptr, ptr %l0, !tbaa !29
  %t765 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t765, ptr %l415, !tbaa !27
  %t766 = load i64, ptr %l25, !tbaa !24
  %t768 = getelementptr { i64, ptr }, ptr %l415, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !27
  %t770 = getelementptr ptr, ptr %t769, i64 %t766
  %t771 = load ptr, ptr %t770, !tbaa !39
  %t774 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %t764, ptr %t771)
  store %"compiler/source:Span" %t774, ptr %l418
  br label %bb168
bb168:
  %t775 = load ptr, ptr %l407, !tbaa !29
  %t776 = load ptr, ptr %l410, !tbaa !29
  %t777 = load i32, ptr %l413, !tbaa !23
  %t778 = load %"compiler/source:Span", ptr %l418
  %t779 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t775, ptr %t776, i32 %t777, %"compiler/source:Span" %t778)
  store ptr %t779, ptr %l419
  br label %bb169
bb169:
  %t780 = load ptr, ptr %l419, !tbaa !29
  store ptr %t780, ptr %l404, !tbaa !29
  br label %bb170
bb170:
  %t782 = load ptr, ptr %l404, !tbaa !29
  store ptr %t782, ptr %l26, !tbaa !29
  %t783 = load ptr, ptr %l0, !tbaa !29
  %t784 = load { i64, [3 x i64] }, ptr %l32
  %t787 = getelementptr %"compiler/check:Checker", ptr %t783, i32 0, i32 9
  store { i64, [3 x i64] } %t784, ptr %t787
  br label %bb171
bb171:
  br label %bb172
bb172:
  br label %bb174
bb173:
  %t788 = load ptr, ptr %l425, !tbaa !29
  store ptr %t788, ptr %l26, !tbaa !29
  br label %bb174
bb174:
  br label %bb175
bb175:
  %t790 = load ptr, ptr %l0, !tbaa !29
  store ptr %t790, ptr %l427, !tbaa !29
  %t791 = load ptr, ptr %l0, !tbaa !29
  %t792 = load ptr, ptr %l4, !tbaa !29
  %t795 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v0, ptr %t791, ptr %t792)
  store i64 %t795, ptr %l430
  br label %bb176
bb176:
  %t796 = load i64, ptr %l16, !tbaa !24
  store i64 %t796, ptr %l431, !tbaa !24
  %t797 = load ptr, ptr %l26, !tbaa !29
  store ptr %t797, ptr %l432, !tbaa !29
  %t798 = load %"compiler/source:Span", ptr %l27
  store %"compiler/source:Span" %t798, ptr %l433
  %t799 = load ptr, ptr %l0, !tbaa !29
  %t800 = load i64, ptr %l5, !tbaa !24
  %t803 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v0, ptr %t799, i64 %t800)
  store { i64, ptr } %t803, ptr %l436
  br label %bb177
bb177:
  %t804 = load { i64, ptr }, ptr %l436, !tbaa !27
  %t805 = extractvalue { i64, ptr } %t804, 0
  %t806 = extractvalue { i64, ptr } %t804, 1
  %t807 = mul i64 %t805, 1
  %t808 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t807)
  call void @llvm.memcpy.p0.p0.i64(ptr %t808, ptr %t806, i64 %t807, i1 false)
  %t809 = insertvalue { i64, ptr } undef, i64 %t805, 0
  %t810 = insertvalue { i64, ptr } %t809, ptr %t808, 1
  %t811 = load ptr, ptr %l427, !tbaa !29
  %t812 = load i64, ptr %l430, !tbaa !24
  %t813 = load i64, ptr %l431, !tbaa !24
  %t814 = load ptr, ptr %l432, !tbaa !29
  %t815 = load %"compiler/source:Span", ptr %l433
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v0, ptr %v0, ptr %t811, i64 %t812, i64 %t813, ptr %t814, %"compiler/source:Span" %t815, { i64, ptr } %t810)
  br label %bb178
bb178:
  %t817 = load ptr, ptr %l0, !tbaa !29
  %t819 = getelementptr %"compiler/check:Checker", ptr %t817, i32 0, i32 31
  store ptr %t819, ptr %l439, !tbaa !29
  %t820 = load ptr, ptr %l26, !tbaa !29
  %t822 = icmp eq ptr %t820, null
  br i1 %t822, label %bb179, label %bb180
bb179:
  call void @__olang_check_failed(ptr @olang_loc_5243f41784a5b43d_9dc8734848aaa559)
  unreachable
bb180:
  br label %bb181
bb181:
  %t824 = load ptr, ptr %l26, !tbaa !29
  %t825 = load ptr, ptr %l439, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t825, ptr %t824)
  br label %bb182
bb182:
  %t827 = load i64, ptr %l16, !tbaa !24
  %t829 = add i64 %t827, 1
  store i64 %t829, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb183
bb183:
  %t831 = load i64, ptr %l24, !tbaa !24
  %t833 = add i64 %t831, 1
  store i64 %t833, ptr %l24, !tbaa !24
  br label %bb83
bb184:
  br label %bb185
bb185:
  store %olang.scope zeroinitializer, ptr %s24
  %t835 = load i64, ptr %l16, !tbaa !24
  %t836 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t838 = extractvalue { i64, ptr } %t836, 0
  %t841 = icmp slt i64 %t835, %t838
  %t843 = xor i1 %t841, true
  br i1 %t843, label %bb186, label %bb187
bb186:
  call void @__olang_scope_close(ptr %s24)
  br label %bb193
bb187:
  br label %bb188
bb188:
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t847 = getelementptr %"compiler/check:Checker", ptr %t845, i32 0, i32 31
  store ptr %t847, ptr %l453, !tbaa !29
  %t848 = load ptr, ptr %l0, !tbaa !29
  store ptr %t848, ptr %l454, !tbaa !29
  %t849 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t849, ptr %l455
  %t850 = load i64, ptr %l5, !tbaa !24
  store i64 %t850, ptr %l456, !tbaa !24
  %t851 = load i64, ptr %l16, !tbaa !24
  store i64 %t851, ptr %l457, !tbaa !24
  %t852 = load ptr, ptr %l6, !tbaa !29
  %t854 = icmp eq ptr %t852, null
  %t856 = xor i1 %t854, true
  store i1 %t856, ptr %l460, !tbaa !21
  %t857 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t857, ptr %l461, !tbaa !27
  %t858 = load i64, ptr %l16, !tbaa !24
  %t860 = getelementptr { i64, ptr }, ptr %l461, i32 0, i32 1
  %t861 = load ptr, ptr %t860, !tbaa !27
  %t862 = getelementptr i32, ptr %t861, i64 %t858
  %t863 = load i32, ptr %t862, !tbaa !33
  store i32 %t863, ptr %l463, !tbaa !23
  %t864 = load ptr, ptr %l0, !tbaa !29
  %t865 = load ptr, ptr %l4, !tbaa !29
  %t868 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v0, ptr %t864, ptr %t865)
  store i32 %t868, ptr %l466
  br label %bb189
bb189:
  %t869 = load ptr, ptr %l454, !tbaa !29
  %t870 = load %"compiler/source:Span", ptr %l455
  %t871 = load i64, ptr %l456, !tbaa !24
  %t872 = load i64, ptr %l457, !tbaa !24
  %t873 = load i1, ptr %l460, !tbaa !21
  %t874 = load i32, ptr %l463, !tbaa !23
  %t875 = load i32, ptr %l466, !tbaa !23
  %t876 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %t869, %"compiler/source:Span" %t870, i64 %t871, i64 %t872, i1 %t873, i32 %t874, i32 %t875)
  store ptr %t876, ptr %l467
  br label %bb190
bb190:
  %t877 = load ptr, ptr %l453, !tbaa !29
  %t878 = load ptr, ptr %l467, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t877, ptr %t878)
  br label %bb191
bb191:
  %t879 = load i64, ptr %l16, !tbaa !24
  %t881 = add i64 %t879, 1
  store i64 %t881, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s24)
  br label %bb192
bb192:
  br label %bb185
bb193:
  %t883 = load i1, ptr %l11, !tbaa !21
  br i1 %t883, label %bb194, label %bb195
bb194:
  store i32 0, ptr %l471, !tbaa !23
  br label %bb197
bb195:
  %t885 = load ptr, ptr %l0, !tbaa !29
  %t886 = load ptr, ptr %l4, !tbaa !29
  %t887 = load i32, ptr %l3, !tbaa !23
  %t891 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %t885, ptr %t886, i32 %t887)
  store i32 %t891, ptr %l475
  br label %bb196
bb196:
  %t892 = load i32, ptr %l475, !tbaa !23
  store i32 %t892, ptr %l471, !tbaa !23
  br label %bb197
bb197:
  %t893 = load i32, ptr %l471, !tbaa !23
  store i32 %t893, ptr %l33, !tbaa !23
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t896 = getelementptr %"compiler/check:Checker", ptr %t894, i32 0, i32 1
  %t897 = load ptr, ptr %t896, !tbaa !29
  %t899 = getelementptr %"compiler/generic:Program", ptr %t897, i32 0, i32 2
  %t900 = load i32, ptr %l33, !tbaa !23
  %t903 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t899, i32 %t900)
  store { i64, ptr } %t903, ptr %l480
  br label %bb198
bb198:
  %t904 = load { i64, ptr }, ptr %l480, !tbaa !27
  %t905 = extractvalue { i64, ptr } %t904, 0
  %t907 = icmp sgt i64 %t905, 0
  br i1 %t907, label %bb199, label %bb200
bb199:
  %t909 = load ptr, ptr %l0, !tbaa !29
  %t911 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t909)
  store ptr %t911, ptr %l485
  br label %bb201
bb200:
  store i1 false, ptr %l483, !tbaa !21
  br label %bb202
bb201:
  %t912 = load ptr, ptr %l485, !tbaa !29
  %t914 = getelementptr %"compiler/check:frame", ptr %t912, i32 0, i32 15
  %t915 = load i64, ptr %t914, !tbaa !24
  %t917 = icmp eq i64 %t915, 0
  store i1 %t917, ptr %l483, !tbaa !21
  br label %bb202
bb202:
  %t919 = load i1, ptr %l483, !tbaa !21
  br i1 %t919, label %bb203, label %bb204
bb203:
  %t920 = getelementptr %"compiler/source:Span", ptr %l10, i32 0, i32 0
  %t921 = load i32, ptr %t920, !tbaa !23
  %t923 = icmp sge i32 %t921, 0
  br i1 %t923, label %bb205, label %bb206
bb204:
  br label %bb217
bb205:
  store %olang.scope zeroinitializer, ptr %s26
  %t925 = load ptr, ptr %l0, !tbaa !29
  store ptr %t925, ptr %l491, !tbaa !29
  %t926 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t926, ptr %l492
  %t927 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t929 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNeedsTry(ptr %v0, ptr %s26, { i64, ptr } %t927)
  store %"compiler/msgs:Msg" %t929, ptr %l494
  br label %bb207
bb206:
  %t930 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t932 = extractvalue { i64, ptr } %t930, 0
  %t934 = icmp sgt i64 %t932, 0
  br i1 %t934, label %bb209, label %bb210
bb207:
  %t936 = load ptr, ptr %l491, !tbaa !29
  %t937 = load %"compiler/source:Span", ptr %l492
  %t938 = load %"compiler/msgs:Msg", ptr %l494
  %t939 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s26, ptr %t936, %"compiler/source:Span" %t937, %"compiler/msgs:Msg" %t938)
  store i64 %t939, ptr %l495
  br label %bb208
bb208:
  call void @__olang_scope_close(ptr %s26)
  br label %bb216
bb209:
  store %olang.scope zeroinitializer, ptr %s28
  %t940 = load ptr, ptr %l0, !tbaa !29
  store ptr %t940, ptr %l499, !tbaa !29
  %t941 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t941, ptr %l500
  %t942 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t944 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorCallFails(ptr %v0, ptr %s28, { i64, ptr } %t942)
  store %"compiler/msgs:Msg" %t944, ptr %l502
  br label %bb211
bb210:
  store %olang.scope zeroinitializer, ptr %s29
  %t945 = load ptr, ptr %l0, !tbaa !29
  store ptr %t945, ptr %l504, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t946, ptr %l505
  %t947 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %s29)
  store %"compiler/msgs:Msg" %t947, ptr %l506
  br label %bb213
bb211:
  %t948 = load ptr, ptr %l499, !tbaa !29
  %t949 = load %"compiler/source:Span", ptr %l500
  %t950 = load %"compiler/msgs:Msg", ptr %l502
  %t951 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s28, ptr %t948, %"compiler/source:Span" %t949, %"compiler/msgs:Msg" %t950)
  store i64 %t951, ptr %l503
  br label %bb212
bb212:
  call void @__olang_scope_close(ptr %s28)
  br label %bb215
bb213:
  %t952 = load ptr, ptr %l504, !tbaa !29
  %t953 = load %"compiler/source:Span", ptr %l505
  %t954 = load %"compiler/msgs:Msg", ptr %l506
  %t955 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s29, ptr %t952, %"compiler/source:Span" %t953, %"compiler/msgs:Msg" %t954)
  store i64 %t955, ptr %l507
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s29)
  br label %bb215
bb215:
  br label %bb216
bb216:
  br label %bb217
bb217:
  %t956 = load ptr, ptr %l0, !tbaa !29
  %t958 = getelementptr %"compiler/check:Checker", ptr %t956, i32 0, i32 1
  %t959 = load ptr, ptr %t958, !tbaa !29
  %t961 = getelementptr %"compiler/generic:Program", ptr %t959, i32 0, i32 2
  %t962 = load i32, ptr %l33, !tbaa !23
  %t965 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t961, i32 %t962)
  store { i64, ptr } %t965, ptr %l512
  br label %bb218
bb218:
  %t966 = load { i64, ptr }, ptr %l512, !tbaa !27
  %t967 = extractvalue { i64, ptr } %t966, 0
  %t969 = icmp sgt i64 %t967, 0
  br i1 %t969, label %bb219, label %bb220
bb219:
  %t971 = load ptr, ptr %l0, !tbaa !29
  %t973 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t971)
  store ptr %t973, ptr %l516
  br label %bb221
bb220:
  br label %bb222
bb221:
  %t974 = load ptr, ptr %l516, !tbaa !29
  store ptr %t974, ptr %l517, !tbaa !29
  %t975 = load ptr, ptr %l517, !tbaa !29
  %t976 = getelementptr %"compiler/check:frame", ptr %t975, i32 0, i32 17
  %t977 = load i64, ptr %t976, !tbaa !24
  %t979 = add i64 %t977, 1
  %t981 = load ptr, ptr %l517, !tbaa !29
  %t982 = getelementptr %"compiler/check:frame", ptr %t981, i32 0, i32 17
  store i64 %t979, ptr %t982, !tbaa !24
  br label %bb222
bb222:
  %t983 = load ptr, ptr %l0, !tbaa !29
  %t984 = load i32, ptr %l33, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %t983, i32 %t984)
  br label %bb223
bb223:
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t988 = load i32, ptr %l33, !tbaa !23
  %t991 = getelementptr %"compiler/check:Checker", ptr %t987, i32 0, i32 34
  store i32 %t988, ptr %t991, !tbaa !23
  %t992 = load ptr, ptr %l0, !tbaa !29
  %t994 = getelementptr %"compiler/check:Checker", ptr %t992, i32 0, i32 1
  %t995 = load ptr, ptr %t994, !tbaa !29
  %t997 = getelementptr %"compiler/generic:Program", ptr %t995, i32 0, i32 2
  %t998 = load i32, ptr %l3, !tbaa !23
  %t1001 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t997, i32 %t998)
  store i32 %t1001, ptr %l528
  br label %bb224
bb224:
  %t1002 = load i32, ptr %l528, !tbaa !23
  store i32 %t1002, ptr %l34, !tbaa !23
  %t1003 = load ptr, ptr %l0, !tbaa !29
  %t1004 = load i32, ptr %l34, !tbaa !23
  %t1007 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1003, i32 %t1004)
  store i1 %t1007, ptr %l531
  br label %bb225
bb225:
  %t1008 = load i1, ptr %l531, !tbaa !21
  br i1 %t1008, label %bb226, label %bb227
bb226:
  %t1009 = load ptr, ptr %l0, !tbaa !29
  %t1011 = getelementptr %"compiler/check:Checker", ptr %t1009, i32 0, i32 1
  %t1012 = load ptr, ptr %t1011, !tbaa !29
  %t1014 = getelementptr %"compiler/generic:Program", ptr %t1012, i32 0, i32 2
  %t1015 = load i32, ptr %l3, !tbaa !23
  %t1018 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t1014, i32 %t1015, i64 0)
  store i64 %t1018, ptr %l537
  br label %bb228
bb227:
  store i1 false, ptr %l532, !tbaa !21
  br label %bb229
bb228:
  %t1019 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t1020 = load i64, ptr %l537, !tbaa !24
  %t1022 = icmp eq i64 %t1020, %t1019
  store i1 %t1022, ptr %l532, !tbaa !21
  br label %bb229
bb229:
  %t1024 = load i1, ptr %l532, !tbaa !21
  br i1 %t1024, label %bb230, label %bb231
bb230:
  %t1025 = load ptr, ptr %l0, !tbaa !29
  %t1027 = getelementptr %"compiler/check:Checker", ptr %t1025, i32 0, i32 1
  %t1028 = load ptr, ptr %t1027, !tbaa !29
  %t1030 = getelementptr %"compiler/generic:Program", ptr %t1028, i32 0, i32 2
  store ptr %t1030, ptr %l542, !tbaa !29
  %t1031 = load ptr, ptr %l0, !tbaa !29
  %t1033 = getelementptr %"compiler/check:Checker", ptr %t1031, i32 0, i32 1
  %t1034 = load ptr, ptr %t1033, !tbaa !29
  %t1036 = getelementptr %"compiler/generic:Program", ptr %t1034, i32 0, i32 2
  %t1037 = load i32, ptr %l34, !tbaa !23
  %t1040 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1036, i32 %t1037)
  store i32 %t1040, ptr %l547
  br label %bb232
bb231:
  %t1041 = load ptr, ptr %l0, !tbaa !29
  %t1043 = getelementptr %"compiler/check:Checker", ptr %t1041, i32 0, i32 1
  %t1044 = load ptr, ptr %t1043, !tbaa !29
  %t1046 = getelementptr %"compiler/generic:Program", ptr %t1044, i32 0, i32 2
  %t1047 = load i32, ptr %l34, !tbaa !23
  %t1050 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t1046, i32 %t1047)
  store i32 %t1050, ptr %l560
  br label %bb235
bb232:
  %t1051 = load ptr, ptr %l0, !tbaa !29
  %t1053 = getelementptr %"compiler/check:Checker", ptr %t1051, i32 0, i32 1
  %t1054 = load ptr, ptr %t1053, !tbaa !29
  %t1056 = getelementptr %"compiler/generic:Program", ptr %t1054, i32 0, i32 2
  %t1057 = load i32, ptr %l34, !tbaa !23
  %t1060 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1056, i32 %t1057)
  store i64 %t1060, ptr %l552
  br label %bb233
bb233:
  %t1061 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1062 = load i64, ptr %l552, !tbaa !24
  %t1064 = or i64 %t1062, %t1061
  %t1065 = load ptr, ptr %l542, !tbaa !29
  %t1066 = load i32, ptr %l547, !tbaa !23
  %t1068 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1065, i32 %t1066, i64 %t1064)
  store i32 %t1068, ptr %l555
  br label %bb234
bb234:
  %t1069 = load i32, ptr %l555, !tbaa !23
  store i32 %t1069, ptr %l34, !tbaa !23
  br label %bb276
bb235:
  %t1070 = load i32, ptr %l560
  %t1072 = trunc i64 22 to i32
  %t1073 = icmp eq i32 %t1070, %t1072
  br i1 %t1073, label %bb236, label %bb237
bb236:
  store %olang.scope zeroinitializer, ptr %s33
  %t1075 = load ptr, ptr %l0, !tbaa !29
  %t1077 = getelementptr %"compiler/check:Checker", ptr %t1075, i32 0, i32 1
  %t1078 = load ptr, ptr %t1077, !tbaa !29
  %t1080 = getelementptr %"compiler/generic:Program", ptr %t1078, i32 0, i32 2
  store ptr %t1080, ptr %l565, !tbaa !29
  %t1081 = load ptr, ptr %l0, !tbaa !29
  %t1083 = getelementptr %"compiler/check:Checker", ptr %t1081, i32 0, i32 1
  %t1084 = load ptr, ptr %t1083, !tbaa !29
  %t1086 = getelementptr %"compiler/generic:Program", ptr %t1084, i32 0, i32 2
  %t1087 = load i32, ptr %l34, !tbaa !23
  %t1090 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t1086, i32 %t1087)
  store i32 %t1090, ptr %l570
  br label %bb238
bb237:
  br label %bb275
bb238:
  %t1091 = load ptr, ptr %l565, !tbaa !29
  %t1092 = load i32, ptr %l570, !tbaa !23
  %t1093 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t1091, i32 %t1092)
  store { i64, ptr } %t1093, ptr %l571
  br label %bb239
bb239:
  %t1094 = load { i64, ptr }, ptr %l571, !tbaa !27
  store { i64, ptr } %t1094, ptr %l35, !tbaa !27
  %t1095 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %s33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1095, ptr %l572
  br label %bb240
bb240:
  %t1096 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l572
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1096, ptr %l36
  store i1 false, ptr %l37, !tbaa !21
  store i64 0, ptr %l38, !tbaa !24
  %t1097 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t1099 = extractvalue { i64, ptr } %t1097, 0
  store i64 %t1099, ptr %l39, !tbaa !24
  store i64 1, ptr %l40, !tbaa !24
  %t1101 = load i64, ptr %l39, !tbaa !24
  %t1102 = load i64, ptr %l38, !tbaa !24
  %t1105 = icmp sgt i64 %t1101, %t1102
  br i1 %t1105, label %bb241, label %bb242
bb241:
  %t1107 = load i64, ptr %l40, !tbaa !24
  %t1109 = icmp sgt i64 %t1107, 0
  br i1 %t1109, label %bb243, label %bb244
bb242:
  store i64 0, ptr %l578, !tbaa !24
  br label %bb246
bb243:
  %t1111 = load i64, ptr %l39, !tbaa !24
  %t1112 = load i64, ptr %l38, !tbaa !24
  %t1115 = sub i64 %t1111, %t1112
  %t1116 = load i64, ptr %l40, !tbaa !24
  %t1119 = add i64 %t1115, %t1116
  %t1121 = sub i64 %t1119, 1
  %t1122 = load i64, ptr %l40, !tbaa !24
  %t1125 = sdiv i64 %t1121, %t1122
  store i64 %t1125, ptr %l581, !tbaa !24
  br label %bb245
bb244:
  store i64 0, ptr %l581, !tbaa !24
  br label %bb245
bb245:
  %t1127 = load i64, ptr %l581, !tbaa !24
  store i64 %t1127, ptr %l578, !tbaa !24
  br label %bb246
bb246:
  %t1128 = load i64, ptr %l578, !tbaa !24
  store i64 %t1128, ptr %l41, !tbaa !24
  store i64 0, ptr %l42, !tbaa !24
  br label %bb247
bb247:
  store %olang.scope zeroinitializer, ptr %s35
  %t1129 = load i64, ptr %l42, !tbaa !24
  %t1130 = load i64, ptr %l41, !tbaa !24
  %t1133 = icmp slt i64 %t1129, %t1130
  %t1135 = xor i1 %t1133, true
  br i1 %t1135, label %bb248, label %bb249
bb248:
  call void @__olang_scope_close(ptr %s35)
  br label %bb268
bb249:
  br label %bb250
bb250:
  %t1137 = load i64, ptr %l38, !tbaa !24
  %t1138 = load i64, ptr %l42, !tbaa !24
  %t1139 = load i64, ptr %l40, !tbaa !24
  %t1142 = mul i64 %t1138, %t1139
  %t1145 = add i64 %t1137, %t1142
  store i64 %t1145, ptr %l43, !tbaa !24
  %t1147 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t1147, ptr %l599, !tbaa !27
  %t1148 = load i64, ptr %l43, !tbaa !24
  %t1150 = getelementptr { i64, ptr }, ptr %l599, i32 0, i32 1
  %t1151 = load ptr, ptr %t1150, !tbaa !27
  %t1152 = getelementptr i32, ptr %t1151, i64 %t1148
  %t1153 = load i32, ptr %t1152, !tbaa !33
  store i32 %t1153, ptr %l44, !tbaa !23
  %t1155 = load ptr, ptr %l0, !tbaa !29
  %t1156 = load i32, ptr %l44, !tbaa !23
  %t1159 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1155, i32 %t1156)
  store i1 %t1159, ptr %l604
  br label %bb251
bb251:
  %t1160 = load i1, ptr %l604, !tbaa !21
  br i1 %t1160, label %bb252, label %bb253
bb252:
  %t1161 = load ptr, ptr %l0, !tbaa !29
  %t1163 = getelementptr %"compiler/check:Checker", ptr %t1161, i32 0, i32 1
  %t1164 = load ptr, ptr %t1163, !tbaa !29
  %t1166 = getelementptr %"compiler/generic:Program", ptr %t1164, i32 0, i32 2
  %t1167 = load i32, ptr %l3, !tbaa !23
  %t1168 = load i64, ptr %l43, !tbaa !24
  %t1172 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %t1166, i32 %t1167, i64 %t1168)
  store i64 %t1172, ptr %l611
  br label %bb254
bb253:
  store i1 false, ptr %l605, !tbaa !21
  br label %bb255
bb254:
  %t1173 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t1174 = load i64, ptr %l611, !tbaa !24
  %t1176 = icmp eq i64 %t1174, %t1173
  store i1 %t1176, ptr %l605, !tbaa !21
  br label %bb255
bb255:
  %t1178 = load i1, ptr %l605, !tbaa !21
  br i1 %t1178, label %bb256, label %bb257
bb256:
  %t1179 = load ptr, ptr %l0, !tbaa !29
  %t1181 = getelementptr %"compiler/check:Checker", ptr %t1179, i32 0, i32 1
  %t1182 = load ptr, ptr %t1181, !tbaa !29
  %t1184 = getelementptr %"compiler/generic:Program", ptr %t1182, i32 0, i32 2
  %t1185 = load i32, ptr %l44, !tbaa !23
  %t1188 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1184, i32 %t1185)
  store i64 %t1188, ptr %l619
  br label %bb258
bb257:
  store i1 false, ptr %l614, !tbaa !21
  br label %bb259
bb258:
  %t1189 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1190 = load i64, ptr %l619, !tbaa !24
  %t1192 = and i64 %t1190, %t1189
  %t1194 = icmp eq i64 %t1192, 0
  store i1 %t1194, ptr %l614, !tbaa !21
  br label %bb259
bb259:
  %t1196 = load i1, ptr %l614, !tbaa !21
  br i1 %t1196, label %bb260, label %bb261
bb260:
  %t1197 = load ptr, ptr %l0, !tbaa !29
  %t1199 = getelementptr %"compiler/check:Checker", ptr %t1197, i32 0, i32 1
  %t1200 = load ptr, ptr %t1199, !tbaa !29
  %t1202 = getelementptr %"compiler/generic:Program", ptr %t1200, i32 0, i32 2
  store ptr %t1202, ptr %l625, !tbaa !29
  %t1203 = load ptr, ptr %l0, !tbaa !29
  %t1205 = getelementptr %"compiler/check:Checker", ptr %t1203, i32 0, i32 1
  %t1206 = load ptr, ptr %t1205, !tbaa !29
  %t1208 = getelementptr %"compiler/generic:Program", ptr %t1206, i32 0, i32 2
  %t1209 = load i32, ptr %l44, !tbaa !23
  %t1212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t1208, i32 %t1209)
  store i32 %t1212, ptr %l630
  br label %bb262
bb261:
  br label %bb265
bb262:
  %t1213 = load ptr, ptr %l0, !tbaa !29
  %t1215 = getelementptr %"compiler/check:Checker", ptr %t1213, i32 0, i32 1
  %t1216 = load ptr, ptr %t1215, !tbaa !29
  %t1218 = getelementptr %"compiler/generic:Program", ptr %t1216, i32 0, i32 2
  %t1219 = load i32, ptr %l44, !tbaa !23
  %t1222 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t1218, i32 %t1219)
  store i64 %t1222, ptr %l635
  br label %bb263
bb263:
  %t1223 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t1224 = load i64, ptr %l635, !tbaa !24
  %t1226 = or i64 %t1224, %t1223
  %t1227 = load ptr, ptr %l625, !tbaa !29
  %t1228 = load i32, ptr %l630, !tbaa !23
  %t1230 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t1227, i32 %t1228, i64 %t1226)
  store i32 %t1230, ptr %l638
  br label %bb264
bb264:
  %t1231 = load i32, ptr %l638, !tbaa !23
  store i32 %t1231, ptr %l44, !tbaa !23
  store i1 true, ptr %l37, !tbaa !21
  br label %bb265
bb265:
  %t1232 = load i32, ptr %l44, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s33, ptr %l36, i32 %t1232)
  br label %bb266
bb266:
  call void @__olang_scope_close(ptr %s35)
  br label %bb267
bb267:
  %t1235 = load i64, ptr %l42, !tbaa !24
  %t1237 = add i64 %t1235, 1
  store i64 %t1237, ptr %l42, !tbaa !24
  br label %bb247
bb268:
  %t1239 = load i1, ptr %l37, !tbaa !21
  br i1 %t1239, label %bb269, label %bb270
bb269:
  store %olang.scope zeroinitializer, ptr %s38
  %t1241 = load ptr, ptr %l0, !tbaa !29
  %t1243 = getelementptr %"compiler/check:Checker", ptr %t1241, i32 0, i32 1
  %t1244 = load ptr, ptr %t1243, !tbaa !29
  %t1246 = getelementptr %"compiler/generic:Program", ptr %t1244, i32 0, i32 2
  store ptr %t1246, ptr %l646, !tbaa !29
  %t1247 = load ptr, ptr %l0, !tbaa !29
  %t1249 = getelementptr %"compiler/check:Checker", ptr %t1247, i32 0, i32 1
  %t1250 = load ptr, ptr %t1249, !tbaa !29
  %t1252 = getelementptr %"compiler/generic:Program", ptr %t1250, i32 0, i32 2
  store ptr %t1252, ptr %l649, !tbaa !29
  %t1254 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s33, ptr %s38, ptr %l36)
  store { i64, ptr } %t1254, ptr %l651
  br label %bb271
bb270:
  br label %bb274
bb271:
  %t1255 = load ptr, ptr %l649, !tbaa !29
  %t1256 = load { i64, ptr }, ptr %l651, !tbaa !27
  %t1257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s38, ptr %t1255, { i64, ptr } %t1256)
  store i32 %t1257, ptr %l652
  br label %bb272
bb272:
  %t1258 = load ptr, ptr %l646, !tbaa !29
  %t1259 = load i32, ptr %l652, !tbaa !23
  %t1260 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t1258, i32 %t1259)
  store i32 %t1260, ptr %l653
  br label %bb273
bb273:
  %t1261 = load i32, ptr %l653, !tbaa !23
  store i32 %t1261, ptr %l34, !tbaa !23
  call void @__olang_scope_close(ptr %s38)
  br label %bb274
bb274:
  call void @__olang_scope_close(ptr %s33)
  br label %bb275
bb275:
  br label %bb276
bb276:
  %t1262 = load ptr, ptr %l0, !tbaa !29
  %t1263 = load ptr, ptr %l4, !tbaa !29
  %t1264 = load i32, ptr %l34, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCheckCallee(ptr %v0, ptr %v0, ptr %t1262, ptr %t1263, i32 %t1264)
  br label %bb277
bb277:
  %t1268 = load ptr, ptr %l0, !tbaa !29
  %t1270 = getelementptr %"compiler/check:Checker", ptr %t1268, i32 0, i32 31
  %t1271 = load i64, ptr %l15, !tbaa !24
  %t1274 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t1270, i64 %t1271)
  store { i64, ptr } %t1274, ptr %l660
  br label %bb278
bb278:
  %t1275 = load { i64, ptr }, ptr %l660, !tbaa !27
  store { i64, ptr } %t1275, ptr %l45, !tbaa !27
  %t1276 = load ptr, ptr %l0, !tbaa !29
  %t1277 = load %"compiler/source:Span", ptr %l1
  %t1281 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1276, i32 0, %"compiler/source:Span" %t1277)
  store i32 %t1281, ptr %l664
  br label %bb279
bb279:
  %t1282 = load i32, ptr %l664, !tbaa !23
  store i32 %t1282, ptr %l46, !tbaa !23
  %t1283 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1283, ptr %l665
  %t1284 = load i32, ptr %l34, !tbaa !23
  store i32 %t1284, ptr %l666, !tbaa !23
  %t1285 = load ptr, ptr %l4, !tbaa !29
  %t1286 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t1287
  %t1288 = getelementptr { i64, [2 x i64] }, ptr %t1287, i32 0, i32 0
  store i64 0, ptr %t1288
  %t1289 = load { i64, [2 x i64] }, ptr %t1287
  %t1290 = load i32, ptr %l46, !tbaa !23
  %t1295 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t1285, { i64, ptr } %t1286, { i64, [2 x i64] } %t1289, i32 %t1290, i1 false, i1 false)
  store %"compiler/typed:Call" %t1295, ptr %l671
  br label %bb280
bb280:
  %t1296 = load %"compiler/typed:Call", ptr %l671
  %t1297 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t1296, ptr %t1297
  store { i64, [5 x i64] } zeroinitializer, ptr %t1298
  %t1299 = getelementptr { i64, [5 x i64] }, ptr %t1298, i32 0, i32 0
  store i64 6, ptr %t1299
  %t1300 = load %"compiler/source:Span", ptr %l665
  %t1301 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1300, 0
  %t1302 = load i32, ptr %l666, !tbaa !23
  %t1303 = insertvalue { %"compiler/source:Span", i32, ptr } %t1301, i32 %t1302, 1
  %t1305 = insertvalue { %"compiler/source:Span", i32, ptr } %t1303, ptr %t1297, 2
  %t1306 = getelementptr { i64, [5 x i64] }, ptr %t1298, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1305, ptr %t1306
  %t1307 = load { i64, [5 x i64] }, ptr %t1298
  %t1308 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t1308, ptr %lp47
  %t1310 = load ptr, ptr %lp47
  store { i64, [5 x i64] } %t1307, ptr %t1310
  %t1311 = load ptr, ptr %l0, !tbaa !29
  %t1312 = load ptr, ptr %l4, !tbaa !29
  %t1315 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v0, ptr %t1311, ptr %t1312)
  store i64 %t1315, ptr %l676
  br label %bb281
bb281:
  %t1316 = load i64, ptr %l676, !tbaa !24
  store i64 %t1316, ptr %l48, !tbaa !24
  %t1317 = load i64, ptr %l48, !tbaa !24
  %t1319 = icmp sge i64 %t1317, 0
  br i1 %t1319, label %bb282, label %bb283
bb282:
  %t1321 = load ptr, ptr %l0, !tbaa !29
  %t1323 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1321)
  store ptr %t1323, ptr %l681
  br label %bb284
bb283:
  store i1 false, ptr %l679, !tbaa !21
  br label %bb285
bb284:
  %t1324 = load ptr, ptr %l681, !tbaa !29
  %t1326 = getelementptr %"compiler/check:frame", ptr %t1324, i32 0, i32 49
  %t1327 = load i64, ptr %t1326, !tbaa !24
  %t1329 = icmp eq i64 %t1327, 0
  store i1 %t1329, ptr %l679, !tbaa !21
  br label %bb285
bb285:
  %t1331 = load i1, ptr %l679, !tbaa !21
  br i1 %t1331, label %bb286, label %bb287
bb286:
  %t1332 = load ptr, ptr %l0, !tbaa !29
  %t1333 = load i64, ptr %l48, !tbaa !24
  %t1336 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t1332, i64 %t1333)
  store i1 %t1336, ptr %l688
  br label %bb288
bb287:
  store i1 false, ptr %l685, !tbaa !21
  br label %bb289
bb288:
  %t1337 = load i1, ptr %l688, !tbaa !21
  store i1 %t1337, ptr %l685, !tbaa !21
  br label %bb289
bb289:
  %t1338 = load i1, ptr %l685, !tbaa !21
  br i1 %t1338, label %bb290, label %bb291
bb290:
  %t1339 = load ptr, ptr %l0, !tbaa !29
  %t1340 = load %"compiler/source:Span", ptr %l1
  %t1341 = load %"compiler/source:Span", ptr %l2
  %t1342 = load i32, ptr %l34, !tbaa !23
  %t1343 = load ptr, ptr %lp47
  %t1344 = load { i64, [5 x i64] }, ptr %t1343
  %t1346 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1344, ptr %t1346
  %t1347 = load ptr, ptr %l4, !tbaa !29
  %t1348 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t1349 = load i32, ptr %l46, !tbaa !23
  %t1350 = load i64, ptr %l48, !tbaa !24
  %t1360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractAt(ptr %v0, ptr %t1339, %"compiler/source:Span" %t1340, %"compiler/source:Span" %t1341, i32 %t1342, ptr %t1346, ptr %t1347, { i64, ptr } %t1348, i32 %t1349, i64 %t1350)
  store ptr %t1360, ptr %l699
  br label %bb292
bb291:
  br label %bb293
bb292:
  %t1361 = load ptr, ptr %l699, !tbaa !29
  %t1362 = load { i64, [5 x i64] }, ptr %t1361
  %t1364 = load ptr, ptr %lp47
  store { i64, [5 x i64] } %t1362, ptr %t1364
  br label %bb293
bb293:
  %t1365 = load ptr, ptr %l0, !tbaa !29
  %t1367 = getelementptr %"compiler/check:Checker", ptr %t1365, i32 0, i32 32
  %t1369 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1367)
  store i64 %t1369, ptr %l703
  br label %bb294
bb294:
  %t1370 = load i64, ptr %l13, !tbaa !24
  %t1371 = load i64, ptr %l703, !tbaa !24
  %t1373 = icmp sgt i64 %t1371, %t1370
  br i1 %t1373, label %bb295, label %bb296
bb295:
  %t1375 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1375, ptr %l706
  %t1376 = load i32, ptr %l34, !tbaa !23
  store i32 %t1376, ptr %l707, !tbaa !23
  %t1377 = load ptr, ptr %l0, !tbaa !29
  %t1379 = getelementptr %"compiler/check:Checker", ptr %t1377, i32 0, i32 32
  %t1380 = load i64, ptr %l13, !tbaa !24
  %t1383 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t1379, i64 %t1380)
  store { i64, ptr } %t1383, ptr %l711
  br label %bb297
bb296:
  br label %bb299
bb297:
  %t1384 = load ptr, ptr %lp47
  %t1385 = load { i64, ptr }, ptr %l711, !tbaa !27
  %t1387 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t1385, ptr %t1384)
  store %"compiler/typed:Seq" %t1387, ptr %l713
  br label %bb298
bb298:
  %t1388 = load %"compiler/typed:Seq", ptr %l713
  %t1389 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t1388, ptr %t1389
  store { i64, [5 x i64] } zeroinitializer, ptr %t1390
  %t1391 = getelementptr { i64, [5 x i64] }, ptr %t1390, i32 0, i32 0
  store i64 12, ptr %t1391
  %t1392 = load %"compiler/source:Span", ptr %l706
  %t1393 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1392, 0
  %t1394 = load i32, ptr %l707, !tbaa !23
  %t1395 = insertvalue { %"compiler/source:Span", i32, ptr } %t1393, i32 %t1394, 1
  %t1397 = insertvalue { %"compiler/source:Span", i32, ptr } %t1395, ptr %t1389, 2
  %t1398 = getelementptr { i64, [5 x i64] }, ptr %t1390, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1397, ptr %t1398
  %t1399 = load { i64, [5 x i64] }, ptr %t1390
  %t1401 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1399, ptr %t1401
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1401, ptr %rv
  br label %ret
bb299:
  %t1403 = load ptr, ptr %lp47
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1403, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, [2 x i64] }
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i1
  %l15 = alloca ptr
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { i32 }, ptr %t12, i32 0, i32 0
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb13
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 10
  %t19 = load i32, ptr %l2, !tbaa !23
  %t21 = sext i32 %t19 to i64
  %t24 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t18, i64 %t21)
  store ptr %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t27 = getelementptr %"compiler/typed:Body", ptr %t25, i32 0, i32 1
  %t28 = load { i64, [2 x i64] }, ptr %t27
  store { i64, [2 x i64] } %t28, ptr %l3
  %t30 = load { i64, [2 x i64] }, ptr %l3
  %t32 = extractvalue { i64, [2 x i64] } %t30, 0
  %t33 = icmp eq i64 %t32, 0
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = getelementptr { i64, [2 x i64] }, ptr %l3, i32 0, i32 1
  %t36 = getelementptr { i64 }, ptr %t35, i32 0, i32 0
  %t37 = load i64, ptr %t36
  store i64 %t37, ptr %l4, !tbaa !24
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t46, ptr %l24
  br label %bb10
bb10:
  %t47 = load i32, ptr %l24, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckGlobal(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l35 = alloca %"compiler/generic:Context"
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l57 = alloca %"compiler/typed:Block"
  %l66 = alloca i64
  %l69 = alloca i64
  %l88 = alloca { i64, ptr }
  %l104 = alloca i32
  %l109 = alloca ptr
  %l111 = alloca %"compiler/generic:Context"
  %l115 = alloca i32
  %l118 = alloca i64
  %l126 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l141 = alloca i32
  %l146 = alloca i1
  %l147 = alloca i1
  %l155 = alloca ptr
  %l163 = alloca i1
  %l164 = alloca i1
  %l167 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l175 = alloca %"compiler/source:Span"
  %l177 = alloca i1
  %l182 = alloca i1
  %l192 = alloca ptr
  %l205 = alloca i32
  %l207 = alloca i32
  %l209 = alloca i1
  %l210 = alloca ptr
  %l214 = alloca i32
  %l215 = alloca i1
  %l216 = alloca ptr
  %l217 = alloca %"compiler/source:Span"
  %l218 = alloca %"compiler/source:Span"
  %l219 = alloca i32
  %l225 = alloca ptr
  %l228 = alloca ptr
  %l229 = alloca %"compiler/source:Span"
  %l235 = alloca ptr
  %l242 = alloca ptr
  %l243 = alloca ptr
  %l247 = alloca { i64, ptr }
  %l248 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %t417 = alloca { i64, [4 x i64] }, align 8
  %t443 = alloca { i64, [4 x i64] }, align 8
  %t462 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l2, !tbaa !24
  %t6 = load i32, ptr %l3, !tbaa !23
  %t10 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t4, i64 %t5, i32 %t6)
  store ptr %t10, ptr %l23
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l23, !tbaa !29
  store ptr %t11, ptr %l4, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  %t13 = load i32, ptr %l3, !tbaa !23
  %t15 = sext i32 %t13 to i64
  %t18 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t12, i64 %t15)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18, ptr %l27
  br label %bb2
bb2:
  %t19 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l27
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t19, ptr %l5
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = load i64, ptr %l2, !tbaa !24
  %t23 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t28 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t20, i64 %a1, i64 %t22, i32 %t23, i32 0)
  store ptr %t28, ptr %l32
  br label %bb3
bb3:
  %t29 = load ptr, ptr %l32, !tbaa !29
  store ptr %t29, ptr %l33, !tbaa !29
  %t31 = load i64, ptr %l2, !tbaa !24
  %t33 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t31, i64 -1)
  store %"compiler/generic:Context" %t33, ptr %l35
  br label %bb4
bb4:
  %t34 = load %"compiler/generic:Context", ptr %l35
  %t35 = load ptr, ptr %l33, !tbaa !29
  %t36 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 4
  store %"compiler/generic:Context" %t34, ptr %t36
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t37)
  store ptr %t39, ptr %l37
  br label %bb5
bb5:
  %t40 = load ptr, ptr %l37, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Body", ptr %t40, i32 0, i32 4
  %t43 = load %"compiler/source:Span", ptr %t42
  store %"compiler/source:Span" %t43, ptr %l7
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t45)
  store ptr %t47, ptr %l41
  br label %bb6
bb6:
  %t48 = load %"compiler/source:Span", ptr %l7
  %t49 = load ptr, ptr %l41, !tbaa !29
  %t52 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t49, i32 -1, i32 0, %"compiler/source:Span" %t48)
  store i32 %t52, ptr %l44
  br label %bb7
bb7:
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb8, label %bb9
bb8:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 23
  %t60 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %t59, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t60, i32 %t61)
  br label %bb10
bb9:
  br label %bb18
bb10:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t65)
  store ptr %t67, ptr %l52
  br label %bb11
bb11:
  %t68 = load ptr, ptr %l52, !tbaa !29
  store ptr %t68, ptr %l53, !tbaa !29
  %t69 = icmp sge i64 0, 0
  br i1 %t69, label %bb12, label %bb13
bb12:
  %t71 = icmp sle i64 0, 1152921504606846975
  br i1 %t71, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_27b76e5e144937_92b9984f1a7672bb)
  unreachable
bb14:
  %t73 = mul i64 0, 8
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 0, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t78 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t76)
  store %"compiler/typed:Block" %t78, ptr %l57
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_27b76e5e144937_92b9984f1a7672bb)
  unreachable
bb16:
  %t79 = load %"compiler/typed:Block", ptr %l57
  %t80 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t79, ptr %t80
  %t82 = load ptr, ptr %l53, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Body", ptr %t82, i32 0, i32 11
  store ptr %t80, ptr %t83, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t84)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  store i64 0, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t88 = getelementptr %"compiler/ast:VarDecl", ptr %t86, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t93 = load i64, ptr %l10, !tbaa !24
  %t94 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb19, label %bb20
bb19:
  %t99 = load i64, ptr %l11, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb24
bb21:
  %t103 = load i64, ptr %l10, !tbaa !24
  %t104 = load i64, ptr %l9, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l11, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l11, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l69, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l69, !tbaa !24
  store i64 %t119, ptr %l66, !tbaa !24
  br label %bb24
bb24:
  %t120 = load i64, ptr %l66, !tbaa !24
  store i64 %t120, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = load i64, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l12, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb27:
  br label %bb28
bb28:
  %t129 = load i64, ptr %l9, !tbaa !24
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l14, !tbaa !24
  %t139 = load ptr, ptr %l4, !tbaa !29
  %t141 = getelementptr %"compiler/ast:VarDecl", ptr %t139, i32 0, i32 0
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l88, !tbaa !27
  %t143 = load i64, ptr %l14, !tbaa !24
  %t145 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr i32, ptr %t146, i64 %t143
  %t148 = load i32, ptr %t147, !tbaa !33
  %t149 = load i32, ptr %l3, !tbaa !23
  %t152 = icmp eq i32 %t148, %t149
  br i1 %t152, label %bb29, label %bb30
bb29:
  %t154 = load i64, ptr %l14, !tbaa !24
  store i64 %t154, ptr %l8, !tbaa !24
  br label %bb31
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb32:
  %t156 = load i64, ptr %l13, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l13, !tbaa !24
  br label %bb25
bb33:
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t160, ptr %l15, !tbaa !23
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t164 = getelementptr %"compiler/ast:VarDecl", ptr %t162, i32 0, i32 2
  %t165 = load ptr, ptr %t164, !tbaa !29
  %t167 = icmp eq ptr %t165, null
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb34, label %bb35
bb34:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load ptr, ptr %l4, !tbaa !29
  %t174 = getelementptr %"compiler/ast:VarDecl", ptr %t172, i32 0, i32 2
  %t175 = load ptr, ptr %t174, !tbaa !29
  %t178 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v0, ptr %t171, ptr %t175)
  store i32 %t178, ptr %l104
  br label %bb36
bb35:
  br label %bb42
bb36:
  %t179 = load i32, ptr %l104, !tbaa !23
  store i32 %t179, ptr %l15, !tbaa !23
  %t180 = load i32, ptr %l15, !tbaa !23
  %t181 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t184 = icmp ne i32 %t180, %t181
  br i1 %t184, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  store ptr %t189, ptr %l109, !tbaa !29
  %t190 = load i64, ptr %l2, !tbaa !24
  %t192 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %s7, i64 %t190, i64 -1)
  store %"compiler/generic:Context" %t192, ptr %l111
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t193 = load %"compiler/generic:Context", ptr %l111
  %t194 = call ptr @__olang_scope_alloc_a(ptr %s7, i64 24, i64 8)
  store %"compiler/generic:Context" %t193, ptr %t194
  %t195 = load ptr, ptr %l4, !tbaa !29
  %t196 = load i32, ptr %l3, !tbaa !23
  %t197 = load ptr, ptr %l109, !tbaa !29
  %t201 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %s7, ptr %v0, ptr %t197, ptr %t194, ptr %t195, i32 %t196)
  store i32 %t201, ptr %l115
  br label %bb40
bb40:
  %t202 = load i32, ptr %l115, !tbaa !23
  store i32 %t202, ptr %l15, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 32
  %t207 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t205)
  store i64 %t207, ptr %l118
  br label %bb43
bb43:
  %t208 = load i64, ptr %l118, !tbaa !24
  store i64 %t208, ptr %l16, !tbaa !24
  store ptr null, ptr %l17, !tbaa !29
  %t209 = load i64, ptr %l8, !tbaa !24
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = getelementptr %"compiler/ast:VarDecl", ptr %t210, i32 0, i32 3
  %t213 = load { i64, ptr }, ptr %t212, !tbaa !27
  %t215 = extractvalue { i64, ptr } %t213, 0
  %t218 = icmp slt i64 %t209, %t215
  br i1 %t218, label %bb44, label %bb45
bb44:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l4, !tbaa !29
  %t223 = getelementptr %"compiler/ast:VarDecl", ptr %t221, i32 0, i32 3
  %t224 = load { i64, ptr }, ptr %t223, !tbaa !27
  store { i64, ptr } %t224, ptr %l126, !tbaa !27
  %t225 = load i64, ptr %l8, !tbaa !24
  %t227 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = getelementptr ptr, ptr %t228, i64 %t225
  %t230 = load ptr, ptr %t229, !tbaa !39
  %t231 = load i32, ptr %l15, !tbaa !23
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %t220, ptr %t230, i32 %t231)
  store ptr %t235, ptr %l130
  br label %bb46
bb45:
  %t236 = load ptr, ptr %l4, !tbaa !29
  %t238 = getelementptr %"compiler/ast:VarDecl", ptr %t236, i32 0, i32 3
  %t239 = load { i64, ptr }, ptr %t238, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t243 = icmp eq i64 %t241, 1
  br i1 %t243, label %bb72, label %bb73
bb46:
  %t245 = load ptr, ptr %l130, !tbaa !29
  store ptr %t245, ptr %l17, !tbaa !29
  %t247 = load ptr, ptr %l4, !tbaa !29
  %t249 = getelementptr %"compiler/ast:VarDecl", ptr %t247, i32 0, i32 2
  %t250 = load ptr, ptr %t249, !tbaa !29
  %t252 = icmp eq ptr %t250, null
  br i1 %t252, label %bb47, label %bb48
bb47:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load ptr, ptr %l4, !tbaa !29
  %t257 = getelementptr %"compiler/ast:VarDecl", ptr %t255, i32 0, i32 3
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  store { i64, ptr } %t258, ptr %l137, !tbaa !27
  %t259 = load i64, ptr %l8, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr ptr, ptr %t262, i64 %t259
  %t264 = load ptr, ptr %t263, !tbaa !39
  %t265 = load ptr, ptr %l17, !tbaa !29
  %t269 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v0, ptr %v0, ptr %t254, ptr %t264, ptr %t265, i1 true)
  store i32 %t269, ptr %l141
  br label %bb49
bb48:
  br label %bb50
bb49:
  %t270 = load i32, ptr %l141, !tbaa !23
  store i32 %t270, ptr %l15, !tbaa !23
  br label %bb50
bb50:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load i64, ptr %l2, !tbaa !24
  %t273 = load i32, ptr %l3, !tbaa !23
  %t274 = load ptr, ptr %l4, !tbaa !29
  %t279 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuildDefaulted(ptr %v0, ptr %v0, ptr %t271, i64 %t272, i32 %t273, ptr %t274)
  store i1 %t279, ptr %l146
  br label %bb51
bb51:
  %t280 = load i1, ptr %l146, !tbaa !21
  br i1 %t280, label %bb52, label %bb53
bb52:
  %t281 = load i32, ptr %l15, !tbaa !23
  %t282 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t285 = icmp ne i32 %t281, %t282
  store i1 %t285, ptr %l147, !tbaa !21
  br label %bb54
bb53:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb54
bb54:
  %t287 = load i1, ptr %l147, !tbaa !21
  br i1 %t287, label %bb55, label %bb56
bb55:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l7
  %t290 = load i32, ptr %l3, !tbaa !23
  %t291 = load i32, ptr %l15, !tbaa !23
  %t296 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefineValue(ptr %v0, ptr %t288, %"compiler/source:Span" %t289, i32 %t290, i32 %t291)
  store ptr %t296, ptr %l155
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t297 = load ptr, ptr %l155, !tbaa !29
  store ptr %t297, ptr %l18, !tbaa !29
  %t298 = load ptr, ptr %l18, !tbaa !29
  %t300 = icmp eq ptr %t298, null
  %t302 = xor i1 %t300, true
  br i1 %t302, label %bb58, label %bb59
bb58:
  %t304 = load ptr, ptr %l18, !tbaa !29
  store ptr %t304, ptr %l17, !tbaa !29
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t307 = load ptr, ptr %l4, !tbaa !29
  %t309 = getelementptr %"compiler/ast:VarDecl", ptr %t307, i32 0, i32 2
  %t310 = load ptr, ptr %t309, !tbaa !29
  %t312 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t310)
  store i1 %t312, ptr %l163
  br label %bb62
bb62:
  %t313 = load i1, ptr %l163, !tbaa !21
  br i1 %t313, label %bb63, label %bb64
bb63:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t315 = load i32, ptr %l15, !tbaa !23
  %t318 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t314, i32 %t315)
  store i1 %t318, ptr %l167
  br label %bb65
bb64:
  store i1 false, ptr %l164, !tbaa !21
  br label %bb66
bb65:
  %t319 = load i1, ptr %l167, !tbaa !21
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l164, !tbaa !21
  br label %bb66
bb66:
  %t322 = load i1, ptr %l164, !tbaa !21
  br i1 %t322, label %bb67, label %bb68
bb67:
  %t323 = load ptr, ptr %l0, !tbaa !29
  store ptr %t323, ptr %l169, !tbaa !29
  %t324 = load ptr, ptr %l17, !tbaa !29
  store ptr %t324, ptr %l170, !tbaa !29
  %t325 = load ptr, ptr %l4, !tbaa !29
  %t327 = getelementptr %"compiler/ast:VarDecl", ptr %t325, i32 0, i32 3
  %t328 = load { i64, ptr }, ptr %t327, !tbaa !27
  store { i64, ptr } %t328, ptr %l172, !tbaa !27
  %t329 = load i64, ptr %l8, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t329
  %t334 = load ptr, ptr %t333, !tbaa !39
  %t336 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t334)
  store %"compiler/source:Span" %t336, ptr %l175
  br label %bb69
bb68:
  br label %bb71
bb69:
  %t337 = load i64, ptr @G_2ecompiler_2fcheck_2eRoGlobal, !tbaa !24
  %t338 = load ptr, ptr %l169, !tbaa !29
  %t339 = load ptr, ptr %l170, !tbaa !29
  %t340 = load %"compiler/source:Span", ptr %l175
  %t342 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t338, ptr %t339, %"compiler/source:Span" %t340, i64 %t337)
  store i1 %t342, ptr %l177
  br label %bb70
bb70:
  br label %bb71
bb71:
  br label %bb81
bb72:
  %t343 = load ptr, ptr %l4, !tbaa !29
  %t345 = getelementptr %"compiler/ast:VarDecl", ptr %t343, i32 0, i32 0
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  %t350 = icmp sgt i64 %t348, 1
  store i1 %t350, ptr %l182, !tbaa !21
  br label %bb74
bb73:
  store i1 false, ptr %l182, !tbaa !21
  br label %bb74
bb74:
  %t352 = load i1, ptr %l182, !tbaa !21
  br i1 %t352, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load %"compiler/source:Span", ptr %l7
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s14, ptr %t353, %"compiler/source:Span" %t354, { i64, ptr } { i64 37, ptr @.d15 })
  br label %bb77
bb76:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l7
  %t359 = load i32, ptr %l15, !tbaa !23
  %t363 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %t357, %"compiler/source:Span" %t358, i32 %t359)
  store ptr %t363, ptr %l192
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s14)
  br label %bb80
bb78:
  %t364 = load ptr, ptr %l192, !tbaa !29
  store ptr %t364, ptr %l17, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load %"compiler/source:Span", ptr %l7
  %t368 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v0, ptr %t366, i32 1, %"compiler/source:Span" %t367, i32 %t368, ptr null)
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 23
  %t376 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l5
  %t377 = load i32, ptr %l15, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %t375, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t376, i32 %t377)
  br label %bb82
bb82:
  %t381 = load ptr, ptr %l17, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb83, label %bb84
bb83:
  %t387 = load i32, ptr %l15, !tbaa !23
  store i32 %t387, ptr %l205, !tbaa !23
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t388)
  store i32 %t390, ptr %l207
  br label %bb85
bb84:
  br label %bb105
bb85:
  %t391 = load i32, ptr %l205, !tbaa !23
  %t392 = load i32, ptr %l207, !tbaa !23
  %t393 = icmp eq i32 %t391, %t392
  br i1 %t393, label %bb86, label %bb87
bb86:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l210, !tbaa !29
  %t396 = load ptr, ptr %l17, !tbaa !29
  %t398 = icmp eq ptr %t396, null
  br i1 %t398, label %bb88, label %bb89
bb87:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb93
bb88:
  call void @__olang_check_failed(ptr @olang_loc_6495b6dfee4ecee2_6e1c2cfd4a22a64e)
  unreachable
bb89:
  br label %bb90
bb90:
  %t400 = load ptr, ptr %l17, !tbaa !29
  %t402 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %t400)
  store i32 %t402, ptr %l214
  br label %bb91
bb91:
  %t403 = load ptr, ptr %l210, !tbaa !29
  %t404 = load i32, ptr %l214, !tbaa !23
  %t405 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t403, i32 %t404)
  store i1 %t405, ptr %l215
  br label %bb92
bb92:
  %t406 = load i1, ptr %l215, !tbaa !21
  store i1 %t406, ptr %l209, !tbaa !21
  br label %bb93
bb93:
  %t407 = load i1, ptr %l209, !tbaa !21
  br i1 %t407, label %bb94, label %bb95
bb94:
  %t408 = load ptr, ptr %l0, !tbaa !29
  store ptr %t408, ptr %l216, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t409, ptr %l217
  %t410 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t410, ptr %l218
  %t411 = load i32, ptr %l15, !tbaa !23
  store i32 %t411, ptr %l219, !tbaa !23
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = icmp eq ptr %t412, null
  br i1 %t414, label %bb96, label %bb97
bb95:
  br label %bb100
bb96:
  call void @__olang_check_failed(ptr @olang_loc_6495b6dfee4ecee2_6e1c2cfd4a22a64e)
  unreachable
bb97:
  br label %bb98
bb98:
  %t416 = load ptr, ptr %l17, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t417
  %t418 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 0
  store i64 2, ptr %t418
  %t419 = load %"compiler/source:Span", ptr %l218
  %t420 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t419, 0
  %t421 = load i32, ptr %l219, !tbaa !23
  %t422 = insertvalue { %"compiler/source:Span", i32, ptr } %t420, i32 %t421, 1
  %t424 = insertvalue { %"compiler/source:Span", i32, ptr } %t422, ptr %t416, 2
  %t425 = getelementptr { i64, [4 x i64] }, ptr %t417, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t424, ptr %t425
  %t426 = load { i64, [4 x i64] }, ptr %t417
  %t428 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t426, ptr %t428
  %t429 = load ptr, ptr %l216, !tbaa !29
  %t430 = load %"compiler/source:Span", ptr %l217
  %t432 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t429, %"compiler/source:Span" %t430, ptr %t428)
  store ptr %t432, ptr %l225
  br label %bb99
bb99:
  %t433 = load ptr, ptr %l225, !tbaa !29
  store ptr %t433, ptr %l17, !tbaa !29
  br label %bb100
bb100:
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t437 = getelementptr %"compiler/check:Checker", ptr %t435, i32 0, i32 32
  store ptr %t437, ptr %l228, !tbaa !29
  %t438 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t438, ptr %l229
  %t439 = load %"compiler/source:Span", ptr %l7
  %t440 = load i32, ptr %l15, !tbaa !23
  %t441 = load i64, ptr %l2, !tbaa !24
  %t442 = load i32, ptr %l3, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t443
  %t444 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 0
  store i64 1, ptr %t444
  %t446 = insertvalue { %"compiler/source:Span", i32, i64, i32 } undef, %"compiler/source:Span" %t439, 0
  %t448 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t446, i32 %t440, 1
  %t450 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t448, i64 %t441, 2
  %t452 = insertvalue { %"compiler/source:Span", i32, i64, i32 } %t450, i32 %t442, 3
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t443, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, i32 } %t452, ptr %t453
  %t454 = load { i64, [4 x i64] }, ptr %t443
  %t456 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t454, ptr %t456
  store ptr %t456, ptr %l235, !tbaa !29
  %t457 = load ptr, ptr %l17, !tbaa !29
  %t459 = icmp eq ptr %t457, null
  br i1 %t459, label %bb101, label %bb102
bb101:
  call void @__olang_check_failed(ptr @olang_loc_8d548c3c72e36863_6a32d0416bf96aff)
  unreachable
bb102:
  br label %bb103
bb103:
  %t461 = load ptr, ptr %l17, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 0
  store i64 1, ptr %t463
  %t464 = load %"compiler/source:Span", ptr %l229
  %t465 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t464, 0
  %t466 = load ptr, ptr %l235, !tbaa !29
  %t467 = insertvalue { %"compiler/source:Span", ptr, ptr } %t465, ptr %t466, 1
  %t469 = insertvalue { %"compiler/source:Span", ptr, ptr } %t467, ptr %t461, 2
  %t470 = getelementptr { i64, [3 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t469, ptr %t470
  %t471 = load { i64, [3 x i64] }, ptr %t462
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t471, ptr %t473
  %t474 = load ptr, ptr %l228, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t474, ptr %t473)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t476 = load ptr, ptr %l0, !tbaa !29
  %t478 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t476)
  store ptr %t478, ptr %l242
  br label %bb106
bb106:
  %t479 = load ptr, ptr %l242, !tbaa !29
  store ptr %t479, ptr %l243, !tbaa !29
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t482 = getelementptr %"compiler/check:Checker", ptr %t480, i32 0, i32 32
  %t483 = load i64, ptr %l16, !tbaa !24
  %t486 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t482, i64 %t483)
  store { i64, ptr } %t486, ptr %l247
  br label %bb107
bb107:
  %t487 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t488 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t487)
  store %"compiler/typed:Block" %t488, ptr %l248
  br label %bb108
bb108:
  %t489 = load %"compiler/typed:Block", ptr %l248
  %t490 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t489, ptr %t490
  %t492 = load ptr, ptr %l243, !tbaa !29
  %t493 = getelementptr %"compiler/typed:Body", ptr %t492, i32 0, i32 11
  store ptr %t490, ptr %t493, !tbaa !29
  %t494 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t494)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckedPrim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i64
  %l9 = alloca i64
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l26 = alloca { i64, ptr }
  %rv = alloca ptr
  %t36 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t9, ptr %a4)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t15, ptr %a5)
  br label %bb3
bb3:
  store %"compiler/source:Span" %a1, ptr %l16
  %t20 = load i32, ptr %l2, !tbaa !23
  store i32 %t20, ptr %l17, !tbaa !23
  %t21 = load i32, ptr %l3
  store i32 %t21, ptr %l18
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l3
  %t24 = load i32, ptr %l2, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earithCheck(ptr %v0, ptr %t22, i32 %t23, i32 %t24)
  store i32 %t28, ptr %l22
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 31
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t31, i64 %t32)
  store { i64, ptr } %t35, ptr %l26
  br label %bb5
bb5:
  store { i64, [5 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 0
  store i64 9, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l16
  %t39 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t38, 0
  %t40 = load i32, ptr %l17, !tbaa !23
  %t41 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t39, i32 %t40, 1
  %t42 = load i32, ptr %l18
  %t43 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t41, i32 %t42, 2
  %t44 = load i32, ptr %l22
  %t45 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t43, i32 %t44, 3
  %t46 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t47 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t45, { i64, ptr } %t46, 4
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t47, ptr %t48
  %t49 = load { i64, [5 x i64] }, ptr %t36
  %t51 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t49, ptr %t51
  store ptr %t51, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l6 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca i32
  %l22 = alloca i32
  %l31 = alloca i64
  %l33 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t6 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  %t8 = xor i1 %t7, true
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t15)
  store ptr %t17, ptr %l12
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t22 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t23 = load ptr, ptr %l10, !tbaa !29
  %t27 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t23, ptr %t20, ptr %t21, i32 %t22)
  store i32 %t27, ptr %l17
  br label %bb6
bb6:
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %l2, !tbaa !23
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l22
  br label %bb7
bb7:
  %t39 = load i32, ptr %l22
  %t41 = trunc i64 26 to i32
  %t42 = icmp eq i32 %t39, %t41
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb8, label %bb9
bb8:
  store i64 -1, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l2, !tbaa !23
  %t56 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l31
  br label %bb11
bb11:
  %t57 = load i64, ptr %l31, !tbaa !24
  %t58 = icmp ne i64 %t57, 0
  br i1 %t58, label %bb12, label %bb13
bb12:
  store i64 1, ptr %l33, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecountPost(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, i64, i64 }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i64
  %l17 = alloca { i64, i64, i64 }
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/source:Span"
  %l25 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l35 = alloca i32
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l43 = alloca i32
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l54 = alloca ptr
  %rv = alloca ptr
  %t38 = alloca { i64, [4 x i64] }, align 8
  %t79 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store ptr null, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 32
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l13
  br label %bb4
bb4:
  %t11 = load i64, ptr %l13, !tbaa !24
  store i64 %t11, ptr %l3, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l1
  %t17 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t12, i32 3, %"compiler/source:Span" %t13)
  store { i64, i64, i64 } %t17, ptr %l17
  br label %bb5
bb5:
  %t18 = load { i64, i64, i64 }, ptr %l17
  store { i64, i64, i64 } %t18, ptr %l4
  %t19 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 0
  %t20 = load i64, ptr %t19, !tbaa !24
  store i64 %t20, ptr %l5, !tbaa !24
  %t22 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 1
  %t23 = load i64, ptr %t22, !tbaa !24
  store i64 %t23, ptr %l6, !tbaa !24
  %t25 = getelementptr { i64, i64, i64 }, ptr %l4, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l7, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l21, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t29, ptr %l22
  %t30 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t30, ptr %l23
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l25
  br label %bb6
bb6:
  %t34 = load i64, ptr %l2, !tbaa !24
  %t36 = trunc i64 %t34 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t38
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 0
  store i64 0, ptr %t39
  %t40 = load %"compiler/source:Span", ptr %l23
  %t41 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t40, 0
  %t42 = load i32, ptr %l25, !tbaa !23
  %t43 = insertvalue { %"compiler/source:Span", i32, i32 } %t41, i32 %t42, 1
  %t45 = insertvalue { %"compiler/source:Span", i32, i32 } %t43, i32 %t36, 2
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t45, ptr %t46
  %t47 = load { i64, [4 x i64] }, ptr %t38
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l31, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l32
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t52)
  store i32 %t54, ptr %l34
  br label %bb7
bb7:
  store i32 3, ptr %l35
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l1
  %t57 = load i64, ptr %l2, !tbaa !24
  %t61 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t55, %"compiler/source:Span" %t56, i64 %t57)
  store ptr %t61, ptr %l39
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l40, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t63, ptr %l41
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t64)
  store i32 %t66, ptr %l43
  br label %bb9
bb9:
  %t67 = load ptr, ptr %l40, !tbaa !29
  %t68 = load %"compiler/source:Span", ptr %l41
  %t69 = load i32, ptr %l43, !tbaa !23
  %t70 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t67, %"compiler/source:Span" %t68, i32 %t69, i64 1)
  store ptr %t70, ptr %l44
  br label %bb10
bb10:
  %t71 = load ptr, ptr %l44, !tbaa !29
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t73 = load %"compiler/source:Span", ptr %l32
  %t74 = load i32, ptr %l34, !tbaa !23
  %t75 = load i32, ptr %l35
  %t76 = load ptr, ptr %l39, !tbaa !29
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t72, %"compiler/source:Span" %t73, i32 %t74, i32 %t75, ptr %t76, ptr %t71)
  store ptr %t78, ptr %l46
  br label %bb11
bb11:
  store { i64, [3 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 0
  store i64 1, ptr %t80
  %t81 = load %"compiler/source:Span", ptr %l22
  %t82 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t81, 0
  %t83 = load ptr, ptr %l30, !tbaa !29
  %t84 = insertvalue { %"compiler/source:Span", ptr, ptr } %t82, ptr %t83, 1
  %t85 = load ptr, ptr %l46, !tbaa !29
  %t86 = insertvalue { %"compiler/source:Span", ptr, ptr } %t84, ptr %t85, 2
  %t87 = getelementptr { i64, [3 x i64] }, ptr %t79, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t86, ptr %t87
  %t88 = load { i64, [3 x i64] }, ptr %t79
  %t90 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t88, ptr %t90
  %t91 = load ptr, ptr %l21, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t91, ptr %t90)
  br label %bb12
bb12:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t93, i64 %t94, i64 %t95, i64 %t96, i64 %t97)
  store ptr %t103, ptr %l54
  br label %bb13
bb13:
  %t104 = load ptr, ptr %l54, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, i64, i64 }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca { i64, i64, i64 }
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca i32
  %l56 = alloca i32
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l66 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca i32
  %l82 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l91 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l125 = alloca %"compiler/typed:Elem"
  %l129 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca i32
  %l146 = alloca ptr
  %l150 = alloca ptr
  %l152 = alloca ptr
  %l154 = alloca ptr
  %l156 = alloca ptr
  %l158 = alloca i32
  %l159 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l164 = alloca i64
  %l169 = alloca ptr
  %l171 = alloca ptr
  %l175 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l181 = alloca ptr
  %l183 = alloca ptr
  %l187 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l189 = alloca ptr
  %l191 = alloca ptr
  %l195 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l199 = alloca i64
  %l203 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l207 = alloca i32
  %l217 = alloca i64
  %l219 = alloca ptr
  %l222 = alloca i64
  %l223 = alloca i32
  %l224 = alloca i64
  %l226 = alloca ptr
  %l229 = alloca i64
  %l230 = alloca i32
  %l236 = alloca ptr
  %l239 = alloca i64
  %l243 = alloca { i64, i64, i64 }
  %l247 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l249 = alloca i32
  %l250 = alloca i32
  %l254 = alloca ptr
  %l258 = alloca ptr
  %l260 = alloca ptr
  %l278 = alloca ptr
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t97 = alloca { i64, [2 x i64] }, align 8
  %t121 = alloca { i64, [3 x i64] }, align 8
  %t173 = alloca { i64, [4 x i64] }, align 8
  %t213 = alloca { i64, [4 x i64] }, align 8
  %t275 = alloca { i64, [2 x i64] }, align 8
  %t378 = alloca { i64, [3 x i64] }, align 8
  %t494 = alloca { i64, [4 x i64] }, align 8
  %t507 = alloca { i64, [3 x i64] }, align 8
  %t538 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load i64, ptr %l32, !tbaa !24
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l36
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l36
  store { i64, i64, i64 } %t13, ptr %l12
  %t14 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l13, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l15, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l41
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l41, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l46
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l46, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 11
  %t38 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l50, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l51, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t43, ptr %l52
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l53, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l54
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t46, ptr %l55, !tbaa !23
  store i32 15, ptr %l56
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i64, ptr %l3, !tbaa !24
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, i64 %t49)
  store ptr %t53, ptr %l60
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i64 %a4)
  store ptr %t60, ptr %l64
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l64, !tbaa !29
  %t62 = load ptr, ptr %l53, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l54
  %t64 = load i32, ptr %l55, !tbaa !23
  %t65 = load i32, ptr %l56
  %t66 = load ptr, ptr %l60, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t62, %"compiler/source:Span" %t63, i32 %t64, i32 %t65, ptr %t66, ptr %t61)
  store ptr %t68, ptr %l66
  br label %bb9
bb9:
  %t69 = load i64, ptr %l13, !tbaa !24
  %t70 = load ptr, ptr %l51, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l52
  %t72 = load ptr, ptr %l66, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, ptr %t72, i64 %t69)
  store ptr %t74, ptr %l68
  br label %bb10
bb10:
  %t75 = load ptr, ptr %l50, !tbaa !29
  %t76 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t75, ptr %t76)
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l3, !tbaa !24
  %t81 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t77, i64 %t78)
  store i32 %t81, ptr %l71
  br label %bb12
bb12:
  %t82 = load i32, ptr %l71, !tbaa !23
  store i32 %t82, ptr %l16, !tbaa !23
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/ast:ForIn", ptr %t83, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = icmp ne i32 %t86, 0
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/ast:ForIn", ptr %t91, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load %"compiler/source:Span", ptr %l1
  %t96 = load i32, ptr %l16, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load { i64, [2 x i64] }, ptr %t97
  %t106 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t90, i32 %t94, %"compiler/source:Span" %t95, i32 %t96, i32 1, { i64, [2 x i64] } %t99)
  store i64 %t106, ptr %l82
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t107 = load i64, ptr %l82, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l83, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t109, ptr %l84
  %t112 = trunc i64 %t107 to i32
  store i32 %t112, ptr %l87, !tbaa !23
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  %t116 = load i64, ptr %l3, !tbaa !24
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t114, %"compiler/source:Span" %t115, i64 %t116)
  store ptr %t120, ptr %l91
  br label %bb16
bb16:
  store { i64, [3 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [3 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t123 = load %"compiler/source:Span", ptr %l84
  %t124 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t123, 0
  %t125 = load i32, ptr %l87, !tbaa !23
  %t126 = insertvalue { %"compiler/source:Span", i32, ptr } %t124, i32 %t125, 1
  %t127 = load ptr, ptr %l91, !tbaa !29
  %t128 = insertvalue { %"compiler/source:Span", i32, ptr } %t126, ptr %t127, 2
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t121, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t128, ptr %t129
  %t130 = load { i64, [3 x i64] }, ptr %t121
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t130, ptr %t132
  %t133 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t133, ptr %t132)
  br label %bb17
bb17:
  br label %bb18
bb18:
  store ptr null, ptr %l18, !tbaa !29
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = icmp sge i64 %t135, 0
  br i1 %t137, label %bb19, label %bb20
bb19:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l5, !tbaa !24
  %t143 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t139, i64 %t140)
  store i32 %t143, ptr %l98
  br label %bb21
bb20:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l131, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l132
  %t146 = load i32, ptr %l16, !tbaa !23
  store i32 %t146, ptr %l133, !tbaa !23
  store i32 3, ptr %l134
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t147, %"compiler/source:Span" %t148, i64 %a7)
  store ptr %t153, ptr %l138
  br label %bb28
bb21:
  %t154 = load i32, ptr %l98, !tbaa !23
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l99
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t161, i32 %t154)
  store i32 %t165, ptr %l104
  br label %bb22
bb22:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t168 = load i64, ptr %l5, !tbaa !24
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t166, %"compiler/source:Span" %t167, i64 %t168)
  store ptr %t172, ptr %l108
  br label %bb23
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 0
  store i64 2, ptr %t174
  %t175 = load %"compiler/source:Span", ptr %l99
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t175, 0
  %t177 = load i32, ptr %l104, !tbaa !23
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, i32 %t177, 1
  %t179 = load ptr, ptr %l108, !tbaa !29
  %t180 = insertvalue { %"compiler/source:Span", i32, ptr } %t178, ptr %t179, 2
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t180, ptr %t181
  %t182 = load { i64, [4 x i64] }, ptr %t173
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t182, ptr %t184
  store ptr %t184, ptr %l20, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l111, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t187, ptr %l112
  %t188 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t188, ptr %l113
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t194, i32 %a6)
  store i32 %t198, ptr %l118
  br label %bb24
bb24:
  %t199 = load ptr, ptr %l20, !tbaa !29
  store ptr %t199, ptr %l119, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  %t202 = load i64, ptr %l3, !tbaa !24
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t200, %"compiler/source:Span" %t201, i64 %t202)
  store ptr %t206, ptr %l123
  br label %bb25
bb25:
  %t207 = load ptr, ptr %l119, !tbaa !29
  %t208 = load ptr, ptr %l123, !tbaa !29
  %t210 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t207, ptr %t208, i32 0)
  store %"compiler/typed:Elem" %t210, ptr %l125
  br label %bb26
bb26:
  %t211 = load %"compiler/typed:Elem", ptr %l125
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t211, ptr %t212
  store { i64, [4 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 0
  store i64 4, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l113
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t215, 0
  %t217 = load i32, ptr %l118, !tbaa !23
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr } %t216, i32 %t217, 1
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr } %t218, ptr %t212, 2
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t220, ptr %t221
  %t222 = load { i64, [4 x i64] }, ptr %t213
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t222, ptr %t224
  %t225 = load ptr, ptr %l111, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l112
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t225, %"compiler/source:Span" %t226, ptr %t224)
  store ptr %t228, ptr %l129
  br label %bb27
bb27:
  %t229 = load ptr, ptr %l129, !tbaa !29
  store ptr %t229, ptr %l18, !tbaa !29
  br label %bb33
bb28:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l139, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t232, ptr %l140
  %t233 = load i32, ptr %l16, !tbaa !23
  store i32 %t233, ptr %l141, !tbaa !23
  store i32 5, ptr %l142
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t236 = load i64, ptr %l3, !tbaa !24
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t234, %"compiler/source:Span" %t235, i64 %t236)
  store ptr %t240, ptr %l146
  br label %bb29
bb29:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l1
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t241, %"compiler/source:Span" %t242, i64 %a8)
  store ptr %t247, ptr %l150
  br label %bb30
bb30:
  %t248 = load ptr, ptr %l150, !tbaa !29
  %t249 = load ptr, ptr %l139, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l140
  %t251 = load i32, ptr %l141, !tbaa !23
  %t252 = load i32, ptr %l142
  %t253 = load ptr, ptr %l146, !tbaa !29
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t249, %"compiler/source:Span" %t250, i32 %t251, i32 %t252, ptr %t253, ptr %t248)
  store ptr %t255, ptr %l152
  br label %bb31
bb31:
  %t256 = load ptr, ptr %l152, !tbaa !29
  %t257 = load ptr, ptr %l131, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l132
  %t259 = load i32, ptr %l133, !tbaa !23
  %t260 = load i32, ptr %l134
  %t261 = load ptr, ptr %l138, !tbaa !29
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259, i32 %t260, ptr %t261, ptr %t256)
  store ptr %t263, ptr %l154
  br label %bb32
bb32:
  %t264 = load ptr, ptr %l154, !tbaa !29
  store ptr %t264, ptr %l18, !tbaa !29
  br label %bb33
bb33:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l156, !tbaa !29
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr %"compiler/ast:ForIn", ptr %t267, i32 0, i32 1
  %t270 = load i32, ptr %t269, !tbaa !23
  store i32 %t270, ptr %l158, !tbaa !23
  %t271 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t271, ptr %l159
  %t272 = load ptr, ptr %l18, !tbaa !29
  %t274 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t272)
  store i32 %t274, ptr %l161
  br label %bb34
bb34:
  store { i64, [2 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [2 x i64] }, ptr %t275, i32 0, i32 0
  store i64 5, ptr %t276
  %t277 = load { i64, [2 x i64] }, ptr %t275
  %t278 = load ptr, ptr %l156, !tbaa !29
  %t279 = load i32, ptr %l158, !tbaa !23
  %t280 = load %"compiler/source:Span", ptr %l159
  %t281 = load i32, ptr %l161, !tbaa !23
  %t284 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t278, i32 %t279, %"compiler/source:Span" %t280, i32 %t281, i32 1, { i64, [2 x i64] } %t277)
  store i64 %t284, ptr %l164
  br label %bb35
bb35:
  %t285 = load i64, ptr %l164, !tbaa !24
  store i64 %t285, ptr %l21, !tbaa !24
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t286, i32 0, i32 29
  %t289 = getelementptr %"compiler/source:Span", ptr %t288, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = icmp sge i32 %t290, 0
  br i1 %t292, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 27
  store ptr %t296, ptr %l169, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t297)
  store ptr %t299, ptr %l171
  br label %bb38
bb37:
  br label %bb51
bb38:
  %t300 = load ptr, ptr %l171, !tbaa !29
  %t302 = getelementptr %"compiler/check:frame", ptr %t300, i32 0, i32 0
  %t303 = load i64, ptr %t302, !tbaa !24
  %t304 = load i64, ptr %l21, !tbaa !24
  %t307 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t303, i64 %t304)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t307, ptr %l175
  br label %bb39
bb39:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/check:Checker", ptr %t308, i32 0, i32 29
  %t311 = load %"compiler/source:Span", ptr %t310
  %t312 = load ptr, ptr %l169, !tbaa !29
  %t313 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l175
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_He56f4e53267726fe8dffcfd34146d8e6(ptr %v0, ptr %t312, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t313, %"compiler/source:Span" %t311)
  br label %bb40
bb40:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 30
  %t318 = load i1, ptr %t317, !tbaa !21
  br i1 %t318, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/check:Checker", ptr %t320, i32 0, i32 26
  store ptr %t322, ptr %l181, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t323)
  store ptr %t325, ptr %l183
  br label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 28
  store ptr %t328, ptr %l189, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t329)
  store ptr %t331, ptr %l191
  br label %bb46
bb43:
  %t332 = load ptr, ptr %l183, !tbaa !29
  %t334 = getelementptr %"compiler/check:frame", ptr %t332, i32 0, i32 0
  %t335 = load i64, ptr %t334, !tbaa !24
  %t336 = load i64, ptr %l21, !tbaa !24
  %t339 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t335, i64 %t336)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t339, ptr %l187
  br label %bb44
bb44:
  %t340 = load ptr, ptr %l181, !tbaa !29
  %t341 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l187
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t340, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t341, i1 true)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb46:
  %t342 = load ptr, ptr %l191, !tbaa !29
  %t344 = getelementptr %"compiler/check:frame", ptr %t342, i32 0, i32 0
  %t345 = load i64, ptr %t344, !tbaa !24
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s6, i64 %t345, i64 %t346)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t349, ptr %l195
  br label %bb47
bb47:
  %t350 = load ptr, ptr %l189, !tbaa !29
  %t351 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l195
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t350, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t351, i1 true)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l196, !tbaa !29
  %t353 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 -1, i32 -1)
  store %"compiler/source:Span" %t353, ptr %l197
  br label %bb50
bb50:
  %t354 = load %"compiler/source:Span", ptr %l197
  %t355 = load ptr, ptr %l196, !tbaa !29
  %t356 = getelementptr %"compiler/check:Checker", ptr %t355, i32 0, i32 29
  store %"compiler/source:Span" %t354, ptr %t356
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb51:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l198, !tbaa !29
  %t358 = load i64, ptr %l21, !tbaa !24
  store i64 %t358, ptr %l199, !tbaa !24
  %t359 = load ptr, ptr %l18, !tbaa !29
  %t361 = icmp eq ptr %t359, null
  br i1 %t361, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_8ffd1bc2c5314d3c_1a7e454980bc5230)
  unreachable
bb53:
  br label %bb54
bb54:
  %t363 = load ptr, ptr %l18, !tbaa !29
  %t364 = load ptr, ptr %l198, !tbaa !29
  %t365 = load i64, ptr %l199, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t364, i64 %t365, ptr %t363)
  br label %bb55
bb55:
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l203, !tbaa !29
  %t368 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t368, ptr %l204
  %t369 = load i64, ptr %l21, !tbaa !24
  %t371 = trunc i64 %t369 to i32
  store i32 %t371, ptr %l207, !tbaa !23
  %t373 = load ptr, ptr %l18, !tbaa !29
  %t375 = icmp eq ptr %t373, null
  br i1 %t375, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_6754b7d1e64b38ab_d9cb88888f730d0f)
  unreachable
bb57:
  br label %bb58
bb58:
  %t377 = load ptr, ptr %l18, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t378
  %t379 = getelementptr { i64, [3 x i64] }, ptr %t378, i32 0, i32 0
  store i64 0, ptr %t379
  %t380 = load %"compiler/source:Span", ptr %l204
  %t381 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t380, 0
  %t382 = load i32, ptr %l207, !tbaa !23
  %t383 = insertvalue { %"compiler/source:Span", i32, ptr } %t381, i32 %t382, 1
  %t385 = insertvalue { %"compiler/source:Span", i32, ptr } %t383, ptr %t377, 2
  %t386 = getelementptr { i64, [3 x i64] }, ptr %t378, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t385, ptr %t386
  %t387 = load { i64, [3 x i64] }, ptr %t378
  %t389 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t387, ptr %t389
  %t390 = load ptr, ptr %l203, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t390, ptr %t389)
  br label %bb59
bb59:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t392, ptr %t393, ptr %a9, i32 %a10)
  br label %bb60
bb60:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t400)
  store ptr %t402, ptr %l219
  br label %bb61
bb61:
  %t403 = load ptr, ptr %l219, !tbaa !29
  %t405 = getelementptr %"compiler/check:frame", ptr %t403, i32 0, i32 10
  %t407 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t405)
  %t408 = extractvalue { i32, i64 } %t407, 1
  %t409 = extractvalue { i32, i64 } %t407, 0
  store i32 %t409, ptr %l223
  %t410 = icmp ne i32 %t409, 0
  br i1 %t410, label %bb63, label %ok.411
ok.411:
  store i64 %t408, ptr %l222
  br label %bb62
bb62:
  %t412 = load i64, ptr %l222, !tbaa !24
  store i64 %t412, ptr %l217, !tbaa !24
  br label %bb65
bb63:
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t413)
  store ptr %t415, ptr %l226
  br label %bb66
bb66:
  %t416 = load ptr, ptr %l226, !tbaa !29
  %t418 = getelementptr %"compiler/check:frame", ptr %t416, i32 0, i32 11
  %t420 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t418)
  %t421 = extractvalue { i32, i64 } %t420, 1
  %t422 = extractvalue { i32, i64 } %t420, 0
  store i32 %t422, ptr %l230
  %t423 = icmp ne i32 %t422, 0
  br i1 %t423, label %bb68, label %ok.424
ok.424:
  store i64 %t421, ptr %l229
  br label %bb67
bb67:
  %t425 = load i64, ptr %l229, !tbaa !24
  store i64 %t425, ptr %l224, !tbaa !24
  br label %bb70
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load i64, ptr %l13, !tbaa !24
  %t428 = load i64, ptr %l14, !tbaa !24
  %t429 = load i64, ptr %l15, !tbaa !24
  %t430 = load i64, ptr %l11, !tbaa !24
  %t436 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t426, i64 %t427, i64 %t428, i64 %t429, i64 %t430)
  store ptr %t436, ptr %l236
  br label %bb71
bb71:
  %t437 = load ptr, ptr %l236, !tbaa !29
  store ptr %t437, ptr %l22, !tbaa !29
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/check:Checker", ptr %t438, i32 0, i32 32
  %t442 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t440)
  store i64 %t442, ptr %l239
  br label %bb72
bb72:
  %t443 = load i64, ptr %l239, !tbaa !24
  store i64 %t443, ptr %l23, !tbaa !24
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l1
  %t449 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t444, i32 3, %"compiler/source:Span" %t445)
  store { i64, i64, i64 } %t449, ptr %l243
  br label %bb73
bb73:
  %t450 = load { i64, i64, i64 }, ptr %l243
  store { i64, i64, i64 } %t450, ptr %l24
  %t451 = getelementptr { i64, i64, i64 }, ptr %l24, i32 0, i32 0
  %t452 = load i64, ptr %t451, !tbaa !24
  store i64 %t452, ptr %l25, !tbaa !24
  %t454 = getelementptr { i64, i64, i64 }, ptr %l24, i32 0, i32 1
  %t455 = load i64, ptr %t454, !tbaa !24
  store i64 %t455, ptr %l26, !tbaa !24
  %t457 = getelementptr { i64, i64, i64 }, ptr %l24, i32 0, i32 2
  %t458 = load i64, ptr %t457, !tbaa !24
  store i64 %t458, ptr %l27, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l247, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t461, ptr %l248
  %t462 = load i32, ptr %l16, !tbaa !23
  store i32 %t462, ptr %l249, !tbaa !23
  store i32 3, ptr %l250
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load %"compiler/source:Span", ptr %l1
  %t465 = load i64, ptr %l3, !tbaa !24
  %t469 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t463, %"compiler/source:Span" %t464, i64 %t465)
  store ptr %t469, ptr %l254
  br label %bb74
bb74:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load %"compiler/source:Span", ptr %l1
  %t472 = load i32, ptr %l16, !tbaa !23
  %t476 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t470, %"compiler/source:Span" %t471, i32 %t472, i64 1)
  store ptr %t476, ptr %l258
  br label %bb75
bb75:
  %t477 = load ptr, ptr %l258, !tbaa !29
  %t478 = load ptr, ptr %l247, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l248
  %t480 = load i32, ptr %l249, !tbaa !23
  %t481 = load i32, ptr %l250
  %t482 = load ptr, ptr %l254, !tbaa !29
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t478, %"compiler/source:Span" %t479, i32 %t480, i32 %t481, ptr %t482, ptr %t477)
  store ptr %t484, ptr %l260
  br label %bb76
bb76:
  %t485 = load ptr, ptr %l260, !tbaa !29
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load %"compiler/source:Span", ptr %l1
  %t488 = load %"compiler/source:Span", ptr %l1
  %t489 = load i32, ptr %l16, !tbaa !23
  %t490 = load i64, ptr %l3, !tbaa !24
  %t492 = trunc i64 %t490 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t494
  %t495 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 0
  store i64 0, ptr %t495
  %t497 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t488, 0
  %t499 = insertvalue { %"compiler/source:Span", i32, i32 } %t497, i32 %t489, 1
  %t501 = insertvalue { %"compiler/source:Span", i32, i32 } %t499, i32 %t492, 2
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t501, ptr %t502
  %t503 = load { i64, [4 x i64] }, ptr %t494
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t503, ptr %t505
  store { i64, [3 x i64] } zeroinitializer, ptr %t507
  %t508 = getelementptr { i64, [3 x i64] }, ptr %t507, i32 0, i32 0
  store i64 1, ptr %t508
  %t510 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t487, 0
  %t512 = insertvalue { %"compiler/source:Span", ptr, ptr } %t510, ptr %t505, 1
  %t514 = insertvalue { %"compiler/source:Span", ptr, ptr } %t512, ptr %t485, 2
  %t515 = getelementptr { i64, [3 x i64] }, ptr %t507, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t514, ptr %t515
  %t516 = load { i64, [3 x i64] }, ptr %t507
  %t518 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t516, ptr %t518
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t486, ptr %t518)
  br label %bb77
bb77:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load i64, ptr %l25, !tbaa !24
  %t523 = load i64, ptr %l26, !tbaa !24
  %t524 = load i64, ptr %l27, !tbaa !24
  %t525 = load i64, ptr %l23, !tbaa !24
  %t531 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t521, i64 %t522, i64 %t523, i64 %t524, i64 %t525)
  store ptr %t531, ptr %l278
  br label %bb78
bb78:
  %t532 = load ptr, ptr %l278, !tbaa !29
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load %"compiler/source:Span", ptr %l1
  %t535 = load ptr, ptr %l22, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t538
  %t539 = getelementptr { i64, [3 x i64] }, ptr %t538, i32 0, i32 0
  store i64 4, ptr %t539
  %t541 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t534, 0
  %t543 = insertvalue { %"compiler/source:Span", ptr, ptr } %t541, ptr %t535, 1
  %t545 = insertvalue { %"compiler/source:Span", ptr, ptr } %t543, ptr %t532, 2
  %t546 = getelementptr { i64, [3 x i64] }, ptr %t538, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t545, ptr %t546
  %t547 = load { i64, [3 x i64] }, ptr %t538
  %t549 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t547, ptr %t549
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t533, ptr %t549)
  br label %bb79
bb79:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, i64 %a3, i32 %a4, { i64, ptr } %a5, { i64, ptr } %a6, %"compiler/source:Span" %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l41 = alloca ptr
  %l47 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l55 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca i64
  %l64 = alloca i64
  %l82 = alloca { i64, ptr }
  %l87 = alloca i1
  %l90 = alloca ptr
  %l95 = alloca i32
  %l100 = alloca i64
  %l104 = alloca i32
  %l107 = alloca ptr
  %l113 = alloca i64
  %l123 = alloca { i64, ptr }
  %l135 = alloca i32
  %l140 = alloca ptr
  %l143 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l146 = alloca i32
  %l147 = alloca i32
  %l150 = alloca ptr
  %l151 = alloca i64
  %l153 = alloca { i64, ptr }
  %l158 = alloca i32
  %l159 = alloca i32
  %l171 = alloca i64
  %l180 = alloca ptr
  %l181 = alloca ptr
  %l184 = alloca %"compiler/generic:Context"
  %l185 = alloca ptr
  %l188 = alloca i64
  %l192 = alloca i64
  %l196 = alloca ptr
  %l199 = alloca i32
  %l208 = alloca ptr
  %l215 = alloca i32
  %l222 = alloca %"compiler/source:Span"
  %l224 = alloca i32
  %l240 = alloca { i64, ptr }
  %l247 = alloca ptr
  %l249 = alloca i32
  %l251 = alloca %"compiler/source:Span"
  %l254 = alloca i32
  %l267 = alloca i64
  %l270 = alloca i64
  %l289 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l309 = alloca ptr
  %l312 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i64
  %t265 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  store %"compiler/source:Span" %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %t1, i64 %t2)
  store ptr %t5, ptr %l41
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l41, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t9 = icmp eq ptr %t7, null
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_4d78ccd557b2cb07_4b61304073c9a48b)
  unreachable
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  store ptr %t18, ptr %l47, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l52
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l47, !tbaa !29
  %t30 = load i32, ptr %l52, !tbaa !23
  %t31 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t31, ptr %l53
  br label %bb6
bb6:
  %t32 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t32, ptr %l10, !tbaa !27
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l54
  br label %bb7
bb7:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l54
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l11
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l55
  br label %bb8
bb8:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t43 = load i64, ptr %l14, !tbaa !24
  %t44 = load i64, ptr %l13, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb9, label %bb10
bb9:
  %t49 = load i64, ptr %l15, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l61, !tbaa !24
  br label %bb14
bb11:
  %t53 = load i64, ptr %l14, !tbaa !24
  %t54 = load i64, ptr %l13, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l15, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l15, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l64, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb13
bb13:
  %t69 = load i64, ptr %l64, !tbaa !24
  store i64 %t69, ptr %l61, !tbaa !24
  br label %bb14
bb14:
  %t70 = load i64, ptr %l61, !tbaa !24
  store i64 %t70, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t71 = load i64, ptr %l17, !tbaa !24
  %t72 = load i64, ptr %l16, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb17:
  br label %bb18
bb18:
  %t79 = load i64, ptr %l13, !tbaa !24
  %t80 = load i64, ptr %l17, !tbaa !24
  %t81 = load i64, ptr %l15, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l18, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t89, ptr %l82, !tbaa !27
  %t90 = load i64, ptr %l18, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t90
  %t95 = load i32, ptr %t94, !tbaa !33
  store i32 %t95, ptr %l19, !tbaa !23
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i32, ptr %l19, !tbaa !23
  %t101 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t97, i32 %t98)
  store i1 %t101, ptr %l87
  br label %bb19
bb19:
  %t102 = load i1, ptr %l87, !tbaa !21
  br i1 %t102, label %bb20, label %bb21
bb20:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  store ptr %t108, ptr %l90, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l19, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l95
  br label %bb22
bb21:
  br label %bb25
bb22:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l19, !tbaa !23
  %t128 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t124, i32 %t125)
  store i64 %t128, ptr %l100
  br label %bb23
bb23:
  %t129 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t131 = xor i64 %t129, -1
  %t132 = load i64, ptr %l100, !tbaa !24
  %t134 = and i64 %t132, %t131
  %t135 = load ptr, ptr %l90, !tbaa !29
  %t136 = load i32, ptr %l95, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t135, i32 %t136, i64 %t134)
  store i32 %t138, ptr %l104
  br label %bb24
bb24:
  %t139 = load i32, ptr %l104, !tbaa !23
  store i32 %t139, ptr %l19, !tbaa !23
  br label %bb25
bb25:
  %t140 = load i32, ptr %l19, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l11, i32 %t140)
  br label %bb26
bb26:
  store ptr %l12, ptr %l107, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l4, !tbaa !23
  %t150 = load i64, ptr %l18, !tbaa !24
  %t154 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %t148, i32 %t149, i64 %t150)
  store i64 %t154, ptr %l113
  br label %bb27
bb27:
  %t155 = load ptr, ptr %l107, !tbaa !29
  %t156 = load i64, ptr %l113, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t155, i64 %t156)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  %t157 = load i64, ptr %l17, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l17, !tbaa !24
  br label %bb15
bb30:
  %t161 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t161, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  store i64 %t165, ptr %l22, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t167 = load i64, ptr %l21, !tbaa !24
  %t168 = load i64, ptr %l22, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb33:
  br label %bb34
bb34:
  %t175 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t175, ptr %l123, !tbaa !27
  %t176 = load i64, ptr %l21, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i32, ptr %t179, i64 %t176
  %t181 = load i32, ptr %t180, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l11, i32 %t181)
  br label %bb35
bb35:
  %t186 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l12, i64 %t186)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %bb37
bb37:
  %t189 = load i64, ptr %l21, !tbaa !24
  %t191 = add i64 %t189, 1
  store i64 %t191, ptr %l21, !tbaa !24
  br label %bb31
bb38:
  %t193 = load i32, ptr %l2
  %t195 = trunc i64 2 to i32
  %t196 = icmp eq i32 %t193, %t195
  %t198 = xor i1 %t196, true
  br i1 %t198, label %bb39, label %bb40
bb39:
  %t200 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t200, ptr %l135, !tbaa !23
  br label %bb41
bb40:
  %t202 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t202, ptr %l135, !tbaa !23
  br label %bb41
bb41:
  %t204 = load i32, ptr %l135, !tbaa !23
  store i32 %t204, ptr %l24, !tbaa !23
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !29
  %t210 = getelementptr %"compiler/generic:Program", ptr %t208, i32 0, i32 2
  store ptr %t210, ptr %l140, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  store ptr %t216, ptr %l143, !tbaa !29
  %t218 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s0, ptr %s0, ptr %l11)
  store { i64, ptr } %t218, ptr %l145
  br label %bb42
bb42:
  %t219 = load ptr, ptr %l143, !tbaa !29
  %t220 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t221 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t219, { i64, ptr } %t220)
  store i32 %t221, ptr %l146
  br label %bb43
bb43:
  %t222 = load i32, ptr %l24, !tbaa !23
  store i32 %t222, ptr %l147, !tbaa !23
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/check:Checker", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  %t228 = getelementptr %"compiler/generic:Program", ptr %t226, i32 0, i32 2
  store ptr %t228, ptr %l150, !tbaa !29
  %t229 = load i64, ptr @G_2ecompiler_2ftypes_2eRoleFn, !tbaa !24
  store i64 %t229, ptr %l151, !tbaa !24
  %t231 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l12)
  store { i64, ptr } %t231, ptr %l153
  br label %bb44
bb44:
  %t232 = load i64, ptr @G_2ecompiler_2ftypes_2eOwnScope, !tbaa !24
  %t234 = insertvalue [1 x i64] undef, i64 %t232, 0
  %t236 = load ptr, ptr @__olang_prog_scope
  %t237 = call ptr @__olang_scope_alloc(ptr %t236, i64 8)
  store [1 x i64] %t234, ptr %t237
  %t238 = insertvalue { i64, ptr } undef, i64 1, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = extractvalue { i64, ptr } %t239, 1
  %t243 = mul i64 %t241, 8
  %t244 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t247 = load ptr, ptr %l150, !tbaa !29
  %t248 = load i64, ptr %l151, !tbaa !24
  %t249 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t251 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %s0, ptr %s0, ptr %t247, i64 %t248, { i64, ptr } %t249, { i64, ptr } %t246)
  store i32 %t251, ptr %l158
  br label %bb45
bb45:
  %t252 = load ptr, ptr %l140, !tbaa !29
  %t253 = load i32, ptr %l146, !tbaa !23
  %t254 = load i32, ptr %l147, !tbaa !23
  %t255 = load i32, ptr %l158, !tbaa !23
  %t256 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t252, i32 %t253, i32 %t254, i32 0, i32 %t255, i64 0)
  store i32 %t256, ptr %l159
  br label %bb46
bb46:
  %t257 = load i32, ptr %l159, !tbaa !23
  store i32 %t257, ptr %l25, !tbaa !23
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load i64, ptr %l1, !tbaa !24
  %t261 = trunc i64 %t259 to i32
  %t263 = load i32, ptr %l2
  store { i64, [2 x i64] } zeroinitializer, ptr %t265
  %t266 = getelementptr { i64, [2 x i64] }, ptr %t265, i32 0, i32 0
  store i64 8, ptr %t266
  %t268 = insertvalue { i32, i32, i64 } undef, i32 %t261, 0
  %t270 = insertvalue { i32, i32, i64 } %t268, i32 %t263, 1
  %t272 = insertvalue { i32, i32, i64 } %t270, i64 %a3, 2
  %t273 = getelementptr { i64, [2 x i64] }, ptr %t265, i32 0, i32 1
  store { i32, i32, i64 } %t272, ptr %t273
  %t274 = load { i64, [2 x i64] }, ptr %t265
  %t275 = load i32, ptr %l25, !tbaa !23
  %t276 = load ptr, ptr %l9, !tbaa !29
  %t278 = getelementptr %"compiler/check:ctSource", ptr %t276, i32 0, i32 4
  %t279 = load i64, ptr %t278, !tbaa !24
  %t280 = load %"compiler/source:Span", ptr %l7
  %t286 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t258, { i64, [2 x i64] } %t274, i32 %t275, i64 %t279, %"compiler/source:Span" %t280)
  store i64 %t286, ptr %l171
  br label %bb47
bb47:
  %t287 = load i64, ptr %l171, !tbaa !24
  store i64 %t287, ptr %l26, !tbaa !24
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t290 = getelementptr %"compiler/check:Checker", ptr %t288, i32 0, i32 15
  %t291 = load i64, ptr %l26, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t290, i64 %t291, i64 1)
  br label %bb48
bb48:
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i64, ptr %l26, !tbaa !24
  %t296 = load ptr, ptr %l9, !tbaa !29
  %t298 = getelementptr %"compiler/check:ctSource", ptr %t296, i32 0, i32 4
  %t299 = load i64, ptr %t298, !tbaa !24
  %t300 = load i32, ptr %l24, !tbaa !23
  %t305 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t294, i64 %t295, i64 %t299, i32 %t300, i32 0)
  store ptr %t305, ptr %l180
  br label %bb49
bb49:
  %t306 = load ptr, ptr %l180, !tbaa !29
  store ptr %t306, ptr %l27, !tbaa !29
  %t307 = load ptr, ptr %l27, !tbaa !29
  store ptr %t307, ptr %l181, !tbaa !29
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load i64, ptr %l1, !tbaa !24
  %t312 = call %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v0, ptr %t308, i64 %t309)
  store %"compiler/generic:Context" %t312, ptr %l184
  br label %bb50
bb50:
  %t313 = load %"compiler/generic:Context", ptr %l184
  %t314 = load ptr, ptr %l181, !tbaa !29
  %t315 = getelementptr %"compiler/check:frame", ptr %t314, i32 0, i32 4
  store %"compiler/generic:Context" %t313, ptr %t315
  %t316 = load ptr, ptr %l27, !tbaa !29
  store ptr %t316, ptr %l185, !tbaa !29
  %t317 = load i32, ptr %l2
  %t319 = trunc i64 0 to i32
  %t320 = icmp eq i32 %t317, %t319
  br i1 %t320, label %bb51, label %bb52
bb51:
  %t322 = load i64, ptr @G_2ecompiler_2fcheck_2eCtReq, !tbaa !24
  store i64 %t322, ptr %l188, !tbaa !24
  br label %bb56
bb52:
  %t324 = load i32, ptr %l2
  %t326 = trunc i64 1 to i32
  %t327 = icmp eq i32 %t324, %t326
  br i1 %t327, label %bb53, label %bb54
bb53:
  %t329 = load i64, ptr @G_2ecompiler_2fcheck_2eCtEns, !tbaa !24
  store i64 %t329, ptr %l192, !tbaa !24
  br label %bb55
bb54:
  %t331 = load i64, ptr @G_2ecompiler_2fcheck_2eCtEntry, !tbaa !24
  store i64 %t331, ptr %l192, !tbaa !24
  br label %bb55
bb55:
  %t333 = load i64, ptr %l192, !tbaa !24
  store i64 %t333, ptr %l188, !tbaa !24
  br label %bb56
bb56:
  %t334 = load i64, ptr %l188, !tbaa !24
  %t335 = load ptr, ptr %l185, !tbaa !29
  %t336 = getelementptr %"compiler/check:frame", ptr %t335, i32 0, i32 49
  store i64 %t334, ptr %t336, !tbaa !24
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t339 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t337)
  store ptr %t339, ptr %l196
  br label %bb57
bb57:
  %t340 = load %"compiler/source:Span", ptr %l7
  %t341 = load ptr, ptr %l196, !tbaa !29
  %t344 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t341, i32 -1, i32 0, %"compiler/source:Span" %t340)
  store i32 %t344, ptr %l199
  br label %bb58
bb58:
  store i64 0, ptr %l28, !tbaa !24
  %t345 = load ptr, ptr %l9, !tbaa !29
  %t347 = getelementptr %"compiler/check:ctSource", ptr %t345, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = icmp eq ptr %t348, null
  %t352 = xor i1 %t350, true
  br i1 %t352, label %bb59, label %bb60
bb59:
  %t354 = load i64, ptr %l28, !tbaa !24
  %t355 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t355, 0
  %t360 = icmp slt i64 %t354, %t357
  br i1 %t360, label %bb61, label %bb62
bb60:
  br label %bb75
bb61:
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l208, !tbaa !29
  %t363 = load ptr, ptr %l9, !tbaa !29
  %t365 = getelementptr %"compiler/check:ctSource", ptr %t363, i32 0, i32 1
  %t366 = load ptr, ptr %t365, !tbaa !29
  %t368 = icmp eq ptr %t366, null
  br i1 %t368, label %bb63, label %bb64
bb62:
  br label %bb74
bb63:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb64:
  br label %bb65
bb65:
  %t370 = load ptr, ptr %l9, !tbaa !29
  %t372 = getelementptr %"compiler/check:ctSource", ptr %t370, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !29
  %t376 = getelementptr %"compiler/ast:Param", ptr %t373, i32 0, i32 1
  %t377 = load i32, ptr %t376, !tbaa !23
  store i32 %t377, ptr %l215, !tbaa !23
  %t378 = load ptr, ptr %l9, !tbaa !29
  %t380 = getelementptr %"compiler/check:ctSource", ptr %t378, i32 0, i32 1
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = icmp eq ptr %t381, null
  br i1 %t383, label %bb66, label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb67:
  br label %bb68
bb68:
  %t385 = load ptr, ptr %l9, !tbaa !29
  %t387 = getelementptr %"compiler/check:ctSource", ptr %t385, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !29
  %t391 = getelementptr %"compiler/ast:Param", ptr %t388, i32 0, i32 0
  %t392 = load %"compiler/source:Span", ptr %t391
  store %"compiler/source:Span" %t392, ptr %l222
  %t394 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l11, i64 0)
  store i32 %t394, ptr %l224
  br label %bb69
bb69:
  %t395 = load ptr, ptr %l9, !tbaa !29
  %t397 = getelementptr %"compiler/check:ctSource", ptr %t395, i32 0, i32 1
  %t398 = load ptr, ptr %t397, !tbaa !29
  %t400 = icmp eq ptr %t398, null
  br i1 %t400, label %bb70, label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_82a7c94587506de8_24388316e0066d9c)
  unreachable
bb71:
  br label %bb72
bb72:
  %t402 = load ptr, ptr %l9, !tbaa !29
  %t404 = getelementptr %"compiler/check:ctSource", ptr %t402, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !29
  %t408 = getelementptr %"compiler/ast:Param", ptr %t405, i32 0, i32 2
  %t409 = load ptr, ptr %t408, !tbaa !29
  %t410 = load ptr, ptr %l208, !tbaa !29
  %t411 = load i32, ptr %l215, !tbaa !23
  %t412 = load %"compiler/source:Span", ptr %l222
  %t413 = load i32, ptr %l224, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t410, i32 %t411, %"compiler/source:Span" %t412, i32 %t413, i64 0, ptr %t409)
  br label %bb73
bb73:
  br label %bb74
bb74:
  store i64 1, ptr %l28, !tbaa !24
  br label %bb75
bb75:
  %t415 = load ptr, ptr %l9, !tbaa !29
  %t417 = getelementptr %"compiler/check:ctSource", ptr %t415, i32 0, i32 2
  %t418 = load { i64, ptr }, ptr %t417, !tbaa !27
  store { i64, ptr } %t418, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t420 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t422 = extractvalue { i64, ptr } %t420, 0
  store i64 %t422, ptr %l31, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s11
  %t424 = load i64, ptr %l30, !tbaa !24
  %t425 = load i64, ptr %l31, !tbaa !24
  %t428 = icmp slt i64 %t424, %t425
  %t430 = xor i1 %t428, true
  br i1 %t430, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s11)
  br label %bb86
bb78:
  br label %bb79
bb79:
  %t432 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t432, ptr %l240, !tbaa !27
  %t433 = load i64, ptr %l30, !tbaa !24
  %t435 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr ptr, ptr %t436, i64 %t433
  %t438 = load ptr, ptr %t437, !tbaa !39
  store ptr %t438, ptr %l32, !tbaa !29
  %t440 = load i64, ptr %l28, !tbaa !24
  %t441 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t446 = icmp slt i64 %t440, %t443
  br i1 %t446, label %bb80, label %bb81
bb80:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l247, !tbaa !29
  %t449 = load ptr, ptr %l32, !tbaa !29
  %t451 = getelementptr %"compiler/ast:Param", ptr %t449, i32 0, i32 1
  %t452 = load i32, ptr %t451, !tbaa !23
  store i32 %t452, ptr %l249, !tbaa !23
  %t453 = load ptr, ptr %l32, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Param", ptr %t453, i32 0, i32 0
  %t456 = load %"compiler/source:Span", ptr %t455
  store %"compiler/source:Span" %t456, ptr %l251
  %t457 = load i64, ptr %l28, !tbaa !24
  %t460 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l11, i64 %t457)
  store i32 %t460, ptr %l254
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t461 = load i64, ptr %l28, !tbaa !24
  %t462 = load ptr, ptr %l32, !tbaa !29
  %t464 = getelementptr %"compiler/ast:Param", ptr %t462, i32 0, i32 2
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t466 = load ptr, ptr %l247, !tbaa !29
  %t467 = load i32, ptr %l249, !tbaa !23
  %t468 = load %"compiler/source:Span", ptr %l251
  %t469 = load i32, ptr %l254, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v0, ptr %t466, i32 %t467, %"compiler/source:Span" %t468, i32 %t469, i64 %t461, ptr %t465)
  br label %bb83
bb83:
  br label %bb84
bb84:
  %t472 = load i64, ptr %l28, !tbaa !24
  %t474 = add i64 %t472, 1
  store i64 %t474, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb85
bb85:
  %t476 = load i64, ptr %l30, !tbaa !24
  %t478 = add i64 %t476, 1
  store i64 %t478, ptr %l30, !tbaa !24
  br label %bb76
bb86:
  store i64 0, ptr %l33, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 0
  store i64 %t482, ptr %l34, !tbaa !24
  store i64 1, ptr %l35, !tbaa !24
  %t484 = load i64, ptr %l34, !tbaa !24
  %t485 = load i64, ptr %l33, !tbaa !24
  %t488 = icmp sgt i64 %t484, %t485
  br i1 %t488, label %bb87, label %bb88
bb87:
  %t490 = load i64, ptr %l35, !tbaa !24
  %t492 = icmp sgt i64 %t490, 0
  br i1 %t492, label %bb89, label %bb90
bb88:
  store i64 0, ptr %l267, !tbaa !24
  br label %bb92
bb89:
  %t494 = load i64, ptr %l34, !tbaa !24
  %t495 = load i64, ptr %l33, !tbaa !24
  %t498 = sub i64 %t494, %t495
  %t499 = load i64, ptr %l35, !tbaa !24
  %t502 = add i64 %t498, %t499
  %t504 = sub i64 %t502, 1
  %t505 = load i64, ptr %l35, !tbaa !24
  %t508 = sdiv i64 %t504, %t505
  store i64 %t508, ptr %l270, !tbaa !24
  br label %bb91
bb90:
  store i64 0, ptr %l270, !tbaa !24
  br label %bb91
bb91:
  %t510 = load i64, ptr %l270, !tbaa !24
  store i64 %t510, ptr %l267, !tbaa !24
  br label %bb92
bb92:
  %t511 = load i64, ptr %l267, !tbaa !24
  store i64 %t511, ptr %l36, !tbaa !24
  store i64 0, ptr %l37, !tbaa !24
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s15
  %t512 = load i64, ptr %l37, !tbaa !24
  %t513 = load i64, ptr %l36, !tbaa !24
  %t516 = icmp slt i64 %t512, %t513
  %t518 = xor i1 %t516, true
  br i1 %t518, label %bb94, label %bb95
bb94:
  call void @__olang_scope_close(ptr %s15)
  br label %bb99
bb95:
  br label %bb96
bb96:
  %t520 = load i64, ptr %l33, !tbaa !24
  %t521 = load i64, ptr %l37, !tbaa !24
  %t522 = load i64, ptr %l35, !tbaa !24
  %t525 = mul i64 %t521, %t522
  %t528 = add i64 %t520, %t525
  store i64 %t528, ptr %l38, !tbaa !24
  %t530 = load ptr, ptr %l0, !tbaa !29
  store { i64, ptr } %a6, ptr %l289, !tbaa !27
  %t532 = load i64, ptr %l38, !tbaa !24
  %t534 = getelementptr { i64, ptr }, ptr %l289, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !27
  %t536 = getelementptr i32, ptr %t535, i64 %t532
  %t537 = load i32, ptr %t536, !tbaa !33
  %t538 = load %"compiler/source:Span", ptr %l7
  %t539 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t539, ptr %l293, !tbaa !27
  %t540 = load i64, ptr %l38, !tbaa !24
  %t542 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !27
  %t544 = getelementptr i32, ptr %t543, i64 %t540
  %t545 = load i32, ptr %t544, !tbaa !33
  %t546 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t548 = extractvalue { i64, ptr } %t546, 0
  %t549 = load i64, ptr %l38, !tbaa !24
  %t552 = add i64 %t548, %t549
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %s15, ptr %t530, i32 %t537, %"compiler/source:Span" %t538, i32 %t545, i64 %t552, ptr null)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s15)
  br label %bb98
bb98:
  %t558 = load i64, ptr %l37, !tbaa !24
  %t560 = add i64 %t558, 1
  store i64 %t560, ptr %l37, !tbaa !24
  br label %bb93
bb99:
  %t562 = load ptr, ptr %l0, !tbaa !29
  %t564 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t562)
  store ptr %t564, ptr %l303
  br label %bb100
bb100:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t567 = getelementptr %"compiler/check:Checker", ptr %t565, i32 0, i32 1
  %t568 = load ptr, ptr %t567, !tbaa !29
  %t569 = load i32, ptr %l25, !tbaa !23
  %t572 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t568, i32 %t569)
  store { i64, ptr } %t572, ptr %l307
  br label %bb101
bb101:
  %t573 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t574 = extractvalue { i64, ptr } %t573, 0
  %t575 = extractvalue { i64, ptr } %t573, 1
  %t576 = mul i64 %t574, 8
  %t577 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t576)
  call void @llvm.memcpy.p0.p0.i64(ptr %t577, ptr %t575, i64 %t576, i1 false)
  %t578 = insertvalue { i64, ptr } undef, i64 %t574, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t577, 1
  %t580 = load ptr, ptr %l303, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t580, { i64, ptr } %t579)
  br label %bb102
bb102:
  %t582 = load ptr, ptr %l27, !tbaa !29
  store ptr %t582, ptr %l309, !tbaa !29
  %t583 = load ptr, ptr %l0, !tbaa !29
  %t585 = getelementptr %"compiler/check:Checker", ptr %t583, i32 0, i32 32
  %t587 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t585)
  store i64 %t587, ptr %l312
  br label %bb103
bb103:
  %t588 = load i64, ptr %l312, !tbaa !24
  %t589 = load ptr, ptr %l309, !tbaa !29
  %t590 = getelementptr %"compiler/check:frame", ptr %t589, i32 0, i32 52
  store i64 %t588, ptr %t590, !tbaa !24
  %t591 = load i64, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  store i64 %t591, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectItems(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 32
  store ptr %t8, ptr %l6, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t9)
  store %"compiler/source:Span" %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v1, ptr %t13)
  store %"compiler/source:Span" %t15, ptr %l11
  br label %bb3
bb3:
  %t16 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l11
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t17, %"compiler/source:Span" %t18, i32 %t16, i64 1)
  store ptr %t20, ptr %l13
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l13, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 6, ptr %t23
  %t24 = load %"compiler/source:Span", ptr %l8
  %t25 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t24, 0
  %t27 = insertvalue { %"compiler/source:Span", ptr } %t25, ptr %t21, 1
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t27, ptr %t28
  %t29 = load { i64, [3 x i64] }, ptr %t22
  %t31 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t29, ptr %t31
  %t32 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t32, ptr %t31)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclNote(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 9
  %t4 = load { i64, [3 x i64] }, ptr %t3
  %t6 = extractvalue { i64, [3 x i64] } %t4, 0
  %t7 = icmp eq i64 %t6, 0
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 4
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l9, !tbaa !29
  store i64 %a1, ptr %l10, !tbaa !24
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 9
  %t25 = load { i64, [3 x i64] }, ptr %t24
  store { i64, [3 x i64] } %t25, ptr %l12
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %s1)
  store %"compiler/msgs:Msg" %t26, ptr %l13
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t27 = load ptr, ptr %l9, !tbaa !29
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = load { i64, [3 x i64] }, ptr %l12
  %t30 = load %"compiler/msgs:Msg", ptr %l13
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s1, ptr %t27, i64 %t28, { i64, [3 x i64] } %t29, %"compiler/msgs:Msg" %t30)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i1
  %l13 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l38 = alloca i1
  %l48 = alloca i64
  %l51 = alloca ptr
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i32
  %l61 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TypeDecl", ptr %t5, i32 0, i32 3
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  store i1 %t10, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t12 = load i1, ptr %l9, !tbaa !21
  br i1 %t12, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t15 = getelementptr %"compiler/ast:TypeDecl", ptr %t13, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = icmp sgt i64 %t18, 0
  store i1 %t20, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  br label %ret
bb8:
  br label %bb9
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t25 = getelementptr %"compiler/ast:TypeDecl", ptr %t23, i32 0, i32 3
  %t26 = load ptr, ptr %t25, !tbaa !29
  store ptr %t26, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  store ptr %t28, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t29 = load ptr, ptr %l20, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l20, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 0
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb11
bb11:
  %t36 = load i1, ptr %l21, !tbaa !21
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t37 = load ptr, ptr %l3, !tbaa !29
  %t39 = getelementptr { i64, [6 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { ptr }, ptr %t39, i32 0, i32 0
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t43 = load ptr, ptr %l4, !tbaa !29
  %t45 = getelementptr %"compiler/ast:StructBody", ptr %t43, i32 0, i32 5
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb15, label %bb16
bb15:
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb31
bb18:
  %t52 = load ptr, ptr %l3, !tbaa !29
  store ptr %t52, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb19, label %bb20
bb19:
  %t56 = load ptr, ptr %l30, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 3
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t60 = load i1, ptr %l31, !tbaa !21
  br i1 %t60, label %bb21, label %bb22
bb21:
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t63 = getelementptr { i64, [6 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { ptr, ptr }, ptr %t63, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  store ptr %t65, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb30
bb23:
  %t67 = load ptr, ptr %l5, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l38, !tbaa !21
  br label %bb26
bb25:
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t73 = getelementptr %"compiler/ast:Func", ptr %t71, i32 0, i32 5
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 0
  %t78 = icmp sgt i64 %t76, 0
  store i1 %t78, ptr %l38, !tbaa !21
  br label %bb26
bb26:
  %t80 = load i1, ptr %l38, !tbaa !21
  br i1 %t80, label %bb27, label %bb28
bb27:
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb31
bb30:
  br label %ret
bb31:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TypeDecl", ptr %t86, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t84, i64 %t85, i32 %t89)
  store i64 %t93, ptr %l48
  br label %bb32
bb32:
  %t94 = load i64, ptr %l48, !tbaa !24
  store i64 %t94, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l6, !tbaa !24
  %t97 = icmp slt i64 %t95, 0
  br i1 %t97, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l51, !tbaa !29
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !29
  %t105 = getelementptr %"compiler/generic:Program", ptr %t103, i32 0, i32 2
  store ptr %t105, ptr %l54, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t110 = load i64, ptr %l1, !tbaa !24
  %t111 = load i64, ptr %l6, !tbaa !24
  %t115 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t109, i64 %t110, i64 %t111)
  store i32 %t115, ptr %l59
  br label %bb36
bb36:
  %t116 = load ptr, ptr %l54, !tbaa !29
  %t117 = load i32, ptr %l59, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %t116, i32 %t117, i32 0)
  store i32 %t118, ptr %l60
  br label %bb37
bb37:
  %t119 = load ptr, ptr %l51, !tbaa !29
  %t120 = load i32, ptr %l60, !tbaa !23
  %t121 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t119, i32 %t120)
  store i64 %t121, ptr %l61
  br label %bb38
bb38:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresName(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"compiler/names:Entry"
  %l14 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/names:Resolver", ptr %t7, i32 0, i32 1
  %t13 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v0, ptr %t9, i64 %a1)
  store ptr %t13, ptr %l14
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t16 = getelementptr %"compiler/names:Table", ptr %t14, i32 0, i32 0
  store ptr %t16, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, { i64, ptr } } %t22, 1
  %t24 = extractvalue { i32, { i64, ptr } } %t22, 0
  store i32 %t24, ptr %l21
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb4, label %ok.26
ok.26:
  store { i64, ptr } %t23, ptr %l20
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  br label %bb8
bb4:
  %t28 = load i32, ptr %l21, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_de9000bcffb5dadf_73d3889d184bf993)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb8:
  %t33 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t33, ptr %l5, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  store i64 %t36, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load i64, ptr %l7, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp slt i64 %t38, %t39
  %t44 = xor i1 %t42, true
  br i1 %t44, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb11:
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t46, ptr %l30, !tbaa !27
  %t47 = load i64, ptr %l7, !tbaa !24
  %t49 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/names:Entry", ptr %t50, i64 %t47
  %t52 = load %"compiler/names:Entry", ptr %t51
  store %"compiler/names:Entry" %t52, ptr %l8
  %t54 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t59 = icmp eq i32 %t55, %a2
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = add i64 %t62, 1
  store i64 %t64, ptr %l7, !tbaa !24
  br label %bb9
bb17:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t67 = load i64, ptr %l6, !tbaa !24
  %t70 = add i64 %t66, %t67
  store i64 %t70, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  br label %bb2
bb19:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l23 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca i1
  %l42 = alloca ptr
  %l43 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l85 = alloca i1
  %l86 = alloca ptr
  %l87 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca i1
  %l102 = alloca ptr
  %l103 = alloca i1
  %l113 = alloca i1
  %l114 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l132 = alloca i1
  %l133 = alloca i1
  %l137 = alloca i1
  %l138 = alloca i1
  %l142 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l161 = alloca ptr
  %l162 = alloca i1
  %l172 = alloca i1
  %l173 = alloca i1
  %l176 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i1
  %l188 = alloca i1
  %l189 = alloca i1
  %l192 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l206 = alloca i1
  %l207 = alloca i1
  %l210 = alloca i1
  %l211 = alloca i1
  %l214 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i1
  %l221 = alloca ptr
  %l222 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca i1
  %l241 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca i1
  %l253 = alloca i1
  %l254 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l24, !tbaa !29
  store i1 false, ptr %l25, !tbaa !21
  %t7 = load ptr, ptr %l24, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l24, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l25, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t16 = load ptr, ptr %l28, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb8, label %bb9
bb8:
  %t19 = load ptr, ptr %l28, !tbaa !29
  %t20 = load i64, ptr %t19
  %t22 = icmp eq i64 %t20, 1
  store i1 %t22, ptr %l29, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l29, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  br label %bb16
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t25 = load ptr, ptr %l32, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t28 = load ptr, ptr %l32, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 26
  store i1 %t31, ptr %l33, !tbaa !21
  br label %bb13
bb13:
  %t32 = load i1, ptr %l33, !tbaa !21
  br i1 %t32, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb163
bb17:
  %t33 = load ptr, ptr %l1, !tbaa !29
  store ptr %t33, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t34 = load ptr, ptr %l36, !tbaa !29
  %t35 = icmp ne ptr %t34, null
  br i1 %t35, label %bb18, label %bb19
bb18:
  %t37 = load ptr, ptr %l36, !tbaa !29
  %t38 = load i64, ptr %t37
  %t40 = icmp eq i64 %t38, 2
  store i1 %t40, ptr %l37, !tbaa !21
  br label %bb19
bb19:
  %t41 = load i1, ptr %l37, !tbaa !21
  br i1 %t41, label %bb20, label %bb21
bb20:
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = getelementptr { i64, [5 x i64] }, ptr %t42, i32 0, i32 1
  %t45 = getelementptr { %"compiler/source:Span", ptr }, ptr %t44, i32 0, i32 1
  %t46 = load ptr, ptr %t45
  store ptr %t46, ptr %l2, !tbaa !29
  br label %bb34
bb21:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l42, !tbaa !29
  store i1 false, ptr %l43, !tbaa !21
  %t49 = load ptr, ptr %l42, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb22, label %bb23
bb22:
  %t52 = load ptr, ptr %l42, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 3
  store i1 %t55, ptr %l43, !tbaa !21
  br label %bb23
bb23:
  %t56 = load i1, ptr %l43, !tbaa !21
  br i1 %t56, label %bb24, label %bb25
bb24:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [5 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l2, !tbaa !29
  br label %bb34
bb25:
  %t63 = load ptr, ptr %l1, !tbaa !29
  store ptr %t63, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t64 = load ptr, ptr %l48, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb26, label %bb27
bb26:
  %t67 = load ptr, ptr %l48, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 4
  store i1 %t70, ptr %l49, !tbaa !21
  br label %bb27
bb27:
  %t71 = load i1, ptr %l49, !tbaa !21
  br i1 %t71, label %bb28, label %bb29
bb28:
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t74, i32 0, i32 2
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l2, !tbaa !29
  br label %bb34
bb29:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t79 = load ptr, ptr %l54, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb30, label %bb31
bb30:
  %t82 = load ptr, ptr %l54, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 15
  store i1 %t85, ptr %l55, !tbaa !21
  br label %bb31
bb31:
  %t86 = load i1, ptr %l55, !tbaa !21
  br i1 %t86, label %bb32, label %bb33
bb32:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t89, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l2, !tbaa !29
  br label %bb34
bb33:
  br label %bb36
bb34:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t93, ptr %t94)
  store i1 %t98, ptr %l63
  br label %bb35
bb35:
  %t99 = load i1, ptr %l63, !tbaa !21
  store i1 %t99, ptr %l23, !tbaa !21
  br label %bb163
bb36:
  %t100 = load ptr, ptr %l1, !tbaa !29
  store ptr %t100, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t101 = load ptr, ptr %l64, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb37, label %bb38
bb37:
  %t104 = load ptr, ptr %l64, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 9
  store i1 %t107, ptr %l65, !tbaa !21
  br label %bb38
bb38:
  %t108 = load i1, ptr %l65, !tbaa !21
  br i1 %t108, label %bb39, label %bb40
bb39:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr { i64, [5 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l3, !tbaa !29
  br label %bb49
bb40:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t116 = load ptr, ptr %l70, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb41, label %bb42
bb41:
  %t119 = load ptr, ptr %l70, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 11
  store i1 %t122, ptr %l71, !tbaa !21
  br label %bb42
bb42:
  %t123 = load i1, ptr %l71, !tbaa !21
  br i1 %t123, label %bb43, label %bb44
bb43:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l3, !tbaa !29
  br label %bb49
bb44:
  %t130 = load ptr, ptr %l1, !tbaa !29
  store ptr %t130, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t131 = load ptr, ptr %l76, !tbaa !29
  %t132 = icmp ne ptr %t131, null
  br i1 %t132, label %bb45, label %bb46
bb45:
  %t134 = load ptr, ptr %l76, !tbaa !29
  %t135 = load i64, ptr %t134
  %t137 = icmp eq i64 %t135, 14
  store i1 %t137, ptr %l77, !tbaa !21
  br label %bb46
bb46:
  %t138 = load i1, ptr %l77, !tbaa !21
  br i1 %t138, label %bb47, label %bb48
bb47:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr { i64, [5 x i64] }, ptr %t139, i32 0, i32 1
  %t142 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t141, i32 0, i32 1
  %t143 = load ptr, ptr %t142
  store ptr %t143, ptr %l3, !tbaa !29
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t146 = load ptr, ptr %l3, !tbaa !29
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t145, ptr %t146)
  store i1 %t150, ptr %l85
  br label %bb50
bb50:
  %t151 = load i1, ptr %l85, !tbaa !21
  store i1 %t151, ptr %l23, !tbaa !21
  br label %bb163
bb51:
  %t152 = load ptr, ptr %l1, !tbaa !29
  store ptr %t152, ptr %l86, !tbaa !29
  store i1 false, ptr %l87, !tbaa !21
  %t153 = load ptr, ptr %l86, !tbaa !29
  %t154 = icmp ne ptr %t153, null
  br i1 %t154, label %bb52, label %bb53
bb52:
  %t156 = load ptr, ptr %l86, !tbaa !29
  %t157 = load i64, ptr %t156
  %t159 = icmp eq i64 %t157, 5
  store i1 %t159, ptr %l87, !tbaa !21
  br label %bb53
bb53:
  %t160 = load i1, ptr %l87, !tbaa !21
  br i1 %t160, label %bb54, label %bb55
bb54:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  %t164 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t163, i32 0, i32 2
  %t165 = load ptr, ptr %t164
  store ptr %t165, ptr %l4, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t169 = getelementptr { i64, [5 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t169, i32 0, i32 3
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l5, !tbaa !29
  br label %bb64
bb55:
  %t173 = load ptr, ptr %l1, !tbaa !29
  store ptr %t173, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t174 = load ptr, ptr %l94, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb56, label %bb57
bb56:
  %t177 = load ptr, ptr %l94, !tbaa !29
  %t178 = load i64, ptr %t177
  %t180 = icmp eq i64 %t178, 6
  store i1 %t180, ptr %l95, !tbaa !21
  br label %bb57
bb57:
  %t181 = load i1, ptr %l95, !tbaa !21
  br i1 %t181, label %bb58, label %bb59
bb58:
  %t182 = load ptr, ptr %l1, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t184, i32 0, i32 1
  %t186 = load ptr, ptr %t185
  store ptr %t186, ptr %l4, !tbaa !29
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t190, i32 0, i32 2
  %t192 = load ptr, ptr %t191
  store ptr %t192, ptr %l5, !tbaa !29
  br label %bb64
bb59:
  %t194 = load ptr, ptr %l1, !tbaa !29
  store ptr %t194, ptr %l102, !tbaa !29
  store i1 false, ptr %l103, !tbaa !21
  %t195 = load ptr, ptr %l102, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb60, label %bb61
bb60:
  %t198 = load ptr, ptr %l102, !tbaa !29
  %t199 = load i64, ptr %t198
  %t201 = icmp eq i64 %t199, 10
  store i1 %t201, ptr %l103, !tbaa !21
  br label %bb61
bb61:
  %t202 = load i1, ptr %l103, !tbaa !21
  br i1 %t202, label %bb62, label %bb63
bb62:
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr { i64, [5 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l4, !tbaa !29
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l5, !tbaa !29
  br label %bb64
bb63:
  br label %bb70
bb64:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l4, !tbaa !29
  %t220 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t215, ptr %t216)
  store i1 %t220, ptr %l113
  br label %bb65
bb65:
  %t221 = load i1, ptr %l113, !tbaa !21
  br i1 %t221, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l114, !tbaa !21
  br label %bb69
bb67:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l5, !tbaa !29
  %t227 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t222, ptr %t223)
  store i1 %t227, ptr %l118
  br label %bb68
bb68:
  %t228 = load i1, ptr %l118, !tbaa !21
  store i1 %t228, ptr %l114, !tbaa !21
  br label %bb69
bb69:
  %t229 = load i1, ptr %l114, !tbaa !21
  store i1 %t229, ptr %l23, !tbaa !21
  br label %bb163
bb70:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t231 = load ptr, ptr %l119, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb71, label %bb72
bb71:
  %t234 = load ptr, ptr %l119, !tbaa !29
  %t235 = load i64, ptr %t234
  %t237 = icmp eq i64 %t235, 8
  store i1 %t237, ptr %l120, !tbaa !21
  br label %bb72
bb72:
  %t238 = load i1, ptr %l120, !tbaa !21
  br i1 %t238, label %bb73, label %bb74
bb73:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [5 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t241, i32 0, i32 1
  %t243 = load ptr, ptr %t242
  store ptr %t243, ptr %l6, !tbaa !29
  %t245 = load ptr, ptr %l1, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t247, i32 0, i32 2
  %t249 = load ptr, ptr %t248
  store ptr %t249, ptr %l7, !tbaa !29
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t253, i32 0, i32 3
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l8, !tbaa !29
  br label %bb75
bb74:
  br label %bb85
bb75:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l6, !tbaa !29
  %t262 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t257, ptr %t258)
  store i1 %t262, ptr %l132
  br label %bb76
bb76:
  %t263 = load i1, ptr %l132, !tbaa !21
  br i1 %t263, label %bb77, label %bb78
bb77:
  store i1 true, ptr %l133, !tbaa !21
  br label %bb80
bb78:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load ptr, ptr %l7, !tbaa !29
  %t269 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t264, ptr %t265)
  store i1 %t269, ptr %l137
  br label %bb79
bb79:
  %t270 = load i1, ptr %l137, !tbaa !21
  store i1 %t270, ptr %l133, !tbaa !21
  br label %bb80
bb80:
  %t271 = load i1, ptr %l133, !tbaa !21
  br i1 %t271, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb84
bb82:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load ptr, ptr %l8, !tbaa !29
  %t277 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t272, ptr %t273)
  store i1 %t277, ptr %l142
  br label %bb83
bb83:
  %t278 = load i1, ptr %l142, !tbaa !21
  store i1 %t278, ptr %l138, !tbaa !21
  br label %bb84
bb84:
  %t279 = load i1, ptr %l138, !tbaa !21
  store i1 %t279, ptr %l23, !tbaa !21
  br label %bb163
bb85:
  %t280 = load ptr, ptr %l1, !tbaa !29
  store ptr %t280, ptr %l143, !tbaa !29
  store i1 false, ptr %l144, !tbaa !21
  %t281 = load ptr, ptr %l143, !tbaa !29
  %t282 = icmp ne ptr %t281, null
  br i1 %t282, label %bb86, label %bb87
bb86:
  %t284 = load ptr, ptr %l143, !tbaa !29
  %t285 = load i64, ptr %t284
  %t287 = icmp eq i64 %t285, 7
  store i1 %t287, ptr %l144, !tbaa !21
  br label %bb87
bb87:
  %t288 = load i1, ptr %l144, !tbaa !21
  br i1 %t288, label %bb88, label %bb89
bb88:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr { i64, [5 x i64] }, ptr %t289, i32 0, i32 1
  %t292 = getelementptr { %"compiler/source:Span", ptr }, ptr %t291, i32 0, i32 1
  %t293 = load ptr, ptr %t292
  store ptr %t293, ptr %l9, !tbaa !29
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t296 = load ptr, ptr %l9, !tbaa !29
  %t298 = getelementptr %"compiler/ast:Chain", ptr %t296, i32 0, i32 1
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !27
  %t302 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t295, { i64, ptr } %t299)
  store i1 %t302, ptr %l152
  br label %bb91
bb91:
  %t303 = load i1, ptr %l152, !tbaa !21
  store i1 %t303, ptr %l23, !tbaa !21
  br label %bb163
bb92:
  %t304 = load ptr, ptr %l1, !tbaa !29
  store ptr %t304, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t305 = load ptr, ptr %l153, !tbaa !29
  %t306 = icmp ne ptr %t305, null
  br i1 %t306, label %bb93, label %bb94
bb93:
  %t308 = load ptr, ptr %l153, !tbaa !29
  %t309 = load i64, ptr %t308
  %t311 = icmp eq i64 %t309, 12
  store i1 %t311, ptr %l154, !tbaa !21
  br label %bb94
bb94:
  %t312 = load i1, ptr %l154, !tbaa !21
  br i1 %t312, label %bb95, label %bb96
bb95:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr { i64, [5 x i64] }, ptr %t313, i32 0, i32 1
  %t316 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t315, i32 0, i32 1
  %t317 = load ptr, ptr %t316
  store ptr %t317, ptr %l10, !tbaa !29
  %t319 = load ptr, ptr %l1, !tbaa !29
  %t321 = getelementptr { i64, [5 x i64] }, ptr %t319, i32 0, i32 1
  %t322 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t321, i32 0, i32 2
  %t323 = load { i64, ptr }, ptr %t322
  store { i64, ptr } %t323, ptr %l11, !tbaa !27
  br label %bb101
bb96:
  %t325 = load ptr, ptr %l1, !tbaa !29
  store ptr %t325, ptr %l161, !tbaa !29
  store i1 false, ptr %l162, !tbaa !21
  %t326 = load ptr, ptr %l161, !tbaa !29
  %t327 = icmp ne ptr %t326, null
  br i1 %t327, label %bb97, label %bb98
bb97:
  %t329 = load ptr, ptr %l161, !tbaa !29
  %t330 = load i64, ptr %t329
  %t332 = icmp eq i64 %t330, 13
  store i1 %t332, ptr %l162, !tbaa !21
  br label %bb98
bb98:
  %t333 = load i1, ptr %l162, !tbaa !21
  br i1 %t333, label %bb99, label %bb100
bb99:
  %t334 = load ptr, ptr %l1, !tbaa !29
  %t336 = getelementptr { i64, [5 x i64] }, ptr %t334, i32 0, i32 1
  %t337 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t336, i32 0, i32 1
  %t338 = load ptr, ptr %t337
  store ptr %t338, ptr %l10, !tbaa !29
  %t340 = load ptr, ptr %l1, !tbaa !29
  %t342 = getelementptr { i64, [5 x i64] }, ptr %t340, i32 0, i32 1
  %t343 = getelementptr { %"compiler/source:Span", ptr, i32, { i64, ptr } }, ptr %t342, i32 0, i32 3
  %t344 = load { i64, ptr }, ptr %t343
  store { i64, ptr } %t344, ptr %l11, !tbaa !27
  br label %bb101
bb100:
  br label %bb107
bb101:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l10, !tbaa !29
  %t351 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t346, ptr %t347)
  store i1 %t351, ptr %l172
  br label %bb102
bb102:
  %t352 = load i1, ptr %l172, !tbaa !21
  br i1 %t352, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb106
bb104:
  %t353 = load ptr, ptr %l0, !tbaa !29
  %t354 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t357 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t353, { i64, ptr } %t354)
  store i1 %t357, ptr %l176
  br label %bb105
bb105:
  %t358 = load i1, ptr %l176, !tbaa !21
  store i1 %t358, ptr %l173, !tbaa !21
  br label %bb106
bb106:
  %t359 = load i1, ptr %l173, !tbaa !21
  store i1 %t359, ptr %l23, !tbaa !21
  br label %bb163
bb107:
  %t360 = load ptr, ptr %l1, !tbaa !29
  store ptr %t360, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t361 = load ptr, ptr %l177, !tbaa !29
  %t362 = icmp ne ptr %t361, null
  br i1 %t362, label %bb108, label %bb109
bb108:
  %t364 = load ptr, ptr %l177, !tbaa !29
  %t365 = load i64, ptr %t364
  %t367 = icmp eq i64 %t365, 16
  store i1 %t367, ptr %l178, !tbaa !21
  br label %bb109
bb109:
  %t368 = load i1, ptr %l178, !tbaa !21
  br i1 %t368, label %bb110, label %bb111
bb110:
  %t369 = load ptr, ptr %l1, !tbaa !29
  %t371 = getelementptr { i64, [5 x i64] }, ptr %t369, i32 0, i32 1
  %t372 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t371, i32 0, i32 1
  %t373 = load ptr, ptr %t372
  store ptr %t373, ptr %l12, !tbaa !29
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr { i64, [5 x i64] }, ptr %t375, i32 0, i32 1
  %t378 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t377, i32 0, i32 2
  %t379 = load { i64, ptr }, ptr %t378
  store { i64, ptr } %t379, ptr %l13, !tbaa !27
  br label %bb112
bb111:
  br label %bb118
bb112:
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t382 = load ptr, ptr %l12, !tbaa !29
  %t386 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t381, ptr %t382)
  store i1 %t386, ptr %l188
  br label %bb113
bb113:
  %t387 = load i1, ptr %l188, !tbaa !21
  br i1 %t387, label %bb114, label %bb115
bb114:
  store i1 true, ptr %l189, !tbaa !21
  br label %bb117
bb115:
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t389 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t392 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t388, { i64, ptr } %t389)
  store i1 %t392, ptr %l192
  br label %bb116
bb116:
  %t393 = load i1, ptr %l192, !tbaa !21
  store i1 %t393, ptr %l189, !tbaa !21
  br label %bb117
bb117:
  %t394 = load i1, ptr %l189, !tbaa !21
  store i1 %t394, ptr %l23, !tbaa !21
  br label %bb163
bb118:
  %t395 = load ptr, ptr %l1, !tbaa !29
  store ptr %t395, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t396 = load ptr, ptr %l193, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb119, label %bb120
bb119:
  %t399 = load ptr, ptr %l193, !tbaa !29
  %t400 = load i64, ptr %t399
  %t402 = icmp eq i64 %t400, 17
  store i1 %t402, ptr %l194, !tbaa !21
  br label %bb120
bb120:
  %t403 = load i1, ptr %l194, !tbaa !21
  br i1 %t403, label %bb121, label %bb122
bb121:
  %t404 = load ptr, ptr %l1, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t406, i32 0, i32 1
  %t408 = load ptr, ptr %t407
  store ptr %t408, ptr %l14, !tbaa !29
  %t410 = load ptr, ptr %l1, !tbaa !29
  %t412 = getelementptr { i64, [5 x i64] }, ptr %t410, i32 0, i32 1
  %t413 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t412, i32 0, i32 2
  %t414 = load ptr, ptr %t413
  store ptr %t414, ptr %l15, !tbaa !29
  %t416 = load ptr, ptr %l1, !tbaa !29
  %t418 = getelementptr { i64, [5 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t418, i32 0, i32 3
  %t420 = load ptr, ptr %t419
  store ptr %t420, ptr %l16, !tbaa !29
  br label %bb123
bb122:
  br label %bb133
bb123:
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t423 = load ptr, ptr %l14, !tbaa !29
  %t427 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t422, ptr %t423)
  store i1 %t427, ptr %l206
  br label %bb124
bb124:
  %t428 = load i1, ptr %l206, !tbaa !21
  br i1 %t428, label %bb125, label %bb126
bb125:
  store i1 true, ptr %l207, !tbaa !21
  br label %bb128
bb126:
  %t429 = load ptr, ptr %l0, !tbaa !29
  %t430 = load ptr, ptr %l15, !tbaa !29
  %t433 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t429, ptr %t430)
  store i1 %t433, ptr %l210
  br label %bb127
bb127:
  %t434 = load i1, ptr %l210, !tbaa !21
  store i1 %t434, ptr %l207, !tbaa !21
  br label %bb128
bb128:
  %t435 = load i1, ptr %l207, !tbaa !21
  br i1 %t435, label %bb129, label %bb130
bb129:
  store i1 true, ptr %l211, !tbaa !21
  br label %bb132
bb130:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l16, !tbaa !29
  %t440 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t436, ptr %t437)
  store i1 %t440, ptr %l214
  br label %bb131
bb131:
  %t441 = load i1, ptr %l214, !tbaa !21
  store i1 %t441, ptr %l211, !tbaa !21
  br label %bb132
bb132:
  %t442 = load i1, ptr %l211, !tbaa !21
  store i1 %t442, ptr %l23, !tbaa !21
  br label %bb163
bb133:
  %t443 = load ptr, ptr %l1, !tbaa !29
  store ptr %t443, ptr %l215, !tbaa !29
  store i1 false, ptr %l216, !tbaa !21
  %t444 = load ptr, ptr %l215, !tbaa !29
  %t445 = icmp ne ptr %t444, null
  br i1 %t445, label %bb134, label %bb135
bb134:
  %t447 = load ptr, ptr %l215, !tbaa !29
  %t448 = load i64, ptr %t447
  %t450 = icmp eq i64 %t448, 18
  store i1 %t450, ptr %l216, !tbaa !21
  br label %bb135
bb135:
  %t451 = load i1, ptr %l216, !tbaa !21
  br i1 %t451, label %bb136, label %bb137
bb136:
  %t452 = load ptr, ptr %l1, !tbaa !29
  %t454 = getelementptr { i64, [5 x i64] }, ptr %t452, i32 0, i32 1
  %t455 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t454, i32 0, i32 2
  %t456 = load { i64, ptr }, ptr %t455
  store { i64, ptr } %t456, ptr %l17, !tbaa !27
  br label %bb150
bb137:
  %t458 = load ptr, ptr %l1, !tbaa !29
  store ptr %t458, ptr %l221, !tbaa !29
  store i1 false, ptr %l222, !tbaa !21
  %t459 = load ptr, ptr %l221, !tbaa !29
  %t460 = icmp ne ptr %t459, null
  br i1 %t460, label %bb138, label %bb139
bb138:
  %t462 = load ptr, ptr %l221, !tbaa !29
  %t463 = load i64, ptr %t462
  %t465 = icmp eq i64 %t463, 19
  store i1 %t465, ptr %l222, !tbaa !21
  br label %bb139
bb139:
  %t466 = load i1, ptr %l222, !tbaa !21
  br i1 %t466, label %bb140, label %bb141
bb140:
  %t467 = load ptr, ptr %l1, !tbaa !29
  %t469 = getelementptr { i64, [5 x i64] }, ptr %t467, i32 0, i32 1
  %t470 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t469, i32 0, i32 1
  %t471 = load { i64, ptr }, ptr %t470
  store { i64, ptr } %t471, ptr %l17, !tbaa !27
  br label %bb150
bb141:
  %t473 = load ptr, ptr %l1, !tbaa !29
  store ptr %t473, ptr %l227, !tbaa !29
  store i1 false, ptr %l228, !tbaa !21
  %t474 = load ptr, ptr %l227, !tbaa !29
  %t475 = icmp ne ptr %t474, null
  br i1 %t475, label %bb142, label %bb143
bb142:
  %t477 = load ptr, ptr %l227, !tbaa !29
  %t478 = load i64, ptr %t477
  %t480 = icmp eq i64 %t478, 21
  store i1 %t480, ptr %l228, !tbaa !21
  br label %bb143
bb143:
  %t481 = load i1, ptr %l228, !tbaa !21
  br i1 %t481, label %bb144, label %bb145
bb144:
  %t482 = load ptr, ptr %l1, !tbaa !29
  %t484 = getelementptr { i64, [5 x i64] }, ptr %t482, i32 0, i32 1
  %t485 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t484, i32 0, i32 1
  %t486 = load { i64, ptr }, ptr %t485
  store { i64, ptr } %t486, ptr %l17, !tbaa !27
  br label %bb150
bb145:
  %t488 = load ptr, ptr %l1, !tbaa !29
  store ptr %t488, ptr %l233, !tbaa !29
  store i1 false, ptr %l234, !tbaa !21
  %t489 = load ptr, ptr %l233, !tbaa !29
  %t490 = icmp ne ptr %t489, null
  br i1 %t490, label %bb146, label %bb147
bb146:
  %t492 = load ptr, ptr %l233, !tbaa !29
  %t493 = load i64, ptr %t492
  %t495 = icmp eq i64 %t493, 25
  store i1 %t495, ptr %l234, !tbaa !21
  br label %bb147
bb147:
  %t496 = load i1, ptr %l234, !tbaa !21
  br i1 %t496, label %bb148, label %bb149
bb148:
  %t497 = load ptr, ptr %l1, !tbaa !29
  %t499 = getelementptr { i64, [5 x i64] }, ptr %t497, i32 0, i32 1
  %t500 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t499, i32 0, i32 1
  %t501 = load { i64, ptr }, ptr %t500
  store { i64, ptr } %t501, ptr %l17, !tbaa !27
  br label %bb150
bb149:
  br label %bb152
bb150:
  %t503 = load ptr, ptr %l0, !tbaa !29
  %t504 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t507 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %t503, { i64, ptr } %t504)
  store i1 %t507, ptr %l241
  br label %bb151
bb151:
  %t508 = load i1, ptr %l241, !tbaa !21
  store i1 %t508, ptr %l23, !tbaa !21
  br label %bb163
bb152:
  %t509 = load ptr, ptr %l1, !tbaa !29
  store ptr %t509, ptr %l242, !tbaa !29
  store i1 false, ptr %l243, !tbaa !21
  %t510 = load ptr, ptr %l242, !tbaa !29
  %t511 = icmp ne ptr %t510, null
  br i1 %t511, label %bb153, label %bb154
bb153:
  %t513 = load ptr, ptr %l242, !tbaa !29
  %t514 = load i64, ptr %t513
  %t516 = icmp eq i64 %t514, 22
  store i1 %t516, ptr %l243, !tbaa !21
  br label %bb154
bb154:
  %t517 = load i1, ptr %l243, !tbaa !21
  br i1 %t517, label %bb155, label %bb156
bb155:
  %t518 = load ptr, ptr %l1, !tbaa !29
  %t520 = getelementptr { i64, [5 x i64] }, ptr %t518, i32 0, i32 1
  %t521 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t520, i32 0, i32 1
  %t522 = load ptr, ptr %t521
  store ptr %t522, ptr %l18, !tbaa !29
  %t524 = load ptr, ptr %l1, !tbaa !29
  %t526 = getelementptr { i64, [5 x i64] }, ptr %t524, i32 0, i32 1
  %t527 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t526, i32 0, i32 2
  %t528 = load { i64, ptr }, ptr %t527
  store { i64, ptr } %t528, ptr %l19, !tbaa !27
  br label %bb157
bb156:
  br label %bb162
bb157:
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load ptr, ptr %l18, !tbaa !29
  %t535 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaresNames(ptr %v0, ptr %v1, ptr %t530, ptr %t531)
  store i1 %t535, ptr %l253
  br label %bb158
bb158:
  %t536 = load i1, ptr %l253, !tbaa !21
  br i1 %t536, label %bb159, label %bb160
bb159:
  store i1 true, ptr %l254, !tbaa !21
  br label %bb161
bb160:
  %t537 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t539 = extractvalue { i64, ptr } %t537, 0
  %t541 = icmp sgt i64 %t539, 0
  store i1 %t541, ptr %l254, !tbaa !21
  br label %bb161
bb161:
  %t543 = load i1, ptr %l254, !tbaa !21
  store i1 %t543, ptr %l23, !tbaa !21
  br label %bb163
bb162:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb163
bb163:
  %t544 = load i1, ptr %l23, !tbaa !21
  store i1 %t544, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i1
  %l13 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca i64
  %l50 = alloca i1
  %l55 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp eq i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"compiler/ast:TopIf", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = icmp eq ptr %t10, null
  %t14 = xor i1 %t12, true
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t16 = load i1, ptr %l8, !tbaa !21
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t19 = getelementptr %"compiler/ast:TopIf", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08)
  unreachable
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t26 = getelementptr %"compiler/ast:TopIf", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/ast:TopBranch", ptr %t27, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t35 = icmp sgt i64 %t33, 0
  store i1 %t35, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t37 = load i1, ptr %l13, !tbaa !21
  br i1 %t37, label %bb10, label %bb11
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l23, !tbaa !29
  %t39 = load i64, ptr %l1, !tbaa !24
  store i64 %t39, ptr %l24, !tbaa !24
  %t40 = load ptr, ptr %l2, !tbaa !29
  %t42 = getelementptr %"compiler/ast:TopIf", ptr %t40, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = icmp eq ptr %t43, null
  br i1 %t45, label %bb12, label %bb13
bb11:
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08)
  unreachable
bb13:
  br label %bb14
bb14:
  %t47 = load ptr, ptr %l2, !tbaa !29
  %t49 = getelementptr %"compiler/ast:TopIf", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t53 = getelementptr %"compiler/ast:TopBranch", ptr %t50, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = load ptr, ptr %l23, !tbaa !29
  %t56 = load i64, ptr %l24, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %t55, i64 %t56, { i64, ptr } %t54)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"compiler/ast:TopIf", ptr %t58, i32 0, i32 2
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb17, label %bb18
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l36, !tbaa !29
  %t68 = load i64, ptr %l1, !tbaa !24
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = getelementptr %"compiler/ast:TopIf", ptr %t69, i32 0, i32 2
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = icmp eq ptr %t72, null
  br i1 %t74, label %bb19, label %bb20
bb18:
  br label %bb23
bb19:
  call void @__olang_check_failed(ptr @olang_loc_40b85daad0e541e3_3cdd9f152c967927)
  unreachable
bb20:
  br label %bb21
bb21:
  %t76 = load ptr, ptr %l2, !tbaa !29
  %t78 = getelementptr %"compiler/ast:TopIf", ptr %t76, i32 0, i32 2
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load i64, ptr %l4, !tbaa !24
  %t83 = add i64 %t81, 1
  %t84 = load ptr, ptr %l36, !tbaa !29
  %t85 = load i64, ptr %l37, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %t84, i64 %t85, ptr %t79, i64 %t80, i64 %t83)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t89 = load ptr, ptr %l2, !tbaa !29
  %t91 = getelementptr %"compiler/ast:TopIf", ptr %t89, i32 0, i32 3
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb24, label %bb25
bb24:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t99 = load i64, ptr %l4, !tbaa !24
  %t101 = add i64 %t99, 1
  %t104 = icmp eq i64 %t98, %t101
  store i1 %t104, ptr %l50, !tbaa !21
  br label %bb26
bb25:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb26
bb26:
  %t106 = load i1, ptr %l50, !tbaa !21
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l2, !tbaa !29
  %t109 = getelementptr %"compiler/ast:TopIf", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb32
bb29:
  call void @__olang_check_failed(ptr @olang_loc_17f9884e4c50a862_1761fccd5f6f3c76)
  unreachable
bb30:
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l2, !tbaa !29
  %t116 = getelementptr %"compiler/ast:TopIf", ptr %t114, i32 0, i32 3
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t120 = getelementptr %"compiler/ast:TopBranch", ptr %t117, i32 0, i32 1
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t121, 0
  %t125 = icmp sgt i64 %t123, 0
  store i1 %t125, ptr %l55, !tbaa !21
  br label %bb32
bb32:
  %t127 = load i1, ptr %l55, !tbaa !21
  br i1 %t127, label %bb33, label %bb34
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l65, !tbaa !29
  %t129 = load i64, ptr %l1, !tbaa !24
  store i64 %t129, ptr %l66, !tbaa !24
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr %"compiler/ast:TopIf", ptr %t130, i32 0, i32 3
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  br i1 %t135, label %bb35, label %bb36
bb34:
  br label %bb39
bb35:
  call void @__olang_check_failed(ptr @olang_loc_17f9884e4c50a862_1761fccd5f6f3c76)
  unreachable
bb36:
  br label %bb37
bb37:
  %t137 = load ptr, ptr %l2, !tbaa !29
  %t139 = getelementptr %"compiler/ast:TopIf", ptr %t137, i32 0, i32 3
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t143 = getelementptr %"compiler/ast:TopBranch", ptr %t140, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  %t145 = load ptr, ptr %l65, !tbaa !29
  %t146 = load i64, ptr %l66, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %t145, i64 %t146, { i64, ptr } %t144)
  br label %bb38
bb38:
  br label %bb39
bb39:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultArg(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4, i32 %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l23 = alloca ptr
  %l27 = alloca ptr
  %l29 = alloca i1
  %l34 = alloca i64
  %l43 = alloca i1
  %l46 = alloca i1
  %l53 = alloca i1
  %l56 = alloca { i64, ptr }
  %l66 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca i64
  %l76 = alloca { i64, ptr }
  %l78 = alloca %"compiler/msgs:Msg"
  %l79 = alloca i64
  %l82 = alloca ptr
  %l86 = alloca i64
  %l88 = alloca ptr
  %l92 = alloca ptr
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l104 = alloca %"compiler/generic:Context"
  %l108 = alloca ptr
  %l111 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l124 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca ptr
  %t249 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load %"compiler/source:Span", ptr %l1
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i32, ptr %l5, !tbaa !23
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %t5, %"compiler/source:Span" %t6, i64 %t7, i32 %t8)
  store ptr %t13, ptr %l23
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t14 = load ptr, ptr %l23, !tbaa !29
  store ptr %t14, ptr %rv
  br label %ret
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t18, i64 %t19)
  store ptr %t22, ptr %l27
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l27, !tbaa !29
  store ptr %t23, ptr %l7, !tbaa !29
  br i1 %a4, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb8
bb7:
  %t26 = load ptr, ptr %l7, !tbaa !29
  %t28 = getelementptr %"compiler/ast:Func", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = icmp eq ptr %t29, null
  %t33 = xor i1 %t31, true
  store i1 %t33, ptr %l29, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l29, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = sub i64 %t36, 1
  store i64 %t38, ptr %l34, !tbaa !24
  br label %bb11
bb10:
  %t40 = load i64, ptr %l3, !tbaa !24
  store i64 %t40, ptr %l34, !tbaa !24
  br label %bb11
bb11:
  %t42 = load i64, ptr %l34, !tbaa !24
  store i64 %t42, ptr %l8, !tbaa !24
  %t43 = load ptr, ptr %l7, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Func", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/ast:Sig", ptr %t46, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t53 = icmp eq i64 %t51, 0
  br i1 %t53, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb14
bb13:
  %t55 = load i64, ptr %l8, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  store i1 %t57, ptr %l43, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l43, !tbaa !21
  br i1 %t59, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb17
bb16:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t61 = load ptr, ptr %l7, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Sig", ptr %t64, i32 0, i32 0
  %t67 = load { i64, ptr }, ptr %t66, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t72 = icmp sge i64 %t60, %t69
  store i1 %t72, ptr %l46, !tbaa !21
  br label %bb17
bb17:
  %t74 = load i1, ptr %l46, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  %t75 = load ptr, ptr %l7, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Func", ptr %t75, i32 0, i32 3
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Sig", ptr %t78, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l56, !tbaa !27
  %t82 = load i64, ptr %l8, !tbaa !24
  %t84 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = getelementptr ptr, ptr %t85, i64 %t82
  %t87 = load ptr, ptr %t86, !tbaa !39
  %t89 = getelementptr %"compiler/ast:Param", ptr %t87, i32 0, i32 3
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  store i1 %t92, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t94 = load i1, ptr %l53, !tbaa !21
  br i1 %t94, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = getelementptr %"compiler/ast:Func", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/ast:Sig", ptr %t98, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t105 = icmp sgt i64 %t103, 0
  br i1 %t105, label %bb23, label %bb24
bb22:
  br label %bb32
bb23:
  %t107 = load ptr, ptr %l7, !tbaa !29
  %t109 = getelementptr %"compiler/ast:Func", ptr %t107, i32 0, i32 3
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/ast:Sig", ptr %t110, i32 0, i32 0
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l66, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb25
bb25:
  %t117 = load i64, ptr %l66, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l71, !tbaa !29
  %t119 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t119, ptr %l72
  %t120 = load i64, ptr %l9, !tbaa !24
  store i64 %t120, ptr %l73, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp eq i64 %t121, 1
  br i1 %t123, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr @.d16 }, ptr %l76, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr @.d17 }, ptr %l76, !tbaa !27
  br label %bb28
bb28:
  %t125 = load i64, ptr %l8, !tbaa !24
  %t126 = load i64, ptr %l73, !tbaa !24
  %t127 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t129 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s2, ptr %s2, i64 %t126, { i64, ptr } %t127, i64 %t125)
  store %"compiler/msgs:Msg" %t129, ptr %l78
  br label %bb29
bb29:
  %t130 = load ptr, ptr %l71, !tbaa !29
  %t131 = load %"compiler/source:Span", ptr %l72
  %t132 = load %"compiler/msgs:Msg", ptr %l78
  %t133 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t130, %"compiler/source:Span" %t131, %"compiler/msgs:Msg" %t132)
  store i64 %t133, ptr %l79
  br label %bb30
bb30:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load %"compiler/source:Span", ptr %l1
  %t138 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t134, %"compiler/source:Span" %t135)
  store ptr %t138, ptr %l82
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t139 = load ptr, ptr %l82, !tbaa !29
  store ptr %t139, ptr %rv
  br label %ret
bb32:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t144 = load i64, ptr %l2, !tbaa !24
  %t147 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t143, i64 %t144)
  store i64 %t147, ptr %l86
  br label %bb33
bb33:
  %t148 = load i64, ptr %l86, !tbaa !24
  store i64 %t148, ptr %l10, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t149)
  store ptr %t151, ptr %l88
  br label %bb34
bb34:
  %t152 = load ptr, ptr %l88, !tbaa !29
  %t154 = getelementptr %"compiler/check:frame", ptr %t152, i32 0, i32 2
  %t155 = load i64, ptr %t154, !tbaa !24
  store i64 %t155, ptr %l11, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t157)
  store ptr %t159, ptr %l92
  br label %bb35
bb35:
  %t160 = load ptr, ptr %l92, !tbaa !29
  store ptr %t160, ptr %l12, !tbaa !29
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l12, !tbaa !29
  %t164 = getelementptr %"compiler/check:frame", ptr %t162, i32 0, i32 0
  %t165 = load i64, ptr %t164, !tbaa !24
  %t166 = load i64, ptr %l10, !tbaa !24
  %t167 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t161, i64 %t165, i64 %t166, i32 %t167, i32 0)
  store ptr %t172, ptr %l98
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l98, !tbaa !29
  store ptr %t173, ptr %l13, !tbaa !29
  %t174 = load ptr, ptr %l13, !tbaa !29
  store ptr %t174, ptr %l99, !tbaa !29
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i64, ptr %l2, !tbaa !24
  %t184 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %v0, ptr %v0, ptr %t178, i64 %t179, i32 %a6)
  store %"compiler/generic:Context" %t184, ptr %l104
  br label %bb37
bb37:
  %t185 = load %"compiler/generic:Context", ptr %l104
  %t186 = load ptr, ptr %l99, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t186, i32 0, i32 4
  store %"compiler/generic:Context" %t185, ptr %t187
  %t188 = load ptr, ptr %l13, !tbaa !29
  %t189 = load ptr, ptr %l12, !tbaa !29
  %t191 = getelementptr %"compiler/check:frame", ptr %t189, i32 0, i32 7
  %t192 = load i64, ptr %t191, !tbaa !24
  %t195 = getelementptr %"compiler/check:frame", ptr %t188, i32 0, i32 7
  store i64 %t192, ptr %t195, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  store ptr %t196, ptr %l108, !tbaa !29
  %t197 = load ptr, ptr %l7, !tbaa !29
  %t199 = getelementptr %"compiler/ast:Func", ptr %t197, i32 0, i32 3
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Sig", ptr %t200, i32 0, i32 0
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  store { i64, ptr } %t203, ptr %l111, !tbaa !27
  %t204 = load i64, ptr %l8, !tbaa !24
  %t206 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = getelementptr ptr, ptr %t207, i64 %t204
  %t209 = load ptr, ptr %t208, !tbaa !39
  %t211 = getelementptr %"compiler/ast:Param", ptr %t209, i32 0, i32 3
  %t212 = load ptr, ptr %t211, !tbaa !29
  store ptr %t212, ptr %l14, !tbaa !29
  %t214 = load ptr, ptr %l14, !tbaa !29
  %t216 = icmp eq ptr %t214, null
  br i1 %t216, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_573d6efe4eadca3f_fa49b5af8bd78213)
  unreachable
bb39:
  br label %bb40
bb40:
  %t218 = load ptr, ptr %l14, !tbaa !29
  %t219 = load i32, ptr %l5, !tbaa !23
  %t220 = load ptr, ptr %l108, !tbaa !29
  %t223 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v0, ptr %t220, ptr %t218, i32 %t219)
  store ptr %t223, ptr %l119
  br label %bb41
bb41:
  %t224 = load ptr, ptr %l119, !tbaa !29
  store ptr %t224, ptr %l15, !tbaa !29
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load ptr, ptr %l15, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v0, ptr %t225, ptr %t226)
  br label %bb42
bb42:
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t232 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t230)
  store ptr %t232, ptr %l124
  br label %bb43
bb43:
  %t233 = load ptr, ptr %l124, !tbaa !29
  %t235 = getelementptr %"compiler/check:frame", ptr %t233, i32 0, i32 2
  %t236 = load i64, ptr %t235, !tbaa !24
  store i64 %t236, ptr %l16, !tbaa !24
  %t238 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t238)
  br label %bb44
bb44:
  %t240 = load i64, ptr %l16, !tbaa !24
  %t241 = load i64, ptr %l11, !tbaa !24
  %t244 = icmp ne i64 %t240, %t241
  br i1 %t244, label %bb45, label %bb46
bb45:
  %t246 = load %"compiler/source:Span", ptr %l1
  %t247 = load i64, ptr %l16, !tbaa !24
  %t248 = load ptr, ptr %l15, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t249
  %t250 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 0
  store i64 17, ptr %t250
  %t252 = insertvalue { %"compiler/source:Span", i64, ptr } undef, %"compiler/source:Span" %t246, 0
  %t254 = insertvalue { %"compiler/source:Span", i64, ptr } %t252, i64 %t247, 1
  %t256 = insertvalue { %"compiler/source:Span", i64, ptr } %t254, ptr %t248, 2
  %t257 = getelementptr { i64, [5 x i64] }, ptr %t249, i32 0, i32 1
  store { %"compiler/source:Span", i64, ptr } %t256, ptr %t257
  %t258 = load { i64, [5 x i64] }, ptr %t249
  %t260 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t258, ptr %t260
  store ptr %t260, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t262 = load ptr, ptr %l15, !tbaa !29
  store ptr %t262, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i32
  %l10 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l10
  br label %bb4
bb3:
  %t17 = load i32, ptr %l1, !tbaa !23
  store i32 %t17, ptr %l5, !tbaa !23
  br label %bb5
bb4:
  %t19 = load i32, ptr %l10, !tbaa !23
  store i32 %t19, ptr %l5, !tbaa !23
  br label %bb5
bb5:
  %t20 = load i32, ptr %l5, !tbaa !23
  store i32 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l22 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l5, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 5
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb20
bb8:
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr %"compiler/ast:If", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = icmp eq ptr %t23, null
  br i1 %t25, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_986dcc23e228494c_5356e2d9a8a4da00)
  unreachable
bb10:
  br label %bb11
bb11:
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t33 = getelementptr %"compiler/ast:Branch", ptr %t30, i32 0, i32 2
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = icmp sge i64 %t34, 0
  br i1 %t36, label %bb12, label %bb13
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 0
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/load:Loader", ptr %t44, i32 0, i32 4
  %t47 = load ptr, ptr %t46, !tbaa !29
  store ptr %t47, ptr %l22, !tbaa !29
  %t48 = load ptr, ptr %l2, !tbaa !29
  %t50 = getelementptr %"compiler/ast:If", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = icmp eq ptr %t51, null
  br i1 %t53, label %bb14, label %bb15
bb13:
  br label %bb18
bb14:
  call void @__olang_check_failed(ptr @olang_loc_986dcc23e228494c_5356e2d9a8a4da00)
  unreachable
bb15:
  br label %bb16
bb16:
  %t55 = load ptr, ptr %l2, !tbaa !29
  %t57 = getelementptr %"compiler/ast:If", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Branch", ptr %t58, i32 0, i32 2
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l22, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %t63, i64 %t62)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = getelementptr %"compiler/ast:If", ptr %t66, i32 0, i32 2
  %t69 = load ptr, ptr %t68, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropElse(ptr %v0, ptr %v1, ptr %t65, ptr %t69)
  br label %bb19
bb19:
  br label %bb21
bb20:
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v0, ptr %t1, ptr %t2)
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 32
  %t8 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t7, ptr %t8)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eenumCase(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, [3 x i64] }
  %l27 = alloca ptr
  %l31 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i32
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l53 = alloca ptr
  %l58 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca i64
  %l93 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l104 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/msgs:Msg"
  %l109 = alloca i64
  %l112 = alloca ptr
  %l121 = alloca i32
  %l124 = alloca ptr
  %l129 = alloca i32
  %l130 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca %"compiler/source:Span"
  %l143 = alloca i64
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"compiler/msgs:Msg"
  %l150 = alloca i64
  %l153 = alloca ptr
  %l156 = alloca i64
  %l158 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca ptr
  %l166 = alloca ptr
  %l171 = alloca i64
  %l174 = alloca i64
  %l197 = alloca i1
  %l202 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca ptr
  %l211 = alloca ptr
  %l216 = alloca i32
  %l217 = alloca i64
  %l219 = alloca { i64, ptr }
  %l223 = alloca { i64, [3 x i64] }
  %l225 = alloca { i64, ptr }
  %l228 = alloca { i64, ptr }
  %l231 = alloca ptr
  %l235 = alloca { i64, ptr }
  %l238 = alloca i1
  %l240 = alloca ptr
  %l242 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l246 = alloca %"compiler/source:Span"
  %l248 = alloca i1
  %l257 = alloca { i64, ptr }
  %l258 = alloca %"compiler/source:Span"
  %l259 = alloca i32
  %l264 = alloca %"compiler/typed:Make"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t484 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i32 %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l31
  br label %bb1
bb1:
  %t6 = load i1, ptr %l31, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load i32, ptr %l3, !tbaa !23
  %t13 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t9, i32 %t10)
  store i1 %t13, ptr %l35
  br label %bb4
bb3:
  br label %bb18
bb4:
  %t14 = load i1, ptr %l35, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l39
  br label %bb7
bb6:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb8
bb7:
  %t20 = load i32, ptr %l39
  %t22 = trunc i64 2 to i32
  %t23 = icmp eq i32 %t20, %t22
  store i1 %t23, ptr %l36, !tbaa !21
  br label %bb8
bb8:
  %t25 = load i1, ptr %l36, !tbaa !21
  br i1 %t25, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load %"compiler/source:Span", ptr %l1
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t26, %"compiler/source:Span" %t27)
  store { i64, ptr } %t30, ptr %l44
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t31 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l45, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t33, ptr %l46
  %t34 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t38 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordAsValue(ptr %v0, ptr %v0, ptr %s2, { i64, ptr } %t34, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t38, ptr %l49
  br label %bb12
bb12:
  %t39 = load ptr, ptr %l45, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l46
  %t41 = load %"compiler/msgs:Msg", ptr %l49
  %t42 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t39, %"compiler/source:Span" %t40, %"compiler/msgs:Msg" %t41)
  store i64 %t42, ptr %l50
  br label %bb13
bb13:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l1
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t43, %"compiler/source:Span" %t44)
  store ptr %t47, ptr %l53
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  %t48 = load ptr, ptr %l53, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t49, %"compiler/source:Span" %t50, { i64, ptr } { i64 31, ptr @.d18 })
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l1
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t53, %"compiler/source:Span" %t54)
  store ptr %t57, ptr %l58
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  %t58 = load ptr, ptr %l58, !tbaa !29
  store ptr %t58, ptr %rv
  br label %ret
bb18:
  store i64 -1, ptr %l7, !tbaa !24
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t64 = getelementptr %"compiler/generic:Program", ptr %t62, i32 0, i32 2
  %t65 = load i32, ptr %l3, !tbaa !23
  %t68 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t68, ptr %l63
  br label %bb19
bb19:
  %t69 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t69, ptr %l8, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb20, label %bb21
bb20:
  store i64 0, ptr %l9, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t76, 0
  store i64 %t78, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = icmp sgt i64 %t80, %t81
  br i1 %t84, label %bb22, label %bb23
bb21:
  br label %bb37
bb22:
  %t86 = load i64, ptr %l11, !tbaa !24
  %t88 = icmp sgt i64 %t86, 0
  br i1 %t88, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb27
bb24:
  %t90 = load i64, ptr %l10, !tbaa !24
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = sub i64 %t90, %t91
  %t95 = load i64, ptr %l11, !tbaa !24
  %t98 = add i64 %t94, %t95
  %t100 = sub i64 %t98, 1
  %t101 = load i64, ptr %l11, !tbaa !24
  %t104 = sdiv i64 %t100, %t101
  store i64 %t104, ptr %l75, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb26
bb26:
  %t106 = load i64, ptr %l75, !tbaa !24
  store i64 %t106, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t107 = load i64, ptr %l72, !tbaa !24
  store i64 %t107, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load i64, ptr %l13, !tbaa !24
  %t109 = load i64, ptr %l12, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb29, label %bb30
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb30:
  br label %bb31
bb31:
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = load i64, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l11, !tbaa !24
  %t121 = mul i64 %t117, %t118
  %t124 = add i64 %t116, %t121
  store i64 %t124, ptr %l14, !tbaa !24
  %t126 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t126, ptr %l93, !tbaa !27
  %t127 = load i64, ptr %l14, !tbaa !24
  %t129 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = getelementptr i32, ptr %t130, i64 %t127
  %t132 = load i32, ptr %t131, !tbaa !33
  %t133 = load i32, ptr %l4, !tbaa !23
  %t136 = icmp eq i32 %t132, %t133
  br i1 %t136, label %bb32, label %bb33
bb32:
  %t138 = load i64, ptr %l14, !tbaa !24
  store i64 %t138, ptr %l7, !tbaa !24
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb35
bb35:
  %t140 = load i64, ptr %l13, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l13, !tbaa !24
  br label %bb28
bb36:
  br label %bb37
bb37:
  %t144 = load i64, ptr %l7, !tbaa !24
  %t146 = icmp slt i64 %t144, 0
  br i1 %t146, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l103, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t149, ptr %l104
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t151 = load i32, ptr %l3, !tbaa !23
  %t152 = load i32, ptr %l4, !tbaa !23
  %t156 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s8, ptr %t150, i32 %t151, i32 %t152)
  store %"compiler/msgs:Msg" %t156, ptr %l108
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t157 = load ptr, ptr %l103, !tbaa !29
  %t158 = load %"compiler/source:Span", ptr %l104
  %t159 = load %"compiler/msgs:Msg", ptr %l108
  %t160 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t157, %"compiler/source:Span" %t158, %"compiler/msgs:Msg" %t159)
  store i64 %t160, ptr %l109
  br label %bb41
bb41:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load %"compiler/source:Span", ptr %l1
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t161, %"compiler/source:Span" %t162)
  store ptr %t165, ptr %l112
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  %t166 = load ptr, ptr %l112, !tbaa !29
  store ptr %t166, ptr %rv
  br label %ret
bb43:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i32, ptr %l3, !tbaa !23
  %t169 = load i32, ptr %l4, !tbaa !23
  %t170 = load %"compiler/source:Span", ptr %l2
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %t167, i32 %t168, i32 %t169, %"compiler/source:Span" %t170)
  br label %bb44
bb44:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/check:Checker", ptr %t175, i32 0, i32 1
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = load i32, ptr %l3, !tbaa !23
  %t180 = load i64, ptr %l7, !tbaa !24
  %t184 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t178, i32 %t179, i64 %t180)
  store i32 %t184, ptr %l121
  br label %bb45
bb45:
  %t185 = load i32, ptr %l121, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/generic:Program", ptr %t189, i32 0, i32 2
  store ptr %t191, ptr %l124, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 2
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t197, i32 %t185)
  store i32 %t201, ptr %l129
  br label %bb46
bb46:
  %t202 = load ptr, ptr %l124, !tbaa !29
  %t203 = load i32, ptr %l129, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t202, i32 %t203)
  store { i64, ptr } %t204, ptr %l130
  br label %bb47
bb47:
  %t205 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t205, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb48, label %bb49
bb48:
  %t212 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 0
  store i64 %t214, ptr %l17, !tbaa !24
  br label %bb50
bb49:
  br label %bb50
bb50:
  %t216 = load i64, ptr %l17, !tbaa !24
  %t217 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t217, 0
  %t222 = icmp ne i64 %t216, %t219
  br i1 %t222, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l140, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t225, ptr %l141
  %t226 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t226, 0
  store i64 %t228, ptr %l143, !tbaa !24
  %t229 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t233 = icmp eq i64 %t231, 1
  br i1 %t233, label %bb53, label %bb54
bb52:
  br label %bb59
bb53:
  store { i64, ptr } { i64 0, ptr @.d19 }, ptr %l147, !tbaa !27
  br label %bb55
bb54:
  store { i64, ptr } { i64 1, ptr @.d20 }, ptr %l147, !tbaa !27
  br label %bb55
bb55:
  %t235 = load i64, ptr %l17, !tbaa !24
  %t236 = load i64, ptr %l143, !tbaa !24
  %t237 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t239 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s10, ptr %s10, i64 %t236, { i64, ptr } %t237, i64 %t235)
  store %"compiler/msgs:Msg" %t239, ptr %l149
  br label %bb56
bb56:
  %t240 = load ptr, ptr %l140, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l141
  %t242 = load %"compiler/msgs:Msg", ptr %l149
  %t243 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t240, %"compiler/source:Span" %t241, %"compiler/msgs:Msg" %t242)
  store i64 %t243, ptr %l150
  br label %bb57
bb57:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load %"compiler/source:Span", ptr %l1
  %t248 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t244, %"compiler/source:Span" %t245)
  store ptr %t248, ptr %l153
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  %t249 = load ptr, ptr %l153, !tbaa !29
  store ptr %t249, ptr %rv
  br label %ret
bb59:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 31
  %t254 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t252)
  store i64 %t254, ptr %l156
  br label %bb60
bb60:
  %t255 = load i64, ptr %l156, !tbaa !24
  store i64 %t255, ptr %l18, !tbaa !24
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t258 = getelementptr %"compiler/check:Checker", ptr %t256, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !29
  store ptr %t259, ptr %l158, !tbaa !29
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t262 = getelementptr %"compiler/check:Checker", ptr %t260, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !29
  %t265 = getelementptr %"compiler/generic:Program", ptr %t263, i32 0, i32 2
  %t266 = load i32, ptr %l3, !tbaa !23
  %t269 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t265, i32 %t266)
  store i32 %t269, ptr %l163
  br label %bb61
bb61:
  %t270 = load ptr, ptr %l158, !tbaa !29
  %t271 = load i32, ptr %l163, !tbaa !23
  %t272 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t270, i32 %t271)
  store ptr %t272, ptr %l164
  br label %bb62
bb62:
  %t273 = load i64, ptr %l7, !tbaa !24
  %t274 = load ptr, ptr %l164, !tbaa !29
  %t276 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t274, i64 %t273)
  store ptr %t276, ptr %l166
  br label %bb63
bb63:
  %t277 = load ptr, ptr %l166, !tbaa !29
  store ptr %t277, ptr %l19, !tbaa !29
  store i64 0, ptr %l20, !tbaa !24
  %t278 = load i64, ptr %l17, !tbaa !24
  store i64 %t278, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t280 = load i64, ptr %l21, !tbaa !24
  %t281 = load i64, ptr %l20, !tbaa !24
  %t284 = icmp sgt i64 %t280, %t281
  br i1 %t284, label %bb64, label %bb65
bb64:
  %t286 = load i64, ptr %l22, !tbaa !24
  %t288 = icmp sgt i64 %t286, 0
  br i1 %t288, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l171, !tbaa !24
  br label %bb69
bb66:
  %t290 = load i64, ptr %l21, !tbaa !24
  %t291 = load i64, ptr %l20, !tbaa !24
  %t294 = sub i64 %t290, %t291
  %t295 = load i64, ptr %l22, !tbaa !24
  %t298 = add i64 %t294, %t295
  %t300 = sub i64 %t298, 1
  %t301 = load i64, ptr %l22, !tbaa !24
  %t304 = sdiv i64 %t300, %t301
  store i64 %t304, ptr %l174, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb68
bb68:
  %t306 = load i64, ptr %l174, !tbaa !24
  store i64 %t306, ptr %l171, !tbaa !24
  br label %bb69
bb69:
  %t307 = load i64, ptr %l171, !tbaa !24
  store i64 %t307, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s12
  %t308 = load i64, ptr %l24, !tbaa !24
  %t309 = load i64, ptr %l23, !tbaa !24
  %t312 = icmp slt i64 %t308, %t309
  %t314 = xor i1 %t312, true
  br i1 %t314, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb72:
  br label %bb73
bb73:
  %t316 = load i64, ptr %l20, !tbaa !24
  %t317 = load i64, ptr %l24, !tbaa !24
  %t318 = load i64, ptr %l22, !tbaa !24
  %t321 = mul i64 %t317, %t318
  %t324 = add i64 %t316, %t321
  store i64 %t324, ptr %l25, !tbaa !24
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 9
  %t329 = load { i64, [3 x i64] }, ptr %t328
  store { i64, [3 x i64] } %t329, ptr %l26
  %t331 = load ptr, ptr %l19, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  %t335 = xor i1 %t333, true
  br i1 %t335, label %bb74, label %bb75
bb74:
  %t337 = load ptr, ptr %l19, !tbaa !29
  %t339 = getelementptr %"compiler/ast:CaseDecl", ptr %t337, i32 0, i32 2
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t344 = icmp sgt i64 %t342, 0
  store i1 %t344, ptr %l197, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb76
bb76:
  %t346 = load i1, ptr %l197, !tbaa !21
  br i1 %t346, label %bb77, label %bb78
bb77:
  %t347 = load i64, ptr %l25, !tbaa !24
  %t348 = load ptr, ptr %l19, !tbaa !29
  %t350 = getelementptr %"compiler/ast:CaseDecl", ptr %t348, i32 0, i32 2
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t351, 0
  %t356 = icmp slt i64 %t347, %t353
  store i1 %t356, ptr %l202, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb79
bb79:
  %t358 = load i1, ptr %l202, !tbaa !21
  br i1 %t358, label %bb80, label %bb81
bb80:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l208, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l209, !tbaa !29
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/check:Checker", ptr %t361, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !29
  store ptr %t364, ptr %l211, !tbaa !29
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/check:Checker", ptr %t365, i32 0, i32 1
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t370 = getelementptr %"compiler/generic:Program", ptr %t368, i32 0, i32 2
  %t371 = load i32, ptr %l3, !tbaa !23
  %t374 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t370, i32 %t371)
  store i32 %t374, ptr %l216
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t375 = load ptr, ptr %l211, !tbaa !29
  %t376 = load i32, ptr %l216, !tbaa !23
  %t377 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %t375, i32 %t376)
  store i64 %t377, ptr %l217
  br label %bb83
bb83:
  %t378 = load ptr, ptr %l19, !tbaa !29
  %t380 = getelementptr %"compiler/ast:CaseDecl", ptr %t378, i32 0, i32 2
  %t381 = load { i64, ptr }, ptr %t380, !tbaa !27
  store { i64, ptr } %t381, ptr %l219, !tbaa !27
  %t382 = load i64, ptr %l25, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr ptr, ptr %t385, i64 %t382
  %t387 = load ptr, ptr %t386, !tbaa !39
  %t389 = getelementptr %"compiler/ast:Param", ptr %t387, i32 0, i32 2
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t391 = load ptr, ptr %l209, !tbaa !29
  %t392 = load i64, ptr %l217, !tbaa !24
  %t394 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t391, i64 %t392, ptr %t390)
  store { i64, [3 x i64] } %t394, ptr %l223
  br label %bb84
bb84:
  %t395 = load { i64, [3 x i64] }, ptr %l223
  %t396 = load ptr, ptr %l208, !tbaa !29
  %t397 = getelementptr %"compiler/check:Checker", ptr %t396, i32 0, i32 9
  store { i64, [3 x i64] } %t395, ptr %t397
  br label %bb85
bb85:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t399, ptr %l225, !tbaa !27
  %t400 = load i64, ptr %l25, !tbaa !24
  %t402 = getelementptr { i64, ptr }, ptr %l225, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr ptr, ptr %t403, i64 %t400
  %t405 = load ptr, ptr %t404, !tbaa !39
  %t406 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t406, ptr %l228, !tbaa !27
  %t407 = load i64, ptr %l25, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l228, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i32, ptr %t410, i64 %t407
  %t412 = load i32, ptr %t411, !tbaa !33
  %t416 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t398, ptr %t405, i32 %t412)
  store ptr %t416, ptr %l231
  br label %bb86
bb86:
  %t417 = load ptr, ptr %l231, !tbaa !29
  store ptr %t417, ptr %l27, !tbaa !29
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t419 = load { i64, [3 x i64] }, ptr %l26
  %t422 = getelementptr %"compiler/check:Checker", ptr %t418, i32 0, i32 9
  store { i64, [3 x i64] } %t419, ptr %t422
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t424, ptr %l235, !tbaa !27
  %t425 = load i64, ptr %l25, !tbaa !24
  %t427 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr i32, ptr %t428, i64 %t425
  %t430 = load i32, ptr %t429, !tbaa !33
  %t433 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t423, i32 %t430)
  store i1 %t433, ptr %l238
  br label %bb87
bb87:
  %t434 = load i1, ptr %l238, !tbaa !21
  %t435 = xor i1 %t434, true
  br i1 %t435, label %bb88, label %bb89
bb88:
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l240, !tbaa !29
  %t438 = load ptr, ptr %l27, !tbaa !29
  store ptr %t438, ptr %l242, !tbaa !29
  %t440 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t440, ptr %l243, !tbaa !27
  %t441 = load i64, ptr %l25, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr ptr, ptr %t444, i64 %t441
  %t446 = load ptr, ptr %t445, !tbaa !39
  %t448 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t446)
  store %"compiler/source:Span" %t448, ptr %l246
  br label %bb90
bb89:
  br label %bb92
bb90:
  %t449 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t450 = load ptr, ptr %l240, !tbaa !29
  %t451 = load ptr, ptr %l242, !tbaa !29
  %t452 = load %"compiler/source:Span", ptr %l246
  %t454 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t450, ptr %t451, %"compiler/source:Span" %t452, i64 %t449)
  store i1 %t454, ptr %l248
  br label %bb91
bb91:
  br label %bb92
bb92:
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 31
  %t458 = load ptr, ptr %l27, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t457, ptr %t458)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s12)
  br label %bb94
bb94:
  %t461 = load i64, ptr %l24, !tbaa !24
  %t463 = add i64 %t461, 1
  store i64 %t463, ptr %l24, !tbaa !24
  br label %bb70
bb95:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t467 = getelementptr %"compiler/check:Checker", ptr %t465, i32 0, i32 31
  %t468 = load i64, ptr %l18, !tbaa !24
  %t471 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t467, i64 %t468)
  store { i64, ptr } %t471, ptr %l257
  br label %bb96
bb96:
  %t472 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t473 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t473, ptr %l258
  %t474 = load i32, ptr %l3, !tbaa !23
  store i32 %t474, ptr %l259, !tbaa !23
  %t475 = load i64, ptr %l7, !tbaa !24
  %t481 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 1, i64 %t475, { i64, ptr } %t472, ptr null, i32 -1, i32 0)
  store %"compiler/typed:Make" %t481, ptr %l264
  br label %bb97
bb97:
  %t482 = load %"compiler/typed:Make", ptr %l264
  %t483 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t482, ptr %t483
  store { i64, [5 x i64] } zeroinitializer, ptr %t484
  %t485 = getelementptr { i64, [5 x i64] }, ptr %t484, i32 0, i32 0
  store i64 7, ptr %t485
  %t486 = load %"compiler/source:Span", ptr %l258
  %t487 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t486, 0
  %t488 = load i32, ptr %l259, !tbaa !23
  %t489 = insertvalue { %"compiler/source:Span", i32, ptr } %t487, i32 %t488, 1
  %t491 = insertvalue { %"compiler/source:Span", i32, ptr } %t489, ptr %t483, 2
  %t492 = getelementptr { i64, [5 x i64] }, ptr %t484, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t491, ptr %t492
  %t493 = load { i64, [5 x i64] }, ptr %t484
  %t495 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t493, ptr %t495
  store ptr %t495, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4, i32 %a5, i32 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca %"compiler/source:Span"
  %l33 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l48 = alloca %"compiler/msgs:Msg"
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l60 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca i8
  %l66 = alloca i64
  %l67 = alloca i64
  %l72 = alloca { i64, ptr }
  %l74 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca ptr
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i32
  %l97 = alloca i32
  %l98 = alloca i64
  %l104 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l108 = alloca %"compiler/msgs:Msg"
  %l109 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca i32
  %l116 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l129 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca %"compiler/msgs:Msg"
  %l143 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i32 %a5, ptr %l5
  store i32 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l17, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t9 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t5, i64 %t6)
  store ptr %t9, ptr %l21
  br label %bb1
bb1:
  %t10 = load ptr, ptr %l17, !tbaa !29
  %t11 = load ptr, ptr %l21, !tbaa !29
  %t12 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t10, ptr %t11)
  store %"compiler/source:Span" %t12, ptr %l22
  br label %bb2
bb2:
  %t13 = load %"compiler/source:Span", ptr %l22
  store %"compiler/source:Span" %t13, ptr %l7
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t22 = icmp slt i64 %t16, %t19
  %t26 = xor i1 %t22, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t30 = getelementptr [22 x %"compiler/check:opShape"], ptr @G_2ecompiler_2fcheck_2eOpShapes, i64 0, i64 %a4
  %t31 = getelementptr %"compiler/check:opShape", ptr %t30, i32 0, i32 3
  %t32 = load i1, ptr %t31, !tbaa !21
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb5, label %bb6
bb4:
  br label %bb18
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load i32, ptr %l5, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %t36, i32 %t37)
  store i1 %t40, ptr %l36
  br label %bb7
bb6:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb8
bb7:
  %t41 = load i1, ptr %l36, !tbaa !21
  store i1 %t41, ptr %l33, !tbaa !21
  br label %bb8
bb8:
  %t42 = load i1, ptr %l33, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/generic:Program", ptr %t46, i32 0, i32 2
  %t49 = load i32, ptr %l6, !tbaa !23
  %t52 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t48, i32 %t49)
  store { i64, ptr } %t52, ptr %l42
  br label %bb11
bb10:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb12
bb11:
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  %t56 = icmp sgt i64 %t54, 0
  store i1 %t56, ptr %l37, !tbaa !21
  br label %bb12
bb12:
  %t58 = load i1, ptr %l37, !tbaa !21
  br i1 %t58, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t60, ptr %l46
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %v2, ptr %s2, { i64, ptr } %t61)
  store %"compiler/msgs:Msg" %t63, ptr %l48
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t64 = load ptr, ptr %l45, !tbaa !29
  %t65 = load %"compiler/source:Span", ptr %l46
  %t66 = load %"compiler/msgs:Msg", ptr %l48
  %t67 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t64, %"compiler/source:Span" %t65, %"compiler/msgs:Msg" %t66)
  store i64 %t67, ptr %l49
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l50, !tbaa !27
  %t69 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t69, 0
  store i64 %t72, ptr %l53, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l54, !tbaa !24
  %t75 = icmp sge i64 7, 0
  br i1 %t75, label %bb19, label %bb20
bb19:
  %t77 = load i64, ptr %l53, !tbaa !24
  %t78 = icmp sle i64 7, %t77
  br i1 %t78, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_feae5f9a3edd32a2_1e841cd8c4e091f6)
  unreachable
bb21:
  %t80 = load i64, ptr %l53, !tbaa !24
  %t81 = load i64, ptr %l54, !tbaa !24
  %t82 = icmp sle i64 %t80, %t81
  br i1 %t82, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_feae5f9a3edd32a2_1e841cd8c4e091f6)
  unreachable
bb23:
  %t84 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !27
  %t86 = load i64, ptr %l53, !tbaa !24
  %t87 = getelementptr i8, ptr %t85, i64 7
  %t88 = sub i64 %t86, 7
  %t89 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t87, 1
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = extractvalue { i64, ptr } %t90, 0
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t92, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l9, !tbaa !27
  %t98 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t98, ptr %l60, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i8, ptr %t100, i64 0
  %t102 = load i8, ptr %t101, !tbaa !32
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t102)
  store i1 %t104, ptr %l62
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_feae5f9a3edd32a2_1e841cd8c4e091f6)
  unreachable
bb25:
  %t105 = load i1, ptr %l62, !tbaa !21
  br i1 %t105, label %bb26, label %bb27
bb26:
  %t106 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i8, ptr %t107, i64 0
  %t109 = load i8, ptr %t108, !tbaa !32
  %t111 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %t109)
  store i8 %t111, ptr %l64
  br label %bb28
bb27:
  br label %bb38
bb28:
  %t112 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t112, 0
  store i64 %t114, ptr %l66, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l67, !tbaa !24
  %t117 = icmp sge i64 1, 0
  br i1 %t117, label %bb29, label %bb30
bb29:
  %t119 = load i64, ptr %l66, !tbaa !24
  %t120 = icmp sle i64 1, %t119
  br i1 %t120, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_1b34257fee27c01f_cee7281d74ae4253)
  unreachable
bb31:
  %t122 = load i64, ptr %l66, !tbaa !24
  %t123 = load i64, ptr %l67, !tbaa !24
  %t124 = icmp sle i64 %t122, %t123
  br i1 %t124, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_1b34257fee27c01f_cee7281d74ae4253)
  unreachable
bb33:
  %t126 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = load i64, ptr %l66, !tbaa !24
  %t129 = getelementptr i8, ptr %t127, i64 1
  %t130 = sub i64 %t128, 1
  %t131 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t132 = insertvalue { i64, ptr } %t131, ptr %t129, 1
  %t133 = load i8, ptr %l64, !tbaa !22
  %t135 = extractvalue { i64, ptr } %t132, 1
  %t136 = extractvalue { i64, ptr } %t132, 0
  %t137 = add i64 1, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  store i8 %t133, ptr %t138
  %t139 = getelementptr i8, ptr %t138, i64 1
  call void @olang_textcopy(ptr %t139, ptr %t135, i64 %t136)
  %t140 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t138, 1
  store { i64, ptr } %t141, ptr %l72, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l74, !tbaa !24
  %t147 = load i64, ptr %l74, !tbaa !24
  %t148 = icmp eq i64 %t143, %t147
  br i1 %t148, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_1b34257fee27c01f_cee7281d74ae4253)
  unreachable
bb35:
  %t150 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = load i64, ptr %l74, !tbaa !24
  %t155 = mul i64 %t154, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t151, ptr %t153, i64 %t155, i1 false)
  br label %bb37
bb36:
  %t156 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t156, ptr %l9, !tbaa !27
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l76, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  store ptr %t163, ptr %l79, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/check:Checker", ptr %t164, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/generic:Program", ptr %t167, i32 0, i32 2
  %t170 = load i32, ptr %l5, !tbaa !23
  %t173 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t169, i32 %t170)
  store i32 %t173, ptr %l84
  br label %bb39
bb39:
  %t174 = load ptr, ptr %l79, !tbaa !29
  %t175 = load i32, ptr %l84, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t174, i32 %t175)
  store { i64, ptr } %t176, ptr %l85
  br label %bb40
bb40:
  %t177 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t177, ptr %l86, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr i32, ptr %t179, i64 0
  %t181 = load i32, ptr %t180, !tbaa !33
  %t182 = load ptr, ptr %l76, !tbaa !29
  %t184 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t182, i32 %t181)
  store i32 %t184, ptr %l88
  br label %bb41
bb41:
  %t185 = load i32, ptr %l88, !tbaa !23
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  store ptr %t189, ptr %l90, !tbaa !29
  store i32 %t185, ptr %l91, !tbaa !23
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/generic:Program", ptr %t194, i32 0, i32 0
  %t197 = load ptr, ptr %t196, !tbaa !29
  %t199 = getelementptr %"compiler/load:Loader", ptr %t197, i32 0, i32 3
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t204 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t200, { i64, ptr } %t201)
  store i32 %t204, ptr %l97
  br label %bb42
bb42:
  %t205 = load ptr, ptr %l90, !tbaa !29
  %t206 = load i32, ptr %l91, !tbaa !23
  %t207 = load i32, ptr %l97, !tbaa !23
  %t208 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t205, i32 %t206, i32 %t207)
  store i64 %t208, ptr %l98
  br label %bb43
bb43:
  %t209 = load i64, ptr %l98, !tbaa !24
  store i64 %t209, ptr %l11, !tbaa !24
  %t210 = load i64, ptr %l11, !tbaa !24
  %t211 = load i64, ptr %l1, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  br i1 %t214, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb45:
  br label %bb46
bb46:
  %t216 = load i64, ptr %l11, !tbaa !24
  %t218 = icmp slt i64 %t216, 0
  br i1 %t218, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s7
  %t220 = load ptr, ptr %l0, !tbaa !29
  store ptr %t220, ptr %l104, !tbaa !29
  %t221 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t221, ptr %l105
  %t222 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t226 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedWithoutPlain(ptr %v1, ptr %s0, ptr %s7, { i64, ptr } %t222, { i64, ptr } %t223)
  store %"compiler/msgs:Msg" %t226, ptr %l108
  br label %bb49
bb48:
  br label %bb51
bb49:
  %t227 = load ptr, ptr %l104, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l105
  %t229 = load %"compiler/msgs:Msg", ptr %l108
  %t230 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t227, %"compiler/source:Span" %t228, %"compiler/msgs:Msg" %t229)
  store i64 %t230, ptr %l109
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb51:
  %t231 = load ptr, ptr %l0, !tbaa !29
  %t233 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  %t236 = getelementptr %"compiler/generic:Program", ptr %t234, i32 0, i32 2
  store ptr %t236, ptr %l112, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i64, ptr %l11, !tbaa !24
  %t241 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %t237, i64 %t238)
  store i32 %t241, ptr %l115
  br label %bb52
bb52:
  %t242 = load ptr, ptr %l112, !tbaa !29
  %t243 = load i32, ptr %l115, !tbaa !23
  %t244 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t242, i32 %t243)
  store { i64, ptr } %t244, ptr %l116
  br label %bb53
bb53:
  %t245 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t245, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t246 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t248 = extractvalue { i64, ptr } %t246, 0
  store i64 %t248, ptr %l14, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t250 = load i64, ptr %l13, !tbaa !24
  %t251 = load i64, ptr %l14, !tbaa !24
  %t254 = icmp slt i64 %t250, %t251
  %t256 = xor i1 %t254, true
  br i1 %t256, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb66
bb56:
  br label %bb57
bb57:
  %t258 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t258, ptr %l123, !tbaa !27
  %t259 = load i64, ptr %l13, !tbaa !24
  %t261 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t262 = load ptr, ptr %t261, !tbaa !27
  %t263 = getelementptr i32, ptr %t262, i64 %t259
  %t264 = load i32, ptr %t263, !tbaa !33
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i32, ptr %l6, !tbaa !23
  %t272 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t266, i32 %t267, i32 %t264)
  store i32 %t272, ptr %l129
  br label %bb58
bb58:
  %t273 = load i32, ptr %l129, !tbaa !23
  store i32 %t273, ptr %l16, !tbaa !23
  %t274 = load i32, ptr %l16, !tbaa !23
  %t275 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t278 = icmp ne i32 %t274, %t275
  br i1 %t278, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l133, !tbaa !29
  %t281 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t281, ptr %l134
  %t282 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t282, ptr %l135, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t283, ptr %l136, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t284, ptr %l137, !tbaa !27
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t286 = load i32, ptr %l16, !tbaa !23
  %t289 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t285, i32 %t286)
  store { i64, ptr } %t289, ptr %l140
  br label %bb61
bb60:
  br label %bb64
bb61:
  %t290 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t291 = extractvalue { i64, ptr } %t290, 0
  %t292 = extractvalue { i64, ptr } %t290, 1
  %t293 = mul i64 %t291, 1
  %t294 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t293)
  call void @llvm.memcpy.p0.p0.i64(ptr %t294, ptr %t292, i64 %t293, i1 false)
  %t295 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t296 = insertvalue { i64, ptr } %t295, ptr %t294, 1
  %t297 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t298 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t301 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedNotSuperset(ptr %v1, ptr %s0, ptr %s0, ptr %s10, ptr %s10, { i64, ptr } %t297, { i64, ptr } %t298, { i64, ptr } %t299, { i64, ptr } %t296)
  store %"compiler/msgs:Msg" %t301, ptr %l142
  br label %bb62
bb62:
  %t302 = load ptr, ptr %l133, !tbaa !29
  %t303 = load %"compiler/source:Span", ptr %l134
  %t304 = load %"compiler/msgs:Msg", ptr %l142
  %t305 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t302, %"compiler/source:Span" %t303, %"compiler/msgs:Msg" %t304)
  store i64 %t305, ptr %l143
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb64:
  call void @__olang_scope_close(ptr %s9)
  br label %bb65
bb65:
  %t306 = load i64, ptr %l13, !tbaa !24
  %t308 = add i64 %t306, 1
  store i64 %t308, ptr %l13, !tbaa !24
  br label %bb54
bb66:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalDeps(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %lp3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca %"compiler/check:b5aWalk"
  %l11 = alloca i1
  %l12 = alloca i64
  %l14 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v1, i64 %a1)
  store %"compiler/check:b5aWalk" %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store ptr %t4, ptr %lp3
  %t5 = load %"compiler/check:b5aWalk", ptr %l6
  %t6 = load ptr, ptr %lp3
  store %"compiler/check:b5aWalk" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %lp3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aInit(ptr %v0, ptr %v1, ptr %t7, ptr %t8, i64 %a2)
  br label %bb2
bb2:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %lp3
  %t14 = getelementptr %"compiler/check:b5aWalk", ptr %t13, i32 0, i32 7
  %t15 = load i1, ptr %t14, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l12, !tbaa !24
  %t18 = load ptr, ptr %lp3
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %t18, i32 0, i32 2
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v1, ptr %t19)
  store i64 %t21, ptr %l14
  br label %bb6
bb5:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb7
bb6:
  %t22 = load i64, ptr %l12, !tbaa !24
  %t23 = load i64, ptr %l14, !tbaa !24
  %t24 = icmp slt i64 %t22, %t23
  store i1 %t24, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t26 = load i1, ptr %l11, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb14
bb9:
  br label %bb10
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %lp3
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %lp3
  %t32 = getelementptr %"compiler/check:b5aWalk", ptr %t31, i32 0, i32 2
  %t33 = load i64, ptr %l4, !tbaa !24
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v1, ptr %t32, i64 %t33)
  store i64 %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l17, !tbaa !29
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t39 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %t37, ptr %t38, i64 %t39)
  br label %bb12
bb12:
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = add i64 %t40, 1
  store i64 %t42, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb13
bb13:
  br label %bb3
bb14:
  %t44 = load ptr, ptr %lp3
  %t45 = getelementptr %"compiler/check:b5aWalk", ptr %t44, i32 0, i32 3
  %t46 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t45
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehidden(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l8 = alloca i64
  %rv = alloca i64
  %t4 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [2 x i64] } zeroinitializer, ptr %t4
  %t5 = getelementptr { i64, [2 x i64] }, ptr %t4, i32 0, i32 0
  store i64 0, ptr %t5
  %t6 = load { i64, [2 x i64] }, ptr %t4
  %t12 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %a1, i32 %a2, i32 3, { i64, [2 x i64] } %t6)
  store i64 %t12, ptr %l8
  br label %bb1
bb1:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimmutableGlobal(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca ptr
  %l8 = alloca ptr
  %l12 = alloca i1
  %l15 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t10 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %t4, i64 %a1, i32 %a2)
  store ptr %t10, ptr %l8
  br label %bb1
bb1:
  %t11 = load ptr, ptr %l8, !tbaa !29
  store ptr %t11, ptr %l3, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = icmp eq ptr %t12, null
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr %"compiler/ast:VarDecl", ptr %t18, i32 0, i32 2
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = call i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %t21)
  store i1 %t23, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l12, !tbaa !21
  br label %bb5
bb4:
  %t24 = load i1, ptr %l15, !tbaa !21
  %t25 = xor i1 %t24, true
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l12, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einGeneric(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca ptr
  %l5 = alloca i64
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
  store ptr %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 4
  %t7 = getelementptr %"compiler/generic:Context", ptr %t6, i32 0, i32 2
  %t9 = call i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einRange(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %lp9 = alloca ptr
  %l12 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l47 = alloca ptr
  %l50 = alloca i64
  %l55 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca %"compiler/source:Span"
  %l59 = alloca i32
  %l60 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l68 = alloca i32
  %l69 = alloca i32
  %l70 = alloca i32
  %l74 = alloca { i64, ptr }
  %l76 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t134 = alloca { i64, [5 x i64] }, align 8
  %t159 = alloca i64
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t1, i32 %a3, { i64, ptr } { i64 3, ptr @.d21 }, i64 0)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load i64, ptr %l5, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t11, %"compiler/source:Span" %t12, { i64, ptr } { i64 38, ptr @.d22 })
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t15 = icmp sge i64 0, 0
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = icmp sle i64 0, 1152921504606846975
  br i1 %t17, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e824f9a9b7a4d826_1573df97ffd6af2)
  unreachable
bb7:
  %t19 = mul i64 0, 8
  %t20 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t19)
  %t21 = insertvalue { i64, ptr } undef, i64 0, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t22, ptr %rv
  br label %ret
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e824f9a9b7a4d826_1573df97ffd6af2)
  unreachable
bb9:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l21, !tbaa !29
  %t26 = load ptr, ptr %l4, !tbaa !29
  store ptr %t26, ptr %l22, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t27)
  store i32 %t29, ptr %l24
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = load i32, ptr %l24, !tbaa !23
  %t33 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t30, ptr %t31, i32 %t32)
  store ptr %t33, ptr %l25
  br label %bb11
bb11:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t34)
  store %"compiler/source:Span" %t36, ptr %l27
  br label %bb12
bb12:
  %t37 = load ptr, ptr %l20, !tbaa !29
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l27
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t37, ptr %t38, %"compiler/source:Span" %t39)
  store ptr %t40, ptr %l28
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l28, !tbaa !29
  store ptr %t41, ptr %l6, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l29, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t43, ptr %l30
  %t44 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t44, ptr %l31
  %t45 = load i64, ptr %l5, !tbaa !24
  store i64 %t45, ptr %l32, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l1
  %t52 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t46, %"compiler/source:Span" %t47, ptr %a2)
  store ptr %t52, ptr %l36
  br label %bb14
bb14:
  %t53 = load ptr, ptr %l36, !tbaa !29
  store ptr %t53, ptr %l37, !tbaa !29
  %t54 = icmp sge i64 0, 0
  br i1 %t54, label %bb15, label %bb16
bb15:
  %t56 = icmp sle i64 0, 1152921504606846975
  br i1 %t56, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e57695a485c1fbbb_594346b6b5819ee7)
  unreachable
bb17:
  %t58 = mul i64 0, 8
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 0, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l40, !tbaa !27
  %t62 = icmp sge i64 0, 0
  br i1 %t62, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e57695a485c1fbbb_594346b6b5819ee7)
  unreachable
bb19:
  %t64 = icmp sle i64 0, 1152921504606846975
  br i1 %t64, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e57695a485c1fbbb_594346b6b5819ee7)
  unreachable
bb21:
  %t66 = mul i64 0, 8
  %t67 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 0, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = icmp sge i64 0, 0
  br i1 %t70, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e57695a485c1fbbb_594346b6b5819ee7)
  unreachable
bb23:
  %t72 = icmp sle i64 0, 2305843009213693951
  br i1 %t72, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_23ae6d164f19c0d8_5e726559a7bbcc04)
  unreachable
bb25:
  %t74 = mul i64 0, 4
  %t75 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 0, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  %t78 = load ptr, ptr %l29, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l30
  %t80 = load %"compiler/source:Span", ptr %l31
  %t81 = load i64, ptr %l32, !tbaa !24
  %t82 = load ptr, ptr %l37, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t84 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t86 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s0, ptr %t78, %"compiler/source:Span" %t79, %"compiler/source:Span" %t80, i64 %t81, ptr %t82, { i64, ptr } %t83, { i64, ptr } %t84, { i64, ptr } %t77)
  store ptr %t86, ptr %l47
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_23ae6d164f19c0d8_5e726559a7bbcc04)
  unreachable
bb27:
  %t87 = load ptr, ptr %l47, !tbaa !29
  store ptr %t87, ptr %l7, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t88, i32 0, i32 31
  %t92 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l50
  br label %bb28
bb28:
  %t93 = load i64, ptr %l50, !tbaa !24
  store i64 %t93, ptr %l8, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 31
  %t97 = load ptr, ptr %l6, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t96, ptr %t97)
  br label %bb29
bb29:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 31
  store ptr %t102, ptr %l55, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l56, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t104, ptr %l57
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t105)
  store i32 %t107, ptr %l59
  br label %bb30
bb30:
  %t108 = load ptr, ptr %l56, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l57
  %t110 = load i32, ptr %l59, !tbaa !23
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t108, %"compiler/source:Span" %t109, i32 %t110, i64 0)
  store ptr %t111, ptr %l60
  br label %bb31
bb31:
  %t112 = load ptr, ptr %l55, !tbaa !29
  %t113 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t112, ptr %t113)
  br label %bb32
bb32:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 31
  %t117 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t116, ptr %t117)
  br label %bb33
bb33:
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t122 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t120)
  store %"compiler/source:Span" %t122, ptr %l65
  br label %bb34
bb34:
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t126 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t123)
  store i32 %t126, ptr %l68
  br label %bb35
bb35:
  store i32 24, ptr %l69
  store i32 2, ptr %l70
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t127, i32 0, i32 31
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t129, i64 %t130)
  store { i64, ptr } %t133, ptr %l74
  br label %bb36
bb36:
  store { i64, [5 x i64] } zeroinitializer, ptr %t134
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 0
  store i64 9, ptr %t135
  %t136 = load %"compiler/source:Span", ptr %l65
  %t137 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t136, 0
  %t138 = load i32, ptr %l68, !tbaa !23
  %t139 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t137, i32 %t138, 1
  %t140 = load i32, ptr %l69
  %t141 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t139, i32 %t140, 2
  %t142 = load i32, ptr %l70
  %t143 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t141, i32 %t142, 3
  %t144 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t145 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t143, { i64, ptr } %t144, 4
  %t146 = getelementptr { i64, [5 x i64] }, ptr %t134, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t145, ptr %t146
  %t147 = load { i64, [5 x i64] }, ptr %t134
  %t148 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store ptr %t148, ptr %lp9
  %t150 = load ptr, ptr %lp9
  store { i64, [5 x i64] } %t147, ptr %t150
  %t151 = load ptr, ptr %lp9
  store ptr %t151, ptr %l76, !tbaa !29
  %t152 = icmp sge i64 1, 0
  br i1 %t152, label %bb37, label %bb38
bb37:
  %t154 = icmp sle i64 1, 1152921504606846975
  br i1 %t154, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_96656321f78b9245_710c9f1a5efb4d11)
  unreachable
bb39:
  %t156 = mul i64 1, 8
  %t157 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t156)
  %t158 = load ptr, ptr %l76, !tbaa !29
  store i64 0, ptr %t159
  br label %fill.160
fill.160:
  %t163 = load i64, ptr %t159
  %t164 = icmp slt i64 %t163, 1
  br i1 %t164, label %fillb.161, label %filld.162
fillb.161:
  %t165 = getelementptr ptr, ptr %t157, i64 %t163
  store ptr %t158, ptr %t165
  %t166 = add i64 %t163, 1
  store i64 %t166, ptr %t159
  br label %fill.160
filld.162:
  %t167 = insertvalue { i64, ptr } undef, i64 1, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t157, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t168, ptr %rv
  br label %ret
bb40:
  call void @__olang_check_failed(ptr @olang_loc_96656321f78b9245_710c9f1a5efb4d11)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l6
  br label %bb1
bb1:
  %t11 = load i32, ptr %l6
  %t13 = trunc i64 18 to i32
  %t14 = icmp eq i32 %t11, %t13
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ejoinStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, i64, i64 }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l25 = alloca i32
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca i64
  %l56 = alloca ptr
  %l64 = alloca ptr
  %l67 = alloca i64
  %l70 = alloca i64
  %l74 = alloca { i64, i64, i64 }
  %l90 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l105 = alloca ptr
  %l107 = alloca ptr
  %l110 = alloca i64
  %l112 = alloca i64
  %l114 = alloca ptr
  %l117 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i32
  %l125 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i32
  %l132 = alloca ptr
  %l133 = alloca %"compiler/source:Span"
  %l134 = alloca %"compiler/msgs:Msg"
  %l135 = alloca i64
  %l136 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l140 = alloca i64
  %l144 = alloca i64
  %l147 = alloca i64
  %l168 = alloca i32
  %l170 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca i32
  %l183 = alloca { i64, ptr }
  %l203 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l209 = alloca i1
  %l214 = alloca i64
  %l216 = alloca ptr
  %l219 = alloca { i64, ptr }
  %l221 = alloca %"compiler/source:Span"
  %l222 = alloca %"compiler/msgs:Msg"
  %l223 = alloca i64
  %l227 = alloca i64
  %l229 = alloca i1
  %l234 = alloca ptr
  %l235 = alloca %"compiler/source:Span"
  %l236 = alloca %"compiler/msgs:Msg"
  %l237 = alloca i64
  %l240 = alloca i64
  %l242 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca i32
  %l255 = alloca { i64, ptr }
  %l268 = alloca i64
  %l286 = alloca { i64, ptr }
  %l289 = alloca ptr
  %l293 = alloca ptr
  %l301 = alloca i64
  %l305 = alloca i64
  %l308 = alloca i64
  %l329 = alloca ptr
  %l333 = alloca i1
  %l337 = alloca ptr
  %l343 = alloca i1
  %l345 = alloca ptr
  %l348 = alloca { i64, ptr }
  %l351 = alloca %"compiler/source:Span"
  %l352 = alloca %"compiler/msgs:Msg"
  %l353 = alloca i64
  %l360 = alloca i64
  %l361 = alloca i64
  %l364 = alloca { i64, ptr }
  %l365 = alloca i64
  %l366 = alloca i32
  %l367 = alloca ptr
  %l377 = alloca %"compiler/source:Span"
  %l381 = alloca i64
  %l383 = alloca ptr
  %l384 = alloca %"compiler/source:Span"
  %l385 = alloca ptr
  %l387 = alloca i32
  %l388 = alloca { i64, ptr }
  %l390 = alloca %"compiler/msgs:Msg"
  %l391 = alloca i64
  %l394 = alloca ptr
  %l395 = alloca %"compiler/source:Span"
  %l396 = alloca ptr
  %l398 = alloca i1
  %l400 = alloca { i64, ptr }
  %l401 = alloca %"compiler/typed:Join"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s31 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s35 = alloca %olang.scope
  %t715 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l56
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l56, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 30
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 38
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t15 = load ptr, ptr %l3, !tbaa !29
  %t17 = getelementptr %"compiler/check:frame", ptr %t15, i32 0, i32 35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t17, i64 0)
  br label %bb2
bb2:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 36
  store ptr %t21, ptr %l64, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 37
  %t26 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t24)
  store i64 %t26, ptr %l67
  br label %bb3
bb3:
  %t27 = load ptr, ptr %l64, !tbaa !29
  %t28 = load i64, ptr %l67, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t27, i64 %t28)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 32
  %t33 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t31)
  store i64 %t33, ptr %l70
  br label %bb5
bb5:
  %t34 = load i64, ptr %l70, !tbaa !24
  store i64 %t34, ptr %l6, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l1
  %t40 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t35, i32 5, %"compiler/source:Span" %t36)
  store { i64, i64, i64 } %t40, ptr %l74
  br label %bb6
bb6:
  %t41 = load { i64, i64, i64 }, ptr %l74
  store { i64, i64, i64 } %t41, ptr %l7
  %t42 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 0
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  %t45 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t48 = getelementptr { i64, i64, i64 }, ptr %l7, i32 0, i32 2
  %t49 = load i64, ptr %t48, !tbaa !24
  store i64 %t49, ptr %l10, !tbaa !24
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr %"compiler/ast:JoinS", ptr %t51, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t58 = icmp sgt i64 %t56, 0
  br i1 %t58, label %bb7, label %bb8
bb7:
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/ast:JoinS", ptr %t60, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  store i64 %t67, ptr %l13, !tbaa !24
  br label %bb9
bb8:
  br label %bb16
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l12, !tbaa !24
  %t70 = load i64, ptr %l13, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t77 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t77, ptr %l90, !tbaa !27
  %t78 = load i64, ptr %l12, !tbaa !24
  %t80 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr ptr, ptr %t81, i64 %t78
  %t83 = load ptr, ptr %t82, !tbaa !39
  %t85 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t85, ptr %t83)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb14:
  %t90 = load i64, ptr %l12, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l12, !tbaa !24
  br label %bb9
bb15:
  br label %bb16
bb16:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = load i64, ptr %l10, !tbaa !24
  %t98 = load i64, ptr %l6, !tbaa !24
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t94, i64 %t95, i64 %t96, i64 %t97, i64 %t98)
  store ptr %t104, ptr %l103
  br label %bb17
bb17:
  %t105 = load ptr, ptr %l103, !tbaa !29
  store ptr %t105, ptr %l15, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t106)
  store ptr %t108, ptr %l105
  br label %bb18
bb18:
  %t109 = load ptr, ptr %l105, !tbaa !29
  store ptr %t109, ptr %l3, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 35
  store ptr %t112, ptr %l107, !tbaa !29
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/check:frame", ptr %t113, i32 0, i32 35
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l110
  br label %bb19
bb19:
  %t118 = load i64, ptr %l110, !tbaa !24
  %t119 = sub i64 %t118, 1
  %t120 = load ptr, ptr %l107, !tbaa !29
  %t122 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t120, i64 %t119)
  store i64 %t122, ptr %l112
  br label %bb20
bb20:
  %t123 = load i64, ptr %l112, !tbaa !24
  store i64 %t123, ptr %l16, !tbaa !24
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = getelementptr %"compiler/check:frame", ptr %t124, i32 0, i32 36
  store ptr %t126, ptr %l114, !tbaa !29
  %t127 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/check:frame", ptr %t127, i32 0, i32 36
  %t131 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t129)
  store i64 %t131, ptr %l117
  br label %bb21
bb21:
  %t132 = load i64, ptr %l117, !tbaa !24
  %t133 = sub i64 %t132, 1
  %t134 = load ptr, ptr %l114, !tbaa !29
  %t136 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t134, i64 %t133)
  store i64 %t136, ptr %l119
  br label %bb22
bb22:
  %t137 = load i64, ptr %l119, !tbaa !24
  store i64 %t137, ptr %l17, !tbaa !24
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = getelementptr %"compiler/check:frame", ptr %t138, i32 0, i32 35
  %t142 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t140)
  %t143 = extractvalue { i32, i64 } %t142, 1
  %t144 = extractvalue { i32, i64 } %t142, 0
  store i32 %t144, ptr %l124
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb24, label %ok.146
ok.146:
  store i64 %t143, ptr %l123
  br label %bb23
bb23:
  %t147 = load i64, ptr %l123, !tbaa !24
  store i64 %t147, ptr %l120, !tbaa !24
  br label %bb26
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = getelementptr %"compiler/check:frame", ptr %t148, i32 0, i32 36
  %t152 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t150)
  %t153 = extractvalue { i32, i64 } %t152, 1
  %t154 = extractvalue { i32, i64 } %t152, 0
  store i32 %t154, ptr %l129
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb28, label %ok.156
ok.156:
  store i64 %t153, ptr %l128
  br label %bb27
bb27:
  %t157 = load i64, ptr %l128, !tbaa !24
  store i64 %t157, ptr %l125, !tbaa !24
  br label %bb30
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t158 = load i64, ptr %l16, !tbaa !24
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l132, !tbaa !29
  %t163 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t163, ptr %l133
  %t164 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %s7)
  store %"compiler/msgs:Msg" %t164, ptr %l134
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t165 = load ptr, ptr %l132, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l133
  %t167 = load %"compiler/msgs:Msg", ptr %l134
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t165, %"compiler/source:Span" %t166, %"compiler/msgs:Msg" %t167)
  store i64 %t168, ptr %l135
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s7)
  br label %bb35
bb35:
  %t169 = load ptr, ptr @__olang_prog_scope
  %t170 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t169)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %l136
  br label %bb36
bb36:
  %t171 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l136
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t171, ptr %l18
  %t172 = load i64, ptr %l17, !tbaa !24
  store i64 %t172, ptr %l19, !tbaa !24
  %t174 = load ptr, ptr %l3, !tbaa !29
  %t176 = getelementptr %"compiler/check:frame", ptr %t174, i32 0, i32 37
  %t178 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t176)
  store i64 %t178, ptr %l140
  br label %bb37
bb37:
  %t179 = load i64, ptr %l140, !tbaa !24
  store i64 %t179, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t180 = load i64, ptr %l20, !tbaa !24
  %t181 = load i64, ptr %l19, !tbaa !24
  %t184 = icmp sgt i64 %t180, %t181
  br i1 %t184, label %bb38, label %bb39
bb38:
  %t186 = load i64, ptr %l21, !tbaa !24
  %t188 = icmp sgt i64 %t186, 0
  br i1 %t188, label %bb40, label %bb41
bb39:
  store i64 0, ptr %l144, !tbaa !24
  br label %bb43
bb40:
  %t190 = load i64, ptr %l20, !tbaa !24
  %t191 = load i64, ptr %l19, !tbaa !24
  %t194 = sub i64 %t190, %t191
  %t195 = load i64, ptr %l21, !tbaa !24
  %t198 = add i64 %t194, %t195
  %t200 = sub i64 %t198, 1
  %t201 = load i64, ptr %l21, !tbaa !24
  %t204 = sdiv i64 %t200, %t201
  store i64 %t204, ptr %l147, !tbaa !24
  br label %bb42
bb41:
  store i64 0, ptr %l147, !tbaa !24
  br label %bb42
bb42:
  %t206 = load i64, ptr %l147, !tbaa !24
  store i64 %t206, ptr %l144, !tbaa !24
  br label %bb43
bb43:
  %t207 = load i64, ptr %l144, !tbaa !24
  store i64 %t207, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t208 = load i64, ptr %l23, !tbaa !24
  %t209 = load i64, ptr %l22, !tbaa !24
  %t212 = icmp slt i64 %t208, %t209
  %t214 = xor i1 %t212, true
  br i1 %t214, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb46:
  br label %bb47
bb47:
  %t216 = load i64, ptr %l19, !tbaa !24
  %t217 = load i64, ptr %l23, !tbaa !24
  %t218 = load i64, ptr %l21, !tbaa !24
  %t221 = mul i64 %t217, %t218
  %t224 = add i64 %t216, %t221
  %t226 = load ptr, ptr %l3, !tbaa !29
  %t228 = getelementptr %"compiler/check:frame", ptr %t226, i32 0, i32 37
  %t232 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t228, i64 %t224)
  store i32 %t232, ptr %l168
  br label %bb48
bb48:
  %t233 = load i32, ptr %l168, !tbaa !23
  store i32 %t233, ptr %l25, !tbaa !23
  store i1 false, ptr %l26, !tbaa !21
  store ptr %l18, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t235 = load ptr, ptr %l27, !tbaa !29
  %t236 = load i64, ptr %l28, !tbaa !24
  %t239 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s0, ptr %t235, i64 %t236)
  %t240 = extractvalue { i32, { i64, ptr } } %t239, 1
  %t241 = extractvalue { i32, { i64, ptr } } %t239, 0
  store i32 %t241, ptr %l174
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb51, label %ok.243
ok.243:
  store { i64, ptr } %t240, ptr %l173
  br label %bb50
bb50:
  %t244 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t244, ptr %l170, !tbaa !27
  br label %bb55
bb51:
  %t245 = load i32, ptr %l174, !tbaa !23
  %t246 = ashr i32 %t245, 16
  %t248 = icmp eq i32 %t246, 1
  br i1 %t248, label %bb52, label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_55f84e4449673261_62da473350726dd5)
  unreachable
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb66
bb55:
  %t250 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t250, ptr %l29, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t251, 0
  store i64 %t253, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s12
  %t255 = load i64, ptr %l31, !tbaa !24
  %t256 = load i64, ptr %l30, !tbaa !24
  %t259 = icmp slt i64 %t255, %t256
  %t261 = xor i1 %t259, true
  br i1 %t261, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb58:
  br label %bb59
bb59:
  %t263 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t263, ptr %l183, !tbaa !27
  %t264 = load i64, ptr %l31, !tbaa !24
  %t266 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !27
  %t268 = getelementptr i32, ptr %t267, i64 %t264
  %t269 = load i32, ptr %t268, !tbaa !33
  %t272 = load i32, ptr %l25, !tbaa !23
  %t275 = icmp eq i32 %t269, %t272
  br i1 %t275, label %bb60, label %bb61
bb60:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb62
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s12)
  br label %bb63
bb63:
  %t277 = load i64, ptr %l31, !tbaa !24
  %t279 = add i64 %t277, 1
  store i64 %t279, ptr %l31, !tbaa !24
  br label %bb56
bb64:
  %t281 = load i64, ptr %l28, !tbaa !24
  %t282 = load i64, ptr %l30, !tbaa !24
  %t285 = add i64 %t281, %t282
  store i64 %t285, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb65:
  br label %bb49
bb66:
  %t287 = load i1, ptr %l26, !tbaa !21
  %t289 = xor i1 %t287, true
  br i1 %t289, label %bb67, label %bb68
bb67:
  %t291 = load i32, ptr %l25, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i32 %t291)
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s9)
  br label %bb71
bb71:
  %t294 = load i64, ptr %l23, !tbaa !24
  %t296 = add i64 %t294, 1
  store i64 %t296, ptr %l23, !tbaa !24
  br label %bb44
bb72:
  %t298 = load ptr, ptr %l3, !tbaa !29
  %t300 = getelementptr %"compiler/check:frame", ptr %t298, i32 0, i32 37
  %t301 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %t300, i64 %t301)
  br label %bb73
bb73:
  %t304 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t304, ptr %l203
  br label %bb74
bb74:
  %t305 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l203
  %t306 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t305, ptr %t306
  store ptr %t306, ptr %l33, !tbaa !29
  %t308 = load ptr, ptr %l2, !tbaa !29
  %t310 = getelementptr %"compiler/ast:JoinS", ptr %t308, i32 0, i32 2
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t315 = icmp sgt i64 %t313, 0
  br i1 %t315, label %bb75, label %bb76
bb75:
  %t317 = load ptr, ptr %l2, !tbaa !29
  %t319 = getelementptr %"compiler/ast:JoinS", ptr %t317, i32 0, i32 0
  %t320 = load i1, ptr %t319, !tbaa !21
  %t322 = xor i1 %t320, true
  store i1 %t322, ptr %l209, !tbaa !21
  br label %bb77
bb76:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb77
bb77:
  %t324 = load i1, ptr %l209, !tbaa !21
  br i1 %t324, label %bb78, label %bb79
bb78:
  %t326 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t326, ptr %l214
  br label %bb80
bb79:
  br label %bb87
bb80:
  %t327 = load i64, ptr %l214, !tbaa !24
  %t328 = icmp eq i64 %t327, 0
  br i1 %t328, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s18
  %t330 = load ptr, ptr %l0, !tbaa !29
  store ptr %t330, ptr %l216, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l2, !tbaa !29
  %t334 = getelementptr %"compiler/ast:JoinS", ptr %t332, i32 0, i32 2
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l219, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr ptr, ptr %t337, i64 0
  %t339 = load ptr, ptr %t338, !tbaa !39
  %t342 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t331, ptr %t339)
  store %"compiler/source:Span" %t342, ptr %l221
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t343 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %s18)
  store %"compiler/msgs:Msg" %t343, ptr %l222
  br label %bb84
bb84:
  %t344 = load ptr, ptr %l216, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l221
  %t346 = load %"compiler/msgs:Msg", ptr %l222
  %t347 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s18, ptr %t344, %"compiler/source:Span" %t345, %"compiler/msgs:Msg" %t346)
  store i64 %t347, ptr %l223
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s18)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t348 = load ptr, ptr %l2, !tbaa !29
  %t350 = getelementptr %"compiler/ast:JoinS", ptr %t348, i32 0, i32 0
  %t351 = load i1, ptr %t350, !tbaa !21
  br i1 %t351, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s19
  %t354 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t354, ptr %l227
  br label %bb90
bb89:
  %t356 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18)
  store i64 %t356, ptr %l381
  br label %bb168
bb90:
  %t357 = load i64, ptr %l227, !tbaa !24
  %t358 = icmp eq i64 %t357, 0
  br i1 %t358, label %bb91, label %bb92
bb91:
  %t360 = load ptr, ptr %l3, !tbaa !29
  %t362 = getelementptr %"compiler/check:frame", ptr %t360, i32 0, i32 38
  %t363 = load i64, ptr %t362, !tbaa !24
  %t364 = load i64, ptr %l5, !tbaa !24
  %t367 = icmp eq i64 %t363, %t364
  store i1 %t367, ptr %l229, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l229, !tbaa !21
  br label %bb93
bb93:
  %t369 = load i1, ptr %l229, !tbaa !21
  br i1 %t369, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s20
  %t370 = load ptr, ptr %l0, !tbaa !29
  store ptr %t370, ptr %l234, !tbaa !29
  %t371 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t371, ptr %l235
  %t372 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %s20)
  store %"compiler/msgs:Msg" %t372, ptr %l236
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t373 = load ptr, ptr %l234, !tbaa !29
  %t374 = load %"compiler/source:Span", ptr %l235
  %t375 = load %"compiler/msgs:Msg", ptr %l236
  %t376 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s20, ptr %t373, %"compiler/source:Span" %t374, %"compiler/msgs:Msg" %t375)
  store i64 %t376, ptr %l237
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s20)
  br label %bb98
bb98:
  %t377 = load ptr, ptr %l3, !tbaa !29
  %t379 = getelementptr %"compiler/check:frame", ptr %t377, i32 0, i32 25
  %t381 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t379)
  store i64 %t381, ptr %l240
  br label %bb99
bb99:
  %t382 = load i64, ptr %l240, !tbaa !24
  store i64 %t382, ptr %l34, !tbaa !24
  store ptr %l18, ptr %l35, !tbaa !29
  store i64 0, ptr %l36, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s22
  %t384 = load ptr, ptr %l35, !tbaa !29
  %t385 = load i64, ptr %l36, !tbaa !24
  %t388 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %s0, ptr %t384, i64 %t385)
  %t389 = extractvalue { i32, { i64, ptr } } %t388, 1
  %t390 = extractvalue { i32, { i64, ptr } } %t388, 0
  store i32 %t390, ptr %l246
  %t391 = icmp ne i32 %t390, 0
  br i1 %t391, label %bb102, label %ok.392
ok.392:
  store { i64, ptr } %t389, ptr %l245
  br label %bb101
bb101:
  %t393 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t393, ptr %l242, !tbaa !27
  br label %bb106
bb102:
  %t394 = load i32, ptr %l246, !tbaa !23
  %t395 = ashr i32 %t394, 16
  %t397 = icmp eq i32 %t395, 1
  br i1 %t397, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_a0600b9a17fc9cd0_1e19997b248853e4)
  unreachable
bb105:
  call void @__olang_scope_close(ptr %s22)
  br label %bb115
bb106:
  %t399 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t399, ptr %l37, !tbaa !27
  %t400 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t400, 0
  store i64 %t402, ptr %l38, !tbaa !24
  store i64 0, ptr %l39, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s23
  %t404 = load i64, ptr %l39, !tbaa !24
  %t405 = load i64, ptr %l38, !tbaa !24
  %t408 = icmp slt i64 %t404, %t405
  %t410 = xor i1 %t408, true
  br i1 %t410, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s23)
  br label %bb113
bb109:
  br label %bb110
bb110:
  %t412 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t412, ptr %l255, !tbaa !27
  %t413 = load i64, ptr %l39, !tbaa !24
  %t415 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr i32, ptr %t416, i64 %t413
  %t418 = load i32, ptr %t417, !tbaa !33
  %t420 = load ptr, ptr %l3, !tbaa !29
  %t422 = getelementptr %"compiler/check:frame", ptr %t420, i32 0, i32 25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t422, i32 %t418)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s23)
  br label %bb112
bb112:
  %t426 = load i64, ptr %l39, !tbaa !24
  %t428 = add i64 %t426, 1
  store i64 %t428, ptr %l39, !tbaa !24
  br label %bb107
bb113:
  %t430 = load i64, ptr %l36, !tbaa !24
  %t431 = load i64, ptr %l38, !tbaa !24
  %t434 = add i64 %t430, %t431
  store i64 %t434, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb114
bb114:
  br label %bb100
bb115:
  %t436 = load ptr, ptr %l3, !tbaa !29
  %t438 = getelementptr %"compiler/check:frame", ptr %t436, i32 0, i32 25
  %t440 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t438)
  store i64 %t440, ptr %l268
  br label %bb116
bb116:
  %t441 = load i64, ptr %l268, !tbaa !24
  store i64 %t441, ptr %l41, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t443 = load ptr, ptr %l2, !tbaa !29
  %t445 = getelementptr %"compiler/ast:JoinS", ptr %t443, i32 0, i32 2
  %t446 = load { i64, ptr }, ptr %t445, !tbaa !27
  %t447 = load i64, ptr %l34, !tbaa !24
  %t448 = load i64, ptr %l41, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %t442, { i64, ptr } %t446, i64 %t447, i64 %t448)
  br label %bb117
bb117:
  %t453 = load ptr, ptr %l2, !tbaa !29
  %t455 = getelementptr %"compiler/ast:JoinS", ptr %t453, i32 0, i32 2
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !27
  %t458 = extractvalue { i64, ptr } %t456, 0
  %t460 = icmp sgt i64 %t458, 0
  br i1 %t460, label %bb118, label %bb119
bb118:
  %t462 = load ptr, ptr %l2, !tbaa !29
  %t464 = getelementptr %"compiler/ast:JoinS", ptr %t462, i32 0, i32 2
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  store { i64, ptr } %t465, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t467, 0
  store i64 %t469, ptr %l44, !tbaa !24
  br label %bb120
bb119:
  br label %bb159
bb120:
  store %olang.scope zeroinitializer, ptr %s27
  %t471 = load i64, ptr %l43, !tbaa !24
  %t472 = load i64, ptr %l44, !tbaa !24
  %t475 = icmp slt i64 %t471, %t472
  %t477 = xor i1 %t475, true
  br i1 %t477, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s27)
  br label %bb127
bb122:
  br label %bb123
bb123:
  %t479 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t479, ptr %l286, !tbaa !27
  %t480 = load i64, ptr %l43, !tbaa !24
  %t482 = getelementptr { i64, ptr }, ptr %l286, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr ptr, ptr %t483, i64 %t480
  %t485 = load ptr, ptr %t484, !tbaa !39
  %t487 = load ptr, ptr %l33, !tbaa !29
  store ptr %t487, ptr %l289, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t494 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %t488, ptr %t485, i32 %t490, i1 false)
  store ptr %t494, ptr %l293
  br label %bb124
bb124:
  %t495 = load ptr, ptr %l289, !tbaa !29
  %t496 = load ptr, ptr %l293, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %v0, ptr %v0, ptr %t495, ptr %t496)
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s27)
  br label %bb126
bb126:
  %t497 = load i64, ptr %l43, !tbaa !24
  %t499 = add i64 %t497, 1
  store i64 %t499, ptr %l43, !tbaa !24
  br label %bb120
bb127:
  %t501 = load ptr, ptr %l3, !tbaa !29
  %t503 = getelementptr %"compiler/check:frame", ptr %t501, i32 0, i32 30
  %t504 = load i64, ptr %t503, !tbaa !24
  %t505 = load i64, ptr %l4, !tbaa !24
  %t508 = icmp sgt i64 %t504, %t505
  br i1 %t508, label %bb128, label %bb129
bb128:
  store i64 0, ptr %l46, !tbaa !24
  %t510 = load ptr, ptr %l33, !tbaa !29
  %t512 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v0, ptr %t510)
  store i64 %t512, ptr %l301
  br label %bb130
bb129:
  br label %bb158
bb130:
  %t513 = load i64, ptr %l301, !tbaa !24
  store i64 %t513, ptr %l47, !tbaa !24
  store i64 1, ptr %l48, !tbaa !24
  %t514 = load i64, ptr %l47, !tbaa !24
  %t515 = load i64, ptr %l46, !tbaa !24
  %t518 = icmp sgt i64 %t514, %t515
  br i1 %t518, label %bb131, label %bb132
bb131:
  %t520 = load i64, ptr %l48, !tbaa !24
  %t522 = icmp sgt i64 %t520, 0
  br i1 %t522, label %bb133, label %bb134
bb132:
  store i64 0, ptr %l305, !tbaa !24
  br label %bb136
bb133:
  %t524 = load i64, ptr %l47, !tbaa !24
  %t525 = load i64, ptr %l46, !tbaa !24
  %t528 = sub i64 %t524, %t525
  %t529 = load i64, ptr %l48, !tbaa !24
  %t532 = add i64 %t528, %t529
  %t534 = sub i64 %t532, 1
  %t535 = load i64, ptr %l48, !tbaa !24
  %t538 = sdiv i64 %t534, %t535
  store i64 %t538, ptr %l308, !tbaa !24
  br label %bb135
bb134:
  store i64 0, ptr %l308, !tbaa !24
  br label %bb135
bb135:
  %t540 = load i64, ptr %l308, !tbaa !24
  store i64 %t540, ptr %l305, !tbaa !24
  br label %bb136
bb136:
  %t541 = load i64, ptr %l305, !tbaa !24
  store i64 %t541, ptr %l49, !tbaa !24
  store i64 0, ptr %l50, !tbaa !24
  br label %bb137
bb137:
  store %olang.scope zeroinitializer, ptr %s31
  %t542 = load i64, ptr %l50, !tbaa !24
  %t543 = load i64, ptr %l49, !tbaa !24
  %t546 = icmp slt i64 %t542, %t543
  %t548 = xor i1 %t546, true
  br i1 %t548, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s31)
  br label %bb157
bb139:
  br label %bb140
bb140:
  %t550 = load i64, ptr %l46, !tbaa !24
  %t551 = load i64, ptr %l50, !tbaa !24
  %t552 = load i64, ptr %l48, !tbaa !24
  %t555 = mul i64 %t551, %t552
  %t558 = add i64 %t550, %t555
  store i64 %t558, ptr %l51, !tbaa !24
  %t560 = load ptr, ptr %l33, !tbaa !29
  %t562 = load i64, ptr %l51, !tbaa !24
  %t565 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v0, ptr %v0, ptr %t560, i64 %t562)
  store ptr %t565, ptr %l329
  br label %bb141
bb141:
  %t566 = load ptr, ptr %l329, !tbaa !29
  %t568 = getelementptr %"compiler/typed:Clause", ptr %t566, i32 0, i32 3
  %t569 = load ptr, ptr %t568, !tbaa !29
  %t571 = icmp eq ptr %t569, null
  br i1 %t571, label %bb142, label %bb143
bb142:
  store i1 true, ptr %l333, !tbaa !21
  br label %bb149
bb143:
  %t573 = load ptr, ptr %l33, !tbaa !29
  %t575 = load i64, ptr %l51, !tbaa !24
  %t578 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v0, ptr %v0, ptr %t573, i64 %t575)
  store ptr %t578, ptr %l337
  br label %bb144
bb144:
  %t579 = load ptr, ptr %l337, !tbaa !29
  %t581 = getelementptr %"compiler/typed:Clause", ptr %t579, i32 0, i32 3
  %t582 = load ptr, ptr %t581, !tbaa !29
  store ptr %t582, ptr %l52, !tbaa !29
  %t584 = load ptr, ptr %l52, !tbaa !29
  %t586 = icmp eq ptr %t584, null
  br i1 %t586, label %bb145, label %bb146
bb145:
  call void @__olang_check_failed(ptr @olang_loc_3aadc4e023da3b64_af78beb3670ebce8)
  unreachable
bb146:
  br label %bb147
bb147:
  %t588 = load ptr, ptr %l52, !tbaa !29
  %t590 = call i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %t588)
  store i1 %t590, ptr %l343
  br label %bb148
bb148:
  %t591 = load i1, ptr %l343, !tbaa !21
  %t592 = xor i1 %t591, true
  store i1 %t592, ptr %l333, !tbaa !21
  br label %bb149
bb149:
  %t594 = load i1, ptr %l333, !tbaa !21
  br i1 %t594, label %bb150, label %bb151
bb150:
  store %olang.scope zeroinitializer, ptr %s32
  %t595 = load ptr, ptr %l0, !tbaa !29
  store ptr %t595, ptr %l345, !tbaa !29
  %t596 = load ptr, ptr %l0, !tbaa !29
  %t597 = load ptr, ptr %l2, !tbaa !29
  %t599 = getelementptr %"compiler/ast:JoinS", ptr %t597, i32 0, i32 2
  %t600 = load { i64, ptr }, ptr %t599, !tbaa !27
  store { i64, ptr } %t600, ptr %l348, !tbaa !27
  %t601 = load i64, ptr %l51, !tbaa !24
  %t603 = getelementptr { i64, ptr }, ptr %l348, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !27
  %t605 = getelementptr ptr, ptr %t604, i64 %t601
  %t606 = load ptr, ptr %t605, !tbaa !39
  %t609 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %t596, ptr %t606)
  store %"compiler/source:Span" %t609, ptr %l351
  br label %bb152
bb151:
  br label %bb155
bb152:
  %t610 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %s32)
  store %"compiler/msgs:Msg" %t610, ptr %l352
  br label %bb153
bb153:
  %t611 = load ptr, ptr %l345, !tbaa !29
  %t612 = load %"compiler/source:Span", ptr %l351
  %t613 = load %"compiler/msgs:Msg", ptr %l352
  %t614 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s32, ptr %t611, %"compiler/source:Span" %t612, %"compiler/msgs:Msg" %t613)
  store i64 %t614, ptr %l353
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s32)
  call void @__olang_scope_close(ptr %s31)
  br label %bb157
bb155:
  call void @__olang_scope_close(ptr %s31)
  br label %bb156
bb156:
  %t615 = load i64, ptr %l50, !tbaa !24
  %t617 = add i64 %t615, 1
  store i64 %t617, ptr %l50, !tbaa !24
  br label %bb137
bb157:
  br label %bb158
bb158:
  br label %bb159
bb159:
  %t619 = load ptr, ptr %l0, !tbaa !29
  %t620 = load i64, ptr %l34, !tbaa !24
  %t621 = load i64, ptr %l41, !tbaa !24
  %t622 = load ptr, ptr %l33, !tbaa !29
  %t627 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v0, ptr %t619, i64 %t620, i64 %t621, ptr %t622)
  store i64 %t627, ptr %l360
  br label %bb160
bb160:
  %t628 = load i64, ptr %l360, !tbaa !24
  store i64 %t628, ptr %l53, !tbaa !24
  %t629 = load ptr, ptr %l0, !tbaa !29
  %t630 = load %"compiler/source:Span", ptr %l1
  %t633 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t629, %"compiler/source:Span" %t630)
  store { i64, ptr } %t633, ptr %l364
  br label %bb161
bb161:
  %t634 = load { i64, ptr }, ptr %l364, !tbaa !27
  %t635 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s19, { i64, ptr } %t634, { i64, ptr } { i64 4, ptr @.d23 })
  %t636 = extractvalue { i32, i64 } %t635, 1
  %t637 = extractvalue { i32, i64 } %t635, 0
  store i32 %t637, ptr %l366
  %t638 = icmp ne i32 %t637, 0
  br i1 %t638, label %bb163, label %ok.639
ok.639:
  store i64 %t636, ptr %l365
  br label %bb162
bb162:
  %t640 = load i64, ptr %l365, !tbaa !24
  store i64 %t640, ptr %l361, !tbaa !24
  br label %bb165
bb163:
  br label %bb164
bb164:
  store i64 0, ptr %l361, !tbaa !24
  br label %bb165
bb165:
  %t641 = load i64, ptr %l361, !tbaa !24
  store i64 %t641, ptr %l54, !tbaa !24
  %t642 = load ptr, ptr %l0, !tbaa !29
  store ptr %t642, ptr %l367, !tbaa !29
  %t643 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t644 = load i32, ptr %t643, !tbaa !23
  %t645 = load i64, ptr %l54, !tbaa !24
  %t647 = trunc i64 %t645 to i32
  %t650 = add i32 %t644, %t647
  %t651 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t652 = load i32, ptr %t651, !tbaa !23
  %t653 = load i64, ptr %l54, !tbaa !24
  %t655 = trunc i64 %t653 to i32
  %t658 = add i32 %t652, %t655
  %t660 = add i32 %t658, 4
  %t663 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s19, i32 %t650, i32 %t660)
  store %"compiler/source:Span" %t663, ptr %l377
  br label %bb166
bb166:
  %t664 = load i64, ptr %l34, !tbaa !24
  %t665 = load i64, ptr %l53, !tbaa !24
  %t666 = load ptr, ptr %l367, !tbaa !29
  %t667 = load %"compiler/source:Span", ptr %l377
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %t666, %"compiler/source:Span" %t667, i64 %t664, i64 %t665, i1 false)
  br label %bb167
bb167:
  call void @__olang_scope_close(ptr %s19)
  br label %bb176
bb168:
  %t670 = load i64, ptr %l381, !tbaa !24
  %t671 = icmp sgt i64 %t670, 0
  br i1 %t671, label %bb169, label %bb170
bb169:
  store %olang.scope zeroinitializer, ptr %s35
  %t673 = load ptr, ptr %l0, !tbaa !29
  store ptr %t673, ptr %l383, !tbaa !29
  %t674 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t674, ptr %l384
  %t675 = load ptr, ptr %l0, !tbaa !29
  store ptr %t675, ptr %l385, !tbaa !29
  %t677 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l18, i64 0)
  store i32 %t677, ptr %l387
  br label %bb171
bb170:
  br label %bb175
bb171:
  %t678 = load ptr, ptr %l385, !tbaa !29
  %t679 = load i32, ptr %l387, !tbaa !23
  %t680 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s35, ptr %t678, i32 %t679)
  store { i64, ptr } %t680, ptr %l388
  br label %bb172
bb172:
  %t681 = load { i64, ptr }, ptr %l388, !tbaa !27
  %t682 = extractvalue { i64, ptr } %t681, 0
  %t683 = extractvalue { i64, ptr } %t681, 1
  %t684 = mul i64 %t682, 1
  %t685 = call ptr @__olang_scope_alloc(ptr %s35, i64 %t684)
  call void @llvm.memcpy.p0.p0.i64(ptr %t685, ptr %t683, i64 %t684, i1 false)
  %t686 = insertvalue { i64, ptr } undef, i64 %t682, 0
  %t687 = insertvalue { i64, ptr } %t686, ptr %t685, 1
  %t689 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %s35, ptr %s35, { i64, ptr } %t687)
  store %"compiler/msgs:Msg" %t689, ptr %l390
  br label %bb173
bb173:
  %t690 = load ptr, ptr %l383, !tbaa !29
  %t691 = load %"compiler/source:Span", ptr %l384
  %t692 = load %"compiler/msgs:Msg", ptr %l390
  %t693 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s35, ptr %t690, %"compiler/source:Span" %t691, %"compiler/msgs:Msg" %t692)
  store i64 %t693, ptr %l391
  br label %bb174
bb174:
  call void @__olang_scope_close(ptr %s35)
  br label %bb175
bb175:
  br label %bb176
bb176:
  %t694 = load ptr, ptr %l3, !tbaa !29
  %t695 = load i64, ptr %l4, !tbaa !24
  %t698 = getelementptr %"compiler/check:frame", ptr %t694, i32 0, i32 30
  store i64 %t695, ptr %t698, !tbaa !24
  %t699 = load ptr, ptr %l0, !tbaa !29
  store ptr %t699, ptr %l394, !tbaa !29
  %t700 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t700, ptr %l395
  %t701 = load ptr, ptr %l15, !tbaa !29
  store ptr %t701, ptr %l396, !tbaa !29
  %t702 = load ptr, ptr %l2, !tbaa !29
  %t704 = getelementptr %"compiler/ast:JoinS", ptr %t702, i32 0, i32 0
  %t705 = load i1, ptr %t704, !tbaa !21
  store i1 %t705, ptr %l398, !tbaa !21
  %t706 = load ptr, ptr %l33, !tbaa !29
  %t708 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eT_H39fa81f2ad510245a68cbacb663c8d87(ptr %v0, ptr %v0, ptr %t706)
  store { i64, ptr } %t708, ptr %l400
  br label %bb177
bb177:
  %t709 = load ptr, ptr %l396, !tbaa !29
  %t710 = load i1, ptr %l398, !tbaa !21
  %t711 = load { i64, ptr }, ptr %l400, !tbaa !27
  %t712 = call %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t709, i1 %t710, { i64, ptr } %t711)
  store %"compiler/typed:Join" %t712, ptr %l401
  br label %bb178
bb178:
  %t713 = load %"compiler/typed:Join", ptr %l401
  %t714 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Join" %t713, ptr %t714
  store { i64, [3 x i64] } zeroinitializer, ptr %t715
  %t716 = getelementptr { i64, [3 x i64] }, ptr %t715, i32 0, i32 0
  store i64 12, ptr %t716
  %t717 = load %"compiler/source:Span", ptr %l395
  %t718 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t717, 0
  %t720 = insertvalue { %"compiler/source:Span", ptr } %t718, ptr %t714, 1
  %t721 = getelementptr { i64, [3 x i64] }, ptr %t715, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t720, ptr %t721
  %t722 = load { i64, [3 x i64] }, ptr %t715
  %t724 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t722, ptr %t724
  %t725 = load ptr, ptr %l394, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t725, ptr %t724)
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca ptr
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i32
  %l28 = alloca i1
  %l29 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca i32
  %lp48 = alloca ptr
  %l53 = alloca ptr
  %l56 = alloca %"compiler/source:Span"
  %l57 = alloca %"compiler/msgs:Msg"
  %l58 = alloca i64
  %l61 = alloca ptr
  %l65 = alloca i1
  %l70 = alloca i32
  %l73 = alloca i32
  %l84 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l92 = alloca i32
  %l93 = alloca { i64, ptr }
  %l100 = alloca i1
  %l105 = alloca ptr
  %l106 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca i64
  %l116 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l119 = alloca i64
  %l122 = alloca ptr
  %l123 = alloca i64
  %l131 = alloca i64
  %l134 = alloca i64
  %l152 = alloca { i64, ptr }
  %l158 = alloca i64
  %l160 = alloca { i64, ptr }
  %l164 = alloca i32
  %l168 = alloca i1
  %l170 = alloca i1
  %l173 = alloca ptr
  %l177 = alloca i32
  %l178 = alloca i32
  %l181 = alloca i1
  %l183 = alloca { i64, ptr }
  %l187 = alloca i1
  %l189 = alloca { i64, ptr }
  %l192 = alloca i32
  %l193 = alloca { i64, ptr }
  %l196 = alloca i32
  %l198 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca ptr
  %l208 = alloca %"compiler/source:Span"
  %l210 = alloca { i64, ptr }
  %l214 = alloca { i64, ptr }
  %l215 = alloca { i64, ptr }
  %l216 = alloca ptr
  %l217 = alloca { i64, ptr }
  %l224 = alloca %"compiler/source:Span"
  %l225 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %l227 = alloca i64
  %l230 = alloca ptr
  %l234 = alloca i1
  %l236 = alloca { i64, ptr }
  %l239 = alloca i1
  %l241 = alloca i1
  %l247 = alloca { i64, ptr }
  %l250 = alloca i1
  %l255 = alloca i1
  %l257 = alloca { i64, ptr }
  %l260 = alloca i1
  %l262 = alloca i1
  %l265 = alloca ptr
  %l269 = alloca i32
  %l271 = alloca { i64, ptr }
  %l274 = alloca i32
  %l275 = alloca i1
  %l277 = alloca { i64, ptr }
  %l283 = alloca ptr
  %l287 = alloca i1
  %l288 = alloca i1
  %l290 = alloca { i64, ptr }
  %l293 = alloca i1
  %l294 = alloca i1
  %l297 = alloca ptr
  %l301 = alloca i32
  %l303 = alloca { i64, ptr }
  %l306 = alloca i32
  %l307 = alloca i1
  %l308 = alloca i1
  %l314 = alloca i64
  %l320 = alloca ptr
  %l321 = alloca { i64, ptr }
  %l324 = alloca %"compiler/source:Span"
  %l327 = alloca { i64, ptr }
  %l329 = alloca %"compiler/msgs:Msg"
  %l330 = alloca i64
  %l333 = alloca ptr
  %l337 = alloca i1
  %l339 = alloca { i64, ptr }
  %l342 = alloca i1
  %l345 = alloca { i64, ptr }
  %l348 = alloca ptr
  %l349 = alloca { i64, ptr }
  %l352 = alloca %"compiler/source:Span"
  %l354 = alloca { i64, ptr }
  %l358 = alloca { i64, ptr }
  %l360 = alloca %"compiler/msgs:Msg"
  %l361 = alloca i64
  %l364 = alloca ptr
  %l376 = alloca i64
  %l385 = alloca i64
  %l388 = alloca i64
  %l406 = alloca i64
  %l410 = alloca { i64, ptr }
  %l414 = alloca i32
  %l420 = alloca i32
  %l424 = alloca ptr
  %l429 = alloca i32
  %l430 = alloca i32
  %l434 = alloca i1
  %l435 = alloca ptr
  %l440 = alloca i32
  %l441 = alloca i1
  %l447 = alloca i32
  %l452 = alloca i1
  %l458 = alloca i1
  %l465 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l482 = alloca { i64, ptr }
  %l485 = alloca ptr
  %l487 = alloca ptr
  %l489 = alloca ptr
  %l493 = alloca i32
  %l498 = alloca ptr
  %l500 = alloca { i64, ptr }
  %l501 = alloca i32
  %l509 = alloca i32
  %l513 = alloca i32
  %l518 = alloca i32
  %l523 = alloca i32
  %l525 = alloca ptr
  %l528 = alloca i64
  %l530 = alloca ptr
  %l535 = alloca { i64, [2 x i64] }
  %l543 = alloca i32
  %l547 = alloca i64
  %l557 = alloca ptr
  %l568 = alloca ptr
  %l571 = alloca i32
  %l576 = alloca i64
  %l579 = alloca i64
  %l598 = alloca { i64, ptr }
  %l602 = alloca { i64, ptr }
  %l609 = alloca { i64, ptr }
  %l613 = alloca { i64, ptr }
  %l620 = alloca { i64, ptr }
  %l625 = alloca i1
  %l629 = alloca ptr
  %l631 = alloca ptr
  %l633 = alloca ptr
  %l636 = alloca { i64, ptr }
  %l641 = alloca ptr
  %l643 = alloca ptr
  %l655 = alloca ptr
  %l656 = alloca ptr
  %l659 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l661 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l663 = alloca i32
  %l671 = alloca i32
  %l673 = alloca ptr
  %l679 = alloca i1
  %l681 = alloca ptr
  %l685 = alloca i1
  %l688 = alloca i1
  %l690 = alloca ptr
  %l691 = alloca %"compiler/source:Span"
  %l694 = alloca { i64, ptr }
  %l696 = alloca %"compiler/msgs:Msg"
  %l697 = alloca i64
  %l699 = alloca ptr
  %l702 = alloca { i64, ptr }
  %l708 = alloca ptr
  %l709 = alloca i64
  %l712 = alloca { i64, [3 x i64] }
  %l713 = alloca %"compiler/check:roFn"
  %l717 = alloca i32
  %l720 = alloca ptr
  %l721 = alloca i32
  %l726 = alloca i64
  %l727 = alloca i32
  %l730 = alloca ptr
  %l731 = alloca i32
  %l736 = alloca i64
  %l737 = alloca i32
  %l738 = alloca %"compiler/source:Span"
  %l739 = alloca i32
  %l742 = alloca i32
  %l743 = alloca { i64, ptr }
  %l747 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %s36 = alloca %olang.scope
  %s37 = alloca %olang.scope
  %rv = alloca ptr
  %t1105 = alloca { i64, [2 x i64] }, align 8
  %t1571 = alloca { i64, [4 x i64] }, align 8
  %t1583 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 3
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/ast:Sig", ptr %t4, i32 0, i32 4
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l53, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load %"compiler/source:Span", ptr %l1
  %t14 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %t10, %"compiler/source:Span" %t11)
  store %"compiler/source:Span" %t14, ptr %l56
  br label %bb3
bb2:
  br label %bb7
bb3:
  %t15 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %s1, ptr %s1, { i64, ptr } { i64 8, ptr @.d24 })
  store %"compiler/msgs:Msg" %t15, ptr %l57
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l53, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l56
  %t18 = load %"compiler/msgs:Msg", ptr %l57
  %t19 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t16, %"compiler/source:Span" %t17, %"compiler/msgs:Msg" %t18)
  store i64 %t19, ptr %l58
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t20, %"compiler/source:Span" %t21)
  store ptr %t24, ptr %l61
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load ptr, ptr %l61, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb7:
  %t26 = load i32, ptr %l3, !tbaa !23
  %t27 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t30 = icmp ne i32 %t26, %t27
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l3, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l70
  br label %bb10
bb9:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb11
bb10:
  %t42 = load i32, ptr %l70
  %t44 = trunc i64 21 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l65, !tbaa !21
  br label %bb11
bb11:
  %t47 = load i1, ptr %l65, !tbaa !21
  br i1 %t47, label %bb12, label %bb13
bb12:
  %t48 = load i32, ptr %l3, !tbaa !23
  store i32 %t48, ptr %l73, !tbaa !23
  br label %bb14
bb13:
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t50, ptr %l73, !tbaa !23
  br label %bb14
bb14:
  %t52 = load i32, ptr %l73, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l2, !tbaa !29
  %t55 = getelementptr %"compiler/ast:Func", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/ast:Sig", ptr %t56, i32 0, i32 0
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  store { i64, ptr } %t59, ptr %l5, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 0
  store i64 %t63, ptr %l6, !tbaa !24
  %t65 = load i32, ptr %l4, !tbaa !23
  %t66 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t69 = icmp ne i32 %t65, %t66
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l87, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l4, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l92
  br label %bb17
bb16:
  %t88 = load ptr, ptr @__olang_prog_scope
  %t89 = call ptr @__olang_scope_alloc(ptr %t88, i64 0)
  store [0 x i32] zeroinitializer, ptr %t89
  %t90 = insertvalue { i64, ptr } undef, i64 0, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 4
  %t96 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l84, !tbaa !27
  br label %bb19
bb17:
  %t100 = load ptr, ptr %l87, !tbaa !29
  %t101 = load i32, ptr %l92, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t100, i32 %t101)
  store { i64, ptr } %t102, ptr %l93
  br label %bb18
bb18:
  %t103 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t103, ptr %l84, !tbaa !27
  br label %bb19
bb19:
  %t104 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t104, ptr %l7, !tbaa !27
  %t105 = load i32, ptr %l4, !tbaa !23
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t109 = icmp ne i32 %t105, %t106
  br i1 %t109, label %bb20, label %bb21
bb20:
  %t111 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = load i64, ptr %l6, !tbaa !24
  %t117 = icmp ne i64 %t113, %t114
  store i1 %t117, ptr %l100, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l100, !tbaa !21
  br label %bb22
bb22:
  %t119 = load i1, ptr %l100, !tbaa !21
  br i1 %t119, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s2
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l105, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t121, ptr %l106
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i32, ptr %l4, !tbaa !23
  %t126 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t122, i32 %t123)
  store { i64, ptr } %t126, ptr %l109
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t127 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 0
  %t129 = extractvalue { i64, ptr } %t127, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  store { i64, ptr } %t133, ptr %l110, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l112, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t141 = icmp eq i64 %t139, 1
  br i1 %t141, label %bb26, label %bb27
bb26:
  store { i64, ptr } { i64 0, ptr @.d25 }, ptr %l116, !tbaa !27
  br label %bb28
bb27:
  store { i64, ptr } { i64 1, ptr @.d26 }, ptr %l116, !tbaa !27
  br label %bb28
bb28:
  %t143 = load i64, ptr %l6, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t145 = load i64, ptr %l112, !tbaa !24
  %t146 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t148 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t144, i64 %t145, { i64, ptr } %t146, i64 %t143)
  store %"compiler/msgs:Msg" %t148, ptr %l118
  br label %bb29
bb29:
  %t149 = load ptr, ptr %l105, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l106
  %t151 = load %"compiler/msgs:Msg", ptr %l118
  %t152 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t149, %"compiler/source:Span" %t150, %"compiler/msgs:Msg" %t151)
  store i64 %t152, ptr %l119
  br label %bb30
bb30:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load %"compiler/source:Span", ptr %l1
  %t157 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t153, %"compiler/source:Span" %t154)
  store ptr %t157, ptr %l122
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t158 = load ptr, ptr %l122, !tbaa !29
  store ptr %t158, ptr %rv
  br label %ret
bb32:
  %t159 = load i64, ptr %l6, !tbaa !24
  store i64 %t159, ptr %l123, !tbaa !24
  %t160 = load i64, ptr %l123, !tbaa !24
  %t161 = icmp sge i64 %t160, 0
  br i1 %t161, label %bb33, label %bb34
bb33:
  %t163 = load i64, ptr %l123, !tbaa !24
  %t164 = icmp sle i64 %t163, 2305843009213693951
  br i1 %t164, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_d264b31a2a0953e1_a8a3a5518784125d)
  unreachable
bb35:
  %t166 = load i64, ptr %l123, !tbaa !24
  %t167 = mul i64 %t166, 4
  %t168 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t167)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t172 = load i64, ptr %l6, !tbaa !24
  store i64 %t172, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t175 = load i64, ptr %l9, !tbaa !24
  %t178 = icmp sgt i64 %t174, %t175
  br i1 %t178, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d264b31a2a0953e1_a8a3a5518784125d)
  unreachable
bb37:
  %t180 = load i64, ptr %l11, !tbaa !24
  %t182 = icmp sgt i64 %t180, 0
  br i1 %t182, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l131, !tbaa !24
  br label %bb42
bb39:
  %t184 = load i64, ptr %l10, !tbaa !24
  %t185 = load i64, ptr %l9, !tbaa !24
  %t188 = sub i64 %t184, %t185
  %t189 = load i64, ptr %l11, !tbaa !24
  %t192 = add i64 %t188, %t189
  %t194 = sub i64 %t192, 1
  %t195 = load i64, ptr %l11, !tbaa !24
  %t198 = sdiv i64 %t194, %t195
  store i64 %t198, ptr %l134, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l134, !tbaa !24
  br label %bb41
bb41:
  %t200 = load i64, ptr %l134, !tbaa !24
  store i64 %t200, ptr %l131, !tbaa !24
  br label %bb42
bb42:
  %t201 = load i64, ptr %l131, !tbaa !24
  store i64 %t201, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s4
  %t202 = load i64, ptr %l13, !tbaa !24
  %t203 = load i64, ptr %l12, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s4)
  br label %bb133
bb45:
  br label %bb46
bb46:
  %t210 = load i64, ptr %l9, !tbaa !24
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l11, !tbaa !24
  %t215 = mul i64 %t211, %t212
  %t218 = add i64 %t210, %t215
  store i64 %t218, ptr %l14, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t220, ptr %l152, !tbaa !27
  %t221 = load i64, ptr %l14, !tbaa !24
  %t223 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !27
  %t225 = getelementptr ptr, ptr %t224, i64 %t221
  %t226 = load ptr, ptr %t225, !tbaa !39
  %t228 = getelementptr %"compiler/ast:Param", ptr %t226, i32 0, i32 2
  %t229 = load ptr, ptr %t228, !tbaa !29
  %t231 = icmp eq ptr %t229, null
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb47, label %bb48
bb47:
  %t235 = load i64, ptr %l14, !tbaa !24
  store i64 %t235, ptr %l158, !tbaa !24
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t237, ptr %l160, !tbaa !27
  %t238 = load i64, ptr %l14, !tbaa !24
  %t240 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !27
  %t242 = getelementptr ptr, ptr %t241, i64 %t238
  %t243 = load ptr, ptr %t242, !tbaa !39
  %t245 = getelementptr %"compiler/ast:Param", ptr %t243, i32 0, i32 2
  %t246 = load ptr, ptr %t245, !tbaa !29
  %t249 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t236, ptr %t246)
  store i32 %t249, ptr %l164
  br label %bb49
bb48:
  %t250 = load i32, ptr %l4, !tbaa !23
  %t251 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t254 = icmp ne i32 %t250, %t251
  br i1 %t254, label %bb120, label %bb121
bb49:
  %t256 = load i32, ptr %l164, !tbaa !23
  %t257 = load i64, ptr %l158, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i32, ptr %t259, i64 %t257
  store i32 %t256, ptr %t260, !tbaa !33
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t262 = load i64, ptr %l14, !tbaa !24
  %t264 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t265 = load ptr, ptr %t264, !tbaa !27
  %t266 = getelementptr i32, ptr %t265, i64 %t262
  %t267 = load i32, ptr %t266, !tbaa !33
  %t270 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t261, i32 %t267)
  store i1 %t270, ptr %l168
  br label %bb50
bb50:
  %t271 = load i1, ptr %l168, !tbaa !21
  %t272 = xor i1 %t271, true
  br i1 %t272, label %bb51, label %bb52
bb51:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t276 = getelementptr %"compiler/check:Checker", ptr %t274, i32 0, i32 1
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/generic:Program", ptr %t277, i32 0, i32 2
  store ptr %t279, ptr %l173, !tbaa !29
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i64, ptr %l14, !tbaa !24
  %t283 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !27
  %t285 = getelementptr i32, ptr %t284, i64 %t281
  %t286 = load i32, ptr %t285, !tbaa !33
  %t289 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t280, i32 %t286)
  store i32 %t289, ptr %l177
  br label %bb53
bb52:
  store i1 false, ptr %l170, !tbaa !21
  br label %bb55
bb53:
  %t290 = load ptr, ptr %l173, !tbaa !29
  %t291 = load i32, ptr %l177, !tbaa !23
  %t292 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t290, i32 %t291)
  store i32 %t292, ptr %l178
  br label %bb54
bb54:
  %t293 = load i32, ptr %l178
  %t295 = trunc i64 19 to i32
  %t296 = icmp eq i32 %t293, %t295
  store i1 %t296, ptr %l170, !tbaa !21
  br label %bb55
bb55:
  %t298 = load i1, ptr %l170, !tbaa !21
  br i1 %t298, label %bb56, label %bb57
bb56:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t300, ptr %l183, !tbaa !27
  %t301 = load i64, ptr %l14, !tbaa !24
  %t303 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !27
  %t305 = getelementptr ptr, ptr %t304, i64 %t301
  %t306 = load ptr, ptr %t305, !tbaa !39
  %t308 = getelementptr %"compiler/ast:Param", ptr %t306, i32 0, i32 2
  %t309 = load ptr, ptr %t308, !tbaa !29
  %t312 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t299, ptr %t309)
  store i1 %t312, ptr %l187
  br label %bb58
bb57:
  store i1 false, ptr %l181, !tbaa !21
  br label %bb59
bb58:
  %t313 = load i1, ptr %l187, !tbaa !21
  %t314 = xor i1 %t313, true
  store i1 %t314, ptr %l181, !tbaa !21
  br label %bb59
bb59:
  %t316 = load i1, ptr %l181, !tbaa !21
  br i1 %t316, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t317 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t317, ptr %l189, !tbaa !27
  %t318 = load i64, ptr %l14, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr ptr, ptr %t321, i64 %t318
  %t323 = load ptr, ptr %t322, !tbaa !39
  %t325 = getelementptr %"compiler/ast:Param", ptr %t323, i32 0, i32 0
  %t326 = getelementptr %"compiler/source:Span", ptr %t325, i32 0, i32 0
  %t327 = load i32, ptr %t326, !tbaa !23
  store i32 %t327, ptr %l192, !tbaa !23
  %t328 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t328, ptr %l193, !tbaa !27
  %t329 = load i64, ptr %l14, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l193, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t329
  %t334 = load ptr, ptr %t333, !tbaa !39
  %t336 = getelementptr %"compiler/ast:Param", ptr %t334, i32 0, i32 0
  %t337 = getelementptr %"compiler/source:Span", ptr %t336, i32 0, i32 0
  %t338 = load i32, ptr %t337, !tbaa !23
  store i32 %t338, ptr %l196, !tbaa !23
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t340, ptr %l198, !tbaa !27
  %t341 = load i64, ptr %l14, !tbaa !24
  %t343 = getelementptr { i64, ptr }, ptr %l198, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr ptr, ptr %t344, i64 %t341
  %t346 = load ptr, ptr %t345, !tbaa !39
  %t348 = getelementptr %"compiler/ast:Param", ptr %t346, i32 0, i32 1
  %t349 = load i32, ptr %t348, !tbaa !23
  %t352 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t339, i32 %t349)
  store { i64, ptr } %t352, ptr %l202
  br label %bb62
bb61:
  br label %bb73
bb62:
  %t353 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 0
  %t356 = trunc i64 %t354 to i32
  %t357 = load i32, ptr %l196, !tbaa !23
  %t359 = add i32 %t357, %t356
  %t360 = load i32, ptr %l192, !tbaa !23
  %t362 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t360, i32 %t359)
  store %"compiler/source:Span" %t362, ptr %l206
  br label %bb63
bb63:
  %t363 = load %"compiler/source:Span", ptr %l206
  %t364 = load ptr, ptr %l0, !tbaa !29
  store ptr %t364, ptr %l207, !tbaa !29
  store %"compiler/source:Span" %t363, ptr %l208
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t367, ptr %l210, !tbaa !27
  %t368 = load i64, ptr %l14, !tbaa !24
  %t370 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !27
  %t372 = getelementptr ptr, ptr %t371, i64 %t368
  %t373 = load ptr, ptr %t372, !tbaa !39
  %t375 = getelementptr %"compiler/ast:Param", ptr %t373, i32 0, i32 1
  %t376 = load i32, ptr %t375, !tbaa !23
  %t379 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t366, i32 %t376)
  store { i64, ptr } %t379, ptr %l214
  br label %bb64
bb64:
  %t380 = load { i64, ptr }, ptr %l214, !tbaa !27
  %t381 = extractvalue { i64, ptr } %t380, 0
  %t382 = extractvalue { i64, ptr } %t380, 1
  %t383 = mul i64 %t381, 1
  %t384 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t383)
  call void @llvm.memcpy.p0.p0.i64(ptr %t384, ptr %t382, i64 %t383, i1 false)
  %t385 = insertvalue { i64, ptr } undef, i64 %t381, 0
  %t386 = insertvalue { i64, ptr } %t385, ptr %t384, 1
  store { i64, ptr } %t386, ptr %l215, !tbaa !27
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l216, !tbaa !29
  %t388 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t388, ptr %l217, !tbaa !27
  %t389 = load i64, ptr %l14, !tbaa !24
  %t391 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t392 = load ptr, ptr %t391, !tbaa !27
  %t393 = getelementptr ptr, ptr %t392, i64 %t389
  %t394 = load ptr, ptr %t393, !tbaa !39
  %t396 = getelementptr %"compiler/ast:Param", ptr %t394, i32 0, i32 2
  %t397 = load ptr, ptr %t396, !tbaa !29
  store ptr %t397, ptr %l16, !tbaa !29
  %t399 = load ptr, ptr %l16, !tbaa !29
  %t401 = icmp eq ptr %t399, null
  br i1 %t401, label %bb65, label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_9765c214aae0d14_3e0d6126973403f8)
  unreachable
bb66:
  br label %bb67
bb67:
  %t403 = load ptr, ptr %l16, !tbaa !29
  %t405 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t403)
  store %"compiler/source:Span" %t405, ptr %l224
  br label %bb68
bb68:
  %t406 = load ptr, ptr %l216, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l224
  %t408 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t406, %"compiler/source:Span" %t407)
  store { i64, ptr } %t408, ptr %l225
  br label %bb69
bb69:
  %t409 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t410 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t411 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %s6, ptr %v0, ptr %s6, { i64, ptr } %t409, { i64, ptr } %t410)
  store %"compiler/msgs:Msg" %t411, ptr %l226
  br label %bb70
bb70:
  %t412 = load ptr, ptr %l207, !tbaa !29
  %t413 = load %"compiler/source:Span", ptr %l208
  %t414 = load %"compiler/msgs:Msg", ptr %l226
  %t415 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t412, %"compiler/source:Span" %t413, %"compiler/msgs:Msg" %t414)
  store i64 %t415, ptr %l227
  br label %bb71
bb71:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l1
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t416, %"compiler/source:Span" %t417)
  store ptr %t420, ptr %l230
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t421 = load ptr, ptr %l230, !tbaa !29
  store ptr %t421, ptr %rv
  br label %ret
bb73:
  %t422 = load i32, ptr %l4, !tbaa !23
  %t423 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t426 = icmp ne i32 %t422, %t423
  br i1 %t426, label %bb74, label %bb75
bb74:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t429 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t429, ptr %l236, !tbaa !27
  %t430 = load i64, ptr %l14, !tbaa !24
  %t432 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr i32, ptr %t433, i64 %t430
  %t435 = load i32, ptr %t434, !tbaa !33
  %t438 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t428, i32 %t435, i64 -1)
  store i1 %t438, ptr %l239
  br label %bb76
bb75:
  store i1 false, ptr %l234, !tbaa !21
  br label %bb77
bb76:
  %t439 = load i1, ptr %l239, !tbaa !21
  %t440 = xor i1 %t439, true
  store i1 %t440, ptr %l234, !tbaa !21
  br label %bb77
bb77:
  %t442 = load i1, ptr %l234, !tbaa !21
  br i1 %t442, label %bb78, label %bb79
bb78:
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/generic:Program", ptr %t446, i32 0, i32 2
  %t449 = load i64, ptr %l14, !tbaa !24
  %t451 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr i32, ptr %t452, i64 %t449
  %t454 = load i32, ptr %t453, !tbaa !33
  %t455 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t455, ptr %l247, !tbaa !27
  %t456 = load i64, ptr %l14, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr i32, ptr %t459, i64 %t456
  %t461 = load i32, ptr %t460, !tbaa !33
  %t465 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t448, i32 %t454, i32 %t461)
  store i1 %t465, ptr %l250
  br label %bb80
bb79:
  store i1 false, ptr %l241, !tbaa !21
  br label %bb81
bb80:
  %t466 = load i1, ptr %l250, !tbaa !21
  %t467 = xor i1 %t466, true
  store i1 %t467, ptr %l241, !tbaa !21
  br label %bb81
bb81:
  %t469 = load i1, ptr %l241, !tbaa !21
  br i1 %t469, label %bb82, label %bb83
bb82:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load i64, ptr %l14, !tbaa !24
  %t473 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = getelementptr i32, ptr %t474, i64 %t471
  %t476 = load i32, ptr %t475, !tbaa !33
  %t479 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t470, i32 %t476)
  store i1 %t479, ptr %l255
  br label %bb84
bb83:
  br label %bb119
bb84:
  %t480 = load ptr, ptr %l0, !tbaa !29
  %t481 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t481, ptr %l257, !tbaa !27
  %t482 = load i64, ptr %l14, !tbaa !24
  %t484 = getelementptr { i64, ptr }, ptr %l257, i32 0, i32 1
  %t485 = load ptr, ptr %t484, !tbaa !27
  %t486 = getelementptr i32, ptr %t485, i64 %t482
  %t487 = load i32, ptr %t486, !tbaa !33
  %t490 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t480, i32 %t487)
  store i1 %t490, ptr %l260
  br label %bb85
bb85:
  %t491 = load i1, ptr %l255, !tbaa !21
  %t492 = load i1, ptr %l260, !tbaa !21
  %t493 = icmp ne i1 %t491, %t492
  br i1 %t493, label %bb86, label %bb87
bb86:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/check:Checker", ptr %t495, i32 0, i32 1
  %t498 = load ptr, ptr %t497, !tbaa !29
  %t500 = getelementptr %"compiler/generic:Program", ptr %t498, i32 0, i32 2
  store ptr %t500, ptr %l265, !tbaa !29
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t502 = load i64, ptr %l14, !tbaa !24
  %t504 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !27
  %t506 = getelementptr i32, ptr %t505, i64 %t502
  %t507 = load i32, ptr %t506, !tbaa !33
  %t510 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t501, i32 %t507)
  store i32 %t510, ptr %l269
  br label %bb88
bb87:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb91
bb88:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t512, ptr %l271, !tbaa !27
  %t513 = load i64, ptr %l14, !tbaa !24
  %t515 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t516 = load ptr, ptr %t515, !tbaa !27
  %t517 = getelementptr i32, ptr %t516, i64 %t513
  %t518 = load i32, ptr %t517, !tbaa !33
  %t521 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t511, i32 %t518)
  store i32 %t521, ptr %l274
  br label %bb89
bb89:
  %t522 = load ptr, ptr %l265, !tbaa !29
  %t523 = load i32, ptr %l269, !tbaa !23
  %t524 = load i32, ptr %l274, !tbaa !23
  %t525 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t522, i32 %t523, i32 %t524)
  store i1 %t525, ptr %l275
  br label %bb90
bb90:
  %t526 = load i1, ptr %l275, !tbaa !21
  store i1 %t526, ptr %l262, !tbaa !21
  br label %bb91
bb91:
  %t527 = load i1, ptr %l262, !tbaa !21
  br i1 %t527, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s8
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t529 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t529, ptr %l277, !tbaa !27
  %t530 = load i64, ptr %l14, !tbaa !24
  %t532 = getelementptr { i64, ptr }, ptr %l277, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !27
  %t534 = getelementptr ptr, ptr %t533, i64 %t530
  %t535 = load ptr, ptr %t534, !tbaa !39
  %t537 = getelementptr %"compiler/ast:Param", ptr %t535, i32 0, i32 0
  %t538 = load %"compiler/source:Span", ptr %t537
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s8, ptr %t528, %"compiler/source:Span" %t538, { i64, ptr } { i64 74, ptr @.d27 })
  br label %bb94
bb93:
  br label %bb96
bb94:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t542 = load %"compiler/source:Span", ptr %l1
  %t545 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t541, %"compiler/source:Span" %t542)
  store ptr %t545, ptr %l283
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t546 = load ptr, ptr %l283, !tbaa !29
  store ptr %t546, ptr %rv
  br label %ret
bb96:
  %t547 = load ptr, ptr %l0, !tbaa !29
  %t548 = load i64, ptr %l14, !tbaa !24
  %t550 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t551 = load ptr, ptr %t550, !tbaa !27
  %t552 = getelementptr i32, ptr %t551, i64 %t548
  %t553 = load i32, ptr %t552, !tbaa !33
  %t556 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t547, i32 %t553)
  store i1 %t556, ptr %l287
  br label %bb97
bb97:
  %t557 = load i1, ptr %l287, !tbaa !21
  br i1 %t557, label %bb98, label %bb99
bb98:
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t559, ptr %l290, !tbaa !27
  %t560 = load i64, ptr %l14, !tbaa !24
  %t562 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t563 = load ptr, ptr %t562, !tbaa !27
  %t564 = getelementptr i32, ptr %t563, i64 %t560
  %t565 = load i32, ptr %t564, !tbaa !33
  %t568 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t558, i32 %t565)
  store i1 %t568, ptr %l293
  br label %bb100
bb99:
  store i1 false, ptr %l288, !tbaa !21
  br label %bb101
bb100:
  %t569 = load i1, ptr %l293, !tbaa !21
  store i1 %t569, ptr %l288, !tbaa !21
  br label %bb101
bb101:
  %t570 = load i1, ptr %l288, !tbaa !21
  br i1 %t570, label %bb102, label %bb103
bb102:
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t573 = getelementptr %"compiler/check:Checker", ptr %t571, i32 0, i32 1
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t576 = getelementptr %"compiler/generic:Program", ptr %t574, i32 0, i32 2
  store ptr %t576, ptr %l297, !tbaa !29
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load i64, ptr %l14, !tbaa !24
  %t580 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t581 = load ptr, ptr %t580, !tbaa !27
  %t582 = getelementptr i32, ptr %t581, i64 %t578
  %t583 = load i32, ptr %t582, !tbaa !33
  %t586 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t577, i32 %t583)
  store i32 %t586, ptr %l301
  br label %bb104
bb103:
  store i1 false, ptr %l294, !tbaa !21
  br label %bb107
bb104:
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t588 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t588, ptr %l303, !tbaa !27
  %t589 = load i64, ptr %l14, !tbaa !24
  %t591 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t592 = load ptr, ptr %t591, !tbaa !27
  %t593 = getelementptr i32, ptr %t592, i64 %t589
  %t594 = load i32, ptr %t593, !tbaa !33
  %t597 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t587, i32 %t594)
  store i32 %t597, ptr %l306
  br label %bb105
bb105:
  %t598 = load ptr, ptr %l297, !tbaa !29
  %t599 = load i32, ptr %l301, !tbaa !23
  %t600 = load i32, ptr %l306, !tbaa !23
  %t601 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t598, i32 %t599, i32 %t600)
  store i1 %t601, ptr %l307
  br label %bb106
bb106:
  %t602 = load i1, ptr %l307, !tbaa !21
  store i1 %t602, ptr %l294, !tbaa !21
  br label %bb107
bb107:
  %t603 = load i1, ptr %l294, !tbaa !21
  br i1 %t603, label %bb108, label %bb109
bb108:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 2
  %t610 = load i64, ptr %l14, !tbaa !24
  %t612 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t613 = load ptr, ptr %t612, !tbaa !27
  %t614 = getelementptr i32, ptr %t613, i64 %t610
  %t615 = load i32, ptr %t614, !tbaa !33
  %t618 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t609, i32 %t615)
  store i64 %t618, ptr %l314
  br label %bb110
bb109:
  store i1 false, ptr %l308, !tbaa !21
  br label %bb111
bb110:
  %t619 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t620 = load i64, ptr %l314, !tbaa !24
  %t622 = and i64 %t620, %t619
  %t624 = icmp eq i64 %t622, 0
  store i1 %t624, ptr %l308, !tbaa !21
  br label %bb111
bb111:
  %t626 = load i1, ptr %l308, !tbaa !21
  %t629 = xor i1 %t626, true
  br i1 %t629, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s9
  %t631 = load ptr, ptr %l0, !tbaa !29
  store ptr %t631, ptr %l320, !tbaa !29
  %t632 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t632, ptr %l321, !tbaa !27
  %t633 = load i64, ptr %l14, !tbaa !24
  %t635 = getelementptr { i64, ptr }, ptr %l321, i32 0, i32 1
  %t636 = load ptr, ptr %t635, !tbaa !27
  %t637 = getelementptr ptr, ptr %t636, i64 %t633
  %t638 = load ptr, ptr %t637, !tbaa !39
  %t640 = getelementptr %"compiler/ast:Param", ptr %t638, i32 0, i32 0
  %t641 = load %"compiler/source:Span", ptr %t640
  store %"compiler/source:Span" %t641, ptr %l324
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load i32, ptr %l4, !tbaa !23
  %t646 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s9, ptr %t642, i32 %t643)
  store { i64, ptr } %t646, ptr %l327
  br label %bb114
bb113:
  br label %bb118
bb114:
  %t647 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t648 = extractvalue { i64, ptr } %t647, 0
  %t649 = extractvalue { i64, ptr } %t647, 1
  %t650 = mul i64 %t648, 1
  %t651 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t650)
  call void @llvm.memcpy.p0.p0.i64(ptr %t651, ptr %t649, i64 %t650, i1 false)
  %t652 = insertvalue { i64, ptr } undef, i64 %t648, 0
  %t653 = insertvalue { i64, ptr } %t652, ptr %t651, 1
  %t655 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %s9, ptr %s9, { i64, ptr } %t653)
  store %"compiler/msgs:Msg" %t655, ptr %l329
  br label %bb115
bb115:
  %t656 = load ptr, ptr %l320, !tbaa !29
  %t657 = load %"compiler/source:Span", ptr %l324
  %t658 = load %"compiler/msgs:Msg", ptr %l329
  %t659 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t656, %"compiler/source:Span" %t657, %"compiler/msgs:Msg" %t658)
  store i64 %t659, ptr %l330
  br label %bb116
bb116:
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t661 = load %"compiler/source:Span", ptr %l1
  %t664 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t660, %"compiler/source:Span" %t661)
  store ptr %t664, ptr %l333
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t665 = load ptr, ptr %l333, !tbaa !29
  store ptr %t665, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  br label %bb131
bb120:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t667 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t667, ptr %l339, !tbaa !27
  %t668 = load i64, ptr %l14, !tbaa !24
  %t670 = getelementptr { i64, ptr }, ptr %l339, i32 0, i32 1
  %t671 = load ptr, ptr %t670, !tbaa !27
  %t672 = getelementptr i32, ptr %t671, i64 %t668
  %t673 = load i32, ptr %t672, !tbaa !33
  %t676 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t666, i32 %t673, i64 -1)
  store i1 %t676, ptr %l342
  br label %bb122
bb121:
  store i1 false, ptr %l337, !tbaa !21
  br label %bb123
bb122:
  %t677 = load i1, ptr %l342, !tbaa !21
  %t678 = xor i1 %t677, true
  store i1 %t678, ptr %l337, !tbaa !21
  br label %bb123
bb123:
  %t680 = load i1, ptr %l337, !tbaa !21
  br i1 %t680, label %bb124, label %bb125
bb124:
  %t681 = load i64, ptr %l14, !tbaa !24
  %t682 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t682, ptr %l345, !tbaa !27
  %t683 = load i64, ptr %l14, !tbaa !24
  %t685 = getelementptr { i64, ptr }, ptr %l345, i32 0, i32 1
  %t686 = load ptr, ptr %t685, !tbaa !27
  %t687 = getelementptr i32, ptr %t686, i64 %t683
  %t688 = load i32, ptr %t687, !tbaa !33
  %t691 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t692 = load ptr, ptr %t691, !tbaa !27
  %t693 = getelementptr i32, ptr %t692, i64 %t681
  store i32 %t688, ptr %t693, !tbaa !33
  br label %bb130
bb125:
  store %olang.scope zeroinitializer, ptr %s12
  %t694 = load ptr, ptr %l0, !tbaa !29
  store ptr %t694, ptr %l348, !tbaa !29
  %t695 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t695, ptr %l349, !tbaa !27
  %t696 = load i64, ptr %l14, !tbaa !24
  %t698 = getelementptr { i64, ptr }, ptr %l349, i32 0, i32 1
  %t699 = load ptr, ptr %t698, !tbaa !27
  %t700 = getelementptr ptr, ptr %t699, i64 %t696
  %t701 = load ptr, ptr %t700, !tbaa !39
  %t703 = getelementptr %"compiler/ast:Param", ptr %t701, i32 0, i32 0
  %t704 = load %"compiler/source:Span", ptr %t703
  store %"compiler/source:Span" %t704, ptr %l352
  %t705 = load ptr, ptr %l0, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t706, ptr %l354, !tbaa !27
  %t707 = load i64, ptr %l14, !tbaa !24
  %t709 = getelementptr { i64, ptr }, ptr %l354, i32 0, i32 1
  %t710 = load ptr, ptr %t709, !tbaa !27
  %t711 = getelementptr ptr, ptr %t710, i64 %t707
  %t712 = load ptr, ptr %t711, !tbaa !39
  %t714 = getelementptr %"compiler/ast:Param", ptr %t712, i32 0, i32 1
  %t715 = load i32, ptr %t714, !tbaa !23
  %t718 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s12, ptr %t705, i32 %t715)
  store { i64, ptr } %t718, ptr %l358
  br label %bb126
bb126:
  %t719 = load { i64, ptr }, ptr %l358, !tbaa !27
  %t720 = extractvalue { i64, ptr } %t719, 0
  %t721 = extractvalue { i64, ptr } %t719, 1
  %t722 = mul i64 %t720, 1
  %t723 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t722)
  call void @llvm.memcpy.p0.p0.i64(ptr %t723, ptr %t721, i64 %t722, i1 false)
  %t724 = insertvalue { i64, ptr } undef, i64 %t720, 0
  %t725 = insertvalue { i64, ptr } %t724, ptr %t723, 1
  %t727 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %s12, ptr %s12, { i64, ptr } %t725)
  store %"compiler/msgs:Msg" %t727, ptr %l360
  br label %bb127
bb127:
  %t728 = load ptr, ptr %l348, !tbaa !29
  %t729 = load %"compiler/source:Span", ptr %l352
  %t730 = load %"compiler/msgs:Msg", ptr %l360
  %t731 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t728, %"compiler/source:Span" %t729, %"compiler/msgs:Msg" %t730)
  store i64 %t731, ptr %l361
  br label %bb128
bb128:
  %t732 = load ptr, ptr %l0, !tbaa !29
  %t733 = load %"compiler/source:Span", ptr %l1
  %t736 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t732, %"compiler/source:Span" %t733)
  store ptr %t736, ptr %l364
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t737 = load ptr, ptr %l364, !tbaa !29
  store ptr %t737, ptr %rv
  br label %ret
bb130:
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s4)
  br label %bb132
bb132:
  %t738 = load i64, ptr %l13, !tbaa !24
  %t740 = add i64 %t738, 1
  store i64 %t740, ptr %l13, !tbaa !24
  br label %bb43
bb133:
  store i1 false, ptr %l18, !tbaa !21
  %t742 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  store i32 %t742, ptr %l19, !tbaa !23
  %t744 = load ptr, ptr %l2, !tbaa !29
  %t746 = getelementptr %"compiler/ast:Func", ptr %t744, i32 0, i32 3
  %t747 = load ptr, ptr %t746, !tbaa !29
  %t749 = getelementptr %"compiler/ast:Sig", ptr %t747, i32 0, i32 1
  %t750 = load { i64, ptr }, ptr %t749, !tbaa !27
  %t752 = extractvalue { i64, ptr } %t750, 0
  %t754 = icmp sgt i64 %t752, 0
  br i1 %t754, label %bb134, label %bb135
bb134:
  store %olang.scope zeroinitializer, ptr %s14
  %t756 = load ptr, ptr %l2, !tbaa !29
  %t758 = getelementptr %"compiler/ast:Func", ptr %t756, i32 0, i32 3
  %t759 = load ptr, ptr %t758, !tbaa !29
  %t761 = getelementptr %"compiler/ast:Sig", ptr %t759, i32 0, i32 1
  %t762 = load { i64, ptr }, ptr %t761, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t762, 0
  store i64 %t764, ptr %l376, !tbaa !24
  %t765 = load i64, ptr %l376, !tbaa !24
  %t766 = icmp sge i64 %t765, 0
  br i1 %t766, label %bb136, label %bb137
bb135:
  %t768 = load i32, ptr %l4, !tbaa !23
  %t769 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t772 = icmp ne i32 %t768, %t769
  br i1 %t772, label %bb158, label %bb159
bb136:
  %t774 = load i64, ptr %l376, !tbaa !24
  %t775 = icmp sle i64 %t774, 2305843009213693951
  br i1 %t775, label %bb138, label %bb139
bb137:
  call void @__olang_check_failed(ptr @olang_loc_5a62442bf09cb677_66ce856a58ef9453)
  unreachable
bb138:
  %t777 = load i64, ptr %l376, !tbaa !24
  %t778 = mul i64 %t777, 4
  %t779 = call ptr @__olang_scope_alloc_zeroed(ptr %s14, i64 %t778)
  %t780 = insertvalue { i64, ptr } undef, i64 %t777, 0
  %t781 = insertvalue { i64, ptr } %t780, ptr %t779, 1
  store { i64, ptr } %t781, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t783 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t785 = extractvalue { i64, ptr } %t783, 0
  store i64 %t785, ptr %l22, !tbaa !24
  store i64 1, ptr %l23, !tbaa !24
  %t787 = load i64, ptr %l22, !tbaa !24
  %t788 = load i64, ptr %l21, !tbaa !24
  %t791 = icmp sgt i64 %t787, %t788
  br i1 %t791, label %bb140, label %bb141
bb139:
  call void @__olang_check_failed(ptr @olang_loc_5a62442bf09cb677_66ce856a58ef9453)
  unreachable
bb140:
  %t793 = load i64, ptr %l23, !tbaa !24
  %t795 = icmp sgt i64 %t793, 0
  br i1 %t795, label %bb142, label %bb143
bb141:
  store i64 0, ptr %l385, !tbaa !24
  br label %bb145
bb142:
  %t797 = load i64, ptr %l22, !tbaa !24
  %t798 = load i64, ptr %l21, !tbaa !24
  %t801 = sub i64 %t797, %t798
  %t802 = load i64, ptr %l23, !tbaa !24
  %t805 = add i64 %t801, %t802
  %t807 = sub i64 %t805, 1
  %t808 = load i64, ptr %l23, !tbaa !24
  %t811 = sdiv i64 %t807, %t808
  store i64 %t811, ptr %l388, !tbaa !24
  br label %bb144
bb143:
  store i64 0, ptr %l388, !tbaa !24
  br label %bb144
bb144:
  %t813 = load i64, ptr %l388, !tbaa !24
  store i64 %t813, ptr %l385, !tbaa !24
  br label %bb145
bb145:
  %t814 = load i64, ptr %l385, !tbaa !24
  store i64 %t814, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb146
bb146:
  store %olang.scope zeroinitializer, ptr %s16
  %t815 = load i64, ptr %l25, !tbaa !24
  %t816 = load i64, ptr %l24, !tbaa !24
  %t819 = icmp slt i64 %t815, %t816
  %t821 = xor i1 %t819, true
  br i1 %t821, label %bb147, label %bb148
bb147:
  call void @__olang_scope_close(ptr %s16)
  br label %bb152
bb148:
  br label %bb149
bb149:
  %t823 = load i64, ptr %l21, !tbaa !24
  %t824 = load i64, ptr %l25, !tbaa !24
  %t825 = load i64, ptr %l23, !tbaa !24
  %t828 = mul i64 %t824, %t825
  %t831 = add i64 %t823, %t828
  store i64 %t831, ptr %l26, !tbaa !24
  %t833 = load i64, ptr %l26, !tbaa !24
  store i64 %t833, ptr %l406, !tbaa !24
  %t834 = load ptr, ptr %l0, !tbaa !29
  %t835 = load ptr, ptr %l2, !tbaa !29
  %t837 = getelementptr %"compiler/ast:Func", ptr %t835, i32 0, i32 3
  %t838 = load ptr, ptr %t837, !tbaa !29
  %t840 = getelementptr %"compiler/ast:Sig", ptr %t838, i32 0, i32 1
  %t841 = load { i64, ptr }, ptr %t840, !tbaa !27
  store { i64, ptr } %t841, ptr %l410, !tbaa !27
  %t842 = load i64, ptr %l26, !tbaa !24
  %t844 = getelementptr { i64, ptr }, ptr %l410, i32 0, i32 1
  %t845 = load ptr, ptr %t844, !tbaa !27
  %t846 = getelementptr ptr, ptr %t845, i64 %t842
  %t847 = load ptr, ptr %t846, !tbaa !39
  %t851 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t834, ptr %t847)
  store i32 %t851, ptr %l414
  br label %bb150
bb150:
  %t852 = load i32, ptr %l414, !tbaa !23
  %t853 = load i64, ptr %l406, !tbaa !24
  %t854 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t855 = load ptr, ptr %t854, !tbaa !27
  %t856 = getelementptr i32, ptr %t855, i64 %t853
  store i32 %t852, ptr %t856, !tbaa !33
  call void @__olang_scope_close(ptr %s16)
  br label %bb151
bb151:
  %t857 = load i64, ptr %l25, !tbaa !24
  %t859 = add i64 %t857, 1
  store i64 %t859, ptr %l25, !tbaa !24
  br label %bb146
bb152:
  %t861 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t861, 0
  %t865 = icmp eq i64 %t863, 1
  br i1 %t865, label %bb153, label %bb154
bb153:
  %t867 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t868 = load ptr, ptr %t867, !tbaa !27
  %t869 = getelementptr i32, ptr %t868, i64 0
  %t870 = load i32, ptr %t869, !tbaa !33
  store i32 %t870, ptr %l420, !tbaa !23
  br label %bb157
bb154:
  %t872 = load ptr, ptr %l0, !tbaa !29
  %t874 = getelementptr %"compiler/check:Checker", ptr %t872, i32 0, i32 1
  %t875 = load ptr, ptr %t874, !tbaa !29
  %t877 = getelementptr %"compiler/generic:Program", ptr %t875, i32 0, i32 2
  store ptr %t877, ptr %l424, !tbaa !29
  %t878 = load ptr, ptr %l0, !tbaa !29
  %t880 = getelementptr %"compiler/check:Checker", ptr %t878, i32 0, i32 1
  %t881 = load ptr, ptr %t880, !tbaa !29
  %t883 = getelementptr %"compiler/generic:Program", ptr %t881, i32 0, i32 2
  %t884 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t887 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s14, ptr %t883, { i64, ptr } %t884)
  store i32 %t887, ptr %l429
  br label %bb155
bb155:
  %t888 = load ptr, ptr %l424, !tbaa !29
  %t889 = load i32, ptr %l429, !tbaa !23
  %t890 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %t888, i32 %t889)
  store i32 %t890, ptr %l430
  br label %bb156
bb156:
  %t891 = load i32, ptr %l430, !tbaa !23
  store i32 %t891, ptr %l420, !tbaa !23
  br label %bb157
bb157:
  %t892 = load i32, ptr %l420, !tbaa !23
  store i32 %t892, ptr %l19, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  br label %bb167
bb158:
  %t893 = load ptr, ptr %l0, !tbaa !29
  store ptr %t893, ptr %l435, !tbaa !29
  %t894 = load ptr, ptr %l0, !tbaa !29
  %t896 = getelementptr %"compiler/check:Checker", ptr %t894, i32 0, i32 1
  %t897 = load ptr, ptr %t896, !tbaa !29
  %t899 = getelementptr %"compiler/generic:Program", ptr %t897, i32 0, i32 2
  %t900 = load i32, ptr %l4, !tbaa !23
  %t903 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t899, i32 %t900)
  store i32 %t903, ptr %l440
  br label %bb160
bb159:
  store i1 false, ptr %l434, !tbaa !21
  br label %bb162
bb160:
  %t904 = load ptr, ptr %l435, !tbaa !29
  %t905 = load i32, ptr %l440, !tbaa !23
  %t906 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t904, i32 %t905, i64 -1)
  store i1 %t906, ptr %l441
  br label %bb161
bb161:
  %t907 = load i1, ptr %l441, !tbaa !21
  %t908 = xor i1 %t907, true
  store i1 %t908, ptr %l434, !tbaa !21
  br label %bb162
bb162:
  %t910 = load i1, ptr %l434, !tbaa !21
  br i1 %t910, label %bb163, label %bb164
bb163:
  %t911 = load ptr, ptr %l0, !tbaa !29
  %t913 = getelementptr %"compiler/check:Checker", ptr %t911, i32 0, i32 1
  %t914 = load ptr, ptr %t913, !tbaa !29
  %t916 = getelementptr %"compiler/generic:Program", ptr %t914, i32 0, i32 2
  %t917 = load i32, ptr %l4, !tbaa !23
  %t920 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t916, i32 %t917)
  store i32 %t920, ptr %l447
  br label %bb165
bb164:
  store i1 true, ptr %l18, !tbaa !21
  %t921 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t921, ptr %l19, !tbaa !23
  br label %bb166
bb165:
  %t923 = load i32, ptr %l447, !tbaa !23
  store i32 %t923, ptr %l19, !tbaa !23
  br label %bb166
bb166:
  br label %bb167
bb167:
  store i32 0, ptr %l27, !tbaa !23
  store i1 false, ptr %l28, !tbaa !21
  %t924 = load ptr, ptr %l2, !tbaa !29
  %t926 = getelementptr %"compiler/ast:Func", ptr %t924, i32 0, i32 3
  %t927 = load ptr, ptr %t926, !tbaa !29
  %t929 = getelementptr %"compiler/ast:Sig", ptr %t927, i32 0, i32 2
  %t930 = load i1, ptr %t929, !tbaa !21
  br i1 %t930, label %bb168, label %bb169
bb168:
  %t932 = load ptr, ptr %l2, !tbaa !29
  %t934 = getelementptr %"compiler/ast:Func", ptr %t932, i32 0, i32 3
  %t935 = load ptr, ptr %t934, !tbaa !29
  %t937 = getelementptr %"compiler/ast:Sig", ptr %t935, i32 0, i32 3
  %t938 = load { i64, ptr }, ptr %t937, !tbaa !27
  %t940 = extractvalue { i64, ptr } %t938, 0
  %t942 = icmp eq i64 %t940, 0
  store i1 %t942, ptr %l452, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l452, !tbaa !21
  br label %bb170
bb170:
  %t944 = load i1, ptr %l452, !tbaa !21
  br i1 %t944, label %bb171, label %bb172
bb171:
  %t945 = load i32, ptr %l4, !tbaa !23
  %t946 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t949 = icmp eq i32 %t945, %t946
  store i1 %t949, ptr %l458, !tbaa !21
  br label %bb173
bb172:
  store i1 false, ptr %l458, !tbaa !21
  br label %bb173
bb173:
  %t951 = load i1, ptr %l458, !tbaa !21
  br i1 %t951, label %bb174, label %bb175
bb174:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb199
bb175:
  %t952 = load ptr, ptr %l2, !tbaa !29
  %t954 = getelementptr %"compiler/ast:Func", ptr %t952, i32 0, i32 3
  %t955 = load ptr, ptr %t954, !tbaa !29
  %t957 = getelementptr %"compiler/ast:Sig", ptr %t955, i32 0, i32 2
  %t958 = load i1, ptr %t957, !tbaa !21
  br i1 %t958, label %bb176, label %bb177
bb176:
  store %olang.scope zeroinitializer, ptr %s23
  %t960 = load ptr, ptr @__olang_prog_scope
  %t961 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t960)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t961, ptr %l465
  br label %bb178
bb177:
  %t962 = load i32, ptr %l4, !tbaa !23
  %t963 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t966 = icmp ne i32 %t962, %t963
  br i1 %t966, label %bb194, label %bb195
bb178:
  %t968 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l465
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t968, ptr %l29
  %t969 = load ptr, ptr %l2, !tbaa !29
  %t971 = getelementptr %"compiler/ast:Func", ptr %t969, i32 0, i32 3
  %t972 = load ptr, ptr %t971, !tbaa !29
  %t974 = getelementptr %"compiler/ast:Sig", ptr %t972, i32 0, i32 3
  %t975 = load { i64, ptr }, ptr %t974, !tbaa !27
  %t977 = extractvalue { i64, ptr } %t975, 0
  %t979 = icmp eq i64 %t977, 0
  br i1 %t979, label %bb179, label %bb180
bb179:
  %t981 = load i32, ptr @G_2ecompiler_2ftypes_2eDefaultErrT, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s23, ptr %l29, i32 %t981)
  br label %bb181
bb180:
  br label %bb182
bb181:
  br label %bb182
bb182:
  %t984 = load ptr, ptr %l2, !tbaa !29
  %t986 = getelementptr %"compiler/ast:Func", ptr %t984, i32 0, i32 3
  %t987 = load ptr, ptr %t986, !tbaa !29
  %t989 = getelementptr %"compiler/ast:Sig", ptr %t987, i32 0, i32 3
  %t990 = load { i64, ptr }, ptr %t989, !tbaa !27
  store { i64, ptr } %t990, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t992 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t994 = extractvalue { i64, ptr } %t992, 0
  store i64 %t994, ptr %l32, !tbaa !24
  br label %bb183
bb183:
  store %olang.scope zeroinitializer, ptr %s26
  %t996 = load i64, ptr %l31, !tbaa !24
  %t997 = load i64, ptr %l32, !tbaa !24
  %t1000 = icmp slt i64 %t996, %t997
  %t1002 = xor i1 %t1000, true
  br i1 %t1002, label %bb184, label %bb185
bb184:
  call void @__olang_scope_close(ptr %s26)
  br label %bb191
bb185:
  br label %bb186
bb186:
  %t1004 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t1004, ptr %l482, !tbaa !27
  %t1005 = load i64, ptr %l31, !tbaa !24
  %t1007 = getelementptr { i64, ptr }, ptr %l482, i32 0, i32 1
  %t1008 = load ptr, ptr %t1007, !tbaa !27
  %t1009 = getelementptr ptr, ptr %t1008, i64 %t1005
  %t1010 = load ptr, ptr %t1009, !tbaa !39
  store ptr %t1010, ptr %l33, !tbaa !29
  store ptr %l29, ptr %l485, !tbaa !29
  %t1012 = load ptr, ptr %l0, !tbaa !29
  %t1014 = getelementptr %"compiler/check:Checker", ptr %t1012, i32 0, i32 1
  %t1015 = load ptr, ptr %t1014, !tbaa !29
  store ptr %t1015, ptr %l487, !tbaa !29
  %t1016 = load ptr, ptr %l0, !tbaa !29
  %t1018 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1016)
  store ptr %t1018, ptr %l489
  br label %bb187
bb187:
  %t1019 = load ptr, ptr %l489, !tbaa !29
  %t1021 = getelementptr %"compiler/check:frame", ptr %t1019, i32 0, i32 4
  %t1022 = load ptr, ptr %l33, !tbaa !29
  %t1023 = load ptr, ptr %l487, !tbaa !29
  %t1026 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %v1, ptr %t1023, ptr %t1021, ptr %t1022)
  store i32 %t1026, ptr %l493
  br label %bb188
bb188:
  %t1027 = load ptr, ptr %l485, !tbaa !29
  %t1028 = load i32, ptr %l493, !tbaa !23
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %s23, ptr %t1027, i32 %t1028)
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s26)
  br label %bb190
bb190:
  %t1029 = load i64, ptr %l31, !tbaa !24
  %t1031 = add i64 %t1029, 1
  store i64 %t1031, ptr %l31, !tbaa !24
  br label %bb183
bb191:
  %t1033 = load ptr, ptr %l0, !tbaa !29
  %t1035 = getelementptr %"compiler/check:Checker", ptr %t1033, i32 0, i32 1
  %t1036 = load ptr, ptr %t1035, !tbaa !29
  %t1038 = getelementptr %"compiler/generic:Program", ptr %t1036, i32 0, i32 2
  store ptr %t1038, ptr %l498, !tbaa !29
  %t1040 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %s23, ptr %s23, ptr %l29)
  store { i64, ptr } %t1040, ptr %l500
  br label %bb192
bb192:
  %t1041 = load ptr, ptr %l498, !tbaa !29
  %t1042 = load { i64, ptr }, ptr %l500, !tbaa !27
  %t1043 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s23, ptr %t1041, { i64, ptr } %t1042)
  store i32 %t1043, ptr %l501
  br label %bb193
bb193:
  %t1044 = load i32, ptr %l501, !tbaa !23
  store i32 %t1044, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s23)
  br label %bb198
bb194:
  %t1045 = load ptr, ptr %l0, !tbaa !29
  %t1047 = getelementptr %"compiler/check:Checker", ptr %t1045, i32 0, i32 1
  %t1048 = load ptr, ptr %t1047, !tbaa !29
  %t1050 = getelementptr %"compiler/generic:Program", ptr %t1048, i32 0, i32 2
  %t1051 = load i32, ptr %l4, !tbaa !23
  %t1054 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t1050, i32 %t1051)
  store i32 %t1054, ptr %l509
  br label %bb196
bb195:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb197
bb196:
  %t1055 = load i32, ptr %l509, !tbaa !23
  store i32 %t1055, ptr %l27, !tbaa !23
  br label %bb197
bb197:
  br label %bb198
bb198:
  br label %bb199
bb199:
  %t1056 = load i32, ptr %l4, !tbaa !23
  %t1057 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1060 = icmp ne i32 %t1056, %t1057
  br i1 %t1060, label %bb200, label %bb201
bb200:
  %t1062 = load ptr, ptr %l0, !tbaa !29
  %t1064 = getelementptr %"compiler/check:Checker", ptr %t1062, i32 0, i32 1
  %t1065 = load ptr, ptr %t1064, !tbaa !29
  %t1067 = getelementptr %"compiler/generic:Program", ptr %t1065, i32 0, i32 2
  %t1068 = load i32, ptr %l4, !tbaa !23
  %t1071 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t1067, i32 %t1068)
  store i32 %t1071, ptr %l518
  br label %bb202
bb201:
  store i32 0, ptr %l513, !tbaa !23
  br label %bb203
bb202:
  %t1072 = load i32, ptr %l518, !tbaa !23
  store i32 %t1072, ptr %l513, !tbaa !23
  br label %bb203
bb203:
  %t1073 = load i32, ptr %l513, !tbaa !23
  store i32 %t1073, ptr %l34, !tbaa !23
  %t1074 = load ptr, ptr %l0, !tbaa !29
  %t1076 = getelementptr %"compiler/check:Checker", ptr %t1074, i32 0, i32 1
  %t1077 = load ptr, ptr %t1076, !tbaa !29
  %t1079 = getelementptr %"compiler/generic:Program", ptr %t1077, i32 0, i32 2
  %t1080 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t1083 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t1079, { i64, ptr } %t1080)
  store i32 %t1083, ptr %l523
  br label %bb204
bb204:
  %t1084 = load i32, ptr %l523, !tbaa !23
  store i32 %t1084, ptr %l35, !tbaa !23
  %t1085 = load ptr, ptr %l0, !tbaa !29
  %t1087 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1085)
  store ptr %t1087, ptr %l525
  br label %bb205
bb205:
  %t1088 = load ptr, ptr %l525, !tbaa !29
  store ptr %t1088, ptr %l36, !tbaa !29
  %t1089 = load ptr, ptr %l0, !tbaa !29
  %t1091 = getelementptr %"compiler/check:Checker", ptr %t1089, i32 0, i32 12
  %t1093 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t1091)
  store i64 %t1093, ptr %l528
  br label %bb206
bb206:
  %t1094 = load i64, ptr %l528, !tbaa !24
  %t1095 = sub i64 %t1094, 1
  store i64 %t1095, ptr %l37, !tbaa !24
  %t1097 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1097, ptr %l530, !tbaa !29
  %t1098 = load ptr, ptr %l36, !tbaa !29
  %t1100 = getelementptr %"compiler/check:frame", ptr %t1098, i32 0, i32 0
  %t1101 = load i64, ptr %t1100, !tbaa !24
  %t1103 = trunc i64 %t1101 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t1105
  %t1106 = getelementptr { i64, [2 x i64] }, ptr %t1105, i32 0, i32 0
  store i64 4, ptr %t1106
  %t1108 = insertvalue { i32 } undef, i32 %t1103, 0
  %t1109 = getelementptr { i64, [2 x i64] }, ptr %t1105, i32 0, i32 1
  store { i32 } %t1108, ptr %t1109
  %t1110 = load { i64, [2 x i64] }, ptr %t1105
  store { i64, [2 x i64] } %t1110, ptr %l535
  %t1111 = load ptr, ptr %l0, !tbaa !29
  %t1113 = getelementptr %"compiler/check:Checker", ptr %t1111, i32 0, i32 1
  %t1114 = load ptr, ptr %t1113, !tbaa !29
  %t1116 = getelementptr %"compiler/generic:Program", ptr %t1114, i32 0, i32 2
  %t1117 = load i32, ptr %l35, !tbaa !23
  %t1118 = load i32, ptr %l19, !tbaa !23
  %t1119 = load i32, ptr %l27, !tbaa !23
  %t1120 = load i32, ptr %l34, !tbaa !23
  %t1126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t1116, i32 %t1117, i32 %t1118, i32 %t1119, i32 %t1120, i64 0)
  store i32 %t1126, ptr %l543
  br label %bb207
bb207:
  %t1127 = load ptr, ptr %l36, !tbaa !29
  %t1129 = getelementptr %"compiler/check:frame", ptr %t1127, i32 0, i32 1
  %t1130 = load i64, ptr %t1129, !tbaa !24
  %t1131 = load %"compiler/source:Span", ptr %l1
  %t1132 = load ptr, ptr %l530, !tbaa !29
  %t1133 = load { i64, [2 x i64] }, ptr %l535
  %t1134 = load i32, ptr %l543, !tbaa !23
  %t1137 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t1132, { i64, [2 x i64] } %t1133, i32 %t1134, i64 %t1130, %"compiler/source:Span" %t1131)
  store i64 %t1137, ptr %l547
  br label %bb208
bb208:
  %t1138 = load i64, ptr %l547, !tbaa !24
  store i64 %t1138, ptr %l38, !tbaa !24
  %t1139 = load ptr, ptr %l0, !tbaa !29
  %t1141 = getelementptr %"compiler/check:Checker", ptr %t1139, i32 0, i32 15
  %t1142 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1141, i64 %t1142, i64 1)
  br label %bb209
bb209:
  %t1145 = load ptr, ptr %l0, !tbaa !29
  %t1146 = load i64, ptr %l38, !tbaa !24
  %t1147 = load ptr, ptr %l36, !tbaa !29
  %t1149 = getelementptr %"compiler/check:frame", ptr %t1147, i32 0, i32 1
  %t1150 = load i64, ptr %t1149, !tbaa !24
  %t1151 = load i32, ptr %l19, !tbaa !23
  %t1152 = load i32, ptr %l27, !tbaa !23
  %t1158 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t1145, i64 %t1146, i64 %t1150, i32 %t1151, i32 %t1152)
  store ptr %t1158, ptr %l557
  br label %bb210
bb210:
  %t1159 = load ptr, ptr %l557, !tbaa !29
  store ptr %t1159, ptr %l39, !tbaa !29
  %t1160 = load ptr, ptr %l39, !tbaa !29
  %t1161 = load ptr, ptr %l36, !tbaa !29
  %t1163 = getelementptr %"compiler/check:frame", ptr %t1161, i32 0, i32 4
  %t1164 = load %"compiler/generic:Context", ptr %t1163
  %t1167 = getelementptr %"compiler/check:frame", ptr %t1160, i32 0, i32 4
  store %"compiler/generic:Context" %t1164, ptr %t1167
  %t1168 = load ptr, ptr %l39, !tbaa !29
  %t1169 = load i64, ptr %l37, !tbaa !24
  %t1172 = getelementptr %"compiler/check:frame", ptr %t1168, i32 0, i32 21
  store i64 %t1169, ptr %t1172, !tbaa !24
  %t1173 = load ptr, ptr %l39, !tbaa !29
  %t1174 = load i1, ptr %l18, !tbaa !21
  %t1177 = getelementptr %"compiler/check:frame", ptr %t1173, i32 0, i32 22
  store i1 %t1174, ptr %t1177, !tbaa !21
  %t1178 = load ptr, ptr %l39, !tbaa !29
  %t1179 = load i1, ptr %l28, !tbaa !21
  %t1182 = getelementptr %"compiler/check:frame", ptr %t1178, i32 0, i32 23
  store i1 %t1179, ptr %t1182, !tbaa !21
  %t1183 = load ptr, ptr %l0, !tbaa !29
  %t1185 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1183)
  store ptr %t1185, ptr %l568
  br label %bb211
bb211:
  %t1186 = load %"compiler/source:Span", ptr %l1
  %t1187 = load ptr, ptr %l568, !tbaa !29
  %t1190 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t1187, i32 -1, i32 0, %"compiler/source:Span" %t1186)
  store i32 %t1190, ptr %l571
  br label %bb212
bb212:
  store i64 0, ptr %l40, !tbaa !24
  %t1191 = load i64, ptr %l6, !tbaa !24
  store i64 %t1191, ptr %l41, !tbaa !24
  store i64 1, ptr %l42, !tbaa !24
  %t1193 = load i64, ptr %l41, !tbaa !24
  %t1194 = load i64, ptr %l40, !tbaa !24
  %t1197 = icmp sgt i64 %t1193, %t1194
  br i1 %t1197, label %bb213, label %bb214
bb213:
  %t1199 = load i64, ptr %l42, !tbaa !24
  %t1201 = icmp sgt i64 %t1199, 0
  br i1 %t1201, label %bb215, label %bb216
bb214:
  store i64 0, ptr %l576, !tbaa !24
  br label %bb218
bb215:
  %t1203 = load i64, ptr %l41, !tbaa !24
  %t1204 = load i64, ptr %l40, !tbaa !24
  %t1207 = sub i64 %t1203, %t1204
  %t1208 = load i64, ptr %l42, !tbaa !24
  %t1211 = add i64 %t1207, %t1208
  %t1213 = sub i64 %t1211, 1
  %t1214 = load i64, ptr %l42, !tbaa !24
  %t1217 = sdiv i64 %t1213, %t1214
  store i64 %t1217, ptr %l579, !tbaa !24
  br label %bb217
bb216:
  store i64 0, ptr %l579, !tbaa !24
  br label %bb217
bb217:
  %t1219 = load i64, ptr %l579, !tbaa !24
  store i64 %t1219, ptr %l576, !tbaa !24
  br label %bb218
bb218:
  %t1220 = load i64, ptr %l576, !tbaa !24
  store i64 %t1220, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  br label %bb219
bb219:
  store %olang.scope zeroinitializer, ptr %s32
  %t1221 = load i64, ptr %l44, !tbaa !24
  %t1222 = load i64, ptr %l43, !tbaa !24
  %t1225 = icmp slt i64 %t1221, %t1222
  %t1227 = xor i1 %t1225, true
  br i1 %t1227, label %bb220, label %bb221
bb220:
  call void @__olang_scope_close(ptr %s32)
  br label %bb229
bb221:
  br label %bb222
bb222:
  %t1229 = load i64, ptr %l40, !tbaa !24
  %t1230 = load i64, ptr %l44, !tbaa !24
  %t1231 = load i64, ptr %l42, !tbaa !24
  %t1234 = mul i64 %t1230, %t1231
  %t1237 = add i64 %t1229, %t1234
  store i64 %t1237, ptr %l45, !tbaa !24
  %t1239 = load ptr, ptr %l0, !tbaa !29
  %t1240 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1240, ptr %l598, !tbaa !27
  %t1241 = load i64, ptr %l45, !tbaa !24
  %t1243 = getelementptr { i64, ptr }, ptr %l598, i32 0, i32 1
  %t1244 = load ptr, ptr %t1243, !tbaa !27
  %t1245 = getelementptr ptr, ptr %t1244, i64 %t1241
  %t1246 = load ptr, ptr %t1245, !tbaa !39
  %t1248 = getelementptr %"compiler/ast:Param", ptr %t1246, i32 0, i32 1
  %t1249 = load i32, ptr %t1248, !tbaa !23
  %t1250 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1250, ptr %l602, !tbaa !27
  %t1251 = load i64, ptr %l45, !tbaa !24
  %t1253 = getelementptr { i64, ptr }, ptr %l602, i32 0, i32 1
  %t1254 = load ptr, ptr %t1253, !tbaa !27
  %t1255 = getelementptr ptr, ptr %t1254, i64 %t1251
  %t1256 = load ptr, ptr %t1255, !tbaa !39
  %t1258 = getelementptr %"compiler/ast:Param", ptr %t1256, i32 0, i32 0
  %t1259 = load %"compiler/source:Span", ptr %t1258
  %t1260 = load i64, ptr %l45, !tbaa !24
  %t1262 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t1263 = load ptr, ptr %t1262, !tbaa !27
  %t1264 = getelementptr i32, ptr %t1263, i64 %t1260
  %t1265 = load i32, ptr %t1264, !tbaa !33
  %t1266 = load i64, ptr %l45, !tbaa !24
  %t1267 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1267, ptr %l609, !tbaa !27
  %t1268 = load i64, ptr %l45, !tbaa !24
  %t1270 = getelementptr { i64, ptr }, ptr %l609, i32 0, i32 1
  %t1271 = load ptr, ptr %t1270, !tbaa !27
  %t1272 = getelementptr ptr, ptr %t1271, i64 %t1268
  %t1273 = load ptr, ptr %t1272, !tbaa !39
  %t1275 = getelementptr %"compiler/ast:Param", ptr %t1273, i32 0, i32 2
  %t1276 = load ptr, ptr %t1275, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %t1239, i32 %t1249, %"compiler/source:Span" %t1259, i32 %t1265, i64 %t1266, ptr %t1276)
  br label %bb223
bb223:
  %t1283 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1283, ptr %l613, !tbaa !27
  %t1284 = load i64, ptr %l45, !tbaa !24
  %t1286 = getelementptr { i64, ptr }, ptr %l613, i32 0, i32 1
  %t1287 = load ptr, ptr %t1286, !tbaa !27
  %t1288 = getelementptr ptr, ptr %t1287, i64 %t1284
  %t1289 = load ptr, ptr %t1288, !tbaa !39
  %t1291 = getelementptr %"compiler/ast:Param", ptr %t1289, i32 0, i32 2
  %t1292 = load ptr, ptr %t1291, !tbaa !29
  %t1294 = icmp eq ptr %t1292, null
  %t1296 = xor i1 %t1294, true
  br i1 %t1296, label %bb224, label %bb225
bb224:
  %t1298 = load ptr, ptr %l0, !tbaa !29
  %t1299 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t1299, ptr %l620, !tbaa !27
  %t1300 = load i64, ptr %l45, !tbaa !24
  %t1302 = getelementptr { i64, ptr }, ptr %l620, i32 0, i32 1
  %t1303 = load ptr, ptr %t1302, !tbaa !27
  %t1304 = getelementptr ptr, ptr %t1303, i64 %t1300
  %t1305 = load ptr, ptr %t1304, !tbaa !39
  %t1306 = load i64, ptr %l45, !tbaa !24
  %t1308 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t1309 = load ptr, ptr %t1308, !tbaa !27
  %t1310 = getelementptr i32, ptr %t1309, i64 %t1306
  %t1311 = load i32, ptr %t1310, !tbaa !33
  %t1315 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %t1298, ptr %t1305, i32 %t1311, i1 false)
  store i1 %t1315, ptr %l625
  br label %bb226
bb225:
  br label %bb227
bb226:
  br label %bb227
bb227:
  call void @__olang_scope_close(ptr %s32)
  br label %bb228
bb228:
  %t1316 = load i64, ptr %l44, !tbaa !24
  %t1318 = add i64 %t1316, 1
  store i64 %t1318, ptr %l44, !tbaa !24
  br label %bb219
bb229:
  %t1320 = load ptr, ptr %l0, !tbaa !29
  %t1322 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1320)
  store ptr %t1322, ptr %l629
  br label %bb230
bb230:
  %t1323 = load ptr, ptr %l0, !tbaa !29
  %t1325 = getelementptr %"compiler/check:Checker", ptr %t1323, i32 0, i32 1
  %t1326 = load ptr, ptr %t1325, !tbaa !29
  store ptr %t1326, ptr %l631, !tbaa !29
  %t1327 = load ptr, ptr %l0, !tbaa !29
  %t1329 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1327)
  store ptr %t1329, ptr %l633
  br label %bb231
bb231:
  %t1330 = load ptr, ptr %l633, !tbaa !29
  %t1332 = getelementptr %"compiler/typed:Body", ptr %t1330, i32 0, i32 2
  %t1333 = load i32, ptr %t1332, !tbaa !23
  %t1334 = load ptr, ptr %l631, !tbaa !29
  %t1336 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t1334, i32 %t1333)
  store { i64, ptr } %t1336, ptr %l636
  br label %bb232
bb232:
  %t1337 = load { i64, ptr }, ptr %l636, !tbaa !27
  %t1338 = extractvalue { i64, ptr } %t1337, 0
  %t1339 = extractvalue { i64, ptr } %t1337, 1
  %t1340 = mul i64 %t1338, 8
  %t1341 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t1340)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1341, ptr %t1339, i64 %t1340, i1 false)
  %t1342 = insertvalue { i64, ptr } undef, i64 %t1338, 0
  %t1343 = insertvalue { i64, ptr } %t1342, ptr %t1341, 1
  %t1344 = load ptr, ptr %l629, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t1344, { i64, ptr } %t1343)
  br label %bb233
bb233:
  %t1346 = load ptr, ptr %l0, !tbaa !29
  %t1347 = load ptr, ptr %l2, !tbaa !29
  %t1349 = getelementptr %"compiler/ast:Func", ptr %t1347, i32 0, i32 4
  %t1350 = load { i64, ptr }, ptr %t1349, !tbaa !27
  %t1353 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %t1346, { i64, ptr } %t1350)
  store ptr %t1353, ptr %l641
  br label %bb234
bb234:
  %t1354 = load ptr, ptr %l641, !tbaa !29
  store ptr %t1354, ptr %l46, !tbaa !29
  %t1355 = load ptr, ptr %l0, !tbaa !29
  %t1357 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1355)
  store ptr %t1357, ptr %l643
  br label %bb235
bb235:
  %t1358 = load ptr, ptr %l643, !tbaa !29
  %t1359 = load ptr, ptr %l46, !tbaa !29
  %t1363 = getelementptr %"compiler/typed:Body", ptr %t1358, i32 0, i32 11
  store ptr %t1359, ptr %t1363, !tbaa !29
  %t1364 = load ptr, ptr %l39, !tbaa !29
  %t1366 = getelementptr %"compiler/check:frame", ptr %t1364, i32 0, i32 22
  %t1367 = load i1, ptr %t1366, !tbaa !21
  br i1 %t1367, label %bb236, label %bb237
bb236:
  %t1369 = load ptr, ptr %l39, !tbaa !29
  %t1371 = getelementptr %"compiler/check:frame", ptr %t1369, i32 0, i32 22
  store i1 false, ptr %t1371, !tbaa !21
  %t1372 = load ptr, ptr %l39, !tbaa !29
  %t1373 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1376 = getelementptr %"compiler/check:frame", ptr %t1372, i32 0, i32 5
  store i32 %t1373, ptr %t1376, !tbaa !23
  br label %bb238
bb237:
  br label %bb238
bb238:
  %t1377 = load ptr, ptr %l39, !tbaa !29
  %t1379 = getelementptr %"compiler/check:frame", ptr %t1377, i32 0, i32 5
  %t1380 = load i32, ptr %t1379, !tbaa !23
  store i32 %t1380, ptr %l19, !tbaa !23
  %t1382 = load i1, ptr %l28, !tbaa !21
  br i1 %t1382, label %bb239, label %bb240
bb239:
  store %olang.scope zeroinitializer, ptr %s36
  %t1384 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1384, ptr %l655, !tbaa !29
  %t1385 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1385, ptr %l656, !tbaa !29
  %t1386 = load ptr, ptr %l0, !tbaa !29
  %t1387 = load ptr, ptr %l39, !tbaa !29
  %t1390 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v0, ptr %s36, ptr %t1386, ptr %t1387)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1390, ptr %l659
  br label %bb241
bb240:
  br label %bb244
bb241:
  %t1391 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l659
  %t1392 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1391, ptr %t1392
  %t1393 = load ptr, ptr %l656, !tbaa !29
  %t1395 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %s36, ptr %s36, ptr %t1393, ptr %t1392)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1395, ptr %l661
  br label %bb242
bb242:
  %t1396 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l661
  %t1397 = call ptr @__olang_scope_alloc_a(ptr %s36, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1396, ptr %t1397
  %t1398 = load ptr, ptr %l655, !tbaa !29
  %t1400 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %s36, ptr %t1398, ptr %t1397)
  store i32 %t1400, ptr %l663
  br label %bb243
bb243:
  %t1401 = load i32, ptr %l663, !tbaa !23
  store i32 %t1401, ptr %l27, !tbaa !23
  call void @__olang_scope_close(ptr %s36)
  br label %bb244
bb244:
  %t1402 = load ptr, ptr %l0, !tbaa !29
  %t1404 = getelementptr %"compiler/check:Checker", ptr %t1402, i32 0, i32 1
  %t1405 = load ptr, ptr %t1404, !tbaa !29
  %t1407 = getelementptr %"compiler/generic:Program", ptr %t1405, i32 0, i32 2
  %t1408 = load i32, ptr %l35, !tbaa !23
  %t1409 = load i32, ptr %l19, !tbaa !23
  %t1410 = load i32, ptr %l27, !tbaa !23
  %t1411 = load i32, ptr %l34, !tbaa !23
  %t1417 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t1407, i32 %t1408, i32 %t1409, i32 %t1410, i32 %t1411, i64 0)
  store i32 %t1417, ptr %l671
  br label %bb245
bb245:
  %t1418 = load i32, ptr %l671, !tbaa !23
  store i32 %t1418, ptr %l47, !tbaa !23
  %t1419 = load ptr, ptr %l0, !tbaa !29
  %t1421 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t1419)
  store ptr %t1421, ptr %l673
  br label %bb246
bb246:
  %t1422 = load ptr, ptr %l673, !tbaa !29
  %t1423 = load i32, ptr %l47, !tbaa !23
  %t1426 = getelementptr %"compiler/typed:Body", ptr %t1422, i32 0, i32 2
  store i32 %t1423, ptr %t1426, !tbaa !23
  %t1427 = load i32, ptr %l19, !tbaa !23
  %t1428 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t1431 = icmp ne i32 %t1427, %t1428
  br i1 %t1431, label %bb247, label %bb248
bb247:
  %t1433 = load ptr, ptr %l0, !tbaa !29
  %t1435 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1433)
  store ptr %t1435, ptr %l681
  br label %bb249
bb248:
  store i1 false, ptr %l679, !tbaa !21
  br label %bb250
bb249:
  %t1436 = load ptr, ptr %l681, !tbaa !29
  %t1438 = getelementptr %"compiler/check:frame", ptr %t1436, i32 0, i32 20
  %t1439 = load i1, ptr %t1438, !tbaa !21
  %t1441 = xor i1 %t1439, true
  store i1 %t1441, ptr %l679, !tbaa !21
  br label %bb250
bb250:
  %t1443 = load i1, ptr %l679, !tbaa !21
  br i1 %t1443, label %bb251, label %bb252
bb251:
  %t1444 = load ptr, ptr %l46, !tbaa !29
  %t1447 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t1444)
  store i1 %t1447, ptr %l688
  br label %bb253
bb252:
  store i1 false, ptr %l685, !tbaa !21
  br label %bb254
bb253:
  %t1448 = load i1, ptr %l688, !tbaa !21
  %t1449 = xor i1 %t1448, true
  store i1 %t1449, ptr %l685, !tbaa !21
  br label %bb254
bb254:
  %t1451 = load i1, ptr %l685, !tbaa !21
  br i1 %t1451, label %bb255, label %bb256
bb255:
  store %olang.scope zeroinitializer, ptr %s37
  %t1452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1452, ptr %l690, !tbaa !29
  %t1453 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1453, ptr %l691
  %t1454 = load ptr, ptr %l0, !tbaa !29
  %t1455 = load i32, ptr %l19, !tbaa !23
  %t1458 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s37, ptr %t1454, i32 %t1455)
  store { i64, ptr } %t1458, ptr %l694
  br label %bb257
bb256:
  br label %bb260
bb257:
  %t1459 = load { i64, ptr }, ptr %l694, !tbaa !27
  %t1460 = extractvalue { i64, ptr } %t1459, 0
  %t1461 = extractvalue { i64, ptr } %t1459, 1
  %t1462 = mul i64 %t1460, 1
  %t1463 = call ptr @__olang_scope_alloc(ptr %s37, i64 %t1462)
  call void @llvm.memcpy.p0.p0.i64(ptr %t1463, ptr %t1461, i64 %t1462, i1 false)
  %t1464 = insertvalue { i64, ptr } undef, i64 %t1460, 0
  %t1465 = insertvalue { i64, ptr } %t1464, ptr %t1463, 1
  %t1467 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %s37, ptr %s37, { i64, ptr } %t1465)
  store %"compiler/msgs:Msg" %t1467, ptr %l696
  br label %bb258
bb258:
  %t1468 = load ptr, ptr %l690, !tbaa !29
  %t1469 = load %"compiler/source:Span", ptr %l691
  %t1470 = load %"compiler/msgs:Msg", ptr %l696
  %t1471 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s37, ptr %t1468, %"compiler/source:Span" %t1469, %"compiler/msgs:Msg" %t1470)
  store i64 %t1471, ptr %l697
  br label %bb259
bb259:
  call void @__olang_scope_close(ptr %s37)
  br label %bb260
bb260:
  %t1472 = load ptr, ptr %l0, !tbaa !29
  %t1474 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1472)
  store ptr %t1474, ptr %l699
  br label %bb261
bb261:
  %t1475 = load ptr, ptr %l699, !tbaa !29
  %t1477 = getelementptr %"compiler/check:frame", ptr %t1475, i32 0, i32 27
  %t1479 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v0, ptr %t1477)
  store { i64, ptr } %t1479, ptr %l702
  br label %bb262
bb262:
  %t1480 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t1480, ptr %lp48
  %t1481 = load { i64, ptr }, ptr %l702, !tbaa !27
  %t1482 = load ptr, ptr %lp48
  store { i64, ptr } %t1481, ptr %t1482, !tbaa !27
  %t1483 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t1483)
  br label %bb263
bb263:
  %t1485 = load ptr, ptr %l0, !tbaa !29
  %t1487 = getelementptr %"compiler/check:Checker", ptr %t1485, i32 0, i32 15
  %t1488 = load i64, ptr %l38, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t1487, i64 %t1488, i64 2)
  br label %bb264
bb264:
  %t1491 = load ptr, ptr %l0, !tbaa !29
  %t1493 = getelementptr %"compiler/check:Checker", ptr %t1491, i32 0, i32 59
  store ptr %t1493, ptr %l708, !tbaa !29
  %t1494 = load i64, ptr %l38, !tbaa !24
  store i64 %t1494, ptr %l709, !tbaa !24
  %t1495 = load ptr, ptr %l0, !tbaa !29
  %t1496 = load %"compiler/source:Span", ptr %l1
  %t1499 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t1495, %"compiler/source:Span" %t1496)
  store { i64, [3 x i64] } %t1499, ptr %l712
  br label %bb265
bb265:
  %t1500 = load i64, ptr %l709, !tbaa !24
  %t1501 = load { i64, [3 x i64] }, ptr %l712
  %t1502 = call %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v0, i64 %t1500, i64 0, { i64, [3 x i64] } %t1501, { i64, ptr } { i64 11, ptr @.d28 })
  store %"compiler/check:roFn" %t1502, ptr %l713
  br label %bb266
bb266:
  %t1503 = load ptr, ptr %l708, !tbaa !29
  %t1504 = load %"compiler/check:roFn", ptr %l713
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v0, ptr %t1503, %"compiler/check:roFn" %t1504)
  br label %bb267
bb267:
  %t1505 = load i32, ptr %l4, !tbaa !23
  %t1506 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t1509 = icmp eq i32 %t1505, %t1506
  br i1 %t1509, label %bb268, label %bb269
bb268:
  %t1511 = load ptr, ptr %l0, !tbaa !29
  %t1513 = getelementptr %"compiler/check:Checker", ptr %t1511, i32 0, i32 1
  %t1514 = load ptr, ptr %t1513, !tbaa !29
  %t1516 = getelementptr %"compiler/generic:Program", ptr %t1514, i32 0, i32 2
  store ptr %t1516, ptr %l720, !tbaa !29
  %t1517 = load i32, ptr %l47, !tbaa !23
  store i32 %t1517, ptr %l721, !tbaa !23
  %t1518 = load ptr, ptr %l0, !tbaa !29
  %t1520 = getelementptr %"compiler/check:Checker", ptr %t1518, i32 0, i32 1
  %t1521 = load ptr, ptr %t1520, !tbaa !29
  %t1522 = load ptr, ptr %l2, !tbaa !29
  %t1524 = getelementptr %"compiler/ast:Func", ptr %t1522, i32 0, i32 3
  %t1525 = load ptr, ptr %t1524, !tbaa !29
  %t1528 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %t1521, ptr %t1525)
  store i64 %t1528, ptr %l726
  br label %bb270
bb269:
  %t1529 = load ptr, ptr %l0, !tbaa !29
  %t1531 = getelementptr %"compiler/check:Checker", ptr %t1529, i32 0, i32 1
  %t1532 = load ptr, ptr %t1531, !tbaa !29
  %t1534 = getelementptr %"compiler/generic:Program", ptr %t1532, i32 0, i32 2
  store ptr %t1534, ptr %l730, !tbaa !29
  %t1535 = load i32, ptr %l47, !tbaa !23
  store i32 %t1535, ptr %l731, !tbaa !23
  %t1536 = load ptr, ptr %l0, !tbaa !29
  %t1538 = getelementptr %"compiler/check:Checker", ptr %t1536, i32 0, i32 1
  %t1539 = load ptr, ptr %t1538, !tbaa !29
  %t1541 = getelementptr %"compiler/generic:Program", ptr %t1539, i32 0, i32 2
  %t1542 = load i32, ptr %l4, !tbaa !23
  %t1545 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %t1541, i32 %t1542)
  store i64 %t1545, ptr %l736
  br label %bb272
bb270:
  %t1546 = load ptr, ptr %l720, !tbaa !29
  %t1547 = load i32, ptr %l721, !tbaa !23
  %t1548 = load i64, ptr %l726, !tbaa !24
  %t1549 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t1546, i32 %t1547, i64 %t1548)
  store i32 %t1549, ptr %l727
  br label %bb271
bb271:
  %t1550 = load i32, ptr %l727, !tbaa !23
  store i32 %t1550, ptr %l717, !tbaa !23
  br label %bb274
bb272:
  %t1551 = load ptr, ptr %l730, !tbaa !29
  %t1552 = load i32, ptr %l731, !tbaa !23
  %t1553 = load i64, ptr %l736, !tbaa !24
  %t1554 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %t1551, i32 %t1552, i64 %t1553)
  store i32 %t1554, ptr %l737
  br label %bb273
bb273:
  %t1555 = load i32, ptr %l737, !tbaa !23
  store i32 %t1555, ptr %l717, !tbaa !23
  br label %bb274
bb274:
  %t1556 = load i32, ptr %l717, !tbaa !23
  %t1557 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1557, ptr %l738
  store i32 %t1556, ptr %l739, !tbaa !23
  %t1559 = load i64, ptr %l38, !tbaa !24
  %t1561 = trunc i64 %t1559 to i32
  store i32 %t1561, ptr %l742, !tbaa !23
  %t1563 = load ptr, ptr %lp48
  %t1564 = load { i64, ptr }, ptr %t1563, !tbaa !27
  store { i64, ptr } %t1564, ptr %l743, !tbaa !27
  %t1565 = load ptr, ptr %l0, !tbaa !29
  %t1566 = load %"compiler/source:Span", ptr %l1
  %t1570 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t1565, i32 5, %"compiler/source:Span" %t1566)
  store i32 %t1570, ptr %l747
  br label %bb275
bb275:
  store { i64, [4 x i64] } zeroinitializer, ptr %t1571
  %t1572 = getelementptr { i64, [4 x i64] }, ptr %t1571, i32 0, i32 0
  store i64 1, ptr %t1572
  %t1573 = load i32, ptr %l742, !tbaa !23
  %t1574 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t1573, 0
  %t1575 = load { i64, ptr }, ptr %l743, !tbaa !27
  %t1576 = insertvalue { i32, { i64, ptr }, i32 } %t1574, { i64, ptr } %t1575, 1
  %t1577 = load i32, ptr %l747, !tbaa !23
  %t1578 = insertvalue { i32, { i64, ptr }, i32 } %t1576, i32 %t1577, 2
  %t1579 = getelementptr { i64, [4 x i64] }, ptr %t1571, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t1578, ptr %t1579
  %t1580 = load { i64, [4 x i64] }, ptr %t1571
  %t1582 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t1580, ptr %t1582
  store { i64, [5 x i64] } zeroinitializer, ptr %t1583
  %t1584 = getelementptr { i64, [5 x i64] }, ptr %t1583, i32 0, i32 0
  store i64 15, ptr %t1584
  %t1585 = load %"compiler/source:Span", ptr %l738
  %t1586 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1585, 0
  %t1587 = load i32, ptr %l739, !tbaa !23
  %t1588 = insertvalue { %"compiler/source:Span", i32, ptr } %t1586, i32 %t1587, 1
  %t1590 = insertvalue { %"compiler/source:Span", i32, ptr } %t1588, ptr %t1582, 2
  %t1591 = getelementptr { i64, [5 x i64] }, ptr %t1583, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1590, ptr %t1591
  %t1592 = load { i64, [5 x i64] }, ptr %t1583
  %t1594 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t1592, ptr %t1594
  call void @__olang_scope_close(ptr %s0)
  store ptr %t1594, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteral(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca i32
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l22 = alloca i32
  %l25 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l37 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l47 = alloca i32
  %l50 = alloca i64
  %l51 = alloca ptr
  %l56 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca %"compiler/source:Span"
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/msgs:Msg"
  %l72 = alloca i64
  %l75 = alloca ptr
  %l78 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca %"compiler/msgs:Msg"
  %l86 = alloca i64
  %l89 = alloca ptr
  %l94 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2
  %t3 = trunc i64 6 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  %t7 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t7, ptr %l8
  %t8 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t8, ptr %l9, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  %t13 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t9, %"compiler/source:Span" %t10)
  store { i64, ptr } %t13, ptr %l12
  br label %bb3
bb2:
  br label %bb9
bb3:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t14, { i64, ptr } { i64 4, ptr @.d29 })
  store i1 %t15, ptr %l13
  br label %bb4
bb4:
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  store i64 1, ptr %l14, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l8
  %t19 = load i32, ptr %l9, !tbaa !23
  %t20 = load i64, ptr %l14, !tbaa !24
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t17, %"compiler/source:Span" %t18, i32 %t19, i64 %t20)
  store ptr %t21, ptr %l15
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load ptr, ptr %l15, !tbaa !29
  store ptr %t22, ptr %rv
  br label %ret
bb9:
  %t23 = load i32, ptr %l2
  %t25 = trunc i64 7 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb10, label %bb11
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/generic:Program", ptr %t31, i32 0, i32 2
  %t34 = load i32, ptr %l3, !tbaa !23
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t33, i32 %t34)
  store i32 %t37, ptr %l22
  br label %bb12
bb11:
  br label %bb25
bb12:
  %t38 = load i32, ptr %l22
  store i32 %t38, ptr %l4
  %t39 = load i32, ptr %l4
  %t41 = trunc i64 20 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l3, !tbaa !23
  %t53 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t49, i32 %t50)
  store i1 %t53, ptr %l30
  br label %bb15
bb14:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb16
bb15:
  %t54 = load i1, ptr %l30, !tbaa !21
  store i1 %t54, ptr %l25, !tbaa !21
  br label %bb16
bb16:
  %t55 = load i1, ptr %l25, !tbaa !21
  br i1 %t55, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb19
bb18:
  %t56 = load i32, ptr %l4
  %t58 = trunc i64 21 to i32
  %t59 = icmp eq i32 %t56, %t58
  store i1 %t59, ptr %l31, !tbaa !21
  br label %bb19
bb19:
  %t61 = load i1, ptr %l31, !tbaa !21
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l1
  %t64 = load i32, ptr %l3, !tbaa !23
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t62, %"compiler/source:Span" %t63, i32 %t64, i64 0)
  store ptr %t68, ptr %l37
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load ptr, ptr %l37, !tbaa !29
  store ptr %t69, ptr %rv
  br label %ret
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, i32 %t72, i64 0)
  store ptr %t76, ptr %l41
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load ptr, ptr %l41, !tbaa !29
  store ptr %t77, ptr %rv
  br label %ret
bb25:
  %t78 = load i32, ptr %l2
  %t80 = trunc i64 4 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb26, label %bb27
bb26:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l44, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t84, ptr %l45
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %t85)
  store i32 %t87, ptr %l47
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load %"compiler/source:Span", ptr %l1
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t88, %"compiler/source:Span" %t89)
  store i64 %t92, ptr %l50
  br label %bb29
bb29:
  %t93 = load ptr, ptr %l44, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l45
  %t95 = load i32, ptr %l47, !tbaa !23
  %t96 = load i64, ptr %l50, !tbaa !24
  %t97 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t93, %"compiler/source:Span" %t94, i32 %t95, i64 %t96)
  store ptr %t97, ptr %l51
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t98 = load ptr, ptr %l51, !tbaa !29
  store ptr %t98, ptr %rv
  br label %ret
bb31:
  %t99 = load i32, ptr %l2
  %t101 = trunc i64 5 to i32
  %t102 = icmp eq i32 %t99, %t101
  br i1 %t102, label %bb32, label %bb33
bb32:
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load %"compiler/source:Span", ptr %l1
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %t104, %"compiler/source:Span" %t105)
  store ptr %t108, ptr %l56
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load ptr, ptr %l56, !tbaa !29
  store ptr %t109, ptr %rv
  br label %ret
bb35:
  %t110 = load i32, ptr %l2
  %t112 = trunc i64 2 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb36, label %bb37
bb36:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  %t119 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t115, %"compiler/source:Span" %t116)
  store { i64, ptr } %t119, ptr %l61
  br label %bb38
bb37:
  br label %bb48
bb38:
  %t120 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t121 = call i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %t120)
  store i1 %t121, ptr %l62
  br label %bb39
bb39:
  %t122 = load i1, ptr %l62, !tbaa !21
  %t123 = xor i1 %t122, true
  br i1 %t123, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l64, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t126, ptr %l65
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l1
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t127, %"compiler/source:Span" %t128)
  store { i64, ptr } %t131, ptr %l68
  br label %bb42
bb41:
  br label %bb46
bb42:
  %t132 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s7, { i64, ptr } %t132)
  store { i64, ptr } %t133, ptr %l69
  br label %bb43
bb43:
  %t134 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 0
  %t136 = extractvalue { i64, ptr } %t134, 1
  %t137 = mul i64 %t135, 1
  %t138 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t137)
  call void @llvm.memcpy.p0.p0.i64(ptr %t138, ptr %t136, i64 %t137, i1 false)
  %t139 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t138, 1
  %t142 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %s7, ptr %s7, { i64, ptr } %t140)
  store %"compiler/msgs:Msg" %t142, ptr %l71
  br label %bb44
bb44:
  %t143 = load ptr, ptr %l64, !tbaa !29
  %t144 = load %"compiler/source:Span", ptr %l65
  %t145 = load %"compiler/msgs:Msg", ptr %l71
  %t146 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t143, %"compiler/source:Span" %t144, %"compiler/msgs:Msg" %t145)
  store i64 %t146, ptr %l72
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t151 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t147, %"compiler/source:Span" %t148)
  store ptr %t151, ptr %l75
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t152 = load ptr, ptr %l75, !tbaa !29
  store ptr %t152, ptr %rv
  br label %ret
bb48:
  %t153 = load i32, ptr %l2
  %t155 = trunc i64 3 to i32
  %t156 = icmp eq i32 %t153, %t155
  br i1 %t156, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l78, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t159, ptr %l79
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load %"compiler/source:Span", ptr %l1
  %t164 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t160, %"compiler/source:Span" %t161)
  store { i64, ptr } %t164, ptr %l82
  br label %bb51
bb50:
  br label %bb56
bb51:
  %t165 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t166 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s8, { i64, ptr } %t165)
  store { i64, ptr } %t166, ptr %l83
  br label %bb52
bb52:
  %t167 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = mul i64 %t168, 1
  %t171 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t170)
  call void @llvm.memcpy.p0.p0.i64(ptr %t171, ptr %t169, i64 %t170, i1 false)
  %t172 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  %t175 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %s8, ptr %s8, { i64, ptr } %t173)
  store %"compiler/msgs:Msg" %t175, ptr %l85
  br label %bb53
bb53:
  %t176 = load ptr, ptr %l78, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l79
  %t178 = load %"compiler/msgs:Msg", ptr %l85
  %t179 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t176, %"compiler/source:Span" %t177, %"compiler/msgs:Msg" %t178)
  store i64 %t179, ptr %l86
  br label %bb54
bb54:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load %"compiler/source:Span", ptr %l1
  %t184 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t180, %"compiler/source:Span" %t181)
  store ptr %t184, ptr %l89
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t185 = load ptr, ptr %l89, !tbaa !29
  store ptr %t185, ptr %rv
  br label %ret
bb56:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s0, ptr %t186, %"compiler/source:Span" %t187, { i64, ptr } { i64 22, ptr @.d30 })
  br label %bb57
bb57:
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l1
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t190, %"compiler/source:Span" %t191)
  store ptr %t194, ptr %l94
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t195 = load ptr, ptr %l94, !tbaa !29
  store ptr %t195, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBinding(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, { i64, ptr } %a3, i64 %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i32
  %l31 = alloca i64
  %l34 = alloca i64
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l59 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca i64
  %l73 = alloca i32
  %l75 = alloca { i64, ptr }
  %l78 = alloca i1
  %l93 = alloca i32
  %l99 = alloca i64
  %l102 = alloca i64
  %l127 = alloca i1
  %l129 = alloca { i64, ptr }
  %l132 = alloca i1
  %l134 = alloca { i64, ptr }
  %l141 = alloca i32
  %l145 = alloca i1
  %l150 = alloca i64
  %l153 = alloca i1
  %l158 = alloca i64
  %l162 = alloca { i64, ptr }
  %l166 = alloca i1
  %l171 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i64
  %l175 = alloca i64
  %l181 = alloca i32
  %l183 = alloca i1
  %l185 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l6, !tbaa !24
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/generic:Binding", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t6 = load i64, ptr %l7, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t10 = icmp sgt i64 %t6, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l8, !tbaa !24
  %t14 = icmp sgt i64 %t12, 0
  br i1 %t14, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb3:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l6, !tbaa !24
  %t20 = sub i64 %t16, %t17
  %t21 = load i64, ptr %l8, !tbaa !24
  %t24 = add i64 %t20, %t21
  %t26 = sub i64 %t24, 1
  %t27 = load i64, ptr %l8, !tbaa !24
  %t30 = sdiv i64 %t26, %t27
  store i64 %t30, ptr %l34, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb5
bb5:
  %t32 = load i64, ptr %l34, !tbaa !24
  store i64 %t32, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l31, !tbaa !24
  store i64 %t33, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load i64, ptr %l10, !tbaa !24
  %t35 = load i64, ptr %l9, !tbaa !24
  %t38 = icmp slt i64 %t34, %t35
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb73
bb9:
  br label %bb10
bb10:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l10, !tbaa !24
  %t44 = load i64, ptr %l8, !tbaa !24
  %t47 = mul i64 %t43, %t44
  %t50 = add i64 %t42, %t47
  store i64 %t50, ptr %l11, !tbaa !24
  %t52 = load ptr, ptr %l2, !tbaa !29
  %t54 = getelementptr %"compiler/generic:Binding", ptr %t52, i32 0, i32 3
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l53, !tbaa !27
  %t56 = load i64, ptr %l11, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i1, ptr %t59, i64 %t56
  %t61 = load i1, ptr %t60, !tbaa !31
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l57, !tbaa !21
  br label %bb13
bb12:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Binding", ptr %t65, i32 0, i32 2
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l59, !tbaa !27
  %t69 = load i64, ptr %l11, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr i32, ptr %t72, i64 %t69
  %t74 = load i32, ptr %t73, !tbaa !33
  %t75 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t78 = icmp eq i32 %t74, %t75
  store i1 %t78, ptr %l57, !tbaa !21
  br label %bb13
bb13:
  %t80 = load i1, ptr %l57, !tbaa !21
  br i1 %t80, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb72
bb15:
  br label %bb16
bb16:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !29
  store ptr %t84, ptr %l65, !tbaa !29
  %t85 = load i64, ptr %l1, !tbaa !24
  store i64 %t85, ptr %l66, !tbaa !24
  %t86 = load i64, ptr %l11, !tbaa !24
  store i64 %t86, ptr %l67, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Binding", ptr %t93, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t99 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t92, { i64, ptr } %t96)
  store i32 %t99, ptr %l73
  br label %bb17
bb17:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Binding", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l75, !tbaa !27
  %t104 = load i64, ptr %l11, !tbaa !24
  %t106 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t104
  %t109 = load i32, ptr %t108, !tbaa !33
  %t110 = load ptr, ptr %l65, !tbaa !29
  %t111 = load i64, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l67, !tbaa !24
  %t113 = load i32, ptr %l73, !tbaa !23
  %t115 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %t110, i64 %t111, i64 %t112, i32 %t113, i32 %t109)
  store i1 %t115, ptr %l78
  br label %bb18
bb18:
  %t116 = load i1, ptr %l78, !tbaa !21
  br i1 %t116, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb72
bb20:
  br label %bb21
bb21:
  store ptr @G_2ecompiler_2fcheck_2eliteralOrder, ptr %l12
  store i64 0, ptr %l13, !tbaa !24
  %t118 = load ptr, ptr %l12
  store i64 12, ptr %l14, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t121 = load i64, ptr %l13, !tbaa !24
  %t122 = load i64, ptr %l14, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb24:
  br label %bb25
bb25:
  %t129 = load ptr, ptr %l12
  %t130 = load i64, ptr %l13, !tbaa !24
  %t133 = getelementptr [12 x { i64, ptr }], ptr %t129, i64 0, i64 %t130
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !37
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t143 = load ptr, ptr @__olang_prog_scope
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %t143, ptr %t141, { i64, ptr } %t134)
  store i32 %t146, ptr %l93
  br label %bb26
bb26:
  %t147 = load i32, ptr %l93, !tbaa !23
  store i32 %t147, ptr %l16, !tbaa !23
  store i1 true, ptr %l17, !tbaa !21
  store i64 0, ptr %l18, !tbaa !24
  %t148 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  store i64 %t150, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t152 = load i64, ptr %l19, !tbaa !24
  %t153 = load i64, ptr %l18, !tbaa !24
  %t156 = icmp sgt i64 %t152, %t153
  br i1 %t156, label %bb27, label %bb28
bb27:
  %t158 = load i64, ptr %l20, !tbaa !24
  %t160 = icmp sgt i64 %t158, 0
  br i1 %t160, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb32
bb29:
  %t162 = load i64, ptr %l19, !tbaa !24
  %t163 = load i64, ptr %l18, !tbaa !24
  %t166 = sub i64 %t162, %t163
  %t167 = load i64, ptr %l20, !tbaa !24
  %t170 = add i64 %t166, %t167
  %t172 = sub i64 %t170, 1
  %t173 = load i64, ptr %l20, !tbaa !24
  %t176 = sdiv i64 %t172, %t173
  store i64 %t176, ptr %l102, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb31
bb31:
  %t178 = load i64, ptr %l102, !tbaa !24
  store i64 %t178, ptr %l99, !tbaa !24
  br label %bb32
bb32:
  %t179 = load i64, ptr %l99, !tbaa !24
  store i64 %t179, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s8
  %t180 = load i64, ptr %l22, !tbaa !24
  %t181 = load i64, ptr %l21, !tbaa !24
  %t184 = icmp slt i64 %t180, %t181
  %t186 = xor i1 %t184, true
  br i1 %t186, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s8)
  br label %bb61
bb35:
  br label %bb36
bb36:
  %t188 = load i64, ptr %l18, !tbaa !24
  %t189 = load i64, ptr %l22, !tbaa !24
  %t190 = load i64, ptr %l20, !tbaa !24
  %t193 = mul i64 %t189, %t190
  %t196 = add i64 %t188, %t193
  store i64 %t196, ptr %l23, !tbaa !24
  %t198 = load i64, ptr %l23, !tbaa !24
  %t202 = add i64 %t198, %a4
  store i64 %t202, ptr %l24, !tbaa !24
  %t204 = load i64, ptr %l24, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t210 = icmp sge i64 %t204, %t207
  br i1 %t210, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l127, !tbaa !21
  br label %bb40
bb38:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t213, ptr %l129, !tbaa !27
  %t214 = load i64, ptr %l23, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr ptr, ptr %t217, i64 %t214
  %t219 = load ptr, ptr %t218, !tbaa !39
  %t222 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t212, ptr %t219)
  store i1 %t222, ptr %l132
  br label %bb39
bb39:
  %t223 = load i1, ptr %l132, !tbaa !21
  %t224 = xor i1 %t223, true
  store i1 %t224, ptr %l127, !tbaa !21
  br label %bb40
bb40:
  %t226 = load i1, ptr %l127, !tbaa !21
  br i1 %t226, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb42:
  br label %bb43
bb43:
  %t227 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t227, ptr %l134, !tbaa !27
  %t228 = load i64, ptr %l24, !tbaa !24
  %t230 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !27
  %t232 = getelementptr i32, ptr %t231, i64 %t228
  %t233 = load i32, ptr %t232, !tbaa !33
  store i32 %t233, ptr %l25, !tbaa !23
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/check:Checker", ptr %t235, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/generic:Program", ptr %t238, i32 0, i32 2
  %t241 = load i32, ptr %l25, !tbaa !23
  %t244 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t240, i32 %t241)
  store i32 %t244, ptr %l141
  br label %bb44
bb44:
  %t245 = load i32, ptr %l141
  %t247 = trunc i64 25 to i32
  %t248 = icmp eq i32 %t245, %t247
  %t250 = xor i1 %t248, true
  br i1 %t250, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb48
bb46:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = getelementptr %"compiler/generic:Program", ptr %t255, i32 0, i32 2
  %t258 = load i32, ptr %l25, !tbaa !23
  %t261 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t257, i32 %t258)
  store i64 %t261, ptr %l150
  br label %bb47
bb47:
  %t262 = load i64, ptr %l1, !tbaa !24
  %t263 = load i64, ptr %l150, !tbaa !24
  %t265 = icmp ne i64 %t263, %t262
  store i1 %t265, ptr %l145, !tbaa !21
  br label %bb48
bb48:
  %t267 = load i1, ptr %l145, !tbaa !21
  br i1 %t267, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb52
bb50:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l25, !tbaa !23
  %t277 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %t273, i32 %t274)
  store i64 %t277, ptr %l158
  br label %bb51
bb51:
  %t278 = load i64, ptr %l11, !tbaa !24
  %t279 = load i64, ptr %l158, !tbaa !24
  %t281 = icmp ne i64 %t279, %t278
  store i1 %t281, ptr %l153, !tbaa !21
  br label %bb52
bb52:
  %t283 = load i1, ptr %l153, !tbaa !21
  br i1 %t283, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb54:
  br label %bb55
bb55:
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t285, ptr %l162, !tbaa !27
  %t286 = load i64, ptr %l23, !tbaa !24
  %t288 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr ptr, ptr %t289, i64 %t286
  %t291 = load ptr, ptr %t290, !tbaa !39
  %t292 = load i32, ptr %l16, !tbaa !23
  %t296 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v3, ptr %t284, ptr %t291, i32 %t292)
  store i1 %t296, ptr %l166
  br label %bb56
bb56:
  %t297 = load i1, ptr %l166, !tbaa !21
  %t298 = xor i1 %t297, true
  br i1 %t298, label %bb57, label %bb58
bb57:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb59
bb58:
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s8)
  br label %bb60
bb60:
  %t300 = load i64, ptr %l22, !tbaa !24
  %t302 = add i64 %t300, 1
  store i64 %t302, ptr %l22, !tbaa !24
  br label %bb33
bb61:
  %t304 = load i1, ptr %l17, !tbaa !21
  br i1 %t304, label %bb62, label %bb63
bb62:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = getelementptr %"compiler/check:Checker", ptr %t306, i32 0, i32 1
  %t309 = load ptr, ptr %t308, !tbaa !29
  store ptr %t309, ptr %l173, !tbaa !29
  %t310 = load i64, ptr %l1, !tbaa !24
  store i64 %t310, ptr %l174, !tbaa !24
  %t311 = load i64, ptr %l11, !tbaa !24
  store i64 %t311, ptr %l175, !tbaa !24
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  %t318 = load ptr, ptr %l2, !tbaa !29
  %t320 = getelementptr %"compiler/generic:Binding", ptr %t318, i32 0, i32 2
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  %t324 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %t317, { i64, ptr } %t321)
  store i32 %t324, ptr %l181
  br label %bb64
bb63:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb66
bb64:
  %t325 = load i32, ptr %l16, !tbaa !23
  %t326 = load ptr, ptr %l173, !tbaa !29
  %t327 = load i64, ptr %l174, !tbaa !24
  %t328 = load i64, ptr %l175, !tbaa !24
  %t329 = load i32, ptr %l181, !tbaa !23
  %t331 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %t326, i64 %t327, i64 %t328, i32 %t329, i32 %t325)
  store i1 %t331, ptr %l183
  br label %bb65
bb65:
  %t332 = load i1, ptr %l183, !tbaa !21
  store i1 %t332, ptr %l171, !tbaa !21
  br label %bb66
bb66:
  %t333 = load i1, ptr %l171, !tbaa !21
  br i1 %t333, label %bb67, label %bb68
bb67:
  %t334 = load ptr, ptr %l2, !tbaa !29
  %t336 = getelementptr %"compiler/generic:Binding", ptr %t334, i32 0, i32 2
  %t337 = load { i64, ptr }, ptr %t336, !tbaa !27
  store { i64, ptr } %t337, ptr %l185, !tbaa !27
  %t338 = load i64, ptr %l11, !tbaa !24
  %t339 = load i32, ptr %l16, !tbaa !23
  %t342 = getelementptr { i64, ptr }, ptr %l185, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr i32, ptr %t343, i64 %t338
  store i32 %t339, ptr %t344, !tbaa !33
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s6)
  br label %bb70
bb70:
  %t345 = load i64, ptr %l13, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l13, !tbaa !24
  br label %bb22
bb71:
  call void @__olang_scope_close(ptr %s2)
  br label %bb72
bb72:
  %t349 = load i64, ptr %l10, !tbaa !24
  %t351 = add i64 %t349, 1
  store i64 %t351, ptr %l10, !tbaa !24
  br label %bb7
bb73:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l18 = alloca ptr
  %l21 = alloca i64
  %l25 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %t11, i64 %t12)
  store i64 %t15, ptr %l12
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t16 = load i64, ptr %l12, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  store i64 %t21, ptr %l15, !tbaa !24
  br label %bb7
bb6:
  %t23 = load i64, ptr %l3, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t25 = load i64, ptr %l15, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l18, !tbaa !29
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 12
  %t31 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t29)
  store i64 %t31, ptr %l21
  br label %bb9
bb9:
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = sub i64 %t32, 1
  %t34 = load i32, ptr %l1, !tbaa !23
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t36, i64 %t33, i32 %t34, %"compiler/source:Span" %a2)
  store i64 %t40, ptr %l25
  br label %bb10
bb10:
  %t41 = load i64, ptr %l25, !tbaa !24
  store i64 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, [2 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i64
  %l35 = alloca i64
  %l43 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca i1
  %l56 = alloca { i64, [2 x i64] }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l64 = alloca i1
  %l65 = alloca { i64, [2 x i64] }
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t34 = alloca { i64, [2 x i64] }, align 8
  %t59 = alloca { i64, [2 x i64] }, align 8
  %t79 = alloca { i64, [2 x i64] }, align 8
  %t94 = alloca { i64, [2 x i64] }, align 8
  %t140 = alloca { i64, [2 x i64] }, align 8
  %t144 = alloca { i64, [2 x i64] }, align 8
  %t149 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 5, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  store ptr %t9, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t10 = load ptr, ptr %l9, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t14 = load i64, ptr %t13
  %t16 = icmp eq i64 %t14, 3
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l10, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr { i64, [5 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t20, i32 0, i32 0
  %t22 = load %"compiler/source:Span", ptr %t21
  store %"compiler/source:Span" %t22, ptr %l2
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t26, i32 0, i32 2
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l3, !tbaa !23
  br label %bb8
bb7:
  br label %bb28
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load i32, ptr %l3, !tbaa !23
  %t32 = icmp eq i32 %t30, 0
  br i1 %t32, label %bb9, label %bb10
bb9:
  store { i64, [2 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [2 x i64] }, ptr %t34, i32 0, i32 0
  store i64 1, ptr %t35
  %t36 = load { i64, [2 x i64] }, ptr %t34
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t36, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l3, !tbaa !23
  %t42 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t38, i32 %t39)
  store { i64, ptr } %t42, ptr %l22
  br label %bb12
bb12:
  %t43 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t43, { i64, ptr } { i64 6, ptr @.d31 })
  store i1 %t44, ptr %l23
  br label %bb13
bb13:
  %t45 = load i1, ptr %l23, !tbaa !21
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasResultScope(ptr %v0, ptr %t46)
  store i1 %t48, ptr %l25
  br label %bb16
bb15:
  br label %bb22
bb16:
  %t49 = load i1, ptr %l25, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l27, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t53, ptr %l28
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnScopeNone(ptr %s5)
  store %"compiler/msgs:Msg" %t54, ptr %l29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t55 = load ptr, ptr %l27, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l28
  %t57 = load %"compiler/msgs:Msg", ptr %l29
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t55, %"compiler/source:Span" %t56, %"compiler/msgs:Msg" %t57)
  store i64 %t58, ptr %l30
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb21
bb21:
  store { i64, [2 x i64] } zeroinitializer, ptr %t59
  %t60 = getelementptr { i64, [2 x i64] }, ptr %t59, i32 0, i32 0
  store i64 4, ptr %t60
  %t61 = load { i64, [2 x i64] }, ptr %t59
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t61, ptr %rv
  br label %ret
bb22:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l3, !tbaa !23
  %t65 = load %"compiler/source:Span", ptr %l2
  %t69 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalOrCapture(ptr %v0, ptr %t63, i32 %t64, %"compiler/source:Span" %t65)
  store i64 %t69, ptr %l35
  br label %bb23
bb23:
  %t70 = load i64, ptr %l35, !tbaa !24
  store i64 %t70, ptr %l4, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  %t73 = icmp sge i64 %t71, 0
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t75 = load i64, ptr %l4, !tbaa !24
  %t77 = trunc i64 %t75 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t79
  %t80 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 0
  store i64 2, ptr %t80
  %t82 = insertvalue { i32 } undef, i32 %t77, 0
  %t83 = getelementptr { i64, [2 x i64] }, ptr %t79, i32 0, i32 1
  store { i32 } %t82, ptr %t83
  %t84 = load { i64, [2 x i64] }, ptr %t79
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t84, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t86)
  store ptr %t88, ptr %l43
  br label %bb27
bb27:
  %t89 = load ptr, ptr %l43, !tbaa !29
  %t91 = getelementptr %"compiler/check:frame", ptr %t89, i32 0, i32 1
  %t92 = load i64, ptr %t91, !tbaa !24
  %t93 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 0
  store i64 3, ptr %t95
  %t97 = insertvalue { i64, i32 } undef, i64 %t92, 0
  %t99 = insertvalue { i64, i32 } %t97, i32 %t93, 1
  %t100 = getelementptr { i64, [2 x i64] }, ptr %t94, i32 0, i32 1
  store { i64, i32 } %t99, ptr %t100
  %t101 = load { i64, [2 x i64] }, ptr %t94
  call void @__olang_scope_close(ptr %s2)
  store { i64, [2 x i64] } %t101, ptr %rv
  br label %ret
bb28:
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t104 = load ptr, ptr %l48, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l48, !tbaa !29
  %t108 = load i64, ptr %t107
  %t110 = icmp eq i64 %t108, 4
  store i1 %t110, ptr %l49, !tbaa !21
  br label %bb30
bb30:
  %t111 = load i1, ptr %l49, !tbaa !21
  br i1 %t111, label %bb31, label %bb32
bb31:
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr { i64, [5 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t114, i32 0, i32 1
  %t116 = load ptr, ptr %t115
  store ptr %t116, ptr %l5, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l5, !tbaa !29
  %t122 = call { i64, [2 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkOf(ptr %v0, ptr %v1, ptr %t118, ptr %t119)
  store { i64, [2 x i64] } %t122, ptr %l56
  br label %bb34
bb34:
  %t123 = load { i64, [2 x i64] }, ptr %l56
  store { i64, [2 x i64] } %t123, ptr %rv
  br label %ret
bb35:
  %t124 = load ptr, ptr %l1, !tbaa !29
  store ptr %t124, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t125 = load ptr, ptr %l57, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb36, label %bb37
bb36:
  %t128 = load ptr, ptr %l57, !tbaa !29
  %t129 = load i64, ptr %t128
  %t131 = icmp eq i64 %t129, 0
  store i1 %t131, ptr %l58, !tbaa !21
  br label %bb37
bb37:
  %t132 = load i1, ptr %l58, !tbaa !21
  br i1 %t132, label %bb38, label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb45
bb40:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t138 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t133, ptr %t134)
  store i1 %t138, ptr %l64
  br label %bb41
bb41:
  %t139 = load i1, ptr %l64, !tbaa !21
  br i1 %t139, label %bb42, label %bb43
bb42:
  store { i64, [2 x i64] } zeroinitializer, ptr %t140
  %t141 = getelementptr { i64, [2 x i64] }, ptr %t140, i32 0, i32 0
  store i64 5, ptr %t141
  %t142 = load { i64, [2 x i64] }, ptr %t140
  store { i64, [2 x i64] } %t142, ptr %l65
  br label %bb44
bb43:
  store { i64, [2 x i64] } zeroinitializer, ptr %t144
  %t145 = getelementptr { i64, [2 x i64] }, ptr %t144, i32 0, i32 0
  store i64 0, ptr %t145
  %t146 = load { i64, [2 x i64] }, ptr %t144
  store { i64, [2 x i64] } %t146, ptr %l65
  br label %bb44
bb44:
  %t148 = load { i64, [2 x i64] }, ptr %l65
  store { i64, [2 x i64] } %t148, ptr %rv
  br label %ret
bb45:
  store { i64, [2 x i64] } zeroinitializer, ptr %t149
  %t150 = getelementptr { i64, [2 x i64] }, ptr %t149, i32 0, i32 0
  store i64 0, ptr %t150
  %t151 = load { i64, [2 x i64] }, ptr %t149
  store { i64, [2 x i64] } %t151, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i1
  %l15 = alloca i32
  %l20 = alloca i1
  %l25 = alloca i64
  %l30 = alloca ptr
  %l35 = alloca i32
  %l37 = alloca i1
  %l40 = alloca ptr
  %l45 = alloca i32
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l54 = alloca i32
  %l56 = alloca i1
  %l59 = alloca ptr
  %l64 = alloca i32
  %l66 = alloca i1
  %l69 = alloca ptr
  %l74 = alloca i32
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca ptr
  %l83 = alloca i32
  %l85 = alloca i1
  %l86 = alloca i1
  %l87 = alloca ptr
  %l92 = alloca i32
  %l94 = alloca i1
  %l99 = alloca ptr
  %l104 = alloca i32
  %l106 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t3 = icmp eq i32 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l15
  br label %bb7
bb7:
  %t23 = load i32, ptr %l15
  store i32 %t23, ptr %l3
  %t24 = load i32, ptr %l3
  %t26 = trunc i64 25 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb15
bb10:
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = icmp slt i64 %t29, 0
  br i1 %t31, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb14
bb12:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %t38, i32 %t39)
  store i64 %t42, ptr %l25
  br label %bb13
bb13:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t44 = load i64, ptr %l25, !tbaa !24
  %t46 = icmp eq i64 %t44, %t43
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t48 = load i1, ptr %l20, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load i32, ptr %l3
  %t51 = trunc i64 18 to i32
  %t52 = icmp eq i32 %t49, %t51
  br i1 %t52, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t60 = getelementptr %"compiler/generic:Program", ptr %t58, i32 0, i32 2
  %t61 = load i32, ptr %l1, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t60, i32 %t61)
  store i32 %t64, ptr %l35
  br label %bb19
bb19:
  %t65 = load i64, ptr %l2, !tbaa !24
  %t66 = load ptr, ptr %l30, !tbaa !29
  %t67 = load i32, ptr %l35, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t66, i32 %t67, i64 %t65)
  store i1 %t69, ptr %l37
  br label %bb20
bb20:
  %t70 = load i1, ptr %l37, !tbaa !21
  store i1 %t70, ptr %rv
  br label %ret
bb21:
  %t71 = load i32, ptr %l3
  %t73 = trunc i64 19 to i32
  %t74 = icmp eq i32 %t71, %t73
  br i1 %t74, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l40, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l1, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l45
  br label %bb25
bb25:
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t89 = load i32, ptr %l45, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t88, i32 %t89, i64 %t87)
  store i1 %t91, ptr %l47
  br label %bb26
bb26:
  %t92 = load i1, ptr %l47, !tbaa !21
  br i1 %t92, label %bb27, label %bb28
bb27:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb31
bb28:
  %t93 = load ptr, ptr %l0, !tbaa !29
  store ptr %t93, ptr %l49, !tbaa !29
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  %t100 = load i32, ptr %l1, !tbaa !23
  %t103 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t99, i32 %t100)
  store i32 %t103, ptr %l54
  br label %bb29
bb29:
  %t104 = load i64, ptr %l2, !tbaa !24
  %t105 = load ptr, ptr %l49, !tbaa !29
  %t106 = load i32, ptr %l54, !tbaa !23
  %t108 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t105, i32 %t106, i64 %t104)
  store i1 %t108, ptr %l56
  br label %bb30
bb30:
  %t109 = load i1, ptr %l56, !tbaa !21
  store i1 %t109, ptr %l48, !tbaa !21
  br label %bb31
bb31:
  %t110 = load i1, ptr %l48, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
bb32:
  %t111 = load i32, ptr %l3
  %t113 = trunc i64 20 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb38
bb35:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l59, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l1, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l64
  br label %bb36
bb36:
  %t127 = load i64, ptr %l2, !tbaa !24
  %t128 = load ptr, ptr %l59, !tbaa !29
  %t129 = load i32, ptr %l64, !tbaa !23
  %t131 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t128, i32 %t129, i64 %t127)
  store i1 %t131, ptr %l66
  br label %bb37
bb37:
  %t132 = load i1, ptr %l66, !tbaa !21
  store i1 %t132, ptr %rv
  br label %ret
bb38:
  %t133 = load i32, ptr %l3
  %t135 = trunc i64 21 to i32
  %t136 = icmp eq i32 %t133, %t135
  br i1 %t136, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb54
bb41:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l69, !tbaa !29
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t141 = getelementptr %"compiler/check:Checker", ptr %t139, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/generic:Program", ptr %t142, i32 0, i32 2
  %t145 = load i32, ptr %l1, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l74
  br label %bb42
bb42:
  %t149 = load i64, ptr %l2, !tbaa !24
  %t150 = load ptr, ptr %l69, !tbaa !29
  %t151 = load i32, ptr %l74, !tbaa !23
  %t153 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t150, i32 %t151, i64 %t149)
  store i1 %t153, ptr %l76
  br label %bb43
bb43:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l77, !tbaa !21
  br label %bb48
bb45:
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l78, !tbaa !29
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t162 = load i32, ptr %l1, !tbaa !23
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t161, i32 %t162)
  store i32 %t165, ptr %l83
  br label %bb46
bb46:
  %t166 = load i64, ptr %l2, !tbaa !24
  %t167 = load ptr, ptr %l78, !tbaa !29
  %t168 = load i32, ptr %l83, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ementionsVar(ptr %v0, ptr %t167, i32 %t168, i64 %t166)
  store i1 %t170, ptr %l85
  br label %bb47
bb47:
  %t171 = load i1, ptr %l85, !tbaa !21
  store i1 %t171, ptr %l77, !tbaa !21
  br label %bb48
bb48:
  %t172 = load i1, ptr %l77, !tbaa !21
  br i1 %t172, label %bb49, label %bb50
bb49:
  store i1 true, ptr %l86, !tbaa !21
  br label %bb53
bb50:
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l87, !tbaa !29
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %l1, !tbaa !23
  %t183 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t179, i32 %t180)
  store i32 %t183, ptr %l92
  br label %bb51
bb51:
  %t184 = load i64, ptr %l2, !tbaa !24
  %t185 = load ptr, ptr %l87, !tbaa !29
  %t186 = load i32, ptr %l92, !tbaa !23
  %t188 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t185, i32 %t186, i64 %t184)
  store i1 %t188, ptr %l94
  br label %bb52
bb52:
  %t189 = load i1, ptr %l94, !tbaa !21
  store i1 %t189, ptr %l86, !tbaa !21
  br label %bb53
bb53:
  %t190 = load i1, ptr %l86, !tbaa !21
  store i1 %t190, ptr %rv
  br label %ret
bb54:
  %t191 = load i32, ptr %l3
  %t193 = trunc i64 22 to i32
  %t194 = icmp eq i32 %t191, %t193
  br i1 %t194, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  %t196 = load i32, ptr %l3
  %t198 = trunc i64 23 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb57, label %bb58
bb57:
  br label %bb59
bb58:
  br label %bb62
bb59:
  %t201 = load ptr, ptr %l0, !tbaa !29
  store ptr %t201, ptr %l99, !tbaa !29
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/check:Checker", ptr %t202, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/generic:Program", ptr %t205, i32 0, i32 2
  %t208 = load i32, ptr %l1, !tbaa !23
  %t211 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t207, i32 %t208)
  store i32 %t211, ptr %l104
  br label %bb60
bb60:
  %t212 = load i64, ptr %l2, !tbaa !24
  %t213 = load ptr, ptr %l99, !tbaa !29
  %t214 = load i32, ptr %l104, !tbaa !23
  %t216 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %t213, i32 %t214, i64 %t212)
  store i1 %t216, ptr %l106
  br label %bb61
bb61:
  %t217 = load i1, ptr %l106, !tbaa !21
  store i1 %t217, ptr %rv
  br label %ret
bb62:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l5 = alloca i64
  %l12 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 31
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 31
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t9, ptr %a1)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 31
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l12
  br label %bb3
bb3:
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca %"compiler/source:Span"
  %l29 = alloca %"compiler/source:Span"
  %l31 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l35 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopOf(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store %"compiler/source:Span" %t20, ptr %l14
  br label %bb6
bb6:
  %t21 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t23 = load ptr, ptr %l15, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %t26
  %t29 = icmp eq i64 %t27, 5
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [5 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34
  store i32 %t35, ptr %l3
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l4, !tbaa !29
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb17
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l25, !tbaa !29
  %t50 = load ptr, ptr %l4, !tbaa !29
  %t52 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t50)
  store %"compiler/source:Span" %t52, ptr %l27
  br label %bb13
bb13:
  %t53 = load ptr, ptr %l5, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l29
  br label %bb14
bb14:
  %t56 = load i32, ptr %l3
  %t58 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s2, i32 %t56)
  store { i64, ptr } %t58, ptr %l31
  br label %bb15
bb15:
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = load ptr, ptr %l25, !tbaa !29
  %t62 = load %"compiler/source:Span", ptr %l27
  %t63 = load %"compiler/source:Span", ptr %l29
  %t65 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t61, %"compiler/source:Span" %t62, %"compiler/source:Span" %t63, i64 %t60)
  store %"compiler/source:Span" %t65, ptr %l33
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  %t66 = load %"compiler/source:Span", ptr %l33
  store %"compiler/source:Span" %t66, ptr %rv
  br label %ret
bb17:
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t69 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t67)
  store %"compiler/source:Span" %t69, ptr %l35
  br label %bb18
bb18:
  %t70 = load %"compiler/source:Span", ptr %l35
  store %"compiler/source:Span" %t70, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca i1
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l17 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l35 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i32
  %l53 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %l64 = alloca i1
  %l67 = alloca i1
  %l69 = alloca i1
  %l72 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i32
  %l80 = alloca i32
  %l82 = alloca i32
  %l86 = alloca { i64, ptr }
  %l90 = alloca %"compiler/source:Span"
  %l92 = alloca ptr
  %l94 = alloca ptr
  %l100 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca ptr
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l116 = alloca %"compiler/msgs:Msg"
  %l117 = alloca i64
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Param", ptr %t2, i32 0, i32 2
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_70239da7d97117f8_be3796eb66d568d4)
  unreachable
bb2:
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Param", ptr %t9, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %t14, ptr %t12, i32 %t13)
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t19 = getelementptr %"compiler/ast:Param", ptr %t17, i32 0, i32 2
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = getelementptr %"compiler/ast:Param", ptr %t27, i32 0, i32 2
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t33 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t26, ptr %t30)
  store i1 %t33, ptr %l21
  br label %bb7
bb6:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb8
bb7:
  %t34 = load i1, ptr %l21, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l17, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t38, i32 %t39)
  store i1 %t42, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t43 = load i1, ptr %l26, !tbaa !21
  %t44 = xor i1 %t43, true
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t46 = load i1, ptr %l23, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 %a3, ptr %l28, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb15
bb15:
  %t49 = load i1, ptr %l28, !tbaa !21
  br i1 %t49, label %bb16, label %bb17
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l2, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb18
bb17:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb19
bb18:
  %t60 = load i32, ptr %l35
  %t62 = trunc i64 19 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load i32, ptr %l2, !tbaa !23
  %t72 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapParam(ptr %v0, ptr %v1, ptr %t66, ptr %t67, i32 %t68)
  store i1 %t72, ptr %l41
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t73 = load i1, ptr %l41, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
bb23:
  store i1 false, ptr %l4, !tbaa !21
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t74, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l2, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l46
  br label %bb24
bb24:
  %t84 = load i32, ptr %l46
  %t86 = trunc i64 19 to i32
  %t87 = icmp eq i32 %t84, %t86
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb25, label %bb26
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t93 = load i32, ptr %l2, !tbaa !23
  %t97 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapParam(ptr %v0, ptr %v1, ptr %t91, ptr %t92, i32 %t93)
  store i1 %t97, ptr %l53
  br label %bb27
bb26:
  br label %bb28
bb27:
  %t98 = load i1, ptr %l53, !tbaa !21
  store i1 %t98, ptr %l4, !tbaa !21
  br label %bb28
bb28:
  %t99 = load ptr, ptr %l1, !tbaa !29
  %t101 = getelementptr %"compiler/ast:Param", ptr %t99, i32 0, i32 2
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t104 = icmp eq ptr %t102, null
  %t106 = xor i1 %t104, true
  br i1 %t106, label %bb29, label %bb30
bb29:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Param", ptr %t109, i32 0, i32 2
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t115 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %t108, ptr %t112)
  store i1 %t115, ptr %l62
  br label %bb31
bb30:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb32
bb31:
  %t116 = load i1, ptr %l62, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l58, !tbaa !21
  br label %bb32
bb32:
  %t119 = load i1, ptr %l58, !tbaa !21
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load i32, ptr %l2, !tbaa !23
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t120, i32 %t121)
  store i1 %t124, ptr %l67
  br label %bb35
bb34:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb36
bb35:
  %t125 = load i1, ptr %l67, !tbaa !21
  %t126 = xor i1 %t125, true
  store i1 %t126, ptr %l64, !tbaa !21
  br label %bb36
bb36:
  %t128 = load i1, ptr %l64, !tbaa !21
  br i1 %t128, label %bb37, label %bb38
bb37:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t129, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  store ptr %t134, ptr %l72, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l2, !tbaa !23
  %t139 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t135, i32 %t136)
  store i32 %t139, ptr %l75
  br label %bb39
bb38:
  store i1 false, ptr %l69, !tbaa !21
  br label %bb41
bb39:
  %t140 = load ptr, ptr %l72, !tbaa !29
  %t141 = load i32, ptr %l75, !tbaa !23
  %t142 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t140, i32 %t141)
  store i32 %t142, ptr %l76
  br label %bb40
bb40:
  %t143 = load i32, ptr %l76
  %t145 = trunc i64 19 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l69, !tbaa !21
  br label %bb41
bb41:
  %t148 = load i1, ptr %l69, !tbaa !21
  br i1 %t148, label %bb42, label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s3
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr %"compiler/ast:Param", ptr %t149, i32 0, i32 0
  %t152 = getelementptr %"compiler/source:Span", ptr %t151, i32 0, i32 0
  %t153 = load i32, ptr %t152, !tbaa !23
  store i32 %t153, ptr %l80, !tbaa !23
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Param", ptr %t154, i32 0, i32 0
  %t157 = getelementptr %"compiler/source:Span", ptr %t156, i32 0, i32 0
  %t158 = load i32, ptr %t157, !tbaa !23
  store i32 %t158, ptr %l82, !tbaa !23
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Param", ptr %t160, i32 0, i32 1
  %t163 = load i32, ptr %t162, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t159, i32 %t163)
  store { i64, ptr } %t166, ptr %l86
  br label %bb44
bb43:
  br label %bb57
bb44:
  %t167 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  %t170 = trunc i64 %t168 to i32
  %t171 = load i32, ptr %l82, !tbaa !23
  %t173 = add i32 %t171, %t170
  %t174 = load i32, ptr %l80, !tbaa !23
  %t176 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t174, i32 %t173)
  store %"compiler/source:Span" %t176, ptr %l90
  br label %bb45
bb45:
  %t177 = load %"compiler/source:Span", ptr %l90
  store %"compiler/source:Span" %t177, ptr %l5
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr %"compiler/check:Checker", ptr %t178, i32 0, i32 18
  store ptr %t180, ptr %l92, !tbaa !29
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t181)
  store ptr %t183, ptr %l94
  br label %bb46
bb46:
  %t184 = load ptr, ptr %l94, !tbaa !29
  %t186 = getelementptr %"compiler/check:frame", ptr %t184, i32 0, i32 2
  %t187 = load i64, ptr %t186, !tbaa !24
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t190 = getelementptr %"compiler/ast:Param", ptr %t188, i32 0, i32 0
  %t191 = getelementptr %"compiler/source:Span", ptr %t190, i32 0, i32 0
  %t192 = load i32, ptr %t191, !tbaa !23
  %t194 = sext i32 %t192 to i64
  %t197 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s3, i64 %t187, i64 %t194)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t197, ptr %l100
  br label %bb47
bb47:
  %t198 = load ptr, ptr %l92, !tbaa !29
  %t199 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l100
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t198, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t199, i1 true)
  br label %bb48
bb48:
  %t200 = load ptr, ptr %l0, !tbaa !29
  store ptr %t200, ptr %l101, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t201, ptr %l102
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load ptr, ptr %l1, !tbaa !29
  %t205 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 1
  %t206 = load i32, ptr %t205, !tbaa !23
  %t209 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t202, i32 %t206)
  store { i64, ptr } %t209, ptr %l106
  br label %bb49
bb49:
  %t210 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l107, !tbaa !27
  %t217 = load ptr, ptr %l0, !tbaa !29
  store ptr %t217, ptr %l108, !tbaa !29
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Param", ptr %t218, i32 0, i32 2
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = icmp eq ptr %t221, null
  br i1 %t223, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_397a47855f80e417_31e96358085bf9e3)
  unreachable
bb51:
  br label %bb52
bb52:
  %t225 = load ptr, ptr %l1, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Param", ptr %t225, i32 0, i32 2
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t228)
  store %"compiler/source:Span" %t230, ptr %l114
  br label %bb53
bb53:
  %t231 = load ptr, ptr %l108, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l114
  %t233 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t231, %"compiler/source:Span" %t232)
  store { i64, ptr } %t233, ptr %l115
  br label %bb54
bb54:
  %t234 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t236 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %s3, ptr %v0, ptr %s3, { i64, ptr } %t234, { i64, ptr } %t235)
  store %"compiler/msgs:Msg" %t236, ptr %l116
  br label %bb55
bb55:
  %t237 = load ptr, ptr %l101, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l102
  %t239 = load %"compiler/msgs:Msg", ptr %l116
  %t240 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t237, %"compiler/source:Span" %t238, %"compiler/msgs:Msg" %t239)
  store i64 %t240, ptr %l117
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb57:
  %t241 = load i1, ptr %l4, !tbaa !21
  store i1 %t241, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca { i64, [3 x i64] }
  %l11 = alloca i32
  %l12 = alloca %"compiler/typed:Local"
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca %"compiler/source:Span"
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca i64
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca i32
  %lp29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %lp40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %lp47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca i1
  %l70 = alloca i64
  %l73 = alloca i1
  %l75 = alloca ptr
  %l79 = alloca %"compiler/typed:Local"
  %l84 = alloca i1
  %l86 = alloca ptr
  %l90 = alloca %"compiler/typed:Local"
  %l100 = alloca i64
  %l103 = alloca { i64, [3 x i64] }
  %l108 = alloca ptr
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l121 = alloca %"compiler/typed:Local"
  %l124 = alloca i1
  %l126 = alloca i1
  %l131 = alloca ptr
  %l135 = alloca %"compiler/typed:Local"
  %l139 = alloca i1
  %l140 = alloca i1
  %l143 = alloca i1
  %l144 = alloca i1
  %l147 = alloca ptr
  %l152 = alloca i32
  %l157 = alloca i32
  %l158 = alloca i1
  %l160 = alloca ptr
  %l164 = alloca %"compiler/typed:Local"
  %l167 = alloca ptr
  %l172 = alloca i32
  %l177 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i32
  %l186 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca %"compiler/source:Span"
  %l195 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l201 = alloca %"compiler/msgs:Msg"
  %l202 = alloca i64
  %l203 = alloca ptr
  %l204 = alloca i64
  %l208 = alloca ptr
  %l209 = alloca ptr
  %l212 = alloca i32
  %l216 = alloca ptr
  %l217 = alloca %"compiler/typed:Bind"
  %l222 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca i1
  %l233 = alloca i32
  %l237 = alloca i64
  %l244 = alloca ptr
  %l247 = alloca i32
  %l249 = alloca ptr
  %l250 = alloca i1
  %l259 = alloca i32
  %l262 = alloca i1
  %l263 = alloca i1
  %l266 = alloca i1
  %l271 = alloca i32
  %l276 = alloca i32
  %l278 = alloca ptr
  %l279 = alloca %"compiler/source:Span"
  %l282 = alloca { i64, ptr }
  %l284 = alloca %"compiler/source:Span"
  %l288 = alloca %"compiler/msgs:Msg"
  %l289 = alloca i64
  %l293 = alloca ptr
  %l296 = alloca i1
  %l299 = alloca i1
  %l300 = alloca i1
  %l303 = alloca i1
  %l304 = alloca i1
  %l309 = alloca i32
  %l314 = alloca i32
  %l317 = alloca ptr
  %l319 = alloca %"compiler/source:Span"
  %l322 = alloca { i64, ptr }
  %l323 = alloca { i64, ptr }
  %l324 = alloca ptr
  %l326 = alloca %"compiler/source:Span"
  %l327 = alloca { i64, ptr }
  %l328 = alloca { i64, ptr }
  %l330 = alloca %"compiler/msgs:Msg"
  %l331 = alloca i64
  %l335 = alloca ptr
  %l341 = alloca ptr
  %l342 = alloca ptr
  %l343 = alloca i1
  %l354 = alloca i32
  %l358 = alloca i64
  %l361 = alloca ptr
  %l362 = alloca i1
  %l373 = alloca i32
  %l376 = alloca i1
  %l377 = alloca i1
  %l380 = alloca i1
  %l385 = alloca i32
  %l390 = alloca i32
  %l392 = alloca ptr
  %l393 = alloca %"compiler/source:Span"
  %l396 = alloca { i64, ptr }
  %l398 = alloca %"compiler/source:Span"
  %l402 = alloca %"compiler/msgs:Msg"
  %l403 = alloca i64
  %l407 = alloca ptr
  %l408 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l416 = alloca { i64, ptr }
  %l419 = alloca ptr
  %l420 = alloca i1
  %l425 = alloca ptr
  %l426 = alloca i1
  %l433 = alloca ptr
  %l435 = alloca %"compiler/source:Span"
  %l439 = alloca ptr
  %l442 = alloca ptr
  %l443 = alloca %"compiler/source:Span"
  %l444 = alloca ptr
  %l445 = alloca %"compiler/source:Span"
  %l446 = alloca ptr
  %l448 = alloca { i64, ptr }
  %l452 = alloca ptr
  %l457 = alloca ptr
  %l462 = alloca i32
  %l465 = alloca ptr
  %l470 = alloca i32
  %l471 = alloca { i64, ptr }
  %l477 = alloca ptr
  %l478 = alloca %"compiler/source:Span"
  %l480 = alloca i64
  %l484 = alloca { i64, ptr }
  %l487 = alloca %"compiler/msgs:Msg"
  %l488 = alloca i64
  %l492 = alloca ptr
  %l496 = alloca i1
  %l497 = alloca %"compiler/source:Span"
  %l498 = alloca i32
  %l502 = alloca ptr
  %l507 = alloca ptr
  %l512 = alloca i32
  %l513 = alloca { i64, ptr }
  %l514 = alloca { i64, ptr }
  %l517 = alloca %"compiler/source:Span"
  %l518 = alloca i32
  %l522 = alloca %"compiler/typed:Payload"
  %l530 = alloca i64
  %l533 = alloca i64
  %l551 = alloca { i64, ptr }
  %l554 = alloca %"compiler/source:Span"
  %l555 = alloca { i64, ptr }
  %l561 = alloca ptr
  %l562 = alloca %"compiler/source:Span"
  %l563 = alloca ptr
  %l565 = alloca { i64, ptr }
  %l569 = alloca { i64, ptr }
  %l574 = alloca ptr
  %l575 = alloca ptr
  %l579 = alloca ptr
  %l580 = alloca i1
  %l593 = alloca ptr
  %s8 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca ptr
  %t98 = alloca { i64, [2 x i64] }, align 8
  %t850 = alloca { i64, [5 x i64] }, align 8
  %t968 = alloca { i64, [4 x i64] }, align 8
  %t1018 = alloca { i64, [4 x i64] }, align 8
  %t1099 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t2 = load ptr, ptr %l50, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l50, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l51, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l51, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span" }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l6
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l6
  %t18 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t22 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t16, %"compiler/source:Span" %t17, i32 %t18, i64 1)
  store ptr %t22, ptr %l59
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l59, !tbaa !29
  store ptr %t23, ptr %rv
  br label %ret
bb7:
  %t24 = load ptr, ptr %l1, !tbaa !29
  store ptr %t24, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t25 = load ptr, ptr %l60, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb8, label %bb9
bb8:
  %t28 = load ptr, ptr %l60, !tbaa !29
  %t29 = load i64, ptr %t28
  %t31 = icmp eq i64 %t29, 3
  store i1 %t31, ptr %l61, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l61, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t35 = getelementptr { i64, [4 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { %"compiler/source:Span", i32 }, ptr %t35, i32 0, i32 0
  %t37 = load %"compiler/source:Span", ptr %t36
  store %"compiler/source:Span" %t37, ptr %l7
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l8, !tbaa !23
  br label %bb12
bb11:
  br label %bb78
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load i32, ptr %l8, !tbaa !23
  %t49 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t45, i32 %t46)
  store i64 %t49, ptr %l70
  br label %bb13
bb13:
  %t50 = load i64, ptr %l70, !tbaa !24
  store i64 %t50, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp slt i64 %t51, 0
  br i1 %t53, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb18
bb15:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t55)
  store ptr %t57, ptr %l75
  br label %bb16
bb16:
  %t58 = load ptr, ptr %l75, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Body", ptr %t58, i32 0, i32 7
  %t61 = load i64, ptr %l9, !tbaa !24
  %t64 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t60, i64 %t61)
  store %"compiler/typed:Local" %t64, ptr %l79
  br label %bb17
bb17:
  %t65 = getelementptr %"compiler/typed:Local", ptr %l79, i32 0, i32 3
  %t66 = load i32, ptr %t65, !tbaa !23
  %t68 = sext i32 %t66 to i64
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp ne i64 %t68, %t69
  store i1 %t72, ptr %l73, !tbaa !21
  br label %bb18
bb18:
  %t74 = load i1, ptr %l73, !tbaa !21
  br i1 %t74, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb23
bb20:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t75)
  store ptr %t77, ptr %l86
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l86, !tbaa !29
  %t80 = getelementptr %"compiler/typed:Body", ptr %t78, i32 0, i32 7
  %t81 = load i64, ptr %l9, !tbaa !24
  %t84 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t80, i64 %t81)
  store %"compiler/typed:Local" %t84, ptr %l90
  br label %bb22
bb22:
  %t85 = getelementptr %"compiler/typed:Local", ptr %l90, i32 0, i32 4
  %t86 = load i32, ptr %t85
  %t88 = trunc i64 4 to i32
  %t89 = icmp eq i32 %t86, %t88
  %t91 = xor i1 %t89, true
  store i1 %t91, ptr %l84, !tbaa !21
  br label %bb23
bb23:
  %t93 = load i1, ptr %l84, !tbaa !21
  br i1 %t93, label %bb24, label %bb25
bb24:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l8, !tbaa !23
  %t96 = load %"compiler/source:Span", ptr %l7
  %t97 = load i32, ptr %l3, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t98
  %t99 = getelementptr { i64, [2 x i64] }, ptr %t98, i32 0, i32 0
  store i64 5, ptr %t99
  %t100 = load { i64, [2 x i64] }, ptr %t98
  %t107 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t94, i32 %t95, %"compiler/source:Span" %t96, i32 %t97, i32 4, { i64, [2 x i64] } %t100)
  store i64 %t107, ptr %l100
  br label %bb26
bb25:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  store ptr %t113, ptr %l115, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t114)
  store ptr %t116, ptr %l117
  br label %bb33
bb26:
  %t117 = load i64, ptr %l100, !tbaa !24
  store i64 %t117, ptr %l9, !tbaa !24
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t122 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v0, ptr %t118, ptr %t119)
  store { i64, [3 x i64] } %t122, ptr %l103
  br label %bb27
bb27:
  %t123 = load { i64, [3 x i64] }, ptr %l103
  store { i64, [3 x i64] } %t123, ptr %l10
  %t124 = load { i64, [3 x i64] }, ptr %l10
  %t126 = extractvalue { i64, [3 x i64] } %t124, 0
  %t127 = icmp eq i64 %t126, 0
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t131)
  store ptr %t133, ptr %l108
  br label %bb30
bb29:
  br label %bb32
bb30:
  %t134 = load ptr, ptr %l108, !tbaa !29
  %t136 = getelementptr %"compiler/check:frame", ptr %t134, i32 0, i32 3
  %t137 = load i64, ptr %l9, !tbaa !24
  %t138 = load { i64, [3 x i64] }, ptr %l10
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %t136, i64 %t137, { i64, [3 x i64] } %t138)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb71
bb33:
  %t142 = load ptr, ptr %l117, !tbaa !29
  %t144 = getelementptr %"compiler/typed:Body", ptr %t142, i32 0, i32 7
  %t145 = load i64, ptr %l9, !tbaa !24
  %t148 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t144, i64 %t145)
  store %"compiler/typed:Local" %t148, ptr %l121
  br label %bb34
bb34:
  %t149 = getelementptr %"compiler/typed:Local", ptr %l121, i32 0, i32 2
  %t150 = load i32, ptr %t149, !tbaa !23
  %t151 = load i32, ptr %l3, !tbaa !23
  %t152 = load ptr, ptr %l115, !tbaa !29
  %t155 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t152, i32 %t150, i32 %t151)
  store i1 %t155, ptr %l124
  br label %bb35
bb35:
  %t156 = load i1, ptr %l124, !tbaa !21
  %t157 = xor i1 %t156, true
  br i1 %t157, label %bb36, label %bb37
bb36:
  %t159 = load i32, ptr %l3, !tbaa !23
  %t160 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t163 = icmp ne i32 %t159, %t160
  store i1 %t163, ptr %l126, !tbaa !21
  br label %bb38
bb37:
  store i1 false, ptr %l126, !tbaa !21
  br label %bb38
bb38:
  %t165 = load i1, ptr %l126, !tbaa !21
  br i1 %t165, label %bb39, label %bb40
bb39:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t166)
  store ptr %t168, ptr %l131
  br label %bb41
bb40:
  br label %bb70
bb41:
  %t169 = load ptr, ptr %l131, !tbaa !29
  %t171 = getelementptr %"compiler/typed:Body", ptr %t169, i32 0, i32 7
  %t172 = load i64, ptr %l9, !tbaa !24
  %t175 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t171, i64 %t172)
  store %"compiler/typed:Local" %t175, ptr %l135
  br label %bb42
bb42:
  %t176 = getelementptr %"compiler/typed:Local", ptr %l135, i32 0, i32 2
  %t177 = load i32, ptr %t176, !tbaa !23
  store i32 %t177, ptr %l11, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load i32, ptr %l11, !tbaa !23
  %t183 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t179, i32 %t180)
  store i1 %t183, ptr %l139
  br label %bb43
bb43:
  %t184 = load i1, ptr %l139, !tbaa !21
  br i1 %t184, label %bb44, label %bb45
bb44:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l3, !tbaa !23
  %t189 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t185, i32 %t186)
  store i1 %t189, ptr %l143
  br label %bb46
bb45:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb47
bb46:
  %t190 = load i1, ptr %l143, !tbaa !21
  store i1 %t190, ptr %l140, !tbaa !21
  br label %bb47
bb47:
  %t191 = load i1, ptr %l140, !tbaa !21
  br i1 %t191, label %bb48, label %bb49
bb48:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 2
  store ptr %t197, ptr %l147, !tbaa !29
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t200 = getelementptr %"compiler/check:Checker", ptr %t198, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = getelementptr %"compiler/generic:Program", ptr %t201, i32 0, i32 2
  %t204 = load i32, ptr %l11, !tbaa !23
  %t207 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t203, i32 %t204)
  store i32 %t207, ptr %l152
  br label %bb50
bb49:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb53
bb50:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l3, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l157
  br label %bb51
bb51:
  %t218 = load ptr, ptr %l147, !tbaa !29
  %t219 = load i32, ptr %l152, !tbaa !23
  %t220 = load i32, ptr %l157, !tbaa !23
  %t221 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t218, i32 %t219, i32 %t220)
  store i1 %t221, ptr %l158
  br label %bb52
bb52:
  %t222 = load i1, ptr %l158, !tbaa !21
  store i1 %t222, ptr %l144, !tbaa !21
  br label %bb53
bb53:
  %t223 = load i1, ptr %l144, !tbaa !21
  br i1 %t223, label %bb54, label %bb55
bb54:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t224)
  store ptr %t226, ptr %l160
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s8
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l191, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t228, ptr %l192
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load i32, ptr %l8, !tbaa !23
  %t233 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s8, ptr %t229, i32 %t230)
  store { i64, ptr } %t233, ptr %l195
  br label %bb65
bb56:
  %t234 = load ptr, ptr %l160, !tbaa !29
  %t236 = getelementptr %"compiler/typed:Body", ptr %t234, i32 0, i32 7
  %t237 = load i64, ptr %l9, !tbaa !24
  %t240 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t236, i64 %t237)
  store %"compiler/typed:Local" %t240, ptr %l164
  br label %bb57
bb57:
  %t241 = load %"compiler/typed:Local", ptr %l164
  store %"compiler/typed:Local" %t241, ptr %l12
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/check:Checker", ptr %t242, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/generic:Program", ptr %t245, i32 0, i32 2
  store ptr %t247, ptr %l167, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t250 = getelementptr %"compiler/check:Checker", ptr %t248, i32 0, i32 1
  %t251 = load ptr, ptr %t250, !tbaa !29
  %t253 = getelementptr %"compiler/generic:Program", ptr %t251, i32 0, i32 2
  %t254 = load i32, ptr %l11, !tbaa !23
  %t257 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t253, i32 %t254)
  store i32 %t257, ptr %l172
  br label %bb58
bb58:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:Checker", ptr %t258, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t263 = getelementptr %"compiler/generic:Program", ptr %t261, i32 0, i32 2
  %t264 = load i32, ptr %l11, !tbaa !23
  %t267 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t263, i32 %t264)
  store i64 %t267, ptr %l177
  br label %bb59
bb59:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = getelementptr %"compiler/check:Checker", ptr %t268, i32 0, i32 1
  %t271 = load ptr, ptr %t270, !tbaa !29
  %t273 = getelementptr %"compiler/generic:Program", ptr %t271, i32 0, i32 2
  %t274 = load i32, ptr %l3, !tbaa !23
  %t277 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t273, i32 %t274)
  store i64 %t277, ptr %l182
  br label %bb60
bb60:
  %t278 = load i64, ptr %l177, !tbaa !24
  %t279 = load i64, ptr %l182, !tbaa !24
  %t280 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t278, i64 %t279)
  store i64 %t280, ptr %l183
  br label %bb61
bb61:
  %t281 = load ptr, ptr %l167, !tbaa !29
  %t282 = load i32, ptr %l172, !tbaa !23
  %t283 = load i64, ptr %l183, !tbaa !24
  %t284 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t281, i32 %t282, i64 %t283)
  store i32 %t284, ptr %l184
  br label %bb62
bb62:
  %t285 = load i32, ptr %l184, !tbaa !23
  %t286 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 2
  store i32 %t285, ptr %t286, !tbaa !23
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t287)
  store ptr %t289, ptr %l186
  br label %bb63
bb63:
  %t290 = load ptr, ptr %l186, !tbaa !29
  %t292 = getelementptr %"compiler/typed:Body", ptr %t290, i32 0, i32 7
  %t293 = load i64, ptr %l9, !tbaa !24
  %t294 = load %"compiler/typed:Local", ptr %l12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t292, i64 %t293, %"compiler/typed:Local" %t294)
  br label %bb64
bb64:
  br label %bb69
bb65:
  %t298 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t299 = extractvalue { i64, ptr } %t298, 0
  %t300 = extractvalue { i64, ptr } %t298, 1
  %t301 = mul i64 %t299, 1
  %t302 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t301)
  call void @llvm.memcpy.p0.p0.i64(ptr %t302, ptr %t300, i64 %t301, i1 false)
  %t303 = insertvalue { i64, ptr } undef, i64 %t299, 0
  %t304 = insertvalue { i64, ptr } %t303, ptr %t302, 1
  store { i64, ptr } %t304, ptr %l196, !tbaa !27
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t306 = load i32, ptr %l11, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t305, i32 %t306)
  store { i64, ptr } %t309, ptr %l199
  br label %bb66
bb66:
  %t310 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 0
  %t312 = extractvalue { i64, ptr } %t310, 1
  %t313 = mul i64 %t311, 1
  %t314 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t313)
  call void @llvm.memcpy.p0.p0.i64(ptr %t314, ptr %t312, i64 %t313, i1 false)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t314, 1
  %t317 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t319 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %s8, ptr %s8, ptr %s8, { i64, ptr } %t317, { i64, ptr } %t316)
  store %"compiler/msgs:Msg" %t319, ptr %l201
  br label %bb67
bb67:
  %t320 = load ptr, ptr %l191, !tbaa !29
  %t321 = load %"compiler/source:Span", ptr %l192
  %t322 = load %"compiler/msgs:Msg", ptr %l201
  %t323 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t320, %"compiler/source:Span" %t321, %"compiler/msgs:Msg" %t322)
  store i64 %t323, ptr %l202
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s8)
  br label %bb69
bb69:
  br label %bb70
bb70:
  br label %bb71
bb71:
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l203, !tbaa !29
  %t325 = load i64, ptr %l9, !tbaa !24
  store i64 %t325, ptr %l204, !tbaa !24
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load %"compiler/source:Span", ptr %l7
  %t328 = load ptr, ptr %l2, !tbaa !29
  %t332 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t326, %"compiler/source:Span" %t327, ptr %t328)
  store ptr %t332, ptr %l208
  br label %bb72
bb72:
  %t333 = load ptr, ptr %l203, !tbaa !29
  %t334 = load i64, ptr %l204, !tbaa !24
  %t335 = load ptr, ptr %l208, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t333, i64 %t334, ptr %t335)
  br label %bb73
bb73:
  %t336 = load ptr, ptr %l4, !tbaa !29
  store ptr %t336, ptr %l209, !tbaa !29
  %t337 = load i64, ptr %l9, !tbaa !24
  %t339 = trunc i64 %t337 to i32
  store i32 %t339, ptr %l212, !tbaa !23
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l7
  %t343 = load ptr, ptr %l2, !tbaa !29
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t341, %"compiler/source:Span" %t342, ptr %t343)
  store ptr %t347, ptr %l216
  br label %bb74
bb74:
  %t348 = load i32, ptr %l212, !tbaa !23
  %t349 = load ptr, ptr %l216, !tbaa !29
  %t350 = call %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v0, i32 %t348, ptr %t349)
  store %"compiler/typed:Bind" %t350, ptr %l217
  br label %bb75
bb75:
  %t351 = load %"compiler/typed:Bind", ptr %l217
  %t352 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store %"compiler/typed:Bind" %t351, ptr %t352
  %t353 = load ptr, ptr %l209, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2ePus_H9902a4d50743896fa3c9f4890ae04f69(ptr %v0, ptr %v0, ptr %t353, ptr %t352)
  br label %bb76
bb76:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load %"compiler/source:Span", ptr %l7
  %t357 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t355, %"compiler/source:Span" %t356, i32 %t357, i64 1)
  store ptr %t361, ptr %l222
  br label %bb77
bb77:
  %t362 = load ptr, ptr %l222, !tbaa !29
  store ptr %t362, ptr %rv
  br label %ret
bb78:
  %t363 = load ptr, ptr %l1, !tbaa !29
  store ptr %t363, ptr %l223, !tbaa !29
  store i1 false, ptr %l224, !tbaa !21
  %t364 = load ptr, ptr %l223, !tbaa !29
  %t365 = icmp ne ptr %t364, null
  br i1 %t365, label %bb79, label %bb80
bb79:
  %t367 = load ptr, ptr %l223, !tbaa !29
  %t368 = load i64, ptr %t367
  %t370 = icmp eq i64 %t368, 1
  store i1 %t370, ptr %l224, !tbaa !21
  br label %bb80
bb80:
  %t371 = load i1, ptr %l224, !tbaa !21
  br i1 %t371, label %bb81, label %bb82
bb81:
  %t372 = load ptr, ptr %l1, !tbaa !29
  %t374 = getelementptr { i64, [4 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr }, ptr %t374, i32 0, i32 0
  %t376 = load %"compiler/source:Span", ptr %t375
  store %"compiler/source:Span" %t376, ptr %l13
  %t378 = load ptr, ptr %l1, !tbaa !29
  %t380 = getelementptr { i64, [4 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr }, ptr %t380, i32 0, i32 1
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l14, !tbaa !29
  br label %bb83
bb82:
  br label %bb144
bb83:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l3, !tbaa !23
  %t388 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t384, i32 %t385)
  store i32 %t388, ptr %l233
  br label %bb84
bb84:
  %t389 = load i32, ptr %l233, !tbaa !23
  store i32 %t389, ptr %l15, !tbaa !23
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t391 = load ptr, ptr %l14, !tbaa !29
  %t392 = load i32, ptr %l15, !tbaa !23
  %t396 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t390, ptr %t391, i32 %t392)
  store i64 %t396, ptr %l237
  br label %bb85
bb85:
  %t397 = load i64, ptr %l237, !tbaa !24
  store i64 %t397, ptr %l16, !tbaa !24
  %t398 = load i64, ptr %l16, !tbaa !24
  %t400 = icmp sge i64 %t398, 0
  br i1 %t400, label %bb86, label %bb87
bb86:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load %"compiler/source:Span", ptr %l13
  %t404 = load ptr, ptr %l2, !tbaa !29
  %t405 = load i64, ptr %l16, !tbaa !24
  %t410 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t402, %"compiler/source:Span" %t403, ptr %t404, i64 %t405)
  store ptr %t410, ptr %l244
  br label %bb88
bb87:
  br label %bb89
bb88:
  %t411 = load ptr, ptr %l244, !tbaa !29
  store ptr %t411, ptr %rv
  br label %ret
bb89:
  %t412 = load ptr, ptr %l0, !tbaa !29
  %t413 = load ptr, ptr %l14, !tbaa !29
  %t416 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t412, ptr %t413)
  store i32 %t416, ptr %l247
  br label %bb90
bb90:
  %t417 = load i32, ptr %l247, !tbaa !23
  %t418 = icmp slt i32 %t417, 0
  br i1 %t418, label %bb91, label %bb92
bb91:
  %t420 = load ptr, ptr %l14, !tbaa !29
  store ptr %t420, ptr %l249, !tbaa !29
  store i1 false, ptr %l250, !tbaa !21
  %t421 = load ptr, ptr %l249, !tbaa !29
  %t422 = icmp ne ptr %t421, null
  br i1 %t422, label %bb93, label %bb94
bb92:
  br label %bb142
bb93:
  %t424 = load ptr, ptr %l249, !tbaa !29
  %t425 = load i64, ptr %t424
  %t427 = icmp eq i64 %t425, 15
  store i1 %t427, ptr %l250, !tbaa !21
  br label %bb94
bb94:
  %t428 = load i1, ptr %l250, !tbaa !21
  br i1 %t428, label %bb95, label %bb96
bb95:
  %t429 = load ptr, ptr %l14, !tbaa !29
  %t431 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  %t432 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t431, i32 0, i32 1
  %t433 = load ptr, ptr %t432
  store ptr %t433, ptr %l17, !tbaa !29
  %t435 = load ptr, ptr %l14, !tbaa !29
  %t437 = getelementptr { i64, [5 x i64] }, ptr %t435, i32 0, i32 1
  %t438 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t437, i32 0, i32 2
  %t439 = load i32, ptr %t438
  store i32 %t439, ptr %l18, !tbaa !23
  br label %bb97
bb96:
  br label %bb140
bb97:
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load ptr, ptr %l17, !tbaa !29
  %t445 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t441, ptr %t442)
  store i32 %t445, ptr %l259
  br label %bb98
bb98:
  %t446 = load i32, ptr %l259, !tbaa !23
  store i32 %t446, ptr %l19, !tbaa !23
  %t447 = load ptr, ptr %l0, !tbaa !29
  %t448 = load i32, ptr %l15, !tbaa !23
  %t451 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t447, i32 %t448)
  store i1 %t451, ptr %l262
  br label %bb99
bb99:
  %t452 = load i1, ptr %l262, !tbaa !21
  br i1 %t452, label %bb100, label %bb101
bb100:
  %t453 = load i32, ptr %l19, !tbaa !23
  %t455 = icmp sge i32 %t453, 0
  store i1 %t455, ptr %l263, !tbaa !21
  br label %bb102
bb101:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb102
bb102:
  %t457 = load i1, ptr %l263, !tbaa !21
  br i1 %t457, label %bb103, label %bb104
bb103:
  %t458 = load ptr, ptr %l0, !tbaa !29
  %t460 = getelementptr %"compiler/check:Checker", ptr %t458, i32 0, i32 1
  %t461 = load ptr, ptr %t460, !tbaa !29
  %t463 = getelementptr %"compiler/generic:Program", ptr %t461, i32 0, i32 2
  %t464 = load i32, ptr %l19, !tbaa !23
  %t467 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t463, i32 %t464)
  store i32 %t467, ptr %l271
  br label %bb105
bb104:
  store i1 false, ptr %l266, !tbaa !21
  br label %bb107
bb105:
  %t468 = load ptr, ptr %l0, !tbaa !29
  %t470 = getelementptr %"compiler/check:Checker", ptr %t468, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t473 = getelementptr %"compiler/generic:Program", ptr %t471, i32 0, i32 2
  %t474 = load i32, ptr %l15, !tbaa !23
  %t477 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t473, i32 %t474)
  store i32 %t477, ptr %l276
  br label %bb106
bb106:
  %t478 = load i32, ptr %l271, !tbaa !23
  %t479 = load i32, ptr %l276, !tbaa !23
  %t480 = icmp eq i32 %t478, %t479
  store i1 %t480, ptr %l266, !tbaa !21
  br label %bb107
bb107:
  %t482 = load i1, ptr %l266, !tbaa !21
  br i1 %t482, label %bb108, label %bb109
bb108:
  store %olang.scope zeroinitializer, ptr %s13
  %t483 = load ptr, ptr %l0, !tbaa !29
  store ptr %t483, ptr %l278, !tbaa !29
  %t484 = load %"compiler/source:Span", ptr %l13
  store %"compiler/source:Span" %t484, ptr %l279
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t486 = load i32, ptr %l18, !tbaa !23
  %t489 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t485, i32 %t486)
  store { i64, ptr } %t489, ptr %l282
  br label %bb110
bb109:
  br label %bb115
bb110:
  %t490 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 0
  %t492 = load %"compiler/source:Span", ptr %l279
  %t494 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t492, i64 %t491)
  store %"compiler/source:Span" %t494, ptr %l284
  br label %bb111
bb111:
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t496 = load i32, ptr %l15, !tbaa !23
  %t497 = load i32, ptr %l18, !tbaa !23
  %t501 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s13, ptr %t495, i32 %t496, i32 %t497)
  store %"compiler/msgs:Msg" %t501, ptr %l288
  br label %bb112
bb112:
  %t502 = load ptr, ptr %l278, !tbaa !29
  %t503 = load %"compiler/source:Span", ptr %l284
  %t504 = load %"compiler/msgs:Msg", ptr %l288
  %t505 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s13, ptr %t502, %"compiler/source:Span" %t503, %"compiler/msgs:Msg" %t504)
  store i64 %t505, ptr %l289
  br label %bb113
bb113:
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t507 = load %"compiler/source:Span", ptr %l13
  %t508 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t512 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t506, %"compiler/source:Span" %t507, i32 %t508, i64 0)
  store ptr %t512, ptr %l293
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s13)
  %t513 = load ptr, ptr %l293, !tbaa !29
  store ptr %t513, ptr %rv
  br label %ret
bb115:
  %t514 = load i32, ptr %l19, !tbaa !23
  %t516 = icmp sge i32 %t514, 0
  br i1 %t516, label %bb116, label %bb117
bb116:
  %t518 = load ptr, ptr %l0, !tbaa !29
  %t519 = load i32, ptr %l19, !tbaa !23
  %t522 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t518, i32 %t519)
  store i1 %t522, ptr %l299
  br label %bb118
bb117:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb119
bb118:
  %t523 = load i1, ptr %l299, !tbaa !21
  store i1 %t523, ptr %l296, !tbaa !21
  br label %bb119
bb119:
  %t524 = load i1, ptr %l296, !tbaa !21
  br i1 %t524, label %bb120, label %bb121
bb120:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load i32, ptr %l15, !tbaa !23
  %t529 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t525, i32 %t526)
  store i1 %t529, ptr %l303
  br label %bb122
bb121:
  store i1 false, ptr %l300, !tbaa !21
  br label %bb128
bb122:
  %t530 = load i1, ptr %l303, !tbaa !21
  br i1 %t530, label %bb123, label %bb124
bb123:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t533 = getelementptr %"compiler/check:Checker", ptr %t531, i32 0, i32 1
  %t534 = load ptr, ptr %t533, !tbaa !29
  %t536 = getelementptr %"compiler/generic:Program", ptr %t534, i32 0, i32 2
  %t537 = load i32, ptr %l19, !tbaa !23
  %t540 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t536, i32 %t537)
  store i32 %t540, ptr %l309
  br label %bb125
bb124:
  store i1 false, ptr %l304, !tbaa !21
  br label %bb127
bb125:
  %t541 = load ptr, ptr %l0, !tbaa !29
  %t543 = getelementptr %"compiler/check:Checker", ptr %t541, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !29
  %t546 = getelementptr %"compiler/generic:Program", ptr %t544, i32 0, i32 2
  %t547 = load i32, ptr %l15, !tbaa !23
  %t550 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t546, i32 %t547)
  store i32 %t550, ptr %l314
  br label %bb126
bb126:
  %t551 = load i32, ptr %l309, !tbaa !23
  %t552 = load i32, ptr %l314, !tbaa !23
  %t553 = icmp eq i32 %t551, %t552
  store i1 %t553, ptr %l304, !tbaa !21
  br label %bb127
bb127:
  %t555 = load i1, ptr %l304, !tbaa !21
  %t556 = xor i1 %t555, true
  store i1 %t556, ptr %l300, !tbaa !21
  br label %bb128
bb128:
  %t558 = load i1, ptr %l300, !tbaa !21
  br i1 %t558, label %bb129, label %bb130
bb129:
  store %olang.scope zeroinitializer, ptr %s14
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l317, !tbaa !29
  %t560 = load ptr, ptr %l17, !tbaa !29
  %t562 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t560)
  store %"compiler/source:Span" %t562, ptr %l319
  br label %bb131
bb130:
  br label %bb139
bb131:
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i32, ptr %l15, !tbaa !23
  %t567 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s14, ptr %t563, i32 %t564)
  store { i64, ptr } %t567, ptr %l322
  br label %bb132
bb132:
  %t568 = load { i64, ptr }, ptr %l322, !tbaa !27
  %t569 = extractvalue { i64, ptr } %t568, 0
  %t570 = extractvalue { i64, ptr } %t568, 1
  %t571 = mul i64 %t569, 1
  %t572 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t571)
  call void @llvm.memcpy.p0.p0.i64(ptr %t572, ptr %t570, i64 %t571, i1 false)
  %t573 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t574 = insertvalue { i64, ptr } %t573, ptr %t572, 1
  store { i64, ptr } %t574, ptr %l323, !tbaa !27
  %t575 = load ptr, ptr %l0, !tbaa !29
  store ptr %t575, ptr %l324, !tbaa !29
  %t576 = load ptr, ptr %l17, !tbaa !29
  %t578 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t576)
  store %"compiler/source:Span" %t578, ptr %l326
  br label %bb133
bb133:
  %t579 = load ptr, ptr %l324, !tbaa !29
  %t580 = load %"compiler/source:Span", ptr %l326
  %t581 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t579, %"compiler/source:Span" %t580)
  store { i64, ptr } %t581, ptr %l327
  br label %bb134
bb134:
  %t582 = load { i64, ptr }, ptr %l327, !tbaa !27
  %t583 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s14, { i64, ptr } %t582)
  store { i64, ptr } %t583, ptr %l328
  br label %bb135
bb135:
  %t584 = load { i64, ptr }, ptr %l328, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t584, 0
  %t586 = extractvalue { i64, ptr } %t584, 1
  %t587 = mul i64 %t585, 1
  %t588 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t587)
  call void @llvm.memcpy.p0.p0.i64(ptr %t588, ptr %t586, i64 %t587, i1 false)
  %t589 = insertvalue { i64, ptr } undef, i64 %t585, 0
  %t590 = insertvalue { i64, ptr } %t589, ptr %t588, 1
  %t591 = load { i64, ptr }, ptr %l323, !tbaa !27
  %t593 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternType(ptr %s14, ptr %s14, ptr %s14, { i64, ptr } %t591, { i64, ptr } %t590)
  store %"compiler/msgs:Msg" %t593, ptr %l330
  br label %bb136
bb136:
  %t594 = load ptr, ptr %l317, !tbaa !29
  %t595 = load %"compiler/source:Span", ptr %l319
  %t596 = load %"compiler/msgs:Msg", ptr %l330
  %t597 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t594, %"compiler/source:Span" %t595, %"compiler/msgs:Msg" %t596)
  store i64 %t597, ptr %l331
  br label %bb137
bb137:
  %t598 = load ptr, ptr %l0, !tbaa !29
  %t599 = load %"compiler/source:Span", ptr %l13
  %t600 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t604 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t598, %"compiler/source:Span" %t599, i32 %t600, i64 0)
  store ptr %t604, ptr %l335
  br label %bb138
bb138:
  call void @__olang_scope_close(ptr %s14)
  %t605 = load ptr, ptr %l335, !tbaa !29
  store ptr %t605, ptr %rv
  br label %ret
bb139:
  br label %bb141
bb140:
  br label %bb141
bb141:
  br label %bb142
bb142:
  %t606 = load ptr, ptr %l0, !tbaa !29
  %t607 = load %"compiler/source:Span", ptr %l13
  %t608 = load ptr, ptr %l2, !tbaa !29
  %t609 = load ptr, ptr %l14, !tbaa !29
  %t610 = load i32, ptr %l3, !tbaa !23
  %t616 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %t606, %"compiler/source:Span" %t607, ptr %t608, ptr %t609, i32 %t610)
  store ptr %t616, ptr %l341
  br label %bb143
bb143:
  %t617 = load ptr, ptr %l341, !tbaa !29
  store ptr %t617, ptr %rv
  br label %ret
bb144:
  %t618 = load ptr, ptr %l1, !tbaa !29
  store ptr %t618, ptr %l342, !tbaa !29
  store i1 false, ptr %l343, !tbaa !21
  %t619 = load ptr, ptr %l342, !tbaa !29
  %t620 = icmp ne ptr %t619, null
  br i1 %t620, label %bb145, label %bb146
bb145:
  %t622 = load ptr, ptr %l342, !tbaa !29
  %t623 = load i64, ptr %t622
  %t625 = icmp eq i64 %t623, 2
  store i1 %t625, ptr %l343, !tbaa !21
  br label %bb146
bb146:
  %t626 = load i1, ptr %l343, !tbaa !21
  br i1 %t626, label %bb147, label %bb148
bb147:
  %t627 = load ptr, ptr %l1, !tbaa !29
  %t629 = getelementptr { i64, [4 x i64] }, ptr %t627, i32 0, i32 1
  %t630 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t629, i32 0, i32 0
  %t631 = load %"compiler/source:Span", ptr %t630
  store %"compiler/source:Span" %t631, ptr %l20
  %t633 = load ptr, ptr %l1, !tbaa !29
  %t635 = getelementptr { i64, [4 x i64] }, ptr %t633, i32 0, i32 1
  %t636 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t635, i32 0, i32 1
  %t637 = load ptr, ptr %t636
  store ptr %t637, ptr %l21, !tbaa !29
  %t639 = load ptr, ptr %l1, !tbaa !29
  %t641 = getelementptr { i64, [4 x i64] }, ptr %t639, i32 0, i32 1
  %t642 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t641, i32 0, i32 2
  %t643 = load { i64, ptr }, ptr %t642
  store { i64, ptr } %t643, ptr %l22, !tbaa !27
  br label %bb149
bb148:
  br label %bb240
bb149:
  %t645 = load ptr, ptr %l0, !tbaa !29
  %t646 = load i32, ptr %l3, !tbaa !23
  %t649 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t645, i32 %t646)
  store i32 %t649, ptr %l354
  br label %bb150
bb150:
  %t650 = load i32, ptr %l354, !tbaa !23
  store i32 %t650, ptr %l23, !tbaa !23
  %t651 = load ptr, ptr %l0, !tbaa !29
  %t652 = load ptr, ptr %l21, !tbaa !29
  %t653 = load i32, ptr %l23, !tbaa !23
  %t657 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %t651, ptr %t652, i32 %t653)
  store i64 %t657, ptr %l358
  br label %bb151
bb151:
  %t658 = load i64, ptr %l358, !tbaa !24
  store i64 %t658, ptr %l24, !tbaa !24
  %t659 = load i64, ptr %l24, !tbaa !24
  %t661 = icmp slt i64 %t659, 0
  br i1 %t661, label %bb152, label %bb153
bb152:
  %t663 = load ptr, ptr %l21, !tbaa !29
  store ptr %t663, ptr %l361, !tbaa !29
  store i1 false, ptr %l362, !tbaa !21
  %t664 = load ptr, ptr %l361, !tbaa !29
  %t665 = icmp ne ptr %t664, null
  br i1 %t665, label %bb154, label %bb155
bb153:
  br label %bb203
bb154:
  %t667 = load ptr, ptr %l361, !tbaa !29
  %t668 = load i64, ptr %t667
  %t670 = icmp eq i64 %t668, 15
  store i1 %t670, ptr %l362, !tbaa !21
  br label %bb155
bb155:
  %t671 = load i1, ptr %l362, !tbaa !21
  br i1 %t671, label %bb156, label %bb157
bb156:
  %t672 = load ptr, ptr %l21, !tbaa !29
  %t674 = getelementptr { i64, [5 x i64] }, ptr %t672, i32 0, i32 1
  %t675 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t674, i32 0, i32 0
  %t676 = load %"compiler/source:Span", ptr %t675
  store %"compiler/source:Span" %t676, ptr %l25
  %t678 = load ptr, ptr %l21, !tbaa !29
  %t680 = getelementptr { i64, [5 x i64] }, ptr %t678, i32 0, i32 1
  %t681 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t680, i32 0, i32 1
  %t682 = load ptr, ptr %t681
  store ptr %t682, ptr %l26, !tbaa !29
  %t684 = load ptr, ptr %l21, !tbaa !29
  %t686 = getelementptr { i64, [5 x i64] }, ptr %t684, i32 0, i32 1
  %t687 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t686, i32 0, i32 2
  %t688 = load i32, ptr %t687
  store i32 %t688, ptr %l27, !tbaa !23
  br label %bb158
bb157:
  br label %bb177
bb158:
  %t690 = load ptr, ptr %l0, !tbaa !29
  %t691 = load ptr, ptr %l26, !tbaa !29
  %t694 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t690, ptr %t691)
  store i32 %t694, ptr %l373
  br label %bb159
bb159:
  %t695 = load i32, ptr %l373, !tbaa !23
  store i32 %t695, ptr %l28, !tbaa !23
  %t696 = load ptr, ptr %l0, !tbaa !29
  %t697 = load i32, ptr %l23, !tbaa !23
  %t700 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t696, i32 %t697)
  store i1 %t700, ptr %l376
  br label %bb160
bb160:
  %t701 = load i1, ptr %l376, !tbaa !21
  br i1 %t701, label %bb161, label %bb162
bb161:
  %t702 = load i32, ptr %l28, !tbaa !23
  %t704 = icmp sge i32 %t702, 0
  store i1 %t704, ptr %l377, !tbaa !21
  br label %bb163
bb162:
  store i1 false, ptr %l377, !tbaa !21
  br label %bb163
bb163:
  %t706 = load i1, ptr %l377, !tbaa !21
  br i1 %t706, label %bb164, label %bb165
bb164:
  %t707 = load ptr, ptr %l0, !tbaa !29
  %t709 = getelementptr %"compiler/check:Checker", ptr %t707, i32 0, i32 1
  %t710 = load ptr, ptr %t709, !tbaa !29
  %t712 = getelementptr %"compiler/generic:Program", ptr %t710, i32 0, i32 2
  %t713 = load i32, ptr %l28, !tbaa !23
  %t716 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t712, i32 %t713)
  store i32 %t716, ptr %l385
  br label %bb166
bb165:
  store i1 false, ptr %l380, !tbaa !21
  br label %bb168
bb166:
  %t717 = load ptr, ptr %l0, !tbaa !29
  %t719 = getelementptr %"compiler/check:Checker", ptr %t717, i32 0, i32 1
  %t720 = load ptr, ptr %t719, !tbaa !29
  %t722 = getelementptr %"compiler/generic:Program", ptr %t720, i32 0, i32 2
  %t723 = load i32, ptr %l23, !tbaa !23
  %t726 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t722, i32 %t723)
  store i32 %t726, ptr %l390
  br label %bb167
bb167:
  %t727 = load i32, ptr %l385, !tbaa !23
  %t728 = load i32, ptr %l390, !tbaa !23
  %t729 = icmp eq i32 %t727, %t728
  store i1 %t729, ptr %l380, !tbaa !21
  br label %bb168
bb168:
  %t731 = load i1, ptr %l380, !tbaa !21
  br i1 %t731, label %bb169, label %bb170
bb169:
  store %olang.scope zeroinitializer, ptr %s19
  %t732 = load ptr, ptr %l0, !tbaa !29
  store ptr %t732, ptr %l392, !tbaa !29
  %t733 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t733, ptr %l393
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t735 = load i32, ptr %l27, !tbaa !23
  %t738 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t734, i32 %t735)
  store { i64, ptr } %t738, ptr %l396
  br label %bb171
bb170:
  br label %bb176
bb171:
  %t739 = load { i64, ptr }, ptr %l396, !tbaa !27
  %t740 = extractvalue { i64, ptr } %t739, 0
  %t741 = load %"compiler/source:Span", ptr %l393
  %t743 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t741, i64 %t740)
  store %"compiler/source:Span" %t743, ptr %l398
  br label %bb172
bb172:
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load i32, ptr %l23, !tbaa !23
  %t746 = load i32, ptr %l27, !tbaa !23
  %t750 = call %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %s19, ptr %t744, i32 %t745, i32 %t746)
  store %"compiler/msgs:Msg" %t750, ptr %l402
  br label %bb173
bb173:
  %t751 = load ptr, ptr %l392, !tbaa !29
  %t752 = load %"compiler/source:Span", ptr %l398
  %t753 = load %"compiler/msgs:Msg", ptr %l402
  %t754 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s19, ptr %t751, %"compiler/source:Span" %t752, %"compiler/msgs:Msg" %t753)
  store i64 %t754, ptr %l403
  br label %bb174
bb174:
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t756 = load %"compiler/source:Span", ptr %l20
  %t757 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t761 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t755, %"compiler/source:Span" %t756, i32 %t757, i64 0)
  store ptr %t761, ptr %l407
  br label %bb175
bb175:
  call void @__olang_scope_close(ptr %s19)
  %t762 = load ptr, ptr %l407, !tbaa !29
  store ptr %t762, ptr %rv
  br label %ret
bb176:
  br label %bb178
bb177:
  br label %bb178
bb178:
  %t763 = load ptr, ptr @__olang_prog_scope
  %t764 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %t763)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t764, ptr %l408
  br label %bb179
bb179:
  %t765 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t765, ptr %lp29
  %t766 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l408
  %t767 = load ptr, ptr %lp29
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t766, ptr %t767
  %t768 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t768, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  %t770 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t772 = extractvalue { i64, ptr } %t770, 0
  store i64 %t772, ptr %l32, !tbaa !24
  br label %bb180
bb180:
  store %olang.scope zeroinitializer, ptr %s22
  %t774 = load i64, ptr %l31, !tbaa !24
  %t775 = load i64, ptr %l32, !tbaa !24
  %t778 = icmp slt i64 %t774, %t775
  %t780 = xor i1 %t778, true
  br i1 %t780, label %bb181, label %bb182
bb181:
  call void @__olang_scope_close(ptr %s22)
  br label %bb200
bb182:
  br label %bb183
bb183:
  %t782 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t782, ptr %l416, !tbaa !27
  %t783 = load i64, ptr %l31, !tbaa !24
  %t785 = getelementptr { i64, ptr }, ptr %l416, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !27
  %t787 = getelementptr ptr, ptr %t786, i64 %t783
  %t788 = load ptr, ptr %t787, !tbaa !39
  store ptr %t788, ptr %l33, !tbaa !29
  %t790 = load ptr, ptr %l33, !tbaa !29
  store ptr %t790, ptr %l419, !tbaa !29
  store i1 false, ptr %l420, !tbaa !21
  %t791 = load ptr, ptr %l419, !tbaa !29
  %t792 = icmp ne ptr %t791, null
  br i1 %t792, label %bb184, label %bb185
bb184:
  %t794 = load ptr, ptr %l419, !tbaa !29
  %t795 = load i64, ptr %t794
  %t797 = icmp eq i64 %t795, 4
  store i1 %t797, ptr %l420, !tbaa !21
  br label %bb185
bb185:
  %t798 = load i1, ptr %l420, !tbaa !21
  br i1 %t798, label %bb186, label %bb187
bb186:
  %t799 = load ptr, ptr %l33, !tbaa !29
  %t801 = getelementptr { i64, [4 x i64] }, ptr %t799, i32 0, i32 1
  %t802 = getelementptr { %"compiler/source:Span", ptr }, ptr %t801, i32 0, i32 1
  %t803 = load ptr, ptr %t802
  store ptr %t803, ptr %l34, !tbaa !29
  br label %bb192
bb187:
  %t805 = load ptr, ptr %l33, !tbaa !29
  store ptr %t805, ptr %l425, !tbaa !29
  store i1 false, ptr %l426, !tbaa !21
  %t806 = load ptr, ptr %l425, !tbaa !29
  %t807 = icmp ne ptr %t806, null
  br i1 %t807, label %bb188, label %bb189
bb188:
  %t809 = load ptr, ptr %l425, !tbaa !29
  %t810 = load i64, ptr %t809
  %t812 = icmp eq i64 %t810, 1
  store i1 %t812, ptr %l426, !tbaa !21
  br label %bb189
bb189:
  %t813 = load i1, ptr %l426, !tbaa !21
  br i1 %t813, label %bb190, label %bb191
bb190:
  %t814 = load ptr, ptr %l33, !tbaa !29
  %t816 = getelementptr { i64, [4 x i64] }, ptr %t814, i32 0, i32 1
  %t817 = getelementptr { %"compiler/source:Span", ptr }, ptr %t816, i32 0, i32 1
  %t818 = load ptr, ptr %t817
  store ptr %t818, ptr %l34, !tbaa !29
  br label %bb192
bb191:
  br label %bb194
bb192:
  %t820 = load ptr, ptr %lp29
  %t821 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t820, ptr %t821)
  br label %bb193
bb193:
  br label %bb198
bb194:
  store %olang.scope zeroinitializer, ptr %s24
  %t824 = load ptr, ptr %l0, !tbaa !29
  store ptr %t824, ptr %l433, !tbaa !29
  %t825 = load ptr, ptr %l33, !tbaa !29
  %t827 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t825)
  store %"compiler/source:Span" %t827, ptr %l435
  br label %bb195
bb195:
  %t828 = load ptr, ptr %l433, !tbaa !29
  %t829 = load %"compiler/source:Span", ptr %l435
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s24, ptr %t828, %"compiler/source:Span" %t829, { i64, ptr } { i64 46, ptr @.d32 })
  br label %bb196
bb196:
  %t830 = load ptr, ptr %l0, !tbaa !29
  %t831 = load %"compiler/source:Span", ptr %l20
  %t832 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t836 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t830, %"compiler/source:Span" %t831, i32 %t832, i64 0)
  store ptr %t836, ptr %l439
  br label %bb197
bb197:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s22)
  %t837 = load ptr, ptr %l439, !tbaa !29
  store ptr %t837, ptr %rv
  br label %ret
bb198:
  call void @__olang_scope_close(ptr %s22)
  br label %bb199
bb199:
  %t838 = load i64, ptr %l31, !tbaa !24
  %t840 = add i64 %t838, 1
  store i64 %t840, ptr %l31, !tbaa !24
  br label %bb180
bb200:
  %t842 = load ptr, ptr %l0, !tbaa !29
  store ptr %t842, ptr %l442, !tbaa !29
  %t843 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t843, ptr %l443
  %t844 = load ptr, ptr %l2, !tbaa !29
  store ptr %t844, ptr %l444, !tbaa !29
  %t845 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t845, ptr %l445
  %t846 = load ptr, ptr %l21, !tbaa !29
  store ptr %t846, ptr %l446, !tbaa !29
  %t847 = load ptr, ptr %lp29
  %t849 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t847)
  store { i64, ptr } %t849, ptr %l448
  br label %bb201
bb201:
  store { i64, [5 x i64] } zeroinitializer, ptr %t850
  %t851 = getelementptr { i64, [5 x i64] }, ptr %t850, i32 0, i32 0
  store i64 12, ptr %t851
  %t852 = load %"compiler/source:Span", ptr %l445
  %t853 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t852, 0
  %t854 = load ptr, ptr %l446, !tbaa !29
  %t855 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t853, ptr %t854, 1
  %t856 = load { i64, ptr }, ptr %l448, !tbaa !27
  %t857 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t855, { i64, ptr } %t856, 2
  %t858 = getelementptr { i64, [5 x i64] }, ptr %t850, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t857, ptr %t858
  %t859 = load { i64, [5 x i64] }, ptr %t850
  %t861 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t859, ptr %t861
  %t862 = load i32, ptr %l3, !tbaa !23
  %t863 = load ptr, ptr %l442, !tbaa !29
  %t864 = load %"compiler/source:Span", ptr %l443
  %t865 = load ptr, ptr %l444, !tbaa !29
  %t868 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v0, ptr %t863, %"compiler/source:Span" %t864, ptr %t865, ptr %t861, i32 %t862)
  store ptr %t868, ptr %l452
  br label %bb202
bb202:
  %t869 = load ptr, ptr %l452, !tbaa !29
  store ptr %t869, ptr %rv
  br label %ret
bb203:
  %t870 = load ptr, ptr %l0, !tbaa !29
  %t871 = load %"compiler/source:Span", ptr %l20
  %t872 = load ptr, ptr %l2, !tbaa !29
  %t873 = load i64, ptr %l24, !tbaa !24
  %t878 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %t870, %"compiler/source:Span" %t871, ptr %t872, i64 %t873)
  store ptr %t878, ptr %l457
  br label %bb204
bb204:
  %t879 = load ptr, ptr %l457, !tbaa !29
  store ptr %t879, ptr %l35, !tbaa !29
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t882 = getelementptr %"compiler/check:Checker", ptr %t880, i32 0, i32 1
  %t883 = load ptr, ptr %t882, !tbaa !29
  %t884 = load i32, ptr %l23, !tbaa !23
  %t885 = load i64, ptr %l24, !tbaa !24
  %t889 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %t883, i32 %t884, i64 %t885)
  store i32 %t889, ptr %l462
  br label %bb205
bb205:
  %t890 = load i32, ptr %l462, !tbaa !23
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t893 = getelementptr %"compiler/check:Checker", ptr %t891, i32 0, i32 1
  %t894 = load ptr, ptr %t893, !tbaa !29
  %t896 = getelementptr %"compiler/generic:Program", ptr %t894, i32 0, i32 2
  store ptr %t896, ptr %l465, !tbaa !29
  %t897 = load ptr, ptr %l0, !tbaa !29
  %t899 = getelementptr %"compiler/check:Checker", ptr %t897, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !29
  %t902 = getelementptr %"compiler/generic:Program", ptr %t900, i32 0, i32 2
  %t906 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t902, i32 %t890)
  store i32 %t906, ptr %l470
  br label %bb206
bb206:
  %t907 = load ptr, ptr %l465, !tbaa !29
  %t908 = load i32, ptr %l470, !tbaa !23
  %t909 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t907, i32 %t908)
  store { i64, ptr } %t909, ptr %l471
  br label %bb207
bb207:
  %t910 = load { i64, ptr }, ptr %l471, !tbaa !27
  store { i64, ptr } %t910, ptr %l37, !tbaa !27
  %t911 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t913 = extractvalue { i64, ptr } %t911, 0
  %t914 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t916 = extractvalue { i64, ptr } %t914, 0
  %t919 = icmp ne i64 %t913, %t916
  br i1 %t919, label %bb208, label %bb209
bb208:
  store %olang.scope zeroinitializer, ptr %s26
  %t921 = load ptr, ptr %l0, !tbaa !29
  store ptr %t921, ptr %l477, !tbaa !29
  %t922 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t922, ptr %l478
  %t923 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t925 = extractvalue { i64, ptr } %t923, 0
  store i64 %t925, ptr %l480, !tbaa !24
  %t926 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t928 = extractvalue { i64, ptr } %t926, 0
  %t930 = icmp eq i64 %t928, 1
  br i1 %t930, label %bb210, label %bb211
bb209:
  br label %bb216
bb210:
  store { i64, ptr } { i64 0, ptr @.d33 }, ptr %l484, !tbaa !27
  br label %bb212
bb211:
  store { i64, ptr } { i64 1, ptr @.d34 }, ptr %l484, !tbaa !27
  br label %bb212
bb212:
  %t932 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t934 = extractvalue { i64, ptr } %t932, 0
  %t935 = load i64, ptr %l480, !tbaa !24
  %t936 = load { i64, ptr }, ptr %l484, !tbaa !27
  %t938 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s26, ptr %s26, i64 %t935, { i64, ptr } %t936, i64 %t934)
  store %"compiler/msgs:Msg" %t938, ptr %l487
  br label %bb213
bb213:
  %t939 = load ptr, ptr %l477, !tbaa !29
  %t940 = load %"compiler/source:Span", ptr %l478
  %t941 = load %"compiler/msgs:Msg", ptr %l487
  %t942 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s26, ptr %t939, %"compiler/source:Span" %t940, %"compiler/msgs:Msg" %t941)
  store i64 %t942, ptr %l488
  br label %bb214
bb214:
  %t943 = load ptr, ptr %l0, !tbaa !29
  %t944 = load %"compiler/source:Span", ptr %l20
  %t945 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t949 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t943, %"compiler/source:Span" %t944, i32 %t945, i64 0)
  store ptr %t949, ptr %l492
  br label %bb215
bb215:
  call void @__olang_scope_close(ptr %s26)
  %t950 = load ptr, ptr %l492, !tbaa !29
  store ptr %t950, ptr %rv
  br label %ret
bb216:
  %t951 = load ptr, ptr %l2, !tbaa !29
  store ptr %t951, ptr %l38, !tbaa !29
  %t953 = load ptr, ptr %l0, !tbaa !29
  %t954 = load i32, ptr %l3, !tbaa !23
  %t957 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t953, i32 %t954)
  store i1 %t957, ptr %l496
  br label %bb217
bb217:
  %t958 = load i1, ptr %l496, !tbaa !21
  br i1 %t958, label %bb218, label %bb219
bb218:
  %t959 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t959, ptr %l497
  %t960 = load i32, ptr %l23, !tbaa !23
  store i32 %t960, ptr %l498, !tbaa !23
  %t961 = load ptr, ptr %l0, !tbaa !29
  %t962 = load %"compiler/source:Span", ptr %l20
  %t963 = load ptr, ptr %l2, !tbaa !29
  %t967 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t961, %"compiler/source:Span" %t962, ptr %t963)
  store ptr %t967, ptr %l502
  br label %bb220
bb219:
  br label %bb221
bb220:
  store { i64, [4 x i64] } zeroinitializer, ptr %t968
  %t969 = getelementptr { i64, [4 x i64] }, ptr %t968, i32 0, i32 0
  store i64 2, ptr %t969
  %t970 = load %"compiler/source:Span", ptr %l497
  %t971 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t970, 0
  %t972 = load i32, ptr %l498, !tbaa !23
  %t973 = insertvalue { %"compiler/source:Span", i32, ptr } %t971, i32 %t972, 1
  %t974 = load ptr, ptr %l502, !tbaa !29
  %t975 = insertvalue { %"compiler/source:Span", i32, ptr } %t973, ptr %t974, 2
  %t976 = getelementptr { i64, [4 x i64] }, ptr %t968, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t975, ptr %t976
  %t977 = load { i64, [4 x i64] }, ptr %t968
  %t979 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t977, ptr %t979
  store ptr %t979, ptr %l38, !tbaa !29
  br label %bb221
bb221:
  %t981 = load ptr, ptr %l0, !tbaa !29
  %t983 = getelementptr %"compiler/check:Checker", ptr %t981, i32 0, i32 1
  %t984 = load ptr, ptr %t983, !tbaa !29
  %t986 = getelementptr %"compiler/generic:Program", ptr %t984, i32 0, i32 2
  store ptr %t986, ptr %l507, !tbaa !29
  %t987 = load ptr, ptr %l0, !tbaa !29
  %t989 = getelementptr %"compiler/check:Checker", ptr %t987, i32 0, i32 1
  %t990 = load ptr, ptr %t989, !tbaa !29
  %t992 = getelementptr %"compiler/generic:Program", ptr %t990, i32 0, i32 2
  %t993 = load i32, ptr %l23, !tbaa !23
  %t996 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t992, i32 %t993)
  store i32 %t996, ptr %l512
  br label %bb222
bb222:
  %t997 = load ptr, ptr %l507, !tbaa !29
  %t998 = load i32, ptr %l512, !tbaa !23
  %t999 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t997, i32 %t998)
  store { i64, ptr } %t999, ptr %l513
  br label %bb223
bb223:
  %t1000 = load { i64, ptr }, ptr %l513, !tbaa !27
  store { i64, ptr } %t1000, ptr %l514, !tbaa !27
  %t1001 = load i64, ptr %l24, !tbaa !24
  %t1003 = getelementptr { i64, ptr }, ptr %l514, i32 0, i32 1
  %t1004 = load ptr, ptr %t1003, !tbaa !27
  %t1005 = getelementptr i32, ptr %t1004, i64 %t1001
  %t1006 = load i32, ptr %t1005, !tbaa !33
  %t1008 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t1008, ptr %l517
  store i32 %t1006, ptr %l518, !tbaa !23
  %t1010 = load ptr, ptr %l38, !tbaa !29
  %t1011 = load i64, ptr %l24, !tbaa !24
  %t1015 = call %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v0, ptr %t1010, i64 %t1011, i32 0)
  store %"compiler/typed:Payload" %t1015, ptr %l522
  br label %bb224
bb224:
  %t1016 = load %"compiler/typed:Payload", ptr %l522
  %t1017 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Payload" %t1016, ptr %t1017
  store { i64, [4 x i64] } zeroinitializer, ptr %t1018
  %t1019 = getelementptr { i64, [4 x i64] }, ptr %t1018, i32 0, i32 0
  store i64 5, ptr %t1019
  %t1020 = load %"compiler/source:Span", ptr %l517
  %t1021 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t1020, 0
  %t1022 = load i32, ptr %l518, !tbaa !23
  %t1023 = insertvalue { %"compiler/source:Span", i32, ptr } %t1021, i32 %t1022, 1
  %t1025 = insertvalue { %"compiler/source:Span", i32, ptr } %t1023, ptr %t1017, 2
  %t1026 = getelementptr { i64, [4 x i64] }, ptr %t1018, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t1025, ptr %t1026
  %t1027 = load { i64, [4 x i64] }, ptr %t1018
  %t1028 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t1028, ptr %lp40
  %t1030 = load ptr, ptr %lp40
  store { i64, [4 x i64] } %t1027, ptr %t1030
  store i64 0, ptr %l41, !tbaa !24
  %t1031 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t1033 = extractvalue { i64, ptr } %t1031, 0
  store i64 %t1033, ptr %l42, !tbaa !24
  store i64 1, ptr %l43, !tbaa !24
  %t1035 = load i64, ptr %l42, !tbaa !24
  %t1036 = load i64, ptr %l41, !tbaa !24
  %t1039 = icmp sgt i64 %t1035, %t1036
  br i1 %t1039, label %bb225, label %bb226
bb225:
  %t1041 = load i64, ptr %l43, !tbaa !24
  %t1043 = icmp sgt i64 %t1041, 0
  br i1 %t1043, label %bb227, label %bb228
bb226:
  store i64 0, ptr %l530, !tbaa !24
  br label %bb230
bb227:
  %t1045 = load i64, ptr %l42, !tbaa !24
  %t1046 = load i64, ptr %l41, !tbaa !24
  %t1049 = sub i64 %t1045, %t1046
  %t1050 = load i64, ptr %l43, !tbaa !24
  %t1053 = add i64 %t1049, %t1050
  %t1055 = sub i64 %t1053, 1
  %t1056 = load i64, ptr %l43, !tbaa !24
  %t1059 = sdiv i64 %t1055, %t1056
  store i64 %t1059, ptr %l533, !tbaa !24
  br label %bb229
bb228:
  store i64 0, ptr %l533, !tbaa !24
  br label %bb229
bb229:
  %t1061 = load i64, ptr %l533, !tbaa !24
  store i64 %t1061, ptr %l530, !tbaa !24
  br label %bb230
bb230:
  %t1062 = load i64, ptr %l530, !tbaa !24
  store i64 %t1062, ptr %l44, !tbaa !24
  store i64 0, ptr %l45, !tbaa !24
  br label %bb231
bb231:
  store %olang.scope zeroinitializer, ptr %s29
  %t1063 = load i64, ptr %l45, !tbaa !24
  %t1064 = load i64, ptr %l44, !tbaa !24
  %t1067 = icmp slt i64 %t1063, %t1064
  %t1069 = xor i1 %t1067, true
  br i1 %t1069, label %bb232, label %bb233
bb232:
  call void @__olang_scope_close(ptr %s29)
  br label %bb239
bb233:
  br label %bb234
bb234:
  %t1071 = load i64, ptr %l41, !tbaa !24
  %t1072 = load i64, ptr %l45, !tbaa !24
  %t1073 = load i64, ptr %l43, !tbaa !24
  %t1076 = mul i64 %t1072, %t1073
  %t1079 = add i64 %t1071, %t1076
  store i64 %t1079, ptr %l46, !tbaa !24
  %t1081 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t1081, ptr %l551, !tbaa !27
  %t1082 = load i64, ptr %l46, !tbaa !24
  %t1084 = getelementptr { i64, ptr }, ptr %l551, i32 0, i32 1
  %t1085 = load ptr, ptr %t1084, !tbaa !27
  %t1086 = getelementptr ptr, ptr %t1085, i64 %t1082
  %t1087 = load ptr, ptr %t1086, !tbaa !39
  %t1089 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t1087)
  store %"compiler/source:Span" %t1089, ptr %l554
  br label %bb235
bb235:
  %t1090 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t1090, ptr %l555, !tbaa !27
  %t1091 = load i64, ptr %l46, !tbaa !24
  %t1093 = getelementptr { i64, ptr }, ptr %l555, i32 0, i32 1
  %t1094 = load ptr, ptr %t1093, !tbaa !27
  %t1095 = getelementptr i32, ptr %t1094, i64 %t1091
  %t1096 = load i32, ptr %t1095, !tbaa !33
  %t1097 = load ptr, ptr %lp40
  %t1098 = load i64, ptr %l46, !tbaa !24
  store { i64, [4 x i64] } zeroinitializer, ptr %t1099
  %t1100 = getelementptr { i64, [4 x i64] }, ptr %t1099, i32 0, i32 0
  store i64 3, ptr %t1100
  %t1101 = load %"compiler/source:Span", ptr %l554
  %t1102 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t1101, 0
  %t1104 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t1102, i32 %t1096, 1
  %t1106 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t1104, ptr %t1097, 2
  %t1108 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t1106, i64 %t1098, 3
  %t1109 = getelementptr { i64, [4 x i64] }, ptr %t1099, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t1108, ptr %t1109
  %t1110 = load { i64, [4 x i64] }, ptr %t1099
  %t1111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store ptr %t1111, ptr %lp47
  %t1113 = load ptr, ptr %lp47
  store { i64, [4 x i64] } %t1110, ptr %t1113
  %t1114 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1114, ptr %l561, !tbaa !29
  %t1115 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t1115, ptr %l562
  %t1116 = load ptr, ptr %l35, !tbaa !29
  store ptr %t1116, ptr %l563, !tbaa !29
  %t1117 = load ptr, ptr %l0, !tbaa !29
  %t1118 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t1118, ptr %l565, !tbaa !27
  %t1119 = load i64, ptr %l46, !tbaa !24
  %t1121 = getelementptr { i64, ptr }, ptr %l565, i32 0, i32 1
  %t1122 = load ptr, ptr %t1121, !tbaa !27
  %t1123 = getelementptr ptr, ptr %t1122, i64 %t1119
  %t1124 = load ptr, ptr %t1123, !tbaa !39
  %t1125 = load ptr, ptr %lp47
  %t1126 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t1126, ptr %l569, !tbaa !27
  %t1127 = load i64, ptr %l46, !tbaa !24
  %t1129 = getelementptr { i64, ptr }, ptr %l569, i32 0, i32 1
  %t1130 = load ptr, ptr %t1129, !tbaa !27
  %t1131 = getelementptr i32, ptr %t1130, i64 %t1127
  %t1132 = load i32, ptr %t1131, !tbaa !33
  %t1133 = load ptr, ptr %l4, !tbaa !29
  %t1134 = load i64, ptr %l5, !tbaa !24
  %t1141 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epattern(ptr %v0, ptr %v1, ptr %t1117, ptr %t1124, ptr %t1125, i32 %t1132, ptr %t1133, i64 %t1134)
  store ptr %t1141, ptr %l574
  br label %bb236
bb236:
  %t1142 = load ptr, ptr %l561, !tbaa !29
  %t1143 = load %"compiler/source:Span", ptr %l562
  %t1144 = load ptr, ptr %l563, !tbaa !29
  %t1145 = load ptr, ptr %l574, !tbaa !29
  %t1146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %t1142, %"compiler/source:Span" %t1143, ptr %t1144, ptr %t1145)
  store ptr %t1146, ptr %l575
  br label %bb237
bb237:
  %t1147 = load ptr, ptr %l575, !tbaa !29
  store ptr %t1147, ptr %l35, !tbaa !29
  call void @__olang_scope_close(ptr %s29)
  br label %bb238
bb238:
  %t1148 = load i64, ptr %l45, !tbaa !24
  %t1150 = add i64 %t1148, 1
  store i64 %t1150, ptr %l45, !tbaa !24
  br label %bb231
bb239:
  %t1152 = load ptr, ptr %l35, !tbaa !29
  store ptr %t1152, ptr %rv
  br label %ret
bb240:
  %t1154 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1154, ptr %l579, !tbaa !29
  store i1 false, ptr %l580, !tbaa !21
  %t1155 = load ptr, ptr %l579, !tbaa !29
  %t1156 = icmp ne ptr %t1155, null
  br i1 %t1156, label %bb241, label %bb242
bb241:
  %t1158 = load ptr, ptr %l579, !tbaa !29
  %t1159 = load i64, ptr %t1158
  %t1161 = icmp eq i64 %t1159, 4
  store i1 %t1161, ptr %l580, !tbaa !21
  br label %bb242
bb242:
  %t1162 = load i1, ptr %l580, !tbaa !21
  br i1 %t1162, label %bb243, label %bb244
bb243:
  %t1163 = load ptr, ptr %l1, !tbaa !29
  %t1165 = getelementptr { i64, [4 x i64] }, ptr %t1163, i32 0, i32 1
  %t1166 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1165, i32 0, i32 0
  %t1167 = load %"compiler/source:Span", ptr %t1166
  store %"compiler/source:Span" %t1167, ptr %l48
  %t1169 = load ptr, ptr %l1, !tbaa !29
  %t1171 = getelementptr { i64, [4 x i64] }, ptr %t1169, i32 0, i32 1
  %t1172 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1171, i32 0, i32 1
  %t1173 = load ptr, ptr %t1172
  store ptr %t1173, ptr %l49, !tbaa !29
  br label %bb245
bb244:
  br label %bb247
bb245:
  %t1175 = load ptr, ptr %l0, !tbaa !29
  %t1176 = load ptr, ptr %l49, !tbaa !29
  %t1177 = load ptr, ptr %l2, !tbaa !29
  %t1178 = load i32, ptr %l3, !tbaa !23
  %t1179 = load ptr, ptr %l4, !tbaa !29
  %t1180 = load i64, ptr %l5, !tbaa !24
  %t1187 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %t1175, ptr %t1176, ptr %t1177, i32 %t1178, ptr %t1179, i64 %t1180, i1 true)
  store ptr %t1187, ptr %l593
  br label %bb246
bb246:
  %t1188 = load ptr, ptr %l593, !tbaa !29
  store ptr %t1188, ptr %rv
  br label %ret
bb247:
  call void @__olang_check_failed(ptr @olang_loc_2bba12d772c132ef_de888473626934f3)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereachesWritable(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca ptr
  %l37 = alloca ptr
  %l40 = alloca ptr
  %l44 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l63 = alloca { i64, ptr }
  %l68 = alloca i64
  %l72 = alloca ptr
  %l75 = alloca i64
  %l78 = alloca i64
  %l82 = alloca i64
  %l85 = alloca i64
  %l104 = alloca ptr
  %l108 = alloca i32
  %l112 = alloca i1
  %l114 = alloca { i64, ptr }
  %l117 = alloca i1
  %l118 = alloca i1
  %l120 = alloca { i64, ptr }
  %l123 = alloca i1
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l20
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l2
  call void @compiler_2fcheck_2enamesIn(ptr %v1, ptr %s0, ptr %a1, ptr %l2)
  br label %bb2
bb2:
  store i64 -1, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t7)
  store ptr %t9, ptr %l24
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l24, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Body", ptr %t10, i32 0, i32 1
  %t13 = load { i64, [2 x i64] }, ptr %t12
  store { i64, [2 x i64] } %t13, ptr %l4
  %t15 = load { i64, [2 x i64] }, ptr %l4
  %t17 = extractvalue { i64, [2 x i64] } %t15, 0
  %t18 = icmp eq i64 %t17, 8
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = getelementptr { i64, [2 x i64] }, ptr %l4, i32 0, i32 1
  %t21 = getelementptr { i32, i32, i64 }, ptr %t20, i32 0, i32 0
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l5, !tbaa !23
  br label %bb6
bb5:
  br label %bb7
bb6:
  %t24 = load i32, ptr %l5, !tbaa !23
  %t26 = sext i32 %t24 to i64
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb8
bb8:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  store ptr %t38, ptr %l37, !tbaa !29
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = getelementptr %"compiler/generic:Program", ptr %t42, i32 0, i32 2
  store ptr %t44, ptr %l40, !tbaa !29
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 10
  %t48 = load i64, ptr %l3, !tbaa !24
  %t51 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l44
  br label %bb12
bb12:
  %t52 = load ptr, ptr %l44, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t56 = load ptr, ptr %l40, !tbaa !29
  %t58 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t56, i32 %t55)
  store i32 %t58, ptr %l47
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l37, !tbaa !29
  %t60 = load i32, ptr %l47, !tbaa !23
  %t61 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t59, i32 %t60)
  store { i64, ptr } %t61, ptr %l48
  br label %bb14
bb14:
  %t62 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t62, ptr %l6, !tbaa !27
  store ptr %l2, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s5
  %t64 = load ptr, ptr %l7, !tbaa !29
  %t65 = load i64, ptr %l8, !tbaa !24
  %t68 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %s0, ptr %t64, i64 %t65)
  %t69 = extractvalue { i32, { i64, ptr } } %t68, 1
  %t70 = extractvalue { i32, { i64, ptr } } %t68, 0
  store i32 %t70, ptr %l54
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb17, label %ok.72
ok.72:
  store { i64, ptr } %t69, ptr %l53
  br label %bb16
bb16:
  %t73 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t73, ptr %l50, !tbaa !27
  br label %bb21
bb17:
  %t74 = load i32, ptr %l54, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_de7ddc22b2de2288_ecbab7ee09a112dc)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb61
bb21:
  %t79 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t79, ptr %l9, !tbaa !27
  %t80 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t84 = load i64, ptr %l11, !tbaa !24
  %t85 = load i64, ptr %l10, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s6)
  br label %bb59
bb24:
  br label %bb25
bb25:
  %t92 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t92, ptr %l63, !tbaa !27
  %t93 = load i64, ptr %l11, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t93
  %t98 = load i32, ptr %t97, !tbaa !33
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %t100, i32 %t98)
  store i64 %t104, ptr %l68
  br label %bb26
bb26:
  %t105 = load i64, ptr %l68, !tbaa !24
  store i64 %t105, ptr %l13, !tbaa !24
  %t106 = load i64, ptr %l13, !tbaa !24
  %t108 = icmp slt i64 %t106, 0
  br i1 %t108, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb28:
  br label %bb29
bb29:
  store i64 0, ptr %l14, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t110)
  store ptr %t112, ptr %l72
  br label %bb30
bb30:
  %t113 = load ptr, ptr %l72, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Body", ptr %t113, i32 0, i32 5
  %t117 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t115)
  store i64 %t117, ptr %l75
  br label %bb31
bb31:
  %t118 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = load i64, ptr %l75, !tbaa !24
  %t123 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t121, i64 %t120)
  store i64 %t123, ptr %l78
  br label %bb32
bb32:
  %t124 = load i64, ptr %l78, !tbaa !24
  store i64 %t124, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = icmp sgt i64 %t125, %t126
  br i1 %t129, label %bb33, label %bb34
bb33:
  %t131 = load i64, ptr %l16, !tbaa !24
  %t133 = icmp sgt i64 %t131, 0
  br i1 %t133, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb38
bb35:
  %t135 = load i64, ptr %l15, !tbaa !24
  %t136 = load i64, ptr %l14, !tbaa !24
  %t139 = sub i64 %t135, %t136
  %t140 = load i64, ptr %l16, !tbaa !24
  %t143 = add i64 %t139, %t140
  %t145 = sub i64 %t143, 1
  %t146 = load i64, ptr %l16, !tbaa !24
  %t149 = sdiv i64 %t145, %t146
  store i64 %t149, ptr %l85, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l85, !tbaa !24
  br label %bb37
bb37:
  %t151 = load i64, ptr %l85, !tbaa !24
  store i64 %t151, ptr %l82, !tbaa !24
  br label %bb38
bb38:
  %t152 = load i64, ptr %l82, !tbaa !24
  store i64 %t152, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t153 = load i64, ptr %l18, !tbaa !24
  %t154 = load i64, ptr %l17, !tbaa !24
  %t157 = icmp slt i64 %t153, %t154
  %t159 = xor i1 %t157, true
  br i1 %t159, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb41:
  br label %bb42
bb42:
  %t161 = load i64, ptr %l14, !tbaa !24
  %t162 = load i64, ptr %l18, !tbaa !24
  %t163 = load i64, ptr %l16, !tbaa !24
  %t166 = mul i64 %t162, %t163
  %t169 = add i64 %t161, %t166
  store i64 %t169, ptr %l19, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t171)
  store ptr %t173, ptr %l104
  br label %bb43
bb43:
  %t174 = load ptr, ptr %l104, !tbaa !29
  %t176 = getelementptr %"compiler/typed:Body", ptr %t174, i32 0, i32 5
  %t177 = load i64, ptr %l19, !tbaa !24
  %t180 = call i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t176, i64 %t177)
  store i32 %t180, ptr %l108
  br label %bb44
bb44:
  %t181 = load i32, ptr %l108, !tbaa !23
  %t182 = sext i32 %t181 to i64
  %t183 = load i64, ptr %l13, !tbaa !24
  %t186 = icmp eq i64 %t182, %t183
  br i1 %t186, label %bb45, label %bb46
bb45:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t189, ptr %l114, !tbaa !27
  %t190 = load i64, ptr %l19, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr i32, ptr %t193, i64 %t190
  %t195 = load i32, ptr %t194, !tbaa !33
  %t198 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %t188, i32 %t195)
  store i1 %t198, ptr %l117
  br label %bb47
bb46:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb52
bb47:
  %t199 = load i1, ptr %l117, !tbaa !21
  br i1 %t199, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb51
bb49:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t201, ptr %l120, !tbaa !27
  %t202 = load i64, ptr %l19, !tbaa !24
  %t204 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr i32, ptr %t205, i64 %t202
  %t207 = load i32, ptr %t206, !tbaa !33
  %t210 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t200, i32 %t207)
  store i1 %t210, ptr %l123
  br label %bb50
bb50:
  %t211 = load i1, ptr %l123, !tbaa !21
  store i1 %t211, ptr %l118, !tbaa !21
  br label %bb51
bb51:
  %t212 = load i1, ptr %l118, !tbaa !21
  store i1 %t212, ptr %l112, !tbaa !21
  br label %bb52
bb52:
  %t213 = load i1, ptr %l112, !tbaa !21
  br i1 %t213, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb54:
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb56:
  %t215 = load i64, ptr %l18, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l18, !tbaa !24
  br label %bb39
bb57:
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb58:
  %t219 = load i64, ptr %l11, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l11, !tbaa !24
  br label %bb22
bb59:
  %t223 = load i64, ptr %l8, !tbaa !24
  %t224 = load i64, ptr %l10, !tbaa !24
  %t227 = add i64 %t223, %t224
  store i64 %t227, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb60
bb60:
  br label %bb15
bb61:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %rv = alloca ptr
  %t6 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/source:Span" %a1, ptr %l3
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t2)
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [5 x i64] }, ptr %t6, i32 0, i32 0
  store i64 2, ptr %t7
  %t8 = load %"compiler/source:Span", ptr %l3
  %t9 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t8, 0
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t9, i32 %t10, 1
  %t13 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t11, ptr %t5, 2
  %t14 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t13, i32 -1, 3
  %t15 = getelementptr { i64, [5 x i64] }, ptr %t6, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t14, ptr %t15
  %t16 = load { i64, [5 x i64] }, ptr %t6
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t16, ptr %t18
  store ptr %t18, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca i32
  %l6 = alloca i32
  %rv = alloca ptr
  %t15 = alloca { i64, [4 x i64] }, align 8
  %t27 = alloca { i64, [5 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load i64, ptr %l2, !tbaa !24
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !tbaa !23
  store i32 %t6, ptr %l3, !tbaa !23
  %t7 = load %"compiler/source:Span", ptr %l1
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = load %"compiler/source:Span", ptr %l1
  %t10 = load i32, ptr %l3, !tbaa !23
  %t11 = load i64, ptr %l2, !tbaa !24
  %t13 = trunc i64 %t11 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t15
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 0
  store i64 0, ptr %t16
  %t18 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t9, 0
  %t20 = insertvalue { %"compiler/source:Span", i32, i32 } %t18, i32 %t10, 1
  %t22 = insertvalue { %"compiler/source:Span", i32, i32 } %t20, i32 %t13, 2
  %t23 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t22, ptr %t23
  %t24 = load { i64, [4 x i64] }, ptr %t15
  %t26 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t24, ptr %t26
  store { i64, [5 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 0
  store i64 2, ptr %t28
  %t30 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t7, 0
  %t32 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t30, i32 %t8, 1
  %t34 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t32, ptr %t26, 2
  %t35 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t34, i32 -1, 3
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t27, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t35, ptr %t36
  %t37 = load { i64, [5 x i64] }, ptr %t27
  %t39 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t37, ptr %t39
  store ptr %t39, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erefWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l18 = alloca i1
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l27 = alloca %"compiler/names:Ref"
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2erefWrittenTop(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t6 = load ptr, ptr %l1, !tbaa !29
  store ptr %t6, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t7 = load ptr, ptr %l7, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb5, label %bb6
bb5:
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t14 = load i1, ptr %l8, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t17, i32 0, i32 0
  %t19 = load %"compiler/source:Span", ptr %t18
  store %"compiler/source:Span" %t19, ptr %l2
  %t21 = load ptr, ptr %l1, !tbaa !29
  %t23 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  %t24 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t23, i32 0, i32 1
  %t25 = load { i64, ptr }, ptr %t24
  store { i64, ptr } %t25, ptr %l3, !tbaa !27
  br label %bb9
bb8:
  br label %bb15
bb9:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 1
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t40)
  store ptr %t42, ptr %l23
  br label %bb12
bb11:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb14
bb12:
  %t43 = load ptr, ptr %l23, !tbaa !29
  %t45 = getelementptr %"compiler/check:frame", ptr %t43, i32 0, i32 2
  %t46 = load i64, ptr %t45, !tbaa !24
  %t47 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t49 = load ptr, ptr %l21, !tbaa !29
  %t52 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t49, i64 %t46, i32 %t48)
  store %"compiler/names:Ref" %t52, ptr %l27
  br label %bb13
bb13:
  %t53 = getelementptr %"compiler/names:Ref", ptr %l27, i32 0, i32 0
  %t54 = load i32, ptr %t53
  %t56 = trunc i64 8 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l18, !tbaa !21
  br label %bb14
bb14:
  %t59 = load i1, ptr %l18, !tbaa !21
  store i1 %t59, ptr %rv
  br label %ret
bb15:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereturnStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, [3 x i64] }
  %l19 = alloca ptr
  %l23 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/msgs:Msg"
  %l33 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca %"compiler/source:Span"
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l48 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca %"compiler/msgs:Msg"
  %l54 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/msgs:Msg"
  %l60 = alloca i64
  %l64 = alloca ptr
  %l68 = alloca %"compiler/source:Span"
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l74 = alloca i64
  %l82 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/msgs:Msg"
  %l88 = alloca i64
  %l105 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca %"compiler/source:Span"
  %l113 = alloca { i64, ptr }
  %l115 = alloca %"compiler/msgs:Msg"
  %l116 = alloca i64
  %l127 = alloca ptr
  %l128 = alloca %"compiler/source:Span"
  %l129 = alloca %"compiler/msgs:Msg"
  %l130 = alloca i64
  %l133 = alloca ptr
  %l135 = alloca { i64, [3 x i64] }
  %l137 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l143 = alloca i32
  %l145 = alloca i32
  %l147 = alloca i1
  %l148 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i1
  %l160 = alloca ptr
  %l163 = alloca i1
  %l165 = alloca ptr
  %l167 = alloca ptr
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/source:Span"
  %l172 = alloca i1
  %l183 = alloca i32
  %l191 = alloca ptr
  %l196 = alloca i32
  %l197 = alloca { i64, ptr }
  %l207 = alloca i64
  %l213 = alloca i64
  %l216 = alloca i64
  %l236 = alloca ptr
  %l239 = alloca { i64, [3 x i64] }
  %l241 = alloca ptr
  %l243 = alloca { i64, ptr }
  %l246 = alloca { i64, ptr }
  %l249 = alloca ptr
  %l257 = alloca { i64, ptr }
  %l258 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l260 = alloca %"compiler/source:Span"
  %l261 = alloca i32
  %l265 = alloca %"compiler/typed:Make"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %t34 = alloca { i64, [3 x i64] }, align 8
  %t126 = alloca { i64, [3 x i64] }, align 8
  %t161 = alloca { i64, [3 x i64] }, align 8
  %t227 = alloca { i64, [3 x i64] }, align 8
  %t309 = alloca { i64, [4 x i64] }, align 8
  %t354 = alloca { i64, [3 x i64] }, align 8
  %t543 = alloca { i64, [5 x i64] }, align 8
  %t555 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l19
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l19, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  store i64 %t13, ptr %l23, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l23, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/check:frame", ptr %t16, i32 0, i32 12
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb7, label %bb8
bb6:
  br label %bb13
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l30, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t26, ptr %l31
  %t27 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInTest(ptr %s2)
  store %"compiler/msgs:Msg" %t27, ptr %l32
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t28 = load ptr, ptr %l30, !tbaa !29
  %t29 = load %"compiler/source:Span", ptr %l31
  %t30 = load %"compiler/msgs:Msg", ptr %l32
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t28, %"compiler/source:Span" %t29, %"compiler/msgs:Msg" %t30)
  store i64 %t31, ptr %l33
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb11:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t34
  %t35 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 0
  store i64 6, ptr %t35
  %t37 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t33, 0
  %t38 = insertvalue { %"compiler/source:Span", ptr } %t37, ptr null, 1
  %t39 = getelementptr { i64, [3 x i64] }, ptr %t34, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t38, ptr %t39
  %t40 = load { i64, [3 x i64] }, ptr %t34
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t40, ptr %t42
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t32, ptr %t42)
  br label %bb12
bb12:
  br label %ret
bb13:
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 13
  %t48 = load i1, ptr %t47, !tbaa !21
  br i1 %t48, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l40, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l41
  %t52 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInCtor(ptr %s3)
  store %"compiler/msgs:Msg" %t52, ptr %l42
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t53 = load ptr, ptr %l40, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l41
  %t55 = load %"compiler/msgs:Msg", ptr %l42
  %t56 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t53, %"compiler/source:Span" %t54, %"compiler/msgs:Msg" %t55)
  store i64 %t56, ptr %l43
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb18:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 5
  %t60 = load i32, ptr %t59, !tbaa !23
  %t61 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t64 = icmp eq i32 %t60, %t61
  br i1 %t64, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l48, !tbaa !29
  %t67 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t68 = load i32, ptr %t67, !tbaa !23
  %t69 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t70 = load i32, ptr %t69, !tbaa !23
  %t72 = add i32 %t70, 6
  %t75 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 %t68, i32 %t72)
  store %"compiler/source:Span" %t75, ptr %l52
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t76 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInNoreturn(ptr %s4)
  store %"compiler/msgs:Msg" %t76, ptr %l53
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l52
  %t79 = load %"compiler/msgs:Msg", ptr %l53
  %t80 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t77, %"compiler/source:Span" %t78, %"compiler/msgs:Msg" %t79)
  store i64 %t80, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
bb24:
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/check:frame", ptr %t81, i32 0, i32 29
  %t84 = load i1, ptr %t83, !tbaa !21
  br i1 %t84, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l57, !tbaa !29
  %t87 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t87, ptr %l58
  %t88 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseReturns(ptr %s5)
  store %"compiler/msgs:Msg" %t88, ptr %l59
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t89 = load ptr, ptr %l57, !tbaa !29
  %t90 = load %"compiler/source:Span", ptr %l58
  %t91 = load %"compiler/msgs:Msg", ptr %l59
  %t92 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t89, %"compiler/source:Span" %t90, %"compiler/msgs:Msg" %t91)
  store i64 %t92, ptr %l60
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  br label %ret
bb29:
  %t93 = load ptr, ptr %l3, !tbaa !29
  %t95 = getelementptr %"compiler/check:frame", ptr %t93, i32 0, i32 32
  %t96 = load i64, ptr %t95, !tbaa !24
  %t98 = icmp sge i64 %t96, 0
  br i1 %t98, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s6
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l64, !tbaa !29
  %t101 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t103 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t104 = load i32, ptr %t103, !tbaa !23
  %t106 = add i32 %t104, 6
  %t109 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t102, i32 %t106)
  store %"compiler/source:Span" %t109, ptr %l68
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/check:frame", ptr %t111, i32 0, i32 33
  %t114 = load i1, ptr %t113, !tbaa !21
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s6, ptr %t110, i1 %t114)
  store { i64, ptr } %t117, ptr %l72
  br label %bb33
bb33:
  %t118 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t119 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgReturns(ptr %s6, ptr %s6, { i64, ptr } %t118)
  store %"compiler/msgs:Msg" %t119, ptr %l73
  br label %bb34
bb34:
  %t120 = load ptr, ptr %l64, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l68
  %t122 = load %"compiler/msgs:Msg", ptr %l73
  %t123 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t120, %"compiler/source:Span" %t121, %"compiler/msgs:Msg" %t122)
  store i64 %t123, ptr %l74
  br label %bb35
bb35:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t125 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t126
  %t127 = getelementptr { i64, [3 x i64] }, ptr %t126, i32 0, i32 0
  store i64 6, ptr %t127
  %t129 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t125, 0
  %t130 = insertvalue { %"compiler/source:Span", ptr } %t129, ptr null, 1
  %t131 = getelementptr { i64, [3 x i64] }, ptr %t126, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t130, ptr %t131
  %t132 = load { i64, [3 x i64] }, ptr %t126
  %t134 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t132, ptr %t134
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t124, ptr %t134)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  br label %ret
bb37:
  %t137 = load ptr, ptr %l3, !tbaa !29
  %t139 = getelementptr %"compiler/check:frame", ptr %t137, i32 0, i32 31
  %t140 = load i64, ptr %t139, !tbaa !24
  %t142 = icmp sge i64 %t140, 0
  br i1 %t142, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s7
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l82, !tbaa !29
  %t145 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t147 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t148 = load i32, ptr %t147, !tbaa !23
  %t150 = add i32 %t148, 6
  %t153 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s7, i32 %t146, i32 %t150)
  store %"compiler/source:Span" %t153, ptr %l86
  br label %bb40
bb39:
  br label %bb44
bb40:
  %t154 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferReturns(ptr %s7)
  store %"compiler/msgs:Msg" %t154, ptr %l87
  br label %bb41
bb41:
  %t155 = load ptr, ptr %l82, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l86
  %t157 = load %"compiler/msgs:Msg", ptr %l87
  %t158 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t155, %"compiler/source:Span" %t156, %"compiler/msgs:Msg" %t157)
  store i64 %t158, ptr %l88
  br label %bb42
bb42:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [3 x i64] }, ptr %t161, i32 0, i32 0
  store i64 6, ptr %t162
  %t164 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t160, 0
  %t165 = insertvalue { %"compiler/source:Span", ptr } %t164, ptr null, 1
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t165, ptr %t166
  %t167 = load { i64, [3 x i64] }, ptr %t161
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t167, ptr %t169
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t159, ptr %t169)
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %ret
bb44:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = getelementptr %"compiler/check:frame", ptr %t172, i32 0, i32 22
  %t175 = load i1, ptr %t174, !tbaa !21
  br i1 %t175, label %bb45, label %bb46
bb45:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l1
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %t177, %"compiler/source:Span" %t178, { i64, ptr } %t179)
  br label %bb47
bb46:
  br label %bb48
bb47:
  br label %ret
bb48:
  %t183 = load ptr, ptr %l3, !tbaa !29
  %t185 = getelementptr %"compiler/check:frame", ptr %t183, i32 0, i32 5
  %t186 = load i32, ptr %t185, !tbaa !23
  store i32 %t186, ptr %l5, !tbaa !23
  %t188 = load i64, ptr %l4, !tbaa !24
  %t190 = icmp eq i64 %t188, 0
  br i1 %t190, label %bb49, label %bb50
bb49:
  %t192 = load i32, ptr %l5, !tbaa !23
  %t193 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t196 = icmp ne i32 %t192, %t193
  br i1 %t196, label %bb51, label %bb52
bb50:
  br label %bb61
bb51:
  %t198 = load i32, ptr %l5, !tbaa !23
  %t199 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t202 = icmp ne i32 %t198, %t199
  store i1 %t202, ptr %l105, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l105, !tbaa !21
  br label %bb53
bb53:
  %t204 = load i1, ptr %l105, !tbaa !21
  br i1 %t204, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t205 = load ptr, ptr %l0, !tbaa !29
  store ptr %t205, ptr %l109, !tbaa !29
  %t206 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t206, ptr %l110
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l5, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s10, ptr %t207, i32 %t208)
  store { i64, ptr } %t211, ptr %l113
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t212 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t220 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnNeedsValue(ptr %s10, ptr %s10, { i64, ptr } %t218)
  store %"compiler/msgs:Msg" %t220, ptr %l115
  br label %bb57
bb57:
  %t221 = load ptr, ptr %l109, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l110
  %t223 = load %"compiler/msgs:Msg", ptr %l115
  %t224 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s10, ptr %t221, %"compiler/source:Span" %t222, %"compiler/msgs:Msg" %t223)
  store i64 %t224, ptr %l116
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %ret
bb59:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l1
  store { i64, [3 x i64] } zeroinitializer, ptr %t227
  %t228 = getelementptr { i64, [3 x i64] }, ptr %t227, i32 0, i32 0
  store i64 6, ptr %t228
  %t230 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t226, 0
  %t231 = insertvalue { %"compiler/source:Span", ptr } %t230, ptr null, 1
  %t232 = getelementptr { i64, [3 x i64] }, ptr %t227, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t231, ptr %t232
  %t233 = load { i64, [3 x i64] }, ptr %t227
  %t235 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t233, ptr %t235
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t225, ptr %t235)
  br label %bb60
bb60:
  br label %ret
bb61:
  %t238 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t242 = icmp eq i64 %t240, 1
  br i1 %t242, label %bb62, label %bb63
bb62:
  %t244 = load i32, ptr %l5, !tbaa !23
  %t245 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t248 = icmp eq i32 %t244, %t245
  br i1 %t248, label %bb64, label %bb65
bb63:
  br label %bb88
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t250, ptr %l127, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t251, ptr %l128
  %t252 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnValueInVoid(ptr %s12)
  store %"compiler/msgs:Msg" %t252, ptr %l129
  br label %bb66
bb65:
  br label %bb68
bb66:
  %t253 = load ptr, ptr %l127, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l128
  %t255 = load %"compiler/msgs:Msg", ptr %l129
  %t256 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t253, %"compiler/source:Span" %t254, %"compiler/msgs:Msg" %t255)
  store i64 %t256, ptr %l130
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s12)
  br label %ret
bb68:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr %"compiler/check:Checker", ptr %t257, i32 0, i32 9
  %t260 = load { i64, [3 x i64] }, ptr %t259
  store { i64, [3 x i64] } %t260, ptr %l6
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l133, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %t263, i64 0)
  store { i64, [3 x i64] } %t265, ptr %l135
  br label %bb69
bb69:
  %t266 = load { i64, [3 x i64] }, ptr %l135
  %t267 = load ptr, ptr %l133, !tbaa !29
  %t268 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 9
  store { i64, [3 x i64] } %t266, ptr %t268
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t270, ptr %l137, !tbaa !27
  %t271 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr ptr, ptr %t272, i64 0
  %t274 = load ptr, ptr %t273, !tbaa !39
  %t275 = load i32, ptr %l5, !tbaa !23
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t269, ptr %t274, i32 %t275)
  store ptr %t279, ptr %l140
  br label %bb70
bb70:
  %t280 = load ptr, ptr %l140, !tbaa !29
  store ptr %t280, ptr %l7, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load { i64, [3 x i64] }, ptr %l6
  %t285 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 9
  store { i64, [3 x i64] } %t282, ptr %t285
  %t286 = load i32, ptr %l5, !tbaa !23
  store i32 %t286, ptr %l143, !tbaa !23
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t287)
  store i32 %t289, ptr %l145
  br label %bb71
bb71:
  %t290 = load i32, ptr %l143, !tbaa !23
  %t291 = load i32, ptr %l145, !tbaa !23
  %t292 = icmp eq i32 %t290, %t291
  br i1 %t292, label %bb72, label %bb73
bb72:
  %t294 = load ptr, ptr %l0, !tbaa !29
  store ptr %t294, ptr %l148, !tbaa !29
  %t295 = load ptr, ptr %l7, !tbaa !29
  %t298 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t295)
  store i32 %t298, ptr %l151
  br label %bb74
bb73:
  store i1 false, ptr %l147, !tbaa !21
  br label %bb76
bb74:
  %t299 = load ptr, ptr %l148, !tbaa !29
  %t300 = load i32, ptr %l151, !tbaa !23
  %t301 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t299, i32 %t300)
  store i1 %t301, ptr %l152
  br label %bb75
bb75:
  %t302 = load i1, ptr %l152, !tbaa !21
  store i1 %t302, ptr %l147, !tbaa !21
  br label %bb76
bb76:
  %t303 = load i1, ptr %l147, !tbaa !21
  br i1 %t303, label %bb77, label %bb78
bb77:
  %t304 = load ptr, ptr %l0, !tbaa !29
  %t305 = load %"compiler/source:Span", ptr %l1
  %t306 = load %"compiler/source:Span", ptr %l1
  %t307 = load i32, ptr %l5, !tbaa !23
  %t308 = load ptr, ptr %l7, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t309
  %t310 = getelementptr { i64, [4 x i64] }, ptr %t309, i32 0, i32 0
  store i64 2, ptr %t310
  %t312 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t306, 0
  %t314 = insertvalue { %"compiler/source:Span", i32, ptr } %t312, i32 %t307, 1
  %t316 = insertvalue { %"compiler/source:Span", i32, ptr } %t314, ptr %t308, 2
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t309, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t316, ptr %t317
  %t318 = load { i64, [4 x i64] }, ptr %t309
  %t320 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t318, ptr %t320
  %t324 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t304, %"compiler/source:Span" %t305, ptr %t320)
  store ptr %t324, ptr %l160
  br label %bb79
bb78:
  br label %bb80
bb79:
  %t325 = load ptr, ptr %l160, !tbaa !29
  store ptr %t325, ptr %l7, !tbaa !29
  br label %bb80
bb80:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l5, !tbaa !23
  %t330 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t326, i32 %t327)
  store i1 %t330, ptr %l163
  br label %bb81
bb81:
  %t331 = load i1, ptr %l163, !tbaa !21
  %t332 = xor i1 %t331, true
  br i1 %t332, label %bb82, label %bb83
bb82:
  %t334 = load ptr, ptr %l0, !tbaa !29
  store ptr %t334, ptr %l165, !tbaa !29
  %t335 = load ptr, ptr %l7, !tbaa !29
  store ptr %t335, ptr %l167, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t337, ptr %l168, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 0
  %t341 = load ptr, ptr %t340, !tbaa !39
  %t343 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t341)
  store %"compiler/source:Span" %t343, ptr %l170
  br label %bb84
bb83:
  br label %bb86
bb84:
  %t344 = load i64, ptr @G_2ecompiler_2fcheck_2eRoReturned, !tbaa !24
  %t345 = load ptr, ptr %l165, !tbaa !29
  %t346 = load ptr, ptr %l167, !tbaa !29
  %t347 = load %"compiler/source:Span", ptr %l170
  %t349 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t345, ptr %t346, %"compiler/source:Span" %t347, i64 %t344)
  store i1 %t349, ptr %l172
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t351 = load %"compiler/source:Span", ptr %l1
  %t352 = load ptr, ptr %l7, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t354
  %t355 = getelementptr { i64, [3 x i64] }, ptr %t354, i32 0, i32 0
  store i64 6, ptr %t355
  %t357 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t351, 0
  %t359 = insertvalue { %"compiler/source:Span", ptr } %t357, ptr %t352, 1
  %t360 = getelementptr { i64, [3 x i64] }, ptr %t354, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t359, ptr %t360
  %t361 = load { i64, [3 x i64] }, ptr %t354
  %t363 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t361, ptr %t363
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t350, ptr %t363)
  br label %bb87
bb87:
  br label %ret
bb88:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/check:Checker", ptr %t366, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !29
  %t371 = getelementptr %"compiler/generic:Program", ptr %t369, i32 0, i32 2
  %t372 = load i32, ptr %l5, !tbaa !23
  %t375 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t371, i32 %t372)
  store i32 %t375, ptr %l183
  br label %bb89
bb89:
  %t376 = load i32, ptr %l183
  %t378 = trunc i64 22 to i32
  %t379 = icmp eq i32 %t376, %t378
  %t381 = xor i1 %t379, true
  br i1 %t381, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s15
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s15, ptr %t383, %"compiler/source:Span" %t384, { i64, ptr } { i64 47, ptr @.d35 })
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s15)
  br label %ret
bb93:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t389 = getelementptr %"compiler/check:Checker", ptr %t387, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !29
  %t392 = getelementptr %"compiler/generic:Program", ptr %t390, i32 0, i32 2
  store ptr %t392, ptr %l191, !tbaa !29
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t395 = getelementptr %"compiler/check:Checker", ptr %t393, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !29
  %t398 = getelementptr %"compiler/generic:Program", ptr %t396, i32 0, i32 2
  %t399 = load i32, ptr %l5, !tbaa !23
  %t402 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t398, i32 %t399)
  store i32 %t402, ptr %l196
  br label %bb94
bb94:
  %t403 = load ptr, ptr %l191, !tbaa !29
  %t404 = load i32, ptr %l196, !tbaa !23
  %t405 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t403, i32 %t404)
  store { i64, ptr } %t405, ptr %l197
  br label %bb95
bb95:
  %t406 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t406, ptr %l8, !tbaa !27
  %t407 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 0
  %t410 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t415 = icmp ne i64 %t409, %t412
  br i1 %t415, label %bb96, label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s16
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t418 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s16, ptr %t417, %"compiler/source:Span" %t418, { i64, ptr } { i64 50, ptr @.d36 })
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s16)
  br label %ret
bb99:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 31
  %t425 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t423)
  store i64 %t425, ptr %l207
  br label %bb100
bb100:
  %t426 = load i64, ptr %l207, !tbaa !24
  store i64 %t426, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  %t427 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t429 = extractvalue { i64, ptr } %t427, 0
  store i64 %t429, ptr %l11, !tbaa !24
  store i64 1, ptr %l12, !tbaa !24
  %t431 = load i64, ptr %l11, !tbaa !24
  %t432 = load i64, ptr %l10, !tbaa !24
  %t435 = icmp sgt i64 %t431, %t432
  br i1 %t435, label %bb101, label %bb102
bb101:
  %t437 = load i64, ptr %l12, !tbaa !24
  %t439 = icmp sgt i64 %t437, 0
  br i1 %t439, label %bb103, label %bb104
bb102:
  store i64 0, ptr %l213, !tbaa !24
  br label %bb106
bb103:
  %t441 = load i64, ptr %l11, !tbaa !24
  %t442 = load i64, ptr %l10, !tbaa !24
  %t445 = sub i64 %t441, %t442
  %t446 = load i64, ptr %l12, !tbaa !24
  %t449 = add i64 %t445, %t446
  %t451 = sub i64 %t449, 1
  %t452 = load i64, ptr %l12, !tbaa !24
  %t455 = sdiv i64 %t451, %t452
  store i64 %t455, ptr %l216, !tbaa !24
  br label %bb105
bb104:
  store i64 0, ptr %l216, !tbaa !24
  br label %bb105
bb105:
  %t457 = load i64, ptr %l216, !tbaa !24
  store i64 %t457, ptr %l213, !tbaa !24
  br label %bb106
bb106:
  %t458 = load i64, ptr %l213, !tbaa !24
  store i64 %t458, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s18
  %t459 = load i64, ptr %l14, !tbaa !24
  %t460 = load i64, ptr %l13, !tbaa !24
  %t463 = icmp slt i64 %t459, %t460
  %t465 = xor i1 %t463, true
  br i1 %t465, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s18)
  br label %bb115
bb109:
  br label %bb110
bb110:
  %t467 = load i64, ptr %l10, !tbaa !24
  %t468 = load i64, ptr %l14, !tbaa !24
  %t469 = load i64, ptr %l12, !tbaa !24
  %t472 = mul i64 %t468, %t469
  %t475 = add i64 %t467, %t472
  store i64 %t475, ptr %l15, !tbaa !24
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/check:Checker", ptr %t477, i32 0, i32 9
  %t480 = load { i64, [3 x i64] }, ptr %t479
  store { i64, [3 x i64] } %t480, ptr %l16
  %t482 = load ptr, ptr %l0, !tbaa !29
  store ptr %t482, ptr %l236, !tbaa !29
  %t483 = load ptr, ptr %l0, !tbaa !29
  %t484 = load i64, ptr %l15, !tbaa !24
  %t487 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %t483, i64 %t484)
  store { i64, [3 x i64] } %t487, ptr %l239
  br label %bb111
bb111:
  %t488 = load { i64, [3 x i64] }, ptr %l239
  %t489 = load ptr, ptr %l236, !tbaa !29
  %t490 = getelementptr %"compiler/check:Checker", ptr %t489, i32 0, i32 9
  store { i64, [3 x i64] } %t488, ptr %t490
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr %"compiler/check:Checker", ptr %t491, i32 0, i32 31
  store ptr %t493, ptr %l241, !tbaa !29
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t495, ptr %l243, !tbaa !27
  %t496 = load i64, ptr %l15, !tbaa !24
  %t498 = getelementptr { i64, ptr }, ptr %l243, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !27
  %t500 = getelementptr ptr, ptr %t499, i64 %t496
  %t501 = load ptr, ptr %t500, !tbaa !39
  %t502 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t502, ptr %l246, !tbaa !27
  %t503 = load i64, ptr %l15, !tbaa !24
  %t505 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !27
  %t507 = getelementptr i32, ptr %t506, i64 %t503
  %t508 = load i32, ptr %t507, !tbaa !33
  %t512 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t494, ptr %t501, i32 %t508)
  store ptr %t512, ptr %l249
  br label %bb112
bb112:
  %t513 = load ptr, ptr %l241, !tbaa !29
  %t514 = load ptr, ptr %l249, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t513, ptr %t514)
  br label %bb113
bb113:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t516 = load { i64, [3 x i64] }, ptr %l16
  %t519 = getelementptr %"compiler/check:Checker", ptr %t515, i32 0, i32 9
  store { i64, [3 x i64] } %t516, ptr %t519
  call void @__olang_scope_close(ptr %s18)
  br label %bb114
bb114:
  %t520 = load i64, ptr %l14, !tbaa !24
  %t522 = add i64 %t520, 1
  store i64 %t522, ptr %l14, !tbaa !24
  br label %bb107
bb115:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = getelementptr %"compiler/check:Checker", ptr %t524, i32 0, i32 31
  %t527 = load i64, ptr %l9, !tbaa !24
  %t530 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t526, i64 %t527)
  store { i64, ptr } %t530, ptr %l257
  br label %bb116
bb116:
  %t531 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t532 = load ptr, ptr %l0, !tbaa !29
  store ptr %t532, ptr %l258, !tbaa !29
  %t533 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t533, ptr %l259
  %t534 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t534, ptr %l260
  %t535 = load i32, ptr %l5, !tbaa !23
  store i32 %t535, ptr %l261, !tbaa !23
  %t540 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 0, i64 0, { i64, ptr } %t531, ptr null, i32 -1, i32 0)
  store %"compiler/typed:Make" %t540, ptr %l265
  br label %bb117
bb117:
  %t541 = load %"compiler/typed:Make", ptr %l265
  %t542 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t541, ptr %t542
  store { i64, [5 x i64] } zeroinitializer, ptr %t543
  %t544 = getelementptr { i64, [5 x i64] }, ptr %t543, i32 0, i32 0
  store i64 7, ptr %t544
  %t545 = load %"compiler/source:Span", ptr %l260
  %t546 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t545, 0
  %t547 = load i32, ptr %l261, !tbaa !23
  %t548 = insertvalue { %"compiler/source:Span", i32, ptr } %t546, i32 %t547, 1
  %t550 = insertvalue { %"compiler/source:Span", i32, ptr } %t548, ptr %t542, 2
  %t551 = getelementptr { i64, [5 x i64] }, ptr %t543, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t550, ptr %t551
  %t552 = load { i64, [5 x i64] }, ptr %t543
  %t554 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t552, ptr %t554
  store { i64, [3 x i64] } zeroinitializer, ptr %t555
  %t556 = getelementptr { i64, [3 x i64] }, ptr %t555, i32 0, i32 0
  store i64 6, ptr %t556
  %t557 = load %"compiler/source:Span", ptr %l259
  %t558 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t557, 0
  %t560 = insertvalue { %"compiler/source:Span", ptr } %t558, ptr %t554, 1
  %t561 = getelementptr { i64, [3 x i64] }, ptr %t555, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t560, ptr %t561
  %t562 = load { i64, [3 x i64] }, ptr %t555
  %t564 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t562, ptr %t564
  %t565 = load ptr, ptr %l258, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t565, ptr %t564)
  br label %bb118
bb118:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erewritten(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l14 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l21 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l22 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a2, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t15, ptr %l14, !tbaa !27
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr i64, ptr %t19, i64 %t16
  %t21 = load i64, ptr %t20, !tbaa !34
  %t25 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 84
  store ptr %t25, ptr %l18, !tbaa !29
  %t30 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %a1, i64 %t21)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l21
  %t33 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t31, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t32)
  store i1 %t33, ptr %l22
  br label %bb6
bb6:
  %t34 = load i1, ptr %l22, !tbaa !21
  br i1 %t34, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t36 = load i64, ptr %l4, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l4, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l4 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %l4, i64 0)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroValue(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t9 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t6)
  store i32 %t9, ptr %l8
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l5, !tbaa !29
  %t11 = load i32, ptr %l8, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t10, i32 %t11)
  store i1 %t12, ptr %l9
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  store i1 %t13, ptr %l4, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l4, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb10
bb7:
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t19 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t16)
  store i32 %t19, ptr %l14
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i32, ptr %l14, !tbaa !23
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t20, i32 %t21)
  store i1 %t22, ptr %l15
  br label %bb9
bb9:
  %t23 = load i1, ptr %l15, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb10
bb10:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store i1 %t32, ptr %l20
  br label %bb14
bb14:
  %t33 = load i1, ptr %l20, !tbaa !21
  store i1 %t33, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l15 = alloca i1
  %l19 = alloca i32
  %l21 = alloca i64
  %l25 = alloca i64
  %l28 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca i64
  %l36 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l48 = alloca %"compiler/generic:Binding"
  %l50 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca i64
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i64
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t4, i64 %t5)
  store i1 %t8, ptr %l15
  br label %bb1
bb1:
  %t9 = load i1, ptr %l15, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  %t17 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t13, i64 %t14)
  store i32 %t17, ptr %l19
  br label %bb5
bb5:
  %t18 = load i32, ptr %l19, !tbaa !23
  store i32 %t18, ptr %l3, !tbaa !23
  %t19 = load i64, ptr %l1, !tbaa !24
  %t21 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t19)
  store i64 %t21, ptr %l21
  br label %bb6
bb6:
  %t22 = load i64, ptr %l21, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t30, ptr %l25
  br label %bb7
bb7:
  %t31 = load i64, ptr %l25, !tbaa !24
  store i64 %t31, ptr %l5, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t34 = icmp eq i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l28, !tbaa !29
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = load i64, ptr %l1, !tbaa !24
  %t44 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t40, i64 %t41, i32 0)
  store i64 %t44, ptr %l32
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t45 = load ptr, ptr %l28, !tbaa !29
  %t46 = load i64, ptr %l32, !tbaa !24
  %t47 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t45, i64 %t46)
  store i64 %t47, ptr %l33
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb12:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  store ptr %t53, ptr %l36, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = load i32, ptr %l3, !tbaa !23
  %t63 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t59, i32 %t60)
  store i32 %t63, ptr %l41
  br label %bb13
bb13:
  %t64 = load ptr, ptr %l36, !tbaa !29
  %t65 = load i32, ptr %l41, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t64, i32 %t65)
  store { i64, ptr } %t66, ptr %l42
  br label %bb14
bb14:
  %t67 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t67, ptr %l6, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  br label %bb17
bb17:
  %t74 = load i64, ptr %l4, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t74, i64 %t75)
  store %"compiler/generic:Binding" %t78, ptr %l48
  br label %bb18
bb18:
  %t79 = load %"compiler/generic:Binding", ptr %l48
  store %"compiler/generic:Binding" %t79, ptr %l7
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 0
  %t85 = load i32, ptr %t84, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t80, i32 %t85, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb19
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %s0, ptr %t94, ptr %l7)
  br label %bb20
bb20:
  %t97 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  store { i64, ptr } %t98, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t100 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load i64, ptr %l9, !tbaa !24
  %t105 = load i64, ptr %l10, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb23:
  br label %bb24
bb24:
  %t112 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t112, ptr %l64, !tbaa !27
  %t113 = load i64, ptr %l9, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t113
  %t118 = load i32, ptr %t117, !tbaa !33
  %t121 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t124 = icmp eq i32 %t118, %t121
  br i1 %t124, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t126 = load i64, ptr %l9, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l9, !tbaa !24
  br label %bb21
bb29:
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l72, !tbaa !29
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/check:Checker", ptr %t131, i32 0, i32 1
  %t134 = load ptr, ptr %t133, !tbaa !29
  store ptr %t134, ptr %l74, !tbaa !29
  %t135 = load i64, ptr %l1, !tbaa !24
  store i64 %t135, ptr %l75, !tbaa !24
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 2
  %t142 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t141, { i64, ptr } %t143)
  store i32 %t146, ptr %l80
  br label %bb30
bb30:
  %t147 = load ptr, ptr %l74, !tbaa !29
  %t148 = load i64, ptr %l75, !tbaa !24
  %t149 = load i32, ptr %l80, !tbaa !23
  %t150 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t147, i64 %t148, i32 %t149)
  store i64 %t150, ptr %l81
  br label %bb31
bb31:
  %t151 = load ptr, ptr %l72, !tbaa !29
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t151, i64 %t152)
  store i64 %t153, ptr %l82
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 43
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr @.d37 }, { i64, ptr } { i64 6, ptr @.d38 })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 43
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 43
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalueTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca i32
  %l52 = alloca ptr
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l60 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  store ptr %t2, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t5 = load i32, ptr %l4, !tbaa !23
  %t8 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t4, i32 %t5)
  store i1 %t8, ptr %l11
  br label %bb1
bb1:
  %t9 = load i1, ptr %l11, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l4, !tbaa !23
  %t14 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t10, i32 %t11)
  store i32 %t14, ptr %l15
  br label %bb4
bb3:
  %t15 = load i32, ptr %l4, !tbaa !23
  store i32 %t15, ptr %l12, !tbaa !23
  br label %bb5
bb4:
  %t17 = load i32, ptr %l15, !tbaa !23
  store i32 %t17, ptr %l12, !tbaa !23
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l8, !tbaa !29
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t18, ptr %t19, i32 %t20)
  store ptr %t21, ptr %l17
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l17, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l21
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t33 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t30)
  store i32 %t33, ptr %l25
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l22, !tbaa !29
  %t35 = load i32, ptr %l25, !tbaa !23
  %t36 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l26
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l18, !tbaa !29
  %t38 = load i32, ptr %l21, !tbaa !23
  %t39 = load i32, ptr %l26, !tbaa !23
  %t40 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %t37, i32 %t38, i32 %t39)
  store i1 %t40, ptr %l27
  br label %bb10
bb10:
  %t41 = load i1, ptr %l27, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l29, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t45)
  store %"compiler/source:Span" %t47, ptr %l31
  br label %bb13
bb12:
  br label %bb20
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l32, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load i32, ptr %l4, !tbaa !23
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l35
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l32, !tbaa !29
  %t55 = load i32, ptr %l35, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l36
  br label %bb15
bb15:
  %t57 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t59 = extractvalue { i64, ptr } %t57, 1
  %t60 = mul i64 %t58, 1
  %t61 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t60)
  call void @llvm.memcpy.p0.p0.i64(ptr %t61, ptr %t59, i64 %t60, i1 false)
  %t62 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t61, 1
  store { i64, ptr } %t63, ptr %l37, !tbaa !27
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v0, ptr %s1, ptr %t64, ptr %t65)
  store { i64, ptr } %t68, ptr %l40
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  %t76 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t78 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t76, { i64, ptr } %t75)
  store %"compiler/msgs:Msg" %t78, ptr %l42
  br label %bb17
bb17:
  %t79 = load ptr, ptr %l29, !tbaa !29
  %t80 = load %"compiler/source:Span", ptr %l31
  %t81 = load %"compiler/msgs:Msg", ptr %l42
  %t82 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t79, %"compiler/source:Span" %t80, %"compiler/msgs:Msg" %t81)
  store i64 %t82, ptr %l43
  br label %bb18
bb18:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l1
  %t85 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t83, %"compiler/source:Span" %t84, i32 %t85, i64 0)
  store ptr %t89, ptr %l47
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t90 = load ptr, ptr %l47, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l48, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l49
  %t93 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t93, ptr %l50
  store i32 73, ptr %l51
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l52, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load %"compiler/source:Span", ptr %l1
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t95, %"compiler/source:Span" %t96, ptr %a2)
  store ptr %t101, ptr %l56
  br label %bb21
bb21:
  %t102 = load %"compiler/source:Span", ptr %l1
  %t103 = load ptr, ptr %l52, !tbaa !29
  %t104 = load ptr, ptr %l56, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t103, ptr %t104, %"compiler/source:Span" %t102)
  store ptr %t106, ptr %l58
  br label %bb22
bb22:
  %t107 = load ptr, ptr %l5, !tbaa !29
  store ptr %t107, ptr %l59, !tbaa !29
  %t108 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t108, ptr %l60
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t111 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t109)
  store %"compiler/source:Span" %t111, ptr %l62
  br label %bb23
bb23:
  %t112 = load ptr, ptr %l48, !tbaa !29
  %t113 = load %"compiler/source:Span", ptr %l49
  %t114 = load %"compiler/source:Span", ptr %l50
  %t115 = load i32, ptr %l51
  %t116 = load ptr, ptr %l58, !tbaa !29
  %t117 = load ptr, ptr %l59, !tbaa !29
  %t118 = load %"compiler/source:Span", ptr %l60
  %t119 = load %"compiler/source:Span", ptr %l62
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %t112, %"compiler/source:Span" %t113, %"compiler/source:Span" %t114, i32 %t115, ptr %t116, ptr %t117, %"compiler/source:Span" %t118, %"compiler/source:Span" %t119)
  store ptr %t120, ptr %l63
  br label %bb24
bb24:
  %t121 = load ptr, ptr %l63, !tbaa !29
  store ptr %t121, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewordIndex(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca { i64, ptr }
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t9, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t14, %t15
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp sgt i64 %t20, 0
  br i1 %t22, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t24 = load i64, ptr %l5, !tbaa !24
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t29 = load i64, ptr %l6, !tbaa !24
  %t32 = add i64 %t28, %t29
  %t34 = sub i64 %t32, 1
  %t35 = load i64, ptr %l6, !tbaa !24
  %t38 = sdiv i64 %t34, %t35
  store i64 %t38, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l22, !tbaa !24
  store i64 %t40, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l19, !tbaa !24
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t42 = load i64, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb16
bb10:
  br label %bb11
bb11:
  %t50 = load i64, ptr %l4, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = mul i64 %t51, %t52
  %t58 = add i64 %t50, %t55
  store i64 %t58, ptr %l9, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t60, ptr %l40, !tbaa !27
  %t61 = load i64, ptr %l9, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  %t70 = icmp eq i32 %t66, %a2
  br i1 %t70, label %bb12, label %bb13
bb12:
  %t72 = load i64, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  store i64 %t72, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t74 = load i64, ptr %l8, !tbaa !24
  %t76 = add i64 %t74, 1
  store i64 %t76, ptr %l8, !tbaa !24
  br label %bb8
bb16:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i64
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t5 = load i64, ptr %t4, !tbaa !24
  store i64 %t5, ptr %l2, !tbaa !65
  %t8 = load i32, ptr %l0, !tbaa !23
  %t10 = icmp eq i32 %t8, 13
  br i1 %t10, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t12 = load i64, ptr %l2, !tbaa !65
  %t14 = uitofp i64 %t12 to float
  %t16 = bitcast float %t14 to i32
  %t18 = zext i32 %t16 to i64
  store i64 %t18, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load i32, ptr %l0, !tbaa !23
  %t22 = icmp eq i32 %t20, 12
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l2, !tbaa !65
  %t26 = call bfloat @__olang_int_bf16(i64 %t24, i1 false)
  %t28 = bitcast bfloat %t26 to i16
  %t29 = call i16 asm "", "=r,0"(i16 %t28)
  %t31 = zext i16 %t29 to i64
  store i64 %t31, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 11
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l2, !tbaa !65
  %t39 = uitofp i64 %t37 to double
  %t40 = call double @llvm.arithmetic.fence.f64(double %t39)
  %t41 = fptrunc double %t40 to half
  %t43 = bitcast half %t41 to i16
  %t44 = call i16 asm "", "=r,0"(i16 %t43)
  %t46 = zext i16 %t44 to i64
  store i64 %t46, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !65
  %t50 = uitofp i64 %t48 to double
  %t52 = bitcast double %t50 to i64
  store i64 %t52, ptr %rv
  br label %ret
bb12:
  %t55 = load i32, ptr %l0, !tbaa !23
  %t57 = icmp eq i32 %t55, 13
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = sitofp i64 %t60 to float
  %t64 = bitcast float %t62 to i32
  %t66 = zext i32 %t64 to i64
  store i64 %t66, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load i32, ptr %l0, !tbaa !23
  %t70 = icmp eq i32 %t68, 12
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  %t76 = sub i64 0, %t73
  %t77 = select i1 %t75, i64 %t76, i64 %t73
  %t78 = call bfloat @__olang_int_bf16(i64 %t77, i1 %t75)
  %t80 = bitcast bfloat %t78 to i16
  %t81 = call i16 asm "", "=r,0"(i16 %t80)
  %t83 = zext i16 %t81 to i64
  store i64 %t83, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t85 = load i32, ptr %l0, !tbaa !23
  %t87 = icmp eq i32 %t85, 11
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = sitofp i64 %t90 to double
  %t93 = call double @llvm.arithmetic.fence.f64(double %t92)
  %t94 = fptrunc double %t93 to half
  %t96 = bitcast half %t94 to i16
  %t97 = call i16 asm "", "=r,0"(i16 %t96)
  %t99 = zext i16 %t97 to i64
  store i64 %t99, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t101 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = sitofp i64 %t102 to double
  %t106 = bitcast double %t104 to i64
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2eisWild(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eleaves(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l40 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i1
  %l78 = alloca { i64, ptr }
  %l83 = alloca i1
  %l89 = alloca ptr
  %l90 = alloca i1
  %l99 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca i1
  %l109 = alloca i32
  %l113 = alloca ptr
  %l114 = alloca i1
  %l127 = alloca { i64, ptr }
  %l132 = alloca i1
  %l144 = alloca i1
  %s9 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t2 = load ptr, ptr %l15, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l15, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l16, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l16, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t12 = load ptr, ptr %l20, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l20, !tbaa !29
  %t16 = load i64, ptr %t15
  %t18 = icmp eq i64 %t16, 7
  store i1 %t18, ptr %l21, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t22 = load ptr, ptr %l25, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb13, label %bb14
bb13:
  %t25 = load ptr, ptr %l25, !tbaa !29
  %t26 = load i64, ptr %t25
  %t28 = icmp eq i64 %t26, 8
  store i1 %t28, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t29 = load i1, ptr %l26, !tbaa !21
  br i1 %t29, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i1 true, ptr %rv
  br label %ret
bb18:
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = icmp ne ptr %t32, null
  br i1 %t33, label %bb19, label %bb20
bb19:
  %t35 = load ptr, ptr %l30, !tbaa !29
  %t36 = load i64, ptr %t35
  %t38 = icmp eq i64 %t36, 3
  store i1 %t38, ptr %l31, !tbaa !21
  br label %bb20
bb20:
  %t39 = load i1, ptr %l31, !tbaa !21
  br i1 %t39, label %bb21, label %bb22
bb21:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr { i64, [3 x i64] }, ptr %t40, i32 0, i32 1
  %t43 = getelementptr { %"compiler/source:Span", ptr }, ptr %t42, i32 0, i32 1
  %t44 = load ptr, ptr %t43
  store ptr %t44, ptr %l1, !tbaa !29
  br label %bb23
bb22:
  br label %bb32
bb23:
  %t46 = load ptr, ptr %l1, !tbaa !29
  %t48 = getelementptr %"compiler/typed:If", ptr %t46, i32 0, i32 2
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb24, label %bb25
bb24:
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/typed:If", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t58)
  store i1 %t61, ptr %l44
  br label %bb26
bb25:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb27
bb26:
  %t62 = load i1, ptr %l44, !tbaa !21
  store i1 %t62, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t63 = load i1, ptr %l40, !tbaa !21
  br i1 %t63, label %bb28, label %bb29
bb28:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/typed:If", ptr %t64, i32 0, i32 2
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t67)
  store i1 %t69, ptr %l48
  br label %bb30
bb29:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb31
bb30:
  %t70 = load i1, ptr %l48, !tbaa !21
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb31
bb31:
  %t71 = load i1, ptr %l45, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
bb32:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t73 = load ptr, ptr %l49, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb33, label %bb34
bb33:
  %t76 = load ptr, ptr %l49, !tbaa !29
  %t77 = load i64, ptr %t76
  %t79 = icmp eq i64 %t77, 10
  store i1 %t79, ptr %l50, !tbaa !21
  br label %bb34
bb34:
  %t80 = load i1, ptr %l50, !tbaa !21
  br i1 %t80, label %bb35, label %bb36
bb35:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr { i64, [3 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr }, ptr %t83, i32 0, i32 1
  %t85 = load ptr, ptr %t84
  store ptr %t85, ptr %l2, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t87)
  store i1 %t90, ptr %l57
  br label %bb38
bb38:
  %t91 = load i1, ptr %l57, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
bb39:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t93 = load ptr, ptr %l58, !tbaa !29
  %t94 = icmp ne ptr %t93, null
  br i1 %t94, label %bb40, label %bb41
bb40:
  %t96 = load ptr, ptr %l58, !tbaa !29
  %t97 = load i64, ptr %t96
  %t99 = icmp eq i64 %t97, 12
  store i1 %t99, ptr %l59, !tbaa !21
  br label %bb41
bb41:
  %t100 = load i1, ptr %l59, !tbaa !21
  br i1 %t100, label %bb42, label %bb43
bb42:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", ptr }, ptr %t103, i32 0, i32 1
  %t105 = load ptr, ptr %t104
  store ptr %t105, ptr %l3, !tbaa !29
  br label %bb44
bb43:
  br label %bb59
bb44:
  %t107 = load ptr, ptr %l3, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Join", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t113 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t110)
  store i1 %t113, ptr %l67
  br label %bb45
bb45:
  %t114 = load i1, ptr %l67, !tbaa !21
  %t115 = xor i1 %t114, true
  br i1 %t115, label %bb46, label %bb47
bb46:
  store i1 false, ptr %rv
  br label %ret
bb47:
  br label %bb48
bb48:
  %t118 = load ptr, ptr %l3, !tbaa !29
  %t120 = getelementptr %"compiler/typed:Join", ptr %t118, i32 0, i32 2
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  store { i64, ptr } %t121, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 0
  store i64 %t125, ptr %l6, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s9
  %t127 = load i64, ptr %l5, !tbaa !24
  %t128 = load i64, ptr %l6, !tbaa !24
  %t131 = icmp slt i64 %t127, %t128
  %t133 = xor i1 %t131, true
  br i1 %t133, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb51:
  br label %bb52
bb52:
  %t135 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t135, ptr %l78, !tbaa !27
  %t136 = load i64, ptr %l5, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr ptr, ptr %t139, i64 %t136
  %t141 = load ptr, ptr %t140, !tbaa !39
  %t145 = getelementptr %"compiler/typed:Clause", ptr %t141, i32 0, i32 3
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t146)
  store i1 %t148, ptr %l83
  br label %bb53
bb53:
  %t149 = load i1, ptr %l83, !tbaa !21
  %t150 = xor i1 %t149, true
  br i1 %t150, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s9)
  store i1 false, ptr %rv
  br label %ret
bb55:
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb57:
  %t153 = load i64, ptr %l5, !tbaa !24
  %t155 = add i64 %t153, 1
  store i64 %t155, ptr %l5, !tbaa !24
  br label %bb49
bb58:
  store i1 true, ptr %rv
  br label %ret
bb59:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t159 = load ptr, ptr %l89, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb60, label %bb61
bb60:
  %t162 = load ptr, ptr %l89, !tbaa !29
  %t163 = load i64, ptr %t162
  %t165 = icmp eq i64 %t163, 4
  store i1 %t165, ptr %l90, !tbaa !21
  br label %bb61
bb61:
  %t166 = load i1, ptr %l90, !tbaa !21
  br i1 %t166, label %bb62, label %bb63
bb62:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr { i64, [3 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t169, i32 0, i32 1
  %t171 = load ptr, ptr %t170
  store ptr %t171, ptr %l8, !tbaa !29
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t173 = load ptr, ptr %l8, !tbaa !29
  %t175 = load ptr, ptr %l8, !tbaa !29
  %t177 = getelementptr %"compiler/typed:Block", ptr %t175, i32 0, i32 0
  %t178 = load i32, ptr %t177, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ebreaks(ptr %v0, ptr %t173, i32 %t178)
  store i1 %t181, ptr %l99
  br label %bb65
bb65:
  %t182 = load i1, ptr %l99, !tbaa !21
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %rv
  br label %ret
bb66:
  %t185 = load ptr, ptr %l0, !tbaa !29
  store ptr %t185, ptr %l101, !tbaa !29
  store i1 false, ptr %l102, !tbaa !21
  %t186 = load ptr, ptr %l101, !tbaa !29
  %t187 = icmp ne ptr %t186, null
  br i1 %t187, label %bb67, label %bb68
bb67:
  %t189 = load ptr, ptr %l101, !tbaa !29
  %t190 = load i64, ptr %t189
  %t192 = icmp eq i64 %t190, 2
  store i1 %t192, ptr %l102, !tbaa !21
  br label %bb68
bb68:
  %t193 = load i1, ptr %l102, !tbaa !21
  br i1 %t193, label %bb69, label %bb70
bb69:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr { i64, [3 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", ptr }, ptr %t196, i32 0, i32 1
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l9, !tbaa !29
  br label %bb71
bb70:
  br label %bb96
bb71:
  %t200 = load ptr, ptr %l9, !tbaa !29
  %t203 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t200)
  store i32 %t203, ptr %l109
  br label %bb72
bb72:
  %t204 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t205 = load i32, ptr %l109, !tbaa !23
  %t207 = icmp eq i32 %t205, %t204
  br i1 %t207, label %bb73, label %bb74
bb73:
  store i1 true, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  %t210 = load ptr, ptr %l9, !tbaa !29
  store ptr %t210, ptr %l113, !tbaa !29
  store i1 false, ptr %l114, !tbaa !21
  %t211 = load ptr, ptr %l113, !tbaa !29
  %t212 = icmp ne ptr %t211, null
  br i1 %t212, label %bb76, label %bb77
bb76:
  %t214 = load ptr, ptr %l113, !tbaa !29
  %t215 = load i64, ptr %t214
  %t217 = icmp eq i64 %t215, 13
  store i1 %t217, ptr %l114, !tbaa !21
  br label %bb77
bb77:
  %t218 = load i1, ptr %l114, !tbaa !21
  br i1 %t218, label %bb78, label %bb79
bb78:
  %t219 = load ptr, ptr %l9, !tbaa !29
  %t221 = getelementptr { i64, [5 x i64] }, ptr %t219, i32 0, i32 1
  %t222 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t221, i32 0, i32 2
  %t223 = load ptr, ptr %t222
  store ptr %t223, ptr %l10, !tbaa !29
  br label %bb80
bb79:
  br label %bb95
bb80:
  %t225 = load ptr, ptr %l10, !tbaa !29
  %t227 = getelementptr %"compiler/typed:Match", ptr %t225, i32 0, i32 1
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t230 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  store i64 %t232, ptr %l13, !tbaa !24
  br label %bb81
bb81:
  store %olang.scope zeroinitializer, ptr %s17
  %t234 = load i64, ptr %l12, !tbaa !24
  %t235 = load i64, ptr %l13, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  %t240 = xor i1 %t238, true
  br i1 %t240, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s17)
  br label %bb90
bb83:
  br label %bb84
bb84:
  %t242 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t242, ptr %l127, !tbaa !27
  %t243 = load i64, ptr %l12, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr ptr, ptr %t246, i64 %t243
  %t248 = load ptr, ptr %t247, !tbaa !39
  %t252 = getelementptr %"compiler/typed:Arm", ptr %t248, i32 0, i32 3
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t253)
  store i1 %t255, ptr %l132
  br label %bb85
bb85:
  %t256 = load i1, ptr %l132, !tbaa !21
  %t257 = xor i1 %t256, true
  br i1 %t257, label %bb86, label %bb87
bb86:
  call void @__olang_scope_close(ptr %s17)
  store i1 false, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s17)
  br label %bb89
bb89:
  %t260 = load i64, ptr %l12, !tbaa !24
  %t262 = add i64 %t260, 1
  store i64 %t262, ptr %l12, !tbaa !24
  br label %bb81
bb90:
  %t264 = load ptr, ptr %l10, !tbaa !29
  %t266 = getelementptr %"compiler/typed:Match", ptr %t264, i32 0, i32 2
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = icmp eq ptr %t267, null
  br i1 %t269, label %bb91, label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70)
  unreachable
bb92:
  br label %bb93
bb93:
  %t271 = load ptr, ptr %l10, !tbaa !29
  %t273 = getelementptr %"compiler/typed:Match", ptr %t271, i32 0, i32 2
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t277 = getelementptr %"compiler/typed:Arm", ptr %t274, i32 0, i32 3
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t278)
  store i1 %t280, ptr %l144
  br label %bb94
bb94:
  %t281 = load i1, ptr %l144, !tbaa !21
  store i1 %t281, ptr %rv
  br label %ret
bb95:
  store i1 false, ptr %rv
  br label %ret
bb96:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2elocalRead(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t17 = load ptr, ptr %l8, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l8, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l9, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %rv
  br label %ret
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8)
  unreachable
bb16:
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_a6ce77febe1defe5_34385e948c177179)
  unreachable
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enamedFn(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 15
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_a1143936e424f416_6a846c9af99dae82)
  unreachable
bb16:
  %t25 = load i1, ptr %l9, !tbaa !21
  store i1 %t25, ptr %l2, !tbaa !21
  br label %bb22
bb17:
  br i1 true, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_b0c5dfd122db8337_2ed6598a574b6003)
  unreachable
bb22:
  %t26 = load i1, ptr %l2, !tbaa !21
  store i1 %t26, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2enoLit() #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s0, i1 false, i1 false, i1 false, i64 0, double 0x0000000000000000)
  store %"compiler/check:litv" %t1, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t2 = load %"compiler/check:litv", ptr %l0
  store %"compiler/check:litv" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2eofMag(i1 %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i64
  %l11 = alloca %"compiler/check:litv"
  %l14 = alloca %"compiler/check:litv"
  %l21 = alloca %"compiler/check:litv"
  %l22 = alloca %"compiler/check:litv"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/check:litv"
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = shl i64 1, 63
  store i64 %t1, ptr %l2, !tbaa !65
  %t5 = xor i1 %a0, true
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load i64, ptr %l1, !tbaa !65
  %t8 = load i64, ptr %l2, !tbaa !65
  %t11 = icmp ult i64 %t7, %t8
  br i1 %t11, label %bb3, label %bb4
bb2:
  br label %bb8
bb3:
  %t13 = load i64, ptr %l1, !tbaa !65
  %t16 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t13)
  store %"compiler/check:litv" %t16, ptr %l11
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t17 = load %"compiler/check:litv", ptr %l11
  store %"compiler/check:litv" %t17, ptr %rv
  br label %ret
bb6:
  %t18 = load i64, ptr %l1, !tbaa !65
  %t21 = call %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %s1, i1 true, i1 false, i1 true, i64 %t18, double 0x0000000000000000)
  store %"compiler/check:litv" %t21, ptr %l14
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t22 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t22, ptr %rv
  br label %ret
bb8:
  %t23 = load i64, ptr %l1, !tbaa !65
  %t24 = load i64, ptr %l2, !tbaa !65
  %t27 = icmp ule i64 %t23, %t24
  br i1 %t27, label %bb9, label %bb10
bb9:
  %t29 = load i64, ptr %l1, !tbaa !65
  %t31 = sub i64 0, %t29
  %t34 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t31)
  store %"compiler/check:litv" %t34, ptr %l21
  br label %bb11
bb10:
  br label %bb12
bb11:
  %t35 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t35, ptr %rv
  br label %ret
bb12:
  %t36 = call %"compiler/check:litv" @compiler_2fcheck_2enoLit()
  store %"compiler/check:litv" %t36, ptr %l22
  br label %bb13
bb13:
  %t37 = load %"compiler/check:litv", ptr %l22
  store %"compiler/check:litv" %t37, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i1
  %l38 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca i1
  %l49 = alloca i1
  %l50 = alloca i1
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l69 = alloca { i64, ptr }
  %l74 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca i1
  %l90 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca i1
  %l103 = alloca i1
  %l104 = alloca ptr
  %l105 = alloca i1
  %l110 = alloca ptr
  %l111 = alloca i1
  %l118 = alloca i1
  %l119 = alloca ptr
  %l120 = alloca i1
  %l127 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca i1
  %l136 = alloca i1
  %l137 = alloca ptr
  %l138 = alloca i1
  %l147 = alloca i1
  %l148 = alloca i1
  %l152 = alloca i1
  %l153 = alloca ptr
  %l154 = alloca i1
  %l162 = alloca i1
  %l163 = alloca i1
  %l167 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l176 = alloca i1
  %l177 = alloca ptr
  %l178 = alloca i1
  %l186 = alloca i1
  %l187 = alloca i1
  %l191 = alloca i1
  %l192 = alloca ptr
  %l193 = alloca i1
  %l201 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l215 = alloca { i64, ptr }
  %l220 = alloca i1
  %s6 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t7 = load ptr, ptr %l29, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l29, !tbaa !29
  %t11 = load i64, ptr %t10
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l30, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l30, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [5 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", ptr }, ptr %t17, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  store ptr %t19, ptr %l2, !tbaa !29
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t26 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t21, { i64, ptr } %t23)
  store i1 %t26, ptr %l38
  br label %bb9
bb9:
  %t27 = load i1, ptr %l38, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
bb10:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t29 = load ptr, ptr %l39, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t32 = load ptr, ptr %l39, !tbaa !29
  %t33 = load i64, ptr %t32
  %t35 = icmp eq i64 %t33, 3
  store i1 %t35, ptr %l40, !tbaa !21
  br label %bb12
bb12:
  %t36 = load i1, ptr %l40, !tbaa !21
  br i1 %t36, label %bb13, label %bb14
bb13:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [5 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l3, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr { i64, [5 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t45, i32 0, i32 3
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l4, !tbaa !29
  br label %bb15
bb14:
  br label %bb21
bb15:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t53 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t49, { i64, ptr } %t50)
  store i1 %t53, ptr %l49
  br label %bb16
bb16:
  %t54 = load i1, ptr %l49, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l50, !tbaa !21
  br label %bb20
bb18:
  %t55 = load ptr, ptr %l4, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t60 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t55, { i64, ptr } %t57)
  store i1 %t60, ptr %l54
  br label %bb19
bb19:
  %t61 = load i1, ptr %l54, !tbaa !21
  store i1 %t61, ptr %l50, !tbaa !21
  br label %bb20
bb20:
  %t62 = load i1, ptr %l50, !tbaa !21
  store i1 %t62, ptr %rv
  br label %ret
bb21:
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t64 = load ptr, ptr %l55, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb22, label %bb23
bb22:
  %t67 = load ptr, ptr %l55, !tbaa !29
  %t68 = load i64, ptr %t67
  %t70 = icmp eq i64 %t68, 2
  store i1 %t70, ptr %l56, !tbaa !21
  br label %bb23
bb23:
  %t71 = load i1, ptr %l56, !tbaa !21
  br i1 %t71, label %bb24, label %bb25
bb24:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr { i64, [5 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l5, !tbaa !29
  br label %bb26
bb25:
  br label %bb37
bb26:
  %t78 = load ptr, ptr %l5, !tbaa !29
  %t80 = getelementptr %"compiler/ast:Multi", ptr %t78, i32 0, i32 0
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  store i64 %t85, ptr %l8, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l8, !tbaa !24
  %t91 = icmp slt i64 %t87, %t88
  %t93 = xor i1 %t91, true
  br i1 %t93, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t95 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t95, ptr %l69, !tbaa !27
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 %t96
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t104 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %t104)
  store i1 %t107, ptr %l74
  br label %bb31
bb31:
  %t108 = load i1, ptr %l74, !tbaa !21
  br i1 %t108, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  store i1 true, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t110 = load i64, ptr %l7, !tbaa !24
  %t112 = add i64 %t110, 1
  store i64 %t112, ptr %l7, !tbaa !24
  br label %bb27
bb36:
  store i1 false, ptr %rv
  br label %ret
bb37:
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l79, !tbaa !29
  store i1 false, ptr %l80, !tbaa !21
  %t116 = load ptr, ptr %l79, !tbaa !29
  %t117 = icmp ne ptr %t116, null
  br i1 %t117, label %bb38, label %bb39
bb38:
  %t119 = load ptr, ptr %l79, !tbaa !29
  %t120 = load i64, ptr %t119
  %t122 = icmp eq i64 %t120, 4
  store i1 %t122, ptr %l80, !tbaa !21
  br label %bb39
bb39:
  %t123 = load i1, ptr %l80, !tbaa !21
  br i1 %t123, label %bb40, label %bb41
bb40:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr { i64, [5 x i64] }, ptr %t124, i32 0, i32 1
  %t127 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t126, i32 0, i32 1
  %t128 = load ptr, ptr %t127
  store ptr %t128, ptr %l10, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr { i64, [5 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr }, i1 }, ptr %t132, i32 0, i32 2
  %t134 = load { i64, ptr }, ptr %t133
  store { i64, ptr } %t134, ptr %l11, !tbaa !27
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t136 = load ptr, ptr %l10, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t141 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t136, { i64, ptr } %t138)
  store i1 %t141, ptr %l90
  br label %bb43
bb43:
  %t142 = load i1, ptr %l90, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb47
bb45:
  %t143 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t147 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t143, { i64, ptr } %t144)
  store i1 %t147, ptr %l94
  br label %bb46
bb46:
  %t148 = load i1, ptr %l94, !tbaa !21
  store i1 %t148, ptr %l91, !tbaa !21
  br label %bb47
bb47:
  %t149 = load i1, ptr %l91, !tbaa !21
  store i1 %t149, ptr %rv
  br label %ret
bb48:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l95, !tbaa !29
  store i1 false, ptr %l96, !tbaa !21
  %t151 = load ptr, ptr %l95, !tbaa !29
  %t152 = icmp ne ptr %t151, null
  br i1 %t152, label %bb49, label %bb50
bb49:
  %t154 = load ptr, ptr %l95, !tbaa !29
  %t155 = load i64, ptr %t154
  %t157 = icmp eq i64 %t155, 5
  store i1 %t157, ptr %l96, !tbaa !21
  br label %bb50
bb50:
  %t158 = load i1, ptr %l96, !tbaa !21
  br i1 %t158, label %bb51, label %bb52
bb51:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr { i64, [5 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", ptr }, ptr %t161, i32 0, i32 1
  %t163 = load ptr, ptr %t162
  store ptr %t163, ptr %l12, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t166 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t169 = call i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %t165, { i64, ptr } %t166)
  store i1 %t169, ptr %l103
  br label %bb54
bb54:
  %t170 = load i1, ptr %l103, !tbaa !21
  store i1 %t170, ptr %rv
  br label %ret
bb55:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l104, !tbaa !29
  store i1 false, ptr %l105, !tbaa !21
  %t172 = load ptr, ptr %l104, !tbaa !29
  %t173 = icmp ne ptr %t172, null
  br i1 %t173, label %bb56, label %bb57
bb56:
  %t175 = load ptr, ptr %l104, !tbaa !29
  %t176 = load i64, ptr %t175
  %t178 = icmp eq i64 %t176, 6
  store i1 %t178, ptr %l105, !tbaa !21
  br label %bb57
bb57:
  %t179 = load i1, ptr %l105, !tbaa !21
  br i1 %t179, label %bb58, label %bb59
bb58:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr { i64, [5 x i64] }, ptr %t180, i32 0, i32 1
  %t183 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t182, i32 0, i32 1
  %t184 = load { i64, ptr }, ptr %t183
  store { i64, ptr } %t184, ptr %l13, !tbaa !27
  br label %bb64
bb59:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l110, !tbaa !29
  store i1 false, ptr %l111, !tbaa !21
  %t187 = load ptr, ptr %l110, !tbaa !29
  %t188 = icmp ne ptr %t187, null
  br i1 %t188, label %bb60, label %bb61
bb60:
  %t190 = load ptr, ptr %l110, !tbaa !29
  %t191 = load i64, ptr %t190
  %t193 = icmp eq i64 %t191, 19
  store i1 %t193, ptr %l111, !tbaa !21
  br label %bb61
bb61:
  %t194 = load i1, ptr %l111, !tbaa !21
  br i1 %t194, label %bb62, label %bb63
bb62:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr { i64, [5 x i64] }, ptr %t195, i32 0, i32 1
  %t198 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t197, i32 0, i32 1
  %t199 = load { i64, ptr }, ptr %t198
  store { i64, ptr } %t199, ptr %l13, !tbaa !27
  br label %bb64
bb63:
  br label %bb66
bb64:
  %t201 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t205 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t201, { i64, ptr } %t202)
  store i1 %t205, ptr %l118
  br label %bb65
bb65:
  %t206 = load i1, ptr %l118, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb66:
  %t207 = load ptr, ptr %l0, !tbaa !29
  store ptr %t207, ptr %l119, !tbaa !29
  store i1 false, ptr %l120, !tbaa !21
  %t208 = load ptr, ptr %l119, !tbaa !29
  %t209 = icmp ne ptr %t208, null
  br i1 %t209, label %bb67, label %bb68
bb67:
  %t211 = load ptr, ptr %l119, !tbaa !29
  %t212 = load i64, ptr %t211
  %t214 = icmp eq i64 %t212, 7
  store i1 %t214, ptr %l120, !tbaa !21
  br label %bb68
bb68:
  %t215 = load i1, ptr %l120, !tbaa !21
  br i1 %t215, label %bb69, label %bb70
bb69:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr { i64, [5 x i64] }, ptr %t216, i32 0, i32 1
  %t219 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t218, i32 0, i32 2
  %t220 = load { i64, ptr }, ptr %t219
  store { i64, ptr } %t220, ptr %l14, !tbaa !27
  br label %bb71
bb70:
  br label %bb73
bb71:
  %t222 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t226 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t222, { i64, ptr } %t223)
  store i1 %t226, ptr %l127
  br label %bb72
bb72:
  %t227 = load i1, ptr %l127, !tbaa !21
  store i1 %t227, ptr %rv
  br label %ret
bb73:
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l128, !tbaa !29
  store i1 false, ptr %l129, !tbaa !21
  %t229 = load ptr, ptr %l128, !tbaa !29
  %t230 = icmp ne ptr %t229, null
  br i1 %t230, label %bb74, label %bb75
bb74:
  %t232 = load ptr, ptr %l128, !tbaa !29
  %t233 = load i64, ptr %t232
  %t235 = icmp eq i64 %t233, 10
  store i1 %t235, ptr %l129, !tbaa !21
  br label %bb75
bb75:
  %t236 = load i1, ptr %l129, !tbaa !21
  br i1 %t236, label %bb76, label %bb77
bb76:
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = getelementptr { i64, [5 x i64] }, ptr %t237, i32 0, i32 1
  %t240 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t239, i32 0, i32 1
  %t241 = load { i64, ptr }, ptr %t240
  store { i64, ptr } %t241, ptr %l15, !tbaa !27
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t243 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t247 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t243, { i64, ptr } %t244)
  store i1 %t247, ptr %l136
  br label %bb79
bb79:
  %t248 = load i1, ptr %l136, !tbaa !21
  store i1 %t248, ptr %rv
  br label %ret
bb80:
  %t249 = load ptr, ptr %l0, !tbaa !29
  store ptr %t249, ptr %l137, !tbaa !29
  store i1 false, ptr %l138, !tbaa !21
  %t250 = load ptr, ptr %l137, !tbaa !29
  %t251 = icmp ne ptr %t250, null
  br i1 %t251, label %bb81, label %bb82
bb81:
  %t253 = load ptr, ptr %l137, !tbaa !29
  %t254 = load i64, ptr %t253
  %t256 = icmp eq i64 %t254, 8
  store i1 %t256, ptr %l138, !tbaa !21
  br label %bb82
bb82:
  %t257 = load i1, ptr %l138, !tbaa !21
  br i1 %t257, label %bb83, label %bb84
bb83:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr { i64, [5 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", ptr }, ptr %t260, i32 0, i32 1
  %t262 = load ptr, ptr %t261
  store ptr %t262, ptr %l16, !tbaa !29
  br label %bb85
bb84:
  br label %bb91
bb85:
  %t264 = load ptr, ptr %l16, !tbaa !29
  %t266 = getelementptr %"compiler/ast:For3", ptr %t264, i32 0, i32 2
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t272 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t267, { i64, ptr } %t269)
  store i1 %t272, ptr %l147
  br label %bb86
bb86:
  %t273 = load i1, ptr %l147, !tbaa !21
  br i1 %t273, label %bb87, label %bb88
bb87:
  store i1 true, ptr %l148, !tbaa !21
  br label %bb90
bb88:
  %t274 = load ptr, ptr %l16, !tbaa !29
  %t276 = getelementptr %"compiler/ast:For3", ptr %t274, i32 0, i32 3
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t281 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t277, { i64, ptr } %t278)
  store i1 %t281, ptr %l152
  br label %bb89
bb89:
  %t282 = load i1, ptr %l152, !tbaa !21
  store i1 %t282, ptr %l148, !tbaa !21
  br label %bb90
bb90:
  %t283 = load i1, ptr %l148, !tbaa !21
  store i1 %t283, ptr %rv
  br label %ret
bb91:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l153, !tbaa !29
  store i1 false, ptr %l154, !tbaa !21
  %t285 = load ptr, ptr %l153, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb92, label %bb93
bb92:
  %t288 = load ptr, ptr %l153, !tbaa !29
  %t289 = load i64, ptr %t288
  %t291 = icmp eq i64 %t289, 9
  store i1 %t291, ptr %l154, !tbaa !21
  br label %bb93
bb93:
  %t292 = load i1, ptr %l154, !tbaa !21
  br i1 %t292, label %bb94, label %bb95
bb94:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr { i64, [5 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l17, !tbaa !29
  br label %bb96
bb95:
  br label %bb102
bb96:
  %t299 = load ptr, ptr %l17, !tbaa !29
  %t301 = getelementptr %"compiler/ast:ForIn", ptr %t299, i32 0, i32 4
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t303 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t306 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t302, { i64, ptr } %t303)
  store i1 %t306, ptr %l162
  br label %bb97
bb97:
  %t307 = load i1, ptr %l162, !tbaa !21
  br i1 %t307, label %bb98, label %bb99
bb98:
  store i1 true, ptr %l163, !tbaa !21
  br label %bb101
bb99:
  %t308 = load ptr, ptr %l17, !tbaa !29
  %t310 = getelementptr %"compiler/ast:ForIn", ptr %t308, i32 0, i32 5
  %t311 = load { i64, ptr }, ptr %t310, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t315 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t311, { i64, ptr } %t312)
  store i1 %t315, ptr %l167
  br label %bb100
bb100:
  %t316 = load i1, ptr %l167, !tbaa !21
  store i1 %t316, ptr %l163, !tbaa !21
  br label %bb101
bb101:
  %t317 = load i1, ptr %l163, !tbaa !21
  store i1 %t317, ptr %rv
  br label %ret
bb102:
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t319 = load ptr, ptr %l168, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb103, label %bb104
bb103:
  %t322 = load ptr, ptr %l168, !tbaa !29
  %t323 = load i64, ptr %t322
  %t325 = icmp eq i64 %t323, 11
  store i1 %t325, ptr %l169, !tbaa !21
  br label %bb104
bb104:
  %t326 = load i1, ptr %l169, !tbaa !21
  br i1 %t326, label %bb105, label %bb106
bb105:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", ptr }, ptr %t329, i32 0, i32 1
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l18, !tbaa !29
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t333 = load ptr, ptr %l18, !tbaa !29
  %t334 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t337 = call i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %t333, { i64, ptr } %t334)
  store i1 %t337, ptr %l176
  br label %bb108
bb108:
  %t338 = load i1, ptr %l176, !tbaa !21
  store i1 %t338, ptr %rv
  br label %ret
bb109:
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l177, !tbaa !29
  store i1 false, ptr %l178, !tbaa !21
  %t340 = load ptr, ptr %l177, !tbaa !29
  %t341 = icmp ne ptr %t340, null
  br i1 %t341, label %bb110, label %bb111
bb110:
  %t343 = load ptr, ptr %l177, !tbaa !29
  %t344 = load i64, ptr %t343
  %t346 = icmp eq i64 %t344, 17
  store i1 %t346, ptr %l178, !tbaa !21
  br label %bb111
bb111:
  %t347 = load i1, ptr %l178, !tbaa !21
  br i1 %t347, label %bb112, label %bb113
bb112:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr { i64, [5 x i64] }, ptr %t348, i32 0, i32 1
  %t351 = getelementptr { %"compiler/source:Span", ptr }, ptr %t350, i32 0, i32 1
  %t352 = load ptr, ptr %t351
  store ptr %t352, ptr %l19, !tbaa !29
  br label %bb114
bb113:
  br label %bb120
bb114:
  %t354 = load ptr, ptr %l19, !tbaa !29
  %t356 = getelementptr %"compiler/ast:JoinS", ptr %t354, i32 0, i32 1
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t361 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t357, { i64, ptr } %t358)
  store i1 %t361, ptr %l186
  br label %bb115
bb115:
  %t362 = load i1, ptr %l186, !tbaa !21
  br i1 %t362, label %bb116, label %bb117
bb116:
  store i1 true, ptr %l187, !tbaa !21
  br label %bb119
bb117:
  %t363 = load ptr, ptr %l19, !tbaa !29
  %t365 = getelementptr %"compiler/ast:JoinS", ptr %t363, i32 0, i32 2
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t370 = call i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %t366, { i64, ptr } %t367)
  store i1 %t370, ptr %l191
  br label %bb118
bb118:
  %t371 = load i1, ptr %l191, !tbaa !21
  store i1 %t371, ptr %l187, !tbaa !21
  br label %bb119
bb119:
  %t372 = load i1, ptr %l187, !tbaa !21
  store i1 %t372, ptr %rv
  br label %ret
bb120:
  %t373 = load ptr, ptr %l0, !tbaa !29
  store ptr %t373, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t374 = load ptr, ptr %l192, !tbaa !29
  %t375 = icmp ne ptr %t374, null
  br i1 %t375, label %bb121, label %bb122
bb121:
  %t377 = load ptr, ptr %l192, !tbaa !29
  %t378 = load i64, ptr %t377
  %t380 = icmp eq i64 %t378, 18
  store i1 %t380, ptr %l193, !tbaa !21
  br label %bb122
bb122:
  %t381 = load i1, ptr %l193, !tbaa !21
  br i1 %t381, label %bb123, label %bb124
bb123:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr { i64, [5 x i64] }, ptr %t382, i32 0, i32 1
  %t385 = getelementptr { %"compiler/source:Span", ptr }, ptr %t384, i32 0, i32 1
  %t386 = load ptr, ptr %t385
  store ptr %t386, ptr %l20, !tbaa !29
  br label %bb125
bb124:
  br label %bb127
bb125:
  %t388 = load ptr, ptr %l20, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t393 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t388, { i64, ptr } %t390)
  store i1 %t393, ptr %l201
  br label %bb126
bb126:
  %t394 = load i1, ptr %l201, !tbaa !21
  store i1 %t394, ptr %rv
  br label %ret
bb127:
  %t395 = load ptr, ptr %l0, !tbaa !29
  store ptr %t395, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t396 = load ptr, ptr %l202, !tbaa !29
  %t397 = icmp ne ptr %t396, null
  br i1 %t397, label %bb128, label %bb129
bb128:
  %t399 = load ptr, ptr %l202, !tbaa !29
  %t400 = load i64, ptr %t399
  %t402 = icmp eq i64 %t400, 16
  store i1 %t402, ptr %l203, !tbaa !21
  br label %bb129
bb129:
  %t403 = load i1, ptr %l203, !tbaa !21
  br i1 %t403, label %bb130, label %bb131
bb130:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr { i64, [5 x i64] }, ptr %t404, i32 0, i32 1
  %t407 = getelementptr { %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t406, i32 0, i32 1
  %t408 = load { i64, ptr }, ptr %t407
  store { i64, ptr } %t408, ptr %l21, !tbaa !27
  br label %bb132
bb131:
  br label %bb143
bb132:
  %t410 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t410, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t412 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t412, 0
  store i64 %t414, ptr %l24, !tbaa !24
  br label %bb133
bb133:
  store %olang.scope zeroinitializer, ptr %s21
  %t416 = load i64, ptr %l23, !tbaa !24
  %t417 = load i64, ptr %l24, !tbaa !24
  %t420 = icmp slt i64 %t416, %t417
  %t422 = xor i1 %t420, true
  br i1 %t422, label %bb134, label %bb135
bb134:
  call void @__olang_scope_close(ptr %s21)
  br label %bb142
bb135:
  br label %bb136
bb136:
  %t424 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t424, ptr %l215, !tbaa !27
  %t425 = load i64, ptr %l23, !tbaa !24
  %t427 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t428 = load ptr, ptr %t427, !tbaa !27
  %t429 = getelementptr ptr, ptr %t428, i64 %t425
  %t430 = load ptr, ptr %t429, !tbaa !39
  %t433 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t436 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t430, { i64, ptr } %t433)
  store i1 %t436, ptr %l220
  br label %bb137
bb137:
  %t437 = load i1, ptr %l220, !tbaa !21
  br i1 %t437, label %bb138, label %bb139
bb138:
  call void @__olang_scope_close(ptr %s21)
  store i1 true, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s21)
  br label %bb141
bb141:
  %t439 = load i64, ptr %l23, !tbaa !24
  %t441 = add i64 %t439, 1
  store i64 %t441, ptr %l23, !tbaa !24
  br label %bb133
bb142:
  store i1 false, ptr %rv
  br label %ret
bb143:
  br i1 true, label %bb144, label %bb145
bb144:
  br label %bb146
bb145:
  br label %bb147
bb146:
  store i1 false, ptr %rv
  br label %ret
bb147:
  call void @__olang_check_failed(ptr @olang_loc_3f7a94628940c729_cdb98f41ead125dd)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredIf(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/ast:If", ptr %t8, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = icmp eq ptr %t20, null
  br i1 %t22, label %bb4, label %bb5
bb3:
  br label %bb8
bb4:
  call void @__olang_check_failed(ptr @olang_loc_b4de3dcccf9032b4_264e366d03c66670)
  unreachable
bb5:
  br label %bb6
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/ast:If", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Branch", ptr %t27, i32 0, i32 1
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  %t32 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %t31, ptr %t32)
  br label %bb7
bb7:
  br label %bb8
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 2
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t39 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  br label %bb9
bb9:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v1, ptr %t16, i32 %t17, i1 true)
  br label %bb6
bb6:
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t21 = load ptr, ptr %l12, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t25 = load i64, ptr %t24
  %t27 = icmp eq i64 %t25, 2
  store i1 %t27, ptr %l13, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l13, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", ptr }, ptr %t31, i32 0, i32 1
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t35 = load ptr, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredTarget(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  br label %bb13
bb13:
  br label %bb16
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t39, ptr %t41)
  br label %bb15
bb15:
  br label %bb16
bb16:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_3aframe_2ector(ptr %out, ptr %v0, i64 %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4) #0 {
entry:
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"compiler/generic:Context"
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i64
  %l13 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i32
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l46 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l47 = alloca i64
  %l48 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l50 = alloca { i64, ptr }
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l61 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l62 = alloca %"compiler/generic:Context"
  %l65 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l66 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l67 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l68 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l70 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l71 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l74 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l75 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l76 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l77 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l87 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l88 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l89 = alloca %"compiler/check:frame"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l5, !tbaa !24
  store i64 %a1, ptr %l6, !tbaa !24
  store i64 %a2, ptr %l7, !tbaa !24
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e(ptr %t7)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l61
  br label %bb1
bb1:
  %t9 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l61
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l8
  %t10 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 0, i64 -1)
  store %"compiler/generic:Context" %t10, ptr %l62
  br label %bb2
bb2:
  %t11 = load %"compiler/generic:Context", ptr %l62
  store %"compiler/generic:Context" %t11, ptr %l9
  store i32 %a3, ptr %l10, !tbaa !23
  store i32 %a4, ptr %l11, !tbaa !23
  store i64 0, ptr %l12, !tbaa !24
  %t16 = load ptr, ptr @__olang_prog_scope
  %t17 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t16)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, ptr %l65
  br label %bb3
bb3:
  %t18 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l65
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, ptr %l13
  %t19 = load ptr, ptr @__olang_prog_scope
  %t20 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e(ptr %t19)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, ptr %l66
  br label %bb4
bb4:
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l66
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l14
  %t22 = load ptr, ptr @__olang_prog_scope
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l67
  br label %bb5
bb5:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l67
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l15
  %t25 = load ptr, ptr @__olang_prog_scope
  %t26 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t25)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %l68
  br label %bb6
bb6:
  %t27 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, ptr %l16
  store i1 false, ptr %l17, !tbaa !21
  store i1 false, ptr %l18, !tbaa !21
  %t28 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t28, ptr %l19, !tbaa !23
  store i64 0, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  store i1 false, ptr %l25, !tbaa !21
  store i64 -1, ptr %l26, !tbaa !24
  store i1 false, ptr %l27, !tbaa !21
  store i1 false, ptr %l28, !tbaa !21
  store i1 false, ptr %l29, !tbaa !21
  %t30 = load ptr, ptr @__olang_prog_scope
  %t31 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t30)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t31, ptr %l70
  br label %bb7
bb7:
  %t32 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l70
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t32, ptr %l30
  %t33 = load ptr, ptr @__olang_prog_scope
  %t34 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t33)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t34, ptr %l71
  br label %bb8
bb8:
  %t35 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l71
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t35, ptr %l31
  %t36 = load ptr, ptr @__olang_prog_scope
  %t37 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e(ptr %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t37, ptr %l72
  br label %bb9
bb9:
  %t38 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t38, ptr %l32
  store i64 -1, ptr %l33, !tbaa !24
  store i1 false, ptr %l34, !tbaa !21
  store i64 0, ptr %l35, !tbaa !24
  store i64 -1, ptr %l36, !tbaa !24
  store i64 -1, ptr %l37, !tbaa !24
  store i1 false, ptr %l38, !tbaa !21
  store i64 -1, ptr %l39, !tbaa !24
  %t39 = load ptr, ptr @__olang_prog_scope
  %t40 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t39)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l73
  br label %bb10
bb10:
  %t41 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l73
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l40
  %t42 = load ptr, ptr @__olang_prog_scope
  %t43 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t42)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t43, ptr %l74
  br label %bb11
bb11:
  %t44 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t44, ptr %l41
  %t45 = load ptr, ptr @__olang_prog_scope
  %t46 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %t45)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t46, ptr %l75
  br label %bb12
bb12:
  %t47 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t47, ptr %l42
  store i64 0, ptr %l43, !tbaa !24
  store i64 0, ptr %l44, !tbaa !24
  %t48 = load ptr, ptr @__olang_prog_scope
  %t49 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t48)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t49, ptr %l76
  br label %bb13
bb13:
  %t50 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l76
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t50, ptr %l45
  %t51 = load ptr, ptr @__olang_prog_scope
  %t52 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %t51)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t52, ptr %l77
  br label %bb14
bb14:
  %t53 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l77
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t53, ptr %l46
  store i64 -1, ptr %l47, !tbaa !24
  %t54 = load ptr, ptr @__olang_prog_scope
  %t55 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e(ptr %t54)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t55, ptr %l78
  br label %bb15
bb15:
  %t56 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t56, ptr %l48
  %t57 = load ptr, ptr @__olang_prog_scope
  %t58 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t57)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t58, ptr %l79
  br label %bb16
bb16:
  %t59 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t59, ptr %l49
  %t60 = icmp sge i64 0, 0
  br i1 %t60, label %bb17, label %bb18
bb17:
  %t62 = icmp sle i64 0, 2305843009213693951
  br i1 %t62, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_8df4ab6431d52630_31943992274c649c)
  unreachable
bb19:
  %t64 = mul i64 0, 4
  %t65 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 0, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l50, !tbaa !27
  %t69 = load ptr, ptr @__olang_prog_scope
  %t70 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e(ptr %t69)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l83
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_8df4ab6431d52630_31943992274c649c)
  unreachable
bb21:
  %t71 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l51
  %t72 = icmp sge i64 0, 0
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = icmp sle i64 0, 1152921504606846975
  br i1 %t74, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c67c2282dc8bf9dd_b54d55782b869669)
  unreachable
bb24:
  %t76 = mul i64 0, 8
  %t77 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t76)
  %t78 = insertvalue { i64, ptr } undef, i64 0, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l52, !tbaa !27
  store i64 0, ptr %l53, !tbaa !24
  store i64 0, ptr %l54, !tbaa !24
  %t81 = load ptr, ptr @__olang_prog_scope
  %t82 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %t81)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t82, ptr %l87
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_c67c2282dc8bf9dd_b54d55782b869669)
  unreachable
bb26:
  %t83 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l87
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t83, ptr %l55
  %t84 = load ptr, ptr @__olang_prog_scope
  %t85 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %t84)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %l88
  br label %bb27
bb27:
  %t86 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l88
  %t87 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 0
  %t88 = load i64, ptr %l5, !tbaa !24
  store i64 %t88, ptr %t87, !tbaa !24
  %t89 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 1
  %t90 = load i64, ptr %l6, !tbaa !24
  store i64 %t90, ptr %t89, !tbaa !24
  %t91 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 2
  %t92 = load i64, ptr %l7, !tbaa !24
  store i64 %t92, ptr %t91, !tbaa !24
  %t93 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 3
  %t94 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t94, ptr %t93
  %t95 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 4
  %t96 = load %"compiler/generic:Context", ptr %l9
  store %"compiler/generic:Context" %t96, ptr %t95
  %t97 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 5
  %t98 = load i32, ptr %l10, !tbaa !23
  store i32 %t98, ptr %t97, !tbaa !23
  %t99 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 6
  %t100 = load i32, ptr %l11, !tbaa !23
  store i32 %t100, ptr %t99, !tbaa !23
  %t101 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 7
  %t102 = load i64, ptr %l12, !tbaa !24
  store i64 %t102, ptr %t101, !tbaa !24
  %t103 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 8
  %t104 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t104, ptr %t103
  %t105 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 9
  %t106 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %t105
  %t107 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 10
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %t107
  %t109 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 11
  %t110 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l16
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t110, ptr %t109
  %t111 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 12
  %t112 = load i1, ptr %l17, !tbaa !21
  store i1 %t112, ptr %t111, !tbaa !21
  %t113 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 13
  %t114 = load i1, ptr %l18, !tbaa !21
  store i1 %t114, ptr %t113, !tbaa !21
  %t115 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 14
  %t116 = load i32, ptr %l19, !tbaa !23
  store i32 %t116, ptr %t115, !tbaa !23
  %t117 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 15
  %t118 = load i64, ptr %l20, !tbaa !24
  store i64 %t118, ptr %t117, !tbaa !24
  %t119 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 16
  %t120 = load i64, ptr %l21, !tbaa !24
  store i64 %t120, ptr %t119, !tbaa !24
  %t121 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 17
  %t122 = load i64, ptr %l22, !tbaa !24
  store i64 %t122, ptr %t121, !tbaa !24
  %t123 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 18
  %t124 = load i64, ptr %l23, !tbaa !24
  store i64 %t124, ptr %t123, !tbaa !24
  %t125 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 19
  %t126 = load i64, ptr %l24, !tbaa !24
  store i64 %t126, ptr %t125, !tbaa !24
  %t127 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 20
  %t128 = load i1, ptr %l25, !tbaa !21
  store i1 %t128, ptr %t127, !tbaa !21
  %t129 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 21
  %t130 = load i64, ptr %l26, !tbaa !24
  store i64 %t130, ptr %t129, !tbaa !24
  %t131 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 22
  %t132 = load i1, ptr %l27, !tbaa !21
  store i1 %t132, ptr %t131, !tbaa !21
  %t133 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 23
  %t134 = load i1, ptr %l28, !tbaa !21
  store i1 %t134, ptr %t133, !tbaa !21
  %t135 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 24
  %t136 = load i1, ptr %l29, !tbaa !21
  store i1 %t136, ptr %t135, !tbaa !21
  %t137 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 25
  %t138 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t138, ptr %t137
  %t139 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 26
  %t140 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l31
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t140, ptr %t139
  %t141 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 27
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l32
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %t141
  %t143 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 28
  %t144 = load i64, ptr %l33, !tbaa !24
  store i64 %t144, ptr %t143, !tbaa !24
  %t145 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 29
  %t146 = load i1, ptr %l34, !tbaa !21
  store i1 %t146, ptr %t145, !tbaa !21
  %t147 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 30
  %t148 = load i64, ptr %l35, !tbaa !24
  store i64 %t148, ptr %t147, !tbaa !24
  %t149 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 31
  %t150 = load i64, ptr %l36, !tbaa !24
  store i64 %t150, ptr %t149, !tbaa !24
  %t151 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 32
  %t152 = load i64, ptr %l37, !tbaa !24
  store i64 %t152, ptr %t151, !tbaa !24
  %t153 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 33
  %t154 = load i1, ptr %l38, !tbaa !21
  store i1 %t154, ptr %t153, !tbaa !21
  %t155 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 34
  %t156 = load i64, ptr %l39, !tbaa !24
  store i64 %t156, ptr %t155, !tbaa !24
  %t157 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 35
  %t158 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t158, ptr %t157
  %t159 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 36
  %t160 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t160, ptr %t159
  %t161 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 37
  %t162 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l42
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t162, ptr %t161
  %t163 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 38
  %t164 = load i64, ptr %l43, !tbaa !24
  store i64 %t164, ptr %t163, !tbaa !24
  %t165 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 39
  %t166 = load i64, ptr %l44, !tbaa !24
  store i64 %t166, ptr %t165, !tbaa !24
  %t167 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 40
  %t168 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l45
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t168, ptr %t167
  %t169 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 41
  %t170 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l46
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t170, ptr %t169
  %t171 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 42
  %t172 = load i64, ptr %l47, !tbaa !24
  store i64 %t172, ptr %t171, !tbaa !24
  %t173 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 43
  %t174 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l48
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t174, ptr %t173
  %t175 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 44
  %t176 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l49
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t176, ptr %t175
  %t177 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 45
  %t178 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t178, ptr %t177, !tbaa !27
  %t179 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 46
  %t180 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t180, ptr %t179
  %t181 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 47
  %t182 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t182, ptr %t181, !tbaa !27
  %t183 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 48
  %t184 = load i64, ptr %l53, !tbaa !24
  store i64 %t184, ptr %t183, !tbaa !24
  %t185 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 49
  %t186 = load i64, ptr %l54, !tbaa !24
  store i64 %t186, ptr %t185, !tbaa !24
  %t187 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 50
  %t188 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l55
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %t187
  %t189 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 51
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t86, ptr %t189
  %t191 = getelementptr %"compiler/check:frame", ptr %l89, i32 0, i32 52
  store i64 0, ptr %t191, !tbaa !24
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l89, i64 416, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/check:roDeepArg" @compiler_2fcheck_3aroDeepArg_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roDeepArg"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roDeepArg" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roDeepArg" %t10, ptr %a1, 1
  %t14 = insertvalue %"compiler/check:roDeepArg" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/check:roDeepArg" %t14, i64 %a3, 3
  store %"compiler/check:roDeepArg" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roDeepArg", ptr %rv
  ret %"compiler/check:roDeepArg" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [1 x i8] c"("
@.d1 = private constant [1 x i8] c")"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d2 = private constant [4 x i8] c"Call"
@.d3 = private constant [4 x i8] c"call"
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d4 = private constant [4 x i8] c"Call"
@.d5 = private constant [1 x i8] c"'"
@.d6 = private constant [1 x i8] c"'"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.d7 = private constant [32 x i8] c"a build constant without a value"
@.d8 = private constant [3 x i8] c"U64"
@.d9 = private constant [3 x i8] c"F64"
@.d10 = private constant [35 x i8] c"a build constant of this kind (B10)"
@.d11 = private constant [4 x i8] c"std/"
@.d12 = private constant [0 x i8] c""
@.d13 = private constant [0 x i8] c""
@.d14 = private constant [1 x i8] c"s"
@.d15 = private constant [37 x i8] c"several globals given one value (D8c)"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d16 = private constant [0 x i8] c""
@.d17 = private constant [1 x i8] c"s"
@.d18 = private constant [31 x i8] c"a member of a type of this kind"
@.d19 = private constant [0 x i8] c""
@.d20 = private constant [1 x i8] c"s"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d21 = private constant [3 x i8] c"Len"
@.d22 = private constant [38 x i8] c"a derived CheckedAt with no Len (E31a)"
@.d23 = private constant [4 x i8] c"join"
@.d24 = private constant [8 x i8] c"a lambda"
@.d25 = private constant [0 x i8] c""
@.d26 = private constant [1 x i8] c"s"
@.d27 = private constant [74 x i8] c"a lambda parameter written as a reference where a value is expected (D16a)"
@.d28 = private constant [11 x i8] c"this lambda"
@.d29 = private constant [4 x i8] c"true"
@.d30 = private constant [22 x i8] c"a literal of this kind"
@.d31 = private constant [6 x i8] c"return"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d32 = private constant [46 x i8] c"a binding in a call compared as a value (S13d)"
@.d33 = private constant [0 x i8] c""
@.d34 = private constant [1 x i8] c"s"
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d35 = private constant [47 x i8] c"several values returned where one is the result"
@.d36 = private constant [50 x i8] c"a count of returned values other than the result's"
@.d37 = private constant [16 x i8] c"std/prelude/text"
@.d38 = private constant [6 x i8] c"String"
declare bfloat @__olang_int_bf16(i64, i1)
declare double @llvm.arithmetic.fence.f64(double)
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %t1)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@olang_loc_335172168044531c_a265ad00fca232a0 = external constant [0 x i8]
@olang_loc_b70a8dfc847e84e9_67f505336baa0acd = external constant [0 x i8]
@olang_loc_877bc023f9996aa_af9d54b66b552ace = external constant [0 x i8]
@olang_loc_39cc6def4be103fb_5346127ded5ad1ff = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyErrors(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewritable(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aroFn_3e_2ePush_3ccompiler_2fcheck_3aroFn_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:roFn" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_76c98d42818871e4_51853c380fcafc70 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_5b6dfd884f12314a_d55d816e86cc2196 = external constant [0 x i8]
@olang_loc_fdeda218c1a4d1e1_676c59a9a8adaaad = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwrapNull(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eBangNothingFails(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eTrun_H62a150000c9aaeb3d030aed80f9d3e2e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_77940e7aab679ede_bd13144cbc386012 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_37018c2ebf0da22a_371c8892c4c63a5e = external constant [0 x i8]
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
@olang_loc_f6343df54e321530_17a07bfc25de31ec = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eOwning = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroTrack(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare { i32, { %"compiler/cond:Value", i1 } } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eValueOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ewrittenMut(ptr %v0, ptr %a0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eDefined(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espread(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroArgFor(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i64 %a2, ptr %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eSpreadCount(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eTru_H381e973120335535f017a290d5069d76(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTupleNotAValue(ptr %v0)
@olang_loc_7b3c05f45f3d8f68_d7530d71c92369a4 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdChoosesPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echosenAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondLentWritable(ptr %v0)
@olang_loc_460d09842f9fec87_8a34dc35fdcd1373 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eargSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, %"compiler/source:Span" %a4)
@olang_loc_1a2fe83b02404856_98942d3dbe0d9432 = external constant [0 x i8]
@olang_loc_5243f41784a5b43d_9dc8734848aaa559 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeErrors(ptr %v0, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMembershipNeedsTry(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOperatorCallFails(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eUnhandledFallibleCall(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleak(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResultFrom(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eOwnScope = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eToAr_H9d0f958437b2bc29fe1d416dfb9901d7(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eTuple(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCheckCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4, i1 %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, { i64, ptr } %a6, i32 %a7, i64 %a8)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceArgs(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalDecl(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H66d61cdd994b442644a8ee2ce6a8bf73(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i32 %a2)
@olang_loc_27b76e5e144937_92b9984f1a7672bb = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGlobalStorage(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferred(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefineValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
@G_2ecompiler_2fcheck_2eRoGlobal = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ezero(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2easkValue(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4)
@olang_loc_6495b6dfee4ecee2_6e1c2cfd4a22a64e = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
@olang_loc_8d548c3c72e36863_6a32d0416bf96aff = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earithCheck(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadsConst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFoldKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_He56f4e53267726fe8dffcfd34146d8e6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/source:Span" %a2)
@olang_loc_8ffd1bc2c5314d3c_1a7e454980bc5230 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_6754b7d1e64b38ab_d9cb88888f730d0f = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4d78ccd557b2cb07_4b61304073c9a48b = external constant [0 x i8]
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eShareOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@G_2ecompiler_2ftypes_2eRoleFn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopes(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/generic:Context" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eCtReq = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtEns = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eCtEntry = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_82a7c94587506de8_24388316e0066d9c = external constant [0 x i8]
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteNullableDecl(ptr %v0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamed(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fnames_3aTable_26_3_H69143a7a0e1afc2e54b5dfb8bd89d2f6(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fnames_3aEntry_3e_2eRunFrom_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_de9000bcffb5dadf_73d3889d184bf993 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyDeclaresNames(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_cd06913e2f5eb0d4_3977f9e98d534b08 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_40b85daad0e541e3_3cdd9f152c967927 = external constant [0 x i8]
@olang_loc_17f9884e4c50a862_1761fccd5f6f3c76 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorDefault(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnContext(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_573d6efe4eadca3f_fa49b5af8bd78213 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edefaultReads(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_986dcc23e228494c_5356e2d9a8a4da00 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKeep(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordAsValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoCase(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecasePublic(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCaseSig(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eOpShapes = external constant <{ [8 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [24 x i8], ptr, [16 x i8] }>
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einfersErrs(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMethodCannotFail(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_feae5f9a3edd32a2_1e841cd8c4e091f6 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToLower(i8 %a0)
@olang_loc_1b34257fee27c01f_cee7281d74ae4253 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedWithoutPlain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnErrors(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCheckedNotSuperset(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare %"compiler/check:b5aWalk" @compiler_2fcheck_3ab5aWalk_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i64 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_H0e73c22773457b60eb954c2c4a2643e9(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_e824f9a9b7a4d826_1573df97ffd6af2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_e57695a485c1fbbb_594346b6b5819ee7 = external constant [0 x i8]
@olang_loc_23ae6d164f19c0d8_5e726559a7bbcc04 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_96656321f78b9245_710c9f1a5efb4d11 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinWithoutSpawn(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_55f84e4449673261_62da473350726dd5 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCatchNeedsTry(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinCannotFail(ptr %v0)
@olang_loc_a0600b9a17fc9cd0_1e19997b248853e4 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclause(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eP_Hee51906bde9346e7b7b6808fdce5ba81(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eL_H39694dc3b7c161b4999ab170e8f3fd84(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eA_H5c1658fda327bafea70286240d031c3b(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_3aadc4e023da3b64_af78beb3670ebce8 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eleavesValue(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinClauseMustLeave(ptr %v0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaught(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, ptr %a3)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eescapes(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3, i1 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinNotTried(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aClause_26_3e_2eT_H39fa81f2ad510245a68cbacb663c8d87(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/typed:Join" @compiler_2ftyped_3aJoin_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoreturnSpan(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoreturnHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaArity(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2, i64 %a3)
@olang_loc_d264b31a2a0953e1_a8a3a5518784125d = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_9765c214aae0d14_3e0d6126973403f8 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayParamByValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaSignature(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLambdaParamUntyped(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5a62442bf09cb677_66ce856a58ef9453 = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eDefaultErrT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eletOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecanonicalErrs(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eMissingReturn(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v1, ptr %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSigNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNamesIdOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eWithNames(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextLit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @compiler_2fcheck_2ebadSeparator(ptr %v0, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIntLiteralTooLarge(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eFloatLiteralRange(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeetsBound(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
@G_2ecompiler_2fcheck_2eliteralOrder = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eA(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eB(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasResultScope(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnScopeNone(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistMentions(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
@olang_loc_70239da7d97117f8_be3796eb66d568d4 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecapParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_397a47855f80e417_31e96358085bf9e3 = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Hc07a7e56a24d8f1225398db99ea19a4b(ptr %v0, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eSetAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1, %"compiler/typed:Local" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAltBindingType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/typed:Bind" @compiler_2ftyped_3aBind_2ector(ptr %v0, ptr %v1, i32 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aBind_26_3e_2ePus_H9902a4d50743896fa3c9f4890ae04f69(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTag(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisCase(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2ePatternType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2eToArray_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/typed:Payload" @compiler_2ftyped_3aPayload_2ector(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eand2(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprPattern(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2, i32 %a3, ptr %a4, i64 %a5, i1 %a6)
@olang_loc_2bba12d772c132ef_de888473626934f3 = external constant [0 x i8]
declare void @compiler_2fcheck_2enamesIn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eRun_H660dd195b8dfbe46b01e30313ba3abe1(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_de7ddc22b2de2288_ecbab7ee09a112dc = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2erefWrittenTop(ptr %v0, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInTest(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInCtor(ptr %v0)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnInNoreturn(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseReturns(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgReturns(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferReturns(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einferReturn(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnNeedsValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReturnValueInVoid(ptr %v0)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresultAt(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eRoReturned = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInferThroughBounds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emeets(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etyOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaseValueType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorWords(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ebreaks(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_eb3e4e8f3f96f0ec_5bc3fc9686c42b70 = external constant [0 x i8]
@olang_loc_51cc068c3aeae8b4_3b6d62df8d15b2a8 = external constant [0 x i8]
@olang_loc_a6ce77febe1defe5_34385e948c177179 = external constant [0 x i8]
@olang_loc_a1143936e424f416_6a846c9af99dae82 = external constant [0 x i8]
@olang_loc_b0c5dfd122db8337_2ed6598a574b6003 = external constant [0 x i8]
declare %"compiler/check:litv" @compiler_2fcheck_3alitv_2ector(ptr %v0, i1 %a0, i1 %a1, i1 %a2, i64 %a3, double %a4)
declare %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0)
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclausesAssign(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ematchAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_3f7a94628940c729_cdb98f41ead125dd = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_b4de3dcccf9032b4_264e366d03c66670 = external constant [0 x i8]
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredStmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3_H96b7de74ba8f33ba996281c879dd113a(ptr %v0, ptr %a0, i32 %a1, i1 %a2)
@olang_loc_8df4ab6431d52630_31943992274c649c = external constant [0 x i8]
@olang_loc_c67c2282dc8bf9dd_b54d55782b869669 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20I64_3e_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20Bool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anullNarrow_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
