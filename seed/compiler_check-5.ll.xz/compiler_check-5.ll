; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, { i64, [3 x i64] }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/source:Span", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/types:Table" = type { ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1 }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, ptr, ptr, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Bind" = type { i32, ptr }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, { i64, [2 x i64] }, i32, i1 }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i32, i64, i64, i64, i1, i64, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:errBind" = type { i32, i64, i32, %"compiler/source:Span" }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr }, ptr }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnyTable" = type { i32, i32, i32, i64, %"compiler/source:Span", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1 }
%"compiler/typed:ContractInfo" = type { { i64, ptr }, i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:ContractBlock" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1 }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr } }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1 }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [2 x i64] } }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/check:reflVal" = type { i1, i64, i64, { i64, ptr }, i32 }
%"compiler/generic:Desc" = type { i64, i32, i64, i64 }
%"std/pair:Pair.1eb2466213689e002f25e81e83536e78" = type { i64, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/check:EmbedAsk" = type { i64, i64, i32 }
%"compiler/check:atRec" = type { i64, i64, ptr, i32 }
%"compiler/check:roFn" = type { i64, i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
define dso_local void @compiler_2fcheck_2eLaneCmp_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 4, ptr @G_2ecompiler_2fcheck_2eLaneCmp, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eLaneSel_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 5, ptr @G_2ecompiler_2fcheck_2eLaneSel, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2eLaneUn_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 3, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2eassignsWhole(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l5, !tbaa !29
  store i1 false, ptr %l6, !tbaa !21
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 3
  store i1 %t8, ptr %l6, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t24, i32 0, i32 3
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb14
bb5:
  %t28 = load i32, ptr %l2
  %t30 = trunc i64 60 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb6, label %bb7
bb6:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = call i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %t33, { i64, ptr } %t34)
  store i1 %t37, ptr %l20
  br label %bb8
bb7:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb9
bb8:
  %t38 = load i1, ptr %l20, !tbaa !21
  store i1 %t38, ptr %l17, !tbaa !21
  br label %bb9
bb9:
  %t39 = load i1, ptr %l17, !tbaa !21
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t40 = load ptr, ptr %l4, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t45 = call i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %t40, { i64, ptr } %t42)
  store i1 %t45, ptr %l25
  br label %bb12
bb11:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb13
bb12:
  %t46 = load i1, ptr %l25, !tbaa !21
  %t47 = xor i1 %t46, true
  store i1 %t47, ptr %l21, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l21, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb14:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedAll(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l12 = alloca { i64, ptr }
  %l16 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  %t16 = load i64, ptr %l2, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  %t25 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t21)
  store i1 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l2, !tbaa !24
  br label %bb1
bb10:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l26 = alloca i1
  %l27 = alloca ptr
  %l28 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca i1
  %l48 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l56 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  store i1 false, ptr %l8, !tbaa !21
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l8, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l8, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb50
bb6:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t11 = load ptr, ptr %l11, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb7, label %bb8
bb7:
  %t14 = load ptr, ptr %l11, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 2
  store i1 %t17, ptr %l12, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l12, !tbaa !21
  br i1 %t18, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t21, i32 0, i32 2
  %t23 = load ptr, ptr %t22
  store ptr %t23, ptr %l1, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l18
  br label %bb12
bb12:
  %t28 = load i1, ptr %l18, !tbaa !21
  store i1 %t28, ptr %l6, !tbaa !21
  br label %bb50
bb13:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb14, label %bb15
bb14:
  %t33 = load ptr, ptr %l19, !tbaa !29
  %t34 = load i64, ptr %t33
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t37 = load i1, ptr %l20, !tbaa !21
  br i1 %t37, label %bb16, label %bb17
bb16:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t40, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  store ptr %t42, ptr %l2, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t44 = load ptr, ptr %l2, !tbaa !29
  %t46 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t44)
  store i1 %t46, ptr %l26
  br label %bb19
bb19:
  %t47 = load i1, ptr %l26, !tbaa !21
  store i1 %t47, ptr %l6, !tbaa !21
  br label %bb50
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l27, !tbaa !29
  store i1 false, ptr %l28, !tbaa !21
  %t49 = load ptr, ptr %l27, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb21, label %bb22
bb21:
  %t52 = load ptr, ptr %l27, !tbaa !29
  %t53 = load i64, ptr %t52
  %t55 = icmp eq i64 %t53, 4
  store i1 %t55, ptr %l28, !tbaa !21
  br label %bb22
bb22:
  %t56 = load i1, ptr %l28, !tbaa !21
  br i1 %t56, label %bb23, label %bb24
bb23:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t59, i32 0, i32 2
  %t61 = load ptr, ptr %t60
  store ptr %t61, ptr %l3, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t65 = getelementptr %"compiler/typed:Elem", ptr %t63, i32 0, i32 0
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t66)
  store i1 %t68, ptr %l35
  br label %bb26
bb26:
  %t69 = load i1, ptr %l35, !tbaa !21
  br i1 %t69, label %bb27, label %bb28
bb27:
  %t70 = load ptr, ptr %l3, !tbaa !29
  %t72 = getelementptr %"compiler/typed:Elem", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t73)
  store i1 %t75, ptr %l39
  br label %bb29
bb28:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb30
bb29:
  %t76 = load i1, ptr %l39, !tbaa !21
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb30
bb30:
  %t77 = load i1, ptr %l36, !tbaa !21
  store i1 %t77, ptr %l6, !tbaa !21
  br label %bb50
bb31:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t79 = load ptr, ptr %l40, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb32, label %bb33
bb32:
  %t82 = load ptr, ptr %l40, !tbaa !29
  %t83 = load i64, ptr %t82
  %t85 = icmp eq i64 %t83, 5
  store i1 %t85, ptr %l41, !tbaa !21
  br label %bb33
bb33:
  %t86 = load i1, ptr %l41, !tbaa !21
  br i1 %t86, label %bb34, label %bb35
bb34:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb36
bb35:
  br label %bb38
bb36:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Payload", ptr %t93, i32 0, i32 0
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = call i1 @compiler_2fcheck_2eclosedPlace(ptr %v0, ptr %t96)
  store i1 %t98, ptr %l48
  br label %bb37
bb37:
  %t99 = load i1, ptr %l48, !tbaa !21
  store i1 %t99, ptr %l6, !tbaa !21
  br label %bb50
bb38:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t101 = load ptr, ptr %l49, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb39, label %bb40
bb39:
  %t104 = load ptr, ptr %l49, !tbaa !29
  %t105 = load i64, ptr %t104
  %t107 = icmp eq i64 %t105, 6
  store i1 %t107, ptr %l50, !tbaa !21
  br label %bb40
bb40:
  %t108 = load i1, ptr %l50, !tbaa !21
  br i1 %t108, label %bb41, label %bb42
bb41:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t111, i32 0, i32 2
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l5, !tbaa !29
  br label %bb43
bb42:
  br label %bb45
bb43:
  %t115 = load ptr, ptr %l5, !tbaa !29
  %t117 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t115)
  store i1 %t117, ptr %l56
  br label %bb44
bb44:
  %t118 = load i1, ptr %l56, !tbaa !21
  store i1 %t118, ptr %l6, !tbaa !21
  br label %bb50
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8)
  unreachable
bb50:
  %t119 = load i1, ptr %l6, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca { i64, ptr }
  %l14 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store ptr %a0, ptr %l4, !tbaa !29
  store i64 %a1, ptr %l5, !tbaa !24
  %t3 = icmp sge i64 0, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sle i64 0, 2305843009213693951
  br i1 %t5, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb3:
  %t7 = mul i64 0, 4
  %t8 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 0, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l8, !tbaa !27
  %t11 = icmp sge i64 0, 0
  br i1 %t11, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb5:
  %t13 = icmp sle i64 0, 2305843009213693951
  br i1 %t13, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb7:
  %t15 = mul i64 0, 4
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 0, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %s0, ptr %s0, ptr %v1, ptr %t21, i64 %t22, i64 -1, { i64, ptr } %t23, { i64, ptr } %t18, ptr %a2, i32 %a3)
  store i64 %t27, ptr %l14
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_a6ae1e9a693d05c9_888d1f7981f90365)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i64, ptr %l14, !tbaa !24
  store i64 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eGlobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCaseType(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i32
  %l11 = alloca i32
  %l16 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l24 = alloca { i64, ptr }
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca i64
  %l33 = alloca i32
  %l37 = alloca i1
  %l39 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l49 = alloca %"compiler/msgs:Msg"
  %l50 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca i1
  %l67 = alloca ptr
  %l71 = alloca i32
  %l72 = alloca i32
  %l81 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca %"compiler/source:Span"
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/msgs:Msg"
  %l95 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load i32, ptr %l11, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l16
  br label %bb2
bb2:
  %t17 = load i32, ptr %l16
  %t19 = trunc i64 29 to i32
  %t20 = icmp eq i32 %t17, %t19
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l20, !tbaa !29
  %t25 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t25, ptr %l21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load i32, ptr %l2, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t26, i32 %t27)
  store { i64, ptr } %t30, ptr %l24
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t31 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  %t39 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseNotAny(ptr %s1, ptr %s1, { i64, ptr } %t37)
  store %"compiler/msgs:Msg" %t39, ptr %l26
  br label %bb6
bb6:
  %t40 = load ptr, ptr %l20, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l21
  %t42 = load %"compiler/msgs:Msg", ptr %l26
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t40, %"compiler/source:Span" %t41, %"compiler/msgs:Msg" %t42)
  store i64 %t43, ptr %l27
  br label %bb7
bb7:
  %t44 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  store i32 %t44, ptr %rv
  br label %ret
bb8:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  %t52 = load i32, ptr %l4, !tbaa !23
  %t55 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %t51, i32 %t52)
  store i32 %t55, ptr %l33
  br label %bb9
bb9:
  %t56 = load i32, ptr %l33, !tbaa !23
  store i32 %t56, ptr %l5, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i32, ptr %l5, !tbaa !23
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %t60, i32 %t61)
  store i1 %t64, ptr %l37
  br label %bb10
bb10:
  %t65 = load i1, ptr %l37, !tbaa !21
  %t66 = xor i1 %t65, true
  br i1 %t66, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l39, !tbaa !29
  %t69 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t69, ptr %l40
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load i32, ptr %l2, !tbaa !23
  %t74 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t70, i32 %t71)
  store { i64, ptr } %t74, ptr %l43
  br label %bb13
bb12:
  br label %bb17
bb13:
  %t75 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l44, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load i32, ptr %l5, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t82, i32 %t83)
  store { i64, ptr } %t86, ptr %l47
  br label %bb14
bb14:
  %t87 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  %t94 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t96 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyOpenInspected(ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t94, { i64, ptr } %t93)
  store %"compiler/msgs:Msg" %t96, ptr %l49
  br label %bb15
bb15:
  %t97 = load ptr, ptr %l39, !tbaa !29
  %t98 = load %"compiler/source:Span", ptr %l40
  %t99 = load %"compiler/msgs:Msg", ptr %l49
  %t100 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t97, %"compiler/source:Span" %t98, %"compiler/msgs:Msg" %t99)
  store i64 %t100, ptr %l50
  br label %bb16
bb16:
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t101, ptr %rv
  br label %ret
bb17:
  %t103 = load ptr, ptr %l3, !tbaa !29
  store ptr %t103, ptr %l6, !tbaa !29
  %t105 = load ptr, ptr %l3, !tbaa !29
  store ptr %t105, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t106 = load ptr, ptr %l53, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb18, label %bb19
bb18:
  %t109 = load ptr, ptr %l53, !tbaa !29
  %t110 = load i64, ptr %t109
  %t112 = icmp eq i64 %t110, 3
  store i1 %t112, ptr %l54, !tbaa !21
  br label %bb19
bb19:
  %t113 = load i1, ptr %l54, !tbaa !21
  br i1 %t113, label %bb20, label %bb21
bb20:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t116, i32 0, i32 1
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t120 = load ptr, ptr %l7, !tbaa !29
  store ptr %t120, ptr %l6, !tbaa !29
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load ptr, ptr %l6, !tbaa !29
  %t126 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %t122, ptr %t123, i1 true)
  store i1 %t126, ptr %l62
  br label %bb25
bb25:
  %t127 = load i1, ptr %l62, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb26, label %bb27
bb26:
  %t130 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t130, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  store ptr %t137, ptr %l67, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t139 = load ptr, ptr %l6, !tbaa !29
  %t143 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t138, ptr %t139)
  store i32 %t143, ptr %l71
  br label %bb29
bb29:
  %t144 = load ptr, ptr %l67, !tbaa !29
  %t145 = load i32, ptr %l71, !tbaa !23
  %t146 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t146, ptr %l72
  br label %bb30
bb30:
  %t147 = load i32, ptr %l72, !tbaa !23
  store i32 %t147, ptr %l8, !tbaa !23
  %t148 = load i32, ptr %l8, !tbaa !23
  %t149 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t152 = icmp eq i32 %t148, %t149
  br i1 %t152, label %bb31, label %bb32
bb31:
  %t154 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t154, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i32, ptr %l8, !tbaa !23
  %t161 = load i32, ptr %l5, !tbaa !23
  %t165 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %t159, i32 %t160, i32 %t161)
  store i1 %t165, ptr %l81
  br label %bb34
bb34:
  %t166 = load i1, ptr %l81, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l83, !tbaa !29
  %t170 = load ptr, ptr %l3, !tbaa !29
  %t172 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t170)
  store %"compiler/source:Span" %t172, ptr %l85
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i32, ptr %l8, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t173, i32 %t174)
  store { i64, ptr } %t177, ptr %l88
  br label %bb38
bb38:
  %t178 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l89, !tbaa !27
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t186 = load i32, ptr %l5, !tbaa !23
  %t189 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t185, i32 %t186)
  store { i64, ptr } %t189, ptr %l92
  br label %bb39
bb39:
  %t190 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t197 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t199 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMemberCase(ptr %s7, ptr %s7, ptr %s7, { i64, ptr } %t197, { i64, ptr } %t196)
  store %"compiler/msgs:Msg" %t199, ptr %l94
  br label %bb40
bb40:
  %t200 = load ptr, ptr %l83, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l85
  %t202 = load %"compiler/msgs:Msg", ptr %l94
  %t203 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t200, %"compiler/source:Span" %t201, %"compiler/msgs:Msg" %t202)
  store i64 %t203, ptr %l95
  br label %bb41
bb41:
  %t204 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  store i32 %t204, ptr %rv
  br label %ret
bb42:
  %t206 = load i32, ptr %l8, !tbaa !23
  store i32 %t206, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayLit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %lp4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l34 = alloca i1
  %l35 = alloca i1
  %l40 = alloca i64
  %l43 = alloca ptr
  %l53 = alloca i64
  %l56 = alloca i64
  %l74 = alloca i64
  %l76 = alloca { i64, ptr }
  %l81 = alloca ptr
  %l82 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca i32
  %l91 = alloca i32
  %l96 = alloca ptr
  %l100 = alloca i64
  %l103 = alloca i1
  %l107 = alloca i1
  %l110 = alloca ptr
  %l113 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca i32
  %l120 = alloca ptr
  %l122 = alloca i32
  %l124 = alloca i32
  %l125 = alloca i32
  %l130 = alloca i32
  %l133 = alloca i1
  %l136 = alloca ptr
  %l141 = alloca i32
  %l142 = alloca i32
  %l145 = alloca i1
  %l150 = alloca i1
  %l160 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l170 = alloca { i64, ptr }
  %l172 = alloca %"compiler/msgs:Msg"
  %l173 = alloca i64
  %l176 = alloca ptr
  %l179 = alloca i64
  %l185 = alloca i64
  %l188 = alloca i64
  %l206 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca i32
  %l210 = alloca { i64, ptr }
  %l213 = alloca %"compiler/source:Span"
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l221 = alloca %"compiler/source:Span"
  %l223 = alloca i1
  %l229 = alloca %"compiler/source:Span"
  %l232 = alloca ptr
  %l233 = alloca i32
  %l236 = alloca ptr
  %l238 = alloca i32
  %l241 = alloca i32
  %l242 = alloca i32
  %l243 = alloca i32
  %l247 = alloca { i64, ptr }
  %l251 = alloca i32
  %l253 = alloca %"compiler/typed:Make"
  %l259 = alloca i64
  %l267 = alloca { i64, ptr }
  %l273 = alloca ptr
  %l276 = alloca i1
  %l278 = alloca ptr
  %l280 = alloca ptr
  %l282 = alloca %"compiler/source:Span"
  %l284 = alloca i1
  %l295 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l299 = alloca i32
  %l302 = alloca ptr
  %l304 = alloca i32
  %l306 = alloca i32
  %l307 = alloca i32
  %l308 = alloca %"compiler/source:Span"
  %l309 = alloca i32
  %l310 = alloca i32
  %l311 = alloca { i64, ptr }
  %l315 = alloca i32
  %l317 = alloca %"compiler/typed:Make"
  %s3 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca ptr
  %t32 = alloca i64
  %t483 = alloca { i64, [5 x i64] }, align 8
  %t616 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l34
  br label %bb1
bb1:
  %t6 = load i1, ptr %l34, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp sgt i64 %t9, 0
  store i1 %t11, ptr %l35, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l35, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l40, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load %"compiler/source:Span", ptr %l1
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t17, %"compiler/source:Span" %t18)
  store ptr %t21, ptr %l43
  br label %bb7
bb6:
  br label %bb96
bb7:
  %t22 = load i64, ptr %l40, !tbaa !24
  %t23 = icmp sge i64 %t22, 0
  br i1 %t23, label %bb8, label %bb9
bb8:
  %t25 = load i64, ptr %l40, !tbaa !24
  %t26 = icmp sle i64 %t25, 1152921504606846975
  br i1 %t26, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_88d3ea04e82c2d9e_ee1d738344e93712)
  unreachable
bb10:
  %t28 = load i64, ptr %l40, !tbaa !24
  %t29 = mul i64 %t28, 8
  %t30 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t29)
  %t31 = load ptr, ptr %l43, !tbaa !29
  store i64 0, ptr %t32
  br label %fill.33
fill.33:
  %t36 = load i64, ptr %t32
  %t37 = icmp slt i64 %t36, %t28
  br i1 %t37, label %fillb.34, label %filld.35
fillb.34:
  %t38 = getelementptr ptr, ptr %t30, i64 %t36
  store ptr %t31, ptr %t38
  %t39 = add i64 %t36, 1
  store i64 %t39, ptr %t32
  br label %fill.33
filld.35:
  %t40 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t30, 1
  %t42 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t42, ptr %lp4
  %t44 = load ptr, ptr %lp4
  store { i64, ptr } %t41, ptr %t44, !tbaa !27
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t45, ptr %l5, !tbaa !23
  store i1 true, ptr %l6, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp sgt i64 %t51, %t52
  br i1 %t55, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_88d3ea04e82c2d9e_ee1d738344e93712)
  unreachable
bb12:
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = icmp sgt i64 %t57, 0
  br i1 %t59, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l53, !tbaa !24
  br label %bb17
bb14:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t65 = sub i64 %t61, %t62
  %t66 = load i64, ptr %l9, !tbaa !24
  %t69 = add i64 %t65, %t66
  %t71 = sub i64 %t69, 1
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = sdiv i64 %t71, %t72
  store i64 %t75, ptr %l56, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb16
bb16:
  %t77 = load i64, ptr %l56, !tbaa !24
  store i64 %t77, ptr %l53, !tbaa !24
  br label %bb17
bb17:
  %t78 = load i64, ptr %l53, !tbaa !24
  store i64 %t78, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s3
  %t79 = load i64, ptr %l11, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb64
bb20:
  br label %bb21
bb21:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t88 = load i64, ptr %l11, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t92 = mul i64 %t88, %t89
  %t95 = add i64 %t87, %t92
  store i64 %t95, ptr %l12, !tbaa !24
  %t97 = load i64, ptr %l12, !tbaa !24
  store i64 %t97, ptr %l74, !tbaa !24
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t99, ptr %l76, !tbaa !27
  %t100 = load i64, ptr %l12, !tbaa !24
  %t102 = getelementptr { i64, ptr }, ptr %l76, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr ptr, ptr %t103, i64 %t100
  %t105 = load ptr, ptr %t104, !tbaa !39
  %t107 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t98, ptr %t105, i32 %t107)
  store ptr %t111, ptr %l81
  br label %bb22
bb22:
  %t112 = load ptr, ptr %l81, !tbaa !29
  %t113 = load ptr, ptr %lp4
  %t114 = load i64, ptr %l74, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr ptr, ptr %t116, i64 %t114
  store ptr %t112, ptr %t117, !tbaa !39
  %t118 = load ptr, ptr %l0, !tbaa !29
  store ptr %t118, ptr %l82, !tbaa !29
  %t119 = load i64, ptr %l12, !tbaa !24
  %t120 = load ptr, ptr %lp4
  %t122 = getelementptr { i64, ptr }, ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr ptr, ptr %t123, i64 %t119
  %t125 = load ptr, ptr %t124, !tbaa !39
  %t128 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t125)
  store i32 %t128, ptr %l86
  br label %bb23
bb23:
  %t129 = load ptr, ptr %l82, !tbaa !29
  %t130 = load i32, ptr %l86, !tbaa !23
  %t131 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t131, ptr %l87
  br label %bb24
bb24:
  %t132 = load i32, ptr %l87, !tbaa !23
  store i32 %t132, ptr %l13, !tbaa !23
  %t133 = load i64, ptr %l12, !tbaa !24
  %t134 = load ptr, ptr %lp4
  %t136 = getelementptr { i64, ptr }, ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr ptr, ptr %t137, i64 %t133
  %t139 = load ptr, ptr %t138, !tbaa !39
  %t142 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t139)
  store i32 %t142, ptr %l91
  br label %bb25
bb25:
  %t143 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = load i32, ptr %l91, !tbaa !23
  %t146 = icmp eq i32 %t144, %t143
  br i1 %t146, label %bb26, label %bb27
bb26:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l1
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t148, %"compiler/source:Span" %t149)
  store ptr %t152, ptr %l96
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s3)
  %t153 = load ptr, ptr %l96, !tbaa !29
  store ptr %t153, ptr %rv
  br label %ret
bb29:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l12, !tbaa !24
  %t156 = load ptr, ptr %lp4
  %t158 = getelementptr { i64, ptr }, ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr ptr, ptr %t159, i64 %t155
  %t161 = load ptr, ptr %t160, !tbaa !39
  %t164 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v0, ptr %t154, ptr %t161)
  store i64 %t164, ptr %l100
  br label %bb30
bb30:
  %t165 = load i64, ptr %l100, !tbaa !24
  store i64 %t165, ptr %l14, !tbaa !24
  %t166 = load i64, ptr %l14, !tbaa !24
  %t168 = icmp sge i64 %t166, 0
  br i1 %t168, label %bb31, label %bb32
bb31:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l13, !tbaa !23
  %t172 = load i32, ptr %l2, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t170, i32 %t171, i32 %t172)
  store i1 %t176, ptr %l107
  br label %bb33
bb32:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb34
bb33:
  %t177 = load i1, ptr %l107, !tbaa !21
  store i1 %t177, ptr %l103, !tbaa !21
  br label %bb34
bb34:
  %t178 = load i1, ptr %l103, !tbaa !21
  br i1 %t178, label %bb35, label %bb36
bb35:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  store ptr %t184, ptr %l110, !tbaa !29
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  store ptr %t190, ptr %l113, !tbaa !29
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load i32, ptr %l2, !tbaa !23
  %t195 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t191, i32 %t192)
  store i32 %t195, ptr %l116
  br label %bb37
bb36:
  br label %bb42
bb37:
  %t196 = load ptr, ptr %l113, !tbaa !29
  %t197 = load i32, ptr %l116, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t196, i32 %t197)
  store i32 %t198, ptr %l117
  br label %bb38
bb38:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  store ptr %t204, ptr %l120, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t205)
  store i32 %t207, ptr %l122
  br label %bb39
bb39:
  %t208 = load i64, ptr %l14, !tbaa !24
  %t209 = load ptr, ptr %l120, !tbaa !29
  %t210 = load i32, ptr %l122, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t209, i32 %t210, i64 %t208)
  store i32 %t212, ptr %l124
  br label %bb40
bb40:
  %t213 = load ptr, ptr %l110, !tbaa !29
  %t214 = load i32, ptr %l117, !tbaa !23
  %t215 = load i32, ptr %l124, !tbaa !23
  %t216 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t213, i32 %t214, i32 %t215)
  store i32 %t216, ptr %l125
  br label %bb41
bb41:
  %t217 = load i32, ptr %l125, !tbaa !23
  store i32 %t217, ptr %l13, !tbaa !23
  br label %bb42
bb42:
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = getelementptr %"compiler/check:Checker", ptr %t218, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !29
  %t223 = getelementptr %"compiler/generic:Program", ptr %t221, i32 0, i32 2
  %t224 = load i32, ptr %l13, !tbaa !23
  %t227 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t223, i32 %t224)
  store i32 %t227, ptr %l130
  br label %bb43
bb43:
  %t228 = load i32, ptr %l130
  %t230 = trunc i64 19 to i32
  %t231 = icmp eq i32 %t228, %t230
  br i1 %t231, label %bb44, label %bb45
bb44:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/check:Checker", ptr %t233, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !29
  %t238 = getelementptr %"compiler/generic:Program", ptr %t236, i32 0, i32 2
  store ptr %t238, ptr %l136, !tbaa !29
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/check:Checker", ptr %t239, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/generic:Program", ptr %t242, i32 0, i32 2
  %t245 = load i32, ptr %l13, !tbaa !23
  %t248 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t244, i32 %t245)
  store i32 %t248, ptr %l141
  br label %bb46
bb45:
  store i1 false, ptr %l133, !tbaa !21
  br label %bb48
bb46:
  %t249 = load ptr, ptr %l136, !tbaa !29
  %t250 = load i32, ptr %l141, !tbaa !23
  %t251 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t249, i32 %t250)
  store i32 %t251, ptr %l142
  br label %bb47
bb47:
  %t252 = load i32, ptr %l142
  %t254 = trunc i64 26 to i32
  %t255 = icmp eq i32 %t252, %t254
  store i1 %t255, ptr %l133, !tbaa !21
  br label %bb48
bb48:
  %t257 = load i1, ptr %l133, !tbaa !21
  br i1 %t257, label %bb49, label %bb50
bb49:
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t260 = getelementptr %"compiler/check:Checker", ptr %t258, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !29
  %t262 = load i32, ptr %l13, !tbaa !23
  %t263 = load i32, ptr %l2, !tbaa !23
  %t267 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %t261, i32 %t262, i32 %t263)
  store i1 %t267, ptr %l150
  br label %bb51
bb50:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb52
bb51:
  %t268 = load i1, ptr %l150, !tbaa !21
  store i1 %t268, ptr %l145, !tbaa !21
  br label %bb52
bb52:
  %t269 = load i1, ptr %l145, !tbaa !21
  br i1 %t269, label %bb53, label %bb54
bb53:
  %t270 = load i32, ptr %l5, !tbaa !23
  %t271 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t274 = icmp eq i32 %t270, %t271
  br i1 %t274, label %bb55, label %bb56
bb54:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb62
bb55:
  %t276 = load i32, ptr %l13, !tbaa !23
  store i32 %t276, ptr %l5, !tbaa !23
  br label %bb61
bb56:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/generic:Program", ptr %t281, i32 0, i32 2
  %t284 = load i32, ptr %l5, !tbaa !23
  %t285 = load i32, ptr %l13, !tbaa !23
  %t289 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t283, i32 %t284, i32 %t285)
  store i1 %t289, ptr %l160
  br label %bb57
bb57:
  %t290 = load i1, ptr %l160, !tbaa !21
  %t291 = xor i1 %t290, true
  br i1 %t291, label %bb58, label %bb59
bb58:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb60
bb59:
  br label %bb60
bb60:
  br label %bb61
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s3)
  br label %bb63
bb63:
  %t293 = load i64, ptr %l11, !tbaa !24
  %t295 = add i64 %t293, 1
  store i64 %t295, ptr %l11, !tbaa !24
  br label %bb18
bb64:
  %t297 = load i1, ptr %l6, !tbaa !21
  %t299 = xor i1 %t297, true
  br i1 %t299, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s12
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l166, !tbaa !29
  %t302 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t302, ptr %l167
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load i32, ptr %l2, !tbaa !23
  %t307 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t303, i32 %t304)
  store { i64, ptr } %t307, ptr %l170
  br label %bb67
bb66:
  br label %bb71
bb67:
  %t308 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  %t310 = extractvalue { i64, ptr } %t308, 1
  %t311 = mul i64 %t309, 1
  %t312 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t311)
  call void @llvm.memcpy.p0.p0.i64(ptr %t312, ptr %t310, i64 %t311, i1 false)
  %t313 = insertvalue { i64, ptr } undef, i64 %t309, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t312, 1
  %t316 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %s12, ptr %s12, { i64, ptr } %t314)
  store %"compiler/msgs:Msg" %t316, ptr %l172
  br label %bb68
bb68:
  %t317 = load ptr, ptr %l166, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l167
  %t319 = load %"compiler/msgs:Msg", ptr %l172
  %t320 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s12, ptr %t317, %"compiler/source:Span" %t318, %"compiler/msgs:Msg" %t319)
  store i64 %t320, ptr %l173
  br label %bb69
bb69:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t322 = load %"compiler/source:Span", ptr %l1
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t321, %"compiler/source:Span" %t322)
  store ptr %t325, ptr %l176
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s12)
  %t326 = load ptr, ptr %l176, !tbaa !29
  store ptr %t326, ptr %rv
  br label %ret
bb71:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = getelementptr %"compiler/check:Checker", ptr %t327, i32 0, i32 32
  %t331 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t329)
  store i64 %t331, ptr %l179
  br label %bb72
bb72:
  %t332 = load i64, ptr %l179, !tbaa !24
  store i64 %t332, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  %t333 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t333, 0
  store i64 %t335, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t337 = load i64, ptr %l17, !tbaa !24
  %t338 = load i64, ptr %l16, !tbaa !24
  %t341 = icmp sgt i64 %t337, %t338
  br i1 %t341, label %bb73, label %bb74
bb73:
  %t343 = load i64, ptr %l18, !tbaa !24
  %t345 = icmp sgt i64 %t343, 0
  br i1 %t345, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l185, !tbaa !24
  br label %bb78
bb75:
  %t347 = load i64, ptr %l17, !tbaa !24
  %t348 = load i64, ptr %l16, !tbaa !24
  %t351 = sub i64 %t347, %t348
  %t352 = load i64, ptr %l18, !tbaa !24
  %t355 = add i64 %t351, %t352
  %t357 = sub i64 %t355, 1
  %t358 = load i64, ptr %l18, !tbaa !24
  %t361 = sdiv i64 %t357, %t358
  store i64 %t361, ptr %l188, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l188, !tbaa !24
  br label %bb77
bb77:
  %t363 = load i64, ptr %l188, !tbaa !24
  store i64 %t363, ptr %l185, !tbaa !24
  br label %bb78
bb78:
  %t364 = load i64, ptr %l185, !tbaa !24
  store i64 %t364, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s14
  %t365 = load i64, ptr %l20, !tbaa !24
  %t366 = load i64, ptr %l19, !tbaa !24
  %t369 = icmp slt i64 %t365, %t366
  %t371 = xor i1 %t369, true
  br i1 %t371, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb81:
  br label %bb82
bb82:
  %t373 = load i64, ptr %l16, !tbaa !24
  %t374 = load i64, ptr %l20, !tbaa !24
  %t375 = load i64, ptr %l18, !tbaa !24
  %t378 = mul i64 %t374, %t375
  %t381 = add i64 %t373, %t378
  store i64 %t381, ptr %l21, !tbaa !24
  %t383 = load ptr, ptr %l0, !tbaa !29
  store ptr %t383, ptr %l206, !tbaa !29
  %t384 = load i64, ptr %l21, !tbaa !24
  %t385 = load ptr, ptr %lp4
  %t387 = getelementptr { i64, ptr }, ptr %t385, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr ptr, ptr %t388, i64 %t384
  %t390 = load ptr, ptr %t389, !tbaa !39
  store ptr %t390, ptr %l208, !tbaa !29
  %t391 = load i32, ptr %l5, !tbaa !23
  store i32 %t391, ptr %l209, !tbaa !23
  %t392 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t392, ptr %l210, !tbaa !27
  %t393 = load i64, ptr %l21, !tbaa !24
  %t395 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t396 = load ptr, ptr %t395, !tbaa !27
  %t397 = getelementptr ptr, ptr %t396, i64 %t393
  %t398 = load ptr, ptr %t397, !tbaa !39
  %t400 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t398)
  store %"compiler/source:Span" %t400, ptr %l213
  br label %bb83
bb83:
  %t401 = load ptr, ptr %l206, !tbaa !29
  %t402 = load ptr, ptr %l208, !tbaa !29
  %t403 = load i32, ptr %l209, !tbaa !23
  %t404 = load %"compiler/source:Span", ptr %l213
  %t405 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t401, ptr %t402, i32 %t403, %"compiler/source:Span" %t404)
  store ptr %t405, ptr %l214
  br label %bb84
bb84:
  %t406 = load ptr, ptr %l214, !tbaa !29
  store ptr %t406, ptr %l22, !tbaa !29
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l215, !tbaa !29
  %t408 = load ptr, ptr %l22, !tbaa !29
  store ptr %t408, ptr %l217, !tbaa !29
  %t410 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t410, ptr %l218, !tbaa !27
  %t411 = load i64, ptr %l21, !tbaa !24
  %t413 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !27
  %t415 = getelementptr ptr, ptr %t414, i64 %t411
  %t416 = load ptr, ptr %t415, !tbaa !39
  %t418 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t416)
  store %"compiler/source:Span" %t418, ptr %l221
  br label %bb85
bb85:
  %t419 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t420 = load ptr, ptr %l215, !tbaa !29
  %t421 = load ptr, ptr %l217, !tbaa !29
  %t422 = load %"compiler/source:Span", ptr %l221
  %t424 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t420, ptr %t421, %"compiler/source:Span" %t422, i64 %t419)
  store i1 %t424, ptr %l223
  br label %bb86
bb86:
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t427 = getelementptr %"compiler/check:Checker", ptr %t425, i32 0, i32 32
  %t428 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t427, ptr %t428)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s14)
  br label %bb88
bb88:
  %t431 = load i64, ptr %l20, !tbaa !24
  %t433 = add i64 %t431, 1
  store i64 %t433, ptr %l20, !tbaa !24
  br label %bb79
bb89:
  %t435 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t435, ptr %l229
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/check:Checker", ptr %t436, i32 0, i32 1
  %t439 = load ptr, ptr %t438, !tbaa !29
  %t441 = getelementptr %"compiler/generic:Program", ptr %t439, i32 0, i32 2
  store ptr %t441, ptr %l232, !tbaa !29
  %t442 = load i32, ptr %l5, !tbaa !23
  store i32 %t442, ptr %l233, !tbaa !23
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/generic:Program", ptr %t446, i32 0, i32 2
  store ptr %t448, ptr %l236, !tbaa !29
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t449)
  store i32 %t451, ptr %l238
  br label %bb90
bb90:
  %t452 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t452, 0
  %t455 = load ptr, ptr %l236, !tbaa !29
  %t456 = load i32, ptr %l238, !tbaa !23
  %t458 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t455, i32 %t456, i64 %t454)
  store i32 %t458, ptr %l241
  br label %bb91
bb91:
  %t459 = load ptr, ptr %l232, !tbaa !29
  %t460 = load i32, ptr %l233, !tbaa !23
  %t461 = load i32, ptr %l241, !tbaa !23
  %t462 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t459, i32 %t460, i32 %t461)
  store i32 %t462, ptr %l242
  br label %bb92
bb92:
  store i32 2, ptr %l243
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/check:Checker", ptr %t463, i32 0, i32 32
  %t466 = load i64, ptr %l15, !tbaa !24
  %t469 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t465, i64 %t466)
  store { i64, ptr } %t469, ptr %l247
  br label %bb93
bb93:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load %"compiler/source:Span", ptr %l1
  %t475 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t470, i32 1, %"compiler/source:Span" %t471)
  store i32 %t475, ptr %l251
  br label %bb94
bb94:
  %t476 = load i32, ptr %l243
  %t477 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t478 = load i32, ptr %l251, !tbaa !23
  %t480 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t476, i64 0, { i64, ptr } %t477, ptr null, i32 %t478, i32 0)
  store %"compiler/typed:Make" %t480, ptr %l253
  br label %bb95
bb95:
  %t481 = load %"compiler/typed:Make", ptr %l253
  %t482 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t481, ptr %t482
  store { i64, [5 x i64] } zeroinitializer, ptr %t483
  %t484 = getelementptr { i64, [5 x i64] }, ptr %t483, i32 0, i32 0
  store i64 7, ptr %t484
  %t485 = load %"compiler/source:Span", ptr %l229
  %t486 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t485, 0
  %t487 = load i32, ptr %l242, !tbaa !23
  %t488 = insertvalue { %"compiler/source:Span", i32, ptr } %t486, i32 %t487, 1
  %t490 = insertvalue { %"compiler/source:Span", i32, ptr } %t488, ptr %t482, 2
  %t491 = getelementptr { i64, [5 x i64] }, ptr %t483, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t490, ptr %t491
  %t492 = load { i64, [5 x i64] }, ptr %t483
  %t494 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t492, ptr %t494
  store ptr %t494, ptr %rv
  br label %ret
bb96:
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/check:Checker", ptr %t496, i32 0, i32 32
  %t500 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t498)
  store i64 %t500, ptr %l259
  br label %bb97
bb97:
  %t501 = load i64, ptr %l259, !tbaa !24
  store i64 %t501, ptr %l23, !tbaa !24
  %t502 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t502, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t504 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t504, 0
  store i64 %t506, ptr %l26, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s17
  %t508 = load i64, ptr %l25, !tbaa !24
  %t509 = load i64, ptr %l26, !tbaa !24
  %t512 = icmp slt i64 %t508, %t509
  %t514 = xor i1 %t512, true
  br i1 %t514, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb100:
  br label %bb101
bb101:
  %t516 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t516, ptr %l267, !tbaa !27
  %t517 = load i64, ptr %l25, !tbaa !24
  %t519 = getelementptr { i64, ptr }, ptr %l267, i32 0, i32 1
  %t520 = load ptr, ptr %t519, !tbaa !27
  %t521 = getelementptr ptr, ptr %t520, i64 %t517
  %t522 = load ptr, ptr %t521, !tbaa !39
  store ptr %t522, ptr %l27, !tbaa !29
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load ptr, ptr %l27, !tbaa !29
  %t526 = load i32, ptr %l2, !tbaa !23
  %t530 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t524, ptr %t525, i32 %t526)
  store ptr %t530, ptr %l273
  br label %bb102
bb102:
  %t531 = load ptr, ptr %l273, !tbaa !29
  store ptr %t531, ptr %l28, !tbaa !29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t533 = load i32, ptr %l2, !tbaa !23
  %t536 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t532, i32 %t533)
  store i1 %t536, ptr %l276
  br label %bb103
bb103:
  %t537 = load i1, ptr %l276, !tbaa !21
  %t538 = xor i1 %t537, true
  br i1 %t538, label %bb104, label %bb105
bb104:
  %t540 = load ptr, ptr %l0, !tbaa !29
  store ptr %t540, ptr %l278, !tbaa !29
  %t541 = load ptr, ptr %l28, !tbaa !29
  store ptr %t541, ptr %l280, !tbaa !29
  %t543 = load ptr, ptr %l27, !tbaa !29
  %t545 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t543)
  store %"compiler/source:Span" %t545, ptr %l282
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t546 = load i64, ptr @G_2ecompiler_2fcheck_2eRoStored, !tbaa !24
  %t547 = load ptr, ptr %l278, !tbaa !29
  %t548 = load ptr, ptr %l280, !tbaa !29
  %t549 = load %"compiler/source:Span", ptr %l282
  %t551 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v0, ptr %t547, ptr %t548, %"compiler/source:Span" %t549, i64 %t546)
  store i1 %t551, ptr %l284
  br label %bb107
bb107:
  br label %bb108
bb108:
  %t552 = load ptr, ptr %l0, !tbaa !29
  %t554 = getelementptr %"compiler/check:Checker", ptr %t552, i32 0, i32 32
  %t555 = load ptr, ptr %l28, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t554, ptr %t555)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s17)
  br label %bb110
bb110:
  %t558 = load i64, ptr %l25, !tbaa !24
  %t560 = add i64 %t558, 1
  store i64 %t560, ptr %l25, !tbaa !24
  br label %bb98
bb111:
  %t562 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t564 = extractvalue { i64, ptr } %t562, 0
  store i64 %t564, ptr %l29, !tbaa !24
  %t566 = load ptr, ptr %l0, !tbaa !29
  %t568 = getelementptr %"compiler/check:Checker", ptr %t566, i32 0, i32 32
  %t569 = load i64, ptr %l23, !tbaa !24
  %t572 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t568, i64 %t569)
  store { i64, ptr } %t572, ptr %l295
  br label %bb112
bb112:
  %t573 = load { i64, ptr }, ptr %l295, !tbaa !27
  store { i64, ptr } %t573, ptr %l30, !tbaa !27
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = getelementptr %"compiler/check:Checker", ptr %t574, i32 0, i32 1
  %t577 = load ptr, ptr %t576, !tbaa !29
  %t579 = getelementptr %"compiler/generic:Program", ptr %t577, i32 0, i32 2
  store ptr %t579, ptr %l298, !tbaa !29
  %t580 = load i32, ptr %l2, !tbaa !23
  store i32 %t580, ptr %l299, !tbaa !23
  %t581 = load ptr, ptr %l0, !tbaa !29
  %t583 = getelementptr %"compiler/check:Checker", ptr %t581, i32 0, i32 1
  %t584 = load ptr, ptr %t583, !tbaa !29
  %t586 = getelementptr %"compiler/generic:Program", ptr %t584, i32 0, i32 2
  store ptr %t586, ptr %l302, !tbaa !29
  %t587 = load ptr, ptr %l0, !tbaa !29
  %t589 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t587)
  store i32 %t589, ptr %l304
  br label %bb113
bb113:
  %t590 = load i64, ptr %l29, !tbaa !24
  %t591 = load ptr, ptr %l302, !tbaa !29
  %t592 = load i32, ptr %l304, !tbaa !23
  %t594 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %t591, i32 %t592, i64 %t590)
  store i32 %t594, ptr %l306
  br label %bb114
bb114:
  %t595 = load ptr, ptr %l298, !tbaa !29
  %t596 = load i32, ptr %l299, !tbaa !23
  %t597 = load i32, ptr %l306, !tbaa !23
  %t598 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t595, i32 %t596, i32 %t597)
  store i32 %t598, ptr %l307
  br label %bb115
bb115:
  %t599 = load i32, ptr %l307, !tbaa !23
  %t600 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t600, ptr %l308
  store i32 %t599, ptr %l309, !tbaa !23
  store i32 2, ptr %l310
  %t602 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t602, ptr %l311, !tbaa !27
  %t603 = load ptr, ptr %l0, !tbaa !29
  %t604 = load %"compiler/source:Span", ptr %l1
  %t608 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t603, i32 1, %"compiler/source:Span" %t604)
  store i32 %t608, ptr %l315
  br label %bb116
bb116:
  %t609 = load i32, ptr %l310
  %t610 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t611 = load i32, ptr %l315, !tbaa !23
  %t613 = call %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v0, ptr %v0, i32 %t609, i64 0, { i64, ptr } %t610, ptr null, i32 %t611, i32 0)
  store %"compiler/typed:Make" %t613, ptr %l317
  br label %bb117
bb117:
  %t614 = load %"compiler/typed:Make", ptr %l317
  %t615 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Make" %t614, ptr %t615
  store { i64, [5 x i64] } zeroinitializer, ptr %t616
  %t617 = getelementptr { i64, [5 x i64] }, ptr %t616, i32 0, i32 0
  store i64 7, ptr %t617
  %t618 = load %"compiler/source:Span", ptr %l308
  %t619 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t618, 0
  %t620 = load i32, ptr %l309, !tbaa !23
  %t621 = insertvalue { %"compiler/source:Span", i32, ptr } %t619, i32 %t620, 1
  %t623 = insertvalue { %"compiler/source:Span", i32, ptr } %t621, ptr %t615, 2
  %t624 = getelementptr { i64, [5 x i64] }, ptr %t616, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t623, ptr %t624
  %t625 = load { i64, [5 x i64] }, ptr %t616
  %t627 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t625, ptr %t627
  store ptr %t627, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eattempt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i64
  %l20 = alloca i64
  %l23 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l52 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i1
  %l70 = alloca ptr
  %l73 = alloca i1
  %l76 = alloca i1
  %l80 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i1
  %l97 = alloca ptr
  %l103 = alloca i1
  %l107 = alloca i64
  %l116 = alloca i32
  %l120 = alloca ptr
  %l124 = alloca i1
  %l128 = alloca ptr
  %l132 = alloca ptr
  %l136 = alloca i64
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca ptr
  %l150 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l155 = alloca %"compiler/msgs:Msg"
  %l156 = alloca i64
  %l161 = alloca ptr
  %l177 = alloca ptr
  %l179 = alloca i64
  %l180 = alloca i64
  %l182 = alloca ptr
  %l186 = alloca i64
  %l187 = alloca i64
  %l194 = alloca i64
  %l198 = alloca i64
  %l201 = alloca i64
  %l221 = alloca i1
  %l233 = alloca ptr
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t4)
  store i64 %t6, ptr %l16
  br label %bb1
bb1:
  %t7 = load i64, ptr %l16, !tbaa !24
  store i64 %t7, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l2, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t12 = icmp sgt i64 %t8, %t9
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  br i1 %t16, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l20, !tbaa !24
  br label %bb7
bb4:
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t18, %t19
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = add i64 %t22, %t23
  %t28 = sub i64 %t26, 1
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = sdiv i64 %t28, %t29
  store i64 %t32, ptr %l23, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb6
bb6:
  %t34 = load i64, ptr %l23, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l20, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = load i64, ptr %l5, !tbaa !24
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb90
bb10:
  br label %bb11
bb11:
  %t44 = load i64, ptr %l1, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = mul i64 %t45, %t46
  %t52 = add i64 %t44, %t49
  store i64 %t52, ptr %l6, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t57, i64 %t58)
  store i1 %t61, ptr %l44
  br label %bb12
bb12:
  %t62 = load i1, ptr %l44, !tbaa !21
  br i1 %t62, label %bb13, label %bb14
bb13:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 3
  %t66 = load i1, ptr %t65, !tbaa !21
  br i1 %t66, label %bb15, label %bb16
bb14:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t72 = load i64, ptr %l6, !tbaa !24
  %t75 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t71, i64 %t72)
  store i64 %t75, ptr %l52
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb18
bb17:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 0
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/load:Loader", ptr %t82, i32 0, i32 7
  %t85 = load i64, ptr %t84, !tbaa !24
  %t86 = load i64, ptr %l52, !tbaa !24
  %t88 = icmp ne i64 %t86, %t85
  store i1 %t88, ptr %l48, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l48, !tbaa !21
  %t91 = xor i1 %t90, true
  store i1 %t91, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t93 = load i1, ptr %l45, !tbaa !21
  br i1 %t93, label %bb20, label %bb21
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %t94, i64 %t95)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t101, i64 %t102)
  store i1 %t105, ptr %l64
  br label %bb24
bb24:
  %t106 = load i1, ptr %l64, !tbaa !21
  %t107 = xor i1 %t106, true
  br i1 %t107, label %bb25, label %bb26
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t113 = load i64, ptr %l6, !tbaa !24
  %t116 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t112, i64 %t113)
  store ptr %t116, ptr %l70
  br label %bb27
bb26:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb28
bb27:
  %t117 = load ptr, ptr %l70, !tbaa !29
  %t119 = getelementptr %"compiler/ast:Func", ptr %t117, i32 0, i32 7
  %t120 = load i1, ptr %t119, !tbaa !21
  store i1 %t120, ptr %l66, !tbaa !21
  br label %bb28
bb28:
  %t122 = load i1, ptr %l66, !tbaa !21
  br i1 %t122, label %bb29, label %bb30
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/check:Checker", ptr %t123, i32 0, i32 3
  %t126 = load i1, ptr %t125, !tbaa !21
  br i1 %t126, label %bb31, label %bb32
bb30:
  store i1 false, ptr %l73, !tbaa !21
  br label %bb35
bb31:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t132 = load i64, ptr %l6, !tbaa !24
  %t135 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t131, i64 %t132)
  store i64 %t135, ptr %l80
  br label %bb33
bb32:
  store i1 false, ptr %l76, !tbaa !21
  br label %bb34
bb33:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !29
  %t141 = getelementptr %"compiler/generic:Program", ptr %t139, i32 0, i32 0
  %t142 = load ptr, ptr %t141, !tbaa !29
  %t144 = getelementptr %"compiler/load:Loader", ptr %t142, i32 0, i32 7
  %t145 = load i64, ptr %t144, !tbaa !24
  %t146 = load i64, ptr %l80, !tbaa !24
  %t148 = icmp ne i64 %t146, %t145
  store i1 %t148, ptr %l76, !tbaa !21
  br label %bb34
bb34:
  %t150 = load i1, ptr %l76, !tbaa !21
  %t151 = xor i1 %t150, true
  store i1 %t151, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t153 = load i1, ptr %l73, !tbaa !21
  br i1 %t153, label %bb36, label %bb37
bb36:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %t154, i64 %t155)
  br label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i64, ptr %l6, !tbaa !24
  %t165 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l92
  br label %bb40
bb40:
  %t166 = load i1, ptr %l92, !tbaa !21
  br i1 %t166, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb44
bb42:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t171 = load i64, ptr %l6, !tbaa !24
  %t174 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t170, i64 %t171)
  store ptr %t174, ptr %l97
  br label %bb43
bb43:
  %t175 = load ptr, ptr %l97, !tbaa !29
  %t177 = getelementptr %"compiler/ast:Func", ptr %t175, i32 0, i32 6
  %t178 = load i1, ptr %t177, !tbaa !21
  %t180 = xor i1 %t178, true
  store i1 %t180, ptr %l93, !tbaa !21
  br label %bb44
bb44:
  %t182 = load i1, ptr %l93, !tbaa !21
  br i1 %t182, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb46:
  br label %bb47
bb47:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t183, i32 0, i32 3
  %t186 = load i1, ptr %t185, !tbaa !21
  br i1 %t186, label %bb48, label %bb49
bb48:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t188, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load i64, ptr %l6, !tbaa !24
  %t195 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t191, i64 %t192)
  store i64 %t195, ptr %l107
  br label %bb50
bb49:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb51
bb50:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 0
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/load:Loader", ptr %t202, i32 0, i32 7
  %t205 = load i64, ptr %t204, !tbaa !24
  %t206 = load i64, ptr %l107, !tbaa !24
  %t208 = icmp ne i64 %t206, %t205
  store i1 %t208, ptr %l103, !tbaa !21
  br label %bb51
bb51:
  %t210 = load i1, ptr %l103, !tbaa !21
  br i1 %t210, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb53:
  br label %bb54
bb54:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t215 = load i64, ptr %l6, !tbaa !24
  %t218 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t214, i64 %t215)
  store i32 %t218, ptr %l116
  br label %bb55
bb55:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  %t223 = load i64, ptr %l6, !tbaa !24
  %t226 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t222, i64 %t223)
  store ptr %t226, ptr %l120
  br label %bb56
bb56:
  %t227 = load ptr, ptr %l120, !tbaa !29
  %t229 = getelementptr %"compiler/ast:Func", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = icmp eq ptr %t230, null
  br i1 %t232, label %bb57, label %bb58
bb57:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t238 = load i64, ptr %l6, !tbaa !24
  %t241 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t237, i64 %t238)
  store ptr %t241, ptr %l128
  br label %bb59
bb58:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb60
bb59:
  %t242 = load ptr, ptr %l128, !tbaa !29
  %t244 = getelementptr %"compiler/ast:Func", ptr %t242, i32 0, i32 3
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Sig", ptr %t245, i32 0, i32 6
  %t248 = load i1, ptr %t247, !tbaa !21
  store i1 %t248, ptr %l124, !tbaa !21
  br label %bb60
bb60:
  %t250 = load i1, ptr %l124, !tbaa !21
  br i1 %t250, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s7
  %t251 = load ptr, ptr %l0, !tbaa !29
  store ptr %t251, ptr %l132, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = getelementptr %"compiler/check:Checker", ptr %t252, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t256 = load i64, ptr %l6, !tbaa !24
  %t259 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t255, i64 %t256)
  store i64 %t259, ptr %l136
  br label %bb63
bb62:
  br label %bb72
bb63:
  %t260 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t261 = load ptr, ptr %l132, !tbaa !29
  %t262 = load i64, ptr %l136, !tbaa !24
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t261, i64 -1, i64 %t262, i32 %t260, i32 0)
  store ptr %t264, ptr %l138
  br label %bb64
bb64:
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l139, !tbaa !29
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l140, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/check:Checker", ptr %t267, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t271 = load i64, ptr %l6, !tbaa !24
  %t274 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t270, i64 %t271)
  store ptr %t274, ptr %l144
  br label %bb65
bb65:
  %t275 = load ptr, ptr %l140, !tbaa !29
  %t276 = load ptr, ptr %l144, !tbaa !29
  %t277 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t275, ptr %t276)
  store %"compiler/source:Span" %t277, ptr %l145
  br label %bb66
bb66:
  %t278 = load ptr, ptr %l0, !tbaa !29
  store ptr %t278, ptr %l146, !tbaa !29
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/check:Checker", ptr %t279, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !29
  %t283 = load i64, ptr %l6, !tbaa !24
  %t286 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t282, i64 %t283)
  store ptr %t286, ptr %l150
  br label %bb67
bb67:
  %t287 = load ptr, ptr %l150, !tbaa !29
  %t289 = getelementptr %"compiler/ast:Func", ptr %t287, i32 0, i32 2
  %t290 = load i32, ptr %t289, !tbaa !23
  %t291 = load ptr, ptr %l146, !tbaa !29
  %t293 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t291, i32 %t290)
  store { i64, ptr } %t293, ptr %l153
  br label %bb68
bb68:
  %t294 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  %t296 = extractvalue { i64, ptr } %t294, 1
  %t297 = mul i64 %t295, 1
  %t298 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t298, ptr %t296, i64 %t297, i1 false)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t302 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %s7, ptr %s7, { i64, ptr } %t300)
  store %"compiler/msgs:Msg" %t302, ptr %l155
  br label %bb69
bb69:
  %t303 = load ptr, ptr %l139, !tbaa !29
  %t304 = load %"compiler/source:Span", ptr %l145
  %t305 = load %"compiler/msgs:Msg", ptr %l155
  %t306 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t303, %"compiler/source:Span" %t304, %"compiler/msgs:Msg" %t305)
  store i64 %t306, ptr %l156
  br label %bb70
bb70:
  %t307 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t307)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s7)
  br label %bb72
bb72:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/check:Checker", ptr %t309, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !29
  %t313 = load i64, ptr %l6, !tbaa !24
  %t316 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t312, i64 %t313)
  store ptr %t316, ptr %l161
  br label %bb73
bb73:
  %t317 = load ptr, ptr %l161, !tbaa !29
  %t319 = getelementptr %"compiler/ast:Func", ptr %t317, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !29
  %t322 = icmp eq ptr %t320, null
  %t324 = xor i1 %t322, true
  br i1 %t324, label %bb74, label %bb75
bb74:
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorMethod(ptr %v0, ptr %t326, i64 %t327)
  br label %bb76
bb75:
  br label %bb80
bb76:
  %t330 = load ptr, ptr %l0, !tbaa !29
  %t331 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritClash(ptr %v0, ptr %t330, i64 %t331)
  br label %bb77
bb77:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %t334, i64 %t335)
  br label %bb78
bb78:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %t338, i64 %t339)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i64, ptr %l6, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %t342, i64 %t343)
  br label %bb81
bb81:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/check:Checker", ptr %t346, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  store ptr %t349, ptr %l177, !tbaa !29
  %t350 = load i64, ptr %l6, !tbaa !24
  %t352 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t350)
  store i64 %t352, ptr %l179
  br label %bb82
bb82:
  %t353 = load ptr, ptr %l177, !tbaa !29
  %t354 = load i64, ptr %l179, !tbaa !24
  %t355 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t353, i64 %t354)
  store i64 %t355, ptr %l180
  br label %bb83
bb83:
  %t356 = load i64, ptr %l180, !tbaa !24
  %t357 = icmp sgt i64 %t356, 0
  br i1 %t357, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb85:
  br label %bb86
bb86:
  %t359 = load ptr, ptr %l0, !tbaa !29
  store ptr %t359, ptr %l182, !tbaa !29
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/check:Checker", ptr %t360, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !29
  %t364 = load i64, ptr %l6, !tbaa !24
  %t367 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %t363, i64 %t364, i32 0)
  store i64 %t367, ptr %l186
  br label %bb87
bb87:
  %t368 = load ptr, ptr %l182, !tbaa !29
  %t369 = load i64, ptr %l186, !tbaa !24
  %t370 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t368, i64 %t369)
  store i64 %t370, ptr %l187
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s2)
  br label %bb89
bb89:
  %t371 = load i64, ptr %l5, !tbaa !24
  %t373 = add i64 %t371, 1
  store i64 %t373, ptr %l5, !tbaa !24
  br label %bb8
bb90:
  store i64 0, ptr %l7, !tbaa !24
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t377 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 1
  %t378 = load ptr, ptr %t377, !tbaa !29
  %t380 = getelementptr %"compiler/generic:Program", ptr %t378, i32 0, i32 0
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/load:Loader", ptr %t381, i32 0, i32 5
  %t385 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t383)
  store i64 %t385, ptr %l194
  br label %bb91
bb91:
  %t386 = load i64, ptr %l194, !tbaa !24
  store i64 %t386, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t387 = load i64, ptr %l8, !tbaa !24
  %t388 = load i64, ptr %l7, !tbaa !24
  %t391 = icmp sgt i64 %t387, %t388
  br i1 %t391, label %bb92, label %bb93
bb92:
  %t393 = load i64, ptr %l9, !tbaa !24
  %t395 = icmp sgt i64 %t393, 0
  br i1 %t395, label %bb94, label %bb95
bb93:
  store i64 0, ptr %l198, !tbaa !24
  br label %bb97
bb94:
  %t397 = load i64, ptr %l8, !tbaa !24
  %t398 = load i64, ptr %l7, !tbaa !24
  %t401 = sub i64 %t397, %t398
  %t402 = load i64, ptr %l9, !tbaa !24
  %t405 = add i64 %t401, %t402
  %t407 = sub i64 %t405, 1
  %t408 = load i64, ptr %l9, !tbaa !24
  %t411 = sdiv i64 %t407, %t408
  store i64 %t411, ptr %l201, !tbaa !24
  br label %bb96
bb95:
  store i64 0, ptr %l201, !tbaa !24
  br label %bb96
bb96:
  %t413 = load i64, ptr %l201, !tbaa !24
  store i64 %t413, ptr %l198, !tbaa !24
  br label %bb97
bb97:
  %t414 = load i64, ptr %l198, !tbaa !24
  store i64 %t414, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb98
bb98:
  store %olang.scope zeroinitializer, ptr %s12
  %t415 = load i64, ptr %l11, !tbaa !24
  %t416 = load i64, ptr %l10, !tbaa !24
  %t419 = icmp slt i64 %t415, %t416
  %t421 = xor i1 %t419, true
  br i1 %t421, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s12)
  br label %bb114
bb100:
  br label %bb101
bb101:
  %t423 = load i64, ptr %l7, !tbaa !24
  %t424 = load i64, ptr %l11, !tbaa !24
  %t425 = load i64, ptr %l9, !tbaa !24
  %t428 = mul i64 %t424, %t425
  %t431 = add i64 %t423, %t428
  store i64 %t431, ptr %l12, !tbaa !24
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t435 = getelementptr %"compiler/check:Checker", ptr %t433, i32 0, i32 3
  %t436 = load i1, ptr %t435, !tbaa !21
  br i1 %t436, label %bb102, label %bb103
bb102:
  %t438 = load i64, ptr %l12, !tbaa !24
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = getelementptr %"compiler/check:Checker", ptr %t439, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !29
  %t444 = getelementptr %"compiler/generic:Program", ptr %t442, i32 0, i32 0
  %t445 = load ptr, ptr %t444, !tbaa !29
  %t447 = getelementptr %"compiler/load:Loader", ptr %t445, i32 0, i32 7
  %t448 = load i64, ptr %t447, !tbaa !24
  %t451 = icmp ne i64 %t438, %t448
  store i1 %t451, ptr %l221, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb104
bb104:
  %t453 = load i1, ptr %l221, !tbaa !21
  br i1 %t453, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s12)
  br label %bb113
bb106:
  br label %bb107
bb107:
  %t454 = load ptr, ptr %l0, !tbaa !29
  %t456 = getelementptr %"compiler/check:Checker", ptr %t454, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !29
  %t459 = getelementptr %"compiler/generic:Program", ptr %t457, i32 0, i32 0
  %t460 = load ptr, ptr %t459, !tbaa !29
  %t462 = getelementptr %"compiler/load:Loader", ptr %t460, i32 0, i32 5
  %t463 = load i64, ptr %l12, !tbaa !24
  %t466 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t462, i64 %t463)
  store ptr %t466, ptr %l233
  br label %bb108
bb108:
  %t467 = load ptr, ptr %l233, !tbaa !29
  %t469 = getelementptr %"compiler/load:Module", ptr %t467, i32 0, i32 8
  %t470 = load { i64, ptr }, ptr %t469, !tbaa !27
  store { i64, ptr } %t470, ptr %l13, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t474 = extractvalue { i64, ptr } %t472, 0
  %t476 = icmp sgt i64 %t474, 0
  br i1 %t476, label %bb109, label %bb110
bb109:
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t479 = load i64, ptr %l12, !tbaa !24
  %t480 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v0, ptr %t478, i64 %t479, { i64, ptr } %t480)
  br label %bb111
bb110:
  br label %bb112
bb111:
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s12)
  br label %bb113
bb113:
  %t484 = load i64, ptr %l11, !tbaa !24
  %t486 = add i64 %t484, 1
  store i64 %t486, ptr %l11, !tbaa !24
  br label %bb98
bb114:
  %t488 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %t488)
  br label %bb115
bb115:
  %t490 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %t490)
  br label %bb116
bb116:
  %t492 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettle(ptr %v0, ptr %t492)
  br label %bb117
bb117:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aArm(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l21 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/typed:Arm", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l5, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l6, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Alt", ptr %t32, i32 0, i32 0
  %t35 = load ptr, ptr %t34, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t30, ptr %t31, ptr %t35)
  br label %bb8
bb8:
  %t40 = load ptr, ptr %l6, !tbaa !29
  %t42 = getelementptr %"compiler/typed:Alt", ptr %t40, i32 0, i32 1
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !27
  store { i64, ptr } %t43, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l9, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s5
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l9, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb11:
  br label %bb12
bb12:
  %t57 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t57, ptr %l37, !tbaa !27
  %t58 = load i64, ptr %l8, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 %t58
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Bind", ptr %t63, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t65, ptr %t66, ptr %t70)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb14:
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = add i64 %t75, 1
  store i64 %t77, ptr %l8, !tbaa !24
  br label %bb9
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb16:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l4, !tbaa !24
  br label %bb4
bb17:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Arm", ptr %t85, i32 0, i32 2
  %t88 = load ptr, ptr %t87, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t83, ptr %t84, ptr %t88)
  br label %bb18
bb18:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = getelementptr %"compiler/typed:Arm", ptr %t94, i32 0, i32 3
  %t97 = load ptr, ptr %t96, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %t92, ptr %t93, ptr %t97)
  br label %bb19
bb19:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l2, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Arm", ptr %t103, i32 0, i32 4
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  br label %bb20
bb20:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i1
  %l48 = alloca ptr
  %l49 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t6 = load ptr, ptr %l13, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l13, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l14, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  %t20 = load ptr, ptr %l2, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l4, !tbaa !24
  %t26 = load ptr, ptr %l2, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t28, i32 0, i32 3
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l5, !tbaa !23
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t34 = load i64, ptr %l4, !tbaa !24
  %t35 = load i32, ptr %l5, !tbaa !23
  %t36 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %t32, ptr %t33, i64 %t34, i32 %t35, i32 %t36)
  br label %bb9
bb9:
  br label %bb51
bb10:
  %t42 = load ptr, ptr %l2, !tbaa !29
  store ptr %t42, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t43 = load ptr, ptr %l28, !tbaa !29
  %t44 = icmp ne ptr %t43, null
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load ptr, ptr %l28, !tbaa !29
  %t47 = load i64, ptr %t46
  %t49 = icmp eq i64 %t47, 2
  store i1 %t49, ptr %l29, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l29, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t51 = load ptr, ptr %l2, !tbaa !29
  %t53 = getelementptr { i64, [4 x i64] }, ptr %t51, i32 0, i32 1
  %t54 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t53, i32 0, i32 2
  %t55 = load ptr, ptr %t54
  store ptr %t55, ptr %l6, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t57, ptr %t58, ptr %t59)
  br label %bb16
bb16:
  br label %bb51
bb17:
  %t64 = load ptr, ptr %l2, !tbaa !29
  store ptr %t64, ptr %l38, !tbaa !29
  store i1 false, ptr %l39, !tbaa !21
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t68 = load ptr, ptr %l38, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 3
  store i1 %t71, ptr %l39, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l39, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l2, !tbaa !29
  %t75 = getelementptr { i64, [4 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l7, !tbaa !29
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t79, ptr %t80, ptr %t81)
  br label %bb23
bb23:
  br label %bb51
bb24:
  %t86 = load ptr, ptr %l2, !tbaa !29
  store ptr %t86, ptr %l48, !tbaa !29
  store i1 false, ptr %l49, !tbaa !21
  %t87 = load ptr, ptr %l48, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb25, label %bb26
bb25:
  %t90 = load ptr, ptr %l48, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 4
  store i1 %t93, ptr %l49, !tbaa !21
  br label %bb26
bb26:
  %t94 = load i1, ptr %l49, !tbaa !21
  br i1 %t94, label %bb27, label %bb28
bb27:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t97, i32 0, i32 2
  %t99 = load ptr, ptr %t98
  store ptr %t99, ptr %l8, !tbaa !29
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load ptr, ptr %l8, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Elem", ptr %t103, i32 0, i32 0
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t101, ptr %t102, ptr %t106)
  br label %bb30
bb30:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Elem", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t111, ptr %t112, ptr %t116)
  br label %bb31
bb31:
  br label %bb51
bb32:
  %t121 = load ptr, ptr %l2, !tbaa !29
  store ptr %t121, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t122 = load ptr, ptr %l64, !tbaa !29
  %t123 = icmp ne ptr %t122, null
  br i1 %t123, label %bb33, label %bb34
bb33:
  %t125 = load ptr, ptr %l64, !tbaa !29
  %t126 = load i64, ptr %t125
  %t128 = icmp eq i64 %t126, 5
  store i1 %t128, ptr %l65, !tbaa !21
  br label %bb34
bb34:
  %t129 = load i1, ptr %l65, !tbaa !21
  br i1 %t129, label %bb35, label %bb36
bb35:
  %t130 = load ptr, ptr %l2, !tbaa !29
  %t132 = getelementptr { i64, [4 x i64] }, ptr %t130, i32 0, i32 1
  %t133 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t132, i32 0, i32 2
  %t134 = load ptr, ptr %t133
  store ptr %t134, ptr %l9, !tbaa !29
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load ptr, ptr %l1, !tbaa !29
  %t138 = load ptr, ptr %l9, !tbaa !29
  %t140 = getelementptr %"compiler/typed:Payload", ptr %t138, i32 0, i32 0
  %t141 = load ptr, ptr %t140, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPlace(ptr %v0, ptr %v1, ptr %v2, ptr %t136, ptr %t137, ptr %t141)
  br label %bb38
bb38:
  br label %bb51
bb39:
  %t146 = load ptr, ptr %l2, !tbaa !29
  store ptr %t146, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t147 = load ptr, ptr %l75, !tbaa !29
  %t148 = icmp ne ptr %t147, null
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %l75, !tbaa !29
  %t151 = load i64, ptr %t150
  %t153 = icmp eq i64 %t151, 6
  store i1 %t153, ptr %l76, !tbaa !21
  br label %bb41
bb41:
  %t154 = load i1, ptr %l76, !tbaa !21
  br i1 %t154, label %bb42, label %bb43
bb42:
  %t155 = load ptr, ptr %l2, !tbaa !29
  %t157 = getelementptr { i64, [4 x i64] }, ptr %t155, i32 0, i32 1
  %t158 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t157, i32 0, i32 2
  %t159 = load ptr, ptr %t158
  store ptr %t159, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t163 = load ptr, ptr %l10, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t161, ptr %t162, ptr %t163)
  br label %bb45
bb45:
  br label %bb51
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e)
  unreachable
bb51:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l22 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l50 = alloca ptr
  %l55 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i32
  %l72 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l80 = alloca ptr
  %l86 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l92 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, [2 x i64] }
  %l101 = alloca i32
  %l102 = alloca %"compiler/typed:Call"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t141 = alloca { i64, [3 x i64] }, align 8
  %t156 = alloca { i64, [2 x i64] }, align 8
  %t172 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 32
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i64, ptr %l22, !tbaa !24
  store i64 %t6, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l10, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb7
bb4:
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = load i64, ptr %l8, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l10, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l10, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l31, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb6
bb6:
  %t37 = load i64, ptr %l31, !tbaa !24
  store i64 %t37, ptr %l28, !tbaa !24
  br label %bb7
bb7:
  %t38 = load i64, ptr %l28, !tbaa !24
  store i64 %t38, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l12, !tbaa !24
  %t40 = load i64, ptr %l11, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb10:
  br label %bb11
bb11:
  %t47 = load i64, ptr %l8, !tbaa !24
  %t48 = load i64, ptr %l12, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 32
  store ptr %t59, ptr %l50, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %t60, { i64, ptr } %t61, ptr %a5, i64 %t55)
  store ptr %t68, ptr %l55
  br label %bb12
bb12:
  %t69 = load ptr, ptr %l50, !tbaa !29
  %t70 = load ptr, ptr %l55, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t69, ptr %t70)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t73 = add i64 %t71, 1
  store i64 %t73, ptr %l12, !tbaa !24
  br label %bb8
bb15:
  store ptr %a6, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t77 = load ptr, ptr %l14, !tbaa !29
  %t78 = load i64, ptr %l15, !tbaa !24
  %t81 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v2, ptr %t77, i64 %t78)
  %t82 = extractvalue { i32, { i64, ptr } } %t81, 1
  %t83 = extractvalue { i32, { i64, ptr } } %t81, 0
  store i32 %t83, ptr %l63
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb18, label %ok.85
ok.85:
  store { i64, ptr } %t82, ptr %l62
  br label %bb17
bb17:
  %t86 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t86, ptr %l59, !tbaa !27
  br label %bb22
bb18:
  %t87 = load i32, ptr %l63, !tbaa !23
  %t88 = ashr i32 %t87, 16
  %t90 = icmp eq i32 %t88, 1
  br i1 %t90, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_6ff259b9ccd7369f_aca193469829e60b)
  unreachable
bb21:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb22:
  %t92 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t92, ptr %l16, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  store i64 %t95, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l18, !tbaa !24
  %t98 = load i64, ptr %l17, !tbaa !24
  %t101 = icmp slt i64 %t97, %t98
  %t103 = xor i1 %t101, true
  br i1 %t103, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb25:
  br label %bb26
bb26:
  %t105 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t105, ptr %l72, !tbaa !27
  %t106 = load i64, ptr %l18, !tbaa !24
  %t108 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !27
  %t110 = getelementptr i64, ptr %t109, i64 %t106
  %t111 = load i64, ptr %t110, !tbaa !34
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 32
  store ptr %t115, ptr %l76, !tbaa !29
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l1
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t116, %"compiler/source:Span" %t117, i64 %t111)
  store ptr %t122, ptr %l80
  br label %bb27
bb27:
  %t123 = load ptr, ptr %l76, !tbaa !29
  %t124 = load ptr, ptr %l80, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t123, ptr %t124)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t125 = load i64, ptr %l18, !tbaa !24
  %t127 = add i64 %t125, 1
  store i64 %t127, ptr %l18, !tbaa !24
  br label %bb23
bb30:
  %t129 = load i64, ptr %l15, !tbaa !24
  %t130 = load i64, ptr %l17, !tbaa !24
  %t133 = add i64 %t129, %t130
  store i64 %t133, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  br label %bb16
bb32:
  %t135 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t135, ptr %l86
  store i32 %a3, ptr %l87, !tbaa !23
  %t139 = trunc i64 %a2 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [3 x i64] }, ptr %t141, i32 0, i32 0
  store i64 0, ptr %t142
  %t144 = insertvalue { i32 } undef, i32 %t139, 0
  %t145 = getelementptr { i64, [3 x i64] }, ptr %t141, i32 0, i32 1
  store { i32 } %t144, ptr %t145
  %t146 = load { i64, [3 x i64] }, ptr %t141
  %t148 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t146, ptr %t148
  store ptr %t148, ptr %l92, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 32
  %t152 = load i64, ptr %l7, !tbaa !24
  %t155 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t151, i64 %t152)
  store { i64, ptr } %t155, ptr %l96
  br label %bb33
bb33:
  store { i64, [2 x i64] } zeroinitializer, ptr %t156
  %t157 = getelementptr { i64, [2 x i64] }, ptr %t156, i32 0, i32 0
  store i64 0, ptr %t157
  %t158 = load { i64, [2 x i64] }, ptr %t156
  store { i64, [2 x i64] } %t158, ptr %l97
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l1
  %t164 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t159, i32 0, %"compiler/source:Span" %t160)
  store i32 %t164, ptr %l101
  br label %bb34
bb34:
  %t165 = load ptr, ptr %l92, !tbaa !29
  %t166 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t167 = load { i64, [2 x i64] }, ptr %l97
  %t168 = load i32, ptr %l101, !tbaa !23
  %t169 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t165, { i64, ptr } %t166, { i64, [2 x i64] } %t167, i32 %t168, i1 false)
  store %"compiler/typed:Call" %t169, ptr %l102
  br label %bb35
bb35:
  %t170 = load %"compiler/typed:Call", ptr %l102
  %t171 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t170, ptr %t171
  store { i64, [5 x i64] } zeroinitializer, ptr %t172
  %t173 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 0
  store i64 6, ptr %t173
  %t174 = load %"compiler/source:Span", ptr %l86
  %t175 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t174, 0
  %t176 = load i32, ptr %l87, !tbaa !23
  %t177 = insertvalue { %"compiler/source:Span", i32, ptr } %t175, i32 %t176, 1
  %t179 = insertvalue { %"compiler/source:Span", i32, ptr } %t177, ptr %t171, 2
  %t180 = getelementptr { i64, [5 x i64] }, ptr %t172, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t179, ptr %t180
  %t181 = load { i64, [5 x i64] }, ptr %t172
  %t183 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t181, ptr %t183
  store ptr %t183, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eboundParam(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l19 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l49 = alloca i64
  %l51 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca { i64, ptr }
  %l68 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca i32
  %l77 = alloca i64
  %l82 = alloca i32
  %l83 = alloca i32
  %l88 = alloca i1
  %l93 = alloca i1
  %l98 = alloca i32
  %l101 = alloca i1
  %l102 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i1
  %l112 = alloca i1
  %l118 = alloca i1
  %l122 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t7 = icmp sge i64 %t1, %t4
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t9, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/generic:Binding", ptr %t11, i32 0, i32 1
  %t14 = load i64, ptr %t13, !tbaa !24
  store i64 %t14, ptr %l19, !tbaa !24
  %t15 = load i64, ptr %l19, !tbaa !24
  %t16 = icmp sge i64 %t15, 0
  br i1 %t16, label %bb4, label %bb5
bb4:
  %t18 = load i64, ptr %l19, !tbaa !24
  %t19 = icmp sle i64 %t18, 2305843009213693951
  br i1 %t19, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_f6613c7e75250c33_3760568a21e1f80f)
  unreachable
bb6:
  %t21 = load i64, ptr %l19, !tbaa !24
  %t22 = mul i64 %t21, 4
  %t23 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t22)
  %t24 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t25 = insertvalue { i64, ptr } %t24, ptr %t23, 1
  store { i64, ptr } %t25, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Binding", ptr %t27, i32 0, i32 1
  %t30 = load i64, ptr %t29, !tbaa !24
  store i64 %t30, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t36 = icmp sgt i64 %t32, %t33
  br i1 %t36, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_f6613c7e75250c33_3760568a21e1f80f)
  unreachable
bb8:
  %t38 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp sgt i64 %t38, 0
  br i1 %t40, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb13
bb10:
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sub i64 %t42, %t43
  %t47 = load i64, ptr %l7, !tbaa !24
  %t50 = add i64 %t46, %t47
  %t52 = sub i64 %t50, 1
  %t53 = load i64, ptr %l7, !tbaa !24
  %t56 = sdiv i64 %t52, %t53
  store i64 %t56, ptr %l31, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb12
bb12:
  %t58 = load i64, ptr %l31, !tbaa !24
  store i64 %t58, ptr %l28, !tbaa !24
  br label %bb13
bb13:
  %t59 = load i64, ptr %l28, !tbaa !24
  store i64 %t59, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l9, !tbaa !24
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb16:
  br label %bb17
bb17:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = mul i64 %t69, %t70
  %t76 = add i64 %t68, %t73
  store i64 %t76, ptr %l10, !tbaa !24
  %t78 = load i64, ptr %l10, !tbaa !24
  store i64 %t78, ptr %l49, !tbaa !24
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Binding", ptr %t79, i32 0, i32 2
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  store { i64, ptr } %t82, ptr %l51, !tbaa !27
  %t83 = load i64, ptr %l10, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr i32, ptr %t86, i64 %t83
  %t88 = load i32, ptr %t87, !tbaa !33
  %t89 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t92 = icmp ne i32 %t88, %t89
  br i1 %t92, label %bb18, label %bb19
bb18:
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Binding", ptr %t94, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  store { i64, ptr } %t97, ptr %l58, !tbaa !27
  %t98 = load i64, ptr %l10, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  store i32 %t103, ptr %l56, !tbaa !23
  br label %bb21
bb19:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !29
  %t110 = getelementptr %"compiler/generic:Program", ptr %t108, i32 0, i32 2
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Binding", ptr %t111, i32 0, i32 0
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  %t116 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t121 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t110, i64 %t114, i64 %t115, i64 %t116)
  store i32 %t121, ptr %l68
  br label %bb20
bb20:
  %t122 = load i32, ptr %l68, !tbaa !23
  store i32 %t122, ptr %l56, !tbaa !23
  br label %bb21
bb21:
  %t123 = load i32, ptr %l56, !tbaa !23
  %t124 = load i64, ptr %l49, !tbaa !24
  %t125 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr i32, ptr %t126, i64 %t124
  store i32 %t123, ptr %t127, !tbaa !33
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb22:
  %t128 = load i64, ptr %l9, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l9, !tbaa !24
  br label %bb14
bb23:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  store ptr %t135, ptr %l72, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t136, ptr %l73, !tbaa !27
  %t137 = load i64, ptr %l2, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  store i32 %t142, ptr %l75, !tbaa !23
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Binding", ptr %t143, i32 0, i32 0
  %t146 = load i64, ptr %t145, !tbaa !24
  store i64 %t146, ptr %l77, !tbaa !24
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"compiler/check:Checker", ptr %t147, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !29
  %t152 = getelementptr %"compiler/generic:Program", ptr %t150, i32 0, i32 2
  %t153 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t152, { i64, ptr } %t153)
  store i32 %t156, ptr %l82
  br label %bb24
bb24:
  %t157 = load ptr, ptr %l72, !tbaa !29
  %t158 = load i32, ptr %l75, !tbaa !23
  %t159 = load i64, ptr %l77, !tbaa !24
  %t160 = load i32, ptr %l82, !tbaa !23
  %t161 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t157, i32 %t158, i64 %t159, i32 %t160)
  store i32 %t161, ptr %l83
  br label %bb25
bb25:
  %t162 = load i32, ptr %l83, !tbaa !23
  store i32 %t162, ptr %l11, !tbaa !23
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = getelementptr %"compiler/check:Checker", ptr %t163, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !29
  %t168 = getelementptr %"compiler/generic:Program", ptr %t166, i32 0, i32 2
  %t169 = load i32, ptr %l11, !tbaa !23
  %t172 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t168, i32 %t169)
  store i1 %t172, ptr %l88
  br label %bb26
bb26:
  %t173 = load i1, ptr %l88, !tbaa !21
  %t174 = xor i1 %t173, true
  br i1 %t174, label %bb27, label %bb28
bb27:
  %t176 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t176, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load i32, ptr %l11, !tbaa !23
  %t182 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t178, i32 %t179)
  store i1 %t182, ptr %l93
  br label %bb30
bb30:
  %t183 = load i1, ptr %l93, !tbaa !21
  br i1 %t183, label %bb31, label %bb32
bb31:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Program", ptr %t187, i32 0, i32 2
  %t190 = load i32, ptr %l11, !tbaa !23
  %t193 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t189, i32 %t190)
  store i32 %t193, ptr %l98
  br label %bb33
bb32:
  br label %bb50
bb33:
  %t194 = load i32, ptr %l98, !tbaa !23
  store i32 %t194, ptr %l12, !tbaa !23
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l12, !tbaa !23
  %t199 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t195, i32 %t196)
  store i1 %t199, ptr %l101
  br label %bb34
bb34:
  %t200 = load i1, ptr %l101, !tbaa !21
  br i1 %t200, label %bb35, label %bb36
bb35:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/check:Checker", ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !29
  %t205 = load i32, ptr %l12, !tbaa !23
  %t208 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t204, i32 %t205)
  store i1 %t208, ptr %l106
  br label %bb37
bb36:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb38
bb37:
  %t209 = load i1, ptr %l106, !tbaa !21
  store i1 %t209, ptr %l102, !tbaa !21
  br label %bb38
bb38:
  %t210 = load i1, ptr %l102, !tbaa !21
  br i1 %t210, label %bb39, label %bb40
bb39:
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = getelementptr %"compiler/check:Checker", ptr %t211, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/generic:Program", ptr %t214, i32 0, i32 2
  %t217 = load i32, ptr %l12, !tbaa !23
  %t220 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %t216, i32 %t217)
  store i1 %t220, ptr %l112
  br label %bb41
bb40:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb42
bb41:
  %t221 = load i1, ptr %l112, !tbaa !21
  store i1 %t221, ptr %l107, !tbaa !21
  br label %bb42
bb42:
  %t222 = load i1, ptr %l107, !tbaa !21
  br i1 %t222, label %bb43, label %bb44
bb43:
  %t223 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t223, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  %t231 = load i32, ptr %l11, !tbaa !23
  %t234 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l118
  br label %bb46
bb46:
  %t235 = load i1, ptr %l118, !tbaa !21
  br i1 %t235, label %bb47, label %bb48
bb47:
  %t236 = load i32, ptr %l11, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t236, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load i32, ptr %l11, !tbaa !23
  %t242 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t238, i32 %t239)
  store i32 %t242, ptr %l122
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s0)
  %t243 = load i32, ptr %l122, !tbaa !23
  store i32 %t243, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca %"compiler/source:Span"
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, [2 x i64] }
  %l13 = alloca i32
  %l14 = alloca %"compiler/typed:Call"
  %rv = alloca ptr
  %t5 = alloca { i64, [2 x i64] }, align 8
  %t21 = alloca { i64, [5 x i64] }, align 8
  store %"compiler/source:Span" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t1, ptr %l5
  store i32 %a2, ptr %l6, !tbaa !23
  store ptr %a3, ptr %l7, !tbaa !29
  store { i64, ptr } %a4, ptr %l8, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t5
  %t6 = getelementptr { i64, [2 x i64] }, ptr %t5, i32 0, i32 0
  store i64 0, ptr %t6
  %t7 = load { i64, [2 x i64] }, ptr %t5
  store { i64, [2 x i64] } %t7, ptr %l9
  %t9 = load %"compiler/source:Span", ptr %l1
  %t13 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 0, %"compiler/source:Span" %t9)
  store i32 %t13, ptr %l13
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l7, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t16 = load { i64, [2 x i64] }, ptr %l9
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = call %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t14, { i64, ptr } %t15, { i64, [2 x i64] } %t16, i32 %t17, i1 false)
  store %"compiler/typed:Call" %t18, ptr %l14
  br label %bb2
bb2:
  %t19 = load %"compiler/typed:Call", ptr %l14
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store %"compiler/typed:Call" %t19, ptr %t20
  store { i64, [5 x i64] } zeroinitializer, ptr %t21
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 0
  store i64 6, ptr %t22
  %t23 = load %"compiler/source:Span", ptr %l5
  %t24 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t23, 0
  %t25 = load i32, ptr %l6, !tbaa !23
  %t26 = insertvalue { %"compiler/source:Span", i32, ptr } %t24, i32 %t25, 1
  %t28 = insertvalue { %"compiler/source:Span", i32, ptr } %t26, ptr %t20, 2
  %t29 = getelementptr { i64, [5 x i64] }, ptr %t21, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t28, ptr %t29
  %t30 = load { i64, [5 x i64] }, ptr %t21
  %t32 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t30, ptr %t32
  store ptr %t32, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l12 = alloca i32
  %l20 = alloca ptr
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l49 = alloca i32
  %l50 = alloca i64
  %l54 = alloca ptr
  %l57 = alloca i32
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca i64
  %l66 = alloca i32
  %l67 = alloca %"compiler/source:Span"
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/source:Span"
  %l79 = alloca i64
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l98 = alloca ptr
  %l111 = alloca i1
  %l112 = alloca { i64, ptr }
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l127 = alloca i1
  %l128 = alloca { i64, ptr }
  %l132 = alloca ptr
  %l136 = alloca %"compiler/source:Span"
  %l137 = alloca %"compiler/msgs:Msg"
  %l138 = alloca i64
  %l143 = alloca ptr
  %l146 = alloca i1
  %l147 = alloca { i64, ptr }
  %l153 = alloca i1
  %l156 = alloca i32
  %l158 = alloca i32
  %l160 = alloca i1
  %l161 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l169 = alloca %"compiler/source:Span"
  %l170 = alloca %"compiler/msgs:Msg"
  %l171 = alloca i64
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca %"compiler/source:Span"
  %l181 = alloca { i64, ptr }
  %l183 = alloca %"compiler/msgs:Msg"
  %l184 = alloca i64
  %l189 = alloca ptr
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t42 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l3, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l5, !tbaa !23
  %t6 = load i32, ptr %l5, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t10 = icmp eq i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t12, { i64, ptr } %t13)
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t16, %"compiler/source:Span" %t17)
  store ptr %t20, ptr %l20
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load ptr, ptr %l20, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
bb6:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  %t28 = load i32, ptr %l5, !tbaa !23
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t27, i32 %t28)
  store i32 %t31, ptr %l25
  br label %bb7
bb7:
  %t32 = load i32, ptr %l25
  %t34 = trunc i64 21 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb8, label %bb9
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l28, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t38, ptr %l29
  %t39 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t39, ptr %l30
  %t40 = load i32, ptr %l5, !tbaa !23
  store i32 %t40, ptr %l31, !tbaa !23
  %t41 = load ptr, ptr %l3, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t42
  %t43 = getelementptr { i64, [3 x i64] }, ptr %t42, i32 0, i32 0
  store i64 2, ptr %t43
  %t45 = insertvalue { ptr } undef, ptr %t41, 0
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t42, i32 0, i32 1
  store { ptr } %t45, ptr %t46
  %t47 = load { i64, [3 x i64] }, ptr %t42
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t47, ptr %t49
  store ptr %t49, ptr %l34, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t50, ptr %l35, !tbaa !27
  %t51 = icmp sge i64 0, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  br label %bb15
bb10:
  %t53 = icmp sle i64 0, 1152921504606846975
  br i1 %t53, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb12:
  %t55 = mul i64 0, 8
  %t56 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 0, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t59 = load ptr, ptr %l28, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l29
  %t61 = load %"compiler/source:Span", ptr %l30
  %t62 = load i32, ptr %l31, !tbaa !23
  %t63 = load ptr, ptr %l34, !tbaa !29
  %t64 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t66 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %t59, %"compiler/source:Span" %t60, %"compiler/source:Span" %t61, i32 %t62, ptr %t63, i64 -1, ptr null, { i64, ptr } %t64, { i64, ptr } %t58)
  store ptr %t66, ptr %l39
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_c23231398495940d_3184fca2d3133de9)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t67 = load ptr, ptr %l39, !tbaa !29
  store ptr %t67, ptr %rv
  br label %ret
bb15:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l41, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i32, ptr %l5, !tbaa !23
  %t76 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l44
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 3
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t86, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t88, ptr %l49
  br label %bb17
bb17:
  %t89 = load ptr, ptr %l41, !tbaa !29
  %t90 = load i32, ptr %l44, !tbaa !23
  %t91 = load i32, ptr %l49, !tbaa !23
  %t92 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t89, i32 %t90, i32 %t91)
  store i64 %t92, ptr %l50
  br label %bb18
bb18:
  %t93 = load i64, ptr %l50, !tbaa !24
  store i64 %t93, ptr %l6, !tbaa !24
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = icmp slt i64 %t94, 0
  br i1 %t96, label %bb19, label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s3
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l54, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l57
  br label %bb21
bb20:
  br label %bb24
bb21:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/generic:Program", ptr %t110, i32 0, i32 0
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/load:Loader", ptr %t113, i32 0, i32 3
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s3, ptr %t116, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t118, ptr %l62
  br label %bb22
bb22:
  %t119 = load ptr, ptr %l54, !tbaa !29
  %t120 = load i32, ptr %l57, !tbaa !23
  %t121 = load i32, ptr %l62, !tbaa !23
  %t122 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t119, i32 %t120, i32 %t121)
  store i64 %t122, ptr %l63
  br label %bb23
bb23:
  %t123 = load i64, ptr %l63, !tbaa !24
  store i64 %t123, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l64, !tbaa !29
  %t125 = load i64, ptr %l6, !tbaa !24
  store i64 %t125, ptr %l65, !tbaa !24
  %t126 = load i32, ptr %l5, !tbaa !23
  store i32 %t126, ptr %l66, !tbaa !23
  %t127 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t127, ptr %l67
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l2
  %t132 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t128, %"compiler/source:Span" %t129)
  store { i64, ptr } %t132, ptr %l70
  br label %bb25
bb25:
  %t133 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t134 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %s0, { i64, ptr } %t133)
  store { i64, ptr } %t134, ptr %l71
  br label %bb26
bb26:
  %t135 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = mul i64 %t136, 1
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @llvm.memcpy.p0.p0.i64(ptr %t139, ptr %t137, i64 %t138, i1 false)
  %t140 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t142 = load ptr, ptr %l64, !tbaa !29
  %t143 = load i64, ptr %l65, !tbaa !24
  %t144 = load i32, ptr %l66, !tbaa !23
  %t145 = load %"compiler/source:Span", ptr %l67
  %t147 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t142, i64 %t143, i32 %t144, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d2, i32 0, i32 1) }, %"compiler/source:Span" %t145, { i64, ptr } %t141)
  store i1 %t147, ptr %l73
  br label %bb27
bb27:
  %t148 = load i64, ptr %l6, !tbaa !24
  %t150 = icmp sge i64 %t148, 0
  br i1 %t150, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l76, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t153, ptr %l77
  %t154 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t154, ptr %l78
  %t155 = load i64, ptr %l6, !tbaa !24
  store i64 %t155, ptr %l79, !tbaa !24
  %t156 = load ptr, ptr %l3, !tbaa !29
  store ptr %t156, ptr %l81, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t158, ptr %l82, !tbaa !27
  %t159 = icmp sge i64 0, 0
  br i1 %t159, label %bb30, label %bb31
bb29:
  br label %bb39
bb30:
  %t161 = icmp sle i64 0, 1152921504606846975
  br i1 %t161, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb32:
  %t163 = mul i64 0, 8
  %t164 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t163)
  %t165 = insertvalue { i64, ptr } undef, i64 0, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l85, !tbaa !27
  %t167 = icmp sge i64 0, 0
  br i1 %t167, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_dec816aeadd109e0_adcbe0bcced90c1c)
  unreachable
bb34:
  %t169 = icmp sle i64 0, 2305843009213693951
  br i1 %t169, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb36:
  %t171 = mul i64 0, 4
  %t172 = call ptr @__olang_scope_alloc_zeroed(ptr %s4, i64 %t171)
  %t173 = insertvalue { i64, ptr } undef, i64 0, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t175 = load ptr, ptr %l76, !tbaa !29
  %t176 = load %"compiler/source:Span", ptr %l77
  %t177 = load %"compiler/source:Span", ptr %l78
  %t178 = load i64, ptr %l79, !tbaa !24
  %t179 = load ptr, ptr %l81, !tbaa !29
  %t180 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t183 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %s4, ptr %t175, %"compiler/source:Span" %t176, %"compiler/source:Span" %t177, i64 %t178, ptr %t179, { i64, ptr } %t180, { i64, ptr } %t181, { i64, ptr } %t174)
  store ptr %t183, ptr %l89
  br label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98ffdf46f6e43303_7907d8ed59f5817f)
  unreachable
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t184 = load ptr, ptr %l89, !tbaa !29
  store ptr %t184, ptr %rv
  br label %ret
bb39:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/load:Loader", ptr %t191, i32 0, i32 5
  store ptr %t193, ptr %l93, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t194)
  store ptr %t196, ptr %l95
  br label %bb40
bb40:
  %t197 = load ptr, ptr %l95, !tbaa !29
  %t199 = getelementptr %"compiler/check:frame", ptr %t197, i32 0, i32 1
  %t200 = load i64, ptr %t199, !tbaa !24
  %t201 = load ptr, ptr %l93, !tbaa !29
  %t203 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t201, i64 %t200)
  store ptr %t203, ptr %l98
  br label %bb41
bb41:
  %t204 = load ptr, ptr %l98, !tbaa !29
  %t206 = getelementptr %"compiler/load:Module", ptr %t204, i32 0, i32 6
  %t207 = load ptr, ptr %t206, !tbaa !29
  store ptr %t207, ptr %l7, !tbaa !29
  %t209 = load ptr, ptr %l7, !tbaa !29
  %t211 = icmp eq ptr %t209, null
  br i1 %t211, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a)
  unreachable
bb43:
  br label %bb44
bb44:
  %t213 = load ptr, ptr %l7, !tbaa !29
  %t216 = getelementptr %"compiler/source:Source", ptr %t213, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l8, !tbaa !27
  %t219 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t220 = load i32, ptr %t219, !tbaa !23
  %t222 = sext i32 %t220 to i64
  %t224 = sub i64 %t222, 1
  store i64 %t224, ptr %l9, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s5
  %t226 = load i64, ptr %l9, !tbaa !24
  %t228 = icmp sgt i64 %t226, 0
  br i1 %t228, label %bb46, label %bb47
bb46:
  %t230 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t230, ptr %l112, !tbaa !27
  %t231 = load i64, ptr %l9, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr i8, ptr %t234, i64 %t231
  %t236 = load i8, ptr %t235, !tbaa !32
  %t238 = icmp eq i8 %t236, 32
  store i1 %t238, ptr %l111, !tbaa !21
  br label %bb48
bb47:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb48
bb48:
  %t240 = load i1, ptr %l111, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb49, label %bb50
bb49:
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb50:
  br label %bb51
bb51:
  %t243 = load i64, ptr %l9, !tbaa !24
  %t245 = sub i64 %t243, 1
  store i64 %t245, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb52
bb52:
  br label %bb45
bb53:
  %t247 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t248 = load i32, ptr %t247, !tbaa !23
  %t250 = icmp sgt i32 %t248, 0
  br i1 %t250, label %bb54, label %bb55
bb54:
  %t252 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t252, ptr %l122, !tbaa !27
  %t253 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t254 = load i32, ptr %t253, !tbaa !23
  %t256 = sext i32 %t254 to i64
  %t258 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i8, ptr %t259, i64 %t256
  %t261 = load i8, ptr %t260, !tbaa !32
  %t263 = icmp eq i8 %t261, 40
  store i1 %t263, ptr %l121, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb56
bb56:
  %t265 = load i1, ptr %l121, !tbaa !21
  br i1 %t265, label %bb57, label %bb58
bb57:
  %t266 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t266, ptr %l128, !tbaa !27
  %t267 = load i64, ptr %l9, !tbaa !24
  %t269 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t270 = load ptr, ptr %t269, !tbaa !27
  %t271 = getelementptr i8, ptr %t270, i64 %t267
  %t272 = load i8, ptr %t271, !tbaa !32
  %t274 = icmp eq i8 %t272, 34
  store i1 %t274, ptr %l127, !tbaa !21
  br label %bb59
bb58:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb59
bb59:
  %t276 = load i1, ptr %l127, !tbaa !21
  br i1 %t276, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s6
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l132, !tbaa !29
  %t278 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t279 = load i32, ptr %t278, !tbaa !23
  %t280 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t281 = load i32, ptr %t280, !tbaa !23
  %t283 = add i32 %t281, 1
  %t286 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s6, i32 %t279, i32 %t283)
  store %"compiler/source:Span" %t286, ptr %l136
  br label %bb62
bb61:
  br label %bb67
bb62:
  %t287 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s6)
  store %"compiler/msgs:Msg" %t287, ptr %l137
  br label %bb63
bb63:
  %t288 = load ptr, ptr %l132, !tbaa !29
  %t289 = load %"compiler/source:Span", ptr %l136
  %t290 = load %"compiler/msgs:Msg", ptr %l137
  %t291 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t288, %"compiler/source:Span" %t289, %"compiler/msgs:Msg" %t290)
  store i64 %t291, ptr %l138
  br label %bb64
bb64:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t292, { i64, ptr } %t293)
  br label %bb65
bb65:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t297 = load %"compiler/source:Span", ptr %l1
  %t300 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t296, %"compiler/source:Span" %t297)
  store ptr %t300, ptr %l143
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t301 = load ptr, ptr %l143, !tbaa !29
  store ptr %t301, ptr %rv
  br label %ret
bb67:
  %t302 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t303 = load i32, ptr %t302, !tbaa !23
  %t305 = icmp sgt i32 %t303, 0
  br i1 %t305, label %bb68, label %bb69
bb68:
  %t307 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t307, ptr %l147, !tbaa !27
  %t308 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t309 = load i32, ptr %t308, !tbaa !23
  %t311 = sext i32 %t309 to i64
  %t313 = sub i64 %t311, 1
  %t315 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr i8, ptr %t316, i64 %t313
  %t318 = load i8, ptr %t317, !tbaa !32
  %t320 = icmp eq i8 %t318, 36
  br i1 %t320, label %bb70, label %bb71
bb69:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb78
bb70:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t323 = load i32, ptr %l5, !tbaa !23
  %t326 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t322, i32 %t323)
  store i32 %t326, ptr %l156
  br label %bb72
bb71:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb74
bb72:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t329 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t327)
  store i32 %t329, ptr %l158
  br label %bb73
bb73:
  %t330 = load i32, ptr %l156, !tbaa !23
  %t331 = load i32, ptr %l158, !tbaa !23
  %t332 = icmp eq i32 %t330, %t331
  store i1 %t332, ptr %l153, !tbaa !21
  br label %bb74
bb74:
  %t334 = load i1, ptr %l153, !tbaa !21
  br i1 %t334, label %bb75, label %bb76
bb75:
  store i1 true, ptr %l160, !tbaa !21
  br label %bb77
bb76:
  %t335 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t335, ptr %l161, !tbaa !27
  %t336 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t337 = load i32, ptr %t336, !tbaa !23
  %t339 = sext i32 %t337 to i64
  %t341 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i8, ptr %t342, i64 %t339
  %t344 = load i8, ptr %t343, !tbaa !32
  %t346 = icmp eq i8 %t344, 34
  store i1 %t346, ptr %l160, !tbaa !21
  br label %bb77
bb77:
  %t348 = load i1, ptr %l160, !tbaa !21
  store i1 %t348, ptr %l146, !tbaa !21
  br label %bb78
bb78:
  %t349 = load i1, ptr %l146, !tbaa !21
  br i1 %t349, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s7
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l166, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load %"compiler/source:Span", ptr %l2
  %t355 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %t351, %"compiler/source:Span" %t352, i64 1)
  store %"compiler/source:Span" %t355, ptr %l169
  br label %bb81
bb80:
  br label %bb86
bb81:
  %t356 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %s7)
  store %"compiler/msgs:Msg" %t356, ptr %l170
  br label %bb82
bb82:
  %t357 = load ptr, ptr %l166, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l169
  %t359 = load %"compiler/msgs:Msg", ptr %l170
  %t360 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t357, %"compiler/source:Span" %t358, %"compiler/msgs:Msg" %t359)
  store i64 %t360, ptr %l171
  br label %bb83
bb83:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t361, { i64, ptr } %t362)
  br label %bb84
bb84:
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t366 = load %"compiler/source:Span", ptr %l1
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t365, %"compiler/source:Span" %t366)
  store ptr %t369, ptr %l176
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t370 = load ptr, ptr %l176, !tbaa !29
  store ptr %t370, ptr %rv
  br label %ret
bb86:
  %t371 = load ptr, ptr %l0, !tbaa !29
  store ptr %t371, ptr %l177, !tbaa !29
  %t372 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t372, ptr %l178
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t374 = load i32, ptr %l5, !tbaa !23
  %t377 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t373, i32 %t374)
  store { i64, ptr } %t377, ptr %l181
  br label %bb87
bb87:
  %t378 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t379 = extractvalue { i64, ptr } %t378, 0
  %t380 = extractvalue { i64, ptr } %t378, 1
  %t381 = mul i64 %t379, 1
  %t382 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t381)
  call void @llvm.memcpy.p0.p0.i64(ptr %t382, ptr %t380, i64 %t381, i1 false)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t386 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %s0, ptr %s0, { i64, ptr } %t384)
  store %"compiler/msgs:Msg" %t386, ptr %l183
  br label %bb88
bb88:
  %t387 = load ptr, ptr %l177, !tbaa !29
  %t388 = load %"compiler/source:Span", ptr %l178
  %t389 = load %"compiler/msgs:Msg", ptr %l183
  %t390 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t387, %"compiler/source:Span" %t388, %"compiler/msgs:Msg" %t389)
  store i64 %t390, ptr %l184
  br label %bb89
bb89:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t392 = load { i64, ptr }, ptr %l4, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t391, { i64, ptr } %t392)
  br label %bb90
bb90:
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t396 = load %"compiler/source:Span", ptr %l1
  %t399 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t395, %"compiler/source:Span" %t396)
  store ptr %t399, ptr %l189
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  %t400 = load ptr, ptr %l189, !tbaa !29
  store ptr %t400, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallbackType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l48 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca i1
  %l69 = alloca i32
  %l73 = alloca i1
  %l76 = alloca i1
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load i32, ptr %l11
  %t13 = trunc i64 21 to i32
  %t14 = icmp eq i32 %t11, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l18, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l23
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l18, !tbaa !29
  %t35 = load i32, ptr %l23, !tbaa !23
  %t36 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t34, i32 %t35)
  store { i64, ptr } %t36, ptr %l24
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t40 = icmp sgt i64 %t38, 0
  store i1 %t40, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t42 = load i1, ptr %l15, !tbaa !21
  br i1 %t42, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l1, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l35
  br label %bb10
bb10:
  %t60 = load ptr, ptr %l30, !tbaa !29
  %t61 = load i32, ptr %l35, !tbaa !23
  %t62 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t60, i32 %t61)
  store { i64, ptr } %t62, ptr %l36
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t63, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  store i64 %t66, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t68 = load i64, ptr %l3, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb14:
  br label %bb15
bb15:
  %t76 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t76, ptr %l43, !tbaa !27
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i32, ptr %t80, i64 %t77
  %t82 = load i32, ptr %t81, !tbaa !33
  store i32 %t82, ptr %l5, !tbaa !23
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load i32, ptr %l5, !tbaa !23
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t88, ptr %l48
  br label %bb16
bb16:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb25
bb18:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i32, ptr %l5, !tbaa !23
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t90, i32 %t91)
  store i1 %t94, ptr %l52
  br label %bb19
bb19:
  %t95 = load i1, ptr %l52, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  %t103 = load i32, ptr %l5, !tbaa !23
  %t106 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t102, i32 %t103)
  store i32 %t106, ptr %l59
  br label %bb22
bb21:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb24
bb22:
  %t107 = load ptr, ptr %l54, !tbaa !29
  %t108 = load i32, ptr %l59, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t107, i32 %t108, i64 0)
  store i1 %t109, ptr %l60
  br label %bb23
bb23:
  %t110 = load i1, ptr %l60, !tbaa !21
  store i1 %t110, ptr %l53, !tbaa !21
  br label %bb24
bb24:
  %t111 = load i1, ptr %l53, !tbaa !21
  store i1 %t111, ptr %l49, !tbaa !21
  br label %bb25
bb25:
  %t112 = load i1, ptr %l49, !tbaa !21
  %t113 = xor i1 %t112, true
  br i1 %t113, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t116 = load i64, ptr %l3, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l3, !tbaa !24
  br label %bb12
bb30:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !29
  %t125 = getelementptr %"compiler/generic:Program", ptr %t123, i32 0, i32 2
  %t126 = load i32, ptr %l1, !tbaa !23
  %t129 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t125, i32 %t126)
  store i32 %t129, ptr %l69
  br label %bb31
bb31:
  %t130 = load i32, ptr %l69, !tbaa !23
  store i32 %t130, ptr %l6, !tbaa !23
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  br i1 %t135, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb35
bb33:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load i32, ptr %l6, !tbaa !23
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t137, i32 %t138)
  store i1 %t141, ptr %l76
  br label %bb34
bb34:
  %t142 = load i1, ptr %l76, !tbaa !21
  store i1 %t142, ptr %l73, !tbaa !21
  br label %bb35
bb35:
  %t143 = load i1, ptr %l73, !tbaa !21
  store i1 %t143, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCompare(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l16 = alloca ptr
  %l19 = alloca i64
  %l22 = alloca i64
  %l25 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/msgs:Msg"
  %l31 = alloca i64
  %l35 = alloca ptr
  %l38 = alloca i64
  %l43 = alloca ptr
  %l47 = alloca ptr
  %l51 = alloca %"compiler/check:errBind"
  %l55 = alloca { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }
  %l61 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca ptr
  %l70 = alloca ptr
  %l75 = alloca %"compiler/names:Ref"
  %l79 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca ptr
  %l87 = alloca ptr
  %l91 = alloca i1
  %l92 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l97 = alloca { i64, ptr }
  %l99 = alloca %"compiler/msgs:Msg"
  %l100 = alloca i64
  %l104 = alloca ptr
  %l107 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l111 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca i64
  %l115 = alloca ptr
  %l117 = alloca %"compiler/source:Span"
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca %"compiler/msgs:Msg"
  %l131 = alloca i64
  %l135 = alloca ptr
  %l140 = alloca ptr
  %l143 = alloca ptr
  %l147 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l4, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v2, ptr %t7, ptr %t8)
  store i64 %t11, ptr %l22
  br label %bb2
bb2:
  %t12 = load i64, ptr %l22, !tbaa !24
  store i64 %t12, ptr %l6, !tbaa !24
  %t13 = load i64, ptr %l5, !tbaa !24
  %t15 = icmp sge i64 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  store i1 %t19, ptr %l25, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l25, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l28, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l29
  %t24 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtComparedToCaught(ptr %s1)
  store %"compiler/msgs:Msg" %t24, ptr %l30
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t25 = load ptr, ptr %l28, !tbaa !29
  %t26 = load %"compiler/source:Span", ptr %l29
  %t27 = load %"compiler/msgs:Msg", ptr %l30
  %t28 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t25, %"compiler/source:Span" %t26, %"compiler/msgs:Msg" %t27)
  store i64 %t28, ptr %l31
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load %"compiler/source:Span", ptr %l1
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t29, %"compiler/source:Span" %t30, i32 %t31, i64 0)
  store ptr %t35, ptr %l35
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t36 = load ptr, ptr %l35, !tbaa !29
  store ptr %t36, ptr %rv
  br label %ret
bb11:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sge i64 %t37, 0
  br i1 %t39, label %bb12, label %bb13
bb12:
  %t41 = load i64, ptr %l5, !tbaa !24
  store i64 %t41, ptr %l38, !tbaa !24
  br label %bb14
bb13:
  %t43 = load i64, ptr %l6, !tbaa !24
  store i64 %t43, ptr %l38, !tbaa !24
  br label %bb14
bb14:
  %t45 = load i64, ptr %l38, !tbaa !24
  store i64 %t45, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp sge i64 %t46, 0
  br i1 %t48, label %bb15, label %bb16
bb15:
  %t50 = load ptr, ptr %l4, !tbaa !29
  store ptr %t50, ptr %l43, !tbaa !29
  br label %bb17
bb16:
  %t52 = load ptr, ptr %l3, !tbaa !29
  store ptr %t52, ptr %l43, !tbaa !29
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l43, !tbaa !29
  store ptr %t54, ptr %l8, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t55)
  store ptr %t57, ptr %l47
  br label %bb18
bb18:
  %t58 = load ptr, ptr %l47, !tbaa !29
  %t60 = getelementptr %"compiler/check:frame", ptr %t58, i32 0, i32 53
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t60, i64 %t61)
  store %"compiler/check:errBind" %t64, ptr %l51
  br label %bb19
bb19:
  %t65 = getelementptr %"compiler/check:errBind", ptr %l51, i32 0, i32 0
  %t66 = load i32, ptr %t65, !tbaa !23
  store i32 %t66, ptr %l9, !tbaa !23
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t69 = load ptr, ptr %l8, !tbaa !29
  %t70 = load ptr, ptr @__olang_prog_scope
  %t73 = call { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %t70, ptr %s0, ptr %t68, ptr %t69)
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t73, ptr %l55
  br label %bb20
bb20:
  %t74 = load { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l55
  store { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } %t74, ptr %l10
  %t75 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l10, i32 0, i32 0
  %t76 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t75
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t76, ptr %l11
  %t78 = getelementptr { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 }, ptr %l10, i32 0, i32 1
  %t79 = load i1, ptr %t78, !tbaa !21
  %t83 = xor i1 %t79, true
  br i1 %t83, label %bb21, label %bb22
bb21:
  %t85 = load ptr, ptr %l8, !tbaa !29
  %t86 = load ptr, ptr @__olang_prog_scope
  %t88 = call ptr @compiler_2fcheck_2eexprPath(ptr %t86, ptr %t85)
  store ptr %t88, ptr %l61
  br label %bb23
bb22:
  br label %bb45
bb23:
  %t89 = load ptr, ptr %l61, !tbaa !29
  store ptr %t89, ptr %l13, !tbaa !29
  %t90 = load ptr, ptr %l13, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  br i1 %t92, label %bb24, label %bb25
bb24:
  store i32 0, ptr %l64
  br label %bb28
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/check:Checker", ptr %t95, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/generic:Program", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  store ptr %t101, ptr %l68, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t102)
  store ptr %t104, ptr %l70
  br label %bb26
bb26:
  %t105 = load ptr, ptr %l70, !tbaa !29
  %t107 = getelementptr %"compiler/check:frame", ptr %t105, i32 0, i32 2
  %t108 = load i64, ptr %t107, !tbaa !24
  %t109 = load ptr, ptr %l13, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Path", ptr %t109, i32 0, i32 0
  %t112 = getelementptr %"compiler/source:Span", ptr %t111, i32 0, i32 0
  %t113 = load i32, ptr %t112, !tbaa !23
  %t114 = load ptr, ptr %l68, !tbaa !29
  %t117 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t114, i64 %t108, i32 %t113)
  store %"compiler/names:Ref" %t117, ptr %l75
  br label %bb27
bb27:
  %t118 = getelementptr %"compiler/names:Ref", ptr %l75, i32 0, i32 0
  %t119 = load i32, ptr %t118
  store i32 %t119, ptr %l64
  br label %bb28
bb28:
  %t121 = load i32, ptr %l64
  store i32 %t121, ptr %l14
  %t122 = load i32, ptr %l14
  %t124 = trunc i64 4 to i32
  %t125 = icmp eq i32 %t122, %t124
  br i1 %t125, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb31
bb30:
  %t127 = load i32, ptr %l14
  %t129 = trunc i64 5 to i32
  %t130 = icmp eq i32 %t127, %t129
  store i1 %t130, ptr %l79, !tbaa !21
  br label %bb31
bb31:
  %t132 = load i1, ptr %l79, !tbaa !21
  br i1 %t132, label %bb32, label %bb33
bb32:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  store ptr %t136, ptr %l83, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t137)
  store ptr %t139, ptr %l85
  br label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t140 = load ptr, ptr %l0, !tbaa !29
  store ptr %t140, ptr %l92, !tbaa !29
  %t141 = load ptr, ptr %l8, !tbaa !29
  %t142 = load ptr, ptr @__olang_prog_scope
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %t142, ptr %t141)
  store %"compiler/source:Span" %t144, ptr %l94
  br label %bb39
bb34:
  %t145 = load ptr, ptr %l85, !tbaa !29
  %t147 = getelementptr %"compiler/check:frame", ptr %t145, i32 0, i32 4
  store ptr %t147, ptr %l87, !tbaa !29
  %t148 = load ptr, ptr %l13, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  br i1 %t150, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_7af425f5cb399761_c8cadd9056f4b45)
  unreachable
bb36:
  br label %bb37
bb37:
  %t152 = load ptr, ptr %l13, !tbaa !29
  %t153 = load ptr, ptr @__olang_prog_scope
  %t154 = load ptr, ptr %l83, !tbaa !29
  %t155 = load ptr, ptr %l87, !tbaa !29
  %t157 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %t153, ptr %t154, ptr %t155, ptr %t152)
  store i1 %t157, ptr %l91
  br label %bb38
bb38:
  br label %bb43
bb39:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i32, ptr %l9, !tbaa !23
  %t162 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s4, ptr %t158, i32 %t159)
  store { i64, ptr } %t162, ptr %l97
  br label %bb40
bb40:
  %t163 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 0
  %t165 = extractvalue { i64, ptr } %t163, 1
  %t166 = mul i64 %t164, 1
  %t167 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t166)
  call void @llvm.memcpy.p0.p0.i64(ptr %t167, ptr %t165, i64 %t166, i1 false)
  %t168 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t167, 1
  %t171 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %s4, ptr %s4, { i64, ptr } %t169)
  store %"compiler/msgs:Msg" %t171, ptr %l99
  br label %bb41
bb41:
  %t172 = load ptr, ptr %l92, !tbaa !29
  %t173 = load %"compiler/source:Span", ptr %l94
  %t174 = load %"compiler/msgs:Msg", ptr %l99
  %t175 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t172, %"compiler/source:Span" %t173, %"compiler/msgs:Msg" %t174)
  store i64 %t175, ptr %l100
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb43:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t177 = load %"compiler/source:Span", ptr %l1
  %t178 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t182 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t176, %"compiler/source:Span" %t177, i32 %t178, i64 0)
  store ptr %t182, ptr %l104
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t183 = load ptr, ptr %l104, !tbaa !29
  store ptr %t183, ptr %rv
  br label %ret
bb45:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l7, !tbaa !24
  %t188 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNow(ptr %v0, ptr %s0, ptr %t184, i64 %t185)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t188, ptr %l107
  br label %bb46
bb46:
  %t189 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l107
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t189, ptr %l15
  %t190 = load ptr, ptr %l0, !tbaa !29
  %t194 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t190, ptr %l15, ptr %l11)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t194, ptr %l111
  br label %bb47
bb47:
  %t195 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  %t196 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t195, ptr %t196
  %t198 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %t196)
  store i64 %t198, ptr %l113
  br label %bb48
bb48:
  %t199 = load i64, ptr %l113, !tbaa !24
  %t200 = icmp eq i64 %t199, 0
  br i1 %t200, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s5
  %t202 = load ptr, ptr %l0, !tbaa !29
  store ptr %t202, ptr %l115, !tbaa !29
  %t203 = load ptr, ptr %l8, !tbaa !29
  %t204 = load ptr, ptr @__olang_prog_scope
  %t206 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %t204, ptr %t203)
  store %"compiler/source:Span" %t206, ptr %l117
  br label %bb51
bb50:
  br label %bb58
bb51:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l9, !tbaa !23
  %t211 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t207, i32 %t208)
  store { i64, ptr } %t211, ptr %l120
  br label %bb52
bb52:
  %t212 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  store { i64, ptr } %t218, ptr %l121, !tbaa !27
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t222 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s5, ptr %t219, ptr %l11)
  store { i64, ptr } %t222, ptr %l124
  br label %bb53
bb53:
  %t223 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  %t225 = extractvalue { i64, ptr } %t223, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  store { i64, ptr } %t229, ptr %l125, !tbaa !27
  %t230 = load ptr, ptr %l0, !tbaa !29
  %t233 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s5, ptr %t230, ptr %l15)
  store { i64, ptr } %t233, ptr %l128
  br label %bb54
bb54:
  %t234 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  %t236 = extractvalue { i64, ptr } %t234, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t241 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t244 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %s5, ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t241, { i64, ptr } %t242, { i64, ptr } %t240)
  store %"compiler/msgs:Msg" %t244, ptr %l130
  br label %bb55
bb55:
  %t245 = load ptr, ptr %l115, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l117
  %t247 = load %"compiler/msgs:Msg", ptr %l130
  %t248 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t245, %"compiler/source:Span" %t246, %"compiler/msgs:Msg" %t247)
  store i64 %t248, ptr %l131
  br label %bb56
bb56:
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l1
  %t251 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t249, %"compiler/source:Span" %t250, i32 %t251, i64 0)
  store ptr %t255, ptr %l135
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t256 = load ptr, ptr %l135, !tbaa !29
  store ptr %t256, ptr %rv
  br label %ret
bb58:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l1
  %t259 = load i64, ptr %l7, !tbaa !24
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtTest(ptr %v0, ptr %s0, ptr %t257, %"compiler/source:Span" %t258, i64 %t259, ptr %l11)
  store ptr %t264, ptr %l140
  br label %bb59
bb59:
  %t265 = load ptr, ptr %l140, !tbaa !29
  store ptr %t265, ptr %l16, !tbaa !29
  %t268 = trunc i64 77 to i32
  %t269 = icmp eq i32 %a2, %t268
  br i1 %t269, label %bb60, label %bb61
bb60:
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t272 = load %"compiler/source:Span", ptr %l1
  %t273 = load ptr, ptr %l16, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %t271, %"compiler/source:Span" %t272, ptr %t273)
  store ptr %t277, ptr %l147
  br label %bb62
bb61:
  %t278 = load ptr, ptr %l16, !tbaa !29
  store ptr %t278, ptr %l143, !tbaa !29
  br label %bb63
bb62:
  %t280 = load ptr, ptr %l147, !tbaa !29
  store ptr %t280, ptr %l143, !tbaa !29
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  %t281 = load ptr, ptr %l143, !tbaa !29
  store ptr %t281, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMatch(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i1, i1 }
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca { i1, i1 }
  %l29 = alloca %"compiler/source:Span"
  %l36 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/ast:Branch"
  %l46 = alloca %"compiler/ast:If"
  %l53 = alloca i64
  %l62 = alloca { i64, ptr }
  %l69 = alloca ptr
  %l71 = alloca %"compiler/source:Span"
  %l72 = alloca %"compiler/msgs:Msg"
  %l73 = alloca i64
  %l78 = alloca %"compiler/ast:Branch"
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca %"compiler/ast:If"
  %l92 = alloca %"compiler/source:Span"
  %l96 = alloca ptr
  %l101 = alloca %"compiler/ast:If"
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %t82 = alloca { i64, [4 x i64] }, align 8
  %t176 = alloca { i64, [4 x i64] }, align 8
  %t208 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  %t7 = call { i1, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %t1, %"compiler/source:Span" %a1, ptr %t3)
  store { i1, i1 } %t7, ptr %l14
  br label %bb1
bb1:
  %t8 = load { i1, i1 }, ptr %l14
  store { i1, i1 } %t8, ptr %l3
  %t9 = getelementptr { i1, i1 }, ptr %l3, i32 0, i32 0
  %t10 = load i1, ptr %t9, !tbaa !21
  %t12 = getelementptr { i1, i1 }, ptr %l3, i32 0, i32 1
  %t13 = load i1, ptr %t12, !tbaa !21
  store i1 %t13, ptr %l5, !tbaa !21
  %t17 = xor i1 %t10, true
  br i1 %t17, label %bb2, label %bb3
bb2:
  br label %ret
bb3:
  br label %bb4
bb4:
  store ptr null, ptr %l6, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Match", ptr %t19, i32 0, i32 4
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Match", ptr %t28, i32 0, i32 4
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb7, label %bb8
bb6:
  br label %bb18
bb7:
  call void @__olang_check_failed(ptr @olang_loc_35d0274d34665ca7_d8b5deabc24f5253)
  unreachable
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Match", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Case", ptr %t38, i32 0, i32 0
  %t42 = load %"compiler/source:Span", ptr %t41
  store %"compiler/source:Span" %t42, ptr %l29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Match", ptr %t43, i32 0, i32 4
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_35d0274d34665ca7_d8b5deabc24f5253)
  unreachable
bb11:
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:Match", ptr %t50, i32 0, i32 4
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Case", ptr %t53, i32 0, i32 0
  %t57 = load %"compiler/source:Span", ptr %t56
  store %"compiler/source:Span" %t57, ptr %l36
  %t58 = load ptr, ptr %l2, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Match", ptr %t58, i32 0, i32 4
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = icmp eq ptr %t61, null
  br i1 %t63, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_35d0274d34665ca7_d8b5deabc24f5253)
  unreachable
bb14:
  br label %bb15
bb15:
  %t65 = load ptr, ptr %l2, !tbaa !29
  %t67 = getelementptr %"compiler/ast:Match", ptr %t65, i32 0, i32 4
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t71 = getelementptr %"compiler/ast:Case", ptr %t68, i32 0, i32 4
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t73 = load %"compiler/source:Span", ptr %l36
  %t75 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t73, { i64, ptr } %t72, i64 -1)
  store %"compiler/ast:Branch" %t75, ptr %l44
  br label %bb16
bb16:
  %t76 = load %"compiler/ast:Branch", ptr %l44
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t76, ptr %t77
  %t79 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr null, ptr %t77, ptr null)
  store %"compiler/ast:If" %t79, ptr %l46
  br label %bb17
bb17:
  %t80 = load %"compiler/ast:If", ptr %l46
  %t81 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t80, ptr %t81
  store { i64, [4 x i64] } zeroinitializer, ptr %t82
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 0
  store i64 5, ptr %t83
  %t84 = load %"compiler/source:Span", ptr %l29
  %t85 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t84, 0
  %t87 = insertvalue { %"compiler/source:Span", ptr } %t85, ptr %t81, 1
  %t88 = getelementptr { i64, [4 x i64] }, ptr %t82, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t87, ptr %t88
  %t89 = load { i64, [4 x i64] }, ptr %t82
  %t91 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t89, ptr %t91
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t95 = load i1, ptr %l5, !tbaa !21
  %t99 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %t93, ptr %t94, i1 %t95)
  store i64 %t99, ptr %l53
  br label %bb19
bb19:
  %t100 = load i64, ptr %l53, !tbaa !24
  store i64 %t100, ptr %l7, !tbaa !24
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Match", ptr %t101, i32 0, i32 3
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t108 = sub i64 %t106, 1
  store i64 %t108, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t110 = load i64, ptr %l8, !tbaa !24
  %t112 = icmp sge i64 %t110, 0
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb37
bb22:
  br label %bb23
bb23:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/ast:Match", ptr %t116, i32 0, i32 3
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l62, !tbaa !27
  %t120 = load i64, ptr %l8, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr ptr, ptr %t123, i64 %t120
  %t125 = load ptr, ptr %t124, !tbaa !39
  store ptr %t125, ptr %l9, !tbaa !29
  %t127 = load ptr, ptr %l9, !tbaa !29
  %t129 = getelementptr %"compiler/ast:Case", ptr %t127, i32 0, i32 5
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = icmp eq ptr %t130, null
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l69, !tbaa !29
  %t137 = load ptr, ptr %l9, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Case", ptr %t137, i32 0, i32 0
  %t140 = load %"compiler/source:Span", ptr %t139
  store %"compiler/source:Span" %t140, ptr %l71
  %t141 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %s5)
  store %"compiler/msgs:Msg" %t141, ptr %l72
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t142 = load ptr, ptr %l69, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l71
  %t144 = load %"compiler/msgs:Msg", ptr %l72
  %t145 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t142, %"compiler/source:Span" %t143, %"compiler/msgs:Msg" %t144)
  store i64 %t145, ptr %l73
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  %t146 = load ptr, ptr %l9, !tbaa !29
  %t148 = getelementptr %"compiler/ast:Case", ptr %t146, i32 0, i32 0
  %t149 = load %"compiler/source:Span", ptr %t148
  %t150 = load ptr, ptr %l9, !tbaa !29
  %t152 = getelementptr %"compiler/ast:Case", ptr %t150, i32 0, i32 4
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t156 = call %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t149, { i64, ptr } %t153, i64 -1)
  store %"compiler/ast:Branch" %t156, ptr %l78
  br label %bb29
bb29:
  %t157 = load %"compiler/ast:Branch", ptr %l78
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Branch" %t157, ptr %t158
  store ptr %t158, ptr %l10, !tbaa !29
  %t160 = load i64, ptr %l8, !tbaa !24
  %t161 = load i64, ptr %l7, !tbaa !24
  %t164 = icmp eq i64 %t160, %t161
  br i1 %t164, label %bb30, label %bb31
bb30:
  %t166 = load ptr, ptr %l9, !tbaa !29
  %t168 = getelementptr %"compiler/ast:Case", ptr %t166, i32 0, i32 0
  %t169 = load %"compiler/source:Span", ptr %t168
  store %"compiler/source:Span" %t169, ptr %l84
  %t170 = load ptr, ptr %l10, !tbaa !29
  %t173 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr null, ptr %t170, ptr null)
  store %"compiler/ast:If" %t173, ptr %l87
  br label %bb32
bb31:
  br label %bb33
bb32:
  %t174 = load %"compiler/ast:If", ptr %l87
  %t175 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t174, ptr %t175
  store { i64, [4 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 0
  store i64 5, ptr %t177
  %t178 = load %"compiler/source:Span", ptr %l84
  %t179 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t178, 0
  %t181 = insertvalue { %"compiler/source:Span", ptr } %t179, ptr %t175, 1
  %t182 = getelementptr { i64, [4 x i64] }, ptr %t176, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t181, ptr %t182
  %t183 = load { i64, [4 x i64] }, ptr %t176
  %t185 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t183, ptr %t185
  store ptr %t185, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb33:
  %t187 = load ptr, ptr %l9, !tbaa !29
  %t189 = getelementptr %"compiler/ast:Case", ptr %t187, i32 0, i32 0
  %t190 = load %"compiler/source:Span", ptr %t189
  store %"compiler/source:Span" %t190, ptr %l92
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t192 = load ptr, ptr %l2, !tbaa !29
  %t193 = load ptr, ptr %l9, !tbaa !29
  %t197 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v1, ptr %t191, ptr %t192, ptr %t193)
  store ptr %t197, ptr %l96
  br label %bb34
bb34:
  %t198 = load ptr, ptr %l96, !tbaa !29
  %t199 = load ptr, ptr %l10, !tbaa !29
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t205 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t198, ptr %t199, ptr %t201)
  store %"compiler/ast:If" %t205, ptr %l101
  br label %bb35
bb35:
  %t206 = load %"compiler/ast:If", ptr %l101
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t206, ptr %t207
  store { i64, [4 x i64] } zeroinitializer, ptr %t208
  %t209 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 0
  store i64 5, ptr %t209
  %t210 = load %"compiler/source:Span", ptr %l92
  %t211 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t210, 0
  %t213 = insertvalue { %"compiler/source:Span", ptr } %t211, ptr %t207, 1
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t213, ptr %t214
  %t215 = load { i64, [4 x i64] }, ptr %t208
  %t217 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t215, ptr %t217
  store ptr %t217, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb36:
  %t219 = load i64, ptr %l8, !tbaa !24
  %t221 = sub i64 %t219, 1
  store i64 %t221, ptr %l8, !tbaa !24
  br label %bb20
bb37:
  %t223 = load ptr, ptr %l6, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  %t227 = xor i1 %t225, true
  br i1 %t227, label %bb38, label %bb39
bb38:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %t229, ptr %t230)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMisused(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca i64
  %l30 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca i64
  %l50 = alloca %"compiler/check:errBind"
  %l57 = alloca ptr
  %l58 = alloca %"compiler/source:Span"
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t11)
  store ptr %t13, ptr %l13
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t14 = load ptr, ptr %l13, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 54
  %t17 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t16, i64 %t17, i1 true)
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l17, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t21, ptr %l18
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i32, ptr %l2, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s1, ptr %t22, i32 %t23)
  store { i64, ptr } %t26, ptr %l21
  br label %bb6
bb6:
  %t27 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr %l2, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t34, i32 %t35)
  store { i64, ptr } %t38, ptr %l25
  br label %bb7
bb7:
  %t39 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t41 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNotAValue(ptr %s1, ptr %v0, ptr %s1, { i64, ptr } %t39, { i64, ptr } %t40)
  store %"compiler/msgs:Msg" %t41, ptr %l26
  br label %bb8
bb8:
  %t42 = load ptr, ptr %l17, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l18
  %t44 = load %"compiler/msgs:Msg", ptr %l26
  %t45 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t42, %"compiler/source:Span" %t43, %"compiler/msgs:Msg" %t44)
  store i64 %t45, ptr %l27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t47)
  store ptr %t49, ptr %l30
  br label %bb11
bb11:
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t52 = getelementptr %"compiler/check:frame", ptr %t50, i32 0, i32 19
  %t53 = load i64, ptr %t52, !tbaa !24
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = icmp sge i64 %t55, 0
  %t59 = xor i1 %t57, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb14:
  br label %bb15
bb15:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/check:Checker", ptr %t61, i32 0, i32 13
  %t64 = load i64, ptr %l4, !tbaa !24
  %t67 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store ptr %t67, ptr %l39
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l39, !tbaa !29
  store ptr %t68, ptr %l5, !tbaa !29
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/check:frame", ptr %t69, i32 0, i32 53
  %t73 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t71)
  store i64 %t73, ptr %l42
  br label %bb17
bb17:
  %t74 = load i64, ptr %l42, !tbaa !24
  %t75 = sub i64 %t74, 1
  store i64 %t75, ptr %l6, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = icmp sge i64 %t77, 0
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s4)
  br label %bb32
bb20:
  br label %bb21
bb21:
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t85 = getelementptr %"compiler/check:frame", ptr %t83, i32 0, i32 53
  %t86 = load i64, ptr %l6, !tbaa !24
  %t89 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t85, i64 %t86)
  store %"compiler/check:errBind" %t89, ptr %l50
  br label %bb22
bb22:
  %t90 = getelementptr %"compiler/check:errBind", ptr %l50, i32 0, i32 0
  %t91 = load i32, ptr %t90, !tbaa !23
  %t92 = load i32, ptr %l2, !tbaa !23
  %t95 = icmp eq i32 %t91, %t92
  br i1 %t95, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 54
  %t100 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t99, i64 %t100, i1 true)
  br label %bb25
bb24:
  br label %bb30
bb25:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t104, ptr %l58
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t106 = load i32, ptr %l2, !tbaa !23
  %t109 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t105, i32 %t106)
  store { i64, ptr } %t109, ptr %l61
  br label %bb26
bb26:
  %t110 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  %t112 = extractvalue { i64, ptr } %t110, 1
  %t113 = mul i64 %t111, 1
  %t114 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t113)
  call void @llvm.memcpy.p0.p0.i64(ptr %t114, ptr %t112, i64 %t113, i1 false)
  %t115 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t116 = insertvalue { i64, ptr } %t115, ptr %t114, 1
  store { i64, ptr } %t116, ptr %l62, !tbaa !27
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t117, i32 %t118)
  store { i64, ptr } %t121, ptr %l65
  br label %bb27
bb27:
  %t122 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t124 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaptured(ptr %s5, ptr %v0, ptr %s5, { i64, ptr } %t122, { i64, ptr } %t123)
  store %"compiler/msgs:Msg" %t124, ptr %l66
  br label %bb28
bb28:
  %t125 = load ptr, ptr %l57, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l58
  %t127 = load %"compiler/msgs:Msg", ptr %l66
  %t128 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t125, %"compiler/source:Span" %t126, %"compiler/msgs:Msg" %t127)
  store i64 %t128, ptr %l67
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  %t130 = load i64, ptr %l6, !tbaa !24
  %t132 = sub i64 %t130, 1
  store i64 %t132, ptr %l6, !tbaa !24
  br label %bb18
bb32:
  %t134 = load ptr, ptr %l5, !tbaa !29
  %t136 = getelementptr %"compiler/check:frame", ptr %t134, i32 0, i32 19
  %t137 = load i64, ptr %t136, !tbaa !24
  store i64 %t137, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  br label %bb12
bb34:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtTest(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l35 = alloca ptr
  %l38 = alloca ptr
  %l42 = alloca %"compiler/check:errBind"
  %l44 = alloca { i64, ptr }
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca %"compiler/source:Span"
  %l54 = alloca %"compiler/check:errBind"
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l71 = alloca { i64, ptr }
  %l78 = alloca i32
  %l84 = alloca i64
  %l87 = alloca i64
  %l108 = alloca { i64, ptr }
  %l111 = alloca i32
  %l122 = alloca { i64, ptr }
  %l125 = alloca i64
  %l128 = alloca i64
  %l134 = alloca i64
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca i32
  %l143 = alloca ptr
  %l147 = alloca ptr
  %l149 = alloca ptr
  %l150 = alloca ptr
  %l151 = alloca %"compiler/source:Span"
  %l152 = alloca i32
  %l153 = alloca i32
  %l154 = alloca ptr
  %l160 = alloca ptr
  %l162 = alloca ptr
  %l168 = alloca i64
  %l174 = alloca i64
  %l177 = alloca i64
  %l196 = alloca i64
  %l200 = alloca ptr
  %l201 = alloca %"compiler/source:Span"
  %l202 = alloca i32
  %l203 = alloca i32
  %l204 = alloca ptr
  %l213 = alloca ptr
  %l215 = alloca ptr
  %l218 = alloca ptr
  %l228 = alloca ptr
  %l236 = alloca ptr
  %l246 = alloca ptr
  %l258 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l35
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l35, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 2
  store ptr %t10, ptr %l38, !tbaa !29
  %t11 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 53
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t13, i64 %t14)
  store %"compiler/check:errBind" %t17, ptr %l42
  br label %bb2
bb2:
  %t18 = getelementptr %"compiler/check:errBind", ptr %l42, i32 0, i32 2
  %t19 = load i32, ptr %t18, !tbaa !23
  %t20 = load ptr, ptr %l38, !tbaa !29
  %t22 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t20, i32 %t19)
  store { i64, ptr } %t22, ptr %l44
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t23, ptr %l5, !tbaa !27
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t31 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t29, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t31, ptr %l48
  br label %bb4
bb4:
  %t32 = load i32, ptr %l48, !tbaa !23
  store i32 %t32, ptr %l6, !tbaa !23
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l49, !tbaa !29
  %t34 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t34, ptr %l50
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 53
  %t38 = load i64, ptr %l2, !tbaa !24
  %t41 = call %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/check:errBind" %t41, ptr %l54
  br label %bb5
bb5:
  %t42 = getelementptr %"compiler/check:errBind", ptr %l54, i32 0, i32 1
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load ptr, ptr %l49, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l50
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t44, %"compiler/source:Span" %t45, i64 %t43)
  store ptr %t47, ptr %l56
  br label %bb6
bb6:
  %t48 = load ptr, ptr %l56, !tbaa !29
  store ptr %t48, ptr %l7, !tbaa !29
  store ptr null, ptr %l8, !tbaa !29
  store ptr %a3, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t51 = load ptr, ptr %l9, !tbaa !29
  %t52 = load i64, ptr %l10, !tbaa !24
  %t55 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v1, ptr %t51, i64 %t52)
  %t56 = extractvalue { i32, { i64, ptr } } %t55, 1
  %t57 = extractvalue { i32, { i64, ptr } } %t55, 0
  store i32 %t57, ptr %l62
  %t58 = icmp ne i32 %t57, 0
  br i1 %t58, label %bb9, label %ok.59
ok.59:
  store { i64, ptr } %t56, ptr %l61
  br label %bb8
bb8:
  %t60 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t60, ptr %l58, !tbaa !27
  br label %bb13
bb9:
  %t61 = load i32, ptr %l62, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_73076eedda527293_e224d565c24cbdcf)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb80
bb13:
  %t66 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t66, ptr %l11, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t71 = load i64, ptr %l13, !tbaa !24
  %t72 = load i64, ptr %l12, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb16:
  br label %bb17
bb17:
  %t79 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t79, ptr %l71, !tbaa !27
  %t80 = load i64, ptr %l13, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 %t80
  %t85 = load i32, ptr %t84, !tbaa !33
  store i32 %t85, ptr %l14, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t92 = getelementptr %"compiler/generic:Program", ptr %t90, i32 0, i32 2
  %t93 = load i32, ptr %l14, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t92, i32 %t93)
  store i32 %t96, ptr %l78
  br label %bb18
bb18:
  %t97 = load i32, ptr %l78, !tbaa !23
  store i32 %t97, ptr %l15, !tbaa !23
  store i64 -1, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t98 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  store i64 %t100, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t102 = load i64, ptr %l18, !tbaa !24
  %t103 = load i64, ptr %l17, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb19, label %bb20
bb19:
  %t108 = load i64, ptr %l19, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb21, label %bb22
bb20:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb24
bb21:
  %t112 = load i64, ptr %l18, !tbaa !24
  %t113 = load i64, ptr %l17, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l19, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l19, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l87, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l87, !tbaa !24
  br label %bb23
bb23:
  %t128 = load i64, ptr %l87, !tbaa !24
  store i64 %t128, ptr %l84, !tbaa !24
  br label %bb24
bb24:
  %t129 = load i64, ptr %l84, !tbaa !24
  store i64 %t129, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t130 = load i64, ptr %l21, !tbaa !24
  %t131 = load i64, ptr %l20, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t138 = load i64, ptr %l17, !tbaa !24
  %t139 = load i64, ptr %l21, !tbaa !24
  %t140 = load i64, ptr %l19, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l22, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t154, ptr %l108, !tbaa !27
  %t155 = load i64, ptr %l22, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t155
  %t160 = load i32, ptr %t159, !tbaa !33
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t153, i32 %t160)
  store i32 %t163, ptr %l111
  br label %bb29
bb29:
  %t164 = load i32, ptr %l15, !tbaa !23
  %t165 = load i32, ptr %l111, !tbaa !23
  %t167 = icmp eq i32 %t165, %t164
  br i1 %t167, label %bb30, label %bb31
bb30:
  %t169 = load i64, ptr %l22, !tbaa !24
  store i64 %t169, ptr %l16, !tbaa !24
  br label %bb32
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  br label %bb33
bb33:
  %t171 = load i64, ptr %l21, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l21, !tbaa !24
  br label %bb25
bb34:
  %t175 = load i64, ptr %l16, !tbaa !24
  %t177 = icmp slt i64 %t175, 0
  br i1 %t177, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb77
bb36:
  br label %bb37
bb37:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t185, ptr %l122, !tbaa !27
  %t186 = load i64, ptr %l16, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i32, ptr %t189, i64 %t186
  %t191 = load i32, ptr %t190, !tbaa !33
  %t194 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t184, i32 %t191)
  store i64 %t194, ptr %l125
  br label %bb38
bb38:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load i32, ptr %l15, !tbaa !23
  %t199 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t195, i32 %t196)
  store i64 %t199, ptr %l128
  br label %bb39
bb39:
  %t200 = load i64, ptr %l125, !tbaa !65
  %t201 = load i64, ptr %l128, !tbaa !65
  %t202 = and i64 %t200, %t201
  store i64 %t202, ptr %l23, !tbaa !65
  store ptr null, ptr %l24, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/check:Checker", ptr %t204, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !29
  %t209 = getelementptr %"compiler/generic:Program", ptr %t207, i32 0, i32 2
  %t210 = load i32, ptr %l14, !tbaa !23
  %t213 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t209, i32 %t210)
  store i64 %t213, ptr %l134
  br label %bb40
bb40:
  %t214 = load i64, ptr %l23, !tbaa !65
  %t215 = load i64, ptr %l134, !tbaa !65
  %t217 = and i64 %t215, %t214
  %t218 = load i64, ptr %l23, !tbaa !65
  %t221 = icmp eq i64 %t217, %t218
  br i1 %t221, label %bb41, label %bb42
bb41:
  %t223 = load ptr, ptr %l0, !tbaa !29
  store ptr %t223, ptr %l139, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t224, ptr %l140
  %t225 = load i32, ptr %l6, !tbaa !23
  store i32 %t225, ptr %l141, !tbaa !23
  store i32 9, ptr %l142
  %t226 = load ptr, ptr %l7, !tbaa !29
  store ptr %t226, ptr %l143, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l1
  %t229 = load i32, ptr %l6, !tbaa !23
  %t233 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t227, %"compiler/source:Span" %t228, i32 %t229, i64 16)
  store ptr %t233, ptr %l147
  br label %bb43
bb42:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  %t240 = load i32, ptr %l14, !tbaa !23
  %t243 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t239, i32 %t240)
  store i64 %t243, ptr %l168
  br label %bb47
bb43:
  %t244 = load ptr, ptr %l147, !tbaa !29
  %t245 = load ptr, ptr %l139, !tbaa !29
  %t246 = load %"compiler/source:Span", ptr %l140
  %t247 = load i32, ptr %l141, !tbaa !23
  %t248 = load i32, ptr %l142
  %t249 = load ptr, ptr %l143, !tbaa !29
  %t251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t245, %"compiler/source:Span" %t246, i32 %t247, i32 %t248, ptr %t249, ptr %t244)
  store ptr %t251, ptr %l149
  br label %bb44
bb44:
  %t252 = load ptr, ptr %l149, !tbaa !29
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l150, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t254, ptr %l151
  %t255 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t255, ptr %l152, !tbaa !23
  store i32 13, ptr %l153
  store ptr %t252, ptr %l154, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l1
  %t259 = load i32, ptr %l6, !tbaa !23
  %t260 = load i64, ptr %l16, !tbaa !24
  %t262 = add i64 %t260, 1
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259, i64 %t262)
  store ptr %t267, ptr %l160
  br label %bb45
bb45:
  %t268 = load ptr, ptr %l160, !tbaa !29
  %t269 = load ptr, ptr %l150, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l151
  %t271 = load i32, ptr %l152, !tbaa !23
  %t272 = load i32, ptr %l153
  %t273 = load ptr, ptr %l154, !tbaa !29
  %t275 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t269, %"compiler/source:Span" %t270, i32 %t271, i32 %t272, ptr %t273, ptr %t268)
  store ptr %t275, ptr %l162
  br label %bb46
bb46:
  %t276 = load ptr, ptr %l162, !tbaa !29
  store ptr %t276, ptr %l24, !tbaa !29
  br label %bb69
bb47:
  %t278 = load i64, ptr %l23, !tbaa !65
  %t279 = load i64, ptr %l168, !tbaa !65
  %t281 = and i64 %t279, %t278
  store i64 %t281, ptr %l26, !tbaa !65
  store i64 0, ptr %l27, !tbaa !24
  store i64 64, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t283 = load i64, ptr %l28, !tbaa !24
  %t284 = load i64, ptr %l27, !tbaa !24
  %t287 = icmp sgt i64 %t283, %t284
  br i1 %t287, label %bb48, label %bb49
bb48:
  %t289 = load i64, ptr %l29, !tbaa !24
  %t291 = icmp sgt i64 %t289, 0
  br i1 %t291, label %bb50, label %bb51
bb49:
  store i64 0, ptr %l174, !tbaa !24
  br label %bb53
bb50:
  %t293 = load i64, ptr %l28, !tbaa !24
  %t294 = load i64, ptr %l27, !tbaa !24
  %t297 = sub i64 %t293, %t294
  %t298 = load i64, ptr %l29, !tbaa !24
  %t301 = add i64 %t297, %t298
  %t303 = sub i64 %t301, 1
  %t304 = load i64, ptr %l29, !tbaa !24
  %t307 = sdiv i64 %t303, %t304
  store i64 %t307, ptr %l177, !tbaa !24
  br label %bb52
bb51:
  store i64 0, ptr %l177, !tbaa !24
  br label %bb52
bb52:
  %t309 = load i64, ptr %l177, !tbaa !24
  store i64 %t309, ptr %l174, !tbaa !24
  br label %bb53
bb53:
  %t310 = load i64, ptr %l174, !tbaa !24
  store i64 %t310, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t311 = load i64, ptr %l31, !tbaa !24
  %t312 = load i64, ptr %l30, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  %t317 = xor i1 %t315, true
  br i1 %t317, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s12)
  br label %bb68
bb56:
  br label %bb57
bb57:
  %t319 = load i64, ptr %l27, !tbaa !24
  %t320 = load i64, ptr %l31, !tbaa !24
  %t321 = load i64, ptr %l29, !tbaa !24
  %t324 = mul i64 %t320, %t321
  %t327 = add i64 %t319, %t324
  store i64 %t327, ptr %l32, !tbaa !24
  %t329 = load i64, ptr %l26, !tbaa !65
  %t330 = load i64, ptr %l32, !tbaa !24
  store i64 %t330, ptr %l196, !tbaa !24
  %t331 = load i64, ptr %l196, !tbaa !24
  %t332 = load i64, ptr %l196, !tbaa !24
  %t333 = shl i64 1, %t332
  %t336 = and i64 %t329, %t333
  %t338 = icmp eq i64 %t336, 0
  br i1 %t338, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb67
bb59:
  br label %bb60
bb60:
  %t340 = load ptr, ptr %l0, !tbaa !29
  store ptr %t340, ptr %l200, !tbaa !29
  %t341 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t341, ptr %l201
  %t342 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t342, ptr %l202, !tbaa !23
  store i32 13, ptr %l203
  %t343 = load ptr, ptr %l7, !tbaa !29
  store ptr %t343, ptr %l204, !tbaa !29
  %t344 = load ptr, ptr %l0, !tbaa !29
  %t345 = load %"compiler/source:Span", ptr %l1
  %t346 = load i32, ptr %l6, !tbaa !23
  %t347 = load i64, ptr %l16, !tbaa !24
  %t349 = add i64 %t347, 1
  %t351 = shl i64 %t349, 16
  %t352 = load i64, ptr %l32, !tbaa !24
  %t355 = or i64 %t351, %t352
  %t360 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t344, %"compiler/source:Span" %t345, i32 %t346, i64 %t355)
  store ptr %t360, ptr %l213
  br label %bb61
bb61:
  %t361 = load ptr, ptr %l213, !tbaa !29
  %t362 = load ptr, ptr %l200, !tbaa !29
  %t363 = load %"compiler/source:Span", ptr %l201
  %t364 = load i32, ptr %l202, !tbaa !23
  %t365 = load i32, ptr %l203
  %t366 = load ptr, ptr %l204, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t362, %"compiler/source:Span" %t363, i32 %t364, i32 %t365, ptr %t366, ptr %t361)
  store ptr %t368, ptr %l215
  br label %bb62
bb62:
  %t369 = load ptr, ptr %l215, !tbaa !29
  store ptr %t369, ptr %l33, !tbaa !29
  %t370 = load ptr, ptr %l24, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb63, label %bb64
bb63:
  %t374 = load ptr, ptr %l33, !tbaa !29
  store ptr %t374, ptr %l218, !tbaa !29
  br label %bb66
bb64:
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t378 = load %"compiler/source:Span", ptr %l1
  %t379 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t380 = load ptr, ptr %l24, !tbaa !29
  %t381 = load ptr, ptr %l33, !tbaa !29
  %t389 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t377, %"compiler/source:Span" %t378, i32 %t379, i32 11, ptr %t380, ptr %t381)
  store ptr %t389, ptr %l228
  br label %bb65
bb65:
  %t390 = load ptr, ptr %l228, !tbaa !29
  store ptr %t390, ptr %l218, !tbaa !29
  br label %bb66
bb66:
  %t392 = load ptr, ptr %l218, !tbaa !29
  store ptr %t392, ptr %l24, !tbaa !29
  call void @__olang_scope_close(ptr %s12)
  br label %bb67
bb67:
  %t393 = load i64, ptr %l31, !tbaa !24
  %t395 = add i64 %t393, 1
  store i64 %t395, ptr %l31, !tbaa !24
  br label %bb54
bb68:
  br label %bb69
bb69:
  %t397 = load ptr, ptr %l24, !tbaa !29
  %t399 = icmp eq ptr %t397, null
  br i1 %t399, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s3)
  br label %bb77
bb71:
  br label %bb72
bb72:
  %t401 = load ptr, ptr %l8, !tbaa !29
  %t403 = icmp eq ptr %t401, null
  br i1 %t403, label %bb73, label %bb74
bb73:
  %t405 = load ptr, ptr %l24, !tbaa !29
  store ptr %t405, ptr %l236, !tbaa !29
  br label %bb76
bb74:
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t409 = load %"compiler/source:Span", ptr %l1
  %t410 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t411 = load ptr, ptr %l8, !tbaa !29
  %t412 = load ptr, ptr %l24, !tbaa !29
  %t420 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t408, %"compiler/source:Span" %t409, i32 %t410, i32 11, ptr %t411, ptr %t412)
  store ptr %t420, ptr %l246
  br label %bb75
bb75:
  %t421 = load ptr, ptr %l246, !tbaa !29
  store ptr %t421, ptr %l236, !tbaa !29
  br label %bb76
bb76:
  %t423 = load ptr, ptr %l236, !tbaa !29
  store ptr %t423, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s3)
  br label %bb77
bb77:
  %t424 = load i64, ptr %l13, !tbaa !24
  %t426 = add i64 %t424, 1
  store i64 %t426, ptr %l13, !tbaa !24
  br label %bb14
bb78:
  %t428 = load i64, ptr %l10, !tbaa !24
  %t429 = load i64, ptr %l12, !tbaa !24
  %t432 = add i64 %t428, %t429
  store i64 %t432, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb79
bb79:
  br label %bb7
bb80:
  %t434 = load ptr, ptr %l8, !tbaa !29
  %t436 = icmp eq ptr %t434, null
  br i1 %t436, label %bb81, label %bb82
bb81:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  %t440 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t444 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t438, %"compiler/source:Span" %t439, i32 %t440, i64 0)
  store ptr %t444, ptr %l258
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t445 = load ptr, ptr %l258, !tbaa !29
  store ptr %t445, ptr %rv
  br label %ret
bb84:
  %t446 = load ptr, ptr %l8, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t446, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 47
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d4, i32 0, i32 1) }, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 47
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 47
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckDtor(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l17 = alloca i32
  %l21 = alloca ptr
  %l26 = alloca i64
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca %"compiler/generic:Context"
  %l38 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca %"compiler/source:Span"
  %l41 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l49 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca %"compiler/source:Span"
  %l56 = alloca { i64, ptr }
  %l60 = alloca i64
  %l62 = alloca ptr
  %l69 = alloca ptr
  %l73 = alloca ptr
  %l75 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca i1
  %l94 = alloca ptr
  %l102 = alloca i64
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca i32
  %l109 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca %"compiler/msgs:Msg"
  %l123 = alloca i64
  %l127 = alloca ptr
  %l132 = alloca %"compiler/typed:Block"
  %l135 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t95 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l3, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = load i32, ptr %l3, !tbaa !23
  %t19 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t15, i32 %t16)
  store ptr %t19, ptr %l21
  br label %bb2
bb2:
  %t20 = load ptr, ptr %l21, !tbaa !29
  store ptr %t20, ptr %l4, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = getelementptr %"compiler/generic:Program", ptr %t24, i32 0, i32 2
  %t27 = load i32, ptr %l3, !tbaa !23
  %t30 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t26, i32 %t27)
  store i64 %t30, ptr %l26
  br label %bb3
bb3:
  %t31 = load i64, ptr %l26, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t32, i64 %a1, i64 %t31, i32 %t35, i32 0)
  store ptr %t40, ptr %l31
  br label %bb4
bb4:
  %t41 = load ptr, ptr %l31, !tbaa !29
  store ptr %t41, ptr %l32, !tbaa !29
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v0, ptr %t46, i32 %t47)
  store %"compiler/generic:Context" %t50, ptr %l36
  br label %bb5
bb5:
  %t51 = load %"compiler/generic:Context", ptr %l36
  %t52 = load ptr, ptr %l32, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t52, i32 0, i32 4
  store %"compiler/generic:Context" %t51, ptr %t53
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t54)
  store ptr %t56, ptr %l38
  br label %bb6
bb6:
  store i32 0, ptr %l39
  %t57 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t57, ptr %l40
  br label %bb7
bb7:
  %t58 = load ptr, ptr %l38, !tbaa !29
  %t59 = load i32, ptr %l39
  %t60 = load %"compiler/source:Span", ptr %l40
  %t61 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t58, i32 -1, i32 %t59, %"compiler/source:Span" %t60)
  store i32 %t61, ptr %l41
  br label %bb8
bb8:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/check:Checker", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/generic:Program", ptr %t71, i32 0, i32 2
  store ptr %t73, ptr %l47, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l49
  br label %bb9
bb9:
  %t77 = load ptr, ptr %l49, !tbaa !29
  %t79 = getelementptr %"compiler/typed:Body", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %t79, !tbaa !23
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t81, i32 %t80)
  store i32 %t83, ptr %l52
  br label %bb10
bb10:
  %t84 = load ptr, ptr %l44, !tbaa !29
  %t85 = load i32, ptr %l52, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t84, i32 %t85)
  store { i64, ptr } %t86, ptr %l53
  br label %bb11
bb11:
  %t87 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t87, ptr %l7, !tbaa !27
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l54, !tbaa !29
  %t89 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 0, i32 0)
  store %"compiler/source:Span" %t89, ptr %l55
  br label %bb12
bb12:
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l56, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i32, ptr %t92, i64 0
  %t94 = load i32, ptr %t93, !tbaa !33
  store { i64, [2 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [2 x i64] }, ptr %t95, i32 0, i32 0
  store i64 1, ptr %t96
  %t97 = load { i64, [2 x i64] }, ptr %t95
  %t98 = load ptr, ptr %l54, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l55
  %t103 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t98, i32 0, %"compiler/source:Span" %t99, i32 %t94, i32 0, { i64, [2 x i64] } %t97)
  store i64 %t103, ptr %l60
  br label %bb13
bb13:
  %t104 = load i64, ptr %l60, !tbaa !24
  store i64 %t104, ptr %l8, !tbaa !24
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t105)
  store ptr %t107, ptr %l62
  br label %bb14
bb14:
  %t108 = load ptr, ptr %l62, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Body", ptr %t108, i32 0, i32 5
  %t111 = load i64, ptr %l8, !tbaa !24
  %t113 = trunc i64 %t111 to i32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %v0, ptr %t110, i32 %t113)
  br label %bb15
bb15:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t117)
  store ptr %t119, ptr %l69
  br label %bb16
bb16:
  %t120 = load ptr, ptr %l69, !tbaa !29
  %t121 = load i64, ptr %l8, !tbaa !24
  %t124 = getelementptr %"compiler/check:frame", ptr %t120, i32 0, i32 28
  store i64 %t121, ptr %t124, !tbaa !24
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t125)
  store ptr %t127, ptr %l73
  br label %bb17
bb17:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  store ptr %t131, ptr %l75, !tbaa !29
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t132)
  store ptr %t134, ptr %l77
  br label %bb18
bb18:
  %t135 = load ptr, ptr %l77, !tbaa !29
  %t137 = getelementptr %"compiler/typed:Body", ptr %t135, i32 0, i32 2
  %t138 = load i32, ptr %t137, !tbaa !23
  %t139 = load ptr, ptr %l75, !tbaa !29
  %t141 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t139, i32 %t138)
  store { i64, ptr } %t141, ptr %l80
  br label %bb19
bb19:
  %t142 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  %t144 = extractvalue { i64, ptr } %t142, 1
  %t145 = mul i64 %t143, 8
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  %t149 = load ptr, ptr %l73, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t149, { i64, ptr } %t148)
  br label %bb20
bb20:
  store ptr null, ptr %l9, !tbaa !29
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t153 = icmp eq ptr %t151, null
  br i1 %t153, label %bb21, label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f2da914bb6134d5f_3ef82b9ab3e359c3)
  unreachable
bb22:
  br label %bb23
bb23:
  %t155 = load ptr, ptr %l4, !tbaa !29
  %t158 = getelementptr %"compiler/ast:TypeDecl", ptr %t155, i32 0, i32 3
  %t159 = load ptr, ptr %t158, !tbaa !29
  store ptr %t159, ptr %l10, !tbaa !29
  %t161 = load ptr, ptr %l10, !tbaa !29
  store ptr %t161, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t162 = load ptr, ptr %l87, !tbaa !29
  %t163 = icmp ne ptr %t162, null
  br i1 %t163, label %bb24, label %bb25
bb24:
  %t165 = load ptr, ptr %l87, !tbaa !29
  %t166 = load i64, ptr %t165
  %t168 = icmp eq i64 %t166, 0
  store i1 %t168, ptr %l88, !tbaa !21
  br label %bb25
bb25:
  %t169 = load i1, ptr %l88, !tbaa !21
  br i1 %t169, label %bb26, label %bb27
bb26:
  %t170 = load ptr, ptr %l10, !tbaa !29
  %t172 = getelementptr { i64, [6 x i64] }, ptr %t170, i32 0, i32 1
  %t173 = getelementptr { ptr }, ptr %t172, i32 0, i32 0
  %t174 = load ptr, ptr %t173
  store ptr %t174, ptr %l11, !tbaa !29
  br label %bb28
bb27:
  br label %bb42
bb28:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t176)
  store ptr %t178, ptr %l94
  br label %bb29
bb29:
  %t179 = load ptr, ptr %l94, !tbaa !29
  %t180 = load ptr, ptr %l11, !tbaa !29
  %t182 = getelementptr %"compiler/ast:StructBody", ptr %t180, i32 0, i32 3
  %t183 = load %"compiler/source:Span", ptr %t182
  %t186 = getelementptr %"compiler/typed:Body", ptr %t179, i32 0, i32 4
  store %"compiler/source:Span" %t183, ptr %t186
  %t187 = load ptr, ptr %l11, !tbaa !29
  %t189 = getelementptr %"compiler/ast:StructBody", ptr %t187, i32 0, i32 4
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 0
  %t194 = icmp eq i64 %t192, 0
  br i1 %t194, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s2
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t197 = load ptr, ptr %l11, !tbaa !29
  %t199 = getelementptr %"compiler/ast:StructBody", ptr %t197, i32 0, i32 3
  %t200 = load %"compiler/source:Span", ptr %t199
  %t203 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t196, %"compiler/source:Span" %t200)
  store { i64, ptr } %t203, ptr %l106
  br label %bb32
bb31:
  br label %bb40
bb32:
  %t204 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t205 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %s2, { i64, ptr } %t204, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) })
  %t206 = extractvalue { i32, i64 } %t205, 1
  %t207 = extractvalue { i32, i64 } %t205, 0
  store i32 %t207, ptr %l108
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb34, label %ok.209
ok.209:
  store i64 %t206, ptr %l107
  br label %bb33
bb33:
  %t210 = load i64, ptr %l107, !tbaa !24
  store i64 %t210, ptr %l102, !tbaa !24
  br label %bb36
bb34:
  br label %bb35
bb35:
  call void @__olang_ert_req_clear()
  store i64 0, ptr %l102, !tbaa !24
  br label %bb36
bb36:
  %t211 = load i64, ptr %l102, !tbaa !24
  store i64 %t211, ptr %l12, !tbaa !24
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l109, !tbaa !29
  %t213 = load ptr, ptr %l11, !tbaa !29
  %t215 = getelementptr %"compiler/ast:StructBody", ptr %t213, i32 0, i32 3
  %t216 = getelementptr %"compiler/source:Span", ptr %t215, i32 0, i32 0
  %t217 = load i32, ptr %t216, !tbaa !23
  %t218 = load i64, ptr %l12, !tbaa !24
  %t220 = trunc i64 %t218 to i32
  %t223 = add i32 %t217, %t220
  %t224 = load ptr, ptr %l11, !tbaa !29
  %t226 = getelementptr %"compiler/ast:StructBody", ptr %t224, i32 0, i32 3
  %t227 = getelementptr %"compiler/source:Span", ptr %t226, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t229 = load i64, ptr %l12, !tbaa !24
  %t231 = add i64 %t229, 1
  %t233 = trunc i64 %t231 to i32
  %t236 = add i32 %t228, %t233
  %t239 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t223, i32 %t236)
  store %"compiler/source:Span" %t239, ptr %l121
  br label %bb37
bb37:
  %t240 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyDestructor(ptr %s2)
  store %"compiler/msgs:Msg" %t240, ptr %l122
  br label %bb38
bb38:
  %t241 = load ptr, ptr %l109, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l121
  %t243 = load %"compiler/msgs:Msg", ptr %l122
  %t244 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t241, %"compiler/source:Span" %t242, %"compiler/msgs:Msg" %t243)
  store i64 %t244, ptr %l123
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb40
bb40:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l11, !tbaa !29
  %t248 = getelementptr %"compiler/ast:StructBody", ptr %t246, i32 0, i32 4
  %t249 = load { i64, ptr }, ptr %t248, !tbaa !27
  %t252 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v0, ptr %t245, { i64, ptr } %t249)
  store ptr %t252, ptr %l127
  br label %bb41
bb41:
  %t253 = load ptr, ptr %l127, !tbaa !29
  store ptr %t253, ptr %l9, !tbaa !29
  br label %bb48
bb42:
  %t255 = icmp sge i64 0, 0
  br i1 %t255, label %bb43, label %bb44
bb43:
  %t257 = icmp sle i64 0, 1152921504606846975
  br i1 %t257, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_e7a3ae7e66c3138_2e8ed5b6f09d874)
  unreachable
bb45:
  %t259 = mul i64 0, 8
  %t260 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t259)
  %t261 = insertvalue { i64, ptr } undef, i64 0, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t260, 1
  %t264 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t262)
  store %"compiler/typed:Block" %t264, ptr %l132
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_e7a3ae7e66c3138_2e8ed5b6f09d874)
  unreachable
bb47:
  %t265 = load %"compiler/typed:Block", ptr %l132
  %t266 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t265, ptr %t266
  store ptr %t266, ptr %l9, !tbaa !29
  br label %bb48
bb48:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t270 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t268)
  store ptr %t270, ptr %l135
  br label %bb49
bb49:
  %t271 = load ptr, ptr %l135, !tbaa !29
  %t272 = load ptr, ptr %l9, !tbaa !29
  %t275 = getelementptr %"compiler/typed:Body", ptr %t271, i32 0, i32 11
  store ptr %t272, ptr %t275, !tbaa !29
  %t276 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t276)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckThunk(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l4 = alloca %"compiler/generic:AnyTable"
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:AnySlot"
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca { i64, [3 x i64] }
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i32
  %l43 = alloca %"compiler/generic:AnyTable"
  %l47 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l61 = alloca ptr
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l74 = alloca i32
  %l79 = alloca i32
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l83 = alloca %"compiler/generic:Context"
  %l85 = alloca ptr
  %l89 = alloca ptr
  %l92 = alloca i32
  %l95 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l130 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l163 = alloca ptr
  %l166 = alloca i64
  %l172 = alloca i64
  %l175 = alloca i64
  %l194 = alloca ptr
  %l198 = alloca ptr
  %l204 = alloca { i64, ptr }
  %l205 = alloca ptr
  %l212 = alloca i64
  %l215 = alloca { i64, ptr }
  %l218 = alloca i1
  %l221 = alloca i1
  %l223 = alloca ptr
  %l228 = alloca i64
  %l229 = alloca i1
  %l231 = alloca ptr
  %l239 = alloca i64
  %l247 = alloca ptr
  %l248 = alloca ptr
  %l252 = alloca { i64, ptr }
  %l253 = alloca %"compiler/typed:Block"
  %l258 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l260 = alloca %"compiler/source:Span"
  %l261 = alloca i64
  %l263 = alloca ptr
  %l266 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l271 = alloca ptr
  %l275 = alloca { i64, [3 x i64] }
  %l277 = alloca ptr
  %l282 = alloca i64
  %l283 = alloca { i64, [3 x i64] }
  %l284 = alloca i32
  %l292 = alloca ptr
  %l293 = alloca { i64, [3 x i64] }
  %l294 = alloca { i64, ptr }
  %l297 = alloca { i64, ptr }
  %l300 = alloca { i64, ptr }
  %l303 = alloca ptr
  %l304 = alloca %"compiler/source:Span"
  %l305 = alloca %"compiler/source:Span"
  %l306 = alloca i64
  %l308 = alloca ptr
  %l311 = alloca { i64, ptr }
  %l312 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l326 = alloca i1
  %l327 = alloca ptr
  %l328 = alloca %"compiler/source:Span"
  %l330 = alloca i32
  %l334 = alloca ptr
  %l335 = alloca ptr
  %l339 = alloca ptr
  %l340 = alloca { i64, ptr }
  %l341 = alloca ptr
  %l344 = alloca i1
  %l345 = alloca ptr
  %l346 = alloca %"compiler/source:Span"
  %l348 = alloca i32
  %l351 = alloca ptr
  %l354 = alloca i1
  %l355 = alloca ptr
  %l356 = alloca %"compiler/source:Span"
  %l361 = alloca i32
  %l362 = alloca i32
  %l366 = alloca ptr
  %l367 = alloca ptr
  %l373 = alloca ptr
  %l375 = alloca ptr
  %l383 = alloca ptr
  %l388 = alloca i32
  %l389 = alloca { i64, ptr }
  %l392 = alloca %"compiler/source:Span"
  %l395 = alloca i32
  %l397 = alloca ptr
  %l401 = alloca %"compiler/typed:Try"
  %l407 = alloca i64
  %l412 = alloca i32
  %l438 = alloca ptr
  %l439 = alloca %"compiler/source:Span"
  %l444 = alloca ptr
  %l449 = alloca ptr
  %l450 = alloca ptr
  %l454 = alloca { i64, ptr }
  %l455 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %t237 = alloca { i64, [4 x i64] }, align 8
  %t260 = alloca { i64, [4 x i64] }, align 8
  %t446 = alloca { i64, [3 x i64] }, align 8
  %t547 = alloca { i64, [3 x i64] }, align 8
  %t687 = alloca { i64, [3 x i64] }, align 8
  %t832 = alloca { i64, [5 x i64] }, align 8
  %t873 = alloca { i64, [3 x i64] }, align 8
  %t896 = alloca { i64, [3 x i64] }, align 8
  %t925 = alloca { i64, [3 x i64] }, align 8
  %t939 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 42
  %t10 = call %"compiler/generic:AnyTable" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aAnyTable_3e_2e_H5e3c685c1de22cee1b092c35d74f13cd(ptr %v0, ptr %v0, ptr %t6, i64 %a2)
  store %"compiler/generic:AnyTable" %t10, ptr %l43
  br label %bb1
bb1:
  %t11 = load %"compiler/generic:AnyTable", ptr %l43
  store %"compiler/generic:AnyTable" %t11, ptr %l4
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t16 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 1
  %t17 = load i32, ptr %t16, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t15, i32 %t17)
  store { i64, ptr } %t20, ptr %l47
  br label %bb2
bb2:
  %t21 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t28 = srem i64 %a3, %t22
  store i64 %t28, ptr %l6, !tbaa !24
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 1
  %t35 = load i32, ptr %t34, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %t33, i32 %t35)
  store { i64, ptr } %t38, ptr %l55
  br label %bb3
bb3:
  %t39 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t39, ptr %l56, !tbaa !27
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr %"compiler/generic:AnySlot", ptr %t43, i64 %t40
  %t45 = load %"compiler/generic:AnySlot", ptr %t44
  store %"compiler/generic:AnySlot" %t45, ptr %l7
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load i64, ptr %l1, !tbaa !24
  %t51 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur0(ptr %v0, ptr %t47, i64 %t48)
  store ptr %t51, ptr %l61
  br label %bb4
bb4:
  %t52 = load ptr, ptr %l61, !tbaa !29
  %t54 = getelementptr %"compiler/typed:Body", ptr %t52, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  store i32 %t55, ptr %l8, !tbaa !23
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i64, ptr %l1, !tbaa !24
  %t61 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l66
  br label %bb5
bb5:
  %t62 = load i64, ptr %l66, !tbaa !24
  store i64 %t62, ptr %l9, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  store ptr %t63, ptr %l67, !tbaa !29
  %t64 = load i64, ptr %l1, !tbaa !24
  store i64 %t64, ptr %l68, !tbaa !24
  %t65 = load i64, ptr %l9, !tbaa !24
  store i64 %t65, ptr %l69, !tbaa !24
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/generic:Program", ptr %t69, i32 0, i32 2
  %t72 = load i32, ptr %l8, !tbaa !23
  %t75 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t71, i32 %t72)
  store i32 %t75, ptr %l74
  br label %bb6
bb6:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !29
  %t81 = getelementptr %"compiler/generic:Program", ptr %t79, i32 0, i32 2
  %t82 = load i32, ptr %l8, !tbaa !23
  %t85 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t81, i32 %t82)
  store i32 %t85, ptr %l79
  br label %bb7
bb7:
  %t86 = load ptr, ptr %l67, !tbaa !29
  %t87 = load i64, ptr %l68, !tbaa !24
  %t88 = load i64, ptr %l69, !tbaa !24
  %t89 = load i32, ptr %l74, !tbaa !23
  %t90 = load i32, ptr %l79, !tbaa !23
  %t91 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t86, i64 %t87, i64 %t88, i32 %t89, i32 %t90)
  store ptr %t91, ptr %l80
  br label %bb8
bb8:
  %t92 = load ptr, ptr %l80, !tbaa !29
  store ptr %t92, ptr %l10, !tbaa !29
  %t93 = load ptr, ptr %l10, !tbaa !29
  store ptr %t93, ptr %l81, !tbaa !29
  %t94 = load i64, ptr %l9, !tbaa !24
  %t96 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t94, i64 -1)
  store %"compiler/generic:Context" %t96, ptr %l83
  br label %bb9
bb9:
  %t97 = load %"compiler/generic:Context", ptr %l83
  %t98 = load ptr, ptr %l81, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t98, i32 0, i32 4
  store %"compiler/generic:Context" %t97, ptr %t99
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t100)
  store ptr %t102, ptr %l85
  br label %bb10
bb10:
  %t103 = load ptr, ptr %l85, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 4
  %t106 = load %"compiler/source:Span", ptr %t105
  store %"compiler/source:Span" %t106, ptr %l11
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t108)
  store ptr %t110, ptr %l89
  br label %bb11
bb11:
  %t111 = load %"compiler/source:Span", ptr %l11
  %t112 = load ptr, ptr %l89, !tbaa !29
  %t115 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t112, i32 -1, i32 0, %"compiler/source:Span" %t111)
  store i32 %t115, ptr %l92
  br label %bb12
bb12:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/check:Checker", ptr %t116, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t121 = getelementptr %"compiler/generic:Program", ptr %t119, i32 0, i32 2
  store ptr %t121, ptr %l95, !tbaa !29
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t122, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t127 = getelementptr %"compiler/generic:Program", ptr %t125, i32 0, i32 2
  %t128 = load i32, ptr %l8, !tbaa !23
  %t131 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t127, i32 %t128)
  store i32 %t131, ptr %l100
  br label %bb13
bb13:
  %t132 = load ptr, ptr %l95, !tbaa !29
  %t133 = load i32, ptr %l100, !tbaa !23
  %t134 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t132, i32 %t133)
  store { i64, ptr } %t134, ptr %l101
  br label %bb14
bb14:
  %t135 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t135, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  store i64 %t138, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t140 = load i64, ptr %l14, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = icmp sgt i64 %t140, %t141
  br i1 %t144, label %bb15, label %bb16
bb15:
  %t146 = load i64, ptr %l15, !tbaa !24
  %t148 = icmp sgt i64 %t146, 0
  br i1 %t148, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l107, !tbaa !24
  br label %bb20
bb17:
  %t150 = load i64, ptr %l14, !tbaa !24
  %t151 = load i64, ptr %l13, !tbaa !24
  %t154 = sub i64 %t150, %t151
  %t155 = load i64, ptr %l15, !tbaa !24
  %t158 = add i64 %t154, %t155
  %t160 = sub i64 %t158, 1
  %t161 = load i64, ptr %l15, !tbaa !24
  %t164 = sdiv i64 %t160, %t161
  store i64 %t164, ptr %l110, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l110, !tbaa !24
  br label %bb19
bb19:
  %t166 = load i64, ptr %l110, !tbaa !24
  store i64 %t166, ptr %l107, !tbaa !24
  br label %bb20
bb20:
  %t167 = load i64, ptr %l107, !tbaa !24
  store i64 %t167, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t168 = load i64, ptr %l17, !tbaa !24
  %t169 = load i64, ptr %l16, !tbaa !24
  %t172 = icmp slt i64 %t168, %t169
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb23:
  br label %bb24
bb24:
  %t176 = load i64, ptr %l13, !tbaa !24
  %t177 = load i64, ptr %l17, !tbaa !24
  %t178 = load i64, ptr %l15, !tbaa !24
  %t181 = mul i64 %t177, %t178
  %t184 = add i64 %t176, %t181
  store i64 %t184, ptr %l18, !tbaa !24
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l11
  %t188 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t188, ptr %l130, !tbaa !27
  %t189 = load i64, ptr %l18, !tbaa !24
  %t191 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr i32, ptr %t192, i64 %t189
  %t194 = load i32, ptr %t193, !tbaa !33
  %t195 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %s2, ptr %t186, i32 0, %"compiler/source:Span" %t187, i32 %t194, i64 %t195, ptr null)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb26:
  %t200 = load i64, ptr %l17, !tbaa !24
  %t202 = add i64 %t200, 1
  store i64 %t202, ptr %l17, !tbaa !24
  br label %bb21
bb27:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t204)
  store ptr %t206, ptr %l137
  br label %bb28
bb28:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t209 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t211 = load i32, ptr %l8, !tbaa !23
  %t214 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t210, i32 %t211)
  store { i64, ptr } %t214, ptr %l141
  br label %bb29
bb29:
  %t215 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  %t217 = extractvalue { i64, ptr } %t215, 1
  %t218 = mul i64 %t216, 8
  %t219 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t218)
  call void @llvm.memcpy.p0.p0.i64(ptr %t219, ptr %t217, i64 %t218, i1 false)
  %t220 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  %t222 = load ptr, ptr %l137, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t222, { i64, ptr } %t221)
  br label %bb30
bb30:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l11
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t224, %"compiler/source:Span" %t225, i64 0)
  store ptr %t228, ptr %l145
  br label %bb31
bb31:
  %t229 = load ptr, ptr %l145, !tbaa !29
  %t230 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  store i32 %t231, ptr %l20, !tbaa !23
  %t233 = load %"compiler/source:Span", ptr %l11
  %t234 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 2
  %t235 = load i32, ptr %t234, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t237
  %t238 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 0
  store i64 2, ptr %t238
  %t240 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t233, 0
  %t242 = insertvalue { %"compiler/source:Span", i32, ptr } %t240, i32 %t235, 1
  %t244 = insertvalue { %"compiler/source:Span", i32, ptr } %t242, ptr %t229, 2
  %t245 = getelementptr { i64, [4 x i64] }, ptr %t237, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t244, ptr %t245
  %t246 = load { i64, [4 x i64] }, ptr %t237
  %t248 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t246, ptr %t248
  store ptr %t248, ptr %l21, !tbaa !29
  %t250 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 2
  %t251 = load i32, ptr %t250, !tbaa !23
  %t252 = load i32, ptr %l20, !tbaa !23
  %t255 = icmp ne i32 %t251, %t252
  br i1 %t255, label %bb32, label %bb33
bb32:
  %t257 = load %"compiler/source:Span", ptr %l11
  %t258 = load i32, ptr %l20, !tbaa !23
  %t259 = load ptr, ptr %l21, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t260
  %t261 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 0
  store i64 3, ptr %t261
  %t263 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } undef, %"compiler/source:Span" %t257, 0
  %t265 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t263, i32 %t258, 1
  %t267 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t265, ptr %t259, 2
  %t268 = insertvalue { %"compiler/source:Span", i32, ptr, i64 } %t267, i64 0, 3
  %t269 = getelementptr { i64, [4 x i64] }, ptr %t260, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i64 } %t268, ptr %t269
  %t270 = load { i64, [4 x i64] }, ptr %t260
  %t272 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t270, ptr %t272
  store ptr %t272, ptr %l21, !tbaa !29
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load %"compiler/source:Span", ptr %l11
  %t276 = load ptr, ptr %l21, !tbaa !29
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t274, %"compiler/source:Span" %t275, ptr %t276)
  store ptr %t280, ptr %l163
  br label %bb35
bb35:
  %t281 = load ptr, ptr %l163, !tbaa !29
  store ptr %t281, ptr %l22, !tbaa !29
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/check:Checker", ptr %t282, i32 0, i32 32
  %t286 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t284)
  store i64 %t286, ptr %l166
  br label %bb36
bb36:
  %t287 = load i64, ptr %l166, !tbaa !24
  store i64 %t287, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t288 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t288, 0
  store i64 %t290, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t292 = load i64, ptr %l25, !tbaa !24
  %t293 = load i64, ptr %l24, !tbaa !24
  %t296 = icmp sgt i64 %t292, %t293
  br i1 %t296, label %bb37, label %bb38
bb37:
  %t298 = load i64, ptr %l26, !tbaa !24
  %t300 = icmp sgt i64 %t298, 0
  br i1 %t300, label %bb39, label %bb40
bb38:
  store i64 0, ptr %l172, !tbaa !24
  br label %bb42
bb39:
  %t302 = load i64, ptr %l25, !tbaa !24
  %t303 = load i64, ptr %l24, !tbaa !24
  %t306 = sub i64 %t302, %t303
  %t307 = load i64, ptr %l26, !tbaa !24
  %t310 = add i64 %t306, %t307
  %t312 = sub i64 %t310, 1
  %t313 = load i64, ptr %l26, !tbaa !24
  %t316 = sdiv i64 %t312, %t313
  store i64 %t316, ptr %l175, !tbaa !24
  br label %bb41
bb40:
  store i64 0, ptr %l175, !tbaa !24
  br label %bb41
bb41:
  %t318 = load i64, ptr %l175, !tbaa !24
  store i64 %t318, ptr %l172, !tbaa !24
  br label %bb42
bb42:
  %t319 = load i64, ptr %l172, !tbaa !24
  store i64 %t319, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb43
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t320 = load i64, ptr %l28, !tbaa !24
  %t321 = load i64, ptr %l27, !tbaa !24
  %t324 = icmp slt i64 %t320, %t321
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb44, label %bb45
bb44:
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb45:
  br label %bb46
bb46:
  %t328 = load i64, ptr %l24, !tbaa !24
  %t329 = load i64, ptr %l28, !tbaa !24
  %t330 = load i64, ptr %l26, !tbaa !24
  %t333 = mul i64 %t329, %t330
  %t336 = add i64 %t328, %t333
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = getelementptr %"compiler/check:Checker", ptr %t338, i32 0, i32 32
  store ptr %t340, ptr %l194, !tbaa !29
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = load %"compiler/source:Span", ptr %l11
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t341, %"compiler/source:Span" %t342, i64 %t336)
  store ptr %t347, ptr %l198
  br label %bb47
bb47:
  %t348 = load ptr, ptr %l194, !tbaa !29
  %t349 = load ptr, ptr %l198, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t348, ptr %t349)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t350 = load i64, ptr %l28, !tbaa !24
  %t352 = add i64 %t350, 1
  store i64 %t352, ptr %l28, !tbaa !24
  br label %bb43
bb50:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/check:Checker", ptr %t354, i32 0, i32 32
  %t357 = load i64, ptr %l23, !tbaa !24
  %t360 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t356, i64 %t357)
  store { i64, ptr } %t360, ptr %l204
  br label %bb51
bb51:
  %t361 = load { i64, ptr }, ptr %l204, !tbaa !27
  store { i64, ptr } %t361, ptr %l30, !tbaa !27
  %t362 = load ptr, ptr %l10, !tbaa !29
  store ptr %t362, ptr %l205, !tbaa !29
  %t363 = load ptr, ptr %l205, !tbaa !29
  %t364 = getelementptr %"compiler/check:frame", ptr %t363, i32 0, i32 15
  %t365 = load i64, ptr %t364, !tbaa !24
  %t367 = add i64 %t365, 1
  %t369 = load ptr, ptr %l205, !tbaa !29
  %t370 = getelementptr %"compiler/check:frame", ptr %t369, i32 0, i32 15
  store i64 %t367, ptr %t370, !tbaa !24
  store ptr null, ptr %l31, !tbaa !29
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = getelementptr %"compiler/check:Checker", ptr %t371, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t375 = load i32, ptr %l20, !tbaa !23
  %t376 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 0
  %t377 = load i32, ptr %t376, !tbaa !23
  %t381 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t374, i32 %t375, i32 %t377)
  store i64 %t381, ptr %l212
  br label %bb52
bb52:
  %t382 = load i64, ptr %l212, !tbaa !24
  store i64 %t382, ptr %l32, !tbaa !24
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 0
  %t385 = load i32, ptr %t384, !tbaa !23
  %t388 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t383, i32 %t385)
  store { i64, ptr } %t388, ptr %l215
  br label %bb53
bb53:
  %t389 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t389, ptr %l33, !tbaa !27
  %t390 = load i64, ptr %l32, !tbaa !24
  %t392 = icmp slt i64 %t390, 0
  br i1 %t392, label %bb54, label %bb55
bb54:
  %t394 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 3
  %t395 = load i64, ptr %t394, !tbaa !24
  %t397 = icmp sge i64 %t395, 0
  store i1 %t397, ptr %l218, !tbaa !21
  br label %bb56
bb55:
  store i1 false, ptr %l218, !tbaa !21
  br label %bb56
bb56:
  %t399 = load i1, ptr %l218, !tbaa !21
  br i1 %t399, label %bb57, label %bb58
bb57:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t400, i32 0, i32 98
  store ptr %t402, ptr %l223, !tbaa !29
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/check:Checker", ptr %t403, i32 0, i32 1
  %t406 = load ptr, ptr %t405, !tbaa !29
  %t407 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 1
  %t408 = load i32, ptr %t407, !tbaa !23
  %t409 = load i64, ptr %l6, !tbaa !24
  %t413 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t406, i32 %t408, i64 %t409)
  store i64 %t413, ptr %l228
  br label %bb59
bb58:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb61
bb59:
  %t414 = load ptr, ptr %l223, !tbaa !29
  %t415 = load i64, ptr %l228, !tbaa !24
  %t416 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %t414, i64 %t415)
  store i1 %t416, ptr %l229
  br label %bb60
bb60:
  %t417 = load i1, ptr %l229, !tbaa !21
  %t418 = xor i1 %t417, true
  store i1 %t418, ptr %l221, !tbaa !21
  br label %bb61
bb61:
  %t420 = load i1, ptr %l221, !tbaa !21
  br i1 %t420, label %bb62, label %bb63
bb62:
  %t421 = load ptr, ptr %l10, !tbaa !29
  store ptr %t421, ptr %l231, !tbaa !29
  %t422 = load ptr, ptr %l231, !tbaa !29
  %t423 = getelementptr %"compiler/check:frame", ptr %t422, i32 0, i32 15
  %t424 = load i64, ptr %t423, !tbaa !24
  %t426 = sub i64 %t424, 1
  %t428 = load ptr, ptr %l231, !tbaa !29
  %t429 = getelementptr %"compiler/check:frame", ptr %t428, i32 0, i32 15
  store i64 %t426, ptr %t429, !tbaa !24
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/check:Checker", ptr %t430, i32 0, i32 99
  %t433 = load i64, ptr %l1, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t432, i64 %t433)
  br label %bb64
bb63:
  br label %bb71
bb64:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr %"compiler/check:Checker", ptr %t436, i32 0, i32 33
  %t440 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t438)
  store i64 %t440, ptr %l239
  br label %bb65
bb65:
  %t441 = load i64, ptr %l239, !tbaa !24
  store i64 %t441, ptr %l34, !tbaa !24
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/check:Checker", ptr %t442, i32 0, i32 33
  %t445 = load %"compiler/source:Span", ptr %l11
  store { i64, [3 x i64] } zeroinitializer, ptr %t446
  %t447 = getelementptr { i64, [3 x i64] }, ptr %t446, i32 0, i32 0
  store i64 9, ptr %t447
  %t449 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t445, 0
  %t451 = insertvalue { %"compiler/source:Span", i32, ptr } %t449, i32 0, 1
  %t452 = insertvalue { %"compiler/source:Span", i32, ptr } %t451, ptr null, 2
  %t453 = getelementptr { i64, [3 x i64] }, ptr %t446, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t452, ptr %t453
  %t454 = load { i64, [3 x i64] }, ptr %t446
  %t456 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t454, ptr %t456
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t444, ptr %t456)
  br label %bb66
bb66:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t459)
  store ptr %t461, ptr %l247
  br label %bb67
bb67:
  %t462 = load ptr, ptr %l247, !tbaa !29
  store ptr %t462, ptr %l248, !tbaa !29
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t465 = getelementptr %"compiler/check:Checker", ptr %t463, i32 0, i32 33
  %t466 = load i64, ptr %l34, !tbaa !24
  %t469 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t465, i64 %t466)
  store { i64, ptr } %t469, ptr %l252
  br label %bb68
bb68:
  %t470 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t471 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t470)
  store %"compiler/typed:Block" %t471, ptr %l253
  br label %bb69
bb69:
  %t472 = load %"compiler/typed:Block", ptr %l253
  %t473 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t472, ptr %t473
  %t475 = load ptr, ptr %l248, !tbaa !29
  %t476 = getelementptr %"compiler/typed:Body", ptr %t475, i32 0, i32 11
  store ptr %t473, ptr %t476, !tbaa !29
  %t477 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t477)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb71:
  %t479 = load i64, ptr %l32, !tbaa !24
  %t481 = icmp sge i64 %t479, 0
  br i1 %t481, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s9
  %t483 = load ptr, ptr %l0, !tbaa !29
  store ptr %t483, ptr %l258, !tbaa !29
  %t484 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t484, ptr %l259
  %t485 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t485, ptr %l260
  %t486 = load i64, ptr %l32, !tbaa !24
  store i64 %t486, ptr %l261, !tbaa !24
  %t487 = load ptr, ptr %l22, !tbaa !29
  store ptr %t487, ptr %l263, !tbaa !29
  %t489 = icmp sge i64 0, 0
  br i1 %t489, label %bb74, label %bb75
bb73:
  %t491 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 3
  %t492 = load i64, ptr %t491, !tbaa !24
  %t494 = icmp sge i64 %t492, 0
  br i1 %t494, label %bb83, label %bb84
bb74:
  %t496 = icmp sle i64 0, 1152921504606846975
  br i1 %t496, label %bb76, label %bb77
bb75:
  call void @__olang_check_failed(ptr @olang_loc_3c4a57751e7c3c44_a964a095ba0d8e8)
  unreachable
bb76:
  %t498 = mul i64 0, 8
  %t499 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t498)
  %t500 = insertvalue { i64, ptr } undef, i64 0, 0
  %t501 = insertvalue { i64, ptr } %t500, ptr %t499, 1
  store { i64, ptr } %t501, ptr %l266, !tbaa !27
  %t502 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t502, ptr %l267, !tbaa !27
  %t503 = icmp sge i64 0, 0
  br i1 %t503, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_3c4a57751e7c3c44_a964a095ba0d8e8)
  unreachable
bb78:
  %t505 = icmp sle i64 0, 2305843009213693951
  br i1 %t505, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb80:
  %t507 = mul i64 0, 4
  %t508 = call ptr @__olang_scope_alloc_zeroed(ptr %s9, i64 %t507)
  %t509 = insertvalue { i64, ptr } undef, i64 0, 0
  %t510 = insertvalue { i64, ptr } %t509, ptr %t508, 1
  %t511 = load ptr, ptr %l258, !tbaa !29
  %t512 = load %"compiler/source:Span", ptr %l259
  %t513 = load %"compiler/source:Span", ptr %l260
  %t514 = load i64, ptr %l261, !tbaa !24
  %t515 = load ptr, ptr %l263, !tbaa !29
  %t516 = load { i64, ptr }, ptr %l266, !tbaa !27
  %t517 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t519 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s9, ptr %t511, %"compiler/source:Span" %t512, %"compiler/source:Span" %t513, i64 %t514, ptr %t515, { i64, ptr } %t516, { i64, ptr } %t517, { i64, ptr } %t510)
  store ptr %t519, ptr %l271
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb82:
  %t520 = load ptr, ptr %l271, !tbaa !29
  store ptr %t520, ptr %l31, !tbaa !29
  call void @__olang_scope_close(ptr %s9)
  br label %bb133
bb83:
  store %olang.scope zeroinitializer, ptr %s11
  %t522 = load ptr, ptr %l0, !tbaa !29
  %t524 = getelementptr %"compiler/check:Checker", ptr %t522, i32 0, i32 98
  store ptr %t524, ptr %l277, !tbaa !29
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t527 = getelementptr %"compiler/check:Checker", ptr %t525, i32 0, i32 1
  %t528 = load ptr, ptr %t527, !tbaa !29
  %t529 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 1
  %t530 = load i32, ptr %t529, !tbaa !23
  %t531 = load i64, ptr %l6, !tbaa !24
  %t535 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %t528, i32 %t530, i64 %t531)
  store i64 %t535, ptr %l282
  br label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s15
  %t536 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t538 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t536, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t538, ptr %l326
  br label %bb109
bb85:
  %t539 = load ptr, ptr %l277, !tbaa !29
  %t540 = load i64, ptr %l282, !tbaa !24
  %t541 = call { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %t539, i64 %t540)
  %t542 = extractvalue { i32, { i64, [3 x i64] } } %t541, 1
  %t543 = extractvalue { i32, { i64, [3 x i64] } } %t541, 0
  store i32 %t543, ptr %l284
  %t544 = icmp ne i32 %t543, 0
  br i1 %t544, label %bb87, label %ok.545
ok.545:
  store { i64, [3 x i64] } %t542, ptr %l283
  br label %bb86
bb86:
  %t546 = load { i64, [3 x i64] }, ptr %l283
  store { i64, [3 x i64] } %t546, ptr %l275
  br label %bb89
bb87:
  br label %bb88
bb88:
  call void @__olang_ert_req_clear()
  store { i64, [3 x i64] } zeroinitializer, ptr %t547
  %t548 = getelementptr { i64, [3 x i64] }, ptr %t547, i32 0, i32 0
  store i64 0, ptr %t548
  %t549 = load { i64, [3 x i64] }, ptr %t547
  store { i64, [3 x i64] } %t549, ptr %l275
  br label %bb89
bb89:
  %t551 = load { i64, [3 x i64] }, ptr %l275
  store { i64, [3 x i64] } %t551, ptr %l35
  %t552 = load { i64, [3 x i64] }, ptr %l35
  %t554 = extractvalue { i64, [3 x i64] } %t552, 0
  %t555 = icmp eq i64 %t554, 0
  %t557 = xor i1 %t555, true
  br i1 %t557, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t561 = getelementptr %"compiler/check:Checker", ptr %t559, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !29
  %t564 = getelementptr %"compiler/generic:Program", ptr %t562, i32 0, i32 0
  %t565 = load ptr, ptr %t564, !tbaa !29
  %t567 = getelementptr %"compiler/load:Loader", ptr %t565, i32 0, i32 4
  %t568 = load ptr, ptr %t567, !tbaa !29
  store ptr %t568, ptr %l292, !tbaa !29
  %t569 = load { i64, [3 x i64] }, ptr %l35
  store { i64, [3 x i64] } %t569, ptr %l293
  %t570 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t570, ptr %l294, !tbaa !27
  %t571 = load ptr, ptr %l0, !tbaa !29
  %t572 = getelementptr %"compiler/generic:AnyTable", ptr %l4, i32 0, i32 1
  %t573 = load i32, ptr %t572, !tbaa !23
  %t576 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t571, i32 %t573)
  store { i64, ptr } %t576, ptr %l297
  br label %bb92
bb91:
  br label %bb95
bb92:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t578 = load i32, ptr %l20, !tbaa !23
  %t581 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t577, i32 %t578)
  store { i64, ptr } %t581, ptr %l300
  br label %bb93
bb93:
  %t582 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t583 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t584 = load { i64, ptr }, ptr %l294, !tbaa !27
  %t585 = extractvalue { i64, ptr } %t584, 1
  %t586 = extractvalue { i64, ptr } %t584, 0
  %t587 = add i64 %t583, %t586
  %t588 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t589 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t590 = add i64 %t587, %t589
  %t591 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t592 = extractvalue { i64, ptr } %t591, 1
  %t593 = extractvalue { i64, ptr } %t591, 0
  %t594 = add i64 %t590, %t593
  %t595 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t596 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t597 = add i64 %t594, %t596
  %t598 = load { i64, ptr }, ptr %l300, !tbaa !27
  %t599 = extractvalue { i64, ptr } %t598, 1
  %t600 = extractvalue { i64, ptr } %t598, 0
  %t601 = add i64 %t597, %t600
  %t602 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t603 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t604 = add i64 %t601, %t603
  %t605 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t604)
  call void @olang_textcopy(ptr %t605, ptr %t582, i64 %t583)
  %t606 = getelementptr i8, ptr %t605, i64 %t583
  call void @olang_textcopy(ptr %t606, ptr %t585, i64 %t586)
  %t607 = getelementptr i8, ptr %t606, i64 %t586
  call void @olang_textcopy(ptr %t607, ptr %t588, i64 %t589)
  %t608 = getelementptr i8, ptr %t607, i64 %t589
  call void @olang_textcopy(ptr %t608, ptr %t592, i64 %t593)
  %t609 = getelementptr i8, ptr %t608, i64 %t593
  call void @olang_textcopy(ptr %t609, ptr %t595, i64 %t596)
  %t610 = getelementptr i8, ptr %t609, i64 %t596
  call void @olang_textcopy(ptr %t610, ptr %t599, i64 %t600)
  %t611 = getelementptr i8, ptr %t610, i64 %t600
  call void @olang_textcopy(ptr %t611, ptr %t602, i64 %t603)
  %t612 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t605, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = extractvalue { i64, ptr } %t613, 1
  %t617 = mul i64 %t615, 1
  %t618 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t617)
  call void @llvm.memcpy.p0.p0.i64(ptr %t618, ptr %t616, i64 %t617, i1 false)
  %t619 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  %t621 = load ptr, ptr %l292, !tbaa !29
  %t622 = load { i64, [3 x i64] }, ptr %l293
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %s12, ptr %t621, { i64, [3 x i64] } %t622, { i64, ptr } %t620)
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s12)
  br label %bb95
bb95:
  %t624 = load ptr, ptr %l0, !tbaa !29
  store ptr %t624, ptr %l303, !tbaa !29
  %t625 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t625, ptr %l304
  %t626 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t626, ptr %l305
  %t627 = getelementptr %"compiler/generic:AnySlot", ptr %l7, i32 0, i32 3
  %t628 = load i64, ptr %t627, !tbaa !24
  store i64 %t628, ptr %l306, !tbaa !24
  %t629 = load ptr, ptr %l22, !tbaa !29
  store ptr %t629, ptr %l308, !tbaa !29
  %t631 = icmp sge i64 0, 0
  br i1 %t631, label %bb96, label %bb97
bb96:
  %t633 = icmp sle i64 0, 1152921504606846975
  br i1 %t633, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @olang_loc_f31fa7029241fd32_aa76ba41726a43b6)
  unreachable
bb98:
  %t635 = mul i64 0, 8
  %t636 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t635)
  %t637 = insertvalue { i64, ptr } undef, i64 0, 0
  %t638 = insertvalue { i64, ptr } %t637, ptr %t636, 1
  store { i64, ptr } %t638, ptr %l311, !tbaa !27
  %t639 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t639, ptr %l312, !tbaa !27
  %t640 = icmp sge i64 0, 0
  br i1 %t640, label %bb100, label %bb101
bb99:
  call void @__olang_check_failed(ptr @olang_loc_f31fa7029241fd32_aa76ba41726a43b6)
  unreachable
bb100:
  %t642 = icmp sle i64 0, 2305843009213693951
  br i1 %t642, label %bb102, label %bb103
bb101:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb102:
  %t644 = mul i64 0, 4
  %t645 = call ptr @__olang_scope_alloc_zeroed(ptr %s11, i64 %t644)
  %t646 = insertvalue { i64, ptr } undef, i64 0, 0
  %t647 = insertvalue { i64, ptr } %t646, ptr %t645, 1
  %t648 = load ptr, ptr %l303, !tbaa !29
  %t649 = load %"compiler/source:Span", ptr %l304
  %t650 = load %"compiler/source:Span", ptr %l305
  %t651 = load i64, ptr %l306, !tbaa !24
  %t652 = load ptr, ptr %l308, !tbaa !29
  %t653 = load { i64, ptr }, ptr %l311, !tbaa !27
  %t654 = load { i64, ptr }, ptr %l312, !tbaa !27
  %t656 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s11, ptr %t648, %"compiler/source:Span" %t649, %"compiler/source:Span" %t650, i64 %t651, ptr %t652, { i64, ptr } %t653, { i64, ptr } %t654, { i64, ptr } %t647)
  store ptr %t656, ptr %l316
  br label %bb104
bb103:
  call void @__olang_check_failed(ptr @olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5)
  unreachable
bb104:
  %t657 = load ptr, ptr %l316, !tbaa !29
  store ptr %t657, ptr %l31, !tbaa !29
  %t659 = load { i64, [3 x i64] }, ptr %l35
  %t661 = extractvalue { i64, [3 x i64] } %t659, 0
  %t662 = icmp eq i64 %t661, 0
  %t664 = xor i1 %t662, true
  br i1 %t664, label %bb105, label %bb106
bb105:
  %t666 = load ptr, ptr %l0, !tbaa !29
  %t668 = getelementptr %"compiler/check:Checker", ptr %t666, i32 0, i32 1
  %t669 = load ptr, ptr %t668, !tbaa !29
  %t671 = getelementptr %"compiler/generic:Program", ptr %t669, i32 0, i32 0
  %t672 = load ptr, ptr %t671, !tbaa !29
  %t674 = getelementptr %"compiler/load:Loader", ptr %t672, i32 0, i32 4
  %t675 = load ptr, ptr %t674, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %t675)
  br label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s11)
  br label %bb132
bb109:
  %t677 = load i1, ptr %l326, !tbaa !21
  br i1 %t677, label %bb110, label %bb111
bb110:
  %t678 = load ptr, ptr %l0, !tbaa !29
  store ptr %t678, ptr %l327, !tbaa !29
  %t679 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t679, ptr %l328
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t682 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t680)
  store i32 %t682, ptr %l330
  br label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s17
  %t683 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t685 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s17, { i64, ptr } %t683, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t685, ptr %l344
  br label %bb116
bb112:
  %t686 = load i32, ptr %l20, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t687
  %t688 = getelementptr { i64, [3 x i64] }, ptr %t687, i32 0, i32 0
  store i64 4, ptr %t688
  %t690 = insertvalue { i32, i32 } undef, i32 1, 0
  %t692 = insertvalue { i32, i32 } %t690, i32 %t686, 1
  %t693 = getelementptr { i64, [3 x i64] }, ptr %t687, i32 0, i32 1
  store { i32, i32 } %t692, ptr %t693
  %t694 = load { i64, [3 x i64] }, ptr %t687
  %t696 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t694, ptr %t696
  store ptr %t696, ptr %l334, !tbaa !29
  %t697 = load ptr, ptr %l0, !tbaa !29
  store ptr %t697, ptr %l335, !tbaa !29
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t699 = load ptr, ptr %l22, !tbaa !29
  %t700 = load %"compiler/source:Span", ptr %l11
  %t704 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t698, ptr %t699, %"compiler/source:Span" %t700)
  store ptr %t704, ptr %l339
  br label %bb113
bb113:
  %t705 = load ptr, ptr %l335, !tbaa !29
  %t706 = load ptr, ptr %l339, !tbaa !29
  %t707 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %t705, ptr %t706)
  store { i64, ptr } %t707, ptr %l340
  br label %bb114
bb114:
  %t708 = load ptr, ptr %l327, !tbaa !29
  %t709 = load %"compiler/source:Span", ptr %l328
  %t710 = load i32, ptr %l330, !tbaa !23
  %t711 = load ptr, ptr %l334, !tbaa !29
  %t712 = load { i64, ptr }, ptr %l340, !tbaa !27
  %t713 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallOf(ptr %v0, ptr %t708, %"compiler/source:Span" %t709, i32 %t710, ptr %t711, { i64, ptr } %t712)
  store ptr %t713, ptr %l341
  br label %bb115
bb115:
  %t714 = load ptr, ptr %l341, !tbaa !29
  store ptr %t714, ptr %l31, !tbaa !29
  br label %bb131
bb116:
  %t716 = load i1, ptr %l344, !tbaa !21
  br i1 %t716, label %bb117, label %bb118
bb117:
  %t717 = load ptr, ptr %l0, !tbaa !29
  store ptr %t717, ptr %l345, !tbaa !29
  %t718 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t718, ptr %l346
  %t719 = load ptr, ptr %l0, !tbaa !29
  %t721 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t719)
  store i32 %t721, ptr %l348
  br label %bb119
bb118:
  store %olang.scope zeroinitializer, ptr %s19
  %t722 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t724 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s19, { i64, ptr } %t722, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i1 %t724, ptr %l354
  br label %bb121
bb119:
  %t725 = load ptr, ptr %l22, !tbaa !29
  %t726 = load ptr, ptr %l345, !tbaa !29
  %t727 = load %"compiler/source:Span", ptr %l346
  %t728 = load i32, ptr %l348, !tbaa !23
  %t731 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t726, %"compiler/source:Span" %t727, i32 %t728, i32 22, ptr %t725, ptr null)
  store ptr %t731, ptr %l351
  br label %bb120
bb120:
  %t732 = load ptr, ptr %l351, !tbaa !29
  store ptr %t732, ptr %l31, !tbaa !29
  br label %bb130
bb121:
  %t734 = load i1, ptr %l354, !tbaa !21
  br i1 %t734, label %bb122, label %bb123
bb122:
  %t735 = load ptr, ptr %l0, !tbaa !29
  store ptr %t735, ptr %l355, !tbaa !29
  %t736 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t736, ptr %l356
  %t737 = load ptr, ptr %l0, !tbaa !29
  %t739 = getelementptr %"compiler/check:Checker", ptr %t737, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !29
  %t742 = getelementptr %"compiler/generic:Program", ptr %t740, i32 0, i32 2
  %t743 = load i32, ptr %l8, !tbaa !23
  %t746 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t742, i32 %t743)
  store i32 %t746, ptr %l361
  br label %bb124
bb123:
  store %olang.scope zeroinitializer, ptr %s21
  %t747 = load ptr, ptr %l0, !tbaa !29
  %t748 = load %"compiler/source:Span", ptr %l11
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s21, ptr %t747, %"compiler/source:Span" %t748, { i64, ptr } { i64 45, ptr getelementptr inbounds (<{ i64, [45 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb127
bb124:
  store i32 21, ptr %l362
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t752 = load ptr, ptr %l22, !tbaa !29
  %t753 = load %"compiler/source:Span", ptr %l11
  %t757 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t751, ptr %t752, %"compiler/source:Span" %t753)
  store ptr %t757, ptr %l366
  br label %bb125
bb125:
  %t758 = load ptr, ptr %l355, !tbaa !29
  %t759 = load %"compiler/source:Span", ptr %l356
  %t760 = load i32, ptr %l361, !tbaa !23
  %t761 = load i32, ptr %l362
  %t762 = load ptr, ptr %l366, !tbaa !29
  %t763 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t758, %"compiler/source:Span" %t759, i32 %t760, i32 %t761, ptr %t762, ptr null)
  store ptr %t763, ptr %l367
  br label %bb126
bb126:
  %t764 = load ptr, ptr %l367, !tbaa !29
  store ptr %t764, ptr %l31, !tbaa !29
  br label %bb129
bb127:
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t767 = load %"compiler/source:Span", ptr %l11
  %t770 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t766, %"compiler/source:Span" %t767)
  store ptr %t770, ptr %l373
  br label %bb128
bb128:
  %t771 = load ptr, ptr %l373, !tbaa !29
  store ptr %t771, ptr %l31, !tbaa !29
  call void @__olang_scope_close(ptr %s21)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s19)
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s17)
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s15)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t773 = load ptr, ptr %l10, !tbaa !29
  store ptr %t773, ptr %l375, !tbaa !29
  %t774 = load ptr, ptr %l375, !tbaa !29
  %t775 = getelementptr %"compiler/check:frame", ptr %t774, i32 0, i32 15
  %t776 = load i64, ptr %t775, !tbaa !24
  %t778 = sub i64 %t776, 1
  %t780 = load ptr, ptr %l375, !tbaa !29
  %t781 = getelementptr %"compiler/check:frame", ptr %t780, i32 0, i32 15
  store i64 %t778, ptr %t781, !tbaa !24
  %t782 = load ptr, ptr %l31, !tbaa !29
  %t784 = icmp eq ptr %t782, null
  br i1 %t784, label %bb134, label %bb135
bb134:
  call void @__olang_check_failed(ptr @olang_loc_e17fa1ab378faab9_6d6fcc9fefe16fc5)
  unreachable
bb135:
  br label %bb136
bb136:
  %t786 = load ptr, ptr %l31, !tbaa !29
  store ptr %t786, ptr %l36, !tbaa !29
  %t788 = load ptr, ptr %l0, !tbaa !29
  %t790 = getelementptr %"compiler/check:Checker", ptr %t788, i32 0, i32 1
  %t791 = load ptr, ptr %t790, !tbaa !29
  %t793 = getelementptr %"compiler/generic:Program", ptr %t791, i32 0, i32 2
  store ptr %t793, ptr %l383, !tbaa !29
  %t794 = load ptr, ptr %l0, !tbaa !29
  %t796 = getelementptr %"compiler/check:Checker", ptr %t794, i32 0, i32 1
  %t797 = load ptr, ptr %t796, !tbaa !29
  %t799 = getelementptr %"compiler/generic:Program", ptr %t797, i32 0, i32 2
  %t800 = load i32, ptr %l8, !tbaa !23
  %t803 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t799, i32 %t800)
  store i32 %t803, ptr %l388
  br label %bb137
bb137:
  %t804 = load ptr, ptr %l383, !tbaa !29
  %t805 = load i32, ptr %l388, !tbaa !23
  %t806 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t804, i32 %t805)
  store { i64, ptr } %t806, ptr %l389
  br label %bb138
bb138:
  %t807 = load { i64, ptr }, ptr %l389, !tbaa !27
  %t808 = extractvalue { i64, ptr } %t807, 0
  %t810 = icmp sgt i64 %t808, 0
  br i1 %t810, label %bb139, label %bb140
bb139:
  %t812 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t812, ptr %l392
  %t813 = load ptr, ptr %l36, !tbaa !29
  %t816 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t813)
  store i32 %t816, ptr %l395
  br label %bb141
bb140:
  br label %bb147
bb141:
  %t817 = load ptr, ptr %l36, !tbaa !29
  store ptr %t817, ptr %l397, !tbaa !29
  %t819 = icmp sge i64 0, 0
  br i1 %t819, label %bb142, label %bb143
bb142:
  %t821 = icmp sle i64 0, 1152921504606846975
  br i1 %t821, label %bb144, label %bb145
bb143:
  call void @__olang_check_failed(ptr @olang_loc_cd555273ac5ad6b8_af09fb78e7087b4)
  unreachable
bb144:
  %t823 = mul i64 0, 8
  %t824 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t823)
  %t825 = insertvalue { i64, ptr } undef, i64 0, 0
  %t826 = insertvalue { i64, ptr } %t825, ptr %t824, 1
  %t827 = load ptr, ptr %l397, !tbaa !29
  %t829 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t827, { i64, ptr } %t826, i1 false, i1 false)
  store %"compiler/typed:Try" %t829, ptr %l401
  br label %bb146
bb145:
  call void @__olang_check_failed(ptr @olang_loc_cd555273ac5ad6b8_af09fb78e7087b4)
  unreachable
bb146:
  %t830 = load %"compiler/typed:Try", ptr %l401
  %t831 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Try" %t830, ptr %t831
  store { i64, [5 x i64] } zeroinitializer, ptr %t832
  %t833 = getelementptr { i64, [5 x i64] }, ptr %t832, i32 0, i32 0
  store i64 14, ptr %t833
  %t834 = load %"compiler/source:Span", ptr %l392
  %t835 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t834, 0
  %t836 = load i32, ptr %l395, !tbaa !23
  %t837 = insertvalue { %"compiler/source:Span", i32, ptr } %t835, i32 %t836, 1
  %t839 = insertvalue { %"compiler/source:Span", i32, ptr } %t837, ptr %t831, 2
  %t840 = getelementptr { i64, [5 x i64] }, ptr %t832, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t839, ptr %t840
  %t841 = load { i64, [5 x i64] }, ptr %t832
  %t843 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t841, ptr %t843
  store ptr %t843, ptr %l36, !tbaa !29
  br label %bb147
bb147:
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t847 = getelementptr %"compiler/check:Checker", ptr %t845, i32 0, i32 33
  %t849 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t847)
  store i64 %t849, ptr %l407
  br label %bb148
bb148:
  %t850 = load i64, ptr %l407, !tbaa !24
  store i64 %t850, ptr %l37, !tbaa !24
  %t851 = load ptr, ptr %l0, !tbaa !29
  %t853 = getelementptr %"compiler/check:Checker", ptr %t851, i32 0, i32 1
  %t854 = load ptr, ptr %t853, !tbaa !29
  %t856 = getelementptr %"compiler/generic:Program", ptr %t854, i32 0, i32 2
  %t857 = load i32, ptr %l8, !tbaa !23
  %t860 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t856, i32 %t857)
  store i32 %t860, ptr %l412
  br label %bb149
bb149:
  %t861 = load i32, ptr %l412, !tbaa !23
  store i32 %t861, ptr %l38, !tbaa !23
  %t862 = load i32, ptr %l38, !tbaa !23
  %t863 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t866 = icmp eq i32 %t862, %t863
  br i1 %t866, label %bb150, label %bb151
bb150:
  %t868 = load ptr, ptr %l0, !tbaa !29
  %t870 = getelementptr %"compiler/check:Checker", ptr %t868, i32 0, i32 33
  %t871 = load %"compiler/source:Span", ptr %l11
  %t872 = load ptr, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t873
  %t874 = getelementptr { i64, [3 x i64] }, ptr %t873, i32 0, i32 0
  store i64 2, ptr %t874
  %t876 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t871, 0
  %t878 = insertvalue { %"compiler/source:Span", ptr } %t876, ptr %t872, 1
  %t879 = getelementptr { i64, [3 x i64] }, ptr %t873, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t878, ptr %t879
  %t880 = load { i64, [3 x i64] }, ptr %t873
  %t882 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t880, ptr %t882
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t870, ptr %t882)
  br label %bb152
bb151:
  %t885 = load i32, ptr %l38, !tbaa !23
  %t886 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t889 = icmp eq i32 %t885, %t886
  br i1 %t889, label %bb153, label %bb154
bb152:
  br label %bb160
bb153:
  %t891 = load ptr, ptr %l0, !tbaa !29
  %t893 = getelementptr %"compiler/check:Checker", ptr %t891, i32 0, i32 33
  %t894 = load %"compiler/source:Span", ptr %l11
  %t895 = load ptr, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t896
  %t897 = getelementptr { i64, [3 x i64] }, ptr %t896, i32 0, i32 0
  store i64 2, ptr %t897
  %t899 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t894, 0
  %t901 = insertvalue { %"compiler/source:Span", ptr } %t899, ptr %t895, 1
  %t902 = getelementptr { i64, [3 x i64] }, ptr %t896, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t901, ptr %t902
  %t903 = load { i64, [3 x i64] }, ptr %t896
  %t905 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t903, ptr %t905
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t893, ptr %t905)
  br label %bb155
bb154:
  %t908 = load ptr, ptr %l0, !tbaa !29
  %t910 = getelementptr %"compiler/check:Checker", ptr %t908, i32 0, i32 33
  store ptr %t910, ptr %l438, !tbaa !29
  %t911 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t911, ptr %l439
  %t912 = load ptr, ptr %l0, !tbaa !29
  %t913 = load ptr, ptr %l36, !tbaa !29
  %t914 = load i32, ptr %l38, !tbaa !23
  %t915 = load %"compiler/source:Span", ptr %l11
  %t920 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %t912, ptr %t913, i32 %t914, %"compiler/source:Span" %t915)
  store ptr %t920, ptr %l444
  br label %bb157
bb155:
  %t921 = load ptr, ptr %l0, !tbaa !29
  %t923 = getelementptr %"compiler/check:Checker", ptr %t921, i32 0, i32 33
  %t924 = load %"compiler/source:Span", ptr %l11
  store { i64, [3 x i64] } zeroinitializer, ptr %t925
  %t926 = getelementptr { i64, [3 x i64] }, ptr %t925, i32 0, i32 0
  store i64 9, ptr %t926
  %t928 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t924, 0
  %t930 = insertvalue { %"compiler/source:Span", i32, ptr } %t928, i32 0, 1
  %t931 = insertvalue { %"compiler/source:Span", i32, ptr } %t930, ptr null, 2
  %t932 = getelementptr { i64, [3 x i64] }, ptr %t925, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t931, ptr %t932
  %t933 = load { i64, [3 x i64] }, ptr %t925
  %t935 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t933, ptr %t935
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t923, ptr %t935)
  br label %bb156
bb156:
  br label %bb159
bb157:
  %t938 = load ptr, ptr %l444, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t939
  %t940 = getelementptr { i64, [3 x i64] }, ptr %t939, i32 0, i32 0
  store i64 6, ptr %t940
  %t941 = load %"compiler/source:Span", ptr %l439
  %t942 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t941, 0
  %t944 = insertvalue { %"compiler/source:Span", ptr } %t942, ptr %t938, 1
  %t945 = getelementptr { i64, [3 x i64] }, ptr %t939, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t944, ptr %t945
  %t946 = load { i64, [3 x i64] }, ptr %t939
  %t948 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t946, ptr %t948
  %t949 = load ptr, ptr %l438, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t949, ptr %t948)
  br label %bb158
bb158:
  br label %bb159
bb159:
  br label %bb160
bb160:
  %t951 = load ptr, ptr %l0, !tbaa !29
  %t953 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t951)
  store ptr %t953, ptr %l449
  br label %bb161
bb161:
  %t954 = load ptr, ptr %l449, !tbaa !29
  store ptr %t954, ptr %l450, !tbaa !29
  %t955 = load ptr, ptr %l0, !tbaa !29
  %t957 = getelementptr %"compiler/check:Checker", ptr %t955, i32 0, i32 33
  %t958 = load i64, ptr %l37, !tbaa !24
  %t961 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t957, i64 %t958)
  store { i64, ptr } %t961, ptr %l454
  br label %bb162
bb162:
  %t962 = load { i64, ptr }, ptr %l454, !tbaa !27
  %t963 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t962)
  store %"compiler/typed:Block" %t963, ptr %l455
  br label %bb163
bb163:
  %t964 = load %"compiler/typed:Block", ptr %l455
  %t965 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t964, ptr %t965
  %t967 = load ptr, ptr %l450, !tbaa !29
  %t968 = getelementptr %"compiler/typed:Body", ptr %t967, i32 0, i32 11
  store ptr %t965, ptr %t968, !tbaa !29
  %t969 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t969)
  br label %bb164
bb164:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %l9 = alloca i64
  %l11 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load i32, ptr %l1, !tbaa !23
  %t7 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t3, i32 %t4)
  store i32 %t7, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load i32, ptr %l7, !tbaa !23
  %t12 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %t9, i32 %t10, i32 %a2)
  store i64 %t12, ptr %l9
  br label %bb2
bb2:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t15 = load i64, ptr %l9, !tbaa !24
  %t17 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %t14, i64 %t15, i32 %t13)
  store i32 %t17, ptr %l11
  br label %bb3
bb3:
  %t18 = load i32, ptr %l11, !tbaa !23
  store i32 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econdOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l6 = alloca i32
  %l10 = alloca i1
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"compiler/msgs:Msg"
  %l22 = alloca i64
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t1)
  store i32 %t4, ptr %l6
  br label %bb1
bb1:
  %t5 = load i32, ptr %l6, !tbaa !23
  store i32 %t5, ptr %l3, !tbaa !23
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t10 = icmp ne i32 %t6, %t7
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i32, ptr %l3, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp ne i32 %t12, %t13
  store i1 %t16, ptr %l10, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l10, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l14, !tbaa !29
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t20)
  store %"compiler/source:Span" %t22, ptr %l16
  br label %bb7
bb6:
  br label %bb13
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l3, !tbaa !23
  %t27 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t23, i32 %t24)
  store { i64, ptr } %t27, ptr %l19
  br label %bb8
bb8:
  %t28 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %s1, ptr %s1, { i64, ptr } %t34)
  store %"compiler/msgs:Msg" %t36, ptr %l21
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l14, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l16
  %t39 = load %"compiler/msgs:Msg", ptr %l21
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t37, %"compiler/source:Span" %t38, %"compiler/msgs:Msg" %t39)
  store i64 %t40, ptr %l22
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb11
bb11:
  %t45 = load ptr, ptr %l23, !tbaa !29
  %t46 = load %"compiler/source:Span", ptr %l25
  %t47 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t45, %"compiler/source:Span" %t46)
  store ptr %t47, ptr %l26
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s1)
  %t48 = load ptr, ptr %l26, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
bb13:
  %t49 = load ptr, ptr %l2, !tbaa !29
  store ptr %t49, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecked(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/typed:ContractInfo"
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l15 = alloca i1
  %l19 = alloca i1
  %l20 = alloca %"compiler/typed:ContractInfo"
  %l24 = alloca %"compiler/typed:ContractInfo"
  %l25 = alloca i32
  %l27 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %l48 = alloca i1
  %l58 = alloca ptr
  %l73 = alloca i1
  %l77 = alloca i1
  %l81 = alloca i1
  %l85 = alloca ptr
  %l90 = alloca i1
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 81
  %t4 = load i64, ptr %l1, !tbaa !24
  %t7 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t3, i64 %t4)
  store i1 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i1, ptr %l15, !tbaa !21
  %t9 = xor i1 %t8, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load i64, ptr %l1, !tbaa !24
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t11, i64 %t12)
  store i1 %t15, ptr %l19
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %ret
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 80
  %t19 = load i64, ptr %l1, !tbaa !24
  %t22 = call { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v0, ptr %t18, i64 %t19)
  %t23 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t22, 1
  %t24 = extractvalue { i32, %"compiler/typed:ContractInfo" } %t22, 0
  store i32 %t24, ptr %l25
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb7, label %ok.26
ok.26:
  store %"compiler/typed:ContractInfo" %t23, ptr %l24
  br label %bb6
bb6:
  %t27 = load %"compiler/typed:ContractInfo", ptr %l24
  store %"compiler/typed:ContractInfo" %t27, ptr %l20
  br label %bb9
bb7:
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  br label %ret
bb9:
  %t28 = load %"compiler/typed:ContractInfo", ptr %l20
  store %"compiler/typed:ContractInfo" %t28, ptr %l2
  store i1 false, ptr %l3, !tbaa !21
  %t29 = getelementptr %"compiler/typed:ContractInfo", ptr %l2, i32 0, i32 2
  store ptr %t29, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t31 = load ptr, ptr %l4, !tbaa !29
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %t31, i64 %t32)
  %t36 = extractvalue { i32, { i64, ptr } } %t35, 1
  %t37 = extractvalue { i32, { i64, ptr } } %t35, 0
  store i32 %t37, ptr %l31
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb12, label %ok.39
ok.39:
  store { i64, ptr } %t36, ptr %l30
  br label %bb11
bb11:
  %t40 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t40, ptr %l27, !tbaa !27
  br label %bb16
bb12:
  %t41 = load i32, ptr %l31, !tbaa !23
  %t42 = ashr i32 %t41, 16
  %t44 = icmp eq i32 %t42, 1
  br i1 %t44, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_46400974b7d00480_e2373b052a0b959c)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb16:
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t46, ptr %l6, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t51 = load i64, ptr %l8, !tbaa !24
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb19:
  br label %bb20
bb20:
  %t59 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t59, ptr %l40, !tbaa !27
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr i64, ptr %t63, i64 %t60
  %t65 = load i64, ptr %t64, !tbaa !34
  store i64 %t65, ptr %l9, !tbaa !24
  %t67 = load i1, ptr %l3, !tbaa !21
  br i1 %t67, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l44, !tbaa !21
  br label %bb24
bb22:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 87
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %t71, i64 %t72)
  store i1 %t75, ptr %l48
  br label %bb23
bb23:
  %t76 = load i1, ptr %l48, !tbaa !21
  store i1 %t76, ptr %l44, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l3, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb25:
  %t78 = load i64, ptr %l8, !tbaa !24
  %t80 = add i64 %t78, 1
  store i64 %t80, ptr %l8, !tbaa !24
  br label %bb17
bb26:
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = load i64, ptr %l7, !tbaa !24
  %t86 = add i64 %t82, %t83
  store i64 %t86, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  br label %bb10
bb28:
  %t88 = load i1, ptr %l3, !tbaa !21
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb29, label %bb30
bb29:
  br label %ret
bb30:
  br label %bb31
bb31:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i64, ptr %l1, !tbaa !24
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %t92, i64 %t93)
  store ptr %t96, ptr %l58
  br label %bb32
bb32:
  %t97 = load ptr, ptr %l58, !tbaa !29
  store ptr %t97, ptr %l10, !tbaa !29
  %t98 = load ptr, ptr %l10, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb33, label %bb34
bb33:
  br label %ret
bb34:
  br label %bb35
bb35:
  %t102 = load ptr, ptr %l10, !tbaa !29
  %t104 = getelementptr %"compiler/check:ctSource", ptr %t102, i32 0, i32 0
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/ast:ContractBlock", ptr %t105, i32 0, i32 0
  %t108 = load %"compiler/source:Span", ptr %t107
  store %"compiler/source:Span" %t108, ptr %l11
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t115 = getelementptr %"compiler/generic:Program", ptr %t113, i32 0, i32 0
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/load:Loader", ptr %t116, i32 0, i32 4
  %t119 = load ptr, ptr %t118, !tbaa !29
  %t120 = getelementptr %"compiler/typed:ContractInfo", ptr %l2, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t123 = load i32, ptr %t122, !tbaa !23
  %t125 = sext i32 %t123 to i64
  %t126 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  %t134 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %t119, i64 %t121, i64 %t125, i64 %t129, i64 0)
  store i1 %t134, ptr %l73
  br label %bb36
bb36:
  %t135 = load i1, ptr %l73, !tbaa !21
  br i1 %t135, label %bb37, label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = getelementptr %"compiler/check:Checker", ptr %t136, i32 0, i32 81
  %t139 = load i64, ptr %l1, !tbaa !24
  %t142 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %t138, i64 %t139)
  store i1 %t142, ptr %l77
  br label %bb40
bb40:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 80
  %t146 = load i64, ptr %l1, !tbaa !24
  %t149 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %t145, i64 %t146)
  store i1 %t149, ptr %l81
  br label %bb41
bb41:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 11
  %t153 = load i64, ptr %l1, !tbaa !24
  %t156 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t152, i64 %t153)
  store ptr %t156, ptr %l85
  br label %bb42
bb42:
  %t157 = load ptr, ptr %l85, !tbaa !29
  %t159 = getelementptr %"compiler/typed:Body", ptr %t157, i32 0, i32 12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2eCl_H61e34197f63b762a003a73c4f2bf0624(ptr %v0, ptr %t159)
  br label %bb43
bb43:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i64, ptr %l1, !tbaa !24
  %t165 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t161, i64 %t162)
  store i1 %t165, ptr %l90
  br label %bb44
bb44:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversion(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"compiler/check:litv"
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l15 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca %"compiler/source:Span"
  %l23 = alloca %"compiler/msgs:Msg"
  %l24 = alloca i64
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca %"compiler/check:litv"
  %l35 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l67 = alloca i32
  %l71 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l82 = alloca i1
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l87 = alloca %"compiler/source:Span"
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca %"compiler/msgs:Msg"
  %l97 = alloca i64
  %l100 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l107 = alloca ptr
  %l108 = alloca %"compiler/source:Span"
  %l109 = alloca { i64, ptr }
  %l111 = alloca %"compiler/source:Span"
  %l118 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t7, %"compiler/source:Span" %t8, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d15, i32 0, i32 1) })
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load %"compiler/source:Span", ptr %l1
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t11, %"compiler/source:Span" %t12)
  store ptr %t15, ptr %l15
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t16 = load ptr, ptr %l15, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb5:
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t21 = icmp ne i64 %t19, 1
  br i1 %t21, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  %t24 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t24, ptr %l20
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %s2, ptr %s2, i64 1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d16, i32 0, i32 1) }, i64 %t27)
  store %"compiler/msgs:Msg" %t29, ptr %l23
  br label %bb8
bb7:
  br label %bb11
bb8:
  %t30 = load ptr, ptr %l19, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l20
  %t32 = load %"compiler/msgs:Msg", ptr %l23
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l24
  br label %bb9
bb9:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l1
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t34, %"compiler/source:Span" %t35)
  store ptr %t38, ptr %l27
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load ptr, ptr %l27, !tbaa !29
  store ptr %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr ptr, ptr %t43, i64 0
  %t45 = load ptr, ptr %t44, !tbaa !39
  %t49 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t40, ptr %t45)
  store %"compiler/check:litv" %t49, ptr %l32
  br label %bb12
bb12:
  %t50 = load %"compiler/check:litv", ptr %l32
  store %"compiler/check:litv" %t50, ptr %l4
  %t51 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t51, ptr %l5, !tbaa !23
  %t53 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t54 = load i1, ptr %t53, !tbaa !21
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load %"compiler/check:litv", ptr %l4
  %t58 = load i32, ptr %l2, !tbaa !23
  %t62 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t56, %"compiler/check:litv" %t57, i32 %t58)
  store i1 %t62, ptr %l39
  br label %bb15
bb14:
  store i1 false, ptr %l35, !tbaa !21
  br label %bb16
bb15:
  %t63 = load i1, ptr %l39, !tbaa !21
  store i1 %t63, ptr %l35, !tbaa !21
  br label %bb16
bb16:
  %t64 = load i1, ptr %l35, !tbaa !21
  br i1 %t64, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb18:
  %t65 = getelementptr %"compiler/check:litv", ptr %l4, i32 0, i32 0
  %t66 = load i1, ptr %t65, !tbaa !21
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb19, label %bb20
bb19:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr ptr, ptr %t73, i64 0
  %t75 = load ptr, ptr %t74, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t70, ptr %t75)
  store i1 %t78, ptr %l47
  br label %bb21
bb20:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb26
bb21:
  %t79 = load i1, ptr %l47, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb25
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t81, ptr %l50, !tbaa !27
  %t82 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr ptr, ptr %t83, i64 0
  %t85 = load ptr, ptr %t84, !tbaa !39
  %t88 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %t80, ptr %t85)
  store i1 %t88, ptr %l52
  br label %bb24
bb24:
  %t89 = load i1, ptr %l52, !tbaa !21
  store i1 %t89, ptr %l48, !tbaa !21
  br label %bb25
bb25:
  %t90 = load i1, ptr %l48, !tbaa !21
  store i1 %t90, ptr %l43, !tbaa !21
  br label %bb26
bb26:
  %t91 = load i1, ptr %l43, !tbaa !21
  store i1 %t91, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t92 = load i1, ptr %l40, !tbaa !21
  br i1 %t92, label %bb28, label %bb29
bb28:
  %t93 = load i32, ptr %l2, !tbaa !23
  store i32 %t93, ptr %l5, !tbaa !23
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l54, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t97, ptr %l56, !tbaa !27
  %t98 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = getelementptr ptr, ptr %t99, i64 0
  %t101 = load ptr, ptr %t100, !tbaa !39
  %t103 = load i32, ptr %l5, !tbaa !23
  %t107 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %t96, ptr %t101, i32 %t103)
  store ptr %t107, ptr %l60
  br label %bb31
bb31:
  %t108 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t108, ptr %l61, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr ptr, ptr %t110, i64 0
  %t112 = load ptr, ptr %t111, !tbaa !39
  %t114 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t112)
  store %"compiler/source:Span" %t114, ptr %l63
  br label %bb32
bb32:
  %t115 = load ptr, ptr %l54, !tbaa !29
  %t116 = load ptr, ptr %l60, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l63
  %t118 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t115, ptr %t116, %"compiler/source:Span" %t117)
  store ptr %t118, ptr %l64
  br label %bb33
bb33:
  %t119 = load ptr, ptr %l64, !tbaa !29
  store ptr %t119, ptr %l6, !tbaa !29
  %t120 = load ptr, ptr %l6, !tbaa !29
  %t123 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t120)
  store i32 %t123, ptr %l67
  br label %bb34
bb34:
  %t124 = load i32, ptr %l67, !tbaa !23
  store i32 %t124, ptr %l7, !tbaa !23
  %t125 = load i32, ptr %l7, !tbaa !23
  %t126 = load i32, ptr %l2, !tbaa !23
  %t129 = icmp eq i32 %t125, %t126
  br i1 %t129, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb37
bb36:
  %t131 = load i32, ptr %l7, !tbaa !23
  %t132 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t135 = icmp eq i32 %t131, %t132
  store i1 %t135, ptr %l71, !tbaa !21
  br label %bb37
bb37:
  %t137 = load i1, ptr %l71, !tbaa !21
  br i1 %t137, label %bb38, label %bb39
bb38:
  %t138 = load ptr, ptr %l6, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t140, i32 %t141)
  store i1 %t144, ptr %l78
  br label %bb41
bb41:
  %t145 = load i1, ptr %l78, !tbaa !21
  br i1 %t145, label %bb42, label %bb43
bb42:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l2, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l82
  br label %bb44
bb43:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb45
bb44:
  %t151 = load i1, ptr %l82, !tbaa !21
  store i1 %t151, ptr %l79, !tbaa !21
  br label %bb45
bb45:
  %t152 = load i1, ptr %l79, !tbaa !21
  %t153 = xor i1 %t152, true
  br i1 %t153, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s5
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l84, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t156, ptr %l85, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr ptr, ptr %t158, i64 0
  %t160 = load ptr, ptr %t159, !tbaa !39
  %t162 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t160)
  store %"compiler/source:Span" %t162, ptr %l87
  br label %bb48
bb47:
  br label %bb54
bb48:
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load i32, ptr %l2, !tbaa !23
  %t167 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t163, i32 %t164)
  store { i64, ptr } %t167, ptr %l90
  br label %bb49
bb49:
  %t168 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  %t170 = extractvalue { i64, ptr } %t168, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  store { i64, ptr } %t174, ptr %l91, !tbaa !27
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t176 = load i32, ptr %l7, !tbaa !23
  %t179 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t175, i32 %t176)
  store { i64, ptr } %t179, ptr %l94
  br label %bb50
bb50:
  %t180 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t189 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t187, { i64, ptr } %t186)
  store %"compiler/msgs:Msg" %t189, ptr %l96
  br label %bb51
bb51:
  %t190 = load ptr, ptr %l84, !tbaa !29
  %t191 = load %"compiler/source:Span", ptr %l87
  %t192 = load %"compiler/msgs:Msg", ptr %l96
  %t193 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t190, %"compiler/source:Span" %t191, %"compiler/msgs:Msg" %t192)
  store i64 %t193, ptr %l97
  br label %bb52
bb52:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load %"compiler/source:Span", ptr %l1
  %t198 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t194, %"compiler/source:Span" %t195)
  store ptr %t198, ptr %l100
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t199 = load ptr, ptr %l100, !tbaa !29
  store ptr %t199, ptr %rv
  br label %ret
bb54:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i32, ptr %l7, !tbaa !23
  %t202 = load i32, ptr %l2, !tbaa !23
  %t206 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t200, i32 %t201, i32 %t202)
  store { i64, ptr } %t206, ptr %l104
  br label %bb55
bb55:
  %t207 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  %t210 = icmp sgt i64 %t208, 0
  br i1 %t210, label %bb56, label %bb57
bb56:
  %t212 = load ptr, ptr %l0, !tbaa !29
  store ptr %t212, ptr %l107, !tbaa !29
  %t213 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t213, ptr %l108
  %t214 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t214, ptr %l109, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = getelementptr ptr, ptr %t216, i64 0
  %t218 = load ptr, ptr %t217, !tbaa !39
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l111
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t221 = load ptr, ptr %l6, !tbaa !29
  %t222 = load i32, ptr %l2, !tbaa !23
  %t223 = load ptr, ptr %l107, !tbaa !29
  %t224 = load %"compiler/source:Span", ptr %l108
  %t225 = load %"compiler/source:Span", ptr %l111
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %t223, %"compiler/source:Span" %t224, %"compiler/source:Span" %t225, ptr %t221, i32 %t222)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t229 = load %"compiler/source:Span", ptr %l1
  %t230 = load ptr, ptr %l6, !tbaa !29
  %t231 = load i32, ptr %l2, !tbaa !23
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %t228, %"compiler/source:Span" %t229, ptr %t230, i32 %t231)
  store ptr %t236, ptr %l118
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s0)
  %t237 = load ptr, ptr %l118, !tbaa !29
  store ptr %t237, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econversionAt(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l17 = alloca ptr
  %l21 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i1
  %l30 = alloca i1
  %l40 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l46 = alloca { i64, [2 x i64] }
  %l51 = alloca i32
  %l54 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l65 = alloca %"compiler/generic:Context"
  %l67 = alloca ptr
  %l70 = alloca i32
  %l73 = alloca i64
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l89 = alloca ptr
  %l90 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca %"compiler/typed:Block"
  %l105 = alloca { { i64, [3 x i64] }, { i64, ptr } }
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l111 = alloca ptr
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca %"compiler/source:Span"
  %l115 = alloca i64
  %l116 = alloca %"compiler/source:Span"
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, [3 x i64] }
  %l121 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca %"compiler/check:ContractAsk"
  %s0 = alloca %olang.scope
  %t70 = alloca { i64, [2 x i64] }, align 8
  %t154 = alloca { i64, [3 x i64] }, align 8
  %t266 = alloca %"compiler/check:ContractAsk", align 8
  %t277 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l17, !tbaa !29
  store ptr %t4, ptr %l5, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 49
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = icmp ne i64 %t8, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb4
bb3:
  %t12 = load ptr, ptr %l5, !tbaa !29
  %t14 = getelementptr %"compiler/check:frame", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l21, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l21, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb8
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l27
  br label %bb7
bb7:
  %t23 = load i1, ptr %l27, !tbaa !21
  store i1 %t23, ptr %l25, !tbaa !21
  br label %bb8
bb8:
  %t24 = load i1, ptr %l25, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb12
bb10:
  %t25 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l30
  br label %bb11
bb11:
  %t28 = load i1, ptr %l30, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l28, !tbaa !21
  br label %bb12
bb12:
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 1
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  %t37 = load ptr, ptr %l5, !tbaa !29
  %t39 = getelementptr %"compiler/check:frame", ptr %t37, i32 0, i32 2
  %t40 = load i64, ptr %t39, !tbaa !24
  store i64 %t40, ptr %l7, !tbaa !24
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/check:frame", ptr %t42, i32 0, i32 0
  %t45 = load i64, ptr %t44, !tbaa !24
  store i64 %t45, ptr %l8, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l2
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t51, ptr %l40
  br label %bb16
bb16:
  %t52 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l9, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l43, !tbaa !29
  %t67 = load i64, ptr %l6, !tbaa !24
  %t68 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t69 = load i32, ptr %t68, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t70
  %t71 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 0
  store i64 7, ptr %t71
  %t73 = insertvalue { i64, i32 } undef, i64 %t67, 0
  %t75 = insertvalue { i64, i32 } %t73, i32 %t69, 1
  %t76 = getelementptr { i64, [2 x i64] }, ptr %t70, i32 0, i32 1
  store { i64, i32 } %t75, ptr %t76
  %t77 = load { i64, [2 x i64] }, ptr %t70
  store { i64, [2 x i64] } %t77, ptr %l46
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t83, i32 0, i32 %t84, i32 0, i32 0, i64 0)
  store i32 %t87, ptr %l51
  br label %bb17
bb17:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load %"compiler/source:Span", ptr %l1
  %t90 = load ptr, ptr %l43, !tbaa !29
  %t91 = load { i64, [2 x i64] }, ptr %l46
  %t92 = load i32, ptr %l51, !tbaa !23
  %t95 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t90, { i64, [2 x i64] } %t91, i32 %t92, i64 %t88, %"compiler/source:Span" %t89)
  store i64 %t95, ptr %l54
  br label %bb18
bb18:
  %t96 = load i64, ptr %l54, !tbaa !24
  store i64 %t96, ptr %l10, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 16
  %t100 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t99, i64 %t100, i64 1)
  br label %bb19
bb19:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t104 = load i64, ptr %l10, !tbaa !24
  %t105 = load i64, ptr %l6, !tbaa !24
  %t106 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t103, i64 %t104, i64 %t105, i32 %t106, i32 0)
  store ptr %t111, ptr %l62
  br label %bb20
bb20:
  %t112 = load ptr, ptr %l62, !tbaa !29
  store ptr %t112, ptr %l63, !tbaa !29
  %t114 = load i64, ptr %l6, !tbaa !24
  %t116 = call %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %t114, i64 -1)
  store %"compiler/generic:Context" %t116, ptr %l65
  br label %bb21
bb21:
  %t117 = load %"compiler/generic:Context", ptr %l65
  %t118 = load ptr, ptr %l63, !tbaa !29
  %t119 = getelementptr %"compiler/check:frame", ptr %t118, i32 0, i32 4
  store %"compiler/generic:Context" %t117, ptr %t119
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t120)
  store ptr %t122, ptr %l67
  br label %bb22
bb22:
  %t123 = load %"compiler/source:Span", ptr %l1
  %t124 = load ptr, ptr %l67, !tbaa !29
  %t127 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t124, i32 -1, i32 0, %"compiler/source:Span" %t123)
  store i32 %t127, ptr %l70
  br label %bb23
bb23:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 33
  %t132 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t130)
  store i64 %t132, ptr %l73
  br label %bb24
bb24:
  %t133 = load i64, ptr %l73, !tbaa !24
  store i64 %t133, ptr %l12, !tbaa !24
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 33
  store ptr %t136, ptr %l75, !tbaa !29
  %t137 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t137, ptr %l76
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l77, !tbaa !29
  %t139 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t139, ptr %l78
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %l3, !tbaa !29
  %t142 = load i64, ptr %l8, !tbaa !24
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v0, ptr %t140, ptr %t141, i64 %t142)
  store ptr %t146, ptr %l82
  br label %bb25
bb25:
  %t147 = load i32, ptr %l4, !tbaa !23
  %t148 = load ptr, ptr %l77, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l78
  %t150 = load ptr, ptr %l82, !tbaa !29
  %t152 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %t148, %"compiler/source:Span" %t149, ptr %t150, i32 %t147)
  store ptr %t152, ptr %l84
  br label %bb26
bb26:
  %t153 = load ptr, ptr %l84, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t154
  %t155 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 0
  store i64 6, ptr %t155
  %t156 = load %"compiler/source:Span", ptr %l76
  %t157 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t156, 0
  %t159 = insertvalue { %"compiler/source:Span", ptr } %t157, ptr %t153, 1
  %t160 = getelementptr { i64, [3 x i64] }, ptr %t154, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t159, ptr %t160
  %t161 = load { i64, [3 x i64] }, ptr %t154
  %t163 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t161, ptr %t163
  %t164 = load ptr, ptr %l75, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t164, ptr %t163)
  br label %bb27
bb27:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t166)
  store ptr %t168, ptr %l89
  br label %bb28
bb28:
  %t169 = load ptr, ptr %l89, !tbaa !29
  store ptr %t169, ptr %l90, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 33
  %t173 = load i64, ptr %l12, !tbaa !24
  %t176 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t172, i64 %t173)
  store { i64, ptr } %t176, ptr %l94
  br label %bb29
bb29:
  %t177 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t178 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t177)
  store %"compiler/typed:Block" %t178, ptr %l95
  br label %bb30
bb30:
  %t179 = load %"compiler/typed:Block", ptr %l95
  %t180 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Block" %t179, ptr %t180
  %t182 = load ptr, ptr %l90, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Body", ptr %t182, i32 0, i32 11
  store ptr %t180, ptr %t183, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t184)
  br label %bb31
bb31:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 16
  %t189 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t188, i64 %t189, i64 2)
  br label %bb32
bb32:
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t192, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  %t200 = getelementptr %"compiler/load:Loader", ptr %t198, i32 0, i32 4
  %t201 = load ptr, ptr %t200, !tbaa !29
  %t203 = call { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %s0, ptr %t201)
  store { { i64, [3 x i64] }, { i64, ptr } } %t203, ptr %l105
  br label %bb33
bb33:
  %t204 = load { { i64, [3 x i64] }, { i64, ptr } }, ptr %l105
  store { { i64, [3 x i64] }, { i64, ptr } } %t204, ptr %l13
  %t205 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 0
  %t206 = load { i64, [3 x i64] }, ptr %t205
  %t208 = getelementptr { { i64, [3 x i64] }, { i64, ptr } }, ptr %l13, i32 0, i32 1
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  store { i64, ptr } %t209, ptr %l107, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t210, 0
  store i64 %t211, ptr %l108, !tbaa !24
  %t212 = load i64, ptr %l108, !tbaa !24
  %t213 = mul i64 %t212, 1
  %t214 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t213)
  %t215 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  store { i64, ptr } %t216, ptr %l109, !tbaa !27
  %t217 = getelementptr { i64, ptr }, ptr %l109, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t220 = load ptr, ptr %t219, !tbaa !27
  %t221 = load i64, ptr %l108, !tbaa !24
  %t222 = mul i64 %t221, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t218, ptr %t220, i64 %t222, i1 false)
  %t223 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 82
  store ptr %t226, ptr %l111, !tbaa !29
  %t227 = load i64, ptr %l10, !tbaa !24
  store i64 %t227, ptr %l112, !tbaa !24
  %t228 = load i64, ptr %l7, !tbaa !24
  store i64 %t228, ptr %l113, !tbaa !24
  %t229 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t229, ptr %l114
  %t230 = load i64, ptr %l7, !tbaa !24
  store i64 %t230, ptr %l115, !tbaa !24
  %t231 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t231, ptr %l116
  %t232 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t232, ptr %l117, !tbaa !27
  store { i64, [3 x i64] } %t206, ptr %l118
  %t236 = extractvalue { i64, ptr } %t223, 1
  %t237 = extractvalue { i64, ptr } %t223, 0
  %t238 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t237)
  call void @olang_textcopy(ptr %t238, ptr %t236, i64 %t237)
  %t239 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l121, !tbaa !27
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i32, ptr %l4, !tbaa !23
  %t252 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t248, i32 %t249)
  store { i64, ptr } %t252, ptr %l124
  br label %bb34
bb34:
  %t253 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t254 = extractvalue { i64, ptr } %t253, 1
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t255)
  call void @olang_textcopy(ptr %t256, ptr %t254, i64 %t255)
  %t257 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = extractvalue { i64, ptr } %t258, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  %t267 = load i64, ptr %l112, !tbaa !24
  %t268 = load i64, ptr %l113, !tbaa !24
  %t269 = load %"compiler/source:Span", ptr %l114
  %t270 = load i64, ptr %l115, !tbaa !24
  %t271 = load %"compiler/source:Span", ptr %l116
  %t272 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t273 = load { i64, [3 x i64] }, ptr %l118
  %t274 = load { i64, ptr }, ptr %l121, !tbaa !27
  call void @compiler_2fcheck_3aContractAsk_2ector(ptr %t266, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, i64 %t267, i64 %t268, %"compiler/source:Span" %t269, i64 %t270, %"compiler/source:Span" %t271, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d17, i32 0, i32 1) }, { i64, ptr } %t272, { i64, [3 x i64] } %t273, { i64, ptr } %t274, { i64, ptr } %t265)
  call void @llvm.memmove.p0.p0.i64(ptr %l127, ptr %t266, i64 136, i1 false)
  br label %bb35
bb35:
  %t276 = load ptr, ptr %l111, !tbaa !29
  call void @llvm.memmove.p0.p0.i64(ptr %t277, ptr %l127, i64 136, i1 false)
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_H1e0eaace9d10c5af057a64b660c4ff1f(ptr %v0, ptr %v0, ptr %t276, ptr %t277)
  br label %bb36
bb36:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 83
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t280, i64 -1)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecounted(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3, i64 %a4, i64 %a5, i32 %a6, i64 %a7, i64 %a8, ptr %a9, i32 %a10) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, i64, i64 }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, i64, i64 }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i64
  %l36 = alloca { i64, i64, i64 }
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca %"compiler/source:Span"
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l55 = alloca i32
  %l56 = alloca i32
  %l60 = alloca ptr
  %l64 = alloca ptr
  %l66 = alloca ptr
  %l68 = alloca ptr
  %l71 = alloca i32
  %l82 = alloca i64
  %l83 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l87 = alloca i32
  %l91 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca %"compiler/source:Span"
  %l104 = alloca i32
  %l108 = alloca ptr
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l113 = alloca %"compiler/source:Span"
  %l118 = alloca i32
  %l119 = alloca ptr
  %l123 = alloca ptr
  %l125 = alloca %"compiler/typed:Elem"
  %l129 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l133 = alloca i32
  %l134 = alloca i32
  %l138 = alloca ptr
  %l139 = alloca ptr
  %l140 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca i32
  %l146 = alloca ptr
  %l150 = alloca ptr
  %l152 = alloca ptr
  %l154 = alloca ptr
  %l156 = alloca ptr
  %l158 = alloca i32
  %l159 = alloca %"compiler/source:Span"
  %l161 = alloca i32
  %l164 = alloca i64
  %l169 = alloca ptr
  %l171 = alloca ptr
  %l175 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l181 = alloca ptr
  %l183 = alloca ptr
  %l187 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l189 = alloca ptr
  %l191 = alloca ptr
  %l195 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l196 = alloca ptr
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca ptr
  %l199 = alloca i64
  %l203 = alloca ptr
  %l204 = alloca %"compiler/source:Span"
  %l207 = alloca i32
  %l217 = alloca i64
  %l219 = alloca ptr
  %l222 = alloca i64
  %l223 = alloca i32
  %l224 = alloca i64
  %l226 = alloca ptr
  %l229 = alloca i64
  %l230 = alloca i32
  %l236 = alloca ptr
  %l239 = alloca i64
  %l243 = alloca { i64, i64, i64 }
  %l247 = alloca ptr
  %l248 = alloca %"compiler/source:Span"
  %l249 = alloca i32
  %l250 = alloca i32
  %l254 = alloca ptr
  %l258 = alloca ptr
  %l260 = alloca ptr
  %l278 = alloca ptr
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %t97 = alloca { i64, [2 x i64] }, align 8
  %t121 = alloca { i64, [3 x i64] }, align 8
  %t173 = alloca { i64, [4 x i64] }, align 8
  %t213 = alloca { i64, [4 x i64] }, align 8
  %t275 = alloca { i64, [2 x i64] }, align 8
  %t378 = alloca { i64, [3 x i64] }, align 8
  %t494 = alloca { i64, [4 x i64] }, align 8
  %t507 = alloca { i64, [3 x i64] }, align 8
  %t538 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 33
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l32
  br label %bb1
bb1:
  %t6 = load i64, ptr %l32, !tbaa !24
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load %"compiler/source:Span", ptr %l1
  %t12 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t7, i32 2, %"compiler/source:Span" %t8)
  store { i64, i64, i64 } %t12, ptr %l36
  br label %bb2
bb2:
  %t13 = load { i64, i64, i64 }, ptr %l36
  store { i64, i64, i64 } %t13, ptr %l12
  %t14 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l13, !tbaa !24
  %t17 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 1
  %t18 = load i64, ptr %t17, !tbaa !24
  store i64 %t18, ptr %l14, !tbaa !24
  %t20 = getelementptr { i64, i64, i64 }, ptr %l12, i32 0, i32 2
  %t21 = load i64, ptr %t20, !tbaa !24
  store i64 %t21, ptr %l15, !tbaa !24
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t23)
  store ptr %t25, ptr %l41
  br label %bb3
bb3:
  %t26 = load ptr, ptr %l41, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t32)
  store ptr %t34, ptr %l46
  br label %bb5
bb5:
  %t35 = load ptr, ptr %l46, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 11
  %t38 = load i64, ptr %l13, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t37, i64 %t38)
  br label %bb6
bb6:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l50, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l51, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t43, ptr %l52
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l53, !tbaa !29
  %t45 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t45, ptr %l54
  %t46 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t46, ptr %l55, !tbaa !23
  store i32 15, ptr %l56
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l1
  %t49 = load i64, ptr %l3, !tbaa !24
  %t53 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t47, %"compiler/source:Span" %t48, i64 %t49)
  store ptr %t53, ptr %l60
  br label %bb7
bb7:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t54, %"compiler/source:Span" %t55, i64 %a4)
  store ptr %t60, ptr %l64
  br label %bb8
bb8:
  %t61 = load ptr, ptr %l64, !tbaa !29
  %t62 = load ptr, ptr %l53, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l54
  %t64 = load i32, ptr %l55, !tbaa !23
  %t65 = load i32, ptr %l56
  %t66 = load ptr, ptr %l60, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t62, %"compiler/source:Span" %t63, i32 %t64, i32 %t65, ptr %t66, ptr %t61)
  store ptr %t68, ptr %l66
  br label %bb9
bb9:
  %t69 = load i64, ptr %l13, !tbaa !24
  %t70 = load ptr, ptr %l51, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l52
  %t72 = load ptr, ptr %l66, !tbaa !29
  %t74 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %t70, %"compiler/source:Span" %t71, ptr %t72, i64 %t69)
  store ptr %t74, ptr %l68
  br label %bb10
bb10:
  %t75 = load ptr, ptr %l50, !tbaa !29
  %t76 = load ptr, ptr %l68, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t75, ptr %t76)
  br label %bb11
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l3, !tbaa !24
  %t81 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t77, i64 %t78)
  store i32 %t81, ptr %l71
  br label %bb12
bb12:
  %t82 = load i32, ptr %l71, !tbaa !23
  store i32 %t82, ptr %l16, !tbaa !23
  %t83 = load ptr, ptr %l2, !tbaa !29
  %t85 = getelementptr %"compiler/ast:ForIn", ptr %t83, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t88 = icmp ne i32 %t86, 0
  br i1 %t88, label %bb13, label %bb14
bb13:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load ptr, ptr %l2, !tbaa !29
  %t93 = getelementptr %"compiler/ast:ForIn", ptr %t91, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = load %"compiler/source:Span", ptr %l1
  %t96 = load i32, ptr %l16, !tbaa !23
  store { i64, [2 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [2 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load { i64, [2 x i64] }, ptr %t97
  %t106 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t90, i32 %t94, %"compiler/source:Span" %t95, i32 %t96, i32 1, { i64, [2 x i64] } %t99)
  store i64 %t106, ptr %l82
  br label %bb15
bb14:
  br label %bb18
bb15:
  %t107 = load i64, ptr %l82, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l83, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t109, ptr %l84
  %t112 = trunc i64 %t107 to i32
  store i32 %t112, ptr %l87, !tbaa !23
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load %"compiler/source:Span", ptr %l1
  %t116 = load i64, ptr %l3, !tbaa !24
  %t120 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t114, %"compiler/source:Span" %t115, i64 %t116)
  store ptr %t120, ptr %l91
  br label %bb16
bb16:
  store { i64, [3 x i64] } zeroinitializer, ptr %t121
  %t122 = getelementptr { i64, [3 x i64] }, ptr %t121, i32 0, i32 0
  store i64 0, ptr %t122
  %t123 = load %"compiler/source:Span", ptr %l84
  %t124 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t123, 0
  %t125 = load i32, ptr %l87, !tbaa !23
  %t126 = insertvalue { %"compiler/source:Span", i32, ptr } %t124, i32 %t125, 1
  %t127 = load ptr, ptr %l91, !tbaa !29
  %t128 = insertvalue { %"compiler/source:Span", i32, ptr } %t126, ptr %t127, 2
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t121, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t128, ptr %t129
  %t130 = load { i64, [3 x i64] }, ptr %t121
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t130, ptr %t132
  %t133 = load ptr, ptr %l83, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t133, ptr %t132)
  br label %bb17
bb17:
  br label %bb18
bb18:
  store ptr null, ptr %l18, !tbaa !29
  %t135 = load i64, ptr %l5, !tbaa !24
  %t137 = icmp sge i64 %t135, 0
  br i1 %t137, label %bb19, label %bb20
bb19:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i64, ptr %l5, !tbaa !24
  %t143 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t139, i64 %t140)
  store i32 %t143, ptr %l98
  br label %bb21
bb20:
  %t144 = load ptr, ptr %l0, !tbaa !29
  store ptr %t144, ptr %l131, !tbaa !29
  %t145 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t145, ptr %l132
  %t146 = load i32, ptr %l16, !tbaa !23
  store i32 %t146, ptr %l133, !tbaa !23
  store i32 3, ptr %l134
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t153 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t147, %"compiler/source:Span" %t148, i64 %a7)
  store ptr %t153, ptr %l138
  br label %bb28
bb21:
  %t154 = load i32, ptr %l98, !tbaa !23
  %t155 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t155, ptr %l99
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t161 = getelementptr %"compiler/generic:Program", ptr %t159, i32 0, i32 2
  %t165 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t161, i32 %t154)
  store i32 %t165, ptr %l104
  br label %bb22
bb22:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load %"compiler/source:Span", ptr %l1
  %t168 = load i64, ptr %l5, !tbaa !24
  %t172 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t166, %"compiler/source:Span" %t167, i64 %t168)
  store ptr %t172, ptr %l108
  br label %bb23
bb23:
  store { i64, [4 x i64] } zeroinitializer, ptr %t173
  %t174 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 0
  store i64 2, ptr %t174
  %t175 = load %"compiler/source:Span", ptr %l99
  %t176 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t175, 0
  %t177 = load i32, ptr %l104, !tbaa !23
  %t178 = insertvalue { %"compiler/source:Span", i32, ptr } %t176, i32 %t177, 1
  %t179 = load ptr, ptr %l108, !tbaa !29
  %t180 = insertvalue { %"compiler/source:Span", i32, ptr } %t178, ptr %t179, 2
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t180, ptr %t181
  %t182 = load { i64, [4 x i64] }, ptr %t173
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t182, ptr %t184
  store ptr %t184, ptr %l20, !tbaa !29
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l111, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t187, ptr %l112
  %t188 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t188, ptr %l113
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t194, i32 %a6)
  store i32 %t198, ptr %l118
  br label %bb24
bb24:
  %t199 = load ptr, ptr %l20, !tbaa !29
  store ptr %t199, ptr %l119, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  %t202 = load i64, ptr %l3, !tbaa !24
  %t206 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t200, %"compiler/source:Span" %t201, i64 %t202)
  store ptr %t206, ptr %l123
  br label %bb25
bb25:
  %t207 = load ptr, ptr %l119, !tbaa !29
  %t208 = load ptr, ptr %l123, !tbaa !29
  %t210 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %t207, ptr %t208, i32 0)
  store %"compiler/typed:Elem" %t210, ptr %l125
  br label %bb26
bb26:
  %t211 = load %"compiler/typed:Elem", ptr %l125
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Elem" %t211, ptr %t212
  store { i64, [4 x i64] } zeroinitializer, ptr %t213
  %t214 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 0
  store i64 4, ptr %t214
  %t215 = load %"compiler/source:Span", ptr %l113
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t215, 0
  %t217 = load i32, ptr %l118, !tbaa !23
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr } %t216, i32 %t217, 1
  %t220 = insertvalue { %"compiler/source:Span", i32, ptr } %t218, ptr %t212, 2
  %t221 = getelementptr { i64, [4 x i64] }, ptr %t213, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t220, ptr %t221
  %t222 = load { i64, [4 x i64] }, ptr %t213
  %t224 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t222, ptr %t224
  %t225 = load ptr, ptr %l111, !tbaa !29
  %t226 = load %"compiler/source:Span", ptr %l112
  %t228 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t225, %"compiler/source:Span" %t226, ptr %t224)
  store ptr %t228, ptr %l129
  br label %bb27
bb27:
  %t229 = load ptr, ptr %l129, !tbaa !29
  store ptr %t229, ptr %l18, !tbaa !29
  br label %bb33
bb28:
  %t231 = load ptr, ptr %l0, !tbaa !29
  store ptr %t231, ptr %l139, !tbaa !29
  %t232 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t232, ptr %l140
  %t233 = load i32, ptr %l16, !tbaa !23
  store i32 %t233, ptr %l141, !tbaa !23
  store i32 5, ptr %l142
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l1
  %t236 = load i64, ptr %l3, !tbaa !24
  %t240 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t234, %"compiler/source:Span" %t235, i64 %t236)
  store ptr %t240, ptr %l146
  br label %bb29
bb29:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t242 = load %"compiler/source:Span", ptr %l1
  %t247 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t241, %"compiler/source:Span" %t242, i64 %a8)
  store ptr %t247, ptr %l150
  br label %bb30
bb30:
  %t248 = load ptr, ptr %l150, !tbaa !29
  %t249 = load ptr, ptr %l139, !tbaa !29
  %t250 = load %"compiler/source:Span", ptr %l140
  %t251 = load i32, ptr %l141, !tbaa !23
  %t252 = load i32, ptr %l142
  %t253 = load ptr, ptr %l146, !tbaa !29
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t249, %"compiler/source:Span" %t250, i32 %t251, i32 %t252, ptr %t253, ptr %t248)
  store ptr %t255, ptr %l152
  br label %bb31
bb31:
  %t256 = load ptr, ptr %l152, !tbaa !29
  %t257 = load ptr, ptr %l131, !tbaa !29
  %t258 = load %"compiler/source:Span", ptr %l132
  %t259 = load i32, ptr %l133, !tbaa !23
  %t260 = load i32, ptr %l134
  %t261 = load ptr, ptr %l138, !tbaa !29
  %t263 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t257, %"compiler/source:Span" %t258, i32 %t259, i32 %t260, ptr %t261, ptr %t256)
  store ptr %t263, ptr %l154
  br label %bb32
bb32:
  %t264 = load ptr, ptr %l154, !tbaa !29
  store ptr %t264, ptr %l18, !tbaa !29
  br label %bb33
bb33:
  %t266 = load ptr, ptr %l0, !tbaa !29
  store ptr %t266, ptr %l156, !tbaa !29
  %t267 = load ptr, ptr %l2, !tbaa !29
  %t269 = getelementptr %"compiler/ast:ForIn", ptr %t267, i32 0, i32 1
  %t270 = load i32, ptr %t269, !tbaa !23
  store i32 %t270, ptr %l158, !tbaa !23
  %t271 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t271, ptr %l159
  %t272 = load ptr, ptr %l18, !tbaa !29
  %t274 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t272)
  store i32 %t274, ptr %l161
  br label %bb34
bb34:
  store { i64, [2 x i64] } zeroinitializer, ptr %t275
  %t276 = getelementptr { i64, [2 x i64] }, ptr %t275, i32 0, i32 0
  store i64 5, ptr %t276
  %t277 = load { i64, [2 x i64] }, ptr %t275
  %t278 = load ptr, ptr %l156, !tbaa !29
  %t279 = load i32, ptr %l158, !tbaa !23
  %t280 = load %"compiler/source:Span", ptr %l159
  %t281 = load i32, ptr %l161, !tbaa !23
  %t284 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t278, i32 %t279, %"compiler/source:Span" %t280, i32 %t281, i32 1, { i64, [2 x i64] } %t277)
  store i64 %t284, ptr %l164
  br label %bb35
bb35:
  %t285 = load i64, ptr %l164, !tbaa !24
  store i64 %t285, ptr %l21, !tbaa !24
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t286, i32 0, i32 30
  %t289 = getelementptr %"compiler/source:Span", ptr %t288, i32 0, i32 0
  %t290 = load i32, ptr %t289, !tbaa !23
  %t292 = icmp sge i32 %t290, 0
  br i1 %t292, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s4
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t294, i32 0, i32 28
  store ptr %t296, ptr %l169, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t297)
  store ptr %t299, ptr %l171
  br label %bb38
bb37:
  br label %bb51
bb38:
  %t300 = load ptr, ptr %l171, !tbaa !29
  %t302 = getelementptr %"compiler/check:frame", ptr %t300, i32 0, i32 0
  %t303 = load i64, ptr %t302, !tbaa !24
  %t304 = load i64, ptr %l21, !tbaa !24
  %t307 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s4, i64 %t303, i64 %t304)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t307, ptr %l175
  br label %bb39
bb39:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/check:Checker", ptr %t308, i32 0, i32 30
  %t311 = load %"compiler/source:Span", ptr %t310
  %t312 = load ptr, ptr %l169, !tbaa !29
  %t313 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l175
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_He56f4e53267726fe8dffcfd34146d8e6(ptr %v0, ptr %t312, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t313, %"compiler/source:Span" %t311)
  br label %bb40
bb40:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/check:Checker", ptr %t315, i32 0, i32 31
  %t318 = load i1, ptr %t317, !tbaa !21
  br i1 %t318, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s5
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"compiler/check:Checker", ptr %t320, i32 0, i32 27
  store ptr %t322, ptr %l181, !tbaa !29
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t323)
  store ptr %t325, ptr %l183
  br label %bb43
bb42:
  store %olang.scope zeroinitializer, ptr %s6
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t328 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 29
  store ptr %t328, ptr %l189, !tbaa !29
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t329)
  store ptr %t331, ptr %l191
  br label %bb46
bb43:
  %t332 = load ptr, ptr %l183, !tbaa !29
  %t334 = getelementptr %"compiler/check:frame", ptr %t332, i32 0, i32 0
  %t335 = load i64, ptr %t334, !tbaa !24
  %t336 = load i64, ptr %l21, !tbaa !24
  %t339 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t335, i64 %t336)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t339, ptr %l187
  br label %bb44
bb44:
  %t340 = load ptr, ptr %l181, !tbaa !29
  %t341 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l187
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t340, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t341, i1 true)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s5)
  br label %bb49
bb46:
  %t342 = load ptr, ptr %l191, !tbaa !29
  %t344 = getelementptr %"compiler/check:frame", ptr %t342, i32 0, i32 0
  %t345 = load i64, ptr %t344, !tbaa !24
  %t346 = load i64, ptr %l21, !tbaa !24
  %t349 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s6, i64 %t345, i64 %t346)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t349, ptr %l195
  br label %bb47
bb47:
  %t350 = load ptr, ptr %l189, !tbaa !29
  %t351 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l195
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t350, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t351, i1 true)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l196, !tbaa !29
  %t353 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s4, i32 -1, i32 -1)
  store %"compiler/source:Span" %t353, ptr %l197
  br label %bb50
bb50:
  %t354 = load %"compiler/source:Span", ptr %l197
  %t355 = load ptr, ptr %l196, !tbaa !29
  %t356 = getelementptr %"compiler/check:Checker", ptr %t355, i32 0, i32 30
  store %"compiler/source:Span" %t354, ptr %t356
  call void @__olang_scope_close(ptr %s4)
  br label %bb51
bb51:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l198, !tbaa !29
  %t358 = load i64, ptr %l21, !tbaa !24
  store i64 %t358, ptr %l199, !tbaa !24
  %t359 = load ptr, ptr %l18, !tbaa !29
  %t361 = icmp eq ptr %t359, null
  br i1 %t361, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_8ffd1bc2c5314d3c_1a7e454980bc5230)
  unreachable
bb53:
  br label %bb54
bb54:
  %t363 = load ptr, ptr %l18, !tbaa !29
  %t364 = load ptr, ptr %l198, !tbaa !29
  %t365 = load i64, ptr %l199, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v0, ptr %t364, i64 %t365, ptr %t363)
  br label %bb55
bb55:
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l203, !tbaa !29
  %t368 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t368, ptr %l204
  %t369 = load i64, ptr %l21, !tbaa !24
  %t371 = trunc i64 %t369 to i32
  store i32 %t371, ptr %l207, !tbaa !23
  %t373 = load ptr, ptr %l18, !tbaa !29
  %t375 = icmp eq ptr %t373, null
  br i1 %t375, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_6754b7d1e64b38ab_d9cb88888f730d0f)
  unreachable
bb57:
  br label %bb58
bb58:
  %t377 = load ptr, ptr %l18, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t378
  %t379 = getelementptr { i64, [3 x i64] }, ptr %t378, i32 0, i32 0
  store i64 0, ptr %t379
  %t380 = load %"compiler/source:Span", ptr %l204
  %t381 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t380, 0
  %t382 = load i32, ptr %l207, !tbaa !23
  %t383 = insertvalue { %"compiler/source:Span", i32, ptr } %t381, i32 %t382, 1
  %t385 = insertvalue { %"compiler/source:Span", i32, ptr } %t383, ptr %t377, 2
  %t386 = getelementptr { i64, [3 x i64] }, ptr %t378, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t385, ptr %t386
  %t387 = load { i64, [3 x i64] }, ptr %t378
  %t389 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t387, ptr %t389
  %t390 = load ptr, ptr %l203, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t390, ptr %t389)
  br label %bb59
bb59:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t393 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %t392, ptr %t393, ptr %a9, i32 %a10)
  br label %bb60
bb60:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t400)
  store ptr %t402, ptr %l219
  br label %bb61
bb61:
  %t403 = load ptr, ptr %l219, !tbaa !29
  %t405 = getelementptr %"compiler/check:frame", ptr %t403, i32 0, i32 10
  %t407 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t405)
  %t408 = extractvalue { i32, i64 } %t407, 1
  %t409 = extractvalue { i32, i64 } %t407, 0
  store i32 %t409, ptr %l223
  %t410 = icmp ne i32 %t409, 0
  br i1 %t410, label %bb63, label %ok.411
ok.411:
  store i64 %t408, ptr %l222
  br label %bb62
bb62:
  %t412 = load i64, ptr %l222, !tbaa !24
  store i64 %t412, ptr %l217, !tbaa !24
  br label %bb65
bb63:
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  br label %bb65
bb65:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t413)
  store ptr %t415, ptr %l226
  br label %bb66
bb66:
  %t416 = load ptr, ptr %l226, !tbaa !29
  %t418 = getelementptr %"compiler/check:frame", ptr %t416, i32 0, i32 11
  %t420 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t418)
  %t421 = extractvalue { i32, i64 } %t420, 1
  %t422 = extractvalue { i32, i64 } %t420, 0
  store i32 %t422, ptr %l230
  %t423 = icmp ne i32 %t422, 0
  br i1 %t423, label %bb68, label %ok.424
ok.424:
  store i64 %t421, ptr %l229
  br label %bb67
bb67:
  %t425 = load i64, ptr %l229, !tbaa !24
  store i64 %t425, ptr %l224, !tbaa !24
  br label %bb70
bb68:
  br label %bb69
bb69:
  call void @__olang_ert_req_clear()
  br label %bb70
bb70:
  %t426 = load ptr, ptr %l0, !tbaa !29
  %t427 = load i64, ptr %l13, !tbaa !24
  %t428 = load i64, ptr %l14, !tbaa !24
  %t429 = load i64, ptr %l15, !tbaa !24
  %t430 = load i64, ptr %l11, !tbaa !24
  %t436 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t426, i64 %t427, i64 %t428, i64 %t429, i64 %t430)
  store ptr %t436, ptr %l236
  br label %bb71
bb71:
  %t437 = load ptr, ptr %l236, !tbaa !29
  store ptr %t437, ptr %l22, !tbaa !29
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t440 = getelementptr %"compiler/check:Checker", ptr %t438, i32 0, i32 33
  %t442 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t440)
  store i64 %t442, ptr %l239
  br label %bb72
bb72:
  %t443 = load i64, ptr %l239, !tbaa !24
  store i64 %t443, ptr %l23, !tbaa !24
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load %"compiler/source:Span", ptr %l1
  %t449 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t444, i32 3, %"compiler/source:Span" %t445)
  store { i64, i64, i64 } %t449, ptr %l243
  br label %bb73
bb73:
  %t450 = load { i64, i64, i64 }, ptr %l243
  store { i64, i64, i64 } %t450, ptr %l24
  %t451 = getelementptr { i64, i64, i64 }, ptr %l24, i32 0, i32 0
  %t452 = load i64, ptr %t451, !tbaa !24
  store i64 %t452, ptr %l25, !tbaa !24
  %t454 = getelementptr { i64, i64, i64 }, ptr %l24, i32 0, i32 1
  %t455 = load i64, ptr %t454, !tbaa !24
  store i64 %t455, ptr %l26, !tbaa !24
  %t457 = getelementptr { i64, i64, i64 }, ptr %l24, i32 0, i32 2
  %t458 = load i64, ptr %t457, !tbaa !24
  store i64 %t458, ptr %l27, !tbaa !24
  %t460 = load ptr, ptr %l0, !tbaa !29
  store ptr %t460, ptr %l247, !tbaa !29
  %t461 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t461, ptr %l248
  %t462 = load i32, ptr %l16, !tbaa !23
  store i32 %t462, ptr %l249, !tbaa !23
  store i32 3, ptr %l250
  %t463 = load ptr, ptr %l0, !tbaa !29
  %t464 = load %"compiler/source:Span", ptr %l1
  %t465 = load i64, ptr %l3, !tbaa !24
  %t469 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t463, %"compiler/source:Span" %t464, i64 %t465)
  store ptr %t469, ptr %l254
  br label %bb74
bb74:
  %t470 = load ptr, ptr %l0, !tbaa !29
  %t471 = load %"compiler/source:Span", ptr %l1
  %t472 = load i32, ptr %l16, !tbaa !23
  %t476 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t470, %"compiler/source:Span" %t471, i32 %t472, i64 1)
  store ptr %t476, ptr %l258
  br label %bb75
bb75:
  %t477 = load ptr, ptr %l258, !tbaa !29
  %t478 = load ptr, ptr %l247, !tbaa !29
  %t479 = load %"compiler/source:Span", ptr %l248
  %t480 = load i32, ptr %l249, !tbaa !23
  %t481 = load i32, ptr %l250
  %t482 = load ptr, ptr %l254, !tbaa !29
  %t484 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t478, %"compiler/source:Span" %t479, i32 %t480, i32 %t481, ptr %t482, ptr %t477)
  store ptr %t484, ptr %l260
  br label %bb76
bb76:
  %t485 = load ptr, ptr %l260, !tbaa !29
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t487 = load %"compiler/source:Span", ptr %l1
  %t488 = load %"compiler/source:Span", ptr %l1
  %t489 = load i32, ptr %l16, !tbaa !23
  %t490 = load i64, ptr %l3, !tbaa !24
  %t492 = trunc i64 %t490 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t494
  %t495 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 0
  store i64 0, ptr %t495
  %t497 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t488, 0
  %t499 = insertvalue { %"compiler/source:Span", i32, i32 } %t497, i32 %t489, 1
  %t501 = insertvalue { %"compiler/source:Span", i32, i32 } %t499, i32 %t492, 2
  %t502 = getelementptr { i64, [4 x i64] }, ptr %t494, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t501, ptr %t502
  %t503 = load { i64, [4 x i64] }, ptr %t494
  %t505 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t503, ptr %t505
  store { i64, [3 x i64] } zeroinitializer, ptr %t507
  %t508 = getelementptr { i64, [3 x i64] }, ptr %t507, i32 0, i32 0
  store i64 1, ptr %t508
  %t510 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t487, 0
  %t512 = insertvalue { %"compiler/source:Span", ptr, ptr } %t510, ptr %t505, 1
  %t514 = insertvalue { %"compiler/source:Span", ptr, ptr } %t512, ptr %t485, 2
  %t515 = getelementptr { i64, [3 x i64] }, ptr %t507, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t514, ptr %t515
  %t516 = load { i64, [3 x i64] }, ptr %t507
  %t518 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t516, ptr %t518
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t486, ptr %t518)
  br label %bb77
bb77:
  %t521 = load ptr, ptr %l0, !tbaa !29
  %t522 = load i64, ptr %l25, !tbaa !24
  %t523 = load i64, ptr %l26, !tbaa !24
  %t524 = load i64, ptr %l27, !tbaa !24
  %t525 = load i64, ptr %l23, !tbaa !24
  %t531 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t521, i64 %t522, i64 %t523, i64 %t524, i64 %t525)
  store ptr %t531, ptr %l278
  br label %bb78
bb78:
  %t532 = load ptr, ptr %l278, !tbaa !29
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load %"compiler/source:Span", ptr %l1
  %t535 = load ptr, ptr %l22, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t538
  %t539 = getelementptr { i64, [3 x i64] }, ptr %t538, i32 0, i32 0
  store i64 4, ptr %t539
  %t541 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t534, 0
  %t543 = insertvalue { %"compiler/source:Span", ptr, ptr } %t541, ptr %t535, 1
  %t545 = insertvalue { %"compiler/source:Span", ptr, ptr } %t543, ptr %t532, 2
  %t546 = getelementptr { i64, [3 x i64] }, ptr %t538, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t545, ptr %t546
  %t547 = load { i64, [3 x i64] }, ptr %t538
  %t549 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t547, ptr %t549
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t533, ptr %t549)
  br label %bb79
bb79:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edataLength(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t12, i32 0, i32 3
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l2, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l10, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l11, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l2, !tbaa !29
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { { i64, ptr } }, ptr %t27, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  store { i64, ptr } %t29, ptr %l3, !tbaa !27
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %rv
  br label %ret
bb11:
  store i64 -1, ptr %rv
  br label %ret
bb12:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edecls(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/source:Span"
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l33 = alloca i1
  %l46 = alloca { i64, ptr }
  %l50 = alloca ptr
  %l54 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l58 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca i64
  %l119 = alloca ptr
  %l122 = alloca ptr
  %l123 = alloca i64
  %l129 = alloca %"compiler/source:Span"
  %l131 = alloca i64
  %l132 = alloca ptr
  %l133 = alloca i1
  %l147 = alloca ptr
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l3, !tbaa !24
  store { i64, ptr } %a2, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l6, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l5, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb64
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t15, ptr %l29, !tbaa !27
  %t16 = load i64, ptr %l5, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr ptr, ptr %t19, i64 %t16
  %t21 = load ptr, ptr %t20, !tbaa !39
  store ptr %t21, ptr %l7, !tbaa !29
  %t23 = load ptr, ptr %l7, !tbaa !29
  store ptr %t23, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t24 = load ptr, ptr %l32, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l32, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 3
  store i1 %t30, ptr %l33, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l33, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t34 = getelementptr { i64, [6 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l8, !tbaa !29
  br label %bb9
bb8:
  br label %bb19
bb9:
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t40 = getelementptr %"compiler/ast:VarDecl", ptr %t38, i32 0, i32 0
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l11, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s5
  %t47 = load i64, ptr %l10, !tbaa !24
  %t48 = load i64, ptr %l11, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s5)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t55, ptr %l46, !tbaa !27
  %t56 = load i64, ptr %l10, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i32, ptr %t59, i64 %t56
  %t61 = load i32, ptr %t60, !tbaa !33
  store i32 %t61, ptr %l12, !tbaa !23
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 25
  store ptr %t65, ptr %l50, !tbaa !29
  %t66 = load i64, ptr %l1, !tbaa !24
  %t67 = load i32, ptr %l12, !tbaa !23
  %t69 = sext i32 %t67 to i64
  %t72 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s5, i64 %t66, i64 %t69)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72, ptr %l54
  br label %bb14
bb14:
  %t73 = load ptr, ptr %l50, !tbaa !29
  %t74 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l54
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %t73, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t74)
  br label %bb15
bb15:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i64, ptr %l1, !tbaa !24
  %t77 = load i32, ptr %l12, !tbaa !23
  %t81 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %t75, i64 %t76, i32 %t77)
  store i64 %t81, ptr %l58
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s5)
  br label %bb17
bb17:
  %t82 = load i64, ptr %l10, !tbaa !24
  %t84 = add i64 %t82, 1
  store i64 %t84, ptr %l10, !tbaa !24
  br label %bb10
bb18:
  br label %bb62
bb19:
  %t86 = load ptr, ptr %l7, !tbaa !29
  store ptr %t86, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t87 = load ptr, ptr %l61, !tbaa !29
  %t88 = icmp ne ptr %t87, null
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load ptr, ptr %l61, !tbaa !29
  %t91 = load i64, ptr %t90
  %t93 = icmp eq i64 %t91, 6
  store i1 %t93, ptr %l62, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l62, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load ptr, ptr %l7, !tbaa !29
  %t97 = getelementptr { i64, [6 x i64] }, ptr %t95, i32 0, i32 1
  %t98 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t97, i32 0, i32 0
  %t99 = load %"compiler/source:Span", ptr %t98
  store %"compiler/source:Span" %t99, ptr %l13
  %t101 = load ptr, ptr %l7, !tbaa !29
  %t103 = getelementptr { i64, [6 x i64] }, ptr %t101, i32 0, i32 1
  %t104 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t103, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104
  store { i64, ptr } %t105, ptr %l14, !tbaa !27
  br label %bb24
bb23:
  br label %bb29
bb24:
  %t107 = load i64, ptr %l1, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 0
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/load:Loader", ptr %t114, i32 0, i32 7
  %t117 = load i64, ptr %t116, !tbaa !24
  %t120 = icmp eq i64 %t107, %t117
  br i1 %t120, label %bb25, label %bb26
bb25:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t123 = load i64, ptr %l1, !tbaa !24
  %t124 = load %"compiler/source:Span", ptr %l13
  %t125 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t126 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %t122, i64 %t123, %"compiler/source:Span" %t124, { i64, ptr } %t125, i64 %t126)
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t132 = load i64, ptr %l3, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l3, !tbaa !24
  br label %bb62
bb29:
  %t136 = load ptr, ptr %l7, !tbaa !29
  store ptr %t136, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t137 = load ptr, ptr %l82, !tbaa !29
  %t138 = icmp ne ptr %t137, null
  br i1 %t138, label %bb30, label %bb31
bb30:
  %t140 = load ptr, ptr %l82, !tbaa !29
  %t141 = load i64, ptr %t140
  %t143 = icmp eq i64 %t141, 2
  store i1 %t143, ptr %l83, !tbaa !21
  br label %bb31
bb31:
  %t144 = load i1, ptr %l83, !tbaa !21
  br i1 %t144, label %bb32, label %bb33
bb32:
  %t145 = load ptr, ptr %l7, !tbaa !29
  %t147 = getelementptr { i64, [6 x i64] }, ptr %t145, i32 0, i32 1
  %t148 = getelementptr { %"compiler/source:Span", ptr }, ptr %t147, i32 0, i32 0
  %t149 = load %"compiler/source:Span", ptr %t148
  store %"compiler/source:Span" %t149, ptr %l15
  %t151 = load ptr, ptr %l7, !tbaa !29
  %t153 = getelementptr { i64, [6 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", ptr }, ptr %t153, i32 0, i32 1
  %t155 = load ptr, ptr %t154
  store ptr %t155, ptr %l16, !tbaa !29
  br label %bb34
bb33:
  br label %bb40
bb34:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load i64, ptr %l1, !tbaa !24
  %t159 = load %"compiler/source:Span", ptr %l15
  %t160 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %t157, i64 %t158, %"compiler/source:Span" %t159, ptr %t160)
  br label %bb35
bb35:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l1, !tbaa !24
  %t168 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %t166, i64 %t167, ptr %t168)
  br label %bb36
bb36:
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t174 = load i64, ptr %l1, !tbaa !24
  %t175 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %t173, i64 %t174, ptr %t175)
  br label %bb37
bb37:
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l1, !tbaa !24
  %t182 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %t180, i64 %t181, ptr %t182)
  br label %bb38
bb38:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t188 = load i64, ptr %l1, !tbaa !24
  %t189 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitContracts(ptr %v0, ptr %v1, ptr %t187, i64 %t188, ptr %t189)
  br label %bb39
bb39:
  br label %bb62
bb40:
  %t194 = load ptr, ptr %l7, !tbaa !29
  store ptr %t194, ptr %l111, !tbaa !29
  store i1 false, ptr %l112, !tbaa !21
  %t195 = load ptr, ptr %l111, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t198 = load ptr, ptr %l111, !tbaa !29
  %t199 = load i64, ptr %t198
  %t201 = icmp eq i64 %t199, 7
  store i1 %t201, ptr %l112, !tbaa !21
  br label %bb42
bb42:
  %t202 = load i1, ptr %l112, !tbaa !21
  br i1 %t202, label %bb43, label %bb44
bb43:
  %t203 = load ptr, ptr %l7, !tbaa !29
  %t205 = getelementptr { i64, [6 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 1
  %t207 = load ptr, ptr %t206
  store ptr %t207, ptr %l17, !tbaa !29
  br label %bb45
bb44:
  br label %bb52
bb45:
  %t209 = load ptr, ptr %l0, !tbaa !29
  store ptr %t209, ptr %l117, !tbaa !29
  %t210 = load i64, ptr %l1, !tbaa !24
  store i64 %t210, ptr %l118, !tbaa !24
  %t211 = load ptr, ptr %l17, !tbaa !29
  store ptr %t211, ptr %l119, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/check:Checker", ptr %t212, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !29
  %t217 = getelementptr %"compiler/generic:Program", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  store ptr %t218, ptr %l122, !tbaa !29
  %t219 = load i64, ptr %l1, !tbaa !24
  store i64 %t219, ptr %l123, !tbaa !24
  %t220 = load ptr, ptr %l17, !tbaa !29
  %t222 = getelementptr %"compiler/ast:TopIf", ptr %t220, i32 0, i32 0
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f)
  unreachable
bb47:
  br label %bb48
bb48:
  %t227 = load ptr, ptr %l17, !tbaa !29
  %t229 = getelementptr %"compiler/ast:TopIf", ptr %t227, i32 0, i32 0
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t230)
  store %"compiler/source:Span" %t232, ptr %l129
  br label %bb49
bb49:
  %t233 = getelementptr %"compiler/source:Span", ptr %l129, i32 0, i32 0
  %t234 = load i32, ptr %t233, !tbaa !23
  %t235 = load ptr, ptr %l122, !tbaa !29
  %t236 = load i64, ptr %l123, !tbaa !24
  %t238 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %t235, i64 %t236, i32 %t234)
  store i64 %t238, ptr %l131
  br label %bb50
bb50:
  %t239 = load ptr, ptr %l117, !tbaa !29
  %t240 = load i64, ptr %l118, !tbaa !24
  %t241 = load ptr, ptr %l119, !tbaa !29
  %t242 = load i64, ptr %l131, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %t239, i64 %t240, ptr %t241, i64 %t242, i64 0)
  br label %bb51
bb51:
  br label %bb62
bb52:
  %t243 = load ptr, ptr %l7, !tbaa !29
  store ptr %t243, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t244 = load ptr, ptr %l132, !tbaa !29
  %t245 = icmp ne ptr %t244, null
  br i1 %t245, label %bb53, label %bb54
bb53:
  %t247 = load ptr, ptr %l132, !tbaa !29
  %t248 = load i64, ptr %t247
  %t250 = icmp eq i64 %t248, 5
  store i1 %t250, ptr %l133, !tbaa !21
  br label %bb54
bb54:
  %t251 = load i1, ptr %l133, !tbaa !21
  br i1 %t251, label %bb55, label %bb56
bb55:
  %t252 = load ptr, ptr %l7, !tbaa !29
  %t254 = getelementptr { i64, [6 x i64] }, ptr %t252, i32 0, i32 1
  %t255 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t254, i32 0, i32 0
  %t256 = load %"compiler/source:Span", ptr %t255
  store %"compiler/source:Span" %t256, ptr %l18
  %t258 = load ptr, ptr %l7, !tbaa !29
  %t260 = getelementptr { i64, [6 x i64] }, ptr %t258, i32 0, i32 1
  %t261 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t260, i32 0, i32 1
  %t262 = load i32, ptr %t261
  store i32 %t262, ptr %l19, !tbaa !23
  %t264 = load ptr, ptr %l7, !tbaa !29
  %t266 = getelementptr { i64, [6 x i64] }, ptr %t264, i32 0, i32 1
  %t267 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t266, i32 0, i32 2
  %t268 = load { i64, ptr }, ptr %t267
  store { i64, ptr } %t268, ptr %l20, !tbaa !27
  %t270 = load ptr, ptr %l7, !tbaa !29
  %t272 = getelementptr { i64, [6 x i64] }, ptr %t270, i32 0, i32 1
  %t273 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr } }, ptr %t272, i32 0, i32 3
  %t274 = load { i64, ptr }, ptr %t273
  store { i64, ptr } %t274, ptr %l21, !tbaa !27
  br label %bb57
bb56:
  br label %bb61
bb57:
  %t276 = load ptr, ptr %l0, !tbaa !29
  %t277 = load i64, ptr %l1, !tbaa !24
  %t278 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t282 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t276, i64 -1, i64 %t277, i32 %t278, i32 0)
  store ptr %t282, ptr %l147
  br label %bb58
bb58:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load i64, ptr %l1, !tbaa !24
  %t285 = load %"compiler/source:Span", ptr %l18
  %t286 = load i32, ptr %l19, !tbaa !23
  %t287 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorDeclRules(ptr %v0, ptr %v1, ptr %v1, ptr %t283, i64 %t284, %"compiler/source:Span" %t285, i32 %t286, { i64, ptr } %t287, { i64, ptr } %t288)
  br label %bb59
bb59:
  %t295 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t295)
  br label %bb60
bb60:
  br label %bb62
bb61:
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb63:
  %t297 = load i64, ptr %l5, !tbaa !24
  %t299 = add i64 %t297, 1
  store i64 %t299, ptr %l5, !tbaa !24
  br label %bb1
bb64:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca i1
  %l18 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb11
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t21, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i1 %t22, ptr %l13
  br label %bb7
bb7:
  %t23 = load i1, ptr %l13, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 9
  store i1 true, ptr %t27, !tbaa !21
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t32 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %t28, ptr %t29)
  store ptr %t32, ptr %l18
  br label %bb13
bb13:
  %t33 = load ptr, ptr %l18, !tbaa !29
  store ptr %t33, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  %t38 = xor i1 %t36, true
  br i1 %t38, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l3, !tbaa !29
  store ptr %t41, ptr %l23, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t44 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t42)
  store %"compiler/source:Span" %t44, ptr %l25
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = load ptr, ptr %l23, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l25
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v0, ptr %t45, ptr %t46, %"compiler/source:Span" %t47)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t48 = load ptr, ptr %l3, !tbaa !29
  store ptr %t48, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelseDropped(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca ptr
  %l35 = alloca i1
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t18 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 4
  %t25 = load ptr, ptr %t24, !tbaa !29
  store ptr %t25, ptr %l3, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t29 = getelementptr %"compiler/ast:If", ptr %t27, i32 0, i32 0
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = icmp eq ptr %t30, null
  br i1 %t32, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l3, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:If", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb8, label %bb9
bb7:
  %t42 = load ptr, ptr %l3, !tbaa !29
  store ptr %t42, ptr %l27, !tbaa !29
  %t43 = load ptr, ptr %l2, !tbaa !29
  %t45 = getelementptr %"compiler/ast:If", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb12, label %bb13
bb8:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb9:
  br label %bb10
bb10:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = getelementptr %"compiler/ast:If", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Branch", ptr %t53, i32 0, i32 2
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load ptr, ptr %l18, !tbaa !29
  %t60 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %t58, i64 %t57)
  store i1 %t60, ptr %l26
  br label %bb11
bb11:
  %t61 = load i1, ptr %l26, !tbaa !21
  store i1 %t61, ptr %l17, !tbaa !21
  br label %bb16
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9f409528a62be557_96e98ebb70e4ac13)
  unreachable
bb13:
  br label %bb14
bb14:
  %t62 = load ptr, ptr %l2, !tbaa !29
  %t64 = getelementptr %"compiler/ast:If", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t68 = getelementptr %"compiler/ast:Branch", ptr %t65, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = load ptr, ptr %l27, !tbaa !29
  %t72 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %t70, i64 %t69)
  store i1 %t72, ptr %l35
  br label %bb15
bb15:
  %t73 = load i1, ptr %l35, !tbaa !21
  store i1 %t73, ptr %l17, !tbaa !21
  br label %bb16
bb16:
  %t74 = load i1, ptr %l17, !tbaa !21
  store i1 %t74, ptr %rv
  br label %ret
bb17:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l17 = alloca i32
  %l24 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a2, ptr %l4, !tbaa !65
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l1, !tbaa !23
  %t6 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t2, i32 %t3)
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  %t7 = load i64, ptr %l4, !tbaa !65
  %t8 = load i64, ptr %l7, !tbaa !65
  %t9 = and i64 %t7, %t8
  store i64 %t9, ptr %l3, !tbaa !65
  %t11 = load i64, ptr %l3, !tbaa !65
  %t13 = icmp eq i64 %t11, 0
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t15, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t17 = load i64, ptr %l3, !tbaa !65
  store i64 %t17, ptr %l12, !tbaa !65
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %t18, i32 %t19)
  store i64 %t22, ptr %l15
  br label %bb5
bb5:
  %t23 = load i64, ptr %l12, !tbaa !65
  %t24 = load i64, ptr %l15, !tbaa !65
  %t25 = icmp eq i64 %t23, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load i32, ptr %l1, !tbaa !23
  store i32 %t27, ptr %l17, !tbaa !23
  br label %bb9
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t36 = load i64, ptr %l3, !tbaa !65
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t34, i32 %t35, i64 %t36)
  store i32 %t40, ptr %l24
  br label %bb8
bb8:
  %t41 = load i32, ptr %l24, !tbaa !23
  store i32 %t41, ptr %l17, !tbaa !23
  br label %bb9
bb9:
  %t42 = load i32, ptr %l17, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexplicitArgs(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i32
  %l33 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l43 = alloca i64
  %l45 = alloca i64
  %l49 = alloca i64
  %l54 = alloca i1
  %l57 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l61 = alloca %"compiler/source:Span"
  %l63 = alloca %"compiler/msgs:Msg"
  %l64 = alloca i64
  %l70 = alloca i1
  %l73 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca %"compiler/msgs:Msg"
  %l79 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l89 = alloca %"compiler/source:Span"
  %l93 = alloca %"compiler/msgs:Msg"
  %l94 = alloca i64
  %l101 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca i32
  %l114 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca i32
  %l137 = alloca i64
  %l140 = alloca i64
  %l159 = alloca { i64, ptr }
  %l163 = alloca i32
  %l170 = alloca { i64, ptr }
  %l173 = alloca i64
  %l181 = alloca { i64, ptr }
  %l182 = alloca i64
  %l184 = alloca ptr
  %l186 = alloca ptr
  %l189 = alloca { i64, ptr }
  %l192 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t238 = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store %"compiler/source:Span" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp slt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = icmp sge i64 0, 0
  br i1 %t5, label %bb3, label %bb4
bb2:
  br label %bb7
bb3:
  %t7 = icmp sle i64 0, 2305843009213693951
  br i1 %t7, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb5:
  %t9 = mul i64 0, 4
  %t10 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 0, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t12, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7)
  unreachable
bb7:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %t17, i64 %t18)
  store ptr %t21, ptr %l33
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l33, !tbaa !29
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/ast:Func", ptr %t22, i32 0, i32 2
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t23, i32 %t27)
  store { i64, ptr } %t30, ptr %l37
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t31, ptr %l5, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load i64, ptr %l1, !tbaa !24
  %t39 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %s0, ptr %t35, i64 %t36)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l41
  br label %bb10
bb10:
  %t40 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l6
  %t42 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %l6)
  store i64 %t42, ptr %l43
  br label %bb11
bb11:
  %t43 = load i64, ptr %l43, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t44)
  store i64 %t46, ptr %l45
  br label %bb12
bb12:
  %t47 = load i64, ptr %l45, !tbaa !24
  store i64 %t47, ptr %l8, !tbaa !24
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t52 = load i64, ptr %l1, !tbaa !24
  %t55 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %t51, i64 %t52)
  store i64 %t55, ptr %l49
  br label %bb13
bb13:
  %t56 = load i64, ptr %l49, !tbaa !24
  store i64 %t56, ptr %l9, !tbaa !24
  %t57 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sgt i64 %t59, %t60
  br i1 %t63, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  store i1 %t67, ptr %l54, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb16
bb16:
  %t69 = load i1, ptr %l54, !tbaa !21
  br i1 %t69, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l57, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t71, ptr %l58, !tbaa !27
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  %t79 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t77)
  store %"compiler/source:Span" %t79, ptr %l61
  br label %bb19
bb18:
  br label %bb26
bb19:
  %t80 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t82 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %s2, { i64, ptr } %t80)
  store %"compiler/msgs:Msg" %t82, ptr %l63
  br label %bb20
bb20:
  %t83 = load ptr, ptr %l57, !tbaa !29
  %t84 = load %"compiler/source:Span", ptr %l61
  %t85 = load %"compiler/msgs:Msg", ptr %l63
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t83, %"compiler/source:Span" %t84, %"compiler/msgs:Msg" %t85)
  store i64 %t86, ptr %l64
  br label %bb21
bb21:
  %t87 = icmp sge i64 0, 0
  br i1 %t87, label %bb22, label %bb23
bb22:
  %t89 = icmp sle i64 0, 2305843009213693951
  br i1 %t89, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb24:
  %t91 = mul i64 0, 4
  %t92 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 0, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t94, ptr %rv
  br label %ret
bb25:
  call void @__olang_check_failed(ptr @olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2)
  unreachable
bb26:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp eq i64 %t96, 0
  br i1 %t98, label %bb27, label %bb28
bb27:
  %t100 = load i64, ptr %l8, !tbaa !24
  %t102 = icmp sgt i64 %t100, 0
  store i1 %t102, ptr %l70, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb29
bb29:
  %t104 = load i1, ptr %l70, !tbaa !21
  br i1 %t104, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s3
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l73, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t106, ptr %l74, !tbaa !27
  %t107 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr ptr, ptr %t108, i64 0
  %t110 = load ptr, ptr %t109, !tbaa !39
  %t112 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t110)
  store %"compiler/source:Span" %t112, ptr %l76
  br label %bb32
bb31:
  br label %bb39
bb32:
  %t113 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t115 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %s3, { i64, ptr } %t113)
  store %"compiler/msgs:Msg" %t115, ptr %l78
  br label %bb33
bb33:
  %t116 = load ptr, ptr %l73, !tbaa !29
  %t117 = load %"compiler/source:Span", ptr %l76
  %t118 = load %"compiler/msgs:Msg", ptr %l78
  %t119 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t116, %"compiler/source:Span" %t117, %"compiler/msgs:Msg" %t118)
  store i64 %t119, ptr %l79
  br label %bb34
bb34:
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t122 = icmp sle i64 0, 2305843009213693951
  br i1 %t122, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb37:
  %t124 = mul i64 0, 4
  %t125 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t124)
  %t126 = insertvalue { i64, ptr } undef, i64 0, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t127, ptr %rv
  br label %ret
bb38:
  call void @__olang_check_failed(ptr @olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71)
  unreachable
bb39:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load i64, ptr %l8, !tbaa !24
  %t133 = icmp ne i64 %t129, %t130
  br i1 %t133, label %bb40, label %bb41
bb40:
  store %olang.scope zeroinitializer, ptr %s4
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l86, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t136, ptr %l87, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr ptr, ptr %t138, i64 0
  %t140 = load ptr, ptr %t139, !tbaa !39
  %t142 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t140)
  store %"compiler/source:Span" %t142, ptr %l89
  br label %bb42
bb41:
  br label %bb49
bb42:
  %t143 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t144 = load i64, ptr %l7, !tbaa !24
  %t145 = load i64, ptr %l8, !tbaa !24
  %t149 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s4, { i64, ptr } %t143, i64 %t144, i64 %t145)
  store %"compiler/msgs:Msg" %t149, ptr %l93
  br label %bb43
bb43:
  %t150 = load ptr, ptr %l86, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l89
  %t152 = load %"compiler/msgs:Msg", ptr %l93
  %t153 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t150, %"compiler/source:Span" %t151, %"compiler/msgs:Msg" %t152)
  store i64 %t153, ptr %l94
  br label %bb44
bb44:
  %t154 = icmp sge i64 0, 0
  br i1 %t154, label %bb45, label %bb46
bb45:
  %t156 = icmp sle i64 0, 2305843009213693951
  br i1 %t156, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb47:
  %t158 = mul i64 0, 4
  %t159 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t158)
  %t160 = insertvalue { i64, ptr } undef, i64 0, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t161, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_c902484ee6860410_648a649019eab164)
  unreachable
bb49:
  %t163 = load i64, ptr %l9, !tbaa !24
  %t165 = add i64 %t163, 1
  store i64 %t165, ptr %l10, !tbaa !24
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s6
  %t168 = load ptr, ptr %l11, !tbaa !29
  %t169 = load i64, ptr %l12, !tbaa !24
  %t172 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t168, i64 %t169)
  %t173 = extractvalue { i32, { i64, ptr } } %t172, 1
  %t174 = extractvalue { i32, { i64, ptr } } %t172, 0
  store i32 %t174, ptr %l105
  %t175 = icmp ne i32 %t174, 0
  br i1 %t175, label %bb52, label %ok.176
ok.176:
  store { i64, ptr } %t173, ptr %l104
  br label %bb51
bb51:
  %t177 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t177, ptr %l101, !tbaa !27
  br label %bb56
bb52:
  %t178 = load i32, ptr %l105, !tbaa !23
  %t179 = ashr i32 %t178, 16
  %t181 = icmp eq i32 %t179, 1
  br i1 %t181, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_293fe44c08438718_c9e2b0469f544c2c)
  unreachable
bb55:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb67
bb56:
  %t183 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t183, ptr %l13, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s7
  %t188 = load i64, ptr %l15, !tbaa !24
  %t189 = load i64, ptr %l14, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s7)
  br label %bb65
bb59:
  br label %bb60
bb60:
  %t196 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t196, ptr %l114, !tbaa !27
  %t197 = load i64, ptr %l15, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i64, ptr %t200, i64 %t197
  %t202 = load i64, ptr %t201, !tbaa !34
  store i64 %t202, ptr %l16, !tbaa !24
  %t204 = load i64, ptr %l16, !tbaa !24
  %t206 = add i64 %t204, 1
  %t207 = load i64, ptr %l10, !tbaa !24
  %t210 = icmp sgt i64 %t206, %t207
  br i1 %t210, label %bb61, label %bb62
bb61:
  %t212 = load i64, ptr %l16, !tbaa !24
  %t214 = add i64 %t212, 1
  store i64 %t214, ptr %l10, !tbaa !24
  br label %bb63
bb62:
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s7)
  br label %bb64
bb64:
  %t216 = load i64, ptr %l15, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l15, !tbaa !24
  br label %bb57
bb65:
  %t220 = load i64, ptr %l12, !tbaa !24
  %t221 = load i64, ptr %l14, !tbaa !24
  %t224 = add i64 %t220, %t221
  store i64 %t224, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb66
bb66:
  br label %bb50
bb67:
  %t226 = load i64, ptr %l10, !tbaa !24
  store i64 %t226, ptr %l128, !tbaa !24
  %t227 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t227, ptr %l129, !tbaa !23
  %t228 = load i64, ptr %l128, !tbaa !24
  %t229 = icmp sge i64 %t228, 0
  br i1 %t229, label %bb68, label %bb69
bb68:
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp sle i64 %t231, 2305843009213693951
  br i1 %t232, label %bb70, label %bb71
bb69:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb70:
  %t234 = load i64, ptr %l128, !tbaa !24
  %t235 = mul i64 %t234, 4
  %t236 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t235)
  %t237 = load i32, ptr %l129, !tbaa !23
  store i64 0, ptr %t238
  br label %fill.239
fill.239:
  %t242 = load i64, ptr %t238
  %t243 = icmp slt i64 %t242, %t234
  br i1 %t243, label %fillb.240, label %filld.241
fillb.240:
  %t244 = getelementptr i32, ptr %t236, i64 %t242
  store i32 %t237, ptr %t244
  %t245 = add i64 %t242, 1
  store i64 %t245, ptr %t238
  br label %fill.239
filld.241:
  %t246 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t236, 1
  store { i64, ptr } %t247, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t249 = load i64, ptr %l7, !tbaa !24
  store i64 %t249, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t251 = load i64, ptr %l19, !tbaa !24
  %t252 = load i64, ptr %l18, !tbaa !24
  %t255 = icmp sgt i64 %t251, %t252
  br i1 %t255, label %bb72, label %bb73
bb71:
  call void @__olang_check_failed(ptr @olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6)
  unreachable
bb72:
  %t257 = load i64, ptr %l20, !tbaa !24
  %t259 = icmp sgt i64 %t257, 0
  br i1 %t259, label %bb74, label %bb75
bb73:
  store i64 0, ptr %l137, !tbaa !24
  br label %bb77
bb74:
  %t261 = load i64, ptr %l19, !tbaa !24
  %t262 = load i64, ptr %l18, !tbaa !24
  %t265 = sub i64 %t261, %t262
  %t266 = load i64, ptr %l20, !tbaa !24
  %t269 = add i64 %t265, %t266
  %t271 = sub i64 %t269, 1
  %t272 = load i64, ptr %l20, !tbaa !24
  %t275 = sdiv i64 %t271, %t272
  store i64 %t275, ptr %l140, !tbaa !24
  br label %bb76
bb75:
  store i64 0, ptr %l140, !tbaa !24
  br label %bb76
bb76:
  %t277 = load i64, ptr %l140, !tbaa !24
  store i64 %t277, ptr %l137, !tbaa !24
  br label %bb77
bb77:
  %t278 = load i64, ptr %l137, !tbaa !24
  store i64 %t278, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s11
  %t279 = load i64, ptr %l22, !tbaa !24
  %t280 = load i64, ptr %l21, !tbaa !24
  %t283 = icmp slt i64 %t279, %t280
  %t285 = xor i1 %t283, true
  br i1 %t285, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s11)
  br label %bb92
bb80:
  br label %bb81
bb81:
  %t287 = load i64, ptr %l18, !tbaa !24
  %t288 = load i64, ptr %l22, !tbaa !24
  %t289 = load i64, ptr %l20, !tbaa !24
  %t292 = mul i64 %t288, %t289
  %t295 = add i64 %t287, %t292
  store i64 %t295, ptr %l23, !tbaa !24
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t298, ptr %l159, !tbaa !27
  %t299 = load i64, ptr %l23, !tbaa !24
  %t301 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr ptr, ptr %t302, i64 %t299
  %t304 = load ptr, ptr %t303, !tbaa !39
  %t308 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t297, ptr %t304)
  store i32 %t308, ptr %l163
  br label %bb82
bb82:
  %t309 = load i32, ptr %l163, !tbaa !23
  store i32 %t309, ptr %l24, !tbaa !23
  %t310 = load i32, ptr %l24, !tbaa !23
  %t311 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t314 = icmp eq i32 %t310, %t311
  br i1 %t314, label %bb83, label %bb84
bb83:
  %t316 = icmp sge i64 0, 0
  br i1 %t316, label %bb85, label %bb86
bb84:
  br label %bb89
bb85:
  %t318 = icmp sle i64 0, 2305843009213693951
  br i1 %t318, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_d217cc4a3a9977a9_9d0368fc739efec5)
  unreachable
bb87:
  %t320 = mul i64 0, 4
  %t321 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t320)
  %t322 = insertvalue { i64, ptr } undef, i64 0, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t323, ptr %rv
  br label %ret
bb88:
  call void @__olang_check_failed(ptr @olang_loc_d217cc4a3a9977a9_9d0368fc739efec5)
  unreachable
bb89:
  %t325 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t325, ptr %l170, !tbaa !27
  %t326 = load i64, ptr %l23, !tbaa !24
  %t329 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %l6, i64 %t326)
  store i64 %t329, ptr %l173
  br label %bb90
bb90:
  %t330 = load i32, ptr %l24, !tbaa !23
  %t332 = load i64, ptr %l173, !tbaa !24
  %t333 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr i32, ptr %t334, i64 %t332
  store i32 %t330, ptr %t335, !tbaa !33
  call void @__olang_scope_close(ptr %s11)
  br label %bb91
bb91:
  %t336 = load i64, ptr %l22, !tbaa !24
  %t338 = add i64 %t336, 1
  store i64 %t338, ptr %l22, !tbaa !24
  br label %bb78
bb92:
  %t340 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t340, 0
  %t343 = load i64, ptr %l8, !tbaa !24
  %t346 = icmp sgt i64 %t342, %t343
  br i1 %t346, label %bb93, label %bb94
bb93:
  %t348 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t348, ptr %l181, !tbaa !27
  %t349 = load i64, ptr %l9, !tbaa !24
  store i64 %t349, ptr %l182, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  store ptr %t353, ptr %l184, !tbaa !29
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t354)
  store ptr %t356, ptr %l186
  br label %bb95
bb94:
  br label %bb97
bb95:
  %t357 = load ptr, ptr %l186, !tbaa !29
  %t359 = getelementptr %"compiler/check:frame", ptr %t357, i32 0, i32 4
  %t360 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t360, ptr %l189, !tbaa !27
  %t361 = load i64, ptr %l8, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr ptr, ptr %t364, i64 %t361
  %t366 = load ptr, ptr %t365, !tbaa !39
  %t367 = load ptr, ptr %l184, !tbaa !29
  %t370 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v0, ptr %v1, ptr %t367, ptr %t359, ptr %t366)
  store i32 %t370, ptr %l192
  br label %bb96
bb96:
  %t371 = load i32, ptr %l192, !tbaa !23
  %t372 = load i64, ptr %l182, !tbaa !24
  %t373 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t374 = load ptr, ptr %t373, !tbaa !27
  %t375 = getelementptr i32, ptr %t374, i64 %t372
  store i32 %t371, ptr %t375, !tbaa !33
  br label %bb97
bb97:
  %t376 = load { i64, ptr }, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t376, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportArray(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l9
  br label %bb5
bb5:
  %t13 = load i32, ptr %l9, !tbaa !23
  store i32 %t13, ptr %l2, !tbaa !23
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/generic:Program", ptr %t17, i32 0, i32 2
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l14
  br label %bb6
bb6:
  %t24 = load i32, ptr %l14
  %t26 = trunc i64 19 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l18, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t40 = load ptr, ptr %l18, !tbaa !29
  %t41 = load i32, ptr %l23, !tbaa !23
  %t42 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t40, i32 %t41)
  store i1 %t42, ptr %l24
  br label %bb10
bb10:
  %t43 = load i1, ptr %l24, !tbaa !21
  store i1 %t43, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t44 = load i1, ptr %l17, !tbaa !21
  store i1 %t44, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportParam(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l10 = alloca i1
  %l17 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i32
  %l29 = alloca i32
  %l32 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t8, i32 %t9)
  store i1 %t12, ptr %l10
  br label %bb5
bb5:
  %t13 = load i1, ptr %l10, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/check:Checker", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = getelementptr %"compiler/generic:Program", ptr %t20, i32 0, i32 2
  %t23 = load i32, ptr %l1, !tbaa !23
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t22, i32 %t23)
  store i32 %t26, ptr %l17
  br label %bb9
bb9:
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %l2, !tbaa !23
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i32, ptr %l2, !tbaa !23
  %t32 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %t28, i32 %t29, i64 0)
  store i1 %t32, ptr %l20
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l2, !tbaa !23
  %t39 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l24
  br label %bb14
bb14:
  %t40 = load i32, ptr %l24, !tbaa !23
  store i32 %t40, ptr %l3, !tbaa !23
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l3, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l29
  br label %bb15
bb15:
  %t51 = load i32, ptr %l29
  %t53 = trunc i64 19 to i32
  %t54 = icmp eq i32 %t51, %t53
  br i1 %t54, label %bb16, label %bb17
bb16:
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l33, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l3, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l38
  br label %bb18
bb17:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t67 = load ptr, ptr %l33, !tbaa !29
  %t68 = load i32, ptr %l38, !tbaa !23
  %t69 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %t67, i32 %t68)
  store i1 %t69, ptr %l39
  br label %bb19
bb19:
  %t70 = load i1, ptr %l39, !tbaa !21
  store i1 %t70, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t71 = load i1, ptr %l32, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldTypeAt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l11 = alloca i1
  %l14 = alloca i1
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca { i64, ptr }
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 14
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l2, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t10 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t13 = icmp eq i32 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb5
bb3:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l2, !tbaa !23
  %t19 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %t15, i32 %t16)
  store i1 %t19, ptr %l14
  br label %bb4
bb4:
  %t20 = load i1, ptr %l14, !tbaa !21
  %t21 = xor i1 %t20, true
  store i1 %t21, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l11, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t24 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t24, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  store ptr %t31, ptr %l19, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/generic:Program", ptr %t35, i32 0, i32 2
  %t38 = load i32, ptr %l2, !tbaa !23
  %t41 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t37, i32 %t38)
  store i32 %t41, ptr %l24
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l19, !tbaa !29
  %t43 = load i32, ptr %l24, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t42, i32 %t43)
  store { i64, ptr } %t44, ptr %l25
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t45, ptr %l3, !tbaa !27
  %t46 = load i64, ptr %l1, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t52 = icmp slt i64 %t46, %t49
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = load i64, ptr %l1, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  store i32 %t60, ptr %l30, !tbaa !23
  br label %bb13
bb12:
  %t62 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t62, ptr %l30, !tbaa !23
  br label %bb13
bb13:
  %t64 = load i32, ptr %l30, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efoldPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i1
  %l16 = alloca i64
  %l17 = alloca %"compiler/check:litv"
  %l21 = alloca %"compiler/check:litv"
  %rv = alloca %"compiler/check:litv"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb11
bb5:
  %t22 = load i32, ptr %l3
  %t24 = trunc i64 4 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %t27, %"compiler/source:Span" %t28)
  store i64 %t31, ptr %l16
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = call %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %t32)
  store %"compiler/check:litv" %t33, ptr %l17
  br label %bb9
bb9:
  %t34 = load %"compiler/check:litv", ptr %l17
  store %"compiler/check:litv" %t34, ptr %rv
  br label %ret
bb10:
  br label %bb16
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_2bda502508e1b1d_a3083ba563ab0481)
  unreachable
bb16:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load ptr, ptr %l1, !tbaa !29
  %t40 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t35, ptr %t36)
  store %"compiler/check:litv" %t40, ptr %l21
  br label %bb17
bb17:
  %t41 = load %"compiler/check:litv", ptr %l21
  store %"compiler/check:litv" %t41, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:litv", ptr %rv
  ret %"compiler/check:litv" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %lp10 = alloca ptr
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l18 = alloca %"compiler/typed:Local"
  %l19 = alloca i64
  %l20 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca i64
  %lp24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %lp29 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca i64
  %l48 = alloca i64
  %l52 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i32
  %l65 = alloca i32
  %l66 = alloca ptr
  %l74 = alloca ptr
  %l77 = alloca ptr
  %l80 = alloca i32
  %l82 = alloca ptr
  %l84 = alloca ptr
  %l86 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l93 = alloca i64
  %l98 = alloca ptr
  %l99 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l115 = alloca { i64, ptr }
  %l122 = alloca %"compiler/typed:Local"
  %l125 = alloca i1
  %l128 = alloca { i64, ptr }
  %l129 = alloca i1
  %l130 = alloca ptr
  %l133 = alloca i64
  %l137 = alloca i64
  %l142 = alloca i32
  %l146 = alloca ptr
  %l150 = alloca i1
  %l153 = alloca i1
  %l154 = alloca i1
  %l157 = alloca i1
  %l166 = alloca ptr
  %l169 = alloca i1
  %l170 = alloca i1
  %l175 = alloca i1
  %l176 = alloca { i64, [2 x i64] }
  %l185 = alloca i64
  %l204 = alloca i1
  %l213 = alloca { i64, ptr }
  %l215 = alloca ptr
  %l228 = alloca { i64, ptr }
  %l229 = alloca %"compiler/typed:Block"
  %l231 = alloca i1
  %l240 = alloca { i64, ptr }
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l253 = alloca %"compiler/source:Span"
  %l254 = alloca ptr
  %l258 = alloca { i64, ptr }
  %l259 = alloca %"compiler/typed:Block"
  %l261 = alloca ptr
  %l265 = alloca ptr
  %l268 = alloca { i64, ptr }
  %l273 = alloca %"compiler/source:Span"
  %l274 = alloca i32
  %l277 = alloca i32
  %l278 = alloca { i64, ptr }
  %l282 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca ptr
  %t26 = alloca { i64, [2 x i64] }, align 8
  %t295 = alloca { i64, [4 x i64] }, align 8
  %t332 = alloca { i64, [2 x i64] }, align 8
  %t336 = alloca { i64, [2 x i64] }, align 8
  %t365 = alloca { i64, [3 x i64] }, align 8
  %t565 = alloca { i64, [4 x i64] }, align 8
  %t577 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 0
  %t4 = load %"compiler/source:Span", ptr %t3
  store %"compiler/source:Span" %t4, ptr %l3
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l33
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l33, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 13
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t12)
  store i64 %t14, ptr %l36
  br label %bb2
bb2:
  %t15 = load i64, ptr %l36, !tbaa !24
  %t16 = sub i64 %t15, 1
  store i64 %t16, ptr %l5, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l4, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = trunc i64 %t22 to i32
  store { i64, [2 x i64] } zeroinitializer, ptr %t26
  %t27 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 0
  store i64 4, ptr %t27
  %t29 = insertvalue { i32 } undef, i32 %t24, 0
  %t30 = getelementptr { i64, [2 x i64] }, ptr %t26, i32 0, i32 1
  store { i32 } %t29, ptr %t30
  %t31 = load { i64, [2 x i64] }, ptr %t26
  %t32 = load i32, ptr %l2, !tbaa !23
  %t33 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr %"compiler/check:frame", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load %"compiler/source:Span", ptr %l3
  %t43 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %t18, { i64, [2 x i64] } %t31, i32 %t32, i64 %t36, %"compiler/source:Span" %t37)
  store i64 %t43, ptr %l48
  br label %bb3
bb3:
  %t44 = load i64, ptr %l48, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 16
  %t48 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t47, i64 %t48, i64 1)
  br label %bb4
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l52, !tbaa !29
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l53, !tbaa !24
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t55 = getelementptr %"compiler/check:frame", ptr %t53, i32 0, i32 1
  %t56 = load i64, ptr %t55, !tbaa !24
  store i64 %t56, ptr %l55, !tbaa !24
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/generic:Program", ptr %t60, i32 0, i32 2
  %t63 = load i32, ptr %l2, !tbaa !23
  %t66 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t66, ptr %l60
  br label %bb5
bb5:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l65
  br label %bb6
bb6:
  %t77 = load ptr, ptr %l52, !tbaa !29
  %t78 = load i64, ptr %l53, !tbaa !24
  %t79 = load i64, ptr %l55, !tbaa !24
  %t80 = load i32, ptr %l60, !tbaa !23
  %t81 = load i32, ptr %l65, !tbaa !23
  %t82 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %t77, i64 %t78, i64 %t79, i32 %t80, i32 %t81)
  store ptr %t82, ptr %l66
  br label %bb7
bb7:
  %t83 = load ptr, ptr %l66, !tbaa !29
  store ptr %t83, ptr %l7, !tbaa !29
  %t84 = load ptr, ptr %l7, !tbaa !29
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 4
  %t88 = load %"compiler/generic:Context", ptr %t87
  %t91 = getelementptr %"compiler/check:frame", ptr %t84, i32 0, i32 4
  store %"compiler/generic:Context" %t88, ptr %t91
  %t92 = load ptr, ptr %l7, !tbaa !29
  %t93 = load i64, ptr %l5, !tbaa !24
  %t96 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 19
  store i64 %t93, ptr %t96, !tbaa !24
  %t97 = load ptr, ptr %l7, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 20
  store i1 true, ptr %t99, !tbaa !21
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t100)
  store ptr %t102, ptr %l74
  br label %bb8
bb8:
  %t103 = load ptr, ptr %l74, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Body", ptr %t103, i32 0, i32 15
  store i1 true, ptr %t105, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t106)
  store ptr %t108, ptr %l77
  br label %bb9
bb9:
  %t109 = load %"compiler/source:Span", ptr %l3
  %t110 = load ptr, ptr %l77, !tbaa !29
  %t113 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %t110, i32 -1, i32 0, %"compiler/source:Span" %t109)
  store i32 %t113, ptr %l80
  br label %bb10
bb10:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t114)
  store ptr %t116, ptr %l82
  br label %bb11
bb11:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  store ptr %t120, ptr %l84, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t121)
  store ptr %t123, ptr %l86
  br label %bb12
bb12:
  %t124 = load ptr, ptr %l86, !tbaa !29
  %t126 = getelementptr %"compiler/typed:Body", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %t126, !tbaa !23
  %t128 = load ptr, ptr %l84, !tbaa !29
  %t130 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t128, i32 %t127)
  store { i64, ptr } %t130, ptr %l89
  br label %bb13
bb13:
  %t131 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  %t133 = extractvalue { i64, ptr } %t131, 1
  %t134 = mul i64 %t132, 8
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t138 = load ptr, ptr %l82, !tbaa !29
  call void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %s0, ptr %t138, { i64, ptr } %t137)
  br label %bb14
bb14:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 33
  %t144 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t142)
  store i64 %t144, ptr %l93
  br label %bb15
bb15:
  %t145 = load i64, ptr %l93, !tbaa !24
  store i64 %t145, ptr %l8, !tbaa !24
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t146, i32 0, i32 11
  %t149 = load ptr, ptr %l4, !tbaa !29
  %t151 = getelementptr %"compiler/check:frame", ptr %t149, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t155 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t148, i64 %t152)
  store ptr %t155, ptr %l98
  br label %bb16
bb16:
  %t156 = load ptr, ptr %l98, !tbaa !29
  store ptr %t156, ptr %l9, !tbaa !29
  %t157 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t157, ptr %l99
  br label %bb17
bb17:
  %t158 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 8, i64 8)
  store ptr %t158, ptr %lp10
  %t159 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l99
  %t160 = load ptr, ptr %lp10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t159, ptr %t160
  store i1 true, ptr %l11, !tbaa !21
  %t161 = load ptr, ptr %l9, !tbaa !29
  %t163 = getelementptr %"compiler/typed:Body", ptr %t161, i32 0, i32 5
  store ptr %t163, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb18
bb18:
  store %olang.scope zeroinitializer, ptr %s2
  %t165 = load ptr, ptr %l12, !tbaa !29
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %t165, i64 %t166)
  %t170 = extractvalue { i32, { i64, ptr } } %t169, 1
  %t171 = extractvalue { i32, { i64, ptr } } %t169, 0
  store i32 %t171, ptr %l106
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb20, label %ok.173
ok.173:
  store { i64, ptr } %t170, ptr %l105
  br label %bb19
bb19:
  %t174 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t174, ptr %l102, !tbaa !27
  br label %bb24
bb20:
  %t175 = load i32, ptr %l106, !tbaa !23
  %t176 = ashr i32 %t175, 16
  %t178 = icmp eq i32 %t176, 1
  br i1 %t178, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_fa7d7e355e8b1ea_2ae432ddcb4bb28e)
  unreachable
bb23:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb71
bb24:
  %t180 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t180, ptr %l14, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t181, 0
  store i64 %t183, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t185 = load i64, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t189 = icmp slt i64 %t185, %t186
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb69
bb27:
  br label %bb28
bb28:
  %t193 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t193, ptr %l115, !tbaa !27
  %t194 = load i64, ptr %l16, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i32, ptr %t197, i64 %t194
  %t199 = load i32, ptr %t198, !tbaa !33
  %t201 = load ptr, ptr %l9, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Body", ptr %t201, i32 0, i32 7
  %t206 = sext i32 %t199 to i64
  %t209 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t203, i64 %t206)
  store %"compiler/typed:Local" %t209, ptr %l122
  br label %bb29
bb29:
  %t210 = load %"compiler/typed:Local", ptr %l122
  store %"compiler/typed:Local" %t210, ptr %l18
  %t211 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t212 = load i32, ptr %t211, !tbaa !23
  %t214 = icmp eq i32 %t212, 0
  br i1 %t214, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l125, !tbaa !21
  br label %bb34
bb31:
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t218 = load i32, ptr %t217, !tbaa !23
  %t221 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t216, i32 %t218)
  store { i64, ptr } %t221, ptr %l128
  br label %bb32
bb32:
  %t222 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t223 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s3, { i64, ptr } %t222, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t223, ptr %l129
  br label %bb33
bb33:
  %t224 = load i1, ptr %l129, !tbaa !21
  store i1 %t224, ptr %l125, !tbaa !21
  br label %bb34
bb34:
  %t225 = load i1, ptr %l125, !tbaa !21
  br i1 %t225, label %bb35, label %bb36
bb35:
  store i1 false, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb36:
  br label %bb37
bb37:
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l130, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 13
  %t231 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t229)
  store i64 %t231, ptr %l133
  br label %bb38
bb38:
  %t232 = load i64, ptr %l133, !tbaa !24
  %t233 = sub i64 %t232, 1
  %t234 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t237 = load %"compiler/source:Span", ptr %t236
  %t238 = load ptr, ptr %l130, !tbaa !29
  %t242 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %t238, i64 %t233, i32 %t235, %"compiler/source:Span" %t237)
  store i64 %t242, ptr %l137
  br label %bb39
bb39:
  %t243 = load i64, ptr %l137, !tbaa !24
  store i64 %t243, ptr %l19, !tbaa !24
  %t244 = load i64, ptr %l19, !tbaa !24
  %t246 = icmp slt i64 %t244, 0
  br i1 %t246, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb41:
  br label %bb42
bb42:
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load i64, ptr %l19, !tbaa !24
  %t252 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t248, i64 %t249)
  store i32 %t252, ptr %l142
  br label %bb43
bb43:
  %t253 = load i32, ptr %l142, !tbaa !23
  store i32 %t253, ptr %l20, !tbaa !23
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t256 = load %"compiler/source:Span", ptr %t255
  %t257 = load i64, ptr %l19, !tbaa !24
  %t261 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %t254, %"compiler/source:Span" %t256, i64 %t257)
  store ptr %t261, ptr %l146
  br label %bb44
bb44:
  %t262 = load ptr, ptr %l146, !tbaa !29
  store ptr %t262, ptr %l21, !tbaa !29
  %t263 = load i32, ptr %l20, !tbaa !23
  %t264 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t265 = load i32, ptr %t264, !tbaa !23
  %t268 = icmp ne i32 %t263, %t265
  br i1 %t268, label %bb45, label %bb46
bb45:
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t271 = load i32, ptr %l20, !tbaa !23
  %t274 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t270, i32 %t271)
  store i1 %t274, ptr %l153
  br label %bb47
bb46:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb48
bb47:
  %t275 = load i1, ptr %l153, !tbaa !21
  store i1 %t275, ptr %l150, !tbaa !21
  br label %bb48
bb48:
  %t276 = load i1, ptr %l150, !tbaa !21
  br i1 %t276, label %bb49, label %bb50
bb49:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t279 = load i32, ptr %t278, !tbaa !23
  %t282 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t277, i32 %t279)
  store i1 %t282, ptr %l157
  br label %bb51
bb50:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb52
bb51:
  %t283 = load i1, ptr %l157, !tbaa !21
  %t284 = xor i1 %t283, true
  store i1 %t284, ptr %l154, !tbaa !21
  br label %bb52
bb52:
  %t286 = load i1, ptr %l154, !tbaa !21
  br i1 %t286, label %bb53, label %bb54
bb53:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t289 = load %"compiler/source:Span", ptr %t288
  %t290 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t291 = load %"compiler/source:Span", ptr %t290
  %t292 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t293 = load i32, ptr %t292, !tbaa !23
  %t294 = load ptr, ptr %l21, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t295
  %t296 = getelementptr { i64, [4 x i64] }, ptr %t295, i32 0, i32 0
  store i64 2, ptr %t296
  %t298 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t291, 0
  %t300 = insertvalue { %"compiler/source:Span", i32, ptr } %t298, i32 %t293, 1
  %t302 = insertvalue { %"compiler/source:Span", i32, ptr } %t300, ptr %t294, 2
  %t303 = getelementptr { i64, [4 x i64] }, ptr %t295, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t302, ptr %t303
  %t304 = load { i64, [4 x i64] }, ptr %t295
  %t306 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t304, ptr %t306
  %t310 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t287, %"compiler/source:Span" %t289, ptr %t306)
  store ptr %t310, ptr %l166
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t311 = load ptr, ptr %l166, !tbaa !29
  store ptr %t311, ptr %l21, !tbaa !29
  br label %bb56
bb56:
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t313 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t314 = load i32, ptr %t313, !tbaa !23
  %t317 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t312, i32 %t314)
  store i1 %t317, ptr %l169
  br label %bb57
bb57:
  %t318 = load i1, ptr %l169, !tbaa !21
  br i1 %t318, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l170, !tbaa !21
  br label %bb61
bb59:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/generic:Program", ptr %t322, i32 0, i32 2
  %t325 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t326 = load i32, ptr %t325, !tbaa !23
  %t329 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %t324, i32 %t326)
  store i1 %t329, ptr %l175
  br label %bb60
bb60:
  %t330 = load i1, ptr %l175, !tbaa !21
  store i1 %t330, ptr %l170, !tbaa !21
  br label %bb61
bb61:
  %t331 = load i1, ptr %l170, !tbaa !21
  br i1 %t331, label %bb62, label %bb63
bb62:
  store { i64, [2 x i64] } zeroinitializer, ptr %t332
  %t333 = getelementptr { i64, [2 x i64] }, ptr %t332, i32 0, i32 0
  store i64 5, ptr %t333
  %t334 = load { i64, [2 x i64] }, ptr %t332
  store { i64, [2 x i64] } %t334, ptr %l176
  br label %bb64
bb63:
  store { i64, [2 x i64] } zeroinitializer, ptr %t336
  %t337 = getelementptr { i64, [2 x i64] }, ptr %t336, i32 0, i32 0
  store i64 0, ptr %t337
  %t338 = load { i64, [2 x i64] }, ptr %t336
  store { i64, [2 x i64] } %t338, ptr %l176
  br label %bb64
bb64:
  %t340 = load { i64, [2 x i64] }, ptr %l176
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 0
  %t343 = load i32, ptr %t342, !tbaa !23
  %t344 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t345 = load %"compiler/source:Span", ptr %t344
  %t346 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 2
  %t347 = load i32, ptr %t346, !tbaa !23
  %t355 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t341, i32 %t343, %"compiler/source:Span" %t345, i32 %t347, i32 1, { i64, [2 x i64] } %t340)
  store i64 %t355, ptr %l185
  br label %bb65
bb65:
  %t356 = load i64, ptr %l185, !tbaa !24
  store i64 %t356, ptr %l23, !tbaa !24
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = getelementptr %"compiler/typed:Local", ptr %l18, i32 0, i32 1
  %t359 = load %"compiler/source:Span", ptr %t358
  %t360 = load i64, ptr %l23, !tbaa !24
  %t362 = trunc i64 %t360 to i32
  %t364 = load ptr, ptr %l21, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 0
  store i64 0, ptr %t366
  %t368 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t359, 0
  %t370 = insertvalue { %"compiler/source:Span", i32, ptr } %t368, i32 %t362, 1
  %t372 = insertvalue { %"compiler/source:Span", i32, ptr } %t370, ptr %t364, 2
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t365, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t372, ptr %t373
  %t374 = load { i64, [3 x i64] }, ptr %t365
  %t376 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t374, ptr %t376
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t357, ptr %t376)
  br label %bb66
bb66:
  %t379 = load ptr, ptr %lp10
  %t380 = load i64, ptr %l23, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t379, i64 %t380)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s3)
  br label %bb68
bb68:
  %t383 = load i64, ptr %l16, !tbaa !24
  %t385 = add i64 %t383, 1
  store i64 %t385, ptr %l16, !tbaa !24
  br label %bb25
bb69:
  %t387 = load i64, ptr %l13, !tbaa !24
  %t388 = load i64, ptr %l15, !tbaa !24
  %t391 = add i64 %t387, %t388
  store i64 %t391, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb70
bb70:
  br label %bb18
bb71:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load ptr, ptr %l4, !tbaa !29
  %t396 = getelementptr %"compiler/check:frame", ptr %t394, i32 0, i32 0
  %t397 = load i64, ptr %t396, !tbaa !24
  %t400 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %t393, i64 %t397)
  store i1 %t400, ptr %l204
  br label %bb72
bb72:
  %t401 = load i1, ptr %l204, !tbaa !21
  br i1 %t401, label %bb73, label %bb74
bb73:
  %t402 = load i1, ptr %l11, !tbaa !21
  br i1 %t402, label %bb75, label %bb76
bb74:
  br label %bb80
bb75:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l4, !tbaa !29
  %t407 = getelementptr %"compiler/check:frame", ptr %t405, i32 0, i32 0
  %t408 = load i64, ptr %t407, !tbaa !24
  %t409 = load ptr, ptr %lp10
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecks(ptr %v0, ptr %v0, ptr %t404, i64 %t408, ptr %t409, i1 true)
  br label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s10
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t414 = load %"compiler/source:Span", ptr %l3
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s10, ptr %t413, %"compiler/source:Span" %t414, { i64, ptr } { i64 52, ptr getelementptr inbounds (<{ i64, [52 x i8] }>, ptr @.d20, i32 0, i32 1) })
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s10)
  br label %bb79
bb79:
  br label %bb80
bb80:
  %t417 = load ptr, ptr %l1, !tbaa !29
  %t419 = getelementptr %"compiler/ast:Func", ptr %t417, i32 0, i32 4
  %t420 = load { i64, ptr }, ptr %t419, !tbaa !27
  store { i64, ptr } %t420, ptr %l213, !tbaa !27
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t421)
  store ptr %t423, ptr %l215
  br label %bb81
bb81:
  %t424 = load ptr, ptr %l215, !tbaa !29
  %t426 = getelementptr %"compiler/check:frame", ptr %t424, i32 0, i32 40
  %t427 = load { i64, ptr }, ptr %l213, !tbaa !27
  call void @compiler_2fcheck_2estoredIn(ptr %v1, ptr %v0, { i64, ptr } %t427, ptr %t426)
  br label %bb82
bb82:
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t431 = getelementptr %"compiler/ast:Func", ptr %t429, i32 0, i32 4
  %t432 = load { i64, ptr }, ptr %t431, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t432, 0
  %t436 = icmp sgt i64 %t434, 0
  br i1 %t436, label %bb83, label %bb84
bb83:
  %t438 = load ptr, ptr %l0, !tbaa !29
  %t439 = load ptr, ptr %l1, !tbaa !29
  %t441 = getelementptr %"compiler/ast:Func", ptr %t439, i32 0, i32 4
  %t442 = load { i64, ptr }, ptr %t441, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t438, { i64, ptr } %t442)
  br label %bb85
bb84:
  br label %bb86
bb85:
  br label %bb86
bb86:
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t447 = getelementptr %"compiler/check:Checker", ptr %t445, i32 0, i32 33
  %t448 = load i64, ptr %l8, !tbaa !24
  %t451 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t447, i64 %t448)
  store { i64, ptr } %t451, ptr %l228
  br label %bb87
bb87:
  %t452 = load { i64, ptr }, ptr %l228, !tbaa !27
  %t453 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t452)
  store %"compiler/typed:Block" %t453, ptr %l229
  br label %bb88
bb88:
  %t454 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store ptr %t454, ptr %lp24
  %t455 = load %"compiler/typed:Block", ptr %l229
  %t456 = load ptr, ptr %lp24
  store %"compiler/typed:Block" %t455, ptr %t456
  %t457 = load ptr, ptr %lp24
  %t459 = call i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %t457)
  store i1 %t459, ptr %l231
  br label %bb89
bb89:
  %t460 = load i1, ptr %l231, !tbaa !21
  %t461 = xor i1 %t460, true
  br i1 %t461, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s12
  %t463 = load ptr, ptr %lp24
  %t464 = getelementptr %"compiler/typed:Block", ptr %t463, i32 0, i32 1
  %t465 = load { i64, ptr }, ptr %t464, !tbaa !27
  store { i64, ptr } %t465, ptr %l25, !tbaa !27
  store i64 0, ptr %l26, !tbaa !24
  %t467 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t469 = extractvalue { i64, ptr } %t467, 0
  store i64 %t469, ptr %l27, !tbaa !24
  br label %bb92
bb91:
  br label %bb104
bb92:
  store %olang.scope zeroinitializer, ptr %s14
  %t471 = load i64, ptr %l26, !tbaa !24
  %t472 = load i64, ptr %l27, !tbaa !24
  %t475 = icmp slt i64 %t471, %t472
  %t477 = xor i1 %t475, true
  br i1 %t477, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s14)
  br label %bb98
bb94:
  br label %bb95
bb95:
  %t479 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t479, ptr %l240, !tbaa !27
  %t480 = load i64, ptr %l26, !tbaa !24
  %t482 = getelementptr { i64, ptr }, ptr %l240, i32 0, i32 1
  %t483 = load ptr, ptr %t482, !tbaa !27
  %t484 = getelementptr ptr, ptr %t483, i64 %t480
  %t485 = load ptr, ptr %t484, !tbaa !39
  %t487 = load ptr, ptr %l0, !tbaa !29
  %t489 = getelementptr %"compiler/check:Checker", ptr %t487, i32 0, i32 33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v0, ptr %t489, ptr %t485)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s14)
  br label %bb97
bb97:
  %t493 = load i64, ptr %l26, !tbaa !24
  %t495 = add i64 %t493, 1
  store i64 %t495, ptr %l26, !tbaa !24
  br label %bb92
bb98:
  %t497 = load ptr, ptr %l0, !tbaa !29
  store ptr %t497, ptr %l248, !tbaa !29
  %t498 = load ptr, ptr %l0, !tbaa !29
  store ptr %t498, ptr %l249, !tbaa !29
  %t499 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t500 = load i32, ptr %t499, !tbaa !23
  %t502 = sub i32 %t500, 1
  %t503 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t504 = load i32, ptr %t503, !tbaa !23
  %t507 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s12, i32 %t502, i32 %t504)
  store %"compiler/source:Span" %t507, ptr %l253
  br label %bb99
bb99:
  %t508 = load ptr, ptr %l249, !tbaa !29
  %t509 = load %"compiler/source:Span", ptr %l253
  %t510 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %t508, %"compiler/source:Span" %t509)
  store ptr %t510, ptr %l254
  br label %bb100
bb100:
  %t511 = load ptr, ptr %l248, !tbaa !29
  %t512 = load ptr, ptr %l254, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t511, ptr %t512)
  br label %bb101
bb101:
  %t513 = load ptr, ptr %l0, !tbaa !29
  %t515 = getelementptr %"compiler/check:Checker", ptr %t513, i32 0, i32 33
  %t516 = load i64, ptr %l8, !tbaa !24
  %t519 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t515, i64 %t516)
  store { i64, ptr } %t519, ptr %l258
  br label %bb102
bb102:
  %t520 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t521 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v0, i32 0, { i64, ptr } %t520)
  store %"compiler/typed:Block" %t521, ptr %l259
  br label %bb103
bb103:
  %t522 = load %"compiler/typed:Block", ptr %l259
  %t523 = load ptr, ptr %lp24
  store %"compiler/typed:Block" %t522, ptr %t523
  call void @__olang_scope_close(ptr %s12)
  br label %bb104
bb104:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t526 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t524)
  store ptr %t526, ptr %l261
  br label %bb105
bb105:
  %t527 = load ptr, ptr %l261, !tbaa !29
  %t528 = load ptr, ptr %lp24
  %t531 = getelementptr %"compiler/typed:Body", ptr %t527, i32 0, i32 11
  store ptr %t528, ptr %t531, !tbaa !29
  %t532 = load ptr, ptr %l0, !tbaa !29
  %t534 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t532)
  store ptr %t534, ptr %l265
  br label %bb106
bb106:
  %t535 = load ptr, ptr %l265, !tbaa !29
  %t537 = getelementptr %"compiler/check:frame", ptr %t535, i32 0, i32 27
  %t539 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v0, ptr %t537)
  store { i64, ptr } %t539, ptr %l268
  br label %bb107
bb107:
  %t540 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t540, ptr %lp29
  %t541 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t542 = load ptr, ptr %lp29
  store { i64, ptr } %t541, ptr %t542, !tbaa !27
  %t543 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %t543)
  br label %bb108
bb108:
  %t545 = load ptr, ptr %l0, !tbaa !29
  %t547 = getelementptr %"compiler/check:Checker", ptr %t545, i32 0, i32 16
  %t548 = load i64, ptr %l6, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t547, i64 %t548, i64 2)
  br label %bb109
bb109:
  %t551 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t551, ptr %l273
  %t552 = load i32, ptr %l2, !tbaa !23
  store i32 %t552, ptr %l274, !tbaa !23
  %t553 = load i64, ptr %l6, !tbaa !24
  %t555 = trunc i64 %t553 to i32
  store i32 %t555, ptr %l277, !tbaa !23
  %t557 = load ptr, ptr %lp29
  %t558 = load { i64, ptr }, ptr %t557, !tbaa !27
  store { i64, ptr } %t558, ptr %l278, !tbaa !27
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load %"compiler/source:Span", ptr %l3
  %t564 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t559, i32 5, %"compiler/source:Span" %t560)
  store i32 %t564, ptr %l282
  br label %bb110
bb110:
  store { i64, [4 x i64] } zeroinitializer, ptr %t565
  %t566 = getelementptr { i64, [4 x i64] }, ptr %t565, i32 0, i32 0
  store i64 1, ptr %t566
  %t567 = load i32, ptr %l277, !tbaa !23
  %t568 = insertvalue { i32, { i64, ptr }, i32 } undef, i32 %t567, 0
  %t569 = load { i64, ptr }, ptr %l278, !tbaa !27
  %t570 = insertvalue { i32, { i64, ptr }, i32 } %t568, { i64, ptr } %t569, 1
  %t571 = load i32, ptr %l282, !tbaa !23
  %t572 = insertvalue { i32, { i64, ptr }, i32 } %t570, i32 %t571, 2
  %t573 = getelementptr { i64, [4 x i64] }, ptr %t565, i32 0, i32 1
  store { i32, { i64, ptr }, i32 } %t572, ptr %t573
  %t574 = load { i64, [4 x i64] }, ptr %t565
  %t576 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t574, ptr %t576
  store { i64, [5 x i64] } zeroinitializer, ptr %t577
  %t578 = getelementptr { i64, [5 x i64] }, ptr %t577, i32 0, i32 0
  store i64 15, ptr %t578
  %t579 = load %"compiler/source:Span", ptr %l273
  %t580 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t579, 0
  %t581 = load i32, ptr %l274, !tbaa !23
  %t582 = insertvalue { %"compiler/source:Span", i32, ptr } %t580, i32 %t581, 1
  %t584 = insertvalue { %"compiler/source:Span", i32, ptr } %t582, ptr %t576, 2
  %t585 = getelementptr { i64, [5 x i64] }, ptr %t577, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t584, ptr %t585
  %t586 = load { i64, [5 x i64] }, ptr %t577
  %t588 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t586, ptr %t588
  call void @__olang_scope_close(ptr %s0)
  store ptr %t588, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %t6, i32 %a1)
  store { i64, ptr } %t10, ptr %l11
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l5, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb4:
  br label %bb5
bb5:
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t24, ptr %l18, !tbaa !27
  %t25 = load i64, ptr %l4, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i32, ptr %t28, i64 %t25
  %t30 = load i32, ptr %t29, !tbaa !33
  %t36 = icmp eq i32 %t30, %a2
  br i1 %t36, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t41 = add i64 %t39, 1
  store i64 %t41, ptr %l4, !tbaa !24
  br label %bb2
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l17 = alloca i32
  %l24 = alloca i32
  %l31 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l61 = alloca ptr
  %l66 = alloca i32
  %l70 = alloca i1
  %l78 = alloca i32
  %l81 = alloca ptr
  %l86 = alloca i32
  %l90 = alloca i1
  %l95 = alloca ptr
  %l100 = alloca i32
  %l103 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l17
  br label %bb7
bb7:
  %t23 = load i32, ptr %l17
  store i32 %t23, ptr %l4
  %t24 = load i32, ptr %l4
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb11
bb11:
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp eq i32 %t40, %t39
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l31
  br label %bb15
bb15:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i32, ptr %l36
  store i32 %t62, ptr %l5
  %t63 = load i32, ptr %l5
  %t65 = trunc i64 0 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l39, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l44
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i32, ptr %l44, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t81, i32 %t82, i32 %t79, i64 %t80)
  store i1 %t85, ptr %l47
  br label %bb23
bb23:
  %t86 = load i1, ptr %l47, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i32, ptr %l5
  %t89 = trunc i64 1 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l50, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l1, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l55
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t103 = load i32, ptr %l2, !tbaa !23
  %t104 = load i64, ptr %l3, !tbaa !24
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i32, ptr %l55, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t105, i32 %t106, i32 %t103, i64 %t104)
  store i1 %t109, ptr %l58
  br label %bb28
bb28:
  %t110 = load i1, ptr %l58, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
bb29:
  %t111 = load i32, ptr %l5
  %t113 = trunc i64 4 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l1, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l66
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t127 = load i32, ptr %l2, !tbaa !23
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = add i64 %t128, 1
  %t131 = load ptr, ptr %l61, !tbaa !29
  %t132 = load i32, ptr %l66, !tbaa !23
  %t135 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t131, i32 %t132, i32 %t127, i64 %t130)
  store i1 %t135, ptr %l70
  br label %bb33
bb33:
  %t136 = load i1, ptr %l70, !tbaa !21
  store i1 %t136, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  %t138 = load i32, ptr %l4
  %t140 = trunc i64 19 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb45
bb38:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l1, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l78
  br label %bb39
bb39:
  %t153 = load i32, ptr %l78, !tbaa !23
  %t154 = icmp eq i32 %t153, 0
  br i1 %t154, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l1, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l86
  br label %bb43
bb43:
  %t168 = load i32, ptr %l2, !tbaa !23
  %t169 = load i64, ptr %l3, !tbaa !24
  %t171 = add i64 %t169, 1
  %t172 = load ptr, ptr %l81, !tbaa !29
  %t173 = load i32, ptr %l86, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t172, i32 %t173, i32 %t168, i64 %t171)
  store i1 %t176, ptr %l90
  br label %bb44
bb44:
  %t177 = load i1, ptr %l90, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
bb45:
  %t178 = load i32, ptr %l4
  %t180 = trunc i64 22 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  %t183 = load i32, ptr %l4
  %t185 = trunc i64 23 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l95, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l100
  br label %bb51
bb51:
  %t199 = load i32, ptr %l2, !tbaa !23
  %t200 = load i64, ptr %l3, !tbaa !24
  %t201 = load ptr, ptr %l95, !tbaa !29
  %t202 = load i32, ptr %l100, !tbaa !23
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t201, i32 %t202, i32 %t199, i64 %t200)
  store i1 %t205, ptr %l103
  br label %bb52
bb52:
  %t206 = load i1, ptr %l103, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb53:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinary(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca [2 x i64]
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i32
  %l21 = alloca %"compiler/check:laneNode"
  %l22 = alloca i32
  %l26 = alloca %"compiler/check:laneNode"
  %l28 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l38 = alloca %"compiler/source:Span"
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i32
  %l46 = alloca i64
  %l51 = alloca i32
  %l52 = alloca %"compiler/check:laneNode"
  %l53 = alloca i64
  %l54 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t1, ptr %a4)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %t7, ptr %a5)
  store i64 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l7, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l16, !tbaa !29
  %t14 = load i32, ptr %l3
  store i32 %t14, ptr %l17
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 35
  %t18 = load i64, ptr %l6, !tbaa !24
  %t21 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %s0, ptr %t17, i64 %t18)
  store %"compiler/check:laneNode" %t21, ptr %l21
  br label %bb3
bb3:
  %t22 = getelementptr %"compiler/check:laneNode", ptr %l21, i32 0, i32 8
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l22, !tbaa !23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 35
  %t27 = load i64, ptr %l7, !tbaa !24
  %t30 = call %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %s0, ptr %t26, i64 %t27)
  store %"compiler/check:laneNode" %t30, ptr %l26
  br label %bb4
bb4:
  %t31 = getelementptr %"compiler/check:laneNode", ptr %l26, i32 0, i32 8
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load ptr, ptr %l16, !tbaa !29
  %t34 = load i32, ptr %l17
  %t35 = load i32, ptr %l22, !tbaa !23
  %t37 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %t33, i32 %t34, i32 %t35, i32 %t32)
  store i32 %t37, ptr %l28
  br label %bb5
bb5:
  %t38 = load i32, ptr %l28, !tbaa !23
  store i32 %t38, ptr %l8, !tbaa !23
  %t39 = load i64, ptr %l6, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = insertvalue [2 x i64] undef, i64 %t39, 0
  %t44 = insertvalue [2 x i64] %t42, i64 %t40, 1
  store [2 x i64] %t44, ptr %l9
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l32, !tbaa !29
  %t47 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t47, ptr %l33
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l34, !tbaa !29
  %t49 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneBin, !tbaa !24
  store i64 %t49, ptr %l35, !tbaa !24
  %t50 = load i32, ptr %l3
  store i32 %t50, ptr %l36
  %t51 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t51, ptr %l37
  %t52 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t52, ptr %l38
  %t53 = load i64, ptr %l6, !tbaa !24
  store i64 %t53, ptr %l39, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  store i64 %t54, ptr %l40, !tbaa !24
  %t55 = load i32, ptr %l8, !tbaa !23
  store i32 %t55, ptr %l41, !tbaa !23
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = insertvalue { i64, ptr } undef, i64 2, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %l9, 1
  %t60 = load %"compiler/source:Span", ptr %l2
  %t64 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %s0, ptr %t56, { i64, ptr } %t59, %"compiler/source:Span" %t60)
  store i64 %t64, ptr %l46
  br label %bb6
bb6:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = insertvalue { i64, ptr } undef, i64 2, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %l9, 1
  %t69 = load i32, ptr %l8, !tbaa !23
  %t73 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %s0, ptr %t65, { i64, ptr } %t68, i32 %t69)
  store i32 %t73, ptr %l51
  br label %bb7
bb7:
  %t74 = load i64, ptr %l35, !tbaa !24
  %t75 = load i32, ptr %l36
  %t76 = load %"compiler/source:Span", ptr %l37
  %t77 = load %"compiler/source:Span", ptr %l38
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = load i64, ptr %l40, !tbaa !24
  %t80 = load i32, ptr %l41, !tbaa !23
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = load i32, ptr %l51, !tbaa !23
  %t83 = call %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v0, i64 %t74, i32 %t75, %"compiler/source:Span" %t76, %"compiler/source:Span" %t77, i64 %t78, i64 %t79, i64 -1, ptr null, i32 %t80, i64 %t81, i32 %t82)
  store %"compiler/check:laneNode" %t83, ptr %l52
  br label %bb8
bb8:
  %t84 = load ptr, ptr %l34, !tbaa !29
  %t85 = load %"compiler/check:laneNode", ptr %l52
  %t86 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v0, ptr %t84, %"compiler/check:laneNode" %t85)
  store i64 %t86, ptr %l53
  br label %bb9
bb9:
  %t87 = load ptr, ptr %l32, !tbaa !29
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %t87, %"compiler/source:Span" %t88, i64 %t89)
  store ptr %t90, ptr %l54
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load ptr, ptr %l54, !tbaa !29
  store ptr %t91, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitCtor(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l14 = alloca i1
  %l17 = alloca i1
  %l22 = alloca i32
  %l26 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i32
  %l40 = alloca ptr
  %l42 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca i32
  %l46 = alloca ptr
  %l50 = alloca ptr
  %rv = alloca ptr
  %t86 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l2, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l5, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l5, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb5:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i32, ptr %l2, !tbaa !23
  %t16 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l12
  br label %bb6
bb6:
  %t17 = load i1, ptr %l12, !tbaa !21
  %t18 = xor i1 %t17, true
  store i1 %t18, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t20 = load i1, ptr %l9, !tbaa !21
  br i1 %t20, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb11
bb9:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t25 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t21, ptr %t22)
  store i1 %t25, ptr %l17
  br label %bb10
bb10:
  %t26 = load i1, ptr %l17, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l14, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store ptr null, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t31, i32 %t32)
  store i32 %t35, ptr %l22
  br label %bb15
bb15:
  %t36 = load i32, ptr %l22
  %t38 = trunc i64 4 to i32
  %t39 = icmp eq i32 %t36, %t38
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb19
bb17:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t47 = load i32, ptr %l2, !tbaa !23
  %t50 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t46, i32 %t47)
  store i1 %t50, ptr %l30
  br label %bb18
bb18:
  %t51 = load i1, ptr %l30, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l26, !tbaa !21
  br label %bb19
bb19:
  %t54 = load i1, ptr %l26, !tbaa !21
  br i1 %t54, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb23
bb21:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t59 = load i32, ptr %l2, !tbaa !23
  %t62 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l36
  br label %bb22
bb22:
  %t63 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t64 = load i32, ptr %l36, !tbaa !23
  %t66 = icmp eq i32 %t64, %t63
  store i1 %t66, ptr %l32, !tbaa !21
  br label %bb23
bb23:
  %t68 = load i1, ptr %l32, !tbaa !21
  br i1 %t68, label %bb24, label %bb25
bb24:
  store ptr null, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t70 = load ptr, ptr %l0, !tbaa !29
  store ptr %t70, ptr %l40, !tbaa !29
  %t71 = load ptr, ptr %l1, !tbaa !29
  %t73 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t71)
  store %"compiler/source:Span" %t73, ptr %l42
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t74)
  store %"compiler/source:Span" %t76, ptr %l44
  br label %bb28
bb28:
  %t77 = load i32, ptr %l2, !tbaa !23
  store i32 %t77, ptr %l45, !tbaa !23
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l46, !tbaa !29
  %t79 = icmp sge i64 1, 0
  br i1 %t79, label %bb29, label %bb30
bb29:
  %t81 = icmp sle i64 1, 1152921504606846975
  br i1 %t81, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb31:
  %t83 = mul i64 1, 8
  %t84 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t83)
  %t85 = load ptr, ptr %l46, !tbaa !29
  store i64 0, ptr %t86
  br label %fill.87
fill.87:
  %t90 = load i64, ptr %t86
  %t91 = icmp slt i64 %t90, 1
  br i1 %t91, label %fillb.88, label %filld.89
fillb.88:
  %t92 = getelementptr ptr, ptr %t84, i64 %t90
  store ptr %t85, ptr %t92
  %t93 = add i64 %t90, 1
  store i64 %t93, ptr %t86
  br label %fill.87
filld.89:
  %t94 = insertvalue { i64, ptr } undef, i64 1, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t84, 1
  %t96 = load ptr, ptr %l40, !tbaa !29
  %t97 = load %"compiler/source:Span", ptr %l42
  %t98 = load %"compiler/source:Span", ptr %l44
  %t99 = load i32, ptr %l45, !tbaa !23
  %t101 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v0, ptr %t96, %"compiler/source:Span" %t97, %"compiler/source:Span" %t98, i32 %t99, { i64, ptr } %t95)
  store ptr %t101, ptr %l50
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_89233ed815a81c43_385dc0f6d58c413f)
  unreachable
bb33:
  %t102 = load ptr, ptr %l50, !tbaa !29
  store ptr %t102, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/check:litv"
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l14 = alloca %"compiler/check:litv"
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l29 = alloca i1
  %l30 = alloca ptr
  %l31 = alloca i1
  %l41 = alloca i1
  %l42 = alloca i1
  %l46 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l2, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t13 = call %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %t8, ptr %t9)
  store %"compiler/check:litv" %t13, ptr %l14
  br label %bb4
bb4:
  %t14 = load %"compiler/check:litv", ptr %l14
  store %"compiler/check:litv" %t14, ptr %l3
  %t15 = getelementptr %"compiler/check:litv", ptr %l3, i32 0, i32 0
  %t16 = load i1, ptr %t15, !tbaa !21
  br i1 %t16, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/check:litv", ptr %l3
  %t20 = load i32, ptr %l2, !tbaa !23
  %t24 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t18, %"compiler/check:litv" %t19, i32 %t20)
  store i1 %t24, ptr %l19
  br label %bb7
bb6:
  br label %bb8
bb7:
  %t25 = load i1, ptr %l19, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load ptr, ptr %l1, !tbaa !29
  store ptr %t26, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t27 = load ptr, ptr %l20, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb9, label %bb10
bb9:
  %t30 = load ptr, ptr %l20, !tbaa !29
  %t31 = load i64, ptr %t30
  %t33 = icmp eq i64 %t31, 2
  store i1 %t33, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t34 = load i1, ptr %l21, !tbaa !21
  br i1 %t34, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr { i64, [5 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { %"compiler/source:Span", ptr }, ptr %t37, i32 0, i32 1
  %t39 = load ptr, ptr %t38
  store ptr %t39, ptr %l4, !tbaa !29
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t47 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t41, ptr %t42, i32 %t43)
  store i1 %t47, ptr %l29
  br label %bb14
bb14:
  %t48 = load i1, ptr %l29, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t50 = load ptr, ptr %l30, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb16, label %bb17
bb16:
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load i64, ptr %t53
  %t56 = icmp eq i64 %t54, 8
  store i1 %t56, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l31, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [5 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load ptr, ptr %t61
  store ptr %t62, ptr %l5, !tbaa !29
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 3
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l6, !tbaa !29
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l5, !tbaa !29
  %t72 = load i32, ptr %l2, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t70, ptr %t71, i32 %t72)
  store i1 %t76, ptr %l41
  br label %bb21
bb21:
  %t77 = load i1, ptr %l41, !tbaa !21
  br i1 %t77, label %bb22, label %bb23
bb22:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load ptr, ptr %l6, !tbaa !29
  %t80 = load i32, ptr %l2, !tbaa !23
  %t84 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLikeFits(ptr %v0, ptr %v1, ptr %t78, ptr %t79, i32 %t80)
  store i1 %t84, ptr %l46
  br label %bb24
bb23:
  store i1 false, ptr %l42, !tbaa !21
  br label %bb25
bb24:
  %t85 = load i1, ptr %l46, !tbaa !21
  store i1 %t85, ptr %l42, !tbaa !21
  br label %bb25
bb25:
  %t86 = load i1, ptr %l42, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l5 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i32
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i1
  %l21 = alloca i1
  %l25 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb2, label %bb3
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t9 = load i32, ptr %l1, !tbaa !23
  %t12 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %t8, i32 %t9)
  store i32 %t12, ptr %l8
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t13 = load ptr, ptr %l5, !tbaa !29
  %t14 = load i32, ptr %l8, !tbaa !23
  %t15 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t15, ptr %l9
  br label %bb5
bb5:
  %t16 = load i32, ptr %l9, !tbaa !23
  store i32 %t16, ptr %rv
  br label %ret
bb6:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l1, !tbaa !23
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l12
  br label %bb7
bb7:
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l1, !tbaa !23
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t23, i32 %t24)
  store i1 %t27, ptr %l16
  br label %bb10
bb9:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t28 = load i1, ptr %l16, !tbaa !21
  store i1 %t28, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  %t37 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t33, i32 %t34)
  store i1 %t37, ptr %l21
  br label %bb14
bb13:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb15
bb14:
  %t38 = load i1, ptr %l21, !tbaa !21
  %t39 = xor i1 %t38, true
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb15
bb15:
  %t41 = load i1, ptr %l17, !tbaa !21
  br i1 %t41, label %bb16, label %bb17
bb16:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l25
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t47 = load i32, ptr %l25, !tbaa !23
  store i32 %t47, ptr %rv
  br label %ret
bb19:
  %t48 = load i32, ptr %l1, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emembersWritten(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l9 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca ptr
  %l38 = alloca i32
  %l39 = alloca i64
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %t4, i32 %a1)
  store { i64, ptr } %t8, ptr %l9
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = load i64, ptr %l3, !tbaa !24
  %t15 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb4:
  br label %bb5
bb5:
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t22, ptr %l16, !tbaa !27
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr i32, ptr %t26, i64 %t23
  %t28 = load i32, ptr %t27, !tbaa !33
  store i32 %t28, ptr %l5, !tbaa !23
  %t30 = load i32, ptr %l5, !tbaa !23
  %t31 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t34 = icmp eq i32 %t30, %t31
  br i1 %t34, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l5, !tbaa !23
  %t46 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l27
  br label %bb9
bb9:
  %t47 = load i32, ptr %l27
  %t49 = trunc i64 18 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb10, label %bb11
bb10:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  store ptr %t57, ptr %l33, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l5, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l38
  br label %bb12
bb11:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb16
bb12:
  %t68 = load ptr, ptr %l33, !tbaa !29
  %t69 = load i32, ptr %l38, !tbaa !23
  %t70 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %t68, i32 %t69)
  store i64 %t70, ptr %l39
  br label %bb13
bb13:
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = getelementptr %"compiler/generic:Program", ptr %t74, i32 0, i32 2
  store ptr %t76, ptr %l42, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 2
  %t83 = load i32, ptr %l5, !tbaa !23
  %t86 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %t82, i32 %t83)
  store i32 %t86, ptr %l47
  br label %bb14
bb14:
  %t87 = load ptr, ptr %l42, !tbaa !29
  %t88 = load i32, ptr %l47, !tbaa !23
  %t89 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t87, i32 %t88)
  store { i64, ptr } %t89, ptr %l48
  br label %bb15
bb15:
  %t90 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = load i64, ptr %l39, !tbaa !24
  %t94 = icmp ne i64 %t92, %t91
  store i1 %t94, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t96 = load i1, ptr %l30, !tbaa !21
  br i1 %t96, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  %t98 = load i64, ptr %l3, !tbaa !24
  %t100 = add i64 %t98, 1
  store i64 %t100, ptr %l3, !tbaa !24
  br label %bb2
bb21:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l32 = alloca i1
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l68 = alloca %"compiler/source:Span"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Func", ptr %t2, i32 0, i32 0
  %t5 = load %"compiler/source:Span", ptr %t4
  %t8 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %t1, %"compiler/source:Span" %t5)
  store { i64, ptr } %t8, ptr %l10
  br label %bb1
bb1:
  %t9 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load ptr, ptr %l1, !tbaa !29
  %t13 = getelementptr %"compiler/ast:Func", ptr %t11, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t10, i32 %t14)
  store { i64, ptr } %t17, ptr %l14
  br label %bb2
bb2:
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t18, ptr %l3, !tbaa !27
  store i64 2, ptr %l4, !tbaa !24
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Func", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  %t26 = xor i1 %t24, true
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr %"compiler/ast:Func", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb5, label %bb6
bb4:
  br label %bb8
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6fdba33c6e4026bf_8c9edfb8735784b)
  unreachable
bb6:
  br label %bb7
bb7:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Func", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Param", ptr %t38, i32 0, i32 0
  %t42 = getelementptr %"compiler/source:Span", ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42, !tbaa !23
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr %"compiler/ast:Func", ptr %t44, i32 0, i32 0
  %t47 = getelementptr %"compiler/source:Span", ptr %t46, i32 0, i32 0
  %t48 = load i32, ptr %t47, !tbaa !23
  %t51 = sub i32 %t43, %t48
  %t53 = sext i32 %t51 to i64
  store i64 %t53, ptr %l4, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l4, !tbaa !24
  %t57 = icmp slt i64 %t55, 0
  br i1 %t57, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb11
bb10:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t65 = icmp sgt i64 %t59, %t62
  store i1 %t65, ptr %l32, !tbaa !21
  br label %bb11
bb11:
  %t67 = load i1, ptr %l32, !tbaa !21
  br i1 %t67, label %bb12, label %bb13
bb12:
  store i64 0, ptr %l4, !tbaa !24
  br label %bb14
bb13:
  br label %bb14
bb14:
  %t68 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t68, ptr %l38, !tbaa !27
  %t69 = load i64, ptr %l4, !tbaa !24
  store i64 %t69, ptr %l39, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t70, 0
  store i64 %t73, ptr %l42, !tbaa !24
  %t74 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  store i64 %t75, ptr %l43, !tbaa !24
  %t76 = load i64, ptr %l39, !tbaa !24
  %t77 = icmp sge i64 %t76, 0
  br i1 %t77, label %bb15, label %bb16
bb15:
  %t79 = load i64, ptr %l39, !tbaa !24
  %t80 = load i64, ptr %l42, !tbaa !24
  %t81 = icmp sle i64 %t79, %t80
  br i1 %t81, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_e5967d965d67f828_b4c4cbb3885481d4)
  unreachable
bb17:
  %t83 = load i64, ptr %l42, !tbaa !24
  %t84 = load i64, ptr %l43, !tbaa !24
  %t85 = icmp sle i64 %t83, %t84
  br i1 %t85, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_e5967d965d67f828_b4c4cbb3885481d4)
  unreachable
bb19:
  %t87 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = load i64, ptr %l39, !tbaa !24
  %t90 = load i64, ptr %l42, !tbaa !24
  %t91 = getelementptr i8, ptr %t88, i64 %t89
  %t92 = sub i64 %t90, %t89
  %t93 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t98 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t94, { i64, ptr } %t95)
  %t99 = extractvalue { i32, i64 } %t98, 1
  %t100 = extractvalue { i32, i64 } %t98, 0
  store i32 %t100, ptr %l50
  %t101 = icmp ne i32 %t100, 0
  br i1 %t101, label %bb22, label %ok.102
ok.102:
  store i64 %t99, ptr %l49
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_e5967d965d67f828_b4c4cbb3885481d4)
  unreachable
bb21:
  %t103 = load i64, ptr %l49, !tbaa !24
  store i64 %t103, ptr %l37, !tbaa !24
  br label %bb24
bb22:
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  store i64 -1, ptr %l37, !tbaa !24
  br label %bb24
bb24:
  %t104 = load i64, ptr %l37, !tbaa !24
  store i64 %t104, ptr %l5, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t107 = icmp slt i64 %t105, 0
  br i1 %t107, label %bb25, label %bb26
bb25:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/ast:Func", ptr %t109, i32 0, i32 0
  %t112 = load %"compiler/source:Span", ptr %t111
  call void @__olang_scope_close(ptr %s0)
  store %"compiler/source:Span" %t112, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/ast:Func", ptr %t114, i32 0, i32 0
  %t117 = getelementptr %"compiler/source:Span", ptr %t116, i32 0, i32 0
  %t118 = load i32, ptr %t117, !tbaa !23
  %t119 = load i64, ptr %l4, !tbaa !24
  %t120 = load i64, ptr %l5, !tbaa !24
  %t123 = add i64 %t119, %t120
  %t125 = trunc i64 %t123 to i32
  %t128 = add i32 %t118, %t125
  store i32 %t128, ptr %l6, !tbaa !23
  %t130 = load i32, ptr %l6, !tbaa !23
  %t131 = load i32, ptr %l6, !tbaa !23
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t136 = trunc i64 %t134 to i32
  %t139 = add i32 %t131, %t136
  %t142 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t130, i32 %t139)
  store %"compiler/source:Span" %t142, ptr %l68
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load %"compiler/source:Span", ptr %l68
  store %"compiler/source:Span" %t143, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowCall(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i64
  %l15 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/msgs:Msg"
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca %"compiler/source:Span"
  %l30 = alloca %"compiler/msgs:Msg"
  %l31 = alloca i64
  %l36 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca i32
  %l52 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca i1
  %l63 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l66 = alloca %"compiler/source:Span"
  %l69 = alloca { i64, ptr }
  %l71 = alloca %"compiler/msgs:Msg"
  %l72 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l89 = alloca i32
  %l92 = alloca i64
  %l96 = alloca %"compiler/source:Span"
  %l97 = alloca i32
  %l98 = alloca i32
  %l99 = alloca i32
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t187 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp ne i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t11 = icmp ne i64 %t9, 0
  store i1 %t11, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l15, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t18 = icmp ne i64 %t16, 1
  br i1 %t18, label %bb6, label %bb7
bb5:
  br label %bb15
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l22, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t21, ptr %l23
  %t22 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %s2, ptr %s2, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d21, i32 0, i32 1) }, i64 1, i64 %t24)
  store %"compiler/msgs:Msg" %t26, ptr %l26
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l28, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t28, ptr %l29
  %t29 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %s3, ptr %s3, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t29, ptr %l30
  br label %bb10
bb8:
  %t30 = load ptr, ptr %l22, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l23
  %t32 = load %"compiler/msgs:Msg", ptr %l26
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t30, %"compiler/source:Span" %t31, %"compiler/msgs:Msg" %t32)
  store i64 %t33, ptr %l27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb10:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load %"compiler/source:Span", ptr %l29
  %t36 = load %"compiler/msgs:Msg", ptr %l30
  %t37 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t34, %"compiler/source:Span" %t35, %"compiler/msgs:Msg" %t36)
  store i64 %t37, ptr %l31
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v2, ptr %t38, { i64, ptr } %t39)
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load %"compiler/source:Span", ptr %l1
  %t46 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t42, %"compiler/source:Span" %t43)
  store ptr %t46, ptr %l36
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t47 = load ptr, ptr %l36, !tbaa !29
  store ptr %t47, ptr %rv
  br label %ret
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t49, ptr %l38, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr ptr, ptr %t51, i64 0
  %t53 = load ptr, ptr %t52, !tbaa !39
  %t57 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t48, ptr %t53)
  store i32 %t57, ptr %l41
  br label %bb16
bb16:
  %t58 = load i32, ptr %l41, !tbaa !23
  store i32 %t58, ptr %l6, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = load %"compiler/source:Span", ptr %l1
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t59, ptr %a3, %"compiler/source:Span" %t61)
  store ptr %t65, ptr %l45
  br label %bb17
bb17:
  %t66 = load ptr, ptr %l45, !tbaa !29
  store ptr %t66, ptr %l7, !tbaa !29
  %t67 = load ptr, ptr %l7, !tbaa !29
  %t70 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t67)
  store i32 %t70, ptr %l48
  br label %bb18
bb18:
  %t71 = load i32, ptr %l48, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  %t72 = load i32, ptr %l6, !tbaa !23
  %t73 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t76 = icmp eq i32 %t72, %t73
  br i1 %t76, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb21
bb20:
  %t78 = load i32, ptr %l8, !tbaa !23
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t82 = icmp eq i32 %t78, %t79
  store i1 %t82, ptr %l52, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l52, !tbaa !21
  br i1 %t84, label %bb22, label %bb23
bb22:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load %"compiler/source:Span", ptr %l1
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t85, %"compiler/source:Span" %t86)
  store ptr %t89, ptr %l58
  br label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t90 = load ptr, ptr %l58, !tbaa !29
  store ptr %t90, ptr %rv
  br label %ret
bb25:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l6, !tbaa !23
  %t95 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t91, i32 %t92)
  store i1 %t95, ptr %l61
  br label %bb26
bb26:
  %t96 = load i1, ptr %l61, !tbaa !21
  %t97 = xor i1 %t96, true
  br i1 %t97, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t99 = load ptr, ptr %l0, !tbaa !29
  store ptr %t99, ptr %l63, !tbaa !29
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l64, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr ptr, ptr %t102, i64 0
  %t104 = load ptr, ptr %t103, !tbaa !39
  %t106 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t104)
  store %"compiler/source:Span" %t106, ptr %l66
  br label %bb29
bb28:
  br label %bb34
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l6, !tbaa !23
  %t111 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t107, i32 %t108)
  store { i64, ptr } %t111, ptr %l69
  br label %bb30
bb30:
  %t112 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t120 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowNotNumber(ptr %s5, ptr %s5, { i64, ptr } %t118)
  store %"compiler/msgs:Msg" %t120, ptr %l71
  br label %bb31
bb31:
  %t121 = load ptr, ptr %l63, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l66
  %t123 = load %"compiler/msgs:Msg", ptr %l71
  %t124 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t121, %"compiler/source:Span" %t122, %"compiler/msgs:Msg" %t123)
  store i64 %t124, ptr %l72
  br label %bb32
bb32:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load %"compiler/source:Span", ptr %l1
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t125, %"compiler/source:Span" %t126)
  store ptr %t129, ptr %l75
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load ptr, ptr %l75, !tbaa !29
  store ptr %t130, ptr %rv
  br label %ret
bb34:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t132 = load i32, ptr %l8, !tbaa !23
  %t133 = load i32, ptr %l6, !tbaa !23
  %t137 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %s0, ptr %t131, i32 %t132, i32 %t133)
  store { i64, ptr } %t137, ptr %l79
  br label %bb35
bb35:
  %t138 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t138, ptr %l9, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t143 = icmp eq i64 %t141, 0
  br i1 %t143, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %s6, ptr %s6, ptr %s6, ptr %t145, { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d23, i32 0, i32 1) }, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i32 %t147, ptr %l84
  br label %bb38
bb37:
  br label %bb39
bb38:
  %t148 = mul i64 1, 4
  %t149 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 1, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t152 = load i32, ptr %l84, !tbaa !23
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 0
  store i32 %t152, ptr %t155, !tbaa !33
  %t156 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t156, ptr %l9, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t159 = load %"compiler/source:Span", ptr %l2
  %t163 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %s0, ptr %t157, { i64, ptr } %t158, %"compiler/source:Span" %t159, i1 false)
  store i32 %t163, ptr %l89
  br label %bb40
bb40:
  %t164 = load i32, ptr %l89
  store i32 %t164, ptr %l10
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 32
  %t169 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t167)
  store i64 %t169, ptr %l92
  br label %bb41
bb41:
  %t170 = load i64, ptr %l92, !tbaa !24
  store i64 %t170, ptr %l11, !tbaa !24
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 32
  %t174 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t173, ptr %t174)
  br label %bb42
bb42:
  %t177 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t177, ptr %l96
  %t178 = load i32, ptr %l6, !tbaa !23
  store i32 %t178, ptr %l97, !tbaa !23
  store i32 20, ptr %l98
  %t179 = load i32, ptr %l10
  store i32 %t179, ptr %l99
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 32
  %t183 = load i64, ptr %l11, !tbaa !24
  %t186 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t182, i64 %t183)
  store { i64, ptr } %t186, ptr %l103
  br label %bb43
bb43:
  store { i64, [5 x i64] } zeroinitializer, ptr %t187
  %t188 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 0
  store i64 9, ptr %t188
  %t189 = load %"compiler/source:Span", ptr %l96
  %t190 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } undef, %"compiler/source:Span" %t189, 0
  %t191 = load i32, ptr %l97, !tbaa !23
  %t192 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t190, i32 %t191, 1
  %t193 = load i32, ptr %l98
  %t194 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t192, i32 %t193, 2
  %t195 = load i32, ptr %l99
  %t196 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t194, i32 %t195, 3
  %t197 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t198 = insertvalue { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t196, { i64, ptr } %t197, 4
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32, i32, { i64, ptr } } %t198, ptr %t199
  %t200 = load { i64, [5 x i64] }, ptr %t187
  %t202 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t200, ptr %t202
  call void @__olang_scope_close(ptr %s0)
  store ptr %t202, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedBranch(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, i64 %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca { i64, i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l15 = alloca i1
  %l20 = alloca i1
  %l22 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l28 = alloca %"compiler/typed:Local"
  %l29 = alloca i32
  %l33 = alloca i1
  %l37 = alloca i1
  %l42 = alloca ptr
  %l54 = alloca i64
  %l59 = alloca { i64, i64, i64 }
  %l91 = alloca ptr
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t38 = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t7 = getelementptr %"compiler/ast:Branch", ptr %t5, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t12 = icmp sgt i64 %t10, 0
  store i1 %t12, ptr %l15, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb3
bb3:
  %t14 = load i1, ptr %l15, !tbaa !21
  br i1 %t14, label %bb4, label %bb5
bb4:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/ast:Branch", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  store { i64, ptr } %t18, ptr %l22, !tbaa !27
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l24
  br label %bb6
bb5:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb6:
  %t22 = load ptr, ptr %l24, !tbaa !29
  %t24 = getelementptr %"compiler/typed:Body", ptr %t22, i32 0, i32 7
  %t25 = load i64, ptr %l2, !tbaa !24
  %t28 = call %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t24, i64 %t25)
  store %"compiler/typed:Local" %t28, ptr %l28
  br label %bb7
bb7:
  %t29 = getelementptr %"compiler/typed:Local", ptr %l28, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  store i32 %t30, ptr %l29, !tbaa !23
  %t31 = icmp sge i64 1, 0
  br i1 %t31, label %bb8, label %bb9
bb8:
  %t33 = icmp sle i64 1, 2305843009213693951
  br i1 %t33, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_baa1666d9ed0001e_5936281468ac2d52)
  unreachable
bb10:
  %t35 = mul i64 1, 4
  %t36 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t35)
  %t37 = load i32, ptr %l29, !tbaa !23
  store i64 0, ptr %t38
  br label %fill.39
fill.39:
  %t42 = load i64, ptr %t38
  %t43 = icmp slt i64 %t42, 1
  br i1 %t43, label %fillb.40, label %filld.41
fillb.40:
  %t44 = getelementptr i32, ptr %t36, i64 %t42
  store i32 %t37, ptr %t44
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %t38
  br label %fill.39
filld.41:
  %t46 = insertvalue { i64, ptr } undef, i64 1, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t36, 1
  %t48 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t50 = call i1 @compiler_2fcheck_2eassignsName(ptr %v1, ptr %s0, { i64, ptr } %t48, { i64, ptr } %t47)
  store i1 %t50, ptr %l33
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_baa1666d9ed0001e_5936281468ac2d52)
  unreachable
bb12:
  %t51 = load i1, ptr %l33, !tbaa !21
  %t52 = xor i1 %t51, true
  store i1 %t52, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t54 = load i1, ptr %l20, !tbaa !21
  store i1 %t54, ptr %l6, !tbaa !21
  %t55 = load i1, ptr %l6, !tbaa !21
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  %t59 = load ptr, ptr %l4, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  store i1 %t61, ptr %l37, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t63 = load i1, ptr %l37, !tbaa !21
  br i1 %t63, label %bb17, label %bb18
bb17:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %t64, ptr %t65)
  store ptr %t68, ptr %l42
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t69 = load ptr, ptr %l42, !tbaa !29
  store ptr %t69, ptr %rv
  br label %ret
bb20:
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr %"compiler/ast:Branch", ptr %t70, i32 0, i32 2
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp sge i64 %t73, 0
  br i1 %t75, label %bb21, label %bb22
bb21:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/generic:Program", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 4
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr %"compiler/ast:Branch", ptr %t87, i32 0, i32 2
  %t90 = load i64, ptr %t89, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %t86, i64 %t90)
  br label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb24
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 33
  %t97 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l54
  br label %bb25
bb25:
  %t98 = load i64, ptr %l54, !tbaa !24
  store i64 %t98, ptr %l7, !tbaa !24
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/ast:Branch", ptr %t100, i32 0, i32 0
  %t103 = load %"compiler/source:Span", ptr %t102
  %t107 = call { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %t99, i32 1, %"compiler/source:Span" %t103)
  store { i64, i64, i64 } %t107, ptr %l59
  br label %bb26
bb26:
  %t108 = load { i64, i64, i64 }, ptr %l59
  store { i64, i64, i64 } %t108, ptr %l8
  %t109 = getelementptr { i64, i64, i64 }, ptr %l8, i32 0, i32 0
  %t110 = load i64, ptr %t109, !tbaa !24
  store i64 %t110, ptr %l9, !tbaa !24
  %t112 = getelementptr { i64, i64, i64 }, ptr %l8, i32 0, i32 1
  %t113 = load i64, ptr %t112, !tbaa !24
  store i64 %t113, ptr %l10, !tbaa !24
  %t115 = getelementptr { i64, i64, i64 }, ptr %l8, i32 0, i32 2
  %t116 = load i64, ptr %t115, !tbaa !24
  store i64 %t116, ptr %l11, !tbaa !24
  %t118 = load i1, ptr %l6, !tbaa !21
  br i1 %t118, label %bb27, label %bb28
bb27:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l1, !tbaa !29
  %t123 = getelementptr %"compiler/ast:Branch", ptr %t121, i32 0, i32 0
  %t124 = load %"compiler/source:Span", ptr %t123
  %t125 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %t120, %"compiler/source:Span" %t124, i64 %t125, i64 %a3)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t131 = load ptr, ptr %l4, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb31, label %bb32
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t139 = load i1, ptr %l5, !tbaa !21
  %t140 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v2, ptr %t137, ptr %t138, i1 %t139, i64 %t140)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t147 = icmp eq ptr %t145, null
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb35, label %bb36
bb35:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t153 = load i1, ptr %l5, !tbaa !21
  %t154 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v2, ptr %t151, ptr %t152, i1 %t153, i64 %t154)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Branch", ptr %t160, i32 0, i32 1
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %t159, { i64, ptr } %t163)
  br label %bb39
bb39:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l9, !tbaa !24
  %t168 = load i64, ptr %l10, !tbaa !24
  %t169 = load i64, ptr %l11, !tbaa !24
  %t170 = load i64, ptr %l7, !tbaa !24
  %t176 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %t166, i64 %t167, i64 %t168, i64 %t169, i64 %t170)
  store ptr %t176, ptr %l91
  br label %bb40
bb40:
  %t177 = load ptr, ptr %l91, !tbaa !29
  store ptr %t177, ptr %l12, !tbaa !29
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t180 = getelementptr %"compiler/ast:Branch", ptr %t178, i32 0, i32 2
  %t181 = load i64, ptr %t180, !tbaa !24
  %t183 = icmp sge i64 %t181, 0
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = load ptr, ptr %l0, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t185, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 0
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t193 = getelementptr %"compiler/load:Loader", ptr %t191, i32 0, i32 4
  %t194 = load ptr, ptr %t193, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t194)
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t196 = load ptr, ptr %l12, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t196, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRo(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/typed:Local"
  %l5 = alloca i32
  %l6 = alloca { i64, [3 x i64] }
  %l9 = alloca i64
  %l13 = alloca ptr
  %l17 = alloca %"compiler/typed:Local"
  %l20 = alloca i32
  %l22 = alloca ptr
  %l25 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l26 = alloca i32
  %l27 = alloca i32
  %l30 = alloca { i64, [3 x i64] }
  %l33 = alloca i1
  %l35 = alloca ptr
  %l38 = alloca i32
  %l43 = alloca i32
  %l44 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca { i64, [3 x i64] }
  %l54 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca { i64, [3 x i64] }
  %l73 = alloca { i64, ptr }
  %l74 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %t1, ptr %a2)
  store i64 %t5, ptr %l9
  br label %bb1
bb1:
  %t6 = load i64, ptr %l9, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %t11)
  store ptr %t13, ptr %l13
  br label %bb5
bb5:
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = trunc i64 %t14 to i32
  %t18 = load ptr, ptr %l13, !tbaa !29
  %t20 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t18, i32 %t16)
  store %"compiler/typed:Local" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load %"compiler/typed:Local", ptr %l17
  store %"compiler/typed:Local" %t21, ptr %l4
  %t22 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  %t25 = icmp eq i32 %t23, 0
  br i1 %t25, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 57
  store ptr %t29, ptr %l22, !tbaa !29
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %t30, i64 %t31)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t34, ptr %l25
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l25
  %t37 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59daade663458096c0c7696954afd54(ptr %v0, ptr %t35, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t36)
  %t38 = extractvalue { i32, i32 } %t37, 1
  %t39 = extractvalue { i32, i32 } %t37, 0
  store i32 %t39, ptr %l27
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb12, label %ok.41
ok.41:
  store i32 %t38, ptr %l26
  br label %bb11
bb11:
  %t42 = load i32, ptr %l26, !tbaa !23
  store i32 %t42, ptr %l20, !tbaa !23
  br label %bb14
bb12:
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store i32 0, ptr %l20, !tbaa !23
  br label %bb14
bb14:
  %t43 = load i32, ptr %l20, !tbaa !23
  store i32 %t43, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 1
  %t46 = load %"compiler/source:Span", ptr %t45
  %t49 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %t44, %"compiler/source:Span" %t46)
  store { i64, [3 x i64] } %t49, ptr %l30
  br label %bb15
bb15:
  %t50 = load { i64, [3 x i64] }, ptr %l30
  store { i64, [3 x i64] } %t50, ptr %l6
  %t51 = load i32, ptr %l5, !tbaa !23
  %t53 = icmp ne i32 %t51, 0
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !29
  store ptr %t58, ptr %l35, !tbaa !29
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 2
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t59, i32 %t61)
  store i32 %t64, ptr %l38
  br label %bb18
bb17:
  store i1 false, ptr %l33, !tbaa !21
  br label %bb21
bb18:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !29
  %t70 = getelementptr %"compiler/generic:Program", ptr %t68, i32 0, i32 0
  %t71 = load ptr, ptr %t70, !tbaa !29
  %t73 = getelementptr %"compiler/load:Loader", ptr %t71, i32 0, i32 3
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t76 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t74, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i32 %t76, ptr %l43
  br label %bb19
bb19:
  %t77 = load ptr, ptr %l35, !tbaa !29
  %t78 = load i32, ptr %l38, !tbaa !23
  %t79 = load i32, ptr %l43, !tbaa !23
  %t80 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t77, i32 %t78, i32 %t79)
  store i64 %t80, ptr %l44
  br label %bb20
bb20:
  %t81 = load i64, ptr %l44, !tbaa !24
  %t82 = icmp sge i64 %t81, 0
  store i1 %t82, ptr %l33, !tbaa !21
  br label %bb21
bb21:
  %t84 = load i1, ptr %l33, !tbaa !21
  br i1 %t84, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 0
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = getelementptr %"compiler/load:Loader", ptr %t91, i32 0, i32 4
  %t94 = load ptr, ptr %t93, !tbaa !29
  store ptr %t94, ptr %l49, !tbaa !29
  %t95 = load i64, ptr %l1, !tbaa !24
  store i64 %t95, ptr %l50, !tbaa !24
  %t96 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t96, ptr %l51
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  %t102 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t97, i32 %t99)
  store { i64, ptr } %t102, ptr %l54
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 0
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/load:Loader", ptr %t109, i32 0, i32 4
  %t112 = load ptr, ptr %t111, !tbaa !29
  store ptr %t112, ptr %l68, !tbaa !29
  %t113 = load i64, ptr %l1, !tbaa !24
  store i64 %t113, ptr %l69, !tbaa !24
  %t114 = load { i64, [3 x i64] }, ptr %l6
  store { i64, [3 x i64] } %t114, ptr %l70
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t117 = load i32, ptr %t116, !tbaa !23
  %t120 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t115, i32 %t117)
  store { i64, ptr } %t120, ptr %l73
  br label %bb30
bb24:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load i32, ptr %l5, !tbaa !23
  %t125 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t121, i32 %t122)
  store { i64, ptr } %t125, ptr %l57
  br label %bb25
bb25:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/typed:Local", ptr %l4, i32 0, i32 0
  %t128 = load i32, ptr %t127, !tbaa !23
  %t131 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t126, i32 %t128)
  store { i64, ptr } %t131, ptr %l60
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l5, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t132, i32 %t133)
  store { i64, ptr } %t136, ptr %l63
  br label %bb27
bb27:
  %t137 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t140 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t141 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %s3, { i64, ptr } %t137, { i64, ptr } %t138, { i64, ptr } %t139, { i64, ptr } %t140)
  store %"compiler/msgs:Msg" %t141, ptr %l64
  br label %bb28
bb28:
  %t142 = load ptr, ptr %l49, !tbaa !29
  %t143 = load i64, ptr %l50, !tbaa !24
  %t144 = load { i64, [3 x i64] }, ptr %l51
  %t145 = load %"compiler/msgs:Msg", ptr %l64
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s3, ptr %t142, i64 %t143, { i64, [3 x i64] } %t144, %"compiler/msgs:Msg" %t145)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb33
bb30:
  %t146 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t147 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %s4, { i64, ptr } %t146)
  store %"compiler/msgs:Msg" %t147, ptr %l74
  br label %bb31
bb31:
  %t148 = load ptr, ptr %l68, !tbaa !29
  %t149 = load i64, ptr %l69, !tbaa !24
  %t150 = load { i64, [3 x i64] }, ptr %l70
  %t151 = load %"compiler/msgs:Msg", ptr %l74
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %s4, ptr %t148, i64 %t149, { i64, [3 x i64] } %t150, %"compiler/msgs:Msg" %t151)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s4)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteWrite(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l17 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb9
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 89
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t19)
  store ptr %t21, ptr %l12
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l12, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i32, ptr %l2, !tbaa !23
  %t28 = sext i32 %t26 to i64
  %t31 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s1, i64 %t25, i64 %t28)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, ptr %l17
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l10, !tbaa !29
  %t33 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l17
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t32, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t33, i1 true)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb9:
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca i8
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t3 = load ptr, ptr %t2, !tbaa !27
  %t4 = getelementptr i8, ptr %t3, i64 0
  %t5 = load i8, ptr %t4, !tbaa !32
  %t7 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t5)
  store i8 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t9, 0
  store i64 %t12, ptr %l8, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = icmp sge i64 1, 0
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t17 = load i64, ptr %l8, !tbaa !24
  %t18 = icmp sle i64 1, %t17
  br i1 %t18, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @olang_loc_8ba315a61b976e68_980c0dda48bb0a1c)
  unreachable
bb4:
  %t20 = load i64, ptr %l8, !tbaa !24
  %t21 = load i64, ptr %l9, !tbaa !24
  %t22 = icmp sle i64 %t20, %t21
  br i1 %t22, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_8ba315a61b976e68_980c0dda48bb0a1c)
  unreachable
bb6:
  %t24 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l8, !tbaa !24
  %t27 = getelementptr i8, ptr %t25, i64 1
  %t28 = sub i64 %t26, 1
  %t29 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t27, 1
  %t31 = load i8, ptr %l4, !tbaa !22
  %t33 = extractvalue { i64, ptr } %t30, 1
  %t34 = extractvalue { i64, ptr } %t30, 0
  %t35 = add i64 1, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t35)
  store i8 %t31, ptr %t36
  %t37 = getelementptr i8, ptr %t36, i64 1
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  store { i64, ptr } %t39, ptr %rv
  br label %ret
bb7:
  call void @__olang_check_failed(ptr @olang_loc_8ba315a61b976e68_980c0dda48bb0a1c)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderGlobals(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca i64
  %l31 = alloca i64
  %l34 = alloca i64
  %l57 = alloca ptr
  %l77 = alloca i64
  %l81 = alloca i64
  %l84 = alloca i64
  %l112 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i32
  %l125 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %s0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l21
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l1
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l22
  br label %bb2
bb2:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = getelementptr %"compiler/generic:Program", ptr %t8, i32 0, i32 0
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = getelementptr %"compiler/load:Loader", ptr %t11, i32 0, i32 5
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l27
  br label %bb3
bb3:
  %t16 = load i64, ptr %l27, !tbaa !24
  store i64 %t16, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t17 = load i64, ptr %l4, !tbaa !24
  %t18 = load i64, ptr %l3, !tbaa !24
  %t21 = icmp sgt i64 %t17, %t18
  br i1 %t21, label %bb4, label %bb5
bb4:
  %t23 = load i64, ptr %l5, !tbaa !24
  %t25 = icmp sgt i64 %t23, 0
  br i1 %t25, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb9
bb6:
  %t27 = load i64, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t27, %t28
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = add i64 %t31, %t32
  %t37 = sub i64 %t35, 1
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = sdiv i64 %t37, %t38
  store i64 %t41, ptr %l34, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l34, !tbaa !24
  store i64 %t43, ptr %l31, !tbaa !24
  br label %bb9
bb9:
  %t44 = load i64, ptr %l31, !tbaa !24
  store i64 %t44, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t53 = load i64, ptr %l3, !tbaa !24
  %t54 = load i64, ptr %l7, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  %t58 = mul i64 %t54, %t55
  %t61 = add i64 %t53, %t58
  store i64 %t61, ptr %l8, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 0
  %t69 = load ptr, ptr %t68, !tbaa !29
  %t71 = getelementptr %"compiler/load:Loader", ptr %t69, i32 0, i32 5
  %t72 = load i64, ptr %l8, !tbaa !24
  %t75 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v0, ptr %t71, i64 %t72)
  store ptr %t75, ptr %l57
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l57, !tbaa !29
  %t78 = getelementptr %"compiler/load:Module", ptr %t76, i32 0, i32 3
  %t79 = load i1, ptr %t78, !tbaa !21
  br i1 %t79, label %bb15, label %bb16
bb15:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t81, i64 %t82, ptr %l1, ptr %l2)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  %t87 = load i64, ptr %l7, !tbaa !24
  %t89 = add i64 %t87, 1
  store i64 %t89, ptr %l7, !tbaa !24
  br label %bb10
bb20:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 0
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = getelementptr %"compiler/load:Loader", ptr %t98, i32 0, i32 7
  %t101 = load i64, ptr %t100, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t91, i64 %t101, ptr %l1, ptr %l2)
  br label %bb21
bb21:
  store i64 0, ptr %l9, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/check:Checker", ptr %t106, i32 0, i32 1
  %t109 = load ptr, ptr %t108, !tbaa !29
  %t111 = getelementptr %"compiler/generic:Program", ptr %t109, i32 0, i32 0
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/load:Loader", ptr %t112, i32 0, i32 5
  %t116 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %t114)
  store i64 %t116, ptr %l77
  br label %bb22
bb22:
  %t117 = load i64, ptr %l77, !tbaa !24
  store i64 %t117, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb23, label %bb24
bb23:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l81, !tbaa !24
  br label %bb28
bb25:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l84, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l84, !tbaa !24
  br label %bb27
bb27:
  %t144 = load i64, ptr %l84, !tbaa !24
  store i64 %t144, ptr %l81, !tbaa !24
  br label %bb28
bb28:
  %t145 = load i64, ptr %l81, !tbaa !24
  store i64 %t145, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s6
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  %t164 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %s0, ptr %s0, ptr %t164, i64 %t162, ptr %l1, ptr %l2)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  %t170 = load i64, ptr %l13, !tbaa !24
  %t172 = add i64 %t170, 1
  store i64 %t172, ptr %l13, !tbaa !24
  br label %bb29
bb35:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t174, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t179 = getelementptr %"compiler/generic:Program", ptr %t177, i32 0, i32 41
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t179)
  br label %bb36
bb36:
  store ptr %l2, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s9
  %t182 = load ptr, ptr %l15, !tbaa !29
  %t183 = load i64, ptr %l16, !tbaa !24
  %t186 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t182, i64 %t183)
  %t187 = extractvalue { i32, { i64, ptr } } %t186, 1
  %t188 = extractvalue { i32, { i64, ptr } } %t186, 0
  store i32 %t188, ptr %l116
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb39, label %ok.190
ok.190:
  store { i64, ptr } %t187, ptr %l115
  br label %bb38
bb38:
  %t191 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t191, ptr %l112, !tbaa !27
  br label %bb43
bb39:
  %t192 = load i32, ptr %l116, !tbaa !23
  %t193 = ashr i32 %t192, 16
  %t195 = icmp eq i32 %t193, 1
  br i1 %t195, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_4f5c9f07eee78c9b_27fcb87a83eb07cf)
  unreachable
bb42:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb43:
  %t197 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t197, ptr %l17, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  store i64 %t200, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s10
  %t202 = load i64, ptr %l19, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb45, label %bb46
bb45:
  call void @__olang_scope_close(ptr %s10)
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t210 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t210, ptr %l125, !tbaa !27
  %t211 = load i64, ptr %l19, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr i64, ptr %t214, i64 %t211
  %t216 = load i64, ptr %t215, !tbaa !34
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Program", ptr %t223, i32 0, i32 41
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v0, ptr %t218, i64 %t216, ptr %t225)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s10)
  br label %bb49
bb49:
  %t229 = load i64, ptr %l19, !tbaa !24
  %t231 = add i64 %t229, 1
  store i64 %t231, ptr %l19, !tbaa !24
  br label %bb44
bb50:
  %t233 = load i64, ptr %l16, !tbaa !24
  %t234 = load i64, ptr %l18, !tbaa !24
  %t237 = add i64 %t233, %t234
  store i64 %t237, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  br label %bb37
bb52:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatWild(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb9
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t11 = load ptr, ptr %l6, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = load i64, ptr %t14
  %t17 = icmp eq i64 %t15, 3
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %rv
  br label %ret
bb10:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i1
  %l26 = alloca i1
  %l30 = alloca i1
  %l34 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l41 = alloca i1
  %l43 = alloca i1
  %l46 = alloca ptr
  %l48 = alloca ptr
  %l52 = alloca %"compiler/names:Ref"
  %l55 = alloca i1
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i1
  %l63 = alloca { i64, ptr }
  %l65 = alloca i1
  %l68 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t6 = load ptr, ptr %l15, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l15, !tbaa !29
  %t10 = load i64, ptr %t9
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l16, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l4
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [5 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [5 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t28, i32 0, i32 2
  %t30 = load { i64, ptr }, ptr %t29
  store { i64, ptr } %t30, ptr %l6, !tbaa !27
  br label %bb8
bb7:
  br label %bb48
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load i1, ptr %l3, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t34, 0
  %t38 = icmp eq i64 %t36, 1
  store i1 %t38, ptr %l26, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l26, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  store i1 %t45, ptr %l30, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t47 = load i1, ptr %l30, !tbaa !21
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t48)
  store ptr %t50, ptr %l36
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb17:
  %t51 = load ptr, ptr %l36, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 4
  %t54 = getelementptr %"compiler/generic:Context", ptr %t53, i32 0, i32 2
  %t55 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t55, ptr %l39, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  %t62 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t54, i32 %t59)
  store i1 %t62, ptr %l41
  br label %bb18
bb18:
  %t63 = load i1, ptr %l41, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !29
  store ptr %t73, ptr %l46, !tbaa !29
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t74)
  store ptr %t76, ptr %l48
  br label %bb22
bb21:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb24
bb22:
  %t77 = load ptr, ptr %l48, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 2
  %t80 = load i64, ptr %t79, !tbaa !24
  %t81 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t82 = load i32, ptr %t81, !tbaa !23
  %t83 = load ptr, ptr %l46, !tbaa !29
  %t86 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t83, i64 %t80, i32 %t82)
  store %"compiler/names:Ref" %t86, ptr %l52
  br label %bb23
bb23:
  %t87 = getelementptr %"compiler/names:Ref", ptr %l52, i32 0, i32 0
  %t88 = load i32, ptr %t87
  %t90 = trunc i64 0 to i32
  %t91 = icmp eq i32 %t88, %t90
  store i1 %t91, ptr %l43, !tbaa !21
  br label %bb24
bb24:
  %t93 = load i1, ptr %l43, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t95, ptr %l57, !tbaa !27
  %t96 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 0
  %t99 = load i32, ptr %t98, !tbaa !33
  %t102 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t94, i32 %t99)
  store { i64, ptr } %t102, ptr %l59
  br label %bb27
bb26:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb29
bb27:
  %t103 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t104 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t103, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t104, ptr %l60
  br label %bb28
bb28:
  %t105 = load i1, ptr %l60, !tbaa !21
  %t106 = xor i1 %t105, true
  store i1 %t106, ptr %l55, !tbaa !21
  br label %bb29
bb29:
  %t108 = load i1, ptr %l55, !tbaa !21
  br i1 %t108, label %bb30, label %bb31
bb30:
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t110, ptr %l63, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr i32, ptr %t112, i64 0
  %t114 = load i32, ptr %t113, !tbaa !33
  %t117 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v2, ptr %t109, i32 %t114)
  store i1 %t117, ptr %l65
  br label %bb32
bb31:
  br label %bb37
bb32:
  %t118 = load i1, ptr %l65, !tbaa !21
  %t119 = xor i1 %t118, true
  br i1 %t119, label %bb33, label %bb34
bb33:
  %t121 = load ptr, ptr %l2, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t122, ptr %l68, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr i32, ptr %t124, i64 0
  %t126 = load i32, ptr %t125, !tbaa !33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v2, ptr %t121, i32 %t126)
  br label %bb35
bb34:
  br label %bb36
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb37:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 0
  %t133 = icmp sgt i64 %t131, 0
  br i1 %t133, label %bb38, label %bb39
bb38:
  %t135 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t135, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t137, 0
  store i64 %t139, ptr %l9, !tbaa !24
  br label %bb40
bb39:
  br label %bb47
bb40:
  store %olang.scope zeroinitializer, ptr %s7
  %t141 = load i64, ptr %l8, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  %t145 = icmp slt i64 %t141, %t142
  %t147 = xor i1 %t145, true
  br i1 %t147, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb42:
  br label %bb43
bb43:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l80, !tbaa !27
  %t150 = load i64, ptr %l8, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr ptr, ptr %t153, i64 %t150
  %t155 = load ptr, ptr %t154, !tbaa !39
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t160 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %t157, ptr %t155, ptr %t160, i1 true)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb45:
  %t164 = load i64, ptr %l8, !tbaa !24
  %t166 = add i64 %t164, 1
  store i64 %t166, ptr %l8, !tbaa !24
  br label %bb40
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb48:
  %t168 = load ptr, ptr %l1, !tbaa !29
  store ptr %t168, ptr %l89, !tbaa !29
  store i1 false, ptr %l90, !tbaa !21
  %t169 = load ptr, ptr %l89, !tbaa !29
  %t170 = icmp ne ptr %t169, null
  br i1 %t170, label %bb49, label %bb50
bb49:
  %t172 = load ptr, ptr %l89, !tbaa !29
  %t173 = load i64, ptr %t172
  %t175 = icmp eq i64 %t173, 3
  store i1 %t175, ptr %l90, !tbaa !21
  br label %bb50
bb50:
  %t176 = load i1, ptr %l90, !tbaa !21
  br i1 %t176, label %bb51, label %bb52
bb51:
  %t177 = load ptr, ptr %l1, !tbaa !29
  %t179 = getelementptr { i64, [5 x i64] }, ptr %t177, i32 0, i32 1
  %t180 = getelementptr { %"compiler/source:Span", ptr, i32, i1 }, ptr %t179, i32 0, i32 1
  %t181 = load ptr, ptr %t180
  store ptr %t181, ptr %l11, !tbaa !29
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load ptr, ptr %l11, !tbaa !29
  %t186 = load ptr, ptr %l2, !tbaa !29
  %t187 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %t183, ptr %t184, ptr %t186, i1 %t187)
  br label %bb54
bb54:
  br label %bb63
bb55:
  %t192 = load ptr, ptr %l1, !tbaa !29
  store ptr %t192, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t193 = load ptr, ptr %l100, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb56, label %bb57
bb56:
  %t196 = load ptr, ptr %l100, !tbaa !29
  %t197 = load i64, ptr %t196
  %t199 = icmp eq i64 %t197, 4
  store i1 %t199, ptr %l101, !tbaa !21
  br label %bb57
bb57:
  %t200 = load i1, ptr %l101, !tbaa !21
  br i1 %t200, label %bb58, label %bb59
bb58:
  %t201 = load ptr, ptr %l1, !tbaa !29
  %t203 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { %"compiler/source:Span", ptr, i1, i1 }, ptr %t203, i32 0, i32 1
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l12, !tbaa !29
  %t209 = load ptr, ptr %l2, !tbaa !29
  %t210 = load i1, ptr %l3, !tbaa !21
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %t207, ptr %t208, ptr %t209, i1 %t210)
  br label %bb61
bb61:
  br label %bb63
bb62:
  br label %bb63
bb63:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eraise(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, i32 }
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l15 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/msgs:Msg"
  %l21 = alloca i64
  %l23 = alloca ptr
  %l27 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca %"compiler/msgs:Msg"
  %l33 = alloca i64
  %l35 = alloca ptr
  %l39 = alloca ptr
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca ptr
  %l46 = alloca ptr
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"compiler/msgs:Msg"
  %l51 = alloca i64
  %l58 = alloca i1
  %l61 = alloca ptr
  %l63 = alloca ptr
  %l68 = alloca %"compiler/names:Ref"
  %l73 = alloca { i64, ptr }
  %l75 = alloca i64
  %l79 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l92 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca %"compiler/msgs:Msg"
  %l104 = alloca i64
  %l107 = alloca { i64, i32 }
  %l113 = alloca ptr
  %l115 = alloca ptr
  %l119 = alloca i1
  %l122 = alloca i32
  %l127 = alloca i64
  %l129 = alloca i32
  %l132 = alloca ptr
  %l136 = alloca i1
  %l146 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l160 = alloca i32
  %l169 = alloca ptr
  %l172 = alloca %"compiler/source:Span"
  %l175 = alloca { i64, ptr }
  %l177 = alloca %"compiler/msgs:Msg"
  %l178 = alloca i64
  %l183 = alloca i32
  %l186 = alloca ptr
  %l189 = alloca %"compiler/source:Span"
  %l192 = alloca { i64, ptr }
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %t410 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l15, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 29
  %t7 = load i1, ptr %t6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l18, !tbaa !29
  %t10 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t10, ptr %l19
  %t11 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %s1)
  store %"compiler/msgs:Msg" %t11, ptr %l20
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l18, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l19
  %t14 = load %"compiler/msgs:Msg", ptr %l20
  %t15 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t12, %"compiler/source:Span" %t13, %"compiler/msgs:Msg" %t14)
  store i64 %t15, ptr %l21
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t16)
  store ptr %t18, ptr %l23
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l23, !tbaa !29
  %t21 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 31
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp sge i64 %t22, 0
  br i1 %t24, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l27, !tbaa !29
  %t27 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t28 = load i32, ptr %t27, !tbaa !23
  %t29 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t30 = load i32, ptr %t29, !tbaa !23
  %t32 = add i32 %t30, 5
  %t35 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s2, i32 %t28, i32 %t32)
  store %"compiler/source:Span" %t35, ptr %l31
  br label %bb10
bb9:
  br label %bb13
bb10:
  %t36 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %s2)
  store %"compiler/msgs:Msg" %t36, ptr %l32
  br label %bb11
bb11:
  %t37 = load ptr, ptr %l27, !tbaa !29
  %t38 = load %"compiler/source:Span", ptr %l31
  %t39 = load %"compiler/msgs:Msg", ptr %l32
  %t40 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t37, %"compiler/source:Span" %t38, %"compiler/msgs:Msg" %t39)
  store i64 %t40, ptr %l33
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t41)
  store ptr %t43, ptr %l35
  br label %bb14
bb14:
  %t44 = load ptr, ptr %l35, !tbaa !29
  %t46 = getelementptr %"compiler/check:frame", ptr %t44, i32 0, i32 32
  %t47 = load i64, ptr %t46, !tbaa !24
  %t49 = icmp sge i64 %t47, 0
  br i1 %t49, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l39, !tbaa !29
  %t52 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t54 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = add i32 %t55, 5
  %t60 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s3, i32 %t53, i32 %t57)
  store %"compiler/source:Span" %t60, ptr %l43
  br label %bb17
bb16:
  br label %bb22
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  store ptr %t61, ptr %l44, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t62)
  store ptr %t64, ptr %l46
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l46, !tbaa !29
  %t67 = getelementptr %"compiler/check:frame", ptr %t65, i32 0, i32 33
  %t68 = load i1, ptr %t67, !tbaa !21
  %t69 = load ptr, ptr %l44, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %s3, ptr %t69, i1 %t68)
  store { i64, ptr } %t71, ptr %l49
  br label %bb19
bb19:
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t73 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %s3, ptr %s3, { i64, ptr } %t72)
  store %"compiler/msgs:Msg" %t73, ptr %l50
  br label %bb20
bb20:
  %t74 = load ptr, ptr %l39, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l43
  %t76 = load %"compiler/msgs:Msg", ptr %l50
  %t77 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t74, %"compiler/source:Span" %t75, %"compiler/msgs:Msg" %t76)
  store i64 %t77, ptr %l51
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %ret
bb22:
  %t78 = load ptr, ptr %l2, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb23, label %bb24
bb23:
  br label %ret
bb24:
  br label %bb25
bb25:
  %t82 = load ptr, ptr %l2, !tbaa !29
  %t84 = getelementptr %"compiler/ast:Path", ptr %t82, i32 0, i32 1
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t89 = icmp eq i64 %t87, 1
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/check:Checker", ptr %t91, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !29
  %t96 = getelementptr %"compiler/generic:Program", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  store ptr %t97, ptr %l61, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t98)
  store ptr %t100, ptr %l63
  br label %bb28
bb27:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb30
bb28:
  %t101 = load ptr, ptr %l63, !tbaa !29
  %t103 = getelementptr %"compiler/check:frame", ptr %t101, i32 0, i32 2
  %t104 = load i64, ptr %t103, !tbaa !24
  %t105 = load ptr, ptr %l2, !tbaa !29
  %t107 = getelementptr %"compiler/ast:Path", ptr %t105, i32 0, i32 0
  %t108 = getelementptr %"compiler/source:Span", ptr %t107, i32 0, i32 0
  %t109 = load i32, ptr %t108, !tbaa !23
  %t110 = load ptr, ptr %l61, !tbaa !29
  %t113 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t110, i64 %t104, i32 %t109)
  store %"compiler/names:Ref" %t113, ptr %l68
  br label %bb29
bb29:
  %t114 = getelementptr %"compiler/names:Ref", ptr %l68, i32 0, i32 0
  %t115 = load i32, ptr %t114
  %t117 = trunc i64 1 to i32
  %t118 = icmp eq i32 %t115, %t117
  store i1 %t118, ptr %l58, !tbaa !21
  br label %bb30
bb30:
  %t120 = load i1, ptr %l58, !tbaa !21
  br i1 %t120, label %bb31, label %bb32
bb31:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t122 = load ptr, ptr %l2, !tbaa !29
  %t124 = getelementptr %"compiler/ast:Path", ptr %t122, i32 0, i32 1
  %t125 = load { i64, ptr }, ptr %t124, !tbaa !27
  store { i64, ptr } %t125, ptr %l73, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 0
  %t129 = load i32, ptr %t128, !tbaa !33
  %t132 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %t121, i32 %t129)
  store i64 %t132, ptr %l75
  br label %bb33
bb32:
  br label %bb47
bb33:
  %t133 = load i64, ptr %l75, !tbaa !24
  store i64 %t133, ptr %l3, !tbaa !24
  %t134 = load i64, ptr %l3, !tbaa !24
  %t136 = icmp sge i64 %t134, 0
  br i1 %t136, label %bb34, label %bb35
bb34:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t138)
  store ptr %t140, ptr %l79
  br label %bb36
bb35:
  br label %bb39
bb36:
  %t141 = load ptr, ptr %l79, !tbaa !29
  %t143 = getelementptr %"compiler/check:frame", ptr %t141, i32 0, i32 54
  %t144 = load i64, ptr %l3, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %t143, i64 %t144, i1 true)
  br label %bb37
bb37:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load %"compiler/source:Span", ptr %l1
  %t149 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereraise(ptr %v0, ptr %t147, %"compiler/source:Span" %t148, i64 %t149)
  br label %bb38
bb38:
  br label %ret
bb39:
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load ptr, ptr %l2, !tbaa !29
  %t156 = getelementptr %"compiler/ast:Path", ptr %t154, i32 0, i32 0
  %t157 = load %"compiler/source:Span", ptr %t156
  %t158 = load ptr, ptr %l2, !tbaa !29
  %t160 = getelementptr %"compiler/ast:Path", ptr %t158, i32 0, i32 1
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l90, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = getelementptr i32, ptr %t163, i64 0
  %t165 = load i32, ptr %t164, !tbaa !33
  %t169 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtMisused(ptr %v0, ptr %t153, %"compiler/source:Span" %t157, i32 %t165)
  store i1 %t169, ptr %l92
  br label %bb40
bb40:
  %t170 = load i1, ptr %l92, !tbaa !21
  %t171 = xor i1 %t170, true
  br i1 %t171, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  %t173 = load ptr, ptr %l0, !tbaa !29
  store ptr %t173, ptr %l94, !tbaa !29
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t176 = getelementptr %"compiler/ast:Path", ptr %t174, i32 0, i32 0
  %t177 = load %"compiler/source:Span", ptr %t176
  store %"compiler/source:Span" %t177, ptr %l96
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load ptr, ptr %l2, !tbaa !29
  %t181 = getelementptr %"compiler/ast:Path", ptr %t179, i32 0, i32 1
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  store { i64, ptr } %t182, ptr %l99, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 0
  %t186 = load i32, ptr %t185, !tbaa !33
  %t189 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s7, ptr %t178, i32 %t186)
  store { i64, ptr } %t189, ptr %l101
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t190 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t198 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNotCaught(ptr %s7, ptr %s7, { i64, ptr } %t196)
  store %"compiler/msgs:Msg" %t198, ptr %l103
  br label %bb44
bb44:
  %t199 = load ptr, ptr %l94, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l96
  %t201 = load %"compiler/msgs:Msg", ptr %l103
  %t202 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t199, %"compiler/source:Span" %t200, %"compiler/msgs:Msg" %t201)
  store i64 %t202, ptr %l104
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s7)
  br label %bb46
bb46:
  br label %ret
bb47:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t207 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %t203, ptr %t204)
  store { i64, i32 } %t207, ptr %l107
  br label %bb48
bb48:
  %t208 = load { i64, i32 }, ptr %l107
  store { i64, i32 } %t208, ptr %l4
  %t209 = getelementptr { i64, i32 }, ptr %l4, i32 0, i32 0
  %t210 = load i64, ptr %t209, !tbaa !24
  store i64 %t210, ptr %l5, !tbaa !24
  %t212 = getelementptr { i64, i32 }, ptr %l4, i32 0, i32 1
  %t213 = load i32, ptr %t212, !tbaa !23
  store i32 %t213, ptr %l6, !tbaa !23
  %t215 = load i64, ptr %l5, !tbaa !24
  %t217 = icmp slt i64 %t215, 0
  br i1 %t217, label %bb49, label %bb50
bb49:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = getelementptr %"compiler/check:Checker", ptr %t219, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !29
  store ptr %t222, ptr %l113, !tbaa !29
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t223)
  store ptr %t225, ptr %l115
  br label %bb51
bb50:
  br label %bb53
bb51:
  %t226 = load ptr, ptr %l115, !tbaa !29
  %t228 = getelementptr %"compiler/check:frame", ptr %t226, i32 0, i32 4
  %t229 = load ptr, ptr %l2, !tbaa !29
  %t230 = load ptr, ptr %l113, !tbaa !29
  %t233 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v0, ptr %v1, ptr %t230, ptr %t228, ptr %t229)
  store i1 %t233, ptr %l119
  br label %bb52
bb52:
  br label %ret
bb53:
  %t234 = load i64, ptr %l5, !tbaa !24
  %t236 = icmp slt i64 %t234, 64
  br i1 %t236, label %bb54, label %bb55
bb54:
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = getelementptr %"compiler/check:Checker", ptr %t238, i32 0, i32 1
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t243 = getelementptr %"compiler/generic:Program", ptr %t241, i32 0, i32 2
  %t244 = load i32, ptr %l6, !tbaa !23
  %t245 = load i64, ptr %l5, !tbaa !24
  store i64 %t245, ptr %l127, !tbaa !24
  %t246 = load i64, ptr %l127, !tbaa !24
  %t247 = load i64, ptr %l127, !tbaa !24
  %t248 = shl i64 1, %t247
  %t252 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %t243, i32 %t244, i64 %t248)
  store i32 %t252, ptr %l129
  br label %bb56
bb55:
  %t253 = load i32, ptr %l6, !tbaa !23
  store i32 %t253, ptr %l122, !tbaa !23
  br label %bb57
bb56:
  %t255 = load i32, ptr %l129, !tbaa !23
  store i32 %t255, ptr %l122, !tbaa !23
  br label %bb57
bb57:
  %t256 = load i32, ptr %l122, !tbaa !23
  store i32 %t256, ptr %l7, !tbaa !23
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t257)
  store ptr %t259, ptr %l132
  br label %bb58
bb58:
  %t260 = load ptr, ptr %l132, !tbaa !29
  store ptr %t260, ptr %l8, !tbaa !29
  %t261 = load ptr, ptr %l8, !tbaa !29
  %t263 = getelementptr %"compiler/check:frame", ptr %t261, i32 0, i32 23
  %t264 = load i1, ptr %t263, !tbaa !21
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb59, label %bb60
bb59:
  %t268 = load ptr, ptr %l8, !tbaa !29
  %t270 = getelementptr %"compiler/check:frame", ptr %t268, i32 0, i32 12
  %t271 = load i1, ptr %t270, !tbaa !21
  %t273 = xor i1 %t271, true
  store i1 %t273, ptr %l136, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb61
bb61:
  %t275 = load i1, ptr %l136, !tbaa !21
  br i1 %t275, label %bb62, label %bb63
bb62:
  %t276 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t276, ptr %l9, !tbaa !23
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/check:Checker", ptr %t278, i32 0, i32 1
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/generic:Program", ptr %t281, i32 0, i32 2
  %t284 = load ptr, ptr %l8, !tbaa !29
  %t286 = getelementptr %"compiler/check:frame", ptr %t284, i32 0, i32 6
  %t287 = load i32, ptr %t286, !tbaa !23
  %t290 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t283, i32 %t287)
  store { i64, ptr } %t290, ptr %l146
  br label %bb64
bb63:
  br label %bb90
bb64:
  %t291 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t291, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t292 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t292, 0
  store i64 %t294, ptr %l12, !tbaa !24
  br label %bb65
bb65:
  store %olang.scope zeroinitializer, ptr %s11
  %t296 = load i64, ptr %l11, !tbaa !24
  %t297 = load i64, ptr %l12, !tbaa !24
  %t300 = icmp slt i64 %t296, %t297
  %t302 = xor i1 %t300, true
  br i1 %t302, label %bb66, label %bb67
bb66:
  call void @__olang_scope_close(ptr %s11)
  br label %bb74
bb67:
  br label %bb68
bb68:
  %t304 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t304, ptr %l153, !tbaa !27
  %t305 = load i64, ptr %l11, !tbaa !24
  %t307 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !27
  %t309 = getelementptr i32, ptr %t308, i64 %t305
  %t310 = load i32, ptr %t309, !tbaa !33
  store i32 %t310, ptr %l13, !tbaa !23
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t314 = getelementptr %"compiler/check:Checker", ptr %t312, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !29
  %t317 = getelementptr %"compiler/generic:Program", ptr %t315, i32 0, i32 2
  %t318 = load i32, ptr %l13, !tbaa !23
  %t321 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t317, i32 %t318)
  store i32 %t321, ptr %l160
  br label %bb69
bb69:
  %t322 = load i32, ptr %l6, !tbaa !23
  %t323 = load i32, ptr %l160, !tbaa !23
  %t325 = icmp eq i32 %t323, %t322
  br i1 %t325, label %bb70, label %bb71
bb70:
  %t327 = load i32, ptr %l13, !tbaa !23
  store i32 %t327, ptr %l9, !tbaa !23
  br label %bb72
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s11)
  br label %bb73
bb73:
  %t329 = load i64, ptr %l11, !tbaa !24
  %t331 = add i64 %t329, 1
  store i64 %t331, ptr %l11, !tbaa !24
  br label %bb65
bb74:
  %t333 = load i32, ptr %l9, !tbaa !23
  %t334 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t337 = icmp eq i32 %t333, %t334
  br i1 %t337, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s14
  %t339 = load ptr, ptr %l0, !tbaa !29
  store ptr %t339, ptr %l169, !tbaa !29
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t341 = load ptr, ptr %l2, !tbaa !29
  %t344 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t340, ptr %t341, i64 1)
  store %"compiler/source:Span" %t344, ptr %l172
  br label %bb77
bb76:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load ptr, ptr %l8, !tbaa !29
  %t348 = getelementptr %"compiler/check:frame", ptr %t346, i32 0, i32 6
  %t349 = load i32, ptr %t348, !tbaa !23
  %t350 = load i32, ptr %l7, !tbaa !23
  %t354 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %t345, i32 %t349, i32 %t350)
  store i32 %t354, ptr %l183
  br label %bb81
bb77:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i32, ptr %l6, !tbaa !23
  %t359 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s14, ptr %t355, i32 %t356)
  store { i64, ptr } %t359, ptr %l175
  br label %bb78
bb78:
  %t360 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t361 = extractvalue { i64, ptr } %t360, 0
  %t362 = extractvalue { i64, ptr } %t360, 1
  %t363 = mul i64 %t361, 1
  %t364 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t363)
  call void @llvm.memcpy.p0.p0.i64(ptr %t364, ptr %t362, i64 %t363, i1 false)
  %t365 = insertvalue { i64, ptr } undef, i64 %t361, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  %t368 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %s14, ptr %s14, { i64, ptr } %t366)
  store %"compiler/msgs:Msg" %t368, ptr %l177
  br label %bb79
bb79:
  %t369 = load ptr, ptr %l169, !tbaa !29
  %t370 = load %"compiler/source:Span", ptr %l172
  %t371 = load %"compiler/msgs:Msg", ptr %l177
  %t372 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s14, ptr %t369, %"compiler/source:Span" %t370, %"compiler/msgs:Msg" %t371)
  store i64 %t372, ptr %l178
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s14)
  br label %bb89
bb81:
  %t373 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t374 = load i32, ptr %l183, !tbaa !23
  %t376 = icmp ne i32 %t374, %t373
  br i1 %t376, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s16
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l186, !tbaa !29
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t380 = load ptr, ptr %l2, !tbaa !29
  %t383 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %t379, ptr %t380, i64 0)
  store %"compiler/source:Span" %t383, ptr %l189
  br label %bb84
bb83:
  br label %bb88
bb84:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i32, ptr %l9, !tbaa !23
  %t388 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s16, ptr %t384, i32 %t385)
  store { i64, ptr } %t388, ptr %l192
  br label %bb85
bb85:
  %t389 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t390 = extractvalue { i64, ptr } %t389, 0
  %t391 = extractvalue { i64, ptr } %t389, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t397 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %s16, ptr %s16, { i64, ptr } %t395)
  store %"compiler/msgs:Msg" %t397, ptr %l194
  br label %bb86
bb86:
  %t398 = load ptr, ptr %l186, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l189
  %t400 = load %"compiler/msgs:Msg", ptr %l194
  %t401 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s16, ptr %t398, %"compiler/source:Span" %t399, %"compiler/msgs:Msg" %t400)
  store i64 %t401, ptr %l195
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s16)
  br label %bb88
bb88:
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i32, ptr %l7, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %t402, i32 %t403)
  br label %bb91
bb91:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  %t408 = load i32, ptr %l6, !tbaa !23
  %t409 = load i64, ptr %l5, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t410
  %t411 = getelementptr { i64, [3 x i64] }, ptr %t410, i32 0, i32 0
  store i64 7, ptr %t411
  %t413 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t407, 0
  %t415 = insertvalue { %"compiler/source:Span", i32, i64 } %t413, i32 %t408, 1
  %t417 = insertvalue { %"compiler/source:Span", i32, i64 } %t415, i64 %t409, 2
  %t418 = getelementptr { i64, [3 x i64] }, ptr %t410, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t417, ptr %t418
  %t419 = load { i64, [3 x i64] }, ptr %t410
  %t421 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t419, ptr %t421
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %t406, ptr %t421)
  br label %bb92
bb92:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawValue(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l24 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca %"compiler/source:Span"
  %l33 = alloca { i64, ptr }
  %l35 = alloca %"compiler/msgs:Msg"
  %l36 = alloca i64
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca %"compiler/source:Span"
  %l47 = alloca %"compiler/msgs:Msg"
  %l48 = alloca i64
  %l53 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i1
  %l67 = alloca i1
  %l77 = alloca ptr
  %l81 = alloca ptr
  %l83 = alloca i32
  %l86 = alloca i64
  %l90 = alloca ptr
  %l93 = alloca ptr
  %l98 = alloca i32
  %l99 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l112 = alloca i64
  %l115 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca %"compiler/source:Span"
  %l139 = alloca i32
  %l140 = alloca i32
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l146 = alloca %"compiler/source:Span"
  %l148 = alloca i32
  %l150 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca i32
  %l155 = alloca ptr
  %l160 = alloca ptr
  %l163 = alloca %"compiler/typed:Cond"
  %l171 = alloca i64
  %l174 = alloca %"compiler/source:Span"
  %l175 = alloca i32
  %l179 = alloca { i64, ptr }
  %l182 = alloca %"compiler/typed:Seq"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca ptr
  %t290 = alloca { i64, [5 x i64] }, align 8
  %t333 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l3, !tbaa !23
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %t1, i32 %t2)
  store ptr %t5, ptr %l24
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l24, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t9 = getelementptr %"compiler/check:rawTable", ptr %t7, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t14 = icmp eq i32 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l29, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t17, ptr %l30
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load i32, ptr %l3, !tbaa !23
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t18, i32 %t19)
  store { i64, ptr } %t22, ptr %l33
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t23 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRawValues(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t31, ptr %l35
  br label %bb5
bb5:
  %t32 = load ptr, ptr %l29, !tbaa !29
  %t33 = load %"compiler/source:Span", ptr %l30
  %t34 = load %"compiler/msgs:Msg", ptr %l35
  %t35 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t32, %"compiler/source:Span" %t33, %"compiler/msgs:Msg" %t34)
  store i64 %t35, ptr %l36
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load %"compiler/source:Span", ptr %l1
  %t44 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t40, %"compiler/source:Span" %t41)
  store ptr %t44, ptr %l41
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t45 = load ptr, ptr %l41, !tbaa !29
  store ptr %t45, ptr %rv
  br label %ret
bb9:
  %t46 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t50 = icmp sgt i64 %t48, 0
  br i1 %t50, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l45, !tbaa !29
  %t53 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t53, ptr %l46
  %t54 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %s2, ptr %s2, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t54, ptr %l47
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t55 = load ptr, ptr %l45, !tbaa !29
  %t56 = load %"compiler/source:Span", ptr %l46
  %t57 = load %"compiler/msgs:Msg", ptr %l47
  %t58 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t55, %"compiler/source:Span" %t56, %"compiler/msgs:Msg" %t57)
  store i64 %t58, ptr %l48
  br label %bb13
bb13:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %t59, { i64, ptr } %t60)
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l1
  %t67 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t63, %"compiler/source:Span" %t64)
  store ptr %t67, ptr %l53
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  %t68 = load ptr, ptr %l53, !tbaa !29
  store ptr %t68, ptr %rv
  br label %ret
bb16:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = load %"compiler/source:Span", ptr %l1
  %t75 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t69, ptr %a4, %"compiler/source:Span" %t71)
  store ptr %t75, ptr %l57
  br label %bb17
bb17:
  %t76 = load ptr, ptr %l57, !tbaa !29
  store ptr %t76, ptr %l7, !tbaa !29
  %t77 = load ptr, ptr %l7, !tbaa !29
  store ptr %t77, ptr %l58, !tbaa !29
  store i1 false, ptr %l59, !tbaa !21
  %t78 = load ptr, ptr %l58, !tbaa !29
  %t79 = icmp ne ptr %t78, null
  br i1 %t79, label %bb18, label %bb19
bb18:
  %t81 = load ptr, ptr %l58, !tbaa !29
  %t82 = load i64, ptr %t81
  %t84 = icmp eq i64 %t82, 7
  store i1 %t84, ptr %l59, !tbaa !21
  br label %bb19
bb19:
  %t85 = load i1, ptr %l59, !tbaa !21
  br i1 %t85, label %bb20, label %bb21
bb20:
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t88 = getelementptr { i64, [5 x i64] }, ptr %t86, i32 0, i32 1
  %t89 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t88, i32 0, i32 2
  %t90 = load ptr, ptr %t89
  store ptr %t90, ptr %l8, !tbaa !29
  br label %bb22
bb21:
  br label %bb30
bb22:
  %t92 = load ptr, ptr %l8, !tbaa !29
  %t94 = getelementptr %"compiler/typed:Make", ptr %t92, i32 0, i32 0
  %t95 = load i32, ptr %t94
  %t97 = trunc i64 1 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb23, label %bb24
bb23:
  %t100 = load ptr, ptr %l8, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Make", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t103, 0
  %t107 = icmp eq i64 %t105, 0
  store i1 %t107, ptr %l67, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l67, !tbaa !21
  br label %bb25
bb25:
  %t109 = load i1, ptr %l67, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load %"compiler/source:Span", ptr %l1
  %t112 = load ptr, ptr %l6, !tbaa !29
  %t113 = load ptr, ptr %l8, !tbaa !29
  %t115 = getelementptr %"compiler/typed:Make", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %t115, !tbaa !24
  %t121 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t110, %"compiler/source:Span" %t111, ptr %t112, i64 %t116)
  store ptr %t121, ptr %l77
  br label %bb28
bb27:
  br label %bb29
bb28:
  %t122 = load ptr, ptr %l77, !tbaa !29
  store ptr %t122, ptr %rv
  br label %ret
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l1
  %t125 = load ptr, ptr %l6, !tbaa !29
  %t129 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t123, %"compiler/source:Span" %t124, ptr %t125, i64 0)
  store ptr %t129, ptr %l81
  br label %bb32
bb32:
  %t130 = load ptr, ptr %l81, !tbaa !29
  %t132 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t130)
  store i32 %t132, ptr %l83
  br label %bb33
bb33:
  %t133 = load i32, ptr %l83, !tbaa !23
  store i32 %t133, ptr %l9, !tbaa !23
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 33
  %t138 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t136)
  store i64 %t138, ptr %l86
  br label %bb34
bb34:
  %t139 = load i64, ptr %l86, !tbaa !24
  store i64 %t139, ptr %l10, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load %"compiler/source:Span", ptr %l1
  %t142 = load ptr, ptr %l7, !tbaa !29
  %t146 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %t140, %"compiler/source:Span" %t141, ptr %t142)
  store ptr %t146, ptr %l90
  br label %bb35
bb35:
  %t147 = load ptr, ptr %l90, !tbaa !29
  store ptr %t147, ptr %l11, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  store ptr %t153, ptr %l93, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 2
  %t160 = load i32, ptr %l3, !tbaa !23
  %t163 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t159, i32 %t160)
  store i32 %t163, ptr %l98
  br label %bb36
bb36:
  %t164 = load ptr, ptr %l93, !tbaa !29
  %t165 = load i32, ptr %l98, !tbaa !23
  %t166 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t164, i32 %t165)
  store { i64, ptr } %t166, ptr %l99
  br label %bb37
bb37:
  %t167 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t167, 0
  store i64 %t168, ptr %l12, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load %"compiler/source:Span", ptr %l1
  %t172 = load ptr, ptr %l6, !tbaa !29
  %t173 = load i64, ptr %l12, !tbaa !24
  %t175 = sub i64 %t173, 1
  %t180 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t170, %"compiler/source:Span" %t171, ptr %t172, i64 %t175)
  store ptr %t180, ptr %l106
  br label %bb38
bb38:
  %t181 = load ptr, ptr %l106, !tbaa !29
  store ptr %t181, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  %t182 = load i64, ptr %l12, !tbaa !24
  %t184 = sub i64 %t182, 1
  store i64 %t184, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t186 = load i64, ptr %l15, !tbaa !24
  %t187 = load i64, ptr %l14, !tbaa !24
  %t190 = icmp sgt i64 %t186, %t187
  br i1 %t190, label %bb39, label %bb40
bb39:
  %t192 = load i64, ptr %l16, !tbaa !24
  %t194 = icmp sgt i64 %t192, 0
  br i1 %t194, label %bb41, label %bb42
bb40:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb44
bb41:
  %t196 = load i64, ptr %l15, !tbaa !24
  %t197 = load i64, ptr %l14, !tbaa !24
  %t200 = sub i64 %t196, %t197
  %t201 = load i64, ptr %l16, !tbaa !24
  %t204 = add i64 %t200, %t201
  %t206 = sub i64 %t204, 1
  %t207 = load i64, ptr %l16, !tbaa !24
  %t210 = sdiv i64 %t206, %t207
  store i64 %t210, ptr %l115, !tbaa !24
  br label %bb43
bb42:
  store i64 0, ptr %l115, !tbaa !24
  br label %bb43
bb43:
  %t212 = load i64, ptr %l115, !tbaa !24
  store i64 %t212, ptr %l112, !tbaa !24
  br label %bb44
bb44:
  %t213 = load i64, ptr %l112, !tbaa !24
  store i64 %t213, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s7
  %t214 = load i64, ptr %l18, !tbaa !24
  %t215 = load i64, ptr %l17, !tbaa !24
  %t218 = icmp slt i64 %t214, %t215
  %t220 = xor i1 %t218, true
  br i1 %t220, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb56
bb47:
  br label %bb48
bb48:
  %t222 = load i64, ptr %l14, !tbaa !24
  %t223 = load i64, ptr %l18, !tbaa !24
  %t224 = load i64, ptr %l16, !tbaa !24
  %t227 = mul i64 %t223, %t224
  %t230 = add i64 %t222, %t227
  %t232 = load i64, ptr %l12, !tbaa !24
  %t234 = sub i64 %t232, 2
  %t238 = sub i64 %t234, %t230
  store i64 %t238, ptr %l20, !tbaa !24
  %t240 = load ptr, ptr %l0, !tbaa !29
  store ptr %t240, ptr %l137, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t241, ptr %l138
  %t242 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t242, ptr %l139, !tbaa !23
  store i32 23, ptr %l140
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t244 = load %"compiler/source:Span", ptr %l1
  %t245 = load ptr, ptr %l11, !tbaa !29
  %t249 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t243, %"compiler/source:Span" %t244, ptr %t245)
  store ptr %t249, ptr %l144
  br label %bb49
bb49:
  %t250 = load ptr, ptr %l0, !tbaa !29
  store ptr %t250, ptr %l145, !tbaa !29
  %t251 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t251, ptr %l146
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t252)
  store i32 %t254, ptr %l148
  br label %bb50
bb50:
  %t255 = load i64, ptr %l20, !tbaa !24
  %t256 = load ptr, ptr %l145, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l146
  %t258 = load i32, ptr %l148, !tbaa !23
  %t260 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t256, %"compiler/source:Span" %t257, i32 %t258, i64 %t255)
  store ptr %t260, ptr %l150
  br label %bb51
bb51:
  %t261 = load ptr, ptr %l150, !tbaa !29
  %t262 = load ptr, ptr %l137, !tbaa !29
  %t263 = load %"compiler/source:Span", ptr %l138
  %t264 = load i32, ptr %l139, !tbaa !23
  %t265 = load i32, ptr %l140
  %t266 = load ptr, ptr %l144, !tbaa !29
  %t268 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t262, %"compiler/source:Span" %t263, i32 %t264, i32 %t265, ptr %t266, ptr %t261)
  store ptr %t268, ptr %l152
  br label %bb52
bb52:
  %t269 = load ptr, ptr %l152, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t270, ptr %l153
  %t271 = load i32, ptr %l9, !tbaa !23
  store i32 %t271, ptr %l154, !tbaa !23
  store ptr %t269, ptr %l155, !tbaa !29
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load ptr, ptr %l6, !tbaa !29
  %t276 = load i64, ptr %l20, !tbaa !24
  %t281 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v0, ptr %t273, %"compiler/source:Span" %t274, ptr %t275, i64 %t276)
  store ptr %t281, ptr %l160
  br label %bb53
bb53:
  %t282 = load ptr, ptr %l160, !tbaa !29
  %t283 = load ptr, ptr %l13, !tbaa !29
  %t284 = load ptr, ptr %l155, !tbaa !29
  %t287 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t284, ptr %t282, ptr %t283)
  store %"compiler/typed:Cond" %t287, ptr %l163
  br label %bb54
bb54:
  %t288 = load %"compiler/typed:Cond", ptr %l163
  %t289 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Cond" %t288, ptr %t289
  store { i64, [5 x i64] } zeroinitializer, ptr %t290
  %t291 = getelementptr { i64, [5 x i64] }, ptr %t290, i32 0, i32 0
  store i64 11, ptr %t291
  %t292 = load %"compiler/source:Span", ptr %l153
  %t293 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t292, 0
  %t294 = load i32, ptr %l154, !tbaa !23
  %t295 = insertvalue { %"compiler/source:Span", i32, ptr } %t293, i32 %t294, 1
  %t297 = insertvalue { %"compiler/source:Span", i32, ptr } %t295, ptr %t289, 2
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t290, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t297, ptr %t298
  %t299 = load { i64, [5 x i64] }, ptr %t290
  %t301 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t299, ptr %t301
  store ptr %t301, ptr %l13, !tbaa !29
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t303 = load i64, ptr %l18, !tbaa !24
  %t305 = add i64 %t303, 1
  store i64 %t305, ptr %l18, !tbaa !24
  br label %bb45
bb56:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/check:Checker", ptr %t307, i32 0, i32 33
  %t311 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t309)
  store i64 %t311, ptr %l171
  br label %bb57
bb57:
  %t312 = load i64, ptr %l10, !tbaa !24
  %t313 = load i64, ptr %l171, !tbaa !24
  %t315 = icmp sgt i64 %t313, %t312
  br i1 %t315, label %bb58, label %bb59
bb58:
  %t317 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t317, ptr %l174
  %t318 = load i32, ptr %l9, !tbaa !23
  store i32 %t318, ptr %l175, !tbaa !23
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/check:Checker", ptr %t319, i32 0, i32 33
  %t322 = load i64, ptr %l10, !tbaa !24
  %t325 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t321, i64 %t322)
  store { i64, ptr } %t325, ptr %l179
  br label %bb60
bb59:
  br label %bb62
bb60:
  %t326 = load ptr, ptr %l13, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t330 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t328, ptr %t326)
  store %"compiler/typed:Seq" %t330, ptr %l182
  br label %bb61
bb61:
  %t331 = load %"compiler/typed:Seq", ptr %l182
  %t332 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store %"compiler/typed:Seq" %t331, ptr %t332
  store { i64, [5 x i64] } zeroinitializer, ptr %t333
  %t334 = getelementptr { i64, [5 x i64] }, ptr %t333, i32 0, i32 0
  store i64 12, ptr %t334
  %t335 = load %"compiler/source:Span", ptr %l174
  %t336 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t335, 0
  %t337 = load i32, ptr %l175, !tbaa !23
  %t338 = insertvalue { %"compiler/source:Span", i32, ptr } %t336, i32 %t337, 1
  %t340 = insertvalue { %"compiler/source:Span", i32, ptr } %t338, ptr %t332, 2
  %t341 = getelementptr { i64, [5 x i64] }, ptr %t333, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t340, ptr %t341
  %t342 = load { i64, [5 x i64] }, ptr %t333
  %t344 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t342, ptr %t344
  store ptr %t344, ptr %rv
  br label %ret
bb62:
  %t346 = load ptr, ptr %l13, !tbaa !29
  store ptr %t346, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %rv = alloca ptr
  %t6 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %"compiler/source:Span" %a1, ptr %l3
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t4 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t2)
  store i32 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t6
  %t7 = getelementptr { i64, [5 x i64] }, ptr %t6, i32 0, i32 0
  store i64 2, ptr %t7
  %t8 = load %"compiler/source:Span", ptr %l3
  %t9 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } undef, %"compiler/source:Span" %t8, 0
  %t10 = load i32, ptr %l5, !tbaa !23
  %t11 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t9, i32 %t10, 1
  %t13 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t11, ptr %t5, 2
  %t14 = insertvalue { %"compiler/source:Span", i32, ptr, i32 } %t13, i32 -1, 3
  %t15 = getelementptr { i64, [5 x i64] }, ptr %t6, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, i32 } %t14, ptr %t15
  %t16 = load { i64, [5 x i64] }, ptr %t6
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t16, ptr %t18
  store ptr %t18, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erecvReplaced(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l21 = alloca i64
  %l30 = alloca i64
  %l33 = alloca i64
  %l52 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l65 = alloca i32
  %l70 = alloca i32
  %l75 = alloca i32
  %l80 = alloca i32
  %l81 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t12, i32 %t13)
  store i32 %t16, ptr %l18
  br label %bb1
bb1:
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load i32, ptr %l18, !tbaa !23
  %t19 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %t17, i32 %t18)
  store { i64, ptr } %t19, ptr %l19
  br label %bb2
bb2:
  %t20 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l21, !tbaa !24
  %t24 = load i64, ptr %l21, !tbaa !24
  %t25 = icmp sge i64 %t24, 0
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = icmp sle i64 %t27, 2305843009213693951
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_e5e26ce82a519cb4_386557e0c1145fc8)
  unreachable
bb5:
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = mul i64 %t30, 4
  %t32 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t31)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_e5e26ce82a519cb4_386557e0c1145fc8)
  unreachable
bb7:
  %t46 = load i64, ptr %l7, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb12
bb9:
  %t50 = load i64, ptr %l6, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l33, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb11
bb11:
  %t66 = load i64, ptr %l33, !tbaa !24
  store i64 %t66, ptr %l30, !tbaa !24
  br label %bb12
bb12:
  %t67 = load i64, ptr %l30, !tbaa !24
  store i64 %t67, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  %t68 = load i64, ptr %l9, !tbaa !24
  %t69 = load i64, ptr %l8, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t78 = load i64, ptr %l7, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  store i64 %t84, ptr %l10, !tbaa !24
  %t86 = load i64, ptr %l10, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t87, ptr %l52, !tbaa !27
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i32, ptr %t91, i64 %t88
  %t93 = load i32, ptr %t92, !tbaa !33
  %t96 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t86
  store i32 %t93, ptr %t98, !tbaa !33
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = add i64 %t99, 1
  store i64 %t101, ptr %l9, !tbaa !24
  br label %bb13
bb18:
  %t105 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = getelementptr i32, ptr %t106, i64 0
  store i32 %a2, ptr %t107, !tbaa !33
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  store ptr %t113, ptr %l60, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !29
  %t119 = getelementptr %"compiler/generic:Program", ptr %t117, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t123 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t119, { i64, ptr } %t120)
  store i32 %t123, ptr %l65
  br label %bb19
bb19:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l1, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t133, ptr %l70
  br label %bb20
bb20:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l75
  br label %bb21
bb21:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/check:Checker", ptr %t144, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t149 = getelementptr %"compiler/generic:Program", ptr %t147, i32 0, i32 2
  %t150 = load i32, ptr %l1, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l80
  br label %bb22
bb22:
  %t154 = load ptr, ptr %l60, !tbaa !29
  %t155 = load i32, ptr %l65, !tbaa !23
  %t156 = load i32, ptr %l70, !tbaa !23
  %t157 = load i32, ptr %l75, !tbaa !23
  %t158 = load i32, ptr %l80, !tbaa !23
  %t159 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %t154, i32 %t155, i32 %t156, i32 %t157, i32 %t158, i64 0)
  store i32 %t159, ptr %l81
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t160 = load i32, ptr %l81, !tbaa !23
  store i32 %t160, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflConst(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca %"compiler/generic:Desc"
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l15 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca i1
  %l27 = alloca i1
  %l31 = alloca i1
  %l36 = alloca %"compiler/check:reflVal"
  %l38 = alloca i1
  %l43 = alloca { i64, ptr }
  %l45 = alloca %"compiler/check:reflVal"
  %l47 = alloca i1
  %l52 = alloca i64
  %l55 = alloca %"compiler/check:reflVal"
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i32
  %l60 = alloca %"compiler/check:reflVal"
  %l62 = alloca i1
  %l63 = alloca i1
  %l65 = alloca i1
  %l70 = alloca i1
  %l72 = alloca %"compiler/check:reflVal"
  %l74 = alloca i1
  %l75 = alloca i64
  %l80 = alloca i64
  %l85 = alloca i64
  %l86 = alloca %"compiler/check:reflVal"
  %l88 = alloca i1
  %l92 = alloca i32
  %l97 = alloca i32
  %l101 = alloca i1
  %l104 = alloca ptr
  %l109 = alloca i32
  %l110 = alloca i32
  %l114 = alloca %"compiler/check:reflVal"
  %l117 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i64
  %l124 = alloca %"compiler/check:reflVal"
  %l125 = alloca %"compiler/check:reflVal"
  %l128 = alloca i32
  %l131 = alloca %"compiler/check:reflVal"
  %l135 = alloca %"compiler/check:reflVal"
  %l139 = alloca %"compiler/generic:Desc"
  %l142 = alloca i1
  %l145 = alloca { i64, ptr }
  %l147 = alloca %"compiler/check:reflVal"
  %l149 = alloca i1
  %l150 = alloca i1
  %l156 = alloca ptr
  %l159 = alloca %"compiler/check:reflVal"
  %l161 = alloca i1
  %l162 = alloca i1
  %l168 = alloca i64
  %l171 = alloca %"compiler/check:reflVal"
  %l173 = alloca %"compiler/check:reflVal"
  %l174 = alloca %"compiler/check:reflVal"
  %l175 = alloca %"compiler/check:reflVal"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflVal"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t7, ptr %t8)
  store i32 %t11, ptr %l15
  br label %bb2
bb2:
  %t12 = load i32, ptr %l15, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load i32, ptr %l4, !tbaa !23
  %t15 = icmp sge i32 %t13, 0
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i32, ptr %l4, !tbaa !23
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t17, i32 %t18)
  store i1 %t21, ptr %l21
  br label %bb5
bb4:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb14
bb5:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t27 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %t23, ptr %t24)
  store i1 %t27, ptr %l25
  br label %bb8
bb7:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb9
bb8:
  %t28 = load i1, ptr %l25, !tbaa !21
  %t29 = xor i1 %t28, true
  store i1 %t29, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l22, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load i32, ptr %l4, !tbaa !23
  %t34 = load i32, ptr %l2, !tbaa !23
  %t38 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasCase(ptr %v0, ptr %t32, i32 %t33, i32 %t34)
  store i1 %t38, ptr %l31
  br label %bb12
bb11:
  store i1 false, ptr %l27, !tbaa !21
  br label %bb13
bb12:
  %t39 = load i1, ptr %l31, !tbaa !21
  store i1 %t39, ptr %l27, !tbaa !21
  br label %bb13
bb13:
  %t40 = load i1, ptr %l27, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l18, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l18, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s1
  %t44 = load i32, ptr %l4, !tbaa !23
  %t45 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t48 = icmp eq i32 %t44, %t45
  br i1 %t48, label %bb17, label %bb18
bb16:
  br label %bb77
bb17:
  %t50 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t50, ptr %l36
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t51 = load %"compiler/check:reflVal", ptr %l36
  store %"compiler/check:reflVal" %t51, ptr %rv
  br label %ret
bb20:
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t52, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t54, ptr %l38
  br label %bb21
bb21:
  %t55 = load i1, ptr %l38, !tbaa !21
  br i1 %t55, label %bb22, label %bb23
bb22:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 95
  store i1 true, ptr %t58, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  %t63 = load i32, ptr %l4, !tbaa !23
  %t66 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflName(ptr %v0, ptr %v2, ptr %t62, i32 %t63)
  store { i64, ptr } %t66, ptr %l43
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t67 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = mul i64 %t68, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t70)
  call void @llvm.memcpy.p0.p0.i64(ptr %t71, ptr %t69, i64 %t70, i1 false)
  %t72 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  %t75 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervText(ptr %v2, ptr %v2, { i64, ptr } %t73)
  store %"compiler/check:reflVal" %t75, ptr %l45
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t76 = load %"compiler/check:reflVal", ptr %l45
  store %"compiler/check:reflVal" %t76, ptr %rv
  br label %ret
bb26:
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t77, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i1 %t79, ptr %l47
  br label %bb27
bb27:
  %t80 = load i1, ptr %l47, !tbaa !21
  br i1 %t80, label %bb28, label %bb29
bb28:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 95
  store i1 true, ptr %t83, !tbaa !21
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t88 = load i32, ptr %l4, !tbaa !23
  %t91 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflKind(ptr %v0, ptr %t87, i32 %t88)
  store i64 %t91, ptr %l52
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t92 = load i64, ptr %l52, !tbaa !24
  store i64 %t92, ptr %l5, !tbaa !24
  %t93 = load i64, ptr %l5, !tbaa !24
  %t95 = icmp slt i64 %t93, 0
  br i1 %t95, label %bb31, label %bb32
bb31:
  %t97 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t97, ptr %l55
  br label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load %"compiler/check:reflVal", ptr %l55
  store %"compiler/check:reflVal" %t98, ptr %rv
  br label %ret
bb34:
  %t99 = load i64, ptr @G_2ecompiler_2fcheck_2eRvCase, !tbaa !24
  store i64 %t99, ptr %l56, !tbaa !24
  %t100 = load i64, ptr %l5, !tbaa !24
  store i64 %t100, ptr %l57, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeKindType(ptr %v0, ptr %t101)
  store i32 %t103, ptr %l59
  br label %bb35
bb35:
  %t104 = load i64, ptr %l56, !tbaa !24
  %t105 = load i64, ptr %l57, !tbaa !24
  %t106 = load i32, ptr %l59, !tbaa !23
  %t107 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v2, ptr %v2, i1 true, i64 %t104, i64 %t105, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, i32 %t106)
  store %"compiler/check:reflVal" %t107, ptr %l60
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t108 = load %"compiler/check:reflVal", ptr %l60
  store %"compiler/check:reflVal" %t108, ptr %rv
  br label %ret
bb37:
  %t109 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t111 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t109, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t111, ptr %l62
  br label %bb38
bb38:
  %t112 = load i1, ptr %l62, !tbaa !21
  br i1 %t112, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb42
bb40:
  %t113 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t113, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store i1 %t115, ptr %l65
  br label %bb41
bb41:
  %t116 = load i1, ptr %l65, !tbaa !21
  store i1 %t116, ptr %l63, !tbaa !21
  br label %bb42
bb42:
  %t117 = load i1, ptr %l63, !tbaa !21
  br i1 %t117, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s6
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/check:Checker", ptr %t118, i32 0, i32 95
  store i1 true, ptr %t120, !tbaa !21
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t125 = load i32, ptr %l4, !tbaa !23
  %t128 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %t124, i32 %t125)
  store i1 %t128, ptr %l70
  br label %bb45
bb44:
  br label %bb57
bb45:
  %t129 = load i1, ptr %l70, !tbaa !21
  %t130 = xor i1 %t129, true
  br i1 %t130, label %bb46, label %bb47
bb46:
  %t132 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t132, ptr %l72
  br label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t133 = load %"compiler/check:reflVal", ptr %l72
  store %"compiler/check:reflVal" %t133, ptr %rv
  br label %ret
bb49:
  %t134 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t136 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t134, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t136, ptr %l74
  br label %bb50
bb50:
  %t137 = load i1, ptr %l74, !tbaa !21
  br i1 %t137, label %bb51, label %bb52
bb51:
  %t138 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/check:Checker", ptr %t138, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !29
  %t143 = getelementptr %"compiler/generic:Program", ptr %t141, i32 0, i32 2
  %t144 = load i32, ptr %l4, !tbaa !23
  %t147 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %t143, i32 %t144)
  store i64 %t147, ptr %l80
  br label %bb53
bb52:
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/check:Checker", ptr %t148, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !29
  %t153 = getelementptr %"compiler/generic:Program", ptr %t151, i32 0, i32 2
  %t154 = load i32, ptr %l4, !tbaa !23
  %t157 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %t153, i32 %t154)
  store i64 %t157, ptr %l85
  br label %bb54
bb53:
  %t158 = load i64, ptr %l80, !tbaa !24
  store i64 %t158, ptr %l75, !tbaa !24
  br label %bb55
bb54:
  %t159 = load i64, ptr %l85, !tbaa !24
  store i64 %t159, ptr %l75, !tbaa !24
  br label %bb55
bb55:
  %t160 = load i64, ptr %l75, !tbaa !24
  %t161 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t160)
  store %"compiler/check:reflVal" %t161, ptr %l86
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t162 = load %"compiler/check:reflVal", ptr %l86
  store %"compiler/check:reflVal" %t162, ptr %rv
  br label %ret
bb57:
  %t163 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t163, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t165, ptr %l88
  br label %bb58
bb58:
  %t166 = load i1, ptr %l88, !tbaa !21
  br i1 %t166, label %bb59, label %bb60
bb59:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 95
  store i1 true, ptr %t169, !tbaa !21
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i32, ptr %l4, !tbaa !23
  %t174 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t170, i32 %t171)
  store i32 %t174, ptr %l92
  br label %bb61
bb60:
  br label %bb75
bb61:
  %t175 = load i32, ptr %l92, !tbaa !23
  store i32 %t175, ptr %l6, !tbaa !23
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t178 = getelementptr %"compiler/check:Checker", ptr %t176, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !29
  %t181 = getelementptr %"compiler/generic:Program", ptr %t179, i32 0, i32 2
  %t182 = load i32, ptr %l6, !tbaa !23
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t181, i32 %t182)
  store i32 %t185, ptr %l97
  br label %bb62
bb62:
  %t186 = load i32, ptr %l97
  %t188 = trunc i64 19 to i32
  %t189 = icmp eq i32 %t186, %t188
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb67
bb64:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/check:Checker", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = getelementptr %"compiler/generic:Program", ptr %t196, i32 0, i32 2
  store ptr %t198, ptr %l104, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr %"compiler/check:Checker", ptr %t199, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !29
  %t204 = getelementptr %"compiler/generic:Program", ptr %t202, i32 0, i32 2
  %t205 = load i32, ptr %l6, !tbaa !23
  %t208 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t204, i32 %t205)
  store i32 %t208, ptr %l109
  br label %bb65
bb65:
  %t209 = load ptr, ptr %l104, !tbaa !29
  %t210 = load i32, ptr %l109, !tbaa !23
  %t211 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t209, i32 %t210)
  store i32 %t211, ptr %l110
  br label %bb66
bb66:
  %t212 = load i32, ptr %l110
  %t214 = trunc i64 26 to i32
  %t215 = icmp eq i32 %t212, %t214
  %t217 = xor i1 %t215, true
  store i1 %t217, ptr %l101, !tbaa !21
  br label %bb67
bb67:
  %t219 = load i1, ptr %l101, !tbaa !21
  br i1 %t219, label %bb68, label %bb69
bb68:
  %t220 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t220, ptr %l114
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t221 = load %"compiler/check:reflVal", ptr %l114
  store %"compiler/check:reflVal" %t221, ptr %rv
  br label %ret
bb71:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t224 = getelementptr %"compiler/check:Checker", ptr %t222, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = getelementptr %"compiler/generic:Program", ptr %t225, i32 0, i32 2
  store ptr %t227, ptr %l117, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/check:Checker", ptr %t228, i32 0, i32 1
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/generic:Program", ptr %t231, i32 0, i32 2
  %t234 = load i32, ptr %l6, !tbaa !23
  %t237 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t233, i32 %t234)
  store i32 %t237, ptr %l122
  br label %bb72
bb72:
  %t238 = load ptr, ptr %l117, !tbaa !29
  %t239 = load i32, ptr %l122, !tbaa !23
  %t240 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %t238, i32 %t239)
  store i64 %t240, ptr %l123
  br label %bb73
bb73:
  %t241 = load i64, ptr %l123, !tbaa !24
  %t242 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t241)
  store %"compiler/check:reflVal" %t242, ptr %l124
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t243 = load %"compiler/check:reflVal", ptr %l124
  store %"compiler/check:reflVal" %t243, ptr %rv
  br label %ret
bb75:
  %t244 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t244, ptr %l125
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t245 = load %"compiler/check:reflVal", ptr %l125
  store %"compiler/check:reflVal" %t245, ptr %rv
  br label %ret
bb77:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t250 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t246, ptr %t247)
  store i32 %t250, ptr %l128
  br label %bb78
bb78:
  %t251 = load i32, ptr %l128, !tbaa !23
  store i32 %t251, ptr %l7, !tbaa !23
  %t252 = load i32, ptr %l7, !tbaa !23
  %t254 = icmp slt i32 %t252, 0
  br i1 %t254, label %bb79, label %bb80
bb79:
  %t256 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t256, ptr %l131
  br label %bb81
bb80:
  br label %bb82
bb81:
  call void @__olang_scope_close(ptr %s0)
  %t257 = load %"compiler/check:reflVal", ptr %l131
  store %"compiler/check:reflVal" %t257, ptr %rv
  br label %ret
bb82:
  %t258 = load i32, ptr %l7, !tbaa !23
  %t259 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t262 = icmp eq i32 %t258, %t259
  br i1 %t262, label %bb83, label %bb84
bb83:
  %t264 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t264, ptr %l135
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t265 = load %"compiler/check:reflVal", ptr %l135
  store %"compiler/check:reflVal" %t265, ptr %rv
  br label %ret
bb86:
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/check:Checker", ptr %t266, i32 0, i32 1
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t270 = load i32, ptr %l7, !tbaa !23
  %t273 = call %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %t269, i32 %t270)
  store %"compiler/generic:Desc" %t273, ptr %l139
  br label %bb87
bb87:
  %t274 = load %"compiler/generic:Desc", ptr %l139
  store %"compiler/generic:Desc" %t274, ptr %l8
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 95
  store i1 true, ptr %t277, !tbaa !21
  %t278 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t280 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t278, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t280, ptr %l142
  br label %bb88
bb88:
  %t281 = load i1, ptr %l142, !tbaa !21
  br i1 %t281, label %bb89, label %bb90
bb89:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t283 = load %"compiler/generic:Desc", ptr %l8
  %t286 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v2, ptr %t282, %"compiler/generic:Desc" %t283)
  store { i64, ptr } %t286, ptr %l145
  br label %bb91
bb90:
  br label %bb93
bb91:
  %t287 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t288 = extractvalue { i64, ptr } %t287, 0
  %t289 = extractvalue { i64, ptr } %t287, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  %t295 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervText(ptr %v2, ptr %v2, { i64, ptr } %t293)
  store %"compiler/check:reflVal" %t295, ptr %l147
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s0)
  %t296 = load %"compiler/check:reflVal", ptr %l147
  store %"compiler/check:reflVal" %t296, ptr %rv
  br label %ret
bb93:
  %t297 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t299 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t297, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t299, ptr %l149
  br label %bb94
bb94:
  %t300 = load i1, ptr %l149, !tbaa !21
  br i1 %t300, label %bb95, label %bb96
bb95:
  %t301 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t302 = load i64, ptr %t301, !tbaa !24
  %t303 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescParam, !tbaa !24
  %t306 = icmp eq i64 %t302, %t303
  store i1 %t306, ptr %l150, !tbaa !21
  br label %bb97
bb96:
  store i1 false, ptr %l150, !tbaa !21
  br label %bb97
bb97:
  %t308 = load i1, ptr %l150, !tbaa !21
  br i1 %t308, label %bb98, label %bb99
bb98:
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t310 = load %"compiler/generic:Desc", ptr %l8
  %t313 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %t309, %"compiler/generic:Desc" %t310)
  store ptr %t313, ptr %l156
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t314 = load ptr, ptr %l156, !tbaa !29
  %t315 = icmp eq ptr %t314, null
  %t317 = xor i1 %t315, true
  %t319 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v2, i1 %t317)
  store %"compiler/check:reflVal" %t319, ptr %l159
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s0)
  %t320 = load %"compiler/check:reflVal", ptr %l159
  store %"compiler/check:reflVal" %t320, ptr %rv
  br label %ret
bb102:
  %t321 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t323 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t321, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t323, ptr %l161
  br label %bb103
bb103:
  %t324 = load i1, ptr %l161, !tbaa !21
  br i1 %t324, label %bb104, label %bb105
bb104:
  %t325 = getelementptr %"compiler/generic:Desc", ptr %l8, i32 0, i32 0
  %t326 = load i64, ptr %t325, !tbaa !24
  %t327 = load i64, ptr @G_2ecompiler_2fgeneric_2eDescField, !tbaa !24
  %t330 = icmp eq i64 %t326, %t327
  store i1 %t330, ptr %l162, !tbaa !21
  br label %bb106
bb105:
  store i1 false, ptr %l162, !tbaa !21
  br label %bb106
bb106:
  %t332 = load i1, ptr %l162, !tbaa !21
  br i1 %t332, label %bb107, label %bb108
bb107:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load %"compiler/generic:Desc", ptr %l8
  %t337 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldOffset(ptr %v0, ptr %t333, %"compiler/generic:Desc" %t334)
  store i64 %t337, ptr %l168
  br label %bb109
bb108:
  br label %bb115
bb109:
  %t338 = load i64, ptr %l168, !tbaa !24
  store i64 %t338, ptr %l9, !tbaa !24
  %t339 = load i64, ptr %l9, !tbaa !24
  %t341 = icmp sge i64 %t339, 0
  br i1 %t341, label %bb110, label %bb111
bb110:
  %t343 = load i64, ptr %l9, !tbaa !24
  %t345 = call %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v2, i64 %t343)
  store %"compiler/check:reflVal" %t345, ptr %l173
  br label %bb112
bb111:
  %t346 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t346, ptr %l174
  br label %bb113
bb112:
  %t347 = load %"compiler/check:reflVal", ptr %l173
  store %"compiler/check:reflVal" %t347, ptr %l171
  br label %bb114
bb113:
  %t348 = load %"compiler/check:reflVal", ptr %l174
  store %"compiler/check:reflVal" %t348, ptr %l171
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s0)
  %t349 = load %"compiler/check:reflVal", ptr %l171
  store %"compiler/check:reflVal" %t349, ptr %rv
  br label %ret
bb115:
  %t350 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t350, ptr %l175
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s0)
  %t351 = load %"compiler/check:reflVal", ptr %l175
  store %"compiler/check:reflVal" %t351, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflInt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %lp2 = alloca ptr
  %l5 = alloca %"compiler/check:reflVal"
  %l7 = alloca i1
  %l12 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
  store %"compiler/check:reflVal" %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store ptr %t6, ptr %lp2
  %t7 = load %"compiler/check:reflVal", ptr %l5
  %t8 = load ptr, ptr %lp2
  store %"compiler/check:reflVal" %t7, ptr %t8
  %t9 = load ptr, ptr %lp2
  %t10 = getelementptr %"compiler/check:reflVal", ptr %t9, i32 0, i32 0
  %t11 = load i1, ptr %t10, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load ptr, ptr %lp2
  %t14 = getelementptr %"compiler/check:reflVal", ptr %t13, i32 0, i32 1
  %t15 = load i64, ptr %t14, !tbaa !24
  %t16 = load i64, ptr @G_2ecompiler_2fcheck_2eRvInt, !tbaa !24
  %t19 = icmp eq i64 %t15, %t16
  store i1 %t19, ptr %l7, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t21 = load i1, ptr %l7, !tbaa !21
  br i1 %t21, label %bb5, label %bb6
bb5:
  %t22 = load ptr, ptr %lp2
  %t23 = load %"compiler/check:reflVal", ptr %t22
  store %"compiler/check:reflVal" %t23, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t25 = call %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v2)
  store %"compiler/check:reflVal" %t25, ptr %l12
  br label %bb8
bb8:
  %t26 = load %"compiler/check:reflVal", ptr %l12
  store %"compiler/check:reflVal" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i32, { i64, ptr } }
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca %"compiler/source:Span"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l38 = alloca { i64, ptr }
  %l40 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i32
  %l52 = alloca i32
  %l64 = alloca { i32, { i64, ptr } }
  %l66 = alloca { i64, ptr }
  %l67 = alloca i64
  %l68 = alloca { i64, ptr }
  %l70 = alloca i1
  %l72 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l77 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l83 = alloca %"compiler/msgs:Msg"
  %l84 = alloca i64
  %l87 = alloca ptr
  %l88 = alloca i1
  %l95 = alloca i32
  %l96 = alloca ptr
  %l97 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i1
  %l114 = alloca ptr
  %l116 = alloca ptr
  %l120 = alloca %"compiler/names:Ref"
  %l124 = alloca { i64, ptr }
  %l128 = alloca i1
  %l131 = alloca i1
  %l134 = alloca i32
  %l146 = alloca i32
  %l149 = alloca i32
  %l154 = alloca i1
  %l156 = alloca ptr
  %l160 = alloca %"compiler/source:Span"
  %l161 = alloca { i64, ptr }
  %l163 = alloca %"compiler/source:Span"
  %l166 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l175 = alloca i64
  %l177 = alloca i64
  %l178 = alloca %"compiler/msgs:Msg"
  %l179 = alloca i64
  %l182 = alloca ptr
  %l184 = alloca ptr
  %l189 = alloca i32
  %l193 = alloca i1
  %l197 = alloca i1
  %l199 = alloca i1
  %l203 = alloca i1
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  %t281 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i32 %t5, ptr %l22
  br label %bb1
bb1:
  %t6 = load i32, ptr %l22, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  %t7 = load i32, ptr %l2, !tbaa !23
  %t9 = icmp sge i32 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i32, ptr %l2, !tbaa !23
  store i32 %t11, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t14 = load ptr, ptr %l26, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load i64, ptr %t17
  %t20 = icmp eq i64 %t18, 15
  store i1 %t20, ptr %l27, !tbaa !21
  br label %bb6
bb6:
  %t21 = load i1, ptr %l27, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [5 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t24, i32 0, i32 0
  %t26 = load %"compiler/source:Span", ptr %t25
  store %"compiler/source:Span" %t26, ptr %l3
  %t28 = load ptr, ptr %l1, !tbaa !29
  %t30 = getelementptr { i64, [5 x i64] }, ptr %t28, i32 0, i32 1
  %t31 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t30, i32 0, i32 1
  %t32 = load ptr, ptr %t31
  store ptr %t32, ptr %l4, !tbaa !29
  %t34 = load ptr, ptr %l1, !tbaa !29
  %t36 = getelementptr { i64, [5 x i64] }, ptr %t34, i32 0, i32 1
  %t37 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t36, i32 0, i32 2
  %t38 = load i32, ptr %t37
  store i32 %t38, ptr %l5, !tbaa !23
  br label %bb9
bb8:
  br label %bb39
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t41 = load i32, ptr %l5, !tbaa !23
  %t44 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t40, i32 %t41)
  store { i64, ptr } %t44, ptr %l38
  br label %bb10
bb10:
  %t45 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t45, ptr %l6, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t48 = call i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %t46)
  store i1 %t48, ptr %l40
  br label %bb11
bb11:
  %t49 = load i1, ptr %l40, !tbaa !21
  %t50 = xor i1 %t49, true
  br i1 %t50, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s2)
  store i32 -1, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  store i32 -1, ptr %l7, !tbaa !23
  %t53 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s2, { i64, ptr } %t53, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t55, ptr %l44
  br label %bb15
bb15:
  %t56 = load i1, ptr %l44, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %t57, ptr %t58)
  store i32 %t61, ptr %l47
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t62 = load i32, ptr %l47, !tbaa !23
  store i32 %t62, ptr %l7, !tbaa !23
  br label %bb19
bb19:
  %t63 = load i32, ptr %l7, !tbaa !23
  %t65 = icmp slt i32 %t63, 0
  br i1 %t65, label %bb20, label %bb21
bb20:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t68 = load ptr, ptr %l4, !tbaa !29
  %t71 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t67, ptr %t68)
  store i32 %t71, ptr %l52
  br label %bb22
bb21:
  br label %bb23
bb22:
  %t72 = load i32, ptr %l52, !tbaa !23
  store i32 %t72, ptr %l7, !tbaa !23
  br label %bb23
bb23:
  %t73 = load i32, ptr %l7, !tbaa !23
  %t75 = icmp slt i32 %t73, 0
  br i1 %t75, label %bb24, label %bb25
bb24:
  %t77 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t77, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t79 = load i32, ptr %l7, !tbaa !23
  %t80 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t83 = icmp eq i32 %t79, %t80
  br i1 %t83, label %bb27, label %bb28
bb27:
  %t85 = load i32, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t85, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !29
  %t91 = load i32, ptr %l7, !tbaa !23
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v0, ptr %s2, ptr %t90, i32 %t91, { i64, ptr } %t92)
  store { i32, { i64, ptr } } %t96, ptr %l64
  br label %bb30
bb30:
  %t97 = load { i32, { i64, ptr } }, ptr %l64
  store { i32, { i64, ptr } } %t97, ptr %l8
  %t98 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 0
  %t99 = load i32, ptr %t98, !tbaa !23
  store i32 %t99, ptr %l9, !tbaa !23
  %t101 = getelementptr { i32, { i64, ptr } }, ptr %l8, i32 0, i32 1
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  store { i64, ptr } %t102, ptr %l66, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t103, 0
  store i64 %t104, ptr %l67, !tbaa !24
  %t105 = load i64, ptr %l67, !tbaa !24
  %t106 = mul i64 %t105, 1
  %t107 = call ptr @__olang_scope_alloc_zeroed(ptr %s2, i64 %t106)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  store { i64, ptr } %t109, ptr %l68, !tbaa !27
  %t110 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l67, !tbaa !24
  %t115 = mul i64 %t114, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t111, ptr %t113, i64 %t115, i1 false)
  %t116 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t116, ptr %l10, !tbaa !27
  %t117 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t119 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s2, ptr %s2, { i64, ptr } %t117, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t119, ptr %l70
  br label %bb31
bb31:
  %t120 = load i1, ptr %l70, !tbaa !21
  %t121 = xor i1 %t120, true
  br i1 %t121, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s8
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l72, !tbaa !29
  %t124 = load %"compiler/source:Span", ptr %l3
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t125, 0
  %t130 = call %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %t124, i64 %t127)
  store %"compiler/source:Span" %t130, ptr %l76
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t131, ptr %l77, !tbaa !27
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i32, ptr %l7, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t132, i32 %t133)
  store { i64, ptr } %t136, ptr %l80
  br label %bb35
bb35:
  %t137 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t148 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %s8, ptr %s2, ptr %s8, { i64, ptr } %t145, { i64, ptr } %t143, { i64, ptr } %t144)
  store %"compiler/msgs:Msg" %t148, ptr %l83
  br label %bb36
bb36:
  %t149 = load ptr, ptr %l72, !tbaa !29
  %t150 = load %"compiler/source:Span", ptr %l76
  %t151 = load %"compiler/msgs:Msg", ptr %l83
  %t152 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t149, %"compiler/source:Span" %t150, %"compiler/msgs:Msg" %t151)
  store i64 %t152, ptr %l84
  br label %bb37
bb37:
  %t153 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s2)
  store i32 %t153, ptr %rv
  br label %ret
bb38:
  %t155 = load i32, ptr %l9, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  store i32 %t155, ptr %rv
  br label %ret
bb39:
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l87, !tbaa !29
  store i1 false, ptr %l88, !tbaa !21
  %t158 = load ptr, ptr %l87, !tbaa !29
  %t159 = icmp ne ptr %t158, null
  br i1 %t159, label %bb40, label %bb41
bb40:
  %t161 = load ptr, ptr %l87, !tbaa !29
  %t162 = load i64, ptr %t161
  %t164 = icmp eq i64 %t162, 2
  store i1 %t164, ptr %l88, !tbaa !21
  br label %bb41
bb41:
  %t165 = load i1, ptr %l88, !tbaa !21
  br i1 %t165, label %bb42, label %bb43
bb42:
  %t166 = load ptr, ptr %l1, !tbaa !29
  %t168 = getelementptr { i64, [5 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", ptr }, ptr %t168, i32 0, i32 1
  %t170 = load ptr, ptr %t169
  store ptr %t170, ptr %l11, !tbaa !29
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load ptr, ptr %l11, !tbaa !29
  %t176 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflType(ptr %v0, ptr %v1, ptr %t172, ptr %t173)
  store i32 %t176, ptr %l95
  br label %bb45
bb45:
  %t177 = load i32, ptr %l95, !tbaa !23
  store i32 %t177, ptr %rv
  br label %ret
bb46:
  %t178 = load ptr, ptr %l1, !tbaa !29
  store ptr %t178, ptr %l96, !tbaa !29
  store i1 false, ptr %l97, !tbaa !21
  %t179 = load ptr, ptr %l96, !tbaa !29
  %t180 = icmp ne ptr %t179, null
  br i1 %t180, label %bb47, label %bb48
bb47:
  %t182 = load ptr, ptr %l96, !tbaa !29
  %t183 = load i64, ptr %t182
  %t185 = icmp eq i64 %t183, 14
  store i1 %t185, ptr %l97, !tbaa !21
  br label %bb48
bb48:
  %t186 = load i1, ptr %l97, !tbaa !21
  br i1 %t186, label %bb49, label %bb50
bb49:
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t189 = getelementptr { i64, [5 x i64] }, ptr %t187, i32 0, i32 1
  %t190 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t189, i32 0, i32 0
  %t191 = load %"compiler/source:Span", ptr %t190
  store %"compiler/source:Span" %t191, ptr %l12
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t195 = getelementptr { i64, [5 x i64] }, ptr %t193, i32 0, i32 1
  %t196 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t195, i32 0, i32 1
  %t197 = load ptr, ptr %t196
  store ptr %t197, ptr %l13, !tbaa !29
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr { i64, [5 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t201, i32 0, i32 2
  %t203 = load { i64, ptr }, ptr %t202
  store { i64, ptr } %t203, ptr %l14, !tbaa !27
  br label %bb51
bb50:
  br label %bb103
bb51:
  store i1 false, ptr %l15, !tbaa !21
  %t205 = load ptr, ptr %l13, !tbaa !29
  store ptr %t205, ptr %l106, !tbaa !29
  store i1 false, ptr %l107, !tbaa !21
  %t206 = load ptr, ptr %l106, !tbaa !29
  %t207 = icmp ne ptr %t206, null
  br i1 %t207, label %bb52, label %bb53
bb52:
  %t209 = load ptr, ptr %l106, !tbaa !29
  %t210 = load i64, ptr %t209
  %t212 = icmp eq i64 %t210, 0
  store i1 %t212, ptr %l107, !tbaa !21
  br label %bb53
bb53:
  %t213 = load i1, ptr %l107, !tbaa !21
  br i1 %t213, label %bb54, label %bb55
bb54:
  %t214 = load ptr, ptr %l13, !tbaa !29
  %t216 = getelementptr { i64, [5 x i64] }, ptr %t214, i32 0, i32 1
  %t217 = getelementptr { %"compiler/source:Span", i32 }, ptr %t216, i32 0, i32 0
  %t218 = load %"compiler/source:Span", ptr %t217
  store %"compiler/source:Span" %t218, ptr %l16
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr %"compiler/check:Checker", ptr %t220, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !29
  %t225 = getelementptr %"compiler/generic:Program", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  store ptr %t226, ptr %l114, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t227)
  store ptr %t229, ptr %l116
  br label %bb57
bb57:
  %t230 = load ptr, ptr %l116, !tbaa !29
  %t232 = getelementptr %"compiler/check:frame", ptr %t230, i32 0, i32 2
  %t233 = load i64, ptr %t232, !tbaa !24
  %t234 = getelementptr %"compiler/source:Span", ptr %l16, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  %t236 = load ptr, ptr %l114, !tbaa !29
  %t239 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t236, i64 %t233, i32 %t235)
  store %"compiler/names:Ref" %t239, ptr %l120
  br label %bb58
bb58:
  %t240 = getelementptr %"compiler/names:Ref", ptr %l120, i32 0, i32 0
  %t241 = load i32, ptr %t240
  %t243 = trunc i64 7 to i32
  %t244 = icmp eq i32 %t241, %t243
  store i1 %t244, ptr %l15, !tbaa !21
  br label %bb60
bb59:
  br label %bb60
bb60:
  %t246 = load ptr, ptr %l13, !tbaa !29
  %t248 = call { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v1, ptr %t246)
  store { i64, ptr } %t248, ptr %l124
  br label %bb61
bb61:
  %t249 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t249, ptr %l17, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t254 = icmp eq i64 %t252, 0
  br i1 %t254, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l128, !tbaa !21
  br label %bb68
bb63:
  %t256 = load i1, ptr %l15, !tbaa !21
  %t258 = xor i1 %t256, true
  br i1 %t258, label %bb64, label %bb65
bb64:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l13, !tbaa !29
  %t264 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t260, ptr %t261)
  store i32 %t264, ptr %l134
  br label %bb66
bb65:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb67
bb66:
  %t265 = load i32, ptr %l134, !tbaa !23
  %t266 = icmp slt i32 %t265, 0
  store i1 %t266, ptr %l131, !tbaa !21
  br label %bb67
bb67:
  %t268 = load i1, ptr %l131, !tbaa !21
  store i1 %t268, ptr %l128, !tbaa !21
  br label %bb68
bb68:
  %t269 = load i1, ptr %l128, !tbaa !21
  br i1 %t269, label %bb69, label %bb70
bb69:
  store i32 -1, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  %t271 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t275 = icmp eq i64 %t273, 1
  br i1 %t275, label %bb72, label %bb73
bb72:
  store %olang.scope zeroinitializer, ptr %s14
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load %"compiler/source:Span", ptr %l12
  %t279 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t281
  %t282 = getelementptr { i64, [5 x i64] }, ptr %t281, i32 0, i32 0
  store i64 0, ptr %t282
  %t284 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t278, 0
  %t286 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t284, { i64, ptr } %t279, 1
  %t288 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t286, { i64, ptr } %t280, 2
  %t289 = getelementptr { i64, [5 x i64] }, ptr %t281, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t288, ptr %t289
  %t290 = load { i64, [5 x i64] }, ptr %t281
  %t292 = call ptr @__olang_scope_alloc_a(ptr %s14, i64 48, i64 8)
  store { i64, [5 x i64] } %t290, ptr %t292
  %t295 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %s14, ptr %t277, ptr %t292)
  store i32 %t295, ptr %l146
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s14)
  %t296 = load i32, ptr %l146, !tbaa !23
  store i32 %t296, ptr %rv
  br label %ret
bb75:
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t301 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %t297, ptr %t298)
  store i32 %t301, ptr %l149
  br label %bb76
bb76:
  %t302 = load i32, ptr %l149, !tbaa !23
  store i32 %t302, ptr %l18, !tbaa !23
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t303, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t307 = load i32, ptr %l18, !tbaa !23
  %t308 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t312 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %t306, i32 %t307, { i64, ptr } %t308)
  store i1 %t312, ptr %l154
  br label %bb77
bb77:
  %t313 = load i1, ptr %l154, !tbaa !21
  %t314 = xor i1 %t313, true
  br i1 %t314, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s15
  %t316 = load ptr, ptr %l0, !tbaa !29
  store ptr %t316, ptr %l156, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t321 = icmp sgt i64 %t319, 0
  br i1 %t321, label %bb80, label %bb81
bb79:
  br label %bb89
bb80:
  %t323 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t323, ptr %l161, !tbaa !27
  %t324 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr ptr, ptr %t325, i64 0
  %t327 = load ptr, ptr %t326, !tbaa !39
  %t329 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t327)
  store %"compiler/source:Span" %t329, ptr %l163
  br label %bb82
bb81:
  %t330 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t330, ptr %l160
  br label %bb83
bb82:
  %t332 = load %"compiler/source:Span", ptr %l163
  store %"compiler/source:Span" %t332, ptr %l160
  br label %bb83
bb83:
  %t333 = load ptr, ptr %l0, !tbaa !29
  %t334 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t334, ptr %l166, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t339 = sub i64 %t337, 1
  %t341 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t342 = load ptr, ptr %t341, !tbaa !27
  %t343 = getelementptr i32, ptr %t342, i64 %t339
  %t344 = load i32, ptr %t343, !tbaa !33
  %t347 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %t333, i32 %t344)
  store { i64, ptr } %t347, ptr %l171
  br label %bb84
bb84:
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = getelementptr %"compiler/check:Checker", ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t352 = load i32, ptr %l18, !tbaa !23
  %t355 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %t351, i32 %t352)
  store i64 %t355, ptr %l175
  br label %bb85
bb85:
  %t356 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t358 = call i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v1, { i64, ptr } %t356)
  store i64 %t358, ptr %l177
  br label %bb86
bb86:
  %t359 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t360 = load i64, ptr %l175, !tbaa !24
  %t361 = load i64, ptr %l177, !tbaa !24
  %t362 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %s15, { i64, ptr } %t359, i64 %t360, i64 %t361)
  store %"compiler/msgs:Msg" %t362, ptr %l178
  br label %bb87
bb87:
  %t363 = load ptr, ptr %l156, !tbaa !29
  %t364 = load %"compiler/source:Span", ptr %l160
  %t365 = load %"compiler/msgs:Msg", ptr %l178
  %t366 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t363, %"compiler/source:Span" %t364, %"compiler/msgs:Msg" %t365)
  store i64 %t366, ptr %l179
  br label %bb88
bb88:
  %t367 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s15)
  store i32 %t367, ptr %rv
  br label %ret
bb89:
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t371 = getelementptr %"compiler/check:Checker", ptr %t369, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !29
  store ptr %t372, ptr %l182, !tbaa !29
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t373)
  store ptr %t375, ptr %l184
  br label %bb90
bb90:
  %t376 = load ptr, ptr %l184, !tbaa !29
  %t378 = getelementptr %"compiler/check:frame", ptr %t376, i32 0, i32 4
  %t379 = load i32, ptr %l18, !tbaa !23
  %t380 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t381 = load ptr, ptr %l182, !tbaa !29
  %t385 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v0, ptr %v1, ptr %t381, ptr %t378, i32 %t379, { i64, ptr } %t380)
  store i32 %t385, ptr %l189
  br label %bb91
bb91:
  %t386 = load i32, ptr %l189, !tbaa !23
  store i32 %t386, ptr %l19, !tbaa !23
  %t387 = load i32, ptr %l19, !tbaa !23
  %t388 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t391 = icmp eq i32 %t387, %t388
  br i1 %t391, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l193, !tbaa !21
  br label %bb95
bb93:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load i32, ptr %l19, !tbaa !23
  %t395 = load %"compiler/source:Span", ptr %l12
  %t399 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t393, i32 %t394, %"compiler/source:Span" %t395)
  store i1 %t399, ptr %l197
  br label %bb94
bb94:
  %t400 = load i1, ptr %l197, !tbaa !21
  %t401 = xor i1 %t400, true
  store i1 %t401, ptr %l193, !tbaa !21
  br label %bb95
bb95:
  %t403 = load i1, ptr %l193, !tbaa !21
  br i1 %t403, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l199, !tbaa !21
  br label %bb99
bb97:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t406 = getelementptr %"compiler/check:Checker", ptr %t404, i32 0, i32 1
  %t407 = load ptr, ptr %t406, !tbaa !29
  %t408 = load i32, ptr %l19, !tbaa !23
  %t411 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t407, i32 %t408)
  store i1 %t411, ptr %l203
  br label %bb98
bb98:
  %t412 = load i1, ptr %l203, !tbaa !21
  %t413 = xor i1 %t412, true
  store i1 %t413, ptr %l199, !tbaa !21
  br label %bb99
bb99:
  %t415 = load i1, ptr %l199, !tbaa !21
  br i1 %t415, label %bb100, label %bb101
bb100:
  %t416 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t416, ptr %rv
  br label %ret
bb101:
  br label %bb102
bb102:
  %t418 = load i32, ptr %l19, !tbaa !23
  store i32 %t418, ptr %rv
  br label %ret
bb103:
  store i32 -1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erenderPiece(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, [2 x i64] }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %lp10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca i64
  %l24 = alloca ptr
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l51 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l63 = alloca i64
  %l71 = alloca i64
  %l74 = alloca i64
  %l102 = alloca ptr
  %l105 = alloca i32
  %l109 = alloca i1
  %l114 = alloca i32
  %l117 = alloca i1
  %l122 = alloca i32
  %l125 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca ptr
  %t20 = alloca { i64, [2 x i64] }, align 8
  %t184 = alloca { i64, [2 x i64] }, align 8
  %t254 = alloca { i64, [5 x i64] }, align 8
  %t266 = alloca { i64, [2 x i64] }, align 8
  %t276 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load i64, ptr %l21, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sge i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l24, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l26
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load ptr, ptr %l24, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l26
  %t19 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtText(ptr %v0, ptr %t16, %"compiler/source:Span" %t17, i64 %t15)
  store ptr %t19, ptr %l28
  br label %bb5
bb5:
  store { i64, [2 x i64] } zeroinitializer, ptr %t20
  %t21 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 0
  store i64 1, ptr %t21
  %t22 = load ptr, ptr %l28, !tbaa !29
  %t23 = insertvalue { ptr } undef, ptr %t22, 0
  %t24 = getelementptr { i64, [2 x i64] }, ptr %t20, i32 0, i32 1
  store { ptr } %t23, ptr %t24
  %t25 = load { i64, [2 x i64] }, ptr %t20
  %t27 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t25, ptr %t27
  store ptr %t27, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erendered(ptr %v0, ptr %v1, ptr %t29, %"compiler/source:Span" %a1, ptr %t31)
  store ptr %t35, ptr %l34
  br label %bb7
bb7:
  %t36 = load ptr, ptr %l34, !tbaa !29
  store ptr %t36, ptr %l4, !tbaa !29
  %t37 = load ptr, ptr %l4, !tbaa !29
  store ptr %t37, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t38 = load ptr, ptr %l35, !tbaa !29
  %t39 = icmp ne ptr %t38, null
  br i1 %t39, label %bb8, label %bb9
bb8:
  %t41 = load ptr, ptr %l35, !tbaa !29
  %t42 = load i64, ptr %t41
  %t44 = icmp eq i64 %t42, 15
  store i1 %t44, ptr %l36, !tbaa !21
  br label %bb9
bb9:
  %t45 = load i1, ptr %l36, !tbaa !21
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t46 = load ptr, ptr %l4, !tbaa !29
  %t48 = getelementptr { i64, [5 x i64] }, ptr %t46, i32 0, i32 1
  %t49 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t48, i32 0, i32 2
  %t50 = load ptr, ptr %t49
  store ptr %t50, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb41
bb12:
  %t52 = load ptr, ptr %l5, !tbaa !29
  store ptr %t52, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t53 = load ptr, ptr %l41, !tbaa !29
  %t54 = icmp ne ptr %t53, null
  br i1 %t54, label %bb13, label %bb14
bb13:
  %t56 = load ptr, ptr %l41, !tbaa !29
  %t57 = load i64, ptr %t56
  %t59 = icmp eq i64 %t57, 0
  store i1 %t59, ptr %l42, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l42, !tbaa !21
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  %t64 = getelementptr { i32 }, ptr %t63, i32 0, i32 0
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l6, !tbaa !23
  br label %bb17
bb16:
  br label %bb39
bb17:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 11
  %t70 = load i32, ptr %l6, !tbaa !23
  %t72 = sext i32 %t70 to i64
  %t75 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v0, ptr %t69, i64 %t72)
  store ptr %t75, ptr %l51
  br label %bb18
bb18:
  %t76 = load ptr, ptr %l51, !tbaa !29
  %t78 = getelementptr %"compiler/typed:Body", ptr %t76, i32 0, i32 1
  %t79 = load { i64, [2 x i64] }, ptr %t78
  store { i64, [2 x i64] } %t79, ptr %l7
  %t81 = load { i64, [2 x i64] }, ptr %l7
  %t83 = extractvalue { i64, [2 x i64] } %t81, 0
  %t84 = icmp eq i64 %t83, 0
  br i1 %t84, label %bb19, label %bb20
bb19:
  %t86 = getelementptr { i64, [2 x i64] }, ptr %l7, i32 0, i32 1
  %t87 = getelementptr { i64 }, ptr %t86, i32 0, i32 0
  %t88 = load i64, ptr %t87
  store i64 %t88, ptr %l8, !tbaa !24
  br label %bb21
bb20:
  br label %bb37
bb21:
  store %olang.scope zeroinitializer, ptr %s4
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load i64, ptr %l8, !tbaa !24
  %t92 = load i32, ptr %l6, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t98 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigText(ptr %v0, ptr %s4, ptr %t90, i64 %t91, i64 %t94)
  store { i64, ptr } %t98, ptr %l61
  br label %bb22
bb22:
  %t99 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t99, ptr %l9, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  store i64 %t102, ptr %l63, !tbaa !24
  %t103 = load i64, ptr %l63, !tbaa !24
  %t104 = icmp sge i64 %t103, 0
  br i1 %t104, label %bb23, label %bb24
bb23:
  %t106 = load i64, ptr %l63, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t111, ptr %lp10
  %t113 = load ptr, ptr %lp10
  store { i64, ptr } %t110, ptr %t113, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t114, 0
  store i64 %t116, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t118 = load i64, ptr %l12, !tbaa !24
  %t119 = load i64, ptr %l11, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_db1f2ae5e4bef7a4_1fc823cb35fb1540)
  unreachable
bb25:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb27, label %bb28
bb26:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb30
bb27:
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l13, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l13, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l74, !tbaa !24
  br label %bb29
bb28:
  store i64 0, ptr %l74, !tbaa !24
  br label %bb29
bb29:
  %t144 = load i64, ptr %l74, !tbaa !24
  store i64 %t144, ptr %l71, !tbaa !24
  br label %bb30
bb30:
  %t145 = load i64, ptr %l71, !tbaa !24
  store i64 %t145, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t146 = load i64, ptr %l15, !tbaa !24
  %t147 = load i64, ptr %l14, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s6)
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t155 = load i64, ptr %l15, !tbaa !24
  %t156 = load i64, ptr %l13, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l16, !tbaa !24
  %t164 = load i64, ptr %l16, !tbaa !24
  %t165 = load i64, ptr %l16, !tbaa !24
  %t167 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr i8, ptr %t168, i64 %t165
  %t170 = load i8, ptr %t169, !tbaa !32
  %t173 = load ptr, ptr %lp10
  %t175 = getelementptr { i64, ptr }, ptr %t173, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i8, ptr %t176, i64 %t164
  store i8 %t170, ptr %t177, !tbaa !32
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb35:
  %t178 = load i64, ptr %l15, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l15, !tbaa !24
  br label %bb31
bb36:
  %t182 = load ptr, ptr %lp10
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t184
  %t185 = getelementptr { i64, [2 x i64] }, ptr %t184, i32 0, i32 0
  store i64 0, ptr %t185
  %t187 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t183, 0
  %t188 = getelementptr { i64, [2 x i64] }, ptr %t184, i32 0, i32 1
  store { { i64, ptr } } %t187, ptr %t188
  %t189 = load { i64, [2 x i64] }, ptr %t184
  %t191 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t189, ptr %t191
  call void @__olang_scope_close(ptr %s4)
  store ptr %t191, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb42
bb41:
  br label %bb42
bb42:
  %t193 = load ptr, ptr %l4, !tbaa !29
  %t195 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %t193)
  store ptr %t195, ptr %l102
  br label %bb43
bb43:
  %t196 = load ptr, ptr %l102, !tbaa !29
  store ptr %t196, ptr %l17, !tbaa !29
  %t197 = load ptr, ptr %l4, !tbaa !29
  %t200 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t197)
  store i32 %t200, ptr %l105
  br label %bb44
bb44:
  %t201 = load i32, ptr %l105, !tbaa !23
  store i32 %t201, ptr %l18, !tbaa !23
  %t202 = load ptr, ptr %l17, !tbaa !29
  %t204 = icmp eq ptr %t202, null
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb45, label %bb46
bb45:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 2
  %t214 = load i32, ptr %l18, !tbaa !23
  %t217 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t213, i32 %t214)
  store i32 %t217, ptr %l114
  br label %bb47
bb46:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb48
bb47:
  %t218 = load i32, ptr %l114
  %t220 = trunc i64 19 to i32
  %t221 = icmp eq i32 %t218, %t220
  store i1 %t221, ptr %l109, !tbaa !21
  br label %bb48
bb48:
  %t223 = load i1, ptr %l109, !tbaa !21
  br i1 %t223, label %bb49, label %bb50
bb49:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !29
  %t229 = getelementptr %"compiler/generic:Program", ptr %t227, i32 0, i32 2
  %t230 = load i32, ptr %l18, !tbaa !23
  %t233 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t229, i32 %t230)
  store i32 %t233, ptr %l122
  br label %bb51
bb50:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb52
bb51:
  %t234 = load i32, ptr %l122, !tbaa !23
  %t235 = icmp ne i32 %t234, 0
  store i1 %t235, ptr %l117, !tbaa !21
  br label %bb52
bb52:
  %t237 = load i1, ptr %l117, !tbaa !21
  br i1 %t237, label %bb53, label %bb54
bb53:
  %t238 = load ptr, ptr %l4, !tbaa !29
  %t240 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %t238)
  store %"compiler/source:Span" %t240, ptr %l125
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/check:Checker", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t246 = getelementptr %"compiler/generic:Program", ptr %t244, i32 0, i32 2
  %t247 = load i32, ptr %l18, !tbaa !23
  %t248 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t252 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t246, i32 %t247, i64 %t248)
  store i32 %t252, ptr %l131
  br label %bb56
bb56:
  %t253 = load ptr, ptr %l17, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 0
  store i64 3, ptr %t255
  %t256 = load %"compiler/source:Span", ptr %l125
  %t257 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t256, 0
  %t258 = load i32, ptr %l131, !tbaa !23
  %t259 = insertvalue { %"compiler/source:Span", i32, ptr } %t257, i32 %t258, 1
  %t261 = insertvalue { %"compiler/source:Span", i32, ptr } %t259, ptr %t253, 2
  %t262 = getelementptr { i64, [5 x i64] }, ptr %t254, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t261, ptr %t262
  %t263 = load { i64, [5 x i64] }, ptr %t254
  %t265 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t263, ptr %t265
  store { i64, [2 x i64] } zeroinitializer, ptr %t266
  %t267 = getelementptr { i64, [2 x i64] }, ptr %t266, i32 0, i32 0
  store i64 1, ptr %t267
  %t269 = insertvalue { ptr } undef, ptr %t265, 0
  %t270 = getelementptr { i64, [2 x i64] }, ptr %t266, i32 0, i32 1
  store { ptr } %t269, ptr %t270
  %t271 = load { i64, [2 x i64] }, ptr %t266
  %t273 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t271, ptr %t273
  store ptr %t273, ptr %rv
  br label %ret
bb57:
  %t275 = load ptr, ptr %l4, !tbaa !29
  store { i64, [2 x i64] } zeroinitializer, ptr %t276
  %t277 = getelementptr { i64, [2 x i64] }, ptr %t276, i32 0, i32 0
  store i64 1, ptr %t277
  %t279 = insertvalue { ptr } undef, ptr %t275, 0
  %t280 = getelementptr { i64, [2 x i64] }, ptr %t276, i32 0, i32 1
  store { ptr } %t279, ptr %t280
  %t281 = load { i64, [2 x i64] }, ptr %t276
  %t283 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 24, i64 8)
  store { i64, [2 x i64] } %t281, ptr %t283
  store ptr %t283, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l18 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l25 = alloca ptr
  %l31 = alloca i1
  %l32 = alloca i1
  %l36 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca i1
  %l47 = alloca i1
  %l48 = alloca ptr
  %l54 = alloca i1
  %l55 = alloca ptr
  %l56 = alloca i1
  %l63 = alloca i1
  %l64 = alloca ptr
  %l65 = alloca i1
  %l74 = alloca i1
  %l75 = alloca ptr
  %l81 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l90 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t21 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i1 %t21, ptr %l18
  br label %bb6
bb6:
  %t22 = load i1, ptr %l18, !tbaa !21
  store i1 %t22, ptr %l8, !tbaa !21
  br label %bb66
bb7:
  %t23 = load ptr, ptr %l1, !tbaa !29
  store ptr %t23, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t24 = load ptr, ptr %l19, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t27 = load ptr, ptr %l19, !tbaa !29
  %t28 = load i64, ptr %t27
  %t30 = icmp eq i64 %t28, 11
  store i1 %t30, ptr %l20, !tbaa !21
  br label %bb9
bb9:
  %t31 = load i1, ptr %l20, !tbaa !21
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t32 = load ptr, ptr %l1, !tbaa !29
  %t34 = getelementptr { i64, [5 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t34, i32 0, i32 2
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb21
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr %"compiler/typed:Cond", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t44 = icmp eq ptr %t42, null
  br i1 %t44, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_64f1128892bbfadb_2fd1650a543ec847)
  unreachable
bb14:
  br label %bb15
bb15:
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Cond", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t52 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t50, ptr %t49)
  store i1 %t52, ptr %l31
  br label %bb16
bb16:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb20
bb18:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = getelementptr %"compiler/typed:Cond", ptr %t55, i32 0, i32 2
  %t58 = load ptr, ptr %t57, !tbaa !29
  %t61 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t54, ptr %t58)
  store i1 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i1, ptr %l36, !tbaa !21
  store i1 %t62, ptr %l32, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l32, !tbaa !21
  store i1 %t63, ptr %l8, !tbaa !21
  br label %bb66
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  store ptr %t64, ptr %l37, !tbaa !29
  store i1 false, ptr %l38, !tbaa !21
  %t65 = load ptr, ptr %l37, !tbaa !29
  %t66 = icmp ne ptr %t65, null
  br i1 %t66, label %bb22, label %bb23
bb22:
  %t68 = load ptr, ptr %l37, !tbaa !29
  %t69 = load i64, ptr %t68
  %t71 = icmp eq i64 %t69, 12
  store i1 %t71, ptr %l38, !tbaa !21
  br label %bb23
bb23:
  %t72 = load i1, ptr %l38, !tbaa !21
  br i1 %t72, label %bb24, label %bb25
bb24:
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr { i64, [5 x i64] }, ptr %t73, i32 0, i32 1
  %t76 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t75, i32 0, i32 2
  %t77 = load ptr, ptr %t76
  store ptr %t77, ptr %l4, !tbaa !29
  br label %bb26
bb25:
  br label %bb34
bb26:
  %t79 = load ptr, ptr %l4, !tbaa !29
  %t81 = getelementptr %"compiler/typed:Seq", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = icmp eq ptr %t82, null
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb27, label %bb28
bb27:
  %t88 = load ptr, ptr %l0, !tbaa !29
  store ptr %t88, ptr %l48, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr %"compiler/typed:Seq", ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = icmp eq ptr %t92, null
  br i1 %t94, label %bb29, label %bb30
bb28:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb33
bb29:
  call void @__olang_check_failed(ptr @olang_loc_9b328daa59c12fec_530ed6f7b483a728)
  unreachable
bb30:
  br label %bb31
bb31:
  %t96 = load ptr, ptr %l4, !tbaa !29
  %t98 = getelementptr %"compiler/typed:Seq", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t100 = load ptr, ptr %l48, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t100, ptr %t99)
  store i1 %t102, ptr %l54
  br label %bb32
bb32:
  %t103 = load i1, ptr %l54, !tbaa !21
  store i1 %t103, ptr %l47, !tbaa !21
  br label %bb33
bb33:
  %t104 = load i1, ptr %l47, !tbaa !21
  store i1 %t104, ptr %l8, !tbaa !21
  br label %bb66
bb34:
  %t105 = load ptr, ptr %l1, !tbaa !29
  store ptr %t105, ptr %l55, !tbaa !29
  store i1 false, ptr %l56, !tbaa !21
  %t106 = load ptr, ptr %l55, !tbaa !29
  %t107 = icmp ne ptr %t106, null
  br i1 %t107, label %bb35, label %bb36
bb35:
  %t109 = load ptr, ptr %l55, !tbaa !29
  %t110 = load i64, ptr %t109
  %t112 = icmp eq i64 %t110, 13
  store i1 %t112, ptr %l56, !tbaa !21
  br label %bb36
bb36:
  %t113 = load i1, ptr %l56, !tbaa !21
  br i1 %t113, label %bb37, label %bb38
bb37:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t114, i32 0, i32 1
  %t117 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t116, i32 0, i32 2
  %t118 = load ptr, ptr %t117
  store ptr %t118, ptr %l5, !tbaa !29
  br label %bb39
bb38:
  br label %bb41
bb39:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load ptr, ptr %l5, !tbaa !29
  %t124 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %t120, ptr %t121)
  store i1 %t124, ptr %l63
  br label %bb40
bb40:
  %t125 = load i1, ptr %l63, !tbaa !21
  store i1 %t125, ptr %l8, !tbaa !21
  br label %bb66
bb41:
  %t126 = load ptr, ptr %l1, !tbaa !29
  store ptr %t126, ptr %l64, !tbaa !29
  store i1 false, ptr %l65, !tbaa !21
  %t127 = load ptr, ptr %l64, !tbaa !29
  %t128 = icmp ne ptr %t127, null
  br i1 %t128, label %bb42, label %bb43
bb42:
  %t130 = load ptr, ptr %l64, !tbaa !29
  %t131 = load i64, ptr %t130
  %t133 = icmp eq i64 %t131, 14
  store i1 %t133, ptr %l65, !tbaa !21
  br label %bb43
bb43:
  %t134 = load i1, ptr %l65, !tbaa !21
  br i1 %t134, label %bb44, label %bb45
bb44:
  %t135 = load ptr, ptr %l1, !tbaa !29
  %t137 = getelementptr { i64, [5 x i64] }, ptr %t135, i32 0, i32 1
  %t138 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t137, i32 0, i32 2
  %t139 = load ptr, ptr %t138
  store ptr %t139, ptr %l6, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t141 = load ptr, ptr %l6, !tbaa !29
  %t143 = getelementptr %"compiler/typed:Try", ptr %t141, i32 0, i32 0
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb47, label %bb48
bb47:
  %t150 = load ptr, ptr %l0, !tbaa !29
  store ptr %t150, ptr %l75, !tbaa !29
  %t151 = load ptr, ptr %l6, !tbaa !29
  %t153 = getelementptr %"compiler/typed:Try", ptr %t151, i32 0, i32 0
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = icmp eq ptr %t154, null
  br i1 %t156, label %bb49, label %bb50
bb48:
  store i1 false, ptr %l74, !tbaa !21
  br label %bb53
bb49:
  call void @__olang_check_failed(ptr @olang_loc_aa71917389f82fa1_ab8db462134cc7fd)
  unreachable
bb50:
  br label %bb51
bb51:
  %t158 = load ptr, ptr %l6, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Try", ptr %t158, i32 0, i32 0
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load ptr, ptr %l75, !tbaa !29
  %t164 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCopied(ptr %v0, ptr %v1, ptr %t162, ptr %t161)
  store i1 %t164, ptr %l81
  br label %bb52
bb52:
  %t165 = load i1, ptr %l81, !tbaa !21
  store i1 %t165, ptr %l74, !tbaa !21
  br label %bb53
bb53:
  %t166 = load i1, ptr %l74, !tbaa !21
  store i1 %t166, ptr %l8, !tbaa !21
  br label %bb66
bb54:
  %t167 = load ptr, ptr %l1, !tbaa !29
  store ptr %t167, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t168 = load ptr, ptr %l82, !tbaa !29
  %t169 = icmp ne ptr %t168, null
  br i1 %t169, label %bb55, label %bb56
bb55:
  %t171 = load ptr, ptr %l82, !tbaa !29
  %t172 = load i64, ptr %t171
  %t174 = icmp eq i64 %t172, 6
  store i1 %t174, ptr %l83, !tbaa !21
  br label %bb56
bb56:
  %t175 = load i1, ptr %l83, !tbaa !21
  br i1 %t175, label %bb57, label %bb58
bb57:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t178 = getelementptr { i64, [5 x i64] }, ptr %t176, i32 0, i32 1
  %t179 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t178, i32 0, i32 2
  %t180 = load ptr, ptr %t179
  store ptr %t180, ptr %l7, !tbaa !29
  br label %bb59
bb58:
  br label %bb61
bb59:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load ptr, ptr %l7, !tbaa !29
  %t186 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %t182, ptr %t183)
  store i1 %t186, ptr %l90
  br label %bb60
bb60:
  %t187 = load i1, ptr %l90, !tbaa !21
  store i1 %t187, ptr %l8, !tbaa !21
  br label %bb66
bb61:
  br i1 true, label %bb62, label %bb63
bb62:
  br label %bb64
bb63:
  br label %bb65
bb64:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_45c1f7cb36e76579_9732da1c199d4515)
  unreachable
bb66:
  %t188 = load i1, ptr %l8, !tbaa !21
  store i1 %t188, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroDeepNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l5 = alloca i1
  %l6 = alloca ptr
  %l8 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i32
  %l26 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l35 = alloca %"std/pair:Pair.1eb2466213689e002f25e81e83536e78"
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb5
bb2:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t6)
  store ptr %t8, ptr %l8
  br label %bb3
bb3:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t11 = getelementptr %"compiler/check:frame", ptr %t9, i32 0, i32 0
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = load ptr, ptr %l6, !tbaa !29
  %t15 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t13, i64 %t12)
  store i1 %t15, ptr %l11
  br label %bb4
bb4:
  %t16 = load i1, ptr %l11, !tbaa !21
  %t17 = xor i1 %t16, true
  store i1 %t17, ptr %l5, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l5, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t23 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t20)
  store i32 %t23, ptr %l15
  br label %bb9
bb9:
  %t24 = load i32, ptr %l15, !tbaa !23
  store i32 %t24, ptr %l2, !tbaa !23
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t29 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t25, i32 %t26)
  store i1 %t29, ptr %l18
  br label %bb10
bb10:
  %t30 = load i1, ptr %l18, !tbaa !21
  br i1 %t30, label %bb11, label %bb12
bb11:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t36 = getelementptr %"compiler/generic:Program", ptr %t34, i32 0, i32 2
  %t37 = load i32, ptr %l2, !tbaa !23
  %t40 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t36, i32 %t37)
  store i32 %t40, ptr %l23
  br label %bb13
bb12:
  br label %bb14
bb13:
  %t41 = load i32, ptr %l23, !tbaa !23
  store i32 %t41, ptr %l2, !tbaa !23
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l2, !tbaa !23
  %t46 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l26
  br label %bb15
bb15:
  %t47 = load i1, ptr %l26, !tbaa !21
  %t48 = xor i1 %t47, true
  br i1 %t48, label %bb16, label %bb17
bb16:
  br label %ret
bb17:
  br label %bb18
bb18:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t50, i32 0, i32 67
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t53)
  store ptr %t55, ptr %l31
  br label %bb19
bb19:
  %t56 = load ptr, ptr %l31, !tbaa !29
  %t58 = getelementptr %"compiler/check:frame", ptr %t56, i32 0, i32 0
  %t59 = load i64, ptr %t58, !tbaa !24
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t63 = call %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v1, ptr %v0, i64 %t59, ptr %t60)
  store %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t63, ptr %l35
  br label %bb20
bb20:
  %t64 = load ptr, ptr %l29, !tbaa !29
  %t65 = load %"std/pair:Pair.1eb2466213689e002f25e81e83536e78", ptr %l35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_H33d643ee420c12f578033f46e688097e(ptr %v0, ptr %v0, ptr %t64, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %t65)
  br label %bb21
bb21:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l4 = alloca ptr
  %l7 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l8 = alloca i1
  %l13 = alloca i1
  %l14 = alloca i1
  %l18 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 65
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  %t8 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t4, i64 %t5)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t8, ptr %l7
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t10 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l7
  %t11 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t9, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t10)
  store i1 %t11, ptr %l8
  br label %bb2
bb2:
  %t12 = load i1, ptr %l8, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t20 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t14, i64 %t15, i64 %t16)
  store i1 %t20, ptr %l13
  br label %bb6
bb6:
  %t21 = load i1, ptr %l13, !tbaa !21
  br i1 %t21, label %bb7, label %bb8
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 16
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t24, i64 %t25)
  store i64 %t28, ptr %l18
  br label %bb9
bb8:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb10
bb9:
  %t29 = load i64, ptr %l18, !tbaa !24
  %t30 = icmp ne i64 %t29, 2
  store i1 %t30, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i1, ptr %l14, !tbaa !21
  store i1 %t32, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l7 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l19 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i32
  %l28 = alloca i1
  %l33 = alloca i32
  %l38 = alloca i32
  %l41 = alloca i1
  %l46 = alloca i32
  %l50 = alloca ptr
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca i32
  %l64 = alloca i64
  %l65 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7
  %t13 = trunc i64 19 to i32
  %t14 = icmp eq i32 %t11, %t13
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  %t22 = load i32, ptr %l1, !tbaa !23
  %t25 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t25, ptr %l15
  br label %bb4
bb3:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb5
bb4:
  %t26 = load i32, ptr %l15, !tbaa !23
  %t27 = icmp ne i32 %t26, 0
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb5
bb5:
  %t29 = load i1, ptr %l10, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  store ptr %t35, ptr %l19, !tbaa !29
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t41 = getelementptr %"compiler/generic:Program", ptr %t39, i32 0, i32 2
  %t42 = load i32, ptr %l1, !tbaa !23
  %t45 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t45, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t46 = load ptr, ptr %l19, !tbaa !29
  %t47 = load i32, ptr %l24, !tbaa !23
  %t48 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t46, i32 %t47, i32 0)
  store i32 %t48, ptr %l25
  br label %bb9
bb9:
  %t49 = load i32, ptr %l25, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
bb10:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l1, !tbaa !23
  %t54 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t50, i32 %t51)
  store i1 %t54, ptr %l28
  br label %bb11
bb11:
  %t55 = load i1, ptr %l28, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t61, i32 %t62)
  store i32 %t65, ptr %l33
  br label %bb14
bb13:
  br label %bb27
bb14:
  %t66 = load i32, ptr %l33, !tbaa !23
  store i32 %t66, ptr %l2, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l2, !tbaa !23
  %t76 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t72, i32 %t73)
  store i32 %t76, ptr %l38
  br label %bb15
bb15:
  %t77 = load i32, ptr %l38
  %t79 = trunc i64 19 to i32
  %t80 = icmp eq i32 %t77, %t79
  br i1 %t80, label %bb16, label %bb17
bb16:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  %t87 = getelementptr %"compiler/generic:Program", ptr %t85, i32 0, i32 2
  %t88 = load i32, ptr %l2, !tbaa !23
  %t91 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t87, i32 %t88)
  store i32 %t91, ptr %l46
  br label %bb18
bb17:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb19
bb18:
  %t92 = load i32, ptr %l46, !tbaa !23
  %t93 = icmp ne i32 %t92, 0
  store i1 %t93, ptr %l41, !tbaa !21
  br label %bb19
bb19:
  %t95 = load i1, ptr %l41, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/check:Checker", ptr %t96, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = getelementptr %"compiler/generic:Program", ptr %t99, i32 0, i32 2
  store ptr %t101, ptr %l50, !tbaa !29
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = getelementptr %"compiler/generic:Program", ptr %t105, i32 0, i32 2
  store ptr %t107, ptr %l53, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l2, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l58
  br label %bb22
bb21:
  br label %bb26
bb22:
  %t118 = load ptr, ptr %l53, !tbaa !29
  %t119 = load i32, ptr %l58, !tbaa !23
  %t120 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t118, i32 %t119, i32 0)
  store i32 %t120, ptr %l59
  br label %bb23
bb23:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l1, !tbaa !23
  %t130 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t126, i32 %t127)
  store i64 %t130, ptr %l64
  br label %bb24
bb24:
  %t131 = load ptr, ptr %l50, !tbaa !29
  %t132 = load i32, ptr %l59, !tbaa !23
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t131, i32 %t132, i64 %t133)
  store i32 %t134, ptr %l65
  br label %bb25
bb25:
  %t135 = load i32, ptr %l65, !tbaa !23
  store i32 %t135, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t136 = load i32, ptr %l1, !tbaa !23
  store i32 %t136, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l26 = alloca i32
  %l31 = alloca i64
  %l34 = alloca i64
  %l54 = alloca i1
  %l62 = alloca i64
  %l65 = alloca %"compiler/source:Span"
  %l70 = alloca i32
  %l74 = alloca ptr
  %l81 = alloca i32
  %l86 = alloca i32
  %l93 = alloca i1
  %l96 = alloca i1
  %l100 = alloca ptr
  %l103 = alloca i64
  %l109 = alloca i1
  %l111 = alloca ptr
  %l112 = alloca %"compiler/source:Span"
  %l115 = alloca { i64, ptr }
  %l117 = alloca %"compiler/msgs:Msg"
  %l118 = alloca i64
  %l121 = alloca ptr
  %l124 = alloca i64
  %l127 = alloca i1
  %l134 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l139 = alloca %"compiler/source:Span"
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca ptr
  %l145 = alloca ptr
  %l147 = alloca i32
  %l148 = alloca ptr
  %l150 = alloca %"compiler/source:Span"
  %l151 = alloca ptr
  %l154 = alloca ptr
  %l155 = alloca %"compiler/source:Span"
  %l156 = alloca %"compiler/source:Span"
  %l157 = alloca i64
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l174 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca i32
  %l179 = alloca ptr
  %l181 = alloca %"compiler/source:Span"
  %l182 = alloca ptr
  %l186 = alloca i64
  %l191 = alloca ptr
  %l195 = alloca ptr
  %l196 = alloca %"compiler/source:Span"
  %l197 = alloca %"compiler/source:Span"
  %l198 = alloca i64
  %l202 = alloca ptr
  %l203 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l214 = alloca ptr
  %l217 = alloca ptr
  %l218 = alloca %"compiler/source:Span"
  %l220 = alloca i32
  %l221 = alloca ptr
  %l223 = alloca ptr
  %l224 = alloca ptr
  %l226 = alloca i32
  %l227 = alloca ptr
  %l231 = alloca ptr
  %l232 = alloca %"compiler/source:Span"
  %l234 = alloca i32
  %l235 = alloca i32
  %l236 = alloca %"compiler/source:Span"
  %l242 = alloca i32
  %l246 = alloca ptr
  %l248 = alloca ptr
  %l249 = alloca ptr
  %l251 = alloca i32
  %l252 = alloca ptr
  %l256 = alloca i1
  %l257 = alloca i32
  %l261 = alloca ptr
  %l266 = alloca i32
  %l269 = alloca i32
  %l274 = alloca i32
  %l275 = alloca i32
  %l276 = alloca %"compiler/source:Span"
  %l282 = alloca i32
  %l283 = alloca ptr
  %l286 = alloca ptr
  %l291 = alloca %"compiler/typed:Slice"
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca ptr
  %t100 = alloca { i64, [4 x i64] }, align 8
  %t456 = alloca { i64, [5 x i64] }, align 8
  %t559 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a2, ptr %l6, !tbaa !29
  %t3 = load ptr, ptr %l6, !tbaa !29
  %t5 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %t3)
  store i32 %t5, ptr %l26
  br label %bb1
bb1:
  %t6 = load i32, ptr %l26, !tbaa !23
  store i32 %t6, ptr %l7, !tbaa !23
  %t7 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  store i64 %t7, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  store i64 4, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t9 = load i64, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb2, label %bb3
bb2:
  %t15 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb7
bb4:
  %t19 = load i64, ptr %l10, !tbaa !24
  %t20 = load i64, ptr %l9, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l11, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l11, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l34, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb6
bb6:
  %t35 = load i64, ptr %l34, !tbaa !24
  store i64 %t35, ptr %l31, !tbaa !24
  br label %bb7
bb7:
  %t36 = load i64, ptr %l31, !tbaa !24
  store i64 %t36, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l13, !tbaa !24
  %t38 = load i64, ptr %l12, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb10:
  br label %bb11
bb11:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t46 = load i64, ptr %l13, !tbaa !24
  %t47 = load i64, ptr %l11, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l14, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t56 = load i32, ptr %l7, !tbaa !23
  %t59 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t55, i32 %t56)
  store i1 %t59, ptr %l54
  br label %bb12
bb12:
  %t60 = load i1, ptr %l54, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb14:
  br label %bb15
bb15:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v0, ptr %t63, ptr %t64)
  br label %bb16
bb16:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 2
  %t73 = load i32, ptr %l7, !tbaa !23
  %t76 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t72, i32 %t73)
  store i64 %t76, ptr %l62
  br label %bb17
bb17:
  %t77 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t78 = load i64, ptr %l62, !tbaa !24
  %t80 = and i64 %t78, %t77
  store i64 %t80, ptr %l8, !tbaa !24
  %t82 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t82, ptr %l65
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t83, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l7, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l70
  br label %bb18
bb18:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load %"compiler/source:Span", ptr %l1
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t99 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t93, %"compiler/source:Span" %t94, ptr %t95)
  store ptr %t99, ptr %l74
  br label %bb19
bb19:
  store { i64, [4 x i64] } zeroinitializer, ptr %t100
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 0
  store i64 2, ptr %t101
  %t102 = load %"compiler/source:Span", ptr %l65
  %t103 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t102, 0
  %t104 = load i32, ptr %l70, !tbaa !23
  %t105 = insertvalue { %"compiler/source:Span", i32, ptr } %t103, i32 %t104, 1
  %t106 = load ptr, ptr %l74, !tbaa !29
  %t107 = insertvalue { %"compiler/source:Span", i32, ptr } %t105, ptr %t106, 2
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t100, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t107, ptr %t108
  %t109 = load { i64, [4 x i64] }, ptr %t100
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t109, ptr %t111
  store ptr %t111, ptr %l6, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/check:Checker", ptr %t113, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !29
  %t118 = getelementptr %"compiler/generic:Program", ptr %t116, i32 0, i32 2
  %t119 = load i32, ptr %l7, !tbaa !23
  %t122 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t118, i32 %t119)
  store i32 %t122, ptr %l81
  br label %bb20
bb20:
  %t123 = load i32, ptr %l81, !tbaa !23
  store i32 %t123, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t124 = load i64, ptr %l13, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l13, !tbaa !24
  br label %bb8
bb22:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l7, !tbaa !23
  %t132 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %t128, i32 %t129)
  store i32 %t132, ptr %l86
  br label %bb23
bb23:
  %t133 = load i32, ptr %l86, !tbaa !23
  store i32 %t133, ptr %l15, !tbaa !23
  %t134 = load i32, ptr %l15, !tbaa !23
  %t135 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t138 = icmp eq i32 %t134, %t135
  br i1 %t138, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t140 = load i32, ptr %l7, !tbaa !23
  %t141 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t144 = icmp eq i32 %t140, %t141
  br i1 %t144, label %bb26, label %bb27
bb25:
  br label %bb102
bb26:
  store i1 true, ptr %l93, !tbaa !21
  br label %bb29
bb27:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t147 = load i32, ptr %l7, !tbaa !23
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t146, i32 %t147)
  store i1 %t150, ptr %l96
  br label %bb28
bb28:
  %t151 = load i1, ptr %l96, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l93, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l93, !tbaa !21
  br i1 %t154, label %bb30, label %bb31
bb30:
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t156 = load %"compiler/source:Span", ptr %l1
  %t159 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t155, %"compiler/source:Span" %t156)
  store ptr %t159, ptr %l100
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s5)
  %t160 = load ptr, ptr %l100, !tbaa !29
  store ptr %t160, ptr %rv
  br label %ret
bb33:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load i32, ptr %l7, !tbaa !23
  %t165 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t161, i32 %t162, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d42, i32 0, i32 1) }, i64 2)
  store i64 %t165, ptr %l103
  br label %bb34
bb34:
  %t166 = load i64, ptr %l103, !tbaa !24
  store i64 %t166, ptr %l16, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp slt i64 %t167, 0
  br i1 %t169, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s7
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t172 = load i32, ptr %l7, !tbaa !23
  %t173 = load %"compiler/source:Span", ptr %l1
  %t177 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %s7, ptr %s7, ptr %t171, i32 %t172, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) }, %"compiler/source:Span" %t173, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) }, i64 2, i1 false)
  store i1 %t177, ptr %l109
  br label %bb37
bb36:
  br label %bb45
bb37:
  %t178 = load i1, ptr %l109, !tbaa !21
  %t179 = xor i1 %t178, true
  br i1 %t179, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t181 = load ptr, ptr %l0, !tbaa !29
  store ptr %t181, ptr %l111, !tbaa !29
  %t182 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t182, ptr %l112
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t184 = load i32, ptr %l7, !tbaa !23
  %t187 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s8, ptr %t183, i32 %t184)
  store { i64, ptr } %t187, ptr %l115
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t188 = load { i64, ptr }, ptr %l115, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  %t196 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %s8, ptr %s8, { i64, ptr } %t194)
  store %"compiler/msgs:Msg" %t196, ptr %l117
  br label %bb41
bb41:
  %t197 = load ptr, ptr %l111, !tbaa !29
  %t198 = load %"compiler/source:Span", ptr %l112
  %t199 = load %"compiler/msgs:Msg", ptr %l117
  %t200 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s8, ptr %t197, %"compiler/source:Span" %t198, %"compiler/msgs:Msg" %t199)
  store i64 %t200, ptr %l118
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb43
bb43:
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t202 = load %"compiler/source:Span", ptr %l1
  %t205 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t201, %"compiler/source:Span" %t202)
  store ptr %t205, ptr %l121
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s5)
  %t206 = load ptr, ptr %l121, !tbaa !29
  store ptr %t206, ptr %rv
  br label %ret
bb45:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l7, !tbaa !23
  %t211 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s5, ptr %t207, i32 %t208, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) }, i64 0)
  store i64 %t211, ptr %l124
  br label %bb46
bb46:
  %t212 = load i64, ptr %l124, !tbaa !24
  store i64 %t212, ptr %l17, !tbaa !24
  %t213 = load ptr, ptr %l4, !tbaa !29
  %t215 = icmp eq ptr %t213, null
  br i1 %t215, label %bb47, label %bb48
bb47:
  %t217 = load i64, ptr %l17, !tbaa !24
  %t219 = icmp slt i64 %t217, 0
  store i1 %t219, ptr %l127, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l127, !tbaa !21
  br label %bb49
bb49:
  %t221 = load i1, ptr %l127, !tbaa !21
  br i1 %t221, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s9
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load %"compiler/source:Span", ptr %l1
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s9, ptr %t222, %"compiler/source:Span" %t223, { i64, ptr } { i64 47, ptr getelementptr inbounds (<{ i64, [47 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb52
bb51:
  br label %bb54
bb52:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l1
  %t230 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %t226, %"compiler/source:Span" %t227)
  store ptr %t230, ptr %l134
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s5)
  %t231 = load ptr, ptr %l134, !tbaa !29
  store ptr %t231, ptr %rv
  br label %ret
bb54:
  %t232 = load ptr, ptr %l3, !tbaa !29
  %t234 = icmp eq ptr %t232, null
  br i1 %t234, label %bb55, label %bb56
bb55:
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l138, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t237, ptr %l139
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t240 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t238)
  store i32 %t240, ptr %l141
  br label %bb57
bb56:
  %t241 = load ptr, ptr %l0, !tbaa !29
  store ptr %t241, ptr %l143, !tbaa !29
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l144, !tbaa !29
  %t243 = load ptr, ptr %l3, !tbaa !29
  store ptr %t243, ptr %l145, !tbaa !29
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t244)
  store i32 %t246, ptr %l147
  br label %bb59
bb57:
  %t247 = load ptr, ptr %l138, !tbaa !29
  %t248 = load %"compiler/source:Span", ptr %l139
  %t249 = load i32, ptr %l141, !tbaa !23
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t247, %"compiler/source:Span" %t248, i32 %t249, i64 0)
  store ptr %t250, ptr %l142
  br label %bb58
bb58:
  %t251 = load ptr, ptr %l142, !tbaa !29
  store ptr %t251, ptr %l137, !tbaa !29
  br label %bb63
bb59:
  %t252 = load ptr, ptr %l144, !tbaa !29
  %t253 = load ptr, ptr %l145, !tbaa !29
  %t254 = load i32, ptr %l147, !tbaa !23
  %t255 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t252, ptr %t253, i32 %t254)
  store ptr %t255, ptr %l148
  br label %bb60
bb60:
  %t256 = load ptr, ptr %l3, !tbaa !29
  %t258 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t256)
  store %"compiler/source:Span" %t258, ptr %l150
  br label %bb61
bb61:
  %t259 = load ptr, ptr %l143, !tbaa !29
  %t260 = load ptr, ptr %l148, !tbaa !29
  %t261 = load %"compiler/source:Span", ptr %l150
  %t262 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t259, ptr %t260, %"compiler/source:Span" %t261)
  store ptr %t262, ptr %l151
  br label %bb62
bb62:
  %t263 = load ptr, ptr %l151, !tbaa !29
  store ptr %t263, ptr %l137, !tbaa !29
  br label %bb63
bb63:
  %t264 = load ptr, ptr %l137, !tbaa !29
  store ptr %t264, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t265 = load ptr, ptr %l4, !tbaa !29
  %t267 = icmp eq ptr %t265, null
  br i1 %t267, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s10
  %t269 = load ptr, ptr %l0, !tbaa !29
  store ptr %t269, ptr %l154, !tbaa !29
  %t270 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t270, ptr %l155
  %t271 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t271, ptr %l156
  %t272 = load i64, ptr %l17, !tbaa !24
  store i64 %t272, ptr %l157, !tbaa !24
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load %"compiler/source:Span", ptr %l1
  %t275 = load ptr, ptr %l6, !tbaa !29
  %t279 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t273, %"compiler/source:Span" %t274, ptr %t275)
  store ptr %t279, ptr %l161
  br label %bb66
bb65:
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l174, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  store ptr %t281, ptr %l175, !tbaa !29
  %t282 = load ptr, ptr %l4, !tbaa !29
  store ptr %t282, ptr %l176, !tbaa !29
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t283)
  store i32 %t285, ptr %l178
  br label %bb80
bb66:
  %t286 = load ptr, ptr %l161, !tbaa !29
  store ptr %t286, ptr %l162, !tbaa !29
  %t287 = icmp sge i64 0, 0
  br i1 %t287, label %bb67, label %bb68
bb67:
  %t289 = icmp sle i64 0, 1152921504606846975
  br i1 %t289, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb69:
  %t291 = mul i64 0, 8
  %t292 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t291)
  %t293 = insertvalue { i64, ptr } undef, i64 0, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  store { i64, ptr } %t294, ptr %l165, !tbaa !27
  %t295 = icmp sge i64 0, 0
  br i1 %t295, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb71:
  %t297 = icmp sle i64 0, 1152921504606846975
  br i1 %t297, label %bb73, label %bb74
bb72:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb73:
  %t299 = mul i64 0, 8
  %t300 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t299)
  %t301 = insertvalue { i64, ptr } undef, i64 0, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t300, 1
  store { i64, ptr } %t302, ptr %l168, !tbaa !27
  %t303 = icmp sge i64 0, 0
  br i1 %t303, label %bb75, label %bb76
bb74:
  call void @__olang_check_failed(ptr @olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb)
  unreachable
bb75:
  %t305 = icmp sle i64 0, 2305843009213693951
  br i1 %t305, label %bb77, label %bb78
bb76:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb77:
  %t307 = mul i64 0, 4
  %t308 = call ptr @__olang_scope_alloc_zeroed(ptr %s10, i64 %t307)
  %t309 = insertvalue { i64, ptr } undef, i64 0, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  %t311 = load ptr, ptr %l154, !tbaa !29
  %t312 = load %"compiler/source:Span", ptr %l155
  %t313 = load %"compiler/source:Span", ptr %l156
  %t314 = load i64, ptr %l157, !tbaa !24
  %t315 = load ptr, ptr %l162, !tbaa !29
  %t316 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t317 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t319 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s10, ptr %t311, %"compiler/source:Span" %t312, %"compiler/source:Span" %t313, i64 %t314, ptr %t315, { i64, ptr } %t316, { i64, ptr } %t317, { i64, ptr } %t310)
  store ptr %t319, ptr %l172
  br label %bb79
bb78:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb79:
  %t320 = load ptr, ptr %l172, !tbaa !29
  store ptr %t320, ptr %l19, !tbaa !29
  call void @__olang_scope_close(ptr %s10)
  br label %bb84
bb80:
  %t322 = load ptr, ptr %l175, !tbaa !29
  %t323 = load ptr, ptr %l176, !tbaa !29
  %t324 = load i32, ptr %l178, !tbaa !23
  %t325 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t322, ptr %t323, i32 %t324)
  store ptr %t325, ptr %l179
  br label %bb81
bb81:
  %t326 = load ptr, ptr %l4, !tbaa !29
  %t328 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t326)
  store %"compiler/source:Span" %t328, ptr %l181
  br label %bb82
bb82:
  %t329 = load ptr, ptr %l174, !tbaa !29
  %t330 = load ptr, ptr %l179, !tbaa !29
  %t331 = load %"compiler/source:Span", ptr %l181
  %t332 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %t329, ptr %t330, %"compiler/source:Span" %t331)
  store ptr %t332, ptr %l182
  br label %bb83
bb83:
  %t333 = load ptr, ptr %l182, !tbaa !29
  store ptr %t333, ptr %l19, !tbaa !29
  br label %bb84
bb84:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = getelementptr %"compiler/check:Checker", ptr %t335, i32 0, i32 32
  %t339 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t337)
  store i64 %t339, ptr %l186
  br label %bb85
bb85:
  %t340 = load i64, ptr %l186, !tbaa !24
  store i64 %t340, ptr %l20, !tbaa !24
  %t341 = load ptr, ptr %l0, !tbaa !29
  %t343 = getelementptr %"compiler/check:Checker", ptr %t341, i32 0, i32 32
  %t344 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t343, ptr %t344)
  br label %bb86
bb86:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/check:Checker", ptr %t347, i32 0, i32 32
  store ptr %t349, ptr %l191, !tbaa !29
  %t350 = load ptr, ptr %l19, !tbaa !29
  %t352 = icmp eq ptr %t350, null
  br i1 %t352, label %bb87, label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_b203c9fbf4c249fb_735051f472c86bf)
  unreachable
bb88:
  br label %bb89
bb89:
  %t354 = load ptr, ptr %l19, !tbaa !29
  %t355 = load ptr, ptr %l191, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v0, ptr %t355, ptr %t354)
  br label %bb90
bb90:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l195, !tbaa !29
  %t358 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t358, ptr %l196
  %t359 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t359, ptr %l197
  %t360 = load i64, ptr %l16, !tbaa !24
  store i64 %t360, ptr %l198, !tbaa !24
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t362 = load %"compiler/source:Span", ptr %l1
  %t363 = load ptr, ptr %l6, !tbaa !29
  %t367 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %t361, %"compiler/source:Span" %t362, ptr %t363)
  store ptr %t367, ptr %l202
  br label %bb91
bb91:
  %t368 = load ptr, ptr %l202, !tbaa !29
  store ptr %t368, ptr %l203, !tbaa !29
  %t369 = icmp sge i64 0, 0
  br i1 %t369, label %bb92, label %bb93
bb92:
  %t371 = icmp sle i64 0, 1152921504606846975
  br i1 %t371, label %bb94, label %bb95
bb93:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb94:
  %t373 = mul i64 0, 8
  %t374 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t373)
  %t375 = insertvalue { i64, ptr } undef, i64 0, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  store { i64, ptr } %t376, ptr %l206, !tbaa !27
  %t377 = load ptr, ptr %l0, !tbaa !29
  %t379 = getelementptr %"compiler/check:Checker", ptr %t377, i32 0, i32 32
  %t380 = load i64, ptr %l20, !tbaa !24
  %t383 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %t379, i64 %t380)
  store { i64, ptr } %t383, ptr %l210
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_85a2f2931038d80c_e5a946dd8e187d18)
  unreachable
bb96:
  %t384 = icmp sge i64 0, 0
  br i1 %t384, label %bb97, label %bb98
bb97:
  %t386 = icmp sle i64 0, 2305843009213693951
  br i1 %t386, label %bb99, label %bb100
bb98:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb99:
  %t388 = mul i64 0, 4
  %t389 = call ptr @__olang_scope_alloc_zeroed(ptr %s5, i64 %t388)
  %t390 = insertvalue { i64, ptr } undef, i64 0, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  %t392 = load ptr, ptr %l195, !tbaa !29
  %t393 = load %"compiler/source:Span", ptr %l196
  %t394 = load %"compiler/source:Span", ptr %l197
  %t395 = load i64, ptr %l198, !tbaa !24
  %t396 = load ptr, ptr %l203, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t398 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t400 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v0, ptr %s5, ptr %t392, %"compiler/source:Span" %t393, %"compiler/source:Span" %t394, i64 %t395, ptr %t396, { i64, ptr } %t397, { i64, ptr } %t398, { i64, ptr } %t391)
  store ptr %t400, ptr %l214
  br label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_e4f33d7277813d9a_8adeed4fca551266)
  unreachable
bb101:
  call void @__olang_scope_close(ptr %s5)
  %t401 = load ptr, ptr %l214, !tbaa !29
  store ptr %t401, ptr %rv
  br label %ret
bb102:
  store ptr null, ptr %l21, !tbaa !29
  %t402 = load ptr, ptr %l3, !tbaa !29
  %t404 = icmp eq ptr %t402, null
  br i1 %t404, label %bb103, label %bb104
bb103:
  %t406 = load ptr, ptr %l0, !tbaa !29
  store ptr %t406, ptr %l217, !tbaa !29
  %t407 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t407, ptr %l218
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l220
  br label %bb105
bb104:
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l223, !tbaa !29
  %t412 = load ptr, ptr %l3, !tbaa !29
  store ptr %t412, ptr %l224, !tbaa !29
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t413)
  store i32 %t415, ptr %l226
  br label %bb107
bb105:
  %t416 = load ptr, ptr %l217, !tbaa !29
  %t417 = load %"compiler/source:Span", ptr %l218
  %t418 = load i32, ptr %l220, !tbaa !23
  %t419 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %t416, %"compiler/source:Span" %t417, i32 %t418, i64 0)
  store ptr %t419, ptr %l221
  br label %bb106
bb106:
  %t420 = load ptr, ptr %l221, !tbaa !29
  store ptr %t420, ptr %l21, !tbaa !29
  br label %bb109
bb107:
  %t422 = load ptr, ptr %l223, !tbaa !29
  %t423 = load ptr, ptr %l224, !tbaa !29
  %t424 = load i32, ptr %l226, !tbaa !23
  %t425 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %t422, ptr %t423, i32 %t424)
  store ptr %t425, ptr %l227
  br label %bb108
bb108:
  %t426 = load ptr, ptr %l227, !tbaa !29
  store ptr %t426, ptr %l21, !tbaa !29
  br label %bb109
bb109:
  store ptr null, ptr %l22, !tbaa !29
  %t428 = load ptr, ptr %l4, !tbaa !29
  %t430 = icmp eq ptr %t428, null
  br i1 %t430, label %bb110, label %bb111
bb110:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l231, !tbaa !29
  %t433 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t433, ptr %l232
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t436 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t434)
  store i32 %t436, ptr %l234
  br label %bb112
bb111:
  %t437 = load ptr, ptr %l0, !tbaa !29
  store ptr %t437, ptr %l248, !tbaa !29
  %t438 = load ptr, ptr %l4, !tbaa !29
  store ptr %t438, ptr %l249, !tbaa !29
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %t439)
  store i32 %t441, ptr %l251
  br label %bb115
bb112:
  store i32 22, ptr %l235
  %t442 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t442, ptr %l236
  %t443 = load ptr, ptr %l0, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  %t448 = getelementptr %"compiler/generic:Program", ptr %t446, i32 0, i32 2
  %t449 = load i32, ptr %l7, !tbaa !23
  %t450 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t454 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t448, i32 %t449, i64 %t450)
  store i32 %t454, ptr %l242
  br label %bb113
bb113:
  %t455 = load ptr, ptr %l6, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t456
  %t457 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 0
  store i64 3, ptr %t457
  %t458 = load %"compiler/source:Span", ptr %l236
  %t459 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t458, 0
  %t460 = load i32, ptr %l242, !tbaa !23
  %t461 = insertvalue { %"compiler/source:Span", i32, ptr } %t459, i32 %t460, 1
  %t463 = insertvalue { %"compiler/source:Span", i32, ptr } %t461, ptr %t455, 2
  %t464 = getelementptr { i64, [5 x i64] }, ptr %t456, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t463, ptr %t464
  %t465 = load { i64, [5 x i64] }, ptr %t456
  %t467 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t465, ptr %t467
  %t468 = load ptr, ptr %l231, !tbaa !29
  %t469 = load %"compiler/source:Span", ptr %l232
  %t470 = load i32, ptr %l234, !tbaa !23
  %t471 = load i32, ptr %l235
  %t473 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %t468, %"compiler/source:Span" %t469, i32 %t470, i32 %t471, ptr %t467, ptr null)
  store ptr %t473, ptr %l246
  br label %bb114
bb114:
  %t474 = load ptr, ptr %l246, !tbaa !29
  store ptr %t474, ptr %l22, !tbaa !29
  br label %bb117
bb115:
  %t476 = load ptr, ptr %l248, !tbaa !29
  %t477 = load ptr, ptr %l249, !tbaa !29
  %t478 = load i32, ptr %l251, !tbaa !23
  %t479 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v2, ptr %t476, ptr %t477, i32 %t478)
  store ptr %t479, ptr %l252
  br label %bb116
bb116:
  %t480 = load ptr, ptr %l252, !tbaa !29
  store ptr %t480, ptr %l22, !tbaa !29
  br label %bb117
bb117:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i32, ptr %l7, !tbaa !23
  %t486 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %t482, i32 %t483)
  store i1 %t486, ptr %l256
  br label %bb118
bb118:
  %t487 = load i1, ptr %l256, !tbaa !21
  br i1 %t487, label %bb119, label %bb120
bb119:
  %t488 = load i32, ptr %l7, !tbaa !23
  store i32 %t488, ptr %l257, !tbaa !23
  br label %bb127
bb120:
  %t490 = load ptr, ptr %l0, !tbaa !29
  %t492 = getelementptr %"compiler/check:Checker", ptr %t490, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !29
  %t495 = getelementptr %"compiler/generic:Program", ptr %t493, i32 0, i32 2
  store ptr %t495, ptr %l261, !tbaa !29
  %t496 = load ptr, ptr %l0, !tbaa !29
  %t498 = getelementptr %"compiler/check:Checker", ptr %t496, i32 0, i32 1
  %t499 = load ptr, ptr %t498, !tbaa !29
  %t501 = getelementptr %"compiler/generic:Program", ptr %t499, i32 0, i32 2
  %t502 = load i32, ptr %l15, !tbaa !23
  %t505 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t501, i32 %t502)
  store i32 %t505, ptr %l266
  br label %bb121
bb121:
  %t506 = load i32, ptr %l5
  %t508 = trunc i64 1 to i32
  %t509 = icmp eq i32 %t506, %t508
  br i1 %t509, label %bb122, label %bb123
bb122:
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t512 = load i32, ptr %l15, !tbaa !23
  %t513 = load ptr, ptr %l3, !tbaa !29
  %t514 = load ptr, ptr %l4, !tbaa !29
  %t519 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %t511, i32 %t512, ptr %t513, ptr %t514)
  store i32 %t519, ptr %l274
  br label %bb124
bb123:
  store i32 0, ptr %l269, !tbaa !23
  br label %bb125
bb124:
  %t520 = load i32, ptr %l274, !tbaa !23
  store i32 %t520, ptr %l269, !tbaa !23
  br label %bb125
bb125:
  %t521 = load ptr, ptr %l261, !tbaa !29
  %t522 = load i32, ptr %l266, !tbaa !23
  %t523 = load i32, ptr %l269, !tbaa !23
  %t524 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t521, i32 %t522, i32 %t523)
  store i32 %t524, ptr %l275
  br label %bb126
bb126:
  %t525 = load i32, ptr %l275, !tbaa !23
  store i32 %t525, ptr %l257, !tbaa !23
  br label %bb127
bb127:
  %t526 = load i32, ptr %l257, !tbaa !23
  %t527 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t527, ptr %l276
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/check:Checker", ptr %t528, i32 0, i32 1
  %t531 = load ptr, ptr %t530, !tbaa !29
  %t533 = getelementptr %"compiler/generic:Program", ptr %t531, i32 0, i32 2
  %t535 = load i64, ptr %l8, !tbaa !24
  %t539 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t533, i32 %t526, i64 %t535)
  store i32 %t539, ptr %l282
  br label %bb128
bb128:
  %t540 = load ptr, ptr %l6, !tbaa !29
  store ptr %t540, ptr %l283, !tbaa !29
  %t541 = load ptr, ptr %l21, !tbaa !29
  %t543 = icmp eq ptr %t541, null
  br i1 %t543, label %bb129, label %bb130
bb129:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb130:
  br label %bb131
bb131:
  %t545 = load ptr, ptr %l21, !tbaa !29
  store ptr %t545, ptr %l286, !tbaa !29
  %t546 = load ptr, ptr %l22, !tbaa !29
  %t548 = icmp eq ptr %t546, null
  br i1 %t548, label %bb132, label %bb133
bb132:
  call void @__olang_check_failed(ptr @olang_loc_2f1aad6b95023edd_c82f5ce971f0d619)
  unreachable
bb133:
  br label %bb134
bb134:
  %t550 = load ptr, ptr %l22, !tbaa !29
  %t551 = load i32, ptr %l5
  %t552 = load ptr, ptr %l283, !tbaa !29
  %t553 = load ptr, ptr %l286, !tbaa !29
  %t556 = call %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t552, ptr %t553, ptr %t550, i32 %t551)
  store %"compiler/typed:Slice" %t556, ptr %l291
  br label %bb135
bb135:
  %t557 = load %"compiler/typed:Slice", ptr %l291
  %t558 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"compiler/typed:Slice" %t557, ptr %t558
  store { i64, [5 x i64] } zeroinitializer, ptr %t559
  %t560 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 0
  store i64 10, ptr %t560
  %t561 = load %"compiler/source:Span", ptr %l276
  %t562 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t561, 0
  %t563 = load i32, ptr %l282, !tbaa !23
  %t564 = insertvalue { %"compiler/source:Span", i32, ptr } %t562, i32 %t563, 1
  %t566 = insertvalue { %"compiler/source:Span", i32, ptr } %t564, ptr %t558, 2
  %t567 = getelementptr { i64, [5 x i64] }, ptr %t559, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t566, ptr %t567
  %t568 = load { i64, [5 x i64] }, ptr %t559
  %t570 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store { i64, [5 x i64] } %t568, ptr %t570
  store ptr %t570, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l7 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 0
  %t7 = load ptr, ptr %t6, !tbaa !29
  %t9 = getelementptr %"compiler/load:Loader", ptr %t7, i32 0, i32 3
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %t10, i32 %a1)
  store { i64, ptr } %t14, ptr %l7
  br label %bb1
bb1:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %a0, i32 %a1)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t6)
  store { i64, ptr } %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t8, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunsettle(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca ptr
  %l10 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l36 = alloca ptr
  %l39 = alloca i64
  %l43 = alloca ptr
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 13
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l10
  br label %bb1
bb1:
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store i64 1, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t8 = load i64, ptr %l1, !tbaa !24
  %t11 = icmp sgt i64 %t7, %t8
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l14, !tbaa !24
  br label %bb7
bb4:
  %t17 = load i64, ptr %l2, !tbaa !24
  %t18 = load i64, ptr %l1, !tbaa !24
  %t21 = sub i64 %t17, %t18
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t21, %t22
  %t27 = sub i64 %t25, 1
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sdiv i64 %t27, %t28
  store i64 %t31, ptr %l17, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l17, !tbaa !24
  br label %bb6
bb6:
  %t33 = load i64, ptr %l17, !tbaa !24
  store i64 %t33, ptr %l14, !tbaa !24
  br label %bb7
bb7:
  %t34 = load i64, ptr %l14, !tbaa !24
  store i64 %t34, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l5, !tbaa !24
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l3, !tbaa !24
  %t48 = mul i64 %t44, %t45
  %t51 = add i64 %t43, %t48
  store i64 %t51, ptr %l6, !tbaa !24
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 13
  store ptr %t55, ptr %l36, !tbaa !29
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 13
  %t60 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %t58)
  store i64 %t60, ptr %l39
  br label %bb12
bb12:
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = sub i64 %t61, 1
  %t63 = load i64, ptr %l6, !tbaa !24
  %t66 = sub i64 %t62, %t63
  %t67 = load ptr, ptr %l36, !tbaa !29
  %t69 = call ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v0, ptr %t67, i64 %t66)
  store ptr %t69, ptr %l43
  br label %bb13
bb13:
  %t70 = load ptr, ptr %l43, !tbaa !29
  store ptr %t70, ptr %l7, !tbaa !29
  %t71 = load ptr, ptr %l7, !tbaa !29
  %t73 = getelementptr %"compiler/check:frame", ptr %t71, i32 0, i32 24
  %t74 = load i1, ptr %t73, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 52
  %t79 = load ptr, ptr %l7, !tbaa !29
  %t81 = getelementptr %"compiler/check:frame", ptr %t79, i32 0, i32 0
  %t82 = load i64, ptr %t81, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t78, i64 %t82, i1 true)
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t85 = load i64, ptr %l5, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l5, !tbaa !24
  br label %bb8
bb19:
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewholeNarrowed(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/check:narrowed"
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l15 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l41 = alloca ptr
  %l44 = alloca i64
  %l48 = alloca %"compiler/check:narrowed"
  %l53 = alloca ptr
  %l58 = alloca i32
  %l59 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca i1
  %l72 = alloca i64
  %s2 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %t1)
  store ptr %t3, ptr %l12
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l12, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 43
  %t9 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l15
  br label %bb2
bb2:
  %t10 = load i64, ptr %l15, !tbaa !24
  store i64 %t10, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l22, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l19, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l19, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load i64, ptr %l7, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l3, !tbaa !24
  %t48 = load i64, ptr %l7, !tbaa !24
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l8, !tbaa !24
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 43
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 43
  %t64 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l44
  br label %bb13
bb13:
  %t65 = load i64, ptr %l44, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l8, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eAt_H313390349c5d53629478ea446134cf40(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l48
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l48
  store %"compiler/check:narrowed" %t74, ptr %l9
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l53, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 2
  %t92 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 2
  %t93 = load i32, ptr %t92, !tbaa !23
  %t96 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t91, i32 %t93)
  store i32 %t96, ptr %l58
  br label %bb18
bb18:
  %t97 = load ptr, ptr %l53, !tbaa !29
  %t98 = load i32, ptr %l58, !tbaa !23
  %t99 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %t97, i32 %t98)
  store ptr %t99, ptr %l59
  br label %bb19
bb19:
  %t100 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 1
  %t101 = load i64, ptr %t100, !tbaa !24
  %t102 = load ptr, ptr %l59, !tbaa !29
  %t104 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %t102, i64 %t101)
  store ptr %t104, ptr %l61
  br label %bb20
bb20:
  %t105 = load ptr, ptr %l61, !tbaa !29
  store ptr %t105, ptr %l10, !tbaa !29
  %t106 = load ptr, ptr %l10, !tbaa !29
  %t108 = icmp eq ptr %t106, null
  br i1 %t108, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb23
bb22:
  %t110 = load ptr, ptr %l10, !tbaa !29
  %t112 = getelementptr %"compiler/ast:CaseDecl", ptr %t110, i32 0, i32 3
  %t113 = load i1, ptr %t112, !tbaa !21
  %t115 = xor i1 %t113, true
  store i1 %t115, ptr %l64, !tbaa !21
  br label %bb23
bb23:
  %t117 = load i1, ptr %l64, !tbaa !21
  br i1 %t117, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s2)
  store i64 -1, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t119 = load ptr, ptr %l2, !tbaa !29
  %t121 = getelementptr %"compiler/check:frame", ptr %t119, i32 0, i32 44
  %t122 = getelementptr %"compiler/check:narrowed", ptr %l9, i32 0, i32 3
  %t123 = load i64, ptr %t122, !tbaa !24
  %t126 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t121, i64 %t123)
  store i64 %t126, ptr %l72
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s2)
  %t127 = load i64, ptr %l72, !tbaa !24
  store i64 %t127, ptr %rv
  br label %ret
bb28:
  %t128 = load i64, ptr %l7, !tbaa !24
  %t130 = add i64 %t128, 1
  store i64 %t130, ptr %l7, !tbaa !24
  br label %bb9
bb29:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2eifAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l6 = alloca i1
  %l15 = alloca i1
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:If", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/ast:If", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/ast:If", ptr %t17, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t23 = getelementptr %"compiler/ast:Branch", ptr %t20, i32 0, i32 1
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t28 = call i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %t24, { i64, ptr } %t25)
  store i1 %t28, ptr %l15
  br label %bb6
bb6:
  %t29 = load i1, ptr %l15, !tbaa !21
  store i1 %t29, ptr %l6, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l6, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/ast:If", ptr %t32, i32 0, i32 2
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t39 = call i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %t35, { i64, ptr } %t36)
  store i1 %t39, ptr %l20
  br label %bb11
bb11:
  %t40 = load i1, ptr %l20, !tbaa !21
  store i1 %t40, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eintFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i1
  %l17 = alloca i1
  %l20 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i64
  %l33 = alloca i1
  %l35 = alloca i64
  %l45 = alloca i64
  %l51 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t1, i32 %t2)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t8 = load i32, ptr %l2, !tbaa !23
  %t11 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t7, i32 %t8)
  store i1 %t11, ptr %l10
  br label %bb2
bb2:
  %t12 = load i1, ptr %l10, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t13 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb5, label %bb6
bb4:
  br label %bb26
bb5:
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp sge i64 %t16, 64
  store i1 %t18, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 5
  %t21 = load i1, ptr %t20, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  %t23 = load i64, ptr %l3, !tbaa !24
  %t25 = icmp sge i64 %t23, 64
  br i1 %t25, label %bb10, label %bb11
bb9:
  br label %bb19
bb10:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb18
bb11:
  %t27 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t28 = load i64, ptr %t27, !tbaa !24
  %t30 = icmp sge i64 %t28, 0
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp eq i64 %t32, 63
  br i1 %t34, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb17
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb16
bb15:
  %t36 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t37 = load i64, ptr %t36, !tbaa !24
  %t38 = load i64, ptr %l3, !tbaa !24
  store i64 %t38, ptr %l25, !tbaa !24
  %t39 = load i64, ptr %l25, !tbaa !24
  %t40 = load i64, ptr %l25, !tbaa !24
  %t41 = shl i64 1, %t40
  %t44 = icmp slt i64 %t37, %t41
  store i1 %t44, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t46 = load i1, ptr %l23, !tbaa !21
  store i1 %t46, ptr %l20, !tbaa !21
  br label %bb17
bb17:
  %t47 = load i1, ptr %l20, !tbaa !21
  store i1 %t47, ptr %l17, !tbaa !21
  br label %bb18
bb18:
  %t48 = load i1, ptr %l17, !tbaa !21
  store i1 %t48, ptr %rv
  br label %ret
bb19:
  %t49 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t50 = load i64, ptr %t49, !tbaa !24
  %t52 = icmp slt i64 %t50, 0
  br i1 %t52, label %bb20, label %bb21
bb20:
  store i1 false, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t55 = load i64, ptr %l3, !tbaa !24
  %t57 = icmp sge i64 %t55, 63
  br i1 %t57, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb25
bb24:
  %t59 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t60 = load i64, ptr %t59, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  store i64 %t61, ptr %l35, !tbaa !24
  %t62 = load i64, ptr %l35, !tbaa !24
  %t63 = load i64, ptr %l35, !tbaa !24
  %t64 = shl i64 1, %t63
  %t67 = icmp slt i64 %t60, %t64
  store i1 %t67, ptr %l33, !tbaa !21
  br label %bb25
bb25:
  %t69 = load i1, ptr %l33, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
bb26:
  %t70 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t71 = load i1, ptr %t70, !tbaa !21
  br i1 %t71, label %bb27, label %bb28
bb27:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t75 = icmp sgt i64 %t73, 64
  store i1 %t75, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t77 = load i64, ptr %l3, !tbaa !24
  %t79 = icmp sge i64 %t77, 64
  br i1 %t79, label %bb30, label %bb31
bb30:
  store i1 true, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t82 = load i64, ptr %l3, !tbaa !24
  %t84 = sub i64 %t82, 1
  store i64 %t84, ptr %l45, !tbaa !24
  %t85 = load i64, ptr %l45, !tbaa !24
  %t86 = load i64, ptr %l45, !tbaa !24
  %t87 = shl i64 1, %t86
  store i64 %t87, ptr %l4, !tbaa !24
  %t89 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t90 = load i64, ptr %t89, !tbaa !24
  %t91 = load i64, ptr %l4, !tbaa !24
  %t93 = sub i64 0, %t91
  %t96 = icmp sge i64 %t90, %t93
  br i1 %t96, label %bb33, label %bb34
bb33:
  %t98 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t99 = load i64, ptr %t98, !tbaa !24
  %t100 = load i64, ptr %l4, !tbaa !24
  %t103 = icmp slt i64 %t99, %t100
  store i1 %t103, ptr %l51, !tbaa !21
  br label %bb35
bb34:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb35
bb35:
  %t105 = load i1, ptr %l51, !tbaa !21
  store i1 %t105, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2eintFloatBits(i32 %a0, %"compiler/check:litv" %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca %"compiler/check:litv"
  %l2 = alloca i64
  %rv = alloca i64
  store i32 %a0, ptr %l0
  store %"compiler/check:litv" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 2
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t5 = load i64, ptr %t4, !tbaa !24
  store i64 %t5, ptr %l2, !tbaa !65
  %t8 = load i32, ptr %l0, !tbaa !23
  %t10 = icmp eq i32 %t8, 13
  br i1 %t10, label %bb3, label %bb4
bb2:
  br label %bb12
bb3:
  %t12 = load i64, ptr %l2, !tbaa !65
  %t14 = uitofp i64 %t12 to float
  %t16 = bitcast float %t14 to i32
  %t18 = zext i32 %t16 to i64
  store i64 %t18, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t20 = load i32, ptr %l0, !tbaa !23
  %t22 = icmp eq i32 %t20, 12
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load i64, ptr %l2, !tbaa !65
  %t26 = call bfloat @__olang_int_bf16(i64 %t24, i1 false)
  %t28 = bitcast bfloat %t26 to i16
  %t29 = call i16 asm "", "=r,0"(i16 %t28)
  %t31 = zext i16 %t29 to i64
  store i64 %t31, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load i32, ptr %l0, !tbaa !23
  %t35 = icmp eq i32 %t33, 11
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l2, !tbaa !65
  %t39 = uitofp i64 %t37 to double
  %t40 = call double @llvm.arithmetic.fence.f64(double %t39)
  %t41 = fptrunc double %t40 to half
  %t43 = bitcast half %t41 to i16
  %t44 = call i16 asm "", "=r,0"(i16 %t43)
  %t46 = zext i16 %t44 to i64
  store i64 %t46, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t48 = load i64, ptr %l2, !tbaa !65
  %t50 = uitofp i64 %t48 to double
  %t52 = bitcast double %t50 to i64
  store i64 %t52, ptr %rv
  br label %ret
bb12:
  %t55 = load i32, ptr %l0, !tbaa !23
  %t57 = icmp eq i32 %t55, 13
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t59 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t60 = load i64, ptr %t59, !tbaa !24
  %t62 = sitofp i64 %t60 to float
  %t64 = bitcast float %t62 to i32
  %t66 = zext i32 %t64 to i64
  store i64 %t66, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t68 = load i32, ptr %l0, !tbaa !23
  %t70 = icmp eq i32 %t68, 12
  br i1 %t70, label %bb16, label %bb17
bb16:
  %t72 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t73 = load i64, ptr %t72, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  %t76 = sub i64 0, %t73
  %t77 = select i1 %t75, i64 %t76, i64 %t73
  %t78 = call bfloat @__olang_int_bf16(i64 %t77, i1 %t75)
  %t80 = bitcast bfloat %t78 to i16
  %t81 = call i16 asm "", "=r,0"(i16 %t80)
  %t83 = zext i16 %t81 to i64
  store i64 %t83, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t85 = load i32, ptr %l0, !tbaa !23
  %t87 = icmp eq i32 %t85, 11
  br i1 %t87, label %bb19, label %bb20
bb19:
  %t89 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t90 = load i64, ptr %t89, !tbaa !24
  %t92 = sitofp i64 %t90 to double
  %t93 = call double @llvm.arithmetic.fence.f64(double %t92)
  %t94 = fptrunc double %t93 to half
  %t96 = bitcast half %t94 to i16
  %t97 = call i16 asm "", "=r,0"(i16 %t96)
  %t99 = zext i16 %t97 to i64
  store i64 %t99, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t101 = getelementptr %"compiler/check:litv", ptr %l1, i32 0, i32 3
  %t102 = load i64, ptr %t101, !tbaa !24
  %t104 = sitofp i64 %t102 to double
  %t106 = bitcast double %t104 to i64
  store i64 %t106, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2eisHexDigit(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i8, ptr %l0, !tbaa !22
  %t3 = icmp uge i8 %t1, 97
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i8, ptr %l0, !tbaa !22
  %t7 = icmp ule i8 %t5, 102
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb9
bb5:
  %t10 = load i8, ptr %l0, !tbaa !22
  %t12 = icmp uge i8 %t10, 65
  br i1 %t12, label %bb6, label %bb7
bb6:
  %t14 = load i8, ptr %l0, !tbaa !22
  %t16 = icmp ule i8 %t14, 70
  store i1 %t16, ptr %l9, !tbaa !21
  br label %bb8
bb7:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb8
bb8:
  %t18 = load i1, ptr %l9, !tbaa !21
  store i1 %t18, ptr %l6, !tbaa !21
  br label %bb9
bb9:
  %t19 = load i1, ptr %l6, !tbaa !21
  store i1 %t19, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1
  %t18 = trunc i64 7 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %rv
  br label %ret
bb6:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2enullDefault(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l20 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l39 = alloca i1
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t8 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t8, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  store i64 %t12, ptr %l3, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t18 = icmp slt i64 %t14, %t15
  %t20 = xor i1 %t18, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s3)
  br label %bb22
bb6:
  br label %bb7
bb7:
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l20, !tbaa !27
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr ptr, ptr %t26, i64 %t23
  %t28 = load ptr, ptr %t27, !tbaa !39
  store ptr %t28, ptr %l4, !tbaa !29
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Catch", ptr %t30, i32 0, i32 3
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t37 = icmp eq i64 %t35, 0
  br i1 %t37, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb9:
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l4, !tbaa !29
  %t41 = getelementptr %"compiler/ast:Catch", ptr %t39, i32 0, i32 3
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s6
  %t48 = load i64, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s6)
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t56, ptr %l35, !tbaa !27
  %t57 = load i64, ptr %l6, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr ptr, ptr %t60, i64 %t57
  %t62 = load ptr, ptr %t61, !tbaa !39
  %t66 = call i1 @compiler_2fcheck_2eisNullLit(ptr %v0, ptr %t62)
  store i1 %t66, ptr %l39
  br label %bb15
bb15:
  %t67 = load i1, ptr %l39, !tbaa !21
  br i1 %t67, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  store i1 true, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb19
bb19:
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = add i64 %t69, 1
  store i64 %t71, ptr %l6, !tbaa !24
  br label %bb11
bb20:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb21:
  %t73 = load i64, ptr %l2, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l2, !tbaa !24
  br label %bb4
bb22:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"compiler/check:reflVal" @compiler_2fcheck_2ervText(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca %"compiler/check:reflVal"
  %rv = alloca %"compiler/check:reflVal"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr @G_2ecompiler_2fcheck_2eRvText, !tbaa !24
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t7 = call %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 true, i64 %t1, i64 0, { i64, ptr } %a0, i32 %t3)
  store %"compiler/check:reflVal" %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load %"compiler/check:reflVal", ptr %l4
  store %"compiler/check:reflVal" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflVal", ptr %rv
  ret %"compiler/check:reflVal" %rr
}

define dso_local i1 @compiler_2fcheck_2esamePath(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp ne i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  store i64 0, ptr %l2, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp sgt i64 %t16, %t17
  br i1 %t20, label %bb4, label %bb5
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp sgt i64 %t22, 0
  br i1 %t24, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb9
bb6:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t30 = sub i64 %t26, %t27
  %t31 = load i64, ptr %l4, !tbaa !24
  %t34 = add i64 %t30, %t31
  %t36 = sub i64 %t34, 1
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = sdiv i64 %t36, %t37
  store i64 %t40, ptr %l22, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb8
bb8:
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l19, !tbaa !24
  br label %bb9
bb9:
  %t43 = load i64, ptr %l19, !tbaa !24
  store i64 %t43, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = icmp slt i64 %t44, %t45
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb12:
  br label %bb13
bb13:
  %t52 = load i64, ptr %l2, !tbaa !24
  %t53 = load i64, ptr %l6, !tbaa !24
  %t54 = load i64, ptr %l4, !tbaa !24
  %t57 = mul i64 %t53, %t54
  %t60 = add i64 %t52, %t57
  store i64 %t60, ptr %l7, !tbaa !24
  %t62 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t62, ptr %l40, !tbaa !27
  %t63 = load i64, ptr %l7, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr i32, ptr %t66, i64 %t63
  %t68 = load i32, ptr %t67, !tbaa !33
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t69, ptr %l43, !tbaa !27
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i32, ptr %t73, i64 %t70
  %t75 = load i32, ptr %t74, !tbaa !33
  %t78 = icmp ne i32 %t68, %t75
  br i1 %t78, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  store i1 false, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb17:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb10
bb18:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l33 = alloca ptr
  %l34 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l49 = alloca ptr
  %l50 = alloca i1
  %l57 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l9, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l10, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l15, !tbaa !29
  store i1 false, ptr %l16, !tbaa !21
  %t17 = load ptr, ptr %l15, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l15, !tbaa !29
  %t21 = load i64, ptr %t20
  %t23 = icmp eq i64 %t21, 0
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l16, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [5 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", i32 }, ptr %t27, i32 0, i32 1
  %t29 = load i32, ptr %t28
  store i32 %t29, ptr %l3, !tbaa !23
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t31 = load i32, ptr %l2, !tbaa !23
  %t32 = load i32, ptr %l3, !tbaa !23
  %t35 = icmp eq i32 %t31, %t32
  store i1 %t35, ptr %rv
  br label %ret
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t40 = icmp ne ptr %t39, null
  br i1 %t40, label %bb13, label %bb14
bb13:
  %t42 = load ptr, ptr %l25, !tbaa !29
  %t43 = load i64, ptr %t42
  %t45 = icmp eq i64 %t43, 15
  store i1 %t45, ptr %l26, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l26, !tbaa !21
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr { i64, [5 x i64] }, ptr %t47, i32 0, i32 1
  %t50 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t49, i32 0, i32 1
  %t51 = load ptr, ptr %t50
  store ptr %t51, ptr %l4, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr { i64, [5 x i64] }, ptr %t53, i32 0, i32 1
  %t56 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t55, i32 0, i32 2
  %t57 = load i32, ptr %t56
  store i32 %t57, ptr %l5, !tbaa !23
  br label %bb17
bb16:
  br label %bb28
bb17:
  %t59 = load ptr, ptr %l1, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  store i1 false, ptr %l34, !tbaa !21
  %t60 = load ptr, ptr %l33, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb18, label %bb19
bb18:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load i64, ptr %t63
  %t66 = icmp eq i64 %t64, 15
  store i1 %t66, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t67 = load i1, ptr %l34, !tbaa !21
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr { i64, [5 x i64] }, ptr %t68, i32 0, i32 1
  %t71 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t70, i32 0, i32 1
  %t72 = load ptr, ptr %t71
  store ptr %t72, ptr %l6, !tbaa !29
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t76, i32 0, i32 2
  %t78 = load i32, ptr %t77
  store i32 %t78, ptr %l7, !tbaa !23
  br label %bb22
bb21:
  br label %bb27
bb22:
  %t80 = load i32, ptr %l5, !tbaa !23
  %t81 = load i32, ptr %l7, !tbaa !23
  %t84 = icmp eq i32 %t80, %t81
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t87 = load ptr, ptr %l6, !tbaa !29
  %t90 = call i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %t86, ptr %t87)
  store i1 %t90, ptr %l47
  br label %bb25
bb24:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb26
bb25:
  %t91 = load i1, ptr %l47, !tbaa !21
  store i1 %t91, ptr %l44, !tbaa !21
  br label %bb26
bb26:
  %t92 = load i1, ptr %l44, !tbaa !21
  store i1 %t92, ptr %rv
  br label %ret
bb27:
  store i1 false, ptr %rv
  br label %ret
bb28:
  %t94 = load ptr, ptr %l0, !tbaa !29
  store ptr %t94, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t95 = load ptr, ptr %l49, !tbaa !29
  %t96 = icmp ne ptr %t95, null
  br i1 %t96, label %bb29, label %bb30
bb29:
  %t98 = load ptr, ptr %l49, !tbaa !29
  %t99 = load i64, ptr %t98
  %t101 = icmp eq i64 %t99, 2
  store i1 %t101, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t102 = load i1, ptr %l50, !tbaa !21
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr { i64, [5 x i64] }, ptr %t103, i32 0, i32 1
  %t106 = getelementptr { %"compiler/source:Span", ptr }, ptr %t105, i32 0, i32 1
  %t107 = load ptr, ptr %t106
  store ptr %t107, ptr %l8, !tbaa !29
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t109 = load ptr, ptr %l8, !tbaa !29
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t113 = call i1 @compiler_2fcheck_2esameRead(ptr %v0, ptr %v1, ptr %t109, ptr %t110)
  store i1 %t113, ptr %l57
  br label %bb34
bb34:
  %t114 = load i1, ptr %l57, !tbaa !21
  store i1 %t114, ptr %rv
  br label %ret
bb35:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l18 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Match", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t4, ptr %t6)
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/ast:Match", ptr %t9, i32 0, i32 3
  %t12 = load { i64, ptr }, ptr %t11, !tbaa !27
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  store i64 %t16, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  %t22 = icmp slt i64 %t18, %t19
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l18, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr ptr, ptr %t30, i64 %t27
  %t32 = load ptr, ptr %t31, !tbaa !39
  %t35 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %t32, ptr %t35)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t38 = load i64, ptr %l3, !tbaa !24
  %t40 = add i64 %t38, 1
  store i64 %t40, ptr %l3, !tbaa !24
  br label %bb2
bb8:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/ast:Match", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Match", ptr %t51, i32 0, i32 4
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = icmp eq ptr %t54, null
  br i1 %t56, label %bb11, label %bb12
bb10:
  br label %bb15
bb11:
  call void @__olang_check_failed(ptr @olang_loc_dafed6c5ce7057e_e7afeb5c7864030a)
  unreachable
bb12:
  br label %bb13
bb13:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/ast:Match", ptr %t58, i32 0, i32 4
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %t61, ptr %t62)
  br label %bb14
bb14:
  br label %bb15
bb15:
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fcheck_2etextBytes(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l8 = alloca i64
  %l19 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l8, !tbaa !24
  %t4 = load i64, ptr %l8, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t12 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t12, ptr %lp1
  %t14 = load ptr, ptr %lp1
  store { i64, ptr } %t11, ptr %t14, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  store i64 %t19, ptr %l4, !tbaa !24
  br label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_7873eed4a01e5678_b9c164dc568d47a4)
  unreachable
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = icmp slt i64 %t21, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb5:
  br label %bb6
bb6:
  %t29 = load i64, ptr %l3, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t43 = load ptr, ptr %lp1
  %t45 = getelementptr { i64, ptr }, ptr %t43, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = getelementptr i8, ptr %t46, i64 %t29
  store i8 %t37, ptr %t47, !tbaa !32
  call void @__olang_scope_close(ptr %s2)
  br label %bb7
bb7:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb3
bb8:
  %t52 = load ptr, ptr %lp1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2eunpromoted(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr %"compiler/typed:Promote", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb6:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/check:EmbedAsk" @compiler_2fcheck_3aEmbedAsk_2ector(ptr %v0, i64 %a0, i64 %a1, i32 %a2) #0 {
entry:
  %rv = alloca %"compiler/check:EmbedAsk"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/check:EmbedAsk" undef, i64 %a0, 0
  %t10 = insertvalue %"compiler/check:EmbedAsk" %t8, i64 %a1, 1
  %t12 = insertvalue %"compiler/check:EmbedAsk" %t10, i32 %a2, 2
  store %"compiler/check:EmbedAsk" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:EmbedAsk", ptr %rv
  ret %"compiler/check:EmbedAsk" %rr
}

define dso_local %"compiler/check:atRec" @compiler_2fcheck_3aatRec_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, ptr %a2, i32 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:atRec"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:atRec" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:atRec" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:atRec" %t12, ptr %a2, 2
  %t16 = insertvalue %"compiler/check:atRec" %t14, i32 %a3, 3
  store %"compiler/check:atRec" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:atRec", ptr %rv
  ret %"compiler/check:atRec" %rr
}

define dso_local %"compiler/check:roFn" @compiler_2fcheck_3aroFn_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/check:roFn"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:roFn" undef, i64 %a0, 0
  %t12 = insertvalue %"compiler/check:roFn" %t10, i64 %a1, 1
  %t14 = insertvalue %"compiler/check:roFn" %t12, { i64, [3 x i64] } %a2, 2
  %t16 = insertvalue %"compiler/check:roFn" %t14, { i64, ptr } %a3, 3
  store %"compiler/check:roFn" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:roFn", ptr %rv
  ret %"compiler/check:roFn" %rr
}

define dso_local %"compiler/check:typeCase" @compiler_2fcheck_3atypeCase_2ector(ptr %v0, i1 %a0, i1 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %rv = alloca %"compiler/check:typeCase"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/check:typeCase" undef, i1 %a0, 0
  %t12 = insertvalue %"compiler/check:typeCase" %t10, i1 %a1, 1
  %t14 = insertvalue %"compiler/check:typeCase" %t12, i32 %a2, 2
  %t16 = insertvalue %"compiler/check:typeCase" %t14, i64 %a3, 3
  %t18 = insertvalue %"compiler/check:typeCase" %t16, i64 0, 4
  %t20 = insertvalue %"compiler/check:typeCase" %t18, i1 false, 5
  store %"compiler/check:typeCase" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:typeCase", ptr %rv
  ret %"compiler/check:typeCase" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare void @__olang_check_failed(ptr)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare void @__olang_ert_req_clear()
@.d0 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"call" }>, align 8
@.d2 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Call" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"I32" }>, align 8
@.d4 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"std/prelude/text" }>, align 8
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Char" }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"{" }>, align 8
@.d7 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d9 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c"' is called through an 'any " }>, align 8
@.d10 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"&' here, so " }>, align 8
@.d11 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" needs it" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d12 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d13 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d14 = private constant <{ i64, [45 x i8] }> <{ i64 0, [45 x i8] c"a table slot the instance's type meets no way" }>, align 8
@.d15 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"a conversion of this kind" }>, align 8
@.d16 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d17 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d20 = private constant <{ i64, [52 x i8] }> <{ i64 0, [52 x i8] c"a generator with a contract and an unnamed parameter" }>, align 8
@.d21 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Narrow'" }>, align 8
@.d22 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"'Narrow'" }>, align 8
@.d23 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"std/prelude/number" }>, align 8
@.d24 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"NumberError" }>, align 8
@.d25 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"OVERFLOW" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Clone" }>, align 8
define linkonce_odr %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d28 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Value" }>, align 8
@.d29 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"'Value'" }>, align 8
@.d30 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d31 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d35 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d36 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d38 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"HasDefault" }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Offset" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Type" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Slice" }>, align 8
@.d44 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"'x[lo:hi]'" }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d46 = private constant <{ i64, [47 x i8] }> <{ i64 0, [47 x i8] c"a slice with no end of a type with no Len (E31)" }>, align 8
declare bfloat @__olang_int_bf16(i64, i1)
declare double @llvm.arithmetic.fence.f64(double)
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@G_2ecompiler_2fcheck_2eLaneCmp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneSel = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ehitsPath(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eexprAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eclosedExpr(ptr %v0, ptr %a0)
@olang_loc_3ee32a1caa2e355c_4063d0a06727bdc8 = external constant [0 x i8]
@olang_loc_a6ae1e9a693d05c9_888d1f7981f90365 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eExprBodyIn(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, i32 %a6)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalType(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyCaseNotAny(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/msgs:Msg" %a2)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyTrait(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsClosedTrait(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyOpenInspected(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaseTypeWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMember(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAnyNotMemberCase(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunArrayValue(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
@olang_loc_88d3ea04e82c2d9e_ee1d738344e93712 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ei64(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConst(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLengthsOnly(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrayNestedByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2eLen_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
@G_2ecompiler_2fcheck_2eRoStored = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroStore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, i64 %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aExpr_26_3e_2ePus_H51a5125d8f537c6ff8e01fc80ef561c7(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Make" @compiler_2ftyped_3aMake_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3, i32 %a4, i32 %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprTo(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternRules(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexportRules(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epush(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i32 %a3, i32 %a4)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCommutesNotHere(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epop(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorMethod(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einheritClash(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoverrideClash(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emethodOverlap(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnTypeParams(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnInstance(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_He36936f29a17adf60cb2ecc49df5337f(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fload_3aModule_26_3_H030b501919f792aa875ab74911a0b368(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edrain(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailForms(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroSettle(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aBlock(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aGlobal(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i32 %a3, i32 %a4)
@olang_loc_b2a10b57ca8f7dfa_ebdfac3cc9f6695e = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldArg(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, ptr %a2, i64 %a3)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_6ff259b9ccd7369f_aca193469829e60b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/typed:Call" @compiler_2ftyped_3aCall_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, [2 x i64] } %a2, i32 %a3, i1 %a4)
@olang_loc_f6613c7e75250c33_3760568a21e1f80f = external constant [0 x i8]
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNamed(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDestructs(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsAny(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_c23231398495940d_3184fca2d3133de9 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
@olang_loc_dec816aeadd109e0_adcbe0bcced90c1c = external constant [0 x i8]
@olang_loc_98ffdf46f6e43303_7907d8ed59f5817f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %a0)
@olang_loc_4b3a1421aaa5396_3ffde41a88bcce4a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eJoinPieceCalled(ptr %v0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopAfter(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotCallable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexternValue(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplainStruct(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtComparedToCaught(ptr %v0)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare %"compiler/check:errBind" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eAt_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0, i64 %a1)
declare { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_7af425f5cb399761_c8cadd9056f4b45 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorItemKnown(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCompareWhat(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNow(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare { i1, i1 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCases(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
@olang_loc_35d0274d34665ca7_d8b5deabc24f5253 = external constant [0 x i8]
declare %"compiler/ast:Branch" @compiler_2fast_3aBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtLast(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArrowInStatement(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtCaseTest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtNamed(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eSetAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtNotAValue(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_Hbcd822ae67306ca6a025f17ed2cfb61c(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aerrBind_3e_2eLen_3ccompiler_2fcheck_3aerrBind_3e(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCaughtCaptured(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftypes_3aTypeId_3e_2eRunF_H9c1707946c43ec840ffe1821bea89b1f(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_73076eedda527293_e224d565c24cbdcf = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eallWords(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprim(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceContext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eAddBlock(ptr %v0, ptr %a0, i32 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [2 x i64] } %a5)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2ePus_H9afb0399fee55ed1ef4b4d03ad72cb66(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eSetVars(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_f2da914bb6134d5f_3ef82b9ab3e359c3 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eEmptyDestructor(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erootStmts(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_e7a3ae7e66c3138_2e8ed5b6f09d874 = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare %"compiler/generic:AnyTable" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fgeneric_3aAnyTable_3e_2e_H5e3c685c1de22cee1b092c35d74f13cd(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur0(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ethunkModule(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Context" @compiler_2fgeneric_3aContext_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparam(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i64 %a4, ptr %a5)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSlotKey(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_Had7920a3eff3220b2e12299d961f9124(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aStmt_26_3e_2ePus_He68407854d25cdd1c04f001baf21eeaa(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_3c4a57751e7c3c44_a964a095ba0d8e8 = external constant [0 x i8]
@olang_loc_f96b0b1da9e56a51_6d335a1b9c4b88d5 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, [3 x i64] } } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2fdiag_3aWhere_3e_2e_H38805f4eed72f99710d38d2dedaea985(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2)
@olang_loc_f31fa7029241fd32_aa76ba41726a43b6 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2evalue(ptr %v0, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
@olang_loc_e17fa1ab378faab9_6d6fcc9fefe16fc5 = external constant [0 x i8]
@olang_loc_cd555273ac5ad6b8_af09fb78e7087b4 = external constant [0 x i8]
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperandParam(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCondNotBoolType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehasContract(ptr %v0, ptr %a0, i64 %a1)
declare { i32, %"compiler/typed:ContractInfo" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H1fc1bd863e6a60d3e5c2aece55d841d1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_46400974b7d00480_e2373b052a0b959c = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eRemove_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2ftyped_3aContractIn_H044304b59760c17b661e6227d2ca1ac9(ptr %v0, ptr %a0, i64 %a1)
declare ptr @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2ftyped_3aBody_26_3e_H3eb70eb9c7f7f640b98f0ba58912d6cc(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aScopeRel_3e_2eCl_H61e34197f63b762a003a73c4f2bf0624(ptr %v0, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eArgCount(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/check:litv" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efold(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftLit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeMismatch(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvWords(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econvert(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eevalOnly(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFunc(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3, i32 %a4, i64 %a5)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopyExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efitsTest(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
declare { { i64, [3 x i64] }, { i64, ptr } } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTopContext(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fcheck_3aContractAsk_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, [3 x i64] } %a7, { i64, ptr } %a8, { i64, ptr } %a9)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3aContractAsk_3e_2_H1e0eaace9d10c5af057a64b660c4ff1f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, i64, i64 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopen(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebreakUnless(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_He56f4e53267726fe8dffcfd34146d8e6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, %"compiler/source:Span" %a2)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
@olang_loc_8ffd1bc2c5314d3c_1a7e454980bc5230 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroLet(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_6754b7d1e64b38ab_d9cb88888f730d0f = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ewalkBody(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_Hb6f924c91b81223120b2cba278ece4a6(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eglobalBody(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etestBody(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, i64 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeRules(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclaredCtor(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitSets(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitHeader(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
@olang_loc_9f7e5ad647601e13_a7b1cb3e26ad346f = external constant [0 x i8]
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eChosen(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclsIf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i64 %a3, i64 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorDeclRules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotCapture(ptr %v0, ptr %v1, ptr %a0, ptr %a1, %"compiler/source:Span" %a2)
@olang_loc_9f409528a62be557_96e98ebb70e4ac13 = external constant [0 x i8]
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrWords(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
@olang_loc_92689d3fb9399c33_8949aa7cd18a1ac7 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eOwnVarIndexes(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @compiler_2fgeneric_2eWrittenTypes(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrVarIndex(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrSetArgUnwanted(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3150b71fd0fb46fe_3d08923418e7b7d2 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgsOnNonGeneric(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d7e03fe7b4bf2c3d_64b0c57621292c71 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTypeArgCount(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_c902484ee6860410_648a649019eab164 = external constant [0 x i8]
@olang_loc_293fe44c08438718_c9e2b0469f544c2c = external constant [0 x i8]
@olang_loc_2e16a6af4c93cb6a_eec2ff8433b844a6 = external constant [0 x i8]
@olang_loc_d217cc4a3a9977a9_9d0368fc739efec5 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrsArgOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisStruct(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echarValue(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/check:litv" @compiler_2fcheck_2eintLit(i64 %a0)
@olang_loc_2bda502508e1b1d_a3083ba563ab0481 = external constant [0 x i8]
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cmut_20compiler_2fcheck_3aframe_26_3_H2d42092ce658fb6cce0104fa754a4e33(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocalId_3e_2eRun_H55075af11bca18d6ea540b66cb20a6c9(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_fa7d7e355e8b1ea_2ae432ddcb4bb28e = external constant [0 x i8]
declare %"compiler/typed:Local" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaptureIn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHoldsRefs(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econtractChecks(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2, i1 %a3)
declare void @compiler_2fcheck_2estoredIn(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estmtsOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2eleavesBlock(ptr %v0, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2ftyped_3aCapture_26_3e_2e_Hc9219e836d6ca52518c31537b8e6a8eb(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCaseNames(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLeaf(ptr %v0, ptr %a0, ptr %a1)
declare %"compiler/check:laneNode" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3alaneNode_3e_2eAt_H1a82638d5202f9f6649df5fa501425e5(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBinType(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i32 %a3)
@G_2ecompiler_2fcheck_2eLaneBin = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneLen(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneDecl(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare %"compiler/check:laneNode" @compiler_2fcheck_3alaneNode_2ector(ptr %v0, ptr %v1, i64 %a0, i32 %a1, %"compiler/source:Span" %a2, %"compiler/source:Span" %a3, i64 %a4, i64 %a5, i64 %a6, ptr %a7, i32 %a8, i64 %a9, i32 %a10)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneAdd(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:laneNode" %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneHold(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_89233ed815a81c43_385dc0f6d58c413f = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstruct(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, { i64, ptr } %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneArray(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElemOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMembers(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclParams(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArgs(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_6fdba33c6e4026bf_8c9edfb8735784b = external constant [0 x i8]
@olang_loc_e5967d965d67f828_b4c4cbb3885481d4 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTakesNoArgs(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNarrowNotNumber(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epreludeWord(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efailOp(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, %"compiler/source:Span" %a2, i1 %a3)
@olang_loc_baa1666d9ed0001e_5936281468ac2d52 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eassignsName(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebranchBlock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrow(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushNulls(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epushErrNarrow(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i1 %a2, i64 %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRoot(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroKey(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_Hc59daade663458096c0c7696954afd54(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eat(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopyOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteReadOnlyCopy(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
@olang_loc_8ba315a61b976e68_980c0dda48bb0a1c = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aModules(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, ptr %a2, ptr %a3)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_4f5c9f07eee78c9b_27fcb87a83eb07cf = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eorderModule(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2eHas_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fsource_3aNameId_3e_2ePus_H36cd149548e04f3fb5948be74bb492d4(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTaskClauseError(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eDeferErrorEscapes(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emsgOwner(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eAssertMsgError(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereraise(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eRaiseNotCaught(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epathPart(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euncovered(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorUndeclared(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eErrorWordNotInSet(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleaks1(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoRawValues(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aPlace_2eType(ptr %v0, ptr %a0)
@olang_loc_e5e26ce82a519cb4_386557e0c1145fc8 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eviaTypeVar(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2enoRefl(ptr %v0)
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflName(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eReflKind(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eRvCase = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeKindType(ptr %v0, ptr %a0)
declare %"compiler/check:reflVal" @compiler_2fcheck_3areflVal_2ector(ptr %v0, ptr %v1, i1 %a0, i64 %a1, i64 %a2, { i64, ptr } %a3, i32 %a4)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eLayout(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSize(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAlign(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ervInt(ptr %v0, i64 %a0)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eConstValue(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescTypeOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/generic:Desc" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDescOf(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edescName(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:Desc" %a1)
@G_2ecompiler_2fgeneric_2eDescParam = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamDefault(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ervBool(ptr %v0, i1 %a0)
@G_2ecompiler_2fgeneric_2eDescField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efieldOffset(ptr %v0, ptr %a0, %"compiler/generic:Desc" %a1)
declare %"compiler/check:reflVal" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflFold(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eRvInt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2eProjectsType(ptr %v0, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eProject(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ememberSpan(%"compiler/source:Span" %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eReflNoType(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fcheck_2etypePathOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenericNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eArgsFit(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eWrittenArity(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eApply(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtText(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erendered(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esigText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
@olang_loc_db1f2ae5e4bef7a4_1fc823cb35fb1540 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroPlace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_64f1128892bbfadb_2fd1650a543ec847 = external constant [0 x i8]
@olang_loc_9b328daa59c12fec_530ed6f7b483a728 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_aa71917389f82fa1_ab8db462134cc7fd = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_45c1f7cb36e76579_9732da1c199d4515 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedHolds(ptr %v0, ptr %a0, i32 %a1)
declare %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aExpr_26_3e_2ector(ptr %v0, ptr %v1, i64 %a0, ptr %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fpair_3aPair_3cI64_2c_20compil_H33d643ee420c12f578033f46e688097e(ptr %v0, ptr %v1, ptr %a0, %"std/pair:Pair.1eb2466213689e002f25e81e83536e78" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enullRead(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2earrayOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotOperator(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, { i64, ptr } %a2, %"compiler/source:Span" %a3, { i64, ptr } %a4, i64 %a5, i1 %a6)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotIndexable(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5aa0e1f55b10e6f_53045464d54dc2fb = external constant [0 x i8]
@olang_loc_e4f33d7277813d9a_8adeed4fca551266 = external constant [0 x i8]
@olang_loc_b203c9fbf4c249fb_735051f472c86bf = external constant [0 x i8]
@olang_loc_85a2f2931038d80c_e5a946dd8e187d18 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esliceLength(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2, ptr %a3)
@olang_loc_2f1aad6b95023edd_c82f5ce971f0d619 = external constant [0 x i8]
declare %"compiler/typed:Slice" @compiler_2ftyped_3aSlice_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i32 %a3)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eLe_H3e76598dd6b4a90eb80e3d16fe1b70d0(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fcheck_3anarrowed_3e_2eAt_H313390349c5d53629478ea446134cf40(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_cc3b6ed7ca85eab5_875d9ef7a16c4e59 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2estmtAssigns(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
@G_2ecompiler_2fcheck_2eRvText = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCase(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_dafed6c5ce7057e_e7afeb5c7864030a = external constant [0 x i8]
@olang_loc_7873eed4a01e5678_b9c164dc568d47a4 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
