; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/place:Place" = type { { i64, ptr }, i64, i64 }
%"std/prelude/input:InputBuffer" = type { i32, i1, { i64, ptr }, i64, i64 }
define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2eScanln(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"std/prelude/place:Place" %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/place:Place"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l14 = alloca i32
  %l18 = alloca { i64, ptr }
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store %"std/prelude/place:Place" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load %"std/prelude/place:Place", ptr %l1
  call void @std_2fprelude_2fprint_2ePrint_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %t7, %"std/prelude/place:Place" %t8)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t11 = call { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v2)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb6, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l8
  br label %bb5
bb5:
  %t16 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t16, ptr %l7, !tbaa !27
  br label %bb15
bb6:
  %t17 = load i32, ptr %l9, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  br i1 %t20, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  %t22 = load i32, ptr %l9, !tbaa !23
  %t23 = lshr i32 %t22, 16
  %t24 = and i32 %t22, 65535
  %t25 = icmp eq i32 %t23, 1
  %t26 = select i1 %t25, i32 0, i32 0
  %t27 = icmp eq i32 %t23, 2
  %t28 = select i1 %t27, i32 1, i32 %t26
  %t29 = icmp eq i32 %t22, 0
  %t30 = shl i32 %t28, 16
  %t31 = or i32 %t30, %t24
  %t32 = select i1 %t29, i32 0, i32 %t31
  %t34 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t32, 0
  store { i32, { i64, ptr } } %t34, ptr %rv
  br label %ret
bb9:
  %t35 = load %"std/prelude/place:Place", ptr %l1
  %t37 = call i32 @std_2fprelude_2finput_2ereadRefused(ptr %v1, %"std/prelude/place:Place" %t35)
  store i32 %t37, ptr %l14
  %t38 = icmp ne i32 %t37, 0
  br i1 %t38, label %bb11, label %ok.39, !prof !99
ok.39:
  br label %bb10
bb10:
  br label %bb14
bb11:
  %t40 = load i32, ptr %l14, !tbaa !23
  %t41 = icmp eq i32 %t40, 65536
  br i1 %t41, label %bb12, label %bb13
bb12:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t43 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t43, i64 %t44)
  %t45 = call ptr @__olang_errpay_top_get()
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t46, i64 %t47)
  %t49 = getelementptr { i64, [2 x i64] }, ptr %t45, i32 0, i32 1
  %t50 = getelementptr { { i64, ptr } }, ptr %t49, i32 0, i32 0
  %t51 = load { i64, ptr }, ptr %t50
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call i64 @__olang_rd_quote(ptr null, i64 0, ptr %t53, i64 %t54, i8 34)
  %t56 = call ptr @__olang_sb_room(ptr %s3, i64 %t55)
  %t57 = call i64 @__olang_rd_quote(ptr %t56, i64 0, ptr %t53, i64 %t54, i8 34)
  call void @__olang_sb_add(ptr %s3, i64 %t55)
  %t58 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t59 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t58, i64 %t59)
  %t60 = load ptr, ptr %s3
  %t61 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t62 = load i64, ptr %t61
  %t63 = load ptr, ptr @__olang_prog_scope
  %t64 = call ptr @__olang_scope_alloc(ptr %t63, i64 %t62)
  call void @olang_textcopy(ptr %t64, ptr %t60, i64 %t62)
  %t65 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l18, !tbaa !27
  %t67 = getelementptr %olang.builder, ptr %s3, i32 0, i32 3
  %t68 = load ptr, ptr %t67
  %t69 = icmp ne ptr %t68, null
  br i1 %t69, label %sbgrew.70, label %sbdone.71
sbgrew.70:
  call void @__olang_sb_done(ptr %s3)
  br label %sbdone.71
sbdone.71:
  %t72 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t73 = load ptr, ptr @__olang_prog_scope
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %t73, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t81 = extractvalue { i64, ptr } %t79, 1
  %t82 = extractvalue { i64, ptr } %t79, 0
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  call void @__olang_bang_failed_text(ptr @olang_loc_78089c6e05f54348_c44345d44a04efa4, { i64, ptr } %t84, i1 false)
  unreachable
bb13:
  call void @__olang_bang_failed_plain(ptr @olang_loc_1c32c25abf9ef178_42417acd44bf71fc)
  unreachable
bb14:
  call void @__olang_check_failed(ptr @olang_loc_75bb22291815a95c_1b64f601cbc646a8)
  unreachable
bb15:
  %t85 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t86 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t85, 1
  store { i32, { i64, ptr } } %t86, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fprelude_2finput_2ereadRefused(ptr %v0, %"std/prelude/place:Place" %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/place:Place"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, [2 x i64] }
  %l5 = alloca i64
  %l7 = alloca { i64, [2 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  %t14 = alloca { i64, [2 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %"std/prelude/place:Place" %a0, ptr %l1
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  call void @olang_2emir_2eHelperKind_2eRender_2estd_2fprelude_2fplace_3aPlace(ptr %s1, ptr %l1, i64 0)
  br label %bb1
bb1:
  %t3 = load ptr, ptr %s1
  %t4 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t5 = load i64, ptr %t4
  %t6 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t5)
  call void @olang_textcopy(ptr %t6, ptr %t3, i64 %t5)
  %t7 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t8 = insertvalue { i64, ptr } %t7, ptr %t6, 1
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 3
  %t10 = load ptr, ptr %t9
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %sbgrew.12, label %sbdone.13
sbgrew.12:
  call void @__olang_sb_done(ptr %s1)
  br label %sbdone.13
sbdone.13:
  store { i64, [2 x i64] } zeroinitializer, ptr %t14
  %t15 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 0
  store i64 0, ptr %t15
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t16, 0
  %t18 = getelementptr { i64, [2 x i64] }, ptr %t14, i32 0, i32 1
  store { { i64, ptr } } %t17, ptr %t18
  %t19 = load { i64, [2 x i64] }, ptr %t14
  store { i64, [2 x i64] } %t19, ptr %l4
  %t20 = call ptr @__olang_errpay_push()
  %t21 = ptrtoint ptr %t20 to i64
  store i64 %t21, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l5
  %t23 = inttoptr i64 %t22 to ptr
  %t25 = call { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2finput_3ainput_24payload(ptr %t23, ptr %l4)
  store { i64, [2 x i64] } %t25, ptr %l7
  br label %bb2
bb2:
  %t26 = load { i64, [2 x i64] }, ptr %l7
  %t27 = load i64, ptr %l5
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_scope_alloc_a(ptr %t28, i64 24, i64 8)
  store { i64, [2 x i64] } %t26, ptr %t29
  call void @__olang_errpay_set(ptr %t29)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eBytes(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l13 = alloca i64
  %l28 = alloca i32
  %l39 = alloca i64
  %l44 = alloca i64
  %l47 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i1
  %l81 = alloca ptr
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t3 = icmp sgt i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l13, !tbaa !24
  br label %bb3
bb2:
  store i64 0, ptr %l13, !tbaa !24
  br label %bb3
bb3:
  %t7 = load i64, ptr %l13, !tbaa !24
  %t8 = icmp sge i64 %t7, 0
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t15, ptr %lp2
  %t17 = load ptr, ptr %lp2
  store { i64, ptr } %t14, ptr %t17, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_3985a8c7e5af0b6c_4b8b5d3a34f4de30)
  unreachable
bb6:
  %t18 = load i64, ptr %l3, !tbaa !24
  %t19 = load ptr, ptr %lp2
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = icmp slt i64 %t18, %t22
  %t27 = xor i1 %t25, true
  br i1 %t27, label %bb7, label %bb8
bb7:
  br label %bb30
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"std/prelude/input:InputBuffer", ptr %t29, i32 0, i32 3
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/prelude/input:InputBuffer", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = icmp eq i64 %t32, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t41)
  store i32 %t43, ptr %l28
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb13, label %ok.45, !prof !99
ok.45:
  br label %bb12
bb11:
  br label %bb15
bb12:
  br label %bb14
bb13:
  %t46 = load i32, ptr %l28, !tbaa !23
  %t47 = lshr i32 %t46, 16
  %t48 = and i32 %t46, 65535
  %t49 = icmp eq i32 %t47, 1
  %t50 = select i1 %t49, i32 1, i32 0
  %t51 = icmp eq i32 %t47, 2
  %t52 = select i1 %t51, i32 2, i32 %t50
  %t53 = icmp eq i32 %t46, 0
  %t54 = shl i32 %t52, 16
  %t55 = or i32 %t54, %t48
  %t56 = select i1 %t53, i32 0, i32 %t55
  %t58 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t56, 0
  store { i32, { i64, ptr } } %t58, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"std/prelude/input:InputBuffer", ptr %t59, i32 0, i32 4
  %t62 = load i64, ptr %t61, !tbaa !24
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"std/prelude/input:InputBuffer", ptr %t63, i32 0, i32 3
  %t66 = load i64, ptr %t65, !tbaa !24
  %t69 = sub i64 %t62, %t66
  %t70 = load ptr, ptr %lp2
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = load i64, ptr %l3, !tbaa !24
  %t77 = sub i64 %t73, %t74
  %t80 = call i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %t69, i64 %t77)
  store i64 %t80, ptr %l39
  br label %bb16
bb16:
  %t81 = load i64, ptr %l39, !tbaa !24
  store i64 %t81, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t82 = load i64, ptr %l4, !tbaa !24
  store i64 %t82, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t84 = load i64, ptr %l6, !tbaa !24
  %t85 = load i64, ptr %l5, !tbaa !24
  %t88 = icmp sgt i64 %t84, %t85
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load i64, ptr %l7, !tbaa !24
  %t92 = icmp sgt i64 %t90, 0
  br i1 %t92, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb22
bb19:
  %t94 = load i64, ptr %l6, !tbaa !24
  %t95 = load i64, ptr %l5, !tbaa !24
  %t98 = sub i64 %t94, %t95
  %t99 = load i64, ptr %l7, !tbaa !24
  %t102 = add i64 %t98, %t99
  %t104 = sub i64 %t102, 1
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = sdiv i64 %t104, %t105
  store i64 %t108, ptr %l47, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t110 = load i64, ptr %l47, !tbaa !24
  store i64 %t110, ptr %l44, !tbaa !24
  br label %bb22
bb22:
  %t111 = load i64, ptr %l44, !tbaa !24
  store i64 %t111, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t112 = load i64, ptr %l8, !tbaa !24
  %t113 = sub i64 %t112, 1
  store i64 %t113, ptr %l56, !tbaa !24
  %t114 = load i64, ptr %l8, !tbaa !24
  %t115 = icmp slt i64 %t114, 2147483648
  %t116 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp sge i64 %t116, 0
  %t120 = and i1 %t115, %t117
  store i1 %t120, ptr %l59, !tbaa !21
  br label %bb23
bb23:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb24, label %bb25
bb24:
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t129 = load i64, ptr %l5, !tbaa !24
  %t130 = load i64, ptr %l9, !tbaa !24
  %t131 = load i64, ptr %l7, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l10, !tbaa !24
  %t139 = load i64, ptr %l3, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  %t143 = add i64 %t139, %t140
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"std/prelude/input:InputBuffer", ptr %t145, i32 0, i32 3
  %t148 = load i64, ptr %t147, !tbaa !24
  %t149 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t148, %t149
  %t154 = getelementptr %"std/prelude/input:InputBuffer", ptr %t144, i32 0, i32 2
  %t156 = getelementptr { i64, ptr }, ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i8, ptr %t157, i64 %t152
  %t159 = load i8, ptr %t158, !tbaa !32
  %t161 = load ptr, ptr %lp2
  %t163 = getelementptr { i64, ptr }, ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !27
  %t165 = getelementptr i8, ptr %t164, i64 %t143
  store i8 %t159, ptr %t165, !tbaa !32
  br label %bb27
bb27:
  %t166 = load i64, ptr %l9, !tbaa !24
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %l9, !tbaa !24
  br label %bb23
bb28:
  %t171 = load ptr, ptr %l0, !tbaa !29
  store ptr %t171, ptr %l81, !tbaa !29
  %t172 = load ptr, ptr %l81, !tbaa !29
  %t173 = getelementptr %"std/prelude/input:InputBuffer", ptr %t172, i32 0, i32 3
  %t174 = load i64, ptr %t173, !tbaa !24
  %t176 = load i64, ptr %l4, !tbaa !24
  %t179 = add i64 %t174, %t176
  %t181 = load ptr, ptr %l81, !tbaa !29
  %t182 = getelementptr %"std/prelude/input:InputBuffer", ptr %t181, i32 0, i32 3
  store i64 %t179, ptr %t182, !tbaa !24
  %t183 = load i64, ptr %l3, !tbaa !24
  %t185 = load i64, ptr %l4, !tbaa !24
  %t188 = add i64 %t183, %t185
  store i64 %t188, ptr %l3, !tbaa !24
  br label %bb29
bb29:
  br label %bb6
bb30:
  %t190 = load ptr, ptr %lp2
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t193 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t191, 1
  store { i32, { i64, ptr } } %t193, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l35 = alloca i64
  %l38 = alloca i64
  %l47 = alloca i64
  %l50 = alloca i1
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca ptr
  %l87 = alloca i64
  %l92 = alloca { i64, ptr }
  %l99 = alloca i64
  %l102 = alloca i64
  %l111 = alloca i64
  %l114 = alloca i1
  %l132 = alloca i32
  %l133 = alloca ptr
  %l135 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i64
  %l144 = alloca i64
  %l151 = alloca ptr
  %l158 = alloca i1
  %l165 = alloca i1
  %l171 = alloca { i64, ptr }
  %l172 = alloca i64
  %l173 = alloca { i64, ptr }
  %l174 = alloca ptr
  %l177 = alloca i64
  %l182 = alloca { i64, ptr }
  %l189 = alloca i64
  %l192 = alloca i64
  %l201 = alloca i64
  %l204 = alloca i1
  %s5 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = sub i64 %t4, %t8
  store i64 %t11, ptr %l1, !tbaa !24
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"std/prelude/input:InputBuffer", ptr %t13, i32 0, i32 3
  %t16 = load i64, ptr %t15, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb1, label %bb2
bb1:
  store i64 0, ptr %l2, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb3, label %bb4
bb2:
  br label %bb15
bb3:
  %t28 = load i64, ptr %l4, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l35, !tbaa !24
  br label %bb8
bb5:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load i64, ptr %l2, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l4, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l38, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb7
bb7:
  %t48 = load i64, ptr %l38, !tbaa !24
  store i64 %t48, ptr %l35, !tbaa !24
  br label %bb8
bb8:
  %t49 = load i64, ptr %l35, !tbaa !24
  store i64 %t49, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t50 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t50, 1
  store i64 %t51, ptr %l47, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t53 = icmp slt i64 %t52, 2147483648
  %t54 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  %t58 = and i1 %t53, %t55
  store i1 %t58, ptr %l50, !tbaa !21
  br label %bb9
bb9:
  %t59 = load i64, ptr %l6, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb10, label %bb11
bb10:
  br label %bb14
bb11:
  br label %bb12
bb12:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l4, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l7, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l7, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"std/prelude/input:InputBuffer", ptr %t80, i32 0, i32 3
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t83, %t84
  %t89 = getelementptr %"std/prelude/input:InputBuffer", ptr %t79, i32 0, i32 2
  %t91 = getelementptr { i64, ptr }, ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i8, ptr %t92, i64 %t87
  %t94 = load i8, ptr %t93, !tbaa !32
  %t97 = getelementptr %"std/prelude/input:InputBuffer", ptr %t77, i32 0, i32 2
  %t99 = getelementptr { i64, ptr }, ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i8, ptr %t100, i64 %t78
  store i8 %t94, ptr %t101, !tbaa !32
  br label %bb13
bb13:
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l6, !tbaa !24
  br label %bb9
bb14:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = getelementptr %"std/prelude/input:InputBuffer", ptr %t107, i32 0, i32 3
  store i64 0, ptr %t109, !tbaa !24
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l1, !tbaa !24
  %t114 = getelementptr %"std/prelude/input:InputBuffer", ptr %t110, i32 0, i32 4
  store i64 %t111, ptr %t114, !tbaa !24
  br label %bb15
bb15:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"std/prelude/input:InputBuffer", ptr %t115, i32 0, i32 4
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"std/prelude/input:InputBuffer", ptr %t119, i32 0, i32 2
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t127 = icmp eq i64 %t118, %t124
  br i1 %t127, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"std/prelude/input:InputBuffer", ptr %t129, i32 0, i32 2
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l81, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l82, !tbaa !24
  %t135 = load i64, ptr %l82, !tbaa !24
  %t136 = mul i64 %t135, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t135, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  store { i64, ptr } %t139, ptr %l83, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = load i64, ptr %l82, !tbaa !24
  %t145 = mul i64 %t144, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t141, ptr %t143, i64 %t145, i1 false)
  %t146 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t146, ptr %l8, !tbaa !27
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l84, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t148, 0
  %t152 = mul i64 %t150, 2
  store i64 %t152, ptr %l87, !tbaa !24
  %t153 = load i64, ptr %l87, !tbaa !24
  %t154 = icmp sge i64 %t153, 0
  br i1 %t154, label %bb18, label %bb19
bb17:
  br label %bb34
bb18:
  %t156 = load i64, ptr %l87, !tbaa !24
  %t157 = mul i64 %t156, 1
  %t158 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t163 = load ptr, ptr %l84, !tbaa !29
  %t164 = getelementptr %"std/prelude/input:InputBuffer", ptr %t163, i32 0, i32 2
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  store { i64, ptr } %t165, ptr %l92, !tbaa !27
  %t167 = load ptr, ptr %l84, !tbaa !29
  %t168 = getelementptr %"std/prelude/input:InputBuffer", ptr %t167, i32 0, i32 2
  store { i64, ptr } %t160, ptr %t168, !tbaa !27
  %t169 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t169, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_9ebb7b2d76e16f9e_f5b8f0b55eb9c682)
  unreachable
bb20:
  %t171 = load { i64, ptr }, ptr %l92
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t173 = extractvalue { i64, ptr } %t171, 1
  call void @__olang_region_release_part(ptr %t173, i64 %t172)
  store { i64, ptr } zeroinitializer, ptr %l92
  br label %bb21
bb21:
  store i64 0, ptr %l9, !tbaa !24
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"std/prelude/input:InputBuffer", ptr %t174, i32 0, i32 4
  %t177 = load i64, ptr %t176, !tbaa !24
  store i64 %t177, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t179 = load i64, ptr %l10, !tbaa !24
  %t180 = load i64, ptr %l9, !tbaa !24
  %t183 = icmp sgt i64 %t179, %t180
  br i1 %t183, label %bb22, label %bb23
bb22:
  %t185 = load i64, ptr %l11, !tbaa !24
  %t187 = icmp sgt i64 %t185, 0
  br i1 %t187, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l99, !tbaa !24
  br label %bb27
bb24:
  %t189 = load i64, ptr %l10, !tbaa !24
  %t190 = load i64, ptr %l9, !tbaa !24
  %t193 = sub i64 %t189, %t190
  %t194 = load i64, ptr %l11, !tbaa !24
  %t197 = add i64 %t193, %t194
  %t199 = sub i64 %t197, 1
  %t200 = load i64, ptr %l11, !tbaa !24
  %t203 = sdiv i64 %t199, %t200
  store i64 %t203, ptr %l102, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l102, !tbaa !24
  br label %bb26
bb26:
  %t205 = load i64, ptr %l102, !tbaa !24
  store i64 %t205, ptr %l99, !tbaa !24
  br label %bb27
bb27:
  %t206 = load i64, ptr %l99, !tbaa !24
  store i64 %t206, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t207 = load i64, ptr %l12, !tbaa !24
  %t208 = sub i64 %t207, 1
  store i64 %t208, ptr %l111, !tbaa !24
  %t209 = load i64, ptr %l12, !tbaa !24
  %t210 = icmp slt i64 %t209, 2147483648
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = icmp sge i64 %t211, 0
  %t215 = and i1 %t210, %t212
  store i1 %t215, ptr %l114, !tbaa !21
  br label %bb28
bb28:
  %t216 = load i64, ptr %l13, !tbaa !24
  %t217 = load i64, ptr %l12, !tbaa !24
  %t220 = icmp slt i64 %t216, %t217
  %t222 = xor i1 %t220, true
  br i1 %t222, label %bb29, label %bb30
bb29:
  br label %bb33
bb30:
  br label %bb31
bb31:
  %t224 = load i64, ptr %l9, !tbaa !24
  %t225 = load i64, ptr %l13, !tbaa !24
  %t226 = load i64, ptr %l11, !tbaa !24
  %t229 = mul i64 %t225, %t226
  %t232 = add i64 %t224, %t229
  store i64 %t232, ptr %l14, !tbaa !24
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l14, !tbaa !24
  %t236 = load i64, ptr %l14, !tbaa !24
  %t238 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = getelementptr i8, ptr %t239, i64 %t236
  %t241 = load i8, ptr %t240, !tbaa !32
  %t244 = getelementptr %"std/prelude/input:InputBuffer", ptr %t234, i32 0, i32 2
  %t246 = getelementptr { i64, ptr }, ptr %t244, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = getelementptr i8, ptr %t247, i64 %t235
  store i8 %t241, ptr %t248, !tbaa !32
  br label %bb32
bb32:
  %t249 = load i64, ptr %l13, !tbaa !24
  %t252 = add i64 %t249, 1
  store i64 %t252, ptr %l13, !tbaa !24
  br label %bb28
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb34
bb34:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = getelementptr %"std/prelude/input:InputBuffer", ptr %t254, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  store i32 %t257, ptr %l132, !tbaa !23
  %t258 = load ptr, ptr %l0, !tbaa !29
  store ptr %t258, ptr %l133, !tbaa !29
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"std/prelude/input:InputBuffer", ptr %t259, i32 0, i32 4
  %t262 = load i64, ptr %t261, !tbaa !24
  store i64 %t262, ptr %l135, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr %"std/prelude/input:InputBuffer", ptr %t263, i32 0, i32 2
  %t266 = load { i64, ptr }, ptr %t265, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  store i64 %t268, ptr %l138, !tbaa !24
  %t269 = load ptr, ptr %l133, !tbaa !29
  %t270 = getelementptr %"std/prelude/input:InputBuffer", ptr %t269, i32 0, i32 2
  %t271 = load { i64, ptr }, ptr %t270, !tbaa !27
  %t272 = extractvalue { i64, ptr } %t271, 0
  store i64 %t272, ptr %l139, !tbaa !24
  %t273 = load i64, ptr %l135, !tbaa !24
  %t274 = icmp sge i64 %t273, 0
  br i1 %t274, label %bb35, label %bb36
bb35:
  %t276 = load i64, ptr %l135, !tbaa !24
  %t277 = load i64, ptr %l138, !tbaa !24
  %t278 = icmp sle i64 %t276, %t277
  br i1 %t278, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_92977f40bcde603b_fc91076acd0d7977)
  unreachable
bb37:
  %t280 = load i64, ptr %l138, !tbaa !24
  %t281 = load i64, ptr %l139, !tbaa !24
  %t282 = icmp sle i64 %t280, %t281
  br i1 %t282, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_92977f40bcde603b_fc91076acd0d7977)
  unreachable
bb39:
  %t284 = load ptr, ptr %l133, !tbaa !29
  %t285 = getelementptr %"std/prelude/input:InputBuffer", ptr %t284, i32 0, i32 2
  %t286 = getelementptr { i64, ptr }, ptr %t285, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = load i64, ptr %l135, !tbaa !24
  %t289 = load i64, ptr %l138, !tbaa !24
  %t290 = getelementptr i8, ptr %t287, i64 %t288
  %t291 = sub i64 %t289, %t288
  %t292 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t290, 1
  %t294 = load i32, ptr %l132, !tbaa !23
  %t296 = call i64 @std_2fprelude_2finput_2esysRead(ptr %v0, i32 %t294, { i64, ptr } %t293)
  store i64 %t296, ptr %l144
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_92977f40bcde603b_fc91076acd0d7977)
  unreachable
bb41:
  %t297 = load i64, ptr %l144, !tbaa !24
  store i64 %t297, ptr %l15, !tbaa !24
  %t298 = load i64, ptr %l15, !tbaa !24
  %t300 = icmp slt i64 %t298, 0
  br i1 %t300, label %bb42, label %bb43
bb42:
  store i32 65536, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t303 = load i64, ptr %l15, !tbaa !24
  %t305 = icmp eq i64 %t303, 0
  br i1 %t305, label %bb45, label %bb46
bb45:
  store i32 131072, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t308 = load ptr, ptr %l0, !tbaa !29
  store ptr %t308, ptr %l151, !tbaa !29
  %t309 = load ptr, ptr %l151, !tbaa !29
  %t310 = getelementptr %"std/prelude/input:InputBuffer", ptr %t309, i32 0, i32 4
  %t311 = load i64, ptr %t310, !tbaa !24
  %t313 = load i64, ptr %l15, !tbaa !24
  %t316 = add i64 %t311, %t313
  %t318 = load ptr, ptr %l151, !tbaa !29
  %t319 = getelementptr %"std/prelude/input:InputBuffer", ptr %t318, i32 0, i32 4
  store i64 %t316, ptr %t319, !tbaa !24
  %t320 = load ptr, ptr %l0, !tbaa !29
  %t322 = getelementptr %"std/prelude/input:InputBuffer", ptr %t320, i32 0, i32 1
  %t323 = load i1, ptr %t322, !tbaa !21
  br i1 %t323, label %bb48, label %bb49
bb48:
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t327 = getelementptr %"std/prelude/input:InputBuffer", ptr %t325, i32 0, i32 4
  %t328 = load i64, ptr %t327, !tbaa !24
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t331 = getelementptr %"std/prelude/input:InputBuffer", ptr %t329, i32 0, i32 2
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t337 = icmp eq i64 %t328, %t334
  store i1 %t337, ptr %l158, !tbaa !21
  br label %bb50
bb49:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb50
bb50:
  %t339 = load i1, ptr %l158, !tbaa !21
  br i1 %t339, label %bb51, label %bb52
bb51:
  %t340 = load ptr, ptr %l0, !tbaa !29
  %t342 = getelementptr %"std/prelude/input:InputBuffer", ptr %t340, i32 0, i32 2
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t343, 0
  %t347 = icmp slt i64 %t345, 65536
  store i1 %t347, ptr %l165, !tbaa !21
  br label %bb53
bb52:
  store i1 false, ptr %l165, !tbaa !21
  br label %bb53
bb53:
  %t349 = load i1, ptr %l165, !tbaa !21
  br i1 %t349, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s11
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"std/prelude/input:InputBuffer", ptr %t350, i32 0, i32 2
  %t353 = load { i64, ptr }, ptr %t352, !tbaa !27
  store { i64, ptr } %t353, ptr %l171, !tbaa !27
  %t354 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  store i64 %t355, ptr %l172, !tbaa !24
  %t356 = load i64, ptr %l172, !tbaa !24
  %t357 = mul i64 %t356, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t357)
  %t359 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  store { i64, ptr } %t360, ptr %l173, !tbaa !27
  %t361 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = load i64, ptr %l172, !tbaa !24
  %t366 = mul i64 %t365, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t362, ptr %t364, i64 %t366, i1 false)
  %t367 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t367, ptr %l16, !tbaa !27
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l174, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  %t373 = mul i64 %t371, 2
  store i64 %t373, ptr %l177, !tbaa !24
  %t374 = load i64, ptr %l177, !tbaa !24
  %t375 = icmp sge i64 %t374, 0
  br i1 %t375, label %bb56, label %bb57
bb55:
  br label %bb72
bb56:
  %t377 = load i64, ptr %l177, !tbaa !24
  %t378 = mul i64 %t377, 1
  %t379 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t378)
  %t380 = insertvalue { i64, ptr } undef, i64 %t377, 0
  %t381 = insertvalue { i64, ptr } %t380, ptr %t379, 1
  %t384 = load ptr, ptr %l174, !tbaa !29
  %t385 = getelementptr %"std/prelude/input:InputBuffer", ptr %t384, i32 0, i32 2
  %t386 = load { i64, ptr }, ptr %t385, !tbaa !27
  store { i64, ptr } %t386, ptr %l182, !tbaa !27
  %t388 = load ptr, ptr %l174, !tbaa !29
  %t389 = getelementptr %"std/prelude/input:InputBuffer", ptr %t388, i32 0, i32 2
  store { i64, ptr } %t381, ptr %t389, !tbaa !27
  %t390 = load i1, ptr @olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2
  br i1 %t390, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_c67b2ccd325ea30_72929b4d00680694)
  unreachable
bb58:
  %t392 = load { i64, ptr }, ptr %l182
  %t393 = extractvalue { i64, ptr } %t392, 0
  %t394 = extractvalue { i64, ptr } %t392, 1
  call void @__olang_region_release_part(ptr %t394, i64 %t393)
  store { i64, ptr } zeroinitializer, ptr %l182
  br label %bb59
bb59:
  store i64 0, ptr %l17, !tbaa !24
  %t395 = load ptr, ptr %l0, !tbaa !29
  %t397 = getelementptr %"std/prelude/input:InputBuffer", ptr %t395, i32 0, i32 4
  %t398 = load i64, ptr %t397, !tbaa !24
  store i64 %t398, ptr %l18, !tbaa !24
  store i64 1, ptr %l19, !tbaa !24
  %t400 = load i64, ptr %l18, !tbaa !24
  %t401 = load i64, ptr %l17, !tbaa !24
  %t404 = icmp sgt i64 %t400, %t401
  br i1 %t404, label %bb60, label %bb61
bb60:
  %t406 = load i64, ptr %l19, !tbaa !24
  %t408 = icmp sgt i64 %t406, 0
  br i1 %t408, label %bb62, label %bb63
bb61:
  store i64 0, ptr %l189, !tbaa !24
  br label %bb65
bb62:
  %t410 = load i64, ptr %l18, !tbaa !24
  %t411 = load i64, ptr %l17, !tbaa !24
  %t414 = sub i64 %t410, %t411
  %t415 = load i64, ptr %l19, !tbaa !24
  %t418 = add i64 %t414, %t415
  %t420 = sub i64 %t418, 1
  %t421 = load i64, ptr %l19, !tbaa !24
  %t424 = sdiv i64 %t420, %t421
  store i64 %t424, ptr %l192, !tbaa !24
  br label %bb64
bb63:
  store i64 0, ptr %l192, !tbaa !24
  br label %bb64
bb64:
  %t426 = load i64, ptr %l192, !tbaa !24
  store i64 %t426, ptr %l189, !tbaa !24
  br label %bb65
bb65:
  %t427 = load i64, ptr %l189, !tbaa !24
  store i64 %t427, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  %t428 = load i64, ptr %l20, !tbaa !24
  %t429 = sub i64 %t428, 1
  store i64 %t429, ptr %l201, !tbaa !24
  %t430 = load i64, ptr %l20, !tbaa !24
  %t431 = icmp slt i64 %t430, 2147483648
  %t432 = load i64, ptr %l21, !tbaa !24
  %t433 = icmp sge i64 %t432, 0
  %t436 = and i1 %t431, %t433
  store i1 %t436, ptr %l204, !tbaa !21
  br label %bb66
bb66:
  %t437 = load i64, ptr %l21, !tbaa !24
  %t438 = load i64, ptr %l20, !tbaa !24
  %t441 = icmp slt i64 %t437, %t438
  %t443 = xor i1 %t441, true
  br i1 %t443, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  br label %bb69
bb69:
  %t445 = load i64, ptr %l17, !tbaa !24
  %t446 = load i64, ptr %l21, !tbaa !24
  %t447 = load i64, ptr %l19, !tbaa !24
  %t450 = mul i64 %t446, %t447
  %t453 = add i64 %t445, %t450
  store i64 %t453, ptr %l22, !tbaa !24
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i64, ptr %l22, !tbaa !24
  %t457 = load i64, ptr %l22, !tbaa !24
  %t459 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t460 = load ptr, ptr %t459, !tbaa !27
  %t461 = getelementptr i8, ptr %t460, i64 %t457
  %t462 = load i8, ptr %t461, !tbaa !32
  %t465 = getelementptr %"std/prelude/input:InputBuffer", ptr %t455, i32 0, i32 2
  %t467 = getelementptr { i64, ptr }, ptr %t465, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr i8, ptr %t468, i64 %t456
  store i8 %t462, ptr %t469, !tbaa !32
  br label %bb70
bb70:
  %t470 = load i64, ptr %l21, !tbaa !24
  %t473 = add i64 %t470, 1
  store i64 %t473, ptr %l21, !tbaa !24
  br label %bb66
bb71:
  call void @__olang_scope_close(ptr %s11)
  br label %bb72
bb72:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l19 = alloca i64
  %l22 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l56 = alloca i1
  %l63 = alloca i64
  %l65 = alloca { i64, ptr }
  %l75 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca i64
  %l93 = alloca i64
  %l101 = alloca i64
  %l103 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = add i64 %t4, %t5
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"std/prelude/input:InputBuffer", ptr %t10, i32 0, i32 4
  %t13 = load i64, ptr %t12, !tbaa !24
  store i64 %t13, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = icmp sgt i64 %t15, %t16
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load i64, ptr %l4, !tbaa !24
  %t23 = icmp sgt i64 %t21, 0
  br i1 %t23, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb7
bb4:
  %t25 = load i64, ptr %l3, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = sub i64 %t25, %t26
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = add i64 %t29, %t30
  %t35 = sub i64 %t33, 1
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = sdiv i64 %t35, %t36
  store i64 %t39, ptr %l22, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb6
bb6:
  %t41 = load i64, ptr %l22, !tbaa !24
  store i64 %t41, ptr %l19, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l19, !tbaa !24
  store i64 %t42, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t43 = load i64, ptr %l6, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = icmp slt i64 %t43, %t44
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb9, label %bb10
bb9:
  br label %bb23
bb10:
  br label %bb11
bb11:
  %t51 = load i64, ptr %l2, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t53 = load i64, ptr %l4, !tbaa !24
  %t56 = mul i64 %t52, %t53
  %t59 = add i64 %t51, %t56
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i64, ptr %l7, !tbaa !24
  %t64 = getelementptr %"std/prelude/input:InputBuffer", ptr %t61, i32 0, i32 2
  %t66 = getelementptr { i64, ptr }, ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr i8, ptr %t67, i64 %t62
  %t69 = load i8, ptr %t68, !tbaa !32
  %t72 = icmp eq i8 %t69, 10
  br i1 %t72, label %bb12, label %bb13
bb12:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr %"std/prelude/input:InputBuffer", ptr %t74, i32 0, i32 3
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l8, !tbaa !24
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t80 = load i64, ptr %l7, !tbaa !24
  %t82 = add i64 %t80, 1
  %t85 = getelementptr %"std/prelude/input:InputBuffer", ptr %t79, i32 0, i32 3
  store i64 %t82, ptr %t85, !tbaa !24
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l50, !tbaa !29
  %t87 = load i64, ptr %l8, !tbaa !24
  store i64 %t87, ptr %l51, !tbaa !24
  %t88 = load i64, ptr %l7, !tbaa !24
  store i64 %t88, ptr %l52, !tbaa !24
  %t89 = load i64, ptr %l7, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb14, label %bb15
bb13:
  br label %bb21
bb14:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t96 = load i64, ptr %l7, !tbaa !24
  %t98 = sub i64 %t96, 1
  %t100 = getelementptr %"std/prelude/input:InputBuffer", ptr %t95, i32 0, i32 2
  %t102 = getelementptr { i64, ptr }, ptr %t100, i32 0, i32 1
  %t103 = load ptr, ptr %t102, !tbaa !27
  %t104 = getelementptr i8, ptr %t103, i64 %t98
  %t105 = load i8, ptr %t104, !tbaa !32
  %t108 = icmp eq i8 %t105, 13
  store i1 %t108, ptr %l56, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb16
bb16:
  %t110 = load i1, ptr %l56, !tbaa !21
  br i1 %t110, label %bb17, label %bb18
bb17:
  store i64 1, ptr %l63, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb19
bb19:
  %t111 = load i64, ptr %l52, !tbaa !24
  %t112 = load i64, ptr %l63, !tbaa !24
  %t113 = sub i64 %t111, %t112
  %t114 = load ptr, ptr %l50, !tbaa !29
  %t115 = load i64, ptr %l51, !tbaa !24
  %t117 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t114, i64 %t115, i64 %t113)
  store { i64, ptr } %t117, ptr %l65
  br label %bb20
bb20:
  %t118 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t119 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t118, 1
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t120 = load i64, ptr %l6, !tbaa !24
  %t123 = add i64 %t120, 1
  store i64 %t123, ptr %l6, !tbaa !24
  br label %bb8
bb23:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"std/prelude/input:InputBuffer", ptr %t125, i32 0, i32 4
  %t128 = load i64, ptr %t127, !tbaa !24
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t131 = getelementptr %"std/prelude/input:InputBuffer", ptr %t129, i32 0, i32 3
  %t132 = load i64, ptr %t131, !tbaa !24
  %t135 = sub i64 %t128, %t132
  store i64 %t135, ptr %l1, !tbaa !24
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t137)
  store i32 %t139, ptr %l75
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb25, label %ok.141, !prof !99
ok.141:
  br label %bb24
bb24:
  br label %bb36
bb25:
  %t142 = load i32, ptr %l75, !tbaa !23
  %t143 = ashr i32 %t142, 16
  %t145 = icmp eq i32 %t143, 2
  br i1 %t145, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  %t147 = load i32, ptr %l75, !tbaa !23
  %t148 = lshr i32 %t147, 16
  %t149 = and i32 %t147, 65535
  %t150 = icmp eq i32 %t148, 1
  %t151 = select i1 %t150, i32 1, i32 0
  %t152 = icmp eq i32 %t148, 2
  %t153 = select i1 %t152, i32 2, i32 %t151
  %t154 = icmp eq i32 %t147, 0
  %t155 = shl i32 %t153, 16
  %t156 = or i32 %t155, %t149
  %t157 = select i1 %t154, i32 0, i32 %t156
  %t159 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t157, 0
  store { i32, { i64, ptr } } %t159, ptr %rv
  br label %ret
bb28:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = getelementptr %"std/prelude/input:InputBuffer", ptr %t160, i32 0, i32 3
  %t163 = load i64, ptr %t162, !tbaa !24
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"std/prelude/input:InputBuffer", ptr %t164, i32 0, i32 4
  %t167 = load i64, ptr %t166, !tbaa !24
  %t170 = icmp eq i64 %t163, %t167
  br i1 %t170, label %bb29, label %bb30
bb29:
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 131072, 0
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
bb30:
  br label %bb31
bb31:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"std/prelude/input:InputBuffer", ptr %t174, i32 0, i32 3
  %t177 = load i64, ptr %t176, !tbaa !24
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"std/prelude/input:InputBuffer", ptr %t180, i32 0, i32 4
  %t183 = load i64, ptr %t182, !tbaa !24
  %t186 = getelementptr %"std/prelude/input:InputBuffer", ptr %t179, i32 0, i32 3
  store i64 %t183, ptr %t186, !tbaa !24
  %t187 = load ptr, ptr %l0, !tbaa !29
  store ptr %t187, ptr %l90, !tbaa !29
  store i64 %t177, ptr %l91, !tbaa !24
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"std/prelude/input:InputBuffer", ptr %t189, i32 0, i32 4
  %t192 = load i64, ptr %t191, !tbaa !24
  store i64 %t192, ptr %l93, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t196 = getelementptr %"std/prelude/input:InputBuffer", ptr %t194, i32 0, i32 4
  %t197 = load i64, ptr %t196, !tbaa !24
  %t199 = sub i64 %t197, 1
  %t201 = getelementptr %"std/prelude/input:InputBuffer", ptr %t193, i32 0, i32 2
  %t203 = getelementptr { i64, ptr }, ptr %t201, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i8, ptr %t204, i64 %t199
  %t206 = load i8, ptr %t205, !tbaa !32
  %t209 = icmp eq i8 %t206, 13
  br i1 %t209, label %bb32, label %bb33
bb32:
  store i64 1, ptr %l101, !tbaa !24
  br label %bb34
bb33:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb34
bb34:
  %t211 = load i64, ptr %l93, !tbaa !24
  %t212 = load i64, ptr %l101, !tbaa !24
  %t213 = sub i64 %t211, %t212
  %t214 = load ptr, ptr %l90, !tbaa !29
  %t215 = load i64, ptr %l91, !tbaa !24
  %t217 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t214, i64 %t215, i64 %t213)
  store { i64, ptr } %t217, ptr %l103
  br label %bb35
bb35:
  %t218 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t219 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t218, 1
  store { i32, { i64, ptr } } %t219, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb1
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eWord(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l15 = alloca i1
  %l21 = alloca i1
  %l23 = alloca ptr
  %l33 = alloca i32
  %l44 = alloca i64
  %l47 = alloca i64
  %l69 = alloca i1
  %l78 = alloca { i64, ptr }
  %l88 = alloca i32
  %l101 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  br label %bb1
bb1:
  br label %bb2
bb2:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/input:InputBuffer", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/input:InputBuffer", ptr %t5, i32 0, i32 4
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp slt i64 %t4, %t8
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"std/prelude/input:InputBuffer", ptr %t14, i32 0, i32 3
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = getelementptr %"std/prelude/input:InputBuffer", ptr %t13, i32 0, i32 2
  %t21 = getelementptr { i64, ptr }, ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr i8, ptr %t22, i64 %t17
  %t24 = load i8, ptr %t23, !tbaa !32
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsSpace(i8 %t24)
  store i1 %t27, ptr %l21
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t28 = load i1, ptr %l21, !tbaa !21
  store i1 %t28, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t29 = load i1, ptr %l15, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l23, !tbaa !29
  %t33 = load ptr, ptr %l23, !tbaa !29
  %t34 = getelementptr %"std/prelude/input:InputBuffer", ptr %t33, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t38 = add i64 %t35, 1
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = getelementptr %"std/prelude/input:InputBuffer", ptr %t40, i32 0, i32 3
  store i64 %t38, ptr %t41, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"std/prelude/input:InputBuffer", ptr %t42, i32 0, i32 3
  %t45 = load i64, ptr %t44, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"std/prelude/input:InputBuffer", ptr %t46, i32 0, i32 4
  %t49 = load i64, ptr %t48, !tbaa !24
  %t52 = icmp slt i64 %t45, %t49
  br i1 %t52, label %bb12, label %bb13
bb12:
  br label %bb19
bb13:
  br label %bb14
bb14:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t54)
  store i32 %t56, ptr %l33
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb16, label %ok.58, !prof !99
ok.58:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t59 = load i32, ptr %l33, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t60, 2
  %t65 = select i1 %t64, i32 2, i32 %t63
  %t66 = icmp eq i32 %t59, 0
  %t67 = shl i32 %t65, 16
  %t68 = or i32 %t67, %t61
  %t69 = select i1 %t66, i32 0, i32 %t68
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t69, 0
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  br label %bb1
bb19:
  store i64 0, ptr %l1, !tbaa !24
  br label %bb20
bb20:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"std/prelude/input:InputBuffer", ptr %t72, i32 0, i32 3
  %t75 = load i64, ptr %t74, !tbaa !24
  %t76 = load i64, ptr %l1, !tbaa !24
  %t79 = add i64 %t75, %t76
  store i64 %t79, ptr %l2, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"std/prelude/input:InputBuffer", ptr %t81, i32 0, i32 4
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t86 = load i64, ptr %l3, !tbaa !24
  %t87 = load i64, ptr %l2, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb21, label %bb22
bb21:
  %t92 = load i64, ptr %l4, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb26
bb23:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t97 = load i64, ptr %l2, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l4, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l4, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l47, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb25
bb25:
  %t112 = load i64, ptr %l47, !tbaa !24
  store i64 %t112, ptr %l44, !tbaa !24
  br label %bb26
bb26:
  %t113 = load i64, ptr %l44, !tbaa !24
  store i64 %t113, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb27
bb27:
  %t114 = load i64, ptr %l6, !tbaa !24
  %t115 = load i64, ptr %l5, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb28, label %bb29
bb28:
  br label %bb37
bb29:
  br label %bb30
bb30:
  %t122 = load i64, ptr %l2, !tbaa !24
  %t123 = load i64, ptr %l6, !tbaa !24
  %t124 = load i64, ptr %l4, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l7, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t133 = load i64, ptr %l7, !tbaa !24
  %t135 = getelementptr %"std/prelude/input:InputBuffer", ptr %t132, i32 0, i32 2
  %t137 = getelementptr { i64, ptr }, ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t133
  %t140 = load i8, ptr %t139, !tbaa !32
  %t143 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsSpace(i8 %t140)
  store i1 %t143, ptr %l69
  br label %bb31
bb31:
  %t144 = load i1, ptr %l69, !tbaa !21
  %t145 = xor i1 %t144, true
  br i1 %t145, label %bb32, label %bb33
bb32:
  br label %bb36
bb33:
  br label %bb34
bb34:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t149 = getelementptr %"std/prelude/input:InputBuffer", ptr %t147, i32 0, i32 3
  %t150 = load i64, ptr %t149, !tbaa !24
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l7, !tbaa !24
  %t156 = getelementptr %"std/prelude/input:InputBuffer", ptr %t152, i32 0, i32 3
  store i64 %t153, ptr %t156, !tbaa !24
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = load i64, ptr %l7, !tbaa !24
  %t163 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t157, i64 %t150, i64 %t159)
  store { i64, ptr } %t163, ptr %l78
  br label %bb35
bb35:
  %t164 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t165 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t164, 1
  store { i32, { i64, ptr } } %t165, ptr %rv
  br label %ret
bb36:
  %t166 = load i64, ptr %l6, !tbaa !24
  %t169 = add i64 %t166, 1
  store i64 %t169, ptr %l6, !tbaa !24
  br label %bb27
bb37:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"std/prelude/input:InputBuffer", ptr %t171, i32 0, i32 4
  %t174 = load i64, ptr %t173, !tbaa !24
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"std/prelude/input:InputBuffer", ptr %t175, i32 0, i32 3
  %t178 = load i64, ptr %t177, !tbaa !24
  %t181 = sub i64 %t174, %t178
  store i64 %t181, ptr %l1, !tbaa !24
  %t183 = load ptr, ptr %l0, !tbaa !29
  %t185 = call i32 @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eFill(ptr %v0, ptr %t183)
  store i32 %t185, ptr %l88
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb39, label %ok.187, !prof !99
ok.187:
  br label %bb38
bb38:
  br label %bb44
bb39:
  %t188 = load i32, ptr %l88, !tbaa !23
  %t189 = ashr i32 %t188, 16
  %t191 = icmp eq i32 %t189, 2
  br i1 %t191, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  %t193 = load i32, ptr %l88, !tbaa !23
  %t194 = lshr i32 %t193, 16
  %t195 = and i32 %t193, 65535
  %t196 = icmp eq i32 %t194, 1
  %t197 = select i1 %t196, i32 1, i32 0
  %t198 = icmp eq i32 %t194, 2
  %t199 = select i1 %t198, i32 2, i32 %t197
  %t200 = icmp eq i32 %t193, 0
  %t201 = shl i32 %t199, 16
  %t202 = or i32 %t201, %t195
  %t203 = select i1 %t200, i32 0, i32 %t202
  %t205 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t203, 0
  store { i32, { i64, ptr } } %t205, ptr %rv
  br label %ret
bb42:
  %t206 = load ptr, ptr %l0, !tbaa !29
  %t208 = getelementptr %"std/prelude/input:InputBuffer", ptr %t206, i32 0, i32 3
  %t209 = load i64, ptr %t208, !tbaa !24
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"std/prelude/input:InputBuffer", ptr %t212, i32 0, i32 4
  %t215 = load i64, ptr %t214, !tbaa !24
  %t218 = getelementptr %"std/prelude/input:InputBuffer", ptr %t211, i32 0, i32 3
  store i64 %t215, ptr %t218, !tbaa !24
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"std/prelude/input:InputBuffer", ptr %t221, i32 0, i32 4
  %t224 = load i64, ptr %t223, !tbaa !24
  %t228 = call { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %t219, i64 %t209, i64 %t224)
  store { i64, ptr } %t228, ptr %l101
  br label %bb43
bb43:
  %t229 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t230 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t229, 1
  store { i32, { i64, ptr } } %t230, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  br label %bb20
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @std_2fprelude_2finput_2esysRead(ptr %v0, i32 %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l7 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  %t9 = extractvalue { i64, ptr } %t2, 1
  %t10 = extractvalue { i64, ptr } %t2, 0
  %t12 = call i64 @read(i32 %a0, ptr %t9, i64 %t5)
  store i64 %t12, ptr %l7
  br label %bb1
bb1:
  %t13 = load i64, ptr %l7, !tbaa !24
  store i64 %t13, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

@.d0 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"input.Refused" }>, align 8
declare void @__olang_sb_put(ptr, ptr, i64)
declare ptr @__olang_errpay_top_get()
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
declare i64 @__olang_rd_quote(ptr, i64, ptr, i64, i8)
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare void @__olang_sb_add(ptr, i64)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @__olang_sb_done(ptr)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_bang_failed_text(ptr, { i64, ptr }, i1) cold noreturn
declare void @__olang_bang_failed_plain(ptr) cold noreturn
declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr void @olang_2emir_2eHelperKind_2eRender_2estd_2fprelude_2fplace_3aPlace(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l3 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/place:Place", ptr %a0
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr @__olang_prog_scope
  %t5 = call { i64, ptr } @std_2fprelude_2fplace_2estd_2fprelude_2fplace_3aPlace_2eStr(ptr %t3, ptr %s1, %"std/prelude/place:Place" %t2)
  store { i64, ptr } %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %v0, ptr %t7, i64 %t8)
  call void @__olang_scope_close(ptr %s1)
  br label %ret
ret:
  ret void
}

declare ptr @__olang_errpay_push() cold
define linkonce_odr { i64, [2 x i64] } @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2finput_3ainput_24payload(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, [2 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, [2 x i64] }
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, [2 x i64] }, ptr %a0
  store { i64, [2 x i64] } %t2, ptr %l1
  %t3 = load i64, ptr %l1, !range !{i64 0, i64 1}
  switch i64 %t3, label %bb1 [ i64 0, label %bb2 ]
bb1:
  %t5 = load { i64, [2 x i64] }, ptr %l1
  store { i64, [2 x i64] } %t5, ptr %rv
  br label %ret
bb2:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { { i64, ptr } }, ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7
  store { i64, ptr } %t8, ptr %l3, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l4, !tbaa !24
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l5, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = getelementptr { i64, [2 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { { i64, ptr } }, ptr %t23, i32 0, i32 0
  store { i64, ptr } %t22, ptr %t24
  br label %bb1
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare void @__olang_errpay_set(ptr) cold
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2estd_2fprelude_2finput_3aInputBuffer_2e2 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
declare i64 @read(i32, ptr, i64)
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare void @std_2fprelude_2fprint_2ePrint_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, %"std/prelude/place:Place" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2finput_2eStdinLine(ptr %v0)
@olang_loc_78089c6e05f54348_c44345d44a04efa4 = external constant [0 x i8]
@olang_loc_1c32c25abf9ef178_42417acd44bf71fc = external constant [0 x i8]
@olang_loc_75bb22291815a95c_1b64f601cbc646a8 = external constant [0 x i8]
@olang_loc_3985a8c7e5af0b6c_4b8b5d3a34f4de30 = external constant [0 x i8]
declare i64 @std_2fprelude_2fnumber_2eI64_2eMin_3cI64_3e(i64 %a0, i64 %a1)
@olang_loc_9ebb7b2d76e16f9e_f5b8f0b55eb9c682 = external constant [0 x i8]
@olang_loc_92977f40bcde603b_fc91076acd0d7977 = external constant [0 x i8]
@olang_loc_c67b2ccd325ea30_72929b4d00680694 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2finput_2estd_2fprelude_2finput_3aInputBuffer_2eText(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsSpace(i8 %a0)
declare { i64, ptr } @std_2fprelude_2fplace_2estd_2fprelude_2fplace_3aPlace_2eStr(ptr %v0, ptr %v1, %"std/prelude/place:Place" %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
