; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/bench:Measurement" = type { i64, i64, i64, i64, i64 }
%"std/bench:Series" = type { { i64, ptr } }
define dso_local { i64, ptr } @std_2fbench_2eHuman(ptr %v0, double %a0, double %a1) #0 {
entry:
  %l0 = alloca double
  %l1 = alloca double
  %l2 = alloca { i64, ptr }
  %l3 = alloca double
  %l5 = alloca double
  %l7 = alloca double
  %l9 = alloca double
  %l10 = alloca i64
  %lp11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l48 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store double %a0, ptr %l0
  store double %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  store double 0x3ff0000000000000, ptr %l3, !tbaa !26
  %t3 = load double, ptr %l0, !tbaa !26
  %t5 = fcmp oge double %t3, 0x41cdcd6500000000
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d1, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l16, !tbaa !27
  store double 0x41cdcd6500000000, ptr %l5, !tbaa !26
  store { i64, ptr } %t7, ptr %l18, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t10, ptr %l19, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 0
  store i64 %t12, ptr %l20, !tbaa !24
  %t13 = load i64, ptr %l20, !tbaa !24
  %t14 = mul i64 %t13, 1
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l21, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = load i64, ptr %l20, !tbaa !24
  %t23 = mul i64 %t22, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t19, ptr %t21, i64 %t23, i1 false)
  %t24 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t24, ptr %l2, !tbaa !27
  %t25 = load i1, ptr @olang_2esole_2estd__2fbench__2eHuman_2elocal_2e2
  br i1 %t25, label %bb3, label %bb4
bb2:
  %t27 = load double, ptr %l0, !tbaa !26
  %t29 = fcmp oge double %t27, 0x412e848000000000
  br i1 %t29, label %bb5, label %bb6
bb3:
  %t31 = load { i64, ptr }, ptr %l19
  %t32 = extractvalue { i64, ptr } %t31, 1
  call void @__olang_region_release(ptr %t32)
  store { i64, ptr } zeroinitializer, ptr %l19
  br label %bb4
bb4:
  %t33 = load double, ptr %l5, !tbaa !26
  store double %t33, ptr %l3, !tbaa !26
  br label %bb15
bb5:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d2, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l26, !tbaa !27
  store double 0x412e848000000000, ptr %l7, !tbaa !26
  store { i64, ptr } %t35, ptr %l28, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l29, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l30, !tbaa !24
  %t41 = load i64, ptr %l30, !tbaa !24
  %t42 = mul i64 %t41, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l31, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l30, !tbaa !24
  %t51 = mul i64 %t50, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t52, ptr %l2, !tbaa !27
  %t53 = load i1, ptr @olang_2esole_2estd__2fbench__2eHuman_2elocal_2e2
  br i1 %t53, label %bb7, label %bb8
bb6:
  %t55 = load double, ptr %l0, !tbaa !26
  %t57 = fcmp oge double %t55, 0x408f400000000000
  br i1 %t57, label %bb9, label %bb10
bb7:
  %t59 = load { i64, ptr }, ptr %l29
  %t60 = extractvalue { i64, ptr } %t59, 1
  call void @__olang_region_release(ptr %t60)
  store { i64, ptr } zeroinitializer, ptr %l29
  br label %bb8
bb8:
  %t61 = load double, ptr %l7, !tbaa !26
  store double %t61, ptr %l3, !tbaa !26
  br label %bb14
bb9:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l36, !tbaa !27
  store double 0x408f400000000000, ptr %l9, !tbaa !26
  store { i64, ptr } %t63, ptr %l38, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t66, ptr %l39, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t67, 0
  store i64 %t68, ptr %l40, !tbaa !24
  %t69 = load i64, ptr %l40, !tbaa !24
  %t70 = mul i64 %t69, 1
  %t71 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t70)
  %t72 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t73 = insertvalue { i64, ptr } %t72, ptr %t71, 1
  store { i64, ptr } %t73, ptr %l41, !tbaa !27
  %t74 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = load i64, ptr %l40, !tbaa !24
  %t79 = mul i64 %t78, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t75, ptr %t77, i64 %t79, i1 false)
  %t80 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t80, ptr %l2, !tbaa !27
  %t81 = load i1, ptr @olang_2esole_2estd__2fbench__2eHuman_2elocal_2e2
  br i1 %t81, label %bb11, label %bb12
bb10:
  br label %bb13
bb11:
  %t83 = load { i64, ptr }, ptr %l39
  %t84 = extractvalue { i64, ptr } %t83, 1
  call void @__olang_region_release(ptr %t84)
  store { i64, ptr } zeroinitializer, ptr %l39
  br label %bb12
bb12:
  %t85 = load double, ptr %l9, !tbaa !26
  store double %t85, ptr %l3, !tbaa !26
  br label %bb13
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t87 = load double, ptr %l0, !tbaa !26
  %t88 = load double, ptr %l3, !tbaa !26
  %t91 = fdiv double %t87, %t88
  %t93 = fcmp oge double %t91, 0x4059000000000000
  br i1 %t93, label %bb16, label %bb17
bb16:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb21
bb17:
  %t95 = load double, ptr %l0, !tbaa !26
  %t96 = load double, ptr %l3, !tbaa !26
  %t99 = fdiv double %t95, %t96
  %t101 = fcmp oge double %t99, 0x4024000000000000
  br i1 %t101, label %bb18, label %bb19
bb18:
  store i64 1, ptr %l53, !tbaa !24
  br label %bb20
bb19:
  store i64 2, ptr %l53, !tbaa !24
  br label %bb20
bb20:
  %t103 = load i64, ptr %l53, !tbaa !24
  store i64 %t103, ptr %l48, !tbaa !24
  br label %bb21
bb21:
  %t104 = load i64, ptr %l48, !tbaa !24
  store i64 %t104, ptr %l10, !tbaa !24
  %t105 = load double, ptr %l0, !tbaa !26
  %t106 = load double, ptr %l3, !tbaa !26
  %t109 = fdiv double %t105, %t106
  %t110 = load i64, ptr %l10, !tbaa !24
  %t113 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t109, i64 %t110)
  store { i64, ptr } %t113, ptr %l58
  br label %bb22
bb22:
  %t114 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t119 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t120 = add i64 %t117, %t119
  %t122 = extractvalue { i64, ptr } %t114, 1
  %t123 = extractvalue { i64, ptr } %t114, 0
  %t124 = add i64 %t120, %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t124)
  call void @olang_textcopy(ptr %t125, ptr %t116, i64 %t117)
  %t126 = getelementptr i8, ptr %t125, i64 %t117
  call void @olang_textcopy(ptr %t126, ptr %t118, i64 %t119)
  %t127 = getelementptr i8, ptr %t126, i64 %t119
  call void @olang_textcopy(ptr %t127, ptr %t122, i64 %t123)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t125, 1
  %t130 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t130, ptr %lp11
  %t132 = load ptr, ptr %lp11
  store { i64, ptr } %t129, ptr %t132, !tbaa !27
  %t133 = load double, ptr %l1, !tbaa !26
  %t135 = fcmp oeq double %t133, 0x0000000000000000
  br i1 %t135, label %bb23, label %bb24
bb23:
  %t137 = load ptr, ptr %lp11
  %t138 = load { i64, ptr }, ptr %t137, !tbaa !27
  store { i64, ptr } %t138, ptr %l63, !tbaa !27
  br label %bb26
bb24:
  %t140 = load ptr, ptr %lp11
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l65, !tbaa !27
  %t142 = load double, ptr %l1, !tbaa !26
  %t143 = load double, ptr %l3, !tbaa !26
  %t146 = fdiv double %t142, %t143
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %s0, double %t146, i64 %t147)
  store { i64, ptr } %t150, ptr %l70
  br label %bb25
bb25:
  %t151 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t153 = extractvalue { i64, ptr } %t152, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t156 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t157 = add i64 %t154, %t156
  %t158 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t166 = extractvalue { i64, ptr } %t151, 1
  %t167 = extractvalue { i64, ptr } %t151, 0
  %t168 = add i64 %t164, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t153, i64 %t154)
  %t170 = getelementptr i8, ptr %t169, i64 %t154
  call void @olang_textcopy(ptr %t170, ptr %t155, i64 %t156)
  %t171 = getelementptr i8, ptr %t170, i64 %t156
  call void @olang_textcopy(ptr %t171, ptr %t159, i64 %t160)
  %t172 = getelementptr i8, ptr %t171, i64 %t160
  call void @olang_textcopy(ptr %t172, ptr %t162, i64 %t163)
  %t173 = getelementptr i8, ptr %t172, i64 %t163
  call void @olang_textcopy(ptr %t173, ptr %t166, i64 %t167)
  %t174 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t169, 1
  store { i64, ptr } %t175, ptr %l63, !tbaa !27
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t177 = load { i64, ptr }, ptr %l63, !tbaa !27
  store { i64, ptr } %t177, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @std_2fbench_2estd_2fbench_3aMeasurement_2eAllocsPerOp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/bench:Measurement", ptr %t1, i32 0, i32 2
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/bench:Measurement", ptr %t8, i32 0, i32 2
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/bench:Measurement", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t15, i64 1)
  store i64 %t17, ptr %l9
  br label %bb3
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = sdiv i64 %t18, %t19
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fbench_2estd_2fbench_3aMeasurement_2eBytesPerOp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/bench:Measurement", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/bench:Measurement", ptr %t8, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/bench:Measurement", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t15, i64 1)
  store i64 %t17, ptr %l9
  br label %bb3
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = sdiv i64 %t18, %t19
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @std_2fbench_2estd_2fbench_3aMeasurement_2eInstructionsPerOp(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/bench:Measurement", ptr %t1, i32 0, i32 4
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp slt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %l4, !tbaa !24
  br label %bb4
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"std/bench:Measurement", ptr %t8, i32 0, i32 4
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/bench:Measurement", ptr %t12, i32 0, i32 0
  %t15 = load i64, ptr %t14, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t15, i64 1)
  store i64 %t17, ptr %l9
  br label %bb3
bb3:
  %t18 = load i64, ptr %l6, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = sdiv i64 %t18, %t19
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @std_2fbench_2estd_2fbench_3aMeasurement_2ecounts(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l7 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"std/bench:Measurement", ptr %t3, i32 0, i32 2
  %t6 = load i64, ptr %t5, !tbaa !24
  %t8 = icmp sge i64 %t6, 0
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = call ptr @__olang_scope_hold(ptr %v1)
  %t11 = ptrtoint ptr %t10 to i64
  store i64 %t11, ptr %l7, !tbaa !24
  %t12 = load i1, ptr @olang_2esole_2estd__2fbench__2estd__2fbench__3aMeasurement__2ecounts_2elocal_2e1
  br i1 %t12, label %bb3, label %bb4
bb2:
  br label %bb13
bb3:
  %t14 = call ptr @__olang_region_make(ptr %v1)
  %t15 = ptrtoint ptr %t14 to i64
  store i64 %t15, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = call i64 @std_2fbench_2estd_2fbench_3aMeasurement_2eAllocsPerOp(ptr %v0, ptr %t16)
  store i64 %t18, ptr %l10
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i64 @std_2fbench_2estd_2fbench_3aMeasurement_2eBytesPerOp(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l12
  br label %bb6
bb6:
  %t22 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t23 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t24 = load i64, ptr %l10, !tbaa !24
  %t25 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t26 = add i64 %t23, %t25
  %t27 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load i64, ptr %l12, !tbaa !24
  %t31 = call i64 @__olang_fmt_i64(ptr null, i64 %t30)
  %t32 = add i64 %t29, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d10, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load i64, ptr %l7
  %t37 = inttoptr i64 %t36 to ptr
  %t38 = call ptr @__olang_held_alloc(ptr %t37, i64 %t35)
  call void @olang_textcopy(ptr %t38, ptr %t22, i64 %t23)
  %t39 = getelementptr i8, ptr %t38, i64 %t23
  %t40 = call i64 @__olang_fmt_i64(ptr %t39, i64 %t24)
  %t41 = getelementptr i8, ptr %t39, i64 %t25
  call void @olang_textcopy(ptr %t41, ptr %t27, i64 %t28)
  %t42 = getelementptr i8, ptr %t41, i64 %t28
  %t43 = call i64 @__olang_fmt_i64(ptr %t42, i64 %t30)
  %t44 = getelementptr i8, ptr %t42, i64 %t31
  call void @olang_textcopy(ptr %t44, ptr %t33, i64 %t34)
  %t45 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t38, 1
  store { i64, ptr } %t46, ptr %l13, !tbaa !27
  %t47 = load i1, ptr @olang_2esole_2estd__2fbench__2estd__2fbench__3aMeasurement__2ecounts_2elocal_2e1
  br i1 %t47, label %bb7, label %bb8
bb7:
  %t49 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t52 = icmp eq i64 %t50, 0
  br i1 %t52, label %bb9, label %bb10
bb8:
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t54, ptr %l17, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t55, ptr %l1, !tbaa !27
  %t56 = load i1, ptr @olang_2esole_2estd__2fbench__2estd__2fbench__3aMeasurement__2ecounts_2elocal_2e1
  br i1 %t56, label %bb11, label %bb12
bb9:
  store { i64, ptr } zeroinitializer, ptr %l13, !tbaa !27
  br label %bb10
bb10:
  %t58 = load i64, ptr %l7
  %t59 = inttoptr i64 %t58 to ptr
  %t60 = load { i64, ptr }, ptr %l13
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = call ptr @__olang_region_or(ptr %t61, ptr null)
  %t63 = icmp ne ptr %t62, null
  %t64 = select i1 %t63, ptr %t62, ptr null
  call void @__olang_region_settle_in(ptr %t59, ptr %t64)
  br label %bb8
bb11:
  %t65 = load { i64, ptr }, ptr %l17
  %t66 = extractvalue { i64, ptr } %t65, 1
  call void @__olang_region_release(ptr %t66)
  store { i64, ptr } zeroinitializer, ptr %l17
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"std/bench:Measurement", ptr %t67, i32 0, i32 4
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = icmp sge i64 %t70, 0
  br i1 %t72, label %bb14, label %bb15
bb14:
  %t74 = call ptr @__olang_scope_hold(ptr %v1)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l22, !tbaa !24
  %t76 = load i1, ptr @olang_2esole_2estd__2fbench__2estd__2fbench__3aMeasurement__2ecounts_2elocal_2e1
  br i1 %t76, label %bb16, label %bb17
bb15:
  br label %bb25
bb16:
  %t78 = call ptr @__olang_region_make(ptr %v1)
  %t79 = ptrtoint ptr %t78 to i64
  store i64 %t79, ptr %l22, !tbaa !24
  br label %bb17
bb17:
  %t80 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t80, ptr %l24, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i64 @std_2fbench_2estd_2fbench_3aMeasurement_2eInstructionsPerOp(ptr %v0, ptr %t81)
  store i64 %t83, ptr %l26
  br label %bb18
bb18:
  %t84 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 1
  %t88 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d11, i32 0, i32 1) }, 0
  %t89 = add i64 %t86, %t88
  %t90 = load i64, ptr %l26, !tbaa !24
  %t91 = call i64 @__olang_fmt_i64(ptr null, i64 %t90)
  %t92 = add i64 %t89, %t91
  %t93 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t95 = add i64 %t92, %t94
  %t96 = load i64, ptr %l22
  %t97 = inttoptr i64 %t96 to ptr
  %t98 = call ptr @__olang_held_alloc(ptr %t97, i64 %t95)
  call void @olang_textcopy(ptr %t98, ptr %t85, i64 %t86)
  %t99 = getelementptr i8, ptr %t98, i64 %t86
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  %t101 = call i64 @__olang_fmt_i64(ptr %t100, i64 %t90)
  %t102 = getelementptr i8, ptr %t100, i64 %t91
  call void @olang_textcopy(ptr %t102, ptr %t93, i64 %t94)
  %t103 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t98, 1
  store { i64, ptr } %t104, ptr %l27, !tbaa !27
  %t105 = load i1, ptr @olang_2esole_2estd__2fbench__2estd__2fbench__3aMeasurement__2ecounts_2elocal_2e1
  br i1 %t105, label %bb19, label %bb20
bb19:
  %t107 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  %t110 = icmp eq i64 %t108, 0
  br i1 %t110, label %bb21, label %bb22
bb20:
  %t112 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t112, ptr %l31, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t113, ptr %l1, !tbaa !27
  %t114 = load i1, ptr @olang_2esole_2estd__2fbench__2estd__2fbench__3aMeasurement__2ecounts_2elocal_2e1
  br i1 %t114, label %bb23, label %bb24
bb21:
  store { i64, ptr } zeroinitializer, ptr %l27, !tbaa !27
  br label %bb22
bb22:
  %t116 = load i64, ptr %l22
  %t117 = inttoptr i64 %t116 to ptr
  %t118 = load { i64, ptr }, ptr %l27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = call ptr @__olang_region_or(ptr %t119, ptr null)
  %t121 = icmp ne ptr %t120, null
  %t122 = select i1 %t121, ptr %t120, ptr null
  call void @__olang_region_settle_in(ptr %t117, ptr %t122)
  br label %bb20
bb23:
  %t123 = load { i64, ptr }, ptr %l31
  %t124 = extractvalue { i64, ptr } %t123, 1
  call void @__olang_region_release(ptr %t124)
  store { i64, ptr } zeroinitializer, ptr %l31
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t125 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t125, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, [2 x i64] } @std_2fbench_2estd_2fbench_3aSeries_2eDisplay(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/bench:Measurement"
  %l3 = alloca %"std/bench:Measurement"
  %l5 = alloca double
  %l7 = alloca double
  %l8 = alloca { i64, ptr }
  %l10 = alloca double
  %l11 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, [2 x i64] }
  %t68 = alloca { i64, [2 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/bench:Measurement" @std_2fbench_2estd_2fbench_3aSeries_2eTypical(ptr %v0, ptr %t1)
  store %"std/bench:Measurement" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/bench:Measurement", ptr %l3
  store %"std/bench:Measurement" %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call double @std_2fbench_2estd_2fbench_3aSeries_2eMedian(ptr %v0, ptr %t5)
  store double %t7, ptr %l5
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = call double @std_2fbench_2estd_2fbench_3aSeries_2eSpread(ptr %v0, ptr %t8)
  store double %t10, ptr %l7
  br label %bb3
bb3:
  %t11 = load double, ptr %l5, !tbaa !26
  %t12 = load double, ptr %l7, !tbaa !26
  %t13 = call { i64, ptr } @std_2fbench_2eHuman(ptr %s0, double %t11, double %t12)
  store { i64, ptr } %t13, ptr %l8
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = call double @std_2fbench_2estd_2fbench_3aSeries_2eMin(ptr %v0, ptr %t14)
  store double %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load double, ptr %l10, !tbaa !26
  %t18 = call { i64, ptr } @std_2fbench_2eHuman(ptr %s0, double %t17, double 0x0000000000000000)
  store { i64, ptr } %t18, ptr %l11
  br label %bb6
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"std/bench:Series", ptr %t19, i32 0, i32 0
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = getelementptr %"std/bench:Measurement", ptr %l1, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  %t27 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 1
  %t38 = extractvalue { i64, ptr } %t36, 0
  %t39 = add i64 %t35, %t38
  %t40 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t24)
  %t45 = add i64 %t42, %t44
  %t46 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t51 = add i64 %t48, %t50
  %t52 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t27, i64 %t28)
  %t56 = getelementptr i8, ptr %t55, i64 %t28
  call void @olang_textcopy(ptr %t56, ptr %t30, i64 %t31)
  %t57 = getelementptr i8, ptr %t56, i64 %t31
  call void @olang_textcopy(ptr %t57, ptr %t33, i64 %t34)
  %t58 = getelementptr i8, ptr %t57, i64 %t34
  call void @olang_textcopy(ptr %t58, ptr %t37, i64 %t38)
  %t59 = getelementptr i8, ptr %t58, i64 %t38
  call void @olang_textcopy(ptr %t59, ptr %t40, i64 %t41)
  %t60 = getelementptr i8, ptr %t59, i64 %t41
  %t61 = call i64 @__olang_fmt_i64(ptr %t60, i64 %t24)
  %t62 = getelementptr i8, ptr %t60, i64 %t44
  call void @olang_textcopy(ptr %t62, ptr %t46, i64 %t47)
  %t63 = getelementptr i8, ptr %t62, i64 %t47
  %t64 = call i64 @__olang_fmt_i64(ptr %t63, i64 %t26)
  %t65 = getelementptr i8, ptr %t63, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t52, i64 %t53)
  %t66 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t55, 1
  store { i64, [2 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 0
  store i64 1, ptr %t69
  %t71 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t67, 0
  %t72 = getelementptr { i64, [2 x i64] }, ptr %t68, i32 0, i32 1
  store { { i64, ptr } } %t71, ptr %t72
  %t73 = load { i64, [2 x i64] }, ptr %t68
  call void @__olang_scope_close(ptr %s0)
  store { i64, [2 x i64] } %t73, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [2 x i64] }, ptr %rv
  ret { i64, [2 x i64] } %rr
}

define dso_local double @std_2fbench_2estd_2fbench_3aSeries_2eMin(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l4 = alloca double
  %l5 = alloca i64
  %l6 = alloca double
  %l7 = alloca double
  %l9 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l28 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca double
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2fbench_2estd_2fbench_3aSeries_2ePerOp(ptr %v0, ptr %s0, ptr %a0)
  store { i64, ptr } %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 0
  store i64 %t8, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp sgt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr double, ptr %t18, i64 0
  %t20 = load double, ptr %t19, !tbaa !36
  store double %t20, ptr %l4, !tbaa !26
  store i64 1, ptr %l5, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store double 0x0000000000000000, ptr %l7, !tbaa !26
  br label %bb17
bb5:
  %t22 = load i64, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb16
bb7:
  br label %bb8
bb8:
  %t30 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t30, ptr %l22, !tbaa !27
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr double, ptr %t34, i64 %t31
  %t36 = load double, ptr %t35, !tbaa !36
  store double %t36, ptr %l6, !tbaa !26
  %t38 = load double, ptr %l6, !tbaa !26
  %t39 = load double, ptr %l4, !tbaa !26
  %t42 = fcmp olt double %t38, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l28, !tbaa !21
  br label %bb11
bb10:
  %t44 = load double, ptr %l6, !tbaa !26
  %t45 = load double, ptr %l6, !tbaa !26
  %t48 = fcmp une double %t44, %t45
  store i1 %t48, ptr %l28, !tbaa !21
  br label %bb11
bb11:
  %t50 = load i1, ptr %l28, !tbaa !21
  br i1 %t50, label %bb12, label %bb13
bb12:
  %t51 = load double, ptr %l6, !tbaa !26
  store double %t51, ptr %l4, !tbaa !26
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t53 = load i64, ptr %l5, !tbaa !24
  %t56 = add i64 %t53, 1
  store i64 %t56, ptr %l5, !tbaa !24
  br label %bb5
bb16:
  %t58 = load double, ptr %l4, !tbaa !26
  store double %t58, ptr %l7, !tbaa !26
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load double, ptr %l7, !tbaa !26
  store double %t60, ptr %rv
  br label %ret
ret:
  %rr = load double, ptr %rv
  ret double %rr
}

define dso_local { i64, ptr } @std_2fbench_2estd_2fbench_3aSeries_2eStr(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/bench:Measurement"
  %l3 = alloca %"std/bench:Measurement"
  %l4 = alloca i64
  %l6 = alloca double
  %l7 = alloca { i64, ptr }
  %l9 = alloca double
  %l10 = alloca { i64, ptr }
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/bench:Measurement" @std_2fbench_2estd_2fbench_3aSeries_2eTypical(ptr %v0, ptr %t1)
  store %"std/bench:Measurement" %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load %"std/bench:Measurement", ptr %l3
  store %"std/bench:Measurement" %t4, ptr %l1
  %t5 = getelementptr %"std/bench:Measurement", ptr %l1, i32 0, i32 0
  %t6 = load i64, ptr %t5, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call double @std_2fbench_2estd_2fbench_3aSeries_2eMedian(ptr %v0, ptr %t7)
  store double %t9, ptr %l6
  br label %bb2
bb2:
  %t10 = load double, ptr %l6, !tbaa !26
  %t11 = call { i64, ptr } @std_2fbench_2enanos(ptr %s0, double %t10)
  store { i64, ptr } %t11, ptr %l7
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call double @std_2fbench_2estd_2fbench_3aSeries_2eSpread(ptr %v0, ptr %t12)
  store double %t14, ptr %l9
  br label %bb4
bb4:
  %t15 = load double, ptr %l9, !tbaa !26
  %t16 = call { i64, ptr } @std_2fbench_2enanos(ptr %s0, double %t15)
  store { i64, ptr } %t16, ptr %l10
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"std/bench:Series", ptr %t17, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  store i64 %t22, ptr %l13, !tbaa !24
  %t24 = call { i64, ptr } @std_2fbench_2estd_2fbench_3aMeasurement_2ecounts(ptr %s0, ptr %s0, ptr %l1)
  store { i64, ptr } %t24, ptr %l15
  br label %bb6
bb6:
  %t25 = load i64, ptr %l4, !tbaa !24
  %t26 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t27 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t29 = add i64 %t26, %t28
  %t30 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 1
  %t32 = extractvalue { i64, ptr } %t30, 0
  %t33 = add i64 %t29, %t32
  %t34 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t35 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t36 = add i64 %t33, %t35
  %t37 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = load i64, ptr %l13, !tbaa !24
  %t45 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t46 = add i64 %t43, %t45
  %t47 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t50 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t53)
  %t55 = call i64 @__olang_fmt_i64(ptr %t54, i64 %t25)
  %t56 = getelementptr i8, ptr %t54, i64 %t26
  call void @olang_textcopy(ptr %t56, ptr %t27, i64 %t28)
  %t57 = getelementptr i8, ptr %t56, i64 %t28
  call void @olang_textcopy(ptr %t57, ptr %t31, i64 %t32)
  %t58 = getelementptr i8, ptr %t57, i64 %t32
  call void @olang_textcopy(ptr %t58, ptr %t34, i64 %t35)
  %t59 = getelementptr i8, ptr %t58, i64 %t35
  call void @olang_textcopy(ptr %t59, ptr %t38, i64 %t39)
  %t60 = getelementptr i8, ptr %t59, i64 %t39
  call void @olang_textcopy(ptr %t60, ptr %t41, i64 %t42)
  %t61 = getelementptr i8, ptr %t60, i64 %t42
  %t62 = call i64 @__olang_fmt_i64(ptr %t61, i64 %t44)
  %t63 = getelementptr i8, ptr %t61, i64 %t45
  call void @olang_textcopy(ptr %t63, ptr %t47, i64 %t48)
  %t64 = getelementptr i8, ptr %t63, i64 %t48
  call void @olang_textcopy(ptr %t64, ptr %t51, i64 %t52)
  %t65 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t54, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t66, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ns" }>, align 8
@.d1 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2estd__2fbench__2eHuman_2elocal_2e2 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d2 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ms" }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\C2\B5s" }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" \C2\B1 " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2estd__2fbench__2estd__2fbench__3aMeasurement__2ecounts_2elocal_2e1 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
@.d8 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d9 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c" allocs/op  " }>, align 8
@.d10 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" B/op" }>, align 8
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare ptr @__olang_region_or(ptr, ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@.d11 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"  " }>, align 8
@.d12 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c" instr/op" }>, align 8
@.d13 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"| median | spread | min | runs | calls per run |\0A|---|---|---|---|---|\0A| " }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" | | " }>, align 8
@.d15 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" | " }>, align 8
@.d16 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" |" }>, align 8
@.d17 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" ops  " }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" \C2\B1 " }>, align 8
@.d19 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c" ns/op (" }>, align 8
@.d20 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c" runs)" }>, align 8
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare { i64, ptr } @std_2fprelude_2ffloat_2eF64_2eFixed(ptr %v0, double %a0, i64 %a1)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare %"std/bench:Measurement" @std_2fbench_2estd_2fbench_3aSeries_2eTypical(ptr %v0, ptr %a0)
declare double @std_2fbench_2estd_2fbench_3aSeries_2eMedian(ptr %v0, ptr %a0)
declare double @std_2fbench_2estd_2fbench_3aSeries_2eSpread(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fbench_2estd_2fbench_3aSeries_2ePerOp(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fbench_2enanos(ptr %v0, double %a0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
