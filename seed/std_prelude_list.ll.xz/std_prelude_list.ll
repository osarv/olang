; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
@G_2estd_2fprelude_2flist_2efirstChunk = global i64 zeroinitializer
@G_2estd_2fprelude_2flist_2efirstChunkLog = global i64 zeroinitializer
define dso_local void @olang_2einit_2estd_2fprelude_2flist() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @std_2fprelude_2flist_2efirstChunkLog_2einit()
  br label %bb1
bb1:
  call void @std_2fprelude_2flist_2efirstChunk_2einit()
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2efirstChunkLog_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 3, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2flist_2efirstChunk_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 8, ptr @G_2estd_2fprelude_2flist_2efirstChunk
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @std_2fprelude_2flist_2ehighBit(i64 %a0) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i64
  store i64 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l1
  %t1 = load i64, ptr %l0
  store i64 %t1, ptr %l2
  %t2 = load i64, ptr %l2
  %t3 = icmp sge i64 %t2, 4294967296
  store i1 %t3, ptr %l3
  %t4 = load i1, ptr %l3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i64, ptr %l0
  store i64 %t5, ptr %l4
  %t6 = load i64, ptr %l4
  %t7 = ashr i64 %t6, 32
  store i64 %t7, ptr %l5
  %t8 = load i64, ptr %l5
  store i64 %t8, ptr %l0
  %t9 = load i64, ptr %l1
  store i64 %t9, ptr %l6
  %t10 = load i64, ptr %l6
  %t11 = add i64 %t10, 32
  store i64 %t11, ptr %l7
  %t12 = load i64, ptr %l7
  store i64 %t12, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t13 = load i64, ptr %l0
  store i64 %t13, ptr %l8
  %t14 = load i64, ptr %l8
  %t15 = icmp sge i64 %t14, 65536
  store i1 %t15, ptr %l9
  %t16 = load i1, ptr %l9
  br i1 %t16, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load i64, ptr %l0
  store i64 %t17, ptr %l10
  %t18 = load i64, ptr %l10
  %t19 = ashr i64 %t18, 16
  store i64 %t19, ptr %l11
  %t20 = load i64, ptr %l11
  store i64 %t20, ptr %l0
  %t21 = load i64, ptr %l1
  store i64 %t21, ptr %l12
  %t22 = load i64, ptr %l12
  %t23 = add i64 %t22, 16
  store i64 %t23, ptr %l13
  %t24 = load i64, ptr %l13
  store i64 %t24, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t25 = load i64, ptr %l0
  store i64 %t25, ptr %l14
  %t26 = load i64, ptr %l14
  %t27 = icmp sge i64 %t26, 256
  store i1 %t27, ptr %l15
  %t28 = load i1, ptr %l15
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l0
  store i64 %t29, ptr %l16
  %t30 = load i64, ptr %l16
  %t31 = ashr i64 %t30, 8
  store i64 %t31, ptr %l17
  %t32 = load i64, ptr %l17
  store i64 %t32, ptr %l0
  %t33 = load i64, ptr %l1
  store i64 %t33, ptr %l18
  %t34 = load i64, ptr %l18
  %t35 = add i64 %t34, 8
  store i64 %t35, ptr %l19
  %t36 = load i64, ptr %l19
  store i64 %t36, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t37 = load i64, ptr %l0
  store i64 %t37, ptr %l20
  %t38 = load i64, ptr %l20
  %t39 = icmp sge i64 %t38, 16
  store i1 %t39, ptr %l21
  %t40 = load i1, ptr %l21
  br i1 %t40, label %bb10, label %bb11
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t41 = load i64, ptr %l0
  store i64 %t41, ptr %l22
  %t42 = load i64, ptr %l22
  %t43 = ashr i64 %t42, 4
  store i64 %t43, ptr %l23
  %t44 = load i64, ptr %l23
  store i64 %t44, ptr %l0
  %t45 = load i64, ptr %l1
  store i64 %t45, ptr %l24
  %t46 = load i64, ptr %l24
  %t47 = add i64 %t46, 4
  store i64 %t47, ptr %l25
  %t48 = load i64, ptr %l25
  store i64 %t48, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t49 = load i64, ptr %l0
  store i64 %t49, ptr %l26
  %t50 = load i64, ptr %l26
  %t51 = icmp sge i64 %t50, 4
  store i1 %t51, ptr %l27
  %t52 = load i1, ptr %l27
  br i1 %t52, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s5
  %t53 = load i64, ptr %l0
  store i64 %t53, ptr %l28
  %t54 = load i64, ptr %l28
  %t55 = ashr i64 %t54, 2
  store i64 %t55, ptr %l29
  %t56 = load i64, ptr %l29
  store i64 %t56, ptr %l0
  %t57 = load i64, ptr %l1
  store i64 %t57, ptr %l30
  %t58 = load i64, ptr %l30
  %t59 = add i64 %t58, 2
  store i64 %t59, ptr %l31
  %t60 = load i64, ptr %l31
  store i64 %t60, ptr %l1
  call void @__olang_scope_close(ptr %s5)
  br label %bb15
bb14:
  br label %bb15
bb15:
  %t61 = load i64, ptr %l0
  store i64 %t61, ptr %l32
  %t62 = load i64, ptr %l32
  %t63 = icmp sge i64 %t62, 2
  store i1 %t63, ptr %l33
  %t64 = load i1, ptr %l33
  br i1 %t64, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t65 = load i64, ptr %l1
  store i64 %t65, ptr %l34
  %t66 = load i64, ptr %l34
  %t67 = add i64 %t66, 1
  store i64 %t67, ptr %l35
  %t68 = load i64, ptr %l35
  store i64 %t68, ptr %l1
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t69 = load i64, ptr %l1
  store i64 %t69, ptr %l36
  call void @__olang_scope_close(ptr %s0)
  %t70 = load i64, ptr %l36
  store i64 %t70, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

declare void @__olang_scope_close(ptr)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
