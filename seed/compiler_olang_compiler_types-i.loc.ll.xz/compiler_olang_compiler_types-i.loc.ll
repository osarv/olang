; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_45eead6db3fccf07_9a5d2a967168878b = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_6acc68b2e7073cc7_7f35add4e439b1b3 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_6b228e8e3bb778f6_9ba10c08bed107ca = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_734dc814588cfd35_5917b733a7d676b1 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_75a586d239747118_fb7cb175b601a7c4 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_7a0277f3822d75ab_d06165a8c90fbe07 = weak_odr constant [53 x i8] c"std/prelude/vec.olang:52: array length out of range\0A\00"
@olang_loc_b509d27efc810532_83b2149f0073e7e = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_cca85bf63c0f00d3_511652e6f51d26cf = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
@olang_loc_d8f732a5541499f9_7292a0b8e151f025 = weak_odr constant [53 x i8] c"std/prelude/map.olang:84: array length out of range\0A\00"
