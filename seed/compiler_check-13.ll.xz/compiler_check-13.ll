; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/effects:Effects" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/effects:Facts", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/effects:Facts" = type { i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, [6 x i64], i64 }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64 }
%"compiler/check:frame" = type { i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/generic:Context", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i32, i64, i64, i64, i1, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i64, i64, i64, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, i1 }
%"compiler/generic:Context" = type { i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:b5aWalk" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, { i64, ptr }, ptr, i32 }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, ptr, i1, i1 }
%"compiler/check:narrowed" = type { i64, i64, i32, i64, i64, i1 }
%"compiler/check:nullNarrow" = type { { i64, ptr }, i64, i1 }
%"compiler/check:errNarrow" = type { i32, i32, i64, i1 }
%"compiler/typed:Block" = type { i32, { i64, ptr } }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/check:ctSource" = type { ptr, ptr, { i64, ptr }, i64, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr, { i64, ptr } }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, { i64, ptr }, i32, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/generic:AnySlot" = type { i32, i32, i64, i64, i1, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/typed:Item" = type { i32, i64 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/check:idleCall" = type { i64, i64, %"compiler/source:Span", { i64, ptr }, ptr }
%"compiler/check:factsCopy" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:factRead" = type { i64, { i64, ptr }, i1, i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1 }
%"compiler/check:ContractAsk" = type { i64, i64, %"compiler/source:Span", i64, %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr } }
%"compiler/check:fieldSet" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/check:laneNode" = type { i64, i32, %"compiler/source:Span", %"compiler/source:Span", i64, i64, i64, ptr, i32, i64, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/check:laneVals" = type { i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:litv" = type { i1, i1, i1, i64, double, i1, i1, i1, i128 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr, { i64, ptr } }
%"compiler/check:rawTable" = type { i32, i1, { i64, ptr }, { i64, ptr } }
%"compiler/generic:Binding" = type { i64, i64, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" = type { i64, i64 }
%"compiler/check:elemsShape" = type { { i64, ptr }, i64 }
%"compiler/check:heldCand" = type { i64, i64, i64 }
%"compiler/typed:TaskClause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr }
%"compiler/typed:Spawn" = type { { i64, ptr }, ptr, { i64, ptr }, i32 }
%"compiler/ast:Catch" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i32, %"compiler/source:Span" }
%"compiler/ast:Path" = type { %"compiler/source:Span", { i64, ptr } }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/check:typeCase" = type { i1, i1, i32, i64, i64, i1 }
%"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" = type { i32, i32 }
%"compiler/check:collWalk" = type { ptr, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/check:reflList" = type { i1, i32, i64, i64 }
%"compiler/check:signMag" = type { i1, i128 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:Compr" = type { ptr, ptr, i32, i32, ptr, ptr, i1, i64 }
define dso_local ptr @compiler_2fcheck_2ecasePath(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_27266ce16db26f9e_9560a2a6a3954b82)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"compiler/effects:Effects"
  %l13 = alloca %"compiler/effects:Effects"
  %rv = alloca ptr
  %t19 = alloca %"compiler/effects:Effects", align 8
  %t22 = alloca %"compiler/effects:Effects", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 9
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l6, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 14
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l8
  %t18 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %l8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l10
  br label %bb3
bb2:
  br label %bb6
bb3:
  %t20 = load ptr, ptr %l6, !tbaa !29
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  call void @compiler_2feffects_3aEffects_2ector(ptr %t19, ptr %v0, ptr %v0, ptr %v0, ptr %t20, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21)
  call void @llvm.memmove.p0.p0.i64(ptr %l11, ptr %t19, i64 1016, i1 false)
  br label %bb4
bb4:
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2feffects_3aEffects(ptr %t22, ptr %v0, ptr %l11)
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %t22, i64 1016, i1 false)
  br label %bb5
bb5:
  %t24 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 1016, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t24, ptr %l13, i64 1016, i1 false)
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 9
  store ptr %t24, ptr %t27, !tbaa !29
  br label %bb6
bb6:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 9
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = icmp eq ptr %t31, null
  br i1 %t33, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_76d1a478b1ca441c_29a7b400711a77a8)
  unreachable
bb8:
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 9
  %t38 = load ptr, ptr %t37, !tbaa !29
  store ptr %t38, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eSpellFrom(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  %t5 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 7
  store i64 %a1, ptr %t5, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ealiasModule(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca %"compiler/source:Span"
  %l6 = alloca i1
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l24 = alloca %"compiler/names:Ref"
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l40 = alloca %"compiler/names:Ref"
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportPath(ptr %v0, ptr %v1, ptr %t1, ptr %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l1, !tbaa !29
  store ptr %t10, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t11 = load ptr, ptr %l10, !tbaa !29
  %t12 = icmp ne ptr %t11, null
  br i1 %t12, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l10, !tbaa !29
  %t15 = load i64, ptr %t14, !range !{i64 0, i64 30}
  %t17 = icmp eq i64 %t15, 0
  store i1 %t17, ptr %l11, !tbaa !21
  br label %bb6
bb6:
  %t18 = load i1, ptr %l11, !tbaa !21
  br i1 %t18, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t21 = getelementptr { i64, [4 x i64] }, ptr %t19, i32 0, i32 1
  %t22 = getelementptr { %"compiler/source:Span", i32 }, ptr %t21, i32 0, i32 0
  %t23 = load %"compiler/source:Span", ptr %t22
  store %"compiler/source:Span" %t23, ptr %l2
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/check:Checker", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/generic:Program", ptr %t28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t32)
  store ptr %t34, ptr %l20
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l20, !tbaa !29
  %t37 = getelementptr %"compiler/check:frame", ptr %t35, i32 0, i32 2
  %t38 = load i64, ptr %t37, !tbaa !24
  %t39 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = load ptr, ptr %l18, !tbaa !29
  %t44 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t41, i64 %t38, i32 %t40)
  store %"compiler/names:Ref" %t44, ptr %l24
  br label %bb11
bb11:
  %t45 = getelementptr %"compiler/names:Ref", ptr %l24, i32 0, i32 1
  %t46 = load i64, ptr %t45, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  br label %bb25
bb12:
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t49 = load ptr, ptr %l26, !tbaa !29
  %t50 = icmp ne ptr %t49, null
  br i1 %t50, label %bb13, label %bb14
bb13:
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = load i64, ptr %t52, !range !{i64 0, i64 30}
  %t55 = icmp eq i64 %t53, 14
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l1, !tbaa !29
  %t59 = getelementptr { i64, [4 x i64] }, ptr %t57, i32 0, i32 1
  %t60 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t59, i32 0, i32 0
  %t61 = load %"compiler/source:Span", ptr %t60
  store %"compiler/source:Span" %t61, ptr %l3
  br label %bb17
bb16:
  br label %bb20
bb17:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr %"compiler/check:Checker", ptr %t63, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !29
  %t68 = getelementptr %"compiler/generic:Program", ptr %t66, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !29
  store ptr %t69, ptr %l34, !tbaa !29
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l36
  br label %bb18
bb18:
  %t73 = load ptr, ptr %l36, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 2
  %t76 = load i64, ptr %t75, !tbaa !24
  %t77 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t78 = load i32, ptr %t77, !tbaa !23
  %t79 = load ptr, ptr %l34, !tbaa !29
  %t82 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t79, i64 %t76, i32 %t78)
  store %"compiler/names:Ref" %t82, ptr %l40
  br label %bb19
bb19:
  %t83 = getelementptr %"compiler/names:Ref", ptr %l40, i32 0, i32 1
  %t84 = load i64, ptr %t83, !tbaa !24
  store i64 %t84, ptr %l9, !tbaa !24
  br label %bb25
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i64 -1, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_b38f45ec26bed975_efda74b8eb60f0c1)
  unreachable
bb25:
  %t86 = load i64, ptr %l9, !tbaa !24
  store i64 %t86, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanyCopies(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l4 = alloca i1
  %l6 = alloca i1
  %l9 = alloca ptr
  %l12 = alloca i32
  %l13 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %t1, i32 %t2)
  store i1 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i1, ptr %l4, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = getelementptr %"compiler/generic:Program", ptr %t12, i32 0, i32 2
  store ptr %t14, ptr %l9, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load i32, ptr %l1, !tbaa !23
  %t19 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t15, i32 %t16)
  store i32 %t19, ptr %l12
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l9, !tbaa !29
  %t21 = load i32, ptr %l12, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t20, i32 %t21)
  store i32 %t22, ptr %l13
  br label %bb5
bb5:
  %t23 = load i32, ptr %l13, !range !{i32 0, i32 33}
  %t25 = trunc i64 19 to i32
  %t26 = icmp eq i32 %t23, %t25
  store i1 %t26, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t28 = load i1, ptr %l6, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanySpawned(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, ptr %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i32
  %l14 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca ptr
  %l19 = alloca %"compiler/source:Span"
  %l20 = alloca { i64, ptr }
  %l21 = alloca %"compiler/diagmsg:Msg"
  %l22 = alloca i64
  %l25 = alloca { i64, ptr }
  %l30 = alloca i32
  %l33 = alloca %"std/prelude/text:StringBuilder"
  %l36 = alloca ptr
  %l41 = alloca i32
  %l42 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca i64
  %l56 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l66 = alloca i64
  %l68 = alloca ptr
  %l70 = alloca %"compiler/source:Span"
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l74 = alloca %"compiler/source:Span"
  %l75 = alloca i32
  %l77 = alloca %"compiler/source:Span"
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l84 = alloca %"compiler/source:Span"
  %l85 = alloca { i64, ptr }
  %l86 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store i32 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l14, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t8)
  store %"compiler/source:Span" %t10, ptr %l16
  br label %bb3
bb2:
  br label %bb8
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l17, !tbaa !29
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t14 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t12)
  store %"compiler/source:Span" %t14, ptr %l19
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l17, !tbaa !29
  %t16 = load %"compiler/source:Span", ptr %l19
  %t17 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t15, %"compiler/source:Span" %t16)
  store { i64, ptr } %t17, ptr %l20
  br label %bb5
bb5:
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t19 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %s1, { i64, ptr } %t18)
  store %"compiler/diagmsg:Msg" %t19, ptr %l21
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load %"compiler/source:Span", ptr %l16
  %t22 = load %"compiler/diagmsg:Msg", ptr %l21
  %t23 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t20, %"compiler/source:Span" %t21, %"compiler/diagmsg:Msg" %t22)
  store i64 %t23, ptr %l22
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i32, ptr %l4, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t24, i32 %t25)
  store { i64, ptr } %t28, ptr %l25
  br label %bb9
bb9:
  %t29 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/check:Checker", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/generic:Program", ptr %t33, i32 0, i32 2
  %t36 = load i32, ptr %l4, !tbaa !23
  %t39 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t35, i32 %t36)
  store i32 %t39, ptr %l30
  br label %bb10
bb10:
  %t40 = load i32, ptr %l30, !range !{i32 0, i32 33}
  %t42 = trunc i64 22 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t45 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s2)
  store %"std/prelude/text:StringBuilder" %t45, ptr %l33
  br label %bb13
bb12:
  br label %bb33
bb13:
  %t46 = load %"std/prelude/text:StringBuilder", ptr %l33
  store %"std/prelude/text:StringBuilder" %t46, ptr %l6
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  store ptr %t52, ptr %l36, !tbaa !29
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/check:Checker", ptr %t53, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !29
  %t58 = getelementptr %"compiler/generic:Program", ptr %t56, i32 0, i32 2
  %t59 = load i32, ptr %l4, !tbaa !23
  %t62 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t58, i32 %t59)
  store i32 %t62, ptr %l41
  br label %bb14
bb14:
  %t63 = load ptr, ptr %l36, !tbaa !29
  %t64 = load i32, ptr %l41, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t63, i32 %t64)
  store { i64, ptr } %t65, ptr %l42
  br label %bb15
bb15:
  %t66 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t66, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  store i64 %t69, ptr %l9, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s4
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s4)
  br label %bb28
bb18:
  br label %bb19
bb19:
  %t79 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t79, ptr %l49, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  %t82 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr i32, ptr %t83, i64 %t80
  %t85 = load i32, ptr %t84, !tbaa !33
  store i32 %t85, ptr %l10, !tbaa !23
  %t88 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s2, ptr %l6)
  store i64 %t88, ptr %l53
  br label %bb20
bb20:
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = icmp sgt i64 %t89, 0
  br i1 %t90, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s5
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s5, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  store ptr %l6, ptr %l56, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load i32, ptr %l10, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t93, i32 %t94)
  store { i64, ptr } %t97, ptr %l59
  br label %bb25
bb25:
  %t98 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s2, ptr %s4, ptr %t105, { i64, ptr } %t104)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb27:
  %t107 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l8, !tbaa !24
  br label %bb16
bb28:
  %t112 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s2, ptr %s0, ptr %l6)
  store { i64, ptr } %t112, ptr %l64
  br label %bb29
bb29:
  %t113 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 0
  %t115 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t116 = extractvalue { i64, ptr } %t115, 0
  store i64 %t116, ptr %l66, !tbaa !24
  %t118 = load i64, ptr %l66, !tbaa !24
  %t119 = icmp eq i64 %t114, %t118
  br i1 %t119, label %bb30, label %bb31
bb30:
  %t121 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l66, !tbaa !24
  %t126 = mul i64 %t125, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t122, ptr %t124, i64 %t126, i1 false)
  br label %bb32
bb31:
  %t127 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t127, ptr %l5, !tbaa !27
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s2)
  br label %bb33
bb33:
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l68, !tbaa !29
  %t129 = load ptr, ptr %l3, !tbaa !29
  %t131 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t129)
  store %"compiler/source:Span" %t131, ptr %l70
  br label %bb34
bb34:
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l71, !tbaa !29
  %t133 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t133, ptr %l72, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr ptr, ptr %t135, i64 0
  %t137 = load ptr, ptr %t136, !tbaa !39
  %t139 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t137)
  store %"compiler/source:Span" %t139, ptr %l74
  br label %bb35
bb35:
  %t140 = getelementptr %"compiler/source:Span", ptr %l74, i32 0, i32 0
  %t141 = load i32, ptr %t140, !tbaa !23
  store i32 %t141, ptr %l75, !tbaa !23
  %t144 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t144, ptr %l77
  br label %bb36
bb36:
  %t145 = getelementptr %"compiler/source:Span", ptr %l77, i32 0, i32 0
  %t146 = load i32, ptr %t145, !tbaa !23
  %t147 = load i32, ptr %l75, !tbaa !23
  %t149 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t147, i32 %t146)
  store %"compiler/source:Span" %t149, ptr %l79
  br label %bb37
bb37:
  %t150 = load ptr, ptr %l71, !tbaa !29
  %t151 = load %"compiler/source:Span", ptr %l79
  %t152 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t150, %"compiler/source:Span" %t151)
  store { i64, ptr } %t152, ptr %l80
  br label %bb38
bb38:
  %t153 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t153, ptr %l81, !tbaa !27
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l82, !tbaa !29
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t157 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t155)
  store %"compiler/source:Span" %t157, ptr %l84
  br label %bb39
bb39:
  %t158 = load ptr, ptr %l82, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l84
  %t160 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t158, %"compiler/source:Span" %t159)
  store { i64, ptr } %t160, ptr %l85
  br label %bb40
bb40:
  %t161 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t164 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %s0, ptr %v0, ptr %s0, { i64, ptr } %t161, { i64, ptr } %t162, { i64, ptr } %t163)
  store %"compiler/diagmsg:Msg" %t164, ptr %l86
  br label %bb41
bb41:
  %t165 = load ptr, ptr %l68, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l70
  %t167 = load %"compiler/diagmsg:Msg", ptr %l86
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t165, %"compiler/source:Span" %t166, %"compiler/diagmsg:Msg" %t167)
  store i64 %t168, ptr %l87
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l20 = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 2}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [2 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { ptr }, ptr %t12, i32 0, i32 0
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb12
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l1, !tbaa !29
  %t18 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %t16, ptr %t17, ptr %t18)
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t25 = getelementptr %"compiler/check:b5aWalk", ptr %t23, i32 0, i32 6
  %t26 = load i1, ptr %t25, !tbaa !21
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l17, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t34 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v2, ptr %t32)
  store i32 %t34, ptr %l20
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t35 = load ptr, ptr %l17, !tbaa !29
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = load i32, ptr %l20, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %t35, ptr %t36, i32 %t37, i64 0)
  br label %bb10
bb10:
  br label %bb11
bb11:
  br label %bb17
bb12:
  br i1 true, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_fd984862ae15b7b5_96e74f0ca55af519)
  unreachable
bb17:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebothSpellings(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l14 = alloca i1
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l24 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i32
  %l33 = alloca i32
  %l34 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i1
  %l43 = alloca ptr
  %l46 = alloca ptr
  %l50 = alloca i32
  %l51 = alloca i32
  %l52 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l64 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca { i64, ptr }
  %l75 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb4
bb2:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l12, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t11)
  store i1 %t13, ptr %l14
  br label %bb3
bb3:
  %t14 = load i1, ptr %l14, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l11, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t22 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %s0, ptr %t18, { i64, ptr } %t19)
  store { i64, ptr } %t22, ptr %l18
  br label %bb8
bb8:
  %t23 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 0
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = call i64 @compiler_2fcheck_2eprotocolArity(ptr %s0, { i64, ptr } %t29)
  store i64 %t31, ptr %l20
  br label %bb9
bb9:
  %t32 = load i64, ptr %l20, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp eq i64 %t33, -2
  br i1 %t35, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  %t37 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v1, ptr %s0, { i64, ptr } %t37)
  store { i64, ptr } %t39, ptr %l24
  br label %bb13
bb13:
  %t40 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t40, ptr %l6, !tbaa !27
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t41, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load i32, ptr %l2, !tbaa !23
  store i32 %t45, ptr %l27, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 0
  %t52 = load ptr, ptr %t51, !tbaa !29
  %t54 = getelementptr %"compiler/load:Loader", ptr %t52, i32 0, i32 3
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t59 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s0, ptr %t55, { i64, ptr } %t56)
  store i32 %t59, ptr %l33
  br label %bb14
bb14:
  %t60 = load ptr, ptr %l26, !tbaa !29
  %t61 = load i32, ptr %l27, !tbaa !23
  %t62 = load i32, ptr %l33, !tbaa !23
  %t63 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %t60, i32 %t61, i32 %t62)
  store i64 %t63, ptr %l34
  br label %bb15
bb15:
  %t64 = load i64, ptr %l34, !tbaa !24
  store i64 %t64, ptr %l7, !tbaa !24
  %t65 = load i64, ptr %l7, !tbaa !24
  %t67 = icmp slt i64 %t65, 0
  br i1 %t67, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb17:
  %t69 = load i64, ptr %l5, !tbaa !24
  %t71 = icmp sge i64 %t69, 0
  br i1 %t71, label %bb18, label %bb19
bb18:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l43, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  store ptr %t84, ptr %l46, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l7, !tbaa !24
  %t92 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t88, i64 %t89)
  store i32 %t92, ptr %l50
  br label %bb20
bb19:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb23
bb20:
  %t93 = load ptr, ptr %l46, !tbaa !29
  %t94 = load i32, ptr %l50, !tbaa !23
  %t95 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t93, i32 %t94)
  store i32 %t95, ptr %l51
  br label %bb21
bb21:
  %t96 = load ptr, ptr %l43, !tbaa !29
  %t97 = load i32, ptr %l51, !tbaa !23
  %t98 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t96, i32 %t97)
  store { i64, ptr } %t98, ptr %l52
  br label %bb22
bb22:
  %t99 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t102 = sub i64 %t100, 1
  %t106 = icmp ne i64 %t102, %a4
  store i1 %t106, ptr %l40, !tbaa !21
  br label %bb23
bb23:
  %t108 = load i1, ptr %l40, !tbaa !21
  store i1 %t108, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t109 = load i1, ptr %l37, !tbaa !21
  br i1 %t109, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb26:
  br label %bb27
bb27:
  %t110 = load ptr, ptr %l0, !tbaa !29
  store ptr %t110, ptr %l57, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  store ptr %t111, ptr %l58, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t119 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t115, i64 %a1)
  store ptr %t119, ptr %l62
  br label %bb28
bb28:
  %t120 = load ptr, ptr %l58, !tbaa !29
  %t121 = load ptr, ptr %l62, !tbaa !29
  %t122 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t120, ptr %t121)
  store %"compiler/source:Span" %t122, ptr %l63
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l64, !tbaa !29
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t129 = getelementptr %"compiler/generic:Program", ptr %t127, i32 0, i32 2
  %t130 = load i32, ptr %l2, !tbaa !23
  %t133 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %t129, i32 %t130)
  store i32 %t133, ptr %l69
  br label %bb30
bb30:
  %t134 = load ptr, ptr %l64, !tbaa !29
  %t135 = load i32, ptr %l69, !tbaa !23
  %t136 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s0, ptr %t134, i32 %t135)
  store { i64, ptr } %t136, ptr %l70
  br label %bb31
bb31:
  %t137 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t146 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t151 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %s0, ptr %v1, ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t143, { i64, ptr } %t144, { i64, ptr } %t145, { i64, ptr } %t146)
  store %"compiler/diagmsg:Msg" %t151, ptr %l75
  br label %bb32
bb32:
  %t152 = load ptr, ptr %l57, !tbaa !29
  %t153 = load %"compiler/source:Span", ptr %l63
  %t154 = load %"compiler/diagmsg:Msg", ptr %l75
  %t155 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t152, %"compiler/source:Span" %t153, %"compiler/diagmsg:Msg" %t154)
  store i64 %t155, ptr %l76
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebuiltinType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca i1
  %l10 = alloca i1
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a1)
  store { i64, ptr } %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t7, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t9, ptr %l7
  br label %bb2
bb2:
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  %t11 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t11, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t15 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t13, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i1 %t15, ptr %l10
  br label %bb6
bb6:
  %t16 = load i1, ptr %l10, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb7:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t17, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t19, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t24, { i64, ptr } %t25)
  store i32 %t28, ptr %l16
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l16, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l7 = alloca i64
  %l14 = alloca i64
  %l18 = alloca ptr
  %l26 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, [3 x i64] }
  %rv = alloca { i64, [3 x i64] }
  %t11 = alloca { i64, [3 x i64] }, align 8
  %t46 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledInst(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l7
  br label %bb1
bb1:
  %t6 = load i64, ptr %l7, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store { i64, [3 x i64] } zeroinitializer, ptr %t11
  %t12 = getelementptr { i64, [3 x i64] }, ptr %t11, i32 0, i32 0
  store i64 0, ptr %t12
  %t13 = load { i64, [3 x i64] }, ptr %t11
  store { i64, [3 x i64] } %t13, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !29
  %t19 = load i64, ptr %l2, !tbaa !24
  %t22 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t18, i64 %t19)
  store i64 %t22, ptr %l14
  br label %bb5
bb5:
  %t23 = load i64, ptr %l14, !tbaa !24
  store i64 %t23, ptr %l3, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store ptr %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/ast:Func", ptr %t32, i32 0, i32 3
  %t35 = load ptr, ptr %t34, !tbaa !29
  %t37 = getelementptr %"compiler/ast:Sig", ptr %t35, i32 0, i32 1
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l4, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 0
  %t44 = icmp eq i64 %t42, 0
  br i1 %t44, label %bb7, label %bb8
bb7:
  store { i64, [3 x i64] } zeroinitializer, ptr %t46
  %t47 = getelementptr { i64, [3 x i64] }, ptr %t46, i32 0, i32 0
  store i64 0, ptr %t47
  %t48 = load { i64, [3 x i64] }, ptr %t46
  store { i64, [3 x i64] } %t48, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l26, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l3, !tbaa !24
  %t58 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t54, i64 %t55)
  store i64 %t58, ptr %l30
  br label %bb10
bb10:
  %t59 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t59, ptr %l31, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr ptr, ptr %t61, i64 0
  %t63 = load ptr, ptr %t62, !tbaa !39
  %t65 = load ptr, ptr %l26, !tbaa !29
  %t66 = load i64, ptr %l30, !tbaa !24
  %t68 = call { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v0, ptr %t65, i64 %t66, ptr %t63)
  store { i64, [3 x i64] } %t68, ptr %l34
  br label %bb11
bb11:
  %t69 = load { i64, [3 x i64] }, ptr %l34
  store { i64, [3 x i64] } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [3 x i64] }, ptr %rv
  ret { i64, [3 x i64] } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/generic:Context"
  %l5 = alloca i32
  %l6 = alloca { i64, i32 }
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l16 = alloca ptr
  %l18 = alloca %"compiler/generic:Context"
  %l20 = alloca %"compiler/generic:Context"
  %l25 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca { i64, i32 }
  %l46 = alloca i1
  %l50 = alloca ptr
  %l53 = alloca i64
  %l55 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t21 = alloca %"compiler/generic:Context", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t7 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %a1)
  store ptr %t7, ptr %l11
  br label %bb2
bb2:
  %t8 = load ptr, ptr %l11, !tbaa !29
  store ptr %t8, ptr %l3, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t11 = icmp eq ptr %t9, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t14 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t14, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l16
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l16, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t20, i64 160, i1 false)
  call void @olang_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %t21, ptr %s0, ptr %l18)
  call void @llvm.memmove.p0.p0.i64(ptr %l20, ptr %t21, i64 160, i1 false)
  br label %bb7
bb7:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l20, i64 160, i1 false)
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t31 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %s0, ptr %s0, ptr %t26, ptr %l4, ptr %t27)
  store i32 %t31, ptr %l25
  br label %bb8
bb8:
  %t32 = load i32, ptr %l25, !tbaa !23
  store i32 %t32, ptr %l5, !tbaa !23
  %t33 = load i32, ptr %l5, !tbaa !23
  %t34 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t37 = icmp ne i32 %t33, %t34
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/check:Checker", ptr %t39, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !29
  %t43 = load i32, ptr %l5, !tbaa !23
  %t44 = load ptr, ptr %lp2
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v2, ptr %t42, i32 %t43, ptr %t44)
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t48 = load ptr, ptr %l0, !tbaa !29
  store ptr %t48, ptr %l33, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %lp2
  %t53 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v2, ptr %v2, ptr %t49, ptr %t50)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t53, ptr %l36
  br label %bb12
bb12:
  %t54 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t55 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %t55
  %t56 = load ptr, ptr %l33, !tbaa !29
  %t58 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v2, ptr %v2, ptr %t56, ptr %t55)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %l38
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  %t60 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t65 = call { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %s0, ptr %t61, ptr %t62)
  store { i64, i32 } %t65, ptr %l41
  br label %bb15
bb15:
  %t66 = load { i64, i32 }, ptr %l41
  store { i64, i32 } %t66, ptr %l6
  %t67 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 0
  %t68 = load i64, ptr %t67, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  %t70 = getelementptr { i64, i32 }, ptr %l6, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  store i32 %t71, ptr %l8, !tbaa !23
  %t73 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp slt i64 %t73, 0
  br i1 %t75, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb18
bb17:
  %t77 = load i64, ptr %l7, !tbaa !24
  %t79 = icmp sge i64 %t77, 64
  store i1 %t79, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t81 = load i1, ptr %l46, !tbaa !21
  br i1 %t81, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t83 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t83, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t84 = load ptr, ptr %lp2
  store ptr %t84, ptr %l50, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load i32, ptr %l8, !tbaa !23
  %t87 = load i64, ptr %l7, !tbaa !24
  store i64 %t87, ptr %l53, !tbaa !24
  %t88 = load i64, ptr %l53, !tbaa !24
  %t89 = load i64, ptr %l53, !tbaa !24
  %t90 = shl i64 1, %t89
  %t94 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t85, i32 %t86, i64 %t90)
  store i32 %t94, ptr %l55
  br label %bb22
bb22:
  %t95 = load ptr, ptr %l50, !tbaa !29
  %t96 = load i32, ptr %l55, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t95, i32 %t96)
  br label %bb23
bb23:
  %t97 = load ptr, ptr %lp2
  %t98 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t97
  call void @__olang_scope_close(ptr %s0)
  %t100 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t98, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t100, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclose(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l17 = alloca i64
  %l19 = alloca i1
  %l20 = alloca %"compiler/check:narrowed"
  %l23 = alloca %"compiler/check:narrowed"
  %l24 = alloca i32
  %l29 = alloca %"compiler/check:narrowed"
  %l32 = alloca %"compiler/check:narrowed"
  %l33 = alloca i32
  %l39 = alloca i64
  %l41 = alloca i1
  %l42 = alloca %"compiler/check:nullNarrow"
  %l45 = alloca %"compiler/check:nullNarrow"
  %l46 = alloca i32
  %l51 = alloca %"compiler/check:nullNarrow"
  %l54 = alloca %"compiler/check:nullNarrow"
  %l55 = alloca i32
  %l58 = alloca i64
  %l60 = alloca i1
  %l61 = alloca %"compiler/check:errNarrow"
  %l64 = alloca %"compiler/check:errNarrow"
  %l65 = alloca i32
  %l70 = alloca %"compiler/check:errNarrow"
  %l73 = alloca %"compiler/check:errNarrow"
  %l74 = alloca i32
  %l80 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i32
  %l91 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i32
  %l101 = alloca i64
  %l103 = alloca i1
  %l104 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i32
  %l112 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i32
  %l121 = alloca ptr
  %l128 = alloca %"compiler/typed:Block"
  %s3 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 37
  %t7 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t3, i64 %a4)
  store { i64, ptr } %t7, ptr %l10
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %t9, i64 %a3)
  br label %bb2
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t13)
  store ptr %t15, ptr %l14
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l14, !tbaa !29
  store ptr %t16, ptr %l6, !tbaa !29
  br label %bb4
bb4:
  %t17 = load ptr, ptr %l6, !tbaa !29
  %t19 = getelementptr %"compiler/check:frame", ptr %t17, i32 0, i32 46
  %t21 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t19)
  store i64 %t21, ptr %l17
  br label %bb5
bb5:
  %t22 = load i64, ptr %l17, !tbaa !24
  %t23 = icmp sgt i64 %t22, 0
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l6, !tbaa !29
  %t27 = getelementptr %"compiler/check:frame", ptr %t25, i32 0, i32 46
  %t29 = call { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLast_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t27)
  %t30 = extractvalue { i32, %"compiler/check:narrowed" } %t29, 1
  %t31 = extractvalue { i32, %"compiler/check:narrowed" } %t29, 0
  store i32 %t31, ptr %l24
  %t32 = icmp ne i32 %t31, 0
  br i1 %t32, label %bb9, label %ok.33, !prof !99
ok.33:
  store %"compiler/check:narrowed" %t30, ptr %l23
  br label %bb8
bb7:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb12
bb8:
  %t34 = load %"compiler/check:narrowed", ptr %l23
  store %"compiler/check:narrowed" %t34, ptr %l20
  br label %bb11
bb9:
  br label %bb10
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f3fef639868d2bb5_dd9676d0e98a8921)
  unreachable
bb11:
  %t35 = getelementptr %"compiler/check:narrowed", ptr %l20, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = icmp eq i64 %t36, %t37
  store i1 %t40, ptr %l19, !tbaa !21
  br label %bb12
bb12:
  %t42 = load i1, ptr %l19, !tbaa !21
  %t43 = xor i1 %t42, true
  br i1 %t43, label %bb13, label %bb14
bb13:
  br label %bb26
bb14:
  br label %bb15
bb15:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr %"compiler/check:frame", ptr %t45, i32 0, i32 46
  %t49 = call { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePop_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t47)
  %t50 = extractvalue { i32, %"compiler/check:narrowed" } %t49, 1
  %t51 = extractvalue { i32, %"compiler/check:narrowed" } %t49, 0
  store i32 %t51, ptr %l33
  %t52 = icmp ne i32 %t51, 0
  br i1 %t52, label %bb17, label %ok.53, !prof !99
ok.53:
  store %"compiler/check:narrowed" %t50, ptr %l32
  br label %bb16
bb16:
  %t54 = load %"compiler/check:narrowed", ptr %l32
  store %"compiler/check:narrowed" %t54, ptr %l29
  br label %bb24
bb17:
  %t55 = load i32, ptr %l33, !tbaa !23
  %t56 = icmp eq i32 %t55, 65536
  br i1 %t56, label %bb18, label %bb19
bb18:
  call void @__olang_bang_failed_plain(ptr @olang_loc_df1f5fd28061949_6fd2bc487e6b648d)
  unreachable
bb19:
  %t58 = load i32, ptr %l33, !tbaa !23
  %t59 = icmp eq i32 %t58, 65537
  br i1 %t59, label %bb20, label %bb21
bb20:
  call void @__olang_bang_failed_plain(ptr @olang_loc_adf1079d57e55808_9269da6a723799fc)
  unreachable
bb21:
  %t61 = load i32, ptr %l33, !tbaa !23
  %t62 = icmp eq i32 %t61, 65538
  br i1 %t62, label %bb22, label %bb23
bb22:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4fa1eeadbabe5a66_3dfbfb89ab758d6a)
  unreachable
bb23:
  call void @__olang_bang_failed_plain(ptr @olang_loc_92a21335b7ae999a_7e07c1814bb2a646)
  unreachable
bb24:
  br label %bb25
bb25:
  br label %bb4
bb26:
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s3
  %t64 = load ptr, ptr %l6, !tbaa !29
  %t66 = getelementptr %"compiler/check:frame", ptr %t64, i32 0, i32 50
  %t68 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %t66)
  store i64 %t68, ptr %l39
  br label %bb28
bb28:
  %t69 = load i64, ptr %l39, !tbaa !24
  %t70 = icmp sgt i64 %t69, 0
  br i1 %t70, label %bb29, label %bb30
bb29:
  %t72 = load ptr, ptr %l6, !tbaa !29
  %t74 = getelementptr %"compiler/check:frame", ptr %t72, i32 0, i32 50
  %t76 = call { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLas_H41327bbfea6c01118b477d23a6e2def2(ptr %v0, ptr %s3, ptr %t74)
  %t77 = extractvalue { i32, %"compiler/check:nullNarrow" } %t76, 1
  %t78 = extractvalue { i32, %"compiler/check:nullNarrow" } %t76, 0
  store i32 %t78, ptr %l46
  %t79 = icmp ne i32 %t78, 0
  br i1 %t79, label %bb32, label %ok.80, !prof !99
ok.80:
  store %"compiler/check:nullNarrow" %t77, ptr %l45
  br label %bb31
bb30:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb35
bb31:
  %t81 = load %"compiler/check:nullNarrow", ptr %l45
  store %"compiler/check:nullNarrow" %t81, ptr %l42
  br label %bb34
bb32:
  br label %bb33
bb33:
  call void @__olang_check_failed(ptr @olang_loc_abe1ff4556bedc08_80ba96099639cb2c)
  unreachable
bb34:
  %t82 = getelementptr %"compiler/check:nullNarrow", ptr %l42, i32 0, i32 1
  %t83 = load i64, ptr %t82, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  %t87 = icmp eq i64 %t83, %t84
  store i1 %t87, ptr %l41, !tbaa !21
  br label %bb35
bb35:
  %t89 = load i1, ptr %l41, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s3)
  br label %bb44
bb37:
  br label %bb38
bb38:
  %t92 = load ptr, ptr %l6, !tbaa !29
  %t94 = getelementptr %"compiler/check:frame", ptr %t92, i32 0, i32 50
  %t96 = call { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePop_H59a749d10c64cd066029408cbe89e7b7(ptr %v0, ptr %s3, ptr %t94)
  %t97 = extractvalue { i32, %"compiler/check:nullNarrow" } %t96, 1
  %t98 = extractvalue { i32, %"compiler/check:nullNarrow" } %t96, 0
  store i32 %t98, ptr %l55
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb40, label %ok.100, !prof !99
ok.100:
  store %"compiler/check:nullNarrow" %t97, ptr %l54
  br label %bb39
bb39:
  %t101 = load %"compiler/check:nullNarrow", ptr %l54
  store %"compiler/check:nullNarrow" %t101, ptr %l51
  br label %bb42
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb43
bb43:
  br label %bb27
bb44:
  br label %bb45
bb45:
  %t102 = load ptr, ptr %l6, !tbaa !29
  %t104 = getelementptr %"compiler/check:frame", ptr %t102, i32 0, i32 59
  %t106 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %t104)
  store i64 %t106, ptr %l58
  br label %bb46
bb46:
  %t107 = load i64, ptr %l58, !tbaa !24
  %t108 = icmp sgt i64 %t107, 0
  br i1 %t108, label %bb47, label %bb48
bb47:
  %t110 = load ptr, ptr %l6, !tbaa !29
  %t112 = getelementptr %"compiler/check:frame", ptr %t110, i32 0, i32 59
  %t114 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLast_He310b7451e653469b2155498b3293ff7(ptr %v0, ptr %t112)
  %t115 = extractvalue { i32, %"compiler/check:errNarrow" } %t114, 1
  %t116 = extractvalue { i32, %"compiler/check:errNarrow" } %t114, 0
  store i32 %t116, ptr %l65
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb50, label %ok.118, !prof !99
ok.118:
  store %"compiler/check:errNarrow" %t115, ptr %l64
  br label %bb49
bb48:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb53
bb49:
  %t119 = load %"compiler/check:errNarrow", ptr %l64
  store %"compiler/check:errNarrow" %t119, ptr %l61
  br label %bb52
bb50:
  br label %bb51
bb51:
  call void @__olang_check_failed(ptr @olang_loc_7a4929889a701fe3_96d6f303ecd0d8a7)
  unreachable
bb52:
  %t120 = getelementptr %"compiler/check:errNarrow", ptr %l61, i32 0, i32 2
  %t121 = load i64, ptr %t120, !tbaa !24
  %t122 = load i64, ptr %l1, !tbaa !24
  %t125 = icmp eq i64 %t121, %t122
  store i1 %t125, ptr %l60, !tbaa !21
  br label %bb53
bb53:
  %t127 = load i1, ptr %l60, !tbaa !21
  %t128 = xor i1 %t127, true
  br i1 %t128, label %bb54, label %bb55
bb54:
  br label %bb67
bb55:
  br label %bb56
bb56:
  %t130 = load ptr, ptr %l6, !tbaa !29
  %t132 = getelementptr %"compiler/check:frame", ptr %t130, i32 0, i32 59
  %t134 = call { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePop__He4c3571ab54dd9fc34e0d36cd7afb0ff(ptr %v0, ptr %t132)
  %t135 = extractvalue { i32, %"compiler/check:errNarrow" } %t134, 1
  %t136 = extractvalue { i32, %"compiler/check:errNarrow" } %t134, 0
  store i32 %t136, ptr %l74
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb58, label %ok.138, !prof !99
ok.138:
  store %"compiler/check:errNarrow" %t135, ptr %l73
  br label %bb57
bb57:
  %t139 = load %"compiler/check:errNarrow", ptr %l73
  store %"compiler/check:errNarrow" %t139, ptr %l70
  br label %bb65
bb58:
  %t140 = load i32, ptr %l74, !tbaa !23
  %t141 = icmp eq i32 %t140, 65536
  br i1 %t141, label %bb59, label %bb60
bb59:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b4897252f2a0467_e1365b27726b9d63)
  unreachable
bb60:
  %t143 = load i32, ptr %l74, !tbaa !23
  %t144 = icmp eq i32 %t143, 65537
  br i1 %t144, label %bb61, label %bb62
bb61:
  call void @__olang_bang_failed_plain(ptr @olang_loc_b02f2e0c8b90d83e_466afc0716e3b9a2)
  unreachable
bb62:
  %t146 = load i32, ptr %l74, !tbaa !23
  %t147 = icmp eq i32 %t146, 65538
  br i1 %t147, label %bb63, label %bb64
bb63:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e882b6948f69dce8_e6367676615923ec)
  unreachable
bb64:
  call void @__olang_bang_failed_plain(ptr @olang_loc_9e6114e2cf841093_fa90ce222875bd2f)
  unreachable
bb65:
  br label %bb66
bb66:
  br label %bb45
bb67:
  br label %bb68
bb68:
  %t149 = load ptr, ptr %l6, !tbaa !29
  %t151 = getelementptr %"compiler/check:frame", ptr %t149, i32 0, i32 22
  %t153 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t151)
  store i64 %t153, ptr %l80
  br label %bb69
bb69:
  %t154 = load i64, ptr %l80, !tbaa !24
  %t155 = icmp sgt i64 %t154, 0
  br i1 %t155, label %bb70, label %bb71
bb70:
  %t157 = load ptr, ptr %l6, !tbaa !29
  %t159 = getelementptr %"compiler/check:frame", ptr %t157, i32 0, i32 22
  %t161 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %t159)
  %t162 = extractvalue { i32, i64 } %t161, 1
  %t163 = extractvalue { i32, i64 } %t161, 0
  store i32 %t163, ptr %l87
  %t164 = icmp ne i32 %t163, 0
  br i1 %t164, label %bb73, label %ok.165, !prof !99
ok.165:
  store i64 %t162, ptr %l86
  br label %bb72
bb71:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb76
bb72:
  %t166 = load i64, ptr %l86, !tbaa !24
  store i64 %t166, ptr %l83, !tbaa !24
  br label %bb75
bb73:
  br label %bb74
bb74:
  call void @__olang_check_failed(ptr @olang_loc_c349e4c9332250dd_9daf9d91ff07ef41)
  unreachable
bb75:
  %t167 = load i64, ptr %l1, !tbaa !24
  %t168 = load i64, ptr %l83, !tbaa !24
  %t170 = icmp eq i64 %t168, %t167
  store i1 %t170, ptr %l82, !tbaa !21
  br label %bb76
bb76:
  %t172 = load i1, ptr %l82, !tbaa !21
  %t173 = xor i1 %t172, true
  br i1 %t173, label %bb77, label %bb78
bb77:
  br label %bb90
bb78:
  br label %bb79
bb79:
  %t175 = load ptr, ptr %l6, !tbaa !29
  %t177 = getelementptr %"compiler/check:frame", ptr %t175, i32 0, i32 22
  %t179 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t177)
  %t180 = extractvalue { i32, i64 } %t179, 1
  %t181 = extractvalue { i32, i64 } %t179, 0
  store i32 %t181, ptr %l95
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb81, label %ok.183, !prof !99
ok.183:
  store i64 %t180, ptr %l94
  br label %bb80
bb80:
  %t184 = load i64, ptr %l94, !tbaa !24
  store i64 %t184, ptr %l91, !tbaa !24
  br label %bb88
bb81:
  %t185 = load i32, ptr %l95, !tbaa !23
  %t186 = icmp eq i32 %t185, 65536
  br i1 %t186, label %bb82, label %bb83
bb82:
  call void @__olang_bang_failed_plain(ptr @olang_loc_90c216d2a7707e63_13ebc04feeb9a31f)
  unreachable
bb83:
  %t188 = load i32, ptr %l95, !tbaa !23
  %t189 = icmp eq i32 %t188, 65537
  br i1 %t189, label %bb84, label %bb85
bb84:
  call void @__olang_bang_failed_plain(ptr @olang_loc_e7cf760e54914750_8299ab19ca729e9c)
  unreachable
bb85:
  %t191 = load i32, ptr %l95, !tbaa !23
  %t192 = icmp eq i32 %t191, 65538
  br i1 %t192, label %bb86, label %bb87
bb86:
  call void @__olang_bang_failed_plain(ptr @olang_loc_2de9afb4b96dcf94_71a46e56f9644858)
  unreachable
bb87:
  call void @__olang_bang_failed_plain(ptr @olang_loc_6d051d6c732886d2_d9cb433bcdc0e6)
  unreachable
bb88:
  br label %bb89
bb89:
  br label %bb68
bb90:
  br label %bb91
bb91:
  %t194 = load ptr, ptr %l6, !tbaa !29
  %t196 = getelementptr %"compiler/check:frame", ptr %t194, i32 0, i32 24
  %t198 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t196)
  store i64 %t198, ptr %l101
  br label %bb92
bb92:
  %t199 = load i64, ptr %l101, !tbaa !24
  %t200 = icmp sgt i64 %t199, 0
  br i1 %t200, label %bb93, label %bb94
bb93:
  %t202 = load ptr, ptr %l6, !tbaa !29
  %t204 = getelementptr %"compiler/check:frame", ptr %t202, i32 0, i32 24
  %t206 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %t204)
  %t207 = extractvalue { i32, i64 } %t206, 1
  %t208 = extractvalue { i32, i64 } %t206, 0
  store i32 %t208, ptr %l108
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb96, label %ok.210, !prof !99
ok.210:
  store i64 %t207, ptr %l107
  br label %bb95
bb94:
  store i1 false, ptr %l103, !tbaa !21
  br label %bb99
bb95:
  %t211 = load i64, ptr %l107, !tbaa !24
  store i64 %t211, ptr %l104, !tbaa !24
  br label %bb98
bb96:
  br label %bb97
bb97:
  call void @__olang_check_failed(ptr @olang_loc_fd3792a3478c708a_bd2f712e645466e6)
  unreachable
bb98:
  %t212 = load i64, ptr %l1, !tbaa !24
  %t213 = load i64, ptr %l104, !tbaa !24
  %t215 = icmp eq i64 %t213, %t212
  store i1 %t215, ptr %l103, !tbaa !21
  br label %bb99
bb99:
  %t217 = load i1, ptr %l103, !tbaa !21
  %t218 = xor i1 %t217, true
  br i1 %t218, label %bb100, label %bb101
bb100:
  br label %bb113
bb101:
  br label %bb102
bb102:
  %t220 = load ptr, ptr %l6, !tbaa !29
  %t222 = getelementptr %"compiler/check:frame", ptr %t220, i32 0, i32 24
  %t224 = call { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t222)
  %t225 = extractvalue { i32, i64 } %t224, 1
  %t226 = extractvalue { i32, i64 } %t224, 0
  store i32 %t226, ptr %l116
  %t227 = icmp ne i32 %t226, 0
  br i1 %t227, label %bb104, label %ok.228, !prof !99
ok.228:
  store i64 %t225, ptr %l115
  br label %bb103
bb103:
  %t229 = load i64, ptr %l115, !tbaa !24
  store i64 %t229, ptr %l112, !tbaa !24
  br label %bb111
bb104:
  %t230 = load i32, ptr %l116, !tbaa !23
  %t231 = icmp eq i32 %t230, 65536
  br i1 %t231, label %bb105, label %bb106
bb105:
  call void @__olang_bang_failed_plain(ptr @olang_loc_12b3dc107423b434_482fbf8ad69d32f8)
  unreachable
bb106:
  %t233 = load i32, ptr %l116, !tbaa !23
  %t234 = icmp eq i32 %t233, 65537
  br i1 %t234, label %bb107, label %bb108
bb107:
  call void @__olang_bang_failed_plain(ptr @olang_loc_4090f31281295d0b_b76133cd00d27c97)
  unreachable
bb108:
  %t236 = load i32, ptr %l116, !tbaa !23
  %t237 = icmp eq i32 %t236, 65538
  br i1 %t237, label %bb109, label %bb110
bb109:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ee572ef2923bf685_6f413c271381cde1)
  unreachable
bb110:
  call void @__olang_bang_failed_plain(ptr @olang_loc_ff67d74e2821509e_7f8039e3a9b6d64a)
  unreachable
bb111:
  br label %bb112
bb112:
  br label %bb91
bb113:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t239)
  store ptr %t241, ptr %l121
  br label %bb114
bb114:
  %t242 = load ptr, ptr %l121, !tbaa !29
  %t246 = getelementptr %"compiler/check:frame", ptr %t242, i32 0, i32 7
  store i64 %a2, ptr %t246, !tbaa !24
  %t247 = load i64, ptr %l1, !tbaa !24
  %t249 = trunc i64 %t247 to i32
  %t251 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t254 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v1, ptr %v1, i32 %t249, { i64, ptr } %t251)
  store %"compiler/typed:Block" %t254, ptr %l128
  br label %bb115
bb115:
  %t255 = load %"compiler/typed:Block", ptr %l128
  %t256 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/typed:Block" %t255, ptr %t256
  store ptr %t256, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommutedCall(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca i32
  %l15 = alloca i32
  %l19 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i32
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Span"
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i1
  %l34 = alloca ptr
  %l35 = alloca ptr
  %l39 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca i64
  %l52 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l66 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/source:Span"
  %l74 = alloca i64
  %l76 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l80 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l92 = alloca i64
  %l95 = alloca %"compiler/source:Span"
  %l98 = alloca i32
  %l102 = alloca { i64, ptr }
  %l105 = alloca %"compiler/typed:Seq"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t198 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store i32 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l5, !tbaa !29
  %t5 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l11, !tbaa !29
  %t7 = load i32, ptr %l14, !tbaa !23
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t8, ptr %l15
  br label %bb2
bb2:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l6, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t16 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %t10, i32 %t11, i32 %t12)
  store i64 %t16, ptr %l19
  br label %bb3
bb3:
  %t17 = load i64, ptr %l19, !tbaa !24
  store i64 %t17, ptr %l7, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  %t20 = icmp slt i64 %t18, 0
  br i1 %t20, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load i64, ptr %l7, !tbaa !24
  store i64 %t24, ptr %l24, !tbaa !24
  %t25 = load i32, ptr %l6, !tbaa !23
  store i32 %t25, ptr %l25, !tbaa !23
  %t26 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t28 = call { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %s0, i32 %t26)
  store { i64, ptr } %t28, ptr %l27
  br label %bb7
bb7:
  %t29 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t29, ptr %l28
  %t30 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t32 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s0, i32 %t30)
  store { i64, ptr } %t32, ptr %l30
  br label %bb8
bb8:
  %t33 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t34 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s0, ptr %s0, { i64, ptr } %t33)
  store { i64, ptr } %t34, ptr %l31
  br label %bb9
bb9:
  %t35 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  %t42 = load ptr, ptr %l23, !tbaa !29
  %t43 = load i64, ptr %l24, !tbaa !24
  %t44 = load i32, ptr %l25, !tbaa !23
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t46 = load %"compiler/source:Span", ptr %l28
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %s0, ptr %s0, ptr %t42, i64 %t43, i32 %t44, { i64, ptr } %t45, %"compiler/source:Span" %t46, { i64, ptr } %t41)
  store i1 %t48, ptr %l33
  br label %bb10
bb10:
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l34, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l35, !tbaa !29
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/check:Checker", ptr %t51, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t54, i64 %t55)
  store ptr %t58, ptr %l39
  br label %bb11
bb11:
  %t59 = load ptr, ptr %l39, !tbaa !29
  %t61 = getelementptr %"compiler/ast:Func", ptr %t59, i32 0, i32 2
  %t62 = load i32, ptr %t61, !tbaa !23
  %t63 = load ptr, ptr %l35, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t63, i32 %t62)
  store { i64, ptr } %t65, ptr %l42
  br label %bb12
bb12:
  %t66 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t67 = load ptr, ptr %l34, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 50
  store { i64, ptr } %t66, ptr %t68, !tbaa !27
  %t69 = load ptr, ptr %l4, !tbaa !29
  store ptr %t69, ptr %l43, !tbaa !29
  store i1 false, ptr %l44, !tbaa !21
  %t70 = load ptr, ptr %l43, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb13, label %bb14
bb13:
  %t73 = load ptr, ptr %l43, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 18}
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb28
bb17:
  %t78 = load ptr, ptr %l0, !tbaa !29
  store ptr %t78, ptr %l47, !tbaa !29
  %t79 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t79, ptr %l48
  %t80 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t80, ptr %l49
  %t81 = load i64, ptr %l7, !tbaa !24
  store i64 %t81, ptr %l50, !tbaa !24
  %t82 = load ptr, ptr %l5, !tbaa !29
  store ptr %t82, ptr %l52, !tbaa !29
  %t84 = icmp sge i64 0, 0
  br i1 %t84, label %bb18, label %bb19
bb18:
  %t86 = icmp sle i64 0, 1152921504606846975
  br i1 %t86, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @olang_loc_f9674bcb1008789c_bed0ff146db7b878)
  unreachable
bb20:
  %t88 = mul i64 0, 8
  %t89 = insertvalue { i64, ptr } undef, i64 0, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t90, ptr %l55, !tbaa !27
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t95 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v0, ptr %t91, ptr %t92)
  store { i64, ptr } %t95, ptr %l58
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_f9674bcb1008789c_bed0ff146db7b878)
  unreachable
bb22:
  %t96 = icmp sge i64 0, 0
  br i1 %t96, label %bb23, label %bb24
bb23:
  %t98 = icmp sle i64 0, 2305843009213693951
  br i1 %t98, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb25:
  %t100 = mul i64 0, 4
  %t101 = insertvalue { i64, ptr } undef, i64 0, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t103 = load ptr, ptr %l47, !tbaa !29
  %t104 = load %"compiler/source:Span", ptr %l48
  %t105 = load %"compiler/source:Span", ptr %l49
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = load ptr, ptr %l52, !tbaa !29
  %t108 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t111 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t103, %"compiler/source:Span" %t104, %"compiler/source:Span" %t105, i64 %t106, ptr %t107, { i64, ptr } %t108, { i64, ptr } %t109, { i64, ptr } %t102)
  store ptr %t111, ptr %l62
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb27:
  %t112 = load ptr, ptr %l62, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t112, ptr %rv
  br label %ret
bb28:
  br i1 true, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_fe55a007e1b3e29_3c78fea0979d4bfd)
  unreachable
bb33:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/check:Checker", ptr %t114, i32 0, i32 37
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t116)
  store i64 %t118, ptr %l66
  br label %bb34
bb34:
  %t119 = load i64, ptr %l66, !tbaa !24
  store i64 %t119, ptr %l8, !tbaa !24
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t121 = load %"compiler/source:Span", ptr %l1
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t126 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v3, ptr %t120, %"compiler/source:Span" %t121, ptr %t122)
  store ptr %t126, ptr %l70
  br label %bb35
bb35:
  %t127 = load ptr, ptr %l70, !tbaa !29
  store ptr %t127, ptr %l9, !tbaa !29
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l71, !tbaa !29
  %t129 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t129, ptr %l72
  %t130 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t130, ptr %l73
  %t131 = load i64, ptr %l7, !tbaa !24
  store i64 %t131, ptr %l74, !tbaa !24
  %t132 = load ptr, ptr %l5, !tbaa !29
  store ptr %t132, ptr %l76, !tbaa !29
  %t134 = icmp sge i64 0, 0
  br i1 %t134, label %bb36, label %bb37
bb36:
  %t136 = icmp sle i64 0, 1152921504606846975
  br i1 %t136, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b)
  unreachable
bb38:
  %t138 = mul i64 0, 8
  %t139 = insertvalue { i64, ptr } undef, i64 0, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t140, ptr %l79, !tbaa !27
  %t141 = load ptr, ptr %l0, !tbaa !29
  store ptr %t141, ptr %l80, !tbaa !29
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load %"compiler/source:Span", ptr %l1
  %t144 = load ptr, ptr %l9, !tbaa !29
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t142, %"compiler/source:Span" %t143, ptr %t144)
  store ptr %t148, ptr %l84
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b)
  unreachable
bb40:
  %t149 = load ptr, ptr %l80, !tbaa !29
  %t150 = load ptr, ptr %l84, !tbaa !29
  %t151 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v3, ptr %v0, ptr %t149, ptr %t150)
  store { i64, ptr } %t151, ptr %l85
  br label %bb41
bb41:
  %t152 = icmp sge i64 0, 0
  br i1 %t152, label %bb42, label %bb43
bb42:
  %t154 = icmp sle i64 0, 2305843009213693951
  br i1 %t154, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb44:
  %t156 = mul i64 0, 4
  %t157 = insertvalue { i64, ptr } undef, i64 0, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t159 = load ptr, ptr %l71, !tbaa !29
  %t160 = load %"compiler/source:Span", ptr %l72
  %t161 = load %"compiler/source:Span", ptr %l73
  %t162 = load i64, ptr %l74, !tbaa !24
  %t163 = load ptr, ptr %l76, !tbaa !29
  %t164 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t167 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v3, ptr %v3, ptr %t159, %"compiler/source:Span" %t160, %"compiler/source:Span" %t161, i64 %t162, ptr %t163, { i64, ptr } %t164, { i64, ptr } %t165, { i64, ptr } %t158)
  store ptr %t167, ptr %l89
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_7d2067b11442aa69_727f8f68f20a38e5)
  unreachable
bb46:
  %t168 = load ptr, ptr %l89, !tbaa !29
  store ptr %t168, ptr %l10, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t169, i32 0, i32 37
  %t173 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t171)
  store i64 %t173, ptr %l92
  br label %bb47
bb47:
  %t174 = load i64, ptr %l8, !tbaa !24
  %t175 = load i64, ptr %l92, !tbaa !24
  %t177 = icmp sgt i64 %t175, %t174
  br i1 %t177, label %bb48, label %bb49
bb48:
  %t179 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t179, ptr %l95
  %t180 = load ptr, ptr %l10, !tbaa !29
  %t183 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t180)
  store i32 %t183, ptr %l98
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 37
  %t187 = load i64, ptr %l8, !tbaa !24
  %t190 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t186, i64 %t187)
  store { i64, ptr } %t190, ptr %l102
  br label %bb51
bb51:
  %t191 = load ptr, ptr %l10, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t195 = call %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v3, ptr %v3, { i64, ptr } %t193, ptr %t191, i1 false)
  store %"compiler/typed:Seq" %t195, ptr %l105
  br label %bb52
bb52:
  %t196 = load %"compiler/typed:Seq", ptr %l105
  %t197 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store %"compiler/typed:Seq" %t196, ptr %t197
  store { i64, [5 x i64] } zeroinitializer, ptr %t198
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 0
  store i64 12, ptr %t199
  %t200 = load %"compiler/source:Span", ptr %l95
  %t201 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t200, 0
  %t202 = load i32, ptr %l98, !tbaa !23
  %t203 = insertvalue { %"compiler/source:Span", i32, ptr } %t201, i32 %t202, 1
  %t205 = insertvalue { %"compiler/source:Span", i32, ptr } %t203, ptr %t197, 2
  %t206 = getelementptr { i64, [5 x i64] }, ptr %t198, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t205, ptr %t206
  %t207 = load { i64, [5 x i64] }, ptr %t198
  %t209 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t207, ptr %t209
  call void @__olang_scope_close(ptr %s0)
  store ptr %t209, ptr %rv
  br label %ret
bb53:
  %t211 = load ptr, ptr %l10, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t211, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecomptimeCtx(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l3 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l4 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l5 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca ptr
  %l11 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l12 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l14 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l15 = alloca i32
  %l17 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l32 = alloca ptr
  %l35 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l36 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l38 = alloca %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa"
  %l39 = alloca i32
  %l41 = alloca i1
  %l42 = alloca ptr
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t3)
  store ptr %t5, ptr %l8
  br label %bb2
bb2:
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t8 = getelementptr %"compiler/check:frame", ptr %t6, i32 0, i32 4
  %t9 = getelementptr %"compiler/generic:Context", ptr %t8, i32 0, i32 2
  %t11 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t9)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t11, ptr %l11
  br label %bb3
bb3:
  %t12 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l11
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t12, ptr %l2
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t14 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l2)
  %t15 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t14, 1
  %t16 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t14, 0
  store i32 %t16, ptr %l15
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb6, label %ok.18, !prof !99
ok.18:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t15, ptr %l14
  br label %bb5
bb5:
  %t19 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l14
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t19, ptr %l12
  br label %bb8
bb6:
  %t20 = load i32, ptr %l15, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb8:
  %t24 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l12
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t24, ptr %l3
  store ptr %l1, ptr %l18, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l3, i32 0, i32 0
  %t27 = load i32, ptr %t26, !tbaa !23
  %t30 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t25, i32 %t27)
  store { i64, ptr } %t30, ptr %l21
  br label %bb9
bb9:
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t33 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @olang_textcopy(ptr %t40, ptr %t31, i64 %t32)
  %t41 = getelementptr i8, ptr %t40, i64 %t32
  call void @olang_textcopy(ptr %t41, ptr %t34, i64 %t35)
  %t42 = getelementptr i8, ptr %t41, i64 %t35
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t40, 1
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t47 = extractvalue { i64, ptr } %t44, 1
  %t48 = mul i64 %t46, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @llvm.memcpy.p0.p0.i64(ptr %t49, ptr %t47, i64 %t48, i1 false)
  %t50 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  %t52 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t52, { i64, ptr } %t51)
  br label %bb10
bb10:
  store ptr %l1, ptr %l24, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  %t60 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l3, i32 0, i32 1
  %t61 = load i32, ptr %t60, !tbaa !23
  %t64 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s2, ptr %t59, i32 %t61)
  store { i64, ptr } %t64, ptr %l29
  br label %bb11
bb11:
  %t65 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t72 = load ptr, ptr %l24, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %t72, { i64, ptr } %t71)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  br label %bb4
bb14:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t74)
  store ptr %t76, ptr %l32
  br label %bb15
bb15:
  %t77 = load ptr, ptr %l32, !tbaa !29
  %t79 = getelementptr %"compiler/check:frame", ptr %t77, i32 0, i32 4
  %t80 = getelementptr %"compiler/generic:Context", ptr %t79, i32 0, i32 3
  %t82 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v0, ptr %t80)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t82, ptr %l35
  br label %bb16
bb16:
  %t83 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l35
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t83, ptr %l4
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s5
  %t85 = call { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %l4)
  %t86 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t85, 1
  %t87 = extractvalue { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } %t85, 0
  store i32 %t87, ptr %l39
  %t88 = icmp ne i32 %t87, 0
  br i1 %t88, label %bb19, label %ok.89, !prof !99
ok.89:
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t86, ptr %l38
  br label %bb18
bb18:
  %t90 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l38
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t90, ptr %l36
  br label %bb21
bb19:
  %t91 = load i32, ptr %l39, !tbaa !23
  %t92 = ashr i32 %t91, 16
  %t94 = icmp eq i32 %t92, 1
  store i1 %t94, ptr %l41, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb21:
  %t95 = load %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l36
  store %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" %t95, ptr %l5
  store ptr %l1, ptr %l42, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 0
  %t98 = load i32, ptr %t97, !tbaa !23
  %t101 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s5, ptr %t96, i32 %t98)
  store { i64, ptr } %t101, ptr %l45
  br label %bb22
bb22:
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t104 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t111 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t102, i64 %t103)
  %t112 = getelementptr i8, ptr %t111, i64 %t103
  call void @olang_textcopy(ptr %t112, ptr %t105, i64 %t106)
  %t113 = getelementptr i8, ptr %t112, i64 %t106
  call void @olang_textcopy(ptr %t113, ptr %t108, i64 %t109)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t111, 1
  %t117 = extractvalue { i64, ptr } %t115, 0
  %t118 = extractvalue { i64, ptr } %t115, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  %t123 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t123, { i64, ptr } %t122)
  br label %bb23
bb23:
  store ptr %l1, ptr %l48, !tbaa !29
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t127 = getelementptr %"compiler/check:Checker", ptr %t125, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = getelementptr %"compiler/generic:Program", ptr %t128, i32 0, i32 2
  %t131 = getelementptr %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa", ptr %l5, i32 0, i32 1
  %t132 = load i32, ptr %t131, !tbaa !23
  %t135 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %s5, ptr %t130, i32 %t132)
  store { i64, ptr } %t135, ptr %l53
  br label %bb24
bb24:
  %t136 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = extractvalue { i64, ptr } %t136, 1
  %t139 = mul i64 %t137, 1
  %t140 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t139)
  call void @llvm.memcpy.p0.p0.i64(ptr %t140, ptr %t138, i64 %t139, i1 false)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t143 = load ptr, ptr %l48, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s5, ptr %t143, { i64, ptr } %t142)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb26
bb26:
  br label %bb17
bb27:
  %t146 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t146, ptr %l56
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t147 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t147, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3, ptr %a4, i32 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i64
  %l22 = alloca ptr
  %l29 = alloca ptr
  %l32 = alloca ptr
  %l36 = alloca i1
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l49 = alloca ptr
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca i32
  %l62 = alloca i32
  %l64 = alloca ptr
  %l70 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l78 = alloca i1
  %l81 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l88 = alloca ptr
  %l91 = alloca i32
  %l92 = alloca i1
  %l93 = alloca i32
  %l96 = alloca i32
  %l98 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca i32
  %l106 = alloca i1
  %l107 = alloca i1
  %l110 = alloca i1
  %l111 = alloca i1
  %l117 = alloca i1
  %l119 = alloca i1
  %l122 = alloca i1
  %l124 = alloca i1
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca ptr
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca %"compiler/source:Span"
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l144 = alloca %"compiler/diagmsg:Msg"
  %l145 = alloca i64
  %l148 = alloca ptr
  %l157 = alloca i1
  %l169 = alloca i1
  %l178 = alloca i1
  %l182 = alloca i1
  %l183 = alloca i1
  %l186 = alloca i1
  %l187 = alloca i1
  %l192 = alloca i32
  %l198 = alloca i32
  %l202 = alloca i1
  %l205 = alloca i1
  %l206 = alloca i1
  %l211 = alloca i32
  %l218 = alloca i32
  %l222 = alloca i1
  %l225 = alloca i1
  %l226 = alloca i1
  %l231 = alloca i32
  %l238 = alloca i32
  %l243 = alloca i32
  %l246 = alloca i1
  %l249 = alloca ptr
  %l254 = alloca i32
  %l259 = alloca i32
  %l260 = alloca i1
  %l265 = alloca i32
  %l268 = alloca i1
  %l269 = alloca i1
  %l272 = alloca i1
  %l274 = alloca i1
  %l275 = alloca ptr
  %l276 = alloca i32
  %l281 = alloca i32
  %l282 = alloca i1
  %l286 = alloca i1
  %l287 = alloca i1
  %l290 = alloca i1
  %l292 = alloca i1
  %l293 = alloca ptr
  %l294 = alloca i32
  %l299 = alloca i32
  %l300 = alloca i1
  %l304 = alloca i1
  %l305 = alloca i1
  %l308 = alloca i1
  %l309 = alloca i1
  %l312 = alloca ptr
  %l315 = alloca i32
  %l318 = alloca i32
  %l319 = alloca i1
  %l322 = alloca ptr
  %l325 = alloca i32
  %l330 = alloca i64
  %l335 = alloca i64
  %l336 = alloca i64
  %l337 = alloca i32
  %l340 = alloca i1
  %l341 = alloca i1
  %l344 = alloca i1
  %l345 = alloca i1
  %l348 = alloca ptr
  %l349 = alloca ptr
  %l352 = alloca i32
  %l353 = alloca i32
  %l354 = alloca ptr
  %l357 = alloca i32
  %l358 = alloca i32
  %l359 = alloca i1
  %l362 = alloca ptr
  %l363 = alloca ptr
  %l366 = alloca i32
  %l367 = alloca i32
  %l372 = alloca i64
  %l377 = alloca i64
  %l378 = alloca i64
  %l379 = alloca i32
  %l384 = alloca i32
  %l387 = alloca i1
  %l392 = alloca i32
  %l395 = alloca i1
  %l398 = alloca ptr
  %l403 = alloca i32
  %l408 = alloca i32
  %l409 = alloca i1
  %l412 = alloca ptr
  %l417 = alloca i32
  %l418 = alloca i32
  %l419 = alloca ptr
  %l420 = alloca %"compiler/source:Span"
  %l423 = alloca { i64, ptr }
  %l424 = alloca { i64, ptr }
  %l427 = alloca { i64, ptr }
  %l429 = alloca %"compiler/diagmsg:Msg"
  %l430 = alloca i64
  %l433 = alloca ptr
  %l434 = alloca %"compiler/source:Span"
  %l435 = alloca i32
  %l436 = alloca ptr
  %l437 = alloca ptr
  %l440 = alloca ptr
  %l441 = alloca i32
  %l443 = alloca %"compiler/source:Span"
  %l444 = alloca ptr
  %l445 = alloca ptr
  %l446 = alloca ptr
  %l449 = alloca ptr
  %l450 = alloca i32
  %l452 = alloca %"compiler/source:Span"
  %l453 = alloca ptr
  %l454 = alloca %"compiler/typed:Cond"
  %s5 = alloca %olang.scope
  %s32 = alloca %olang.scope
  %rv = alloca ptr
  %t891 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store i32 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v2, ptr %t1, ptr %t2)
  store i64 %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = load i64, ptr %l15, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp eq i64 %t7, 1
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i32, ptr %l5, !tbaa !23
  %t18 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v4, ptr %t11, ptr %t12, i32 %t14)
  store ptr %t18, ptr %l22
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t19 = load ptr, ptr %l22, !tbaa !29
  store ptr %t19, ptr %rv
  br label %ret
bb5:
  %t20 = load i64, ptr %l6, !tbaa !24
  %t22 = icmp eq i64 %t20, 0
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t27 = load i32, ptr %l5, !tbaa !23
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v3, ptr %v4, ptr %t24, ptr %t25, i32 %t27)
  store ptr %t31, ptr %l29
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t32 = load ptr, ptr %l29, !tbaa !29
  store ptr %t32, ptr %rv
  br label %ret
bb9:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t37 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v2, ptr %v4, ptr %t33, ptr %t34)
  store ptr %t37, ptr %l32
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l32, !tbaa !29
  store ptr %t38, ptr %l7, !tbaa !29
  store ptr null, ptr %l8, !tbaa !29
  store ptr null, ptr %l9, !tbaa !29
  %t39 = load i32, ptr %l5, !tbaa !23
  %t40 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t43 = icmp eq i32 %t39, %t40
  br i1 %t43, label %bb11, label %bb12
bb11:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t46 = load ptr, ptr %l2, !tbaa !29
  %t49 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t45, ptr %t46)
  store i1 %t49, ptr %l39
  br label %bb13
bb12:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb14
bb13:
  %t50 = load i1, ptr %l39, !tbaa !21
  store i1 %t50, ptr %l36, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l36, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load ptr, ptr %l4, !tbaa !29
  %t56 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t52, ptr %t53)
  store i1 %t56, ptr %l43
  br label %bb17
bb16:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb18
bb17:
  %t57 = load i1, ptr %l43, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l40, !tbaa !21
  br label %bb18
bb18:
  %t60 = load i1, ptr %l40, !tbaa !21
  br i1 %t60, label %bb19, label %bb20
bb19:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = load i32, ptr %l5, !tbaa !23
  %t69 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t61, ptr %t62, i1 false, ptr %t63, i32 %t64)
  store ptr %t69, ptr %l49
  br label %bb21
bb20:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t72 = load ptr, ptr %l2, !tbaa !29
  %t73 = load i32, ptr %l5, !tbaa !23
  %t78 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v1, ptr %v4, ptr %t70, ptr %t71, i1 true, ptr %t72, i32 %t73)
  store ptr %t78, ptr %l70
  br label %bb29
bb21:
  %t79 = load ptr, ptr %l49, !tbaa !29
  store ptr %t79, ptr %l9, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l51, !tbaa !29
  %t82 = load ptr, ptr %l3, !tbaa !29
  store ptr %t82, ptr %l52, !tbaa !29
  %t83 = load ptr, ptr %l2, !tbaa !29
  store ptr %t83, ptr %l53, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l54, !tbaa !29
  %t85 = load ptr, ptr %l9, !tbaa !29
  %t88 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t85)
  store i32 %t88, ptr %l57
  br label %bb22
bb22:
  %t89 = load ptr, ptr %l54, !tbaa !29
  %t90 = load i32, ptr %l57, !tbaa !23
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t89, i32 %t90)
  store i1 %t91, ptr %l58
  br label %bb23
bb23:
  %t92 = load i1, ptr %l58, !tbaa !21
  br i1 %t92, label %bb24, label %bb25
bb24:
  %t93 = load ptr, ptr %l9, !tbaa !29
  %t96 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t93)
  store i32 %t96, ptr %l62
  br label %bb26
bb25:
  %t97 = load i32, ptr %l5, !tbaa !23
  store i32 %t97, ptr %l59, !tbaa !23
  br label %bb27
bb26:
  %t99 = load i32, ptr %l62, !tbaa !23
  store i32 %t99, ptr %l59, !tbaa !23
  br label %bb27
bb27:
  %t100 = load ptr, ptr %l51, !tbaa !29
  %t101 = load ptr, ptr %l52, !tbaa !29
  %t102 = load ptr, ptr %l53, !tbaa !29
  %t103 = load i32, ptr %l59, !tbaa !23
  %t104 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v1, ptr %v4, ptr %t100, ptr %t101, i1 true, ptr %t102, i32 %t103)
  store ptr %t104, ptr %l64
  br label %bb28
bb28:
  %t105 = load ptr, ptr %l64, !tbaa !29
  store ptr %t105, ptr %l8, !tbaa !29
  br label %bb48
bb29:
  %t107 = load ptr, ptr %l70, !tbaa !29
  store ptr %t107, ptr %l8, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  store ptr %t109, ptr %l72, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  store ptr %t110, ptr %l73, !tbaa !29
  %t111 = load ptr, ptr %l4, !tbaa !29
  store ptr %t111, ptr %l74, !tbaa !29
  %t112 = load i32, ptr %l5, !tbaa !23
  %t113 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t116 = icmp eq i32 %t112, %t113
  br i1 %t116, label %bb30, label %bb31
bb30:
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t119 = load ptr, ptr %l4, !tbaa !29
  %t122 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t118, ptr %t119)
  store i1 %t122, ptr %l81
  br label %bb32
bb31:
  store i1 false, ptr %l78, !tbaa !21
  br label %bb33
bb32:
  %t123 = load i1, ptr %l81, !tbaa !21
  store i1 %t123, ptr %l78, !tbaa !21
  br label %bb33
bb33:
  %t124 = load i1, ptr %l78, !tbaa !21
  br i1 %t124, label %bb34, label %bb35
bb34:
  %t125 = load ptr, ptr %l0, !tbaa !29
  %t126 = load ptr, ptr %l2, !tbaa !29
  %t129 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t125, ptr %t126)
  store i1 %t129, ptr %l85
  br label %bb36
bb35:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb37
bb36:
  %t130 = load i1, ptr %l85, !tbaa !21
  %t131 = xor i1 %t130, true
  store i1 %t131, ptr %l82, !tbaa !21
  br label %bb37
bb37:
  %t133 = load i1, ptr %l82, !tbaa !21
  br i1 %t133, label %bb38, label %bb39
bb38:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l88, !tbaa !29
  %t135 = load ptr, ptr %l8, !tbaa !29
  %t138 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t135)
  store i32 %t138, ptr %l91
  br label %bb40
bb39:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb42
bb40:
  %t139 = load ptr, ptr %l88, !tbaa !29
  %t140 = load i32, ptr %l91, !tbaa !23
  %t141 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t139, i32 %t140)
  store i1 %t141, ptr %l92
  br label %bb41
bb41:
  %t142 = load i1, ptr %l92, !tbaa !21
  store i1 %t142, ptr %l87, !tbaa !21
  br label %bb42
bb42:
  %t143 = load i1, ptr %l87, !tbaa !21
  br i1 %t143, label %bb43, label %bb44
bb43:
  %t144 = load ptr, ptr %l8, !tbaa !29
  %t147 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t144)
  store i32 %t147, ptr %l96
  br label %bb45
bb44:
  %t148 = load i32, ptr %l5, !tbaa !23
  store i32 %t148, ptr %l93, !tbaa !23
  br label %bb46
bb45:
  %t150 = load i32, ptr %l96, !tbaa !23
  store i32 %t150, ptr %l93, !tbaa !23
  br label %bb46
bb46:
  %t151 = load ptr, ptr %l72, !tbaa !29
  %t152 = load ptr, ptr %l73, !tbaa !29
  %t153 = load ptr, ptr %l74, !tbaa !29
  %t154 = load i32, ptr %l93, !tbaa !23
  %t155 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v2, ptr %v3, ptr %v4, ptr %t151, ptr %t152, i1 false, ptr %t153, i32 %t154)
  store ptr %t155, ptr %l98
  br label %bb47
bb47:
  %t156 = load ptr, ptr %l98, !tbaa !29
  store ptr %t156, ptr %l9, !tbaa !29
  br label %bb48
bb48:
  %t158 = load ptr, ptr %l8, !tbaa !29
  %t160 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t158)
  store i32 %t160, ptr %l101
  br label %bb49
bb49:
  %t161 = load i32, ptr %l101, !tbaa !23
  store i32 %t161, ptr %l10, !tbaa !23
  %t162 = load ptr, ptr %l9, !tbaa !29
  %t164 = call i32 @compiler_2fcheck_2etypeOf(ptr %v4, ptr %t162)
  store i32 %t164, ptr %l103
  br label %bb50
bb50:
  %t165 = load i32, ptr %l103, !tbaa !23
  store i32 %t165, ptr %l11, !tbaa !23
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i32, ptr %l10, !tbaa !23
  %t170 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t166, i32 %t167)
  store i1 %t170, ptr %l106
  br label %bb51
bb51:
  %t171 = load i1, ptr %l106, !tbaa !21
  br i1 %t171, label %bb52, label %bb53
bb52:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l11, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t172, i32 %t173)
  store i1 %t176, ptr %l110
  br label %bb54
bb53:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb55
bb54:
  %t177 = load i1, ptr %l110, !tbaa !21
  store i1 %t177, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  %t178 = load i1, ptr %l107, !tbaa !21
  br i1 %t178, label %bb56, label %bb57
bb56:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t184 = getelementptr %"compiler/generic:Program", ptr %t182, i32 0, i32 2
  %t185 = load i32, ptr %l10, !tbaa !23
  %t186 = load i32, ptr %l11, !tbaa !23
  %t190 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t184, i32 %t185, i32 %t186)
  store i1 %t190, ptr %l117
  br label %bb58
bb57:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb59
bb58:
  %t191 = load i1, ptr %l117, !tbaa !21
  %t192 = xor i1 %t191, true
  store i1 %t192, ptr %l111, !tbaa !21
  br label %bb59
bb59:
  %t194 = load i1, ptr %l111, !tbaa !21
  br i1 %t194, label %bb60, label %bb61
bb60:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l2, !tbaa !29
  %t199 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %t195, ptr %t196)
  store i1 %t199, ptr %l122
  br label %bb62
bb61:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb63
bb62:
  %t200 = load i1, ptr %l122, !tbaa !21
  %t201 = xor i1 %t200, true
  store i1 %t201, ptr %l119, !tbaa !21
  br label %bb63
bb63:
  %t203 = load i1, ptr %l119, !tbaa !21
  br i1 %t203, label %bb64, label %bb65
bb64:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load ptr, ptr %l4, !tbaa !29
  %t208 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v3, ptr %t204, ptr %t205)
  store i1 %t208, ptr %l127
  br label %bb66
bb65:
  store i1 false, ptr %l124, !tbaa !21
  br label %bb67
bb66:
  %t209 = load i1, ptr %l127, !tbaa !21
  %t210 = xor i1 %t209, true
  store i1 %t210, ptr %l124, !tbaa !21
  br label %bb67
bb67:
  %t212 = load i1, ptr %l124, !tbaa !21
  br i1 %t212, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s5
  %t213 = load ptr, ptr %l0, !tbaa !29
  store ptr %t213, ptr %l129, !tbaa !29
  %t214 = load ptr, ptr %l0, !tbaa !29
  store ptr %t214, ptr %l130, !tbaa !29
  %t215 = load ptr, ptr %l2, !tbaa !29
  %t217 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t215)
  store %"compiler/source:Span" %t217, ptr %l132
  br label %bb70
bb69:
  br label %bb78
bb70:
  %t218 = load ptr, ptr %l3, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t218)
  store %"compiler/source:Span" %t220, ptr %l134
  br label %bb71
bb71:
  %t221 = load ptr, ptr %l130, !tbaa !29
  %t222 = load %"compiler/source:Span", ptr %l132
  %t223 = load %"compiler/source:Span", ptr %l134
  %t224 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %t221, %"compiler/source:Span" %t222, %"compiler/source:Span" %t223, i64 2)
  store %"compiler/source:Span" %t224, ptr %l135
  br label %bb72
bb72:
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t226 = load i32, ptr %l10, !tbaa !23
  %t229 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t225, i32 %t226)
  store { i64, ptr } %t229, ptr %l138
  br label %bb73
bb73:
  %t230 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  store { i64, ptr } %t236, ptr %l139, !tbaa !27
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t238 = load i32, ptr %l11, !tbaa !23
  %t241 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s5, ptr %t237, i32 %t238)
  store { i64, ptr } %t241, ptr %l142
  br label %bb74
bb74:
  %t242 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  %t244 = extractvalue { i64, ptr } %t242, 1
  %t245 = mul i64 %t243, 1
  %t246 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t245)
  call void @llvm.memcpy.p0.p0.i64(ptr %t246, ptr %t244, i64 %t245, i1 false)
  %t247 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  %t249 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t251 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t249, { i64, ptr } %t248)
  store %"compiler/diagmsg:Msg" %t251, ptr %l144
  br label %bb75
bb75:
  %t252 = load ptr, ptr %l129, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l135
  %t254 = load %"compiler/diagmsg:Msg", ptr %l144
  %t255 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t252, %"compiler/source:Span" %t253, %"compiler/diagmsg:Msg" %t254)
  store i64 %t255, ptr %l145
  br label %bb76
bb76:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t257 = load %"compiler/source:Span", ptr %l1
  %t260 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t256, %"compiler/source:Span" %t257)
  store ptr %t260, ptr %l148
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s5)
  %t261 = load ptr, ptr %l148, !tbaa !29
  store ptr %t261, ptr %rv
  br label %ret
bb78:
  %t262 = load i32, ptr %l10, !tbaa !23
  store i32 %t262, ptr %l12, !tbaa !23
  %t264 = load i32, ptr %l5, !tbaa !23
  %t265 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t268 = icmp ne i32 %t264, %t265
  br i1 %t268, label %bb79, label %bb80
bb79:
  %t270 = load i32, ptr %l5, !tbaa !23
  store i32 %t270, ptr %l12, !tbaa !23
  br label %bb236
bb80:
  %t272 = load i32, ptr %l10, !tbaa !23
  %t273 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t276 = icmp eq i32 %t272, %t273
  br i1 %t276, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l157, !tbaa !21
  br label %bb83
bb82:
  %t278 = load i32, ptr %l10, !tbaa !23
  %t279 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t282 = icmp eq i32 %t278, %t279
  store i1 %t282, ptr %l157, !tbaa !21
  br label %bb83
bb83:
  %t284 = load i1, ptr %l157, !tbaa !21
  br i1 %t284, label %bb84, label %bb85
bb84:
  %t285 = load i32, ptr %l11, !tbaa !23
  store i32 %t285, ptr %l12, !tbaa !23
  br label %bb235
bb85:
  %t287 = load i32, ptr %l11, !tbaa !23
  %t288 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t291 = icmp eq i32 %t287, %t288
  br i1 %t291, label %bb86, label %bb87
bb86:
  %t293 = load i32, ptr %l10, !tbaa !23
  store i32 %t293, ptr %l12, !tbaa !23
  br label %bb234
bb87:
  %t295 = load i32, ptr %l10, !tbaa !23
  %t296 = load i32, ptr %l11, !tbaa !23
  %t299 = icmp ne i32 %t295, %t296
  br i1 %t299, label %bb88, label %bb89
bb88:
  %t301 = load i32, ptr %l11, !tbaa !23
  %t302 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t305 = icmp ne i32 %t301, %t302
  store i1 %t305, ptr %l169, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb90
bb90:
  %t307 = load i1, ptr %l169, !tbaa !21
  br i1 %t307, label %bb91, label %bb92
bb91:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = getelementptr %"compiler/check:Checker", ptr %t308, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = getelementptr %"compiler/generic:Program", ptr %t311, i32 0, i32 2
  %t314 = load i32, ptr %l10, !tbaa !23
  %t315 = load i32, ptr %l11, !tbaa !23
  %t319 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t313, i32 %t314, i32 %t315)
  store i1 %t319, ptr %l178
  br label %bb93
bb92:
  br label %bb233
bb93:
  %t320 = load i1, ptr %l178, !tbaa !21
  br i1 %t320, label %bb94, label %bb95
bb94:
  %t321 = load i32, ptr %l10, !tbaa !23
  store i32 %t321, ptr %l12, !tbaa !23
  br label %bb232
bb95:
  %t323 = load ptr, ptr %l0, !tbaa !29
  %t324 = load i32, ptr %l10, !tbaa !23
  %t327 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t323, i32 %t324)
  store i1 %t327, ptr %l182
  br label %bb96
bb96:
  %t328 = load i1, ptr %l182, !tbaa !21
  br i1 %t328, label %bb97, label %bb98
bb97:
  %t329 = load ptr, ptr %l0, !tbaa !29
  %t330 = load i32, ptr %l11, !tbaa !23
  %t333 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t329, i32 %t330)
  store i1 %t333, ptr %l186
  br label %bb99
bb98:
  store i1 false, ptr %l183, !tbaa !21
  br label %bb100
bb99:
  %t334 = load i1, ptr %l186, !tbaa !21
  store i1 %t334, ptr %l183, !tbaa !21
  br label %bb100
bb100:
  %t335 = load i1, ptr %l183, !tbaa !21
  br i1 %t335, label %bb101, label %bb102
bb101:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/check:Checker", ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t340 = load i32, ptr %l10, !tbaa !23
  %t341 = load i32, ptr %l11, !tbaa !23
  %t345 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t339, i32 %t340, i32 %t341)
  store i32 %t345, ptr %l192
  br label %bb103
bb102:
  store i1 false, ptr %l187, !tbaa !21
  br label %bb104
bb103:
  %t346 = load i32, ptr %l192, !tbaa !23
  %t347 = icmp sge i32 %t346, 0
  store i1 %t347, ptr %l187, !tbaa !21
  br label %bb104
bb104:
  %t349 = load i1, ptr %l187, !tbaa !21
  br i1 %t349, label %bb105, label %bb106
bb105:
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t354 = load i32, ptr %l10, !tbaa !23
  %t355 = load i32, ptr %l11, !tbaa !23
  %t359 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %t353, i32 %t354, i32 %t355)
  store i32 %t359, ptr %l198
  br label %bb107
bb106:
  %t360 = load i32, ptr %l11, !tbaa !23
  %t361 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t364 = icmp eq i32 %t360, %t361
  br i1 %t364, label %bb108, label %bb109
bb107:
  %t366 = load i32, ptr %l198, !tbaa !23
  store i32 %t366, ptr %l12, !tbaa !23
  br label %bb231
bb108:
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i32, ptr %l10, !tbaa !23
  %t371 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t367, i32 %t368)
  store i1 %t371, ptr %l205
  br label %bb110
bb109:
  store i1 false, ptr %l202, !tbaa !21
  br label %bb115
bb110:
  %t372 = load i1, ptr %l205, !tbaa !21
  br i1 %t372, label %bb111, label %bb112
bb111:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb114
bb112:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t375 = getelementptr %"compiler/check:Checker", ptr %t373, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !29
  %t378 = getelementptr %"compiler/generic:Program", ptr %t376, i32 0, i32 2
  %t379 = load i32, ptr %l10, !tbaa !23
  %t382 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t378, i32 %t379)
  store i32 %t382, ptr %l211
  br label %bb113
bb113:
  %t383 = load i32, ptr %l211, !range !{i32 0, i32 33}
  %t385 = trunc i64 21 to i32
  %t386 = icmp eq i32 %t383, %t385
  store i1 %t386, ptr %l206, !tbaa !21
  br label %bb114
bb114:
  %t388 = load i1, ptr %l206, !tbaa !21
  store i1 %t388, ptr %l202, !tbaa !21
  br label %bb115
bb115:
  %t389 = load i1, ptr %l202, !tbaa !21
  br i1 %t389, label %bb116, label %bb117
bb116:
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = getelementptr %"compiler/check:Checker", ptr %t390, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !29
  %t395 = getelementptr %"compiler/generic:Program", ptr %t393, i32 0, i32 2
  %t396 = load i32, ptr %l10, !tbaa !23
  %t399 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t395, i32 %t396)
  store i32 %t399, ptr %l218
  br label %bb118
bb117:
  %t400 = load i32, ptr %l10, !tbaa !23
  %t401 = load i32, ptr @G_2ecompiler_2ftypes_2eNullT, !tbaa !23
  %t404 = icmp eq i32 %t400, %t401
  br i1 %t404, label %bb119, label %bb120
bb118:
  %t406 = load i32, ptr %l218, !tbaa !23
  store i32 %t406, ptr %l12, !tbaa !23
  br label %bb230
bb119:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t408 = load i32, ptr %l11, !tbaa !23
  %t411 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t407, i32 %t408)
  store i1 %t411, ptr %l225
  br label %bb121
bb120:
  store i1 false, ptr %l222, !tbaa !21
  br label %bb126
bb121:
  %t412 = load i1, ptr %l225, !tbaa !21
  br i1 %t412, label %bb122, label %bb123
bb122:
  store i1 true, ptr %l226, !tbaa !21
  br label %bb125
bb123:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = getelementptr %"compiler/check:Checker", ptr %t413, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !29
  %t418 = getelementptr %"compiler/generic:Program", ptr %t416, i32 0, i32 2
  %t419 = load i32, ptr %l11, !tbaa !23
  %t422 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t418, i32 %t419)
  store i32 %t422, ptr %l231
  br label %bb124
bb124:
  %t423 = load i32, ptr %l231, !range !{i32 0, i32 33}
  %t425 = trunc i64 21 to i32
  %t426 = icmp eq i32 %t423, %t425
  store i1 %t426, ptr %l226, !tbaa !21
  br label %bb125
bb125:
  %t428 = load i1, ptr %l226, !tbaa !21
  store i1 %t428, ptr %l222, !tbaa !21
  br label %bb126
bb126:
  %t429 = load i1, ptr %l222, !tbaa !21
  br i1 %t429, label %bb127, label %bb128
bb127:
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t432 = getelementptr %"compiler/check:Checker", ptr %t430, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !29
  %t435 = getelementptr %"compiler/generic:Program", ptr %t433, i32 0, i32 2
  %t436 = load i32, ptr %l11, !tbaa !23
  %t439 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t435, i32 %t436)
  store i32 %t439, ptr %l238
  br label %bb129
bb128:
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/check:Checker", ptr %t440, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !29
  %t445 = getelementptr %"compiler/generic:Program", ptr %t443, i32 0, i32 2
  %t446 = load i32, ptr %l10, !tbaa !23
  %t449 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t445, i32 %t446)
  store i32 %t449, ptr %l243
  br label %bb130
bb129:
  %t450 = load i32, ptr %l238, !tbaa !23
  store i32 %t450, ptr %l12, !tbaa !23
  br label %bb229
bb130:
  %t451 = load i32, ptr %l243, !range !{i32 0, i32 33}
  %t453 = trunc i64 21 to i32
  %t454 = icmp eq i32 %t451, %t453
  br i1 %t454, label %bb131, label %bb132
bb131:
  %t456 = load ptr, ptr %l0, !tbaa !29
  %t458 = getelementptr %"compiler/check:Checker", ptr %t456, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !29
  %t461 = getelementptr %"compiler/generic:Program", ptr %t459, i32 0, i32 2
  store ptr %t461, ptr %l249, !tbaa !29
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t464 = getelementptr %"compiler/check:Checker", ptr %t462, i32 0, i32 1
  %t465 = load ptr, ptr %t464, !tbaa !29
  %t467 = getelementptr %"compiler/generic:Program", ptr %t465, i32 0, i32 2
  %t468 = load i32, ptr %l10, !tbaa !23
  %t471 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t467, i32 %t468)
  store i32 %t471, ptr %l254
  br label %bb133
bb132:
  store i1 false, ptr %l246, !tbaa !21
  br label %bb136
bb133:
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t474 = getelementptr %"compiler/check:Checker", ptr %t472, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !29
  %t477 = getelementptr %"compiler/generic:Program", ptr %t475, i32 0, i32 2
  %t478 = load i32, ptr %l11, !tbaa !23
  %t481 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t477, i32 %t478)
  store i32 %t481, ptr %l259
  br label %bb134
bb134:
  %t482 = load ptr, ptr %l249, !tbaa !29
  %t483 = load i32, ptr %l254, !tbaa !23
  %t484 = load i32, ptr %l259, !tbaa !23
  %t485 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t482, i32 %t483, i32 %t484)
  store i1 %t485, ptr %l260
  br label %bb135
bb135:
  %t486 = load i1, ptr %l260, !tbaa !21
  store i1 %t486, ptr %l246, !tbaa !21
  br label %bb136
bb136:
  %t487 = load i1, ptr %l246, !tbaa !21
  br i1 %t487, label %bb137, label %bb138
bb137:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t490 = getelementptr %"compiler/check:Checker", ptr %t488, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !29
  %t493 = getelementptr %"compiler/generic:Program", ptr %t491, i32 0, i32 2
  %t494 = load i32, ptr %l10, !tbaa !23
  %t497 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t493, i32 %t494)
  store i32 %t497, ptr %l265
  br label %bb139
bb138:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t499 = load i32, ptr %l10, !tbaa !23
  %t502 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t498, i32 %t499)
  store i1 %t502, ptr %l268
  br label %bb140
bb139:
  %t503 = load i32, ptr %l265, !tbaa !23
  store i32 %t503, ptr %l12, !tbaa !23
  br label %bb228
bb140:
  %t504 = load i1, ptr %l268, !tbaa !21
  br i1 %t504, label %bb141, label %bb142
bb141:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load i32, ptr %l11, !tbaa !23
  %t509 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t505, i32 %t506)
  store i1 %t509, ptr %l272
  br label %bb143
bb142:
  store i1 false, ptr %l269, !tbaa !21
  br label %bb144
bb143:
  %t510 = load i1, ptr %l272, !tbaa !21
  %t511 = xor i1 %t510, true
  store i1 %t511, ptr %l269, !tbaa !21
  br label %bb144
bb144:
  %t513 = load i1, ptr %l269, !tbaa !21
  br i1 %t513, label %bb145, label %bb146
bb145:
  %t514 = load ptr, ptr %l0, !tbaa !29
  store ptr %t514, ptr %l275, !tbaa !29
  %t515 = load i32, ptr %l11, !tbaa !23
  store i32 %t515, ptr %l276, !tbaa !23
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t518 = getelementptr %"compiler/check:Checker", ptr %t516, i32 0, i32 1
  %t519 = load ptr, ptr %t518, !tbaa !29
  %t521 = getelementptr %"compiler/generic:Program", ptr %t519, i32 0, i32 2
  %t522 = load i32, ptr %l10, !tbaa !23
  %t525 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t521, i32 %t522)
  store i32 %t525, ptr %l281
  br label %bb147
bb146:
  store i1 false, ptr %l274, !tbaa !21
  br label %bb149
bb147:
  %t526 = load ptr, ptr %l275, !tbaa !29
  %t527 = load i32, ptr %l276, !tbaa !23
  %t528 = load i32, ptr %l281, !tbaa !23
  %t529 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t526, i32 %t527, i32 %t528)
  store i1 %t529, ptr %l282
  br label %bb148
bb148:
  %t530 = load i1, ptr %l282, !tbaa !21
  store i1 %t530, ptr %l274, !tbaa !21
  br label %bb149
bb149:
  %t531 = load i1, ptr %l274, !tbaa !21
  br i1 %t531, label %bb150, label %bb151
bb150:
  %t532 = load i32, ptr %l10, !tbaa !23
  store i32 %t532, ptr %l12, !tbaa !23
  br label %bb227
bb151:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t535 = load i32, ptr %l11, !tbaa !23
  %t538 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t534, i32 %t535)
  store i1 %t538, ptr %l286
  br label %bb152
bb152:
  %t539 = load i1, ptr %l286, !tbaa !21
  br i1 %t539, label %bb153, label %bb154
bb153:
  %t540 = load ptr, ptr %l0, !tbaa !29
  %t541 = load i32, ptr %l10, !tbaa !23
  %t544 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t540, i32 %t541)
  store i1 %t544, ptr %l290
  br label %bb155
bb154:
  store i1 false, ptr %l287, !tbaa !21
  br label %bb156
bb155:
  %t545 = load i1, ptr %l290, !tbaa !21
  %t546 = xor i1 %t545, true
  store i1 %t546, ptr %l287, !tbaa !21
  br label %bb156
bb156:
  %t548 = load i1, ptr %l287, !tbaa !21
  br i1 %t548, label %bb157, label %bb158
bb157:
  %t549 = load ptr, ptr %l0, !tbaa !29
  store ptr %t549, ptr %l293, !tbaa !29
  %t550 = load i32, ptr %l10, !tbaa !23
  store i32 %t550, ptr %l294, !tbaa !23
  %t551 = load ptr, ptr %l0, !tbaa !29
  %t553 = getelementptr %"compiler/check:Checker", ptr %t551, i32 0, i32 1
  %t554 = load ptr, ptr %t553, !tbaa !29
  %t556 = getelementptr %"compiler/generic:Program", ptr %t554, i32 0, i32 2
  %t557 = load i32, ptr %l11, !tbaa !23
  %t560 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t556, i32 %t557)
  store i32 %t560, ptr %l299
  br label %bb159
bb158:
  store i1 false, ptr %l292, !tbaa !21
  br label %bb161
bb159:
  %t561 = load ptr, ptr %l293, !tbaa !29
  %t562 = load i32, ptr %l294, !tbaa !23
  %t563 = load i32, ptr %l299, !tbaa !23
  %t564 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %t561, i32 %t562, i32 %t563)
  store i1 %t564, ptr %l300
  br label %bb160
bb160:
  %t565 = load i1, ptr %l300, !tbaa !21
  store i1 %t565, ptr %l292, !tbaa !21
  br label %bb161
bb161:
  %t566 = load i1, ptr %l292, !tbaa !21
  br i1 %t566, label %bb162, label %bb163
bb162:
  %t567 = load i32, ptr %l11, !tbaa !23
  store i32 %t567, ptr %l12, !tbaa !23
  br label %bb226
bb163:
  %t569 = load ptr, ptr %l0, !tbaa !29
  %t570 = load i32, ptr %l10, !tbaa !23
  %t573 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t569, i32 %t570)
  store i1 %t573, ptr %l304
  br label %bb164
bb164:
  %t574 = load i1, ptr %l304, !tbaa !21
  br i1 %t574, label %bb165, label %bb166
bb165:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t576 = load i32, ptr %l11, !tbaa !23
  %t579 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t575, i32 %t576)
  store i1 %t579, ptr %l308
  br label %bb167
bb166:
  store i1 false, ptr %l305, !tbaa !21
  br label %bb168
bb167:
  %t580 = load i1, ptr %l308, !tbaa !21
  store i1 %t580, ptr %l305, !tbaa !21
  br label %bb168
bb168:
  %t581 = load i1, ptr %l305, !tbaa !21
  br i1 %t581, label %bb169, label %bb170
bb169:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t584 = getelementptr %"compiler/check:Checker", ptr %t582, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !29
  %t587 = getelementptr %"compiler/generic:Program", ptr %t585, i32 0, i32 2
  store ptr %t587, ptr %l312, !tbaa !29
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load i32, ptr %l10, !tbaa !23
  %t592 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t588, i32 %t589)
  store i32 %t592, ptr %l315
  br label %bb171
bb170:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb174
bb171:
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t594 = load i32, ptr %l11, !tbaa !23
  %t597 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t593, i32 %t594)
  store i32 %t597, ptr %l318
  br label %bb172
bb172:
  %t598 = load ptr, ptr %l312, !tbaa !29
  %t599 = load i32, ptr %l315, !tbaa !23
  %t600 = load i32, ptr %l318, !tbaa !23
  %t601 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t598, i32 %t599, i32 %t600)
  store i1 %t601, ptr %l319
  br label %bb173
bb173:
  %t602 = load i1, ptr %l319, !tbaa !21
  store i1 %t602, ptr %l309, !tbaa !21
  br label %bb174
bb174:
  %t603 = load i1, ptr %l309, !tbaa !21
  br i1 %t603, label %bb175, label %bb176
bb175:
  %t604 = load ptr, ptr %l0, !tbaa !29
  %t606 = getelementptr %"compiler/check:Checker", ptr %t604, i32 0, i32 1
  %t607 = load ptr, ptr %t606, !tbaa !29
  %t609 = getelementptr %"compiler/generic:Program", ptr %t607, i32 0, i32 2
  store ptr %t609, ptr %l322, !tbaa !29
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load i32, ptr %l10, !tbaa !23
  %t614 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t610, i32 %t611)
  store i32 %t614, ptr %l325
  br label %bb177
bb176:
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l10, !tbaa !23
  %t619 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t615, i32 %t616)
  store i1 %t619, ptr %l340
  br label %bb182
bb177:
  %t620 = load ptr, ptr %l0, !tbaa !29
  %t622 = getelementptr %"compiler/check:Checker", ptr %t620, i32 0, i32 1
  %t623 = load ptr, ptr %t622, !tbaa !29
  %t625 = getelementptr %"compiler/generic:Program", ptr %t623, i32 0, i32 2
  %t626 = load i32, ptr %l10, !tbaa !23
  %t629 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t625, i32 %t626)
  store i64 %t629, ptr %l330
  br label %bb178
bb178:
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t632 = getelementptr %"compiler/check:Checker", ptr %t630, i32 0, i32 1
  %t633 = load ptr, ptr %t632, !tbaa !29
  %t635 = getelementptr %"compiler/generic:Program", ptr %t633, i32 0, i32 2
  %t636 = load i32, ptr %l11, !tbaa !23
  %t639 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t635, i32 %t636)
  store i64 %t639, ptr %l335
  br label %bb179
bb179:
  %t640 = load i64, ptr %l330, !tbaa !24
  %t641 = load i64, ptr %l335, !tbaa !24
  %t642 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t640, i64 %t641)
  store i64 %t642, ptr %l336
  br label %bb180
bb180:
  %t643 = load ptr, ptr %l322, !tbaa !29
  %t644 = load i32, ptr %l325, !tbaa !23
  %t645 = load i64, ptr %l336, !tbaa !24
  %t646 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t643, i32 %t644, i64 %t645)
  store i32 %t646, ptr %l337
  br label %bb181
bb181:
  %t647 = load i32, ptr %l337, !tbaa !23
  store i32 %t647, ptr %l12, !tbaa !23
  br label %bb225
bb182:
  %t648 = load i1, ptr %l340, !tbaa !21
  br i1 %t648, label %bb183, label %bb184
bb183:
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load i32, ptr %l11, !tbaa !23
  %t653 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t649, i32 %t650)
  store i1 %t653, ptr %l344
  br label %bb185
bb184:
  store i1 false, ptr %l341, !tbaa !21
  br label %bb186
bb185:
  %t654 = load i1, ptr %l344, !tbaa !21
  store i1 %t654, ptr %l341, !tbaa !21
  br label %bb186
bb186:
  %t655 = load i1, ptr %l341, !tbaa !21
  br i1 %t655, label %bb187, label %bb188
bb187:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t658 = getelementptr %"compiler/check:Checker", ptr %t656, i32 0, i32 1
  %t659 = load ptr, ptr %t658, !tbaa !29
  %t661 = getelementptr %"compiler/generic:Program", ptr %t659, i32 0, i32 2
  store ptr %t661, ptr %l348, !tbaa !29
  %t662 = load ptr, ptr %l0, !tbaa !29
  store ptr %t662, ptr %l349, !tbaa !29
  %t663 = load ptr, ptr %l0, !tbaa !29
  %t664 = load i32, ptr %l10, !tbaa !23
  %t667 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t663, i32 %t664)
  store i32 %t667, ptr %l352
  br label %bb189
bb188:
  store i1 false, ptr %l345, !tbaa !21
  br label %bb194
bb189:
  %t668 = load ptr, ptr %l349, !tbaa !29
  %t669 = load i32, ptr %l352, !tbaa !23
  %t670 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t668, i32 %t669)
  store i32 %t670, ptr %l353
  br label %bb190
bb190:
  %t671 = load ptr, ptr %l0, !tbaa !29
  store ptr %t671, ptr %l354, !tbaa !29
  %t672 = load ptr, ptr %l0, !tbaa !29
  %t673 = load i32, ptr %l11, !tbaa !23
  %t676 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t672, i32 %t673)
  store i32 %t676, ptr %l357
  br label %bb191
bb191:
  %t677 = load ptr, ptr %l354, !tbaa !29
  %t678 = load i32, ptr %l357, !tbaa !23
  %t679 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t677, i32 %t678)
  store i32 %t679, ptr %l358
  br label %bb192
bb192:
  %t680 = load ptr, ptr %l348, !tbaa !29
  %t681 = load i32, ptr %l353, !tbaa !23
  %t682 = load i32, ptr %l358, !tbaa !23
  %t683 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t680, i32 %t681, i32 %t682)
  store i1 %t683, ptr %l359
  br label %bb193
bb193:
  %t684 = load i1, ptr %l359, !tbaa !21
  store i1 %t684, ptr %l345, !tbaa !21
  br label %bb194
bb194:
  %t685 = load i1, ptr %l345, !tbaa !21
  br i1 %t685, label %bb195, label %bb196
bb195:
  %t686 = load ptr, ptr %l0, !tbaa !29
  %t688 = getelementptr %"compiler/check:Checker", ptr %t686, i32 0, i32 1
  %t689 = load ptr, ptr %t688, !tbaa !29
  %t691 = getelementptr %"compiler/generic:Program", ptr %t689, i32 0, i32 2
  store ptr %t691, ptr %l362, !tbaa !29
  %t692 = load ptr, ptr %l0, !tbaa !29
  store ptr %t692, ptr %l363, !tbaa !29
  %t693 = load ptr, ptr %l0, !tbaa !29
  %t694 = load i32, ptr %l10, !tbaa !23
  %t697 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %t693, i32 %t694)
  store i32 %t697, ptr %l366
  br label %bb197
bb196:
  %t698 = load ptr, ptr %l0, !tbaa !29
  %t700 = getelementptr %"compiler/check:Checker", ptr %t698, i32 0, i32 1
  %t701 = load ptr, ptr %t700, !tbaa !29
  %t703 = getelementptr %"compiler/generic:Program", ptr %t701, i32 0, i32 2
  %t704 = load i32, ptr %l10, !tbaa !23
  %t707 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t703, i32 %t704)
  store i32 %t707, ptr %l384
  br label %bb203
bb197:
  %t708 = load ptr, ptr %l363, !tbaa !29
  %t709 = load i32, ptr %l366, !tbaa !23
  %t710 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t708, i32 %t709)
  store i32 %t710, ptr %l367
  br label %bb198
bb198:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t713 = getelementptr %"compiler/check:Checker", ptr %t711, i32 0, i32 1
  %t714 = load ptr, ptr %t713, !tbaa !29
  %t716 = getelementptr %"compiler/generic:Program", ptr %t714, i32 0, i32 2
  %t717 = load i32, ptr %l10, !tbaa !23
  %t720 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t716, i32 %t717)
  store i64 %t720, ptr %l372
  br label %bb199
bb199:
  %t721 = load ptr, ptr %l0, !tbaa !29
  %t723 = getelementptr %"compiler/check:Checker", ptr %t721, i32 0, i32 1
  %t724 = load ptr, ptr %t723, !tbaa !29
  %t726 = getelementptr %"compiler/generic:Program", ptr %t724, i32 0, i32 2
  %t727 = load i32, ptr %l11, !tbaa !23
  %t730 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t726, i32 %t727)
  store i64 %t730, ptr %l377
  br label %bb200
bb200:
  %t731 = load i64, ptr %l372, !tbaa !24
  %t732 = load i64, ptr %l377, !tbaa !24
  %t733 = call i64 @compiler_2fcheck_2emeetPerm(i64 %t731, i64 %t732)
  store i64 %t733, ptr %l378
  br label %bb201
bb201:
  %t734 = load ptr, ptr %l362, !tbaa !29
  %t735 = load i32, ptr %l367, !tbaa !23
  %t736 = load i64, ptr %l378, !tbaa !24
  %t737 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t734, i32 %t735, i64 %t736)
  store i32 %t737, ptr %l379
  br label %bb202
bb202:
  %t738 = load i32, ptr %l379, !tbaa !23
  store i32 %t738, ptr %l12, !tbaa !23
  br label %bb224
bb203:
  %t739 = load i32, ptr %l384, !range !{i32 0, i32 33}
  %t741 = trunc i64 19 to i32
  %t742 = icmp eq i32 %t739, %t741
  br i1 %t742, label %bb204, label %bb205
bb204:
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t746 = getelementptr %"compiler/check:Checker", ptr %t744, i32 0, i32 1
  %t747 = load ptr, ptr %t746, !tbaa !29
  %t749 = getelementptr %"compiler/generic:Program", ptr %t747, i32 0, i32 2
  %t750 = load i32, ptr %l11, !tbaa !23
  %t753 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t749, i32 %t750)
  store i32 %t753, ptr %l392
  br label %bb206
bb205:
  store i1 false, ptr %l387, !tbaa !21
  br label %bb207
bb206:
  %t754 = load i32, ptr %l392, !range !{i32 0, i32 33}
  %t756 = trunc i64 19 to i32
  %t757 = icmp eq i32 %t754, %t756
  store i1 %t757, ptr %l387, !tbaa !21
  br label %bb207
bb207:
  %t759 = load i1, ptr %l387, !tbaa !21
  br i1 %t759, label %bb208, label %bb209
bb208:
  %t760 = load ptr, ptr %l0, !tbaa !29
  %t762 = getelementptr %"compiler/check:Checker", ptr %t760, i32 0, i32 1
  %t763 = load ptr, ptr %t762, !tbaa !29
  %t765 = getelementptr %"compiler/generic:Program", ptr %t763, i32 0, i32 2
  store ptr %t765, ptr %l398, !tbaa !29
  %t766 = load ptr, ptr %l0, !tbaa !29
  %t768 = getelementptr %"compiler/check:Checker", ptr %t766, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !29
  %t771 = getelementptr %"compiler/generic:Program", ptr %t769, i32 0, i32 2
  %t772 = load i32, ptr %l10, !tbaa !23
  %t775 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t771, i32 %t772)
  store i32 %t775, ptr %l403
  br label %bb210
bb209:
  store i1 false, ptr %l395, !tbaa !21
  br label %bb213
bb210:
  %t776 = load ptr, ptr %l0, !tbaa !29
  %t778 = getelementptr %"compiler/check:Checker", ptr %t776, i32 0, i32 1
  %t779 = load ptr, ptr %t778, !tbaa !29
  %t781 = getelementptr %"compiler/generic:Program", ptr %t779, i32 0, i32 2
  %t782 = load i32, ptr %l11, !tbaa !23
  %t785 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t781, i32 %t782)
  store i32 %t785, ptr %l408
  br label %bb211
bb211:
  %t786 = load ptr, ptr %l398, !tbaa !29
  %t787 = load i32, ptr %l403, !tbaa !23
  %t788 = load i32, ptr %l408, !tbaa !23
  %t789 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t786, i32 %t787, i32 %t788)
  store i1 %t789, ptr %l409
  br label %bb212
bb212:
  %t790 = load i1, ptr %l409, !tbaa !21
  store i1 %t790, ptr %l395, !tbaa !21
  br label %bb213
bb213:
  %t791 = load i1, ptr %l395, !tbaa !21
  br i1 %t791, label %bb214, label %bb215
bb214:
  %t792 = load ptr, ptr %l0, !tbaa !29
  %t794 = getelementptr %"compiler/check:Checker", ptr %t792, i32 0, i32 1
  %t795 = load ptr, ptr %t794, !tbaa !29
  %t797 = getelementptr %"compiler/generic:Program", ptr %t795, i32 0, i32 2
  store ptr %t797, ptr %l412, !tbaa !29
  %t798 = load ptr, ptr %l0, !tbaa !29
  %t800 = getelementptr %"compiler/check:Checker", ptr %t798, i32 0, i32 1
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t803 = getelementptr %"compiler/generic:Program", ptr %t801, i32 0, i32 2
  %t804 = load i32, ptr %l10, !tbaa !23
  %t807 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t803, i32 %t804)
  store i32 %t807, ptr %l417
  br label %bb216
bb215:
  store %olang.scope zeroinitializer, ptr %s32
  %t808 = load ptr, ptr %l0, !tbaa !29
  store ptr %t808, ptr %l419, !tbaa !29
  %t809 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t809, ptr %l420
  %t810 = load ptr, ptr %l0, !tbaa !29
  %t811 = load i32, ptr %l10, !tbaa !23
  %t814 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s32, ptr %t810, i32 %t811)
  store { i64, ptr } %t814, ptr %l423
  br label %bb218
bb216:
  %t815 = load ptr, ptr %l412, !tbaa !29
  %t816 = load i32, ptr %l417, !tbaa !23
  %t817 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %t815, i32 %t816, i32 0)
  store i32 %t817, ptr %l418
  br label %bb217
bb217:
  %t818 = load i32, ptr %l418, !tbaa !23
  store i32 %t818, ptr %l12, !tbaa !23
  br label %bb223
bb218:
  %t819 = load { i64, ptr }, ptr %l423, !tbaa !27
  %t820 = extractvalue { i64, ptr } %t819, 0
  %t821 = extractvalue { i64, ptr } %t819, 1
  %t822 = mul i64 %t820, 1
  %t823 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t822)
  call void @llvm.memcpy.p0.p0.i64(ptr %t823, ptr %t821, i64 %t822, i1 false)
  %t824 = insertvalue { i64, ptr } undef, i64 %t820, 0
  %t825 = insertvalue { i64, ptr } %t824, ptr %t823, 1
  store { i64, ptr } %t825, ptr %l424, !tbaa !27
  %t826 = load ptr, ptr %l0, !tbaa !29
  %t827 = load i32, ptr %l11, !tbaa !23
  %t830 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s32, ptr %t826, i32 %t827)
  store { i64, ptr } %t830, ptr %l427
  br label %bb219
bb219:
  %t831 = load { i64, ptr }, ptr %l427, !tbaa !27
  %t832 = extractvalue { i64, ptr } %t831, 0
  %t833 = extractvalue { i64, ptr } %t831, 1
  %t834 = mul i64 %t832, 1
  %t835 = call ptr @__olang_scope_alloc(ptr %s32, i64 %t834)
  call void @llvm.memcpy.p0.p0.i64(ptr %t835, ptr %t833, i64 %t834, i1 false)
  %t836 = insertvalue { i64, ptr } undef, i64 %t832, 0
  %t837 = insertvalue { i64, ptr } %t836, ptr %t835, 1
  %t838 = load { i64, ptr }, ptr %l424, !tbaa !27
  %t840 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %s32, ptr %s32, ptr %s32, { i64, ptr } %t838, { i64, ptr } %t837)
  store %"compiler/diagmsg:Msg" %t840, ptr %l429
  br label %bb220
bb220:
  %t841 = load ptr, ptr %l419, !tbaa !29
  %t842 = load %"compiler/source:Span", ptr %l420
  %t843 = load %"compiler/diagmsg:Msg", ptr %l429
  %t844 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s32, ptr %t841, %"compiler/source:Span" %t842, %"compiler/diagmsg:Msg" %t843)
  store i64 %t844, ptr %l430
  br label %bb221
bb221:
  %t845 = load ptr, ptr %l0, !tbaa !29
  %t846 = load %"compiler/source:Span", ptr %l1
  %t849 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v4, ptr %t845, %"compiler/source:Span" %t846)
  store ptr %t849, ptr %l433
  br label %bb222
bb222:
  call void @__olang_scope_close(ptr %s32)
  %t850 = load ptr, ptr %l433, !tbaa !29
  store ptr %t850, ptr %rv
  br label %ret
bb223:
  br label %bb224
bb224:
  br label %bb225
bb225:
  br label %bb226
bb226:
  br label %bb227
bb227:
  br label %bb228
bb228:
  br label %bb229
bb229:
  br label %bb230
bb230:
  br label %bb231
bb231:
  br label %bb232
bb232:
  br label %bb233
bb233:
  br label %bb234
bb234:
  br label %bb235
bb235:
  br label %bb236
bb236:
  %t851 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t851, ptr %l434
  %t852 = load i32, ptr %l12, !tbaa !23
  store i32 %t852, ptr %l435, !tbaa !23
  %t853 = load ptr, ptr %l7, !tbaa !29
  store ptr %t853, ptr %l436, !tbaa !29
  %t854 = load ptr, ptr %l0, !tbaa !29
  store ptr %t854, ptr %l437, !tbaa !29
  %t855 = load ptr, ptr %l8, !tbaa !29
  %t857 = icmp eq ptr %t855, null
  br i1 %t857, label %bb237, label %bb238
bb237:
  call void @__olang_check_failed(ptr @olang_loc_db85c439bc9f5684_3c0400873f27ba78)
  unreachable
bb238:
  br label %bb239
bb239:
  %t859 = load ptr, ptr %l8, !tbaa !29
  store ptr %t859, ptr %l440, !tbaa !29
  %t860 = load i32, ptr %l12, !tbaa !23
  store i32 %t860, ptr %l441, !tbaa !23
  %t861 = load ptr, ptr %l2, !tbaa !29
  %t863 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t861)
  store %"compiler/source:Span" %t863, ptr %l443
  br label %bb240
bb240:
  %t864 = load ptr, ptr %l437, !tbaa !29
  %t865 = load ptr, ptr %l440, !tbaa !29
  %t866 = load i32, ptr %l441, !tbaa !23
  %t867 = load %"compiler/source:Span", ptr %l443
  %t868 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v4, ptr %v4, ptr %t864, ptr %t865, i32 %t866, %"compiler/source:Span" %t867)
  store ptr %t868, ptr %l444
  br label %bb241
bb241:
  %t869 = load ptr, ptr %l444, !tbaa !29
  store ptr %t869, ptr %l445, !tbaa !29
  %t870 = load ptr, ptr %l0, !tbaa !29
  store ptr %t870, ptr %l446, !tbaa !29
  %t871 = load ptr, ptr %l9, !tbaa !29
  %t873 = icmp eq ptr %t871, null
  br i1 %t873, label %bb242, label %bb243
bb242:
  call void @__olang_check_failed(ptr @olang_loc_db85c439bc9f5684_3c0400873f27ba78)
  unreachable
bb243:
  br label %bb244
bb244:
  %t875 = load ptr, ptr %l9, !tbaa !29
  store ptr %t875, ptr %l449, !tbaa !29
  %t876 = load i32, ptr %l12, !tbaa !23
  store i32 %t876, ptr %l450, !tbaa !23
  %t877 = load ptr, ptr %l4, !tbaa !29
  %t879 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v3, ptr %t877)
  store %"compiler/source:Span" %t879, ptr %l452
  br label %bb245
bb245:
  %t880 = load ptr, ptr %l446, !tbaa !29
  %t881 = load ptr, ptr %l449, !tbaa !29
  %t882 = load i32, ptr %l450, !tbaa !23
  %t883 = load %"compiler/source:Span", ptr %l452
  %t884 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v4, ptr %v0, ptr %t880, ptr %t881, i32 %t882, %"compiler/source:Span" %t883)
  store ptr %t884, ptr %l453
  br label %bb246
bb246:
  %t885 = load ptr, ptr %l436, !tbaa !29
  %t886 = load ptr, ptr %l445, !tbaa !29
  %t887 = load ptr, ptr %l453, !tbaa !29
  %t888 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v4, ptr %v4, ptr %v0, ptr %v4, ptr %t885, ptr %t886, ptr %t887)
  store %"compiler/typed:Cond" %t888, ptr %l454
  br label %bb247
bb247:
  %t889 = load %"compiler/typed:Cond", ptr %l454
  %t890 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 24, i64 8)
  store %"compiler/typed:Cond" %t889, ptr %t890
  store { i64, [5 x i64] } zeroinitializer, ptr %t891
  %t892 = getelementptr { i64, [5 x i64] }, ptr %t891, i32 0, i32 0
  store i64 11, ptr %t892
  %t893 = load %"compiler/source:Span", ptr %l434
  %t894 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t893, 0
  %t895 = load i32, ptr %l435, !tbaa !23
  %t896 = insertvalue { %"compiler/source:Span", i32, ptr } %t894, i32 %t895, 1
  %t898 = insertvalue { %"compiler/source:Span", i32, ptr } %t896, ptr %t890, 2
  %t899 = getelementptr { i64, [5 x i64] }, ptr %t891, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t898, ptr %t899
  %t900 = load { i64, [5 x i64] }, ptr %t891
  %t902 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store { i64, [5 x i64] } %t900, ptr %t902
  store ptr %t902, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectSourceOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca i64
  %lp10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca ptr
  %l23 = alloca ptr
  %l32 = alloca i64
  %l36 = alloca ptr
  %l48 = alloca ptr
  %l50 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l57 = alloca i64
  %l61 = alloca { i64, ptr }
  %l64 = alloca %"compiler/check:ctSource"
  %l73 = alloca i32
  %l77 = alloca ptr
  %l80 = alloca i1
  %l89 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca ptr
  %l98 = alloca i1
  %l106 = alloca i1
  %l130 = alloca %"compiler/check:ctSource"
  %l132 = alloca ptr
  %l133 = alloca i1
  %l140 = alloca i1
  %l158 = alloca %"compiler/check:ctSource"
  %l165 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l176 = alloca i1
  %l184 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l192 = alloca i32
  %l198 = alloca %"compiler/source:Span"
  %l202 = alloca ptr
  %l206 = alloca %"compiler/ast:Param"
  %l214 = alloca ptr
  %l215 = alloca ptr
  %l218 = alloca { i64, ptr }
  %l223 = alloca i64
  %l226 = alloca { i64, ptr }
  %l230 = alloca { i64, ptr }
  %l233 = alloca %"compiler/check:ctSource"
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca ptr
  %t429 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t7 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t3, i64 %a1)
  store ptr %t7, ptr %l23
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l23, !tbaa !29
  %t10 = getelementptr %"compiler/typed:Body", ptr %t8, i32 0, i32 1
  %t11 = load { i64, [2 x i64] }, ptr %t10
  store { i64, [2 x i64] } %t11, ptr %l2
  %t13 = load { i64, [2 x i64] }, ptr %l2
  %t15 = extractvalue { i64, [2 x i64] } %t13, 0
  %t16 = icmp eq i64 %t15, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t19 = getelementptr { i64 }, ptr %t18, i32 0, i32 0
  %t20 = load i64, ptr %t19
  store i64 %t20, ptr %l3, !tbaa !24
  br label %bb4
bb3:
  br label %bb16
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t25, i64 %t26)
  store i64 %t29, ptr %l32
  br label %bb5
bb5:
  %t30 = load i64, ptr %l32, !tbaa !24
  store i64 %t30, ptr %l4, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %t34, i64 %t35)
  store ptr %t38, ptr %l36
  br label %bb6
bb6:
  %t39 = load ptr, ptr %l36, !tbaa !29
  store ptr %t39, ptr %l5, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = getelementptr %"compiler/ast:Sig", ptr %t43, i32 0, i32 5
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = icmp eq ptr %t46, null
  br i1 %t48, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s1)
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t51 = load ptr, ptr %l5, !tbaa !29
  %t53 = getelementptr %"compiler/ast:Func", ptr %t51, i32 0, i32 3
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/ast:Sig", ptr %t54, i32 0, i32 5
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = icmp eq ptr %t57, null
  br i1 %t59, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_700945490095e3ab_b793fb317cfa4b47)
  unreachable
bb11:
  br label %bb12
bb12:
  %t61 = load ptr, ptr %l5, !tbaa !29
  %t63 = getelementptr %"compiler/ast:Func", ptr %t61, i32 0, i32 3
  %t64 = load ptr, ptr %t63, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Sig", ptr %t64, i32 0, i32 5
  %t67 = load ptr, ptr %t66, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  %t68 = load ptr, ptr %l5, !tbaa !29
  %t70 = getelementptr %"compiler/ast:Func", ptr %t68, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !29
  store ptr %t71, ptr %l50, !tbaa !29
  %t72 = load ptr, ptr %l5, !tbaa !29
  %t74 = getelementptr %"compiler/ast:Func", ptr %t72, i32 0, i32 3
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/ast:Sig", ptr %t75, i32 0, i32 0
  %t78 = load { i64, ptr }, ptr %t77, !tbaa !27
  store { i64, ptr } %t78, ptr %l53, !tbaa !27
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t83 = load i64, ptr %l4, !tbaa !24
  %t86 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t82, i64 %t83)
  store i64 %t86, ptr %l57
  br label %bb13
bb13:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t88 = load ptr, ptr %l5, !tbaa !29
  %t90 = getelementptr %"compiler/ast:Func", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %t90, !tbaa !23
  %t94 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %t87, i32 %t91)
  store { i64, ptr } %t94, ptr %l61
  br label %bb14
bb14:
  %t95 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 1
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t103 = extractvalue { i64, ptr } %t100, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load ptr, ptr %l48, !tbaa !29
  %t109 = load ptr, ptr %l50, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t111 = load i64, ptr %l57, !tbaa !24
  %t113 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t108, ptr %t109, { i64, ptr } %t110, i64 %t111, { i64, ptr } %t107)
  store %"compiler/check:ctSource" %t113, ptr %l64
  br label %bb15
bb15:
  %t114 = load %"compiler/check:ctSource", ptr %l64
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t114, ptr %t115
  call void @__olang_scope_close(ptr %s1)
  store ptr %t115, ptr %rv
  br label %ret
bb16:
  %t117 = load { i64, [2 x i64] }, ptr %l2
  %t119 = extractvalue { i64, [2 x i64] } %t117, 0
  %t120 = icmp eq i64 %t119, 1
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t123 = getelementptr { i32, i32 }, ptr %t122, i32 0, i32 0
  %t124 = load i32, ptr %t123
  store i32 %t124, ptr %l6, !tbaa !23
  br label %bb19
bb18:
  br label %bb72
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = getelementptr %"compiler/generic:Program", ptr %t129, i32 0, i32 2
  %t132 = load i32, ptr %l6, !tbaa !23
  %t135 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t131, i32 %t132)
  store i32 %t135, ptr %l73
  br label %bb20
bb20:
  %t136 = load i32, ptr %l73, !tbaa !23
  store i32 %t136, ptr %l7, !tbaa !23
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/check:Checker", ptr %t137, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t141 = load i32, ptr %l7, !tbaa !23
  %t144 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t140, i32 %t141)
  store ptr %t144, ptr %l77
  br label %bb21
bb21:
  %t145 = load ptr, ptr %l77, !tbaa !29
  store ptr %t145, ptr %l8, !tbaa !29
  %t146 = load ptr, ptr %l8, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l80, !tbaa !21
  br label %bb24
bb23:
  %t150 = load ptr, ptr %l8, !tbaa !29
  %t152 = getelementptr %"compiler/ast:TypeDecl", ptr %t150, i32 0, i32 3
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = icmp eq ptr %t153, null
  store i1 %t155, ptr %l80, !tbaa !21
  br label %bb24
bb24:
  %t157 = load i1, ptr %l80, !tbaa !21
  br i1 %t157, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = getelementptr %"compiler/check:Checker", ptr %t159, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !29
  %t164 = getelementptr %"compiler/generic:Program", ptr %t162, i32 0, i32 2
  %t165 = load i32, ptr %l7, !tbaa !23
  %t168 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t164, i32 %t165)
  store i64 %t168, ptr %l89
  br label %bb28
bb28:
  %t169 = load i64, ptr %l89, !tbaa !24
  store i64 %t169, ptr %l9, !tbaa !24
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l8, !tbaa !29
  %t173 = getelementptr %"compiler/ast:TypeDecl", ptr %t171, i32 0, i32 0
  %t174 = load i32, ptr %t173, !tbaa !23
  %t177 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s4, ptr %t170, i32 %t174)
  store { i64, ptr } %t177, ptr %l93
  br label %bb29
bb29:
  %t178 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t179, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t184 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t184, ptr %lp10
  %t186 = load ptr, ptr %lp10
  store { i64, ptr } %t183, ptr %t186, !tbaa !27
  %t187 = load ptr, ptr %l8, !tbaa !29
  %t189 = getelementptr %"compiler/ast:TypeDecl", ptr %t187, i32 0, i32 3
  %t190 = load ptr, ptr %t189, !tbaa !29
  store ptr %t190, ptr %l11, !tbaa !29
  %t192 = load ptr, ptr %l11, !tbaa !29
  store ptr %t192, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t193 = load ptr, ptr %l97, !tbaa !29
  %t194 = icmp ne ptr %t193, null
  br i1 %t194, label %bb30, label %bb31
bb30:
  %t196 = load ptr, ptr %l97, !tbaa !29
  %t197 = load i64, ptr %t196, !range !{i64 0, i64 5}
  %t199 = icmp eq i64 %t197, 0
  store i1 %t199, ptr %l98, !tbaa !21
  br label %bb31
bb31:
  %t200 = load i1, ptr %l98, !tbaa !21
  br i1 %t200, label %bb32, label %bb33
bb32:
  %t201 = load ptr, ptr %l11, !tbaa !29
  %t203 = getelementptr { i64, [6 x i64] }, ptr %t201, i32 0, i32 1
  %t204 = getelementptr { ptr }, ptr %t203, i32 0, i32 0
  %t205 = load ptr, ptr %t204
  store ptr %t205, ptr %l12, !tbaa !29
  br label %bb34
bb33:
  br label %bb51
bb34:
  %t207 = load ptr, ptr %l12, !tbaa !29
  %t209 = getelementptr %"compiler/ast:StructBody", ptr %t207, i32 0, i32 1
  %t210 = load ptr, ptr %t209, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  br i1 %t212, label %bb35, label %bb36
bb35:
  store i1 true, ptr %l106, !tbaa !21
  br label %bb40
bb36:
  %t214 = load ptr, ptr %l12, !tbaa !29
  %t216 = getelementptr %"compiler/ast:StructBody", ptr %t214, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t219 = icmp eq ptr %t217, null
  br i1 %t219, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28)
  unreachable
bb38:
  br label %bb39
bb39:
  %t221 = load ptr, ptr %l12, !tbaa !29
  %t223 = getelementptr %"compiler/ast:StructBody", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t227 = getelementptr %"compiler/ast:Sig", ptr %t224, i32 0, i32 5
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = icmp eq ptr %t228, null
  store i1 %t230, ptr %l106, !tbaa !21
  br label %bb40
bb40:
  %t232 = load i1, ptr %l106, !tbaa !21
  br i1 %t232, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t234 = load ptr, ptr %l12, !tbaa !29
  %t236 = getelementptr %"compiler/ast:StructBody", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = icmp eq ptr %t237, null
  br i1 %t239, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb45:
  br label %bb46
bb46:
  %t241 = load ptr, ptr %l12, !tbaa !29
  %t243 = getelementptr %"compiler/ast:StructBody", ptr %t241, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !29
  %t247 = getelementptr %"compiler/ast:Sig", ptr %t244, i32 0, i32 5
  %t248 = load ptr, ptr %t247, !tbaa !29
  store ptr %t248, ptr %l13, !tbaa !29
  %t250 = load ptr, ptr %l13, !tbaa !29
  %t252 = icmp eq ptr %t250, null
  br i1 %t252, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_25ec48d7738ec131_33504a893c084afd)
  unreachable
bb48:
  br label %bb49
bb49:
  %t254 = load ptr, ptr %l13, !tbaa !29
  %t255 = load ptr, ptr %l12, !tbaa !29
  %t257 = getelementptr %"compiler/ast:StructBody", ptr %t255, i32 0, i32 0
  %t258 = load { i64, ptr }, ptr %t257, !tbaa !27
  %t259 = load i64, ptr %l9, !tbaa !24
  %t260 = load ptr, ptr %lp10
  %t261 = load { i64, ptr }, ptr %t260, !tbaa !27
  %t266 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t254, ptr null, { i64, ptr } %t258, i64 %t259, { i64, ptr } %t261)
  store %"compiler/check:ctSource" %t266, ptr %l130
  br label %bb50
bb50:
  %t267 = load %"compiler/check:ctSource", ptr %l130
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t267, ptr %t268
  call void @__olang_scope_close(ptr %s4)
  store ptr %t268, ptr %rv
  br label %ret
bb51:
  %t270 = load ptr, ptr %l11, !tbaa !29
  store ptr %t270, ptr %l132, !tbaa !29
  store i1 false, ptr %l133, !tbaa !21
  %t271 = load ptr, ptr %l132, !tbaa !29
  %t272 = icmp ne ptr %t271, null
  br i1 %t272, label %bb52, label %bb53
bb52:
  %t274 = load ptr, ptr %l132, !tbaa !29
  %t275 = load i64, ptr %t274, !range !{i64 0, i64 5}
  %t277 = icmp eq i64 %t275, 3
  store i1 %t277, ptr %l133, !tbaa !21
  br label %bb53
bb53:
  %t278 = load i1, ptr %l133, !tbaa !21
  br i1 %t278, label %bb54, label %bb55
bb54:
  %t279 = load ptr, ptr %l11, !tbaa !29
  %t281 = getelementptr { i64, [6 x i64] }, ptr %t279, i32 0, i32 1
  %t282 = getelementptr { ptr, ptr }, ptr %t281, i32 0, i32 1
  %t283 = load ptr, ptr %t282
  store ptr %t283, ptr %l14, !tbaa !29
  br label %bb56
bb55:
  br label %bb67
bb56:
  %t285 = load ptr, ptr %l14, !tbaa !29
  %t287 = icmp eq ptr %t285, null
  br i1 %t287, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l140, !tbaa !21
  br label %bb59
bb58:
  %t289 = load ptr, ptr %l14, !tbaa !29
  %t291 = getelementptr %"compiler/ast:Func", ptr %t289, i32 0, i32 3
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/ast:Sig", ptr %t292, i32 0, i32 5
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t297 = icmp eq ptr %t295, null
  store i1 %t297, ptr %l140, !tbaa !21
  br label %bb59
bb59:
  %t299 = load i1, ptr %l140, !tbaa !21
  br i1 %t299, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t301 = load ptr, ptr %l14, !tbaa !29
  %t303 = getelementptr %"compiler/ast:Func", ptr %t301, i32 0, i32 3
  %t304 = load ptr, ptr %t303, !tbaa !29
  %t306 = getelementptr %"compiler/ast:Sig", ptr %t304, i32 0, i32 5
  %t307 = load ptr, ptr %t306, !tbaa !29
  %t309 = icmp eq ptr %t307, null
  br i1 %t309, label %bb63, label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16)
  unreachable
bb64:
  br label %bb65
bb65:
  %t311 = load ptr, ptr %l14, !tbaa !29
  %t313 = getelementptr %"compiler/ast:Func", ptr %t311, i32 0, i32 3
  %t314 = load ptr, ptr %t313, !tbaa !29
  %t316 = getelementptr %"compiler/ast:Sig", ptr %t314, i32 0, i32 5
  %t317 = load ptr, ptr %t316, !tbaa !29
  %t318 = load ptr, ptr %l14, !tbaa !29
  %t320 = getelementptr %"compiler/ast:Func", ptr %t318, i32 0, i32 3
  %t321 = load ptr, ptr %t320, !tbaa !29
  %t323 = getelementptr %"compiler/ast:Sig", ptr %t321, i32 0, i32 0
  %t324 = load { i64, ptr }, ptr %t323, !tbaa !27
  %t325 = load i64, ptr %l9, !tbaa !24
  %t326 = load ptr, ptr %lp10
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !27
  %t332 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v0, ptr %v1, ptr %v1, ptr %t317, ptr null, { i64, ptr } %t324, i64 %t325, { i64, ptr } %t327)
  store %"compiler/check:ctSource" %t332, ptr %l158
  br label %bb66
bb66:
  %t333 = load %"compiler/check:ctSource", ptr %l158
  %t334 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t333, ptr %t334
  call void @__olang_scope_close(ptr %s4)
  store ptr %t334, ptr %rv
  br label %ret
bb67:
  br i1 true, label %bb68, label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb71
bb70:
  call void @__olang_scope_close(ptr %s4)
  store ptr null, ptr %rv
  br label %ret
bb71:
  call void @__olang_check_failed(ptr @olang_loc_34572fc3675c142e_5b9246c98f1fa642)
  unreachable
bb72:
  %t337 = load { i64, [2 x i64] }, ptr %l2
  %t339 = extractvalue { i64, [2 x i64] } %t337, 0
  %t340 = icmp eq i64 %t339, 10
  br i1 %t340, label %bb73, label %bb74
bb73:
  %t342 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t343 = getelementptr { i32, i64 }, ptr %t342, i32 0, i32 0
  %t344 = load i32, ptr %t343
  store i32 %t344, ptr %l15, !tbaa !23
  %t346 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t347 = getelementptr { i32, i64 }, ptr %t346, i32 0, i32 1
  %t348 = load i64, ptr %t347
  store i64 %t348, ptr %l16, !tbaa !24
  br label %bb75
bb74:
  br label %bb101
bb75:
  store %olang.scope zeroinitializer, ptr %s12
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l165, !tbaa !29
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/check:Checker", ptr %t351, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !29
  %t355 = load i32, ptr %l15, !tbaa !23
  %t358 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t354, i32 %t355)
  store { i64, ptr } %t358, ptr %l169
  br label %bb76
bb76:
  %t359 = load { i64, ptr }, ptr %l169, !tbaa !27
  store { i64, ptr } %t359, ptr %l170, !tbaa !27
  %t360 = load i64, ptr %l16, !tbaa !24
  %t362 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr %"compiler/generic:AnySlot", ptr %t363, i64 %t360
  %t365 = load %"compiler/generic:AnySlot", ptr %t364
  %t366 = load ptr, ptr %l165, !tbaa !29
  %t368 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %t366, %"compiler/generic:AnySlot" %t365)
  store ptr %t368, ptr %l173
  br label %bb77
bb77:
  %t369 = load ptr, ptr %l173, !tbaa !29
  store ptr %t369, ptr %l17, !tbaa !29
  %t370 = load ptr, ptr %l17, !tbaa !29
  %t372 = icmp eq ptr %t370, null
  br i1 %t372, label %bb78, label %bb79
bb78:
  store i1 true, ptr %l176, !tbaa !21
  br label %bb80
bb79:
  %t374 = load ptr, ptr %l17, !tbaa !29
  %t376 = getelementptr %"compiler/ast:Func", ptr %t374, i32 0, i32 3
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = getelementptr %"compiler/ast:Sig", ptr %t377, i32 0, i32 5
  %t380 = load ptr, ptr %t379, !tbaa !29
  %t382 = icmp eq ptr %t380, null
  store i1 %t382, ptr %l176, !tbaa !21
  br label %bb80
bb80:
  %t384 = load i1, ptr %l176, !tbaa !21
  br i1 %t384, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s12)
  store ptr null, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = getelementptr %"compiler/check:Checker", ptr %t386, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !29
  %t391 = getelementptr %"compiler/generic:Program", ptr %t389, i32 0, i32 2
  store ptr %t391, ptr %l184, !tbaa !29
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/check:Checker", ptr %t392, i32 0, i32 1
  %t395 = load ptr, ptr %t394, !tbaa !29
  %t396 = load i32, ptr %l15, !tbaa !23
  %t399 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v0, ptr %t395, i32 %t396)
  store { i64, ptr } %t399, ptr %l188
  br label %bb84
bb84:
  %t400 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t400, ptr %l189, !tbaa !27
  %t401 = load i64, ptr %l16, !tbaa !24
  %t403 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr %"compiler/generic:AnySlot", ptr %t404, i64 %t401
  %t406 = getelementptr %"compiler/generic:AnySlot", ptr %t405, i32 0, i32 1
  %t407 = load i32, ptr %t406, !tbaa !23
  %t408 = load ptr, ptr %l184, !tbaa !29
  %t410 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t408, i32 %t407)
  store i32 %t410, ptr %l192
  br label %bb85
bb85:
  %t411 = load i32, ptr %l192, !tbaa !23
  store i32 %t411, ptr %l18, !tbaa !23
  %t412 = load ptr, ptr %l17, !tbaa !29
  %t414 = getelementptr %"compiler/ast:Func", ptr %t412, i32 0, i32 1
  %t415 = load ptr, ptr %t414, !tbaa !29
  store ptr %t415, ptr %l19, !tbaa !29
  %t417 = load ptr, ptr %l19, !tbaa !29
  %t419 = icmp eq ptr %t417, null
  br i1 %t419, label %bb86, label %bb87
bb86:
  %t421 = load ptr, ptr %l17, !tbaa !29
  %t423 = getelementptr %"compiler/ast:Func", ptr %t421, i32 0, i32 0
  %t424 = load %"compiler/source:Span", ptr %t423
  store %"compiler/source:Span" %t424, ptr %l198
  %t425 = load ptr, ptr %l17, !tbaa !29
  %t427 = getelementptr %"compiler/ast:Func", ptr %t425, i32 0, i32 0
  %t428 = load %"compiler/source:Span", ptr %t427
  store { i64, [5 x i64] } zeroinitializer, ptr %t429
  %t430 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 0
  store i64 4, ptr %t430
  %t432 = insertvalue { %"compiler/source:Span", ptr, i1 } undef, %"compiler/source:Span" %t428, 0
  %t433 = insertvalue { %"compiler/source:Span", ptr, i1 } %t432, ptr null, 1
  %t434 = insertvalue { %"compiler/source:Span", ptr, i1 } %t433, i1 false, 2
  %t435 = getelementptr { i64, [5 x i64] }, ptr %t429, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1 } %t434, ptr %t435
  %t436 = load { i64, [5 x i64] }, ptr %t429
  %t438 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t436, ptr %t438
  store ptr %t438, ptr %l202, !tbaa !29
  %t439 = icmp sge i64 0, 0
  br i1 %t439, label %bb88, label %bb89
bb87:
  br label %bb93
bb88:
  %t441 = icmp sle i64 0, 1152921504606846975
  br i1 %t441, label %bb90, label %bb91
bb89:
  call void @__olang_check_failed(ptr @olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac)
  unreachable
bb90:
  %t443 = mul i64 0, 8
  %t444 = insertvalue { i64, ptr } undef, i64 0, 0
  %t445 = insertvalue { i64, ptr } %t444, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t446 = load %"compiler/source:Span", ptr %l198
  %t447 = load ptr, ptr %l202, !tbaa !29
  %t449 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t446, i32 0, ptr %t447, ptr null, { i64, ptr } %t445)
  store %"compiler/ast:Param" %t449, ptr %l206
  br label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac)
  unreachable
bb92:
  %t450 = load %"compiler/ast:Param", ptr %l206
  %t451 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store %"compiler/ast:Param" %t450, ptr %t451
  store ptr %t451, ptr %l19, !tbaa !29
  br label %bb93
bb93:
  %t453 = load ptr, ptr %l17, !tbaa !29
  %t455 = getelementptr %"compiler/ast:Func", ptr %t453, i32 0, i32 3
  %t456 = load ptr, ptr %t455, !tbaa !29
  %t458 = getelementptr %"compiler/ast:Sig", ptr %t456, i32 0, i32 5
  %t459 = load ptr, ptr %t458, !tbaa !29
  %t461 = icmp eq ptr %t459, null
  br i1 %t461, label %bb94, label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_a90b29f72ec4d10d_507af4b2e3250de1)
  unreachable
bb95:
  br label %bb96
bb96:
  %t463 = load ptr, ptr %l17, !tbaa !29
  %t465 = getelementptr %"compiler/ast:Func", ptr %t463, i32 0, i32 3
  %t466 = load ptr, ptr %t465, !tbaa !29
  %t468 = getelementptr %"compiler/ast:Sig", ptr %t466, i32 0, i32 5
  %t469 = load ptr, ptr %t468, !tbaa !29
  store ptr %t469, ptr %l214, !tbaa !29
  %t470 = load ptr, ptr %l19, !tbaa !29
  store ptr %t470, ptr %l215, !tbaa !29
  %t471 = load ptr, ptr %l17, !tbaa !29
  %t473 = getelementptr %"compiler/ast:Func", ptr %t471, i32 0, i32 3
  %t474 = load ptr, ptr %t473, !tbaa !29
  %t476 = getelementptr %"compiler/ast:Sig", ptr %t474, i32 0, i32 0
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !27
  store { i64, ptr } %t477, ptr %l218, !tbaa !27
  %t478 = load ptr, ptr %l0, !tbaa !29
  %t480 = getelementptr %"compiler/check:Checker", ptr %t478, i32 0, i32 1
  %t481 = load ptr, ptr %t480, !tbaa !29
  %t483 = getelementptr %"compiler/generic:Program", ptr %t481, i32 0, i32 2
  %t484 = load i32, ptr %l18, !tbaa !23
  %t487 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t483, i32 %t484)
  store i64 %t487, ptr %l223
  br label %bb97
bb97:
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load i32, ptr %l15, !tbaa !23
  %t492 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s12, ptr %t488, i32 %t489)
  store { i64, ptr } %t492, ptr %l226
  br label %bb98
bb98:
  %t493 = load ptr, ptr %l0, !tbaa !29
  %t494 = load ptr, ptr %l17, !tbaa !29
  %t496 = getelementptr %"compiler/ast:Func", ptr %t494, i32 0, i32 2
  %t497 = load i32, ptr %t496, !tbaa !23
  %t500 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s12, ptr %t493, i32 %t497)
  store { i64, ptr } %t500, ptr %l230
  br label %bb99
bb99:
  %t501 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t502 = extractvalue { i64, ptr } %t501, 1
  %t503 = extractvalue { i64, ptr } %t501, 0
  %t504 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 1
  %t505 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d7, i32 0, i32 1) }, 0
  %t506 = add i64 %t503, %t505
  %t507 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t508 = extractvalue { i64, ptr } %t507, 1
  %t509 = extractvalue { i64, ptr } %t507, 0
  %t510 = add i64 %t506, %t509
  %t511 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t510)
  call void @olang_textcopy(ptr %t511, ptr %t502, i64 %t503)
  %t512 = getelementptr i8, ptr %t511, i64 %t503
  call void @olang_textcopy(ptr %t512, ptr %t504, i64 %t505)
  %t513 = getelementptr i8, ptr %t512, i64 %t505
  call void @olang_textcopy(ptr %t513, ptr %t508, i64 %t509)
  %t514 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t515 = insertvalue { i64, ptr } %t514, ptr %t511, 1
  %t517 = extractvalue { i64, ptr } %t515, 0
  %t518 = extractvalue { i64, ptr } %t515, 1
  %t519 = mul i64 %t517, 1
  %t520 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t519)
  call void @llvm.memcpy.p0.p0.i64(ptr %t520, ptr %t518, i64 %t519, i1 false)
  %t521 = insertvalue { i64, ptr } undef, i64 %t517, 0
  %t522 = insertvalue { i64, ptr } %t521, ptr %t520, 1
  %t523 = load ptr, ptr %l214, !tbaa !29
  %t524 = load ptr, ptr %l215, !tbaa !29
  %t525 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t526 = load i64, ptr %l223, !tbaa !24
  %t528 = call %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t523, ptr %t524, { i64, ptr } %t525, i64 %t526, { i64, ptr } %t522)
  store %"compiler/check:ctSource" %t528, ptr %l233
  br label %bb100
bb100:
  %t529 = load %"compiler/check:ctSource", ptr %l233
  %t530 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 56, i64 8)
  store %"compiler/check:ctSource" %t529, ptr %t530
  call void @__olang_scope_close(ptr %s12)
  store ptr %t530, ptr %rv
  br label %ret
bb101:
  br i1 true, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  store ptr null, ptr %rv
  br label %ret
bb105:
  call void @__olang_check_failed(ptr @olang_loc_8dac41fcc89db5e5_6cee581458fc6b9)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l4 = alloca i64
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 0)
  store i64 %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load i64, ptr %l4, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorCall(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i32
  %l7 = alloca i1
  %l8 = alloca ptr
  %l9 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/typed:Call", ptr %a1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load ptr, ptr %l2, !tbaa !29
  store ptr %t6, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t7 = load ptr, ptr %l8, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 5}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l9, !tbaa !21
  br label %bb2
bb2:
  %t14 = load i1, ptr %l9, !tbaa !21
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { i32 }, ptr %t17, i32 0, i32 0
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb16
bb5:
  %t23 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 14
  %t24 = load i32, ptr %l3, !tbaa !23
  %t26 = sext i32 %t24 to i64
  %t29 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t23, i64 %t26)
  store ptr %t29, ptr %l18
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/typed:Body", ptr %t30, i32 0, i32 1
  %t33 = load { i64, [2 x i64] }, ptr %t32
  %t37 = extractvalue { i64, [2 x i64] } %t33, 0
  %t38 = icmp eq i64 %t37, 1
  br i1 %t38, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb15
bb10:
  br i1 true, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_8d3e5410ed2a27a9_4efdc57dac874585)
  unreachable
bb15:
  %t40 = load i1, ptr %l21, !tbaa !21
  store i1 %t40, ptr %l7, !tbaa !21
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_1dfbc037cdd154d8_cf42e6f659c8aed4)
  unreachable
bb21:
  %t41 = load i1, ptr %l7, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eelemsWritten(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i1
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca i1
  %l21 = alloca i32
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l2, !tbaa !29
  %t20 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %t16, ptr %t17)
  store i32 %t20, ptr %l12
  br label %bb6
bb6:
  %t21 = load i32, ptr %l12, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
bb7:
  %t22 = load ptr, ptr %l1, !tbaa !29
  store ptr %t22, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t23 = load ptr, ptr %l13, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l13, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 15
  store i1 %t29, ptr %l14, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l14, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l3, !tbaa !29
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t41 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t37, ptr %t38)
  store i32 %t41, ptr %l21
  br label %bb13
bb13:
  %t42 = load i32, ptr %l21, !tbaa !23
  store i32 %t42, ptr %rv
  br label %ret
bb14:
  br i1 true, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb18
bb17:
  store i32 -1, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_ca8c7340acce938e_766edb65a28506b2)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrCompareItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l17 = alloca i32
  %l24 = alloca ptr
  %l29 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca ptr
  %l36 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca %"compiler/diagmsg:Msg"
  %l47 = alloca i64
  %l51 = alloca ptr
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i32
  %l58 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l73 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l75 = alloca i64
  %l77 = alloca ptr
  %l79 = alloca %"compiler/source:Span"
  %l80 = alloca ptr
  %l82 = alloca %"compiler/source:Span"
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca %"compiler/diagmsg:Msg"
  %l95 = alloca i64
  %l99 = alloca ptr
  %l102 = alloca i64
  %l105 = alloca ptr
  %l110 = alloca ptr
  %l113 = alloca ptr
  %l117 = alloca ptr
  %l124 = alloca ptr
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t5 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrSubjectOf(ptr %v0, ptr %v1, ptr %v3, ptr %t1, ptr %t2)
  store ptr %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l14, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load ptr, ptr %l5, !tbaa !29
  %t10 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t7)
  store i32 %t10, ptr %l17
  br label %bb2
bb2:
  %t11 = load i32, ptr %l17, !tbaa !23
  store i32 %t11, ptr %l6, !tbaa !23
  %t12 = load i32, ptr %l6, !tbaa !23
  %t13 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t16 = icmp eq i32 %t12, %t13
  br i1 %t16, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load %"compiler/source:Span", ptr %l1
  %t20 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t24 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t18, %"compiler/source:Span" %t19, i32 %t20, i64 0)
  store ptr %t24, ptr %l24
  br label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load ptr, ptr %l24, !tbaa !29
  store ptr %t25, ptr %rv
  br label %ret
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %l6, !tbaa !23
  %t35 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l29
  br label %bb7
bb7:
  %t36 = load i1, ptr %l29, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l31, !tbaa !29
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t40)
  store %"compiler/source:Span" %t42, ptr %l33
  br label %bb10
bb9:
  br label %bb19
bb10:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l34, !tbaa !29
  %t44 = load ptr, ptr %l3, !tbaa !29
  %t46 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t44)
  store %"compiler/source:Span" %t46, ptr %l36
  br label %bb11
bb11:
  %t47 = load ptr, ptr %l34, !tbaa !29
  %t48 = load %"compiler/source:Span", ptr %l36
  %t49 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t47, %"compiler/source:Span" %t48)
  store { i64, ptr } %t49, ptr %l37
  br label %bb12
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load i32, ptr %l6, !tbaa !23
  %t54 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s2, ptr %t50, i32 %t51)
  store { i64, ptr } %t54, ptr %l40
  br label %bb13
bb13:
  %t55 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = mul i64 %t56, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t58)
  call void @llvm.memcpy.p0.p0.i64(ptr %t59, ptr %t57, i64 %t58, i1 false)
  %t60 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l41, !tbaa !27
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l42, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t63)
  store %"compiler/source:Span" %t65, ptr %l44
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l42, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l44
  %t68 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t66, %"compiler/source:Span" %t67)
  store { i64, ptr } %t68, ptr %l45
  br label %bb15
bb15:
  %t69 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t72 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrComparedNotError(ptr %v0, ptr %s2, ptr %v0, ptr %s2, { i64, ptr } %t69, { i64, ptr } %t70, { i64, ptr } %t71)
  store %"compiler/diagmsg:Msg" %t72, ptr %l46
  br label %bb16
bb16:
  %t73 = load ptr, ptr %l31, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l33
  %t75 = load %"compiler/diagmsg:Msg", ptr %l46
  %t76 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t73, %"compiler/source:Span" %t74, %"compiler/diagmsg:Msg" %t75)
  store i64 %t76, ptr %l47
  br label %bb17
bb17:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load %"compiler/source:Span", ptr %l1
  %t79 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t83 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t77, %"compiler/source:Span" %t78, i32 %t79, i64 0)
  store ptr %t83, ptr %l51
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t84 = load ptr, ptr %l51, !tbaa !29
  store ptr %t84, ptr %rv
  br label %ret
bb19:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t86 = load ptr, ptr %l4, !tbaa !29
  %t89 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecaughtItems(ptr %v0, ptr %v2, ptr %s0, ptr %t85, ptr %t86)
  %t90 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t89, 1
  %t91 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t89, 0
  store i32 %t91, ptr %l56
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb21, label %ok.93, !prof !99
ok.93:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t90, ptr %l55
  br label %bb20
bb20:
  %t94 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l55
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t94, ptr %l52
  br label %bb24
bb21:
  %t95 = load i32, ptr %l56, !tbaa !23
  %t96 = ashr i32 %t95, 16
  %t98 = icmp eq i32 %t96, 1
  store i1 %t98, ptr %l58, !tbaa !21
  br label %bb22
bb22:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l1
  %t101 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t105 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t99, %"compiler/source:Span" %t100, i32 %t101, i64 0)
  store ptr %t105, ptr %l62
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t106 = load ptr, ptr %l62, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
bb24:
  %t107 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t107, ptr %l7
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l63, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l6, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l68
  br label %bb25
bb25:
  %t119 = load ptr, ptr %l63, !tbaa !29
  %t120 = load i32, ptr %l68, !tbaa !23
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %s0, ptr %t119, i32 %t120)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l69
  br label %bb26
bb26:
  %t122 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l69
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %l8
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t127 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t123, ptr %l8, ptr %l7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t127, ptr %l73
  br label %bb27
bb27:
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %s0, ptr %l73)
  store i64 %t129, ptr %l75
  br label %bb28
bb28:
  %t130 = load i64, ptr %l75, !tbaa !24
  %t131 = icmp eq i64 %t130, 0
  br i1 %t131, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s4
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l77, !tbaa !29
  %t134 = load ptr, ptr %l4, !tbaa !29
  %t136 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t134)
  store %"compiler/source:Span" %t136, ptr %l79
  br label %bb31
bb30:
  br label %bb39
bb31:
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l80, !tbaa !29
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t138)
  store %"compiler/source:Span" %t140, ptr %l82
  br label %bb32
bb32:
  %t141 = load ptr, ptr %l80, !tbaa !29
  %t142 = load %"compiler/source:Span", ptr %l82
  %t143 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s4, ptr %t141, %"compiler/source:Span" %t142)
  store { i64, ptr } %t143, ptr %l83
  br label %bb33
bb33:
  %t144 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t146 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  %t149 = add i64 %t145, %t148
  %t150 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t151 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t152 = add i64 %t149, %t151
  %t153 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t152)
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = getelementptr i8, ptr %t154, i64 %t148
  call void @olang_textcopy(ptr %t155, ptr %t150, i64 %t151)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t153, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = mul i64 %t159, 1
  %t162 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t161)
  call void @llvm.memcpy.p0.p0.i64(ptr %t162, ptr %t160, i64 %t161, i1 false)
  %t163 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t162, 1
  store { i64, ptr } %t164, ptr %l85, !tbaa !27
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t168 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s4, ptr %t165, ptr %l7)
  store { i64, ptr } %t168, ptr %l88
  br label %bb34
bb34:
  %t169 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  %t171 = extractvalue { i64, ptr } %t169, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  store { i64, ptr } %t175, ptr %l89, !tbaa !27
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t179 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %s0, ptr %s4, ptr %t176, ptr %l8)
  store { i64, ptr } %t179, ptr %l92
  br label %bb35
bb35:
  %t180 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  %t182 = extractvalue { i64, ptr } %t180, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t187 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t190 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %s4, ptr %s4, ptr %s4, ptr %s4, { i64, ptr } %t187, { i64, ptr } %t188, { i64, ptr } %t186)
  store %"compiler/diagmsg:Msg" %t190, ptr %l94
  br label %bb36
bb36:
  %t191 = load ptr, ptr %l77, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l79
  %t193 = load %"compiler/diagmsg:Msg", ptr %l94
  %t194 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t191, %"compiler/source:Span" %t192, %"compiler/diagmsg:Msg" %t193)
  store i64 %t194, ptr %l95
  br label %bb37
bb37:
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load %"compiler/source:Span", ptr %l1
  %t197 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t201 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t195, %"compiler/source:Span" %t196, i32 %t197, i64 0)
  store ptr %t201, ptr %l99
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t202 = load ptr, ptr %l99, !tbaa !29
  store ptr %t202, ptr %rv
  br label %ret
bb39:
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 37
  %t207 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t205)
  store i64 %t207, ptr %l102
  br label %bb40
bb40:
  %t208 = load i64, ptr %l102, !tbaa !24
  store i64 %t208, ptr %l9, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load ptr, ptr %l5, !tbaa !29
  %t213 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrHeld(ptr %v0, ptr %v3, ptr %v3, ptr %t209, ptr %t210)
  store ptr %t213, ptr %l105
  br label %bb41
bb41:
  %t214 = load ptr, ptr %l105, !tbaa !29
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load %"compiler/source:Span", ptr %l1
  %t222 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrTest(ptr %v0, ptr %v3, ptr %s0, ptr %v3, ptr %t215, %"compiler/source:Span" %t216, ptr %t214, ptr %l7)
  store ptr %t222, ptr %l110
  br label %bb42
bb42:
  %t223 = load ptr, ptr %l110, !tbaa !29
  store ptr %t223, ptr %l11, !tbaa !29
  %t226 = trunc i64 79 to i32
  %t227 = icmp eq i32 %a2, %t226
  br i1 %t227, label %bb43, label %bb44
bb43:
  %t229 = load ptr, ptr %l0, !tbaa !29
  %t230 = load %"compiler/source:Span", ptr %l1
  %t231 = load ptr, ptr %l11, !tbaa !29
  %t235 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t229, %"compiler/source:Span" %t230, ptr %t231)
  store ptr %t235, ptr %l117
  br label %bb45
bb44:
  %t236 = load ptr, ptr %l11, !tbaa !29
  store ptr %t236, ptr %l113, !tbaa !29
  br label %bb46
bb45:
  %t238 = load ptr, ptr %l117, !tbaa !29
  store ptr %t238, ptr %l113, !tbaa !29
  br label %bb46
bb46:
  %t239 = load ptr, ptr %l113, !tbaa !29
  store ptr %t239, ptr %l11, !tbaa !29
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t241 = load %"compiler/source:Span", ptr %l1
  %t242 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t243 = load i64, ptr %l9, !tbaa !24
  %t244 = load ptr, ptr %l11, !tbaa !29
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v3, ptr %v3, ptr %t240, %"compiler/source:Span" %t241, i32 %t242, i64 %t243, ptr %t244)
  store ptr %t250, ptr %l124
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s0)
  %t251 = load ptr, ptr %l124, !tbaa !29
  store ptr %t251, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l14 = alloca i32
  %l25 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca i1
  %l59 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/ast:Match", ptr %t2, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i32 %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load i32, ptr %l14, !tbaa !23
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr %"compiler/ast:Match", ptr %t13, i32 0, i32 3
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t22 = load i64, ptr %l3, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp slt i64 %t22, %t23
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb39
bb7:
  br label %bb8
bb8:
  %t30 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t30, ptr %l25, !tbaa !27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr ptr, ptr %t34, i64 %t31
  %t36 = load ptr, ptr %t35, !tbaa !39
  %t40 = getelementptr %"compiler/ast:Case", ptr %t36, i32 0, i32 1
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  store { i64, ptr } %t41, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb10, label %bb11
bb10:
  br label %bb37
bb11:
  br label %bb12
bb12:
  %t55 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t55, ptr %l36, !tbaa !27
  %t56 = load i64, ptr %l7, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr ptr, ptr %t59, i64 %t56
  %t61 = load ptr, ptr %t60, !tbaa !39
  store ptr %t61, ptr %l9, !tbaa !29
  %t63 = load ptr, ptr %l9, !tbaa !29
  store ptr %t63, ptr %l39, !tbaa !29
  store i1 false, ptr %l40, !tbaa !21
  %t64 = load ptr, ptr %l39, !tbaa !29
  %t65 = icmp ne ptr %t64, null
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load ptr, ptr %l39, !tbaa !29
  %t68 = load i64, ptr %t67, !range !{i64 0, i64 9}
  %t70 = icmp eq i64 %t68, 1
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb14
bb14:
  %t71 = load i1, ptr %l40, !tbaa !21
  br i1 %t71, label %bb15, label %bb16
bb15:
  %t72 = load ptr, ptr %l9, !tbaa !29
  %t74 = getelementptr { i64, [4 x i64] }, ptr %t72, i32 0, i32 1
  %t75 = getelementptr { %"compiler/source:Span", ptr }, ptr %t74, i32 0, i32 1
  %t76 = load ptr, ptr %t75
  store ptr %t76, ptr %l10, !tbaa !29
  br label %bb25
bb16:
  %t78 = load ptr, ptr %l9, !tbaa !29
  store ptr %t78, ptr %l45, !tbaa !29
  store i1 false, ptr %l46, !tbaa !21
  %t79 = load ptr, ptr %l45, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb17, label %bb18
bb17:
  %t82 = load ptr, ptr %l45, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 9}
  %t85 = icmp eq i64 %t83, 4
  store i1 %t85, ptr %l46, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l46, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr }, ptr %t89, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l10, !tbaa !29
  br label %bb25
bb20:
  %t93 = load ptr, ptr %l9, !tbaa !29
  store ptr %t93, ptr %l51, !tbaa !29
  store i1 false, ptr %l52, !tbaa !21
  %t94 = load ptr, ptr %l51, !tbaa !29
  %t95 = icmp ne ptr %t94, null
  br i1 %t95, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l51, !tbaa !29
  %t98 = load i64, ptr %t97, !range !{i64 0, i64 9}
  %t100 = icmp eq i64 %t98, 2
  store i1 %t100, ptr %l52, !tbaa !21
  br label %bb22
bb22:
  %t101 = load i1, ptr %l52, !tbaa !21
  br i1 %t101, label %bb23, label %bb24
bb23:
  %t102 = load ptr, ptr %l9, !tbaa !29
  %t104 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  %t105 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t104, i32 0, i32 1
  %t106 = load ptr, ptr %t105
  store ptr %t106, ptr %l10, !tbaa !29
  br label %bb25
bb24:
  br label %bb30
bb25:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l10, !tbaa !29
  %t112 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %t108, ptr %t109)
  store i1 %t112, ptr %l59
  br label %bb26
bb26:
  %t113 = load i1, ptr %l59, !tbaa !21
  br i1 %t113, label %bb27, label %bb28
bb27:
  store i1 true, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb35
bb30:
  br i1 true, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_91bbe37ca794b073_cd30040e8f82c287)
  unreachable
bb35:
  br label %bb36
bb36:
  %t115 = load i64, ptr %l7, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l7, !tbaa !24
  br label %bb9
bb37:
  br label %bb38
bb38:
  %t119 = load i64, ptr %l3, !tbaa !24
  %t121 = add i64 %t119, 1
  store i64 %t121, ptr %l3, !tbaa !24
  br label %bb5
bb39:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrWordPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l8 = alloca i1
  %l10 = alloca ptr
  %l12 = alloca ptr
  %l16 = alloca i32
  %l19 = alloca i1
  %l22 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2eexprPath(ptr %v1, ptr %s0, ptr %t1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t15)
  store ptr %t17, ptr %l12
  br label %bb4
bb3:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb6
bb4:
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t18, i32 0, i32 4
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load ptr, ptr %l10, !tbaa !29
  %t25 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v0, ptr %s0, ptr %t22, ptr %t20, ptr %t21)
  store i32 %t25, ptr %l16
  br label %bb5
bb5:
  %t26 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t27 = load i32, ptr %l16, !tbaa !23
  %t29 = icmp eq i32 %t27, %t26
  store i1 %t29, ptr %l8, !tbaa !21
  br label %bb6
bb6:
  %t31 = load i1, ptr %l8, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l1, !tbaa !29
  %t36 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %t32, ptr %t33)
  store i1 %t36, ptr %l22
  br label %bb9
bb8:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb10
bb9:
  %t37 = load i1, ptr %l22, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i1, ptr %l19, !tbaa !21
  store i1 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorMethod(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l14 = alloca ptr
  %l18 = alloca i32
  %l21 = alloca ptr
  %l24 = alloca %"compiler/source:Span"
  %l27 = alloca { i64, ptr }
  %l29 = alloca %"compiler/diagmsg:Msg"
  %l30 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i64
  %l45 = alloca i64
  %l46 = alloca ptr
  %l49 = alloca %"compiler/source:Span"
  %l55 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l65 = alloca ptr
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l74 = alloca %"compiler/diagmsg:Msg"
  %l75 = alloca i64
  %l89 = alloca i1
  %l90 = alloca ptr
  %l93 = alloca %"compiler/source:Span"
  %l96 = alloca { i64, ptr }
  %l99 = alloca %"compiler/diagmsg:Msg"
  %l100 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t5 = load i64, ptr %l1, !tbaa !24
  %t8 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t4, i64 %t5)
  store ptr %t8, ptr %l14
  br label %bb1
bb1:
  %t9 = load ptr, ptr %l14, !tbaa !29
  store ptr %t9, ptr %l4, !tbaa !29
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrDeclOf(ptr %v0, ptr %t13, i32 %t14)
  store i32 %t17, ptr %l18
  br label %bb2
bb2:
  %t18 = load i32, ptr %l18, !tbaa !23
  store i32 %t18, ptr %l5, !tbaa !23
  %t19 = load i32, ptr %l5, !tbaa !23
  %t21 = icmp slt i32 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l21, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t28 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t24, ptr %t25)
  store %"compiler/source:Span" %t28, ptr %l24
  br label %bb5
bb4:
  br label %bb9
bb5:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l27
  br label %bb6
bb6:
  %t34 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  %t42 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnBuiltinType(ptr %s1, ptr %s1, { i64, ptr } %t40)
  store %"compiler/diagmsg:Msg" %t42, ptr %l29
  br label %bb7
bb7:
  %t43 = load ptr, ptr %l21, !tbaa !29
  %t44 = load %"compiler/source:Span", ptr %l24
  %t45 = load %"compiler/diagmsg:Msg", ptr %l29
  %t46 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t43, %"compiler/source:Span" %t44, %"compiler/diagmsg:Msg" %t45)
  store i64 %t46, ptr %l30
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb9:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 2
  %t53 = load i32, ptr %l5, !tbaa !23
  %t56 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t52, i32 %t53)
  store i64 %t56, ptr %l35
  br label %bb10
bb10:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l1, !tbaa !24
  %t64 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t60, i64 %t61)
  store i64 %t64, ptr %l39
  br label %bb11
bb11:
  %t65 = load i64, ptr %l35, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = icmp ne i64 %t65, %t66
  br i1 %t67, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l5, !tbaa !23
  %t78 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %t74, i32 %t75)
  store i64 %t78, ptr %l45
  br label %bb14
bb13:
  br label %bb22
bb14:
  %t79 = load i64, ptr %l45, !tbaa !24
  store i64 %t79, ptr %l6, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l46, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load ptr, ptr %l4, !tbaa !29
  %t85 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t81, ptr %t82)
  store %"compiler/source:Span" %t85, ptr %l49
  br label %bb15
bb15:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = getelementptr %"compiler/generic:Program", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/load:Loader", ptr %t92, i32 0, i32 10
  %t95 = load i64, ptr %l6, !tbaa !24
  %t98 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t94, i64 %t95)
  store ptr %t98, ptr %l55
  br label %bb16
bb16:
  %t99 = load ptr, ptr %l55, !tbaa !29
  %t101 = getelementptr %"compiler/load:Module", ptr %t99, i32 0, i32 2
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l6, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/check:Checker", ptr %t104, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = getelementptr %"compiler/generic:Program", ptr %t107, i32 0, i32 0
  %t110 = load ptr, ptr %t109, !tbaa !29
  %t112 = getelementptr %"compiler/load:Loader", ptr %t110, i32 0, i32 12
  %t113 = load i64, ptr %t112, !tbaa !24
  %t116 = icmp eq i64 %t103, %t113
  %t119 = call { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %s2, { i64, ptr } %t102, i1 %t116)
  store { i64, ptr } %t119, ptr %l64
  br label %bb17
bb17:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l65, !tbaa !29
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !29
  %t126 = getelementptr %"compiler/generic:Program", ptr %t124, i32 0, i32 2
  %t127 = load i32, ptr %l5, !tbaa !23
  %t130 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %t126, i32 %t127)
  store i32 %t130, ptr %l70
  br label %bb18
bb18:
  %t131 = load ptr, ptr %l65, !tbaa !29
  %t132 = load i32, ptr %l70, !tbaa !23
  %t133 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s2, ptr %t131, i32 %t132)
  store { i64, ptr } %t133, ptr %l71
  br label %bb19
bb19:
  %t134 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 1
  %t139 = extractvalue { i64, ptr } %t137, 0
  %t140 = add i64 %t136, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t135, i64 %t136)
  %t142 = getelementptr i8, ptr %t141, i64 %t136
  call void @olang_textcopy(ptr %t142, ptr %t138, i64 %t139)
  %t143 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t141, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnForeignType(ptr %s2, ptr %s2, { i64, ptr } %t151)
  store %"compiler/diagmsg:Msg" %t153, ptr %l74
  br label %bb20
bb20:
  %t154 = load ptr, ptr %l46, !tbaa !29
  %t155 = load %"compiler/source:Span", ptr %l49
  %t156 = load %"compiler/diagmsg:Msg", ptr %l74
  %t157 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s2, ptr %t154, %"compiler/source:Span" %t155, %"compiler/diagmsg:Msg" %t156)
  store i64 %t157, ptr %l75
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s2)
  br label %ret
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t158 = insertvalue [8 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t159 = insertvalue [8 x { i64, ptr }] %t158, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, 1
  %t160 = insertvalue [8 x { i64, ptr }] %t159, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d11, i32 0, i32 1) }, 2
  %t161 = insertvalue [8 x { i64, ptr }] %t160, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, 3
  %t162 = insertvalue [8 x { i64, ptr }] %t161, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d13, i32 0, i32 1) }, 4
  %t163 = insertvalue [8 x { i64, ptr }] %t162, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d14, i32 0, i32 1) }, 5
  %t164 = insertvalue [8 x { i64, ptr }] %t163, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, 6
  %t165 = insertvalue [8 x { i64, ptr }] %t164, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, 7
  %t167 = call ptr @__olang_scope_alloc_a(ptr %s4, i64 128, i64 8)
  store [8 x { i64, ptr }] %t165, ptr %t167
  store ptr %t167, ptr %l7
  store i64 0, ptr %l8, !tbaa !24
  %t169 = load ptr, ptr %l7
  store i64 8, ptr %l9, !tbaa !24
  br label %bb23
bb23:
  %t172 = load i64, ptr %l8, !tbaa !24
  %t173 = load i64, ptr %l9, !tbaa !24
  %t176 = icmp slt i64 %t172, %t173
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb24, label %bb25
bb24:
  br label %bb36
bb25:
  br label %bb26
bb26:
  %t180 = load ptr, ptr %l7
  %t181 = load i64, ptr %l8, !tbaa !24
  %t184 = getelementptr [8 x { i64, ptr }], ptr %t180, i64 0, i64 %t181
  %t185 = load { i64, ptr }, ptr %t184, !tbaa !37
  %t188 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t189 = load ptr, ptr @__olang_prog_scope
  %t192 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t189, ptr %v1, { i64, ptr } %t185, { i64, ptr } %t188)
  store i1 %t192, ptr %l89
  br label %bb27
bb27:
  %t193 = load i1, ptr %l89, !tbaa !21
  br i1 %t193, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t194 = load ptr, ptr %l0, !tbaa !29
  store ptr %t194, ptr %l90, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t196 = load ptr, ptr %l4, !tbaa !29
  %t199 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v0, ptr %t195, ptr %t196)
  store %"compiler/source:Span" %t199, ptr %l93
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load i32, ptr %l2, !tbaa !23
  %t204 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s6, ptr %t200, i32 %t201)
  store { i64, ptr } %t204, ptr %l96
  br label %bb31
bb31:
  %t205 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 0
  %t207 = extractvalue { i64, ptr } %t205, 1
  %t208 = mul i64 %t206, 1
  %t209 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t208)
  call void @llvm.memcpy.p0.p0.i64(ptr %t209, ptr %t207, i64 %t208, i1 false)
  %t210 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t209, 1
  %t212 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t215 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorMethodGiven(ptr %s6, ptr %v1, ptr %s6, { i64, ptr } %t211, { i64, ptr } %t212)
  store %"compiler/diagmsg:Msg" %t215, ptr %l99
  br label %bb32
bb32:
  %t216 = load ptr, ptr %l90, !tbaa !29
  %t217 = load %"compiler/source:Span", ptr %l93
  %t218 = load %"compiler/diagmsg:Msg", ptr %l99
  %t219 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t216, %"compiler/source:Span" %t217, %"compiler/diagmsg:Msg" %t218)
  store i64 %t219, ptr %l100
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s6)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t220 = load i64, ptr %l8, !tbaa !24
  %t222 = add i64 %t220, 1
  store i64 %t222, ptr %l8, !tbaa !24
  br label %bb23
bb36:
  call void @__olang_scope_close(ptr %s4)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexhaustedOrBreak(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %lp8 = alloca ptr
  %l11 = alloca i32
  %l14 = alloca i64
  %l25 = alloca ptr
  %l29 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca %"compiler/typed:Block"
  %l35 = alloca %"compiler/typed:Item"
  %l37 = alloca %"compiler/typed:Item"
  %l41 = alloca { i64, ptr }
  %l43 = alloca %"compiler/typed:Item"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca { i64, ptr }
  %l46 = alloca ptr
  %l50 = alloca %"compiler/typed:Clause"
  %l53 = alloca %"compiler/source:Span"
  %l56 = alloca i32
  %l61 = alloca %"compiler/typed:Try"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t22 = alloca { i64, [3 x i64] }, align 8
  %t70 = alloca i64
  %t127 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d17, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) })
  store i32 %t6, ptr %l11
  br label %bb1
bb1:
  %t7 = load i32, ptr %l11, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 37
  %t12 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t10)
  store i64 %t12, ptr %l14
  br label %bb2
bb2:
  %t13 = load i64, ptr %l14, !tbaa !24
  store i64 %t13, ptr %l5, !tbaa !24
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/check:Checker", ptr %t14, i32 0, i32 37
  %t17 = load %"compiler/source:Span", ptr %l1
  %t20 = trunc i64 %a3 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t22
  %t23 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 0
  store i64 5, ptr %t23
  %t25 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t17, 0
  %t27 = insertvalue { %"compiler/source:Span", i32, i32 } %t25, i32 0, 1
  %t29 = insertvalue { %"compiler/source:Span", i32, i32 } %t27, i32 %t20, 2
  %t30 = getelementptr { i64, [3 x i64] }, ptr %t22, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t29, ptr %t30
  %t31 = load { i64, [3 x i64] }, ptr %t22
  %t33 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t31, ptr %t33
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t16, ptr %t33)
  br label %bb3
bb3:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t36)
  store ptr %t38, ptr %l25
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l25, !tbaa !29
  %t41 = getelementptr %"compiler/check:frame", ptr %t39, i32 0, i32 7
  %t42 = load i64, ptr %t41, !tbaa !24
  %t44 = trunc i64 %t42 to i32
  store i32 %t44, ptr %l29, !tbaa !23
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 37
  %t49 = load i64, ptr %l5, !tbaa !24
  %t52 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store { i64, ptr } %t52, ptr %l33
  br label %bb5
bb5:
  %t53 = load i32, ptr %l29, !tbaa !23
  %t54 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t55 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 %t53, { i64, ptr } %t54)
  store %"compiler/typed:Block" %t55, ptr %l34
  br label %bb6
bb6:
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store ptr %t56, ptr %lp6
  %t57 = load %"compiler/typed:Block", ptr %l34
  %t58 = load ptr, ptr %lp6
  store %"compiler/typed:Block" %t57, ptr %t58
  store %"compiler/typed:Item" zeroinitializer, ptr %l35
  %t59 = icmp sgt i64 1, 0
  br i1 %t59, label %bb7, label %bb8
bb7:
  %t61 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v2, i32 0, i64 0)
  store %"compiler/typed:Item" %t61, ptr %l37
  br label %bb9
bb8:
  %t62 = icmp sge i64 1, 0
  br i1 %t62, label %bb10, label %bb11
bb9:
  %t64 = load %"compiler/typed:Item", ptr %l37
  store %"compiler/typed:Item" %t64, ptr %l35
  br label %bb8
bb10:
  %t65 = icmp sle i64 1, 576460752303423487
  br i1 %t65, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb12:
  %t67 = mul i64 1, 16
  %t68 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t67)
  %t69 = load %"compiler/typed:Item", ptr %l35
  store i64 0, ptr %t70
  br label %fill.71
fill.71:
  %t74 = load i64, ptr %t70
  %t75 = icmp slt i64 %t74, 1
  br i1 %t75, label %fillb.72, label %filld.73
fillb.72:
  %t76 = getelementptr %"compiler/typed:Item", ptr %t68, i64 %t74
  store %"compiler/typed:Item" %t69, ptr %t76
  %t77 = add i64 %t74, 1
  store i64 %t77, ptr %t70
  br label %fill.71
filld.73:
  %t78 = insertvalue { i64, ptr } undef, i64 1, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t68, 1
  store { i64, ptr } %t79, ptr %l7, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t81, ptr %l41, !tbaa !27
  %t82 = load i32, ptr %l4, !tbaa !23
  %t84 = call %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %s0, i32 %t82, i64 -1)
  store %"compiler/typed:Item" %t84, ptr %l43
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_8e26fbb1c5557eef_13e6cc5de085742b)
  unreachable
bb14:
  %t85 = load %"compiler/typed:Item", ptr %l43
  %t86 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr %"compiler/typed:Item", ptr %t87, i64 0
  store %"compiler/typed:Item" %t85, ptr %t88
  %t89 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t89, ptr %l44
  %t90 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t90, ptr %l45, !tbaa !27
  %t91 = load ptr, ptr %lp6
  store ptr %t91, ptr %l46, !tbaa !29
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb15, label %bb16
bb15:
  %t94 = icmp sle i64 0, 1152921504606846975
  br i1 %t94, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb17:
  %t96 = mul i64 0, 8
  %t97 = insertvalue { i64, ptr } undef, i64 0, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t99 = load %"compiler/source:Span", ptr %l44
  %t100 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t101 = load ptr, ptr %l46, !tbaa !29
  %t103 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v2, ptr %v2, ptr %v2, ptr %v2, %"compiler/source:Span" %t99, { i64, ptr } %t100, i1 false, ptr %t101, { i64, ptr } %t98, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t103, ptr %l50
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_6d702b04e725ae1a_71c02c55b3dfc416)
  unreachable
bb19:
  %t104 = load %"compiler/typed:Clause", ptr %l50
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 72, i64 8)
  store %"compiler/typed:Clause" %t104, ptr %t105
  %t107 = insertvalue [1 x ptr] undef, ptr %t105, 0
  %t108 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t108, ptr %lp8
  %t110 = load ptr, ptr %lp8
  store [1 x ptr] %t107, ptr %t110
  %t111 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t111, ptr %l53
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t115 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t112)
  store i32 %t115, ptr %l56
  br label %bb20
bb20:
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = load ptr, ptr %lp8
  %t120 = insertvalue { i64, ptr } undef, i64 1, 0
  %t121 = insertvalue { i64, ptr } %t120, ptr %t118, 1
  %t124 = call %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v1, ptr %v2, ptr %v2, ptr %t116, { i64, ptr } %t121, i1 false, i1 true, i1 true)
  store %"compiler/typed:Try" %t124, ptr %l61
  br label %bb21
bb21:
  %t125 = load %"compiler/typed:Try", ptr %l61
  %t126 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/typed:Try" %t125, ptr %t126
  store { i64, [5 x i64] } zeroinitializer, ptr %t127
  %t128 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 0
  store i64 14, ptr %t128
  %t129 = load %"compiler/source:Span", ptr %l53
  %t130 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t129, 0
  %t131 = load i32, ptr %l56, !tbaa !23
  %t132 = insertvalue { %"compiler/source:Span", i32, ptr } %t130, i32 %t131, 1
  %t134 = insertvalue { %"compiler/source:Span", i32, ptr } %t132, ptr %t126, 2
  %t135 = getelementptr { i64, [5 x i64] }, ptr %t127, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t134, ptr %t135
  %t136 = load { i64, [5 x i64] }, ptr %t127
  %t138 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t136, ptr %t138
  call void @__olang_scope_close(ptr %s0)
  store ptr %t138, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i1
  %l32 = alloca ptr
  %l33 = alloca i1
  %l42 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l66 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca i1
  %l91 = alloca ptr
  %l94 = alloca %"compiler/source:Span"
  %l95 = alloca %"compiler/diagmsg:Msg"
  %l96 = alloca i64
  %l97 = alloca ptr
  %l98 = alloca i1
  %l101 = alloca i1
  %l110 = alloca i1
  %l112 = alloca i1
  %l123 = alloca i1
  %l130 = alloca ptr
  %l134 = alloca ptr
  %l137 = alloca i32
  %l141 = alloca i1
  %l145 = alloca i1
  %l149 = alloca i1
  %l151 = alloca i1
  %l154 = alloca ptr
  %l156 = alloca ptr
  %l158 = alloca i64
  %l160 = alloca ptr
  %l162 = alloca i64
  %l164 = alloca %"compiler/source:Span"
  %l165 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l168 = alloca { i64, ptr }
  %l170 = alloca %"compiler/check:idleCall"
  %l176 = alloca ptr
  %l177 = alloca i1
  %l181 = alloca ptr
  %l182 = alloca %"compiler/source:Span"
  %l187 = alloca ptr
  %l195 = alloca ptr
  %l198 = alloca i32
  %l201 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i1
  %l210 = alloca ptr
  %l211 = alloca i1
  %l214 = alloca ptr
  %l217 = alloca %"compiler/source:Span"
  %l219 = alloca %"compiler/diagmsg:Msg"
  %l220 = alloca %"compiler/diagmsg:Msg"
  %l221 = alloca %"compiler/diagmsg:Msg"
  %l222 = alloca i64
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %t101 = alloca { i64, [3 x i64] }, align 8
  %t338 = alloca { i64, [3 x i64] }, align 8
  %t372 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t2 = load ptr, ptr %l23, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l23, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 2
  store i1 %t8, ptr %l24, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l24, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l3, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load %"compiler/source:Span", ptr %l1
  %t18 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexprStmt(ptr %v0, ptr %v1, ptr %t16, %"compiler/source:Span" %t17, ptr %t18)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l32, !tbaa !29
  store i1 false, ptr %l33, !tbaa !21
  %t23 = load ptr, ptr %l32, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb8, label %bb9
bb8:
  %t26 = load ptr, ptr %l32, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 3
  store i1 %t29, ptr %l33, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l33, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t33, i32 0, i32 1
  %t35 = load i32, ptr %t34, !range !{i32 0, i32 98}
  store i32 %t35, ptr %l4
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t39, i32 0, i32 2
  %t41 = load ptr, ptr %t40
  store ptr %t41, ptr %l5, !tbaa !29
  br label %bb12
bb11:
  br label %bb20
bb12:
  %t43 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t45 = trunc i64 76 to i32
  %t46 = icmp eq i32 %t43, %t45
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb15
bb14:
  %t48 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t50 = trunc i64 77 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l42, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l42, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t57 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t59 = trunc i64 76 to i32
  %t60 = icmp eq i32 %t57, %t59
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %t54, %"compiler/source:Span" %t55, ptr %t56, i1 %t60)
  br label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb19:
  br label %bb105
bb20:
  %t65 = load ptr, ptr %l2, !tbaa !29
  store ptr %t65, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t66 = load ptr, ptr %l50, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb21, label %bb22
bb21:
  %t69 = load ptr, ptr %l50, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 30}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l51, !tbaa !21
  br label %bb22
bb22:
  %t73 = load i1, ptr %l51, !tbaa !21
  br i1 %t73, label %bb23, label %bb24
bb23:
  %t74 = load ptr, ptr %l2, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 1
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 98}
  store i32 %t78, ptr %l6
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = getelementptr { i64, [4 x i64] }, ptr %t80, i32 0, i32 1
  %t83 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t82, i32 0, i32 2
  %t84 = load ptr, ptr %t83
  store ptr %t84, ptr %l7, !tbaa !29
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t86 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t88 = trunc i64 80 to i32
  %t89 = icmp eq i32 %t86, %t88
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l60, !tbaa !29
  %t92 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t92, ptr %l61
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l2, !tbaa !29
  %t96 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t100 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t93, ptr %t94, i32 %t96)
  store ptr %t100, ptr %l66
  br label %bb28
bb27:
  br label %bb30
bb28:
  store { i64, [3 x i64] } zeroinitializer, ptr %t101
  %t102 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 0
  store i64 2, ptr %t102
  %t103 = load %"compiler/source:Span", ptr %l61
  %t104 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t103, 0
  %t105 = load ptr, ptr %l66, !tbaa !29
  %t106 = insertvalue { %"compiler/source:Span", ptr } %t104, ptr %t105, 1
  %t107 = getelementptr { i64, [3 x i64] }, ptr %t101, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t106, ptr %t107
  %t108 = load { i64, [3 x i64] }, ptr %t101
  %t110 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t108, ptr %t110
  %t111 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t111, ptr %t110)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb30:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load %"compiler/source:Span", ptr %l1
  %t115 = load ptr, ptr %l7, !tbaa !29
  %t116 = load i32, ptr %l6, !range !{i32 0, i32 98}
  %t118 = trunc i64 76 to i32
  %t119 = icmp eq i32 %t116, %t118
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %t113, %"compiler/source:Span" %t114, ptr %t115, i1 %t119)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb32:
  %t124 = load ptr, ptr %l2, !tbaa !29
  store ptr %t124, ptr %l74, !tbaa !29
  store i1 false, ptr %l75, !tbaa !21
  %t125 = load ptr, ptr %l74, !tbaa !29
  %t126 = icmp ne ptr %t125, null
  br i1 %t126, label %bb33, label %bb34
bb33:
  %t128 = load ptr, ptr %l74, !tbaa !29
  %t129 = load i64, ptr %t128, !range !{i64 0, i64 30}
  %t131 = icmp eq i64 %t129, 12
  store i1 %t131, ptr %l75, !tbaa !21
  br label %bb34
bb34:
  %t132 = load i1, ptr %l75, !tbaa !21
  br i1 %t132, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb92
bb37:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l2, !tbaa !29
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t140 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t133, ptr %t134, i32 %t136)
  store ptr %t140, ptr %l82
  br label %bb38
bb38:
  %t141 = load ptr, ptr %l82, !tbaa !29
  store ptr %t141, ptr %l8, !tbaa !29
  %t142 = load ptr, ptr %l8, !tbaa !29
  store ptr %t142, ptr %l83, !tbaa !29
  store i1 false, ptr %l84, !tbaa !21
  %t143 = load ptr, ptr %l83, !tbaa !29
  %t144 = icmp ne ptr %t143, null
  br i1 %t144, label %bb39, label %bb40
bb39:
  %t146 = load ptr, ptr %l83, !tbaa !29
  %t147 = load i64, ptr %t146, !range !{i64 0, i64 18}
  %t149 = icmp eq i64 %t147, 9
  store i1 %t149, ptr %l84, !tbaa !21
  br label %bb40
bb40:
  %t150 = load i1, ptr %l84, !tbaa !21
  br i1 %t150, label %bb41, label %bb42
bb41:
  %t151 = load ptr, ptr %l8, !tbaa !29
  %t153 = getelementptr { i64, [5 x i64] }, ptr %t151, i32 0, i32 1
  %t154 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t153, i32 0, i32 2
  %t155 = load i32, ptr %t154, !range !{i32 0, i32 49}
  store i32 %t155, ptr %l9
  br label %bb43
bb42:
  br label %bb49
bb43:
  %t157 = load i32, ptr %l9, !range !{i32 0, i32 49}
  %t159 = trunc i64 24 to i32
  %t160 = icmp eq i32 %t157, %t159
  br i1 %t160, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l91, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t164 = load ptr, ptr %l2, !tbaa !29
  %t167 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %t163, ptr %t164)
  store %"compiler/source:Span" %t167, ptr %l94
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t168 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %s7)
  store %"compiler/diagmsg:Msg" %t168, ptr %l95
  br label %bb47
bb47:
  %t169 = load ptr, ptr %l91, !tbaa !29
  %t170 = load %"compiler/source:Span", ptr %l94
  %t171 = load %"compiler/diagmsg:Msg", ptr %l95
  %t172 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t169, %"compiler/source:Span" %t170, %"compiler/diagmsg:Msg" %t171)
  store i64 %t172, ptr %l96
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb49:
  br i1 true, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_602058b5bbdc5ba4_407e96c83aaf1680)
  unreachable
bb54:
  %t173 = load ptr, ptr %l8, !tbaa !29
  store ptr %t173, ptr %l97, !tbaa !29
  store i1 false, ptr %l98, !tbaa !21
  %t174 = load ptr, ptr %l97, !tbaa !29
  %t175 = icmp ne ptr %t174, null
  br i1 %t175, label %bb55, label %bb56
bb55:
  %t177 = load ptr, ptr %l97, !tbaa !29
  %t178 = load i64, ptr %t177, !range !{i64 0, i64 18}
  %t180 = icmp eq i64 %t178, 4
  store i1 %t180, ptr %l98, !tbaa !21
  br label %bb56
bb56:
  %t181 = load i1, ptr %l98, !tbaa !21
  br i1 %t181, label %bb57, label %bb58
bb57:
  %t182 = load ptr, ptr %l8, !tbaa !29
  %t184 = getelementptr { i64, [5 x i64] }, ptr %t182, i32 0, i32 1
  %t185 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t184, i32 0, i32 0
  %t186 = load %"compiler/source:Span", ptr %t185
  store %"compiler/source:Span" %t186, ptr %l10
  %t188 = load ptr, ptr %l8, !tbaa !29
  %t190 = getelementptr { i64, [5 x i64] }, ptr %t188, i32 0, i32 1
  %t191 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t190, i32 0, i32 1
  %t192 = load i32, ptr %t191
  %t194 = load ptr, ptr %l8, !tbaa !29
  %t196 = getelementptr { i64, [5 x i64] }, ptr %t194, i32 0, i32 1
  %t197 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t196, i32 0, i32 2
  %t198 = load ptr, ptr %t197
  store ptr %t198, ptr %l12, !tbaa !29
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t204 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t200, i32 %t192)
  store i1 %t204, ptr %l110
  br label %bb59
bb58:
  store i1 false, ptr %l101, !tbaa !21
  br label %bb60
bb59:
  %t205 = load i1, ptr %l110, !tbaa !21
  %t206 = xor i1 %t205, true
  store i1 %t206, ptr %l101, !tbaa !21
  br label %bb60
bb60:
  %t208 = load i1, ptr %l101, !tbaa !21
  br i1 %t208, label %bb61, label %bb62
bb61:
  %t209 = load ptr, ptr %l8, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 0
  %t213 = load %"compiler/source:Span", ptr %t212
  store %"compiler/source:Span" %t213, ptr %l13
  %t215 = load ptr, ptr %l8, !tbaa !29
  %t217 = getelementptr { i64, [5 x i64] }, ptr %t215, i32 0, i32 1
  %t218 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t217, i32 0, i32 1
  %t219 = load i32, ptr %t218
  %t221 = load ptr, ptr %l8, !tbaa !29
  %t223 = getelementptr { i64, [5 x i64] }, ptr %t221, i32 0, i32 1
  %t224 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t223, i32 0, i32 2
  %t225 = load ptr, ptr %t224
  store ptr %t225, ptr %l15, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/check:Checker", ptr %t227, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !29
  %t232 = getelementptr %"compiler/generic:Program", ptr %t230, i32 0, i32 2
  %t236 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t232, i32 %t219)
  store i1 %t236, ptr %l123
  br label %bb63
bb62:
  store i1 false, ptr %l112, !tbaa !21
  br label %bb64
bb63:
  %t237 = load i1, ptr %l123, !tbaa !21
  store i1 %t237, ptr %l112, !tbaa !21
  br label %bb64
bb64:
  %t238 = load i1, ptr %l112, !tbaa !21
  br i1 %t238, label %bb65, label %bb66
bb65:
  %t239 = load ptr, ptr %l8, !tbaa !29
  %t241 = getelementptr { i64, [5 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t241, i32 0, i32 0
  %t243 = load %"compiler/source:Span", ptr %t242
  store %"compiler/source:Span" %t243, ptr %l16
  %t245 = load ptr, ptr %l8, !tbaa !29
  %t247 = getelementptr { i64, [5 x i64] }, ptr %t245, i32 0, i32 1
  %t248 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t247, i32 0, i32 1
  %t249 = load i32, ptr %t248
  store i32 %t249, ptr %l17, !tbaa !23
  %t251 = load ptr, ptr %l8, !tbaa !29
  %t253 = getelementptr { i64, [5 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t253, i32 0, i32 2
  %t255 = load ptr, ptr %t254
  %t257 = load ptr, ptr %l0, !tbaa !29
  store ptr %t257, ptr %l130, !tbaa !29
  %t258 = load ptr, ptr %l0, !tbaa !29
  %t259 = load %"compiler/source:Span", ptr %l1
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v0, ptr %v0, ptr %t258, %"compiler/source:Span" %t259, ptr %t255, i64 -1)
  store ptr %t264, ptr %l134
  br label %bb67
bb66:
  br label %bb69
bb67:
  %t265 = load ptr, ptr %l130, !tbaa !29
  %t266 = load ptr, ptr %l134, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t265, ptr %t266)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t267 = load ptr, ptr %l8, !tbaa !29
  %t270 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t267)
  store i32 %t270, ptr %l137
  br label %bb70
bb70:
  %t271 = load i32, ptr %l137, !tbaa !23
  store i32 %t271, ptr %l19, !tbaa !23
  %t272 = load i32, ptr %l19, !tbaa !23
  %t273 = load i32, ptr @G_2ecompiler_2ftypes_2eVoidT, !tbaa !23
  %t276 = icmp ne i32 %t272, %t273
  br i1 %t276, label %bb71, label %bb72
bb71:
  %t278 = load i32, ptr %l19, !tbaa !23
  %t279 = load i32, ptr @G_2ecompiler_2ftypes_2eNoreturnT, !tbaa !23
  %t282 = icmp ne i32 %t278, %t279
  store i1 %t282, ptr %l141, !tbaa !21
  br label %bb73
bb72:
  store i1 false, ptr %l141, !tbaa !21
  br label %bb73
bb73:
  %t284 = load i1, ptr %l141, !tbaa !21
  br i1 %t284, label %bb74, label %bb75
bb74:
  %t285 = load i32, ptr %l19, !tbaa !23
  %t286 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t289 = icmp ne i32 %t285, %t286
  store i1 %t289, ptr %l145, !tbaa !21
  br label %bb76
bb75:
  store i1 false, ptr %l145, !tbaa !21
  br label %bb76
bb76:
  %t291 = load i1, ptr %l145, !tbaa !21
  br i1 %t291, label %bb77, label %bb78
bb77:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %t292)
  store i1 %t294, ptr %l151
  br label %bb79
bb78:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb80
bb79:
  %t295 = load i1, ptr %l151, !tbaa !21
  %t296 = xor i1 %t295, true
  store i1 %t296, ptr %l149, !tbaa !21
  br label %bb80
bb80:
  %t298 = load i1, ptr %l149, !tbaa !21
  br i1 %t298, label %bb81, label %bb82
bb81:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/check:Checker", ptr %t299, i32 0, i32 104
  store ptr %t301, ptr %l154, !tbaa !29
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t302)
  store ptr %t304, ptr %l156
  br label %bb83
bb82:
  br label %bb90
bb83:
  %t305 = load ptr, ptr %l156, !tbaa !29
  %t307 = getelementptr %"compiler/check:frame", ptr %t305, i32 0, i32 0
  %t308 = load i64, ptr %t307, !tbaa !24
  store i64 %t308, ptr %l158, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t309)
  store ptr %t311, ptr %l160
  br label %bb84
bb84:
  %t312 = load ptr, ptr %l160, !tbaa !29
  %t314 = getelementptr %"compiler/check:frame", ptr %t312, i32 0, i32 2
  %t315 = load i64, ptr %t314, !tbaa !24
  store i64 %t315, ptr %l162, !tbaa !24
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t318 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t316)
  store %"compiler/source:Span" %t318, ptr %l164
  br label %bb85
bb85:
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l165, !tbaa !29
  %t320 = load ptr, ptr %l2, !tbaa !29
  %t322 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t320)
  store %"compiler/source:Span" %t322, ptr %l167
  br label %bb86
bb86:
  %t323 = load ptr, ptr %l165, !tbaa !29
  %t324 = load %"compiler/source:Span", ptr %l167
  %t325 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t323, %"compiler/source:Span" %t324)
  store { i64, ptr } %t325, ptr %l168
  br label %bb87
bb87:
  %t326 = load ptr, ptr %l8, !tbaa !29
  %t327 = load i64, ptr %l158, !tbaa !24
  %t328 = load i64, ptr %l162, !tbaa !24
  %t329 = load %"compiler/source:Span", ptr %l164
  %t330 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t332 = call %"compiler/check:idleCall" @compiler_2fcheck_3aidleCall_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t327, i64 %t328, %"compiler/source:Span" %t329, { i64, ptr } %t330, ptr %t326)
  store %"compiler/check:idleCall" %t332, ptr %l170
  br label %bb88
bb88:
  %t333 = load ptr, ptr %l154, !tbaa !29
  %t334 = load %"compiler/check:idleCall", ptr %l170
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2ePush_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v0, ptr %t333, %"compiler/check:idleCall" %t334)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l1
  %t337 = load ptr, ptr %l8, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t338
  %t339 = getelementptr { i64, [3 x i64] }, ptr %t338, i32 0, i32 0
  store i64 2, ptr %t339
  %t341 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t336, 0
  %t343 = insertvalue { %"compiler/source:Span", ptr } %t341, ptr %t337, 1
  %t344 = getelementptr { i64, [3 x i64] }, ptr %t338, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t343, ptr %t344
  %t345 = load { i64, [3 x i64] }, ptr %t338
  %t347 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t345, ptr %t347
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t335, ptr %t347)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb92:
  %t350 = load ptr, ptr %l2, !tbaa !29
  store ptr %t350, ptr %l176, !tbaa !29
  store i1 false, ptr %l177, !tbaa !21
  %t351 = load ptr, ptr %l176, !tbaa !29
  %t352 = icmp ne ptr %t351, null
  br i1 %t352, label %bb93, label %bb94
bb93:
  %t354 = load ptr, ptr %l176, !tbaa !29
  %t355 = load i64, ptr %t354, !range !{i64 0, i64 30}
  %t357 = icmp eq i64 %t355, 21
  store i1 %t357, ptr %l177, !tbaa !21
  br label %bb94
bb94:
  %t358 = load i1, ptr %l177, !tbaa !21
  br i1 %t358, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  br label %bb100
bb97:
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/check:Checker", ptr %t359, i32 0, i32 43
  store i1 true, ptr %t361, !tbaa !21
  %t362 = load ptr, ptr %l0, !tbaa !29
  store ptr %t362, ptr %l181, !tbaa !29
  %t363 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t363, ptr %l182
  %t364 = load ptr, ptr %l0, !tbaa !29
  %t365 = load ptr, ptr %l2, !tbaa !29
  %t367 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t371 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t364, ptr %t365, i32 %t367)
  store ptr %t371, ptr %l187
  br label %bb98
bb98:
  store { i64, [3 x i64] } zeroinitializer, ptr %t372
  %t373 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 0
  store i64 2, ptr %t373
  %t374 = load %"compiler/source:Span", ptr %l182
  %t375 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t374, 0
  %t376 = load ptr, ptr %l187, !tbaa !29
  %t377 = insertvalue { %"compiler/source:Span", ptr } %t375, ptr %t376, 1
  %t378 = getelementptr { i64, [3 x i64] }, ptr %t372, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t377, ptr %t378
  %t379 = load { i64, [3 x i64] }, ptr %t372
  %t381 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t379, ptr %t381
  %t382 = load ptr, ptr %l181, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t382, ptr %t381)
  br label %bb99
bb99:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t386 = getelementptr %"compiler/check:Checker", ptr %t384, i32 0, i32 43
  store i1 false, ptr %t386, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb100:
  br i1 true, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @olang_loc_a929affe4386ca95_c275f1e9d349f711)
  unreachable
bb105:
  %t387 = load ptr, ptr %l0, !tbaa !29
  %t388 = load ptr, ptr %l2, !tbaa !29
  %t390 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t394 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v0, ptr %t387, ptr %t388, i32 %t390)
  store ptr %t394, ptr %l195
  br label %bb106
bb106:
  %t395 = load ptr, ptr %l195, !tbaa !29
  %t399 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t395)
  store i32 %t399, ptr %l198
  br label %bb107
bb107:
  %t400 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t401 = load i32, ptr %l198, !tbaa !23
  %t403 = icmp eq i32 %t401, %t400
  br i1 %t403, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb109:
  br label %bb110
bb110:
  %t405 = load ptr, ptr %l2, !tbaa !29
  store ptr %t405, ptr %l202, !tbaa !29
  store i1 false, ptr %l203, !tbaa !21
  %t406 = load ptr, ptr %l202, !tbaa !29
  %t407 = icmp ne ptr %t406, null
  br i1 %t407, label %bb111, label %bb112
bb111:
  %t409 = load ptr, ptr %l202, !tbaa !29
  %t410 = load i64, ptr %t409, !range !{i64 0, i64 30}
  %t412 = icmp eq i64 %t410, 1
  store i1 %t412, ptr %l203, !tbaa !21
  br label %bb112
bb112:
  %t413 = load i1, ptr %l203, !tbaa !21
  br i1 %t413, label %bb113, label %bb114
bb113:
  %t414 = load ptr, ptr %l2, !tbaa !29
  %t416 = getelementptr { i64, [4 x i64] }, ptr %t414, i32 0, i32 1
  %t417 = getelementptr { %"compiler/source:Span", i32 }, ptr %t416, i32 0, i32 1
  %t418 = load i32, ptr %t417, !range !{i32 0, i32 98}
  store i32 %t418, ptr %l21
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t420 = load i32, ptr %l21, !range !{i32 0, i32 98}
  %t422 = trunc i64 5 to i32
  %t423 = icmp eq i32 %t420, %t422
  store i1 %t423, ptr %l201, !tbaa !21
  br label %bb127
bb116:
  %t425 = load ptr, ptr %l2, !tbaa !29
  store ptr %t425, ptr %l210, !tbaa !29
  store i1 false, ptr %l211, !tbaa !21
  %t426 = load ptr, ptr %l210, !tbaa !29
  %t427 = icmp ne ptr %t426, null
  br i1 %t427, label %bb117, label %bb118
bb117:
  %t429 = load ptr, ptr %l210, !tbaa !29
  %t430 = load i64, ptr %t429, !range !{i64 0, i64 30}
  %t432 = icmp eq i64 %t430, 20
  store i1 %t432, ptr %l211, !tbaa !21
  br label %bb118
bb118:
  %t433 = load i1, ptr %l211, !tbaa !21
  br i1 %t433, label %bb119, label %bb120
bb119:
  br label %bb121
bb120:
  br label %bb122
bb121:
  store i1 true, ptr %l201, !tbaa !21
  br label %bb127
bb122:
  br i1 true, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb126
bb125:
  store i1 false, ptr %l201, !tbaa !21
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_c2976cb1f3dad95e_90ea7f94faae157a)
  unreachable
bb127:
  %t434 = load i1, ptr %l201, !tbaa !21
  store i1 %t434, ptr %l22, !tbaa !21
  %t435 = load ptr, ptr %l0, !tbaa !29
  store ptr %t435, ptr %l214, !tbaa !29
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t437 = load ptr, ptr %l2, !tbaa !29
  %t440 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %t436, ptr %t437)
  store %"compiler/source:Span" %t440, ptr %l217
  br label %bb128
bb128:
  %t441 = load i1, ptr %l22, !tbaa !21
  br i1 %t441, label %bb129, label %bb130
bb129:
  %t443 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinNextLine(ptr %s0)
  store %"compiler/diagmsg:Msg" %t443, ptr %l220
  br label %bb131
bb130:
  %t444 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %s0)
  store %"compiler/diagmsg:Msg" %t444, ptr %l221
  br label %bb132
bb131:
  %t445 = load %"compiler/diagmsg:Msg", ptr %l220
  store %"compiler/diagmsg:Msg" %t445, ptr %l219
  br label %bb133
bb132:
  %t446 = load %"compiler/diagmsg:Msg", ptr %l221
  store %"compiler/diagmsg:Msg" %t446, ptr %l219
  br label %bb133
bb133:
  %t447 = load ptr, ptr %l214, !tbaa !29
  %t448 = load %"compiler/source:Span", ptr %l217
  %t449 = load %"compiler/diagmsg:Msg", ptr %l219
  %t450 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s0, ptr %t447, %"compiler/source:Span" %t448, %"compiler/diagmsg:Msg" %t449)
  store i64 %t450, ptr %l222
  br label %bb134
bb134:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsRestored(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factsCopy" %a1) #0 {
entry:
  %l1 = alloca %"compiler/check:factsCopy"
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store %"compiler/check:factsCopy" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l5, !tbaa !29
  %t6 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 0
  %t7 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l6
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e(ptr %v0, ptr %l6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  %t11 = load ptr, ptr %l5, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t11, i32 0, i32 50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t12
  %t13 = load ptr, ptr %l2, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  %t14 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 1
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l10
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %l10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l12
  br label %bb3
bb3:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t20 = getelementptr %"compiler/check:frame", ptr %t19, i32 0, i32 46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t20
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l13, !tbaa !29
  %t22 = getelementptr %"compiler/check:factsCopy", ptr %l1, i32 0, i32 2
  %t23 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l14
  %t25 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %l14)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %l16
  br label %bb4
bb4:
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  %t27 = load ptr, ptr %l13, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t27, i32 0, i32 59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t28
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnFact(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, ptr %a3, i32 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l21 = alloca i1
  %l27 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca ptr
  %l45 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca %"compiler/source:Span"
  %l48 = alloca i32
  %l50 = alloca ptr
  %l52 = alloca %"compiler/effects:Facts"
  %l55 = alloca i1
  %l56 = alloca i64
  %l57 = alloca ptr
  %l62 = alloca i64
  %l65 = alloca ptr
  %l66 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca { i64, ptr }
  %l76 = alloca %"compiler/diagmsg:Msg"
  %l77 = alloca i64
  %l80 = alloca ptr
  %l84 = alloca i64
  %l88 = alloca i1
  %l92 = alloca i1
  %l93 = alloca i32
  %l95 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca i64
  %l101 = alloca { i64, ptr }
  %l102 = alloca i1
  %l104 = alloca ptr
  %l106 = alloca i64
  %l107 = alloca %"compiler/source:Span"
  %l110 = alloca { i64, ptr }
  %l113 = alloca %"compiler/check:factRead"
  %l114 = alloca ptr
  %l115 = alloca %"compiler/source:Span"
  %l116 = alloca i32
  %l118 = alloca i64
  %l119 = alloca ptr
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %a4)
  store { i64, ptr } %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t9 = call i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %t7)
  store i32 %t9, ptr %l16
  br label %bb2
bb2:
  %t10 = load i32, ptr %l16, !range !{i32 0, i32 8}
  store i32 %t10, ptr %l6
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t13 = call i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %t11)
  store i1 %t13, ptr %l18
  br label %bb3
bb3:
  %t14 = load i1, ptr %l18, !tbaa !21
  store i1 %t14, ptr %l7, !tbaa !21
  %t15 = load i32, ptr %l6, !range !{i32 0, i32 8}
  %t17 = trunc i64 7 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i1, ptr %l7, !tbaa !21
  %t22 = xor i1 %t20, true
  store i1 %t22, ptr %l21, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l21, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i64 %t30, ptr %l27
  br label %bb10
bb10:
  %t31 = load i64, ptr %l27, !tbaa !24
  store i64 %t31, ptr %l8, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t37 = load i1, ptr %l7, !tbaa !21
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l32, !tbaa !29
  %t40 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t40, ptr %l33
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t41, ptr %l34, !tbaa !23
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l8, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v0, ptr %t42, i64 %t43, { i64, ptr } %t44)
  store i1 %t48, ptr %l38
  br label %bb16
bb15:
  br label %bb21
bb16:
  %t49 = load i1, ptr %l38, !tbaa !21
  br i1 %t49, label %bb17, label %bb18
bb17:
  store i64 1, ptr %l39, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb19
bb19:
  %t50 = load ptr, ptr %l32, !tbaa !29
  %t51 = load %"compiler/source:Span", ptr %l33
  %t52 = load i32, ptr %l34, !tbaa !23
  %t53 = load i64, ptr %l39, !tbaa !24
  %t54 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t50, %"compiler/source:Span" %t51, i32 %t52, i64 %t53)
  store ptr %t54, ptr %l40
  br label %bb20
bb20:
  %t55 = load ptr, ptr %l40, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t55, ptr %rv
  br label %ret
bb21:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t61 = load i64, ptr %l8, !tbaa !24
  %t64 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %t60, i64 %t61)
  store i1 %t64, ptr %l45
  br label %bb22
bb22:
  %t65 = load i1, ptr %l45, !tbaa !21
  br i1 %t65, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l46, !tbaa !29
  %t67 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t67, ptr %l47
  %t68 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t68, ptr %l48, !tbaa !23
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eEffects(ptr %v0, ptr %v0, ptr %t69)
  store ptr %t71, ptr %l50
  br label %bb25
bb24:
  br label %bb32
bb25:
  %t72 = load i64, ptr %l8, !tbaa !24
  %t73 = load ptr, ptr %l50, !tbaa !29
  %t75 = call %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %t73, i64 %t72)
  store %"compiler/effects:Facts" %t75, ptr %l52
  br label %bb26
bb26:
  %t76 = load i32, ptr %l6, !range !{i32 0, i32 8}
  %t79 = call i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %s4, ptr %l52, i32 %t76)
  store i1 %t79, ptr %l55
  br label %bb27
bb27:
  %t80 = load i1, ptr %l55, !tbaa !21
  br i1 %t80, label %bb28, label %bb29
bb28:
  store i64 1, ptr %l56, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb30
bb30:
  %t81 = load ptr, ptr %l46, !tbaa !29
  %t82 = load %"compiler/source:Span", ptr %l47
  %t83 = load i32, ptr %l48, !tbaa !23
  %t84 = load i64, ptr %l56, !tbaa !24
  %t85 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t81, %"compiler/source:Span" %t82, i32 %t83, i64 %t84)
  store ptr %t85, ptr %l57
  br label %bb31
bb31:
  %t86 = load ptr, ptr %l57, !tbaa !29
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t86, ptr %rv
  br label %ret
bb32:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t90 = load i64, ptr %l8, !tbaa !24
  %t94 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactInst(ptr %v0, ptr %v1, ptr %t88, ptr %t89, i64 %t90)
  store i64 %t94, ptr %l62
  br label %bb33
bb33:
  %t95 = load i64, ptr %l62, !tbaa !24
  store i64 %t95, ptr %l9, !tbaa !24
  %t96 = load i64, ptr %l9, !tbaa !24
  %t98 = icmp slt i64 %t96, 0
  br i1 %t98, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s5
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l65, !tbaa !29
  store %"compiler/source:Span" %a2, ptr %l66
  %t102 = load ptr, ptr %l0, !tbaa !29
  store ptr %t102, ptr %l67, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s5, ptr %t106, i64 %t107)
  store ptr %t110, ptr %l71
  br label %bb36
bb35:
  br label %bb41
bb36:
  %t111 = load ptr, ptr %l71, !tbaa !29
  %t113 = getelementptr %"compiler/ast:Func", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %t113, !tbaa !23
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t117 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t115, i32 %t114)
  store { i64, ptr } %t117, ptr %l74
  br label %bb37
bb37:
  %t118 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t119 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t121 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactOfGeneric(ptr %v0, ptr %v0, ptr %s5, { i64, ptr } %t119, { i64, ptr } %t118)
  store %"compiler/diagmsg:Msg" %t121, ptr %l76
  br label %bb38
bb38:
  %t122 = load ptr, ptr %l65, !tbaa !29
  %t123 = load %"compiler/source:Span", ptr %l66
  %t124 = load %"compiler/diagmsg:Msg", ptr %l76
  %t125 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t122, %"compiler/source:Span" %t123, %"compiler/diagmsg:Msg" %t124)
  store i64 %t125, ptr %l77
  br label %bb39
bb39:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t127 = load %"compiler/source:Span", ptr %l1
  %t130 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v2, ptr %t126, %"compiler/source:Span" %t127)
  store ptr %t130, ptr %l80
  br label %bb40
bb40:
  %t131 = load ptr, ptr %l80, !tbaa !29
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t131, ptr %rv
  br label %ret
bb41:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i64, ptr %l9, !tbaa !24
  %t137 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %t133, i64 %t134)
  store i64 %t137, ptr %l84
  br label %bb42
bb42:
  %t138 = load i64, ptr %l9, !tbaa !24
  %t139 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t141 = call i64 @__olang_fmt_i64(ptr null, i64 %t138)
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = extractvalue { i64, ptr } %t139, 1
  %t147 = extractvalue { i64, ptr } %t139, 0
  %t148 = add i64 %t144, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t148)
  %t150 = call i64 @__olang_fmt_i64(ptr %t149, i64 %t138)
  %t151 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t151, ptr %t142, i64 %t143)
  %t152 = getelementptr i8, ptr %t151, i64 %t143
  call void @olang_textcopy(ptr %t152, ptr %t146, i64 %t147)
  %t153 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t149, 1
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 61
  %t162 = call { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %s0, ptr %t158, { i64, ptr } %t154)
  %t163 = extractvalue { i32, i1 } %t162, 1
  %t164 = extractvalue { i32, i1 } %t162, 0
  store i32 %t164, ptr %l93
  %t165 = icmp ne i32 %t164, 0
  br i1 %t165, label %bb44, label %ok.166, !prof !99
ok.166:
  store i1 %t163, ptr %l92
  br label %bb43
bb43:
  %t167 = load i1, ptr %l92, !tbaa !21
  store i1 %t167, ptr %l88, !tbaa !21
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t168 = load i32, ptr %l6, !range !{i32 0, i32 8}
  %t170 = call i1 @compiler_2feffects_2eConservative(i32 %t168)
  store i1 %t170, ptr %l95
  br label %bb46
bb46:
  %t171 = load i1, ptr %l95, !tbaa !21
  store i1 %t171, ptr %l88, !tbaa !21
  br label %bb47
bb47:
  %t172 = load i1, ptr %l88, !tbaa !21
  store i1 %t172, ptr %l11, !tbaa !21
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 60
  store ptr %t175, ptr %l97, !tbaa !29
  %t176 = load i64, ptr %l9, !tbaa !24
  store i64 %t176, ptr %l98, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = extractvalue { i64, ptr } %t177, 0
  %t181 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t179, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  store { i64, ptr } %t190, ptr %l101, !tbaa !27
  %t191 = load i1, ptr %l11, !tbaa !21
  store i1 %t191, ptr %l102, !tbaa !21
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t192)
  store ptr %t194, ptr %l104
  br label %bb48
bb48:
  %t195 = load ptr, ptr %l104, !tbaa !29
  %t197 = getelementptr %"compiler/check:frame", ptr %t195, i32 0, i32 2
  %t198 = load i64, ptr %t197, !tbaa !24
  store i64 %t198, ptr %l106, !tbaa !24
  %t199 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t199, ptr %l107
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l1
  %t204 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %s0, ptr %t200, %"compiler/source:Span" %t201)
  store { i64, ptr } %t204, ptr %l110
  br label %bb49
bb49:
  %t205 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t206, i64 %t207)
  %t209 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t212 = extractvalue { i64, ptr } %t210, 0
  %t213 = extractvalue { i64, ptr } %t210, 1
  %t214 = mul i64 %t212, 1
  %t215 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t214)
  call void @llvm.memcpy.p0.p0.i64(ptr %t215, ptr %t213, i64 %t214, i1 false)
  %t216 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t217 = insertvalue { i64, ptr } %t216, ptr %t215, 1
  %t218 = load i64, ptr %l98, !tbaa !24
  %t219 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t220 = load i1, ptr %l102, !tbaa !21
  %t221 = load i64, ptr %l106, !tbaa !24
  %t222 = load %"compiler/source:Span", ptr %l107
  %t224 = call %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v0, ptr %v0, i64 %t218, { i64, ptr } %t219, i1 %t220, i64 %t221, %"compiler/source:Span" %t222, { i64, ptr } %t217)
  store %"compiler/check:factRead" %t224, ptr %l113
  br label %bb50
bb50:
  %t225 = load ptr, ptr %l97, !tbaa !29
  %t226 = load %"compiler/check:factRead", ptr %l113
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v0, ptr %t225, %"compiler/check:factRead" %t226)
  br label %bb51
bb51:
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l114, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t228, ptr %l115
  %t229 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t229, ptr %l116, !tbaa !23
  %t230 = load i1, ptr %l11, !tbaa !21
  br i1 %t230, label %bb52, label %bb53
bb52:
  store i64 1, ptr %l118, !tbaa !24
  br label %bb54
bb53:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb54
bb54:
  %t232 = load ptr, ptr %l114, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l115
  %t234 = load i32, ptr %l116, !tbaa !23
  %t235 = load i64, ptr %l118, !tbaa !24
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v2, ptr %t232, %"compiler/source:Span" %t233, i32 %t234, i64 %t235)
  store ptr %t236, ptr %l119
  br label %bb55
bb55:
  %t237 = load ptr, ptr %l119, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t237, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenEnd(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1) #0 {
entry:
  %l2 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t8 = alloca { i64, [3 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %"compiler/source:Span" %a1, ptr %l2
  %t4 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t7 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t5, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d20, i32 0, i32 1) }, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store i32 %t7, ptr %l5
  br label %bb1
bb1:
  store { i64, [3 x i64] } zeroinitializer, ptr %t8
  %t9 = getelementptr { i64, [3 x i64] }, ptr %t8, i32 0, i32 0
  store i64 7, ptr %t9
  %t10 = load %"compiler/source:Span", ptr %l2
  %t11 = insertvalue { %"compiler/source:Span", i32, i64 } undef, %"compiler/source:Span" %t10, 0
  %t12 = load i32, ptr %l5, !tbaa !23
  %t13 = insertvalue { %"compiler/source:Span", i32, i64 } %t11, i32 %t12, 1
  %t14 = insertvalue { %"compiler/source:Span", i32, i64 } %t13, i64 0, 2
  %t15 = getelementptr { i64, [3 x i64] }, ptr %t8, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64 } %t14, ptr %t15
  %t16 = load { i64, [3 x i64] }, ptr %t8
  %t18 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store { i64, [3 x i64] } %t16, ptr %t18
  call void @__olang_scope_close(ptr %s0)
  store ptr %t18, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenRoot(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i32
  %l15 = alloca ptr
  %l17 = alloca i32
  %l23 = alloca i64
  %l28 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i1
  %l39 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"compiler/typed:Block"
  %l58 = alloca ptr
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l71 = alloca i64
  %l73 = alloca i64
  %l78 = alloca i32
  %l82 = alloca i32
  %l86 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l96 = alloca i1
  %l97 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca %"compiler/typed:Local"
  %l102 = alloca %"compiler/source:Span"
  %l105 = alloca { i64, ptr }
  %l107 = alloca %"compiler/diagmsg:Msg"
  %l108 = alloca i64
  %l121 = alloca i32
  %l127 = alloca i64
  %l128 = alloca ptr
  %l129 = alloca %"compiler/source:Span"
  %l132 = alloca i32
  %l136 = alloca ptr
  %l144 = alloca ptr
  %l147 = alloca i64
  %l152 = alloca ptr
  %l153 = alloca %"compiler/source:Span"
  %l154 = alloca %"compiler/source:Span"
  %l155 = alloca i32
  %l160 = alloca ptr
  %l165 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l179 = alloca %"compiler/typed:Block"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca ptr
  %t220 = alloca { i64, [1 x i64] }, align 8
  %t243 = alloca { i64, [3 x i64] }, align 8
  %t293 = alloca { i64, [3 x i64] }, align 8
  %t335 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/ast:Func", ptr %t1, i32 0, i32 0
  %t4 = load %"compiler/source:Span", ptr %t3
  store %"compiler/source:Span" %t4, ptr %l4
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/check:Checker", ptr %t6, i32 0, i32 37
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l23
  br label %bb1
bb1:
  %t11 = load i64, ptr %l23, !tbaa !24
  store i64 %t11, ptr %l5, !tbaa !24
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t17, i32 %a2)
  store i32 %t21, ptr %l28
  br label %bb2
bb2:
  %t22 = load i32, ptr %l28, !tbaa !23
  store i32 %t22, ptr %l6, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t27 = load i32, ptr %l6, !tbaa !23
  %t30 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %t26, i32 %t27)
  store i32 %t30, ptr %l32
  br label %bb3
bb3:
  %t31 = load i32, ptr %l32, !tbaa !23
  store i32 %t31, ptr %l7, !tbaa !23
  %t32 = load i32, ptr %l7, !tbaa !23
  %t33 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t36 = icmp eq i32 %t32, %t33
  br i1 %t36, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb8
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/generic:Program", ptr %t41, i32 0, i32 2
  store ptr %t43, ptr %l39, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l7, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l44
  br label %bb6
bb6:
  %t54 = load ptr, ptr %l39, !tbaa !29
  %t55 = load i32, ptr %l44, !tbaa !23
  %t56 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t54, i32 %t55)
  store { i64, ptr } %t56, ptr %l45
  br label %bb7
bb7:
  %t57 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t57, 0
  %t60 = icmp ne i64 %t58, 1
  store i1 %t60, ptr %l36, !tbaa !21
  br label %bb8
bb8:
  %t62 = load i1, ptr %l36, !tbaa !21
  br i1 %t62, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l4
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %s1, ptr %t63, %"compiler/source:Span" %t64, { i64, ptr } { i64 46, ptr getelementptr inbounds (<{ i64, [46 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 37
  %t70 = load i64, ptr %l5, !tbaa !24
  %t73 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t69, i64 %t70)
  store { i64, ptr } %t73, ptr %l53
  br label %bb12
bb12:
  %t74 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t75 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t74)
  store %"compiler/typed:Block" %t75, ptr %l54
  br label %bb13
bb13:
  %t76 = load %"compiler/typed:Block", ptr %l54
  %t77 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t76, ptr %t77
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store ptr %t77, ptr %rv
  br label %ret
bb14:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  store ptr %t84, ptr %l58, !tbaa !29
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t85, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t90 = getelementptr %"compiler/generic:Program", ptr %t88, i32 0, i32 2
  %t91 = load i32, ptr %l7, !tbaa !23
  %t94 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t90, i32 %t91)
  store i32 %t94, ptr %l63
  br label %bb15
bb15:
  %t95 = load ptr, ptr %l58, !tbaa !29
  %t96 = load i32, ptr %l63, !tbaa !23
  %t97 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t95, i32 %t96)
  store { i64, ptr } %t97, ptr %l64
  br label %bb16
bb16:
  %t98 = load { i64, ptr }, ptr %l64, !tbaa !27
  store { i64, ptr } %t98, ptr %l65, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i32, ptr %t100, i64 0
  %t102 = load i32, ptr %t101, !tbaa !33
  store i32 %t102, ptr %l8, !tbaa !23
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t104)
  store ptr %t106, ptr %l68
  br label %bb17
bb17:
  %t107 = load ptr, ptr %l68, !tbaa !29
  %t109 = getelementptr %"compiler/typed:Body", ptr %t107, i32 0, i32 5
  store ptr %t109, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb18
bb18:
  %t111 = load i64, ptr %l10, !tbaa !24
  store i64 %t111, ptr %l71, !tbaa !24
  %t112 = load ptr, ptr %l9, !tbaa !29
  %t114 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t112)
  store i64 %t114, ptr %l73
  br label %bb19
bb19:
  %t115 = load i64, ptr %l71, !tbaa !24
  %t116 = load i64, ptr %l73, !tbaa !24
  %t117 = icmp slt i64 %t115, %t116
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb20, label %bb21
bb20:
  br label %bb42
bb21:
  br label %bb22
bb22:
  %t121 = load ptr, ptr %l9, !tbaa !29
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t121, i64 %t122)
  store i32 %t125, ptr %l78
  br label %bb23
bb23:
  %t126 = load i32, ptr %l78, !tbaa !23
  store i32 %t126, ptr %l11, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load i32, ptr %l11, !tbaa !23
  %t130 = sext i32 %t128 to i64
  %t133 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t127, i64 %t130)
  store i32 %t133, ptr %l82
  br label %bb24
bb24:
  %t134 = load i32, ptr %l82, !tbaa !23
  store i32 %t134, ptr %l12, !tbaa !23
  %t135 = load i32, ptr %l12, !tbaa !23
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t139 = icmp ne i32 %t135, %t136
  br i1 %t139, label %bb25, label %bb26
bb25:
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l12, !tbaa !23
  %t145 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t141, i32 %t142)
  store i1 %t145, ptr %l89
  br label %bb27
bb26:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb28
bb27:
  %t146 = load i1, ptr %l89, !tbaa !21
  %t147 = xor i1 %t146, true
  store i1 %t147, ptr %l86, !tbaa !21
  br label %bb28
bb28:
  %t149 = load i1, ptr %l86, !tbaa !21
  br i1 %t149, label %bb29, label %bb30
bb29:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t155 = getelementptr %"compiler/generic:Program", ptr %t153, i32 0, i32 2
  %t156 = load i32, ptr %l12, !tbaa !23
  %t159 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %t155, i32 %t156)
  store i1 %t159, ptr %l96
  br label %bb31
bb30:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb32
bb31:
  %t160 = load i1, ptr %l96, !tbaa !21
  store i1 %t160, ptr %l91, !tbaa !21
  br label %bb32
bb32:
  %t161 = load i1, ptr %l91, !tbaa !21
  br i1 %t161, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l97, !tbaa !29
  %t163 = load ptr, ptr %l0, !tbaa !29
  %t165 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v0, ptr %t163)
  store ptr %t165, ptr %l99
  br label %bb35
bb34:
  br label %bb40
bb35:
  %t166 = load i32, ptr %l11, !tbaa !23
  %t167 = load ptr, ptr %l99, !tbaa !29
  %t169 = call %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %t167, i32 %t166)
  store %"compiler/typed:Local" %t169, ptr %l101
  br label %bb36
bb36:
  %t170 = getelementptr %"compiler/typed:Local", ptr %l101, i32 0, i32 1
  %t171 = load %"compiler/source:Span", ptr %t170
  store %"compiler/source:Span" %t171, ptr %l102
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t173 = load i32, ptr %l12, !tbaa !23
  %t176 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s4, ptr %t172, i32 %t173)
  store { i64, ptr } %t176, ptr %l105
  br label %bb37
bb37:
  %t177 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t185 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructGenParam(ptr %s4, ptr %s4, { i64, ptr } %t183)
  store %"compiler/diagmsg:Msg" %t185, ptr %l107
  br label %bb38
bb38:
  %t186 = load ptr, ptr %l97, !tbaa !29
  %t187 = load %"compiler/source:Span", ptr %l102
  %t188 = load %"compiler/diagmsg:Msg", ptr %l107
  %t189 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s4, ptr %t186, %"compiler/source:Span" %t187, %"compiler/diagmsg:Msg" %t188)
  store i64 %t189, ptr %l108
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s4)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t190 = load i64, ptr %l10, !tbaa !24
  %t192 = add i64 %t190, 1
  store i64 %t192, ptr %l10, !tbaa !24
  br label %bb18
bb42:
  store i64 -1, ptr %l13, !tbaa !24
  %t194 = load i64, ptr %l3, !tbaa !24
  %t195 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenFromReturn, !tbaa !24
  %t198 = icmp eq i64 %t194, %t195
  br i1 %t198, label %bb43, label %bb44
bb43:
  %t200 = load ptr, ptr %l0, !tbaa !29
  %t202 = getelementptr %"compiler/check:Checker", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t205 = getelementptr %"compiler/generic:Program", ptr %t203, i32 0, i32 2
  %t206 = load i32, ptr %l6, !tbaa !23
  %t207 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t208 = load i64, ptr @G_2ecompiler_2ftypes_2eNullable, !tbaa !24
  %t211 = or i64 %t207, %t208
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t205, i32 %t206, i64 %t211)
  store i32 %t215, ptr %l121
  br label %bb45
bb44:
  br label %bb49
bb45:
  %t216 = load i32, ptr %l121, !tbaa !23
  store i32 %t216, ptr %l14, !tbaa !23
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t218 = load %"compiler/source:Span", ptr %l4
  %t219 = load i32, ptr %l14, !tbaa !23
  store { i64, [1 x i64] } zeroinitializer, ptr %t220
  %t221 = getelementptr { i64, [1 x i64] }, ptr %t220, i32 0, i32 0
  store i64 3, ptr %t221
  %t222 = load { i64, [1 x i64] }, ptr %t220
  %t228 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t217, i32 0, %"compiler/source:Span" %t218, i32 %t219, i32 3, { i64, [1 x i64] } %t222)
  store i64 %t228, ptr %l127
  br label %bb46
bb46:
  %t229 = load i64, ptr %l127, !tbaa !24
  store i64 %t229, ptr %l13, !tbaa !24
  %t230 = load ptr, ptr %l0, !tbaa !29
  store ptr %t230, ptr %l128, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t231, ptr %l129
  %t232 = load i64, ptr %l13, !tbaa !24
  %t234 = trunc i64 %t232 to i32
  store i32 %t234, ptr %l132, !tbaa !23
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t237 = load %"compiler/source:Span", ptr %l4
  %t238 = load i32, ptr %l14, !tbaa !23
  %t242 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v0, ptr %t236, %"compiler/source:Span" %t237, i32 %t238, i64 0)
  store ptr %t242, ptr %l136
  br label %bb47
bb47:
  store { i64, [3 x i64] } zeroinitializer, ptr %t243
  %t244 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 0
  store i64 0, ptr %t244
  %t245 = load %"compiler/source:Span", ptr %l129
  %t246 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t245, 0
  %t247 = load i32, ptr %l132, !tbaa !23
  %t248 = insertvalue { %"compiler/source:Span", i32, ptr } %t246, i32 %t247, 1
  %t249 = load ptr, ptr %l136, !tbaa !29
  %t250 = insertvalue { %"compiler/source:Span", i32, ptr } %t248, ptr %t249, 2
  %t251 = getelementptr { i64, [3 x i64] }, ptr %t243, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t250, ptr %t251
  %t252 = load { i64, [3 x i64] }, ptr %t243
  %t254 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t252, ptr %t254
  %t255 = load ptr, ptr %l128, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t255, ptr %t254)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load ptr, ptr %l1, !tbaa !29
  %t259 = load i32, ptr %l8, !tbaa !23
  %t260 = load i64, ptr %l3, !tbaa !24
  %t261 = load i64, ptr %l13, !tbaa !24
  %t267 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %v2, ptr %t257, ptr %t258, i32 %t259, i64 %t260, i64 %t261)
  store ptr %t267, ptr %l144
  br label %bb50
bb50:
  %t268 = load ptr, ptr %l144, !tbaa !29
  store ptr %t268, ptr %l15, !tbaa !29
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i32, ptr %l6, !tbaa !23
  %t273 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ectorBody(ptr %v0, ptr %t269, i32 %t270)
  store i64 %t273, ptr %l147
  br label %bb51
bb51:
  %t274 = load i64, ptr %l147, !tbaa !24
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/check:Checker", ptr %t275, i32 0, i32 23
  %t278 = load i32, ptr %t277, !tbaa !23
  store i32 %t278, ptr %l17, !tbaa !23
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t281 = load i32, ptr %l6, !tbaa !23
  %t284 = getelementptr %"compiler/check:Checker", ptr %t280, i32 0, i32 23
  store i32 %t281, ptr %t284, !tbaa !23
  %t285 = load ptr, ptr %l0, !tbaa !29
  store ptr %t285, ptr %l152, !tbaa !29
  %t286 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t286, ptr %l153
  %t287 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t287, ptr %l154
  %t288 = load i32, ptr %l7, !tbaa !23
  store i32 %t288, ptr %l155, !tbaa !23
  %t291 = trunc i64 %t274 to i32
  store { i64, [3 x i64] } zeroinitializer, ptr %t293
  %t294 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 0
  store i64 0, ptr %t294
  %t296 = insertvalue { i32 } undef, i32 %t291, 0
  %t297 = getelementptr { i64, [3 x i64] }, ptr %t293, i32 0, i32 1
  store { i32 } %t296, ptr %t297
  %t298 = load { i64, [3 x i64] }, ptr %t293
  %t300 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store { i64, [3 x i64] } %t298, ptr %t300
  store ptr %t300, ptr %l160, !tbaa !29
  %t301 = icmp sge i64 0, 0
  br i1 %t301, label %bb52, label %bb53
bb52:
  %t303 = icmp sle i64 0, 1152921504606846975
  br i1 %t303, label %bb54, label %bb55
bb53:
  call void @__olang_check_failed(ptr @olang_loc_8107208a4245ff9c_ccbe9a9f570baf38)
  unreachable
bb54:
  %t305 = mul i64 0, 8
  %t306 = insertvalue { i64, ptr } undef, i64 0, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t308 = load ptr, ptr %l15, !tbaa !29
  %t309 = mul i64 1, 8
  %t310 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t309)
  %t311 = insertvalue { i64, ptr } undef, i64 1, 0
  %t312 = insertvalue { i64, ptr } %t311, ptr %t310, 1
  store { i64, ptr } %t312, ptr %l165, !tbaa !27
  %t314 = getelementptr { i64, ptr }, ptr %l165, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr ptr, ptr %t315, i64 0
  store ptr %t308, ptr %t316, !tbaa !39
  %t317 = load ptr, ptr %l152, !tbaa !29
  %t318 = load %"compiler/source:Span", ptr %l153
  %t319 = load %"compiler/source:Span", ptr %l154
  %t320 = load i32, ptr %l155, !tbaa !23
  %t321 = load ptr, ptr %l160, !tbaa !29
  %t323 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t324 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v2, ptr %v0, ptr %v0, ptr %v0, ptr %v2, ptr %t317, %"compiler/source:Span" %t318, %"compiler/source:Span" %t319, i32 %t320, ptr %t321, i64 -1, ptr null, { i64, ptr } %t307, { i64, ptr } %t323)
  store ptr %t324, ptr %l166
  br label %bb56
bb55:
  call void @__olang_check_failed(ptr @olang_loc_8107208a4245ff9c_ccbe9a9f570baf38)
  unreachable
bb56:
  %t325 = load ptr, ptr %l166, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t327 = load i32, ptr %l17, !tbaa !23
  %t330 = getelementptr %"compiler/check:Checker", ptr %t326, i32 0, i32 23
  store i32 %t327, ptr %t330, !tbaa !23
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load %"compiler/source:Span", ptr %l4
  store { i64, [3 x i64] } zeroinitializer, ptr %t335
  %t336 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 0
  store i64 6, ptr %t336
  %t338 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t332, 0
  %t340 = insertvalue { %"compiler/source:Span", ptr } %t338, ptr %t325, 1
  %t341 = getelementptr { i64, [3 x i64] }, ptr %t335, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t340, ptr %t341
  %t342 = load { i64, [3 x i64] }, ptr %t335
  %t344 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t342, ptr %t344
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t331, ptr %t344)
  br label %bb57
bb57:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = getelementptr %"compiler/check:Checker", ptr %t347, i32 0, i32 37
  %t350 = load i64, ptr %l5, !tbaa !24
  %t353 = call { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t349, i64 %t350)
  store { i64, ptr } %t353, ptr %l178
  br label %bb58
bb58:
  %t354 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t355 = call %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v2, i32 0, { i64, ptr } %t354)
  store %"compiler/typed:Block" %t355, ptr %l179
  br label %bb59
bb59:
  %t356 = load %"compiler/typed:Block", ptr %l179
  %t357 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/typed:Block" %t356, ptr %t357
  call void @__olang_scope_close(ptr %s0)
  store ptr %t357, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egrowViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i64 %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sle i64 %t1, 0
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, i64 } %t9, 1
  %t11 = extractvalue { i32, i64 } %t9, 0
  store i32 %t11, ptr %l11
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb5, label %ok.13, !prof !99
ok.13:
  store i64 %t10, ptr %l10
  br label %bb4
bb4:
  %t14 = load i64, ptr %l10, !tbaa !24
  store i64 %t14, ptr %l7, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t15 = load i64, ptr %l7, !tbaa !24
  store i64 %t15, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t17 = load i64, ptr %l3, !tbaa !24
  %t20 = or i64 %t16, %t17
  %t21 = load i64, ptr %l4, !tbaa !24
  %t24 = icmp eq i64 %t20, %t21
  br i1 %t24, label %bb8, label %bb9
bb8:
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t27 = load i64, ptr %l2, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = or i64 %t28, %t29
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v1, ptr %t26, i64 %t27, i64 %t32)
  br label %bb11
bb11:
  %t38 = getelementptr %"compiler/check:Checker", ptr %a0, i32 0, i32 70
  store i1 true, ptr %t38, !tbaa !21
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ehandlesContracts(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca i64
  %l15 = alloca i32
  %l19 = alloca i1
  %l23 = alloca i32
  %l29 = alloca i64
  %l33 = alloca i64
  %l36 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l63 = alloca i1
  %l67 = alloca %"compiler/check:ContractAsk"
  %l69 = alloca i1
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t109 = alloca %"compiler/check:ContractAsk", align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v1, ptr %t1)
  store i64 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i64, ptr %l11, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s0, ptr %s0, ptr %t10, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d23, i32 0, i32 1) }, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d24, i32 0, i32 1) })
  store i32 %t12, ptr %l15
  br label %bb5
bb5:
  %t13 = load i32, ptr %l15, !tbaa !23
  store i32 %t13, ptr %l3, !tbaa !23
  %t14 = load i32, ptr %l3, !tbaa !23
  %t15 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = icmp eq i32 %t14, %t15
  br i1 %t18, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb9
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i32, ptr %l3, !tbaa !23
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t26 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %t20, i32 %t21, ptr %t22)
  store i32 %t26, ptr %l23
  br label %bb8
bb8:
  %t27 = load i32, ptr %l3, !tbaa !23
  %t28 = load i32, ptr %l23, !tbaa !23
  %t30 = icmp eq i32 %t28, %t27
  store i1 %t30, ptr %l19, !tbaa !21
  br label %bb9
bb9:
  %t32 = load i1, ptr %l19, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb11:
  br label %bb12
bb12:
  store i64 %a1, ptr %l4, !tbaa !24
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/check:Checker", ptr %t35, i32 0, i32 118
  %t39 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %t37)
  store i64 %t39, ptr %l29
  br label %bb13
bb13:
  %t40 = load i64, ptr %l29, !tbaa !24
  store i64 %t40, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t41 = load i64, ptr %l5, !tbaa !24
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = icmp sgt i64 %t41, %t42
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t49 = icmp sgt i64 %t47, 0
  br i1 %t49, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb19
bb16:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l4, !tbaa !24
  %t55 = sub i64 %t51, %t52
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = add i64 %t55, %t56
  %t61 = sub i64 %t59, 1
  %t62 = load i64, ptr %l6, !tbaa !24
  %t65 = sdiv i64 %t61, %t62
  store i64 %t65, ptr %l36, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb18
bb18:
  %t67 = load i64, ptr %l36, !tbaa !24
  store i64 %t67, ptr %l33, !tbaa !24
  br label %bb19
bb19:
  %t68 = load i64, ptr %l33, !tbaa !24
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t69 = load i64, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t73 = icmp slt i64 %t69, %t70
  %t75 = xor i1 %t73, true
  br i1 %t75, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s4)
  br label %bb36
bb22:
  br label %bb23
bb23:
  %t77 = load i64, ptr %l4, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  %t82 = mul i64 %t78, %t79
  %t85 = add i64 %t77, %t82
  store i64 %t85, ptr %l9, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 119
  %t90 = load i64, ptr %l9, !tbaa !24
  %t93 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  store i64 %t93, ptr %l57
  br label %bb24
bb24:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t94)
  store ptr %t96, ptr %l59
  br label %bb25
bb25:
  %t97 = load ptr, ptr %l59, !tbaa !29
  %t99 = getelementptr %"compiler/check:frame", ptr %t97, i32 0, i32 0
  %t100 = load i64, ptr %t99, !tbaa !24
  %t101 = load i64, ptr %l57, !tbaa !24
  %t103 = icmp eq i64 %t101, %t100
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/check:Checker", ptr %t105, i32 0, i32 118
  %t108 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eAt_H56c1cddaee4bc4aa5c09605de1331e44(ptr %t109, ptr %v0, ptr %v0, ptr %t107, i64 %t108)
  call void @llvm.memmove.p0.p0.i64(ptr %l67, ptr %t109, i64 136, i1 false)
  br label %bb28
bb27:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb30
bb28:
  %t112 = getelementptr %"compiler/check:ContractAsk", ptr %l67, i32 0, i32 5
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t115 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t113, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  store i1 %t115, ptr %l69
  br label %bb29
bb29:
  %t116 = load i1, ptr %l69, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l63, !tbaa !21
  br label %bb30
bb30:
  %t119 = load i1, ptr %l63, !tbaa !21
  br i1 %t119, label %bb31, label %bb32
bb31:
  %t120 = load ptr, ptr %l0, !tbaa !29
  %t122 = getelementptr %"compiler/check:Checker", ptr %t120, i32 0, i32 120
  %t123 = load i64, ptr %l9, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %t122, i64 %t123, i1 true)
  br label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s4)
  br label %bb35
bb35:
  %t126 = load i64, ptr %l8, !tbaa !24
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l8, !tbaa !24
  br label %bb20
bb36:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eheldOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l6 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca %"compiler/source:Span"
  %l19 = alloca i32
  %l22 = alloca i64
  %l31 = alloca %"compiler/source:Span"
  %l34 = alloca i32
  %rv = alloca ptr
  %t28 = alloca { i64, [1 x i64] }, align 8
  %t45 = alloca { i64, [3 x i64] }, align 8
  %t68 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ereadPlace(ptr %v1, ptr %v2, ptr %t1)
  store ptr %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l6, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load ptr, ptr %l3, !tbaa !29
  store ptr %t11, ptr %l10, !tbaa !29
  store i1 false, ptr %l11, !tbaa !21
  %t12 = load ptr, ptr %l10, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb4, label %bb5
bb3:
  br label %bb15
bb4:
  %t15 = load ptr, ptr %l10, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 8}
  %t18 = icmp eq i64 %t16, 0
  store i1 %t18, ptr %l11, !tbaa !21
  br label %bb5
bb5:
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t20 = load ptr, ptr %l3, !tbaa !29
  store ptr %t20, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_ab1100555885b989_2cac6a0e3d43e9fd)
  unreachable
bb14:
  br label %bb15
bb15:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l15, !tbaa !29
  %t23 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t23, ptr %l16
  %t24 = load ptr, ptr %l2, !tbaa !29
  %t27 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t24)
  store i32 %t27, ptr %l19
  br label %bb16
bb16:
  store { i64, [1 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [1 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [1 x i64] }, ptr %t28
  %t31 = load ptr, ptr %l15, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l16
  %t33 = load i32, ptr %l19, !tbaa !23
  %t36 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %t31, i32 0, %"compiler/source:Span" %t32, i32 %t33, i32 2, { i64, [1 x i64] } %t30)
  store i64 %t36, ptr %l22
  br label %bb17
bb17:
  %t37 = load i64, ptr %l22, !tbaa !24
  store i64 %t37, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l1
  %t40 = load i64, ptr %l4, !tbaa !24
  %t42 = trunc i64 %t40 to i32
  %t44 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t45
  %t46 = getelementptr { i64, [3 x i64] }, ptr %t45, i32 0, i32 0
  store i64 0, ptr %t46
  %t48 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t39, 0
  %t50 = insertvalue { %"compiler/source:Span", i32, ptr } %t48, i32 %t42, 1
  %t52 = insertvalue { %"compiler/source:Span", i32, ptr } %t50, ptr %t44, 2
  %t53 = getelementptr { i64, [3 x i64] }, ptr %t45, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t52, ptr %t53
  %t54 = load { i64, [3 x i64] }, ptr %t45
  %t56 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t54, ptr %t56
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t38, ptr %t56)
  br label %bb18
bb18:
  %t59 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t59, ptr %l31
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t63 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t60)
  store i32 %t63, ptr %l34
  br label %bb19
bb19:
  %t64 = load i64, ptr %l4, !tbaa !24
  %t66 = trunc i64 %t64 to i32
  store { i64, [4 x i64] } zeroinitializer, ptr %t68
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 0
  store i64 0, ptr %t69
  %t70 = load %"compiler/source:Span", ptr %l31
  %t71 = insertvalue { %"compiler/source:Span", i32, i32 } undef, %"compiler/source:Span" %t70, 0
  %t72 = load i32, ptr %l34, !tbaa !23
  %t73 = insertvalue { %"compiler/source:Span", i32, i32 } %t71, i32 %t72, 1
  %t75 = insertvalue { %"compiler/source:Span", i32, i32 } %t73, i32 %t66, 2
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t68, i32 0, i32 1
  store { %"compiler/source:Span", i32, i32 } %t75, ptr %t76
  %t77 = load { i64, [4 x i64] }, ptr %t68
  %t79 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t77, ptr %t79
  store ptr %t79, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l17 = alloca i32
  %l24 = alloca i32
  %l31 = alloca i1
  %l36 = alloca i32
  %l39 = alloca ptr
  %l44 = alloca i32
  %l47 = alloca i1
  %l50 = alloca ptr
  %l55 = alloca i32
  %l58 = alloca i1
  %l61 = alloca ptr
  %l66 = alloca i32
  %l70 = alloca i1
  %l78 = alloca i32
  %l81 = alloca ptr
  %l86 = alloca i32
  %l90 = alloca i1
  %l95 = alloca ptr
  %l100 = alloca i32
  %l103 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = getelementptr %"compiler/generic:Program", ptr %t16, i32 0, i32 2
  %t19 = load i32, ptr %l1, !tbaa !23
  %t22 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t18, i32 %t19)
  store i32 %t22, ptr %l17
  br label %bb7
bb7:
  %t23 = load i32, ptr %l17, !range !{i32 0, i32 33}
  store i32 %t23, ptr %l4
  %t24 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t26 = trunc i64 18 to i32
  %t27 = icmp eq i32 %t24, %t26
  br i1 %t27, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb35
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/check:Checker", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  %t34 = getelementptr %"compiler/generic:Program", ptr %t32, i32 0, i32 2
  %t35 = load i32, ptr %l1, !tbaa !23
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t38, ptr %l24
  br label %bb11
bb11:
  %t39 = load i32, ptr %l2, !tbaa !23
  %t40 = load i32, ptr %l24, !tbaa !23
  %t42 = icmp eq i32 %t40, %t39
  br i1 %t42, label %bb12, label %bb13
bb12:
  store i1 true, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t45, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t48, i32 %t49)
  store i1 %t52, ptr %l31
  br label %bb15
bb15:
  %t53 = load i1, ptr %l31, !tbaa !21
  %t54 = xor i1 %t53, true
  br i1 %t54, label %bb16, label %bb17
bb16:
  store i1 false, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t58 = load i32, ptr %l1, !tbaa !23
  %t61 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l36
  br label %bb19
bb19:
  %t62 = load i32, ptr %l36, !range !{i32 0, i32 6}
  store i32 %t62, ptr %l5
  %t63 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t65 = trunc i64 0 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb20, label %bb21
bb20:
  %t68 = load ptr, ptr %l0, !tbaa !29
  store ptr %t68, ptr %l39, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load i32, ptr %l1, !tbaa !23
  %t78 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t74, i32 %t75)
  store i32 %t78, ptr %l44
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t79 = load i32, ptr %l2, !tbaa !23
  %t80 = load i64, ptr %l3, !tbaa !24
  %t81 = load ptr, ptr %l39, !tbaa !29
  %t82 = load i32, ptr %l44, !tbaa !23
  %t85 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t81, i32 %t82, i32 %t79, i64 %t80)
  store i1 %t85, ptr %l47
  br label %bb23
bb23:
  %t86 = load i1, ptr %l47, !tbaa !21
  store i1 %t86, ptr %rv
  br label %ret
bb24:
  %t87 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t89 = trunc i64 1 to i32
  %t90 = icmp eq i32 %t87, %t89
  br i1 %t90, label %bb25, label %bb26
bb25:
  %t92 = load ptr, ptr %l0, !tbaa !29
  store ptr %t92, ptr %l50, !tbaa !29
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/check:Checker", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t98 = getelementptr %"compiler/generic:Program", ptr %t96, i32 0, i32 2
  %t99 = load i32, ptr %l1, !tbaa !23
  %t102 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t98, i32 %t99)
  store i32 %t102, ptr %l55
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t103 = load i32, ptr %l2, !tbaa !23
  %t104 = load i64, ptr %l3, !tbaa !24
  %t105 = load ptr, ptr %l50, !tbaa !29
  %t106 = load i32, ptr %l55, !tbaa !23
  %t109 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t105, i32 %t106, i32 %t103, i64 %t104)
  store i1 %t109, ptr %l58
  br label %bb28
bb28:
  %t110 = load i1, ptr %l58, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
bb29:
  %t111 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t113 = trunc i64 4 to i32
  %t114 = icmp eq i32 %t111, %t113
  br i1 %t114, label %bb30, label %bb31
bb30:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l61, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/check:Checker", ptr %t117, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !29
  %t122 = getelementptr %"compiler/generic:Program", ptr %t120, i32 0, i32 2
  %t123 = load i32, ptr %l1, !tbaa !23
  %t126 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t122, i32 %t123)
  store i32 %t126, ptr %l66
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t127 = load i32, ptr %l2, !tbaa !23
  %t128 = load i64, ptr %l3, !tbaa !24
  %t130 = add i64 %t128, 1
  %t131 = load ptr, ptr %l61, !tbaa !29
  %t132 = load i32, ptr %l66, !tbaa !23
  %t135 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t131, i32 %t132, i32 %t127, i64 %t130)
  store i1 %t135, ptr %l70
  br label %bb33
bb33:
  %t136 = load i1, ptr %l70, !tbaa !21
  store i1 %t136, ptr %rv
  br label %ret
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  %t138 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t140 = trunc i64 19 to i32
  %t141 = icmp eq i32 %t138, %t140
  br i1 %t141, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  br label %bb45
bb38:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  %t149 = load i32, ptr %l1, !tbaa !23
  %t152 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t148, i32 %t149)
  store i32 %t152, ptr %l78
  br label %bb39
bb39:
  %t153 = load i32, ptr %l78, !tbaa !23
  %t154 = icmp eq i32 %t153, 0
  br i1 %t154, label %bb40, label %bb41
bb40:
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t157 = load ptr, ptr %l0, !tbaa !29
  store ptr %t157, ptr %l81, !tbaa !29
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr %"compiler/check:Checker", ptr %t158, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = getelementptr %"compiler/generic:Program", ptr %t161, i32 0, i32 2
  %t164 = load i32, ptr %l1, !tbaa !23
  %t167 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t163, i32 %t164)
  store i32 %t167, ptr %l86
  br label %bb43
bb43:
  %t168 = load i32, ptr %l2, !tbaa !23
  %t169 = load i64, ptr %l3, !tbaa !24
  %t171 = add i64 %t169, 1
  %t172 = load ptr, ptr %l81, !tbaa !29
  %t173 = load i32, ptr %l86, !tbaa !23
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsBy(ptr %v0, ptr %t172, i32 %t173, i32 %t168, i64 %t171)
  store i1 %t176, ptr %l90
  br label %bb44
bb44:
  %t177 = load i1, ptr %l90, !tbaa !21
  store i1 %t177, ptr %rv
  br label %ret
bb45:
  %t178 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t180 = trunc i64 22 to i32
  %t181 = icmp eq i32 %t178, %t180
  br i1 %t181, label %bb46, label %bb47
bb46:
  br label %bb50
bb47:
  %t183 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t185 = trunc i64 23 to i32
  %t186 = icmp eq i32 %t183, %t185
  br i1 %t186, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb53
bb50:
  %t188 = load ptr, ptr %l0, !tbaa !29
  store ptr %t188, ptr %l95, !tbaa !29
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/check:Checker", ptr %t189, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/generic:Program", ptr %t192, i32 0, i32 2
  %t195 = load i32, ptr %l1, !tbaa !23
  %t198 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t194, i32 %t195)
  store i32 %t198, ptr %l100
  br label %bb51
bb51:
  %t199 = load i32, ptr %l2, !tbaa !23
  %t200 = load i64, ptr %l3, !tbaa !24
  %t201 = load ptr, ptr %l95, !tbaa !29
  %t202 = load i32, ptr %l100, !tbaa !23
  %t205 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %t201, i32 %t202, i32 %t199, i64 %t200)
  store i1 %t205, ptr %l103
  br label %bb52
bb52:
  %t206 = load i1, ptr %l103, !tbaa !21
  store i1 %t206, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_4d3e518c37f06fac_dc2de6c574f30d28)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l8 = alloca i1
  %l21 = alloca i32
  %l27 = alloca i1
  %l32 = alloca i32
  %l35 = alloca ptr
  %l40 = alloca i32
  %l43 = alloca i1
  %l46 = alloca ptr
  %l51 = alloca i32
  %l54 = alloca i1
  %l57 = alloca ptr
  %l62 = alloca i32
  %l66 = alloca i1
  %l74 = alloca i32
  %l77 = alloca ptr
  %l82 = alloca i32
  %l86 = alloca i1
  %l91 = alloca ptr
  %l96 = alloca i32
  %l99 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l3, !tbaa !24
  %t3 = icmp sgt i64 %t1, 16
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t5 = load i32, ptr %l1, !tbaa !23
  %t6 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t9 = icmp eq i32 %t5, %t6
  store i1 %t9, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l8, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 false, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t13 = load i32, ptr %l1, !tbaa !23
  %t14 = load i32, ptr %l2, !tbaa !23
  %t17 = icmp eq i32 %t13, %t14
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l21
  br label %bb10
bb10:
  %t30 = load i32, ptr %l21, !range !{i32 0, i32 33}
  store i32 %t30, ptr %l4
  %t31 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t33 = trunc i64 18 to i32
  %t34 = icmp eq i32 %t31, %t33
  br i1 %t34, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb34
bb13:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/check:Checker", ptr %t36, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !29
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l27
  br label %bb14
bb14:
  %t44 = load i1, ptr %l27, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t49 = load i32, ptr %l1, !tbaa !23
  %t52 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %t48, i32 %t49)
  store i32 %t52, ptr %l32
  br label %bb18
bb18:
  %t53 = load i32, ptr %l32, !range !{i32 0, i32 6}
  store i32 %t53, ptr %l5
  %t54 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t56 = trunc i64 0 to i32
  %t57 = icmp eq i32 %t54, %t56
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l35, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !29
  %t65 = getelementptr %"compiler/generic:Program", ptr %t63, i32 0, i32 2
  %t66 = load i32, ptr %l1, !tbaa !23
  %t69 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t65, i32 %t66)
  store i32 %t69, ptr %l40
  br label %bb21
bb20:
  br label %bb23
bb21:
  %t70 = load i32, ptr %l2, !tbaa !23
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load ptr, ptr %l35, !tbaa !29
  %t73 = load i32, ptr %l40, !tbaa !23
  %t76 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t72, i32 %t73, i32 %t70, i64 %t71)
  store i1 %t76, ptr %l43
  br label %bb22
bb22:
  %t77 = load i1, ptr %l43, !tbaa !21
  store i1 %t77, ptr %rv
  br label %ret
bb23:
  %t78 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t80 = trunc i64 1 to i32
  %t81 = icmp eq i32 %t78, %t80
  br i1 %t81, label %bb24, label %bb25
bb24:
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l46, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l1, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l51
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t94 = load i32, ptr %l2, !tbaa !23
  %t95 = load i64, ptr %l3, !tbaa !24
  %t96 = load ptr, ptr %l46, !tbaa !29
  %t97 = load i32, ptr %l51, !tbaa !23
  %t100 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t96, i32 %t97, i32 %t94, i64 %t95)
  store i1 %t100, ptr %l54
  br label %bb27
bb27:
  %t101 = load i1, ptr %l54, !tbaa !21
  store i1 %t101, ptr %rv
  br label %ret
bb28:
  %t102 = load i32, ptr %l5, !range !{i32 0, i32 6}
  %t104 = trunc i64 4 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l57, !tbaa !29
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/generic:Program", ptr %t111, i32 0, i32 2
  %t114 = load i32, ptr %l1, !tbaa !23
  %t117 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t113, i32 %t114)
  store i32 %t117, ptr %l62
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t118 = load i32, ptr %l2, !tbaa !23
  %t119 = load i64, ptr %l3, !tbaa !24
  %t121 = add i64 %t119, 1
  %t122 = load ptr, ptr %l57, !tbaa !29
  %t123 = load i32, ptr %l62, !tbaa !23
  %t126 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t122, i32 %t123, i32 %t118, i64 %t121)
  store i1 %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load i1, ptr %l66, !tbaa !21
  store i1 %t127, ptr %rv
  br label %ret
bb33:
  store i1 false, ptr %rv
  br label %ret
bb34:
  %t129 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t131 = trunc i64 19 to i32
  %t132 = icmp eq i32 %t129, %t131
  br i1 %t132, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  br label %bb44
bb37:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l1, !tbaa !23
  %t143 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t139, i32 %t140)
  store i32 %t143, ptr %l74
  br label %bb38
bb38:
  %t144 = load i32, ptr %l74, !tbaa !23
  %t145 = icmp eq i32 %t144, 0
  br i1 %t145, label %bb39, label %bb40
bb39:
  store i1 false, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t148 = load ptr, ptr %l0, !tbaa !29
  store ptr %t148, ptr %l77, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = getelementptr %"compiler/check:Checker", ptr %t149, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !29
  %t154 = getelementptr %"compiler/generic:Program", ptr %t152, i32 0, i32 2
  %t155 = load i32, ptr %l1, !tbaa !23
  %t158 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t154, i32 %t155)
  store i32 %t158, ptr %l82
  br label %bb42
bb42:
  %t159 = load i32, ptr %l2, !tbaa !23
  %t160 = load i64, ptr %l3, !tbaa !24
  %t162 = add i64 %t160, 1
  %t163 = load ptr, ptr %l77, !tbaa !29
  %t164 = load i32, ptr %l82, !tbaa !23
  %t167 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsInst(ptr %v0, ptr %t163, i32 %t164, i32 %t159, i64 %t162)
  store i1 %t167, ptr %l86
  br label %bb43
bb43:
  %t168 = load i1, ptr %l86, !tbaa !21
  store i1 %t168, ptr %rv
  br label %ret
bb44:
  %t169 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t171 = trunc i64 22 to i32
  %t172 = icmp eq i32 %t169, %t171
  br i1 %t172, label %bb45, label %bb46
bb45:
  br label %bb49
bb46:
  %t174 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t176 = trunc i64 23 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t179 = load ptr, ptr %l0, !tbaa !29
  store ptr %t179, ptr %l91, !tbaa !29
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/check:Checker", ptr %t180, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = getelementptr %"compiler/generic:Program", ptr %t183, i32 0, i32 2
  %t186 = load i32, ptr %l1, !tbaa !23
  %t189 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %t185, i32 %t186)
  store i32 %t189, ptr %l96
  br label %bb50
bb50:
  %t190 = load i32, ptr %l2, !tbaa !23
  %t191 = load i64, ptr %l3, !tbaa !24
  %t192 = load ptr, ptr %l91, !tbaa !29
  %t193 = load i32, ptr %l96, !tbaa !23
  %t196 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %t192, i32 %t193, i32 %t190, i64 %t191)
  store i1 %t196, ptr %l99
  br label %bb51
bb51:
  %t197 = load i1, ptr %l99, !tbaa !21
  store i1 %t197, ptr %rv
  br label %ret
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store i1 false, ptr %rv
  br label %ret
bb56:
  call void @__olang_check_failed(ptr @olang_loc_aed268118a11ee23_4542719cec09658f)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eitemOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca i1
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 8
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t18, i32 0, i32 2
  %t20 = load ptr, ptr %t19
  store ptr %t20, ptr %l4, !tbaa !29
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t22 = load i32, ptr %l3, !tbaa !23
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = insertvalue { i32, ptr } undef, i32 %t22, 0
  %t27 = insertvalue { i32, ptr } %t25, ptr %t23, 1
  store { i32, ptr } %t27, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  store i1 false, ptr %l18, !tbaa !21
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = icmp ne ptr %t30, null
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l17, !tbaa !29
  %t34 = load i64, ptr %t33, !range !{i64 0, i64 9}
  %t36 = icmp eq i64 %t34, 3
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb8
bb8:
  %t37 = load i1, ptr %l18, !tbaa !21
  br i1 %t37, label %bb9, label %bb10
bb9:
  %t38 = load ptr, ptr %l1, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", i32 }, ptr %t40, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l5, !tbaa !23
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t46 = getelementptr %"compiler/check:fieldSet", ptr %a2, i32 0, i32 1
  %t47 = load i32, ptr %t46, !tbaa !23
  %t49 = icmp sge i32 %t47, 0
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t51 = load i32, ptr %l5, !tbaa !23
  %t52 = load ptr, ptr %l1, !tbaa !29
  %t54 = insertvalue { i32, ptr } undef, i32 %t51, 0
  %t56 = insertvalue { i32, ptr } %t54, ptr %t52, 1
  store { i32, ptr } %t56, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  br label %bb20
bb15:
  br i1 true, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_a8dc05ade1085e71_1f4ef85bbb60cc55)
  unreachable
bb20:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t59 = insertvalue { i32, ptr } undef, i32 0, 0
  %t61 = insertvalue { i32, ptr } %t59, ptr %t58, 1
  store { i32, ptr } %t61, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, i64 %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l19 = alloca %"compiler/check:laneNode"
  %l23 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i32
  %l33 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca %"compiler/source:Span"
  %l40 = alloca i32
  %l44 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l49 = alloca %"compiler/source:Span"
  %l50 = alloca i32
  %l54 = alloca %"compiler/typed:Elem"
  %l58 = alloca ptr
  %l62 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i32
  %l76 = alloca ptr
  %l85 = alloca ptr
  %l91 = alloca i1
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca ptr
  %l111 = alloca ptr
  %l117 = alloca ptr
  %l123 = alloca ptr
  %l129 = alloca ptr
  %l130 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %l132 = alloca ptr
  %l137 = alloca ptr
  %l138 = alloca ptr
  %l143 = alloca ptr
  %l144 = alloca %"compiler/typed:Cond"
  %l153 = alloca ptr
  %l159 = alloca ptr
  %l162 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca ptr
  %l167 = alloca %"compiler/source:Span"
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l172 = alloca i1
  %l174 = alloca i1
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l177 = alloca %"compiler/source:Span"
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l182 = alloca i1
  %l186 = alloca ptr
  %l189 = alloca %"compiler/source:Span"
  %l190 = alloca i32
  %l191 = alloca ptr
  %l193 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca %"compiler/typed:Cond"
  %l202 = alloca %"compiler/source:Span"
  %l203 = alloca i32
  %l204 = alloca ptr
  %l208 = alloca ptr
  %l211 = alloca %"compiler/typed:Cond"
  %l215 = alloca ptr
  %l224 = alloca ptr
  %l225 = alloca ptr
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca ptr
  %t61 = alloca { i64, [4 x i64] }, align 8
  %t88 = alloca { i64, [4 x i64] }, align 8
  %t322 = alloca { i64, [5 x i64] }, align 8
  %t470 = alloca { i64, [5 x i64] }, align 8
  %t505 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i64 %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 39
  %t4 = load i64, ptr %l2, !tbaa !24
  %t7 = call %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v3, ptr %t3, i64 %t4)
  store %"compiler/check:laneNode" %t7, ptr %l19
  br label %bb1
bb1:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 88, i64 8)
  store ptr %t8, ptr %lp5
  %t9 = load %"compiler/check:laneNode", ptr %l19
  %t10 = load ptr, ptr %lp5
  store %"compiler/check:laneNode" %t9, ptr %t10
  %t11 = load ptr, ptr %lp5
  %t12 = getelementptr %"compiler/check:laneNode", ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneArr, !tbaa !24
  %t17 = icmp eq i64 %t13, %t14
  br i1 %t17, label %bb2, label %bb3
bb2:
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:laneVals", ptr %t19, i32 0, i32 1
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t21, i64 %t22)
  %t26 = extractvalue { i32, i64 } %t25, 1
  %t27 = extractvalue { i32, i64 } %t25, 0
  store i32 %t27, ptr %l28
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb5, label %ok.29, !prof !99
ok.29:
  store i64 %t26, ptr %l27
  br label %bb4
bb3:
  br label %bb17
bb4:
  %t30 = load i64, ptr %l27, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  br label %bb7
bb5:
  br label %bb6
bb6:
  store i64 -1, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  %t31 = load i64, ptr %l23, !tbaa !24
  store i64 %t31, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l6, !tbaa !24
  %t34 = icmp slt i64 %t32, 0
  br i1 %t34, label %bb8, label %bb9
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t37 = load %"compiler/source:Span", ptr %l1
  %t40 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t36, %"compiler/source:Span" %t37)
  store ptr %t40, ptr %l33
  br label %bb10
bb9:
  br label %bb11
bb10:
  %t41 = load ptr, ptr %l33, !tbaa !29
  store ptr %t41, ptr %rv
  br label %ret
bb11:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i64, ptr %l6, !tbaa !24
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %t42, i64 %t43)
  store i32 %t46, ptr %l36
  br label %bb12
bb12:
  %t47 = load i32, ptr %l36, !tbaa !23
  %t48 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t48, ptr %l37
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t49, i32 %t47)
  store i32 %t53, ptr %l40
  br label %bb13
bb13:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load %"compiler/source:Span", ptr %l1
  %t56 = load i64, ptr %l6, !tbaa !24
  %t60 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t54, %"compiler/source:Span" %t55, i64 %t56)
  store ptr %t60, ptr %l44
  br label %bb14
bb14:
  store { i64, [4 x i64] } zeroinitializer, ptr %t61
  %t62 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 0
  store i64 2, ptr %t62
  %t63 = load %"compiler/source:Span", ptr %l37
  %t64 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t63, 0
  %t65 = load i32, ptr %l40, !tbaa !23
  %t66 = insertvalue { %"compiler/source:Span", i32, ptr } %t64, i32 %t65, 1
  %t67 = load ptr, ptr %l44, !tbaa !29
  %t68 = insertvalue { %"compiler/source:Span", i32, ptr } %t66, ptr %t67, 2
  %t69 = getelementptr { i64, [4 x i64] }, ptr %t61, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t68, ptr %t69
  %t70 = load { i64, [4 x i64] }, ptr %t61
  %t72 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t70, ptr %t72
  %t74 = load ptr, ptr %l0, !tbaa !29
  store ptr %t74, ptr %l47, !tbaa !29
  %t75 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t75, ptr %l48
  %t76 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t76, ptr %l49
  %t77 = load ptr, ptr %lp5
  %t78 = getelementptr %"compiler/check:laneNode", ptr %t77, i32 0, i32 8
  %t79 = load i32, ptr %t78, !tbaa !23
  store i32 %t79, ptr %l50, !tbaa !23
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t85 = call %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v3, ptr %v2, ptr %v3, ptr %t72, ptr %t81, i32 0)
  store %"compiler/typed:Elem" %t85, ptr %l54
  br label %bb15
bb15:
  %t86 = load %"compiler/typed:Elem", ptr %l54
  %t87 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Elem" %t86, ptr %t87
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 4, ptr %t89
  %t90 = load %"compiler/source:Span", ptr %l49
  %t91 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t90, 0
  %t92 = load i32, ptr %l50, !tbaa !23
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr } %t91, i32 %t92, 1
  %t95 = insertvalue { %"compiler/source:Span", i32, ptr } %t93, ptr %t87, 2
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t95, ptr %t96
  %t97 = load { i64, [4 x i64] }, ptr %t88
  %t99 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 40, i64 8)
  store { i64, [4 x i64] } %t97, ptr %t99
  %t100 = load ptr, ptr %l47, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l48
  %t103 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v3, ptr %v3, ptr %t100, %"compiler/source:Span" %t101, ptr %t99)
  store ptr %t103, ptr %l58
  br label %bb16
bb16:
  %t104 = load ptr, ptr %l58, !tbaa !29
  store ptr %t104, ptr %rv
  br label %ret
bb17:
  %t105 = load ptr, ptr %lp5
  %t106 = getelementptr %"compiler/check:laneNode", ptr %t105, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  %t108 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneScalar, !tbaa !24
  %t111 = icmp eq i64 %t107, %t108
  br i1 %t111, label %bb18, label %bb19
bb18:
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = getelementptr %"compiler/check:laneVals", ptr %t113, i32 0, i32 1
  %t116 = load i64, ptr %l2, !tbaa !24
  %t119 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v1, ptr %t115, i64 %t116)
  %t120 = extractvalue { i32, i64 } %t119, 1
  %t121 = extractvalue { i32, i64 } %t119, 0
  store i32 %t121, ptr %l67
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb21, label %ok.123, !prof !99
ok.123:
  store i64 %t120, ptr %l66
  br label %bb20
bb19:
  br label %bb31
bb20:
  %t124 = load i64, ptr %l66, !tbaa !24
  store i64 %t124, ptr %l62, !tbaa !24
  br label %bb23
bb21:
  br label %bb22
bb22:
  store i64 -1, ptr %l62, !tbaa !24
  br label %bb23
bb23:
  %t125 = load i64, ptr %l62, !tbaa !24
  store i64 %t125, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l9, !tbaa !24
  %t128 = icmp slt i64 %t126, 0
  br i1 %t128, label %bb24, label %bb25
bb24:
  %t130 = load ptr, ptr %lp5
  %t131 = getelementptr %"compiler/check:laneNode", ptr %t130, i32 0, i32 7
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb26, label %bb27
bb25:
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_24a46e21631caff9_33b011dc8e05d16d)
  unreachable
bb27:
  br label %bb28
bb28:
  %t136 = load ptr, ptr %lp5
  %t137 = getelementptr %"compiler/check:laneNode", ptr %t136, i32 0, i32 7
  %t138 = load ptr, ptr %t137, !tbaa !29
  store ptr %t138, ptr %rv
  br label %ret
bb29:
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load ptr, ptr %lp5
  %t142 = getelementptr %"compiler/check:laneNode", ptr %t141, i32 0, i32 2
  %t143 = load %"compiler/source:Span", ptr %t142
  %t144 = load i64, ptr %l9, !tbaa !24
  %t148 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v3, ptr %t140, %"compiler/source:Span" %t143, i64 %t144)
  store ptr %t148, ptr %l76
  br label %bb30
bb30:
  %t149 = load ptr, ptr %l76, !tbaa !29
  store ptr %t149, ptr %rv
  br label %ret
bb31:
  %t150 = load ptr, ptr %lp5
  %t151 = getelementptr %"compiler/check:laneNode", ptr %t150, i32 0, i32 0
  %t152 = load i64, ptr %t151, !tbaa !24
  %t153 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneUn, !tbaa !24
  %t156 = icmp eq i64 %t152, %t153
  br i1 %t156, label %bb32, label %bb33
bb32:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t159 = load %"compiler/source:Span", ptr %l1
  %t160 = load ptr, ptr %lp5
  %t161 = getelementptr %"compiler/check:laneNode", ptr %t160, i32 0, i32 4
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load ptr, ptr %l3, !tbaa !29
  %t164 = load ptr, ptr %l4, !tbaa !29
  %t170 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t158, %"compiler/source:Span" %t159, i64 %t162, ptr %t163, ptr %t164)
  store ptr %t170, ptr %l85
  br label %bb34
bb33:
  br label %bb42
bb34:
  %t171 = load ptr, ptr %l85, !tbaa !29
  store ptr %t171, ptr %l10, !tbaa !29
  %t172 = load ptr, ptr %lp5
  %t173 = getelementptr %"compiler/check:laneNode", ptr %t172, i32 0, i32 1
  %t174 = load i32, ptr %t173, !range !{i32 0, i32 98}
  %t176 = trunc i64 48 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t180 = load ptr, ptr %l10, !tbaa !29
  %t181 = load ptr, ptr %lp5
  %t182 = getelementptr %"compiler/check:laneNode", ptr %t181, i32 0, i32 2
  %t183 = load %"compiler/source:Span", ptr %t182
  %t187 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v3, ptr %s6, ptr %t179, ptr %t180, %"compiler/source:Span" %t183, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t187, ptr %l91
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load ptr, ptr %lp5
  %t190 = getelementptr %"compiler/check:laneNode", ptr %t189, i32 0, i32 2
  %t191 = load %"compiler/source:Span", ptr %t190
  %t192 = load ptr, ptr %l10, !tbaa !29
  %t196 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v3, ptr %v3, ptr %t188, %"compiler/source:Span" %t191, ptr %t192)
  store ptr %t196, ptr %l95
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s6)
  %t197 = load ptr, ptr %l95, !tbaa !29
  store ptr %t197, ptr %rv
  br label %ret
bb39:
  %t198 = load ptr, ptr %l0, !tbaa !29
  store ptr %t198, ptr %l96, !tbaa !29
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load ptr, ptr %lp5
  %t201 = getelementptr %"compiler/check:laneNode", ptr %t200, i32 0, i32 2
  %t202 = load %"compiler/source:Span", ptr %t201
  %t203 = load ptr, ptr %lp5
  %t204 = getelementptr %"compiler/check:laneNode", ptr %t203, i32 0, i32 1
  %t205 = load i32, ptr %t204, !range !{i32 0, i32 98}
  %t206 = load ptr, ptr %l10, !tbaa !29
  %t211 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v3, ptr %v0, ptr %t199, %"compiler/source:Span" %t202, i32 %t205, ptr %t206)
  store ptr %t211, ptr %l101
  br label %bb40
bb40:
  %t212 = load ptr, ptr %l96, !tbaa !29
  %t213 = load ptr, ptr %l101, !tbaa !29
  %t214 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v0, ptr %v3, ptr %t212, ptr %t213)
  store ptr %t214, ptr %l102
  br label %bb41
bb41:
  %t215 = load ptr, ptr %l102, !tbaa !29
  store ptr %t215, ptr %rv
  br label %ret
bb42:
  %t216 = load ptr, ptr %lp5
  %t217 = getelementptr %"compiler/check:laneNode", ptr %t216, i32 0, i32 0
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr @G_2ecompiler_2fcheck_2eLaneSel, !tbaa !24
  %t222 = icmp eq i64 %t218, %t219
  br i1 %t222, label %bb43, label %bb44
bb43:
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t225 = load %"compiler/source:Span", ptr %l1
  %t226 = load ptr, ptr %lp5
  %t227 = getelementptr %"compiler/check:laneNode", ptr %t226, i32 0, i32 4
  %t228 = load i64, ptr %t227, !tbaa !24
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t230 = load ptr, ptr %l4, !tbaa !29
  %t236 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t224, %"compiler/source:Span" %t225, i64 %t228, ptr %t229, ptr %t230)
  store ptr %t236, ptr %l111
  br label %bb45
bb44:
  br label %bb55
bb45:
  %t237 = load ptr, ptr %l111, !tbaa !29
  store ptr %t237, ptr %l11, !tbaa !29
  %t238 = load ptr, ptr %l0, !tbaa !29
  %t239 = load %"compiler/source:Span", ptr %l1
  %t240 = load ptr, ptr %lp5
  %t241 = getelementptr %"compiler/check:laneNode", ptr %t240, i32 0, i32 5
  %t242 = load i64, ptr %t241, !tbaa !24
  %t243 = load ptr, ptr %l3, !tbaa !29
  %t244 = load ptr, ptr %l4, !tbaa !29
  %t250 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t238, %"compiler/source:Span" %t239, i64 %t242, ptr %t243, ptr %t244)
  store ptr %t250, ptr %l117
  br label %bb46
bb46:
  %t251 = load ptr, ptr %l117, !tbaa !29
  store ptr %t251, ptr %l12, !tbaa !29
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load %"compiler/source:Span", ptr %l1
  %t254 = load ptr, ptr %lp5
  %t255 = getelementptr %"compiler/check:laneNode", ptr %t254, i32 0, i32 6
  %t256 = load i64, ptr %t255, !tbaa !24
  %t257 = load ptr, ptr %l3, !tbaa !29
  %t258 = load ptr, ptr %l4, !tbaa !29
  %t264 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t252, %"compiler/source:Span" %t253, i64 %t256, ptr %t257, ptr %t258)
  store ptr %t264, ptr %l123
  br label %bb47
bb47:
  %t265 = load ptr, ptr %l123, !tbaa !29
  store ptr %t265, ptr %l13, !tbaa !29
  %t266 = load ptr, ptr %lp5
  %t267 = getelementptr %"compiler/check:laneNode", ptr %t266, i32 0, i32 8
  %t268 = load i32, ptr %t267, !tbaa !23
  %t269 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t272 = icmp eq i32 %t268, %t269
  br i1 %t272, label %bb48, label %bb49
bb48:
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %lp5
  %t276 = getelementptr %"compiler/check:laneNode", ptr %t275, i32 0, i32 2
  %t277 = load %"compiler/source:Span", ptr %t276
  %t280 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t274, %"compiler/source:Span" %t277)
  store ptr %t280, ptr %l129
  br label %bb50
bb49:
  br label %bb51
bb50:
  %t281 = load ptr, ptr %l129, !tbaa !29
  store ptr %t281, ptr %rv
  br label %ret
bb51:
  %t282 = load ptr, ptr %lp5
  %t283 = getelementptr %"compiler/check:laneNode", ptr %t282, i32 0, i32 2
  %t284 = load %"compiler/source:Span", ptr %t283
  store %"compiler/source:Span" %t284, ptr %l130
  %t285 = load ptr, ptr %lp5
  %t286 = getelementptr %"compiler/check:laneNode", ptr %t285, i32 0, i32 8
  %t287 = load i32, ptr %t286, !tbaa !23
  store i32 %t287, ptr %l131, !tbaa !23
  %t288 = load ptr, ptr %l11, !tbaa !29
  store ptr %t288, ptr %l132, !tbaa !29
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load ptr, ptr %l12, !tbaa !29
  %t291 = load ptr, ptr %lp5
  %t292 = getelementptr %"compiler/check:laneNode", ptr %t291, i32 0, i32 8
  %t293 = load i32, ptr %t292, !tbaa !23
  %t294 = load ptr, ptr %lp5
  %t295 = getelementptr %"compiler/check:laneNode", ptr %t294, i32 0, i32 2
  %t296 = load %"compiler/source:Span", ptr %t295
  %t301 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v3, ptr %v3, ptr %t289, ptr %t290, i32 %t293, %"compiler/source:Span" %t296)
  store ptr %t301, ptr %l137
  br label %bb52
bb52:
  %t302 = load ptr, ptr %l137, !tbaa !29
  store ptr %t302, ptr %l138, !tbaa !29
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t304 = load ptr, ptr %l13, !tbaa !29
  %t305 = load ptr, ptr %lp5
  %t306 = getelementptr %"compiler/check:laneNode", ptr %t305, i32 0, i32 8
  %t307 = load i32, ptr %t306, !tbaa !23
  %t308 = load ptr, ptr %lp5
  %t309 = getelementptr %"compiler/check:laneNode", ptr %t308, i32 0, i32 2
  %t310 = load %"compiler/source:Span", ptr %t309
  %t315 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v3, ptr %v0, ptr %t303, ptr %t304, i32 %t307, %"compiler/source:Span" %t310)
  store ptr %t315, ptr %l143
  br label %bb53
bb53:
  %t316 = load ptr, ptr %l132, !tbaa !29
  %t317 = load ptr, ptr %l138, !tbaa !29
  %t318 = load ptr, ptr %l143, !tbaa !29
  %t319 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v0, ptr %v3, ptr %t316, ptr %t317, ptr %t318)
  store %"compiler/typed:Cond" %t319, ptr %l144
  br label %bb54
bb54:
  %t320 = load %"compiler/typed:Cond", ptr %l144
  %t321 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t320, ptr %t321
  store { i64, [5 x i64] } zeroinitializer, ptr %t322
  %t323 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 0
  store i64 11, ptr %t323
  %t324 = load %"compiler/source:Span", ptr %l130
  %t325 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t324, 0
  %t326 = load i32, ptr %l131, !tbaa !23
  %t327 = insertvalue { %"compiler/source:Span", i32, ptr } %t325, i32 %t326, 1
  %t329 = insertvalue { %"compiler/source:Span", i32, ptr } %t327, ptr %t321, 2
  %t330 = getelementptr { i64, [5 x i64] }, ptr %t322, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t329, ptr %t330
  %t331 = load { i64, [5 x i64] }, ptr %t322
  %t333 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t331, ptr %t333
  store ptr %t333, ptr %rv
  br label %ret
bb55:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load %"compiler/source:Span", ptr %l1
  %t337 = load ptr, ptr %lp5
  %t338 = getelementptr %"compiler/check:laneNode", ptr %t337, i32 0, i32 4
  %t339 = load i64, ptr %t338, !tbaa !24
  %t340 = load ptr, ptr %l3, !tbaa !29
  %t341 = load ptr, ptr %l4, !tbaa !29
  %t347 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t335, %"compiler/source:Span" %t336, i64 %t339, ptr %t340, ptr %t341)
  store ptr %t347, ptr %l153
  br label %bb56
bb56:
  %t348 = load ptr, ptr %l153, !tbaa !29
  store ptr %t348, ptr %l14, !tbaa !29
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t350 = load %"compiler/source:Span", ptr %l1
  %t351 = load ptr, ptr %lp5
  %t352 = getelementptr %"compiler/check:laneNode", ptr %t351, i32 0, i32 5
  %t353 = load i64, ptr %t352, !tbaa !24
  %t354 = load ptr, ptr %l3, !tbaa !29
  %t355 = load ptr, ptr %l4, !tbaa !29
  %t361 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneElem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t349, %"compiler/source:Span" %t350, i64 %t353, ptr %t354, ptr %t355)
  store ptr %t361, ptr %l159
  br label %bb57
bb57:
  %t362 = load ptr, ptr %l159, !tbaa !29
  store ptr %t362, ptr %l15, !tbaa !29
  %t363 = load ptr, ptr %lp5
  %t364 = getelementptr %"compiler/check:laneNode", ptr %t363, i32 0, i32 1
  %t365 = load i32, ptr %t364, !range !{i32 0, i32 98}
  %t367 = trunc i64 45 to i32
  %t368 = icmp eq i32 %t365, %t367
  br i1 %t368, label %bb58, label %bb59
bb58:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb60
bb59:
  %t370 = load ptr, ptr %lp5
  %t371 = getelementptr %"compiler/check:laneNode", ptr %t370, i32 0, i32 1
  %t372 = load i32, ptr %t371, !range !{i32 0, i32 98}
  %t374 = trunc i64 46 to i32
  %t375 = icmp eq i32 %t372, %t374
  store i1 %t375, ptr %l162, !tbaa !21
  br label %bb60
bb60:
  %t377 = load i1, ptr %l162, !tbaa !21
  br i1 %t377, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s9
  %t378 = load ptr, ptr %l0, !tbaa !29
  store ptr %t378, ptr %l165, !tbaa !29
  %t379 = load ptr, ptr %l14, !tbaa !29
  store ptr %t379, ptr %l166, !tbaa !29
  %t380 = load ptr, ptr %lp5
  %t381 = getelementptr %"compiler/check:laneNode", ptr %t380, i32 0, i32 3
  %t382 = load %"compiler/source:Span", ptr %t381
  store %"compiler/source:Span" %t382, ptr %l167
  %t383 = load ptr, ptr %lp5
  %t384 = getelementptr %"compiler/check:laneNode", ptr %t383, i32 0, i32 1
  %t385 = load i32, ptr %t384, !range !{i32 0, i32 98}
  %t387 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t385)
  store { i64, ptr } %t387, ptr %l169
  br label %bb63
bb62:
  br label %bb83
bb63:
  %t388 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t389 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s9, ptr %s9, { i64, ptr } %t388)
  store { i64, ptr } %t389, ptr %l170
  br label %bb64
bb64:
  %t390 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t391 = extractvalue { i64, ptr } %t390, 0
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t397 = load ptr, ptr %l165, !tbaa !29
  %t398 = load ptr, ptr %l166, !tbaa !29
  %t399 = load %"compiler/source:Span", ptr %l167
  %t401 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v3, ptr %s9, ptr %t397, ptr %t398, %"compiler/source:Span" %t399, { i64, ptr } %t396)
  store i1 %t401, ptr %l172
  br label %bb65
bb65:
  %t402 = load i1, ptr %l172, !tbaa !21
  %t403 = xor i1 %t402, true
  br i1 %t403, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l174, !tbaa !21
  br label %bb71
bb67:
  %t405 = load ptr, ptr %l0, !tbaa !29
  store ptr %t405, ptr %l175, !tbaa !29
  %t406 = load ptr, ptr %l15, !tbaa !29
  store ptr %t406, ptr %l176, !tbaa !29
  %t407 = load ptr, ptr %lp5
  %t408 = getelementptr %"compiler/check:laneNode", ptr %t407, i32 0, i32 3
  %t409 = load %"compiler/source:Span", ptr %t408
  store %"compiler/source:Span" %t409, ptr %l177
  %t410 = load ptr, ptr %lp5
  %t411 = getelementptr %"compiler/check:laneNode", ptr %t410, i32 0, i32 1
  %t412 = load i32, ptr %t411, !range !{i32 0, i32 98}
  %t414 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s9, i32 %t412)
  store { i64, ptr } %t414, ptr %l179
  br label %bb68
bb68:
  %t415 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t416 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %s9, ptr %s9, { i64, ptr } %t415)
  store { i64, ptr } %t416, ptr %l180
  br label %bb69
bb69:
  %t417 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t417, 0
  %t419 = extractvalue { i64, ptr } %t417, 1
  %t420 = mul i64 %t418, 1
  %t421 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t420)
  call void @llvm.memcpy.p0.p0.i64(ptr %t421, ptr %t419, i64 %t420, i1 false)
  %t422 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t421, 1
  %t424 = load ptr, ptr %l175, !tbaa !29
  %t425 = load ptr, ptr %l176, !tbaa !29
  %t426 = load %"compiler/source:Span", ptr %l177
  %t428 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v3, ptr %s9, ptr %t424, ptr %t425, %"compiler/source:Span" %t426, { i64, ptr } %t423)
  store i1 %t428, ptr %l182
  br label %bb70
bb70:
  %t429 = load i1, ptr %l182, !tbaa !21
  %t430 = xor i1 %t429, true
  store i1 %t430, ptr %l174, !tbaa !21
  br label %bb71
bb71:
  %t432 = load i1, ptr %l174, !tbaa !21
  br i1 %t432, label %bb72, label %bb73
bb72:
  %t433 = load ptr, ptr %l0, !tbaa !29
  %t434 = load ptr, ptr %lp5
  %t435 = getelementptr %"compiler/check:laneNode", ptr %t434, i32 0, i32 2
  %t436 = load %"compiler/source:Span", ptr %t435
  %t439 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v3, ptr %t433, %"compiler/source:Span" %t436)
  store ptr %t439, ptr %l186
  br label %bb74
bb73:
  br label %bb75
bb74:
  call void @__olang_scope_close(ptr %s9)
  %t440 = load ptr, ptr %l186, !tbaa !29
  store ptr %t440, ptr %rv
  br label %ret
bb75:
  %t441 = load ptr, ptr %lp5
  %t442 = getelementptr %"compiler/check:laneNode", ptr %t441, i32 0, i32 1
  %t443 = load i32, ptr %t442, !range !{i32 0, i32 98}
  %t445 = trunc i64 45 to i32
  %t446 = icmp eq i32 %t443, %t445
  br i1 %t446, label %bb76, label %bb77
bb76:
  %t448 = load ptr, ptr %lp5
  %t449 = getelementptr %"compiler/check:laneNode", ptr %t448, i32 0, i32 2
  %t450 = load %"compiler/source:Span", ptr %t449
  store %"compiler/source:Span" %t450, ptr %l189
  %t451 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t451, ptr %l190, !tbaa !23
  %t452 = load ptr, ptr %l14, !tbaa !29
  store ptr %t452, ptr %l191, !tbaa !29
  %t453 = load ptr, ptr %l15, !tbaa !29
  store ptr %t453, ptr %l193, !tbaa !29
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load ptr, ptr %lp5
  %t457 = getelementptr %"compiler/check:laneNode", ptr %t456, i32 0, i32 2
  %t458 = load %"compiler/source:Span", ptr %t457
  %t459 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t463 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t455, %"compiler/source:Span" %t458, i32 %t459, i64 0)
  store ptr %t463, ptr %l197
  br label %bb78
bb77:
  br label %bb80
bb78:
  %t464 = load ptr, ptr %l191, !tbaa !29
  %t465 = load ptr, ptr %l193, !tbaa !29
  %t466 = load ptr, ptr %l197, !tbaa !29
  %t467 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t464, ptr %t465, ptr %t466)
  store %"compiler/typed:Cond" %t467, ptr %l198
  br label %bb79
bb79:
  %t468 = load %"compiler/typed:Cond", ptr %l198
  %t469 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t468, ptr %t469
  store { i64, [5 x i64] } zeroinitializer, ptr %t470
  %t471 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 0
  store i64 11, ptr %t471
  %t472 = load %"compiler/source:Span", ptr %l189
  %t473 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t472, 0
  %t474 = load i32, ptr %l190, !tbaa !23
  %t475 = insertvalue { %"compiler/source:Span", i32, ptr } %t473, i32 %t474, 1
  %t477 = insertvalue { %"compiler/source:Span", i32, ptr } %t475, ptr %t469, 2
  %t478 = getelementptr { i64, [5 x i64] }, ptr %t470, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t477, ptr %t478
  %t479 = load { i64, [5 x i64] }, ptr %t470
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t479, ptr %t481
  call void @__olang_scope_close(ptr %s9)
  store ptr %t481, ptr %rv
  br label %ret
bb80:
  %t483 = load ptr, ptr %lp5
  %t484 = getelementptr %"compiler/check:laneNode", ptr %t483, i32 0, i32 2
  %t485 = load %"compiler/source:Span", ptr %t484
  store %"compiler/source:Span" %t485, ptr %l202
  %t486 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  store i32 %t486, ptr %l203, !tbaa !23
  %t487 = load ptr, ptr %l14, !tbaa !29
  store ptr %t487, ptr %l204, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %lp5
  %t490 = getelementptr %"compiler/check:laneNode", ptr %t489, i32 0, i32 2
  %t491 = load %"compiler/source:Span", ptr %t490
  %t492 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t496 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v3, ptr %t488, %"compiler/source:Span" %t491, i32 %t492, i64 1)
  store ptr %t496, ptr %l208
  br label %bb81
bb81:
  %t497 = load ptr, ptr %l208, !tbaa !29
  %t498 = load ptr, ptr %l15, !tbaa !29
  %t499 = load ptr, ptr %l204, !tbaa !29
  %t502 = call %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v3, ptr %v3, ptr %v3, ptr %v3, ptr %t499, ptr %t497, ptr %t498)
  store %"compiler/typed:Cond" %t502, ptr %l211
  br label %bb82
bb82:
  %t503 = load %"compiler/typed:Cond", ptr %l211
  %t504 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 24, i64 8)
  store %"compiler/typed:Cond" %t503, ptr %t504
  store { i64, [5 x i64] } zeroinitializer, ptr %t505
  %t506 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 0
  store i64 11, ptr %t506
  %t507 = load %"compiler/source:Span", ptr %l202
  %t508 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t507, 0
  %t509 = load i32, ptr %l203, !tbaa !23
  %t510 = insertvalue { %"compiler/source:Span", i32, ptr } %t508, i32 %t509, 1
  %t512 = insertvalue { %"compiler/source:Span", i32, ptr } %t510, ptr %t504, 2
  %t513 = getelementptr { i64, [5 x i64] }, ptr %t505, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t512, ptr %t513
  %t514 = load { i64, [5 x i64] }, ptr %t505
  %t516 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 48, i64 8)
  store { i64, [5 x i64] } %t514, ptr %t516
  call void @__olang_scope_close(ptr %s9)
  store ptr %t516, ptr %rv
  br label %ret
bb83:
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l215, !tbaa !29
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load ptr, ptr %lp5
  %t521 = getelementptr %"compiler/check:laneNode", ptr %t520, i32 0, i32 2
  %t522 = load %"compiler/source:Span", ptr %t521
  %t523 = load ptr, ptr %lp5
  %t524 = getelementptr %"compiler/check:laneNode", ptr %t523, i32 0, i32 3
  %t525 = load %"compiler/source:Span", ptr %t524
  %t526 = load ptr, ptr %lp5
  %t527 = getelementptr %"compiler/check:laneNode", ptr %t526, i32 0, i32 1
  %t528 = load i32, ptr %t527, !range !{i32 0, i32 98}
  %t529 = load ptr, ptr %l14, !tbaa !29
  %t530 = load ptr, ptr %l15, !tbaa !29
  %t531 = load ptr, ptr %lp5
  %t532 = getelementptr %"compiler/check:laneNode", ptr %t531, i32 0, i32 2
  %t533 = load %"compiler/source:Span", ptr %t532
  %t534 = load ptr, ptr %lp5
  %t535 = getelementptr %"compiler/check:laneNode", ptr %t534, i32 0, i32 2
  %t536 = load %"compiler/source:Span", ptr %t535
  %t545 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v3, ptr %v3, ptr %v0, ptr %t519, %"compiler/source:Span" %t522, %"compiler/source:Span" %t525, i32 %t528, ptr %t529, ptr %t530, %"compiler/source:Span" %t533, %"compiler/source:Span" %t536)
  store ptr %t545, ptr %l224
  br label %bb84
bb84:
  %t546 = load ptr, ptr %l215, !tbaa !29
  %t547 = load ptr, ptr %l224, !tbaa !29
  %t548 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v0, ptr %v3, ptr %t546, ptr %t547)
  store ptr %t548, ptr %l225
  br label %bb85
bb85:
  %t549 = load ptr, ptr %l225, !tbaa !29
  store ptr %t549, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l24 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l45 = alloca i1
  %l46 = alloca i1
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca i1
  %l64 = alloca { i64, ptr }
  %l70 = alloca i1
  %l71 = alloca ptr
  %l77 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t2 = load ptr, ptr %l11, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 17
  store i1 %t8, ptr %l12, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l12, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t12 = load ptr, ptr %l16, !tbaa !29
  %t13 = icmp ne ptr %t12, null
  br i1 %t13, label %bb7, label %bb8
bb7:
  %t15 = load ptr, ptr %l16, !tbaa !29
  %t16 = load i64, ptr %t15, !range !{i64 0, i64 30}
  %t18 = icmp eq i64 %t16, 15
  store i1 %t18, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t22, i32 0, i32 1
  %t24 = load ptr, ptr %t23
  store ptr %t24, ptr %l2, !tbaa !29
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t27 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %t26, ptr %t27)
  store i32 %t30, ptr %l24
  br label %bb12
bb12:
  %t31 = load i32, ptr %l24, !tbaa !23
  %t32 = icmp sge i32 %t31, 0
  store i1 %t32, ptr %rv
  br label %ret
bb13:
  %t34 = load ptr, ptr %l1, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  store i1 false, ptr %l27, !tbaa !21
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = icmp ne ptr %t35, null
  br i1 %t36, label %bb14, label %bb15
bb14:
  %t38 = load ptr, ptr %l26, !tbaa !29
  %t39 = load i64, ptr %t38, !range !{i64 0, i64 30}
  %t41 = icmp eq i64 %t39, 2
  store i1 %t41, ptr %l27, !tbaa !21
  br label %bb15
bb15:
  %t42 = load i1, ptr %l27, !tbaa !21
  br i1 %t42, label %bb16, label %bb17
bb16:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t45 = getelementptr { i64, [4 x i64] }, ptr %t43, i32 0, i32 1
  %t46 = getelementptr { %"compiler/source:Span", ptr }, ptr %t45, i32 0, i32 1
  %t47 = load ptr, ptr %t46
  store ptr %t47, ptr %l3, !tbaa !29
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t53 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t49, ptr %t50)
  store i1 %t53, ptr %l34
  br label %bb19
bb19:
  %t54 = load i1, ptr %l34, !tbaa !21
  store i1 %t54, ptr %rv
  br label %ret
bb20:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t56 = load ptr, ptr %l35, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb21, label %bb22
bb21:
  %t59 = load ptr, ptr %l35, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 30}
  %t62 = icmp eq i64 %t60, 8
  store i1 %t62, ptr %l36, !tbaa !21
  br label %bb22
bb22:
  %t63 = load i1, ptr %l36, !tbaa !21
  br i1 %t63, label %bb23, label %bb24
bb23:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t66, i32 0, i32 1
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l4, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t72 = getelementptr { i64, [4 x i64] }, ptr %t70, i32 0, i32 1
  %t73 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t72, i32 0, i32 3
  %t74 = load ptr, ptr %t73
  store ptr %t74, ptr %l5, !tbaa !29
  br label %bb25
bb24:
  br label %bb31
bb25:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t80 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t76, ptr %t77)
  store i1 %t80, ptr %l45
  br label %bb26
bb26:
  %t81 = load i1, ptr %l45, !tbaa !21
  br i1 %t81, label %bb27, label %bb28
bb27:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t83 = load ptr, ptr %l5, !tbaa !29
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t82, ptr %t83)
  store i1 %t86, ptr %l49
  br label %bb29
bb28:
  store i1 false, ptr %l46, !tbaa !21
  br label %bb30
bb29:
  %t87 = load i1, ptr %l49, !tbaa !21
  store i1 %t87, ptr %l46, !tbaa !21
  br label %bb30
bb30:
  %t88 = load i1, ptr %l46, !tbaa !21
  store i1 %t88, ptr %rv
  br label %ret
bb31:
  %t89 = load ptr, ptr %l1, !tbaa !29
  store ptr %t89, ptr %l50, !tbaa !29
  store i1 false, ptr %l51, !tbaa !21
  %t90 = load ptr, ptr %l50, !tbaa !29
  %t91 = icmp ne ptr %t90, null
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = load ptr, ptr %l50, !tbaa !29
  %t94 = load i64, ptr %t93, !range !{i64 0, i64 30}
  %t96 = icmp eq i64 %t94, 23
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb33
bb33:
  %t97 = load i1, ptr %l51, !tbaa !21
  br i1 %t97, label %bb34, label %bb35
bb34:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr { i64, [4 x i64] }, ptr %t98, i32 0, i32 1
  %t101 = getelementptr { %"compiler/source:Span", ptr }, ptr %t100, i32 0, i32 1
  %t102 = load ptr, ptr %t101
  store ptr %t102, ptr %l6, !tbaa !29
  br label %bb36
bb35:
  br label %bb53
bb36:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t106 = getelementptr %"compiler/ast:Match", ptr %t104, i32 0, i32 3
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  store { i64, ptr } %t107, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l9, !tbaa !24
  br label %bb37
bb37:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb38, label %bb39
bb38:
  br label %bb52
bb39:
  br label %bb40
bb40:
  %t121 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t121, ptr %l64, !tbaa !27
  %t122 = load i64, ptr %l8, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  store ptr %t127, ptr %l10, !tbaa !29
  %t129 = load ptr, ptr %l10, !tbaa !29
  %t131 = getelementptr %"compiler/ast:Case", ptr %t129, i32 0, i32 5
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = icmp eq ptr %t132, null
  br i1 %t134, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb47
bb42:
  %t136 = load ptr, ptr %l0, !tbaa !29
  store ptr %t136, ptr %l71, !tbaa !29
  %t137 = load ptr, ptr %l10, !tbaa !29
  %t139 = getelementptr %"compiler/ast:Case", ptr %t137, i32 0, i32 5
  %t140 = load ptr, ptr %t139, !tbaa !29
  %t142 = icmp eq ptr %t140, null
  br i1 %t142, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_ddeebe9155436d6a_19ee353760b572b6)
  unreachable
bb44:
  br label %bb45
bb45:
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = getelementptr %"compiler/ast:Case", ptr %t144, i32 0, i32 5
  %t147 = load ptr, ptr %t146, !tbaa !29
  %t148 = load ptr, ptr %l71, !tbaa !29
  %t150 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitArray(ptr %v0, ptr %v1, ptr %t148, ptr %t147)
  store i1 %t150, ptr %l77
  br label %bb46
bb46:
  %t151 = load i1, ptr %l77, !tbaa !21
  %t152 = xor i1 %t151, true
  store i1 %t152, ptr %l70, !tbaa !21
  br label %bb47
bb47:
  %t154 = load i1, ptr %l70, !tbaa !21
  br i1 %t154, label %bb48, label %bb49
bb48:
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t158 = add i64 %t156, 1
  store i64 %t158, ptr %l8, !tbaa !24
  br label %bb37
bb52:
  %t160 = load ptr, ptr %l6, !tbaa !29
  %t162 = getelementptr %"compiler/ast:Match", ptr %t160, i32 0, i32 3
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t167 = icmp sgt i64 %t165, 0
  store i1 %t167, ptr %rv
  br label %ret
bb53:
  br i1 true, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  br label %bb57
bb56:
  store i1 false, ptr %rv
  br label %ret
bb57:
  call void @__olang_check_failed(ptr @olang_loc_7406e676cee1d8f8_b07044052169e244)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitBeside(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, ptr %a3, i32 %a4, %"compiler/source:Span" %a5, i1 %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/check:litv"
  %l4 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca i32
  %l17 = alloca i1
  %l20 = alloca i1
  %l25 = alloca i32
  %l28 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i32
  %l40 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca ptr
  %l51 = alloca ptr
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca i32
  %l63 = alloca i32
  %l64 = alloca i1
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/check:litv" %a2, ptr %l2
  store i32 %a4, ptr %l4
  store i1 %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  %t4 = call i32 @compiler_2fcheck_2etypeOf(ptr %v2, ptr %a3)
  store i32 %t4, ptr %l12
  br label %bb1
bb1:
  %t5 = load i32, ptr %l12, !tbaa !23
  store i32 %t5, ptr %l7, !tbaa !23
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load i32, ptr %l7, !tbaa !23
  %t10 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l15
  br label %bb2
bb2:
  %t11 = load i32, ptr %l15, !tbaa !23
  store i32 %t11, ptr %l8, !tbaa !23
  %t12 = load i1, ptr %l6, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i32, ptr %l8, !tbaa !23
  %t18 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t14, i32 %t15)
  store i1 %t18, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb6
bb5:
  %t19 = load i1, ptr %l20, !tbaa !21
  %t20 = xor i1 %t19, true
  store i1 %t20, ptr %l17, !tbaa !21
  br label %bb6
bb6:
  %t22 = load i1, ptr %l17, !tbaa !21
  br i1 %t22, label %bb7, label %bb8
bb7:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i32, ptr %l7, !tbaa !23
  %t25 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t29 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %t23, i32 %t24, i32 %t25)
  store i32 %t29, ptr %l25
  br label %bb9
bb8:
  br label %bb10
bb9:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l8, !tbaa !23
  br label %bb10
bb10:
  %t31 = load i1, ptr %l6, !tbaa !21
  %t33 = xor i1 %t31, true
  br i1 %t33, label %bb11, label %bb12
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i32, ptr %l8, !tbaa !23
  %t39 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t35, i32 %t36)
  store i1 %t39, ptr %l31
  br label %bb13
bb12:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb14
bb13:
  %t40 = load i1, ptr %l31, !tbaa !21
  %t41 = xor i1 %t40, true
  store i1 %t41, ptr %l28, !tbaa !21
  br label %bb14
bb14:
  %t43 = load i1, ptr %l28, !tbaa !21
  br i1 %t43, label %bb15, label %bb16
bb15:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t45 = load i32, ptr %l7, !tbaa !23
  %t46 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t50 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %t44, i32 %t45, i32 %t46)
  store i32 %t50, ptr %l36
  br label %bb17
bb16:
  br label %bb18
bb17:
  %t51 = load i32, ptr %l36, !tbaa !23
  store i32 %t51, ptr %l8, !tbaa !23
  br label %bb18
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t53 = load %"compiler/check:litv", ptr %l2
  %t54 = load i32, ptr %l8, !tbaa !23
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t52, %"compiler/check:litv" %t53, i32 %t54)
  store i1 %t58, ptr %l40
  br label %bb19
bb19:
  %t59 = load i1, ptr %l40, !tbaa !21
  br i1 %t59, label %bb20, label %bb21
bb20:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load %"compiler/check:litv", ptr %l2
  %t63 = load i32, ptr %l8, !tbaa !23
  %t68 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v3, ptr %t60, ptr %t61, %"compiler/check:litv" %t62, i32 %t63)
  store ptr %t68, ptr %l46
  br label %bb22
bb21:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t70 = load ptr, ptr %l1, !tbaa !29
  %t71 = load %"compiler/check:litv", ptr %l2
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t77 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v3, ptr %t69, ptr %t70, %"compiler/check:litv" %t71, i32 %t72)
  store ptr %t77, ptr %l51
  br label %bb23
bb22:
  %t78 = load ptr, ptr %l46, !tbaa !29
  store ptr %t78, ptr %l41, !tbaa !29
  br label %bb24
bb23:
  %t79 = load ptr, ptr %l51, !tbaa !29
  store ptr %t79, ptr %l41, !tbaa !29
  br label %bb24
bb24:
  %t80 = load ptr, ptr %l41, !tbaa !29
  store ptr %t80, ptr %l9, !tbaa !29
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t82 = load %"compiler/check:litv", ptr %l2
  %t83 = load i32, ptr %l8, !tbaa !23
  %t87 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %t81, %"compiler/check:litv" %t82, i32 %t83)
  store i1 %t87, ptr %l55
  br label %bb25
bb25:
  %t88 = load i1, ptr %l55, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb26, label %bb27
bb26:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l58, !tbaa !29
  store %"compiler/source:Span" %a5, ptr %l59
  %t93 = load i32, ptr %l7, !tbaa !23
  store i32 %t93, ptr %l60, !tbaa !23
  %t94 = load ptr, ptr %l9, !tbaa !29
  %t97 = call i32 @compiler_2fcheck_2etypeOf(ptr %v3, ptr %t94)
  store i32 %t97, ptr %l63
  br label %bb28
bb27:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb30
bb28:
  %t98 = load ptr, ptr %l58, !tbaa !29
  %t99 = load %"compiler/source:Span", ptr %l59
  %t100 = load i32, ptr %l60, !tbaa !23
  %t101 = load i32, ptr %l63, !tbaa !23
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %t98, %"compiler/source:Span" %t99, i32 %t100, i32 %t101)
  store i1 %t102, ptr %l64
  br label %bb29
bb29:
  %t103 = load i1, ptr %l64, !tbaa !21
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb30
bb30:
  %t104 = load i1, ptr %l57, !tbaa !21
  br i1 %t104, label %bb31, label %bb32
bb31:
  store ptr null, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t106 = load ptr, ptr %l9, !tbaa !29
  store ptr %t106, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalNamed(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l2 = alloca i64
  %l4 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i32
  %rv = alloca i64
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %a0)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 8
  %t10 = call { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %t6, i32 %a1)
  %t11 = extractvalue { i32, i64 } %t10, 1
  %t12 = extractvalue { i32, i64 } %t10, 0
  store i32 %t12, ptr %l9
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  store i64 %t11, ptr %l8
  br label %bb2
bb2:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  br label %bb5
bb3:
  br label %bb4
bb4:
  store i64 -1, ptr %l2, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l2, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutParam(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca %"compiler/source:Span"
  %l7 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l14 = alloca { i64, ptr }
  %l16 = alloca %"compiler/diagmsg:Msg"
  %l17 = alloca i64
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = load i32, ptr %l2, !tbaa !23
  %t7 = call %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %t1, ptr %a1, i32 %t3)
  store %"compiler/source:Span" %t7, ptr %l7
  br label %bb1
bb1:
  %t8 = load %"compiler/source:Span", ptr %l7
  store %"compiler/source:Span" %t8, ptr %l3
  %t9 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t10 = load i32, ptr %t9, !tbaa !23
  %t12 = icmp sge i32 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l0, !tbaa !29
  store ptr %t14, ptr %l10, !tbaa !29
  %t15 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t15, ptr %l11
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l14
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  %t29 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %s1, ptr %s1, { i64, ptr } %t27)
  store %"compiler/diagmsg:Msg" %t29, ptr %l16
  br label %bb5
bb5:
  %t30 = load ptr, ptr %l10, !tbaa !29
  %t31 = load %"compiler/source:Span", ptr %l11
  %t32 = load %"compiler/diagmsg:Msg", ptr %l16
  %t33 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t30, %"compiler/source:Span" %t31, %"compiler/diagmsg:Msg" %t32)
  store i64 %t33, ptr %l17
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameAt(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l12 = alloca i32
  %l13 = alloca i32
  %l16 = alloca { i64, ptr }
  %l20 = alloca %"compiler/source:Span"
  %s1 = alloca %olang.scope
  %rv = alloca %"compiler/source:Span"
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v1, ptr %t1)
  store %"compiler/source:Span" %t3, ptr %l5
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Span", ptr %l5
  store %"compiler/source:Span" %t4, ptr %l2
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 9}
  %t12 = icmp eq i64 %t10, 8
  store i1 %t12, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  %t13 = load i1, ptr %l7, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  br label %bb6
bb5:
  br label %bb9
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t20 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %l12, !tbaa !23
  %t22 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t23 = load i32, ptr %t22, !tbaa !23
  store i32 %t23, ptr %l13, !tbaa !23
  %t25 = load i32, ptr %l3, !tbaa !23
  %t28 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %s1, ptr %a0, i32 %t25)
  store { i64, ptr } %t28, ptr %l16
  br label %bb7
bb7:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t32 = trunc i64 %t30 to i32
  %t33 = load i32, ptr %l13, !tbaa !23
  %t35 = add i32 %t33, %t32
  %t36 = load i32, ptr %l12, !tbaa !23
  %t38 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s1, i32 %t36, i32 %t35)
  store %"compiler/source:Span" %t38, ptr %l20
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s1)
  %t39 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t39, ptr %rv
  br label %ret
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  %t40 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t40, ptr %rv
  br label %ret
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4d673442943c2a5_9663aeaf0b5db41)
  unreachable
ret:
  %rr = load %"compiler/source:Span", ptr %rv
  ret %"compiler/source:Span" %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamedMet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i32
  %l16 = alloca i1
  %l18 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l23 = alloca i1
  %l25 = alloca i1
  %l28 = alloca ptr
  %l30 = alloca ptr
  %l34 = alloca %"compiler/names:Ref"
  %l39 = alloca { i64, ptr }
  %l45 = alloca i1
  %l47 = alloca ptr
  %l50 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i32
  %l55 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l60 = alloca i32
  %l61 = alloca i32
  %l66 = alloca i1
  %l67 = alloca i1
  %l72 = alloca i32
  %l75 = alloca ptr
  %l76 = alloca %"compiler/source:Span"
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i64
  %l92 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l101 = alloca ptr
  %l102 = alloca %"compiler/source:Span"
  %l103 = alloca ptr
  %l105 = alloca %"compiler/source:Span"
  %l106 = alloca { i64, ptr }
  %l107 = alloca %"compiler/diagmsg:Msg"
  %l108 = alloca i64
  %l116 = alloca i1
  %l117 = alloca ptr
  %l118 = alloca %"compiler/source:Span"
  %l119 = alloca ptr
  %l121 = alloca %"compiler/source:Span"
  %l122 = alloca { i64, ptr }
  %l123 = alloca %"compiler/diagmsg:Msg"
  %l124 = alloca i64
  %l128 = alloca ptr
  %l130 = alloca ptr
  %l134 = alloca %"compiler/names:Ref"
  %l137 = alloca i1
  %l140 = alloca i1
  %l142 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l150 = alloca i1
  %l152 = alloca i1
  %l157 = alloca i1
  %l167 = alloca i1
  %l171 = alloca i1
  %l173 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l176 = alloca i1
  %l177 = alloca i1
  %l180 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l183 = alloca %"compiler/source:Span"
  %l186 = alloca %"compiler/diagmsg:Msg"
  %l187 = alloca i64
  %l196 = alloca { i64, ptr }
  %l200 = alloca i1
  %l203 = alloca i1
  %l209 = alloca ptr
  %l211 = alloca ptr
  %l216 = alloca i32
  %l219 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca { i64, ptr }
  %l224 = alloca i32
  %l225 = alloca i1
  %l228 = alloca ptr
  %l229 = alloca i32
  %l230 = alloca { i64, ptr }
  %l232 = alloca %"compiler/source:Span"
  %l233 = alloca i1
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t7)
  store ptr %t9, ptr %l18
  br label %bb3
bb2:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l18, !tbaa !29
  %t12 = getelementptr %"compiler/check:frame", ptr %t10, i32 0, i32 4
  %t13 = getelementptr %"compiler/generic:Context", ptr %t12, i32 0, i32 2
  %t14 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t14, ptr %l21, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr i32, ptr %t16, i64 0
  %t18 = load i32, ptr %t17, !tbaa !33
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t13, i32 %t18)
  store i1 %t21, ptr %l23
  br label %bb4
bb4:
  %t22 = load i1, ptr %l23, !tbaa !21
  %t23 = xor i1 %t22, true
  store i1 %t23, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t25 = load i1, ptr %l16, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !29
  %t31 = getelementptr %"compiler/generic:Program", ptr %t29, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !29
  store ptr %t32, ptr %l28, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t33)
  store ptr %t35, ptr %l30
  br label %bb8
bb7:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb10
bb8:
  %t36 = load ptr, ptr %l30, !tbaa !29
  %t38 = getelementptr %"compiler/check:frame", ptr %t36, i32 0, i32 2
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t42 = load ptr, ptr %l28, !tbaa !29
  %t45 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t42, i64 %t39, i32 %t41)
  store %"compiler/names:Ref" %t45, ptr %l34
  br label %bb9
bb9:
  %t46 = getelementptr %"compiler/names:Ref", ptr %l34, i32 0, i32 0
  %t47 = load i32, ptr %t46, !range !{i32 0, i32 9}
  %t49 = trunc i64 0 to i32
  %t50 = icmp eq i32 %t47, %t49
  store i1 %t50, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l25, !tbaa !21
  br i1 %t52, label %bb11, label %bb12
bb11:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load %"compiler/source:Span", ptr %l2
  %t55 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t55, ptr %l39, !tbaa !27
  %t56 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr i32, ptr %t57, i64 0
  %t59 = load i32, ptr %t58, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %t53, %"compiler/source:Span" %t54, i32 %t59)
  br label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb14:
  %t64 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t68 = icmp eq i64 %t66, 1
  br i1 %t68, label %bb15, label %bb16
bb15:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t70)
  store ptr %t72, ptr %l47
  br label %bb17
bb16:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb19
bb17:
  %t73 = load ptr, ptr %l47, !tbaa !29
  %t75 = getelementptr %"compiler/check:frame", ptr %t73, i32 0, i32 4
  %t76 = getelementptr %"compiler/generic:Context", ptr %t75, i32 0, i32 2
  %t77 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t77, ptr %l50, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i32, ptr %t79, i64 0
  %t81 = load i32, ptr %t80, !tbaa !33
  %t84 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t76, i32 %t81)
  store i1 %t84, ptr %l52
  br label %bb18
bb18:
  %t85 = load i1, ptr %l52, !tbaa !21
  store i1 %t85, ptr %l45, !tbaa !21
  br label %bb19
bb19:
  %t86 = load i1, ptr %l45, !tbaa !21
  br i1 %t86, label %bb20, label %bb21
bb20:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t87)
  store ptr %t89, ptr %l55
  br label %bb22
bb21:
  br label %bb39
bb22:
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t92 = getelementptr %"compiler/check:frame", ptr %t90, i32 0, i32 4
  %t93 = getelementptr %"compiler/generic:Context", ptr %t92, i32 0, i32 2
  %t94 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t94, ptr %l58, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 0
  %t98 = load i32, ptr %t97, !tbaa !33
  %t101 = call { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %t93, i32 %t98)
  %t102 = extractvalue { i32, i32 } %t101, 1
  %t103 = extractvalue { i32, i32 } %t101, 0
  store i32 %t103, ptr %l61
  %t104 = icmp ne i32 %t103, 0
  br i1 %t104, label %bb24, label %ok.105, !prof !99
ok.105:
  store i32 %t102, ptr %l60
  br label %bb23
bb23:
  %t106 = load i32, ptr %l60, !tbaa !23
  store i32 %t106, ptr %l53, !tbaa !23
  br label %bb26
bb24:
  br label %bb25
bb25:
  %t107 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t107, ptr %l53, !tbaa !23
  br label %bb26
bb26:
  %t109 = load i32, ptr %l53, !tbaa !23
  store i32 %t109, ptr %l5, !tbaa !23
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/check:Checker", ptr %t110, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !29
  %t114 = load i32, ptr %l5, !tbaa !23
  %t117 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %t113, i32 %t114)
  store i1 %t117, ptr %l66
  br label %bb27
bb27:
  %t118 = load i1, ptr %l66, !tbaa !21
  br i1 %t118, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l67, !tbaa !21
  br label %bb31
bb29:
  %t119 = load ptr, ptr %l0, !tbaa !29
  %t121 = getelementptr %"compiler/check:Checker", ptr %t119, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !29
  %t124 = getelementptr %"compiler/generic:Program", ptr %t122, i32 0, i32 2
  %t125 = load i32, ptr %l5, !tbaa !23
  %t128 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t124, i32 %t125)
  store i32 %t128, ptr %l72
  br label %bb30
bb30:
  %t129 = load i32, ptr %l72, !range !{i32 0, i32 33}
  %t131 = trunc i64 30 to i32
  %t132 = icmp eq i32 %t129, %t131
  store i1 %t132, ptr %l67, !tbaa !21
  br label %bb31
bb31:
  %t134 = load i1, ptr %l67, !tbaa !21
  br i1 %t134, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s3
  %t135 = load ptr, ptr %l0, !tbaa !29
  store ptr %t135, ptr %l75, !tbaa !29
  %t136 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t136, ptr %l76
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t138, ptr %l78, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 0
  %t142 = load i32, ptr %t141, !tbaa !33
  %t145 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t137, i32 %t142)
  store { i64, ptr } %t145, ptr %l80
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t146 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  store { i64, ptr } %t152, ptr %l81, !tbaa !27
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t154, ptr %l83, !tbaa !27
  %t155 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr i32, ptr %t156, i64 0
  %t158 = load i32, ptr %t157, !tbaa !33
  %t161 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t153, i32 %t158)
  store { i64, ptr } %t161, ptr %l85
  br label %bb35
bb35:
  %t162 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t164 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrVarNotType(ptr %s3, ptr %v0, ptr %s3, { i64, ptr } %t162, { i64, ptr } %t163)
  store %"compiler/diagmsg:Msg" %t164, ptr %l86
  br label %bb36
bb36:
  %t165 = load ptr, ptr %l75, !tbaa !29
  %t166 = load %"compiler/source:Span", ptr %l76
  %t167 = load %"compiler/diagmsg:Msg", ptr %l86
  %t168 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t165, %"compiler/source:Span" %t166, %"compiler/diagmsg:Msg" %t167)
  store i64 %t168, ptr %l87
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb38:
  br label %bb39
bb39:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t176 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v1, ptr %t170, ptr %t171, ptr %t172)
  store i1 %t176, ptr %l92
  br label %bb40
bb40:
  %t177 = load i1, ptr %l92, !tbaa !21
  br i1 %t177, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/check:Checker", ptr %t179, i32 0, i32 90
  %t182 = load i1, ptr %t181, !tbaa !21
  %t184 = xor i1 %t182, true
  br i1 %t184, label %bb44, label %bb45
bb44:
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t187 = load ptr, ptr %l1, !tbaa !29
  %t190 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncNamed(ptr %v0, ptr %v1, ptr %t186, ptr %t187)
  store i1 %t190, ptr %l100
  br label %bb46
bb45:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb47
bb46:
  %t191 = load i1, ptr %l100, !tbaa !21
  store i1 %t191, ptr %l97, !tbaa !21
  br label %bb47
bb47:
  %t192 = load i1, ptr %l97, !tbaa !21
  br i1 %t192, label %bb48, label %bb49
bb48:
  store %olang.scope zeroinitializer, ptr %s5
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l101, !tbaa !29
  %t194 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t194, ptr %l102
  %t195 = load ptr, ptr %l0, !tbaa !29
  store ptr %t195, ptr %l103, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t198 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t196)
  store %"compiler/source:Span" %t198, ptr %l105
  br label %bb50
bb49:
  br label %bb54
bb50:
  %t199 = load ptr, ptr %l103, !tbaa !29
  %t200 = load %"compiler/source:Span", ptr %l105
  %t201 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t199, %"compiler/source:Span" %t200)
  store { i64, ptr } %t201, ptr %l106
  br label %bb51
bb51:
  %t202 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t203 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncDeclBare(ptr %v0, ptr %s5, { i64, ptr } %t202)
  store %"compiler/diagmsg:Msg" %t203, ptr %l107
  br label %bb52
bb52:
  %t204 = load ptr, ptr %l101, !tbaa !29
  %t205 = load %"compiler/source:Span", ptr %l102
  %t206 = load %"compiler/diagmsg:Msg", ptr %l107
  %t207 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t204, %"compiler/source:Span" %t205, %"compiler/diagmsg:Msg" %t206)
  store i64 %t207, ptr %l108
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb54:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 91
  %t212 = load i1, ptr %t211, !tbaa !21
  store i1 %t212, ptr %l6, !tbaa !21
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t216 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 90
  store i1 false, ptr %t216, !tbaa !21
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = getelementptr %"compiler/check:Checker", ptr %t217, i32 0, i32 91
  store i1 false, ptr %t219, !tbaa !21
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t221 = load ptr, ptr %l1, !tbaa !29
  %t224 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %t220, ptr %t221)
  store i1 %t224, ptr %l116
  br label %bb55
bb55:
  %t225 = load i1, ptr %l116, !tbaa !21
  br i1 %t225, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s6
  %t226 = load ptr, ptr %l0, !tbaa !29
  store ptr %t226, ptr %l117, !tbaa !29
  %t227 = load %"compiler/source:Span", ptr %l2
  store %"compiler/source:Span" %t227, ptr %l118
  %t228 = load ptr, ptr %l0, !tbaa !29
  store ptr %t228, ptr %l119, !tbaa !29
  %t229 = load ptr, ptr %l1, !tbaa !29
  %t231 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v1, ptr %t229)
  store %"compiler/source:Span" %t231, ptr %l121
  br label %bb58
bb57:
  br label %bb62
bb58:
  %t232 = load ptr, ptr %l119, !tbaa !29
  %t233 = load %"compiler/source:Span", ptr %l121
  %t234 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t232, %"compiler/source:Span" %t233)
  store { i64, ptr } %t234, ptr %l122
  br label %bb59
bb59:
  %t235 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t236 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %s6, { i64, ptr } %t235)
  store %"compiler/diagmsg:Msg" %t236, ptr %l123
  br label %bb60
bb60:
  %t237 = load ptr, ptr %l117, !tbaa !29
  %t238 = load %"compiler/source:Span", ptr %l118
  %t239 = load %"compiler/diagmsg:Msg", ptr %l123
  %t240 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t237, %"compiler/source:Span" %t238, %"compiler/diagmsg:Msg" %t239)
  store i64 %t240, ptr %l124
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb62:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = getelementptr %"compiler/check:Checker", ptr %t242, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t247 = getelementptr %"compiler/generic:Program", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  store ptr %t248, ptr %l128, !tbaa !29
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t251 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t249)
  store ptr %t251, ptr %l130
  br label %bb63
bb63:
  %t252 = load ptr, ptr %l130, !tbaa !29
  %t254 = getelementptr %"compiler/check:frame", ptr %t252, i32 0, i32 2
  %t255 = load i64, ptr %t254, !tbaa !24
  %t256 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t257 = load i32, ptr %t256, !tbaa !23
  %t258 = load ptr, ptr %l128, !tbaa !29
  %t261 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t258, i64 %t255, i32 %t257)
  store %"compiler/names:Ref" %t261, ptr %l134
  br label %bb64
bb64:
  %t262 = load %"compiler/names:Ref", ptr %l134
  store %"compiler/names:Ref" %t262, ptr %l7
  %t263 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t264 = load i32, ptr %t263, !range !{i32 0, i32 9}
  %t266 = trunc i64 4 to i32
  %t267 = icmp eq i32 %t264, %t266
  br i1 %t267, label %bb65, label %bb66
bb65:
  %t269 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t270 = load i64, ptr %t269, !tbaa !24
  %t272 = icmp sge i64 %t270, 0
  store i1 %t272, ptr %l137, !tbaa !21
  br label %bb67
bb66:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb67
bb67:
  %t274 = load i1, ptr %l137, !tbaa !21
  br i1 %t274, label %bb68, label %bb69
bb68:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t275)
  store ptr %t277, ptr %l142
  br label %bb70
bb69:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb72
bb70:
  %t278 = load ptr, ptr %l142, !tbaa !29
  %t280 = getelementptr %"compiler/check:frame", ptr %t278, i32 0, i32 4
  %t281 = getelementptr %"compiler/generic:Context", ptr %t280, i32 0, i32 2
  %t282 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t282, ptr %l145, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t283, 0
  %t287 = sub i64 %t285, 1
  %t289 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !27
  %t291 = getelementptr i32, ptr %t290, i64 %t287
  %t292 = load i32, ptr %t291, !tbaa !33
  %t295 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %t281, i32 %t292)
  store i1 %t295, ptr %l150
  br label %bb71
bb71:
  %t296 = load i1, ptr %l150, !tbaa !21
  %t297 = xor i1 %t296, true
  store i1 %t297, ptr %l140, !tbaa !21
  br label %bb72
bb72:
  %t299 = load i1, ptr %l140, !tbaa !21
  br i1 %t299, label %bb73, label %bb74
bb73:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t303 = load %"compiler/names:Ref", ptr %l7
  %t308 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgCountMet(ptr %v0, ptr %v2, ptr %v3, ptr %t300, { i64, ptr } %t301, { i64, ptr } %t302, %"compiler/names:Ref" %t303)
  store i1 %t308, ptr %l157
  br label %bb75
bb74:
  store i1 false, ptr %l152, !tbaa !21
  br label %bb76
bb75:
  %t309 = load i1, ptr %l157, !tbaa !21
  %t310 = xor i1 %t309, true
  store i1 %t310, ptr %l152, !tbaa !21
  br label %bb76
bb76:
  %t312 = load i1, ptr %l152, !tbaa !21
  br i1 %t312, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t314 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t318 = icmp eq i64 %t316, 0
  br i1 %t318, label %bb80, label %bb81
bb80:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  %t321 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t325 = icmp eq i64 %t323, 1
  br i1 %t325, label %bb83, label %bb84
bb83:
  %t327 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t327, 0
  %t331 = icmp sgt i64 %t329, 1
  store i1 %t331, ptr %l167, !tbaa !21
  br label %bb85
bb84:
  store i1 false, ptr %l167, !tbaa !21
  br label %bb85
bb85:
  %t333 = load i1, ptr %l167, !tbaa !21
  br i1 %t333, label %bb86, label %bb87
bb86:
  %t334 = load ptr, ptr %l0, !tbaa !29
  %t335 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t335, ptr %l173, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = getelementptr i32, ptr %t337, i64 0
  %t339 = load i32, ptr %t338, !tbaa !33
  %t342 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t334, i32 %t339)
  store { i64, ptr } %t342, ptr %l175
  br label %bb88
bb87:
  store i1 false, ptr %l171, !tbaa !21
  br label %bb90
bb88:
  %t343 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t344 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t343, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t344, ptr %l176
  br label %bb89
bb89:
  %t345 = load i1, ptr %l176, !tbaa !21
  store i1 %t345, ptr %l171, !tbaa !21
  br label %bb90
bb90:
  %t346 = load i1, ptr %l171, !tbaa !21
  br i1 %t346, label %bb91, label %bb92
bb91:
  %t347 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t348 = load i32, ptr %t347, !range !{i32 0, i32 9}
  %t350 = trunc i64 7 to i32
  %t351 = icmp eq i32 %t348, %t350
  store i1 %t351, ptr %l177, !tbaa !21
  br label %bb93
bb92:
  store i1 false, ptr %l177, !tbaa !21
  br label %bb93
bb93:
  %t353 = load i1, ptr %l177, !tbaa !21
  br i1 %t353, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s9
  %t354 = load ptr, ptr %l0, !tbaa !29
  store ptr %t354, ptr %l180, !tbaa !29
  %t355 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t355, ptr %l181, !tbaa !27
  %t356 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !27
  %t358 = getelementptr ptr, ptr %t357, i64 1
  %t359 = load ptr, ptr %t358, !tbaa !39
  %t361 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t359)
  store %"compiler/source:Span" %t361, ptr %l183
  br label %bb96
bb95:
  br label %bb99
bb96:
  %t362 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t364 = extractvalue { i64, ptr } %t362, 0
  %t366 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %s9, i64 %t364)
  store %"compiler/diagmsg:Msg" %t366, ptr %l186
  br label %bb97
bb97:
  %t367 = load ptr, ptr %l180, !tbaa !29
  %t368 = load %"compiler/source:Span", ptr %l183
  %t369 = load %"compiler/diagmsg:Msg", ptr %l186
  %t370 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s9, ptr %t367, %"compiler/source:Span" %t368, %"compiler/diagmsg:Msg" %t369)
  store i64 %t370, ptr %l187
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb99:
  %t372 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t372, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l10, !tbaa !24
  br label %bb100
bb100:
  %t378 = load i64, ptr %l9, !tbaa !24
  %t379 = load i64, ptr %l10, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb101, label %bb102
bb101:
  br label %bb113
bb102:
  br label %bb103
bb103:
  %t386 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t386, ptr %l196, !tbaa !27
  %t387 = load i64, ptr %l9, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l196, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr ptr, ptr %t390, i64 %t387
  %t392 = load ptr, ptr %t391, !tbaa !39
  store ptr %t392, ptr %l11, !tbaa !29
  %t394 = load ptr, ptr %l11, !tbaa !29
  %t396 = call i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v3, ptr %t394)
  store i1 %t396, ptr %l200
  br label %bb104
bb104:
  %t397 = load i1, ptr %l200, !tbaa !21
  br i1 %t397, label %bb105, label %bb106
bb105:
  br label %bb112
bb106:
  br label %bb107
bb107:
  %t398 = load ptr, ptr %l0, !tbaa !29
  %t399 = load ptr, ptr %l11, !tbaa !29
  %t402 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgMet(ptr %v0, ptr %v3, ptr %t398, ptr %t399)
  store i1 %t402, ptr %l203
  br label %bb108
bb108:
  %t403 = load i1, ptr %l203, !tbaa !21
  %t404 = xor i1 %t403, true
  br i1 %t404, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t407 = load i64, ptr %l9, !tbaa !24
  %t409 = add i64 %t407, 1
  store i64 %t409, ptr %l9, !tbaa !24
  br label %bb100
bb113:
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t413 = getelementptr %"compiler/check:Checker", ptr %t411, i32 0, i32 1
  %t414 = load ptr, ptr %t413, !tbaa !29
  store ptr %t414, ptr %l209, !tbaa !29
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t415)
  store ptr %t417, ptr %l211
  br label %bb114
bb114:
  %t418 = load ptr, ptr %l211, !tbaa !29
  %t420 = getelementptr %"compiler/check:frame", ptr %t418, i32 0, i32 4
  %t421 = load ptr, ptr %l1, !tbaa !29
  %t423 = load ptr, ptr %l209, !tbaa !29
  %t426 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v0, ptr %v1, ptr %t423, ptr %t420, ptr %t421)
  store i32 %t426, ptr %l216
  br label %bb115
bb115:
  %t427 = load i32, ptr %l216, !tbaa !23
  store i32 %t427, ptr %l12, !tbaa !23
  %t428 = load i1, ptr %l6, !tbaa !21
  %t430 = xor i1 %t428, true
  br i1 %t430, label %bb116, label %bb117
bb116:
  %t432 = load ptr, ptr %l0, !tbaa !29
  store ptr %t432, ptr %l220, !tbaa !29
  %t433 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t433, ptr %l221, !tbaa !27
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load i32, ptr %l12, !tbaa !23
  %t438 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownBuffer(ptr %v0, ptr %t434, i32 %t435)
  store i32 %t438, ptr %l224
  br label %bb118
bb117:
  store i1 false, ptr %l219, !tbaa !21
  br label %bb120
bb118:
  %t439 = load ptr, ptr %l220, !tbaa !29
  %t440 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t441 = load i32, ptr %l224, !tbaa !23
  %t442 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunendedArgs(ptr %v0, ptr %v3, ptr %t439, { i64, ptr } %t440, i32 %t441)
  store i1 %t442, ptr %l225
  br label %bb119
bb119:
  %t443 = load i1, ptr %l225, !tbaa !21
  %t444 = xor i1 %t443, true
  store i1 %t444, ptr %l219, !tbaa !21
  br label %bb120
bb120:
  %t446 = load i1, ptr %l219, !tbaa !21
  br i1 %t446, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb122:
  br label %bb123
bb123:
  %t448 = load ptr, ptr %l0, !tbaa !29
  store ptr %t448, ptr %l228, !tbaa !29
  %t449 = load i32, ptr %l12, !tbaa !23
  store i32 %t449, ptr %l229, !tbaa !23
  %t450 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t450, ptr %l230, !tbaa !27
  %t451 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !27
  %t453 = getelementptr ptr, ptr %t452, i64 0
  %t454 = load ptr, ptr %t453, !tbaa !39
  %t456 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v3, ptr %t454)
  store %"compiler/source:Span" %t456, ptr %l232
  br label %bb124
bb124:
  %t457 = load ptr, ptr %l228, !tbaa !29
  %t458 = load i32, ptr %l229, !tbaa !23
  %t459 = load %"compiler/source:Span", ptr %l232
  %t460 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %t457, i32 %t458, %"compiler/source:Span" %t459)
  store i1 %t460, ptr %l233
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s0)
  %t461 = load i1, ptr %l233, !tbaa !21
  store i1 %t461, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enamesType(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca { i64, ptr }
  %l17 = alloca i32
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %l31 = alloca i64
  %l35 = alloca i1
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l72 = alloca ptr
  %l75 = alloca i1
  %l80 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l2, !tbaa !23
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t1, i32 %t2)
  store { i64, ptr } %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t16 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v0, ptr %t12, { i64, ptr } %t13)
  store i32 %t16, ptr %l17
  br label %bb2
bb2:
  %t17 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t18 = load i32, ptr %l17, !tbaa !23
  %t20 = icmp ne i32 %t18, %t17
  br i1 %t20, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb6
bb4:
  %t22 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t24 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t22, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  store i1 %t24, ptr %l22
  br label %bb5
bb5:
  %t25 = load i1, ptr %l22, !tbaa !21
  store i1 %t25, ptr %l20, !tbaa !21
  br label %bb6
bb6:
  %t26 = load i1, ptr %l20, !tbaa !21
  br i1 %t26, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb10
bb8:
  %t27 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t29, ptr %l25
  br label %bb9
bb9:
  %t30 = load i1, ptr %l25, !tbaa !21
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb10
bb10:
  %t31 = load i1, ptr %l23, !tbaa !21
  br i1 %t31, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t33, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = load i32, ptr %l2, !tbaa !23
  %t42 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t36, i64 %a1, i32 %t38)
  store i64 %t42, ptr %l31
  br label %bb14
bb14:
  %t43 = load i64, ptr %l31, !tbaa !24
  %t44 = icmp sge i64 %t43, 0
  br i1 %t44, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t47 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t49 = call i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %t47)
  store i1 %t49, ptr %l35
  br label %bb18
bb18:
  %t50 = load i1, ptr %l35, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  store i64 0, ptr %l4, !tbaa !24
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 0
  %t60 = load ptr, ptr %t59, !tbaa !29
  %t62 = getelementptr %"compiler/load:Loader", ptr %t60, i32 0, i32 10
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l42
  br label %bb22
bb22:
  %t65 = load i64, ptr %l42, !tbaa !24
  store i64 %t65, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t67 = load i64, ptr %l4, !tbaa !24
  %t70 = icmp sgt i64 %t66, %t67
  br i1 %t70, label %bb23, label %bb24
bb23:
  %t72 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sgt i64 %t72, 0
  br i1 %t74, label %bb25, label %bb26
bb24:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb28
bb25:
  %t76 = load i64, ptr %l5, !tbaa !24
  %t77 = load i64, ptr %l4, !tbaa !24
  %t80 = sub i64 %t76, %t77
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = add i64 %t80, %t81
  %t86 = sub i64 %t84, 1
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = sdiv i64 %t86, %t87
  store i64 %t90, ptr %l49, !tbaa !24
  br label %bb27
bb26:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb27
bb27:
  %t92 = load i64, ptr %l49, !tbaa !24
  store i64 %t92, ptr %l46, !tbaa !24
  br label %bb28
bb28:
  %t93 = load i64, ptr %l46, !tbaa !24
  store i64 %t93, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb29
bb29:
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t98 = icmp slt i64 %t94, %t95
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb30, label %bb31
bb30:
  br label %bb42
bb31:
  br label %bb32
bb32:
  %t102 = load i64, ptr %l4, !tbaa !24
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  %t107 = mul i64 %t103, %t104
  %t110 = add i64 %t102, %t107
  store i64 %t110, ptr %l9, !tbaa !24
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/check:Checker", ptr %t112, i32 0, i32 1
  %t115 = load ptr, ptr %t114, !tbaa !29
  %t117 = getelementptr %"compiler/generic:Program", ptr %t115, i32 0, i32 0
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t120 = getelementptr %"compiler/load:Loader", ptr %t118, i32 0, i32 10
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t120, i64 %t121)
  store ptr %t124, ptr %l72
  br label %bb33
bb33:
  %t125 = load ptr, ptr %l72, !tbaa !29
  %t127 = getelementptr %"compiler/load:Module", ptr %t125, i32 0, i32 3
  %t128 = load i1, ptr %t127, !tbaa !21
  br i1 %t128, label %bb34, label %bb35
bb34:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t134 = load i64, ptr %l9, !tbaa !24
  %t135 = load i32, ptr %l2, !tbaa !23
  %t139 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %t133, i64 %t134, i32 %t135)
  store i64 %t139, ptr %l80
  br label %bb36
bb35:
  store i1 false, ptr %l75, !tbaa !21
  br label %bb37
bb36:
  %t140 = load i64, ptr %l80, !tbaa !24
  %t141 = icmp sge i64 %t140, 0
  store i1 %t141, ptr %l75, !tbaa !21
  br label %bb37
bb37:
  %t143 = load i1, ptr %l75, !tbaa !21
  br i1 %t143, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t145 = load i64, ptr %l8, !tbaa !24
  %t147 = add i64 %t145, 1
  store i64 %t147, ptr %l8, !tbaa !24
  br label %bb29
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enarrowedField(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/check:narrowed"
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca ptr
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l49 = alloca ptr
  %l52 = alloca i64
  %l56 = alloca %"compiler/check:narrowed"
  %l60 = alloca i1
  %l63 = alloca ptr
  %l68 = alloca i32
  %l69 = alloca ptr
  %l71 = alloca ptr
  %l74 = alloca i1
  %l89 = alloca i64
  %l92 = alloca i64
  %l110 = alloca { i64, ptr }
  %l121 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l20
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l20, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t7 = getelementptr %"compiler/check:frame", ptr %t5, i32 0, i32 46
  %t9 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t7)
  store i64 %t9, ptr %l23
  br label %bb2
bb2:
  %t10 = load i64, ptr %l23, !tbaa !24
  store i64 %t10, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp sgt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load i64, ptr %l6, !tbaa !24
  %t19 = icmp sgt i64 %t17, 0
  br i1 %t19, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb8
bb5:
  %t21 = load i64, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t25 = sub i64 %t21, %t22
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = add i64 %t25, %t26
  %t31 = sub i64 %t29, 1
  %t32 = load i64, ptr %l6, !tbaa !24
  %t35 = sdiv i64 %t31, %t32
  store i64 %t35, ptr %l30, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l30, !tbaa !24
  store i64 %t37, ptr %l27, !tbaa !24
  br label %bb8
bb8:
  %t38 = load i64, ptr %l27, !tbaa !24
  store i64 %t38, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp slt i64 %t39, %t40
  %t45 = xor i1 %t43, true
  br i1 %t45, label %bb10, label %bb11
bb10:
  br label %bb50
bb11:
  br label %bb12
bb12:
  %t47 = load i64, ptr %l4, !tbaa !24
  %t48 = load i64, ptr %l8, !tbaa !24
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = mul i64 %t48, %t49
  %t55 = add i64 %t47, %t52
  store i64 %t55, ptr %l9, !tbaa !24
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = getelementptr %"compiler/check:frame", ptr %t57, i32 0, i32 46
  store ptr %t59, ptr %l49, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t62 = getelementptr %"compiler/check:frame", ptr %t60, i32 0, i32 46
  %t64 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t62)
  store i64 %t64, ptr %l52
  br label %bb13
bb13:
  %t65 = load i64, ptr %l52, !tbaa !24
  %t66 = sub i64 %t65, 1
  %t67 = load i64, ptr %l9, !tbaa !24
  %t70 = sub i64 %t66, %t67
  %t71 = load ptr, ptr %l49, !tbaa !29
  %t73 = call %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %t71, i64 %t70)
  store %"compiler/check:narrowed" %t73, ptr %l56
  br label %bb14
bb14:
  %t74 = load %"compiler/check:narrowed", ptr %l56
  store %"compiler/check:narrowed" %t74, ptr %l10
  %t75 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 0
  %t76 = load i64, ptr %t75, !tbaa !24
  %t80 = icmp ne i64 %t76, %a1
  br i1 %t80, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb17
bb16:
  %t82 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 5
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l60, !tbaa !21
  br label %bb17
bb17:
  %t85 = load i1, ptr %l60, !tbaa !21
  br i1 %t85, label %bb18, label %bb19
bb18:
  br label %bb49
bb19:
  br label %bb20
bb20:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/check:Checker", ptr %t86, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !29
  store ptr %t89, ptr %l63, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 2
  %t96 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 2
  %t97 = load i32, ptr %t96, !tbaa !23
  %t100 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t95, i32 %t97)
  store i32 %t100, ptr %l68
  br label %bb21
bb21:
  %t101 = load ptr, ptr %l63, !tbaa !29
  %t102 = load i32, ptr %l68, !tbaa !23
  %t103 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v0, ptr %t101, i32 %t102)
  store ptr %t103, ptr %l69
  br label %bb22
bb22:
  %t104 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 1
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load ptr, ptr %l69, !tbaa !29
  %t108 = call ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v0, ptr %t106, i64 %t105)
  store ptr %t108, ptr %l71
  br label %bb23
bb23:
  %t109 = load ptr, ptr %l71, !tbaa !29
  store ptr %t109, ptr %l11, !tbaa !29
  %t110 = load ptr, ptr %l11, !tbaa !29
  %t112 = icmp eq ptr %t110, null
  br i1 %t112, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb26
bb25:
  %t114 = load ptr, ptr %l11, !tbaa !29
  %t116 = getelementptr %"compiler/ast:CaseDecl", ptr %t114, i32 0, i32 3
  %t117 = load i1, ptr %t116, !tbaa !21
  store i1 %t117, ptr %l74, !tbaa !21
  br label %bb26
bb26:
  %t119 = load i1, ptr %l74, !tbaa !21
  br i1 %t119, label %bb27, label %bb28
bb27:
  store i64 -1, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  %t121 = load ptr, ptr %l11, !tbaa !29
  %t123 = getelementptr %"compiler/ast:CaseDecl", ptr %t121, i32 0, i32 2
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l12, !tbaa !27
  %t126 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t130 = icmp eq i64 %t128, 0
  br i1 %t130, label %bb30, label %bb31
bb30:
  store i64 -1, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  store i64 0, ptr %l13, !tbaa !24
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t137 = load i64, ptr %l14, !tbaa !24
  %t138 = load i64, ptr %l13, !tbaa !24
  %t141 = icmp sgt i64 %t137, %t138
  br i1 %t141, label %bb33, label %bb34
bb33:
  %t143 = load i64, ptr %l15, !tbaa !24
  %t145 = icmp sgt i64 %t143, 0
  br i1 %t145, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l89, !tbaa !24
  br label %bb38
bb35:
  %t147 = load i64, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l13, !tbaa !24
  %t151 = sub i64 %t147, %t148
  %t152 = load i64, ptr %l15, !tbaa !24
  %t155 = add i64 %t151, %t152
  %t157 = sub i64 %t155, 1
  %t158 = load i64, ptr %l15, !tbaa !24
  %t161 = sdiv i64 %t157, %t158
  store i64 %t161, ptr %l92, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb37
bb37:
  %t163 = load i64, ptr %l92, !tbaa !24
  store i64 %t163, ptr %l89, !tbaa !24
  br label %bb38
bb38:
  %t164 = load i64, ptr %l89, !tbaa !24
  store i64 %t164, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb39
bb39:
  %t165 = load i64, ptr %l17, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t173 = load i64, ptr %l13, !tbaa !24
  %t174 = load i64, ptr %l17, !tbaa !24
  %t175 = load i64, ptr %l15, !tbaa !24
  %t178 = mul i64 %t174, %t175
  %t181 = add i64 %t173, %t178
  store i64 %t181, ptr %l18, !tbaa !24
  %t183 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t183, ptr %l110, !tbaa !27
  %t184 = load i64, ptr %l18, !tbaa !24
  %t186 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !27
  %t188 = getelementptr ptr, ptr %t187, i64 %t184
  %t189 = load ptr, ptr %t188, !tbaa !39
  %t191 = getelementptr %"compiler/ast:Param", ptr %t189, i32 0, i32 1
  %t192 = load i32, ptr %t191, !tbaa !23
  %t196 = icmp eq i32 %t192, %a2
  br i1 %t196, label %bb43, label %bb44
bb43:
  %t198 = load ptr, ptr %l3, !tbaa !29
  %t200 = getelementptr %"compiler/check:frame", ptr %t198, i32 0, i32 47
  %t201 = getelementptr %"compiler/check:narrowed", ptr %l10, i32 0, i32 3
  %t202 = load i64, ptr %t201, !tbaa !24
  %t203 = load i64, ptr %l18, !tbaa !24
  %t206 = add i64 %t202, %t203
  %t209 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t200, i64 %t206)
  store i64 %t209, ptr %l121
  br label %bb45
bb44:
  br label %bb46
bb45:
  %t210 = load i64, ptr %l121, !tbaa !24
  store i64 %t210, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  %t211 = load i64, ptr %l17, !tbaa !24
  %t213 = add i64 %t211, 1
  store i64 %t213, ptr %l17, !tbaa !24
  br label %bb39
bb48:
  store i64 -1, ptr %rv
  br label %ret
bb49:
  %t216 = load i64, ptr %l8, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l8, !tbaa !24
  br label %bb9
bb50:
  store i64 -1, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enewBody(ptr %v0, ptr %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l13 = alloca i32
  %l14 = alloca { i64, [2 x i64] }
  %l15 = alloca i32
  %l21 = alloca ptr
  %l25 = alloca %"compiler/typed:Body"
  %rv = alloca i64
  %t34 = alloca %"compiler/typed:Body", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 14
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 14
  store ptr %t9, ptr %l10, !tbaa !29
  %t10 = load i64, ptr %l5, !tbaa !24
  %t12 = trunc i64 %t10 to i32
  store i32 %t12, ptr %l13, !tbaa !23
  store { i64, [2 x i64] } %a1, ptr %l14
  store i32 %a2, ptr %l15, !tbaa !23
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 10
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t24, i64 %a3)
  store ptr %t28, ptr %l21
  br label %bb2
bb2:
  %t29 = load ptr, ptr %l21, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = load i32, ptr %l13, !tbaa !23
  %t36 = load { i64, [2 x i64] }, ptr %l14
  %t37 = load i32, ptr %l15, !tbaa !23
  call void @compiler_2ftyped_3aBody_2ector(ptr %t34, ptr %v0, i32 %t35, { i64, [2 x i64] } %t36, i32 %t37, i64 %t32, %"compiler/source:Span" %a4)
  call void @llvm.memmove.p0.p0.i64(ptr %l25, ptr %t34, i64 408, i1 false)
  br label %bb3
bb3:
  %t40 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 408, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t40, ptr %l25, i64 408, i1 false)
  %t41 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Hb4635a51dd989c2102029bfb32ae3a2f(ptr %v0, ptr %v0, ptr %t41, ptr %t40)
  br label %bb4
bb4:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 19
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t45, i64 0)
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 17
  %t50 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t49, i64 %t50)
  br label %bb6
bb6:
  %t53 = load i64, ptr %l5, !tbaa !24
  store i64 %t53, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enormalSet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca i32
  %l17 = alloca ptr
  %l22 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i32
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store ptr %a1, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l4, !tbaa !24
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load ptr, ptr %l3, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb16
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load i64, ptr %l4, !tbaa !24
  %t21 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v1, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l16
  br label %bb7
bb7:
  %t22 = load i32, ptr %l16, !tbaa !23
  store i32 %t22, ptr %l5, !tbaa !23
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l17, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l5, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l22
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l5, !tbaa !23
  %t43 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %t39, i32 %t40)
  store i64 %t43, ptr %l27
  br label %bb9
bb9:
  %t44 = load ptr, ptr %l17, !tbaa !29
  %t45 = load i32, ptr %l22, !tbaa !23
  %t46 = load i64, ptr %l27, !tbaa !65
  %t47 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %t44, i32 %t45, i64 %t46)
  store i32 %t47, ptr %l28
  br label %bb10
bb10:
  %t48 = load i32, ptr %l28, !tbaa !23
  store i32 %t48, ptr %l6, !tbaa !23
  %t49 = load i32, ptr %l6, !tbaa !23
  %t50 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t53 = icmp ne i32 %t49, %t50
  br i1 %t53, label %bb11, label %bb12
bb11:
  %t55 = load ptr, ptr %lp2
  %t56 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v2, ptr %t55, i32 %t56)
  br label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t59 = load i64, ptr %l4, !tbaa !24
  %t61 = add i64 %t59, 1
  store i64 %t61, ptr %l4, !tbaa !24
  br label %bb2
bb16:
  %t63 = load ptr, ptr %lp2
  %t64 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t63
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRawBits(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l7 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i1
  %l20 = alloca i32
  %l22 = alloca ptr
  %l27 = alloca i32
  %l30 = alloca i1
  %l32 = alloca i1
  %l37 = alloca i32
  %l42 = alloca ptr
  %l47 = alloca i32
  %l50 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %t6, i32 %a1)
  store i32 %t10, ptr %l7
  br label %bb1
bb1:
  %t11 = load i32, ptr %l7, !tbaa !23
  store i32 %t11, ptr %l2, !tbaa !23
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l12
  br label %bb2
bb2:
  %t22 = load i32, ptr %l12, !range !{i32 0, i32 33}
  %t24 = trunc i64 19 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb3, label %bb4
bb3:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 2
  %t33 = load i32, ptr %l2, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %t32, i32 %t33)
  store i32 %t36, ptr %l20
  br label %bb5
bb4:
  store i1 false, ptr %l15, !tbaa !21
  br label %bb6
bb5:
  %t37 = load i32, ptr %l20, !tbaa !23
  %t38 = icmp ne i32 %t37, 0
  store i1 %t38, ptr %l15, !tbaa !21
  br label %bb6
bb6:
  %t40 = load i1, ptr %l15, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l2, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l27
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t52 = load ptr, ptr %l22, !tbaa !29
  %t53 = load i32, ptr %l27, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoteRawBits(ptr %v0, ptr %t52, i32 %t53)
  br label %bb10
bb10:
  br label %ret
bb11:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = load i32, ptr %l2, !tbaa !23
  %t58 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %t54, i32 %t55)
  store i1 %t58, ptr %l30
  br label %bb12
bb12:
  %t59 = load i1, ptr %l30, !tbaa !21
  %t60 = xor i1 %t59, true
  br i1 %t60, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb16
bb14:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l2, !tbaa !23
  %t71 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawType(ptr %v0, ptr %t67, i32 %t68)
  store i32 %t71, ptr %l37
  br label %bb15
bb15:
  %t72 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t73 = load i32, ptr %l37, !tbaa !23
  %t75 = icmp eq i32 %t73, %t72
  store i1 %t75, ptr %l32, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l32, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  br label %ret
bb18:
  br label %bb19
bb19:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  store ptr %t83, ptr %l42, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = getelementptr %"compiler/generic:Program", ptr %t87, i32 0, i32 2
  %t90 = load i32, ptr %l2, !tbaa !23
  %t93 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t89, i32 %t90)
  store i32 %t93, ptr %l47
  br label %bb20
bb20:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t95 = load i32, ptr %l2, !tbaa !23
  %t98 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v0, ptr %t94, i32 %t95)
  store ptr %t98, ptr %l50
  br label %bb21
bb21:
  %t99 = load ptr, ptr %l50, !tbaa !29
  %t101 = getelementptr %"compiler/check:rawTable", ptr %t99, i32 0, i32 2
  %t102 = load { i64, ptr }, ptr %t101, !tbaa !27
  %t103 = load ptr, ptr %l42, !tbaa !29
  %t104 = load i32, ptr %l47, !tbaa !23
  call void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetRawBits(ptr %v0, ptr %v0, ptr %t103, i32 %t104, { i64, ptr } %t102)
  br label %bb22
bb22:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOn(ptr %v0, ptr %a0, i64 %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/generic:Binding"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i32
  %l18 = alloca ptr
  %l21 = alloca ptr
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %l37 = alloca i64
  %l41 = alloca i64
  %l44 = alloca { i64, ptr }
  %l49 = alloca %"compiler/generic:Binding"
  %l51 = alloca { i64, ptr }
  %l55 = alloca i64
  %l63 = alloca i64
  %l66 = alloca i64
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l100 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca { i64, ptr }
  %l107 = alloca i32
  %l108 = alloca i64
  %l113 = alloca i32
  %l114 = alloca i32
  %l119 = alloca i1
  %l120 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l18, !tbaa !29
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  store ptr %t12, ptr %l21, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t17 = load i64, ptr %l1, !tbaa !24
  %t20 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t16, i64 %t17)
  store i32 %t20, ptr %l25
  br label %bb1
bb1:
  %t21 = load ptr, ptr %l21, !tbaa !29
  %t22 = load i32, ptr %l25, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t21, i32 %t22)
  store i32 %t23, ptr %l26
  br label %bb2
bb2:
  %t24 = load ptr, ptr %l18, !tbaa !29
  %t25 = load i32, ptr %l26, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l27
  br label %bb3
bb3:
  %t27 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t27, ptr %l4, !tbaa !27
  %t28 = load i64, ptr %l3, !tbaa !24
  %t30 = icmp slt i64 %t28, 0
  br i1 %t30, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb6
bb5:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t38 = icmp sge i64 %t32, %t35
  store i1 %t38, ptr %l30, !tbaa !21
  br label %bb6
bb6:
  %t40 = load i1, ptr %l30, !tbaa !21
  br i1 %t40, label %bb7, label %bb8
bb7:
  %t41 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t41, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t43 = load i64, ptr %l1, !tbaa !24
  %t45 = call i64 @compiler_2fgeneric_2eFnOwner(i64 %t43)
  store i64 %t45, ptr %l37
  br label %bb10
bb10:
  %t46 = load i64, ptr %l37, !tbaa !24
  store i64 %t46, ptr %l5, !tbaa !24
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %t50, i64 %t51)
  store i64 %t54, ptr %l41
  br label %bb11
bb11:
  %t55 = load i64, ptr %l41, !tbaa !24
  store i64 %t55, ptr %l6, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t58 = icmp eq i64 %t56, 0
  br i1 %t58, label %bb12, label %bb13
bb12:
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t60, ptr %l44, !tbaa !27
  %t61 = load i64, ptr %l3, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr i32, ptr %t64, i64 %t61
  %t66 = load i32, ptr %t65, !tbaa !33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t66, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t68 = load i64, ptr %l5, !tbaa !24
  %t69 = load i64, ptr %l6, !tbaa !24
  %t72 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t68, i64 %t69)
  store %"compiler/generic:Binding" %t72, ptr %l49
  br label %bb15
bb15:
  %t73 = load %"compiler/generic:Binding", ptr %l49
  store %"compiler/generic:Binding" %t73, ptr %l7
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t75, ptr %l51, !tbaa !27
  %t76 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !27
  %t78 = getelementptr i32, ptr %t77, i64 0
  %t79 = load i32, ptr %t78, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %s0, ptr %t74, i32 %t79, i32 %a2, ptr %l7, i1 false, i1 true)
  br label %bb16
bb16:
  %t85 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 1
  %t86 = load i64, ptr %t85, !tbaa !24
  store i64 %t86, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l55, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load i64, ptr %l55, !tbaa !24
  %t91 = icmp sle i64 %t90, 2305843009213693951
  br i1 %t91, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d8c7da3a96e96ec6_ffec47baa4f6769a)
  unreachable
bb19:
  %t93 = load i64, ptr %l55, !tbaa !24
  %t94 = mul i64 %t93, 4
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t99 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 1
  %t100 = load i64, ptr %t99, !tbaa !24
  store i64 %t100, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = icmp sgt i64 %t102, %t103
  br i1 %t106, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_d8c7da3a96e96ec6_ffec47baa4f6769a)
  unreachable
bb21:
  %t108 = load i64, ptr %l11, !tbaa !24
  %t110 = icmp sgt i64 %t108, 0
  br i1 %t110, label %bb23, label %bb24
bb22:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb26
bb23:
  %t112 = load i64, ptr %l10, !tbaa !24
  %t113 = load i64, ptr %l9, !tbaa !24
  %t116 = sub i64 %t112, %t113
  %t117 = load i64, ptr %l11, !tbaa !24
  %t120 = add i64 %t116, %t117
  %t122 = sub i64 %t120, 1
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = sdiv i64 %t122, %t123
  store i64 %t126, ptr %l66, !tbaa !24
  br label %bb25
bb24:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb25
bb25:
  %t128 = load i64, ptr %l66, !tbaa !24
  store i64 %t128, ptr %l63, !tbaa !24
  br label %bb26
bb26:
  %t129 = load i64, ptr %l63, !tbaa !24
  store i64 %t129, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb27
bb27:
  %t130 = load i64, ptr %l13, !tbaa !24
  %t131 = load i64, ptr %l12, !tbaa !24
  %t134 = icmp slt i64 %t130, %t131
  %t136 = xor i1 %t134, true
  br i1 %t136, label %bb28, label %bb29
bb28:
  br label %bb36
bb29:
  br label %bb30
bb30:
  %t138 = load i64, ptr %l9, !tbaa !24
  %t139 = load i64, ptr %l13, !tbaa !24
  %t140 = load i64, ptr %l11, !tbaa !24
  %t143 = mul i64 %t139, %t140
  %t146 = add i64 %t138, %t143
  store i64 %t146, ptr %l14, !tbaa !24
  %t148 = load i64, ptr %l14, !tbaa !24
  store i64 %t148, ptr %l84, !tbaa !24
  %t149 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  store { i64, ptr } %t150, ptr %l85, !tbaa !27
  %t151 = load i64, ptr %l14, !tbaa !24
  %t153 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !27
  %t155 = getelementptr i32, ptr %t154, i64 %t151
  %t156 = load i32, ptr %t155, !tbaa !33
  %t157 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t160 = icmp ne i32 %t156, %t157
  br i1 %t160, label %bb31, label %bb32
bb31:
  %t162 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 2
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l91, !tbaa !27
  %t164 = load i64, ptr %l14, !tbaa !24
  %t166 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = getelementptr i32, ptr %t167, i64 %t164
  %t169 = load i32, ptr %t168, !tbaa !33
  store i32 %t169, ptr %l90, !tbaa !23
  br label %bb34
bb32:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t171, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 0
  %t178 = load i64, ptr %t177, !tbaa !24
  %t179 = load i64, ptr %l14, !tbaa !24
  %t180 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t185 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %t176, i64 %t178, i64 %t179, i64 %t180)
  store i32 %t185, ptr %l100
  br label %bb33
bb33:
  %t186 = load i32, ptr %l100, !tbaa !23
  store i32 %t186, ptr %l90, !tbaa !23
  br label %bb34
bb34:
  %t187 = load i32, ptr %l90, !tbaa !23
  %t188 = load i64, ptr %l84, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i32, ptr %t190, i64 %t188
  store i32 %t187, ptr %t191, !tbaa !33
  br label %bb35
bb35:
  %t192 = load i64, ptr %l13, !tbaa !24
  %t194 = add i64 %t192, 1
  store i64 %t194, ptr %l13, !tbaa !24
  br label %bb27
bb36:
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  store ptr %t199, ptr %l104, !tbaa !29
  %t200 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t200, ptr %l105, !tbaa !27
  %t201 = load i64, ptr %l3, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr i32, ptr %t204, i64 %t201
  %t206 = load i32, ptr %t205, !tbaa !33
  store i32 %t206, ptr %l107, !tbaa !23
  %t207 = getelementptr %"compiler/generic:Binding", ptr %l7, i32 0, i32 0
  %t208 = load i64, ptr %t207, !tbaa !24
  store i64 %t208, ptr %l108, !tbaa !24
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t209, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t214 = getelementptr %"compiler/generic:Program", ptr %t212, i32 0, i32 2
  %t215 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t218 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t214, { i64, ptr } %t215)
  store i32 %t218, ptr %l113
  br label %bb37
bb37:
  %t219 = load ptr, ptr %l104, !tbaa !29
  %t220 = load i32, ptr %l107, !tbaa !23
  %t221 = load i64, ptr %l108, !tbaa !24
  %t222 = load i32, ptr %l113, !tbaa !23
  %t223 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t219, i32 %t220, i64 %t221, i32 %t222)
  store i32 %t223, ptr %l114
  br label %bb38
bb38:
  %t224 = load i32, ptr %l114, !tbaa !23
  store i32 %t224, ptr %l15, !tbaa !23
  %t225 = load ptr, ptr %l0, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t225, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t230 = getelementptr %"compiler/generic:Program", ptr %t228, i32 0, i32 2
  %t231 = load i32, ptr %l15, !tbaa !23
  %t234 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %t230, i32 %t231)
  store i1 %t234, ptr %l119
  br label %bb39
bb39:
  %t235 = load i1, ptr %l119, !tbaa !21
  br i1 %t235, label %bb40, label %bb41
bb40:
  %t236 = load i32, ptr %l15, !tbaa !23
  store i32 %t236, ptr %l120, !tbaa !23
  br label %bb42
bb41:
  %t238 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  store i32 %t238, ptr %l120, !tbaa !23
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  %t240 = load i32, ptr %l120, !tbaa !23
  store i32 %t240, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eplaceType(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca ptr
  %l7 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 26
  %t4 = load i32, ptr %t3, !tbaa !23
  %t6 = icmp slt i32 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/check:Checker", ptr %t9, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !29
  %t14 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %s1, ptr %s1, ptr %t12, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d30, i32 0, i32 1) }, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d31, i32 0, i32 1) })
  store i32 %t14, ptr %l7
  br label %bb3
bb2:
  br label %bb4
bb3:
  %t15 = load i32, ptr %l7, !tbaa !23
  %t16 = load ptr, ptr %l4, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 26
  store i32 %t15, ptr %t17, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 26
  %t21 = load i32, ptr %t20, !tbaa !23
  store i32 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflPiece(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca i1
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i32
  %s2 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l2
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", i32 }, ptr %t18, i32 0, i32 1
  %t20 = load i32, ptr %t19, !range !{i32 0, i32 98}
  store i32 %t20, ptr %l3
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t22 = load i32, ptr %l3, !range !{i32 0, i32 98}
  %t24 = trunc i64 5 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t28 = load %"compiler/source:Span", ptr %l2
  %t31 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %s2, ptr %t27, %"compiler/source:Span" %t28)
  store { i64, ptr } %t31, ptr %l18
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t32 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t32, ptr %l19, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load i64, ptr %l20, !tbaa !24
  %t36 = mul i64 %t35, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t36)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  store { i64, ptr } %t39, ptr %l21, !tbaa !27
  %t40 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = mul i64 %t44, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t41, ptr %t43, i64 %t45, i1 false)
  %t46 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  %t48 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t46, 1
  store { i32, { i64, ptr } } %t48, ptr %rv
  br label %ret
bb9:
  br label %bb27
bb10:
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t50 = load ptr, ptr %l23, !tbaa !29
  %t51 = icmp ne ptr %t50, null
  br i1 %t51, label %bb11, label %bb12
bb11:
  %t53 = load ptr, ptr %l23, !tbaa !29
  %t54 = load i64, ptr %t53, !range !{i64 0, i64 30}
  %t56 = icmp eq i64 %t54, 3
  store i1 %t56, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t57 = load i1, ptr %l24, !tbaa !21
  br i1 %t57, label %bb13, label %bb14
bb13:
  %t58 = load ptr, ptr %l1, !tbaa !29
  %t60 = getelementptr { i64, [4 x i64] }, ptr %t58, i32 0, i32 1
  %t61 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t60, i32 0, i32 1
  %t62 = load i32, ptr %t61, !range !{i32 0, i32 98}
  store i32 %t62, ptr %l4
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [4 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l5, !tbaa !29
  br label %bb15
bb14:
  br label %bb22
bb15:
  %t70 = load i32, ptr %l4, !range !{i32 0, i32 98}
  %t72 = trunc i64 89 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb16, label %bb17
bb16:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load ptr, ptr %l5, !tbaa !29
  %t79 = call { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflRendered(ptr %v0, ptr %v1, ptr %v2, ptr %t75, ptr %t76)
  %t80 = extractvalue { i32, { i64, ptr } } %t79, 1
  %t81 = extractvalue { i32, { i64, ptr } } %t79, 0
  store i32 %t81, ptr %l37
  %t82 = icmp ne i32 %t81, 0
  br i1 %t82, label %bb19, label %ok.83, !prof !99
ok.83:
  store { i64, ptr } %t80, ptr %l36
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t84 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t84, ptr %l33, !tbaa !27
  br label %bb20
bb19:
  %t85 = load i32, ptr %l37, !tbaa !23
  %t86 = lshr i32 %t85, 16
  %t87 = and i32 %t85, 65535
  %t88 = icmp eq i32 %t86, 1
  %t89 = select i1 %t88, i32 1, i32 0
  %t90 = icmp eq i32 %t85, 0
  %t91 = shl i32 %t89, 16
  %t92 = or i32 %t91, %t87
  %t93 = select i1 %t90, i32 0, i32 %t92
  %t95 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t93, 0
  store { i32, { i64, ptr } } %t95, ptr %rv
  br label %ret
bb20:
  %t96 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t97 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t96, 1
  store { i32, { i64, ptr } } %t97, ptr %rv
  br label %ret
bb21:
  br label %bb27
bb22:
  br i1 true, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_2063aa53a395a078_c72ae34d29618694)
  unreachable
bb27:
  %t99 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t99, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca i1
  %l30 = alloca i1
  %l32 = alloca { i64, ptr }
  %l35 = alloca i1
  %l41 = alloca { i64, ptr }
  %l44 = alloca i64
  %l48 = alloca i1
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l58 = alloca i32
  %l59 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t1, i64 %t2)
  store i1 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i1, ptr %l6, !tbaa !21
  %t7 = xor i1 %t6, true
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/generic:Program", ptr %t13, i32 0, i32 2
  store ptr %t15, ptr %l11, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t21 = getelementptr %"compiler/generic:Program", ptr %t19, i32 0, i32 2
  store ptr %t21, ptr %l14, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 14
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l18
  br label %bb5
bb5:
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t31 = getelementptr %"compiler/typed:Body", ptr %t29, i32 0, i32 2
  %t32 = load i32, ptr %t31, !tbaa !23
  %t33 = load ptr, ptr %l14, !tbaa !29
  %t35 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t33, i32 %t32)
  store i32 %t35, ptr %l21
  br label %bb6
bb6:
  %t36 = load ptr, ptr %l11, !tbaa !29
  %t37 = load i32, ptr %l21, !tbaa !23
  %t38 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t36, i32 %t37)
  store { i64, ptr } %t38, ptr %l22
  br label %bb7
bb7:
  %t39 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t39, ptr %l3, !tbaa !27
  %t40 = load i64, ptr %l2, !tbaa !24
  %t42 = icmp slt i64 %t40, 0
  br i1 %t42, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l25, !tbaa !21
  br label %bb10
bb9:
  %t44 = load i64, ptr %l2, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t50 = icmp sge i64 %t44, %t47
  store i1 %t50, ptr %l25, !tbaa !21
  br label %bb10
bb10:
  %t52 = load i1, ptr %l25, !tbaa !21
  br i1 %t52, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb14
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t54, ptr %l32, !tbaa !27
  %t55 = load i64, ptr %l2, !tbaa !24
  %t57 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr i32, ptr %t58, i64 %t55
  %t60 = load i32, ptr %t59, !tbaa !33
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t53, i32 %t60)
  store i1 %t63, ptr %l35
  br label %bb13
bb13:
  %t64 = load i1, ptr %l35, !tbaa !21
  %t65 = xor i1 %t64, true
  store i1 %t65, ptr %l30, !tbaa !21
  br label %bb14
bb14:
  %t67 = load i1, ptr %l30, !tbaa !21
  br i1 %t67, label %bb15, label %bb16
bb15:
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = load i64, ptr %l2, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr i32, ptr %t79, i64 %t76
  %t81 = load i32, ptr %t80, !tbaa !33
  %t84 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t74, i32 %t81)
  store i64 %t84, ptr %l44
  br label %bb18
bb18:
  %t85 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t86 = load i64, ptr %l44, !tbaa !24
  %t88 = and i64 %t86, %t85
  %t90 = icmp eq i64 %t88, 0
  br i1 %t90, label %bb19, label %bb20
bb19:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  store ptr %t97, ptr %l51, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t103 = getelementptr %"compiler/generic:Program", ptr %t101, i32 0, i32 2
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t104, ptr %l55, !tbaa !27
  %t105 = load i64, ptr %l2, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i32, ptr %t108, i64 %t105
  %t110 = load i32, ptr %t109, !tbaa !33
  %t113 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t103, i32 %t110)
  store i32 %t113, ptr %l58
  br label %bb21
bb20:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb23
bb21:
  %t114 = load ptr, ptr %l51, !tbaa !29
  %t115 = load i32, ptr %l58, !tbaa !23
  %t116 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t116, ptr %l59
  br label %bb22
bb22:
  %t117 = load i32, ptr %l59, !range !{i32 0, i32 33}
  %t119 = trunc i64 21 to i32
  %t120 = icmp eq i32 %t117, %t119
  %t122 = xor i1 %t120, true
  store i1 %t122, ptr %l48, !tbaa !21
  br label %bb23
bb23:
  %t124 = load i1, ptr %l48, !tbaa !21
  store i1 %t124, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCallCopy(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i64
  %l23 = alloca i64
  %l26 = alloca i64
  %l45 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t4 = getelementptr %"compiler/typed:Call", ptr %t2, i32 0, i32 0
  %t5 = load ptr, ptr %t4, !tbaa !29
  %t8 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %t5)
  store i64 %t8, ptr %l13
  br label %bb1
bb1:
  %t9 = load i64, ptr %l13, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t12 = icmp slt i64 %t10, 0
  br i1 %t12, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  store i64 0, ptr %l3, !tbaa !24
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/typed:Call", ptr %t15, i32 0, i32 1
  %t18 = load { i64, ptr }, ptr %t17, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t18, 0
  store i64 %t20, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb7, label %bb8
bb6:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb10
bb7:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l26, !tbaa !24
  br label %bb9
bb8:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb9
bb9:
  %t48 = load i64, ptr %l26, !tbaa !24
  store i64 %t48, ptr %l23, !tbaa !24
  br label %bb10
bb10:
  %t49 = load i64, ptr %l23, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb11
bb11:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb12, label %bb13
bb12:
  br label %bb29
bb13:
  br label %bb14
bb14:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load ptr, ptr %l1, !tbaa !29
  %t70 = getelementptr %"compiler/typed:Call", ptr %t68, i32 0, i32 1
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  store { i64, ptr } %t71, ptr %l45, !tbaa !27
  %t72 = load i64, ptr %l8, !tbaa !24
  %t74 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !27
  %t76 = getelementptr ptr, ptr %t75, i64 %t72
  %t77 = load ptr, ptr %t76, !tbaa !39
  store ptr %t77, ptr %l9, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l48, !tbaa !29
  %t80 = load ptr, ptr %l9, !tbaa !29
  %t83 = call i32 @compiler_2fcheck_2etypeOf(ptr %v1, ptr %t80)
  store i32 %t83, ptr %l51
  br label %bb15
bb15:
  %t84 = load ptr, ptr %l48, !tbaa !29
  %t85 = load i32, ptr %l51, !tbaa !23
  %t86 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t84, i32 %t85)
  store i1 %t86, ptr %l52
  br label %bb16
bb16:
  %t87 = load i1, ptr %l52, !tbaa !21
  br i1 %t87, label %bb17, label %bb18
bb17:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t89 = load i64, ptr %l2, !tbaa !24
  %t90 = load i64, ptr %l8, !tbaa !24
  %t94 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %t88, i64 %t89, i64 %t90)
  store i1 %t94, ptr %l57
  br label %bb19
bb18:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb20
bb19:
  %t95 = load i1, ptr %l57, !tbaa !21
  store i1 %t95, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t96 = load i1, ptr %l53, !tbaa !21
  br i1 %t96, label %bb21, label %bb22
bb21:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load ptr, ptr %l9, !tbaa !29
  %t102 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %t97, ptr %t98)
  store i1 %t102, ptr %l62
  br label %bb23
bb22:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb24
bb23:
  %t103 = load i1, ptr %l62, !tbaa !21
  store i1 %t103, ptr %l58, !tbaa !21
  br label %bb24
bb24:
  %t104 = load i1, ptr %l58, !tbaa !21
  br i1 %t104, label %bb25, label %bb26
bb25:
  store i1 true, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t108 = add i64 %t106, 1
  store i64 %t108, ptr %l7, !tbaa !24
  br label %bb11
bb29:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroCheckCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l20 = alloca i64
  %l22 = alloca i1
  %l25 = alloca i1
  %l29 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l38 = alloca ptr
  %l41 = alloca ptr
  %l45 = alloca ptr
  %l48 = alloca i32
  %l49 = alloca { i64, ptr }
  %l55 = alloca i64
  %l58 = alloca i64
  %l79 = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %t1, ptr %a1)
  store i64 %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load i64, ptr %l13, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb5
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 19
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t17, ptr %l20
  br label %bb4
bb4:
  %t18 = load i64, ptr %l20, !tbaa !24
  %t19 = icmp ne i64 %t18, 0
  store i1 %t19, ptr %l16, !tbaa !21
  br label %bb5
bb5:
  %t21 = load i1, ptr %l16, !tbaa !21
  br i1 %t21, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb9
bb7:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %t22, i64 %t23)
  store i1 %t26, ptr %l25
  br label %bb8
bb8:
  %t27 = load i1, ptr %l25, !tbaa !21
  %t28 = xor i1 %t27, true
  store i1 %t28, ptr %l22, !tbaa !21
  br label %bb9
bb9:
  %t30 = load i1, ptr %l22, !tbaa !21
  br i1 %t30, label %bb10, label %bb11
bb10:
  br label %ret
bb11:
  br label %bb12
bb12:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t32 = load i32, ptr %l2, !tbaa !23
  %t35 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t31, i32 %t32)
  store i1 %t35, ptr %l29
  br label %bb13
bb13:
  %t36 = load i1, ptr %l29, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb14, label %bb15
bb14:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i32, ptr %l2, !tbaa !23
  %t43 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %t39, i32 %t40)
  store i1 %t43, ptr %l34
  br label %bb16
bb15:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb17
bb16:
  %t44 = load i1, ptr %l34, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l31, !tbaa !21
  br label %bb17
bb17:
  %t47 = load i1, ptr %l31, !tbaa !21
  br i1 %t47, label %bb18, label %bb19
bb18:
  br label %ret
bb19:
  br label %bb20
bb20:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  store ptr %t53, ptr %l38, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !29
  %t59 = getelementptr %"compiler/generic:Program", ptr %t57, i32 0, i32 2
  store ptr %t59, ptr %l41, !tbaa !29
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"compiler/check:Checker", ptr %t60, i32 0, i32 14
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t62, i64 %t63)
  store ptr %t66, ptr %l45
  br label %bb21
bb21:
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t69 = getelementptr %"compiler/typed:Body", ptr %t67, i32 0, i32 2
  %t70 = load i32, ptr %t69, !tbaa !23
  %t71 = load ptr, ptr %l41, !tbaa !29
  %t73 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t71, i32 %t70)
  store i32 %t73, ptr %l48
  br label %bb22
bb22:
  %t74 = load ptr, ptr %l38, !tbaa !29
  %t75 = load i32, ptr %l48, !tbaa !23
  %t76 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t74, i32 %t75)
  store { i64, ptr } %t76, ptr %l49
  br label %bb23
bb23:
  %t77 = load { i64, ptr }, ptr %l49, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t80 = extractvalue { i64, ptr } %t77, 0
  store i64 %t80, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t82 = load i64, ptr %l6, !tbaa !24
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = icmp sgt i64 %t82, %t83
  br i1 %t86, label %bb24, label %bb25
bb24:
  %t88 = load i64, ptr %l7, !tbaa !24
  %t90 = icmp sgt i64 %t88, 0
  br i1 %t90, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb29
bb26:
  %t92 = load i64, ptr %l6, !tbaa !24
  %t93 = load i64, ptr %l5, !tbaa !24
  %t96 = sub i64 %t92, %t93
  %t97 = load i64, ptr %l7, !tbaa !24
  %t100 = add i64 %t96, %t97
  %t102 = sub i64 %t100, 1
  %t103 = load i64, ptr %l7, !tbaa !24
  %t106 = sdiv i64 %t102, %t103
  store i64 %t106, ptr %l58, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l58, !tbaa !24
  br label %bb28
bb28:
  %t108 = load i64, ptr %l58, !tbaa !24
  store i64 %t108, ptr %l55, !tbaa !24
  br label %bb29
bb29:
  %t109 = load i64, ptr %l55, !tbaa !24
  store i64 %t109, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb30
bb30:
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l8, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  %t116 = xor i1 %t114, true
  br i1 %t116, label %bb31, label %bb32
bb31:
  br label %bb40
bb32:
  br label %bb33
bb33:
  %t118 = load i64, ptr %l5, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t120 = load i64, ptr %l7, !tbaa !24
  %t123 = mul i64 %t119, %t120
  %t126 = add i64 %t118, %t123
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i64, ptr %l3, !tbaa !24
  %t134 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroByArg(ptr %v0, ptr %t128, i64 %t129, i64 %t126)
  store i1 %t134, ptr %l79
  br label %bb34
bb34:
  %t135 = load i1, ptr %l79, !tbaa !21
  br i1 %t135, label %bb35, label %bb36
bb35:
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t137 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %t136, i64 %t137)
  br label %bb37
bb36:
  br label %bb38
bb37:
  br label %ret
bb38:
  br label %bb39
bb39:
  %t140 = load i64, ptr %l9, !tbaa !24
  %t142 = add i64 %t140, 1
  store i64 %t142, ptr %l9, !tbaa !24
  br label %bb30
bb40:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroNeed(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l8 = alloca i64
  %l12 = alloca ptr
  %l14 = alloca ptr
  %l18 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %s2 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t10 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %t5, ptr %t6)
  store i64 %t10, ptr %l8
  br label %bb4
bb4:
  %t11 = load i64, ptr %l8, !tbaa !24
  store i64 %t11, ptr %l2, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t14 = icmp sge i64 %t12, 0
  br i1 %t14, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t16, i32 0, i32 77
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t19)
  store ptr %t21, ptr %l14
  br label %bb7
bb6:
  br label %bb10
bb7:
  %t22 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/check:frame", ptr %t22, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr %l2, !tbaa !24
  %t29 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t25, i64 %t26)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t29, ptr %l18
  br label %bb8
bb8:
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t31 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l18
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t30, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t31, i1 true)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameJump(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l15 = alloca ptr
  %l18 = alloca i32
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l36 = alloca i64
  %l39 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i1
  %l68 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca { i64, ptr }
  %l76 = alloca i64
  %l81 = alloca ptr
  %l84 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i1
  %l94 = alloca i1
  %l96 = alloca i1
  %l100 = alloca i1
  %l107 = alloca { i64, ptr }
  %l108 = alloca i64
  %l113 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  store ptr %t6, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l15, !tbaa !29
  %t9 = load ptr, ptr %l3, !tbaa !29
  %t10 = load i32, ptr %l1, !tbaa !23
  %t13 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t9, i32 %t10)
  store i32 %t13, ptr %l18
  br label %bb1
bb1:
  %t14 = load ptr, ptr %l15, !tbaa !29
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t14, i32 %t15)
  store { i64, ptr } %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  %t18 = load ptr, ptr %l3, !tbaa !29
  store ptr %t18, ptr %l20, !tbaa !29
  %t19 = load ptr, ptr %l3, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t19, i32 %t20)
  store i32 %t23, ptr %l23
  br label %bb3
bb3:
  %t24 = load ptr, ptr %l20, !tbaa !29
  %t25 = load i32, ptr %l23, !tbaa !23
  %t26 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t24, i32 %t25)
  store { i64, ptr } %t26, ptr %l24
  br label %bb4
bb4:
  %t27 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t27, ptr %l5, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t36 = icmp ne i64 %t30, %t33
  br i1 %t36, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  store i64 0, ptr %l6, !tbaa !24
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t39, 0
  store i64 %t41, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t44 = load i64, ptr %l6, !tbaa !24
  %t47 = icmp sgt i64 %t43, %t44
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb13
bb10:
  %t53 = load i64, ptr %l7, !tbaa !24
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l8, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l8, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l39, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l39, !tbaa !24
  br label %bb12
bb12:
  %t69 = load i64, ptr %l39, !tbaa !24
  store i64 %t69, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l36, !tbaa !24
  store i64 %t70, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb14
bb14:
  %t71 = load i64, ptr %l10, !tbaa !24
  %t72 = load i64, ptr %l9, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb15, label %bb16
bb15:
  br label %bb28
bb16:
  br label %bb17
bb17:
  %t79 = load i64, ptr %l6, !tbaa !24
  %t80 = load i64, ptr %l10, !tbaa !24
  %t81 = load i64, ptr %l8, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l11, !tbaa !24
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t90, ptr %l58, !tbaa !27
  %t91 = load i64, ptr %l11, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t97, ptr %l61, !tbaa !27
  %t98 = load i64, ptr %l11, !tbaa !24
  %t100 = getelementptr { i64, ptr }, ptr %l61, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = getelementptr i32, ptr %t101, i64 %t98
  %t103 = load i32, ptr %t102, !tbaa !33
  %t107 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t89, i32 %t96, i32 %t103)
  store i1 %t107, ptr %l64
  br label %bb18
bb18:
  %t108 = load i1, ptr %l64, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb23
bb20:
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t112 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t112, ptr %l68, !tbaa !27
  %t113 = load i64, ptr %l11, !tbaa !24
  %t115 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t116 = load ptr, ptr %t115, !tbaa !27
  %t117 = getelementptr i32, ptr %t116, i64 %t113
  %t118 = load i32, ptr %t117, !tbaa !33
  %t121 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t111, i32 %t118)
  store i64 %t121, ptr %l71
  br label %bb21
bb21:
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t123, ptr %l73, !tbaa !27
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i32, ptr %t127, i64 %t124
  %t129 = load i32, ptr %t128, !tbaa !33
  %t132 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t122, i32 %t129)
  store i64 %t132, ptr %l76
  br label %bb22
bb22:
  %t133 = load i64, ptr %l71, !tbaa !24
  %t134 = load i64, ptr %l76, !tbaa !24
  %t135 = icmp ne i64 %t133, %t134
  store i1 %t135, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t137 = load i1, ptr %l66, !tbaa !21
  br i1 %t137, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  br label %bb27
bb27:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l10, !tbaa !24
  br label %bb14
bb28:
  %t143 = load ptr, ptr %l3, !tbaa !29
  store ptr %t143, ptr %l81, !tbaa !29
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t145 = load i32, ptr %l1, !tbaa !23
  %t148 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t144, i32 %t145)
  store i32 %t148, ptr %l84
  br label %bb29
bb29:
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t150 = load i32, ptr %l2, !tbaa !23
  %t153 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t149, i32 %t150)
  store i32 %t153, ptr %l87
  br label %bb30
bb30:
  %t154 = load ptr, ptr %l81, !tbaa !29
  %t155 = load i32, ptr %l84, !tbaa !23
  %t156 = load i32, ptr %l87, !tbaa !23
  %t157 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t154, i32 %t155, i32 %t156)
  store i1 %t157, ptr %l88
  br label %bb31
bb31:
  %t158 = load i1, ptr %l88, !tbaa !21
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t163 = load i32, ptr %l1, !tbaa !23
  %t164 = load i32, ptr %l2, !tbaa !23
  %t168 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t162, i32 %t163, i32 %t164)
  store i1 %t168, ptr %l94
  br label %bb35
bb35:
  %t169 = load i1, ptr %l94, !tbaa !21
  %t170 = xor i1 %t169, true
  br i1 %t170, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l96, !tbaa !21
  br label %bb39
bb37:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t173 = load i32, ptr %l2, !tbaa !23
  %t174 = load i32, ptr %l1, !tbaa !23
  %t178 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %t172, i32 %t173, i32 %t174)
  store i1 %t178, ptr %l100
  br label %bb38
bb38:
  %t179 = load i1, ptr %l100, !tbaa !21
  %t180 = xor i1 %t179, true
  store i1 %t180, ptr %l96, !tbaa !21
  br label %bb39
bb39:
  %t182 = load i1, ptr %l96, !tbaa !21
  br i1 %t182, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb41:
  br label %bb42
bb42:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = getelementptr %"compiler/generic:Program", ptr %t187, i32 0, i32 2
  %t190 = load i32, ptr %l1, !tbaa !23
  %t193 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t189, i32 %t190)
  store { i64, ptr } %t193, ptr %l107
  br label %bb43
bb43:
  %t194 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l108, !tbaa !24
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t196, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t201 = getelementptr %"compiler/generic:Program", ptr %t199, i32 0, i32 2
  %t202 = load i32, ptr %l2, !tbaa !23
  %t205 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %s0, ptr %t201, i32 %t202)
  store { i64, ptr } %t205, ptr %l113
  br label %bb44
bb44:
  %t206 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t208 = load i64, ptr %l108, !tbaa !24
  %t210 = icmp eq i64 %t208, %t207
  call void @__olang_scope_close(ptr %s0)
  store i1 %t210, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esameLen(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l6 = alloca i1
  %l8 = alloca i1
  %l10 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca ptr
  %l20 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l35 = alloca %"compiler/source:Span"
  %l36 = alloca { i64, ptr }
  %l37 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = call i1 @compiler_2fcheck_2eplainLen(ptr %v1, ptr %t1)
  store i1 %t3, ptr %l6
  br label %bb1
bb1:
  %t4 = load i1, ptr %l6, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = call i1 @compiler_2fcheck_2eplainLen(ptr %v2, ptr %t7)
  store i1 %t9, ptr %l10
  br label %bb4
bb4:
  %t10 = load i1, ptr %l10, !tbaa !21
  %t11 = xor i1 %t10, true
  store i1 %t11, ptr %l8, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l8, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t16 = load ptr, ptr %l13, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb9, label %bb10
bb9:
  %t19 = load ptr, ptr %l13, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 30}
  %t22 = icmp eq i64 %t20, 0
  store i1 %t22, ptr %l14, !tbaa !21
  br label %bb10
bb10:
  %t23 = load i1, ptr %l14, !tbaa !21
  br i1 %t23, label %bb11, label %bb12
bb11:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [4 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32 }, ptr %t26, i32 0, i32 1
  %t28 = load i32, ptr %t27
  store i32 %t28, ptr %l3, !tbaa !23
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t30 = load ptr, ptr %l2, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb14, label %bb15
bb14:
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 30}
  %t37 = icmp eq i64 %t35, 0
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l20, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  %t39 = load ptr, ptr %l2, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32 }, ptr %t41, i32 0, i32 1
  %t43 = load i32, ptr %t42
  store i32 %t43, ptr %l4, !tbaa !23
  br label %bb18
bb17:
  br label %bb19
bb18:
  %t45 = load i32, ptr %l3, !tbaa !23
  %t46 = load i32, ptr %l4, !tbaa !23
  %t49 = icmp eq i32 %t45, %t46
  store i1 %t49, ptr %rv
  br label %ret
bb19:
  br i1 true, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb23
bb22:
  store i1 false, ptr %rv
  br label %ret
bb23:
  call void @__olang_check_failed(ptr @olang_loc_e2de52da0998b8a_4e4f16d2638e7f66)
  unreachable
bb24:
  br i1 true, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_4bef50c9347fcfcb_39dc7124156e73c7)
  unreachable
bb29:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l29, !tbaa !29
  %t53 = load ptr, ptr %l1, !tbaa !29
  %t55 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t53)
  store %"compiler/source:Span" %t55, ptr %l31
  br label %bb30
bb30:
  %t56 = load ptr, ptr %l29, !tbaa !29
  %t57 = load %"compiler/source:Span", ptr %l31
  %t58 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t56, %"compiler/source:Span" %t57)
  store { i64, ptr } %t58, ptr %l32
  br label %bb31
bb31:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l33, !tbaa !29
  %t60 = load ptr, ptr %l2, !tbaa !29
  %t62 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t60)
  store %"compiler/source:Span" %t62, ptr %l35
  br label %bb32
bb32:
  %t63 = load ptr, ptr %l33, !tbaa !29
  %t64 = load %"compiler/source:Span", ptr %l35
  %t65 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t63, %"compiler/source:Span" %t64)
  store { i64, ptr } %t65, ptr %l36
  br label %bb33
bb33:
  %t66 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t68 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t66, { i64, ptr } %t67)
  store i1 %t68, ptr %l37
  br label %bb34
bb34:
  %t69 = load i1, ptr %l37, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escalarType(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l6 = alloca i1
  %l11 = alloca i1
  %l17 = alloca i32
  %l21 = alloca i1
  %l26 = alloca i1
  %l31 = alloca ptr
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i1
  %l41 = alloca ptr
  %l46 = alloca i32
  %l47 = alloca i1
  %l52 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb2:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l1, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l11
  br label %bb3
bb3:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l6, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load i32, ptr %l1, !tbaa !23
  %t29 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t26)
  store i32 %t29, ptr %l17
  br label %bb8
bb8:
  %t30 = load i32, ptr %l17, !range !{i32 0, i32 33}
  %t32 = trunc i64 18 to i32
  %t33 = icmp eq i32 %t30, %t32
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb12
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/check:Checker", ptr %t37, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t42 = getelementptr %"compiler/generic:Program", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %l1, !tbaa !23
  %t46 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %t42, i32 %t43)
  store i1 %t46, ptr %l26
  br label %bb11
bb11:
  %t47 = load i1, ptr %l26, !tbaa !21
  %t48 = xor i1 %t47, true
  store i1 %t48, ptr %l21, !tbaa !21
  br label %bb12
bb12:
  %t50 = load i1, ptr %l21, !tbaa !21
  br i1 %t50, label %bb13, label %bb14
bb13:
  store i1 false, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  store ptr %t57, ptr %l31, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t58, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l1, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l36
  br label %bb16
bb16:
  %t68 = load ptr, ptr %l31, !tbaa !29
  %t69 = load i32, ptr %l36, !tbaa !23
  %t70 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t68, i32 %t69)
  store i32 %t70, ptr %l37
  br label %bb17
bb17:
  %t71 = load i32, ptr %l37, !range !{i32 0, i32 6}
  store i32 %t71, ptr %l2
  %t72 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t74 = trunc i64 4 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb23
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l41, !tbaa !29
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l1, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l46
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l41, !tbaa !29
  %t89 = load i32, ptr %l46, !tbaa !23
  %t90 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2escalarType(ptr %v0, ptr %t88, i32 %t89)
  store i1 %t90, ptr %l47
  br label %bb22
bb22:
  %t91 = load i1, ptr %l47, !tbaa !21
  store i1 %t91, ptr %l38, !tbaa !21
  br label %bb34
bb23:
  %t92 = load i32, ptr %l2, !range !{i32 0, i32 6}
  %t94 = trunc i64 1 to i32
  %t95 = icmp eq i32 %t92, %t94
  br i1 %t95, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb29
bb26:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/check:Checker", ptr %t97, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = getelementptr %"compiler/generic:Program", ptr %t100, i32 0, i32 2
  store ptr %t102, ptr %l52, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l1, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l57
  br label %bb27
bb27:
  %t113 = load ptr, ptr %l52, !tbaa !29
  %t114 = load i32, ptr %l57, !tbaa !23
  %t115 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %t113, i32 %t114)
  store i1 %t115, ptr %l58
  br label %bb28
bb28:
  %t116 = load i1, ptr %l58, !tbaa !21
  %t117 = xor i1 %t116, true
  store i1 %t117, ptr %l38, !tbaa !21
  br label %bb34
bb29:
  br i1 true, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  br label %bb33
bb32:
  store i1 false, ptr %l38, !tbaa !21
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_5d236ea53e0f5fd3_8f603dd19b7c69a7)
  unreachable
bb34:
  %t119 = load i1, ptr %l38, !tbaa !21
  store i1 %t119, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqColumn(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l17 = alloca ptr
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a1, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load i64, ptr %l3, !tbaa !24
  store i64 %t3, ptr %l6, !tbaa !24
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t6 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v1, ptr %t4)
  store i64 %t6, ptr %l8
  br label %bb2
bb2:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l8, !tbaa !24
  %t9 = icmp slt i64 %t7, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t13 = load ptr, ptr %l2, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v1, ptr %v1, ptr %t13, i64 %t14)
  store { i64, ptr } %t17, ptr %l13
  br label %bb6
bb6:
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t18, ptr %l15, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr ptr, ptr %t22, i64 0
  %t24 = load ptr, ptr %t23, !tbaa !39
  %t27 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %s2, ptr %a0, ptr %t24)
  store ptr %t27, ptr %l17
  br label %bb7
bb7:
  %t28 = load ptr, ptr %l17, !tbaa !29
  %t30 = getelementptr %"compiler/check:elemsShape", ptr %t28, i32 0, i32 1
  %t31 = load i64, ptr %t30, !tbaa !24
  %t33 = icmp sge i64 %t31, -1
  br i1 %t33, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb12:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esettleHeldWalks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/check:heldCand"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, [2 x i64] }
  %l7 = alloca i64
  %l8 = alloca i64
  %l11 = alloca i64
  %l13 = alloca i64
  %l18 = alloca %"compiler/check:heldCand"
  %l21 = alloca i1
  %l22 = alloca i64
  %l25 = alloca i64
  %l27 = alloca i1
  %l31 = alloca ptr
  %l38 = alloca ptr
  %l46 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i64
  %l53 = alloca i64
  %l58 = alloca ptr
  %l67 = alloca i64
  %l71 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 103
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l11, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2eLen_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l13
  br label %bb2
bb2:
  %t9 = load i64, ptr %l11, !tbaa !24
  %t10 = load i64, ptr %l13, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb48
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/check:heldCand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2eAt_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/check:heldCand" %t19, ptr %l18
  br label %bb6
bb6:
  %t20 = load %"compiler/check:heldCand", ptr %l18
  store %"compiler/check:heldCand" %t20, ptr %l3
  %t21 = getelementptr %"compiler/check:heldCand", ptr %l3, i32 0, i32 0
  %t22 = load i64, ptr %t21, !tbaa !24
  %t24 = icmp slt i64 %t22, 0
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb10
bb8:
  %t26 = getelementptr %"compiler/check:heldCand", ptr %l3, i32 0, i32 0
  %t27 = load i64, ptr %t26, !tbaa !24
  store i64 %t27, ptr %l22, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/check:Checker", ptr %t28, i32 0, i32 14
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l25
  br label %bb9
bb9:
  %t33 = load i64, ptr %l22, !tbaa !24
  %t34 = load i64, ptr %l25, !tbaa !24
  %t35 = icmp sge i64 %t33, %t34
  store i1 %t35, ptr %l21, !tbaa !21
  br label %bb10
bb10:
  %t37 = load i1, ptr %l21, !tbaa !21
  br i1 %t37, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb14
bb12:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/check:Checker", ptr %t38, i32 0, i32 14
  %t41 = getelementptr %"compiler/check:heldCand", ptr %l3, i32 0, i32 0
  %t42 = load i64, ptr %t41, !tbaa !24
  %t45 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t40, i64 %t42)
  store ptr %t45, ptr %l31
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l31, !tbaa !29
  %t48 = getelementptr %"compiler/typed:Body", ptr %t46, i32 0, i32 11
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = icmp eq ptr %t49, null
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  br label %bb47
bb16:
  br label %bb17
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t56 = getelementptr %"compiler/check:Checker", ptr %t54, i32 0, i32 14
  %t57 = getelementptr %"compiler/check:heldCand", ptr %l3, i32 0, i32 0
  %t58 = load i64, ptr %t57, !tbaa !24
  %t61 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t56, i64 %t58)
  store ptr %t61, ptr %l38
  br label %bb18
bb18:
  %t62 = load ptr, ptr %l38, !tbaa !29
  store ptr %t62, ptr %l4, !tbaa !29
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t64 = getelementptr %"compiler/check:heldCand", ptr %l3, i32 0, i32 1
  %t65 = load i64, ptr %t64, !tbaa !24
  %t67 = trunc i64 %t65 to i32
  %t69 = getelementptr %"compiler/check:heldCand", ptr %l3, i32 0, i32 2
  %t70 = load i64, ptr %t69, !tbaa !24
  %t72 = trunc i64 %t70 to i32
  %t77 = call i64 @compiler_2fdefinit_2eHeldWalk(ptr %v0, ptr %t63, i32 %t67, i32 %t72)
  store i64 %t77, ptr %l46
  br label %bb19
bb19:
  %t78 = load i64, ptr %l46, !tbaa !24
  store i64 %t78, ptr %l5, !tbaa !24
  %t79 = load i64, ptr %l5, !tbaa !24
  %t81 = icmp slt i64 %t79, 0
  br i1 %t81, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb23
bb21:
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %l50, !tbaa !24
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 14
  %t88 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t86)
  store i64 %t88, ptr %l53
  br label %bb22
bb22:
  %t89 = load i64, ptr %l50, !tbaa !24
  %t90 = load i64, ptr %l53, !tbaa !24
  %t91 = icmp sge i64 %t89, %t90
  store i1 %t91, ptr %l49, !tbaa !21
  br label %bb23
bb23:
  %t93 = load i1, ptr %l49, !tbaa !21
  br i1 %t93, label %bb24, label %bb25
bb24:
  br label %bb47
bb25:
  br label %bb26
bb26:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 14
  %t97 = load i64, ptr %l5, !tbaa !24
  %t100 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t96, i64 %t97)
  store ptr %t100, ptr %l58
  br label %bb27
bb27:
  %t101 = load ptr, ptr %l58, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Body", ptr %t101, i32 0, i32 1
  %t104 = load { i64, [2 x i64] }, ptr %t103
  store { i64, [2 x i64] } %t104, ptr %l6
  %t106 = load { i64, [2 x i64] }, ptr %l6
  %t108 = extractvalue { i64, [2 x i64] } %t106, 0
  %t109 = icmp eq i64 %t108, 0
  br i1 %t109, label %bb28, label %bb29
bb28:
  %t111 = getelementptr { i64, [2 x i64] }, ptr %l6, i32 0, i32 1
  %t112 = getelementptr { i64 }, ptr %t111, i32 0, i32 0
  %t113 = load i64, ptr %t112
  store i64 %t113, ptr %l7, !tbaa !24
  br label %bb30
bb29:
  br label %bb41
bb30:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = getelementptr %"compiler/check:Checker", ptr %t115, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !29
  %t119 = load i64, ptr %l7, !tbaa !24
  %t122 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t118, i64 %t119)
  store i64 %t122, ptr %l67
  br label %bb31
bb31:
  %t123 = load i64, ptr %l67, !tbaa !24
  store i64 %t123, ptr %l8, !tbaa !24
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = getelementptr %"compiler/check:Checker", ptr %t124, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !29
  %t128 = load i64, ptr %l8, !tbaa !24
  %t131 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %t127, i64 %t128)
  store i1 %t131, ptr %l71
  br label %bb32
bb32:
  %t132 = load i1, ptr %l71, !tbaa !21
  br i1 %t132, label %bb33, label %bb34
bb33:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/check:Checker", ptr %t133, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !29
  %t137 = load i64, ptr %l8, !tbaa !24
  %t140 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenElem(ptr %v0, ptr %t136, i64 %t137)
  store i64 %t140, ptr %l76
  br label %bb35
bb34:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb36
bb35:
  %t141 = load i64, ptr @G_2ecompiler_2fgeneric_2eGenPerTurn, !tbaa !24
  %t142 = load i64, ptr %l76, !tbaa !24
  %t144 = icmp eq i64 %t142, %t141
  store i1 %t144, ptr %l72, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l72, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = getelementptr %"compiler/typed:Body", ptr %t147, i32 0, i32 17
  %t150 = getelementptr %"compiler/check:heldCand", ptr %l3, i32 0, i32 1
  %t151 = load i64, ptr %t150, !tbaa !24
  %t153 = trunc i64 %t151 to i32
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t149, i32 %t153)
  br label %bb39
bb38:
  br label %bb40
bb39:
  br label %bb40
bb40:
  br label %bb46
bb41:
  br i1 true, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_e205085f53b5fcbb_81fd3e9c55e0751f)
  unreachable
bb46:
  br label %bb47
bb47:
  %t157 = load i64, ptr %l2, !tbaa !24
  %t159 = add i64 %t157, 1
  store i64 %t159, ptr %l2, !tbaa !24
  br label %bb1
bb48:
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca i32
  %l31 = alloca %"compiler/check:elemsShape"
  %l38 = alloca i64
  %l41 = alloca i64
  %l59 = alloca { i64, ptr }
  %l62 = alloca i1
  %l68 = alloca %"compiler/check:elemsShape"
  %l73 = alloca %"compiler/check:elemsShape"
  %rv = alloca ptr
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  store i1 false, ptr %l13, !tbaa !21
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 9}
  %t8 = icmp eq i64 %t6, 6
  store i1 %t8, ptr %l13, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l13, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l2, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [4 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t18, i32 0, i32 2
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  br label %bb5
bb4:
  br label %bb39
bb5:
  %t22 = load ptr, ptr %l2, !tbaa !29
  store ptr %t22, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t23 = load ptr, ptr %l20, !tbaa !29
  %t24 = icmp ne ptr %t23, null
  br i1 %t24, label %bb6, label %bb7
bb6:
  %t26 = load ptr, ptr %l20, !tbaa !29
  %t27 = load i64, ptr %t26, !range !{i64 0, i64 30}
  %t29 = icmp eq i64 %t27, 15
  store i1 %t29, ptr %l21, !tbaa !21
  br label %bb7
bb7:
  %t30 = load i1, ptr %l21, !tbaa !21
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t31 = load ptr, ptr %l2, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t33, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  store ptr %t35, ptr %l4, !tbaa !29
  br label %bb10
bb9:
  br label %bb16
bb10:
  %t38 = load ptr, ptr %l4, !tbaa !29
  %t41 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %t38)
  store i32 %t41, ptr %l28
  br label %bb11
bb11:
  %t42 = load i32, ptr %l28, !tbaa !23
  %t43 = icmp slt i32 %t42, 0
  br i1 %t43, label %bb12, label %bb13
bb12:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t47 = call %"compiler/check:elemsShape" @compiler_2fcheck_3aelemsShape_2ector(ptr %v1, ptr %v2, { i64, ptr } %t45, i64 -2)
  store %"compiler/check:elemsShape" %t47, ptr %l31
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t48 = load %"compiler/check:elemsShape", ptr %l31
  %t49 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/check:elemsShape" %t48, ptr %t49
  store ptr %t49, ptr %rv
  br label %ret
bb15:
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c0d1d2eb81d1d8d1_71bd70056b23e28d)
  unreachable
bb21:
  store i64 -1, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t55 = load i64, ptr %l7, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp sgt i64 %t55, %t56
  br i1 %t59, label %bb22, label %bb23
bb22:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp sgt i64 %t61, 0
  br i1 %t63, label %bb24, label %bb25
bb23:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb27
bb24:
  %t65 = load i64, ptr %l7, !tbaa !24
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = sub i64 %t65, %t66
  %t70 = load i64, ptr %l8, !tbaa !24
  %t73 = add i64 %t69, %t70
  %t75 = sub i64 %t73, 1
  %t76 = load i64, ptr %l8, !tbaa !24
  %t79 = sdiv i64 %t75, %t76
  store i64 %t79, ptr %l41, !tbaa !24
  br label %bb26
bb25:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb26
bb26:
  %t81 = load i64, ptr %l41, !tbaa !24
  store i64 %t81, ptr %l38, !tbaa !24
  br label %bb27
bb27:
  %t82 = load i64, ptr %l38, !tbaa !24
  store i64 %t82, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb28
bb28:
  %t83 = load i64, ptr %l10, !tbaa !24
  %t84 = load i64, ptr %l9, !tbaa !24
  %t87 = icmp slt i64 %t83, %t84
  %t89 = xor i1 %t87, true
  br i1 %t89, label %bb29, label %bb30
bb29:
  br label %bb37
bb30:
  br label %bb31
bb31:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load i64, ptr %l10, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t96 = mul i64 %t92, %t93
  %t99 = add i64 %t91, %t96
  store i64 %t99, ptr %l11, !tbaa !24
  %t101 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t101, ptr %l59, !tbaa !27
  %t102 = load i64, ptr %l11, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr ptr, ptr %t105, i64 %t102
  %t107 = load ptr, ptr %t106, !tbaa !39
  %t109 = call i1 @compiler_2fcheck_2eisRest(ptr %v1, ptr %t107)
  store i1 %t109, ptr %l62
  br label %bb32
bb32:
  %t110 = load i1, ptr %l62, !tbaa !21
  br i1 %t110, label %bb33, label %bb34
bb33:
  %t111 = load i64, ptr %l11, !tbaa !24
  store i64 %t111, ptr %l5, !tbaa !24
  br label %bb35
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t113 = load i64, ptr %l10, !tbaa !24
  %t115 = add i64 %t113, 1
  store i64 %t115, ptr %l10, !tbaa !24
  br label %bb28
bb37:
  %t117 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t118 = load i64, ptr %l5, !tbaa !24
  %t121 = call %"compiler/check:elemsShape" @compiler_2fcheck_3aelemsShape_2ector(ptr %v1, ptr %v2, { i64, ptr } %t117, i64 %t118)
  store %"compiler/check:elemsShape" %t121, ptr %l68
  br label %bb38
bb38:
  %t122 = load %"compiler/check:elemsShape", ptr %l68
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/check:elemsShape" %t122, ptr %t123
  store ptr %t123, ptr %rv
  br label %ret
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb48
bb42:
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb43, label %bb44
bb43:
  %t127 = icmp sle i64 0, 1152921504606846975
  br i1 %t127, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_70e9f05b266be8f7_36ef9a2f9f93b02b)
  unreachable
bb45:
  %t129 = mul i64 0, 8
  %t130 = insertvalue { i64, ptr } undef, i64 0, 0
  %t131 = insertvalue { i64, ptr } %t130, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t133 = call %"compiler/check:elemsShape" @compiler_2fcheck_3aelemsShape_2ector(ptr %v2, ptr %v2, { i64, ptr } %t131, i64 -2)
  store %"compiler/check:elemsShape" %t133, ptr %l73
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_70e9f05b266be8f7_36ef9a2f9f93b02b)
  unreachable
bb47:
  %t134 = load %"compiler/check:elemsShape", ptr %l73
  %t135 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store %"compiler/check:elemsShape" %t134, ptr %t135
  store ptr %t135, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_7d3bd01c87e6cabb_168a15d9febd8197)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eshiftInRange(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2, %"compiler/source:Span" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i32
  %l19 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca i1
  %l32 = alloca i32
  %l37 = alloca i1
  %l44 = alloca i64
  %l51 = alloca i64
  %l59 = alloca i1
  %l61 = alloca i1
  %l64 = alloca i64
  %l69 = alloca i64
  %l78 = alloca i64
  %l83 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca %"compiler/source:Span"
  %l102 = alloca { i64, ptr }
  %l106 = alloca %"compiler/diagmsg:Msg"
  %l107 = alloca i64
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %l1, !tbaa !23
  %t5 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t1, i32 %t2)
  store i32 %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = load i32, ptr %l14, !tbaa !23
  store i32 %t6, ptr %l4, !tbaa !23
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t7, i32 0, i32 1
  %t10 = load ptr, ptr %t9, !tbaa !29
  %t12 = getelementptr %"compiler/generic:Program", ptr %t10, i32 0, i32 2
  %t13 = load i32, ptr %l4, !tbaa !23
  %t16 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t12, i32 %t13)
  store i1 %t16, ptr %l19
  br label %bb2
bb2:
  %t17 = load i1, ptr %l19, !tbaa !21
  %t18 = xor i1 %t17, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  store i1 true, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t21 = load ptr, ptr %l2, !tbaa !29
  store ptr %t21, ptr %l22, !tbaa !29
  store i1 false, ptr %l23, !tbaa !21
  %t22 = load ptr, ptr %l22, !tbaa !29
  %t23 = icmp ne ptr %t22, null
  br i1 %t23, label %bb6, label %bb7
bb6:
  %t25 = load ptr, ptr %l22, !tbaa !29
  %t26 = load i64, ptr %t25, !range !{i64 0, i64 18}
  %t28 = icmp eq i64 %t26, 0
  store i1 %t28, ptr %l23, !tbaa !21
  br label %bb7
bb7:
  %t29 = load i1, ptr %l23, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr { i64, [5 x i64] }, ptr %t30, i32 0, i32 1
  %t33 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t32, i32 0, i32 1
  %t34 = load i32, ptr %t33
  store i32 %t34, ptr %l5, !tbaa !23
  %t36 = load ptr, ptr %l2, !tbaa !29
  %t38 = getelementptr { i64, [5 x i64] }, ptr %t36, i32 0, i32 1
  %t39 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t38, i32 0, i32 2
  %t40 = load i64, ptr %t39
  store i64 %t40, ptr %l6, !tbaa !24
  br label %bb10
bb9:
  br label %bb50
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t43 = load i32, ptr %l5, !tbaa !23
  %t46 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %t42, i32 %t43)
  store i32 %t46, ptr %l32
  br label %bb11
bb11:
  %t47 = load i32, ptr %l32, !tbaa !23
  store i32 %t47, ptr %l7, !tbaa !23
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t48, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !29
  %t53 = getelementptr %"compiler/generic:Program", ptr %t51, i32 0, i32 2
  %t54 = load i32, ptr %l7, !tbaa !23
  %t57 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l37
  br label %bb12
bb12:
  %t58 = load i1, ptr %l37, !tbaa !21
  %t59 = xor i1 %t58, true
  br i1 %t59, label %bb13, label %bb14
bb13:
  store i1 true, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/check:Checker", ptr %t62, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = getelementptr %"compiler/generic:Program", ptr %t65, i32 0, i32 2
  %t68 = load i32, ptr %l7, !tbaa !23
  %t71 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t67, i32 %t68)
  store i64 %t71, ptr %l44
  br label %bb16
bb16:
  %t72 = load i64, ptr %l44, !tbaa !24
  store i64 %t72, ptr %l8, !tbaa !24
  %t73 = load i64, ptr %l6, !tbaa !24
  store i64 %t73, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l8, !tbaa !24
  %t77 = icmp sgt i64 %t75, 64
  br i1 %t77, label %bb17, label %bb18
bb17:
  store i64 64, ptr %l8, !tbaa !24
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = icmp slt i64 %t79, 64
  br i1 %t81, label %bb20, label %bb21
bb20:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l8, !tbaa !24
  store i64 %t84, ptr %l51, !tbaa !24
  %t85 = load i64, ptr %l51, !tbaa !24
  %t86 = load i64, ptr %l51, !tbaa !24
  %t87 = shl i64 1, %t86
  %t89 = sub i64 %t87, 1
  %t92 = and i64 %t83, %t89
  store i64 %t92, ptr %l9, !tbaa !24
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = getelementptr %"compiler/check:Checker", ptr %t94, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !29
  %t99 = getelementptr %"compiler/generic:Program", ptr %t97, i32 0, i32 2
  %t100 = load i32, ptr %l7, !tbaa !23
  %t103 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t99, i32 %t100)
  store i1 %t103, ptr %l59
  br label %bb22
bb21:
  br label %bb29
bb22:
  %t104 = load i1, ptr %l59, !tbaa !21
  %t105 = xor i1 %t104, true
  br i1 %t105, label %bb23, label %bb24
bb23:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t110 = sub i64 %t108, 1
  store i64 %t110, ptr %l64, !tbaa !24
  %t112 = load i64, ptr %l64, !tbaa !24
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = ashr i64 %t107, %t113
  %t116 = and i64 %t114, 1
  %t118 = icmp eq i64 %t116, 1
  store i1 %t118, ptr %l61, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb25
bb25:
  %t120 = load i1, ptr %l61, !tbaa !21
  br i1 %t120, label %bb26, label %bb27
bb26:
  %t121 = load i64, ptr %l9, !tbaa !24
  %t122 = load i64, ptr %l8, !tbaa !24
  store i64 %t122, ptr %l69, !tbaa !24
  %t123 = load i64, ptr %l69, !tbaa !24
  %t124 = load i64, ptr %l69, !tbaa !24
  %t125 = shl i64 1, %t124
  %t127 = sub i64 %t125, 1
  %t129 = xor i64 %t127, -1
  %t132 = or i64 %t121, %t129
  store i64 %t132, ptr %l9, !tbaa !24
  br label %bb28
bb27:
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t139 = getelementptr %"compiler/generic:Program", ptr %t137, i32 0, i32 2
  %t140 = load i32, ptr %l4, !tbaa !23
  %t143 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %t139, i32 %t140)
  store i64 %t143, ptr %l78
  br label %bb30
bb30:
  %t144 = load i64, ptr %l78, !tbaa !24
  store i64 %t144, ptr %l10, !tbaa !24
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !29
  %t150 = getelementptr %"compiler/generic:Program", ptr %t148, i32 0, i32 2
  %t151 = load i32, ptr %l7, !tbaa !23
  %t154 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %t150, i32 %t151)
  store i1 %t154, ptr %l83
  br label %bb31
bb31:
  %t155 = load i1, ptr %l83, !tbaa !21
  br i1 %t155, label %bb32, label %bb33
bb32:
  %t156 = load i64, ptr %l8, !tbaa !24
  %t158 = icmp eq i64 %t156, 64
  store i1 %t158, ptr %l84, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb34
bb34:
  %t160 = load i1, ptr %l84, !tbaa !21
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t161 = load i64, ptr %l9, !tbaa !24
  %t163 = icmp slt i64 %t161, 0
  store i1 %t163, ptr %l87, !tbaa !21
  br label %bb37
bb36:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb37
bb37:
  %t165 = load i1, ptr %l87, !tbaa !21
  br i1 %t165, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb40
bb39:
  %t168 = load i64, ptr %l9, !tbaa !24
  %t170 = icmp slt i64 %t168, 0
  store i1 %t170, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t172 = load i1, ptr %l91, !tbaa !21
  br i1 %t172, label %bb41, label %bb42
bb41:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb43
bb42:
  %t173 = load i64, ptr %l9, !tbaa !24
  %t174 = load i64, ptr %l10, !tbaa !24
  %t177 = icmp sge i64 %t173, %t174
  store i1 %t177, ptr %l94, !tbaa !21
  br label %bb43
bb43:
  %t179 = load i1, ptr %l94, !tbaa !21
  br i1 %t179, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t180 = load ptr, ptr %l0, !tbaa !29
  store ptr %t180, ptr %l98, !tbaa !29
  store %"compiler/source:Span" %a3, ptr %l99
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i32, ptr %l1, !tbaa !23
  %t186 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %s7, ptr %t182, i32 %t183)
  store { i64, ptr } %t186, ptr %l102
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t187 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = extractvalue { i64, ptr } %t187, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t194 = load i64, ptr %l9, !tbaa !24
  %t195 = load i64, ptr %l10, !tbaa !24
  %t199 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShiftOutOfRange(ptr %s7, ptr %s7, { i64, ptr } %t193, i64 %t194, i64 %t195)
  store %"compiler/diagmsg:Msg" %t199, ptr %l106
  br label %bb47
bb47:
  %t200 = load ptr, ptr %l98, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l99
  %t202 = load %"compiler/diagmsg:Msg", ptr %l106
  %t203 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s7, ptr %t200, %"compiler/source:Span" %t201, %"compiler/diagmsg:Msg" %t202)
  store i64 %t203, ptr %l107
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s7)
  store i1 false, ptr %rv
  br label %ret
bb49:
  br label %bb55
bb50:
  br i1 true, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_a580fa67a95f3737_235a3d78a5401c13)
  unreachable
bb55:
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnStmt(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca i1
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca ptr
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l26 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l45 = alloca ptr
  %l49 = alloca ptr
  %l53 = alloca i1
  %l56 = alloca i64
  %l60 = alloca ptr
  %l61 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i64
  %l64 = alloca ptr
  %l69 = alloca i64
  %l71 = alloca ptr
  %l72 = alloca %"compiler/source:Span"
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l74 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca i64
  %l85 = alloca ptr
  %l88 = alloca i64
  %l90 = alloca i64
  %l92 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l107 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i1
  %l126 = alloca i64
  %l128 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca %"compiler/source:Span"
  %l146 = alloca %"compiler/diagmsg:Msg"
  %l147 = alloca i64
  %l152 = alloca ptr
  %l155 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca %"compiler/source:Span"
  %l160 = alloca %"compiler/source:Span"
  %l163 = alloca i32
  %l166 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l173 = alloca ptr
  %l175 = alloca ptr
  %l176 = alloca i1
  %l183 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i1
  %l195 = alloca i1
  %l197 = alloca i1
  %l202 = alloca ptr
  %l204 = alloca ptr
  %l206 = alloca %"compiler/source:Span"
  %l207 = alloca %"compiler/diagmsg:Msg"
  %l208 = alloca i64
  %l213 = alloca ptr
  %l215 = alloca ptr
  %l216 = alloca ptr
  %l220 = alloca i1
  %l224 = alloca ptr
  %l225 = alloca { i64, ptr }
  %l226 = alloca i64
  %l229 = alloca i64
  %l235 = alloca ptr
  %l239 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca { i64, ptr }
  %l242 = alloca ptr
  %l243 = alloca ptr
  %l246 = alloca i32
  %l247 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l263 = alloca i1
  %l266 = alloca ptr
  %l268 = alloca %"compiler/source:Span"
  %l269 = alloca %"compiler/diagmsg:Msg"
  %l270 = alloca i64
  %l271 = alloca ptr
  %l277 = alloca i1
  %l279 = alloca ptr
  %l281 = alloca %"compiler/source:Span"
  %l282 = alloca %"compiler/diagmsg:Msg"
  %l283 = alloca i64
  %l284 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l286 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l292 = alloca i32
  %l294 = alloca i64
  %l296 = alloca i1
  %l298 = alloca ptr
  %l302 = alloca ptr
  %l306 = alloca i32
  %l309 = alloca i1
  %l310 = alloca i1
  %l313 = alloca i1
  %l314 = alloca i1
  %l319 = alloca i1
  %l320 = alloca i1
  %l325 = alloca i32
  %l330 = alloca i32
  %l336 = alloca i32
  %l344 = alloca { i64, ptr }
  %l347 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l350 = alloca i1
  %l355 = alloca i1
  %l366 = alloca { i64, ptr }
  %l377 = alloca i1
  %l379 = alloca ptr
  %l381 = alloca %"compiler/source:Span"
  %l383 = alloca { i64, ptr }
  %l388 = alloca ptr
  %l390 = alloca i32
  %l392 = alloca { i64, ptr }
  %l394 = alloca { i64, ptr }
  %l398 = alloca { i64, ptr }
  %l400 = alloca %"compiler/diagmsg:Msg"
  %l401 = alloca i64
  %l406 = alloca i1
  %l408 = alloca ptr
  %l410 = alloca %"compiler/source:Span"
  %l412 = alloca { i64, ptr }
  %l413 = alloca i1
  %l414 = alloca ptr
  %l415 = alloca ptr
  %l416 = alloca i32
  %l418 = alloca i64
  %l419 = alloca ptr
  %l420 = alloca %"compiler/typed:TaskClause"
  %l422 = alloca ptr
  %l424 = alloca %"compiler/source:Span"
  %l426 = alloca { i64, ptr }
  %l427 = alloca i1
  %l431 = alloca %"compiler/typed:Clause"
  %l437 = alloca i64
  %l446 = alloca { i64, ptr }
  %l460 = alloca i64
  %l462 = alloca i1
  %l465 = alloca i64
  %l468 = alloca ptr
  %l472 = alloca i64
  %l474 = alloca ptr
  %l475 = alloca %"compiler/source:Span"
  %l476 = alloca ptr
  %l477 = alloca { i64, ptr }
  %l478 = alloca ptr
  %l481 = alloca i32
  %l482 = alloca ptr
  %l483 = alloca %"compiler/source:Span"
  %l485 = alloca { i64, ptr }
  %l486 = alloca ptr
  %l488 = alloca { i64, ptr }
  %l492 = alloca i32
  %l493 = alloca %"compiler/typed:Spawn"
  %l497 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %t261 = alloca { i64, [3 x i64] }, align 8
  %t958 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l45, !tbaa !29
  %t2 = load ptr, ptr %l45, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t2, i32 0, i32 41
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l45, !tbaa !29
  %t9 = getelementptr %"compiler/check:Checker", ptr %t8, i32 0, i32 41
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t10)
  store ptr %t12, ptr %l49
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l49, !tbaa !29
  store ptr %t13, ptr %l4, !tbaa !29
  %t14 = load ptr, ptr %l4, !tbaa !29
  %t16 = getelementptr %"compiler/check:frame", ptr %t14, i32 0, i32 34
  %t17 = load i64, ptr %t16, !tbaa !24
  %t19 = icmp sge i64 %t17, 0
  br i1 %t19, label %bb2, label %bb3
bb2:
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = getelementptr %"compiler/check:frame", ptr %t21, i32 0, i32 38
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l56
  br label %bb4
bb3:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb5
bb4:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = getelementptr %"compiler/check:frame", ptr %t26, i32 0, i32 37
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr %l56, !tbaa !24
  %t32 = icmp sle i64 %t30, %t29
  store i1 %t32, ptr %l53, !tbaa !21
  br label %bb5
bb5:
  %t34 = load i1, ptr %l53, !tbaa !21
  br i1 %t34, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l60, !tbaa !29
  %t36 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t36, ptr %l61
  %t37 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %s1)
  store %"compiler/diagmsg:Msg" %t37, ptr %l62
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t38 = load ptr, ptr %l60, !tbaa !29
  %t39 = load %"compiler/source:Span", ptr %l61
  %t40 = load %"compiler/diagmsg:Msg", ptr %l62
  %t41 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t38, %"compiler/source:Span" %t39, %"compiler/diagmsg:Msg" %t40)
  store i64 %t41, ptr %l63
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l64, !tbaa !29
  %t43 = load ptr, ptr %l64, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t43, i32 0, i32 41
  %t45 = load i64, ptr %t44, !tbaa !24
  %t47 = sub i64 %t45, 1
  %t49 = load ptr, ptr %l64, !tbaa !29
  %t50 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 41
  store i64 %t47, ptr %t50, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb10:
  %t51 = load ptr, ptr %l4, !tbaa !29
  %t53 = getelementptr %"compiler/check:frame", ptr %t51, i32 0, i32 38
  %t55 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t53)
  store i64 %t55, ptr %l69
  br label %bb11
bb11:
  %t56 = load i64, ptr %l69, !tbaa !24
  %t57 = icmp eq i64 %t56, 0
  br i1 %t57, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l71, !tbaa !29
  %t60 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t60, ptr %l72
  %t61 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %s3)
  store %"compiler/diagmsg:Msg" %t61, ptr %l73
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t62 = load ptr, ptr %l71, !tbaa !29
  %t63 = load %"compiler/source:Span", ptr %l72
  %t64 = load %"compiler/diagmsg:Msg", ptr %l73
  %t65 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t62, %"compiler/source:Span" %t63, %"compiler/diagmsg:Msg" %t64)
  store i64 %t65, ptr %l74
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l75, !tbaa !29
  %t67 = load ptr, ptr %l75, !tbaa !29
  %t68 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 41
  %t69 = load i64, ptr %t68, !tbaa !24
  %t71 = sub i64 %t69, 1
  %t73 = load ptr, ptr %l75, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 41
  store i64 %t71, ptr %t74, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb16:
  %t75 = load ptr, ptr %l4, !tbaa !29
  %t77 = getelementptr %"compiler/check:frame", ptr %t75, i32 0, i32 38
  store ptr %t77, ptr %l79, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/check:frame", ptr %t78, i32 0, i32 38
  %t82 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t80)
  store i64 %t82, ptr %l82
  br label %bb17
bb17:
  %t83 = load i64, ptr %l82, !tbaa !24
  %t84 = sub i64 %t83, 1
  store i64 %t84, ptr %l83, !tbaa !24
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/check:frame", ptr %t85, i32 0, i32 38
  store ptr %t87, ptr %l85, !tbaa !29
  %t88 = load ptr, ptr %l4, !tbaa !29
  %t90 = getelementptr %"compiler/check:frame", ptr %t88, i32 0, i32 38
  %t92 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t90)
  store i64 %t92, ptr %l88
  br label %bb18
bb18:
  %t93 = load i64, ptr %l88, !tbaa !24
  %t94 = sub i64 %t93, 1
  %t95 = load ptr, ptr %l85, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t95, i64 %t94)
  store i64 %t97, ptr %l90
  br label %bb19
bb19:
  %t98 = load i64, ptr %l90, !tbaa !24
  %t99 = add i64 %t98, 1
  %t100 = load ptr, ptr %l79, !tbaa !29
  %t101 = load i64, ptr %l83, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t100, i64 %t101, i64 %t99)
  br label %bb20
bb20:
  %t103 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l92
  br label %bb21
bb21:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l92
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %t105
  store ptr %t105, ptr %l5, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t107, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l8, !tbaa !24
  br label %bb22
bb22:
  %t113 = load i64, ptr %l7, !tbaa !24
  %t114 = load i64, ptr %l8, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb23, label %bb24
bb23:
  br label %bb29
bb24:
  br label %bb25
bb25:
  %t121 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t121, ptr %l101, !tbaa !27
  %t122 = load i64, ptr %l7, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr ptr, ptr %t125, i64 %t122
  %t127 = load ptr, ptr %t126, !tbaa !39
  %t129 = load ptr, ptr %l5, !tbaa !29
  store ptr %t129, ptr %l104, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t134 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v0, ptr %t130, ptr %t127)
  store ptr %t134, ptr %l107
  br label %bb26
bb26:
  %t135 = load ptr, ptr %l104, !tbaa !29
  %t136 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v0, ptr %t135, ptr %t136)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t137 = load i64, ptr %l7, !tbaa !24
  %t139 = add i64 %t137, 1
  store i64 %t139, ptr %l7, !tbaa !24
  br label %bb22
bb29:
  store i1 false, ptr %l10, !tbaa !21
  %t141 = load ptr, ptr %l3, !tbaa !29
  store ptr %t141, ptr %l11, !tbaa !29
  %t143 = icmp sge i64 0, 0
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t145 = icmp sle i64 0, 1152921504606846975
  br i1 %t145, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb32:
  %t147 = mul i64 0, 8
  %t148 = insertvalue { i64, ptr } undef, i64 0, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t149, ptr %l12, !tbaa !27
  %t151 = load ptr, ptr %l3, !tbaa !29
  store ptr %t151, ptr %l114, !tbaa !29
  store i1 false, ptr %l115, !tbaa !21
  %t152 = load ptr, ptr %l114, !tbaa !29
  %t153 = icmp ne ptr %t152, null
  br i1 %t153, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_e10ca684bef0956d_f742028d37a3af11)
  unreachable
bb34:
  %t155 = load ptr, ptr %l114, !tbaa !29
  %t156 = load i64, ptr %t155, !range !{i64 0, i64 30}
  %t158 = icmp eq i64 %t156, 21
  store i1 %t158, ptr %l115, !tbaa !21
  br label %bb35
bb35:
  %t159 = load i1, ptr %l115, !tbaa !21
  br i1 %t159, label %bb36, label %bb37
bb36:
  %t160 = load ptr, ptr %l3, !tbaa !29
  %t162 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  %t163 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t162, i32 0, i32 1
  %t164 = load ptr, ptr %t163
  store ptr %t164, ptr %l13, !tbaa !29
  %t166 = load ptr, ptr %l3, !tbaa !29
  %t168 = getelementptr { i64, [4 x i64] }, ptr %t166, i32 0, i32 1
  %t169 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t168, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169
  store { i64, ptr } %t170, ptr %l14, !tbaa !27
  br label %bb38
bb37:
  br label %bb39
bb38:
  store i1 true, ptr %l10, !tbaa !21
  %t172 = load ptr, ptr %l13, !tbaa !29
  store ptr %t172, ptr %l11, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t174, ptr %l12, !tbaa !27
  br label %bb44
bb39:
  br i1 true, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_c3afd3921db70d3f_27f9f6390ccac16b)
  unreachable
bb44:
  %t176 = load ptr, ptr %l4, !tbaa !29
  %t178 = getelementptr %"compiler/check:frame", ptr %t176, i32 0, i32 28
  %t180 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t178)
  store i64 %t180, ptr %l126
  br label %bb45
bb45:
  %t181 = load i64, ptr %l126, !tbaa !24
  store i64 %t181, ptr %l15, !tbaa !24
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 42
  store i32 0, ptr %t184, !tbaa !23
  %t185 = load ptr, ptr %l4, !tbaa !29
  store ptr %t185, ptr %l128, !tbaa !29
  %t186 = load ptr, ptr %l128, !tbaa !29
  %t187 = getelementptr %"compiler/check:frame", ptr %t186, i32 0, i32 15
  %t188 = load i64, ptr %t187, !tbaa !24
  %t190 = add i64 %t188, 1
  %t192 = load ptr, ptr %l128, !tbaa !29
  %t193 = getelementptr %"compiler/check:frame", ptr %t192, i32 0, i32 15
  store i64 %t190, ptr %t193, !tbaa !24
  store ptr null, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t194 = load ptr, ptr %l11, !tbaa !29
  store ptr %t194, ptr %l131, !tbaa !29
  store i1 false, ptr %l132, !tbaa !21
  %t195 = load ptr, ptr %l131, !tbaa !29
  %t196 = icmp ne ptr %t195, null
  br i1 %t196, label %bb46, label %bb47
bb46:
  %t198 = load ptr, ptr %l131, !tbaa !29
  %t199 = load i64, ptr %t198, !range !{i64 0, i64 30}
  %t201 = icmp eq i64 %t199, 22
  store i1 %t201, ptr %l132, !tbaa !21
  br label %bb47
bb47:
  %t202 = load i1, ptr %l132, !tbaa !21
  br i1 %t202, label %bb48, label %bb49
bb48:
  %t203 = load ptr, ptr %l11, !tbaa !29
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t203, i32 0, i32 1
  %t206 = getelementptr { %"compiler/source:Span", ptr }, ptr %t205, i32 0, i32 0
  %t207 = load %"compiler/source:Span", ptr %t206
  store %"compiler/source:Span" %t207, ptr %l18
  %t209 = load ptr, ptr %l11, !tbaa !29
  %t211 = getelementptr { i64, [4 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", ptr }, ptr %t211, i32 0, i32 1
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l19, !tbaa !29
  br label %bb50
bb49:
  br label %bb71
bb50:
  %t215 = load ptr, ptr %l19, !tbaa !29
  %t217 = getelementptr %"compiler/ast:Func", ptr %t215, i32 0, i32 3
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = getelementptr %"compiler/ast:Sig", ptr %t218, i32 0, i32 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t225 = icmp sgt i64 %t223, 0
  br i1 %t225, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s11
  %t227 = load ptr, ptr %l0, !tbaa !29
  store ptr %t227, ptr %l144, !tbaa !29
  %t228 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t228, ptr %l145
  %t229 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %s11)
  store %"compiler/diagmsg:Msg" %t229, ptr %l146
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t230 = load ptr, ptr %l144, !tbaa !29
  %t231 = load %"compiler/source:Span", ptr %l145
  %t232 = load %"compiler/diagmsg:Msg", ptr %l146
  %t233 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s11, ptr %t230, %"compiler/source:Span" %t231, %"compiler/diagmsg:Msg" %t232)
  store i64 %t233, ptr %l147
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s11)
  br label %bb55
bb55:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load %"compiler/source:Span", ptr %l18
  %t236 = load ptr, ptr %l19, !tbaa !29
  %t237 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t242 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v2, ptr %v0, ptr %t234, %"compiler/source:Span" %t235, ptr %t236, i32 %t237)
  store ptr %t242, ptr %l152
  br label %bb56
bb56:
  %t243 = load ptr, ptr %l152, !tbaa !29
  store ptr %t243, ptr %l20, !tbaa !29
  %t244 = load ptr, ptr %l20, !tbaa !29
  %t247 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t244)
  store i32 %t247, ptr %l155
  br label %bb57
bb57:
  %t248 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t249 = load i32, ptr %l155, !tbaa !23
  %t251 = icmp ne i32 %t249, %t248
  br i1 %t251, label %bb58, label %bb59
bb58:
  %t253 = load ptr, ptr %l0, !tbaa !29
  store ptr %t253, ptr %l158, !tbaa !29
  %t254 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t254, ptr %l159
  %t255 = load %"compiler/source:Span", ptr %l18
  store %"compiler/source:Span" %t255, ptr %l160
  %t256 = load ptr, ptr %l20, !tbaa !29
  %t259 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t256)
  store i32 %t259, ptr %l163
  br label %bb60
bb59:
  br label %bb70
bb60:
  %t260 = load ptr, ptr %l20, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t261
  %t262 = getelementptr { i64, [3 x i64] }, ptr %t261, i32 0, i32 0
  store i64 2, ptr %t262
  %t264 = insertvalue { ptr } undef, ptr %t260, 0
  %t265 = getelementptr { i64, [3 x i64] }, ptr %t261, i32 0, i32 1
  store { ptr } %t264, ptr %t265
  %t266 = load { i64, [3 x i64] }, ptr %t261
  %t268 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t266, ptr %t268
  store ptr %t268, ptr %l166, !tbaa !29
  %t269 = icmp sge i64 0, 0
  br i1 %t269, label %bb61, label %bb62
bb61:
  %t271 = icmp sle i64 0, 1152921504606846975
  br i1 %t271, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb63:
  %t273 = mul i64 0, 8
  %t274 = insertvalue { i64, ptr } undef, i64 0, 0
  %t275 = insertvalue { i64, ptr } %t274, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t275, ptr %l169, !tbaa !27
  %t276 = icmp sge i64 0, 0
  br i1 %t276, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb65:
  %t278 = icmp sle i64 0, 1152921504606846975
  br i1 %t278, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb67:
  %t280 = mul i64 0, 8
  %t281 = insertvalue { i64, ptr } undef, i64 0, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t283 = load ptr, ptr %l158, !tbaa !29
  %t284 = load %"compiler/source:Span", ptr %l159
  %t285 = load %"compiler/source:Span", ptr %l160
  %t286 = load i32, ptr %l163, !tbaa !23
  %t287 = load ptr, ptr %l166, !tbaa !29
  %t288 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t290 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t283, %"compiler/source:Span" %t284, %"compiler/source:Span" %t285, i32 %t286, ptr %t287, i64 -1, ptr null, { i64, ptr } %t288, { i64, ptr } %t282)
  store ptr %t290, ptr %l173
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_da760de622febe3_df78aa298e2a00e7)
  unreachable
bb69:
  %t291 = load ptr, ptr %l173, !tbaa !29
  store ptr %t291, ptr %l16, !tbaa !29
  br label %bb70
bb70:
  br label %bb100
bb71:
  %t293 = load ptr, ptr %l11, !tbaa !29
  store ptr %t293, ptr %l175, !tbaa !29
  store i1 false, ptr %l176, !tbaa !21
  %t294 = load ptr, ptr %l175, !tbaa !29
  %t295 = icmp ne ptr %t294, null
  br i1 %t295, label %bb72, label %bb73
bb72:
  %t297 = load ptr, ptr %l175, !tbaa !29
  %t298 = load i64, ptr %t297, !range !{i64 0, i64 30}
  %t300 = icmp eq i64 %t298, 12
  store i1 %t300, ptr %l176, !tbaa !21
  br label %bb73
bb73:
  %t301 = load i1, ptr %l176, !tbaa !21
  br i1 %t301, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb78
bb76:
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t303 = load ptr, ptr %l11, !tbaa !29
  %t305 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t309 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t302, ptr %t303, i32 %t305)
  store ptr %t309, ptr %l183
  br label %bb77
bb77:
  %t310 = load ptr, ptr %l183, !tbaa !29
  store ptr %t310, ptr %l16, !tbaa !29
  br label %bb100
bb78:
  %t312 = load ptr, ptr %l11, !tbaa !29
  store ptr %t312, ptr %l185, !tbaa !29
  store i1 false, ptr %l186, !tbaa !21
  %t313 = load ptr, ptr %l185, !tbaa !29
  %t314 = icmp ne ptr %t313, null
  br i1 %t314, label %bb79, label %bb80
bb79:
  %t316 = load ptr, ptr %l185, !tbaa !29
  %t317 = load i64, ptr %t316, !range !{i64 0, i64 30}
  %t319 = icmp eq i64 %t317, 4
  store i1 %t319, ptr %l186, !tbaa !21
  br label %bb80
bb80:
  %t320 = load i1, ptr %l186, !tbaa !21
  br i1 %t320, label %bb81, label %bb82
bb81:
  %t321 = load ptr, ptr %l11, !tbaa !29
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t323, i32 0, i32 1
  %t325 = load i32, ptr %t324, !range !{i32 0, i32 98}
  store i32 %t325, ptr %l21
  %t327 = load ptr, ptr %l11, !tbaa !29
  %t329 = getelementptr { i64, [4 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t329, i32 0, i32 2
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l22, !tbaa !29
  br label %bb83
bb82:
  br label %bb91
bb83:
  %t333 = load i32, ptr %l21, !range !{i32 0, i32 98}
  %t335 = trunc i64 80 to i32
  %t336 = icmp eq i32 %t333, %t335
  br i1 %t336, label %bb84, label %bb85
bb84:
  %t338 = load ptr, ptr %l22, !tbaa !29
  %t340 = call i1 @compiler_2fcheck_2ecallLike(ptr %v2, ptr %t338)
  store i1 %t340, ptr %l197
  br label %bb86
bb85:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb87
bb86:
  %t341 = load i1, ptr %l197, !tbaa !21
  store i1 %t341, ptr %l195, !tbaa !21
  br label %bb87
bb87:
  %t342 = load i1, ptr %l195, !tbaa !21
  br i1 %t342, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l17, !tbaa !21
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load ptr, ptr %l11, !tbaa !29
  %t346 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t350 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t343, ptr %t344, i32 %t346)
  store ptr %t350, ptr %l202
  br label %bb90
bb89:
  br label %bb91
bb90:
  %t351 = load ptr, ptr %l202, !tbaa !29
  store ptr %t351, ptr %l16, !tbaa !29
  br label %bb100
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb99
bb94:
  store %olang.scope zeroinitializer, ptr %s15
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l204, !tbaa !29
  %t354 = load ptr, ptr %l11, !tbaa !29
  %t356 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t354)
  store %"compiler/source:Span" %t356, ptr %l206
  br label %bb95
bb95:
  %t357 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %s15)
  store %"compiler/diagmsg:Msg" %t357, ptr %l207
  br label %bb96
bb96:
  %t358 = load ptr, ptr %l204, !tbaa !29
  %t359 = load %"compiler/source:Span", ptr %l206
  %t360 = load %"compiler/diagmsg:Msg", ptr %l207
  %t361 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s15, ptr %t358, %"compiler/source:Span" %t359, %"compiler/diagmsg:Msg" %t360)
  store i64 %t361, ptr %l208
  br label %bb97
bb97:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load ptr, ptr %l11, !tbaa !29
  %t365 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t369 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v2, ptr %v0, ptr %t362, ptr %t363, i32 %t365)
  store ptr %t369, ptr %l213
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s15)
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @olang_loc_5ca7d448b00003f5_5d17299a767670c1)
  unreachable
bb100:
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t370)
  store ptr %t372, ptr %l215
  br label %bb101
bb101:
  %t373 = load ptr, ptr %l215, !tbaa !29
  store ptr %t373, ptr %l4, !tbaa !29
  %t374 = load ptr, ptr %l4, !tbaa !29
  store ptr %t374, ptr %l216, !tbaa !29
  %t375 = load ptr, ptr %l216, !tbaa !29
  %t376 = getelementptr %"compiler/check:frame", ptr %t375, i32 0, i32 15
  %t377 = load i64, ptr %t376, !tbaa !24
  %t379 = sub i64 %t377, 1
  %t381 = load ptr, ptr %l216, !tbaa !29
  %t382 = getelementptr %"compiler/check:frame", ptr %t381, i32 0, i32 15
  store i64 %t379, ptr %t382, !tbaa !24
  %t383 = load i1, ptr %l10, !tbaa !21
  br i1 %t383, label %bb102, label %bb103
bb102:
  %t385 = load ptr, ptr %l16, !tbaa !29
  %t387 = icmp eq ptr %t385, null
  %t389 = xor i1 %t387, true
  store i1 %t389, ptr %l220, !tbaa !21
  br label %bb104
bb103:
  store i1 false, ptr %l220, !tbaa !21
  br label %bb104
bb104:
  %t391 = load i1, ptr %l220, !tbaa !21
  br i1 %t391, label %bb105, label %bb106
bb105:
  %t392 = load ptr, ptr %l0, !tbaa !29
  store ptr %t392, ptr %l224, !tbaa !29
  %t393 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t393, ptr %l225, !tbaa !27
  %t394 = load i64, ptr %l15, !tbaa !24
  store i64 %t394, ptr %l226, !tbaa !24
  %t395 = load ptr, ptr %l4, !tbaa !29
  %t397 = getelementptr %"compiler/check:frame", ptr %t395, i32 0, i32 28
  %t399 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t397)
  store i64 %t399, ptr %l229
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t400 = load ptr, ptr %l224, !tbaa !29
  %t401 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t402 = load i64, ptr %l226, !tbaa !24
  %t403 = load i64, ptr %l229, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v2, ptr %t400, { i64, ptr } %t401, i64 %t402, i64 %t403)
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t404 = load ptr, ptr %l4, !tbaa !29
  %t406 = getelementptr %"compiler/check:frame", ptr %t404, i32 0, i32 28
  %t407 = load i64, ptr %l15, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t406, i64 %t407)
  br label %bb110
bb110:
  %t410 = load ptr, ptr %l16, !tbaa !29
  %t412 = icmp eq ptr %t410, null
  br i1 %t412, label %bb111, label %bb112
bb111:
  %t414 = load ptr, ptr %l0, !tbaa !29
  store ptr %t414, ptr %l235, !tbaa !29
  %t415 = load ptr, ptr %l235, !tbaa !29
  %t416 = getelementptr %"compiler/check:Checker", ptr %t415, i32 0, i32 41
  %t417 = load i64, ptr %t416, !tbaa !24
  %t419 = sub i64 %t417, 1
  %t421 = load ptr, ptr %l235, !tbaa !29
  %t422 = getelementptr %"compiler/check:Checker", ptr %t421, i32 0, i32 41
  store i64 %t419, ptr %t422, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb112:
  br label %bb113
bb113:
  %t423 = load ptr, ptr %l16, !tbaa !29
  %t425 = call i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %t423)
  store i1 %t425, ptr %l239
  br label %bb114
bb114:
  %t426 = load i1, ptr %l239, !tbaa !21
  br i1 %t426, label %bb115, label %bb116
bb115:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l240, !tbaa !29
  %t428 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t428, ptr %l241, !tbaa !27
  %t429 = load ptr, ptr %l3, !tbaa !29
  store ptr %t429, ptr %l242, !tbaa !29
  %t430 = load ptr, ptr %l11, !tbaa !29
  store ptr %t430, ptr %l243, !tbaa !29
  %t431 = load ptr, ptr %l16, !tbaa !29
  %t434 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t431)
  store i32 %t434, ptr %l246
  br label %bb117
bb116:
  br label %bb119
bb117:
  %t435 = load ptr, ptr %l240, !tbaa !29
  %t436 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t437 = load ptr, ptr %l242, !tbaa !29
  %t438 = load ptr, ptr %l243, !tbaa !29
  %t439 = load i32, ptr %l246, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eanySpawned(ptr %v0, ptr %v1, ptr %v2, ptr %v2, ptr %t435, { i64, ptr } %t436, ptr %t437, ptr %t438, i32 %t439)
  br label %bb118
bb118:
  %t440 = load ptr, ptr %l0, !tbaa !29
  store ptr %t440, ptr %l247, !tbaa !29
  %t441 = load ptr, ptr %l247, !tbaa !29
  %t442 = getelementptr %"compiler/check:Checker", ptr %t441, i32 0, i32 41
  %t443 = load i64, ptr %t442, !tbaa !24
  %t445 = sub i64 %t443, 1
  %t447 = load ptr, ptr %l247, !tbaa !29
  %t448 = getelementptr %"compiler/check:Checker", ptr %t447, i32 0, i32 41
  store i64 %t445, ptr %t448, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb119:
  %t449 = load ptr, ptr %l0, !tbaa !29
  %t451 = getelementptr %"compiler/check:Checker", ptr %t449, i32 0, i32 1
  %t452 = load ptr, ptr %t451, !tbaa !29
  %t454 = getelementptr %"compiler/generic:Program", ptr %t452, i32 0, i32 2
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t457 = getelementptr %"compiler/check:Checker", ptr %t455, i32 0, i32 42
  %t458 = load i32, ptr %t457, !tbaa !23
  %t461 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t454, i32 %t458)
  store { i64, ptr } %t461, ptr %l255
  br label %bb120
bb120:
  %t462 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t462, ptr %l23, !tbaa !27
  %t463 = load i1, ptr %l17, !tbaa !21
  br i1 %t463, label %bb121, label %bb122
bb121:
  %t465 = icmp sge i64 0, 0
  br i1 %t465, label %bb123, label %bb124
bb122:
  br label %bb127
bb123:
  %t467 = icmp sle i64 0, 2305843009213693951
  br i1 %t467, label %bb125, label %bb126
bb124:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb125:
  %t469 = mul i64 0, 4
  %t470 = insertvalue { i64, ptr } undef, i64 0, 0
  %t471 = insertvalue { i64, ptr } %t470, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t471, ptr %l23, !tbaa !27
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_a0a2b29f181c5519_be518ce768fc1fe5)
  unreachable
bb127:
  %t473 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t473, 0
  %t477 = icmp sgt i64 %t475, 0
  br i1 %t477, label %bb128, label %bb129
bb128:
  %t479 = load i1, ptr %l10, !tbaa !21
  %t481 = xor i1 %t479, true
  store i1 %t481, ptr %l263, !tbaa !21
  br label %bb130
bb129:
  store i1 false, ptr %l263, !tbaa !21
  br label %bb130
bb130:
  %t483 = load i1, ptr %l263, !tbaa !21
  br i1 %t483, label %bb131, label %bb132
bb131:
  store %olang.scope zeroinitializer, ptr %s22
  %t484 = load ptr, ptr %l0, !tbaa !29
  store ptr %t484, ptr %l266, !tbaa !29
  %t485 = load ptr, ptr %l11, !tbaa !29
  %t487 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t485)
  store %"compiler/source:Span" %t487, ptr %l268
  br label %bb133
bb132:
  br label %bb136
bb133:
  %t488 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %s22)
  store %"compiler/diagmsg:Msg" %t488, ptr %l269
  br label %bb134
bb134:
  %t489 = load ptr, ptr %l266, !tbaa !29
  %t490 = load %"compiler/source:Span", ptr %l268
  %t491 = load %"compiler/diagmsg:Msg", ptr %l269
  %t492 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s22, ptr %t489, %"compiler/source:Span" %t490, %"compiler/diagmsg:Msg" %t491)
  store i64 %t492, ptr %l270
  br label %bb135
bb135:
  %t493 = load ptr, ptr %l4, !tbaa !29
  store ptr %t493, ptr %l271, !tbaa !29
  %t494 = load ptr, ptr %l271, !tbaa !29
  %t495 = getelementptr %"compiler/check:frame", ptr %t494, i32 0, i32 41
  %t496 = load i64, ptr %t495, !tbaa !24
  %t498 = add i64 %t496, 1
  %t500 = load ptr, ptr %l271, !tbaa !29
  %t501 = getelementptr %"compiler/check:frame", ptr %t500, i32 0, i32 41
  store i64 %t498, ptr %t501, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb136
bb136:
  %t502 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t506 = icmp eq i64 %t504, 0
  br i1 %t506, label %bb137, label %bb138
bb137:
  %t508 = load i1, ptr %l10, !tbaa !21
  store i1 %t508, ptr %l277, !tbaa !21
  br label %bb139
bb138:
  store i1 false, ptr %l277, !tbaa !21
  br label %bb139
bb139:
  %t510 = load i1, ptr %l277, !tbaa !21
  br i1 %t510, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s23
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l279, !tbaa !29
  %t512 = load ptr, ptr %l3, !tbaa !29
  %t514 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t512)
  store %"compiler/source:Span" %t514, ptr %l281
  br label %bb142
bb141:
  br label %bb145
bb142:
  %t515 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %s23)
  store %"compiler/diagmsg:Msg" %t515, ptr %l282
  br label %bb143
bb143:
  %t516 = load ptr, ptr %l279, !tbaa !29
  %t517 = load %"compiler/source:Span", ptr %l281
  %t518 = load %"compiler/diagmsg:Msg", ptr %l282
  %t519 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s23, ptr %t516, %"compiler/source:Span" %t517, %"compiler/diagmsg:Msg" %t518)
  store i64 %t519, ptr %l283
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s23)
  br label %bb145
bb145:
  %t520 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t520, ptr %l284
  br label %bb146
bb146:
  %t521 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l284
  %t522 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t521, ptr %t522
  store ptr %t522, ptr %l24, !tbaa !29
  %t524 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t524, ptr %l286
  br label %bb147
bb147:
  %t525 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l286
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t525, ptr %l25
  %t526 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t528 = extractvalue { i64, ptr } %t526, 0
  %t530 = icmp sgt i64 %t528, 0
  br i1 %t530, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s24
  %t532 = load ptr, ptr %l16, !tbaa !29
  %t535 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t532)
  store i32 %t535, ptr %l292
  br label %bb150
bb149:
  br label %bb233
bb150:
  %t536 = load i32, ptr %l292, !tbaa !23
  store i32 %t536, ptr %l26, !tbaa !23
  %t537 = load ptr, ptr %l5, !tbaa !29
  %t539 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t537)
  store i64 %t539, ptr %l294
  br label %bb151
bb151:
  %t540 = load i64, ptr %l294, !tbaa !24
  %t541 = icmp eq i64 %t540, 1
  br i1 %t541, label %bb152, label %bb153
bb152:
  %t543 = load ptr, ptr %l5, !tbaa !29
  %t545 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %s24, ptr %t543, i64 0)
  store ptr %t545, ptr %l298
  br label %bb154
bb153:
  store i1 false, ptr %l296, !tbaa !21
  br label %bb155
bb154:
  %t546 = load ptr, ptr %l298, !tbaa !29
  %t547 = icmp eq ptr %t546, null
  %t549 = xor i1 %t547, true
  store i1 %t549, ptr %l296, !tbaa !21
  br label %bb155
bb155:
  %t551 = load i1, ptr %l296, !tbaa !21
  br i1 %t551, label %bb156, label %bb157
bb156:
  %t552 = load ptr, ptr %l5, !tbaa !29
  %t554 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v0, ptr %t552, i64 0)
  store ptr %t554, ptr %l302
  br label %bb158
bb157:
  br label %bb181
bb158:
  %t555 = load ptr, ptr %l302, !tbaa !29
  store ptr %t555, ptr %l27, !tbaa !29
  %t556 = load ptr, ptr %l27, !tbaa !29
  %t558 = icmp eq ptr %t556, null
  br i1 %t558, label %bb159, label %bb160
bb159:
  call void @__olang_check_failed(ptr @olang_loc_ebab815881a318c_398bac8a238c0b80)
  unreachable
bb160:
  br label %bb161
bb161:
  %t560 = load ptr, ptr %l27, !tbaa !29
  %t562 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %t560)
  store i32 %t562, ptr %l306
  br label %bb162
bb162:
  %t563 = load i32, ptr %l306, !tbaa !23
  store i32 %t563, ptr %l28, !tbaa !23
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t565 = load i32, ptr %l26, !tbaa !23
  %t568 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t564, i32 %t565)
  store i1 %t568, ptr %l309
  br label %bb163
bb163:
  %t569 = load i1, ptr %l309, !tbaa !21
  br i1 %t569, label %bb164, label %bb165
bb164:
  %t570 = load ptr, ptr %l0, !tbaa !29
  %t571 = load i32, ptr %l28, !tbaa !23
  %t574 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t570, i32 %t571)
  store i1 %t574, ptr %l313
  br label %bb166
bb165:
  store i1 false, ptr %l310, !tbaa !21
  br label %bb167
bb166:
  %t575 = load i1, ptr %l313, !tbaa !21
  store i1 %t575, ptr %l310, !tbaa !21
  br label %bb167
bb167:
  %t576 = load i1, ptr %l310, !tbaa !21
  br i1 %t576, label %bb168, label %bb169
bb168:
  %t577 = load ptr, ptr %l0, !tbaa !29
  %t579 = getelementptr %"compiler/check:Checker", ptr %t577, i32 0, i32 1
  %t580 = load ptr, ptr %t579, !tbaa !29
  %t582 = getelementptr %"compiler/generic:Program", ptr %t580, i32 0, i32 2
  %t583 = load i32, ptr %l28, !tbaa !23
  %t586 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %t582, i32 %t583)
  store i1 %t586, ptr %l319
  br label %bb170
bb169:
  store i1 false, ptr %l314, !tbaa !21
  br label %bb171
bb170:
  %t587 = load i1, ptr %l319, !tbaa !21
  store i1 %t587, ptr %l314, !tbaa !21
  br label %bb171
bb171:
  %t588 = load i1, ptr %l314, !tbaa !21
  br i1 %t588, label %bb172, label %bb173
bb172:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/check:Checker", ptr %t589, i32 0, i32 1
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t594 = getelementptr %"compiler/generic:Program", ptr %t592, i32 0, i32 2
  %t595 = load i32, ptr %l28, !tbaa !23
  %t598 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t594, i32 %t595)
  store i32 %t598, ptr %l325
  br label %bb174
bb173:
  store i1 false, ptr %l320, !tbaa !21
  br label %bb176
bb174:
  %t599 = load ptr, ptr %l0, !tbaa !29
  %t601 = getelementptr %"compiler/check:Checker", ptr %t599, i32 0, i32 1
  %t602 = load ptr, ptr %t601, !tbaa !29
  %t604 = getelementptr %"compiler/generic:Program", ptr %t602, i32 0, i32 2
  %t605 = load i32, ptr %l26, !tbaa !23
  %t608 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t604, i32 %t605)
  store i32 %t608, ptr %l330
  br label %bb175
bb175:
  %t609 = load i32, ptr %l325, !tbaa !23
  %t610 = load i32, ptr %l330, !tbaa !23
  %t611 = icmp eq i32 %t609, %t610
  store i1 %t611, ptr %l320, !tbaa !21
  br label %bb176
bb176:
  %t613 = load i1, ptr %l320, !tbaa !21
  br i1 %t613, label %bb177, label %bb178
bb177:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/check:Checker", ptr %t614, i32 0, i32 1
  %t617 = load ptr, ptr %t616, !tbaa !29
  %t619 = getelementptr %"compiler/generic:Program", ptr %t617, i32 0, i32 2
  %t620 = load i32, ptr %l26, !tbaa !23
  %t623 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %t619, i32 %t620)
  store i32 %t623, ptr %l336
  br label %bb179
bb178:
  br label %bb180
bb179:
  %t624 = load i32, ptr %l336, !tbaa !23
  store i32 %t624, ptr %l26, !tbaa !23
  br label %bb180
bb180:
  br label %bb181
bb181:
  %t625 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t625, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t627 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t629 = extractvalue { i64, ptr } %t627, 0
  store i64 %t629, ptr %l31, !tbaa !24
  br label %bb182
bb182:
  store %olang.scope zeroinitializer, ptr %s28
  %t631 = load i64, ptr %l30, !tbaa !24
  %t632 = load i64, ptr %l31, !tbaa !24
  %t635 = icmp slt i64 %t631, %t632
  %t637 = xor i1 %t635, true
  br i1 %t637, label %bb183, label %bb184
bb183:
  call void @__olang_scope_close(ptr %s28)
  br label %bb232
bb184:
  br label %bb185
bb185:
  %t639 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t639, ptr %l344, !tbaa !27
  %t640 = load i64, ptr %l30, !tbaa !24
  %t642 = getelementptr { i64, ptr }, ptr %l344, i32 0, i32 1
  %t643 = load ptr, ptr %t642, !tbaa !27
  %t644 = getelementptr ptr, ptr %t643, i64 %t640
  %t645 = load ptr, ptr %t644, !tbaa !39
  store ptr %t645, ptr %l32, !tbaa !29
  %t647 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %s28, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t647, ptr %l347
  br label %bb186
bb186:
  %t648 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l347
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t648, ptr %l33
  %t649 = load ptr, ptr %l0, !tbaa !29
  %t650 = load ptr, ptr %l32, !tbaa !29
  %t653 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v2, ptr %t649, ptr %t650)
  store i1 %t653, ptr %l350
  br label %bb187
bb187:
  %t654 = load i1, ptr %l350, !tbaa !21
  store i1 %t654, ptr %l34, !tbaa !21
  %t655 = load ptr, ptr %l32, !tbaa !29
  %t657 = getelementptr %"compiler/ast:Catch", ptr %t655, i32 0, i32 1
  %t658 = load { i64, ptr }, ptr %t657, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t658, 0
  %t662 = icmp sgt i64 %t660, 0
  br i1 %t662, label %bb188, label %bb189
bb188:
  %t664 = load i1, ptr %l34, !tbaa !21
  %t666 = xor i1 %t664, true
  store i1 %t666, ptr %l355, !tbaa !21
  br label %bb190
bb189:
  store i1 false, ptr %l355, !tbaa !21
  br label %bb190
bb190:
  %t668 = load i1, ptr %l355, !tbaa !21
  br i1 %t668, label %bb191, label %bb192
bb191:
  %t669 = load ptr, ptr %l32, !tbaa !29
  %t671 = getelementptr %"compiler/ast:Catch", ptr %t669, i32 0, i32 1
  %t672 = load { i64, ptr }, ptr %t671, !tbaa !27
  store { i64, ptr } %t672, ptr %l35, !tbaa !27
  store i64 0, ptr %l36, !tbaa !24
  %t674 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t676 = extractvalue { i64, ptr } %t674, 0
  store i64 %t676, ptr %l37, !tbaa !24
  br label %bb193
bb192:
  br label %bb200
bb193:
  %t678 = load i64, ptr %l36, !tbaa !24
  %t679 = load i64, ptr %l37, !tbaa !24
  %t682 = icmp slt i64 %t678, %t679
  %t684 = xor i1 %t682, true
  br i1 %t684, label %bb194, label %bb195
bb194:
  br label %bb199
bb195:
  br label %bb196
bb196:
  %t686 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t686, ptr %l366, !tbaa !27
  %t687 = load i64, ptr %l36, !tbaa !24
  %t689 = getelementptr { i64, ptr }, ptr %l366, i32 0, i32 1
  %t690 = load ptr, ptr %t689, !tbaa !27
  %t691 = getelementptr ptr, ptr %t690, i64 %t687
  %t692 = load ptr, ptr %t691, !tbaa !39
  %t694 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v2, ptr %s28, ptr %t694, ptr %t692, ptr %l33)
  br label %bb197
bb197:
  br label %bb198
bb198:
  %t699 = load i64, ptr %l36, !tbaa !24
  %t701 = add i64 %t699, 1
  store i64 %t701, ptr %l36, !tbaa !24
  br label %bb193
bb199:
  br label %bb200
bb200:
  %t703 = load ptr, ptr %l32, !tbaa !29
  %t705 = getelementptr %"compiler/ast:Catch", ptr %t703, i32 0, i32 5
  %t706 = load i32, ptr %t705, !tbaa !23
  %t708 = icmp ne i32 %t706, 0
  br i1 %t708, label %bb201, label %bb202
bb201:
  store i1 true, ptr %l377, !tbaa !21
  br label %bb203
bb202:
  %t710 = load i1, ptr %l34, !tbaa !21
  store i1 %t710, ptr %l377, !tbaa !21
  br label %bb203
bb203:
  %t712 = load i1, ptr %l377, !tbaa !21
  br i1 %t712, label %bb204, label %bb205
bb204:
  store %olang.scope zeroinitializer, ptr %s33
  %t713 = load ptr, ptr %l0, !tbaa !29
  store ptr %t713, ptr %l379, !tbaa !29
  %t714 = load i1, ptr %l34, !tbaa !21
  br i1 %t714, label %bb206, label %bb207
bb205:
  br label %bb215
bb206:
  %t716 = load ptr, ptr %l32, !tbaa !29
  %t718 = getelementptr %"compiler/ast:Catch", ptr %t716, i32 0, i32 1
  %t719 = load { i64, ptr }, ptr %t718, !tbaa !27
  store { i64, ptr } %t719, ptr %l383, !tbaa !27
  %t720 = getelementptr { i64, ptr }, ptr %l383, i32 0, i32 1
  %t721 = load ptr, ptr %t720, !tbaa !27
  %t722 = getelementptr ptr, ptr %t721, i64 0
  %t723 = load ptr, ptr %t722, !tbaa !39
  %t725 = getelementptr %"compiler/ast:Path", ptr %t723, i32 0, i32 0
  %t726 = load %"compiler/source:Span", ptr %t725
  store %"compiler/source:Span" %t726, ptr %l381
  br label %bb208
bb207:
  %t728 = load ptr, ptr %l32, !tbaa !29
  %t730 = getelementptr %"compiler/ast:Catch", ptr %t728, i32 0, i32 6
  %t731 = load %"compiler/source:Span", ptr %t730
  store %"compiler/source:Span" %t731, ptr %l381
  br label %bb208
bb208:
  %t733 = load ptr, ptr %l0, !tbaa !29
  store ptr %t733, ptr %l388, !tbaa !29
  %t734 = load i1, ptr %l34, !tbaa !21
  br i1 %t734, label %bb209, label %bb210
bb209:
  %t736 = load ptr, ptr %l32, !tbaa !29
  %t738 = getelementptr %"compiler/ast:Catch", ptr %t736, i32 0, i32 1
  %t739 = load { i64, ptr }, ptr %t738, !tbaa !27
  store { i64, ptr } %t739, ptr %l392, !tbaa !27
  %t740 = getelementptr { i64, ptr }, ptr %l392, i32 0, i32 1
  %t741 = load ptr, ptr %t740, !tbaa !27
  %t742 = getelementptr ptr, ptr %t741, i64 0
  %t743 = load ptr, ptr %t742, !tbaa !39
  %t745 = getelementptr %"compiler/ast:Path", ptr %t743, i32 0, i32 1
  %t746 = load { i64, ptr }, ptr %t745, !tbaa !27
  store { i64, ptr } %t746, ptr %l394, !tbaa !27
  %t747 = getelementptr { i64, ptr }, ptr %l394, i32 0, i32 1
  %t748 = load ptr, ptr %t747, !tbaa !27
  %t749 = getelementptr i32, ptr %t748, i64 0
  %t750 = load i32, ptr %t749, !tbaa !33
  store i32 %t750, ptr %l390, !tbaa !23
  br label %bb211
bb210:
  %t752 = load ptr, ptr %l32, !tbaa !29
  %t754 = getelementptr %"compiler/ast:Catch", ptr %t752, i32 0, i32 5
  %t755 = load i32, ptr %t754, !tbaa !23
  store i32 %t755, ptr %l390, !tbaa !23
  br label %bb211
bb211:
  %t757 = load ptr, ptr %l388, !tbaa !29
  %t758 = load i32, ptr %l390, !tbaa !23
  %t759 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s33, ptr %t757, i32 %t758)
  store { i64, ptr } %t759, ptr %l398
  br label %bb212
bb212:
  %t760 = load { i64, ptr }, ptr %l398, !tbaa !27
  %t761 = extractvalue { i64, ptr } %t760, 0
  %t762 = extractvalue { i64, ptr } %t760, 1
  %t763 = mul i64 %t761, 1
  %t764 = call ptr @__olang_scope_alloc(ptr %s33, i64 %t763)
  call void @llvm.memcpy.p0.p0.i64(ptr %t764, ptr %t762, i64 %t763, i1 false)
  %t765 = insertvalue { i64, ptr } undef, i64 %t761, 0
  %t766 = insertvalue { i64, ptr } %t765, ptr %t764, 1
  %t768 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %s33, ptr %s33, { i64, ptr } %t766)
  store %"compiler/diagmsg:Msg" %t768, ptr %l400
  br label %bb213
bb213:
  %t769 = load ptr, ptr %l379, !tbaa !29
  %t770 = load %"compiler/source:Span", ptr %l381
  %t771 = load %"compiler/diagmsg:Msg", ptr %l400
  %t772 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s33, ptr %t769, %"compiler/source:Span" %t770, %"compiler/diagmsg:Msg" %t771)
  store i64 %t772, ptr %l401
  br label %bb214
bb214:
  call void @__olang_scope_close(ptr %s33)
  br label %bb215
bb215:
  %t773 = load ptr, ptr %l32, !tbaa !29
  %t775 = getelementptr %"compiler/ast:Catch", ptr %t773, i32 0, i32 1
  %t776 = load { i64, ptr }, ptr %t775, !tbaa !27
  %t778 = extractvalue { i64, ptr } %t776, 0
  %t780 = icmp eq i64 %t778, 0
  br i1 %t780, label %bb216, label %bb217
bb216:
  store i1 true, ptr %l406, !tbaa !21
  br label %bb218
bb217:
  %t782 = load i1, ptr %l34, !tbaa !21
  store i1 %t782, ptr %l406, !tbaa !21
  br label %bb218
bb218:
  %t784 = load i1, ptr %l406, !tbaa !21
  store i1 %t784, ptr %l39, !tbaa !21
  %t785 = load ptr, ptr %l24, !tbaa !29
  store ptr %t785, ptr %l408, !tbaa !29
  %t786 = load ptr, ptr %l32, !tbaa !29
  %t788 = getelementptr %"compiler/ast:Catch", ptr %t786, i32 0, i32 0
  %t789 = load %"compiler/source:Span", ptr %t788
  store %"compiler/source:Span" %t789, ptr %l410
  %t791 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s28, ptr %v0, ptr %l33)
  store { i64, ptr } %t791, ptr %l412
  br label %bb219
bb219:
  %t792 = load i1, ptr %l39, !tbaa !21
  store i1 %t792, ptr %l413, !tbaa !21
  %t793 = load ptr, ptr %l0, !tbaa !29
  store ptr %t793, ptr %l414, !tbaa !29
  %t794 = load ptr, ptr %l32, !tbaa !29
  store ptr %t794, ptr %l415, !tbaa !29
  %t795 = load i32, ptr %l26, !tbaa !23
  store i32 %t795, ptr %l416, !tbaa !23
  %t796 = load ptr, ptr %l5, !tbaa !29
  %t798 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t796)
  store i64 %t798, ptr %l418
  br label %bb220
bb220:
  %t799 = load ptr, ptr %l414, !tbaa !29
  %t800 = load ptr, ptr %l415, !tbaa !29
  %t801 = load i32, ptr %l416, !tbaa !23
  %t802 = load i64, ptr %l418, !tbaa !24
  %t803 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v2, ptr %v0, ptr %t799, ptr %t800, i32 %t801, i64 %t802)
  store ptr %t803, ptr %l419
  br label %bb221
bb221:
  %t804 = load %"compiler/source:Span", ptr %l410
  %t805 = load { i64, ptr }, ptr %l412, !tbaa !27
  %t806 = load i1, ptr %l413, !tbaa !21
  %t807 = load ptr, ptr %l419, !tbaa !29
  %t808 = call %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v0, ptr %v0, %"compiler/source:Span" %t804, { i64, ptr } %t805, i1 %t806, ptr %t807)
  store %"compiler/typed:TaskClause" %t808, ptr %l420
  br label %bb222
bb222:
  %t809 = load %"compiler/typed:TaskClause", ptr %l420
  %t810 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store %"compiler/typed:TaskClause" %t809, ptr %t810
  %t811 = load ptr, ptr %l408, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H70975c58788d810dba7712b4ee87a08c(ptr %v0, ptr %v0, ptr %t811, ptr %t810)
  br label %bb223
bb223:
  store ptr %l25, ptr %l422, !tbaa !29
  %t813 = load ptr, ptr %l32, !tbaa !29
  %t815 = getelementptr %"compiler/ast:Catch", ptr %t813, i32 0, i32 0
  %t816 = load %"compiler/source:Span", ptr %t815
  store %"compiler/source:Span" %t816, ptr %l424
  %t818 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %s28, ptr %s0, ptr %l33)
  store { i64, ptr } %t818, ptr %l426
  br label %bb224
bb224:
  %t819 = load i1, ptr %l39, !tbaa !21
  store i1 %t819, ptr %l427, !tbaa !21
  %t820 = icmp sge i64 0, 0
  br i1 %t820, label %bb225, label %bb226
bb225:
  %t822 = icmp sle i64 0, 1152921504606846975
  br i1 %t822, label %bb227, label %bb228
bb226:
  call void @__olang_check_failed(ptr @olang_loc_e78286934eafcc6f_802ae2752731a35b)
  unreachable
bb227:
  %t824 = mul i64 0, 8
  %t825 = insertvalue { i64, ptr } undef, i64 0, 0
  %t826 = insertvalue { i64, ptr } %t825, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t827 = load %"compiler/source:Span", ptr %l424
  %t828 = load { i64, ptr }, ptr %l426, !tbaa !27
  %t829 = load i1, ptr %l427, !tbaa !21
  %t831 = call %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, %"compiler/source:Span" %t827, { i64, ptr } %t828, i1 %t829, ptr null, { i64, ptr } %t826, i64 -1, i32 0)
  store %"compiler/typed:Clause" %t831, ptr %l431
  br label %bb229
bb228:
  call void @__olang_check_failed(ptr @olang_loc_e78286934eafcc6f_802ae2752731a35b)
  unreachable
bb229:
  %t832 = load %"compiler/typed:Clause", ptr %l431
  %t833 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"compiler/typed:Clause" %t832, ptr %t833
  %t834 = load ptr, ptr %l422, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %s0, ptr %s0, ptr %t834, ptr %t833)
  br label %bb230
bb230:
  call void @__olang_scope_close(ptr %s28)
  br label %bb231
bb231:
  %t836 = load i64, ptr %l30, !tbaa !24
  %t838 = add i64 %t836, 1
  store i64 %t838, ptr %l30, !tbaa !24
  br label %bb182
bb232:
  call void @__olang_scope_close(ptr %s24)
  br label %bb233
bb233:
  %t840 = load ptr, ptr %l4, !tbaa !29
  %t842 = getelementptr %"compiler/check:frame", ptr %t840, i32 0, i32 40
  %t844 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t842)
  store i64 %t844, ptr %l437
  br label %bb234
bb234:
  %t845 = load i64, ptr %l437, !tbaa !24
  store i64 %t845, ptr %l40, !tbaa !24
  %t846 = load i1, ptr %l10, !tbaa !21
  br i1 %t846, label %bb235, label %bb236
bb235:
  %t848 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t848, ptr %l41, !tbaa !27
  store i64 0, ptr %l42, !tbaa !24
  %t850 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t852 = extractvalue { i64, ptr } %t850, 0
  store i64 %t852, ptr %l43, !tbaa !24
  br label %bb237
bb236:
  br label %bb244
bb237:
  %t854 = load i64, ptr %l42, !tbaa !24
  %t855 = load i64, ptr %l43, !tbaa !24
  %t858 = icmp slt i64 %t854, %t855
  %t860 = xor i1 %t858, true
  br i1 %t860, label %bb238, label %bb239
bb238:
  br label %bb243
bb239:
  br label %bb240
bb240:
  %t862 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t862, ptr %l446, !tbaa !27
  %t863 = load i64, ptr %l42, !tbaa !24
  %t865 = getelementptr { i64, ptr }, ptr %l446, i32 0, i32 1
  %t866 = load ptr, ptr %t865, !tbaa !27
  %t867 = getelementptr i32, ptr %t866, i64 %t863
  %t868 = load i32, ptr %t867, !tbaa !33
  %t870 = load ptr, ptr %l4, !tbaa !29
  %t872 = getelementptr %"compiler/check:frame", ptr %t870, i32 0, i32 40
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t872, i32 %t868)
  br label %bb241
bb241:
  br label %bb242
bb242:
  %t876 = load i64, ptr %l42, !tbaa !24
  %t878 = add i64 %t876, 1
  store i64 %t878, ptr %l42, !tbaa !24
  br label %bb237
bb243:
  br label %bb244
bb244:
  %t880 = load ptr, ptr %l0, !tbaa !29
  %t881 = load ptr, ptr %l4, !tbaa !29
  %t883 = getelementptr %"compiler/check:frame", ptr %t881, i32 0, i32 40
  %t884 = load i64, ptr %l40, !tbaa !24
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v0, ptr %s0, ptr %t880, ptr %t883, i64 %t884, ptr %l25)
  br label %bb245
bb245:
  %t889 = load ptr, ptr %l5, !tbaa !29
  %t891 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t889)
  store i64 %t891, ptr %l460
  br label %bb246
bb246:
  %t892 = load i64, ptr %l460, !tbaa !24
  %t893 = icmp sgt i64 %t892, 0
  br i1 %t893, label %bb247, label %bb248
bb247:
  %t895 = load ptr, ptr %l4, !tbaa !29
  %t897 = getelementptr %"compiler/check:frame", ptr %t895, i32 0, i32 40
  %t899 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t897)
  store i64 %t899, ptr %l465
  br label %bb249
bb248:
  store i1 false, ptr %l462, !tbaa !21
  br label %bb250
bb249:
  %t900 = load i64, ptr %l40, !tbaa !24
  %t901 = load i64, ptr %l465, !tbaa !24
  %t903 = icmp sgt i64 %t901, %t900
  store i1 %t903, ptr %l462, !tbaa !21
  br label %bb250
bb250:
  %t905 = load i1, ptr %l462, !tbaa !21
  br i1 %t905, label %bb251, label %bb252
bb251:
  %t906 = load ptr, ptr %l4, !tbaa !29
  store ptr %t906, ptr %l468, !tbaa !29
  %t907 = load ptr, ptr %l468, !tbaa !29
  %t908 = getelementptr %"compiler/check:frame", ptr %t907, i32 0, i32 33
  %t909 = load i64, ptr %t908, !tbaa !24
  %t911 = add i64 %t909, 1
  %t913 = load ptr, ptr %l468, !tbaa !29
  %t914 = getelementptr %"compiler/check:frame", ptr %t913, i32 0, i32 33
  store i64 %t911, ptr %t914, !tbaa !24
  br label %bb253
bb252:
  br label %bb253
bb253:
  %t915 = load ptr, ptr %l5, !tbaa !29
  %t917 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %t915)
  store i64 %t917, ptr %l472
  br label %bb254
bb254:
  %t918 = load i64, ptr %l472, !tbaa !24
  %t919 = icmp sgt i64 %t918, 0
  br i1 %t919, label %bb255, label %bb256
bb255:
  %t921 = load ptr, ptr %l0, !tbaa !29
  store ptr %t921, ptr %l474, !tbaa !29
  %t922 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t922, ptr %l475
  %t923 = load ptr, ptr %l3, !tbaa !29
  store ptr %t923, ptr %l476, !tbaa !29
  %t924 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t924, ptr %l477, !tbaa !27
  %t925 = load ptr, ptr %l5, !tbaa !29
  store ptr %t925, ptr %l478, !tbaa !29
  %t926 = load ptr, ptr %l16, !tbaa !29
  %t929 = call i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %t926)
  store i32 %t929, ptr %l481
  br label %bb257
bb256:
  br label %bb259
bb257:
  %t930 = load ptr, ptr %l474, !tbaa !29
  %t931 = load %"compiler/source:Span", ptr %l475
  %t932 = load ptr, ptr %l476, !tbaa !29
  %t933 = load { i64, ptr }, ptr %l477, !tbaa !27
  %t934 = load ptr, ptr %l478, !tbaa !29
  %t935 = load i32, ptr %l481, !tbaa !23
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnTargets(ptr %v0, ptr %v2, ptr %v1, ptr %v0, ptr %t930, %"compiler/source:Span" %t931, ptr %t932, { i64, ptr } %t933, ptr %t934, i32 %t935)
  br label %bb258
bb258:
  br label %bb259
bb259:
  %t936 = load ptr, ptr %l0, !tbaa !29
  store ptr %t936, ptr %l482, !tbaa !29
  %t937 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t937, ptr %l483
  %t938 = load ptr, ptr %l5, !tbaa !29
  %t940 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eT_Hc52cb714df9676093c851daa15f6f747(ptr %v0, ptr %v0, ptr %t938)
  store { i64, ptr } %t940, ptr %l485
  br label %bb260
bb260:
  %t941 = load ptr, ptr %l16, !tbaa !29
  store ptr %t941, ptr %l486, !tbaa !29
  %t942 = load ptr, ptr %l24, !tbaa !29
  %t944 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H788addc5d4e2ce71c84413f6a2c1cfed(ptr %v0, ptr %v0, ptr %t942)
  store { i64, ptr } %t944, ptr %l488
  br label %bb261
bb261:
  %t945 = load ptr, ptr %l0, !tbaa !29
  %t946 = load %"compiler/source:Span", ptr %l1
  %t950 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %t945, i32 6, %"compiler/source:Span" %t946)
  store i32 %t950, ptr %l492
  br label %bb262
bb262:
  %t951 = load { i64, ptr }, ptr %l485, !tbaa !27
  %t952 = load ptr, ptr %l486, !tbaa !29
  %t953 = load { i64, ptr }, ptr %l488, !tbaa !27
  %t954 = load i32, ptr %l492, !tbaa !23
  %t955 = call %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t951, ptr %t952, { i64, ptr } %t953, i32 %t954)
  store %"compiler/typed:Spawn" %t955, ptr %l493
  br label %bb263
bb263:
  %t956 = load %"compiler/typed:Spawn", ptr %l493
  %t957 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 48, i64 8)
  store %"compiler/typed:Spawn" %t956, ptr %t957
  store { i64, [3 x i64] } zeroinitializer, ptr %t958
  %t959 = getelementptr { i64, [3 x i64] }, ptr %t958, i32 0, i32 0
  store i64 14, ptr %t959
  %t960 = load %"compiler/source:Span", ptr %l483
  %t961 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t960, 0
  %t963 = insertvalue { %"compiler/source:Span", ptr } %t961, ptr %t957, 1
  %t964 = getelementptr { i64, [3 x i64] }, ptr %t958, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t963, ptr %t964
  %t965 = load { i64, [3 x i64] }, ptr %t958
  %t967 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 32, i64 8)
  store { i64, [3 x i64] } %t965, ptr %t967
  %t968 = load ptr, ptr %l482, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v0, ptr %t968, ptr %t967)
  br label %bb264
bb264:
  %t970 = load ptr, ptr %l0, !tbaa !29
  store ptr %t970, ptr %l497, !tbaa !29
  %t971 = load ptr, ptr %l497, !tbaa !29
  %t972 = getelementptr %"compiler/check:Checker", ptr %t971, i32 0, i32 41
  %t973 = load i64, ptr %t972, !tbaa !24
  %t975 = sub i64 %t973, 1
  %t977 = load ptr, ptr %l497, !tbaa !29
  %t978 = getelementptr %"compiler/check:Checker", ptr %t977, i32 0, i32 41
  store i64 %t975, ptr %t978, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellArgs(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l21 = alloca i1
  %l25 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i1
  %l36 = alloca { i64, ptr }
  %l40 = alloca i32
  %l54 = alloca i64
  %l57 = alloca i64
  %l78 = alloca { i64, ptr }
  %l81 = alloca i32
  %l84 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l16
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l4, !tbaa !24
  %t18 = icmp sgt i64 %t16, 0
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = getelementptr %"compiler/check:Checker", ptr %t20, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !29
  %t25 = getelementptr %"compiler/generic:Program", ptr %t23, i32 0, i32 2
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t26, ptr %l25, !tbaa !27
  %t27 = load i64, ptr %l4, !tbaa !24
  %t29 = sub i64 %t27, 1
  %t31 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = getelementptr i32, ptr %t32, i64 %t29
  %t34 = load i32, ptr %t33, !tbaa !33
  %t37 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t25, i32 %t34)
  store i32 %t37, ptr %l29
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t38 = load i32, ptr %l29, !range !{i32 0, i32 33}
  %t40 = trunc i64 30 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t43 = load i1, ptr %l21, !tbaa !21
  br i1 %t43, label %bb6, label %bb7
bb6:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l36, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = sub i64 %t51, 1
  %t55 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr i32, ptr %t56, i64 %t53
  %t58 = load i32, ptr %t57, !tbaa !33
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %t49, i32 %t58)
  store i32 %t61, ptr %l40
  br label %bb8
bb7:
  store i1 false, ptr %l32, !tbaa !21
  br label %bb9
bb8:
  %t62 = load i32, ptr %l40, !tbaa !23
  %t63 = icmp eq i32 %t62, 0
  store i1 %t63, ptr %l32, !tbaa !21
  br label %bb9
bb9:
  %t65 = load i1, ptr %l32, !tbaa !21
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t66 = load i64, ptr %l4, !tbaa !24
  %t68 = sub i64 %t66, 1
  store i64 %t68, ptr %l4, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t72 = icmp eq i64 %t70, 0
  br i1 %t72, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb14:
  br label %bb15
bb15:
  %t74 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t74, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb16
bb16:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/check:Checker", ptr %t76, i32 0, i32 4
  %t79 = load i1, ptr %t78, !tbaa !21
  store i1 %t79, ptr %l5, !tbaa !21
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/check:Checker", ptr %t81, i32 0, i32 4
  store i1 true, ptr %t83, !tbaa !21
  store i64 0, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l4, !tbaa !24
  store i64 %t84, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t86 = load i64, ptr %l7, !tbaa !24
  %t87 = load i64, ptr %l6, !tbaa !24
  %t90 = icmp sgt i64 %t86, %t87
  br i1 %t90, label %bb17, label %bb18
bb17:
  %t92 = load i64, ptr %l8, !tbaa !24
  %t94 = icmp sgt i64 %t92, 0
  br i1 %t94, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l54, !tbaa !24
  br label %bb22
bb19:
  %t96 = load i64, ptr %l7, !tbaa !24
  %t97 = load i64, ptr %l6, !tbaa !24
  %t100 = sub i64 %t96, %t97
  %t101 = load i64, ptr %l8, !tbaa !24
  %t104 = add i64 %t100, %t101
  %t106 = sub i64 %t104, 1
  %t107 = load i64, ptr %l8, !tbaa !24
  %t110 = sdiv i64 %t106, %t107
  store i64 %t110, ptr %l57, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l57, !tbaa !24
  br label %bb21
bb21:
  %t112 = load i64, ptr %l57, !tbaa !24
  store i64 %t112, ptr %l54, !tbaa !24
  br label %bb22
bb22:
  %t113 = load i64, ptr %l54, !tbaa !24
  store i64 %t113, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb23
bb23:
  %t114 = load i64, ptr %l10, !tbaa !24
  %t115 = load i64, ptr %l9, !tbaa !24
  %t118 = icmp slt i64 %t114, %t115
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb24, label %bb25
bb24:
  br label %bb41
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l6, !tbaa !24
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  %t127 = mul i64 %t123, %t124
  %t130 = add i64 %t122, %t127
  store i64 %t130, ptr %l11, !tbaa !24
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t137 = getelementptr %"compiler/generic:Program", ptr %t135, i32 0, i32 2
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t138, ptr %l78, !tbaa !27
  %t139 = load i64, ptr %l11, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  %t147 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t137, i32 %t144)
  store i32 %t147, ptr %l81
  br label %bb27
bb27:
  %t148 = load i32, ptr %l81, !range !{i32 0, i32 33}
  %t150 = trunc i64 30 to i32
  %t151 = icmp eq i32 %t148, %t150
  br i1 %t151, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t153 = load ptr, ptr %l1, !tbaa !29
  store ptr %t153, ptr %l84, !tbaa !29
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = icmp sgt i64 %t154, 0
  br i1 %t156, label %bb30, label %bb31
bb29:
  %t158 = load i64, ptr %l11, !tbaa !24
  %t160 = icmp sgt i64 %t158, 0
  br i1 %t160, label %bb34, label %bb35
bb30:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d33, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb32
bb31:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l87, !tbaa !27
  br label %bb32
bb32:
  %t162 = load ptr, ptr %l84, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l87, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t162, { i64, ptr } %t163)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t164 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s7, ptr %t164, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) })
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t168, ptr %l93, !tbaa !27
  %t169 = load i64, ptr %l11, !tbaa !24
  %t171 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i32, ptr %t172, i64 %t169
  %t174 = load i32, ptr %t173, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t166, ptr %t167, i32 %t174, i1 false)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t178 = load i64, ptr %l10, !tbaa !24
  %t180 = add i64 %t178, 1
  store i64 %t180, ptr %l10, !tbaa !24
  br label %bb23
bb41:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t183 = load i1, ptr %l5, !tbaa !21
  %t186 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 4
  store i1 %t183, ptr %t186, !tbaa !21
  %t187 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t187, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espellList(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i32 %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l17 = alloca { i64, ptr }
  %l21 = alloca i1
  %l23 = alloca i1
  %l34 = alloca i64
  %l37 = alloca i64
  %l60 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t10 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t6, i32 %a2)
  store { i64, ptr } %t10, ptr %l17
  br label %bb1
bb1:
  %t11 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t11, ptr %l5, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t16 = icmp eq i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t20 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store i1 %t20, ptr %l23
  br label %bb4
bb3:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb5
bb4:
  %t21 = load i1, ptr %l23, !tbaa !21
  store i1 %t21, ptr %l21, !tbaa !21
  br label %bb5
bb5:
  %t22 = load i1, ptr %l21, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l1, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v2, ptr %t23, { i64, ptr } %t24)
  br label %bb9
bb9:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t27, i32 0, i32 4
  %t30 = load i1, ptr %t29, !tbaa !21
  store i1 %t30, ptr %l6, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 4
  store i1 true, ptr %t34, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 0
  store i64 %t37, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t39 = load i64, ptr %l8, !tbaa !24
  %t40 = load i64, ptr %l7, !tbaa !24
  %t43 = icmp sgt i64 %t39, %t40
  br i1 %t43, label %bb10, label %bb11
bb10:
  %t45 = load i64, ptr %l9, !tbaa !24
  %t47 = icmp sgt i64 %t45, 0
  br i1 %t47, label %bb12, label %bb13
bb11:
  store i64 0, ptr %l34, !tbaa !24
  br label %bb15
bb12:
  %t49 = load i64, ptr %l8, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t53 = sub i64 %t49, %t50
  %t54 = load i64, ptr %l9, !tbaa !24
  %t57 = add i64 %t53, %t54
  %t59 = sub i64 %t57, 1
  %t60 = load i64, ptr %l9, !tbaa !24
  %t63 = sdiv i64 %t59, %t60
  store i64 %t63, ptr %l37, !tbaa !24
  br label %bb14
bb13:
  store i64 0, ptr %l37, !tbaa !24
  br label %bb14
bb14:
  %t65 = load i64, ptr %l37, !tbaa !24
  store i64 %t65, ptr %l34, !tbaa !24
  br label %bb15
bb15:
  %t66 = load i64, ptr %l34, !tbaa !24
  store i64 %t66, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  %t67 = load i64, ptr %l11, !tbaa !24
  %t68 = load i64, ptr %l10, !tbaa !24
  %t71 = icmp slt i64 %t67, %t68
  %t73 = xor i1 %t71, true
  br i1 %t73, label %bb17, label %bb18
bb17:
  br label %bb26
bb18:
  br label %bb19
bb19:
  %t75 = load i64, ptr %l7, !tbaa !24
  %t76 = load i64, ptr %l11, !tbaa !24
  %t77 = load i64, ptr %l9, !tbaa !24
  %t80 = mul i64 %t76, %t77
  %t83 = add i64 %t75, %t80
  store i64 %t83, ptr %l12, !tbaa !24
  %t85 = load i64, ptr %l12, !tbaa !24
  %t87 = icmp sgt i64 %t85, 0
  br i1 %t87, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s4, ptr %t89, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) })
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb23:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load ptr, ptr %l1, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t93, ptr %l60, !tbaa !27
  %t94 = load i64, ptr %l12, !tbaa !24
  %t96 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i32, ptr %t97, i64 %t94
  %t99 = load i32, ptr %t98, !tbaa !33
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %t91, ptr %t92, i32 %t99, i1 false)
  br label %bb24
bb24:
  br label %bb25
bb25:
  %t103 = load i64, ptr %l11, !tbaa !24
  %t105 = add i64 %t103, 1
  store i64 %t105, ptr %l11, !tbaa !24
  br label %bb16
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i1, ptr %l6, !tbaa !21
  %t111 = getelementptr %"compiler/check:Checker", ptr %t107, i32 0, i32 4
  store i1 %t108, ptr %t111, !tbaa !21
  %t112 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v3, ptr %t112, { i64, ptr } %a4)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estaticArray(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i32
  %l6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca ptr
  %l22 = alloca i64
  %l26 = alloca i1
  %l29 = alloca ptr
  %l34 = alloca i32
  %l35 = alloca i32
  %l42 = alloca ptr
  %l47 = alloca i32
  %l48 = alloca i32
  %l49 = alloca ptr
  %l50 = alloca i1
  %l63 = alloca i1
  %l66 = alloca ptr
  %l71 = alloca i32
  %l73 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i32
  %l87 = alloca ptr
  %l89 = alloca i32
  %l91 = alloca i32
  %l97 = alloca i64
  %l99 = alloca ptr
  %l109 = alloca i64
  %l112 = alloca i64
  %l131 = alloca { i64, ptr }
  %l134 = alloca ptr
  %l135 = alloca i1
  %l144 = alloca ptr
  %l145 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca i1
  %l165 = alloca %"compiler/source:Span"
  %l166 = alloca i32
  %l168 = alloca ptr
  %rv = alloca ptr
  %t171 = alloca { i64, [2 x i64] }, align 8
  %t188 = alloca i64
  %t304 = alloca { i64, [2 x i64] }, align 8
  %t357 = alloca { i64, [2 x i64] }, align 8
  %t365 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l2, !tbaa !23
  %t10 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t6, i32 %t7)
  store i64 %t10, ptr %l22
  br label %bb1
bb1:
  %t11 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t12 = load i64, ptr %l22, !tbaa !24
  %t14 = and i64 %t12, %t11
  %t16 = icmp ne i64 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb6
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/generic:Program", ptr %t21, i32 0, i32 2
  store ptr %t23, ptr %l29, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = getelementptr %"compiler/generic:Program", ptr %t27, i32 0, i32 2
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t29, i32 %t30)
  store i32 %t33, ptr %l34
  br label %bb4
bb4:
  %t34 = load ptr, ptr %l29, !tbaa !29
  %t35 = load i32, ptr %l34, !tbaa !23
  %t36 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t34, i32 %t35)
  store i32 %t36, ptr %l35
  br label %bb5
bb5:
  %t37 = load i32, ptr %l35, !range !{i32 0, i32 33}
  %t39 = trunc i64 19 to i32
  %t40 = icmp eq i32 %t37, %t39
  %t42 = xor i1 %t40, true
  store i1 %t42, ptr %l26, !tbaa !21
  br label %bb6
bb6:
  %t44 = load i1, ptr %l26, !tbaa !21
  br i1 %t44, label %bb7, label %bb8
bb7:
  store ptr null, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t46 = load ptr, ptr %l0, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !29
  %t51 = getelementptr %"compiler/generic:Program", ptr %t49, i32 0, i32 2
  store ptr %t51, ptr %l42, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/check:Checker", ptr %t52, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !29
  %t57 = getelementptr %"compiler/generic:Program", ptr %t55, i32 0, i32 2
  %t58 = load i32, ptr %l2, !tbaa !23
  %t61 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t57, i32 %t58)
  store i32 %t61, ptr %l47
  br label %bb10
bb10:
  %t62 = load ptr, ptr %l42, !tbaa !29
  %t63 = load i32, ptr %l47, !tbaa !23
  %t64 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t62, i32 %t63)
  store i32 %t64, ptr %l48
  br label %bb11
bb11:
  %t65 = load i32, ptr %l48, !tbaa !23
  store i32 %t65, ptr %l3, !tbaa !23
  %t66 = load ptr, ptr %l1, !tbaa !29
  store ptr %t66, ptr %l49, !tbaa !29
  store i1 false, ptr %l50, !tbaa !21
  %t67 = load ptr, ptr %l49, !tbaa !29
  %t68 = icmp ne ptr %t67, null
  br i1 %t68, label %bb12, label %bb13
bb12:
  %t70 = load ptr, ptr %l49, !tbaa !29
  %t71 = load i64, ptr %t70, !range !{i64 0, i64 18}
  %t73 = icmp eq i64 %t71, 7
  store i1 %t73, ptr %l50, !tbaa !21
  br label %bb13
bb13:
  %t74 = load i1, ptr %l50, !tbaa !21
  br i1 %t74, label %bb14, label %bb15
bb14:
  %t75 = load ptr, ptr %l1, !tbaa !29
  %t77 = getelementptr { i64, [5 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t77, i32 0, i32 0
  %t79 = load %"compiler/source:Span", ptr %t78
  store %"compiler/source:Span" %t79, ptr %l4
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr { i64, [5 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t83, i32 0, i32 1
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l5, !tbaa !23
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 2
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l6, !tbaa !29
  br label %bb16
bb15:
  br label %bb79
bb16:
  %t93 = load ptr, ptr %l6, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Make", ptr %t93, i32 0, i32 0
  %t96 = load i32, ptr %t95, !range !{i32 0, i32 5}
  %t98 = trunc i64 2 to i32
  %t99 = icmp eq i32 %t96, %t98
  %t101 = xor i1 %t99, true
  br i1 %t101, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb21
bb18:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t103, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  store ptr %t108, ptr %l66, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/check:Checker", ptr %t109, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !29
  %t114 = getelementptr %"compiler/generic:Program", ptr %t112, i32 0, i32 2
  %t115 = load i32, ptr %l5, !tbaa !23
  %t118 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %t114, i32 %t115)
  store i32 %t118, ptr %l71
  br label %bb19
bb19:
  %t119 = load i32, ptr %l3, !tbaa !23
  %t120 = load ptr, ptr %l66, !tbaa !29
  %t121 = load i32, ptr %l71, !tbaa !23
  %t123 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t120, i32 %t121, i32 %t119)
  store i1 %t123, ptr %l73
  br label %bb20
bb20:
  %t124 = load i1, ptr %l73, !tbaa !21
  %t125 = xor i1 %t124, true
  store i1 %t125, ptr %l63, !tbaa !21
  br label %bb21
bb21:
  %t127 = load i1, ptr %l63, !tbaa !21
  br i1 %t127, label %bb22, label %bb23
bb22:
  store ptr null, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t130 = load i32, ptr %l3, !tbaa !23
  %t133 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %t129, i32 %t130)
  store i1 %t133, ptr %l78
  br label %bb25
bb25:
  %t134 = load i1, ptr %l78, !tbaa !21
  br i1 %t134, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l79, !tbaa !21
  br label %bb28
bb27:
  %t135 = load i32, ptr %l3, !tbaa !23
  %t136 = load i32, ptr @G_2ecompiler_2ftypes_2eBoolT, !tbaa !23
  %t139 = icmp eq i32 %t135, %t136
  store i1 %t139, ptr %l79, !tbaa !21
  br label %bb28
bb28:
  %t141 = load i1, ptr %l79, !tbaa !21
  br i1 %t141, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb33
bb30:
  %t142 = load i32, ptr %l3, !tbaa !23
  store i32 %t142, ptr %l84, !tbaa !23
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/check:Checker", ptr %t143, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !29
  %t148 = getelementptr %"compiler/generic:Program", ptr %t146, i32 0, i32 2
  store ptr %t148, ptr %l87, !tbaa !29
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %t149)
  store i32 %t151, ptr %l89
  br label %bb31
bb31:
  %t152 = load i64, ptr @G_2ecompiler_2ftypes_2eReadOnly, !tbaa !24
  %t153 = load ptr, ptr %l87, !tbaa !29
  %t154 = load i32, ptr %l89, !tbaa !23
  %t156 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t153, i32 %t154, i64 %t152)
  store i32 %t156, ptr %l91
  br label %bb32
bb32:
  %t157 = load i32, ptr %l84, !tbaa !23
  %t158 = load i32, ptr %l91, !tbaa !23
  %t159 = icmp eq i32 %t157, %t158
  store i1 %t159, ptr %l83, !tbaa !21
  br label %bb33
bb33:
  %t161 = load i1, ptr %l83, !tbaa !21
  %t162 = xor i1 %t161, true
  br i1 %t162, label %bb34, label %bb35
bb34:
  store ptr null, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t165 = load ptr, ptr %l6, !tbaa !29
  %t167 = getelementptr %"compiler/typed:Make", ptr %t165, i32 0, i32 2
  %t168 = load { i64, ptr }, ptr %t167, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t168, 0
  store i64 %t170, ptr %l97, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = insertvalue { i64 } undef, i64 0, 0
  %t174 = getelementptr { i64, [2 x i64] }, ptr %t171, i32 0, i32 1
  store { i64 } %t173, ptr %t174
  %t175 = load { i64, [2 x i64] }, ptr %t171
  %t177 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t175, ptr %t177
  store ptr %t177, ptr %l99, !tbaa !29
  %t178 = load i64, ptr %l97, !tbaa !24
  %t179 = icmp sge i64 %t178, 0
  br i1 %t179, label %bb37, label %bb38
bb37:
  %t181 = load i64, ptr %l97, !tbaa !24
  %t182 = icmp sle i64 %t181, 1152921504606846975
  br i1 %t182, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb39:
  %t184 = load i64, ptr %l97, !tbaa !24
  %t185 = mul i64 %t184, 8
  %t186 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t185)
  %t187 = load ptr, ptr %l99, !tbaa !29
  store i64 0, ptr %t188
  br label %fill.189
fill.189:
  %t192 = load i64, ptr %t188
  %t193 = icmp slt i64 %t192, %t184
  br i1 %t193, label %fillb.190, label %filld.191
fillb.190:
  %t194 = getelementptr ptr, ptr %t186, i64 %t192
  store ptr %t187, ptr %t194
  %t195 = add i64 %t192, 1
  store i64 %t195, ptr %t188
  br label %fill.189
filld.191:
  %t196 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t186, 1
  %t198 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t198, ptr %lp7
  %t200 = load ptr, ptr %lp7
  store { i64, ptr } %t197, ptr %t200, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t201 = load ptr, ptr %l6, !tbaa !29
  %t203 = getelementptr %"compiler/typed:Make", ptr %t201, i32 0, i32 2
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t204, 0
  store i64 %t206, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t208 = load i64, ptr %l9, !tbaa !24
  %t209 = load i64, ptr %l8, !tbaa !24
  %t212 = icmp sgt i64 %t208, %t209
  br i1 %t212, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_3727962a9e2e15db_7cf774666c9d4227)
  unreachable
bb41:
  %t214 = load i64, ptr %l10, !tbaa !24
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l109, !tbaa !24
  br label %bb46
bb43:
  %t218 = load i64, ptr %l9, !tbaa !24
  %t219 = load i64, ptr %l8, !tbaa !24
  %t222 = sub i64 %t218, %t219
  %t223 = load i64, ptr %l10, !tbaa !24
  %t226 = add i64 %t222, %t223
  %t228 = sub i64 %t226, 1
  %t229 = load i64, ptr %l10, !tbaa !24
  %t232 = sdiv i64 %t228, %t229
  store i64 %t232, ptr %l112, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l112, !tbaa !24
  br label %bb45
bb45:
  %t234 = load i64, ptr %l112, !tbaa !24
  store i64 %t234, ptr %l109, !tbaa !24
  br label %bb46
bb46:
  %t235 = load i64, ptr %l109, !tbaa !24
  store i64 %t235, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  %t236 = load i64, ptr %l12, !tbaa !24
  %t237 = load i64, ptr %l11, !tbaa !24
  %t240 = icmp slt i64 %t236, %t237
  %t242 = xor i1 %t240, true
  br i1 %t242, label %bb48, label %bb49
bb48:
  br label %bb77
bb49:
  br label %bb50
bb50:
  %t244 = load i64, ptr %l8, !tbaa !24
  %t245 = load i64, ptr %l12, !tbaa !24
  %t246 = load i64, ptr %l10, !tbaa !24
  %t249 = mul i64 %t245, %t246
  %t252 = add i64 %t244, %t249
  store i64 %t252, ptr %l13, !tbaa !24
  %t254 = load ptr, ptr %l6, !tbaa !29
  %t256 = getelementptr %"compiler/typed:Make", ptr %t254, i32 0, i32 2
  %t257 = load { i64, ptr }, ptr %t256, !tbaa !27
  store { i64, ptr } %t257, ptr %l131, !tbaa !27
  %t258 = load i64, ptr %l13, !tbaa !24
  %t260 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t261 = load ptr, ptr %t260, !tbaa !27
  %t262 = getelementptr ptr, ptr %t261, i64 %t258
  %t263 = load ptr, ptr %t262, !tbaa !39
  store ptr %t263, ptr %l14, !tbaa !29
  %t265 = load ptr, ptr %l14, !tbaa !29
  store ptr %t265, ptr %l134, !tbaa !29
  store i1 false, ptr %l135, !tbaa !21
  %t266 = load ptr, ptr %l134, !tbaa !29
  %t267 = icmp ne ptr %t266, null
  br i1 %t267, label %bb51, label %bb52
bb51:
  %t269 = load ptr, ptr %l134, !tbaa !29
  %t270 = load i64, ptr %t269, !range !{i64 0, i64 18}
  %t272 = icmp eq i64 %t270, 0
  store i1 %t272, ptr %l135, !tbaa !21
  br label %bb52
bb52:
  %t273 = load i1, ptr %l135, !tbaa !21
  br i1 %t273, label %bb53, label %bb54
bb53:
  %t274 = load ptr, ptr %l14, !tbaa !29
  %t276 = getelementptr { i64, [5 x i64] }, ptr %t274, i32 0, i32 1
  %t277 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t276, i32 0, i32 1
  %t278 = load i32, ptr %t277
  store i32 %t278, ptr %l15, !tbaa !23
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t280 = load i32, ptr %l15, !tbaa !23
  %t281 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t284 = icmp eq i32 %t280, %t281
  br i1 %t284, label %bb56, label %bb57
bb56:
  store ptr null, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t287 = load ptr, ptr %l14, !tbaa !29
  store ptr %t287, ptr %l144, !tbaa !29
  store i1 false, ptr %l145, !tbaa !21
  %t288 = load ptr, ptr %l144, !tbaa !29
  %t289 = icmp ne ptr %t288, null
  br i1 %t289, label %bb59, label %bb60
bb59:
  %t291 = load ptr, ptr %l144, !tbaa !29
  %t292 = load i64, ptr %t291, !range !{i64 0, i64 18}
  %t294 = icmp eq i64 %t292, 0
  store i1 %t294, ptr %l145, !tbaa !21
  br label %bb60
bb60:
  %t295 = load i1, ptr %l145, !tbaa !21
  br i1 %t295, label %bb61, label %bb62
bb61:
  %t296 = load ptr, ptr %l14, !tbaa !29
  %t298 = getelementptr { i64, [5 x i64] }, ptr %t296, i32 0, i32 1
  %t299 = getelementptr { %"compiler/source:Span", i32, i64 }, ptr %t298, i32 0, i32 2
  %t300 = load i64, ptr %t299
  store i64 %t300, ptr %l16, !tbaa !24
  br label %bb63
bb62:
  br label %bb64
bb63:
  %t302 = load i64, ptr %l13, !tbaa !24
  %t303 = load i64, ptr %l16, !tbaa !24
  store { i64, [2 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [2 x i64] }, ptr %t304, i32 0, i32 0
  store i64 0, ptr %t305
  %t307 = insertvalue { i64 } undef, i64 %t303, 0
  %t308 = getelementptr { i64, [2 x i64] }, ptr %t304, i32 0, i32 1
  store { i64 } %t307, ptr %t308
  %t309 = load { i64, [2 x i64] }, ptr %t304
  %t311 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t309, ptr %t311
  %t313 = load ptr, ptr %lp7
  %t315 = getelementptr { i64, ptr }, ptr %t313, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr ptr, ptr %t316, i64 %t302
  store ptr %t311, ptr %t317, !tbaa !39
  br label %bb75
bb64:
  %t318 = load ptr, ptr %l14, !tbaa !29
  store ptr %t318, ptr %l154, !tbaa !29
  store i1 false, ptr %l155, !tbaa !21
  %t319 = load ptr, ptr %l154, !tbaa !29
  %t320 = icmp ne ptr %t319, null
  br i1 %t320, label %bb65, label %bb66
bb65:
  %t322 = load ptr, ptr %l154, !tbaa !29
  %t323 = load i64, ptr %t322, !range !{i64 0, i64 18}
  %t325 = icmp eq i64 %t323, 1
  store i1 %t325, ptr %l155, !tbaa !21
  br label %bb66
bb66:
  %t326 = load i1, ptr %l155, !tbaa !21
  br i1 %t326, label %bb67, label %bb68
bb67:
  %t327 = load ptr, ptr %l14, !tbaa !29
  %t329 = getelementptr { i64, [5 x i64] }, ptr %t327, i32 0, i32 1
  %t330 = getelementptr { %"compiler/source:Span", i32, i64, ptr }, ptr %t329, i32 0, i32 3
  %t331 = load ptr, ptr %t330
  store ptr %t331, ptr %l17, !tbaa !29
  br label %bb69
bb68:
  br label %bb70
bb69:
  %t333 = load i64, ptr %l13, !tbaa !24
  %t334 = load ptr, ptr %l17, !tbaa !29
  %t336 = load ptr, ptr %lp7
  %t338 = getelementptr { i64, ptr }, ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr ptr, ptr %t339, i64 %t333
  store ptr %t334, ptr %t340, !tbaa !39
  br label %bb75
bb70:
  br i1 true, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  store ptr null, ptr %rv
  br label %ret
bb74:
  call void @__olang_check_failed(ptr @olang_loc_81d441761e2a717d_f45e749fdf1e1e81)
  unreachable
bb75:
  br label %bb76
bb76:
  %t342 = load i64, ptr %l12, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l12, !tbaa !24
  br label %bb47
bb77:
  %t346 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t346, ptr %l165
  %t347 = load i32, ptr %l2, !tbaa !23
  store i32 %t347, ptr %l166, !tbaa !23
  %t348 = load ptr, ptr %l0, !tbaa !29
  %t350 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t348)
  store ptr %t350, ptr %l168
  br label %bb78
bb78:
  %t351 = load ptr, ptr %l168, !tbaa !29
  %t353 = getelementptr %"compiler/check:frame", ptr %t351, i32 0, i32 2
  %t354 = load i64, ptr %t353, !tbaa !24
  %t355 = load ptr, ptr %lp7
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  store { i64, [2 x i64] } zeroinitializer, ptr %t357
  %t358 = getelementptr { i64, [2 x i64] }, ptr %t357, i32 0, i32 0
  store i64 2, ptr %t358
  %t360 = insertvalue { { i64, ptr } } undef, { i64, ptr } %t356, 0
  %t361 = getelementptr { i64, [2 x i64] }, ptr %t357, i32 0, i32 1
  store { { i64, ptr } } %t360, ptr %t361
  %t362 = load { i64, [2 x i64] }, ptr %t357
  %t364 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 24, i64 8)
  store { i64, [2 x i64] } %t362, ptr %t364
  store { i64, [5 x i64] } zeroinitializer, ptr %t365
  %t366 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 0
  store i64 1, ptr %t366
  %t367 = load %"compiler/source:Span", ptr %l165
  %t368 = insertvalue { %"compiler/source:Span", i32, i64, ptr } undef, %"compiler/source:Span" %t367, 0
  %t369 = load i32, ptr %l166, !tbaa !23
  %t370 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t368, i32 %t369, 1
  %t372 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t370, i64 %t354, 2
  %t374 = insertvalue { %"compiler/source:Span", i32, i64, ptr } %t372, ptr %t364, 3
  %t375 = getelementptr { i64, [5 x i64] }, ptr %t365, i32 0, i32 1
  store { %"compiler/source:Span", i32, i64, ptr } %t374, ptr %t375
  %t376 = load { i64, [5 x i64] }, ptr %t365
  %t378 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t376, ptr %t378
  store ptr %t378, ptr %rv
  br label %ret
bb79:
  br i1 true, label %bb80, label %bb81
bb80:
  br label %bb82
bb81:
  br label %bb83
bb82:
  store ptr null, ptr %rv
  br label %ret
bb83:
  call void @__olang_check_failed(ptr @olang_loc_64cdadb0ead6eee6_ae7a9e6dd8bef26a)
  unreachable
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrReceivers(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, [2 x i64] }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l22 = alloca i64
  %l26 = alloca i64
  %l29 = alloca i64
  %l50 = alloca i64
  %l52 = alloca i1
  %l54 = alloca ptr
  %l56 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l57 = alloca i1
  %l62 = alloca ptr
  %l71 = alloca i64
  %l75 = alloca ptr
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l100 = alloca i64
  %l106 = alloca ptr
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i32
  %l138 = alloca i64
  %l148 = alloca ptr
  %l154 = alloca ptr
  %l162 = alloca { i64, [3 x i64] }
  %l163 = alloca %"compiler/diagmsg:Msg"
  %l164 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %t306 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/check:Checker", ptr %t3, i32 0, i32 14
  %t7 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t5)
  store i64 %t7, ptr %l22
  br label %bb2
bb2:
  %t8 = load i64, ptr %l22, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l2, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb3, label %bb4
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb8
bb5:
  %t19 = load i64, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l2, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l4, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l4, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l29, !tbaa !24
  br label %bb7
bb6:
  store i64 0, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t35 = load i64, ptr %l29, !tbaa !24
  store i64 %t35, ptr %l26, !tbaa !24
  br label %bb8
bb8:
  %t36 = load i64, ptr %l26, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb11:
  br label %bb12
bb12:
  %t45 = load i64, ptr %l2, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t47 = load i64, ptr %l4, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l7, !tbaa !24
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/check:Checker", ptr %t55, i32 0, i32 19
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t57, i64 %t58)
  store i64 %t61, ptr %l50
  br label %bb13
bb13:
  %t62 = load i64, ptr %l50, !tbaa !24
  %t63 = icmp ne i64 %t62, 2
  br i1 %t63, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb18
bb15:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/check:Checker", ptr %t65, i32 0, i32 77
  store ptr %t67, ptr %l54, !tbaa !29
  %t68 = load i64, ptr %l7, !tbaa !24
  %t70 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s2, i64 %t68, i64 0)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t70, ptr %l56
  br label %bb16
bb16:
  %t71 = load ptr, ptr %l54, !tbaa !29
  %t72 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l56
  %t73 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t71, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t72)
  store i1 %t73, ptr %l57
  br label %bb17
bb17:
  %t74 = load i1, ptr %l57, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l52, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l52, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb20:
  br label %bb21
bb21:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t78, i32 0, i32 14
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t80, i64 %t81)
  store ptr %t84, ptr %l62
  br label %bb22
bb22:
  %t85 = load ptr, ptr %l62, !tbaa !29
  %t87 = getelementptr %"compiler/typed:Body", ptr %t85, i32 0, i32 1
  %t88 = load { i64, [2 x i64] }, ptr %t87
  store { i64, [2 x i64] } %t88, ptr %l8
  %t90 = load { i64, [2 x i64] }, ptr %l8
  %t92 = extractvalue { i64, [2 x i64] } %t90, 0
  %t93 = icmp eq i64 %t92, 0
  br i1 %t93, label %bb23, label %bb24
bb23:
  %t95 = getelementptr { i64, [2 x i64] }, ptr %l8, i32 0, i32 1
  %t96 = getelementptr { i64 }, ptr %t95, i32 0, i32 0
  %t97 = load i64, ptr %t96
  store i64 %t97, ptr %l9, !tbaa !24
  br label %bb25
bb24:
  br label %bb69
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/check:Checker", ptr %t99, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !29
  %t103 = load i64, ptr %l9, !tbaa !24
  %t106 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %t102, i64 %t103)
  store i64 %t106, ptr %l71
  br label %bb26
bb26:
  %t107 = load i64, ptr %l71, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/check:Checker", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t112 = load i64, ptr %l10, !tbaa !24
  %t115 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t111, i64 %t112)
  store ptr %t115, ptr %l75
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l75, !tbaa !29
  store ptr %t116, ptr %l11, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load ptr, ptr %l11, !tbaa !29
  %t120 = getelementptr %"compiler/ast:Func", ptr %t118, i32 0, i32 2
  %t121 = load i32, ptr %t120, !tbaa !23
  %t124 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t117, i32 %t121)
  store { i64, ptr } %t124, ptr %l79
  br label %bb28
bb28:
  %t125 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t125, ptr %l12, !tbaa !27
  %t126 = load ptr, ptr %l11, !tbaa !29
  %t128 = getelementptr %"compiler/ast:Func", ptr %t126, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !29
  %t131 = icmp eq ptr %t129, null
  br i1 %t131, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l83, !tbaa !21
  br label %bb36
bb30:
  %t133 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t135 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t133, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t135, ptr %l85
  br label %bb31
bb31:
  %t136 = load i1, ptr %l85, !tbaa !21
  %t137 = xor i1 %t136, true
  br i1 %t137, label %bb32, label %bb33
bb32:
  %t139 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t141 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t139, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t141, ptr %l89
  br label %bb34
bb33:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb35
bb34:
  %t142 = load i1, ptr %l89, !tbaa !21
  %t143 = xor i1 %t142, true
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb35
bb35:
  %t145 = load i1, ptr %l87, !tbaa !21
  store i1 %t145, ptr %l83, !tbaa !21
  br label %bb36
bb36:
  %t146 = load i1, ptr %l83, !tbaa !21
  br i1 %t146, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb40
bb38:
  %t147 = load i64, ptr %l10, !tbaa !24
  %t150 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t147)
  store i1 %t150, ptr %l94
  br label %bb39
bb39:
  %t151 = load i1, ptr %l94, !tbaa !21
  store i1 %t151, ptr %l91, !tbaa !21
  br label %bb40
bb40:
  %t152 = load i1, ptr %l91, !tbaa !21
  br i1 %t152, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb42:
  br label %bb43
bb43:
  %t153 = load i64, ptr %l10, !tbaa !24
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %s0, ptr %l1, i64 %t153, i1 true)
  br label %bb44
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/check:Checker", ptr %t156, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !29
  %t160 = load i64, ptr %l10, !tbaa !24
  %t163 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t159, i64 %t160)
  store i64 %t163, ptr %l100
  br label %bb45
bb45:
  %t164 = load i64, ptr %l100, !tbaa !24
  store i64 %t164, ptr %l13, !tbaa !24
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t167 = getelementptr %"compiler/check:Checker", ptr %t165, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !29
  %t170 = getelementptr %"compiler/generic:Program", ptr %t168, i32 0, i32 0
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/load:Loader", ptr %t171, i32 0, i32 10
  %t174 = load i64, ptr %l13, !tbaa !24
  %t177 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t173, i64 %t174)
  store ptr %t177, ptr %l106
  br label %bb46
bb46:
  %t178 = load ptr, ptr %l106, !tbaa !29
  %t180 = getelementptr %"compiler/load:Module", ptr %t178, i32 0, i32 6
  %t181 = load ptr, ptr %t180, !tbaa !29
  store ptr %t181, ptr %l14, !tbaa !29
  %t183 = load ptr, ptr %l14, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_7cf0066f219391e3_f59e2f38f1229917)
  unreachable
bb48:
  br label %bb49
bb49:
  %t187 = load ptr, ptr %l14, !tbaa !29
  %t190 = getelementptr %"compiler/source:Source", ptr %t187, i32 0, i32 1
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  store { i64, ptr } %t191, ptr %l15, !tbaa !27
  %t193 = load ptr, ptr %l11, !tbaa !29
  %t195 = getelementptr %"compiler/ast:Func", ptr %t193, i32 0, i32 1
  %t196 = load ptr, ptr %t195, !tbaa !29
  %t198 = icmp eq ptr %t196, null
  br i1 %t198, label %bb50, label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_93e3a02800d00d4_2c47855b6b12ccf8)
  unreachable
bb51:
  br label %bb52
bb52:
  %t200 = load ptr, ptr %l11, !tbaa !29
  %t202 = getelementptr %"compiler/ast:Func", ptr %t200, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !29
  %t206 = getelementptr %"compiler/ast:Param", ptr %t203, i32 0, i32 0
  %t207 = getelementptr %"compiler/source:Span", ptr %t206, i32 0, i32 1
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  store i64 %t210, ptr %l16, !tbaa !24
  %t212 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t212, ptr %l123, !tbaa !27
  %t213 = load i64, ptr %l16, !tbaa !24
  store i64 %t213, ptr %l124, !tbaa !24
  %t214 = load ptr, ptr %l11, !tbaa !29
  %t216 = getelementptr %"compiler/ast:Func", ptr %t214, i32 0, i32 0
  %t217 = getelementptr %"compiler/source:Span", ptr %t216, i32 0, i32 1
  %t218 = load i32, ptr %t217, !tbaa !23
  %t220 = sext i32 %t218 to i64
  store i64 %t220, ptr %l127, !tbaa !24
  %t221 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t221, 0
  store i64 %t222, ptr %l128, !tbaa !24
  %t223 = load i64, ptr %l124, !tbaa !24
  %t224 = icmp sge i64 %t223, 0
  br i1 %t224, label %bb53, label %bb54
bb53:
  %t226 = load i64, ptr %l124, !tbaa !24
  %t227 = load i64, ptr %l127, !tbaa !24
  %t228 = icmp sle i64 %t226, %t227
  br i1 %t228, label %bb55, label %bb56
bb54:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb55:
  %t230 = load i64, ptr %l127, !tbaa !24
  %t231 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp sle i64 %t230, %t231
  br i1 %t232, label %bb57, label %bb58
bb56:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb57:
  %t234 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = load i64, ptr %l124, !tbaa !24
  %t237 = load i64, ptr %l127, !tbaa !24
  %t238 = getelementptr i8, ptr %t235, i64 %t236
  %t239 = sub i64 %t237, %t236
  %t240 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t238, 1
  %t242 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t245 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v0, { i64, ptr } %t241, { i64, ptr } %t242)
  %t246 = extractvalue { i32, i64 } %t245, 1
  %t247 = extractvalue { i32, i64 } %t245, 0
  store i32 %t247, ptr %l135
  %t248 = icmp ne i32 %t247, 0
  br i1 %t248, label %bb60, label %ok.249, !prof !99
ok.249:
  store i64 %t246, ptr %l134
  br label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb)
  unreachable
bb59:
  %t250 = load i64, ptr %l134, !tbaa !24
  store i64 %t250, ptr %l122, !tbaa !24
  br label %bb62
bb60:
  br label %bb61
bb61:
  store i64 -1, ptr %l122, !tbaa !24
  br label %bb62
bb62:
  %t251 = load i64, ptr %l122, !tbaa !24
  store i64 %t251, ptr %l17, !tbaa !24
  %t252 = load i64, ptr %l17, !tbaa !24
  %t254 = icmp slt i64 %t252, 0
  br i1 %t254, label %bb63, label %bb64
bb63:
  %t256 = load ptr, ptr %l11, !tbaa !29
  %t258 = getelementptr %"compiler/ast:Func", ptr %t256, i32 0, i32 0
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l138, !tbaa !24
  br label %bb65
bb64:
  %t264 = load i64, ptr %l16, !tbaa !24
  %t265 = load i64, ptr %l17, !tbaa !24
  %t268 = add i64 %t264, %t265
  store i64 %t268, ptr %l138, !tbaa !24
  br label %bb65
bb65:
  %t270 = load i64, ptr %l138, !tbaa !24
  store i64 %t270, ptr %l18, !tbaa !24
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/check:Checker", ptr %t271, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !29
  %t276 = getelementptr %"compiler/generic:Program", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  %t279 = getelementptr %"compiler/load:Loader", ptr %t277, i32 0, i32 4
  %t280 = load ptr, ptr %t279, !tbaa !29
  store ptr %t280, ptr %l148, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  %t286 = getelementptr %"compiler/generic:Program", ptr %t284, i32 0, i32 0
  %t287 = load ptr, ptr %t286, !tbaa !29
  %t289 = getelementptr %"compiler/load:Loader", ptr %t287, i32 0, i32 10
  %t290 = load i64, ptr %l13, !tbaa !24
  %t293 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t289, i64 %t290)
  store ptr %t293, ptr %l154
  br label %bb66
bb66:
  %t294 = load ptr, ptr %l154, !tbaa !29
  %t296 = getelementptr %"compiler/load:Module", ptr %t294, i32 0, i32 4
  %t297 = load i64, ptr %t296, !tbaa !24
  %t298 = load i64, ptr %l18, !tbaa !24
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t305 = add i64 %t299, %t302
  store { i64, [3 x i64] } zeroinitializer, ptr %t306
  %t307 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 0
  store i64 3, ptr %t307
  %t309 = insertvalue { i64, i64, i64 } undef, i64 %t297, 0
  %t311 = insertvalue { i64, i64, i64 } %t309, i64 %t298, 1
  %t313 = insertvalue { i64, i64, i64 } %t311, i64 %t305, 2
  %t314 = getelementptr { i64, [3 x i64] }, ptr %t306, i32 0, i32 1
  store { i64, i64, i64 } %t313, ptr %t314
  %t315 = load { i64, [3 x i64] }, ptr %t306
  store { i64, [3 x i64] } %t315, ptr %l162
  %t316 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %s4)
  store %"compiler/diagmsg:Msg" %t316, ptr %l163
  br label %bb67
bb67:
  %t317 = load ptr, ptr %l148, !tbaa !29
  %t318 = load { i64, [3 x i64] }, ptr %l162
  %t319 = load %"compiler/diagmsg:Msg", ptr %l163
  %t320 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %s4, ptr %t317, { i64, [3 x i64] } %t318, %"compiler/diagmsg:Msg" %t319)
  store i64 %t320, ptr %l164
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s4)
  br label %bb74
bb69:
  br i1 true, label %bb70, label %bb71
bb70:
  br label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_4caebcac4cec7311_26f3d9a9847d99e5)
  unreachable
bb74:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb75:
  %t321 = load i64, ptr %l6, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l6, !tbaa !24
  br label %bb9
bb76:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitWritten(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/names:Ref"
  %l6 = alloca ptr
  %l7 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l22 = alloca %"compiler/names:Ref"
  %l26 = alloca i1
  %l31 = alloca ptr
  %l33 = alloca ptr
  %l37 = alloca %"compiler/names:Ref"
  %l41 = alloca i1
  %l47 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca %"compiler/source:Span"
  %l60 = alloca ptr
  %l62 = alloca %"compiler/source:Span"
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/diagmsg:Msg"
  %l65 = alloca i64
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t2 = load ptr, ptr %l6, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l6, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 8}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l7, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l7, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [5 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t12, i32 0, i32 0
  %t14 = load %"compiler/source:Span", ptr %t13
  store %"compiler/source:Span" %t14, ptr %l3
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = getelementptr { i64, [5 x i64] }, ptr %t16, i32 0, i32 1
  %t19 = getelementptr { %"compiler/source:Span", { i64, ptr }, { i64, ptr } }, ptr %t18, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  br label %bb5
bb4:
  br label %bb31
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  store ptr %t28, ptr %l16, !tbaa !29
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t29)
  store ptr %t31, ptr %l18
  br label %bb6
bb6:
  %t32 = load ptr, ptr %l18, !tbaa !29
  %t34 = getelementptr %"compiler/check:frame", ptr %t32, i32 0, i32 2
  %t35 = load i64, ptr %t34, !tbaa !24
  %t36 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 0
  %t37 = load i32, ptr %t36, !tbaa !23
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t41 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t38, i64 %t35, i32 %t37)
  store %"compiler/names:Ref" %t41, ptr %l22
  br label %bb7
bb7:
  %t42 = load %"compiler/names:Ref", ptr %l22
  store %"compiler/names:Ref" %t42, ptr %l5
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  %t47 = icmp sgt i64 %t45, 1
  br i1 %t47, label %bb8, label %bb9
bb8:
  %t49 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t50 = load i32, ptr %t49, !range !{i32 0, i32 9}
  %t52 = trunc i64 0 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l26, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l26, !tbaa !21
  br label %bb10
bb10:
  %t55 = load i1, ptr %l26, !tbaa !21
  br i1 %t55, label %bb11, label %bb12
bb11:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/check:Checker", ptr %t56, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = getelementptr %"compiler/generic:Program", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l31, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t63)
  store ptr %t65, ptr %l33
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t66 = load ptr, ptr %l33, !tbaa !29
  %t68 = getelementptr %"compiler/check:frame", ptr %t66, i32 0, i32 2
  %t69 = load i64, ptr %t68, !tbaa !24
  %t70 = getelementptr %"compiler/source:Span", ptr %l3, i32 0, i32 1
  %t71 = load i32, ptr %t70, !tbaa !23
  %t72 = load ptr, ptr %l31, !tbaa !29
  %t75 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t72, i64 %t69, i32 %t71)
  store %"compiler/names:Ref" %t75, ptr %l37
  br label %bb14
bb14:
  %t76 = load %"compiler/names:Ref", ptr %l37
  store %"compiler/names:Ref" %t76, ptr %l5
  br label %bb15
bb15:
  %t77 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 0
  %t78 = load i32, ptr %t77, !range !{i32 0, i32 9}
  %t80 = trunc i64 4 to i32
  %t81 = icmp eq i32 %t78, %t80
  %t83 = xor i1 %t81, true
  br i1 %t83, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb18
bb17:
  %t85 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t86 = load i64, ptr %t85, !tbaa !24
  %t88 = icmp slt i64 %t86, 0
  store i1 %t88, ptr %l41, !tbaa !21
  br label %bb18
bb18:
  %t90 = load i1, ptr %l41, !tbaa !21
  br i1 %t90, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb20:
  br label %bb21
bb21:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = getelementptr %"compiler/check:Checker", ptr %t92, i32 0, i32 1
  %t95 = load ptr, ptr %t94, !tbaa !29
  %t97 = getelementptr %"compiler/generic:Program", ptr %t95, i32 0, i32 2
  store ptr %t97, ptr %l47, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/check:Checker", ptr %t98, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !29
  %t102 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 1
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = getelementptr %"compiler/names:Ref", ptr %l5, i32 0, i32 2
  %t105 = load i64, ptr %t104, !tbaa !24
  %t109 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t101, i64 %t103, i64 %t105)
  store i32 %t109, ptr %l52
  br label %bb22
bb22:
  %t110 = load ptr, ptr %l47, !tbaa !29
  %t111 = load i32, ptr %l52, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %t110, i32 %t111)
  store i32 %t112, ptr %l53
  br label %bb23
bb23:
  %t113 = load i32, ptr %l53, !range !{i32 0, i32 6}
  %t115 = trunc i64 3 to i32
  %t116 = icmp eq i32 %t113, %t115
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l58, !tbaa !29
  %t122 = load %"compiler/source:Span", ptr %l3
  store %"compiler/source:Span" %t122, ptr %l59
  %t123 = load ptr, ptr %l0, !tbaa !29
  store ptr %t123, ptr %l60, !tbaa !29
  %t126 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %a2)
  store %"compiler/source:Span" %t126, ptr %l62
  br label %bb27
bb27:
  %t127 = load ptr, ptr %l60, !tbaa !29
  %t128 = load %"compiler/source:Span", ptr %l62
  %t129 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v0, ptr %t127, %"compiler/source:Span" %t128)
  store { i64, ptr } %t129, ptr %l63
  br label %bb28
bb28:
  %t130 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t131 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %s1, { i64, ptr } %t130)
  store %"compiler/diagmsg:Msg" %t131, ptr %l64
  br label %bb29
bb29:
  %t132 = load ptr, ptr %l58, !tbaa !29
  %t133 = load %"compiler/source:Span", ptr %l59
  %t134 = load %"compiler/diagmsg:Msg", ptr %l64
  %t135 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s1, ptr %t132, %"compiler/source:Span" %t133, %"compiler/diagmsg:Msg" %t134)
  store i64 %t135, ptr %l65
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s1)
  store i1 true, ptr %rv
  br label %ret
bb31:
  br i1 true, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  br label %bb35
bb34:
  store i1 false, ptr %rv
  br label %ret
bb35:
  call void @__olang_check_failed(ptr @olang_loc_aee2bc7202aed69e_9c3c63eda25ac602)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeCaseHolds(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:typeCase" %a1, i32 %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/check:typeCase"
  %l2 = alloca i32
  %l4 = alloca %"compiler/generic:Binding"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l28 = alloca %"compiler/generic:Binding"
  %l37 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l63 = alloca { i64, ptr }
  %l68 = alloca i1
  %l70 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l83 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i32
  %l87 = alloca i64
  %l92 = alloca i32
  %l93 = alloca i32
  %l99 = alloca i1
  %l107 = alloca i1
  %l110 = alloca ptr
  %l115 = alloca i32
  %l120 = alloca i64
  %l124 = alloca i32
  %l130 = alloca i1
  %l132 = alloca i1
  %l138 = alloca i1
  %l146 = alloca i32
  %l152 = alloca i64
  %l155 = alloca i64
  %l173 = alloca { i64, ptr }
  %l183 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i32
  %l187 = alloca i64
  %l192 = alloca i32
  %l193 = alloca i32
  %l195 = alloca i1
  %l198 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l204 = alloca i64
  %l208 = alloca i64
  %l211 = alloca i64
  %l230 = alloca ptr
  %l233 = alloca i32
  %l234 = alloca { i64, ptr }
  %l237 = alloca %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa"
  %s0 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/check:typeCase" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t2 = load i64, ptr %t1, !tbaa !24
  %t3 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = call %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %s0, i64 %t2, i64 %t4)
  store %"compiler/generic:Binding" %t7, ptr %l28
  br label %bb1
bb1:
  %t8 = load %"compiler/generic:Binding", ptr %l28
  store %"compiler/generic:Binding" %t8, ptr %l4
  %t9 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 1
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t13 = load i64, ptr %t12, !tbaa !24
  %t15 = icmp sgt i64 %t13, 0
  br i1 %t15, label %bb4, label %bb5
bb3:
  %t17 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t18 = load i64, ptr %t17, !tbaa !24
  %t20 = icmp eq i64 %t18, 0
  br i1 %t20, label %bb38, label %bb39
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t22, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t26 = load i32, ptr %l2, !tbaa !23
  %t27 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t33 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %s0, ptr %t25, i32 %t26, i32 %t28, ptr %l4)
  store i64 %t33, ptr %l37
  br label %bb6
bb5:
  br label %bb28
bb6:
  store i64 0, ptr %l5, !tbaa !24
  %t34 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  %t41 = icmp sgt i64 %t37, %t38
  br i1 %t41, label %bb7, label %bb8
bb7:
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb12
bb9:
  %t47 = load i64, ptr %l6, !tbaa !24
  %t48 = load i64, ptr %l5, !tbaa !24
  %t51 = sub i64 %t47, %t48
  %t52 = load i64, ptr %l7, !tbaa !24
  %t55 = add i64 %t51, %t52
  %t57 = sub i64 %t55, 1
  %t58 = load i64, ptr %l7, !tbaa !24
  %t61 = sdiv i64 %t57, %t58
  store i64 %t61, ptr %l45, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb11
bb11:
  %t63 = load i64, ptr %l45, !tbaa !24
  store i64 %t63, ptr %l42, !tbaa !24
  br label %bb12
bb12:
  %t64 = load i64, ptr %l42, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb13
bb13:
  %t65 = load i64, ptr %l9, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  %t69 = icmp slt i64 %t65, %t66
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb14, label %bb15
bb14:
  br label %bb27
bb15:
  br label %bb16
bb16:
  %t73 = load i64, ptr %l5, !tbaa !24
  %t74 = load i64, ptr %l9, !tbaa !24
  %t75 = load i64, ptr %l7, !tbaa !24
  %t78 = mul i64 %t74, %t75
  %t81 = add i64 %t73, %t78
  store i64 %t81, ptr %l10, !tbaa !24
  %t83 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  store { i64, ptr } %t84, ptr %l63, !tbaa !27
  %t85 = load i64, ptr %l10, !tbaa !24
  %t87 = getelementptr { i64, ptr }, ptr %l63, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t85
  %t90 = load i32, ptr %t89, !tbaa !33
  %t91 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t94 = icmp eq i32 %t90, %t91
  br i1 %t94, label %bb17, label %bb18
bb17:
  %t96 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 5
  %t97 = load i1, ptr %t96, !tbaa !21
  store i1 %t97, ptr %l68, !tbaa !21
  br label %bb19
bb18:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb19
bb19:
  %t99 = load i1, ptr %l68, !tbaa !21
  br i1 %t99, label %bb20, label %bb21
bb20:
  %t100 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l70, !tbaa !27
  %t102 = load i64, ptr %l10, !tbaa !24
  %t103 = load i32, ptr %l2, !tbaa !23
  %t106 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = getelementptr i32, ptr %t107, i64 %t102
  store i32 %t103, ptr %t108, !tbaa !33
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t109 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  store { i64, ptr } %t110, ptr %l73, !tbaa !27
  %t111 = load i64, ptr %l10, !tbaa !24
  %t113 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = getelementptr i32, ptr %t114, i64 %t111
  %t116 = load i32, ptr %t115, !tbaa !33
  %t117 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t120 = icmp eq i32 %t116, %t117
  br i1 %t120, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t123 = load i64, ptr %l9, !tbaa !24
  %t125 = add i64 %t123, 1
  store i64 %t125, ptr %l9, !tbaa !24
  br label %bb13
bb27:
  br label %bb28
bb28:
  %t127 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t128 = load i64, ptr %t127, !tbaa !24
  %t130 = icmp sgt i64 %t128, 0
  br i1 %t130, label %bb29, label %bb30
bb29:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/check:Checker", ptr %t132, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !29
  store ptr %t135, ptr %l85, !tbaa !29
  %t136 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t137 = load i32, ptr %t136, !tbaa !23
  store i32 %t137, ptr %l86, !tbaa !23
  %t138 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t139 = load i64, ptr %t138, !tbaa !24
  store i64 %t139, ptr %l87, !tbaa !24
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t142 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !29
  %t145 = getelementptr %"compiler/generic:Program", ptr %t143, i32 0, i32 2
  %t146 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  %t150 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t145, { i64, ptr } %t147)
  store i32 %t150, ptr %l92
  br label %bb31
bb30:
  %t151 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t152 = load i32, ptr %t151, !tbaa !23
  store i32 %t152, ptr %l83, !tbaa !23
  br label %bb33
bb31:
  %t154 = load ptr, ptr %l85, !tbaa !29
  %t155 = load i32, ptr %l86, !tbaa !23
  %t156 = load i64, ptr %l87, !tbaa !24
  %t157 = load i32, ptr %l92, !tbaa !23
  %t158 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t154, i32 %t155, i64 %t156, i32 %t157)
  store i32 %t158, ptr %l93
  br label %bb32
bb32:
  %t159 = load i32, ptr %l93, !tbaa !23
  store i32 %t159, ptr %l83, !tbaa !23
  br label %bb33
bb33:
  %t160 = load i32, ptr %l83, !tbaa !23
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = getelementptr %"compiler/check:Checker", ptr %t161, i32 0, i32 1
  %t164 = load ptr, ptr %t163, !tbaa !29
  %t165 = load i32, ptr %l2, !tbaa !23
  %t170 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %t164, i32 %t165, i32 %t160)
  store i1 %t170, ptr %l99
  br label %bb34
bb34:
  %t171 = load i1, ptr %l99, !tbaa !21
  %t172 = xor i1 %t171, true
  br i1 %t172, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb36:
  br label %bb37
bb37:
  br label %bb81
bb38:
  %t175 = load i32, ptr %l2, !tbaa !23
  store i32 %t175, ptr %l12, !tbaa !23
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t178 = load i32, ptr %l2, !tbaa !23
  %t181 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t177, i32 %t178)
  store i1 %t181, ptr %l107
  br label %bb40
bb39:
  %t182 = load ptr, ptr %l0, !tbaa !29
  %t184 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t185 = load ptr, ptr %t184, !tbaa !29
  %t186 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t187 = load i32, ptr %t186, !tbaa !23
  %t188 = load i32, ptr %l2, !tbaa !23
  %t193 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %s0, ptr %t185, i32 %t187, i32 %t188, ptr %l4, i1 false, i1 false)
  store i32 %t193, ptr %l146
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb56, label %ok.195, !prof !99
ok.195:
  br label %bb55
bb40:
  %t196 = load i1, ptr %l107, !tbaa !21
  br i1 %t196, label %bb41, label %bb42
bb41:
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t199 = getelementptr %"compiler/check:Checker", ptr %t197, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !29
  %t202 = getelementptr %"compiler/generic:Program", ptr %t200, i32 0, i32 2
  store ptr %t202, ptr %l110, !tbaa !29
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/check:Checker", ptr %t203, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !29
  %t208 = getelementptr %"compiler/generic:Program", ptr %t206, i32 0, i32 2
  %t209 = load i32, ptr %l2, !tbaa !23
  %t212 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t208, i32 %t209)
  store i32 %t212, ptr %l115
  br label %bb43
bb42:
  br label %bb46
bb43:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/check:Checker", ptr %t213, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !29
  %t218 = getelementptr %"compiler/generic:Program", ptr %t216, i32 0, i32 2
  %t219 = load i32, ptr %l2, !tbaa !23
  %t222 = call i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %t218, i32 %t219)
  store i64 %t222, ptr %l120
  br label %bb44
bb44:
  %t223 = load i64, ptr @G_2ecompiler_2ftypes_2eWritable, !tbaa !24
  %t225 = xor i64 %t223, -1
  %t226 = load i64, ptr %l120, !tbaa !24
  %t228 = and i64 %t226, %t225
  %t229 = load ptr, ptr %l110, !tbaa !29
  %t230 = load i32, ptr %l115, !tbaa !23
  %t232 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %t229, i32 %t230, i64 %t228)
  store i32 %t232, ptr %l124
  br label %bb45
bb45:
  %t233 = load i32, ptr %l124, !tbaa !23
  store i32 %t233, ptr %l12, !tbaa !23
  br label %bb46
bb46:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = getelementptr %"compiler/check:Checker", ptr %t234, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !29
  %t239 = getelementptr %"compiler/generic:Program", ptr %t237, i32 0, i32 2
  %t240 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t241 = load i32, ptr %t240, !tbaa !23
  %t242 = load i32, ptr %l2, !tbaa !23
  %t246 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t239, i32 %t241, i32 %t242)
  store i1 %t246, ptr %l130
  br label %bb47
bb47:
  %t247 = load i1, ptr %l130, !tbaa !21
  %t248 = xor i1 %t247, true
  br i1 %t248, label %bb48, label %bb49
bb48:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t250, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 2
  %t256 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t257 = load i32, ptr %t256, !tbaa !23
  %t258 = load i32, ptr %l12, !tbaa !23
  %t262 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t255, i32 %t257, i32 %t258)
  store i1 %t262, ptr %l138
  br label %bb50
bb49:
  store i1 false, ptr %l132, !tbaa !21
  br label %bb51
bb50:
  %t263 = load i1, ptr %l138, !tbaa !21
  %t264 = xor i1 %t263, true
  store i1 %t264, ptr %l132, !tbaa !21
  br label %bb51
bb51:
  %t266 = load i1, ptr %l132, !tbaa !21
  br i1 %t266, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb53:
  br label %bb54
bb54:
  br label %bb80
bb55:
  br label %bb58
bb56:
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb58:
  store i64 0, ptr %l13, !tbaa !24
  %t269 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 3
  %t270 = load i64, ptr %t269, !tbaa !24
  store i64 %t270, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t272 = load i64, ptr %l14, !tbaa !24
  %t273 = load i64, ptr %l13, !tbaa !24
  %t276 = icmp sgt i64 %t272, %t273
  br i1 %t276, label %bb59, label %bb60
bb59:
  %t278 = load i64, ptr %l15, !tbaa !24
  %t280 = icmp sgt i64 %t278, 0
  br i1 %t280, label %bb61, label %bb62
bb60:
  store i64 0, ptr %l152, !tbaa !24
  br label %bb64
bb61:
  %t282 = load i64, ptr %l14, !tbaa !24
  %t283 = load i64, ptr %l13, !tbaa !24
  %t286 = sub i64 %t282, %t283
  %t287 = load i64, ptr %l15, !tbaa !24
  %t290 = add i64 %t286, %t287
  %t292 = sub i64 %t290, 1
  %t293 = load i64, ptr %l15, !tbaa !24
  %t296 = sdiv i64 %t292, %t293
  store i64 %t296, ptr %l155, !tbaa !24
  br label %bb63
bb62:
  store i64 0, ptr %l155, !tbaa !24
  br label %bb63
bb63:
  %t298 = load i64, ptr %l155, !tbaa !24
  store i64 %t298, ptr %l152, !tbaa !24
  br label %bb64
bb64:
  %t299 = load i64, ptr %l152, !tbaa !24
  store i64 %t299, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb65
bb65:
  %t300 = load i64, ptr %l17, !tbaa !24
  %t301 = load i64, ptr %l16, !tbaa !24
  %t304 = icmp slt i64 %t300, %t301
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb66, label %bb67
bb66:
  br label %bb73
bb67:
  br label %bb68
bb68:
  %t308 = load i64, ptr %l13, !tbaa !24
  %t309 = load i64, ptr %l17, !tbaa !24
  %t310 = load i64, ptr %l15, !tbaa !24
  %t313 = mul i64 %t309, %t310
  %t316 = add i64 %t308, %t313
  %t318 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  store { i64, ptr } %t319, ptr %l173, !tbaa !27
  %t322 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t323 = load ptr, ptr %t322, !tbaa !27
  %t324 = getelementptr i32, ptr %t323, i64 %t316
  %t325 = load i32, ptr %t324, !tbaa !33
  %t326 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t329 = icmp eq i32 %t325, %t326
  br i1 %t329, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb70:
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t332 = load i64, ptr %l17, !tbaa !24
  %t334 = add i64 %t332, 1
  store i64 %t334, ptr %l17, !tbaa !24
  br label %bb65
bb73:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr %"compiler/check:Checker", ptr %t336, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !29
  %t341 = getelementptr %"compiler/generic:Program", ptr %t339, i32 0, i32 2
  store ptr %t341, ptr %l183, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr %"compiler/check:Checker", ptr %t342, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !29
  store ptr %t345, ptr %l185, !tbaa !29
  %t346 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 2
  %t347 = load i32, ptr %t346, !tbaa !23
  store i32 %t347, ptr %l186, !tbaa !23
  %t348 = getelementptr %"compiler/check:typeCase", ptr %l1, i32 0, i32 4
  %t349 = load i64, ptr %t348, !tbaa !24
  store i64 %t349, ptr %l187, !tbaa !24
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/check:Checker", ptr %t350, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = getelementptr %"compiler/generic:Program", ptr %t353, i32 0, i32 2
  %t356 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t357 = load { i64, ptr }, ptr %t356, !tbaa !27
  %t360 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %s0, ptr %t355, { i64, ptr } %t357)
  store i32 %t360, ptr %l192
  br label %bb74
bb74:
  %t361 = load ptr, ptr %l185, !tbaa !29
  %t362 = load i32, ptr %l186, !tbaa !23
  %t363 = load i64, ptr %l187, !tbaa !24
  %t364 = load i32, ptr %l192, !tbaa !23
  %t365 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %t361, i32 %t362, i64 %t363, i32 %t364)
  store i32 %t365, ptr %l193
  br label %bb75
bb75:
  %t366 = load i32, ptr %l2, !tbaa !23
  %t367 = load ptr, ptr %l183, !tbaa !29
  %t368 = load i32, ptr %l193, !tbaa !23
  %t370 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %t367, i32 %t368, i32 %t366)
  store i1 %t370, ptr %l195
  br label %bb76
bb76:
  %t371 = load i1, ptr %l195, !tbaa !21
  %t372 = xor i1 %t371, true
  br i1 %t372, label %bb77, label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  br label %bb80
bb80:
  br label %bb81
bb81:
  %t375 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t375, ptr %l198
  br label %bb82
bb82:
  %t376 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l198
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t376, ptr %l19
  %t377 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %s0, ptr %t377, ptr %a3, ptr %l19, i1 false)
  br label %bb83
bb83:
  store i64 0, ptr %l20, !tbaa !24
  %t384 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l19)
  store i64 %t384, ptr %l204
  br label %bb84
bb84:
  %t385 = load i64, ptr %l204, !tbaa !24
  store i64 %t385, ptr %l21, !tbaa !24
  store i64 1, ptr %l22, !tbaa !24
  %t386 = load i64, ptr %l21, !tbaa !24
  %t387 = load i64, ptr %l20, !tbaa !24
  %t390 = icmp sgt i64 %t386, %t387
  br i1 %t390, label %bb85, label %bb86
bb85:
  %t392 = load i64, ptr %l22, !tbaa !24
  %t394 = icmp sgt i64 %t392, 0
  br i1 %t394, label %bb87, label %bb88
bb86:
  store i64 0, ptr %l208, !tbaa !24
  br label %bb90
bb87:
  %t396 = load i64, ptr %l21, !tbaa !24
  %t397 = load i64, ptr %l20, !tbaa !24
  %t400 = sub i64 %t396, %t397
  %t401 = load i64, ptr %l22, !tbaa !24
  %t404 = add i64 %t400, %t401
  %t406 = sub i64 %t404, 1
  %t407 = load i64, ptr %l22, !tbaa !24
  %t410 = sdiv i64 %t406, %t407
  store i64 %t410, ptr %l211, !tbaa !24
  br label %bb89
bb88:
  store i64 0, ptr %l211, !tbaa !24
  br label %bb89
bb89:
  %t412 = load i64, ptr %l211, !tbaa !24
  store i64 %t412, ptr %l208, !tbaa !24
  br label %bb90
bb90:
  %t413 = load i64, ptr %l208, !tbaa !24
  store i64 %t413, ptr %l23, !tbaa !24
  store i64 0, ptr %l24, !tbaa !24
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s21
  %t414 = load i64, ptr %l24, !tbaa !24
  %t415 = load i64, ptr %l23, !tbaa !24
  %t418 = icmp slt i64 %t414, %t415
  %t420 = xor i1 %t418, true
  br i1 %t420, label %bb92, label %bb93
bb92:
  call void @__olang_scope_close(ptr %s21)
  br label %bb99
bb93:
  br label %bb94
bb94:
  %t422 = load i64, ptr %l20, !tbaa !24
  %t423 = load i64, ptr %l24, !tbaa !24
  %t424 = load i64, ptr %l22, !tbaa !24
  %t427 = mul i64 %t423, %t424
  %t430 = add i64 %t422, %t427
  store i64 %t430, ptr %l25, !tbaa !24
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t434 = getelementptr %"compiler/check:Checker", ptr %t432, i32 0, i32 143
  store ptr %t434, ptr %l230, !tbaa !29
  %t435 = load i64, ptr %l25, !tbaa !24
  %t438 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l19, i64 %t435)
  store i32 %t438, ptr %l233
  br label %bb95
bb95:
  %t439 = getelementptr %"compiler/generic:Binding", ptr %l4, i32 0, i32 2
  %t440 = load { i64, ptr }, ptr %t439, !tbaa !27
  store { i64, ptr } %t440, ptr %l234, !tbaa !27
  %t441 = load i64, ptr %l25, !tbaa !24
  %t443 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t444 = load ptr, ptr %t443, !tbaa !27
  %t445 = getelementptr i32, ptr %t444, i64 %t441
  %t446 = load i32, ptr %t445, !tbaa !33
  %t447 = load i32, ptr %l233, !tbaa !23
  %t449 = call %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %s21, i32 %t447, i32 %t446)
  store %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t449, ptr %l237
  br label %bb96
bb96:
  %t450 = load ptr, ptr %l230, !tbaa !29
  %t451 = load %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa", ptr %l237
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v0, ptr %t450, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %t451)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s21)
  br label %bb98
bb98:
  %t452 = load i64, ptr %l24, !tbaa !24
  %t454 = add i64 %t452, 1
  store i64 %t454, ptr %l24, !tbaa !24
  br label %bb91
bb99:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2euniqueWalk(ptr %v0, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i32
  %l8 = alloca i1
  %l13 = alloca i64
  %l21 = alloca i32
  %l30 = alloca i32
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca ptr
  %l39 = alloca i32
  %l40 = alloca i1
  %l41 = alloca i1
  %l44 = alloca ptr
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l53 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t8 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %t6)
  store i1 %t8, ptr %l8
  br label %bb1
bb1:
  %t9 = load i1, ptr %l8, !tbaa !21
  %t10 = xor i1 %t9, true
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i32, ptr %l1, !tbaa !23
  %t17 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %s0, ptr %t13, i32 %t14, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d41, i32 0, i32 1) }, i64 1)
  store i64 %t17, ptr %l13
  br label %bb5
bb5:
  %t18 = load i64, ptr %l13, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  %t21 = icmp slt i64 %t19, 0
  br i1 %t21, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/check:Checker", ptr %t24, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t28 = load i64, ptr %l2, !tbaa !24
  %t29 = load i32, ptr %l1, !tbaa !23
  %t33 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %t27, i64 %t28, i32 %t29)
  store i32 %t33, ptr %l21
  br label %bb9
bb9:
  %t34 = load i32, ptr %l21, !tbaa !23
  store i32 %t34, ptr %l3, !tbaa !23
  %t35 = load i32, ptr %l3, !tbaa !23
  %t36 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t39 = icmp eq i32 %t35, %t36
  br i1 %t39, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i64 -1, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/check:Checker", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = getelementptr %"compiler/generic:Program", ptr %t45, i32 0, i32 2
  %t48 = load i32, ptr %l3, !tbaa !23
  %t51 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %t47, i32 %t48)
  store i32 %t51, ptr %l30
  br label %bb13
bb13:
  %t52 = load i32, ptr %l30, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i32, ptr %l4, !tbaa !23
  %t57 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %t53, i32 %t54)
  store i1 %t57, ptr %l33
  br label %bb14
bb14:
  %t58 = load i1, ptr %l33, !tbaa !21
  br i1 %t58, label %bb15, label %bb16
bb15:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/check:Checker", ptr %t59, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !29
  store ptr %t62, ptr %l36, !tbaa !29
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l39
  br label %bb17
bb16:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb19
bb17:
  %t68 = load ptr, ptr %l36, !tbaa !29
  %t69 = load i32, ptr %l39, !tbaa !23
  %t70 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %t68, i32 %t69)
  store i1 %t70, ptr %l40
  br label %bb18
bb18:
  %t71 = load i1, ptr %l40, !tbaa !21
  store i1 %t71, ptr %l34, !tbaa !21
  br label %bb19
bb19:
  %t72 = load i1, ptr %l34, !tbaa !21
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = getelementptr %"compiler/generic:Program", ptr %t76, i32 0, i32 2
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/check:Checker", ptr %t79, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !29
  %t84 = getelementptr %"compiler/generic:Program", ptr %t82, i32 0, i32 2
  %t85 = load i32, ptr %l3, !tbaa !23
  %t88 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %t84, i32 %t85)
  store i32 %t88, ptr %l49
  br label %bb22
bb21:
  store i1 false, ptr %l41, !tbaa !21
  br label %bb24
bb22:
  %t89 = load ptr, ptr %l44, !tbaa !29
  %t90 = load i32, ptr %l49, !tbaa !23
  %t91 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t89, i32 %t90)
  store { i64, ptr } %t91, ptr %l50
  br label %bb23
bb23:
  %t92 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  %t95 = icmp eq i64 %t93, 0
  store i1 %t95, ptr %l41, !tbaa !21
  br label %bb24
bb24:
  %t97 = load i1, ptr %l41, !tbaa !21
  br i1 %t97, label %bb25, label %bb26
bb25:
  %t98 = load i64, ptr %l2, !tbaa !24
  store i64 %t98, ptr %l53, !tbaa !24
  br label %bb27
bb26:
  store i64 -1, ptr %l53, !tbaa !24
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i64, ptr %l53, !tbaa !24
  store i64 %t100, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknownType(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca i32
  %l3 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l12 = alloca %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0"
  %l16 = alloca i1
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l33 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca %"compiler/source:Span"
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca i64
  %l50 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca %"compiler/source:Span"
  %l57 = alloca { i64, ptr }
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca %"compiler/source:Span"
  %l66 = alloca { i64, ptr }
  %l69 = alloca %"compiler/diagmsg:Msg"
  %l70 = alloca i64
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v0, ptr %t1)
  store ptr %t3, ptr %l7
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l7, !tbaa !29
  %t6 = getelementptr %"compiler/check:frame", ptr %t4, i32 0, i32 1
  %t7 = load i64, ptr %t6, !tbaa !24
  %t8 = load i32, ptr %l2, !tbaa !23
  %t10 = sext i32 %t8 to i64
  %t13 = call %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %s0, i64 %t7, i64 %t10)
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t13, ptr %l12
  br label %bb2
bb2:
  %t14 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l12
  store %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t14, ptr %l3
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 87
  %t18 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  %t21 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %t17, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t18)
  store i1 %t21, ptr %l16
  br label %bb3
bb3:
  %t22 = load i1, ptr %l16, !tbaa !21
  br i1 %t22, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/check:Checker", ptr %t23, i32 0, i32 87
  %t26 = load %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0", ptr %l3
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %t25, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %t26, i1 true)
  br label %bb7
bb7:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t30 = load i32, ptr %l2, !tbaa !23
  %t33 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %t29, i32 %t30)
  store { i64, ptr } %t33, ptr %l22
  br label %bb8
bb8:
  %t34 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v0, ptr %s0, ptr %t35, { i64, ptr } %t36, i1 false)
  store { i64, ptr } %t39, ptr %l25
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t40, ptr %l5, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb10, label %bb11
bb10:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t51 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportedTypeNamed(ptr %v0, ptr %v0, ptr %s0, ptr %t47, { i64, ptr } %t48)
  store { i64, ptr } %t51, ptr %l31
  br label %bb12
bb11:
  br label %bb16
bb12:
  %t52 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  %t54 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l33, !tbaa !24
  %t57 = load i64, ptr %l33, !tbaa !24
  %t58 = icmp eq i64 %t53, %t57
  br i1 %t58, label %bb13, label %bb14
bb13:
  %t60 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l33, !tbaa !24
  %t65 = mul i64 %t64, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  br label %bb15
bb14:
  %t66 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t67 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t71 = icmp eq i64 %t69, 0
  br i1 %t71, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s3
  %t73 = load ptr, ptr %l0, !tbaa !29
  store ptr %t73, ptr %l38, !tbaa !29
  %t74 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t74, ptr %l39
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t76 = load i32, ptr %l2, !tbaa !23
  %t79 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s3, ptr %t75, i32 %t76)
  store { i64, ptr } %t79, ptr %l42
  br label %bb19
bb18:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/generic:Program", ptr %t83, i32 0, i32 2
  %t86 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t89 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %s0, ptr %t85, { i64, ptr } %t86)
  store i32 %t89, ptr %l50
  br label %bb22
bb19:
  %t90 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t98 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownType(ptr %s3, ptr %s3, { i64, ptr } %t96)
  store %"compiler/diagmsg:Msg" %t98, ptr %l44
  br label %bb20
bb20:
  %t99 = load ptr, ptr %l38, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l39
  %t101 = load %"compiler/diagmsg:Msg", ptr %l44
  %t102 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s3, ptr %t99, %"compiler/source:Span" %t100, %"compiler/diagmsg:Msg" %t101)
  store i64 %t102, ptr %l45
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb32
bb22:
  %t103 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t104 = load i32, ptr %l50, !tbaa !23
  %t106 = icmp ne i32 %t104, %t103
  br i1 %t106, label %bb23, label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load ptr, ptr %l0, !tbaa !29
  store ptr %t108, ptr %l53, !tbaa !29
  %t109 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t109, ptr %l54
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i32, ptr %l2, !tbaa !23
  %t114 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s5, ptr %t110, i32 %t111)
  store { i64, ptr } %t114, ptr %l57
  br label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t115 = load ptr, ptr %l0, !tbaa !29
  store ptr %t115, ptr %l62, !tbaa !29
  %t116 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t116, ptr %l63
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t118 = load i32, ptr %l2, !tbaa !23
  %t121 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %s6, ptr %t117, i32 %t118)
  store { i64, ptr } %t121, ptr %l66
  br label %bb28
bb25:
  %t122 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  %t124 = extractvalue { i64, ptr } %t122, 1
  %t125 = mul i64 %t123, 1
  %t126 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t125)
  call void @llvm.memcpy.p0.p0.i64(ptr %t126, ptr %t124, i64 %t125, i1 false)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t129 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t132 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %s5, ptr %s0, ptr %s5, { i64, ptr } %t128, { i64, ptr } %t129)
  store %"compiler/diagmsg:Msg" %t132, ptr %l60
  br label %bb26
bb26:
  %t133 = load ptr, ptr %l53, !tbaa !29
  %t134 = load %"compiler/source:Span", ptr %l54
  %t135 = load %"compiler/diagmsg:Msg", ptr %l60
  %t136 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s5, ptr %t133, %"compiler/source:Span" %t134, %"compiler/diagmsg:Msg" %t135)
  store i64 %t136, ptr %l61
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb28:
  %t137 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t147 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownTypeMeant(ptr %s6, ptr %s0, ptr %s6, { i64, ptr } %t143, { i64, ptr } %t144)
  store %"compiler/diagmsg:Msg" %t147, ptr %l69
  br label %bb29
bb29:
  %t148 = load ptr, ptr %l62, !tbaa !29
  %t149 = load %"compiler/source:Span", ptr %l63
  %t150 = load %"compiler/diagmsg:Msg", ptr %l69
  %t151 = call i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %s6, ptr %t148, %"compiler/source:Span" %t149, %"compiler/diagmsg:Msg" %t150)
  store i64 %t151, ptr %l70
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s6)
  br label %bb31
bb31:
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l10 = alloca i32
  %l13 = alloca i1
  %l14 = alloca i32
  %l18 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i1
  %l29 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca i1
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l47 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca i1
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:collWalk", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = load ptr, ptr @__olang_prog_scope
  %t11 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t8, ptr %t6, i32 %a1)
  store i32 %t11, ptr %l10
  br label %bb1
bb1:
  %t12 = load i32, ptr %l10, !tbaa !23
  store i32 %t12, ptr %l4, !tbaa !23
  %t13 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp sgt i64 %t13, 16
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t17 = load i32, ptr %l4, !tbaa !23
  store i32 %t17, ptr %l14, !tbaa !23
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/check:collWalk", ptr %t19, i32 0, i32 1
  %t22 = load i32, ptr %t21, !tbaa !23
  %t23 = load ptr, ptr @__olang_prog_scope
  %t26 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %t23, ptr %t18, i32 %t22)
  store i32 %t26, ptr %l18
  br label %bb4
bb4:
  %t27 = load i32, ptr %l14, !tbaa !23
  %t28 = load i32, ptr %l18, !tbaa !23
  %t29 = icmp eq i32 %t27, %t28
  store i1 %t29, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l13, !tbaa !21
  br i1 %t31, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load i32, ptr %l4, !tbaa !23
  %t35 = load ptr, ptr @__olang_prog_scope
  %t38 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t35, ptr %t33, i32 %t34)
  store i32 %t38, ptr %l23
  br label %bb9
bb9:
  %t39 = load i32, ptr %l23, !range !{i32 0, i32 33}
  store i32 %t39, ptr %l5
  %t40 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t42 = trunc i64 25 to i32
  %t43 = icmp eq i32 %t40, %t42
  br i1 %t43, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb43
bb13:
  %t45 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t47 = trunc i64 19 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb19
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l29, !tbaa !29
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load i32, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr @__olang_prog_scope
  %t56 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %t53, ptr %t51, i32 %t52)
  store i32 %t56, ptr %l32
  br label %bb17
bb17:
  %t57 = load i64, ptr %l2, !tbaa !24
  %t59 = add i64 %t57, 1
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t61 = load i32, ptr %l32, !tbaa !23
  %t63 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2eholds(ptr %v0, ptr %t60, i32 %t61, i64 %t59)
  store i1 %t63, ptr %l35
  br label %bb18
bb18:
  %t64 = load i1, ptr %l35, !tbaa !21
  store i1 %t64, ptr %l24, !tbaa !21
  br label %bb43
bb19:
  %t65 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t67 = trunc i64 22 to i32
  %t68 = icmp eq i32 %t65, %t67
  br i1 %t68, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  %t70 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t72 = trunc i64 23 to i32
  %t73 = icmp eq i32 %t70, %t72
  br i1 %t73, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb28
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t75 = load ptr, ptr %l0, !tbaa !29
  store ptr %t75, ptr %l40, !tbaa !29
  %t76 = load ptr, ptr %l3, !tbaa !29
  store ptr %t76, ptr %l41, !tbaa !29
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t78 = load i32, ptr %l4, !tbaa !23
  %t79 = load ptr, ptr @__olang_prog_scope
  %t82 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %t79, ptr %t77, i32 %t78)
  store i32 %t82, ptr %l44
  br label %bb25
bb25:
  %t83 = load ptr, ptr @__olang_prog_scope
  %t84 = load ptr, ptr %l41, !tbaa !29
  %t85 = load i32, ptr %l44, !tbaa !23
  %t86 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %t83, ptr %s4, ptr %t84, i32 %t85)
  store { i64, ptr } %t86, ptr %l45
  br label %bb26
bb26:
  %t87 = load i64, ptr %l2, !tbaa !24
  %t88 = load ptr, ptr %l40, !tbaa !29
  %t89 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t91 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esomeHolds(ptr %v0, ptr %s4, ptr %t88, { i64, ptr } %t89, i64 %t87)
  store i1 %t91, ptr %l47
  br label %bb27
bb27:
  %t92 = load i1, ptr %l47, !tbaa !21
  store i1 %t92, ptr %l24, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  br label %bb43
bb28:
  %t93 = load i32, ptr %l5, !range !{i32 0, i32 33}
  %t95 = trunc i64 18 to i32
  %t96 = icmp eq i32 %t93, %t95
  br i1 %t96, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb38
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load ptr, ptr %l3, !tbaa !29
  %t99 = load i32, ptr %l4, !tbaa !23
  %t100 = load ptr, ptr @__olang_prog_scope
  %t103 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %t100, ptr %t98, i32 %t99)
  store i1 %t103, ptr %l52
  br label %bb32
bb32:
  %t104 = load i1, ptr %l52, !tbaa !21
  br i1 %t104, label %bb33, label %bb34
bb33:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l54, !tbaa !29
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t107 = load i32, ptr %l4, !tbaa !23
  %t108 = load ptr, ptr @__olang_prog_scope
  %t111 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %t108, ptr %s5, ptr %t106, i32 %t107)
  store { i64, ptr } %t111, ptr %l57
  br label %bb35
bb34:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb37
bb35:
  %t112 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 0
  %t114 = extractvalue { i64, ptr } %t112, 1
  %t115 = mul i64 %t113, 4
  %t116 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t119 = load i64, ptr %l2, !tbaa !24
  %t120 = load ptr, ptr %l54, !tbaa !29
  %t123 = call i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esomeHolds(ptr %v0, ptr %s5, ptr %t120, { i64, ptr } %t118, i64 %t119)
  store i1 %t123, ptr %l60
  br label %bb36
bb36:
  %t124 = load i1, ptr %l60, !tbaa !21
  store i1 %t124, ptr %l53, !tbaa !21
  br label %bb37
bb37:
  %t125 = load i1, ptr %l53, !tbaa !21
  store i1 %t125, ptr %l24, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  br label %bb43
bb38:
  br i1 true, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb42
bb41:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_d5cbe87213397023_e63da241b79e21f)
  unreachable
bb43:
  %t126 = load i1, ptr %l24, !tbaa !21
  store i1 %t126, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fcheck_2eexprPath(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l30 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/ast:Path"
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l2, !tbaa !29
  br label %bb2
bb2:
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l8, !tbaa !29
  store i1 false, ptr %l9, !tbaa !21
  %t6 = load ptr, ptr %l8, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l8, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 30}
  %t12 = icmp eq i64 %t10, 0
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t13 = load i1, ptr %l9, !tbaa !21
  br i1 %t13, label %bb5, label %bb6
bb5:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32 }, ptr %t16, i32 0, i32 1
  %t18 = load i32, ptr %t17
  store i32 %t18, ptr %l3, !tbaa !23
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t20 = load i32, ptr %l3, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l1, i32 %t20)
  br label %bb8
bb8:
  br label %bb23
bb9:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t24 = load ptr, ptr %l16, !tbaa !29
  %t25 = icmp ne ptr %t24, null
  br i1 %t25, label %bb10, label %bb11
bb10:
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = load i64, ptr %t27, !range !{i64 0, i64 30}
  %t30 = icmp eq i64 %t28, 14
  store i1 %t30, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t31 = load i1, ptr %l17, !tbaa !21
  br i1 %t31, label %bb12, label %bb13
bb12:
  %t32 = load ptr, ptr %l2, !tbaa !29
  %t34 = getelementptr { i64, [4 x i64] }, ptr %t32, i32 0, i32 1
  %t35 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t34, i32 0, i32 1
  %t36 = load ptr, ptr %t35
  store ptr %t36, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l2, !tbaa !29
  %t40 = getelementptr { i64, [4 x i64] }, ptr %t38, i32 0, i32 1
  %t41 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t40, i32 0, i32 2
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l5, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t44 = load i32, ptr %l5, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %s0, ptr %l1, i32 %t44)
  br label %bb15
bb15:
  %t47 = load ptr, ptr %l4, !tbaa !29
  store ptr %t47, ptr %l2, !tbaa !29
  br label %bb21
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_scope_close(ptr %s0)
  store ptr null, ptr %rv
  br label %ret
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4687f82547dc647_2449c09f4feab02b)
  unreachable
bb21:
  br label %bb22
bb22:
  br label %bb2
bb23:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eRevers_Hae6dce760a5809d9fde696c8bce52839(ptr %s0, ptr %l1)
  br label %bb24
bb24:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t51)
  store %"compiler/source:Span" %t53, ptr %l30
  br label %bb25
bb25:
  %t55 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t55, ptr %l32
  br label %bb26
bb26:
  %t56 = load %"compiler/source:Span", ptr %l30
  %t57 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t58 = call %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t56, { i64, ptr } %t57)
  store %"compiler/ast:Path" %t58, ptr %l33
  br label %bb27
bb27:
  %t59 = load %"compiler/ast:Path", ptr %l33
  %t60 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:Path" %t59, ptr %t60
  call void @__olang_scope_close(ptr %s0)
  store ptr %t60, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2efieldNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l8
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store { i64, ptr } %a1, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l4, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb13
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l17, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr ptr, ptr %t23, i64 %t20
  %t25 = load ptr, ptr %t24, !tbaa !39
  store ptr %t25, ptr %l7, !tbaa !29
  %t29 = icmp sgt i64 %t17, 0
  br i1 %t29, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %l2, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d42, i32 0, i32 1) })
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb9
bb9:
  store ptr %l2, ptr %l23, !tbaa !29
  %t33 = load ptr, ptr %l7, !tbaa !29
  %t35 = getelementptr %"compiler/ast:Param", ptr %t33, i32 0, i32 1
  %t36 = load i32, ptr %t35, !tbaa !23
  %t39 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v0, ptr %a0, i32 %t36)
  store { i64, ptr } %t39, ptr %l27
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l23, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l27, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t40, { i64, ptr } %t41)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t44 = add i64 %t42, 1
  store i64 %t44, ptr %l4, !tbaa !24
  br label %bb2
bb13:
  %t47 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t47, ptr %l31
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fcheck_2eisLit(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  store i1 false, ptr %l2, !tbaa !21
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 18}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l2, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l2, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb6
bb5:
  store i1 true, ptr %rv
  br label %ret
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %rv
  br label %ret
bb10:
  call void @__olang_check_failed(ptr @olang_loc_5b2b374f73dad39a_b03018bc2543a136)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2elaneTok(i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l3 = alloca i1
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %l33 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %rv = alloca i1
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t3 = trunc i64 52 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  %t6 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t8 = trunc i64 53 to i32
  %t9 = icmp eq i32 %t6, %t8
  store i1 %t9, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t11 = load i1, ptr %l3, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t14 = trunc i64 54 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l6, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l6, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb9
bb8:
  %t18 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t20 = trunc i64 56 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l9, !tbaa !21
  br label %bb9
bb9:
  %t23 = load i1, ptr %l9, !tbaa !21
  br i1 %t23, label %bb10, label %bb11
bb10:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb12
bb11:
  %t24 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t26 = trunc i64 57 to i32
  %t27 = icmp eq i32 %t24, %t26
  store i1 %t27, ptr %l12, !tbaa !21
  br label %bb12
bb12:
  %t29 = load i1, ptr %l12, !tbaa !21
  br i1 %t29, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb14:
  %t30 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t32 = trunc i64 85 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  %t35 = load i1, ptr %l15, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb18
bb17:
  %t36 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t38 = trunc i64 86 to i32
  %t39 = icmp eq i32 %t36, %t38
  store i1 %t39, ptr %l18, !tbaa !21
  br label %bb18
bb18:
  %t41 = load i1, ptr %l18, !tbaa !21
  br i1 %t41, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb21
bb20:
  %t42 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t44 = trunc i64 87 to i32
  %t45 = icmp eq i32 %t42, %t44
  store i1 %t45, ptr %l21, !tbaa !21
  br label %bb21
bb21:
  %t47 = load i1, ptr %l21, !tbaa !21
  br i1 %t47, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb24
bb23:
  %t48 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t50 = trunc i64 90 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l24, !tbaa !21
  br label %bb24
bb24:
  %t53 = load i1, ptr %l24, !tbaa !21
  br i1 %t53, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb27
bb26:
  %t54 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t56 = trunc i64 91 to i32
  %t57 = icmp eq i32 %t54, %t56
  store i1 %t57, ptr %l27, !tbaa !21
  br label %bb27
bb27:
  %t59 = load i1, ptr %l27, !tbaa !21
  br i1 %t59, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb30
bb29:
  %t60 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t62 = trunc i64 47 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l30, !tbaa !21
  br label %bb30
bb30:
  %t65 = load i1, ptr %l30, !tbaa !21
  br i1 %t65, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb33
bb32:
  %t66 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t68 = trunc i64 45 to i32
  %t69 = icmp eq i32 %t66, %t68
  store i1 %t69, ptr %l33, !tbaa !21
  br label %bb33
bb33:
  %t71 = load i1, ptr %l33, !tbaa !21
  br i1 %t71, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb36
bb35:
  %t72 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t74 = trunc i64 46 to i32
  %t75 = icmp eq i32 %t72, %t74
  store i1 %t75, ptr %l36, !tbaa !21
  br label %bb36
bb36:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb37, label %bb38
bb37:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb39
bb38:
  %t78 = load i32, ptr %l0, !range !{i32 0, i32 98}
  %t80 = trunc i64 55 to i32
  %t81 = icmp eq i32 %t78, %t80
  store i1 %t81, ptr %l39, !tbaa !21
  br label %bb39
bb39:
  %t83 = load i1, ptr %l39, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fcheck_2elastIsValue(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 1
  %t8 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr ptr, ptr %t9, i64 %t6
  %t11 = load ptr, ptr %t10, !tbaa !39
  store ptr %t11, ptr %l1, !tbaa !29
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  store i1 false, ptr %l10, !tbaa !21
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = icmp ne ptr %t14, null
  br i1 %t15, label %bb1, label %bb2
bb1:
  %t17 = load ptr, ptr %l9, !tbaa !29
  %t18 = load i64, ptr %t17, !range !{i64 0, i64 22}
  %t20 = icmp eq i64 %t18, 0
  store i1 %t20, ptr %l10, !tbaa !21
  br label %bb2
bb2:
  %t21 = load i1, ptr %l10, !tbaa !21
  br i1 %t21, label %bb3, label %bb4
bb3:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr { i64, [4 x i64] }, ptr %t22, i32 0, i32 1
  %t25 = getelementptr { %"compiler/source:Span", ptr }, ptr %t24, i32 0, i32 1
  %t26 = load ptr, ptr %t25
  store ptr %t26, ptr %l2, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t28 = load ptr, ptr %l2, !tbaa !29
  %t30 = call i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %t28)
  store i1 %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l8, !tbaa !21
  br label %bb12
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb11
bb10:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_696a437f6b67e70a_247b6a7ce30931f6)
  unreachable
bb12:
  %t34 = load i1, ptr %l8, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fcheck_2elocalIdOf(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i1
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  store i64 -1, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  store i1 false, ptr %l7, !tbaa !21
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = icmp ne ptr %t7, null
  br i1 %t8, label %bb4, label %bb5
bb4:
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = load i64, ptr %t10, !range !{i64 0, i64 8}
  %t13 = icmp eq i64 %t11, 0
  store i1 %t13, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l7, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr { i64, [4 x i64] }, ptr %t15, i32 0, i32 1
  %t18 = getelementptr { %"compiler/source:Span", i32, i32 }, ptr %t17, i32 0, i32 2
  %t19 = load i32, ptr %t18
  store i32 %t19, ptr %l1, !tbaa !23
  br label %bb8
bb7:
  br label %bb9
bb8:
  %t21 = load i32, ptr %l1, !tbaa !23
  %t23 = sext i32 %t21 to i64
  store i64 %t23, ptr %l5, !tbaa !24
  br label %bb14
bb9:
  br i1 true, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb13
bb12:
  store i64 -1, ptr %l5, !tbaa !24
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_828d46431809dd00_d1819fff0627a99c)
  unreachable
bb14:
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epatTail(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l32 = alloca { i64, ptr }
  %l43 = alloca i64
  %l46 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca %"compiler/source:Span"
  %l77 = alloca i64
  %l80 = alloca i64
  %l99 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %t97 = alloca { i64, [4 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l20
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %t3
  store ptr %t3, ptr %l3, !tbaa !29
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  store i64 %t15, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l8, !tbaa !24
  store i64 %a2, ptr %l9, !tbaa !24
  store i64 1, ptr %l10, !tbaa !24
  %t19 = load i64, ptr %l9, !tbaa !24
  %t20 = load i64, ptr %l8, !tbaa !24
  %t23 = icmp sgt i64 %t19, %t20
  br i1 %t23, label %bb11, label %bb12
bb4:
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l6, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb5, label %bb6
bb5:
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l32, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr ptr, ptr %t37, i64 %t34
  %t39 = load ptr, ptr %t38, !tbaa !39
  %t41 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v1, ptr %t41, ptr %t39)
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t45 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t45, 1
  store i64 %t47, ptr %l5, !tbaa !24
  br label %bb4
bb10:
  br label %bb25
bb11:
  %t49 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp sgt i64 %t49, 0
  br i1 %t51, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l43, !tbaa !24
  br label %bb16
bb13:
  %t53 = load i64, ptr %l9, !tbaa !24
  %t54 = load i64, ptr %l8, !tbaa !24
  %t57 = sub i64 %t53, %t54
  %t58 = load i64, ptr %l10, !tbaa !24
  %t61 = add i64 %t57, %t58
  %t63 = sub i64 %t61, 1
  %t64 = load i64, ptr %l10, !tbaa !24
  %t67 = sdiv i64 %t63, %t64
  store i64 %t67, ptr %l46, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb15
bb15:
  %t69 = load i64, ptr %l46, !tbaa !24
  store i64 %t69, ptr %l43, !tbaa !24
  br label %bb16
bb16:
  %t70 = load i64, ptr %l43, !tbaa !24
  store i64 %t70, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  br label %bb17
bb17:
  %t71 = load i64, ptr %l12, !tbaa !24
  %t72 = load i64, ptr %l11, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb18, label %bb19
bb18:
  br label %bb24
bb19:
  br label %bb20
bb20:
  %t79 = load i64, ptr %l8, !tbaa !24
  %t80 = load i64, ptr %l12, !tbaa !24
  %t81 = load i64, ptr %l10, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l13, !tbaa !24
  %t89 = load ptr, ptr %l3, !tbaa !29
  store ptr %t89, ptr %l64, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l65, !tbaa !27
  %t91 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr ptr, ptr %t92, i64 0
  %t94 = load ptr, ptr %t93, !tbaa !39
  %t96 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %t94)
  store %"compiler/source:Span" %t96, ptr %l67
  br label %bb21
bb21:
  store { i64, [4 x i64] } zeroinitializer, ptr %t97
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 0
  store i64 0, ptr %t98
  %t99 = load %"compiler/source:Span", ptr %l67
  %t100 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t99, 0
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t97, i32 0, i32 1
  store { %"compiler/source:Span" } %t100, ptr %t101
  %t102 = load { i64, [4 x i64] }, ptr %t97
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t102, ptr %t104
  %t105 = load ptr, ptr %l64, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v2, ptr %t105, ptr %t104)
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t107 = load i64, ptr %l12, !tbaa !24
  %t109 = add i64 %t107, 1
  store i64 %t109, ptr %l12, !tbaa !24
  br label %bb17
bb24:
  br label %bb25
bb25:
  store i64 1, ptr %l14, !tbaa !24
  %t111 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l15, !tbaa !24
  store i64 1, ptr %l16, !tbaa !24
  %t115 = load i64, ptr %l15, !tbaa !24
  %t116 = load i64, ptr %l14, !tbaa !24
  %t119 = icmp sgt i64 %t115, %t116
  br i1 %t119, label %bb26, label %bb27
bb26:
  %t121 = load i64, ptr %l16, !tbaa !24
  %t123 = icmp sgt i64 %t121, 0
  br i1 %t123, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l77, !tbaa !24
  br label %bb31
bb28:
  %t125 = load i64, ptr %l15, !tbaa !24
  %t126 = load i64, ptr %l14, !tbaa !24
  %t129 = sub i64 %t125, %t126
  %t130 = load i64, ptr %l16, !tbaa !24
  %t133 = add i64 %t129, %t130
  %t135 = sub i64 %t133, 1
  %t136 = load i64, ptr %l16, !tbaa !24
  %t139 = sdiv i64 %t135, %t136
  store i64 %t139, ptr %l80, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l80, !tbaa !24
  br label %bb30
bb30:
  %t141 = load i64, ptr %l80, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  br label %bb31
bb31:
  %t142 = load i64, ptr %l77, !tbaa !24
  store i64 %t142, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  br label %bb32
bb32:
  %t143 = load i64, ptr %l18, !tbaa !24
  %t144 = load i64, ptr %l17, !tbaa !24
  %t147 = icmp slt i64 %t143, %t144
  %t149 = xor i1 %t147, true
  br i1 %t149, label %bb33, label %bb34
bb33:
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t151 = load i64, ptr %l14, !tbaa !24
  %t152 = load i64, ptr %l18, !tbaa !24
  %t153 = load i64, ptr %l16, !tbaa !24
  %t156 = mul i64 %t152, %t153
  %t159 = add i64 %t151, %t156
  %t161 = load ptr, ptr %l3, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t162, ptr %l99, !tbaa !27
  %t165 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t166 = load ptr, ptr %t165, !tbaa !27
  %t167 = getelementptr ptr, ptr %t166, i64 %t159
  %t168 = load ptr, ptr %t167, !tbaa !39
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v2, ptr %v0, ptr %t161, ptr %t168)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t171 = load i64, ptr %l18, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l18, !tbaa !24
  br label %bb32
bb38:
  %t175 = load ptr, ptr %l3, !tbaa !29
  %t177 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v2, ptr %v2, ptr %t175)
  store { i64, ptr } %t177, ptr %l105
  br label %bb39
bb39:
  %t178 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i1
  %l19 = alloca i32
  %l23 = alloca ptr
  %l24 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i1
  %l40 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i32
  %l59 = alloca i64
  %l62 = alloca i64
  %l81 = alloca { i64, ptr }
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t24 = alloca i64
  %t109 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l13, !tbaa !29
  store i1 false, ptr %l14, !tbaa !21
  %t2 = load ptr, ptr %l13, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 30}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l14, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l14, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l1, !tbaa !23
  br label %bb5
bb4:
  br label %bb10
bb5:
  %t16 = load i32, ptr %l1, !tbaa !23
  store i32 %t16, ptr %l19, !tbaa !23
  %t17 = icmp sge i64 1, 0
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t19 = icmp sle i64 1, 2305843009213693951
  br i1 %t19, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb8:
  %t21 = mul i64 1, 4
  %t22 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t21)
  %t23 = load i32, ptr %l19, !tbaa !23
  store i64 0, ptr %t24
  br label %fill.25
fill.25:
  %t28 = load i64, ptr %t24
  %t29 = icmp slt i64 %t28, 1
  br i1 %t29, label %fillb.26, label %filld.27
fillb.26:
  %t30 = getelementptr i32, ptr %t22, i64 %t28
  store i32 %t23, ptr %t30
  %t31 = add i64 %t28, 1
  store i64 %t31, ptr %t24
  br label %fill.25
filld.27:
  %t32 = insertvalue { i64, ptr } undef, i64 1, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t22, 1
  store { i64, ptr } %t33, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a)
  unreachable
bb10:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t36 = load ptr, ptr %l23, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load ptr, ptr %l23, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 2
  store i1 %t42, ptr %l24, !tbaa !21
  br label %bb12
bb12:
  %t43 = load i1, ptr %l24, !tbaa !21
  br i1 %t43, label %bb13, label %bb14
bb13:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t50 = load ptr, ptr %l2, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %v1, ptr %t50)
  store { i64, ptr } %t52, ptr %l30
  br label %bb16
bb16:
  %t53 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t53, ptr %rv
  br label %ret
bb17:
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  store i1 false, ptr %l32, !tbaa !21
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = icmp ne ptr %t55, null
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = load ptr, ptr %l31, !tbaa !29
  %t59 = load i64, ptr %t58, !range !{i64 0, i64 30}
  %t61 = icmp eq i64 %t59, 14
  store i1 %t61, ptr %l32, !tbaa !21
  br label %bb19
bb19:
  %t62 = load i1, ptr %l32, !tbaa !21
  br i1 %t62, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = getelementptr { i64, [4 x i64] }, ptr %t63, i32 0, i32 1
  %t66 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t65, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  store ptr %t67, ptr %l3, !tbaa !29
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t71, i32 0, i32 2
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l4, !tbaa !23
  br label %bb22
bb21:
  br label %bb47
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call { i64, ptr } @compiler_2fcheck_2epathOf(ptr %v0, ptr %s3, ptr %t75)
  store { i64, ptr } %t77, ptr %l40
  br label %bb23
bb23:
  %t78 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t83 = icmp eq i64 %t81, 0
  br i1 %t83, label %bb24, label %bb25
bb24:
  %t85 = icmp sge i64 0, 0
  br i1 %t85, label %bb26, label %bb27
bb25:
  br label %bb30
bb26:
  %t87 = icmp sle i64 0, 2305843009213693951
  br i1 %t87, label %bb28, label %bb29
bb27:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb28:
  %t89 = mul i64 0, 4
  %t90 = insertvalue { i64, ptr } undef, i64 0, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t91, ptr %rv
  br label %ret
bb29:
  call void @__olang_check_failed(ptr @olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf)
  unreachable
bb30:
  %t93 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t93, 0
  %t97 = add i64 %t95, 1
  store i64 %t97, ptr %l49, !tbaa !24
  %t98 = load i32, ptr %l4, !tbaa !23
  store i32 %t98, ptr %l50, !tbaa !23
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = icmp sge i64 %t99, 0
  br i1 %t100, label %bb31, label %bb32
bb31:
  %t102 = load i64, ptr %l49, !tbaa !24
  %t103 = icmp sle i64 %t102, 2305843009213693951
  br i1 %t103, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb33:
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = mul i64 %t105, 4
  %t107 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t106)
  %t108 = load i32, ptr %l50, !tbaa !23
  store i64 0, ptr %t109
  br label %fill.110
fill.110:
  %t113 = load i64, ptr %t109
  %t114 = icmp slt i64 %t113, %t105
  br i1 %t114, label %fillb.111, label %filld.112
fillb.111:
  %t115 = getelementptr i32, ptr %t107, i64 %t113
  store i32 %t108, ptr %t115
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %t109
  br label %fill.110
filld.112:
  %t117 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t107, 1
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t119, ptr %lp6
  %t121 = load ptr, ptr %lp6
  store { i64, ptr } %t118, ptr %t121, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 0
  store i64 %t124, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t126 = load i64, ptr %l8, !tbaa !24
  %t127 = load i64, ptr %l7, !tbaa !24
  %t130 = icmp sgt i64 %t126, %t127
  br i1 %t130, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_5df9bd969218a728_7fa184e5bc45956c)
  unreachable
bb35:
  %t132 = load i64, ptr %l9, !tbaa !24
  %t134 = icmp sgt i64 %t132, 0
  br i1 %t134, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb40
bb37:
  %t136 = load i64, ptr %l8, !tbaa !24
  %t137 = load i64, ptr %l7, !tbaa !24
  %t140 = sub i64 %t136, %t137
  %t141 = load i64, ptr %l9, !tbaa !24
  %t144 = add i64 %t140, %t141
  %t146 = sub i64 %t144, 1
  %t147 = load i64, ptr %l9, !tbaa !24
  %t150 = sdiv i64 %t146, %t147
  store i64 %t150, ptr %l62, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb39
bb39:
  %t152 = load i64, ptr %l62, !tbaa !24
  store i64 %t152, ptr %l59, !tbaa !24
  br label %bb40
bb40:
  %t153 = load i64, ptr %l59, !tbaa !24
  store i64 %t153, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb41
bb41:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t155 = load i64, ptr %l10, !tbaa !24
  %t158 = icmp slt i64 %t154, %t155
  %t160 = xor i1 %t158, true
  br i1 %t160, label %bb42, label %bb43
bb42:
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t162 = load i64, ptr %l7, !tbaa !24
  %t163 = load i64, ptr %l11, !tbaa !24
  %t164 = load i64, ptr %l9, !tbaa !24
  %t167 = mul i64 %t163, %t164
  %t170 = add i64 %t162, %t167
  store i64 %t170, ptr %l12, !tbaa !24
  %t172 = load i64, ptr %l12, !tbaa !24
  %t173 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t173, ptr %l81, !tbaa !27
  %t174 = load i64, ptr %l12, !tbaa !24
  %t176 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i32, ptr %t177, i64 %t174
  %t179 = load i32, ptr %t178, !tbaa !33
  %t181 = load ptr, ptr %lp6
  %t183 = getelementptr { i64, ptr }, ptr %t181, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = getelementptr i32, ptr %t184, i64 %t172
  store i32 %t179, ptr %t185, !tbaa !33
  br label %bb45
bb45:
  %t186 = load i64, ptr %l11, !tbaa !24
  %t188 = add i64 %t186, 1
  store i64 %t188, ptr %l11, !tbaa !24
  br label %bb41
bb46:
  %t190 = load ptr, ptr %lp6
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  store { i64, ptr } %t191, ptr %rv
  br label %ret
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb55
bb50:
  %t193 = icmp sge i64 0, 0
  br i1 %t193, label %bb51, label %bb52
bb51:
  %t195 = icmp sle i64 0, 2305843009213693951
  br i1 %t195, label %bb53, label %bb54
bb52:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb53:
  %t197 = mul i64 0, 4
  %t198 = insertvalue { i64, ptr } undef, i64 0, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t199, ptr %rv
  br label %ret
bb54:
  call void @__olang_check_failed(ptr @olang_loc_69c4f09cb804b315_a031ca4d3ae928f9)
  unreachable
bb55:
  call void @__olang_check_failed(ptr @olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"compiler/check:reflList" @compiler_2fcheck_2ereflList_2enoList() #0 {
entry:
  %l1 = alloca %"compiler/check:reflList"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/check:reflList"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t3 = call %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %s0, i1 false, i32 %t1, i64 0, i64 -1)
  store %"compiler/check:reflList" %t3, ptr %l1
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t4 = load %"compiler/check:reflList", ptr %l1
  store %"compiler/check:reflList" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:reflList", ptr %rv
  ret %"compiler/check:reflList" %rr
}

define dso_local %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2etwos(%"compiler/check:litv" %a0) #0 {
entry:
  %l0 = alloca %"compiler/check:litv"
  %l1 = alloca %"compiler/check:signMag"
  %l3 = alloca i1
  %l9 = alloca %"compiler/check:signMag"
  %l11 = alloca %"compiler/check:signMag"
  %l15 = alloca %"compiler/check:signMag"
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"compiler/check:signMag"
  store %"compiler/check:litv" %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 5
  %t2 = load i1, ptr %t1, !tbaa !21
  br i1 %t2, label %bb1, label %bb2
bb1:
  %t4 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 6
  %t5 = load i1, ptr %t4, !tbaa !21
  %t7 = xor i1 %t5, true
  store i1 %t7, ptr %l3, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l3, !tbaa !21
  br label %bb3
bb3:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = getelementptr %"compiler/check:litv", ptr %l0, i32 0, i32 3
  %t11 = load i64, ptr %t10, !tbaa !24
  %t14 = zext i64 %t11 to i128
  %t16 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s1, i1 false, i128 %t14)
  store %"compiler/check:signMag" %t16, ptr %l9
  br label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_scope_close(ptr %s1)
  %t17 = load %"compiler/check:signMag", ptr %l9
  store %"compiler/check:signMag" %t17, ptr %rv
  br label %ret
bb7:
  %t18 = load %"compiler/check:litv", ptr %l0
  %t20 = call %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %t18)
  store %"compiler/check:signMag" %t20, ptr %l11
  br label %bb8
bb8:
  %t21 = load %"compiler/check:signMag", ptr %l11
  store %"compiler/check:signMag" %t21, ptr %l1
  %t22 = getelementptr %"compiler/check:signMag", ptr %l1, i32 0, i32 0
  %t23 = load i1, ptr %t22, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = getelementptr %"compiler/check:signMag", ptr %l1, i32 0, i32 1
  %t26 = load i128, ptr %t25
  %t28 = sub i128 0, %t26
  %t30 = call %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %s2, i1 true, i128 %t28)
  store %"compiler/check:signMag" %t30, ptr %l15
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s2)
  %t31 = load %"compiler/check:signMag", ptr %l15
  store %"compiler/check:signMag" %t31, ptr %rv
  br label %ret
bb12:
  %t32 = load %"compiler/check:signMag", ptr %l1
  store %"compiler/check:signMag" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/check:signMag", ptr %rv
  ret %"compiler/check:signMag" %rr
}

define dso_local void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca i1
  %l41 = alloca ptr
  %l42 = alloca i1
  %l47 = alloca ptr
  %l48 = alloca i1
  %l53 = alloca ptr
  %l54 = alloca i1
  %l62 = alloca ptr
  %l63 = alloca i1
  %l70 = alloca ptr
  %l71 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i1
  %l82 = alloca ptr
  %l83 = alloca i1
  %l91 = alloca ptr
  %l92 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca i1
  %l121 = alloca ptr
  %l122 = alloca i1
  %l140 = alloca ptr
  %l141 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l157 = alloca ptr
  %l158 = alloca i1
  %l170 = alloca ptr
  %l171 = alloca i1
  %l187 = alloca ptr
  %l188 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i1
  %l199 = alloca ptr
  %l200 = alloca i1
  %l205 = alloca ptr
  %l206 = alloca i1
  %l211 = alloca ptr
  %l212 = alloca i1
  %l219 = alloca ptr
  %l220 = alloca i1
  %l232 = alloca ptr
  %l233 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l23, !tbaa !29
  store i1 false, ptr %l24, !tbaa !21
  %t6 = load ptr, ptr %l23, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l23, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 30}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l24, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l24, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", ptr }, ptr %t16, i32 0, i32 1
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb28
bb7:
  %t20 = load ptr, ptr %l0, !tbaa !29
  store ptr %t20, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t21 = load ptr, ptr %l29, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l29, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 30}
  %t27 = icmp eq i64 %t25, 26
  store i1 %t27, ptr %l30, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l30, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr { i64, [4 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb28
bb11:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t36 = load ptr, ptr %l35, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l35, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 30}
  %t42 = icmp eq i64 %t40, 28
  store i1 %t42, ptr %l36, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l36, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr { i64, [4 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", ptr }, ptr %t46, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb28
bb15:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l41, !tbaa !29
  store i1 false, ptr %l42, !tbaa !21
  %t51 = load ptr, ptr %l41, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l41, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 30}
  %t57 = icmp eq i64 %t55, 3
  store i1 %t57, ptr %l42, !tbaa !21
  br label %bb17
bb17:
  %t58 = load i1, ptr %l42, !tbaa !21
  br i1 %t58, label %bb18, label %bb19
bb18:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr { i64, [4 x i64] }, ptr %t59, i32 0, i32 1
  %t62 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t61, i32 0, i32 2
  %t63 = load ptr, ptr %t62
  store ptr %t63, ptr %l2, !tbaa !29
  br label %bb28
bb19:
  %t65 = load ptr, ptr %l0, !tbaa !29
  store ptr %t65, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t66 = load ptr, ptr %l47, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb20, label %bb21
bb20:
  %t69 = load ptr, ptr %l47, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 30}
  %t72 = icmp eq i64 %t70, 4
  store i1 %t72, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t73 = load i1, ptr %l48, !tbaa !21
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = getelementptr { i64, [4 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l2, !tbaa !29
  br label %bb28
bb23:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l53, !tbaa !29
  store i1 false, ptr %l54, !tbaa !21
  %t81 = load ptr, ptr %l53, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb24, label %bb25
bb24:
  %t84 = load ptr, ptr %l53, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 30}
  %t87 = icmp eq i64 %t85, 14
  store i1 %t87, ptr %l54, !tbaa !21
  br label %bb25
bb25:
  %t88 = load i1, ptr %l54, !tbaa !21
  br i1 %t88, label %bb26, label %bb27
bb26:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l2, !tbaa !29
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t95, ptr %t97)
  br label %bb29
bb29:
  br label %bb157
bb30:
  %t100 = load ptr, ptr %l0, !tbaa !29
  store ptr %t100, ptr %l62, !tbaa !29
  store i1 false, ptr %l63, !tbaa !21
  %t101 = load ptr, ptr %l62, !tbaa !29
  %t102 = icmp ne ptr %t101, null
  br i1 %t102, label %bb31, label %bb32
bb31:
  %t104 = load ptr, ptr %l62, !tbaa !29
  %t105 = load i64, ptr %t104, !range !{i64 0, i64 30}
  %t107 = icmp eq i64 %t105, 27
  store i1 %t107, ptr %l63, !tbaa !21
  br label %bb32
bb32:
  %t108 = load i1, ptr %l63, !tbaa !21
  br i1 %t108, label %bb33, label %bb34
bb33:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr { i64, [4 x i64] }, ptr %t109, i32 0, i32 1
  %t112 = getelementptr { %"compiler/source:Span", ptr }, ptr %t111, i32 0, i32 1
  %t113 = load ptr, ptr %t112
  store ptr %t113, ptr %l3, !tbaa !29
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t115 = load ptr, ptr %l3, !tbaa !29
  %t116 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t115, ptr %t116)
  br label %bb36
bb36:
  br label %bb157
bb37:
  %t119 = load ptr, ptr %l0, !tbaa !29
  store ptr %t119, ptr %l70, !tbaa !29
  store i1 false, ptr %l71, !tbaa !21
  %t120 = load ptr, ptr %l70, !tbaa !29
  %t121 = icmp ne ptr %t120, null
  br i1 %t121, label %bb38, label %bb39
bb38:
  %t123 = load ptr, ptr %l70, !tbaa !29
  %t124 = load i64, ptr %t123, !range !{i64 0, i64 30}
  %t126 = icmp eq i64 %t124, 9
  store i1 %t126, ptr %l71, !tbaa !21
  br label %bb39
bb39:
  %t127 = load i1, ptr %l71, !tbaa !21
  br i1 %t127, label %bb40, label %bb41
bb40:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t128, i32 0, i32 1
  %t131 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t130, i32 0, i32 1
  %t132 = load ptr, ptr %t131
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb50
bb41:
  %t134 = load ptr, ptr %l0, !tbaa !29
  store ptr %t134, ptr %l76, !tbaa !29
  store i1 false, ptr %l77, !tbaa !21
  %t135 = load ptr, ptr %l76, !tbaa !29
  %t136 = icmp ne ptr %t135, null
  br i1 %t136, label %bb42, label %bb43
bb42:
  %t138 = load ptr, ptr %l76, !tbaa !29
  %t139 = load i64, ptr %t138, !range !{i64 0, i64 30}
  %t141 = icmp eq i64 %t139, 11
  store i1 %t141, ptr %l77, !tbaa !21
  br label %bb43
bb43:
  %t142 = load i1, ptr %l77, !tbaa !21
  br i1 %t142, label %bb44, label %bb45
bb44:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr { i64, [4 x i64] }, ptr %t143, i32 0, i32 1
  %t146 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t145, i32 0, i32 1
  %t147 = load ptr, ptr %t146
  store ptr %t147, ptr %l4, !tbaa !29
  br label %bb50
bb45:
  %t149 = load ptr, ptr %l0, !tbaa !29
  store ptr %t149, ptr %l82, !tbaa !29
  store i1 false, ptr %l83, !tbaa !21
  %t150 = load ptr, ptr %l82, !tbaa !29
  %t151 = icmp ne ptr %t150, null
  br i1 %t151, label %bb46, label %bb47
bb46:
  %t153 = load ptr, ptr %l82, !tbaa !29
  %t154 = load i64, ptr %t153, !range !{i64 0, i64 30}
  %t156 = icmp eq i64 %t154, 13
  store i1 %t156, ptr %l83, !tbaa !21
  br label %bb47
bb47:
  %t157 = load i1, ptr %l83, !tbaa !21
  br i1 %t157, label %bb48, label %bb49
bb48:
  %t158 = load ptr, ptr %l0, !tbaa !29
  %t160 = getelementptr { i64, [4 x i64] }, ptr %t158, i32 0, i32 1
  %t161 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t160, i32 0, i32 1
  %t162 = load ptr, ptr %t161
  store ptr %t162, ptr %l4, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t164 = load ptr, ptr %l4, !tbaa !29
  %t166 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t164, ptr %t166)
  br label %bb51
bb51:
  br label %bb157
bb52:
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l91, !tbaa !29
  store i1 false, ptr %l92, !tbaa !21
  %t170 = load ptr, ptr %l91, !tbaa !29
  %t171 = icmp ne ptr %t170, null
  br i1 %t171, label %bb53, label %bb54
bb53:
  %t173 = load ptr, ptr %l91, !tbaa !29
  %t174 = load i64, ptr %t173, !range !{i64 0, i64 30}
  %t176 = icmp eq i64 %t174, 5
  store i1 %t176, ptr %l92, !tbaa !21
  br label %bb54
bb54:
  %t177 = load i1, ptr %l92, !tbaa !21
  br i1 %t177, label %bb55, label %bb56
bb55:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t180 = getelementptr { i64, [4 x i64] }, ptr %t178, i32 0, i32 1
  %t181 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t180, i32 0, i32 2
  %t182 = load ptr, ptr %t181
  store ptr %t182, ptr %l5, !tbaa !29
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr { i64, [4 x i64] }, ptr %t184, i32 0, i32 1
  %t187 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t186, i32 0, i32 3
  %t188 = load ptr, ptr %t187
  store ptr %t188, ptr %l6, !tbaa !29
  br label %bb65
bb56:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t191 = load ptr, ptr %l99, !tbaa !29
  %t192 = icmp ne ptr %t191, null
  br i1 %t192, label %bb57, label %bb58
bb57:
  %t194 = load ptr, ptr %l99, !tbaa !29
  %t195 = load i64, ptr %t194, !range !{i64 0, i64 30}
  %t197 = icmp eq i64 %t195, 6
  store i1 %t197, ptr %l100, !tbaa !21
  br label %bb58
bb58:
  %t198 = load i1, ptr %l100, !tbaa !21
  br i1 %t198, label %bb59, label %bb60
bb59:
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t201 = getelementptr { i64, [4 x i64] }, ptr %t199, i32 0, i32 1
  %t202 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t201, i32 0, i32 1
  %t203 = load ptr, ptr %t202
  store ptr %t203, ptr %l5, !tbaa !29
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = getelementptr { i64, [4 x i64] }, ptr %t205, i32 0, i32 1
  %t208 = getelementptr { %"compiler/source:Span", ptr, ptr }, ptr %t207, i32 0, i32 2
  %t209 = load ptr, ptr %t208
  store ptr %t209, ptr %l6, !tbaa !29
  br label %bb65
bb60:
  %t211 = load ptr, ptr %l0, !tbaa !29
  store ptr %t211, ptr %l107, !tbaa !29
  store i1 false, ptr %l108, !tbaa !21
  %t212 = load ptr, ptr %l107, !tbaa !29
  %t213 = icmp ne ptr %t212, null
  br i1 %t213, label %bb61, label %bb62
bb61:
  %t215 = load ptr, ptr %l107, !tbaa !29
  %t216 = load i64, ptr %t215, !range !{i64 0, i64 30}
  %t218 = icmp eq i64 %t216, 10
  store i1 %t218, ptr %l108, !tbaa !21
  br label %bb62
bb62:
  %t219 = load i1, ptr %l108, !tbaa !21
  br i1 %t219, label %bb63, label %bb64
bb63:
  %t220 = load ptr, ptr %l0, !tbaa !29
  %t222 = getelementptr { i64, [4 x i64] }, ptr %t220, i32 0, i32 1
  %t223 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t222, i32 0, i32 1
  %t224 = load ptr, ptr %t223
  store ptr %t224, ptr %l5, !tbaa !29
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr { i64, [4 x i64] }, ptr %t226, i32 0, i32 1
  %t229 = getelementptr { %"compiler/source:Span", ptr, ptr, i1 }, ptr %t228, i32 0, i32 2
  %t230 = load ptr, ptr %t229
  store ptr %t230, ptr %l6, !tbaa !29
  br label %bb65
bb64:
  br label %bb68
bb65:
  %t232 = load ptr, ptr %l5, !tbaa !29
  %t234 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t232, ptr %t234)
  br label %bb66
bb66:
  %t237 = load ptr, ptr %l6, !tbaa !29
  %t239 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t237, ptr %t239)
  br label %bb67
bb67:
  br label %bb157
bb68:
  %t242 = load ptr, ptr %l0, !tbaa !29
  store ptr %t242, ptr %l121, !tbaa !29
  store i1 false, ptr %l122, !tbaa !21
  %t243 = load ptr, ptr %l121, !tbaa !29
  %t244 = icmp ne ptr %t243, null
  br i1 %t244, label %bb69, label %bb70
bb69:
  %t246 = load ptr, ptr %l121, !tbaa !29
  %t247 = load i64, ptr %t246, !range !{i64 0, i64 30}
  %t249 = icmp eq i64 %t247, 8
  store i1 %t249, ptr %l122, !tbaa !21
  br label %bb70
bb70:
  %t250 = load i1, ptr %l122, !tbaa !21
  br i1 %t250, label %bb71, label %bb72
bb71:
  %t251 = load ptr, ptr %l0, !tbaa !29
  %t253 = getelementptr { i64, [4 x i64] }, ptr %t251, i32 0, i32 1
  %t254 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254
  store ptr %t255, ptr %l7, !tbaa !29
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = getelementptr { i64, [4 x i64] }, ptr %t257, i32 0, i32 1
  %t260 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t259, i32 0, i32 2
  %t261 = load ptr, ptr %t260
  store ptr %t261, ptr %l8, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = getelementptr { i64, [4 x i64] }, ptr %t263, i32 0, i32 1
  %t266 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t265, i32 0, i32 3
  %t267 = load ptr, ptr %t266
  store ptr %t267, ptr %l9, !tbaa !29
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t269 = load ptr, ptr %l7, !tbaa !29
  %t271 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t269, ptr %t271)
  br label %bb74
bb74:
  %t274 = load ptr, ptr %l8, !tbaa !29
  %t276 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t274, ptr %t276)
  br label %bb75
bb75:
  %t279 = load ptr, ptr %l9, !tbaa !29
  %t281 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t279, ptr %t281)
  br label %bb76
bb76:
  br label %bb157
bb77:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l140, !tbaa !29
  store i1 false, ptr %l141, !tbaa !21
  %t285 = load ptr, ptr %l140, !tbaa !29
  %t286 = icmp ne ptr %t285, null
  br i1 %t286, label %bb78, label %bb79
bb78:
  %t288 = load ptr, ptr %l140, !tbaa !29
  %t289 = load i64, ptr %t288, !range !{i64 0, i64 30}
  %t291 = icmp eq i64 %t289, 7
  store i1 %t291, ptr %l141, !tbaa !21
  br label %bb79
bb79:
  %t292 = load i1, ptr %l141, !tbaa !21
  br i1 %t292, label %bb80, label %bb81
bb80:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t293, i32 0, i32 1
  %t296 = getelementptr { %"compiler/source:Span", ptr }, ptr %t295, i32 0, i32 1
  %t297 = load ptr, ptr %t296
  store ptr %t297, ptr %l10, !tbaa !29
  br label %bb82
bb81:
  br label %bb84
bb82:
  %t299 = load ptr, ptr %l10, !tbaa !29
  %t301 = getelementptr %"compiler/ast:Chain", ptr %t299, i32 0, i32 1
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t303 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t302, ptr %t303)
  br label %bb83
bb83:
  br label %bb157
bb84:
  %t306 = load ptr, ptr %l0, !tbaa !29
  store ptr %t306, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t307 = load ptr, ptr %l149, !tbaa !29
  %t308 = icmp ne ptr %t307, null
  br i1 %t308, label %bb85, label %bb86
bb85:
  %t310 = load ptr, ptr %l149, !tbaa !29
  %t311 = load i64, ptr %t310, !range !{i64 0, i64 30}
  %t313 = icmp eq i64 %t311, 12
  store i1 %t313, ptr %l150, !tbaa !21
  br label %bb86
bb86:
  %t314 = load i1, ptr %l150, !tbaa !21
  br i1 %t314, label %bb87, label %bb88
bb87:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr { i64, [4 x i64] }, ptr %t315, i32 0, i32 1
  %t318 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t317, i32 0, i32 1
  %t319 = load ptr, ptr %t318
  store ptr %t319, ptr %l11, !tbaa !29
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr { i64, [4 x i64] }, ptr %t321, i32 0, i32 1
  %t324 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t323, i32 0, i32 2
  %t325 = load { i64, ptr }, ptr %t324
  store { i64, ptr } %t325, ptr %l12, !tbaa !27
  br label %bb93
bb88:
  %t327 = load ptr, ptr %l0, !tbaa !29
  store ptr %t327, ptr %l157, !tbaa !29
  store i1 false, ptr %l158, !tbaa !21
  %t328 = load ptr, ptr %l157, !tbaa !29
  %t329 = icmp ne ptr %t328, null
  br i1 %t329, label %bb89, label %bb90
bb89:
  %t331 = load ptr, ptr %l157, !tbaa !29
  %t332 = load i64, ptr %t331, !range !{i64 0, i64 30}
  %t334 = icmp eq i64 %t332, 15
  store i1 %t334, ptr %l158, !tbaa !21
  br label %bb90
bb90:
  %t335 = load i1, ptr %l158, !tbaa !21
  br i1 %t335, label %bb91, label %bb92
bb91:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t338 = getelementptr { i64, [4 x i64] }, ptr %t336, i32 0, i32 1
  %t339 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t338, i32 0, i32 1
  %t340 = load ptr, ptr %t339
  store ptr %t340, ptr %l11, !tbaa !29
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t344 = getelementptr { i64, [4 x i64] }, ptr %t342, i32 0, i32 1
  %t345 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t344, i32 0, i32 2
  %t346 = load { i64, ptr }, ptr %t345
  store { i64, ptr } %t346, ptr %l12, !tbaa !27
  br label %bb93
bb92:
  br label %bb96
bb93:
  %t348 = load ptr, ptr %l11, !tbaa !29
  %t350 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t348, ptr %t350)
  br label %bb94
bb94:
  %t353 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t354 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t353, ptr %t354)
  br label %bb95
bb95:
  br label %bb157
bb96:
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l170, !tbaa !29
  store i1 false, ptr %l171, !tbaa !21
  %t358 = load ptr, ptr %l170, !tbaa !29
  %t359 = icmp ne ptr %t358, null
  br i1 %t359, label %bb97, label %bb98
bb97:
  %t361 = load ptr, ptr %l170, !tbaa !29
  %t362 = load i64, ptr %t361, !range !{i64 0, i64 30}
  %t364 = icmp eq i64 %t362, 16
  store i1 %t364, ptr %l171, !tbaa !21
  br label %bb98
bb98:
  %t365 = load i1, ptr %l171, !tbaa !21
  br i1 %t365, label %bb99, label %bb100
bb99:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr { i64, [4 x i64] }, ptr %t366, i32 0, i32 1
  %t369 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t368, i32 0, i32 1
  %t370 = load ptr, ptr %t369
  store ptr %t370, ptr %l13, !tbaa !29
  %t372 = load ptr, ptr %l0, !tbaa !29
  %t374 = getelementptr { i64, [4 x i64] }, ptr %t372, i32 0, i32 1
  %t375 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t374, i32 0, i32 2
  %t376 = load ptr, ptr %t375
  store ptr %t376, ptr %l14, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr { i64, [4 x i64] }, ptr %t378, i32 0, i32 1
  %t381 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t380, i32 0, i32 3
  %t382 = load ptr, ptr %t381
  store ptr %t382, ptr %l15, !tbaa !29
  br label %bb101
bb100:
  br label %bb105
bb101:
  %t384 = load ptr, ptr %l13, !tbaa !29
  %t386 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t384, ptr %t386)
  br label %bb102
bb102:
  %t389 = load ptr, ptr %l14, !tbaa !29
  %t390 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t389, ptr %t390)
  br label %bb103
bb103:
  %t393 = load ptr, ptr %l15, !tbaa !29
  %t394 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t393, ptr %t394)
  br label %bb104
bb104:
  br label %bb157
bb105:
  %t397 = load ptr, ptr %l0, !tbaa !29
  store ptr %t397, ptr %l187, !tbaa !29
  store i1 false, ptr %l188, !tbaa !21
  %t398 = load ptr, ptr %l187, !tbaa !29
  %t399 = icmp ne ptr %t398, null
  br i1 %t399, label %bb106, label %bb107
bb106:
  %t401 = load ptr, ptr %l187, !tbaa !29
  %t402 = load i64, ptr %t401, !range !{i64 0, i64 30}
  %t404 = icmp eq i64 %t402, 17
  store i1 %t404, ptr %l188, !tbaa !21
  br label %bb107
bb107:
  %t405 = load i1, ptr %l188, !tbaa !21
  br i1 %t405, label %bb108, label %bb109
bb108:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t408, i32 0, i32 2
  %t410 = load { i64, ptr }, ptr %t409
  store { i64, ptr } %t410, ptr %l16, !tbaa !27
  br label %bb126
bb109:
  %t412 = load ptr, ptr %l0, !tbaa !29
  store ptr %t412, ptr %l193, !tbaa !29
  store i1 false, ptr %l194, !tbaa !21
  %t413 = load ptr, ptr %l193, !tbaa !29
  %t414 = icmp ne ptr %t413, null
  br i1 %t414, label %bb110, label %bb111
bb110:
  %t416 = load ptr, ptr %l193, !tbaa !29
  %t417 = load i64, ptr %t416, !range !{i64 0, i64 30}
  %t419 = icmp eq i64 %t417, 18
  store i1 %t419, ptr %l194, !tbaa !21
  br label %bb111
bb111:
  %t420 = load i1, ptr %l194, !tbaa !21
  br i1 %t420, label %bb112, label %bb113
bb112:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = getelementptr { i64, [4 x i64] }, ptr %t421, i32 0, i32 1
  %t424 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t423, i32 0, i32 1
  %t425 = load { i64, ptr }, ptr %t424
  store { i64, ptr } %t425, ptr %l16, !tbaa !27
  br label %bb126
bb113:
  %t427 = load ptr, ptr %l0, !tbaa !29
  store ptr %t427, ptr %l199, !tbaa !29
  store i1 false, ptr %l200, !tbaa !21
  %t428 = load ptr, ptr %l199, !tbaa !29
  %t429 = icmp ne ptr %t428, null
  br i1 %t429, label %bb114, label %bb115
bb114:
  %t431 = load ptr, ptr %l199, !tbaa !29
  %t432 = load i64, ptr %t431, !range !{i64 0, i64 30}
  %t434 = icmp eq i64 %t432, 29
  store i1 %t434, ptr %l200, !tbaa !21
  br label %bb115
bb115:
  %t435 = load i1, ptr %l200, !tbaa !21
  br i1 %t435, label %bb116, label %bb117
bb116:
  %t436 = load ptr, ptr %l0, !tbaa !29
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t436, i32 0, i32 1
  %t439 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t438, i32 0, i32 1
  %t440 = load { i64, ptr }, ptr %t439
  store { i64, ptr } %t440, ptr %l16, !tbaa !27
  br label %bb126
bb117:
  %t442 = load ptr, ptr %l0, !tbaa !29
  store ptr %t442, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t443 = load ptr, ptr %l205, !tbaa !29
  %t444 = icmp ne ptr %t443, null
  br i1 %t444, label %bb118, label %bb119
bb118:
  %t446 = load ptr, ptr %l205, !tbaa !29
  %t447 = load i64, ptr %t446, !range !{i64 0, i64 30}
  %t449 = icmp eq i64 %t447, 20
  store i1 %t449, ptr %l206, !tbaa !21
  br label %bb119
bb119:
  %t450 = load i1, ptr %l206, !tbaa !21
  br i1 %t450, label %bb120, label %bb121
bb120:
  %t451 = load ptr, ptr %l0, !tbaa !29
  %t453 = getelementptr { i64, [4 x i64] }, ptr %t451, i32 0, i32 1
  %t454 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t453, i32 0, i32 1
  %t455 = load { i64, ptr }, ptr %t454
  store { i64, ptr } %t455, ptr %l16, !tbaa !27
  br label %bb126
bb121:
  %t457 = load ptr, ptr %l0, !tbaa !29
  store ptr %t457, ptr %l211, !tbaa !29
  store i1 false, ptr %l212, !tbaa !21
  %t458 = load ptr, ptr %l211, !tbaa !29
  %t459 = icmp ne ptr %t458, null
  br i1 %t459, label %bb122, label %bb123
bb122:
  %t461 = load ptr, ptr %l211, !tbaa !29
  %t462 = load i64, ptr %t461, !range !{i64 0, i64 30}
  %t464 = icmp eq i64 %t462, 24
  store i1 %t464, ptr %l212, !tbaa !21
  br label %bb123
bb123:
  %t465 = load i1, ptr %l212, !tbaa !21
  br i1 %t465, label %bb124, label %bb125
bb124:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t466, i32 0, i32 1
  %t469 = getelementptr { %"compiler/source:Span", { i64, ptr } }, ptr %t468, i32 0, i32 1
  %t470 = load { i64, ptr }, ptr %t469
  store { i64, ptr } %t470, ptr %l16, !tbaa !27
  br label %bb126
bb125:
  br label %bb128
bb126:
  %t472 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t473 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %t472, ptr %t473)
  br label %bb127
bb127:
  br label %bb157
bb128:
  %t476 = load ptr, ptr %l0, !tbaa !29
  store ptr %t476, ptr %l219, !tbaa !29
  store i1 false, ptr %l220, !tbaa !21
  %t477 = load ptr, ptr %l219, !tbaa !29
  %t478 = icmp ne ptr %t477, null
  br i1 %t478, label %bb129, label %bb130
bb129:
  %t480 = load ptr, ptr %l219, !tbaa !29
  %t481 = load i64, ptr %t480, !range !{i64 0, i64 30}
  %t483 = icmp eq i64 %t481, 21
  store i1 %t483, ptr %l220, !tbaa !21
  br label %bb130
bb130:
  %t484 = load i1, ptr %l220, !tbaa !21
  br i1 %t484, label %bb131, label %bb132
bb131:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr { i64, [4 x i64] }, ptr %t485, i32 0, i32 1
  %t488 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t487, i32 0, i32 1
  %t489 = load ptr, ptr %t488
  store ptr %t489, ptr %l17, !tbaa !29
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = getelementptr { i64, [4 x i64] }, ptr %t491, i32 0, i32 1
  %t494 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t493, i32 0, i32 2
  %t495 = load { i64, ptr }, ptr %t494
  store { i64, ptr } %t495, ptr %l18, !tbaa !27
  br label %bb133
bb132:
  br label %bb136
bb133:
  %t497 = load ptr, ptr %l17, !tbaa !29
  %t499 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t497, ptr %t499)
  br label %bb134
bb134:
  %t502 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t503 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %t502, ptr %t503)
  br label %bb135
bb135:
  br label %bb157
bb136:
  %t506 = load ptr, ptr %l0, !tbaa !29
  store ptr %t506, ptr %l232, !tbaa !29
  store i1 false, ptr %l233, !tbaa !21
  %t507 = load ptr, ptr %l232, !tbaa !29
  %t508 = icmp ne ptr %t507, null
  br i1 %t508, label %bb137, label %bb138
bb137:
  %t510 = load ptr, ptr %l232, !tbaa !29
  %t511 = load i64, ptr %t510, !range !{i64 0, i64 30}
  %t513 = icmp eq i64 %t511, 23
  store i1 %t513, ptr %l233, !tbaa !21
  br label %bb138
bb138:
  %t514 = load i1, ptr %l233, !tbaa !21
  br i1 %t514, label %bb139, label %bb140
bb139:
  %t515 = load ptr, ptr %l0, !tbaa !29
  %t517 = getelementptr { i64, [4 x i64] }, ptr %t515, i32 0, i32 1
  %t518 = getelementptr { %"compiler/source:Span", ptr }, ptr %t517, i32 0, i32 1
  %t519 = load ptr, ptr %t518
  store ptr %t519, ptr %l19, !tbaa !29
  br label %bb141
bb140:
  br label %bb143
bb141:
  %t521 = load ptr, ptr %l19, !tbaa !29
  %t522 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %t521, ptr %t522)
  br label %bb142
bb142:
  br label %bb157
bb143:
  %t525 = load ptr, ptr %l0, !tbaa !29
  store ptr %t525, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t526 = load ptr, ptr %l240, !tbaa !29
  %t527 = icmp ne ptr %t526, null
  br i1 %t527, label %bb144, label %bb145
bb144:
  %t529 = load ptr, ptr %l240, !tbaa !29
  %t530 = load i64, ptr %t529, !range !{i64 0, i64 30}
  %t532 = icmp eq i64 %t530, 19
  store i1 %t532, ptr %l241, !tbaa !21
  br label %bb145
bb145:
  %t533 = load i1, ptr %l241, !tbaa !21
  br i1 %t533, label %bb146, label %bb147
bb146:
  %t534 = load ptr, ptr %l0, !tbaa !29
  %t536 = getelementptr { i64, [4 x i64] }, ptr %t534, i32 0, i32 1
  %t537 = getelementptr { %"compiler/source:Span", ptr }, ptr %t536, i32 0, i32 1
  %t538 = load ptr, ptr %t537
  store ptr %t538, ptr %l20, !tbaa !29
  br label %bb148
bb147:
  br label %bb152
bb148:
  %t540 = load ptr, ptr %l20, !tbaa !29
  %t542 = getelementptr %"compiler/ast:Compr", ptr %t540, i32 0, i32 1
  %t543 = load ptr, ptr %t542, !tbaa !29
  %t545 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t543, ptr %t545)
  br label %bb149
bb149:
  %t548 = load ptr, ptr %l20, !tbaa !29
  %t550 = getelementptr %"compiler/ast:Compr", ptr %t548, i32 0, i32 4
  %t551 = load ptr, ptr %t550, !tbaa !29
  %t553 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t551, ptr %t553)
  br label %bb150
bb150:
  %t556 = load ptr, ptr %l20, !tbaa !29
  %t558 = getelementptr %"compiler/ast:Compr", ptr %t556, i32 0, i32 5
  %t559 = load ptr, ptr %t558, !tbaa !29
  %t560 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fcheck_2estoredExpr(ptr %v0, ptr %v1, ptr %t559, ptr %t560)
  br label %bb151
bb151:
  br label %bb157
bb152:
  br i1 true, label %bb153, label %bb154
bb153:
  br label %bb155
bb154:
  br label %bb156
bb155:
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_9cea8b157736196b_cebcd42f5be7b27)
  unreachable
bb157:
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fcheck_2etryExisting(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l13 = alloca i1
  %l19 = alloca i1
  %l29 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/typed:Try", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  %t8 = xor i1 %t6, true
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/typed:Try", ptr %t10, i32 0, i32 0
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = icmp eq ptr %t13, null
  br i1 %t15, label %bb3, label %bb4
bb2:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb7
bb3:
  call void @__olang_check_failed(ptr @olang_loc_fa22773c0ed7d28e_9744d977b6aff1d2)
  unreachable
bb4:
  br label %bb5
bb5:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/typed:Try", ptr %t17, i32 0, i32 0
  %t20 = load ptr, ptr %t19, !tbaa !29
  %t22 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l19
  br label %bb6
bb6:
  %t23 = load i1, ptr %l19, !tbaa !21
  store i1 %t23, ptr %l13, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l13, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/typed:Try", ptr %t26, i32 0, i32 1
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  store i64 0, ptr %l2, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb11
bb11:
  %t35 = load i64, ptr %l2, !tbaa !24
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb12, label %bb13
bb12:
  br label %bb26
bb13:
  br label %bb14
bb14:
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l29, !tbaa !27
  %t44 = load i64, ptr %l2, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr ptr, ptr %t47, i64 %t44
  %t49 = load ptr, ptr %t48, !tbaa !39
  %t53 = getelementptr %"compiler/typed:Clause", ptr %t49, i32 0, i32 4
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 0
  store i64 %t58, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l6, !tbaa !24
  %t61 = load i64, ptr %l7, !tbaa !24
  %t64 = icmp slt i64 %t60, %t61
  %t66 = xor i1 %t64, true
  br i1 %t66, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t68 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t68, ptr %l40, !tbaa !27
  %t69 = load i64, ptr %l6, !tbaa !24
  %t71 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = getelementptr ptr, ptr %t72, i64 %t69
  %t74 = load ptr, ptr %t73, !tbaa !39
  %t78 = call i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %t74)
  store i1 %t78, ptr %l44
  br label %bb19
bb19:
  %t79 = load i1, ptr %l44, !tbaa !21
  br i1 %t79, label %bb20, label %bb21
bb20:
  store i1 true, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t81 = load i64, ptr %l6, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l6, !tbaa !24
  br label %bb15
bb24:
  br label %bb25
bb25:
  %t85 = load i64, ptr %l2, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l2, !tbaa !24
  br label %bb11
bb26:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fcheck_3ab5aWalk_2ector(ptr %out, ptr %v0, i64 %a0) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l10 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l14 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l15 = alloca %"compiler/check:b5aWalk"
  br label %start
start:
  br label %bb0
bb0:
  store i64 %a0, ptr %l1, !tbaa !24
  %t3 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l2
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb2
bb2:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l3
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l12
  br label %bb3
bb3:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l4
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l13
  br label %bb4
bb4:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l13
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %l5
  %t11 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t11, ptr %l14
  br label %bb5
bb5:
  %t12 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l14
  %t13 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 0
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %t13, !tbaa !24
  %t15 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 1
  %t16 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t16, ptr %t15
  %t17 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 2
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 3
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 4
  %t22 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t22, ptr %t21
  %t23 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t12, ptr %t23
  %t25 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 6
  store i1 false, ptr %t25, !tbaa !21
  %t27 = getelementptr %"compiler/check:b5aWalk", ptr %l15, i32 0, i32 7
  store i1 false, ptr %t27, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l15, i64 296, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr) cold noreturn
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2feffects_3aEffects(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/effects:Effects"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l17 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l31 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l35 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l39 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 1016, i1 false)
  %t2 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 1
  %t4 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %t2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t6 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 2
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t7)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t11 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t11
  %t12 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 3
  %t14 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, ptr %t12)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l7
  br label %bb3
bb3:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t16 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %t16
  %t17 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 4
  %t19 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, ptr %t17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  %t21 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t21
  %t22 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 5
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  br label %bb5
bb5:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  %t26 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  %t27 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 6
  %t29 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t27)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t29, ptr %l13
  br label %bb6
bb6:
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t31 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t31
  %t32 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 7
  %t34 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t32)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t34, ptr %l15
  br label %bb7
bb7:
  %t35 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l15
  %t36 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 7
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t35, ptr %t36
  %t37 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 8
  %t39 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %v0, ptr %t37)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t39, ptr %l17
  br label %bb8
bb8:
  %t40 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l17
  %t41 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 8
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t40, ptr %t41
  %t42 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 9
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t42)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l19
  br label %bb9
bb9:
  %t45 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t46 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t45, ptr %t46
  %t47 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 10
  %t49 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t47)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t49, ptr %l21
  br label %bb10
bb10:
  %t50 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l21
  %t51 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %t51
  %t52 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 11
  %t54 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %t52)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t54, ptr %l23
  br label %bb11
bb11:
  %t55 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  %t56 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t55, ptr %t56
  %t57 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 12
  %t59 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t57)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t59, ptr %l25
  br label %bb12
bb12:
  %t60 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  %t61 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t60, ptr %t61
  %t62 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 15
  %t64 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t62)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t64, ptr %l27
  br label %bb13
bb13:
  %t65 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  %t66 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %t66
  %t67 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 16
  %t69 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t67)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l29
  br label %bb14
bb14:
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  %t71 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  %t72 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 17
  %t74 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t72)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t74, ptr %l31
  br label %bb15
bb15:
  %t75 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l31
  %t76 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 17
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t75, ptr %t76
  %t77 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 18
  %t79 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %t77)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t79, ptr %l33
  br label %bb16
bb16:
  %t80 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l33
  %t81 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 18
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t80, ptr %t81
  %t82 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 19
  %t84 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t82)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t84, ptr %l35
  br label %bb17
bb17:
  %t85 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l35
  %t86 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 19
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t85, ptr %t86
  %t87 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 20
  %t89 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %t87)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t89, ptr %l37
  br label %bb18
bb18:
  %t90 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  %t91 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 20
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t90, ptr %t91
  %t92 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 25
  %t94 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0, ptr %t92)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t94, ptr %l39
  br label %bb19
bb19:
  %t95 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l39
  %t96 = getelementptr %"compiler/effects:Effects", ptr %l1, i32 0, i32 25
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t95, ptr %t96
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 1016, i1 false)
  br label %ret
ret:
  ret void
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d1 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d2 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
define linkonce_odr void @olang_2eHelperKind_2eCopy_2ecompiler_2fgeneric_3aContext(ptr %out, ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/generic:Context"
  %l3 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memmove.p0.p0.i64(ptr %l1, ptr %a0, i64 160, i1 false)
  %t2 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  %t4 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t2)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t4, ptr %l3
  br label %bb1
bb1:
  %t5 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l3
  %t6 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 2
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t5, ptr %t6
  %t7 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  %t9 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %t7)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t9, ptr %l5
  br label %bb2
bb2:
  %t10 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  %t11 = getelementptr %"compiler/generic:Context", ptr %l1, i32 0, i32 3
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t10, ptr %t11
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l1, i64 160, i1 false)
  br label %ret
ret:
  ret void
}

declare void @__olang_bang_failed_plain(ptr) cold noreturn
@__olang_empty_array = external constant [16 x i64]
@.d3 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d5 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d6 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"=" }>, align 8
@.d7 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d8 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d9 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"Eq" }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"eq" }>, align 8
@.d11 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"hash" }>, align 8
@.d13 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d14 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"copy" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d17 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 32
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 32
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 48
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 48
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

declare i64 @__olang_fmt_i64(ptr, i64)
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c":" }>, align 8
@.d20 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/iterator" }>, align 8
@.d21 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Exhausted" }>, align 8
@.d22 = private constant <{ i64, [46 x i8] }> <{ i64 0, [46 x i8] c"a generator whose Generator has no constructor" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d23 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"std/prelude/argument" }>, align 8
@.d24 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"ArgumentError" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"'not'" }>, align 8
@.d27 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bool" }>, align 8
@.d29 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Array" }>, align 8
@.d30 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"std/prelude/place" }>, align 8
@.d31 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Place" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d33 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ? " }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"? " }>, align 8
@.d35 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c">" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"<" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d39 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Str" }>, align 8
@.d40 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"str" }>, align 8
@.d41 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Ref" }>, align 8
@.d42 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3aFacts_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 80
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 80
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, { i64, ptr } %t4)
  store { i64, ptr } %t6, ptr %l3
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t7, ptr %t8, !tbaa !27
  %t9 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2feffects_3apair_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cBool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 24
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 24
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20I64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 16
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %a0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l5, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l6, !tbaa !24
  %t24 = load i64, ptr %l6, !tbaa !24
  %t25 = mul i64 %t24, 8
  %t26 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l7, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = mul i64 %t33, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t36 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 1
  store { i64, ptr } %t35, ptr %t36, !tbaa !27
  %t37 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  %t38 = load { i64, ptr }, ptr %t37, !tbaa !27
  store { i64, ptr } %t38, ptr %l8, !tbaa !27
  %t39 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 0
  store i64 %t40, ptr %l9, !tbaa !24
  %t41 = load i64, ptr %l9, !tbaa !24
  %t42 = mul i64 %t41, 8
  %t43 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t42)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  store { i64, ptr } %t45, ptr %l10, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l9, !tbaa !24
  %t51 = mul i64 %t50, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t47, ptr %t49, i64 %t51, i1 false)
  %t52 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t53 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1, i32 0, i32 2
  store { i64, ptr } %t52, ptr %t53, !tbaa !27
  %t54 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l1
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t54, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3cI64_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define linkonce_odr { i64, ptr } @olang_2eHelperKind_2eCopy_2eArray_3cstd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l1, !tbaa !24
  %t3 = load i64, ptr %l1, !tbaa !24
  %t4 = mul i64 %t3, 32
  %t5 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t3, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  store { i64, ptr } %t7, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp slt i64 %t8, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load i64, ptr %l3, !tbaa !24
  %t13 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !27
  %t15 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t14, i64 %t12
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3ccompiler_2feffects_3alink_3e(ptr %v0, ptr %t15)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l6
  br label %bb4
bb3:
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  %t20 = load i64, ptr %l3, !tbaa !24
  %t21 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t22, i64 %t20
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t19, ptr %t23
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l3, !tbaa !24
  br label %bb1
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@olang_loc_27266ce16db26f9e_9560a2a6a3954b82 = external constant [0 x i8]
declare void @compiler_2feffects_3aEffects_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
@olang_loc_76d1a478b1ca441c_29a7b400711a77a8 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efr(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_b38f45ec26bed975_efda74b8eb60f0c1 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereferable(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunder(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esrc(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawned(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerr(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, %"compiler/diagmsg:Msg" %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ety(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParts(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eAnySpawnedResult(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aExpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eb5aStr(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
@olang_loc_fd984862ae15b7b5_96e74f0ca55af519 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eoperatorRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2eprotocolArity(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fcheck_2elowerFirst(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodOf(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enameSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePlain(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eProtocolBothSpellings(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etext(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@G_2ecompiler_2ftypes_2eBoolT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\02\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePrim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalledInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
declare { i64, [3 x i64] } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emarkAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrorType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eEntriesOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emerged(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, i32 } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrorWord(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eentryOf(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2ePush_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2egather_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunwind(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLen_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eLast_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
@olang_loc_f3fef639868d2bb5_dd9676d0e98a8921 = external constant [0 x i8]
declare { i32, %"compiler/check:narrowed" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2ePop_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0)
@olang_loc_df1f5fd28061949_6fd2bc487e6b648d = external constant [0 x i8]
@olang_loc_adf1079d57e55808_9269da6a723799fc = external constant [0 x i8]
@olang_loc_4fa1eeadbabe5a66_3dfbfb89ab758d6a = external constant [0 x i8]
@olang_loc_92a21335b7ae999a_7e07c1814bb2a646 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLen_H4b13e48b0a317e727dbe35330ad8712a(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2eLas_H41327bbfea6c01118b477d23a6e2def2(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_abe1ff4556bedc08_80ba96099639cb2c = external constant [0 x i8]
declare { i32, %"compiler/check:nullNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anullNarrow_3e_2ePop_H59a749d10c64cd066029408cbe89e7b7(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLen__H3cdfcddd9c493bd8bcefc7b766e0438b(ptr %v0, ptr %a0)
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2eLast_He310b7451e653469b2155498b3293ff7(ptr %v0, ptr %a0)
@olang_loc_7a4929889a701fe3_96d6f303ecd0d8a7 = external constant [0 x i8]
declare { i32, %"compiler/check:errNarrow" } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aerrNarrow_3e_2ePop__He4c3571ab54dd9fc34e0d36cd7afb0ff(ptr %v0, ptr %a0)
@olang_loc_b4897252f2a0467_e1365b27726b9d63 = external constant [0 x i8]
@olang_loc_b02f2e0c8b90d83e_466afc0716e3b9a2 = external constant [0 x i8]
@olang_loc_e882b6948f69dce8_e6367676615923ec = external constant [0 x i8]
@olang_loc_9e6114e2cf841093_fa90ce222875bd2f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLast_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_c349e4c9332250dd_9daf9d91ff07ef41 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_90c216d2a7707e63_13ebc04feeb9a31f = external constant [0 x i8]
@olang_loc_e7cf760e54914750_8299ab19ca729e9c = external constant [0 x i8]
@olang_loc_2de9afb4b96dcf94_71a46e56f9644858 = external constant [0 x i8]
@olang_loc_6d051d6c732886d2_d9cb433bcdc0e6 = external constant [0 x i8]
@olang_loc_fd3792a3478c708a_bd2f712e645466e6 = external constant [0 x i8]
@olang_loc_12b3dc107423b434_482fbf8ad69d32f8 = external constant [0 x i8]
@olang_loc_4090f31281295d0b_b76133cd00d27c97 = external constant [0 x i8]
@olang_loc_ee572ef2923bf685_6f413c271381cde1 = external constant [0 x i8]
@olang_loc_ff67d74e2821509e_7f8039e3a9b6d64a = external constant [0 x i8]
declare %"compiler/typed:Block" @compiler_2ftyped_3aBlock_2ector(ptr %v0, ptr %v1, i32 %a0, { i64, ptr } %a1)
declare i32 @compiler_2fcheck_2etypeOf(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ederef(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuting(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2fcheck_2eoperatorName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eprivateRole(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, i32 %a2, { i64, ptr } %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
@olang_loc_f9674bcb1008789c_bed0ff146db7b878 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eone(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_7d2067b11442aa69_727f8f68f20a38e5 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einvoke(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3, ptr %a4, { i64, ptr } %a5, { i64, ptr } %a6, { i64, ptr } %a7)
@olang_loc_fe55a007e1b3e29_3c78fea0979d4bfd = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2eLen_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %a0)
@olang_loc_c4a343fb9b24edff_3458e4f6b03fbc5b = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eread(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare %"compiler/typed:Seq" @compiler_2ftyped_3aSeq_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, i1 %a2)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Ha72624ba64524ee3315305b5d1bfb369(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.91de8c8eb84d52d1e58996aec31d85aa" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3ccompiler_2fsource_3aNameId_2c_20co_H6cf169b12565f300e9fe11f1c8d55061(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCanon(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econstCond(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2econd1(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitLike(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactsExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, i1 %a2, ptr %a3, i32 %a4)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSame(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebetween(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i64 %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCondBranchTypes(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunknown(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
@G_2ecompiler_2ftypes_2eNoreturnT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\11\00\00\00" }>, align 8
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMeet(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@G_2ecompiler_2ftypes_2eNullT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\0F\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisRef(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eOrNull(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eflowsInto(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2ePermOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2emeetPerm(i64 %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRef(ptr %v0, ptr %a0, i32 %a1, i64 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erunLength(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eElem(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eArray(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_db85c439bc9f5684_3c0400873f27ba78 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare %"compiler/typed:Cond" @compiler_2ftyped_3aCond_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_700945490095e3ab_b793fb317cfa4b47 = external constant [0 x i8]
declare %"compiler/check:ctSource" @compiler_2fcheck_3actSource_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, { i64, ptr } %a4)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeDecl(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98b1a939df7bf83c_dad16d1edd3f2a28 = external constant [0 x i8]
@olang_loc_25ec48d7738ec131_33504a893c084afd = external constant [0 x i8]
@olang_loc_1c86c4e2a1d4d52a_afb2831c22759b16 = external constant [0 x i8]
@olang_loc_34572fc3675c142e_5b9246c98f1fa642 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAnySlots(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etraitMethod(ptr %v0, ptr %v1, ptr %a0, %"compiler/generic:AnySlot" %a1)
@olang_loc_384cb541f04295b0_3f9ee0143bd9d7ac = external constant [0 x i8]
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3, { i64, ptr } %a4)
@olang_loc_a90b29f72ec4d10d_507af4b2e3250de1 = external constant [0 x i8]
@olang_loc_8dac41fcc89db5e5_6cee581458fc6b9 = external constant [0 x i8]
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etwinBody(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
@olang_loc_8d3e5410ed2a27a9_4efdc57dac874585 = external constant [0 x i8]
@olang_loc_1dfbc037cdd154d8_cf42e6f659c8aed4 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eresolve(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_ca8c7340acce938e_766edb65a28506b2 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrSubjectOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elit(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsErrVal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrComparedNotError(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrValItems(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetMeet(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eLen_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esetText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCaughtNeverIs(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrTest(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enegate(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eseqOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i64 %a3, ptr %a4)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrLocalName(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eerrItemPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_91bbe37ca794b073_cd30040e8f82c287 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eErrDeclOf(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnBuiltinType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fload_2eErrQualifier(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMethodOnForeignType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorMethodGiven(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2ePreludeType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aStmt_26_3e_2ePush_3ccompiler_2ftyped_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/typed:Item" @compiler_2ftyped_3aItem_2ector(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8e26fbb1c5557eef_13e6cc5de085742b = external constant [0 x i8]
@olang_loc_6d702b04e725ae1a_71c02c55b3dfc416 = external constant [0 x i8]
declare %"compiler/typed:Clause" @compiler_2ftyped_3aClause_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, { i64, ptr } %a4, i64 %a5, i32 %a6)
declare %"compiler/typed:Try" @compiler_2ftyped_3aTry_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2, i1 %a3, i1 %a4)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estep(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i1 %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eemit(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecalleeSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotAStatement(ptr %v0)
@olang_loc_602058b5bbdc5ba4_407e96c83aaf1680 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eNeedsDrop(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropIfHeld(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i64 %a3)
@G_2ecompiler_2ftypes_2eVoidT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecopiesDiffer(ptr %v0, ptr %a0)
declare %"compiler/check:idleCall" @compiler_2fcheck_3aidleCall_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aidleCall_3e_2ePush_3ccompiler_2fcheck_3aidleCall_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:idleCall" %a1)
@olang_loc_a929affe4386ca95_c275f1e9d349f711 = external constant [0 x i8]
@olang_loc_c2976cb1f3dad95e_90ea7f94faae157a = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enotStmtSpan(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eJoinNextLine(ptr %v0)
declare i32 @compiler_2feffects_2eFact_2eNamed(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2edeclaredFact(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactFn(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclFact(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnIsExtern(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/effects:Facts" @compiler_2feffects_2ecompiler_2feffects_3aEffects_2eOfExtern(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2feffects_2ecompiler_2feffects_3aFacts_2eHolds(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efactInst(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFactOfGeneric(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efnBody(ptr %v0, ptr %a0, i64 %a1)
declare { i32, i1 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H066d6e237a6d66bfc481a7c4eff443dd(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2feffects_2eConservative(i32 %a0)
declare %"compiler/check:factRead" @compiler_2fcheck_3afactRead_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, { i64, ptr } %a1, i1 %a2, i64 %a3, %"compiler/source:Span" %a4, { i64, ptr } %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3afactRead_3e_2ePush_3ccompiler_2fcheck_3afactRead_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/check:factRead" %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eResult(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eCtorSig(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egap(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, ptr } %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecur(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocalType(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/typed:Local" @compiler_2ftyped_2ecompiler_2ftyped_3aBody_2eLocal(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructGenParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2fgeneric_2eGenFromReturn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FE\FF\FF\FF\FF\FF\FF\FF" }>, align 8
@G_2ecompiler_2ftypes_2eReadOnly = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2ftypes_2eNullable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elocal(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2, i32 %a3, i32 %a4, { i64, [1 x i64] } %a5)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2egenLambda(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3, i64 %a4)
@olang_loc_8107208a4245ff9c_ccbe9a9f570baf38 = external constant [0 x i8]
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecallBody(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, i64 %a5, ptr %a6, { i64, ptr } %a7, { i64, ptr } %a8)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2eGet_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20I64_3e_2ePut_3cI64_2c_20I64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2eLen__H4e51b5ca7b68af485b8486164a690a5f(ptr %v0, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eleft(ptr %v0, ptr %v1, ptr %a0, i32 %a1, ptr %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eLe_H3dc16594b41531049b330439cbeee191(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aContractAsk_3e_2eAt_H56c1cddaee4bc4aa5c09605de1331e44(ptr %out, ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ePut_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1, i1 %a2)
declare ptr @compiler_2fcheck_2ereadPlace(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ab1100555885b989_2cac6a0e3d43e9fd = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edeclKind(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsBy(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eCases(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eLength(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4d3e518c37f06fac_dc2de6c574f30d28 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elistHoldsInst(ptr %v0, ptr %a0, i32 %a1, i32 %a2, i64 %a3)
@olang_loc_aed268118a11ee23_4542719cec09658f = external constant [0 x i8]
@olang_loc_a8dc05ade1085e71_1f4ef85bbb60cc55 = external constant [0 x i8]
declare %"compiler/check:laneNode" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3alaneNode_3e_2eAt_3ccompiler_2fcheck_3alaneNode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fcheck_2eLaneArr = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereadLocal(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, i64 %a2)
declare %"compiler/typed:Elem" @compiler_2ftyped_3aElem_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@G_2ecompiler_2fcheck_2eLaneScalar = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@olang_loc_24a46e21631caff9_33b011dc8e05d16d = external constant [0 x i8]
@G_2ecompiler_2fcheck_2eLaneUn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneBool(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/source:Span" %a2, { i64, ptr } %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunaryOn(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, ptr %a3)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elaneOut(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@G_2ecompiler_2fcheck_2eLaneSel = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopValues(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, %"compiler/source:Span" %a2, i32 %a3, ptr %a4, ptr %a5, %"compiler/source:Span" %a6, %"compiler/source:Span" %a7)
@olang_loc_ddeebe9155436d6a_19ee353760b572b6 = external constant [0 x i8]
@olang_loc_7406e676cee1d8f8_b07044052169e244 = external constant [0 x i8]
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eliteralBeside(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eopParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecommuteParam(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitFits(ptr %v0, ptr %a0, %"compiler/check:litv" %a1, i32 %a2)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elitOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, %"compiler/check:litv" %a2, i32 %a3)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2enoMeet(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2, i32 %a3)
declare { i32, i64 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20I64_3e_H2a27ec2ae5362b2f0ac6d54f3e063c70(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/source:Span" @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2emutBefore(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMutOnValueParam(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aPattern_2eSpan(ptr %v0, ptr %a0)
@olang_loc_4d673442943c2a5_9663aeaf0b5db41 = external constant [0 x i8]
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_He6be2b0836caba7ddc59483ff74db438(ptr %v0, ptr %a0, i32 %a1)
declare { i32, i32 } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3ccompiler_2fsource_3aNameId_2c_20compil_Hfd0413fe7fd4e5914f6cad5b418b7a6d(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsErrVar(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etok(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrVarNotType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2efuncNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncDeclBare(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eforeignNamed(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eForeignByValue(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgCountMet(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, %"compiler/names:Ref" %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eArrayTooManyArgs(ptr %v0, i64 %a0)
declare i1 @compiler_2fgeneric_2eIsErrsArgOf(ptr %v0, ptr %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etypeArgMet(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eownBuffer(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunendedArgs(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i32 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstancesMet(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eTypeEntry(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fload_2ePublic(ptr %v0, { i64, ptr } %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare %"compiler/check:narrowed" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3anarrowed_3e_2eAt_3ccompiler_2fcheck_3anarrowed_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fcheck_2ecaseDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare void @compiler_2ftyped_3aBody_2ector(ptr %out, ptr %v0, i32 %a0, { i64, [2 x i64] } %a1, i32 %a2, i64 %a3, %"compiler/source:Span" %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Hb4635a51dd989c2102029bfb32ae3a2f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eAt_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrOf(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrMask(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRepr(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eisEnum(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eRawType(ptr %v0, ptr %a0, i32 %a1)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2erawsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare void @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eSetRawBits(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2)
declare i64 @compiler_2fgeneric_2eFnOwner(i64 %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eVarCount(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/generic:Binding" @compiler_2fgeneric_3aBinding_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eunify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
@olang_loc_d8c7da3a96e96ec6_ffec47baa4f6769a = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eVar(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eList(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSubst(ptr %v0, ptr %a0, i32 %a1, i64 %a2, i32 %a3)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eClosed(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2estrBytes(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare { i32, { i64, ptr } } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ereflRendered(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_2063aa53a395a078_c72ae34d29618694 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2einstanceBody(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2ftypes_2eWritable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ebodyOfCallee(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroFollows(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroRef(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eholdsWritable(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2echeckNow(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eparamOf(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" @std_2fpair_3aPair_3cI64_2c_20I64_3e_2ector(ptr %v0, i64 %a0, i64 %a1)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H1308596c866d4be061d9da9113abde88(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1, i1 %a2)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopesFit(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eScopeVarsOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fcheck_2eplainLen(ptr %v0, ptr %a0)
@olang_loc_e2de52da0998b8a_4e4f16d2638e7f66 = external constant [0 x i8]
@olang_loc_4bef50c9347fcfcb_39dc7124156e73c7 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasBody(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eHasPayload(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_5d236ea53e0f5fd3_8f603dd19b7c69a7 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_H06f4ae43b564aa38800728c5b9a6edfe(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3ccompiler_2fast_3aPattern_26_3e_Hb04d670045d084ea2498d9030c4fbba9(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2eLen_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %a0)
declare %"compiler/check:heldCand" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fcheck_3aheldCand_3e_2eAt_3ccompiler_2fcheck_3aheldCand_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fdefinit_2eHeldWalk(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eIsGenerator(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eGenElem(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fgeneric_2eGenPerTurn = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\FF\FF\FF\FF\FF\FF\FF\FF" }>, align 8
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2ePush_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e205085f53b5fcbb_81fd3e9c55e0751f = external constant [0 x i8]
declare %"compiler/check:elemsShape" @compiler_2fcheck_3aelemsShape_2ector(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
@olang_loc_c0d1d2eb81d1d8d1_71bd70056b23e28d = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eisRest(ptr %v0, ptr %a0)
@olang_loc_70e9f05b266be8f7_36ef9a2f9f93b02b = external constant [0 x i8]
@olang_loc_7d3bd01c87e6cabb_168a15d9febd8197 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBits(ptr %v0, ptr %a0, i32 %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsUnsigned(ptr %v0, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eShiftOutOfRange(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2)
@olang_loc_a580fa67a95f3737_235a3d78a5401c13 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnInDefer(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnOutsideJoin(ptr %v0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2ector(ptr %v0, i64 %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ediscardOr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eP_Ha5c233616e2ae02d7fe37742cfaef2c2(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e10ca684bef0956d_f742028d37a3af11 = external constant [0 x i8]
@olang_loc_c3afd3921db70d3f_27f9f6390ccac16b = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnLambdaParams(ptr %v0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2elambda(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, i32 %a3)
@olang_loc_da760de622febe3_df78aa298e2a00e7 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2ecallLike(ptr %v0, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnNotCall(ptr %v0)
@olang_loc_5ca7d448b00003f5_5d17299a767670c1 = external constant [0 x i8]
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eproduced(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2, i64 %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftypes_3aTypeId_3e_2eTruncate_3ccompiler_2ftypes_3aTypeId_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fcheck_2edispatched(ptr %v0, ptr %a0)
@olang_loc_a0a2b29f181c5519_be518ce768fc1fe5 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnFallible(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eSpawnTryInfallible(ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ector(ptr %v0, i64 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eL_H6a486a18542e18ee3475c3237c5a5335(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eA_Hf8c35f4f5353320ac1e6ff0719acdfb7(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ebab815881a318c_398bac8a238c0b80 = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNullable(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2ector(ptr %v0, i64 %a0)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eloneBinding(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2ecatchItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCatchNameInTask(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aItem_3e_2eToArray_3ccompiler_2ftyped_3aItem_3e(ptr %v0, ptr %v1, ptr %a0)
declare ptr @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eclauseHandler(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, i64 %a3)
declare %"compiler/typed:TaskClause" @compiler_2ftyped_3aTaskClause_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, { i64, ptr } %a1, i1 %a2, ptr %a3)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H70975c58788d810dba7712b4ee87a08c(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_e78286934eafcc6f_802ae2752731a35b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aClause_26_3e_2ePush_Hc64f4d0e64077a33423ff9c4e583894f(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2edropTaken(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2, ptr %a3)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espawnTargets(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, i32 %a5)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLvalue_3f_26_3e_2eT_Hc52cb714df9676093c851daa15f6f747(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aTaskClause_26_3e_2e_H788addc5d4e2ce71c84413f6a2c1cfed(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esite(ptr %v0, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
declare %"compiler/typed:Spawn" @compiler_2ftyped_3aSpawn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2, i32 %a3)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrSetItems(ptr %v0, ptr %a0, i32 %a1)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2espell(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i1 %a3)
declare i32 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2etextType(ptr %v0, ptr %a0)
@olang_loc_3727962a9e2e15db_7cf774666c9d4227 = external constant [0 x i8]
@olang_loc_81d441761e2a717d_f45e749fdf1e1e81 = external constant [0 x i8]
@olang_loc_64cdadb0ead6eee6_ae7a9e6dd8bef26a = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2ector(ptr %v0)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_H2ed2e5427629ba63a7110fc86d969058(ptr %v0, ptr %a0, %"std/pair:Pair.e476b05c61172463a7c240e364dbb6d0" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2eHas_3cI64_2c_20Bool_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7cf0066f219391e3_f59e2f38f1229917 = external constant [0 x i8]
@olang_loc_93e3a02800d00d4_2c47855b6b12ccf8 = external constant [0 x i8]
@olang_loc_ead499c86a25c3f7_b1128c547d2ccfbb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eStrReceiverWritable(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
@olang_loc_4caebcac4cec7311_26f3d9a9847d99e5 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTraitNotAType(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_aee2bc7202aed69e_9c3c63eda25ac602 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnifyBound(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSatisfies(ptr %v0, ptr %a0, i32 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnify(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, ptr %a3, i1 %a4, i1 %a5)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare void @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2epatternNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2, i1 %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" @std_2fpair_3aPair_3ccompiler_2fsource_3aNameId_2c_20compiler_2ftypes_3aTypeId_3e_2ector(ptr %v0, i32 %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fpair_3aPair_3ccompiler_2fsource__Habcf70cf374eb3bb03a96803ac10570d(ptr %v0, ptr %a0, %"std/pair:Pair.91de8c8eb84d52d1e58996aec31d85aa" %a1)
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eAnyUnique(ptr %v0, ptr %a0)
declare i64 @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eroleMethod(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2, i64 %a3)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eMethodSig(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eUnique(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eErrors(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2esuggest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eimportedTypeNamed(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownType(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownNumberType(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eUnknownTypeMeant(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fcheck_2ecompiler_2fcheck_3acollWalk_2esomeHolds(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eEmbedded(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_d5cbe87213397023_e63da241b79e21f = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4687f82547dc647_2449c09f4feab02b = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eRevers_Hae6dce760a5809d9fde696c8bce52839(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eToArra_H4d02a0b2e27e8f31ffc99daa43750593(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Path" @compiler_2fast_3aPath_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1)
@olang_loc_5b2b374f73dad39a_b03018bc2543a136 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2estmtLike(ptr %v0, ptr %a0)
@olang_loc_696a437f6b67e70a_247b6a7ce30931f6 = external constant [0 x i8]
@olang_loc_828d46431809dd00_d1819fff0627a99c = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eToArr_H3d785ef7fade1f29078b6e80f1d617ba(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3043109bf91ec9f6_e521dc8ddba3d97a = external constant [0 x i8]
@olang_loc_4815dd6a844b648b_8f1bd19822fdb0cf = external constant [0 x i8]
@olang_loc_5df9bd969218a728_7fa184e5bc45956c = external constant [0 x i8]
@olang_loc_69c4f09cb804b315_a031ca4d3ae928f9 = external constant [0 x i8]
@olang_loc_81e6157a61b9a5f1_a0e5ca59452f2055 = external constant [0 x i8]
declare %"compiler/check:reflList" @compiler_2fcheck_3areflList_2ector(ptr %v0, i1 %a0, i32 %a1, i64 %a2, i64 %a3)
declare %"compiler/check:signMag" @compiler_2fcheck_3asignMag_2ector(ptr %v0, i1 %a0, i128 %a1)
declare %"compiler/check:signMag" @compiler_2fcheck_2esignMag_2emagOf(%"compiler/check:litv" %a0)
declare void @compiler_2fcheck_2estoredExprs(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredCatches(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare void @compiler_2fcheck_2estoredMatch(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_9cea8b157736196b_cebcd42f5be7b27 = external constant [0 x i8]
@olang_loc_fa22773c0ed7d28e_9744d977b6aff1d2 = external constant [0 x i8]
declare i1 @compiler_2fcheck_2eexistingValue(ptr %v0, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3ccompiler_2ftypes_3aTypeId_2c_20Bool_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
