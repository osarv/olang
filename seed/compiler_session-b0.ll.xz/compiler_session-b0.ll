; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/fetch:Fetcher" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/load:Loader" = type { { i64, ptr }, ptr, ptr, ptr, ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" = type { ptr, i64 }
%"compiler/session:Analysis" = type { ptr, { i64, ptr }, ptr, ptr, ptr }
%"compiler/views:Kept" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/check:Checker" = type { ptr, ptr, i1, i1, i1, i1, i64, i64, i1, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i64, i32, i32, i1, { i64, [3 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i32, i64, %"compiler/source:Span", i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/check:knownRange", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i32, i1, i1, %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, i32, i32, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, i64, i64, i1, i1, i1, i32, i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/diag:Taken", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/text:StringBuilder", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/check:knownRange" = type { i64, i64, i64 }
%"compiler/diag:Taken" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1, i1, i1, i64, { i64, ptr } }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/session:Reader" = type { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/doc:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/interp:Exec" = type { ptr, ptr, i32, %"compiler/lower:Lowerer", %"compiler/eval:Machine", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1 }
%"compiler/lower:Lowerer" = type { ptr, ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/typed:Plan", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i32, i32, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:RefsKept", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64 }
%"compiler/typed:Plan" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/typed:RefsKept" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/mir:GenInfo" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/eval:Machine" = type { ptr, i32, i64, { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/mir:GenInfo", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/eval:Ptr", i32, { i64, [5 x i64] }, i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, ptr }, { i64, ptr }, i64, { i64, ptr }, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i64, { i64, ptr }, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, { i64, ptr }, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"compiler/source:Span", i32 }
%"compiler/eval:Ptr" = type { i64, i64 }
%"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406" = type { i64, { i64, ptr } }
%"compiler/generic:Program" = type { ptr, ptr, %"compiler/types:Table", %"compiler/facts:Table", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"compiler/generic:Origin", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/types:Table" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/facts:Table" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64 }
%"compiler/generic:Origin" = type { i64, %"compiler/source:Span", i64, i32 }
%"compiler/scope:Scoper" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { ptr, ptr }, { ptr, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, i64, i1, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/typed:Plan", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/source:Span", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fsBody", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i1, i1, i1, i1, i1, i1, { i64, [2 x i64] }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [2 x i64] }, i1, %"compiler/source:Span", { i64, [2 x i64] }, i1, { i64, [2 x i64] }, i1, i1, i1, %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:fnRecs", i1, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", { i64, [2 x i64] }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, { i64, [2 x i64] }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, i64, i1, i32, i1, i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i64, %"compiler/source:Span", i64, i1, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, i1, i1, i1, i1, i64, %"compiler/source:Span", %"compiler/source:Span", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, ptr, { i64, ptr }, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"compiler/scope:instTree", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"compiler/scope:Gap", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, i1, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i64, i64, i64, i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/scope:fsBody" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:fnRecs" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:instTree" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"<poll.h>:pollfd" = type { i32, i16, i16 }
%"compiler/session:Use" = type { i64, i64, { i64, ptr } }
%"compiler/load:Module" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i64, i1, ptr, ptr, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, i1, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, ptr, ptr, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, { i64, ptr }, %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Ref" = type { i32, i64, i64 }
%"compiler/ast:Func" = type { %"compiler/source:Span", ptr, i32, ptr, { i64, ptr }, { i64, ptr }, i1, i1, ptr, i32 }
%"compiler/typed:Local" = type { i32, %"compiler/source:Span", i32, i32, i32, { i64, [1 x i64] }, i1, i1 }
%"compiler/load:Import" = type { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, %"compiler/source:Span" }
%"compiler/typed:Body" = type { i32, { i64, [2 x i64] }, i32, i64, %"compiler/source:Span", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i32, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/scope:Placement" = type { i64, i64, i64, i64, { i64, ptr }, i1 }
%"compiler/session:Found" = type { { i64, ptr }, { i64, ptr }, i64 }
%"compiler/session:memberInfo" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr }, i64 }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" = type { i64, i32 }
%"compiler/names:Entry" = type { i32, %"compiler/source:Span", i32, i1, ptr }
%"compiler/names:Resolver" = type { ptr, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/names:Table" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/session:finder" = type { i64, i64, { i64, ptr }, ptr, i64, { i64, [6 x i64] }, i64 }
%"compiler/session:typeFinder" = type { i64, i32, i64 }
%"std/prelude/text:LineIter" = type { { i64, ptr }, i64 }
%"compiler/typed:Promote" = type { ptr, i32 }
%"compiler/typed:Call" = type { ptr, { i64, ptr }, i32, i1, i1 }
%"compiler/typed:Make" = type { i32, i64, { i64, ptr }, ptr, i32, i32, i1 }
%"compiler/typed:Collect" = type { ptr, ptr, i32, i32, i1, ptr }
%"compiler/typed:Slice" = type { ptr, ptr, ptr, i32 }
%"compiler/typed:Cond" = type { ptr, ptr, ptr }
%"compiler/typed:Seq" = type { { i64, ptr }, ptr, i1 }
%"compiler/typed:Match" = type { { i64, ptr }, { i64, ptr }, ptr, i1 }
%"compiler/typed:Arm" = type { %"compiler/source:Span", { i64, ptr }, ptr, ptr, ptr }
%"compiler/typed:Alt" = type { ptr, { i64, ptr } }
%"compiler/typed:Try" = type { ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/typed:Clause" = type { %"compiler/source:Span", { i64, ptr }, i1, ptr, { i64, ptr }, i64, i32 }
%"compiler/typed:Capture" = type { i32, ptr }
%"compiler/typed:Text" = type { { i64, ptr }, i32 }
%"compiler/typed:Elem" = type { ptr, ptr, i32 }
%"compiler/typed:Payload" = type { ptr, i64, i32 }
%"compiler/session:symWriter" = type { ptr, i64 }
%"compiler/session:Positions" = type { { i64, ptr }, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:MemberDecl" = type { ptr, i32, { i64, ptr }, ptr }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/ast:StructBody" = type { { i64, ptr }, ptr, { i64, ptr }, %"compiler/source:Span", { i64, ptr }, { i64, ptr } }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:TopIf" = type { ptr, ptr, ptr, ptr }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/doc:Example" = type { { i64, ptr }, { i64, ptr } }
define dso_local ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %lp12 = alloca ptr
  %l13 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca ptr
  %l21 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l32 = alloca { i64, ptr }
  %l36 = alloca %"compiler/fetch:Fetcher"
  %l38 = alloca %"compiler/source:Names"
  %l40 = alloca i64
  %l42 = alloca { i64, ptr }
  %l49 = alloca %"compiler/load:Loader"
  %l51 = alloca ptr
  %l54 = alloca { i64, ptr }
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca i64
  %l61 = alloca i64
  %l66 = alloca { i64, ptr }
  %l74 = alloca %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9"
  %l75 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l77 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l78 = alloca i32
  %l80 = alloca i1
  %l85 = alloca i64
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l92 = alloca i64
  %l94 = alloca i64
  %l99 = alloca %"compiler/session:Analysis"
  %l104 = alloca i1
  %l106 = alloca i1
  %l108 = alloca %"compiler/views:Kept"
  %l114 = alloca %"compiler/check:Checker"
  %l120 = alloca ptr
  %l121 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l137 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l140 = alloca i64
  %l144 = alloca i64
  %l147 = alloca i64
  %l148 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l152 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l155 = alloca i1
  %l165 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca ptr
  %t53 = alloca %"compiler/fetch:Fetcher", align 8
  %t88 = alloca %"compiler/load:Loader", align 8
  %t245 = alloca %"compiler/views:Kept", align 8
  %t255 = alloca %"compiler/check:Checker", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call ptr @__olang_scope_hold(ptr %v4)
  %t2 = ptrtoint ptr %t1 to i64
  store i64 %t2, ptr %l21, !tbaa !24
  %t3 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = call ptr @__olang_region_make(ptr %v4)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l21, !tbaa !24
  br label %bb2
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t8 = load i64, ptr %l21
  %t9 = inttoptr i64 %t8 to ptr
  %t11 = call { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %t9, { i64, ptr } %t7)
  store { i64, ptr } %t11, ptr %l24
  br label %bb3
bb3:
  %t12 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t13 = load i64, ptr %l21
  %t14 = inttoptr i64 %t13 to ptr
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_held_alloc(ptr %t14, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l25, !tbaa !27
  %t21 = call ptr @__olang_scope_hold(ptr %v4)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l26, !tbaa !24
  %t23 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1
  br i1 %t23, label %bb4, label %bb5
bb4:
  %t25 = call ptr @__olang_region_make(ptr %v4)
  %t26 = ptrtoint ptr %t25 to i64
  store i64 %t26, ptr %l26, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l26
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %t28)
  store { i64, ptr } %t29, ptr %l28
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t30, ptr %l29, !tbaa !27
  %t31 = call ptr @__olang_scope_hold(ptr %v4)
  %t32 = ptrtoint ptr %t31 to i64
  store i64 %t32, ptr %l30, !tbaa !24
  %t33 = load i1, ptr @olang_2esole_2ecompiler_2ffetch_3aFetcher_2e2
  br i1 %t33, label %bb7, label %bb8
bb7:
  %t35 = call ptr @__olang_region_make(ptr %v4)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l30, !tbaa !24
  br label %bb8
bb8:
  %t37 = load i64, ptr %l30
  %t38 = inttoptr i64 %t37 to ptr
  %t39 = call { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %t38)
  store { i64, ptr } %t39, ptr %l32
  br label %bb9
bb9:
  %t40 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t41 = load i64, ptr %l30
  %t42 = inttoptr i64 %t41 to ptr
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } %t40, 1
  %t45 = mul i64 %t43, 1
  %t46 = call ptr @__olang_held_alloc(ptr %t42, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t44, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  %t49 = load ptr, ptr %l1, !tbaa !29
  %t51 = getelementptr %"compiler/build:Config", ptr %t49, i32 0, i32 24
  %t52 = load i1, ptr %t51, !tbaa !21
  %t54 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @compiler_2ffetch_3aFetcher_2ector(ptr %t53, ptr %v4, ptr %v4, ptr %v4, ptr %v4, { i64, ptr } %t54, { i64, ptr } %t55, { i64, ptr } %t48, i1 %t52, i1 true)
  call void @llvm.memmove.p0.p0.i64(ptr %l36, ptr %t53, i64 184, i1 false)
  br label %bb10
bb10:
  %t58 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 184, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %l36, i64 184, i1 false)
  store ptr %t58, ptr %l6, !tbaa !29
  %t60 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v4)
  store %"compiler/source:Names" %t60, ptr %l38
  br label %bb11
bb11:
  %t61 = load %"compiler/source:Names", ptr %l38
  %t62 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 104, i64 8)
  store %"compiler/source:Names" %t61, ptr %t62
  store ptr %t62, ptr %l7, !tbaa !29
  %t64 = call ptr @__olang_scope_hold(ptr %v4)
  %t65 = ptrtoint ptr %t64 to i64
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e0
  br i1 %t66, label %bb12, label %bb13
bb12:
  %t68 = call ptr @__olang_region_make(ptr %v4)
  %t69 = ptrtoint ptr %t68 to i64
  store i64 %t69, ptr %l40, !tbaa !24
  br label %bb13
bb13:
  %t70 = load i64, ptr %l40
  %t71 = inttoptr i64 %t70 to ptr
  %t72 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %t71)
  store { i64, ptr } %t72, ptr %l42
  br label %bb14
bb14:
  %t73 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t74 = load i64, ptr %l40
  %t75 = inttoptr i64 %t74 to ptr
  %t76 = extractvalue { i64, ptr } %t73, 0
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_held_alloc(ptr %t75, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 3
  %t85 = load ptr, ptr %l6, !tbaa !29
  %t86 = load ptr, ptr %l7, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fload_3aLoader_2ector(ptr %t88, ptr %v4, ptr %v1, ptr %v4, ptr %v4, ptr %v2, ptr %v4, { i64, ptr } %t81, ptr %t84, ptr %t85, ptr %t86, ptr %t87)
  call void @llvm.memmove.p0.p0.i64(ptr %l49, ptr %t88, i64 864, i1 false)
  br label %bb15
bb15:
  %t94 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 864, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t94, ptr %l49, i64 864, i1 false)
  store ptr %t94, ptr %l8, !tbaa !29
  %t96 = load ptr, ptr %l8, !tbaa !29
  store ptr %t96, ptr %l51, !tbaa !29
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Config", ptr %t97, i32 0, i32 1
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t101 = load ptr, ptr %l51, !tbaa !29
  %t102 = getelementptr %"compiler/load:Loader", ptr %t101, i32 0, i32 20
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l54, !tbaa !27
  %t105 = load ptr, ptr %l51, !tbaa !29
  %t106 = getelementptr %"compiler/load:Loader", ptr %t105, i32 0, i32 20
  store { i64, ptr } %t100, ptr %t106, !tbaa !27
  %t107 = load i1, ptr @olang_2esole_2ecompiler_2fload_3aLoader_2e20
  br i1 %t107, label %bb16, label %bb17
bb16:
  %t109 = load { i64, ptr }, ptr %l54
  %t110 = extractvalue { i64, ptr } %t109, 1
  call void @__olang_region_release(ptr %t110)
  store { i64, ptr } zeroinitializer, ptr %l54
  br label %bb17
bb17:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v1, ptr %v4, ptr %t111)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %l57
  br label %bb18
bb18:
  %t114 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  %t115 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t114, ptr %t115
  store ptr %t115, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  %t117 = load i64, ptr %l10, !tbaa !24
  store i64 %t117, ptr %l59, !tbaa !24
  %t118 = load ptr, ptr %l9, !tbaa !29
  %t120 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t118)
  store i64 %t120, ptr %l61
  br label %bb20
bb20:
  %t121 = load i64, ptr %l59, !tbaa !24
  %t122 = load i64, ptr %l61, !tbaa !24
  %t123 = icmp slt i64 %t121, %t122
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb21, label %bb22
bb21:
  br label %bb27
bb22:
  br label %bb23
bb23:
  %t127 = load ptr, ptr %l9, !tbaa !29
  %t128 = load i64, ptr %l10, !tbaa !24
  %t131 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t127, i64 %t128)
  store { i64, ptr } %t131, ptr %l66
  br label %bb24
bb24:
  %t132 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t133 = load ptr, ptr %l8, !tbaa !29
  %t135 = getelementptr %"compiler/load:Loader", ptr %t133, i32 0, i32 21
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v4, ptr %v4, ptr %t135, { i64, ptr } %t132)
  br label %bb25
bb25:
  br label %bb26
bb26:
  %t139 = load i64, ptr %l10, !tbaa !24
  %t142 = add i64 %t139, 1
  store i64 %t142, ptr %l10, !tbaa !24
  br label %bb19
bb27:
  %t146 = call %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v3, ptr %v4, ptr %a3)
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t146, ptr %l74
  br label %bb28
bb28:
  %t147 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t147, ptr %lp12
  %t148 = load %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9", ptr %l74
  %t149 = load ptr, ptr %lp12
  store %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" %t148, ptr %t149
  br label %bb29
bb29:
  %t150 = load ptr, ptr %lp12
  %t152 = call { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v4, ptr %v4, ptr %t150)
  %t153 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t152, 1
  %t154 = extractvalue { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } %t152, 0
  store i32 %t154, ptr %l78
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb31, label %ok.156, !prof !99
ok.156:
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t153, ptr %l77
  br label %bb30
bb30:
  %t157 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l77
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t157, ptr %l75
  br label %bb33
bb31:
  %t158 = load i32, ptr %l78, !tbaa !23
  %t159 = ashr i32 %t158, 16
  %t161 = icmp eq i32 %t159, 1
  store i1 %t161, ptr %l80, !tbaa !21
  br label %bb32
bb32:
  br label %bb36
bb33:
  %t162 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l75
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t162, ptr %l13
  %t163 = load ptr, ptr %l8, !tbaa !29
  %t165 = getelementptr %"compiler/load:Loader", ptr %t163, i32 0, i32 13
  %t166 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l13, i32 0, i32 0
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !27
  %t168 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %l13, i32 0, i32 1
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  call void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v4, ptr %v4, ptr %v4, ptr %t165, { i64, ptr } %t167, { i64, ptr } %t169)
  br label %bb34
bb34:
  br label %bb35
bb35:
  br label %bb29
bb36:
  %t173 = call i64 @std_2ftime_2eNow()
  store i64 %t173, ptr %l85
  br label %bb37
bb37:
  %t174 = load i64, ptr %l85, !tbaa !24
  store i64 %t174, ptr %l14, !tbaa !24
  %t175 = load ptr, ptr %l8, !tbaa !29
  %t176 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t179 = call i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v4, ptr %v0, ptr %t175, { i64, ptr } %t176)
  store i64 %t179, ptr %l88
  br label %bb38
bb38:
  %t180 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t180, ptr %l89, !tbaa !27
  %t181 = load ptr, ptr %l8, !tbaa !29
  %t183 = getelementptr %"compiler/load:Loader", ptr %t181, i32 0, i32 10
  %t185 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v4, ptr %t183)
  store i64 %t185, ptr %l92
  br label %bb39
bb39:
  %t186 = load i64, ptr %l14, !tbaa !24
  %t188 = call i64 @std_2ftime_2eSince(i64 %t186)
  store i64 %t188, ptr %l94
  br label %bb40
bb40:
  %t189 = load i64, ptr %l94, !tbaa !24
  %t190 = sdiv i64 %t189, 1000000
  %t191 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 1
  %t192 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) }, 0
  %t193 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = add i64 %t192, %t195
  %t197 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 1
  %t198 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d1, i32 0, i32 1) }, 0
  %t199 = add i64 %t196, %t198
  %t200 = load i64, ptr %l92, !tbaa !24
  %t201 = call i64 @__olang_fmt_i64(ptr null, i64 %t200)
  %t202 = add i64 %t199, %t201
  %t203 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t205 = add i64 %t202, %t204
  %t207 = call i64 @__olang_fmt_i64(ptr null, i64 %t190)
  %t208 = add i64 %t205, %t207
  %t209 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t210 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t211 = add i64 %t208, %t210
  %t212 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t211)
  call void @olang_textcopy(ptr %t212, ptr %t191, i64 %t192)
  %t213 = getelementptr i8, ptr %t212, i64 %t192
  call void @olang_textcopy(ptr %t213, ptr %t194, i64 %t195)
  %t214 = getelementptr i8, ptr %t213, i64 %t195
  call void @olang_textcopy(ptr %t214, ptr %t197, i64 %t198)
  %t215 = getelementptr i8, ptr %t214, i64 %t198
  %t216 = call i64 @__olang_fmt_i64(ptr %t215, i64 %t200)
  %t217 = getelementptr i8, ptr %t215, i64 %t201
  call void @olang_textcopy(ptr %t217, ptr %t203, i64 %t204)
  %t218 = getelementptr i8, ptr %t217, i64 %t204
  %t219 = call i64 @__olang_fmt_i64(ptr %t218, i64 %t190)
  %t220 = getelementptr i8, ptr %t218, i64 %t207
  call void @olang_textcopy(ptr %t220, ptr %t209, i64 %t210)
  %t221 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t212, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t222)
  br label %bb41
bb41:
  %t225 = load ptr, ptr %l8, !tbaa !29
  %t227 = call %"compiler/session:Analysis" @compiler_2fsession_3aAnalysis_2ector(ptr %v4, ptr %v4, ptr %t225)
  store %"compiler/session:Analysis" %t227, ptr %l99
  br label %bb42
bb42:
  %t228 = load %"compiler/session:Analysis", ptr %l99
  %t229 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 48, i64 8)
  store %"compiler/session:Analysis" %t228, ptr %t229
  store ptr %t229, ptr %l15, !tbaa !29
  %t231 = load ptr, ptr %l8, !tbaa !29
  %t233 = getelementptr %"compiler/load:Loader", ptr %t231, i32 0, i32 12
  %t234 = load i64, ptr %t233, !tbaa !24
  %t236 = icmp slt i64 %t234, 0
  br i1 %t236, label %bb43, label %bb44
bb43:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb46
bb44:
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t240 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v2, ptr %t238)
  store i1 %t240, ptr %l106
  br label %bb45
bb45:
  %t241 = load i1, ptr %l106, !tbaa !21
  store i1 %t241, ptr %l104, !tbaa !21
  br label %bb46
bb46:
  %t242 = load i1, ptr %l104, !tbaa !21
  br i1 %t242, label %bb47, label %bb48
bb47:
  %t243 = load ptr, ptr %l15, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t243, ptr %rv
  br label %ret
bb48:
  br label %bb49
bb49:
  call void @compiler_2fviews_3aKept_2ector(ptr %t245, ptr %v4)
  call void @llvm.memmove.p0.p0.i64(ptr %l108, ptr %t245, i64 296, i1 false)
  br label %bb50
bb50:
  %t246 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 296, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t246, ptr %l108, i64 296, i1 false)
  store ptr %t246, ptr %l16, !tbaa !29
  %t248 = load ptr, ptr %l16, !tbaa !29
  %t249 = load i1, ptr %l5, !tbaa !21
  %t252 = getelementptr %"compiler/views:Kept", ptr %t248, i32 0, i32 3
  store i1 %t249, ptr %t252, !tbaa !21
  %t253 = load ptr, ptr %l8, !tbaa !29
  %t254 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2finterp_2eAnalyze(ptr %t255, ptr %v4, ptr %v4, ptr %v4, ptr %t253, i1 true, ptr %t254)
  call void @llvm.memmove.p0.p0.i64(ptr %l114, ptr %t255, i64 5960, i1 false)
  br label %bb51
bb51:
  %t258 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 5960, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t258, ptr %l114, i64 5960, i1 false)
  store ptr %t258, ptr %l17, !tbaa !29
  %t260 = load ptr, ptr %l15, !tbaa !29
  %t261 = load ptr, ptr %l17, !tbaa !29
  %t265 = getelementptr %"compiler/session:Analysis", ptr %t260, i32 0, i32 2
  store ptr %t261, ptr %t265, !tbaa !29
  %t266 = load i1, ptr %l5, !tbaa !21
  br i1 %t266, label %bb52, label %bb53
bb52:
  %t268 = load ptr, ptr %l15, !tbaa !29
  store ptr %t268, ptr %l120, !tbaa !29
  %t269 = call ptr @__olang_scope_hold(ptr %v4)
  %t270 = ptrtoint ptr %t269 to i64
  store i64 %t270, ptr %l121, !tbaa !24
  %t271 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aAnalysis_2e1
  br i1 %t271, label %bb54, label %bb55
bb53:
  br label %bb59
bb54:
  %t273 = call ptr @__olang_region_make(ptr %v4)
  %t274 = ptrtoint ptr %t273 to i64
  store i64 %t274, ptr %l121, !tbaa !24
  br label %bb55
bb55:
  %t275 = load ptr, ptr %l8, !tbaa !29
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t277 = load i64, ptr %l121
  %t278 = inttoptr i64 %t277 to ptr
  %t281 = call { i64, ptr } @compiler_2frecords_2eModuleKeys(ptr %v4, ptr %v1, ptr %t278, ptr %t275, ptr %t276, i1 true)
  store { i64, ptr } %t281, ptr %l125
  br label %bb56
bb56:
  %t282 = load ptr, ptr %l120, !tbaa !29
  %t283 = getelementptr %"compiler/session:Analysis", ptr %t282, i32 0, i32 1
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !27
  store { i64, ptr } %t284, ptr %l126, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t286 = load ptr, ptr %l120, !tbaa !29
  %t287 = getelementptr %"compiler/session:Analysis", ptr %t286, i32 0, i32 1
  store { i64, ptr } %t285, ptr %t287, !tbaa !27
  %t288 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aAnalysis_2e1
  br i1 %t288, label %bb57, label %bb58
bb57:
  %t290 = load { i64, ptr }, ptr %l126
  %t291 = extractvalue { i64, ptr } %t290, 1
  call void @__olang_region_release(ptr %t291)
  store { i64, ptr } zeroinitializer, ptr %l126
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t292 = load ptr, ptr %l17, !tbaa !29
  %t294 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 89
  %t295 = load i1, ptr %t294, !tbaa !21
  br i1 %t295, label %bb60, label %bb61
bb60:
  %t297 = load ptr, ptr %l8, !tbaa !29
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t299 = load ptr, ptr %l15, !tbaa !29
  %t301 = getelementptr %"compiler/session:Analysis", ptr %t299, i32 0, i32 1
  %t302 = load { i64, ptr }, ptr %t301, !tbaa !27
  %t303 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2frecords_2eFrontRecords(ptr %v4, ptr %v1, ptr %v4, ptr %v4, ptr %t297, ptr %t298, { i64, ptr } %t302, ptr %t303)
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t308 = load ptr, ptr %l17, !tbaa !29
  %t309 = load ptr, ptr %l16, !tbaa !29
  call void @compiler_2finterp_2eJudgeViews(ptr %v4, ptr %v4, ptr %t308, ptr %t309)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t312 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t312, ptr %l137
  br label %bb65
bb65:
  %t313 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l137
  %t314 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t313, ptr %t314
  store ptr %t314, ptr %l18, !tbaa !29
  %t316 = load ptr, ptr %l2, !tbaa !29
  %t318 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v2, ptr %t316)
  store i64 %t318, ptr %l140
  br label %bb66
bb66:
  %t319 = load i64, ptr %l140, !tbaa !24
  %t320 = icmp eq i64 %t319, 0
  store i1 %t320, ptr %l19, !tbaa !21
  %t322 = load i1, ptr %l19, !tbaa !21
  br i1 %t322, label %bb67, label %bb68
bb67:
  %t324 = load ptr, ptr %l17, !tbaa !29
  %t326 = call i64 @compiler_2finterp_2eDecideValues(ptr %v4, ptr %t324)
  store i64 %t326, ptr %l144
  br label %bb69
bb68:
  br label %bb70
bb69:
  br label %bb70
bb70:
  %t327 = load ptr, ptr %l17, !tbaa !29
  %t328 = load ptr, ptr %l18, !tbaa !29
  %t331 = call i64 @compiler_2finterp_2eDecideAsserts(ptr %v4, ptr %s0, ptr %t327, ptr %t328)
  store i64 %t331, ptr %l147
  br label %bb71
bb71:
  %t332 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %s0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t332, ptr %l148
  br label %bb72
bb72:
  %t333 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l148
  %t334 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t333, ptr %t334
  store ptr %t334, ptr %l20, !tbaa !29
  %t336 = load i1, ptr %l19, !tbaa !21
  br i1 %t336, label %bb73, label %bb74
bb73:
  %t338 = load ptr, ptr %l17, !tbaa !29
  %t340 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2eBake(ptr %v4, ptr %s0, ptr %t338)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t340, ptr %l152
  br label %bb75
bb74:
  br label %bb76
bb75:
  %t341 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l152
  %t342 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t341, ptr %t342
  store ptr %t342, ptr %l20, !tbaa !29
  br label %bb76
bb76:
  %t344 = load i1, ptr %l19, !tbaa !21
  br i1 %t344, label %bb77, label %bb78
bb77:
  %t346 = load i1, ptr %l5, !tbaa !21
  store i1 %t346, ptr %l155, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb79
bb79:
  %t348 = load i1, ptr %l155, !tbaa !21
  br i1 %t348, label %bb80, label %bb81
bb80:
  %t349 = load ptr, ptr %l8, !tbaa !29
  %t350 = load ptr, ptr %l17, !tbaa !29
  %t351 = load ptr, ptr %l1, !tbaa !29
  %t352 = load ptr, ptr %l15, !tbaa !29
  %t354 = getelementptr %"compiler/session:Analysis", ptr %t352, i32 0, i32 1
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !27
  %t356 = load ptr, ptr %l16, !tbaa !29
  %t357 = load ptr, ptr %l20, !tbaa !29
  call void @compiler_2frecords_2eKeepFront(ptr %v4, ptr %v4, ptr %v1, ptr %v4, ptr %v4, ptr %s0, ptr %t349, ptr %t350, ptr %t351, { i64, ptr } %t355, ptr %t356, ptr %t357)
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t364 = load i64, ptr %l14, !tbaa !24
  %t366 = call i64 @std_2ftime_2eSince(i64 %t364)
  store i64 %t366, ptr %l165
  br label %bb84
bb84:
  %t367 = load i64, ptr %l165, !tbaa !24
  %t368 = sdiv i64 %t367, 1000000
  %t369 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t372 = call i64 @__olang_fmt_i64(ptr null, i64 %t368)
  %t373 = add i64 %t370, %t372
  %t374 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t377 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t376)
  call void @olang_textcopy(ptr %t377, ptr %t369, i64 %t370)
  %t378 = getelementptr i8, ptr %t377, i64 %t370
  %t379 = call i64 @__olang_fmt_i64(ptr %t378, i64 %t368)
  %t380 = getelementptr i8, ptr %t378, i64 %t372
  call void @olang_textcopy(ptr %t380, ptr %t374, i64 %t375)
  %t381 = insertvalue { i64, ptr } undef, i64 %t376, 0
  %t382 = insertvalue { i64, ptr } %t381, ptr %t377, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t382)
  br label %bb85
bb85:
  br i1 %a4, label %bb86, label %bb87
bb86:
  %t387 = load ptr, ptr %l15, !tbaa !29
  %t388 = load ptr, ptr %l1, !tbaa !29
  call void @compiler_2fsession_2eHold(ptr %v4, ptr %v1, ptr %t387, ptr %t388)
  br label %bb88
bb87:
  br label %bb89
bb88:
  br label %bb89
bb89:
  %t391 = load ptr, ptr %l15, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  store ptr %t391, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local { { i64, ptr }, i32 } @compiler_2fsession_2eChildOutput(ptr %v0, ptr %v1, ptr %a0c, ptr %a0e) #0 {
entry:
  %l0 = alloca { ptr, ptr }
  %l1 = alloca { i32, i32 }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca %"compiler/session:Reader"
  %l6 = alloca i32
  %l7 = alloca { i32, i32 }
  %l13 = alloca { i64, ptr }
  %l15 = alloca i32
  %l21 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i1
  %l38 = alloca %"compiler/session:Reader"
  %l40 = alloca i1
  %l44 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i32 }
  %pf0 = insertvalue { ptr, ptr } undef, ptr %a0c, 0
  %pg0 = insertvalue { ptr, ptr } %pf0, ptr %a0e, 1
  store { ptr, ptr } %pg0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, i32 } @compiler_2fsession_2ePipe()
  store { i32, i32 } %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load { i32, i32 }, ptr %l7
  store { i32, i32 } %t2, ptr %l1
  %t3 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 0
  %t4 = load i32, ptr %t3, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t6 = getelementptr { i32, i32 }, ptr %l1, i32 0, i32 1
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l3, !tbaa !23
  %t9 = load i32, ptr %l2, !tbaa !23
  %t11 = icmp slt i32 %t9, 0
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t13 = load { ptr, ptr }, ptr %l0
  %t15 = extractvalue { ptr, ptr } %t13, 0
  %t16 = extractvalue { ptr, ptr } %t13, 1
  %t17 = call { i64, ptr } %t15(ptr %t16, ptr %v1)
  store { i64, ptr } %t17, ptr %l13
  br label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t19 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t18, 0
  %t20 = insertvalue { { i64, ptr }, i32 } %t19, i32 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t20, ptr %rv
  br label %ret
bb5:
  %t22 = call i32 @fork()
  store i32 %t22, ptr %l15
  br label %bb6
bb6:
  %t23 = load i32, ptr %l15, !tbaa !23
  store i32 %t23, ptr %l4, !tbaa !23
  %t24 = load i32, ptr %l4, !tbaa !23
  %t26 = icmp slt i32 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t28)
  br label %bb9
bb8:
  br label %bb12
bb9:
  %t30 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t30)
  br label %bb10
bb10:
  %t32 = load { ptr, ptr }, ptr %l0
  %t34 = extractvalue { ptr, ptr } %t32, 0
  %t35 = extractvalue { ptr, ptr } %t32, 1
  %t36 = call { i64, ptr } %t34(ptr %t35, ptr %v1)
  store { i64, ptr } %t36, ptr %l21
  br label %bb11
bb11:
  %t37 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t38 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t37, 0
  %t39 = insertvalue { { i64, ptr }, i32 } %t38, i32 0, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t39, ptr %rv
  br label %ret
bb12:
  %t41 = load i32, ptr %l4, !tbaa !23
  %t43 = icmp eq i32 %t41, 0
  br i1 %t43, label %bb13, label %bb14
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t45 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t45)
  br label %bb15
bb14:
  br label %bb25
bb15:
  call void @compiler_2fsession_2eDup2(i32 2, i32 1)
  br label %bb16
bb16:
  %t47 = load i32, ptr %l3, !tbaa !23
  store i32 %t47, ptr %l26, !tbaa !23
  %t48 = load { ptr, ptr }, ptr %l0
  %t50 = extractvalue { ptr, ptr } %t48, 0
  %t51 = extractvalue { ptr, ptr } %t48, 1
  %t52 = call { i64, ptr } %t50(ptr %t51, ptr %s3)
  store { i64, ptr } %t52, ptr %l28
  br label %bb17
bb17:
  %t53 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  %t61 = load i32, ptr %l26, !tbaa !23
  %t63 = call i32 @std_2fio_2eWrite(ptr %s3, i32 %t61, { i64, ptr } %t60)
  store i32 %t63, ptr %l31
  %t64 = icmp ne i32 %t63, 0
  br i1 %t64, label %bb19, label %ok.65, !prof !99
ok.65:
  br label %bb18
bb18:
  br label %bb23
bb19:
  %t66 = load i32, ptr %l31, !tbaa !23
  %t67 = ashr i32 %t66, 16
  %t69 = icmp eq i32 %t67, 1
  store i1 %t69, ptr %l33, !tbaa !21
  %t70 = load i32, ptr %l31, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  br i1 %t73, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  call void @_exit(i32 0)
  unreachable
bb24:
  call void @__olang_check_failed(ptr @olang_loc_35fd852a81194674_cc9a5a6794b34358)
  unreachable
bb25:
  %t75 = load i32, ptr %l3, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t75)
  br label %bb26
bb26:
  %t77 = load i32, ptr %l2, !tbaa !23
  %t79 = call %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %s0, i32 %t77)
  store %"compiler/session:Reader" %t79, ptr %l38
  br label %bb27
bb27:
  %t80 = load %"compiler/session:Reader", ptr %l38
  store %"compiler/session:Reader" %t80, ptr %l5
  br label %bb28
bb28:
  %t82 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %s0, ptr %l5)
  store i1 %t82, ptr %l40
  br label %bb29
bb29:
  %t83 = load i1, ptr %l40, !tbaa !21
  %t84 = xor i1 %t83, true
  br i1 %t84, label %bb30, label %bb31
bb30:
  br label %bb34
bb31:
  br label %bb32
bb32:
  br label %bb33
bb33:
  br label %bb28
bb34:
  %t86 = load i32, ptr %l2, !tbaa !23
  call void @compiler_2fsession_2eCloseFd(i32 %t86)
  br label %bb35
bb35:
  %t88 = load i32, ptr %l4, !tbaa !23
  %t90 = call i32 @compiler_2fsession_2eReap(i32 %t88)
  store i32 %t90, ptr %l44
  br label %bb36
bb36:
  %t91 = load i32, ptr %l44, !tbaa !23
  store i32 %t91, ptr %l6, !tbaa !23
  %t92 = getelementptr %"compiler/session:Reader", ptr %l5, i32 0, i32 1
  %t94 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %s0, ptr %s0, ptr %t92)
  store { i64, ptr } %t94, ptr %l46
  br label %bb37
bb37:
  %t95 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t95, ptr %l47, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 0
  store i64 %t97, ptr %l48, !tbaa !24
  %t98 = load i64, ptr %l48, !tbaa !24
  %t99 = mul i64 %t98, 1
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l49, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !27
  %t107 = load i64, ptr %l48, !tbaa !24
  %t108 = mul i64 %t107, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t104, ptr %t106, i64 %t108, i1 false)
  %t109 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t116 = load i32, ptr %l6, !tbaa !23
  %t118 = insertvalue { { i64, ptr }, i32 } undef, { i64, ptr } %t115, 0
  %t120 = insertvalue { { i64, ptr }, i32 } %t118, i32 %t116, 1
  call void @__olang_scope_close(ptr %s0)
  store { { i64, ptr }, i32 } %t120, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, i32 }, ptr %rv
  ret { { i64, ptr }, i32 } %rr
}

define dso_local i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca i32
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca [2 x { i64, ptr }]
  %l19 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca %"compiler/diag:Diagnostics"
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l33 = alloca ptr
  %l35 = alloca i64
  %l37 = alloca i1
  %l41 = alloca i1
  %l46 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l53 = alloca i1
  %l55 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l65 = alloca ptr
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l78 = alloca i1
  %l79 = alloca ptr
  %l80 = alloca { i64, [3 x i64] }
  %l82 = alloca { i64, ptr }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l85 = alloca i64
  %l87 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l101 = alloca ptr
  %l110 = alloca %"compiler/doc:Module"
  %l112 = alloca { i64, ptr }
  %l115 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l123 = alloca { i64, ptr }
  %l132 = alloca i64
  %l136 = alloca i32
  %l138 = alloca i1
  %l145 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l147 = alloca i64
  %l149 = alloca i64
  %l154 = alloca { i64, ptr }
  %l159 = alloca i32
  %l161 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca i32
  %l166 = alloca i1
  %l169 = alloca ptr
  %l170 = alloca i64
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l176 = alloca i64
  %l179 = alloca { i64, ptr }
  %l181 = alloca %"compiler/doc:Module"
  %l191 = alloca { i64, ptr }
  %l192 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l202 = alloca i32
  %l204 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t6 = alloca %"compiler/diag:Diagnostics", align 8
  %t132 = alloca { i64, [3 x i64] }, align 8
  %t304 = alloca { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, align 8
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t3, ptr %l21
  br label %bb1
bb1:
  %t4 = load i1, ptr %l21, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t5, ptr %l22
  br label %bb4
bb3:
  br label %bb58
bb4:
  %t7 = load i1, ptr %l22, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t6, ptr %s1, i1 %t7)
  call void @llvm.memmove.p0.p0.i64(ptr %l23, ptr %t6, i64 704, i1 false)
  br label %bb5
bb5:
  %t8 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t8, ptr %l23, i64 704, i1 false)
  store ptr %t8, ptr %l4, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t10, ptr %l25, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr { i64, ptr }, ptr %t12, i64 0
  %t14 = load { i64, ptr }, ptr %t13, !tbaa !37
  store { i64, ptr } %t14, ptr %l26, !tbaa !27
  %t15 = load ptr, ptr %l3, !tbaa !29
  store ptr %t15, ptr %l27, !tbaa !29
  %t16 = load ptr, ptr %l4, !tbaa !29
  store ptr %t16, ptr %l28, !tbaa !29
  %t17 = call ptr @__olang_scope_hold(ptr %s1)
  %t18 = ptrtoint ptr %t17 to i64
  store i64 %t18, ptr %l29, !tbaa !24
  %t19 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2c_20std_Hae258982e94f82c7c4916579e261fcef
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t21 = call ptr @__olang_region_make(ptr %s1)
  %t22 = ptrtoint ptr %t21 to i64
  store i64 %t22, ptr %l29, !tbaa !24
  br label %bb7
bb7:
  %t23 = load i64, ptr %l29
  %t24 = inttoptr i64 %t23 to ptr
  %t25 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t24)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t25, ptr %l31
  br label %bb8
bb8:
  %t26 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l31
  %t27 = load i64, ptr %l29
  %t28 = inttoptr i64 %t27 to ptr
  %t29 = call ptr @__olang_scope_alloc_a(ptr %t28, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t26, ptr %t29
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t31 = load ptr, ptr %l27, !tbaa !29
  %t32 = load ptr, ptr %l28, !tbaa !29
  %t34 = call ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %v0, ptr %v3, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t30, ptr %t31, ptr %t32, ptr %t29, i1 true, i1 false)
  store ptr %t34, ptr %l33
  br label %bb9
bb9:
  %t35 = load ptr, ptr %l33, !tbaa !29
  store ptr %t35, ptr %l5, !tbaa !29
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %s1, ptr %t36)
  store i64 %t38, ptr %l35
  br label %bb10
bb10:
  %t39 = load i64, ptr %l35, !tbaa !24
  %t40 = icmp sgt i64 %t39, 0
  br i1 %t40, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  %t42 = load ptr, ptr %l5, !tbaa !29
  %t44 = getelementptr %"compiler/session:Analysis", ptr %t42, i32 0, i32 2
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  store i1 %t47, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l37, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l41, !tbaa !21
  br label %bb16
bb15:
  %t50 = load ptr, ptr %l5, !tbaa !29
  %t52 = getelementptr %"compiler/session:Analysis", ptr %t50, i32 0, i32 3
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  store i1 %t55, ptr %l41, !tbaa !21
  br label %bb16
bb16:
  %t57 = load i1, ptr %l41, !tbaa !21
  br i1 %t57, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t58 = load ptr, ptr %l4, !tbaa !29
  %t60 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s1, ptr %s2, ptr %t58)
  store { i64, ptr } %t60, ptr %l46
  br label %bb19
bb18:
  br label %bb23
bb19:
  %t61 = load { i64, ptr }, ptr %l46, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t61)
  br label %bb20
bb20:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %s1, ptr %s2, ptr %t63)
  store { i64, ptr } %t65, ptr %l49
  br label %bb21
bb21:
  %t66 = load { i64, ptr }, ptr %l49, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t66)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb23:
  %t69 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s1, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t71, ptr %l53
  br label %bb24
bb24:
  %t72 = load i1, ptr %l53, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s3
  %t75 = load ptr, ptr %l5, !tbaa !29
  %t77 = getelementptr %"compiler/session:Analysis", ptr %t75, i32 0, i32 2
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb27, label %bb28
bb26:
  br label %bb45
bb27:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb28:
  br label %bb29
bb29:
  %t82 = load ptr, ptr %l5, !tbaa !29
  %t84 = getelementptr %"compiler/session:Analysis", ptr %t82, i32 0, i32 2
  %t85 = load ptr, ptr %t84, !tbaa !29
  store ptr %t85, ptr %l60, !tbaa !29
  %t86 = load ptr, ptr %l5, !tbaa !29
  %t88 = getelementptr %"compiler/session:Analysis", ptr %t86, i32 0, i32 3
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t91 = icmp eq ptr %t89, null
  br i1 %t91, label %bb30, label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb31:
  br label %bb32
bb32:
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/session:Analysis", ptr %t93, i32 0, i32 3
  %t96 = load ptr, ptr %t95, !tbaa !29
  store ptr %t96, ptr %l65, !tbaa !29
  %t97 = load ptr, ptr %l5, !tbaa !29
  %t99 = getelementptr %"compiler/session:Analysis", ptr %t97, i32 0, i32 4
  %t100 = load ptr, ptr %t99, !tbaa !29
  %t102 = icmp eq ptr %t100, null
  br i1 %t102, label %bb33, label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_3107e0baf714f587_4e2de6149db597f3)
  unreachable
bb34:
  br label %bb35
bb35:
  %t104 = load ptr, ptr %l5, !tbaa !29
  %t106 = getelementptr %"compiler/session:Analysis", ptr %t104, i32 0, i32 4
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/session:Analysis", ptr %t108, i32 0, i32 0
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t113 = getelementptr %"compiler/load:Loader", ptr %t111, i32 0, i32 12
  %t114 = load i64, ptr %t113, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t116 = load ptr, ptr %l60, !tbaa !29
  %t117 = load ptr, ptr %l65, !tbaa !29
  %t121 = call { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %s1, ptr %s1, ptr %s1, ptr %v1, ptr %s3, ptr %t116, ptr %t117, ptr %t107, i64 %t114, { i64, ptr } %t115)
  %t122 = extractvalue { i32, { i64, ptr } } %t121, 1
  %t123 = extractvalue { i32, { i64, ptr } } %t121, 0
  store i32 %t123, ptr %l76
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb37, label %ok.125, !prof !99
ok.125:
  store { i64, ptr } %t122, ptr %l75
  br label %bb36
bb36:
  %t126 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t126, ptr %l55, !tbaa !27
  br label %bb43
bb37:
  %t127 = load i32, ptr %l76, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  store i1 %t130, ptr %l78, !tbaa !21
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load ptr, ptr %l4, !tbaa !29
  store ptr %t131, ptr %l79, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 0
  store i64 0, ptr %t133
  %t134 = load { i64, [3 x i64] }, ptr %t132
  store { i64, [3 x i64] } %t134, ptr %l80
  %t135 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t136, ptr %l82, !tbaa !27
  %t137 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr { i64, ptr }, ptr %t138, i64 0
  %t140 = load { i64, ptr }, ptr %t139, !tbaa !37
  %t143 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDocNoItem(ptr %v1, ptr %v0, ptr %s1, { i64, ptr } %t135, { i64, ptr } %t140)
  store %"compiler/diagmsg:Msg" %t143, ptr %l84
  br label %bb39
bb39:
  %t144 = load ptr, ptr %l79, !tbaa !29
  %t145 = load { i64, [3 x i64] }, ptr %l80
  %t146 = load %"compiler/diagmsg:Msg", ptr %l84
  %t147 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %s1, ptr %s1, ptr %t144, { i64, [3 x i64] } %t145, %"compiler/diagmsg:Msg" %t146)
  store i64 %t147, ptr %l85
  br label %bb40
bb40:
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t150 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s1, ptr %s4, ptr %t148)
  store { i64, ptr } %t150, ptr %l87
  br label %bb41
bb41:
  %t151 = load { i64, ptr }, ptr %l87, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s4, { i64, ptr } %t151)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb43:
  %t154 = load { i64, ptr }, ptr %l55, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s3, { i64, ptr } %t154)
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb45:
  %t158 = load ptr, ptr %l5, !tbaa !29
  %t160 = getelementptr %"compiler/session:Analysis", ptr %t158, i32 0, i32 2
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t163 = icmp eq ptr %t161, null
  br i1 %t163, label %bb46, label %bb47
bb46:
  call void @__olang_check_failed(ptr @olang_loc_6636dd2b26b29868_9b4c1750690bee24)
  unreachable
bb47:
  br label %bb48
bb48:
  %t165 = load ptr, ptr %l5, !tbaa !29
  %t167 = getelementptr %"compiler/session:Analysis", ptr %t165, i32 0, i32 2
  %t168 = load ptr, ptr %t167, !tbaa !29
  store ptr %t168, ptr %l96, !tbaa !29
  %t169 = load ptr, ptr %l5, !tbaa !29
  %t171 = getelementptr %"compiler/session:Analysis", ptr %t169, i32 0, i32 3
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t174 = icmp eq ptr %t172, null
  br i1 %t174, label %bb49, label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_6636dd2b26b29868_9b4c1750690bee24)
  unreachable
bb50:
  br label %bb51
bb51:
  %t176 = load ptr, ptr %l5, !tbaa !29
  %t178 = getelementptr %"compiler/session:Analysis", ptr %t176, i32 0, i32 3
  %t179 = load ptr, ptr %t178, !tbaa !29
  store ptr %t179, ptr %l101, !tbaa !29
  %t180 = load ptr, ptr %l5, !tbaa !29
  %t182 = getelementptr %"compiler/session:Analysis", ptr %t180, i32 0, i32 4
  %t183 = load ptr, ptr %t182, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb52, label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_6636dd2b26b29868_9b4c1750690bee24)
  unreachable
bb53:
  br label %bb54
bb54:
  %t187 = load ptr, ptr %l5, !tbaa !29
  %t189 = getelementptr %"compiler/session:Analysis", ptr %t187, i32 0, i32 4
  %t190 = load ptr, ptr %t189, !tbaa !29
  %t191 = load ptr, ptr %l5, !tbaa !29
  %t193 = getelementptr %"compiler/session:Analysis", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/load:Loader", ptr %t194, i32 0, i32 12
  %t197 = load i64, ptr %t196, !tbaa !24
  %t198 = load ptr, ptr %l96, !tbaa !29
  %t199 = load ptr, ptr %l101, !tbaa !29
  %t202 = call %"compiler/doc:Module" @compiler_2fdoc_2eModule_2eOf(ptr %s1, ptr %s1, ptr %s1, ptr %s1, ptr %t198, ptr %t199, ptr %t190, i64 %t197, i1 false)
  store %"compiler/doc:Module" %t202, ptr %l110
  br label %bb55
bb55:
  %t203 = load %"compiler/doc:Module", ptr %l110
  %t204 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 80, i64 8)
  store %"compiler/doc:Module" %t203, ptr %t204
  %t206 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %s1, ptr %s1, ptr %t204)
  store { i64, ptr } %t206, ptr %l112
  br label %bb56
bb56:
  %t207 = load { i64, ptr }, ptr %l112, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t207)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb58:
  %t210 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t210, ptr %l115
  br label %bb59
bb59:
  %t211 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l115
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t211, ptr %l7
  %t212 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t212, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t214 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 0
  store i64 %t216, ptr %l10, !tbaa !24
  br label %bb60
bb60:
  %t218 = load i64, ptr %l9, !tbaa !24
  %t219 = load i64, ptr %l10, !tbaa !24
  %t222 = icmp slt i64 %t218, %t219
  %t224 = xor i1 %t222, true
  br i1 %t224, label %bb61, label %bb62
bb61:
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t226 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t226, ptr %l123, !tbaa !27
  %t227 = load i64, ptr %l9, !tbaa !24
  %t229 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t230 = load ptr, ptr %t229, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %t230, i64 %t227
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %l7, { i64, ptr } %t232)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t237 = load i64, ptr %l9, !tbaa !24
  %t240 = add i64 %t237, 1
  store i64 %t240, ptr %l9, !tbaa !24
  br label %bb60
bb66:
  %t243 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l7)
  store i64 %t243, ptr %l132
  br label %bb67
bb67:
  %t244 = load i64, ptr %l132, !tbaa !24
  %t245 = icmp eq i64 %t244, 0
  br i1 %t245, label %bb68, label %bb69
bb68:
  call void @compiler_2fsession_2estdModules(ptr %s0, ptr %l7)
  br label %bb70
bb69:
  br label %bb71
bb70:
  br label %bb71
bb71:
  %t248 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t250 = call i32 @std_2fos_2eMkDirAll(ptr %v2, { i64, ptr } %t248)
  store i32 %t250, ptr %l136
  %t251 = icmp ne i32 %t250, 0
  br i1 %t251, label %bb73, label %ok.252, !prof !99
ok.252:
  br label %bb72
bb72:
  br label %bb78
bb73:
  %t253 = load i32, ptr %l136, !tbaa !23
  %t254 = ashr i32 %t253, 16
  %t256 = icmp eq i32 %t254, 1
  store i1 %t256, ptr %l138, !tbaa !21
  %t257 = load i32, ptr %l136, !tbaa !23
  %t258 = ashr i32 %t257, 16
  %t260 = icmp eq i32 %t258, 1
  br i1 %t260, label %bb74, label %bb75
bb74:
  call void @__olang_errpay_pop()
  br label %bb75
bb75:
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s9
  %t262 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t263 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t266 = extractvalue { i64, ptr } %t262, 1
  %t267 = extractvalue { i64, ptr } %t262, 0
  %t268 = add i64 %t264, %t267
  %t269 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t271 = add i64 %t268, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t263, i64 %t264)
  %t273 = getelementptr i8, ptr %t272, i64 %t264
  call void @olang_textcopy(ptr %t273, ptr %t266, i64 %t267)
  %t274 = getelementptr i8, ptr %t273, i64 %t267
  call void @olang_textcopy(ptr %t274, ptr %t269, i64 %t270)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t272, 1
  call void @compiler_2fsession_2esay(ptr %s9, { i64, ptr } %t276)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb78:
  store i32 0, ptr %l12, !tbaa !23
  %t280 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t280, ptr %l145
  br label %bb79
bb79:
  %t281 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l145
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %l13
  store ptr %l7, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s12
  %t283 = load i64, ptr %l15, !tbaa !24
  store i64 %t283, ptr %l147, !tbaa !24
  %t284 = load ptr, ptr %l14, !tbaa !29
  %t286 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t284)
  store i64 %t286, ptr %l149
  br label %bb81
bb81:
  %t287 = load i64, ptr %l147, !tbaa !24
  %t288 = load i64, ptr %l149, !tbaa !24
  %t289 = icmp slt i64 %t287, %t288
  %t291 = xor i1 %t289, true
  br i1 %t291, label %bb82, label %bb83
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb105
bb83:
  br label %bb84
bb84:
  %t293 = load ptr, ptr %l14, !tbaa !29
  %t294 = load i64, ptr %l15, !tbaa !24
  %t297 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t293, i64 %t294)
  store { i64, ptr } %t297, ptr %l154
  br label %bb85
bb85:
  %t298 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t298, ptr %l16, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t301 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t302 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr null, i32 1
  %t303 = ptrtoint ptr %t302 to i64
  %t305 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t304, i32 0, i32 0
  store { i64, ptr } %t299, ptr %t305, !tbaa !28
  %t307 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t304, i32 0, i32 1
  store ptr %t300, ptr %t307, !tbaa !28
  %t309 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t304, i32 0, i32 2
  store { i64, ptr } %t301, ptr %t309, !tbaa !28
  call void @__olang_scope_escape(ptr %s0)
  %t311 = call ptr @__olang_scope_hold(ptr %s0)
  %t312 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t304, i32 0, i32 3
  store ptr %t311, ptr %t312, !tbaa !28
  call void @__olang_scope_escape(ptr %v3)
  %t313 = call ptr @__olang_scope_hold(ptr %v3)
  %t314 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t304, i32 0, i32 4
  store ptr %t313, ptr %t314, !tbaa !28
  call void @__olang_scope_escape(ptr %v2)
  %t315 = call ptr @__olang_scope_hold(ptr %v2)
  %t316 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %t304, i32 0, i32 5
  store ptr %t315, ptr %t316, !tbaa !28
  %t317 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_10, 0
  %t318 = insertvalue { ptr, ptr } %t317, ptr %t304, 1
  %t320 = extractvalue { ptr, ptr } %t318, 0
  %t321 = extractvalue { ptr, ptr } %t318, 1
  %t322 = call i32 @compiler_2fsession_2eInChild(ptr %s12, ptr %t320, ptr %t321)
  store i32 %t322, ptr %l159
  br label %bb86
bb86:
  %t323 = load i32, ptr %l159, !tbaa !23
  %t324 = icmp ne i32 %t323, 0
  br i1 %t324, label %bb87, label %bb88
bb87:
  store i32 1, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  br label %bb104
bb88:
  br label %bb89
bb89:
  %t326 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t328 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s12, { i64, ptr } %t326)
  %t329 = extractvalue { i32, { i64, ptr } } %t328, 1
  %t330 = extractvalue { i32, { i64, ptr } } %t328, 0
  store i32 %t330, ptr %l164
  %t331 = icmp ne i32 %t330, 0
  br i1 %t331, label %bb91, label %ok.332, !prof !99
ok.332:
  store { i64, ptr } %t329, ptr %l163
  br label %bb90
bb90:
  %t333 = load { i64, ptr }, ptr %l163, !tbaa !27
  store { i64, ptr } %t333, ptr %l161, !tbaa !27
  br label %bb95
bb91:
  %t334 = load i32, ptr %l164, !tbaa !23
  %t335 = ashr i32 %t334, 16
  %t337 = icmp eq i32 %t335, 1
  store i1 %t337, ptr %l166, !tbaa !21
  %t338 = load i32, ptr %l164, !tbaa !23
  %t339 = ashr i32 %t338, 16
  %t341 = icmp eq i32 %t339, 1
  br i1 %t341, label %bb92, label %bb93
bb92:
  call void @__olang_errpay_pop()
  br label %bb93
bb93:
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s12)
  br label %bb104
bb95:
  %t343 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t343, ptr %l17, !tbaa !27
  store ptr %l13, ptr %l169, !tbaa !29
  %t344 = call ptr @__olang_scope_hold(ptr %s0)
  %t345 = ptrtoint ptr %t344 to i64
  store i64 %t345, ptr %l170, !tbaa !24
  %t346 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e0
  br i1 %t346, label %bb96, label %bb97
bb96:
  %t348 = call ptr @__olang_region_make(ptr %s0)
  %t349 = ptrtoint ptr %t348 to i64
  store i64 %t349, ptr %l170, !tbaa !24
  br label %bb97
bb97:
  %t350 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t351 = load i64, ptr %l170
  %t352 = inttoptr i64 %t351 to ptr
  %t354 = call { i64, ptr } @compiler_2fsession_2eIdentityOf(ptr %s0, ptr %t352, { i64, ptr } %t350)
  store { i64, ptr } %t354, ptr %l173
  br label %bb98
bb98:
  %t355 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t355, ptr %l174, !tbaa !27
  %t356 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t356, ptr %l175, !tbaa !27
  %t357 = call ptr @__olang_scope_hold(ptr %s0)
  %t358 = ptrtoint ptr %t357 to i64
  store i64 %t358, ptr %l176, !tbaa !24
  %t359 = load i1, ptr @olang_2esole_2ecompiler_2fdoc_3aModule_2e2
  br i1 %t359, label %bb99, label %bb100
bb99:
  %t361 = call ptr @__olang_region_make(ptr %s0)
  %t362 = ptrtoint ptr %t361 to i64
  store i64 %t362, ptr %l176, !tbaa !24
  br label %bb100
bb100:
  %t363 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t364 = load i64, ptr %l176
  %t365 = inttoptr i64 %t364 to ptr
  %t367 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %s12, ptr %t365, { i64, ptr } %t363)
  store { i64, ptr } %t367, ptr %l179
  br label %bb101
bb101:
  %t368 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t369 = load i64, ptr %l176
  %t370 = inttoptr i64 %t369 to ptr
  %t371 = extractvalue { i64, ptr } %t368, 0
  %t372 = extractvalue { i64, ptr } %t368, 1
  %t373 = mul i64 %t371, 1
  %t374 = call ptr @__olang_held_alloc(ptr %t370, i64 %t373)
  call void @llvm.memcpy.p0.p0.i64(ptr %t374, ptr %t372, i64 %t373, i1 false)
  %t375 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t374, 1
  %t377 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t378 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t380 = call %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t377, { i64, ptr } %t378, { i64, ptr } %t376)
  store %"compiler/doc:Module" %t380, ptr %l181
  br label %bb102
bb102:
  %t381 = load ptr, ptr %l169, !tbaa !29
  %t382 = load %"compiler/doc:Module", ptr %l181
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ePush_3ccompiler_2fdoc_3aModule_3e(ptr %s0, ptr %s0, ptr %t381, %"compiler/doc:Module" %t382)
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s12)
  br label %bb104
bb104:
  %t383 = load i64, ptr %l15, !tbaa !24
  %t386 = add i64 %t383, 1
  store i64 %t386, ptr %l15, !tbaa !24
  br label %bb80
bb105:
  %t388 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_11, 0
  %t389 = insertvalue { ptr, ptr } %t388, ptr null, 1
  %t392 = extractvalue { ptr, ptr } %t389, 0
  %t393 = extractvalue { ptr, ptr } %t389, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eSort_3cco_Hfcfbe33647fb7db48e9022f22b0d44cf(ptr %s0, ptr %s0, ptr %l13, ptr %t392, ptr %t393)
  br label %bb106
bb106:
  %t394 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t396 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t394, 0
  %t397 = insertvalue [2 x { i64, ptr }] %t396, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  store [2 x { i64, ptr }] %t397, ptr %l18
  %t400 = insertvalue { i64, ptr } undef, i64 2, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %l18, 1
  %t403 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t401)
  store { i64, ptr } %t403, ptr %l191
  br label %bb107
bb107:
  %t404 = load { i64, ptr }, ptr %l191, !tbaa !27
  store { i64, ptr } %t404, ptr %l19, !tbaa !27
  %t405 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t405, ptr %l192, !tbaa !27
  %t406 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t408 = extractvalue { i64, ptr } %t406, 0
  %t410 = icmp eq i64 %t408, 0
  br i1 %t410, label %bb108, label %bb109
bb108:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l196, !tbaa !27
  br label %bb110
bb109:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l196, !tbaa !27
  br label %bb110
bb110:
  %t413 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eToArray_3ccompiler_2fdoc_3aModule_3e(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t413, ptr %l198
  br label %bb111
bb111:
  %t414 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t416 = call { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t414, { i64, ptr } %t415)
  store { i64, ptr } %t416, ptr %l199
  br label %bb112
bb112:
  %t417 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t417, 0
  %t420 = extractvalue { i64, ptr } %t417, 1
  %t421 = mul i64 %t419, 1
  %t422 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t421)
  call void @llvm.memcpy.p0.p0.i64(ptr %t422, ptr %t420, i64 %t421, i1 false)
  %t423 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t422, 1
  %t425 = load { i64, ptr }, ptr %l192, !tbaa !27
  %t427 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t425, { i64, ptr } %t424)
  store i32 %t427, ptr %l202
  %t428 = icmp ne i32 %t427, 0
  br i1 %t428, label %bb114, label %ok.429, !prof !99
ok.429:
  br label %bb113
bb113:
  br label %bb119
bb114:
  %t430 = load i32, ptr %l202, !tbaa !23
  %t431 = ashr i32 %t430, 16
  %t433 = icmp eq i32 %t431, 1
  store i1 %t433, ptr %l204, !tbaa !21
  %t434 = load i32, ptr %l202, !tbaa !23
  %t435 = ashr i32 %t434, 16
  %t437 = icmp eq i32 %t435, 1
  br i1 %t437, label %bb115, label %bb116
bb115:
  call void @__olang_errpay_pop()
  br label %bb116
bb116:
  br label %bb117
bb117:
  store %olang.scope zeroinitializer, ptr %s16
  %t439 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t440 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t441 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t443 = extractvalue { i64, ptr } %t439, 1
  %t444 = extractvalue { i64, ptr } %t439, 0
  %t445 = add i64 %t441, %t444
  %t446 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t447 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t448 = add i64 %t445, %t447
  %t449 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t448)
  call void @olang_textcopy(ptr %t449, ptr %t440, i64 %t441)
  %t450 = getelementptr i8, ptr %t449, i64 %t441
  call void @olang_textcopy(ptr %t450, ptr %t443, i64 %t444)
  %t451 = getelementptr i8, ptr %t450, i64 %t444
  call void @olang_textcopy(ptr %t451, ptr %t446, i64 %t447)
  %t452 = insertvalue { i64, ptr } undef, i64 %t448, 0
  %t453 = insertvalue { i64, ptr } %t452, ptr %t449, 1
  call void @compiler_2fsession_2esay(ptr %s16, { i64, ptr } %t453)
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb119:
  %t457 = load i32, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t457, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2eHold(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l6 = alloca i1
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca i64
  %l9 = alloca ptr
  %l13 = alloca i1
  %l18 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l32 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l46 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l47 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l49 = alloca i64
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l65 = alloca i64
  %l82 = alloca ptr
  %l87 = alloca i1
  %l95 = alloca i64
  %l97 = alloca i1
  %l100 = alloca i64
  %l117 = alloca i64
  %l130 = alloca ptr
  %l137 = alloca %"compiler/interp:Exec"
  %l139 = alloca ptr
  %l140 = alloca i64
  %l147 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l148 = alloca i64
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %l156 = alloca i64
  %l158 = alloca { i64, ptr }
  %l159 = alloca i64
  %l160 = alloca { i64, ptr }
  %l164 = alloca i64
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l168 = alloca { i64, ptr }
  %l173 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %s0 = alloca %olang.scope
  %t358 = alloca %"compiler/interp:Exec", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb3
bb2:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/session:Analysis", ptr %t8, i32 0, i32 3
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t13 = icmp eq ptr %t11, null
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb3
bb3:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb7
bb5:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/session:Analysis", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  %t23 = getelementptr %"compiler/load:Loader", ptr %t21, i32 0, i32 4
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t26 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %t24)
  store i1 %t26, ptr %l22
  br label %bb6
bb6:
  %t27 = load i1, ptr %l22, !tbaa !21
  store i1 %t27, ptr %l18, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l18, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb9:
  br label %bb10
bb10:
  %t29 = call i64 @std_2ftime_2eNow()
  store i64 %t29, ptr %l23
  br label %bb11
bb11:
  %t30 = load i64, ptr %l23, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/session:Analysis", ptr %t31, i32 0, i32 2
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l3, !tbaa !29
  %t36 = load ptr, ptr %l3, !tbaa !29
  %t38 = icmp eq ptr %t36, null
  br i1 %t38, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_35f6bc648a66c5f9_fb290a2b6e993705)
  unreachable
bb13:
  br label %bb14
bb14:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call ptr @compiler_2fsession_2escoper(ptr %v0, ptr %v0, ptr %t40)
  store ptr %t42, ptr %l29
  br label %bb15
bb15:
  %t43 = load ptr, ptr %l29, !tbaa !29
  store ptr %t43, ptr %l4, !tbaa !29
  %t44 = call ptr @__olang_scope_hold(ptr %s0)
  %t45 = ptrtoint ptr %t44 to i64
  store i64 %t45, ptr %l30, !tbaa !24
  %t46 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eHold_2elocal_2e5
  br i1 %t46, label %bb16, label %bb17
bb16:
  %t48 = call ptr @__olang_region_make(ptr %s0)
  %t49 = ptrtoint ptr %t48 to i64
  store i64 %t49, ptr %l30, !tbaa !24
  br label %bb17
bb17:
  %t50 = load i64, ptr %l30
  %t51 = inttoptr i64 %t50 to ptr
  %t52 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %t51)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t52, ptr %l32
  br label %bb18
bb18:
  %t53 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eHold_2elocal_2e5
  br i1 %t53, label %bb19, label %bb20
bb19:
  %t55 = load i64, ptr %l30
  %t56 = inttoptr i64 %t55 to ptr
  %t57 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 2
  %t58 = load { i64, ptr }, ptr %t57
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = call ptr @__olang_region_or(ptr %t59, ptr null)
  %t61 = call ptr @__olang_region_home(ptr %t60)
  %t62 = icmp ne ptr %t61, null
  %t63 = select i1 %t62, ptr %t61, ptr null
  %t64 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = call ptr @__olang_region_or(ptr %t66, ptr null)
  %t68 = call ptr @__olang_region_home(ptr %t67)
  %t69 = icmp ne ptr %t68, null
  %t70 = select i1 %t69, ptr %t68, ptr %t63
  %t71 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = call ptr @__olang_region_or(ptr %t73, ptr null)
  %t75 = call ptr @__olang_region_home(ptr %t74)
  %t76 = icmp ne ptr %t75, null
  %t77 = select i1 %t76, ptr %t75, ptr %t70
  call void @__olang_region_settle_in(ptr %t56, ptr %t77)
  br label %bb20
bb20:
  %t78 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l32
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t78, ptr %l5
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/session:Analysis", ptr %t79, i32 0, i32 1
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t86 = icmp sgt i64 %t84, 0
  store i1 %t86, ptr %l6, !tbaa !21
  %t88 = load i1, ptr %l6, !tbaa !21
  br i1 %t88, label %bb21, label %bb22
bb21:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  br i1 %t92, label %bb23, label %bb24
bb22:
  br label %bb42
bb23:
  call void @__olang_check_failed(ptr @olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e)
  unreachable
bb24:
  br label %bb25
bb25:
  %t94 = load ptr, ptr %l3, !tbaa !29
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/session:Analysis", ptr %t96, i32 0, i32 1
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t105 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2frecords_2eScopeRecords(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %v0, ptr %t94, ptr %t95, { i64, ptr } %t99, ptr %t100)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t105, ptr %l46
  br label %bb26
bb26:
  %t106 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l5
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t106, ptr %l47
  %t107 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l46
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t107, ptr %l5
  %t108 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eHold_2elocal_2e5
  br i1 %t108, label %bb27, label %bb28
bb27:
  %t110 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = call ptr @__olang_region_or(ptr %t112, ptr null)
  %t114 = call ptr @__olang_region_home(ptr %t113)
  %t115 = icmp ne ptr %t114, null
  %t116 = select i1 %t115, ptr %t114, ptr null
  %t117 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = call ptr @__olang_region_or(ptr %t119, ptr null)
  %t121 = call ptr @__olang_region_home(ptr %t120)
  %t122 = icmp ne ptr %t121, null
  %t123 = select i1 %t122, ptr %t121, ptr %t116
  %t124 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 0
  %t125 = load { i64, ptr }, ptr %t124
  %t126 = extractvalue { i64, ptr } %t125, 1
  %t127 = call ptr @__olang_region_or(ptr %t126, ptr null)
  %t128 = call ptr @__olang_region_home(ptr %t127)
  %t129 = icmp ne ptr %t128, null
  %t130 = select i1 %t129, ptr %t128, ptr %t123
  call void @__olang_region_drop(ptr %t130)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l47
  br label %bb28
bb28:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb29
bb29:
  %t131 = load i64, ptr %l49, !tbaa !24
  %t132 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 3
  %t133 = load i64, ptr %t132, !tbaa !24
  %t134 = icmp slt i64 %t131, %t133
  br i1 %t134, label %bb30, label %bb31
bb30:
  %t136 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 1
  %t137 = load i64, ptr %l49, !tbaa !24
  %t138 = getelementptr { i64, ptr }, ptr %t136, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr i64, ptr %t139, i64 %t137
  %t141 = load i64, ptr %t140, !tbaa !34
  %t142 = icmp sge i64 %t141, -1
  br i1 %t142, label %bb32, label %bb33
bb31:
  %t144 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e0
  br i1 %t144, label %bb36, label %bb37
bb32:
  %t146 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t146, label %bb34, label %bb35
bb33:
  %t148 = load i64, ptr %l49, !tbaa !24
  %t149 = add i64 %t148, 1
  store i64 %t149, ptr %l49, !tbaa !24
  br label %bb29
bb34:
  %t150 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 0
  %t151 = load i64, ptr %l49, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t153, i64 %t151
  %t155 = getelementptr %"std/prelude/map:MapEntry.8d509622153b47f1a5f79c42c8367406", ptr %t154, i32 0, i32 1
  %t156 = load { i64, ptr }, ptr %t155
  %t157 = extractvalue { i64, ptr } %t156, 1
  call void @__olang_region_release(ptr %t157)
  store { i64, ptr } zeroinitializer, ptr %t155
  br label %bb35
bb35:
  br label %bb33
bb36:
  %t158 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 0
  %t159 = load { i64, ptr }, ptr %t158
  %t160 = extractvalue { i64, ptr } %t159, 0
  %t161 = extractvalue { i64, ptr } %t159, 1
  call void @__olang_region_release_part(ptr %t161, i64 %t160)
  store { i64, ptr } zeroinitializer, ptr %t158
  br label %bb37
bb37:
  %t162 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1
  br i1 %t162, label %bb38, label %bb39
bb38:
  %t164 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 1
  %t165 = load { i64, ptr }, ptr %t164
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  call void @__olang_region_release_part(ptr %t167, i64 %t166)
  store { i64, ptr } zeroinitializer, ptr %t164
  br label %bb39
bb39:
  %t168 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e2
  br i1 %t168, label %bb40, label %bb41
bb40:
  %t170 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l47, i32 0, i32 2
  %t171 = load { i64, ptr }, ptr %t170
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t173 = extractvalue { i64, ptr } %t171, 1
  call void @__olang_region_release_part(ptr %t173, i64 %t172)
  store { i64, ptr } zeroinitializer, ptr %t170
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t174 = load ptr, ptr %l4, !tbaa !29
  %t176 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eFieldMarks(ptr %v0, ptr %s0, ptr %t174)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %l57
  br label %bb43
bb43:
  %t177 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t177, ptr %l7
  %t178 = load ptr, ptr %l3, !tbaa !29
  %t180 = icmp eq ptr %t178, null
  br i1 %t180, label %bb44, label %bb45
bb44:
  call void @__olang_check_failed(ptr @olang_loc_6f935d255f99d513_bebfb26ca618488f)
  unreachable
bb45:
  br label %bb46
bb46:
  %t182 = load ptr, ptr %l3, !tbaa !29
  %t185 = getelementptr %"compiler/check:Checker", ptr %t182, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !29
  %t188 = getelementptr %"compiler/generic:Program", ptr %t186, i32 0, i32 0
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/load:Loader", ptr %t189, i32 0, i32 4
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %t192)
  store i64 %t194, ptr %l65
  br label %bb47
bb47:
  %t195 = load i64, ptr %l65, !tbaa !24
  store i64 %t195, ptr %l8, !tbaa !24
  %t196 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %t196)
  br label %bb48
bb48:
  %t198 = load ptr, ptr %l4, !tbaa !29
  %t200 = getelementptr %"compiler/scope:Scoper", ptr %t198, i32 0, i32 305
  %t201 = load i1, ptr %t200, !tbaa !21
  br i1 %t201, label %bb49, label %bb50
bb49:
  %t203 = load ptr, ptr %l3, !tbaa !29
  %t205 = icmp eq ptr %t203, null
  br i1 %t205, label %bb51, label %bb52
bb50:
  br label %bb61
bb51:
  call void @__olang_check_failed(ptr @olang_loc_9e4e38a802f76144_ff726f2d97618db0)
  unreachable
bb52:
  br label %bb53
bb53:
  %t207 = load ptr, ptr %l3, !tbaa !29
  %t210 = getelementptr %"compiler/check:Checker", ptr %t207, i32 0, i32 1
  %t211 = load ptr, ptr %t210, !tbaa !29
  %t213 = getelementptr %"compiler/generic:Program", ptr %t211, i32 0, i32 0
  %t214 = load ptr, ptr %t213, !tbaa !29
  %t216 = getelementptr %"compiler/load:Loader", ptr %t214, i32 0, i32 4
  %t217 = load ptr, ptr %t216, !tbaa !29
  %t218 = load i64, ptr %l8, !tbaa !24
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %t217, i64 %t218, i64 -1)
  br label %bb54
bb54:
  %t221 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eSetFieldMarks(ptr %v0, ptr %s0, ptr %t221, ptr %l7)
  br label %bb55
bb55:
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t226 = icmp eq ptr %t224, null
  br i1 %t226, label %bb56, label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_80db4b4ab4bdeb95_d8fc8731110a3729)
  unreachable
bb57:
  br label %bb58
bb58:
  %t228 = load ptr, ptr %l3, !tbaa !29
  %t230 = call ptr @compiler_2fsession_2escoper(ptr %v0, ptr %v0, ptr %t228)
  store ptr %t230, ptr %l82
  br label %bb59
bb59:
  %t231 = load ptr, ptr %l82, !tbaa !29
  store ptr %t231, ptr %l4, !tbaa !29
  %t232 = load ptr, ptr %l4, !tbaa !29
  %t233 = load i1, ptr %l6, !tbaa !21
  %t236 = getelementptr %"compiler/scope:Scoper", ptr %t232, i32 0, i32 291
  store i1 %t233, ptr %t236, !tbaa !21
  %t237 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %t237)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t239 = load i1, ptr %l6, !tbaa !21
  br i1 %t239, label %bb62, label %bb63
bb62:
  %t241 = load ptr, ptr %l3, !tbaa !29
  %t243 = icmp eq ptr %t241, null
  br i1 %t243, label %bb64, label %bb65
bb63:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb68
bb64:
  call void @__olang_check_failed(ptr @olang_loc_75f06ede6c99afee_aaf5c12ecba84b42)
  unreachable
bb65:
  br label %bb66
bb66:
  %t245 = load ptr, ptr %l3, !tbaa !29
  %t248 = getelementptr %"compiler/check:Checker", ptr %t245, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !29
  %t251 = getelementptr %"compiler/generic:Program", ptr %t249, i32 0, i32 0
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t254 = getelementptr %"compiler/load:Loader", ptr %t252, i32 0, i32 4
  %t255 = load ptr, ptr %t254, !tbaa !29
  %t257 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t255)
  store i64 %t257, ptr %l95
  br label %bb67
bb67:
  %t258 = load i64, ptr %l95, !tbaa !24
  %t259 = icmp eq i64 %t258, 0
  store i1 %t259, ptr %l87, !tbaa !21
  br label %bb68
bb68:
  %t261 = load i1, ptr %l87, !tbaa !21
  br i1 %t261, label %bb69, label %bb70
bb69:
  %t262 = load ptr, ptr %l4, !tbaa !29
  %t264 = getelementptr %"compiler/scope:Scoper", ptr %t262, i32 0, i32 3
  %t266 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %t264)
  store i64 %t266, ptr %l100
  br label %bb71
bb70:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb72
bb71:
  %t267 = load i64, ptr %l100, !tbaa !24
  %t268 = icmp eq i64 %t267, 0
  store i1 %t268, ptr %l97, !tbaa !21
  br label %bb72
bb72:
  %t270 = load i1, ptr %l97, !tbaa !21
  br i1 %t270, label %bb73, label %bb74
bb73:
  %t271 = load ptr, ptr %l3, !tbaa !29
  %t273 = icmp eq ptr %t271, null
  br i1 %t273, label %bb75, label %bb76
bb74:
  br label %bb79
bb75:
  call void @__olang_check_failed(ptr @olang_loc_75f06ede6c99afee_aaf5c12ecba84b42)
  unreachable
bb76:
  br label %bb77
bb77:
  %t275 = load ptr, ptr %l3, !tbaa !29
  %t276 = load ptr, ptr %l1, !tbaa !29
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/session:Analysis", ptr %t277, i32 0, i32 1
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  %t281 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2frecords_2eKeepScope(ptr %v0, ptr %v1, ptr %v0, ptr %v0, ptr %s0, ptr %t275, ptr %t276, { i64, ptr } %t280, ptr %t281, ptr %l5)
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t287 = load i1, ptr %l6, !tbaa !21
  br i1 %t287, label %bb80, label %bb81
bb80:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t292 = getelementptr %"compiler/session:Analysis", ptr %t290, i32 0, i32 0
  %t293 = load ptr, ptr %t292, !tbaa !29
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t296 = getelementptr %"compiler/session:Analysis", ptr %t294, i32 0, i32 1
  %t297 = load { i64, ptr }, ptr %t296, !tbaa !27
  call void @compiler_2frecords_2eTrimRecords(ptr %v1, ptr %v0, ptr %v0, ptr %t289, ptr %t293, { i64, ptr } %t297)
  br label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb83
bb83:
  %t301 = load i64, ptr %l2, !tbaa !24
  %t303 = call i64 @std_2ftime_2eSince(i64 %t301)
  store i64 %t303, ptr %l117
  br label %bb84
bb84:
  %t304 = load i64, ptr %l117, !tbaa !24
  %t305 = sdiv i64 %t304, 1000000
  %t306 = load ptr, ptr %l4, !tbaa !29
  %t308 = getelementptr %"compiler/scope:Scoper", ptr %t306, i32 0, i32 294
  %t309 = load i64, ptr %t308, !tbaa !24
  %t310 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t313 = call i64 @__olang_fmt_i64(ptr null, i64 %t305)
  %t314 = add i64 %t311, %t313
  %t315 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t316 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t317 = add i64 %t314, %t316
  %t319 = call i64 @__olang_fmt_i64(ptr null, i64 %t309)
  %t320 = add i64 %t317, %t319
  %t321 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t322 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t323 = add i64 %t320, %t322
  %t324 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t323)
  call void @olang_textcopy(ptr %t324, ptr %t310, i64 %t311)
  %t325 = getelementptr i8, ptr %t324, i64 %t311
  %t326 = call i64 @__olang_fmt_i64(ptr %t325, i64 %t305)
  %t327 = getelementptr i8, ptr %t325, i64 %t313
  call void @olang_textcopy(ptr %t327, ptr %t315, i64 %t316)
  %t328 = getelementptr i8, ptr %t327, i64 %t316
  %t329 = call i64 @__olang_fmt_i64(ptr %t328, i64 %t309)
  %t330 = getelementptr i8, ptr %t328, i64 %t319
  call void @olang_textcopy(ptr %t330, ptr %t321, i64 %t322)
  %t331 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t324, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t332)
  br label %bb85
bb85:
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t336 = load ptr, ptr %l4, !tbaa !29
  %t340 = getelementptr %"compiler/session:Analysis", ptr %t335, i32 0, i32 3
  store ptr %t336, ptr %t340, !tbaa !29
  %t341 = load ptr, ptr %l3, !tbaa !29
  %t343 = icmp eq ptr %t341, null
  br i1 %t343, label %bb86, label %bb87
bb86:
  call void @__olang_check_failed(ptr @olang_loc_71e3f151f76f601f_4a33fa6849f13ac3)
  unreachable
bb87:
  br label %bb88
bb88:
  %t345 = load ptr, ptr %l3, !tbaa !29
  %t348 = getelementptr %"compiler/check:Checker", ptr %t345, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !29
  store ptr %t349, ptr %l130, !tbaa !29
  %t350 = load ptr, ptr %l3, !tbaa !29
  %t352 = icmp eq ptr %t350, null
  br i1 %t352, label %bb89, label %bb90
bb89:
  call void @__olang_check_failed(ptr @olang_loc_71e3f151f76f601f_4a33fa6849f13ac3)
  unreachable
bb90:
  br label %bb91
bb91:
  %t354 = load ptr, ptr %l3, !tbaa !29
  %t357 = getelementptr %"compiler/check:Checker", ptr %t354, i32 0, i32 19
  %t359 = load ptr, ptr %l130, !tbaa !29
  call void @compiler_2finterp_3aExec_2ector(ptr %t358, ptr %v0, ptr %v0, ptr %v0, ptr %t359, ptr %t357, i32 0)
  call void @llvm.memmove.p0.p0.i64(ptr %l137, ptr %t358, i64 7352, i1 false)
  br label %bb92
bb92:
  %t362 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 7352, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t362, ptr %l137, i64 7352, i1 false)
  store ptr %t362, ptr %l9, !tbaa !29
  %t364 = load ptr, ptr %l9, !tbaa !29
  store ptr %t364, ptr %l139, !tbaa !29
  %t365 = call ptr @__olang_scope_hold(ptr %v0)
  %t366 = ptrtoint ptr %t365 to i64
  store i64 %t366, ptr %l140, !tbaa !24
  %t367 = load i1, ptr @olang_2esole_2ecompiler_2finterp_3aExec_2e10
  br i1 %t367, label %bb93, label %bb94
bb93:
  %t369 = call ptr @__olang_region_make(ptr %v0)
  %t370 = ptrtoint ptr %t369 to i64
  store i64 %t370, ptr %l140, !tbaa !24
  br label %bb94
bb94:
  %t371 = load ptr, ptr %l3, !tbaa !29
  %t373 = icmp eq ptr %t371, null
  br i1 %t373, label %bb95, label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_cfd81b6845724380_171723f1f2963534)
  unreachable
bb96:
  br label %bb97
bb97:
  %t375 = load ptr, ptr %l3, !tbaa !29
  %t378 = getelementptr %"compiler/check:Checker", ptr %t375, i32 0, i32 163
  %t379 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t378
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t379, ptr %l147
  %t381 = load i64, ptr %l140
  %t382 = inttoptr i64 %t381 to ptr
  %t383 = call ptr @__olang_scope_hold(ptr %t382)
  %t384 = ptrtoint ptr %t383 to i64
  store i64 %t384, ptr %l148, !tbaa !24
  %t385 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e0
  br i1 %t385, label %bb98, label %bb99
bb98:
  %t387 = load i64, ptr %l140
  %t388 = inttoptr i64 %t387 to ptr
  %t389 = call ptr @__olang_region_make_part(ptr %t388)
  %t390 = ptrtoint ptr %t389 to i64
  store i64 %t390, ptr %l148, !tbaa !24
  br label %bb99
bb99:
  %t391 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 0
  %t392 = load { i64, ptr }, ptr %t391, !tbaa !27
  store { i64, ptr } %t392, ptr %l150, !tbaa !27
  %t393 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t394 = extractvalue { i64, ptr } %t393, 0
  store i64 %t394, ptr %l151, !tbaa !24
  %t395 = load i64, ptr %l151, !tbaa !24
  %t396 = mul i64 %t395, 16
  %t397 = load i64, ptr %l148
  %t398 = inttoptr i64 %t397 to ptr
  %t399 = call ptr @__olang_held_alloc(ptr %t398, i64 %t396)
  %t400 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  store { i64, ptr } %t401, ptr %l152, !tbaa !27
  %t402 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t405 = load ptr, ptr %t404, !tbaa !27
  %t406 = load i64, ptr %l151, !tbaa !24
  %t407 = mul i64 %t406, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t403, ptr %t405, i64 %t407, i1 false)
  %t408 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t409 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 0
  store { i64, ptr } %t408, ptr %t409, !tbaa !27
  %t410 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e0
  br i1 %t410, label %bb100, label %bb101
bb100:
  %t412 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 0
  %t413 = load { i64, ptr }, ptr %t412, !tbaa !27
  %t414 = extractvalue { i64, ptr } %t413, 0
  %t416 = icmp eq i64 %t414, 0
  br i1 %t416, label %bb102, label %bb103
bb101:
  %t418 = load i64, ptr %l140
  %t419 = inttoptr i64 %t418 to ptr
  %t420 = call ptr @__olang_scope_hold(ptr %t419)
  %t421 = ptrtoint ptr %t420 to i64
  store i64 %t421, ptr %l156, !tbaa !24
  %t422 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e1
  br i1 %t422, label %bb104, label %bb105
bb102:
  %t424 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 0
  store { i64, ptr } zeroinitializer, ptr %t424, !tbaa !27
  br label %bb103
bb103:
  %t425 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 0
  %t426 = load i64, ptr %l148
  %t427 = inttoptr i64 %t426 to ptr
  %t428 = load { i64, ptr }, ptr %t425
  %t429 = extractvalue { i64, ptr } %t428, 1
  %t430 = call ptr @__olang_region_or(ptr %t429, ptr null)
  %t431 = icmp ne ptr %t430, null
  %t432 = select i1 %t431, ptr %t430, ptr null
  call void @__olang_region_settle_in(ptr %t427, ptr %t432)
  br label %bb101
bb104:
  %t433 = load i64, ptr %l140
  %t434 = inttoptr i64 %t433 to ptr
  %t435 = call ptr @__olang_region_make_part(ptr %t434)
  %t436 = ptrtoint ptr %t435 to i64
  store i64 %t436, ptr %l156, !tbaa !24
  br label %bb105
bb105:
  %t437 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 1
  %t438 = load { i64, ptr }, ptr %t437, !tbaa !27
  store { i64, ptr } %t438, ptr %l158, !tbaa !27
  %t439 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t440 = extractvalue { i64, ptr } %t439, 0
  store i64 %t440, ptr %l159, !tbaa !24
  %t441 = load i64, ptr %l159, !tbaa !24
  %t442 = mul i64 %t441, 8
  %t443 = load i64, ptr %l156
  %t444 = inttoptr i64 %t443 to ptr
  %t445 = call ptr @__olang_held_alloc(ptr %t444, i64 %t442)
  %t446 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  store { i64, ptr } %t447, ptr %l160, !tbaa !27
  %t448 = getelementptr { i64, ptr }, ptr %l160, i32 0, i32 1
  %t449 = load ptr, ptr %t448, !tbaa !27
  %t450 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = load i64, ptr %l159, !tbaa !24
  %t453 = mul i64 %t452, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t449, ptr %t451, i64 %t453, i1 false)
  %t454 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t455 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 1
  store { i64, ptr } %t454, ptr %t455, !tbaa !27
  %t456 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e1
  br i1 %t456, label %bb106, label %bb107
bb106:
  %t458 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 1
  %t459 = load { i64, ptr }, ptr %t458, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t459, 0
  %t462 = icmp eq i64 %t460, 0
  br i1 %t462, label %bb108, label %bb109
bb107:
  %t464 = load i64, ptr %l140
  %t465 = inttoptr i64 %t464 to ptr
  %t466 = call ptr @__olang_scope_hold(ptr %t465)
  %t467 = ptrtoint ptr %t466 to i64
  store i64 %t467, ptr %l164, !tbaa !24
  %t468 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e2
  br i1 %t468, label %bb110, label %bb111
bb108:
  %t470 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 1
  store { i64, ptr } zeroinitializer, ptr %t470, !tbaa !27
  br label %bb109
bb109:
  %t471 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 1
  %t472 = load i64, ptr %l156
  %t473 = inttoptr i64 %t472 to ptr
  %t474 = load { i64, ptr }, ptr %t471
  %t475 = extractvalue { i64, ptr } %t474, 1
  %t476 = call ptr @__olang_region_or(ptr %t475, ptr null)
  %t477 = icmp ne ptr %t476, null
  %t478 = select i1 %t477, ptr %t476, ptr null
  call void @__olang_region_settle_in(ptr %t473, ptr %t478)
  br label %bb107
bb110:
  %t479 = load i64, ptr %l140
  %t480 = inttoptr i64 %t479 to ptr
  %t481 = call ptr @__olang_region_make_part(ptr %t480)
  %t482 = ptrtoint ptr %t481 to i64
  store i64 %t482, ptr %l164, !tbaa !24
  br label %bb111
bb111:
  %t483 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 2
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !27
  store { i64, ptr } %t484, ptr %l166, !tbaa !27
  %t485 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t485, 0
  store i64 %t486, ptr %l167, !tbaa !24
  %t487 = load i64, ptr %l167, !tbaa !24
  %t488 = mul i64 %t487, 8
  %t489 = load i64, ptr %l164
  %t490 = inttoptr i64 %t489 to ptr
  %t491 = call ptr @__olang_held_alloc(ptr %t490, i64 %t488)
  %t492 = insertvalue { i64, ptr } undef, i64 %t487, 0
  %t493 = insertvalue { i64, ptr } %t492, ptr %t491, 1
  store { i64, ptr } %t493, ptr %l168, !tbaa !27
  %t494 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t495 = load ptr, ptr %t494, !tbaa !27
  %t496 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t497 = load ptr, ptr %t496, !tbaa !27
  %t498 = load i64, ptr %l167, !tbaa !24
  %t499 = mul i64 %t498, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t495, ptr %t497, i64 %t499, i1 false)
  %t500 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t501 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 2
  store { i64, ptr } %t500, ptr %t501, !tbaa !27
  %t502 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e2
  br i1 %t502, label %bb112, label %bb113
bb112:
  %t504 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 2
  %t505 = load { i64, ptr }, ptr %t504, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 0
  %t508 = icmp eq i64 %t506, 0
  br i1 %t508, label %bb114, label %bb115
bb113:
  %t510 = load i1, ptr @olang_2esole_2ecompiler_2finterp_3aExec_2e10
  br i1 %t510, label %bb116, label %bb117
bb114:
  %t512 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 2
  store { i64, ptr } zeroinitializer, ptr %t512, !tbaa !27
  br label %bb115
bb115:
  %t513 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 2
  %t514 = load i64, ptr %l164
  %t515 = inttoptr i64 %t514 to ptr
  %t516 = load { i64, ptr }, ptr %t513
  %t517 = extractvalue { i64, ptr } %t516, 1
  %t518 = call ptr @__olang_region_or(ptr %t517, ptr null)
  %t519 = icmp ne ptr %t518, null
  %t520 = select i1 %t519, ptr %t518, ptr null
  call void @__olang_region_settle_in(ptr %t515, ptr %t520)
  br label %bb113
bb116:
  %t521 = load i64, ptr %l140
  %t522 = inttoptr i64 %t521 to ptr
  %t523 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 2
  %t524 = load { i64, ptr }, ptr %t523
  %t525 = extractvalue { i64, ptr } %t524, 1
  %t526 = call ptr @__olang_region_or(ptr %t525, ptr null)
  %t527 = call ptr @__olang_region_home(ptr %t526)
  %t528 = icmp ne ptr %t527, null
  %t529 = select i1 %t528, ptr %t527, ptr null
  %t530 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 1
  %t531 = load { i64, ptr }, ptr %t530
  %t532 = extractvalue { i64, ptr } %t531, 1
  %t533 = call ptr @__olang_region_or(ptr %t532, ptr null)
  %t534 = call ptr @__olang_region_home(ptr %t533)
  %t535 = icmp ne ptr %t534, null
  %t536 = select i1 %t535, ptr %t534, ptr %t529
  %t537 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147, i32 0, i32 0
  %t538 = load { i64, ptr }, ptr %t537
  %t539 = extractvalue { i64, ptr } %t538, 1
  %t540 = call ptr @__olang_region_or(ptr %t539, ptr null)
  %t541 = call ptr @__olang_region_home(ptr %t540)
  %t542 = icmp ne ptr %t541, null
  %t543 = select i1 %t542, ptr %t541, ptr %t536
  call void @__olang_region_settle_in(ptr %t522, ptr %t543)
  br label %bb117
bb117:
  %t544 = load ptr, ptr %l139, !tbaa !29
  %t545 = getelementptr %"compiler/interp:Exec", ptr %t544, i32 0, i32 10
  %t546 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t545
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t546, ptr %l173
  %t547 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l147
  %t548 = load ptr, ptr %l139, !tbaa !29
  %t549 = getelementptr %"compiler/interp:Exec", ptr %t548, i32 0, i32 10
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t547, ptr %t549
  %t550 = load i1, ptr @olang_2esole_2ecompiler_2finterp_3aExec_2e10
  br i1 %t550, label %bb118, label %bb119
bb118:
  %t552 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173, i32 0, i32 2
  %t553 = load { i64, ptr }, ptr %t552
  %t554 = extractvalue { i64, ptr } %t553, 1
  %t555 = call ptr @__olang_region_or(ptr %t554, ptr null)
  %t556 = call ptr @__olang_region_home(ptr %t555)
  %t557 = icmp ne ptr %t556, null
  %t558 = select i1 %t557, ptr %t556, ptr null
  %t559 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173, i32 0, i32 1
  %t560 = load { i64, ptr }, ptr %t559
  %t561 = extractvalue { i64, ptr } %t560, 1
  %t562 = call ptr @__olang_region_or(ptr %t561, ptr null)
  %t563 = call ptr @__olang_region_home(ptr %t562)
  %t564 = icmp ne ptr %t563, null
  %t565 = select i1 %t564, ptr %t563, ptr %t558
  %t566 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173, i32 0, i32 0
  %t567 = load { i64, ptr }, ptr %t566
  %t568 = extractvalue { i64, ptr } %t567, 1
  %t569 = call ptr @__olang_region_or(ptr %t568, ptr null)
  %t570 = call ptr @__olang_region_home(ptr %t569)
  %t571 = icmp ne ptr %t570, null
  %t572 = select i1 %t571, ptr %t570, ptr %t565
  call void @__olang_region_drop(ptr %t572)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" zeroinitializer, ptr %l173
  br label %bb119
bb119:
  %t573 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e0
  br i1 %t573, label %bb120, label %bb121
bb120:
  %t575 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173, i32 0, i32 0
  %t576 = load { i64, ptr }, ptr %t575
  %t577 = extractvalue { i64, ptr } %t576, 0
  %t578 = extractvalue { i64, ptr } %t576, 1
  call void @__olang_region_release_part(ptr %t578, i64 %t577)
  store { i64, ptr } zeroinitializer, ptr %t575
  br label %bb121
bb121:
  %t579 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e1
  br i1 %t579, label %bb122, label %bb123
bb122:
  %t581 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173, i32 0, i32 1
  %t582 = load { i64, ptr }, ptr %t581
  %t583 = extractvalue { i64, ptr } %t582, 0
  %t584 = extractvalue { i64, ptr } %t582, 1
  call void @__olang_region_release_part(ptr %t584, i64 %t583)
  store { i64, ptr } zeroinitializer, ptr %t581
  br label %bb123
bb123:
  %t585 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e2
  br i1 %t585, label %bb124, label %bb125
bb124:
  %t587 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l173, i32 0, i32 2
  %t588 = load { i64, ptr }, ptr %t587
  %t589 = extractvalue { i64, ptr } %t588, 0
  %t590 = extractvalue { i64, ptr } %t588, 1
  call void @__olang_region_release_part(ptr %t590, i64 %t589)
  store { i64, ptr } zeroinitializer, ptr %t587
  br label %bb125
bb125:
  %t591 = load ptr, ptr %l0, !tbaa !29
  %t592 = load ptr, ptr %l9, !tbaa !29
  %t596 = getelementptr %"compiler/session:Analysis", ptr %t591, i32 0, i32 4
  store ptr %t592, ptr %t596, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fsession_2eIdentityOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %lp6 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca i64
  %l30 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l38 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l52 = alloca i1
  %l53 = alloca i64
  %l57 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l65 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l72 = alloca i1
  %l74 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t5, ptr %l9
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t8 = call { i64, ptr } @compiler_2fsession_2eRealOf(ptr %s0, ptr %s0, { i64, ptr } %t6)
  store { i64, ptr } %t8, ptr %l11
  br label %bb3
bb3:
  %t9 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t9, ptr %l2, !tbaa !27
  %t10 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t11 = extractvalue { i32, { i64, ptr } } %t10, 1
  %t12 = extractvalue { i32, { i64, ptr } } %t10, 0
  store i32 %t12, ptr %l14
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb5, label %ok.14, !prof !99
ok.14:
  store { i64, ptr } %t11, ptr %l13
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t15, ptr %l12, !tbaa !27
  br label %bb9
bb5:
  %t16 = load i32, ptr %l14, !tbaa !23
  %t17 = ashr i32 %t16, 16
  %t19 = icmp eq i32 %t17, 1
  br i1 %t19, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb9
bb9:
  %t21 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t21, ptr %l3, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t22, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = getelementptr i8, ptr %t34, i64 %t30
  call void @olang_textcopy(ptr %t35, ptr %t31, i64 %t32)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s0, { i64, ptr } %t26, { i64, ptr } %t37)
  store i1 %t41, ptr %l25
  br label %bb10
bb10:
  %t42 = load i1, ptr %l25, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = call ptr @__olang_scope_hold(ptr %s0)
  %t44 = ptrtoint ptr %t43 to i64
  store i64 %t44, ptr %l26, !tbaa !24
  %t45 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e4
  br i1 %t45, label %bb13, label %bb14
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 1
  %t51 = extractvalue { i64, ptr } %t48, 0
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t50, i64 %t51)
  %t56 = getelementptr i8, ptr %t55, i64 %t51
  call void @olang_textcopy(ptr %t56, ptr %t52, i64 %t53)
  %t57 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s4, { i64, ptr } %t47, { i64, ptr } %t58)
  store i1 %t62, ptr %l52
  br label %bb29
bb13:
  %t63 = call ptr @__olang_region_make(ptr %s0)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l26, !tbaa !24
  br label %bb14
bb14:
  %t65 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l30, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l32, !tbaa !24
  %t73 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  store i64 %t74, ptr %l33, !tbaa !24
  %t75 = load i64, ptr %l30, !tbaa !24
  %t76 = icmp sge i64 %t75, 0
  br i1 %t76, label %bb15, label %bb16
bb15:
  %t78 = load i64, ptr %l30, !tbaa !24
  %t79 = load i64, ptr %l32, !tbaa !24
  %t80 = icmp sle i64 %t78, %t79
  br i1 %t80, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb17:
  %t82 = load i64, ptr %l32, !tbaa !24
  %t83 = load i64, ptr %l33, !tbaa !24
  %t84 = icmp sle i64 %t82, %t83
  br i1 %t84, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb19:
  %t86 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = load i64, ptr %l30, !tbaa !24
  %t89 = load i64, ptr %l32, !tbaa !24
  %t90 = getelementptr i8, ptr %t87, i64 %t88
  %t91 = sub i64 %t89, %t88
  %t92 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t90, 1
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = extractvalue { i64, ptr } %t93, 0
  %t97 = load i64, ptr %l26
  %t98 = inttoptr i64 %t97 to ptr
  %t99 = call ptr @__olang_held_alloc(ptr %t98, i64 %t96)
  call void @olang_textcopy(ptr %t99, ptr %t95, i64 %t96)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l38, !tbaa !27
  %t102 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e4
  br i1 %t102, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d)
  unreachable
bb21:
  %t104 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t107 = icmp eq i64 %t105, 0
  br i1 %t107, label %bb23, label %bb24
bb22:
  %t109 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t109, ptr %l42, !tbaa !27
  %t110 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t110, ptr %l4, !tbaa !27
  %t111 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e4
  br i1 %t111, label %bb25, label %bb26
bb23:
  store { i64, ptr } zeroinitializer, ptr %l38, !tbaa !27
  br label %bb24
bb24:
  %t113 = load i64, ptr %l26
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = load { i64, ptr }, ptr %l38
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = icmp ne ptr %t117, null
  %t119 = select i1 %t118, ptr %t117, ptr null
  call void @__olang_region_settle_in(ptr %t114, ptr %t119)
  br label %bb22
bb25:
  %t120 = load { i64, ptr }, ptr %l42
  %t121 = extractvalue { i64, ptr } %t120, 1
  call void @__olang_region_release(ptr %t121)
  store { i64, ptr } zeroinitializer, ptr %l42
  br label %bb26
bb26:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t123, ptr %l46, !tbaa !27
  store { i64, ptr } %t122, ptr %l5, !tbaa !27
  %t125 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e5
  br i1 %t125, label %bb27, label %bb28
bb27:
  %t127 = load { i64, ptr }, ptr %l46
  %t128 = extractvalue { i64, ptr } %t127, 1
  call void @__olang_region_release(ptr %t128)
  store { i64, ptr } zeroinitializer, ptr %l46
  br label %bb28
bb28:
  br label %bb47
bb29:
  %t129 = load i1, ptr %l52, !tbaa !21
  br i1 %t129, label %bb30, label %bb31
bb30:
  %t130 = call ptr @__olang_scope_hold(ptr %s0)
  %t131 = ptrtoint ptr %t130 to i64
  store i64 %t131, ptr %l53, !tbaa !24
  %t132 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e4
  br i1 %t132, label %bb32, label %bb33
bb31:
  br label %bb46
bb32:
  %t134 = call ptr @__olang_region_make(ptr %s0)
  %t135 = ptrtoint ptr %t134 to i64
  store i64 %t135, ptr %l53, !tbaa !24
  br label %bb33
bb33:
  %t136 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l57, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l59, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l60, !tbaa !24
  %t146 = load i64, ptr %l57, !tbaa !24
  %t147 = icmp sge i64 %t146, 0
  br i1 %t147, label %bb34, label %bb35
bb34:
  %t149 = load i64, ptr %l57, !tbaa !24
  %t150 = load i64, ptr %l59, !tbaa !24
  %t151 = icmp sle i64 %t149, %t150
  br i1 %t151, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb36:
  %t153 = load i64, ptr %l59, !tbaa !24
  %t154 = load i64, ptr %l60, !tbaa !24
  %t155 = icmp sle i64 %t153, %t154
  br i1 %t155, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb38:
  %t157 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l57, !tbaa !24
  %t160 = load i64, ptr %l59, !tbaa !24
  %t161 = getelementptr i8, ptr %t158, i64 %t159
  %t162 = sub i64 %t160, %t159
  %t163 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  %t166 = extractvalue { i64, ptr } %t164, 1
  %t167 = extractvalue { i64, ptr } %t164, 0
  %t168 = load i64, ptr %l53
  %t169 = inttoptr i64 %t168 to ptr
  %t170 = call ptr @__olang_held_alloc(ptr %t169, i64 %t167)
  call void @olang_textcopy(ptr %t170, ptr %t166, i64 %t167)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t170, 1
  store { i64, ptr } %t172, ptr %l65, !tbaa !27
  %t173 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e4
  br i1 %t173, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_18466e7707586594_33576ced7420fee0)
  unreachable
bb40:
  %t175 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 0
  %t178 = icmp eq i64 %t176, 0
  br i1 %t178, label %bb42, label %bb43
bb41:
  %t180 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t180, ptr %l69, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l65, !tbaa !27
  store { i64, ptr } %t181, ptr %l4, !tbaa !27
  %t182 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e4
  br i1 %t182, label %bb44, label %bb45
bb42:
  store { i64, ptr } zeroinitializer, ptr %l65, !tbaa !27
  br label %bb43
bb43:
  %t184 = load i64, ptr %l53
  %t185 = inttoptr i64 %t184 to ptr
  %t186 = load { i64, ptr }, ptr %l65
  %t187 = extractvalue { i64, ptr } %t186, 1
  %t188 = call ptr @__olang_region_or(ptr %t187, ptr null)
  %t189 = icmp ne ptr %t188, null
  %t190 = select i1 %t189, ptr %t188, ptr null
  call void @__olang_region_settle_in(ptr %t185, ptr %t190)
  br label %bb41
bb44:
  %t191 = load { i64, ptr }, ptr %l69
  %t192 = extractvalue { i64, ptr } %t191, 1
  call void @__olang_region_release(ptr %t192)
  store { i64, ptr } zeroinitializer, ptr %l69
  br label %bb45
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s4)
  br label %bb47
bb47:
  %t193 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t195 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t193, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) })
  store i1 %t195, ptr %l72
  br label %bb48
bb48:
  %t196 = load i1, ptr %l72, !tbaa !21
  %t197 = xor i1 %t196, true
  br i1 %t197, label %bb49, label %bb50
bb49:
  %t199 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t202 = extractvalue { i64, ptr } %t199, 1
  %t203 = extractvalue { i64, ptr } %t199, 0
  %t205 = extractvalue { i64, ptr } %t200, 1
  %t206 = extractvalue { i64, ptr } %t200, 0
  %t207 = add i64 %t203, %t206
  %t208 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t207)
  call void @olang_textcopy(ptr %t208, ptr %t202, i64 %t203)
  %t209 = getelementptr i8, ptr %t208, i64 %t203
  call void @olang_textcopy(ptr %t209, ptr %t205, i64 %t206)
  %t210 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t211 = insertvalue { i64, ptr } %t210, ptr %t208, 1
  store { i64, ptr } %t211, ptr %l74, !tbaa !27
  br label %bb52
bb50:
  %t213 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t215 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %s0, ptr %s0, { i64, ptr } %t213)
  store { i64, ptr } %t215, ptr %l79
  br label %bb51
bb51:
  %t216 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t217, i64 %t218)
  %t220 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t219, 1
  store { i64, ptr } %t221, ptr %l74, !tbaa !27
  br label %bb52
bb52:
  %t223 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t223, ptr %lp6
  %t224 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t225 = load ptr, ptr %lp6
  store { i64, ptr } %t224, ptr %t225, !tbaa !27
  %t226 = load ptr, ptr %lp6
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t229 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v1, ptr %s0, { i64, ptr } %t227, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d27, i32 0, i32 1) })
  store i1 %t229, ptr %l82
  br label %bb53
bb53:
  %t230 = load i1, ptr %l82, !tbaa !21
  br i1 %t230, label %bb54, label %bb55
bb54:
  %t231 = load ptr, ptr %lp6
  %t232 = load { i64, ptr }, ptr %t231, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t236 = sub i64 %t234, 6
  store i64 %t236, ptr %l86, !tbaa !24
  %t237 = load ptr, ptr %lp6
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 0
  store i64 %t239, ptr %l87, !tbaa !24
  %t240 = icmp sge i64 0, 0
  br i1 %t240, label %bb56, label %bb57
bb55:
  %t242 = load ptr, ptr %lp6
  %t243 = load { i64, ptr }, ptr %t242, !tbaa !27
  store { i64, ptr } %t243, ptr %l83, !tbaa !27
  br label %bb62
bb56:
  %t245 = load i64, ptr %l86, !tbaa !24
  %t246 = icmp sle i64 0, %t245
  br i1 %t246, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb58:
  %t248 = load i64, ptr %l86, !tbaa !24
  %t249 = load i64, ptr %l87, !tbaa !24
  %t250 = icmp sle i64 %t248, %t249
  br i1 %t250, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb60:
  %t252 = load ptr, ptr %lp6
  %t253 = getelementptr { i64, ptr }, ptr %t252, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = load i64, ptr %l86, !tbaa !24
  %t256 = getelementptr i8, ptr %t254, i64 0
  %t257 = sub i64 %t255, 0
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t261 = extractvalue { i64, ptr } %t259, 1
  %t262 = extractvalue { i64, ptr } %t259, 0
  %t263 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t262)
  call void @olang_textcopy(ptr %t263, ptr %t261, i64 %t262)
  %t264 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l83, !tbaa !27
  br label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_decc2d78854299ff_a983c2831d86fddb)
  unreachable
bb62:
  call void @__olang_scope_close(ptr %s0)
  %t267 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t267, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { { i64, ptr }, i64 } } @compiler_2fsession_2eImportFix(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %lp9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l12 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i32
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l24 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l33 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i32
  %l38 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l67 = alloca i1
  %l72 = alloca i64
  %l78 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l87 = alloca { i64, ptr }
  %l95 = alloca i1
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l104 = alloca i64
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l108 = alloca i64
  %l113 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i32, { { i64, ptr }, i64 } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t1 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t3, { i64, ptr } %t4)
  %t8 = extractvalue { i32, i64 } %t7, 1
  %t9 = extractvalue { i32, i64 } %t7, 0
  store i32 %t9, ptr %l16
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb2, label %ok.11, !prof !99
ok.11:
  store i64 %t8, ptr %l15
  br label %bb1
bb1:
  %t12 = load i64, ptr %l15, !tbaa !24
  store i64 %t12, ptr %l12, !tbaa !24
  br label %bb4
bb2:
  %t13 = load i32, ptr %l16, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  store i1 %t16, ptr %l18, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t18 = insertvalue { i32, { { i64, ptr }, i64 } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, i64 } } %t18, ptr %rv
  br label %ret
bb4:
  %t19 = load i64, ptr %l12, !tbaa !24
  %t20 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t20, ptr %l20, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t27 = add i64 %t19, %t24
  store i64 %t27, ptr %l24, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t28, 0
  store i64 %t31, ptr %l27, !tbaa !24
  %t32 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t32, 0
  store i64 %t33, ptr %l28, !tbaa !24
  %t34 = load i64, ptr %l24, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  br i1 %t35, label %bb5, label %bb6
bb5:
  %t37 = load i64, ptr %l24, !tbaa !24
  %t38 = load i64, ptr %l27, !tbaa !24
  %t39 = icmp sle i64 %t37, %t38
  br i1 %t39, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_11adf005d01e014e_cb232ed18e8bcffa)
  unreachable
bb7:
  %t41 = load i64, ptr %l27, !tbaa !24
  %t42 = load i64, ptr %l28, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_11adf005d01e014e_cb232ed18e8bcffa)
  unreachable
bb9:
  %t45 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l24, !tbaa !24
  %t48 = load i64, ptr %l27, !tbaa !24
  %t49 = getelementptr i8, ptr %t46, i64 %t47
  %t50 = sub i64 %t48, %t47
  %t51 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t49, 1
  store { i64, ptr } %t52, ptr %l4, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t56 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t54, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t57 = extractvalue { i32, i64 } %t56, 1
  %t58 = extractvalue { i32, i64 } %t56, 0
  store i32 %t58, ptr %l36
  %t59 = icmp ne i32 %t58, 0
  br i1 %t59, label %bb12, label %ok.60, !prof !99
ok.60:
  store i64 %t57, ptr %l35
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_11adf005d01e014e_cb232ed18e8bcffa)
  unreachable
bb11:
  %t61 = load i64, ptr %l35, !tbaa !24
  store i64 %t61, ptr %l33, !tbaa !24
  br label %bb14
bb12:
  %t62 = load i32, ptr %l36, !tbaa !23
  %t63 = ashr i32 %t62, 16
  %t65 = icmp eq i32 %t63, 1
  store i1 %t65, ptr %l38, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t67 = insertvalue { i32, { { i64, ptr }, i64 } } zeroinitializer, i32 65536, 0
  store { i32, { { i64, ptr }, i64 } } %t67, ptr %rv
  br label %ret
bb14:
  %t68 = load i64, ptr %l33, !tbaa !24
  store i64 %t68, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t69 = load i64, ptr %l7, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t75 = icmp slt i64 %t69, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb17:
  br label %bb18
bb18:
  %t79 = load i64, ptr %l7, !tbaa !24
  store i64 %t79, ptr %l8, !tbaa !24
  br label %bb19
bb19:
  %t81 = load i64, ptr %l8, !tbaa !24
  %t82 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t87 = icmp slt i64 %t81, %t84
  br i1 %t87, label %bb20, label %bb21
bb20:
  %t89 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t89, ptr %l51, !tbaa !27
  %t90 = load i64, ptr %l8, !tbaa !24
  %t92 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i8, ptr %t93, i64 %t90
  %t95 = load i8, ptr %t94, !tbaa !32
  %t97 = icmp ne i8 %t95, 10
  store i1 %t97, ptr %l50, !tbaa !21
  br label %bb22
bb21:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb22
bb22:
  %t99 = load i1, ptr %l50, !tbaa !21
  %t100 = xor i1 %t99, true
  br i1 %t100, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = add i64 %t102, 1
  store i64 %t105, ptr %l8, !tbaa !24
  br label %bb26
bb26:
  br label %bb19
bb27:
  %t107 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t107, ptr %l59, !tbaa !27
  %t108 = load i64, ptr %l7, !tbaa !24
  store i64 %t108, ptr %l60, !tbaa !24
  %t109 = load i64, ptr %l8, !tbaa !24
  store i64 %t109, ptr %l61, !tbaa !24
  %t110 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t110, 0
  store i64 %t111, ptr %l62, !tbaa !24
  %t112 = load i64, ptr %l60, !tbaa !24
  %t113 = icmp sge i64 %t112, 0
  br i1 %t113, label %bb28, label %bb29
bb28:
  %t115 = load i64, ptr %l60, !tbaa !24
  %t116 = load i64, ptr %l61, !tbaa !24
  %t117 = icmp sle i64 %t115, %t116
  br i1 %t117, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_49d3d4d897a09f4b_e833dc78ed36a5d7)
  unreachable
bb30:
  %t119 = load i64, ptr %l61, !tbaa !24
  %t120 = load i64, ptr %l62, !tbaa !24
  %t121 = icmp sle i64 %t119, %t120
  br i1 %t121, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_49d3d4d897a09f4b_e833dc78ed36a5d7)
  unreachable
bb32:
  %t123 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = load i64, ptr %l60, !tbaa !24
  %t126 = load i64, ptr %l61, !tbaa !24
  %t127 = getelementptr i8, ptr %t124, i64 %t125
  %t128 = sub i64 %t126, %t125
  %t129 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t127, 1
  %t132 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s3, { i64, ptr } %t130, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t132, ptr %l67
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_49d3d4d897a09f4b_e833dc78ed36a5d7)
  unreachable
bb34:
  %t133 = load i1, ptr %l67, !tbaa !21
  br i1 %t133, label %bb35, label %bb36
bb35:
  %t134 = load i64, ptr %l8, !tbaa !24
  %t135 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t140 = icmp slt i64 %t134, %t137
  br i1 %t140, label %bb37, label %bb38
bb36:
  br label %bb40
bb37:
  %t142 = load i64, ptr %l8, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l72, !tbaa !24
  br label %bb39
bb38:
  %t146 = load i64, ptr %l8, !tbaa !24
  store i64 %t146, ptr %l72, !tbaa !24
  br label %bb39
bb39:
  %t148 = load i64, ptr %l72, !tbaa !24
  store i64 %t148, ptr %l6, !tbaa !24
  br label %bb40
bb40:
  %t149 = load i64, ptr %l8, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  br label %bb15
bb42:
  %t153 = call ptr @__olang_scope_hold(ptr %v2)
  %t154 = ptrtoint ptr %t153 to i64
  store i64 %t154, ptr %l78, !tbaa !24
  %t155 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportFix_2elocal_2e9
  br i1 %t155, label %bb43, label %bb44
bb43:
  %t157 = call ptr @__olang_region_make(ptr %v2)
  %t158 = ptrtoint ptr %t157 to i64
  store i64 %t158, ptr %l78, !tbaa !24
  br label %bb44
bb44:
  %t159 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t159, ptr %l80, !tbaa !27
  %t160 = load i64, ptr %l5, !tbaa !24
  store i64 %t160, ptr %l81, !tbaa !24
  %t161 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  store i64 %t162, ptr %l82, !tbaa !24
  %t163 = icmp sge i64 0, 0
  br i1 %t163, label %bb45, label %bb46
bb45:
  %t165 = load i64, ptr %l81, !tbaa !24
  %t166 = icmp sle i64 0, %t165
  br i1 %t166, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_99d7ad80954f16d0_3de5076c8923a26c)
  unreachable
bb47:
  %t168 = load i64, ptr %l81, !tbaa !24
  %t169 = load i64, ptr %l82, !tbaa !24
  %t170 = icmp sle i64 %t168, %t169
  br i1 %t170, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_99d7ad80954f16d0_3de5076c8923a26c)
  unreachable
bb49:
  %t172 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t173 = load ptr, ptr %t172, !tbaa !27
  %t174 = load i64, ptr %l81, !tbaa !24
  %t175 = getelementptr i8, ptr %t173, i64 0
  %t176 = sub i64 %t174, 0
  %t177 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = extractvalue { i64, ptr } %t178, 0
  %t182 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t183 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t184 = add i64 %t181, %t183
  %t185 = load i64, ptr %l78
  %t186 = inttoptr i64 %t185 to ptr
  %t187 = call ptr @__olang_held_alloc(ptr %t186, i64 %t184)
  call void @olang_textcopy(ptr %t187, ptr %t180, i64 %t181)
  %t188 = getelementptr i8, ptr %t187, i64 %t181
  call void @olang_textcopy(ptr %t188, ptr %t182, i64 %t183)
  %t189 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t187, 1
  store { i64, ptr } %t190, ptr %l87, !tbaa !27
  %t191 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportFix_2elocal_2e9
  br i1 %t191, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_99d7ad80954f16d0_3de5076c8923a26c)
  unreachable
bb51:
  %t193 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 0
  %t196 = icmp eq i64 %t194, 0
  br i1 %t196, label %bb53, label %bb54
bb52:
  %t198 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t198, ptr %lp9
  %t199 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t200 = load ptr, ptr %lp9
  store { i64, ptr } %t199, ptr %t200, !tbaa !27
  %t201 = load i64, ptr %l6, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t207 = icmp eq i64 %t201, %t204
  br i1 %t207, label %bb55, label %bb56
bb53:
  store { i64, ptr } zeroinitializer, ptr %l87, !tbaa !27
  br label %bb54
bb54:
  %t209 = load i64, ptr %l78
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = load { i64, ptr }, ptr %l87
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = call ptr @__olang_region_or(ptr %t212, ptr null)
  %t214 = icmp ne ptr %t213, null
  %t215 = select i1 %t214, ptr %t213, ptr null
  call void @__olang_region_settle_in(ptr %t210, ptr %t215)
  br label %bb52
bb55:
  %t216 = load i64, ptr %l6, !tbaa !24
  %t218 = icmp sgt i64 %t216, 0
  store i1 %t218, ptr %l95, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l95, !tbaa !21
  br label %bb57
bb57:
  %t220 = load i1, ptr %l95, !tbaa !21
  br i1 %t220, label %bb58, label %bb59
bb58:
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t221, ptr %l99, !tbaa !27
  %t222 = load i64, ptr %l6, !tbaa !24
  %t224 = sub i64 %t222, 1
  %t226 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i8, ptr %t227, i64 %t224
  %t229 = load i8, ptr %t228, !tbaa !32
  %t231 = icmp ne i8 %t229, 10
  store i1 %t231, ptr %l98, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb60
bb60:
  %t233 = load i1, ptr %l98, !tbaa !21
  br i1 %t233, label %bb61, label %bb62
bb61:
  %t234 = call ptr @__olang_scope_hold(ptr %v2)
  %t235 = ptrtoint ptr %t234 to i64
  store i64 %t235, ptr %l104, !tbaa !24
  %t236 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportFix_2elocal_2e9
  br i1 %t236, label %bb63, label %bb64
bb62:
  br label %bb77
bb63:
  %t238 = call ptr @__olang_region_make(ptr %v2)
  %t239 = ptrtoint ptr %t238 to i64
  store i64 %t239, ptr %l104, !tbaa !24
  br label %bb64
bb64:
  %t240 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t240, ptr %l106, !tbaa !27
  %t241 = load i64, ptr %l5, !tbaa !24
  store i64 %t241, ptr %l107, !tbaa !24
  %t242 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l108, !tbaa !24
  %t244 = icmp sge i64 0, 0
  br i1 %t244, label %bb65, label %bb66
bb65:
  %t246 = load i64, ptr %l107, !tbaa !24
  %t247 = icmp sle i64 0, %t246
  br i1 %t247, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_a69546661a842dad_144c74a8276b4119)
  unreachable
bb67:
  %t249 = load i64, ptr %l107, !tbaa !24
  %t250 = load i64, ptr %l108, !tbaa !24
  %t251 = icmp sle i64 %t249, %t250
  br i1 %t251, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_a69546661a842dad_144c74a8276b4119)
  unreachable
bb69:
  %t253 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = load i64, ptr %l107, !tbaa !24
  %t256 = getelementptr i8, ptr %t254, i64 0
  %t257 = sub i64 %t255, 0
  %t258 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t256, 1
  %t260 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t263 = extractvalue { i64, ptr } %t259, 1
  %t264 = extractvalue { i64, ptr } %t259, 0
  %t265 = add i64 %t261, %t264
  %t266 = load i64, ptr %l104
  %t267 = inttoptr i64 %t266 to ptr
  %t268 = call ptr @__olang_held_alloc(ptr %t267, i64 %t265)
  call void @olang_textcopy(ptr %t268, ptr %t260, i64 %t261)
  %t269 = getelementptr i8, ptr %t268, i64 %t261
  call void @olang_textcopy(ptr %t269, ptr %t263, i64 %t264)
  %t270 = insertvalue { i64, ptr } undef, i64 %t265, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t268, 1
  store { i64, ptr } %t271, ptr %l113, !tbaa !27
  %t272 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportFix_2elocal_2e9
  br i1 %t272, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_a69546661a842dad_144c74a8276b4119)
  unreachable
bb71:
  %t274 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t274, 0
  %t277 = icmp eq i64 %t275, 0
  br i1 %t277, label %bb73, label %bb74
bb72:
  %t279 = load ptr, ptr %lp9
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !27
  store { i64, ptr } %t280, ptr %l117, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t282 = load ptr, ptr %lp9
  store { i64, ptr } %t281, ptr %t282, !tbaa !27
  %t283 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportFix_2elocal_2e9
  br i1 %t283, label %bb75, label %bb76
bb73:
  store { i64, ptr } zeroinitializer, ptr %l113, !tbaa !27
  br label %bb74
bb74:
  %t285 = load i64, ptr %l104
  %t286 = inttoptr i64 %t285 to ptr
  %t287 = load { i64, ptr }, ptr %l113
  %t288 = extractvalue { i64, ptr } %t287, 1
  %t289 = call ptr @__olang_region_or(ptr %t288, ptr null)
  %t290 = icmp ne ptr %t289, null
  %t291 = select i1 %t290, ptr %t289, ptr null
  call void @__olang_region_settle_in(ptr %t286, ptr %t291)
  br label %bb72
bb75:
  %t292 = load { i64, ptr }, ptr %l117
  %t293 = extractvalue { i64, ptr } %t292, 1
  call void @__olang_region_release(ptr %t293)
  store { i64, ptr } zeroinitializer, ptr %l117
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t294 = load ptr, ptr %lp9
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !27
  %t296 = load i64, ptr %l6, !tbaa !24
  %t298 = insertvalue { { i64, ptr }, i64 } undef, { i64, ptr } %t295, 0
  %t300 = insertvalue { { i64, ptr }, i64 } %t298, i64 %t296, 1
  call void @__olang_scope_close(ptr %s0)
  %t302 = insertvalue { i32, { { i64, ptr }, i64 } } zeroinitializer, { { i64, ptr }, i64 } %t300, 1
  store { i32, { { i64, ptr }, i64 } } %t302, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { { i64, ptr }, i64 } }, ptr %rv
  ret { i32, { { i64, ptr }, i64 } } %rr
}

define dso_local void @compiler_2fsession_2eImportPaths(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l16 = alloca i1
  %l17 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i64
  %l72 = alloca i64
  %l77 = alloca { i64, ptr }
  %l80 = alloca i1
  %l81 = alloca i64
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l100 = alloca i1
  %l101 = alloca i1
  %l103 = alloca i1
  %l104 = alloca i64
  %l108 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l119 = alloca i1
  %l129 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i1
  %l139 = alloca i1
  %l144 = alloca i1
  %l149 = alloca i1
  %l150 = alloca ptr
  %l151 = alloca { i64, ptr }
  %l154 = alloca i64
  %l155 = alloca i64
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %t9 = alloca %olang.slotscope
  %t38 = alloca %olang.slotscope
  %t67 = alloca %olang.slotscope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d33, i32 0, i32 1) })
  store i1 %t3, ptr %l16
  br label %bb1
bb1:
  %t4 = load i1, ptr %l16, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = call ptr @__olang_scope_hold(ptr %s2)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l17, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_203_3e_2e_2d1
  br i1 %t7, label %bb4, label %bb5
bb3:
  br label %bb17
bb4:
  %t10 = load ptr, ptr %s2
  %t11 = icmp eq ptr %t10, @__olang_slot_chunk
  %t12 = getelementptr %olang.scope, ptr %s2, i32 0, i32 2
  %t13 = load ptr, ptr %t12
  %t14 = select i1 %t11, ptr %t13, ptr %s2
  store %olang.scope zeroinitializer, ptr %t9
  store ptr @__olang_slot_chunk, ptr %t9
  %t15 = getelementptr %olang.scope, ptr %t9, i32 0, i32 2
  store ptr %t14, ptr %t15
  %t16 = getelementptr %olang.slotscope, ptr %t9, i32 0, i32 1
  store i64 0, ptr %t16
  %t17 = ptrtoint ptr %t9 to i64
  store i64 %t17, ptr %l17, !tbaa !24
  br label %bb5
bb5:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %l19, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t18, ptr %l20, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l21, !tbaa !24
  %t21 = load i64, ptr %l21, !tbaa !24
  %t22 = mul i64 %t21, 1
  %t23 = load i64, ptr %l17
  %t24 = inttoptr i64 %t23 to ptr
  %t25 = call ptr @__olang_held_alloc(ptr %t24, i64 %t22)
  %t26 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l22, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l21, !tbaa !24
  %t33 = mul i64 %t32, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = call ptr @__olang_scope_hold(ptr %s2)
  %t35 = ptrtoint ptr %t34 to i64
  store i64 %t35, ptr %l23, !tbaa !24
  %t36 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_203_3e_2e_2d1
  br i1 %t36, label %bb6, label %bb7
bb6:
  %t39 = load ptr, ptr %s2
  %t40 = icmp eq ptr %t39, @__olang_slot_chunk
  %t41 = getelementptr %olang.scope, ptr %s2, i32 0, i32 2
  %t42 = load ptr, ptr %t41
  %t43 = select i1 %t40, ptr %t42, ptr %s2
  store %olang.scope zeroinitializer, ptr %t38
  store ptr @__olang_slot_chunk, ptr %t38
  %t44 = getelementptr %olang.scope, ptr %t38, i32 0, i32 2
  store ptr %t43, ptr %t44
  %t45 = getelementptr %olang.slotscope, ptr %t38, i32 0, i32 1
  store i64 0, ptr %t45
  %t46 = ptrtoint ptr %t38 to i64
  store i64 %t46, ptr %l23, !tbaa !24
  br label %bb7
bb7:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, ptr %l25, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t47, ptr %l26, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l27, !tbaa !24
  %t50 = load i64, ptr %l27, !tbaa !24
  %t51 = mul i64 %t50, 1
  %t52 = load i64, ptr %l23
  %t53 = inttoptr i64 %t52 to ptr
  %t54 = call ptr @__olang_held_alloc(ptr %t53, i64 %t51)
  %t55 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l28, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = load i64, ptr %l27, !tbaa !24
  %t62 = mul i64 %t61, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t58, ptr %t60, i64 %t62, i1 false)
  %t63 = call ptr @__olang_scope_hold(ptr %s2)
  %t64 = ptrtoint ptr %t63 to i64
  store i64 %t64, ptr %l29, !tbaa !24
  %t65 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_203_3e_2e_2d1
  br i1 %t65, label %bb8, label %bb9
bb8:
  %t68 = load ptr, ptr %s2
  %t69 = icmp eq ptr %t68, @__olang_slot_chunk
  %t70 = getelementptr %olang.scope, ptr %s2, i32 0, i32 2
  %t71 = load ptr, ptr %t70
  %t72 = select i1 %t69, ptr %t71, ptr %s2
  store %olang.scope zeroinitializer, ptr %t67
  store ptr @__olang_slot_chunk, ptr %t67
  %t73 = getelementptr %olang.scope, ptr %t67, i32 0, i32 2
  store ptr %t72, ptr %t73
  %t74 = getelementptr %olang.slotscope, ptr %t67, i32 0, i32 1
  store i64 0, ptr %t74
  %t75 = ptrtoint ptr %t67 to i64
  store i64 %t75, ptr %l29, !tbaa !24
  br label %bb9
bb9:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d36, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t76, ptr %l32, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  store i64 %t78, ptr %l33, !tbaa !24
  %t79 = load i64, ptr %l33, !tbaa !24
  %t80 = mul i64 %t79, 1
  %t81 = load i64, ptr %l29
  %t82 = inttoptr i64 %t81 to ptr
  %t83 = call ptr @__olang_held_alloc(ptr %t82, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t83, 1
  store { i64, ptr } %t85, ptr %l34, !tbaa !27
  %t86 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t87 = load ptr, ptr %t86, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = load i64, ptr %l33, !tbaa !24
  %t91 = mul i64 %t90, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t87, ptr %t89, i64 %t91, i1 false)
  %t92 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t93 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } %t92, 0
  %t94 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t95 = insertvalue [3 x { i64, ptr }] %t93, { i64, ptr } %t94, 1
  %t96 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t97 = insertvalue [3 x { i64, ptr }] %t95, { i64, ptr } %t96, 2
  %t99 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 48, i64 8)
  store [3 x { i64, ptr }] %t97, ptr %t99
  store ptr %t99, ptr %l3
  store i64 0, ptr %l4, !tbaa !24
  %t101 = load ptr, ptr %l3
  store i64 3, ptr %l5, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t104 = load i64, ptr %l4, !tbaa !24
  %t105 = load i64, ptr %l5, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t112 = load ptr, ptr %l3
  %t113 = load i64, ptr %l4, !tbaa !24
  %t116 = getelementptr [3 x { i64, ptr }], ptr %t112, i64 0, i64 %t113
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !37
  store { i64, ptr } %t117, ptr %l45, !tbaa !27
  %t118 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l46, !tbaa !24
  %t120 = load i64, ptr %l46, !tbaa !24
  %t121 = mul i64 %t120, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t121)
  %t123 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l47, !tbaa !27
  %t125 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t126 = load ptr, ptr %t125, !tbaa !27
  %t127 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t128 = load ptr, ptr %t127, !tbaa !27
  %t129 = load i64, ptr %l46, !tbaa !24
  %t130 = mul i64 %t129, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t126, ptr %t128, i64 %t130, i1 false)
  %t131 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 16, i64 8)
  store ptr %t131, ptr %lp6
  %t132 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t133 = load ptr, ptr %lp6
  store { i64, ptr } %t132, ptr %t133, !tbaa !27
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load ptr, ptr %lp6
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t137 = load i64, ptr @G_2ecompiler_2fsession_2eCompFolder, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v0, ptr %v0, ptr %s3, ptr %t134, { i64, ptr } %t136, i64 %t137, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d37, i32 0, i32 1) })
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t141 = load i64, ptr %l4, !tbaa !24
  %t144 = add i64 %t141, 1
  store i64 %t144, ptr %l4, !tbaa !24
  br label %bb10
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb17:
  %t146 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 0
  store i64 %t148, ptr %l7, !tbaa !24
  br label %bb18
bb18:
  %t150 = load i64, ptr %l7, !tbaa !24
  %t152 = icmp sgt i64 %t150, 0
  br i1 %t152, label %bb19, label %bb20
bb19:
  %t154 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t154, ptr %l59, !tbaa !27
  %t155 = load i64, ptr %l7, !tbaa !24
  %t157 = sub i64 %t155, 1
  %t159 = getelementptr { i64, ptr }, ptr %l59, i32 0, i32 1
  %t160 = load ptr, ptr %t159, !tbaa !27
  %t161 = getelementptr i8, ptr %t160, i64 %t157
  %t162 = load i8, ptr %t161, !tbaa !32
  %t164 = icmp ne i8 %t162, 47
  store i1 %t164, ptr %l58, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l58, !tbaa !21
  br label %bb21
bb21:
  %t166 = load i1, ptr %l58, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb22, label %bb23
bb22:
  br label %bb26
bb23:
  br label %bb24
bb24:
  %t169 = load i64, ptr %l7, !tbaa !24
  %t172 = sub i64 %t169, 1
  store i64 %t172, ptr %l7, !tbaa !24
  br label %bb25
bb25:
  br label %bb18
bb26:
  %t174 = load i64, ptr %l7, !tbaa !24
  %t176 = icmp eq i64 %t174, 0
  br i1 %t176, label %bb27, label %bb28
bb27:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb28:
  br label %bb29
bb29:
  %t178 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t178, ptr %l70, !tbaa !27
  %t179 = load i64, ptr %l7, !tbaa !24
  store i64 %t179, ptr %l71, !tbaa !24
  %t180 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t180, 0
  store i64 %t181, ptr %l72, !tbaa !24
  %t182 = icmp sge i64 0, 0
  br i1 %t182, label %bb30, label %bb31
bb30:
  %t184 = load i64, ptr %l71, !tbaa !24
  %t185 = icmp sle i64 0, %t184
  br i1 %t185, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_478261abf26af98f_fc848126d7caf56b)
  unreachable
bb32:
  %t187 = load i64, ptr %l71, !tbaa !24
  %t188 = load i64, ptr %l72, !tbaa !24
  %t189 = icmp sle i64 %t187, %t188
  br i1 %t189, label %bb34, label %bb35
bb33:
  call void @__olang_check_failed(ptr @olang_loc_478261abf26af98f_fc848126d7caf56b)
  unreachable
bb34:
  %t191 = getelementptr { i64, ptr }, ptr %l70, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l71, !tbaa !24
  %t194 = getelementptr i8, ptr %t192, i64 0
  %t195 = sub i64 %t193, 0
  %t196 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t194, 1
  store { i64, ptr } %t197, ptr %l8, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l77, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t199, ptr %l9, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t203 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s0, { i64, ptr } %t201, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  store i1 %t203, ptr %l80
  br label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_478261abf26af98f_fc848126d7caf56b)
  unreachable
bb36:
  %t204 = load i1, ptr %l80, !tbaa !21
  br i1 %t204, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s7
  %t205 = call ptr @__olang_scope_hold(ptr %s0)
  %t206 = ptrtoint ptr %t205 to i64
  store i64 %t206, ptr %l81, !tbaa !24
  %t207 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportPaths_2elocal_2e9
  br i1 %t207, label %bb39, label %bb40
bb38:
  store %olang.scope zeroinitializer, ptr %s9
  %t209 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t211 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s9, { i64, ptr } %t209, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) })
  store i1 %t211, ptr %l100
  br label %bb54
bb39:
  %t212 = call ptr @__olang_region_make(ptr %s0)
  %t213 = ptrtoint ptr %t212 to i64
  store i64 %t213, ptr %l81, !tbaa !24
  br label %bb40
bb40:
  %t214 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s7)
  store { i64, ptr } %t214, ptr %l83
  br label %bb41
bb41:
  %t215 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t215, ptr %l84, !tbaa !27
  %t216 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t216, 0
  store i64 %t219, ptr %l87, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l88, !tbaa !24
  %t222 = icmp sge i64 4, 0
  br i1 %t222, label %bb42, label %bb43
bb42:
  %t224 = load i64, ptr %l87, !tbaa !24
  %t225 = icmp sle i64 4, %t224
  br i1 %t225, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_3c61ac8d706d9f92_284cc560dda6476e)
  unreachable
bb44:
  %t227 = load i64, ptr %l87, !tbaa !24
  %t228 = load i64, ptr %l88, !tbaa !24
  %t229 = icmp sle i64 %t227, %t228
  br i1 %t229, label %bb46, label %bb47
bb45:
  call void @__olang_check_failed(ptr @olang_loc_3c61ac8d706d9f92_284cc560dda6476e)
  unreachable
bb46:
  %t231 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = load i64, ptr %l87, !tbaa !24
  %t234 = getelementptr i8, ptr %t232, i64 4
  %t235 = sub i64 %t233, 4
  %t236 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t234, 1
  %t238 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t239 = extractvalue { i64, ptr } %t238, 1
  %t240 = extractvalue { i64, ptr } %t238, 0
  %t241 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t242 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t243 = add i64 %t240, %t242
  %t245 = extractvalue { i64, ptr } %t237, 1
  %t246 = extractvalue { i64, ptr } %t237, 0
  %t247 = add i64 %t243, %t246
  %t248 = load i64, ptr %l81
  %t249 = inttoptr i64 %t248 to ptr
  %t250 = call ptr @__olang_held_alloc(ptr %t249, i64 %t247)
  call void @olang_textcopy(ptr %t250, ptr %t239, i64 %t240)
  %t251 = getelementptr i8, ptr %t250, i64 %t240
  call void @olang_textcopy(ptr %t251, ptr %t241, i64 %t242)
  %t252 = getelementptr i8, ptr %t251, i64 %t242
  call void @olang_textcopy(ptr %t252, ptr %t245, i64 %t246)
  %t253 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t250, 1
  store { i64, ptr } %t254, ptr %l93, !tbaa !27
  %t255 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportPaths_2elocal_2e9
  br i1 %t255, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_3c61ac8d706d9f92_284cc560dda6476e)
  unreachable
bb48:
  %t257 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 0
  %t260 = icmp eq i64 %t258, 0
  br i1 %t260, label %bb50, label %bb51
bb49:
  %t262 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t262, ptr %l97, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t263, ptr %l9, !tbaa !27
  %t264 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportPaths_2elocal_2e9
  br i1 %t264, label %bb52, label %bb53
bb50:
  store { i64, ptr } zeroinitializer, ptr %l93, !tbaa !27
  br label %bb51
bb51:
  %t266 = load i64, ptr %l81
  %t267 = inttoptr i64 %t266 to ptr
  %t268 = load { i64, ptr }, ptr %l93
  %t269 = extractvalue { i64, ptr } %t268, 1
  %t270 = call ptr @__olang_region_or(ptr %t269, ptr null)
  %t271 = icmp ne ptr %t270, null
  %t272 = select i1 %t271, ptr %t270, ptr null
  call void @__olang_region_settle_in(ptr %t267, ptr %t272)
  br label %bb49
bb52:
  %t273 = load { i64, ptr }, ptr %l97
  %t274 = extractvalue { i64, ptr } %t273, 1
  call void @__olang_region_release(ptr %t274)
  store { i64, ptr } zeroinitializer, ptr %l97
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s7)
  br label %bb70
bb54:
  %t275 = load i1, ptr %l100, !tbaa !21
  br i1 %t275, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l101, !tbaa !21
  br label %bb58
bb56:
  %t276 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t278 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v1, ptr %s9, { i64, ptr } %t276, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t278, ptr %l103
  br label %bb57
bb57:
  %t279 = load i1, ptr %l103, !tbaa !21
  store i1 %t279, ptr %l101, !tbaa !21
  br label %bb58
bb58:
  %t280 = load i1, ptr %l101, !tbaa !21
  br i1 %t280, label %bb59, label %bb60
bb59:
  %t281 = call ptr @__olang_scope_hold(ptr %s0)
  %t282 = ptrtoint ptr %t281 to i64
  store i64 %t282, ptr %l104, !tbaa !24
  %t283 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportPaths_2elocal_2e9
  br i1 %t283, label %bb61, label %bb62
bb60:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb61:
  %t285 = call ptr @__olang_region_make(ptr %s0)
  %t286 = ptrtoint ptr %t285 to i64
  store i64 %t286, ptr %l104, !tbaa !24
  br label %bb62
bb62:
  %t288 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t290 = extractvalue { i64, ptr } %a2, 1
  %t291 = extractvalue { i64, ptr } %a2, 0
  %t292 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t294 = add i64 %t291, %t293
  %t296 = extractvalue { i64, ptr } %t288, 1
  %t297 = extractvalue { i64, ptr } %t288, 0
  %t298 = add i64 %t294, %t297
  %t299 = load i64, ptr %l104
  %t300 = inttoptr i64 %t299 to ptr
  %t301 = call ptr @__olang_held_alloc(ptr %t300, i64 %t298)
  call void @olang_textcopy(ptr %t301, ptr %t290, i64 %t291)
  %t302 = getelementptr i8, ptr %t301, i64 %t291
  call void @olang_textcopy(ptr %t302, ptr %t292, i64 %t293)
  %t303 = getelementptr i8, ptr %t302, i64 %t293
  call void @olang_textcopy(ptr %t303, ptr %t296, i64 %t297)
  %t304 = insertvalue { i64, ptr } undef, i64 %t298, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t301, 1
  store { i64, ptr } %t305, ptr %l108, !tbaa !27
  %t306 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportPaths_2elocal_2e9
  br i1 %t306, label %bb63, label %bb64
bb63:
  %t308 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 0
  %t311 = icmp eq i64 %t309, 0
  br i1 %t311, label %bb65, label %bb66
bb64:
  %t313 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t313, ptr %l112, !tbaa !27
  %t314 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t314, ptr %l9, !tbaa !27
  %t315 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2eImportPaths_2elocal_2e9
  br i1 %t315, label %bb67, label %bb68
bb65:
  store { i64, ptr } zeroinitializer, ptr %l108, !tbaa !27
  br label %bb66
bb66:
  %t317 = load i64, ptr %l104
  %t318 = inttoptr i64 %t317 to ptr
  %t319 = load { i64, ptr }, ptr %l108
  %t320 = extractvalue { i64, ptr } %t319, 1
  %t321 = call ptr @__olang_region_or(ptr %t320, ptr null)
  %t322 = icmp ne ptr %t321, null
  %t323 = select i1 %t322, ptr %t321, ptr null
  call void @__olang_region_settle_in(ptr %t318, ptr %t323)
  br label %bb64
bb67:
  %t324 = load { i64, ptr }, ptr %l112
  %t325 = extractvalue { i64, ptr } %t324, 1
  call void @__olang_region_release(ptr %t325)
  store { i64, ptr } zeroinitializer, ptr %l112
  br label %bb68
bb68:
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s9)
  br label %bb70
bb70:
  %t326 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t328 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s0, ptr %v0, { i64, ptr } %t326)
  %t329 = extractvalue { i32, { i64, ptr } } %t328, 1
  %t330 = extractvalue { i32, { i64, ptr } } %t328, 0
  store i32 %t330, ptr %l117
  %t331 = icmp ne i32 %t330, 0
  br i1 %t331, label %bb72, label %ok.332, !prof !99
ok.332:
  store { i64, ptr } %t329, ptr %l116
  br label %bb71
bb71:
  %t333 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t333, ptr %l114, !tbaa !27
  br label %bb76
bb72:
  %t334 = load i32, ptr %l117, !tbaa !23
  %t335 = ashr i32 %t334, 16
  %t337 = icmp eq i32 %t335, 1
  store i1 %t337, ptr %l119, !tbaa !21
  %t338 = load i32, ptr %l117, !tbaa !23
  %t339 = ashr i32 %t338, 16
  %t341 = icmp eq i32 %t339, 1
  br i1 %t341, label %bb73, label %bb74
bb73:
  call void @__olang_errpay_pop()
  br label %bb74
bb74:
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb76:
  %t343 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t343, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t346 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t346, 0
  store i64 %t348, ptr %l13, !tbaa !24
  br label %bb77
bb77:
  store %olang.scope zeroinitializer, ptr %s15
  %t350 = load i64, ptr %l12, !tbaa !24
  %t351 = load i64, ptr %l13, !tbaa !24
  %t354 = icmp slt i64 %t350, %t351
  %t356 = xor i1 %t354, true
  br i1 %t356, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s15)
  br label %bb110
bb79:
  br label %bb80
bb80:
  %t358 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t358, ptr %l129, !tbaa !27
  %t359 = load i64, ptr %l12, !tbaa !24
  %t361 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = getelementptr { i64, ptr }, ptr %t362, i64 %t359
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !37
  store { i64, ptr } %t364, ptr %l14, !tbaa !27
  %t366 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t368 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s15, { i64, ptr } %t366, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t368, ptr %l133
  br label %bb81
bb81:
  %t369 = load i1, ptr %l133, !tbaa !21
  br i1 %t369, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l134, !tbaa !21
  br label %bb89
bb83:
  %t370 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t372 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s15, { i64, ptr } %t370, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t372, ptr %l136
  br label %bb84
bb84:
  %t373 = load i1, ptr %l136, !tbaa !21
  br i1 %t373, label %bb85, label %bb86
bb85:
  %t374 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t376 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s15, { i64, ptr } %t374, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t376, ptr %l139
  br label %bb87
bb86:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb88
bb87:
  %t377 = load i1, ptr %l139, !tbaa !21
  store i1 %t377, ptr %l137, !tbaa !21
  br label %bb88
bb88:
  %t378 = load i1, ptr %l137, !tbaa !21
  store i1 %t378, ptr %l134, !tbaa !21
  br label %bb89
bb89:
  %t379 = load i1, ptr %l134, !tbaa !21
  br i1 %t379, label %bb90, label %bb91
bb90:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb91:
  br label %bb92
bb92:
  %t380 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t381 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t380, 1
  %t384 = extractvalue { i64, ptr } %t380, 0
  %t385 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t386 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t387 = add i64 %t384, %t386
  %t389 = extractvalue { i64, ptr } %t381, 1
  %t390 = extractvalue { i64, ptr } %t381, 0
  %t391 = add i64 %t387, %t390
  %t392 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t391)
  call void @olang_textcopy(ptr %t392, ptr %t383, i64 %t384)
  %t393 = getelementptr i8, ptr %t392, i64 %t384
  call void @olang_textcopy(ptr %t393, ptr %t385, i64 %t386)
  %t394 = getelementptr i8, ptr %t393, i64 %t386
  call void @olang_textcopy(ptr %t394, ptr %t389, i64 %t390)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t392, 1
  %t399 = call i1 @std_2fos_2eIsDir(ptr %s15, { i64, ptr } %t396)
  store i1 %t399, ptr %l144
  br label %bb93
bb93:
  %t400 = load i1, ptr %l144, !tbaa !21
  br i1 %t400, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s18
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t402 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t403 = load i64, ptr @G_2ecompiler_2fsession_2eCompFolder, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v0, ptr %v0, ptr %s18, ptr %t401, { i64, ptr } %t402, i64 %t403, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb96
bb95:
  store %olang.scope zeroinitializer, ptr %s19
  %t407 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t409 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s19, { i64, ptr } %t407, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) })
  store i1 %t409, ptr %l149
  br label %bb97
bb96:
  call void @__olang_scope_close(ptr %s18)
  br label %bb108
bb97:
  %t410 = load i1, ptr %l149, !tbaa !21
  br i1 %t410, label %bb98, label %bb99
bb98:
  store %olang.scope zeroinitializer, ptr %s20
  %t411 = load ptr, ptr %l0, !tbaa !29
  store ptr %t411, ptr %l150, !tbaa !29
  %t412 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t412, ptr %l151, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t417 = sub i64 %t415, 6
  store i64 %t417, ptr %l154, !tbaa !24
  %t418 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t419 = extractvalue { i64, ptr } %t418, 0
  store i64 %t419, ptr %l155, !tbaa !24
  %t420 = icmp sge i64 0, 0
  br i1 %t420, label %bb100, label %bb101
bb99:
  br label %bb107
bb100:
  %t422 = load i64, ptr %l154, !tbaa !24
  %t423 = icmp sle i64 0, %t422
  br i1 %t423, label %bb102, label %bb103
bb101:
  call void @__olang_check_failed(ptr @olang_loc_7b2af1307c65a991_42bd59c234e619cd)
  unreachable
bb102:
  %t425 = load i64, ptr %l154, !tbaa !24
  %t426 = load i64, ptr %l155, !tbaa !24
  %t427 = icmp sle i64 %t425, %t426
  br i1 %t427, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @olang_loc_7b2af1307c65a991_42bd59c234e619cd)
  unreachable
bb104:
  %t429 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t430 = load ptr, ptr %t429, !tbaa !27
  %t431 = load i64, ptr %l154, !tbaa !24
  %t432 = getelementptr i8, ptr %t430, i64 0
  %t433 = sub i64 %t431, 0
  %t434 = insertvalue { i64, ptr } undef, i64 %t433, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t432, 1
  %t436 = load i64, ptr @G_2ecompiler_2fsession_2eCompFile, !tbaa !24
  %t437 = load ptr, ptr %l150, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v0, ptr %v0, ptr %s20, ptr %t437, { i64, ptr } %t435, i64 %t436, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_7b2af1307c65a991_42bd59c234e619cd)
  unreachable
bb106:
  call void @__olang_scope_close(ptr %s20)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s19)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s15)
  br label %bb109
bb109:
  %t440 = load i64, ptr %l12, !tbaa !24
  %t443 = add i64 %t440, 1
  store i64 %t443, ptr %l12, !tbaa !24
  br label %bb77
bb110:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2eImportTyped(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l33 = alloca i1
  %l41 = alloca i64
  %l44 = alloca i64
  %l53 = alloca i64
  %l56 = alloca i1
  %l66 = alloca { i64, ptr }
  %l73 = alloca i64
  %l81 = alloca { i64, ptr }
  %l83 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t3 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sgt i64 %t3, 0
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l15, !tbaa !27
  %t8 = load i64, ptr %l2, !tbaa !24
  %t10 = sub i64 %t8, 1
  %t12 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i8, ptr %t13, i64 %t10
  %t15 = load i8, ptr %t14, !tbaa !32
  %t17 = icmp ne i8 %t15, 10
  store i1 %t17, ptr %l14, !tbaa !21
  br label %bb4
bb3:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb4
bb4:
  %t19 = load i1, ptr %l14, !tbaa !21
  %t20 = xor i1 %t19, true
  br i1 %t20, label %bb5, label %bb6
bb5:
  br label %bb9
bb6:
  br label %bb7
bb7:
  %t22 = load i64, ptr %l2, !tbaa !24
  %t25 = sub i64 %t22, 1
  store i64 %t25, ptr %l2, !tbaa !24
  br label %bb8
bb8:
  br label %bb1
bb9:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t27, ptr %l24, !tbaa !27
  %t28 = load i64, ptr %l2, !tbaa !24
  store i64 %t28, ptr %l25, !tbaa !24
  %t29 = load i64, ptr %l1, !tbaa !24
  store i64 %t29, ptr %l26, !tbaa !24
  %t30 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t31 = extractvalue { i64, ptr } %t30, 0
  store i64 %t31, ptr %l27, !tbaa !24
  %t32 = load i64, ptr %l25, !tbaa !24
  %t33 = icmp sge i64 %t32, 0
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t35 = load i64, ptr %l25, !tbaa !24
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_e7281b11a7ac5d7_4fa3836323ed2ea3)
  unreachable
bb12:
  %t39 = load i64, ptr %l26, !tbaa !24
  %t40 = load i64, ptr %l27, !tbaa !24
  %t41 = icmp sle i64 %t39, %t40
  br i1 %t41, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_e7281b11a7ac5d7_4fa3836323ed2ea3)
  unreachable
bb14:
  %t43 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l25, !tbaa !24
  %t46 = load i64, ptr %l26, !tbaa !24
  %t47 = getelementptr i8, ptr %t44, i64 %t45
  %t48 = sub i64 %t46, %t45
  %t49 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l3, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t54 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t52, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t54, ptr %l33
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_e7281b11a7ac5d7_4fa3836323ed2ea3)
  unreachable
bb16:
  %t55 = load i1, ptr %l33, !tbaa !21
  %t56 = xor i1 %t55, true
  br i1 %t56, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t59 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t59, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  store i64 -1, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t60, 0
  store i64 %t62, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t64 = load i64, ptr %l6, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  %t68 = icmp sgt i64 %t64, %t65
  br i1 %t68, label %bb20, label %bb21
bb20:
  %t70 = load i64, ptr %l7, !tbaa !24
  %t72 = icmp sgt i64 %t70, 0
  br i1 %t72, label %bb22, label %bb23
bb21:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb25
bb22:
  %t74 = load i64, ptr %l6, !tbaa !24
  %t75 = load i64, ptr %l5, !tbaa !24
  %t78 = sub i64 %t74, %t75
  %t79 = load i64, ptr %l7, !tbaa !24
  %t82 = add i64 %t78, %t79
  %t84 = sub i64 %t82, 1
  %t85 = load i64, ptr %l7, !tbaa !24
  %t88 = sdiv i64 %t84, %t85
  store i64 %t88, ptr %l44, !tbaa !24
  br label %bb24
bb23:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb24
bb24:
  %t90 = load i64, ptr %l44, !tbaa !24
  store i64 %t90, ptr %l41, !tbaa !24
  br label %bb25
bb25:
  %t91 = load i64, ptr %l41, !tbaa !24
  store i64 %t91, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t92 = load i64, ptr %l8, !tbaa !24
  %t93 = sub i64 %t92, 1
  store i64 %t93, ptr %l53, !tbaa !24
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = icmp slt i64 %t94, 2147483648
  %t96 = load i64, ptr %l9, !tbaa !24
  %t97 = icmp sge i64 %t96, 0
  %t100 = and i1 %t95, %t97
  store i1 %t100, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t101 = load i64, ptr %l9, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  %t105 = icmp slt i64 %t101, %t102
  %t107 = xor i1 %t105, true
  br i1 %t107, label %bb27, label %bb28
bb27:
  br label %bb37
bb28:
  br label %bb29
bb29:
  %t109 = load i64, ptr %l5, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l7, !tbaa !24
  %t114 = mul i64 %t110, %t111
  %t117 = add i64 %t109, %t114
  store i64 %t117, ptr %l10, !tbaa !24
  %t119 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t119, ptr %l66, !tbaa !27
  %t120 = load i64, ptr %l10, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l66, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr i8, ptr %t123, i64 %t120
  %t125 = load i8, ptr %t124, !tbaa !32
  %t127 = icmp eq i8 %t125, 34
  br i1 %t127, label %bb30, label %bb31
bb30:
  %t129 = load i64, ptr %l4, !tbaa !24
  %t132 = icmp slt i64 %t129, 0
  br i1 %t132, label %bb32, label %bb33
bb31:
  br label %bb35
bb32:
  %t134 = load i64, ptr %l10, !tbaa !24
  store i64 %t134, ptr %l73, !tbaa !24
  br label %bb34
bb33:
  store i64 -2, ptr %l73, !tbaa !24
  br label %bb34
bb34:
  %t136 = load i64, ptr %l73, !tbaa !24
  store i64 %t136, ptr %l4, !tbaa !24
  br label %bb35
bb35:
  br label %bb36
bb36:
  %t137 = load i64, ptr %l9, !tbaa !24
  %t140 = add i64 %t137, 1
  store i64 %t140, ptr %l9, !tbaa !24
  br label %bb26
bb37:
  %t142 = load i64, ptr %l4, !tbaa !24
  %t144 = icmp slt i64 %t142, 0
  br i1 %t144, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t147 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t147, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t148 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t148, ptr %l81, !tbaa !27
  %t149 = load i64, ptr %l4, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l83, !tbaa !24
  %t152 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t152, 0
  store i64 %t155, ptr %l86, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  store i64 %t157, ptr %l87, !tbaa !24
  %t158 = load i64, ptr %l83, !tbaa !24
  %t159 = icmp sge i64 %t158, 0
  br i1 %t159, label %bb41, label %bb42
bb41:
  %t161 = load i64, ptr %l83, !tbaa !24
  %t162 = load i64, ptr %l86, !tbaa !24
  %t163 = icmp sle i64 %t161, %t162
  br i1 %t163, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @olang_loc_f161d409bbcfeffa_eff8e4c73ed9b6c6)
  unreachable
bb43:
  %t165 = load i64, ptr %l86, !tbaa !24
  %t166 = load i64, ptr %l87, !tbaa !24
  %t167 = icmp sle i64 %t165, %t166
  br i1 %t167, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_f161d409bbcfeffa_eff8e4c73ed9b6c6)
  unreachable
bb45:
  %t169 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = load i64, ptr %l83, !tbaa !24
  %t172 = load i64, ptr %l86, !tbaa !24
  %t173 = getelementptr i8, ptr %t170, i64 %t171
  %t174 = sub i64 %t172, %t171
  %t175 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t173, 1
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = extractvalue { i64, ptr } %t176, 0
  %t180 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t178, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  call void @__olang_scope_close(ptr %s0)
  %t184 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t182, 1
  store { i32, { i64, ptr } } %t184, ptr %rv
  br label %ret
bb46:
  call void @__olang_check_failed(ptr @olang_loc_f161d409bbcfeffa_eff8e4c73ed9b6c6)
  unreachable
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2ePromiseTargets(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %lp2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i64
  %l13 = alloca i8
  %l14 = alloca i64
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l68 = alloca i1
  %l69 = alloca i1
  %l71 = alloca i1
  %l72 = alloca i1
  %l74 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca { i64, ptr }
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i64
  %l132 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l144 = alloca i1
  %l146 = alloca i1
  %l149 = alloca i1
  %l151 = alloca i1
  %l156 = alloca i1
  %l157 = alloca { i64, ptr }
  %l160 = alloca i1
  %l165 = alloca ptr
  %l166 = alloca i64
  %l168 = alloca { i64, ptr }
  %l169 = alloca i64
  %l170 = alloca i64
  %l171 = alloca i64
  %l180 = alloca i1
  %l183 = alloca i1
  %l191 = alloca i1
  %l194 = alloca i1
  %l197 = alloca i1
  %l205 = alloca i1
  %l212 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i64
  %l215 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l15
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp2
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  %t4 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t11, ptr %l20, !tbaa !27
  %t12 = load i64, ptr %l3, !tbaa !24
  %t14 = sub i64 %t12, 1
  %t16 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr i8, ptr %t17, i64 %t14
  %t19 = load i8, ptr %t18, !tbaa !32
  %t21 = icmp ne i8 %t19, 10
  store i1 %t21, ptr %l19, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb5
bb5:
  %t23 = load i1, ptr %l19, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t29 = sub i64 %t26, 1
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  br label %bb2
bb10:
  %t31 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t31, ptr %l29, !tbaa !27
  %t32 = load i64, ptr %l3, !tbaa !24
  store i64 %t32, ptr %l30, !tbaa !24
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l31, !tbaa !24
  %t34 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l32, !tbaa !24
  %t36 = load i64, ptr %l30, !tbaa !24
  %t37 = icmp sge i64 %t36, 0
  br i1 %t37, label %bb11, label %bb12
bb11:
  %t39 = load i64, ptr %l30, !tbaa !24
  %t40 = load i64, ptr %l31, !tbaa !24
  %t41 = icmp sle i64 %t39, %t40
  br i1 %t41, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_5667240f2322ee2f_f3539aae4c478ceb)
  unreachable
bb13:
  %t43 = load i64, ptr %l31, !tbaa !24
  %t44 = load i64, ptr %l32, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_5667240f2322ee2f_f3539aae4c478ceb)
  unreachable
bb15:
  %t47 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = load i64, ptr %l30, !tbaa !24
  %t50 = load i64, ptr %l31, !tbaa !24
  %t51 = getelementptr i8, ptr %t48, i64 %t49
  %t52 = sub i64 %t50, %t49
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  store { i64, ptr } %t54, ptr %l4, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t58 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v0, { i64, ptr } %t56)
  store { i64, ptr } %t58, ptr %l38
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_5667240f2322ee2f_f3539aae4c478ceb)
  unreachable
bb17:
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t60 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %s0, ptr %s0, { i64, ptr } %t59, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store { i64, ptr } %t60, ptr %l39
  br label %bb18
bb18:
  %t61 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t61, ptr %l5, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t66 = icmp slt i64 %t64, 2
  br i1 %t66, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb22
bb20:
  %t68 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t72 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s0, { i64, ptr } %t68, { i64, ptr } %t71)
  store i1 %t72, ptr %l47
  br label %bb21
bb21:
  %t73 = load i1, ptr %l47, !tbaa !21
  %t74 = xor i1 %t73, true
  store i1 %t74, ptr %l43, !tbaa !21
  br label %bb22
bb22:
  %t76 = load i1, ptr %l43, !tbaa !21
  br i1 %t76, label %bb23, label %bb24
bb23:
  %t77 = load ptr, ptr %lp2
  %t79 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t77)
  store { i64, ptr } %t79, ptr %l50
  br label %bb25
bb24:
  br label %bb26
bb25:
  %t80 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t80, ptr %l51, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 0
  store i64 %t82, ptr %l52, !tbaa !24
  %t83 = load i64, ptr %l52, !tbaa !24
  %t84 = mul i64 %t83, 16
  %t85 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t84)
  %t86 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l53, !tbaa !27
  %t88 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = load i64, ptr %l52, !tbaa !24
  %t93 = mul i64 %t92, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t89, ptr %t91, i64 %t93, i1 false)
  %t94 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t94, ptr %l51, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t95 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t95, ptr %rv
  br label %ret
bb26:
  %t96 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t98 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t96, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t98, ptr %l55
  br label %bb27
bb27:
  %t99 = load i1, ptr %l55, !tbaa !21
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t100 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t100, ptr %l57, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 0
  %t105 = sub i64 %t103, 1
  %t107 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr { i64, ptr }, ptr %t108, i64 %t105
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !37
  store { i64, ptr } %t110, ptr %l56, !tbaa !27
  br label %bb30
bb29:
  %t112 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t112, ptr %l62, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t117 = sub i64 %t115, 2
  %t119 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t120 = load ptr, ptr %t119, !tbaa !27
  %t121 = getelementptr { i64, ptr }, ptr %t120, i64 %t117
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !37
  store { i64, ptr } %t122, ptr %l56, !tbaa !27
  br label %bb30
bb30:
  %t124 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t124, ptr %l6, !tbaa !27
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t127 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t125, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t127, ptr %l68
  br label %bb31
bb31:
  %t128 = load i1, ptr %l68, !tbaa !21
  br i1 %t128, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb35
bb33:
  %t129 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t129, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d56, i32 0, i32 1) })
  store i1 %t131, ptr %l71
  br label %bb34
bb34:
  %t132 = load i1, ptr %l71, !tbaa !21
  store i1 %t132, ptr %l69, !tbaa !21
  br label %bb35
bb35:
  %t133 = load i1, ptr %l69, !tbaa !21
  br i1 %t133, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l72, !tbaa !21
  br label %bb39
bb37:
  %t134 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t136 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t134, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t136, ptr %l74
  br label %bb38
bb38:
  %t137 = load i1, ptr %l74, !tbaa !21
  store i1 %t137, ptr %l72, !tbaa !21
  br label %bb39
bb39:
  %t138 = load i1, ptr %l72, !tbaa !21
  %t141 = xor i1 %t138, true
  br i1 %t141, label %bb40, label %bb41
bb40:
  %t143 = load ptr, ptr %lp2
  %t145 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t143)
  store { i64, ptr } %t145, ptr %l78
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t146 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t146, ptr %l79, !tbaa !27
  %t147 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  store i64 %t148, ptr %l80, !tbaa !24
  %t149 = load i64, ptr %l80, !tbaa !24
  %t150 = mul i64 %t149, 16
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l81, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l81, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = load i64, ptr %l80, !tbaa !24
  %t159 = mul i64 %t158, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t155, ptr %t157, i64 %t159, i1 false)
  %t160 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t160, ptr %l79, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t161 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t161, ptr %rv
  br label %ret
bb43:
  %t162 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t166 = sub i64 %t164, 1
  store i64 %t166, ptr %l8, !tbaa !24
  br label %bb44
bb44:
  %t168 = load i64, ptr %l8, !tbaa !24
  %t170 = icmp sge i64 %t168, 0
  br i1 %t170, label %bb45, label %bb46
bb45:
  %t172 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t172, ptr %l88, !tbaa !27
  %t173 = load i64, ptr %l8, !tbaa !24
  %t175 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = getelementptr i8, ptr %t176, i64 %t173
  %t178 = load i8, ptr %t177, !tbaa !32
  %t180 = icmp ne i8 %t178, 41
  store i1 %t180, ptr %l87, !tbaa !21
  br label %bb47
bb46:
  store i1 false, ptr %l87, !tbaa !21
  br label %bb47
bb47:
  %t182 = load i1, ptr %l87, !tbaa !21
  %t183 = xor i1 %t182, true
  br i1 %t183, label %bb48, label %bb49
bb48:
  br label %bb52
bb49:
  br label %bb50
bb50:
  %t185 = load i64, ptr %l8, !tbaa !24
  %t188 = sub i64 %t185, 1
  store i64 %t188, ptr %l8, !tbaa !24
  br label %bb51
bb51:
  br label %bb44
bb52:
  %t190 = load i64, ptr %l8, !tbaa !24
  %t192 = icmp slt i64 %t190, 0
  br i1 %t192, label %bb53, label %bb54
bb53:
  %t194 = load ptr, ptr %lp2
  %t196 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t194)
  store { i64, ptr } %t196, ptr %l99
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t197 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t197, ptr %l100, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  store i64 %t199, ptr %l101, !tbaa !24
  %t200 = load i64, ptr %l101, !tbaa !24
  %t201 = mul i64 %t200, 16
  %t202 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t201)
  %t203 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  store { i64, ptr } %t204, ptr %l102, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t206 = load ptr, ptr %t205, !tbaa !27
  %t207 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l101, !tbaa !24
  %t210 = mul i64 %t209, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t206, ptr %t208, i64 %t210, i1 false)
  %t211 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t211, ptr %l100, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t212 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t212, ptr %rv
  br label %ret
bb56:
  %t213 = load i64, ptr %l8, !tbaa !24
  store i64 %t213, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb57
bb57:
  %t215 = load i64, ptr %l9, !tbaa !24
  %t217 = icmp sge i64 %t215, 0
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb58, label %bb59
bb58:
  br label %bb71
bb59:
  br label %bb60
bb60:
  %t221 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t221, ptr %l107, !tbaa !27
  %t222 = load i64, ptr %l9, !tbaa !24
  %t224 = getelementptr { i64, ptr }, ptr %l107, i32 0, i32 1
  %t225 = load ptr, ptr %t224, !tbaa !27
  %t226 = getelementptr i8, ptr %t225, i64 %t222
  %t227 = load i8, ptr %t226, !tbaa !32
  %t229 = icmp eq i8 %t227, 41
  br i1 %t229, label %bb61, label %bb62
bb61:
  %t231 = load i64, ptr %l10, !tbaa !24
  %t234 = add i64 %t231, 1
  store i64 %t234, ptr %l10, !tbaa !24
  br label %bb63
bb62:
  br label %bb63
bb63:
  %t236 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t236, ptr %l114, !tbaa !27
  %t237 = load i64, ptr %l9, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t240 = load ptr, ptr %t239, !tbaa !27
  %t241 = getelementptr i8, ptr %t240, i64 %t237
  %t242 = load i8, ptr %t241, !tbaa !32
  %t244 = icmp eq i8 %t242, 40
  br i1 %t244, label %bb64, label %bb65
bb64:
  %t246 = load i64, ptr %l10, !tbaa !24
  %t249 = sub i64 %t246, 1
  store i64 %t249, ptr %l10, !tbaa !24
  br label %bb66
bb65:
  br label %bb66
bb66:
  %t251 = load i64, ptr %l10, !tbaa !24
  %t253 = icmp eq i64 %t251, 0
  br i1 %t253, label %bb67, label %bb68
bb67:
  br label %bb71
bb68:
  br label %bb69
bb69:
  %t255 = load i64, ptr %l9, !tbaa !24
  %t258 = sub i64 %t255, 1
  store i64 %t258, ptr %l9, !tbaa !24
  br label %bb70
bb70:
  br label %bb57
bb71:
  %t260 = load i64, ptr %l9, !tbaa !24
  %t262 = icmp slt i64 %t260, 0
  br i1 %t262, label %bb72, label %bb73
bb72:
  %t264 = load ptr, ptr %lp2
  %t266 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t264)
  store { i64, ptr } %t266, ptr %l129
  br label %bb74
bb73:
  br label %bb75
bb74:
  %t267 = load { i64, ptr }, ptr %l129, !tbaa !27
  store { i64, ptr } %t267, ptr %l130, !tbaa !27
  %t268 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  store i64 %t269, ptr %l131, !tbaa !24
  %t270 = load i64, ptr %l131, !tbaa !24
  %t271 = mul i64 %t270, 16
  %t272 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t271)
  %t273 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  store { i64, ptr } %t274, ptr %l132, !tbaa !27
  %t275 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = load i64, ptr %l131, !tbaa !24
  %t280 = mul i64 %t279, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t276, ptr %t278, i64 %t280, i1 false)
  %t281 = load { i64, ptr }, ptr %l132, !tbaa !27
  store { i64, ptr } %t281, ptr %l130, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t282 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t282, ptr %rv
  br label %ret
bb75:
  store i1 true, ptr %l11, !tbaa !21
  %t283 = load i64, ptr %l9, !tbaa !24
  %t285 = add i64 %t283, 1
  store i64 %t285, ptr %l12, !tbaa !24
  br label %bb76
bb76:
  %t287 = load i64, ptr %l12, !tbaa !24
  %t288 = load i64, ptr %l8, !tbaa !24
  %t291 = icmp slt i64 %t287, %t288
  %t293 = xor i1 %t291, true
  br i1 %t293, label %bb77, label %bb78
bb77:
  br label %bb140
bb78:
  br label %bb79
bb79:
  %t295 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t295, ptr %l139, !tbaa !27
  %t296 = load i64, ptr %l12, !tbaa !24
  %t298 = getelementptr { i64, ptr }, ptr %l139, i32 0, i32 1
  %t299 = load ptr, ptr %t298, !tbaa !27
  %t300 = getelementptr i8, ptr %t299, i64 %t296
  %t301 = load i8, ptr %t300, !tbaa !32
  store i8 %t301, ptr %l13, !tbaa !22
  %t303 = load i64, ptr %l10, !tbaa !24
  %t305 = icmp eq i64 %t303, 0
  br i1 %t305, label %bb80, label %bb81
bb80:
  %t307 = load i1, ptr %l11, !tbaa !21
  store i1 %t307, ptr %l144, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb82
bb82:
  %t309 = load i1, ptr %l144, !tbaa !21
  br i1 %t309, label %bb83, label %bb84
bb83:
  %t310 = load i8, ptr %l13, !tbaa !22
  %t312 = icmp eq i8 %t310, 95
  br i1 %t312, label %bb85, label %bb86
bb84:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb89
bb85:
  store i1 true, ptr %l149, !tbaa !21
  br label %bb88
bb86:
  %t314 = load i8, ptr %l13, !tbaa !22
  %t316 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t314)
  store i1 %t316, ptr %l151
  br label %bb87
bb87:
  %t317 = load i1, ptr %l151, !tbaa !21
  store i1 %t317, ptr %l149, !tbaa !21
  br label %bb88
bb88:
  %t318 = load i1, ptr %l149, !tbaa !21
  store i1 %t318, ptr %l146, !tbaa !21
  br label %bb89
bb89:
  %t319 = load i1, ptr %l146, !tbaa !21
  br i1 %t319, label %bb90, label %bb91
bb90:
  %t320 = load i64, ptr %l12, !tbaa !24
  store i64 %t320, ptr %l14, !tbaa !24
  br label %bb92
bb91:
  br label %bb111
bb92:
  %t322 = load i64, ptr %l12, !tbaa !24
  %t323 = load i64, ptr %l8, !tbaa !24
  %t326 = icmp slt i64 %t322, %t323
  br i1 %t326, label %bb93, label %bb94
bb93:
  %t328 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t328, ptr %l157, !tbaa !27
  %t329 = load i64, ptr %l12, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l157, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr i8, ptr %t332, i64 %t329
  %t334 = load i8, ptr %t333, !tbaa !32
  %t336 = call i1 @compiler_2fsession_2eWordChar(i8 %t334)
  store i1 %t336, ptr %l160
  br label %bb95
bb94:
  store i1 false, ptr %l156, !tbaa !21
  br label %bb96
bb95:
  %t337 = load i1, ptr %l160, !tbaa !21
  store i1 %t337, ptr %l156, !tbaa !21
  br label %bb96
bb96:
  %t338 = load i1, ptr %l156, !tbaa !21
  %t339 = xor i1 %t338, true
  br i1 %t339, label %bb97, label %bb98
bb97:
  br label %bb101
bb98:
  br label %bb99
bb99:
  %t341 = load i64, ptr %l12, !tbaa !24
  %t344 = add i64 %t341, 1
  store i64 %t344, ptr %l12, !tbaa !24
  br label %bb100
bb100:
  br label %bb92
bb101:
  %t346 = load ptr, ptr %lp2
  store ptr %t346, ptr %l165, !tbaa !29
  %t347 = call ptr @__olang_scope_hold(ptr %v1)
  %t348 = ptrtoint ptr %t347 to i64
  store i64 %t348, ptr %l166, !tbaa !24
  %t349 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t349, label %bb102, label %bb103
bb102:
  %t351 = call ptr @__olang_region_make(ptr %v1)
  %t352 = ptrtoint ptr %t351 to i64
  store i64 %t352, ptr %l166, !tbaa !24
  br label %bb103
bb103:
  %t353 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t353, ptr %l168, !tbaa !27
  %t354 = load i64, ptr %l14, !tbaa !24
  store i64 %t354, ptr %l169, !tbaa !24
  %t355 = load i64, ptr %l12, !tbaa !24
  store i64 %t355, ptr %l170, !tbaa !24
  %t356 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t357 = extractvalue { i64, ptr } %t356, 0
  store i64 %t357, ptr %l171, !tbaa !24
  %t358 = load i64, ptr %l169, !tbaa !24
  %t359 = icmp sge i64 %t358, 0
  br i1 %t359, label %bb104, label %bb105
bb104:
  %t361 = load i64, ptr %l169, !tbaa !24
  %t362 = load i64, ptr %l170, !tbaa !24
  %t363 = icmp sle i64 %t361, %t362
  br i1 %t363, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_eb90226238b175b2_1f1bdee85222deee)
  unreachable
bb106:
  %t365 = load i64, ptr %l170, !tbaa !24
  %t366 = load i64, ptr %l171, !tbaa !24
  %t367 = icmp sle i64 %t365, %t366
  br i1 %t367, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_eb90226238b175b2_1f1bdee85222deee)
  unreachable
bb108:
  %t369 = getelementptr { i64, ptr }, ptr %l168, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = load i64, ptr %l169, !tbaa !24
  %t372 = load i64, ptr %l170, !tbaa !24
  %t373 = getelementptr i8, ptr %t370, i64 %t371
  %t374 = sub i64 %t372, %t371
  %t375 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t376 = insertvalue { i64, ptr } %t375, ptr %t373, 1
  %t378 = extractvalue { i64, ptr } %t376, 1
  %t379 = extractvalue { i64, ptr } %t376, 0
  %t380 = load i64, ptr %l166
  %t381 = inttoptr i64 %t380 to ptr
  %t382 = call ptr @__olang_held_alloc(ptr %t381, i64 %t379)
  call void @olang_textcopy(ptr %t382, ptr %t378, i64 %t379)
  %t383 = insertvalue { i64, ptr } undef, i64 %t379, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t382, 1
  %t386 = load ptr, ptr %l165, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t386, { i64, ptr } %t384)
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_eb90226238b175b2_1f1bdee85222deee)
  unreachable
bb110:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb139
bb111:
  %t388 = load i8, ptr %l13, !tbaa !22
  %t390 = icmp eq i8 %t388, 40
  br i1 %t390, label %bb112, label %bb113
bb112:
  store i1 true, ptr %l180, !tbaa !21
  br label %bb114
bb113:
  %t392 = load i8, ptr %l13, !tbaa !22
  %t394 = icmp eq i8 %t392, 60
  store i1 %t394, ptr %l180, !tbaa !21
  br label %bb114
bb114:
  %t396 = load i1, ptr %l180, !tbaa !21
  br i1 %t396, label %bb115, label %bb116
bb115:
  store i1 true, ptr %l183, !tbaa !21
  br label %bb117
bb116:
  %t397 = load i8, ptr %l13, !tbaa !22
  %t399 = icmp eq i8 %t397, 91
  store i1 %t399, ptr %l183, !tbaa !21
  br label %bb117
bb117:
  %t401 = load i1, ptr %l183, !tbaa !21
  br i1 %t401, label %bb118, label %bb119
bb118:
  %t402 = load i64, ptr %l10, !tbaa !24
  %t405 = add i64 %t402, 1
  store i64 %t405, ptr %l10, !tbaa !24
  br label %bb120
bb119:
  br label %bb120
bb120:
  %t407 = load i8, ptr %l13, !tbaa !22
  %t409 = icmp eq i8 %t407, 41
  br i1 %t409, label %bb121, label %bb122
bb121:
  store i1 true, ptr %l191, !tbaa !21
  br label %bb123
bb122:
  %t411 = load i8, ptr %l13, !tbaa !22
  %t413 = icmp eq i8 %t411, 62
  store i1 %t413, ptr %l191, !tbaa !21
  br label %bb123
bb123:
  %t415 = load i1, ptr %l191, !tbaa !21
  br i1 %t415, label %bb124, label %bb125
bb124:
  store i1 true, ptr %l194, !tbaa !21
  br label %bb126
bb125:
  %t416 = load i8, ptr %l13, !tbaa !22
  %t418 = icmp eq i8 %t416, 93
  store i1 %t418, ptr %l194, !tbaa !21
  br label %bb126
bb126:
  %t420 = load i1, ptr %l194, !tbaa !21
  br i1 %t420, label %bb127, label %bb128
bb127:
  %t421 = load i64, ptr %l10, !tbaa !24
  %t423 = icmp sgt i64 %t421, 0
  store i1 %t423, ptr %l197, !tbaa !21
  br label %bb129
bb128:
  store i1 false, ptr %l197, !tbaa !21
  br label %bb129
bb129:
  %t425 = load i1, ptr %l197, !tbaa !21
  br i1 %t425, label %bb130, label %bb131
bb130:
  %t426 = load i64, ptr %l10, !tbaa !24
  %t429 = sub i64 %t426, 1
  store i64 %t429, ptr %l10, !tbaa !24
  br label %bb132
bb131:
  br label %bb132
bb132:
  %t431 = load i64, ptr %l10, !tbaa !24
  %t433 = icmp eq i64 %t431, 0
  br i1 %t433, label %bb133, label %bb134
bb133:
  %t435 = load i8, ptr %l13, !tbaa !22
  %t437 = icmp eq i8 %t435, 44
  store i1 %t437, ptr %l205, !tbaa !21
  br label %bb135
bb134:
  store i1 false, ptr %l205, !tbaa !21
  br label %bb135
bb135:
  %t439 = load i1, ptr %l205, !tbaa !21
  br i1 %t439, label %bb136, label %bb137
bb136:
  store i1 true, ptr %l11, !tbaa !21
  br label %bb138
bb137:
  br label %bb138
bb138:
  %t440 = load i64, ptr %l12, !tbaa !24
  %t443 = add i64 %t440, 1
  store i64 %t443, ptr %l12, !tbaa !24
  br label %bb139
bb139:
  br label %bb76
bb140:
  %t445 = load ptr, ptr %lp2
  %t447 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t445)
  store { i64, ptr } %t447, ptr %l212
  br label %bb141
bb141:
  %t448 = load { i64, ptr }, ptr %l212, !tbaa !27
  store { i64, ptr } %t448, ptr %l213, !tbaa !27
  %t449 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t450 = extractvalue { i64, ptr } %t449, 0
  store i64 %t450, ptr %l214, !tbaa !24
  %t451 = load i64, ptr %l214, !tbaa !24
  %t452 = mul i64 %t451, 16
  %t453 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t452)
  %t454 = insertvalue { i64, ptr } undef, i64 %t451, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t453, 1
  store { i64, ptr } %t455, ptr %l215, !tbaa !27
  %t456 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t457 = load ptr, ptr %t456, !tbaa !27
  %t458 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = load i64, ptr %l214, !tbaa !24
  %t461 = mul i64 %t460, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t457, ptr %t459, i64 %t461, i1 false)
  %t462 = load { i64, ptr }, ptr %l215, !tbaa !27
  store { i64, ptr } %t462, ptr %l213, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t463 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t463, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0, i32 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca %"<poll.h>:pollfd"
  %l22 = alloca %"<poll.h>:pollfd"
  %l30 = alloca i64
  %l33 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i1
  %l56 = alloca { i64, ptr }
  %l65 = alloca i64
  %l72 = alloca i32
  %l79 = alloca i64
  %l82 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t21 = alloca i64
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l19, !tbaa !24
  store %"<poll.h>:pollfd" zeroinitializer, ptr %l20
  %t6 = load i64, ptr %l19, !tbaa !24
  %t7 = icmp sgt i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = call %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd()
  store %"<poll.h>:pollfd" %t9, ptr %l22
  br label %bb3
bb2:
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp sge i64 %t10, 0
  br i1 %t11, label %bb4, label %bb5
bb3:
  %t13 = load %"<poll.h>:pollfd", ptr %l22
  store %"<poll.h>:pollfd" %t13, ptr %l20
  br label %bb2
bb4:
  %t14 = load i64, ptr %l19, !tbaa !24
  %t15 = icmp sle i64 %t14, 1152921504606846975
  br i1 %t15, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_6afc88ea1ac145e8_494a63ded86193f4)
  unreachable
bb6:
  %t17 = load i64, ptr %l19, !tbaa !24
  %t18 = mul i64 %t17, 8
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  %t20 = load %"<poll.h>:pollfd", ptr %l20
  store i64 0, ptr %t21
  br label %fill.22
fill.22:
  %t25 = load i64, ptr %t21
  %t26 = icmp slt i64 %t25, %t17
  br i1 %t26, label %fillb.23, label %filld.24
fillb.23:
  %t27 = getelementptr %"<poll.h>:pollfd", ptr %t19, i64 %t25
  store %"<poll.h>:pollfd" %t20, ptr %t27
  %t28 = add i64 %t25, 1
  store i64 %t28, ptr %t21
  br label %fill.22
filld.24:
  %t29 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t19, 1
  store { i64, ptr } %t30, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t35 = load i64, ptr %l4, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6afc88ea1ac145e8_494a63ded86193f4)
  unreachable
bb8:
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb10, label %bb11
bb9:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb10:
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load i64, ptr %l4, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l6, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l6, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l33, !tbaa !24
  br label %bb12
bb11:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb12
bb12:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l30, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  %t62 = load i64, ptr %l7, !tbaa !24
  %t63 = sub i64 %t62, 1
  store i64 %t63, ptr %l42, !tbaa !24
  %t64 = load i64, ptr %l7, !tbaa !24
  %t65 = icmp slt i64 %t64, 2147483648
  %t66 = load i64, ptr %l8, !tbaa !24
  %t67 = icmp sge i64 %t66, 0
  %t70 = and i1 %t65, %t67
  store i1 %t70, ptr %l45, !tbaa !21
  br label %bb14
bb14:
  %t71 = load i64, ptr %l8, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = icmp slt i64 %t71, %t72
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t79 = load i64, ptr %l4, !tbaa !24
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = mul i64 %t80, %t81
  %t87 = add i64 %t79, %t84
  store i64 %t87, ptr %l9, !tbaa !24
  %t89 = load i64, ptr %l9, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t90, ptr %l56, !tbaa !27
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t94 = load ptr, ptr %t93, !tbaa !27
  %t95 = getelementptr i32, ptr %t94, i64 %t91
  %t96 = load i32, ptr %t95, !tbaa !33
  %t99 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr %"<poll.h>:pollfd", ptr %t100, i64 %t89
  %t102 = getelementptr %"<poll.h>:pollfd", ptr %t101, i32 0, i32 0
  store i32 %t96, ptr %t102, !tbaa !23
  %t103 = load i64, ptr %l9, !tbaa !24
  %t104 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t106 = trunc i32 %t104 to i16
  %t109 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr %"<poll.h>:pollfd", ptr %t110, i64 %t103
  %t112 = getelementptr %"<poll.h>:pollfd", ptr %t111, i32 0, i32 1
  store i16 %t106, ptr %t112, !tbaa !62
  br label %bb18
bb18:
  %t113 = load i64, ptr %l8, !tbaa !24
  %t116 = add i64 %t113, 1
  store i64 %t116, ptr %l8, !tbaa !24
  br label %bb14
bb19:
  %t118 = load i64, ptr %l2, !tbaa !24
  store i64 %t118, ptr %l65, !tbaa !24
  %t119 = load i64, ptr %l65, !tbaa !24
  %t120 = icmp sge i64 %t119, 0
  br i1 %t120, label %bb20, label %bb21
bb20:
  %t122 = load i64, ptr %l65, !tbaa !24
  %t123 = mul i64 %t122, 1
  %t124 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  store { i64, ptr } %t126, ptr %l10, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t129 = load i64, ptr %l2, !tbaa !24
  %t133 = extractvalue { i64, ptr } %t128, 1
  %t134 = extractvalue { i64, ptr } %t128, 0
  %t137 = call i32 @poll(ptr %t133, i64 %t129, i32 %a1)
  store i32 %t137, ptr %l72
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @olang_loc_cd9998fc5b6bf5d5_fa43d55bb2deeb01)
  unreachable
bb22:
  %t138 = load i32, ptr %l72, !tbaa !23
  %t139 = icmp sle i32 %t138, 0
  br i1 %t139, label %bb23, label %bb24
bb23:
  %t141 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t141, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  store i64 0, ptr %l11, !tbaa !24
  %t143 = load i64, ptr %l2, !tbaa !24
  store i64 %t143, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t145 = load i64, ptr %l12, !tbaa !24
  %t146 = load i64, ptr %l11, !tbaa !24
  %t149 = icmp sgt i64 %t145, %t146
  br i1 %t149, label %bb26, label %bb27
bb26:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t153 = icmp sgt i64 %t151, 0
  br i1 %t153, label %bb28, label %bb29
bb27:
  store i64 0, ptr %l79, !tbaa !24
  br label %bb31
bb28:
  %t155 = load i64, ptr %l12, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = sub i64 %t155, %t156
  %t160 = load i64, ptr %l13, !tbaa !24
  %t163 = add i64 %t159, %t160
  %t165 = sub i64 %t163, 1
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = sdiv i64 %t165, %t166
  store i64 %t169, ptr %l82, !tbaa !24
  br label %bb30
bb29:
  store i64 0, ptr %l82, !tbaa !24
  br label %bb30
bb30:
  %t171 = load i64, ptr %l82, !tbaa !24
  store i64 %t171, ptr %l79, !tbaa !24
  br label %bb31
bb31:
  %t172 = load i64, ptr %l79, !tbaa !24
  store i64 %t172, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  %t173 = load i64, ptr %l14, !tbaa !24
  %t174 = sub i64 %t173, 1
  store i64 %t174, ptr %l91, !tbaa !24
  %t175 = load i64, ptr %l14, !tbaa !24
  %t176 = icmp slt i64 %t175, 2147483648
  %t177 = load i64, ptr %l15, !tbaa !24
  %t178 = icmp sge i64 %t177, 0
  %t181 = and i1 %t176, %t178
  store i1 %t181, ptr %l94, !tbaa !21
  br label %bb32
bb32:
  %t182 = load i64, ptr %l15, !tbaa !24
  %t183 = load i64, ptr %l14, !tbaa !24
  %t186 = icmp slt i64 %t182, %t183
  %t188 = xor i1 %t186, true
  br i1 %t188, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  %t190 = load i64, ptr %l11, !tbaa !24
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l13, !tbaa !24
  %t195 = mul i64 %t191, %t192
  %t198 = add i64 %t190, %t195
  store i64 %t198, ptr %l16, !tbaa !24
  %t200 = load i64, ptr %l16, !tbaa !24
  %t201 = load i64, ptr %l16, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr %"<poll.h>:pollfd", ptr %t204, i64 %t201
  %t206 = getelementptr %"<poll.h>:pollfd", ptr %t205, i32 0, i32 2
  %t207 = load i16, ptr %t206, !tbaa !62
  %t208 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLIN, !tbaa !23
  %t209 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLERR, !tbaa !23
  %t212 = or i32 %t208, %t209
  %t213 = load i32, ptr @G_2e_3cpoll_2eh_3e_2ePOLLHUP, !tbaa !23
  %t216 = or i32 %t212, %t213
  %t218 = trunc i32 %t216 to i16
  %t221 = and i16 %t207, %t218
  %t223 = icmp ne i16 %t221, 0
  %t226 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i1, ptr %t227, i64 %t200
  store i1 %t223, ptr %t228, !tbaa !31
  br label %bb36
bb36:
  %t229 = load i64, ptr %l15, !tbaa !24
  %t232 = add i64 %t229, 1
  store i64 %t232, ptr %l15, !tbaa !24
  br label %bb32
bb37:
  %t234 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t234, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eStdModule(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca [2 x { i64, ptr }]
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store i1 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = call ptr @__olang_scope_hold(ptr %s1)
  %t6 = ptrtoint ptr %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t7, label %bb4, label %bb5
bb3:
  br label %bb14
bb4:
  %t9 = call ptr @__olang_region_make(ptr %s1)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t11 = load i64, ptr %l4
  %t12 = inttoptr i64 %t11 to ptr
  %t13 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %t12)
  store { i64, ptr } %t13, ptr %l6
  br label %bb6
bb6:
  %t14 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t15 = load i64, ptr %l4
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = extractvalue { i64, ptr } %t14, 0
  %t18 = extractvalue { i64, ptr } %t14, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_held_alloc(ptr %t16, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l7, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t24, 0
  store i64 %t27, ptr %l11, !tbaa !24
  %t28 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t28, 0
  store i64 %t29, ptr %l12, !tbaa !24
  %t30 = icmp sge i64 4, 0
  br i1 %t30, label %bb7, label %bb8
bb7:
  %t32 = load i64, ptr %l11, !tbaa !24
  %t33 = icmp sle i64 4, %t32
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb9:
  %t35 = load i64, ptr %l11, !tbaa !24
  %t36 = load i64, ptr %l12, !tbaa !24
  %t37 = icmp sle i64 %t35, %t36
  br i1 %t37, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb11:
  %t39 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = load i64, ptr %l11, !tbaa !24
  %t42 = getelementptr i8, ptr %t40, i64 4
  %t43 = sub i64 %t41, 4
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t46 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t47 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t46, 0
  %t49 = insertvalue [2 x { i64, ptr }] %t47, { i64, ptr } %t45, 1
  store [2 x { i64, ptr }] %t49, ptr %l1
  %t52 = insertvalue { i64, ptr } undef, i64 2, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %l1, 1
  %t55 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s1, ptr %s1, { i64, ptr } %t53)
  store { i64, ptr } %t55, ptr %l20
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_b18535922df9c451_739a4491ef7ea55d)
  unreachable
bb13:
  %t56 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t61 = add i64 %t58, %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @olang_textcopy(ptr %t62, ptr %t57, i64 %t58)
  %t63 = getelementptr i8, ptr %t62, i64 %t58
  call void @olang_textcopy(ptr %t63, ptr %t59, i64 %t60)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t62, 1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb14:
  %t67 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t67, 1
  %t70 = extractvalue { i64, ptr } %t67, 0
  %t71 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t73 = add i64 %t70, %t72
  %t74 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t73)
  call void @olang_textcopy(ptr %t74, ptr %t69, i64 %t70)
  %t75 = getelementptr i8, ptr %t74, i64 %t70
  call void @olang_textcopy(ptr %t75, ptr %t71, i64 %t72)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t74, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t77, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eDeprecatedUses(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l23 = alloca { { i64, ptr }, i64, i64 }
  %lp24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l30 = alloca i64
  %l33 = alloca i1
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i64
  %l46 = alloca i64
  %l49 = alloca i64
  %l71 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca i64
  %l82 = alloca i64
  %l87 = alloca { i64, ptr }
  %l97 = alloca i64
  %l102 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l119 = alloca i64
  %l122 = alloca i64
  %l132 = alloca { i64, ptr }
  %l135 = alloca i1
  %l144 = alloca i1
  %l145 = alloca { i64, ptr }
  %l148 = alloca i1
  %l153 = alloca { i64, ptr }
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i64
  %l164 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i64
  %l172 = alloca %"compiler/source:Span"
  %l173 = alloca { i64, [6 x i64] }
  %l176 = alloca { { i64, ptr }, i64, i64 }
  %l177 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca { i64, ptr }
  %l183 = alloca i1
  %l185 = alloca i1
  %l189 = alloca i1
  %l192 = alloca i64
  %l195 = alloca i64
  %l198 = alloca ptr
  %l202 = alloca %"compiler/session:Use"
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  store i64 %t7, ptr %l30
  br label %bb2
bb2:
  %t8 = load i64, ptr %l30, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/session:Analysis", ptr %t13, i32 0, i32 2
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  store i1 %t18, ptr %l33, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l33, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l38
  br label %bb9
bb9:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/session:Analysis", ptr %t25, i32 0, i32 0
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/load:Loader", ptr %t28, i32 0, i32 10
  %t32 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t30)
  store i64 %t32, ptr %l42
  br label %bb10
bb10:
  %t33 = load i64, ptr %l42, !tbaa !24
  store i64 %t33, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t34 = load i64, ptr %l6, !tbaa !24
  %t35 = load i64, ptr %l5, !tbaa !24
  %t38 = icmp sgt i64 %t34, %t35
  br i1 %t38, label %bb11, label %bb12
bb11:
  %t40 = load i64, ptr %l7, !tbaa !24
  %t42 = icmp sgt i64 %t40, 0
  br i1 %t42, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l46, !tbaa !24
  br label %bb16
bb13:
  %t44 = load i64, ptr %l6, !tbaa !24
  %t45 = load i64, ptr %l5, !tbaa !24
  %t48 = sub i64 %t44, %t45
  %t49 = load i64, ptr %l7, !tbaa !24
  %t52 = add i64 %t48, %t49
  %t54 = sub i64 %t52, 1
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = sdiv i64 %t54, %t55
  store i64 %t58, ptr %l49, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l49, !tbaa !24
  br label %bb15
bb15:
  %t60 = load i64, ptr %l49, !tbaa !24
  store i64 %t60, ptr %l46, !tbaa !24
  br label %bb16
bb16:
  %t61 = load i64, ptr %l46, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb17
bb17:
  %t62 = load i64, ptr %l9, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  %t66 = icmp slt i64 %t62, %t63
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb18, label %bb19
bb18:
  br label %bb37
bb19:
  br label %bb20
bb20:
  %t70 = load i64, ptr %l5, !tbaa !24
  %t71 = load i64, ptr %l9, !tbaa !24
  %t72 = load i64, ptr %l7, !tbaa !24
  %t75 = mul i64 %t71, %t72
  %t78 = add i64 %t70, %t75
  store i64 %t78, ptr %l10, !tbaa !24
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/session:Analysis", ptr %t80, i32 0, i32 0
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t85 = getelementptr %"compiler/load:Loader", ptr %t83, i32 0, i32 10
  %t86 = load i64, ptr %l10, !tbaa !24
  %t89 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t85, i64 %t86)
  store ptr %t89, ptr %l71
  br label %bb21
bb21:
  %t90 = load ptr, ptr %l71, !tbaa !29
  %t92 = getelementptr %"compiler/load:Module", ptr %t90, i32 0, i32 6
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = icmp eq ptr %t93, null
  br i1 %t95, label %bb22, label %bb23
bb22:
  br label %bb36
bb23:
  br label %bb24
bb24:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l10, !tbaa !24
  %t101 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t97, i64 %t98)
  store { i64, ptr } %t101, ptr %l77
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t103 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eDeprecatedNames(ptr %v0, ptr %s0, { i64, ptr } %t102)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t103, ptr %l78
  br label %bb26
bb26:
  %t104 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  %t105 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %t105
  store ptr %t105, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  %t107 = load i64, ptr %l12, !tbaa !24
  store i64 %t107, ptr %l80, !tbaa !24
  %t108 = load ptr, ptr %l11, !tbaa !29
  %t110 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t108)
  store i64 %t110, ptr %l82
  br label %bb28
bb28:
  %t111 = load i64, ptr %l80, !tbaa !24
  %t112 = load i64, ptr %l82, !tbaa !24
  %t113 = icmp slt i64 %t111, %t112
  %t115 = xor i1 %t113, true
  br i1 %t115, label %bb29, label %bb30
bb29:
  br label %bb35
bb30:
  br label %bb31
bb31:
  %t117 = load ptr, ptr %l11, !tbaa !29
  %t118 = load i64, ptr %l12, !tbaa !24
  %t121 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t117, i64 %t118)
  store { i64, ptr } %t121, ptr %l87
  br label %bb32
bb32:
  %t122 = load { i64, ptr }, ptr %l87, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t122)
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = add i64 %t126, 1
  store i64 %t129, ptr %l12, !tbaa !24
  br label %bb27
bb35:
  br label %bb36
bb36:
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l9, !tbaa !24
  br label %bb17
bb37:
  %t137 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l4)
  store i64 %t137, ptr %l97
  br label %bb38
bb38:
  %t138 = load i64, ptr %l97, !tbaa !24
  %t139 = icmp eq i64 %t138, 0
  br i1 %t139, label %bb39, label %bb40
bb39:
  %t141 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i64, ptr %l3, !tbaa !24
  %t147 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t143, i64 %t144)
  store { i64, ptr } %t147, ptr %l102
  br label %bb42
bb42:
  %t148 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t148, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  br label %bb43
bb43:
  %t149 = load i64, ptr %l15, !tbaa !24
  %t150 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t155 = icmp sle i64 %t149, %t152
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb44, label %bb45
bb44:
  br label %bb106
bb45:
  br label %bb46
bb46:
  %t159 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t160 = load i64, ptr %l15, !tbaa !24
  %t163 = call i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %t159, i64 %t160)
  store i64 %t163, ptr %l110
  br label %bb47
bb47:
  %t164 = load i64, ptr %l110, !tbaa !24
  store i64 %t164, ptr %l16, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t165, ptr %l111, !tbaa !27
  %t166 = load i64, ptr %l15, !tbaa !24
  store i64 %t166, ptr %l112, !tbaa !24
  %t167 = load i64, ptr %l16, !tbaa !24
  store i64 %t167, ptr %l113, !tbaa !24
  %t168 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 0
  store i64 %t169, ptr %l114, !tbaa !24
  %t170 = load i64, ptr %l112, !tbaa !24
  %t171 = icmp sge i64 %t170, 0
  br i1 %t171, label %bb48, label %bb49
bb48:
  %t173 = load i64, ptr %l112, !tbaa !24
  %t174 = load i64, ptr %l113, !tbaa !24
  %t175 = icmp sle i64 %t173, %t174
  br i1 %t175, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_7ada9cad4f5dae06_e1e48e82a4e1a6ca)
  unreachable
bb50:
  %t177 = load i64, ptr %l113, !tbaa !24
  %t178 = load i64, ptr %l114, !tbaa !24
  %t179 = icmp sle i64 %t177, %t178
  br i1 %t179, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_7ada9cad4f5dae06_e1e48e82a4e1a6ca)
  unreachable
bb52:
  %t181 = getelementptr { i64, ptr }, ptr %l111, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = load i64, ptr %l112, !tbaa !24
  %t184 = load i64, ptr %l113, !tbaa !24
  %t185 = getelementptr i8, ptr %t182, i64 %t183
  %t186 = sub i64 %t184, %t183
  %t187 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t185, 1
  %t190 = call i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %t188)
  store i64 %t190, ptr %l119
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_7ada9cad4f5dae06_e1e48e82a4e1a6ca)
  unreachable
bb54:
  %t191 = load i64, ptr %l119, !tbaa !24
  store i64 %t191, ptr %l17, !tbaa !24
  %t192 = load i64, ptr %l17, !tbaa !24
  %t194 = icmp slt i64 %t192, 0
  br i1 %t194, label %bb55, label %bb56
bb55:
  %t196 = load i64, ptr %l16, !tbaa !24
  store i64 %t196, ptr %l122, !tbaa !24
  br label %bb57
bb56:
  %t198 = load i64, ptr %l15, !tbaa !24
  %t199 = load i64, ptr %l17, !tbaa !24
  %t202 = add i64 %t198, %t199
  store i64 %t202, ptr %l122, !tbaa !24
  br label %bb57
bb57:
  %t204 = load i64, ptr %l122, !tbaa !24
  store i64 %t204, ptr %l18, !tbaa !24
  %t205 = load i64, ptr %l15, !tbaa !24
  store i64 %t205, ptr %l19, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s11
  %t207 = load i64, ptr %l19, !tbaa !24
  %t208 = load i64, ptr %l18, !tbaa !24
  %t211 = icmp slt i64 %t207, %t208
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb104
bb60:
  br label %bb61
bb61:
  %t215 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t215, ptr %l132, !tbaa !27
  %t216 = load i64, ptr %l19, !tbaa !24
  %t218 = getelementptr { i64, ptr }, ptr %l132, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr i8, ptr %t219, i64 %t216
  %t221 = load i8, ptr %t220, !tbaa !32
  %t223 = call i1 @compiler_2fsession_2eWordChar(i8 %t221)
  store i1 %t223, ptr %l135
  br label %bb62
bb62:
  %t224 = load i1, ptr %l135, !tbaa !21
  %t225 = xor i1 %t224, true
  br i1 %t225, label %bb63, label %bb64
bb63:
  %t227 = load i64, ptr %l19, !tbaa !24
  %t230 = add i64 %t227, 1
  store i64 %t230, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb64:
  br label %bb65
bb65:
  %t232 = load i64, ptr %l19, !tbaa !24
  store i64 %t232, ptr %l20, !tbaa !24
  br label %bb66
bb66:
  %t234 = load i64, ptr %l19, !tbaa !24
  %t235 = load i64, ptr %l18, !tbaa !24
  %t238 = icmp slt i64 %t234, %t235
  br i1 %t238, label %bb67, label %bb68
bb67:
  %t240 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t240, ptr %l145, !tbaa !27
  %t241 = load i64, ptr %l19, !tbaa !24
  %t243 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t244 = load ptr, ptr %t243, !tbaa !27
  %t245 = getelementptr i8, ptr %t244, i64 %t241
  %t246 = load i8, ptr %t245, !tbaa !32
  %t248 = call i1 @compiler_2fsession_2eWordChar(i8 %t246)
  store i1 %t248, ptr %l148
  br label %bb69
bb68:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb70
bb69:
  %t249 = load i1, ptr %l148, !tbaa !21
  store i1 %t249, ptr %l144, !tbaa !21
  br label %bb70
bb70:
  %t250 = load i1, ptr %l144, !tbaa !21
  %t251 = xor i1 %t250, true
  br i1 %t251, label %bb71, label %bb72
bb71:
  br label %bb75
bb72:
  br label %bb73
bb73:
  %t253 = load i64, ptr %l19, !tbaa !24
  %t256 = add i64 %t253, 1
  store i64 %t256, ptr %l19, !tbaa !24
  br label %bb74
bb74:
  br label %bb66
bb75:
  %t258 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t258, ptr %l153, !tbaa !27
  %t259 = load i64, ptr %l20, !tbaa !24
  store i64 %t259, ptr %l154, !tbaa !24
  %t260 = load i64, ptr %l19, !tbaa !24
  store i64 %t260, ptr %l155, !tbaa !24
  %t261 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t262 = extractvalue { i64, ptr } %t261, 0
  store i64 %t262, ptr %l156, !tbaa !24
  %t263 = load i64, ptr %l154, !tbaa !24
  %t264 = icmp sge i64 %t263, 0
  br i1 %t264, label %bb76, label %bb77
bb76:
  %t266 = load i64, ptr %l154, !tbaa !24
  %t267 = load i64, ptr %l155, !tbaa !24
  %t268 = icmp sle i64 %t266, %t267
  br i1 %t268, label %bb78, label %bb79
bb77:
  call void @__olang_check_failed(ptr @olang_loc_7b32137e1a8558e3_9274687faf6829a7)
  unreachable
bb78:
  %t270 = load i64, ptr %l155, !tbaa !24
  %t271 = load i64, ptr %l156, !tbaa !24
  %t272 = icmp sle i64 %t270, %t271
  br i1 %t272, label %bb80, label %bb81
bb79:
  call void @__olang_check_failed(ptr @olang_loc_7b32137e1a8558e3_9274687faf6829a7)
  unreachable
bb80:
  %t274 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t275 = load ptr, ptr %t274, !tbaa !27
  %t276 = load i64, ptr %l154, !tbaa !24
  %t277 = load i64, ptr %l155, !tbaa !24
  %t278 = getelementptr i8, ptr %t275, i64 %t276
  %t279 = sub i64 %t277, %t276
  %t280 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t278, 1
  %t283 = extractvalue { i64, ptr } %t281, 1
  %t284 = extractvalue { i64, ptr } %t281, 0
  %t285 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t284)
  call void @olang_textcopy(ptr %t285, ptr %t283, i64 %t284)
  %t286 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  %t292 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %s0, ptr %s11, ptr %l4, { i64, ptr } %t287)
  store i1 %t292, ptr %l164
  br label %bb82
bb81:
  call void @__olang_check_failed(ptr @olang_loc_7b32137e1a8558e3_9274687faf6829a7)
  unreachable
bb82:
  %t293 = load i1, ptr %l164, !tbaa !21
  %t294 = xor i1 %t293, true
  br i1 %t294, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb84:
  br label %bb85
bb85:
  %t296 = load ptr, ptr %l0, !tbaa !29
  store ptr %t296, ptr %l166, !tbaa !29
  %t297 = load i64, ptr %l3, !tbaa !24
  store i64 %t297, ptr %l167, !tbaa !24
  %t298 = load i64, ptr %l20, !tbaa !24
  %t300 = trunc i64 %t298 to i32
  %t301 = load i64, ptr %l19, !tbaa !24
  %t303 = trunc i64 %t301 to i32
  %t306 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t300, i32 %t303)
  store %"compiler/source:Span" %t306, ptr %l172
  br label %bb86
bb86:
  %t307 = load ptr, ptr %l166, !tbaa !29
  %t308 = load i64, ptr %l167, !tbaa !24
  %t309 = load %"compiler/source:Span", ptr %l172
  %t310 = call { i64, [6 x i64] } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etarget(ptr %v0, ptr %s11, ptr %t307, i64 %t308, %"compiler/source:Span" %t309)
  store { i64, [6 x i64] } %t310, ptr %l173
  br label %bb87
bb87:
  %t311 = load { i64, [6 x i64] }, ptr %l173
  %t312 = load ptr, ptr %l0, !tbaa !29
  %t316 = call { { i64, ptr }, i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2enoteOf(ptr %v0, ptr %s11, ptr %v2, ptr %t312, { i64, [6 x i64] } %t311)
  store { { i64, ptr }, i64, i64 } %t316, ptr %l176
  br label %bb88
bb88:
  %t317 = load { { i64, ptr }, i64, i64 }, ptr %l176
  store { { i64, ptr }, i64, i64 } %t317, ptr %l23
  %t318 = getelementptr { { i64, ptr }, i64, i64 }, ptr %l23, i32 0, i32 0
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  store { i64, ptr } %t319, ptr %l177, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  store i64 %t321, ptr %l178, !tbaa !24
  %t322 = load i64, ptr %l178, !tbaa !24
  %t323 = mul i64 %t322, 1
  %t324 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t323)
  %t325 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  store { i64, ptr } %t326, ptr %l179, !tbaa !27
  %t327 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr { i64, ptr }, ptr %l177, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = load i64, ptr %l178, !tbaa !24
  %t332 = mul i64 %t331, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t328, ptr %t330, i64 %t332, i1 false)
  %t333 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t333, ptr %lp24
  %t334 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t335 = load ptr, ptr %lp24
  store { i64, ptr } %t334, ptr %t335, !tbaa !27
  %t336 = getelementptr { { i64, ptr }, i64, i64 }, ptr %l23, i32 0, i32 1
  %t337 = load i64, ptr %t336, !tbaa !24
  store i64 %t337, ptr %l25, !tbaa !24
  %t339 = getelementptr { { i64, ptr }, i64, i64 }, ptr %l23, i32 0, i32 2
  %t340 = load i64, ptr %t339, !tbaa !24
  store i64 %t340, ptr %l26, !tbaa !24
  %t342 = load ptr, ptr %lp24
  %t343 = load { i64, ptr }, ptr %t342, !tbaa !27
  %t345 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s11, { i64, ptr } %t343, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) })
  store i1 %t345, ptr %l183
  br label %bb89
bb89:
  %t346 = load i1, ptr %l183, !tbaa !21
  %t347 = xor i1 %t346, true
  br i1 %t347, label %bb90, label %bb91
bb90:
  %t349 = load i64, ptr %l26, !tbaa !24
  %t350 = load i64, ptr %l3, !tbaa !24
  %t353 = icmp eq i64 %t349, %t350
  br i1 %t353, label %bb92, label %bb93
bb91:
  store i1 false, ptr %l185, !tbaa !21
  br label %bb97
bb92:
  %t355 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t356 = load i64, ptr %l25, !tbaa !24
  %t359 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t355, i64 %t356)
  store i64 %t359, ptr %l192
  br label %bb94
bb93:
  store i1 false, ptr %l189, !tbaa !21
  br label %bb96
bb94:
  %t360 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t361 = load i64, ptr %l20, !tbaa !24
  %t364 = call i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %t360, i64 %t361)
  store i64 %t364, ptr %l195
  br label %bb95
bb95:
  %t365 = load i64, ptr %l192, !tbaa !24
  %t366 = load i64, ptr %l195, !tbaa !24
  %t367 = icmp eq i64 %t365, %t366
  store i1 %t367, ptr %l189, !tbaa !21
  br label %bb96
bb96:
  %t369 = load i1, ptr %l189, !tbaa !21
  %t370 = xor i1 %t369, true
  store i1 %t370, ptr %l185, !tbaa !21
  br label %bb97
bb97:
  %t372 = load i1, ptr %l185, !tbaa !21
  br i1 %t372, label %bb98, label %bb99
bb98:
  store ptr %l2, ptr %l198, !tbaa !29
  %t373 = load i64, ptr %l20, !tbaa !24
  %t374 = load i64, ptr %l19, !tbaa !24
  %t375 = load ptr, ptr %lp24
  %t376 = load { i64, ptr }, ptr %t375, !tbaa !27
  %t380 = call %"compiler/session:Use" @compiler_2fsession_3aUse_2ector(ptr %v2, ptr %v2, i64 %t373, i64 %t374, { i64, ptr } %t376)
  store %"compiler/session:Use" %t380, ptr %l202
  br label %bb100
bb99:
  br label %bb102
bb100:
  %t381 = load ptr, ptr %l198, !tbaa !29
  %t382 = load %"compiler/session:Use", ptr %l202
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2ePush_3ccompiler_2fsession_3aUse_3e(ptr %v2, ptr %v2, ptr %t381, %"compiler/session:Use" %t382)
  br label %bb101
bb101:
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s11)
  br label %bb103
bb103:
  br label %bb58
bb104:
  %t383 = load i64, ptr %l16, !tbaa !24
  %t385 = add i64 %t383, 1
  store i64 %t385, ptr %l15, !tbaa !24
  br label %bb105
bb105:
  br label %bb43
bb106:
  %t387 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t387, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eMembers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca %"compiler/names:Ref"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l19 = alloca i64
  %l22 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l40 = alloca %"compiler/source:Span"
  %l44 = alloca i1
  %l54 = alloca %"compiler/names:Ref"
  %l62 = alloca %"compiler/names:Ref"
  %l70 = alloca i1
  %l74 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca i32
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca i64
  %l97 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l106 = alloca i1
  %l108 = alloca i1
  %l112 = alloca i64
  %l115 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l133 = alloca i64
  %l137 = alloca i1
  %l144 = alloca i32
  %l145 = alloca i64
  %l149 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a2)
  store i64 %t5, ptr %l19
  br label %bb1
bb1:
  %t6 = load i64, ptr %l19, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 2
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l22, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l22, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 2
  %t22 = load ptr, ptr %t21, !tbaa !29
  store ptr %t22, ptr %l5, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store { i64, ptr } %t28, ptr %l30
  br label %bb8
bb8:
  %t29 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t29, ptr %l6, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/session:Analysis", ptr %t30, i32 0, i32 0
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/load:Loader", ptr %t33, i32 0, i32 10
  %t36 = load i64, ptr %l4, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l35
  br label %bb9
bb9:
  %t40 = load ptr, ptr %l35, !tbaa !29
  %t42 = getelementptr %"compiler/load:Module", ptr %t40, i32 0, i32 4
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l7, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t46 = load i64, ptr %l3, !tbaa !24
  %t49 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t45, i64 %t46)
  store %"compiler/source:Span" %t49, ptr %l40
  br label %bb10
bb10:
  %t50 = load %"compiler/source:Span", ptr %l40
  store %"compiler/source:Span" %t50, ptr %l8
  %t51 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t52 = load i32, ptr %t51, !tbaa !23
  %t53 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t54 = load i32, ptr %t53, !tbaa !23
  %t57 = icmp slt i32 %t52, %t54
  br i1 %t57, label %bb11, label %bb12
bb11:
  %t59 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t60 = load i32, ptr %t59, !tbaa !23
  %t62 = sext i32 %t60 to i64
  %t63 = load i64, ptr %l3, !tbaa !24
  %t66 = icmp eq i64 %t62, %t63
  store i1 %t66, ptr %l44, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb13
bb13:
  %t68 = load i1, ptr %l44, !tbaa !21
  br i1 %t68, label %bb14, label %bb15
bb14:
  %t69 = load ptr, ptr %l5, !tbaa !29
  %t71 = getelementptr %"compiler/check:Checker", ptr %t69, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !29
  %t74 = getelementptr %"compiler/generic:Program", ptr %t72, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t76 = load i64, ptr %l7, !tbaa !24
  %t77 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t82 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t75, i64 %t76, i32 %t78)
  store %"compiler/names:Ref" %t82, ptr %l54
  br label %bb16
bb15:
  br label %bb60
bb16:
  %t83 = load %"compiler/names:Ref", ptr %l54
  store %"compiler/names:Ref" %t83, ptr %l9
  %t84 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 9}
  %t87 = trunc i64 0 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb17, label %bb18
bb17:
  %t90 = load ptr, ptr %l5, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t90, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !29
  %t95 = getelementptr %"compiler/generic:Program", ptr %t93, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !29
  %t97 = load i64, ptr %l7, !tbaa !24
  %t98 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t99 = load i32, ptr %t98, !tbaa !23
  %t103 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t96, i64 %t97, i32 %t99)
  store %"compiler/names:Ref" %t103, ptr %l62
  br label %bb19
bb18:
  br label %bb20
bb19:
  %t104 = load %"compiler/names:Ref", ptr %l62
  store %"compiler/names:Ref" %t104, ptr %l9
  br label %bb20
bb20:
  %t105 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t106 = load i32, ptr %t105, !range !{i32 0, i32 9}
  %t108 = trunc i64 5 to i32
  %t109 = icmp eq i32 %t106, %t108
  br i1 %t109, label %bb21, label %bb22
bb21:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 1
  %t114 = load i64, ptr %t113, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t111, ptr %t112, i64 %t114, i1 false)
  br label %bb23
bb22:
  br label %bb24
bb23:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb24:
  %t118 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 0
  %t119 = load i32, ptr %t118, !range !{i32 0, i32 9}
  %t121 = trunc i64 4 to i32
  %t122 = icmp eq i32 %t119, %t121
  br i1 %t122, label %bb25, label %bb26
bb25:
  %t124 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 2
  %t125 = load i64, ptr %t124, !tbaa !24
  %t127 = icmp sge i64 %t125, 0
  store i1 %t127, ptr %l70, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb27
bb27:
  %t129 = load i1, ptr %l70, !tbaa !21
  br i1 %t129, label %bb28, label %bb29
bb28:
  %t130 = load ptr, ptr %l5, !tbaa !29
  %t132 = getelementptr %"compiler/check:Checker", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  store ptr %t133, ptr %l74, !tbaa !29
  %t134 = load ptr, ptr %l5, !tbaa !29
  %t136 = getelementptr %"compiler/check:Checker", ptr %t134, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !29
  %t138 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 1
  %t139 = load i64, ptr %t138, !tbaa !24
  %t140 = getelementptr %"compiler/names:Ref", ptr %l9, i32 0, i32 2
  %t141 = load i64, ptr %t140, !tbaa !24
  %t145 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %t137, i64 %t139, i64 %t141)
  store i32 %t145, ptr %l79
  br label %bb30
bb29:
  br label %bb59
bb30:
  %t146 = load ptr, ptr %l74, !tbaa !29
  %t147 = load i32, ptr %l79, !tbaa !23
  %t148 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %t146, i32 %t147)
  store i32 %t148, ptr %l80
  br label %bb31
bb31:
  %t149 = load i32, ptr %l80, !tbaa !23
  store %olang.scope zeroinitializer, ptr %s6
  %t150 = load ptr, ptr %l5, !tbaa !29
  %t152 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !29
  %t157 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuildersOf(ptr %v0, ptr %s6, ptr %t153, i32 %t149)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l84
  br label %bb32
bb32:
  %t158 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  %t159 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %t159
  store ptr %t159, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  %t161 = load i64, ptr %l12, !tbaa !24
  store i64 %t161, ptr %l86, !tbaa !24
  %t162 = load ptr, ptr %l11, !tbaa !29
  %t164 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s6, ptr %t162)
  store i64 %t164, ptr %l88
  br label %bb34
bb34:
  %t165 = load i64, ptr %l86, !tbaa !24
  %t166 = load i64, ptr %l88, !tbaa !24
  %t167 = icmp slt i64 %t165, %t166
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb58
bb36:
  br label %bb37
bb37:
  %t171 = load ptr, ptr %l11, !tbaa !29
  %t172 = load i64, ptr %l12, !tbaa !24
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s6, ptr %t171, i64 %t172)
  store i64 %t175, ptr %l93
  br label %bb38
bb38:
  %t176 = load i64, ptr %l93, !tbaa !24
  store i64 %t176, ptr %l13, !tbaa !24
  %t177 = load ptr, ptr %l5, !tbaa !29
  %t179 = getelementptr %"compiler/check:Checker", ptr %t177, i32 0, i32 1
  %t180 = load ptr, ptr %t179, !tbaa !29
  %t181 = load i64, ptr %l13, !tbaa !24
  %t184 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t180, i64 %t181)
  store ptr %t184, ptr %l97
  br label %bb39
bb39:
  %t185 = load ptr, ptr %l97, !tbaa !29
  store ptr %t185, ptr %l14, !tbaa !29
  %t186 = load ptr, ptr %l5, !tbaa !29
  %t188 = getelementptr %"compiler/check:Checker", ptr %t186, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !29
  %t191 = getelementptr %"compiler/generic:Program", ptr %t189, i32 0, i32 0
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/load:Loader", ptr %t192, i32 0, i32 3
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t196 = load ptr, ptr %l14, !tbaa !29
  %t198 = getelementptr %"compiler/ast:Func", ptr %t196, i32 0, i32 9
  %t199 = load i32, ptr %t198, !tbaa !23
  %t202 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t195, i32 %t199)
  store { i64, ptr } %t202, ptr %l104
  br label %bb40
bb40:
  %t203 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t203, ptr %l15, !tbaa !27
  %t204 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t206 = call i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %t204)
  store i1 %t206, ptr %l106
  br label %bb41
bb41:
  %t207 = load i1, ptr %l106, !tbaa !21
  %t208 = xor i1 %t207, true
  br i1 %t208, label %bb42, label %bb43
bb42:
  %t210 = load ptr, ptr %l5, !tbaa !29
  %t212 = getelementptr %"compiler/check:Checker", ptr %t210, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !29
  %t214 = load i64, ptr %l13, !tbaa !24
  %t217 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t213, i64 %t214)
  store i64 %t217, ptr %l112
  br label %bb44
bb43:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb45
bb44:
  %t218 = load i64, ptr %l4, !tbaa !24
  %t219 = load i64, ptr %l112, !tbaa !24
  %t221 = icmp ne i64 %t219, %t218
  store i1 %t221, ptr %l108, !tbaa !21
  br label %bb45
bb45:
  %t223 = load i1, ptr %l108, !tbaa !21
  br i1 %t223, label %bb46, label %bb47
bb46:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb47:
  br label %bb48
bb48:
  %t224 = load ptr, ptr %l1, !tbaa !29
  store ptr %t224, ptr %l115, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t225, ptr %l116, !tbaa !27
  %t226 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  store i64 %t226, ptr %l117, !tbaa !24
  %t227 = load ptr, ptr %l5, !tbaa !29
  store ptr %t227, ptr %l118, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/session:Analysis", ptr %t228, i32 0, i32 3
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = icmp eq ptr %t231, null
  br i1 %t233, label %bb49, label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_3178b68d0296f164_92041ef9c14564d0)
  unreachable
bb50:
  br label %bb51
bb51:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/session:Analysis", ptr %t235, i32 0, i32 3
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t239 = load i64, ptr %l13, !tbaa !24
  %t240 = load ptr, ptr %l118, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v0, ptr %s7, ptr %t240, ptr %t238, i64 %t239)
  store { i64, ptr } %t243, ptr %l125
  br label %bb52
bb52:
  %t244 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t246 = call { i64, ptr } @compiler_2fsession_2efirstLine(ptr %s7, ptr %s7, { i64, ptr } %t244)
  store { i64, ptr } %t246, ptr %l127
  br label %bb53
bb53:
  %t247 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t247, ptr %l128, !tbaa !27
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l129, !tbaa !29
  %t249 = load ptr, ptr %l5, !tbaa !29
  %t251 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !29
  %t253 = load i64, ptr %l13, !tbaa !24
  %t256 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t252, i64 %t253)
  store i64 %t256, ptr %l133
  br label %bb54
bb54:
  %t257 = load ptr, ptr %l14, !tbaa !29
  %t259 = getelementptr %"compiler/ast:Func", ptr %t257, i32 0, i32 0
  %t260 = getelementptr %"compiler/source:Span", ptr %t259, i32 0, i32 0
  %t261 = load i32, ptr %t260, !tbaa !23
  %t263 = sext i32 %t261 to i64
  %t264 = load ptr, ptr %l129, !tbaa !29
  %t265 = load i64, ptr %l133, !tbaa !24
  %t267 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edeprecatedAt(ptr %v0, ptr %t264, i64 %t265, i64 %t263, i1 false)
  store i1 %t267, ptr %l137
  br label %bb55
bb55:
  %t268 = load ptr, ptr %l115, !tbaa !29
  %t269 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t270 = load i64, ptr %l117, !tbaa !24
  %t271 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t272 = load i1, ptr %l137, !tbaa !21
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAddDep(ptr %v1, ptr %v0, ptr %s7, ptr %t268, { i64, ptr } %t269, i64 %t270, { i64, ptr } %t271, i1 %t272)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb57:
  %t273 = load i64, ptr %l12, !tbaa !24
  %t276 = add i64 %t273, 1
  store i64 %t276, ptr %l12, !tbaa !24
  br label %bb33
bb58:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb59:
  br label %bb60
bb60:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t279 = load i64, ptr %l7, !tbaa !24
  %t280 = load i64, ptr %l3, !tbaa !24
  %t284 = call i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeEndingAt(ptr %v0, ptr %t278, i64 %t279, i64 %t280)
  store i32 %t284, ptr %l144
  br label %bb61
bb61:
  %t285 = load i32, ptr %l144, !tbaa !23
  store i32 %t285, ptr %l16, !tbaa !23
  %t286 = load i64, ptr %l3, !tbaa !24
  store i64 %t286, ptr %l145, !tbaa !24
  %t287 = load i32, ptr %l16, !tbaa !23
  %t288 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t291 = icmp ne i32 %t287, %t288
  br i1 %t291, label %bb62, label %bb63
bb62:
  %t293 = load ptr, ptr %l5, !tbaa !29
  %t294 = load i32, ptr %l16, !tbaa !23
  %t297 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s0, ptr %t293, i32 %t294)
  store { i64, ptr } %t297, ptr %l152
  br label %bb64
bb63:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %l149, !tbaa !27
  br label %bb65
bb64:
  %t298 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t298, ptr %l149, !tbaa !27
  br label %bb65
bb65:
  %t300 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t301 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t302 = load i64, ptr %l145, !tbaa !24
  %t303 = call i64 @__olang_fmt_i64(ptr null, i64 %t302)
  %t304 = add i64 %t301, %t303
  %t305 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t307 = add i64 %t304, %t306
  %t308 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t309 = extractvalue { i64, ptr } %t308, 1
  %t310 = extractvalue { i64, ptr } %t308, 0
  %t311 = add i64 %t307, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t300, i64 %t301)
  %t313 = getelementptr i8, ptr %t312, i64 %t301
  %t314 = call i64 @__olang_fmt_i64(ptr %t313, i64 %t302)
  %t315 = getelementptr i8, ptr %t313, i64 %t303
  call void @olang_textcopy(ptr %t315, ptr %t305, i64 %t306)
  %t316 = getelementptr i8, ptr %t315, i64 %t306
  call void @olang_textcopy(ptr %t316, ptr %t309, i64 %t310)
  %t317 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t312, 1
  call void @compiler_2fsession_2eLog(ptr %s0, { i64, ptr } %t318)
  br label %bb66
bb66:
  %t321 = load i32, ptr %l16, !tbaa !23
  %t322 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t325 = icmp eq i32 %t321, %t322
  br i1 %t325, label %bb67, label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb68:
  br label %bb69
bb69:
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load ptr, ptr %l1, !tbaa !29
  %t329 = load i32, ptr %l16, !tbaa !23
  %t330 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeMembers(ptr %v0, ptr %v1, ptr %t327, ptr %t328, i32 %t329, i64 %t330)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eNames(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca %"compiler/typed:Local"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca %"compiler/load:Import"
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i1
  %l38 = alloca ptr
  %l48 = alloca i64
  %l50 = alloca i64
  %l55 = alloca ptr
  %l60 = alloca i1
  %l66 = alloca i1
  %l74 = alloca i64
  %l76 = alloca i64
  %l81 = alloca %"compiler/typed:Local"
  %l84 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l97 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l109 = alloca i64
  %l116 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l134 = alloca i64
  %l136 = alloca i64
  %l141 = alloca %"compiler/load:Import"
  %l152 = alloca i64
  %l156 = alloca i64
  %l159 = alloca i64
  %l181 = alloca ptr
  %s8 = alloca %olang.scope
  %s19 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t5 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a2)
  store i64 %t5, ptr %l27
  br label %bb1
bb1:
  %t6 = load i64, ptr %l27, !tbaa !24
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp slt i64 %t7, 0
  br i1 %t9, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb4
bb3:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/session:Analysis", ptr %t11, i32 0, i32 2
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  store i1 %t16, ptr %l30, !tbaa !21
  br label %bb4
bb4:
  %t18 = load i1, ptr %l30, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %ret
bb6:
  br label %bb7
bb7:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 10
  %t25 = load i64, ptr %l4, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l38
  br label %bb8
bb8:
  %t29 = load ptr, ptr %l38, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/session:Analysis", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  br i1 %t39, label %bb9, label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_804f8b0fb45e435f_c5484f8454187243)
  unreachable
bb10:
  br label %bb11
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/session:Analysis", ptr %t41, i32 0, i32 2
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t47 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 19
  store ptr %t47, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t49 = load i64, ptr %l7, !tbaa !24
  store i64 %t49, ptr %l48, !tbaa !24
  %t50 = load ptr, ptr %l6, !tbaa !29
  %t52 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t50)
  store i64 %t52, ptr %l50
  br label %bb13
bb13:
  %t53 = load i64, ptr %l48, !tbaa !24
  %t54 = load i64, ptr %l50, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  br label %bb60
bb15:
  br label %bb16
bb16:
  %t59 = load ptr, ptr %l6, !tbaa !29
  %t60 = load i64, ptr %l7, !tbaa !24
  %t63 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t59, i64 %t60)
  store ptr %t63, ptr %l55
  br label %bb17
bb17:
  %t64 = load ptr, ptr %l55, !tbaa !29
  store ptr %t64, ptr %l8, !tbaa !29
  %t65 = load ptr, ptr %l8, !tbaa !29
  %t67 = getelementptr %"compiler/typed:Body", ptr %t65, i32 0, i32 3
  %t68 = load i64, ptr %t67, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp ne i64 %t68, %t69
  br i1 %t72, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l60, !tbaa !21
  br label %bb20
bb19:
  %t74 = load ptr, ptr %l8, !tbaa !29
  %t76 = getelementptr %"compiler/typed:Body", ptr %t74, i32 0, i32 4
  %t77 = getelementptr %"compiler/source:Span", ptr %t76, i32 0, i32 0
  %t78 = load i32, ptr %t77, !tbaa !23
  %t80 = sext i32 %t78 to i64
  %t81 = load i64, ptr %l3, !tbaa !24
  %t84 = icmp sgt i64 %t80, %t81
  store i1 %t84, ptr %l60, !tbaa !21
  br label %bb20
bb20:
  %t86 = load i1, ptr %l60, !tbaa !21
  br i1 %t86, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l66, !tbaa !21
  br label %bb23
bb22:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t88 = load ptr, ptr %l8, !tbaa !29
  %t90 = getelementptr %"compiler/typed:Body", ptr %t88, i32 0, i32 4
  %t91 = getelementptr %"compiler/source:Span", ptr %t90, i32 0, i32 1
  %t92 = load i32, ptr %t91, !tbaa !23
  %t94 = sext i32 %t92 to i64
  %t97 = icmp sgt i64 %t87, %t94
  store i1 %t97, ptr %l66, !tbaa !21
  br label %bb23
bb23:
  %t99 = load i1, ptr %l66, !tbaa !21
  br i1 %t99, label %bb24, label %bb25
bb24:
  br label %bb59
bb25:
  br label %bb26
bb26:
  %t100 = load ptr, ptr %l8, !tbaa !29
  %t102 = getelementptr %"compiler/typed:Body", ptr %t100, i32 0, i32 7
  store ptr %t102, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb27
bb27:
  %t104 = load i64, ptr %l10, !tbaa !24
  store i64 %t104, ptr %l74, !tbaa !24
  %t105 = load ptr, ptr %l9, !tbaa !29
  %t107 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t105)
  store i64 %t107, ptr %l76
  br label %bb28
bb28:
  %t108 = load i64, ptr %l74, !tbaa !24
  %t109 = load i64, ptr %l76, !tbaa !24
  %t110 = icmp slt i64 %t108, %t109
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb29, label %bb30
bb29:
  br label %bb58
bb30:
  br label %bb31
bb31:
  %t114 = load ptr, ptr %l9, !tbaa !29
  %t115 = load i64, ptr %l10, !tbaa !24
  %t118 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t114, i64 %t115)
  store %"compiler/typed:Local" %t118, ptr %l81
  br label %bb32
bb32:
  %t119 = load %"compiler/typed:Local", ptr %l81
  store %"compiler/typed:Local" %t119, ptr %l11
  %t120 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t121 = load i32, ptr %t120, !tbaa !23
  %t123 = icmp eq i32 %t121, 0
  br i1 %t123, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb35
bb34:
  %t125 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t126 = getelementptr %"compiler/source:Span", ptr %t125, i32 0, i32 0
  %t127 = load i32, ptr %t126, !tbaa !23
  %t129 = sext i32 %t127 to i64
  %t130 = load i64, ptr %l3, !tbaa !24
  %t133 = icmp sge i64 %t129, %t130
  store i1 %t133, ptr %l84, !tbaa !21
  br label %bb35
bb35:
  %t135 = load i1, ptr %l84, !tbaa !21
  br i1 %t135, label %bb36, label %bb37
bb36:
  br label %bb57
bb37:
  br label %bb38
bb38:
  %t136 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t137 = load i32, ptr %t136, !range !{i32 0, i32 7}
  %t139 = trunc i64 0 to i32
  %t140 = icmp eq i32 %t137, %t139
  br i1 %t140, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb41
bb40:
  %t142 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t143 = load i32, ptr %t142, !range !{i32 0, i32 7}
  %t145 = trunc i64 1 to i32
  %t146 = icmp eq i32 %t143, %t145
  store i1 %t146, ptr %l91, !tbaa !21
  br label %bb41
bb41:
  %t148 = load i1, ptr %l91, !tbaa !21
  br i1 %t148, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l94, !tbaa !21
  br label %bb44
bb43:
  %t149 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 4
  %t150 = load i32, ptr %t149, !range !{i32 0, i32 7}
  %t152 = trunc i64 4 to i32
  %t153 = icmp eq i32 %t150, %t152
  store i1 %t153, ptr %l94, !tbaa !21
  br label %bb44
bb44:
  %t155 = load i1, ptr %l94, !tbaa !21
  br i1 %t155, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s8
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l97, !tbaa !29
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/session:Analysis", ptr %t157, i32 0, i32 2
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = icmp eq ptr %t160, null
  br i1 %t162, label %bb47, label %bb48
bb46:
  br label %bb56
bb47:
  call void @__olang_check_failed(ptr @olang_loc_9033262c592f27c0_922b790dfcbd6cb4)
  unreachable
bb48:
  br label %bb49
bb49:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/session:Analysis", ptr %t164, i32 0, i32 2
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t170 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t171 = load ptr, ptr %t170, !tbaa !29
  %t173 = getelementptr %"compiler/generic:Program", ptr %t171, i32 0, i32 0
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/load:Loader", ptr %t174, i32 0, i32 3
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t178 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t179 = load i32, ptr %t178, !tbaa !23
  %t182 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %t177, i32 %t179)
  store { i64, ptr } %t182, ptr %l108
  br label %bb50
bb50:
  %t183 = load i64, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  store i64 %t183, ptr %l109, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/session:Analysis", ptr %t184, i32 0, i32 2
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = icmp eq ptr %t187, null
  br i1 %t189, label %bb51, label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_9033262c592f27c0_922b790dfcbd6cb4)
  unreachable
bb52:
  br label %bb53
bb53:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/session:Analysis", ptr %t191, i32 0, i32 2
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t195 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 2
  %t196 = load i32, ptr %t195, !tbaa !23
  %t199 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s8, ptr %t194, i32 %t196)
  store { i64, ptr } %t199, ptr %l116
  br label %bb54
bb54:
  %t200 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t201 = load ptr, ptr %l97, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t203 = load i64, ptr %l109, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v1, ptr %s8, ptr %t201, { i64, ptr } %t202, i64 %t203, { i64, ptr } %t200)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb56
bb56:
  br label %bb57
bb57:
  %t205 = load i64, ptr %l10, !tbaa !24
  %t208 = add i64 %t205, 1
  store i64 %t208, ptr %l10, !tbaa !24
  br label %bb27
bb58:
  br label %bb59
bb59:
  %t210 = load i64, ptr %l7, !tbaa !24
  %t213 = add i64 %t210, 1
  store i64 %t213, ptr %l7, !tbaa !24
  br label %bb12
bb60:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t217 = load i64, ptr %l4, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t215, ptr %t216, i64 %t217, i1 true)
  br label %bb61
bb61:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/session:Analysis", ptr %t221, i32 0, i32 0
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/load:Loader", ptr %t224, i32 0, i32 10
  %t227 = load i64, ptr %l4, !tbaa !24
  %t230 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t226, i64 %t227)
  store ptr %t230, ptr %l131
  br label %bb62
bb62:
  %t231 = load ptr, ptr %l131, !tbaa !29
  %t233 = getelementptr %"compiler/load:Module", ptr %t231, i32 0, i32 11
  store ptr %t233, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb63
bb63:
  %t235 = load i64, ptr %l13, !tbaa !24
  store i64 %t235, ptr %l134, !tbaa !24
  %t236 = load ptr, ptr %l12, !tbaa !29
  %t238 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %t236)
  store i64 %t238, ptr %l136
  br label %bb64
bb64:
  %t239 = load i64, ptr %l134, !tbaa !24
  %t240 = load i64, ptr %l136, !tbaa !24
  %t241 = icmp slt i64 %t239, %t240
  %t243 = xor i1 %t241, true
  br i1 %t243, label %bb65, label %bb66
bb65:
  br label %bb71
bb66:
  br label %bb67
bb67:
  %t245 = load ptr, ptr %l12, !tbaa !29
  %t246 = load i64, ptr %l13, !tbaa !24
  %t249 = call %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v0, ptr %t245, i64 %t246)
  store %"compiler/load:Import" %t249, ptr %l141
  br label %bb68
bb68:
  %t250 = load %"compiler/load:Import", ptr %l141
  store %"compiler/load:Import" %t250, ptr %l14
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 2
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t254 = load i64, ptr @G_2ecompiler_2fsession_2eCompModule, !tbaa !24
  %t255 = getelementptr %"compiler/load:Import", ptr %l14, i32 0, i32 3
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %v0, ptr %t251, { i64, ptr } %t253, i64 %t254, { i64, ptr } %t256)
  br label %bb69
bb69:
  br label %bb70
bb70:
  %t261 = load i64, ptr %l13, !tbaa !24
  %t264 = add i64 %t261, 1
  store i64 %t264, ptr %l13, !tbaa !24
  br label %bb63
bb71:
  store i64 0, ptr %l15, !tbaa !24
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t268 = getelementptr %"compiler/session:Analysis", ptr %t266, i32 0, i32 0
  %t269 = load ptr, ptr %t268, !tbaa !29
  %t271 = getelementptr %"compiler/load:Loader", ptr %t269, i32 0, i32 10
  %t273 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %t271)
  store i64 %t273, ptr %l152
  br label %bb72
bb72:
  %t274 = load i64, ptr %l152, !tbaa !24
  store i64 %t274, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t275 = load i64, ptr %l16, !tbaa !24
  %t276 = load i64, ptr %l15, !tbaa !24
  %t279 = icmp sgt i64 %t275, %t276
  br i1 %t279, label %bb73, label %bb74
bb73:
  %t281 = load i64, ptr %l17, !tbaa !24
  %t283 = icmp sgt i64 %t281, 0
  br i1 %t283, label %bb75, label %bb76
bb74:
  store i64 0, ptr %l156, !tbaa !24
  br label %bb78
bb75:
  %t285 = load i64, ptr %l16, !tbaa !24
  %t286 = load i64, ptr %l15, !tbaa !24
  %t289 = sub i64 %t285, %t286
  %t290 = load i64, ptr %l17, !tbaa !24
  %t293 = add i64 %t289, %t290
  %t295 = sub i64 %t293, 1
  %t296 = load i64, ptr %l17, !tbaa !24
  %t299 = sdiv i64 %t295, %t296
  store i64 %t299, ptr %l159, !tbaa !24
  br label %bb77
bb76:
  store i64 0, ptr %l159, !tbaa !24
  br label %bb77
bb77:
  %t301 = load i64, ptr %l159, !tbaa !24
  store i64 %t301, ptr %l156, !tbaa !24
  br label %bb78
bb78:
  %t302 = load i64, ptr %l156, !tbaa !24
  store i64 %t302, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb79
bb79:
  %t303 = load i64, ptr %l19, !tbaa !24
  %t304 = load i64, ptr %l18, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb80, label %bb81
bb80:
  br label %bb89
bb81:
  br label %bb82
bb82:
  %t311 = load i64, ptr %l15, !tbaa !24
  %t312 = load i64, ptr %l19, !tbaa !24
  %t313 = load i64, ptr %l17, !tbaa !24
  %t316 = mul i64 %t312, %t313
  %t319 = add i64 %t311, %t316
  store i64 %t319, ptr %l20, !tbaa !24
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/session:Analysis", ptr %t321, i32 0, i32 0
  %t324 = load ptr, ptr %t323, !tbaa !29
  %t326 = getelementptr %"compiler/load:Loader", ptr %t324, i32 0, i32 10
  %t327 = load i64, ptr %l20, !tbaa !24
  %t330 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t326, i64 %t327)
  store ptr %t330, ptr %l181
  br label %bb83
bb83:
  %t331 = load ptr, ptr %l181, !tbaa !29
  %t333 = getelementptr %"compiler/load:Module", ptr %t331, i32 0, i32 3
  %t334 = load i1, ptr %t333, !tbaa !21
  br i1 %t334, label %bb84, label %bb85
bb84:
  %t336 = load ptr, ptr %l0, !tbaa !29
  %t337 = load ptr, ptr %l1, !tbaa !29
  %t338 = load i64, ptr %l20, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %t336, ptr %t337, i64 %t338, i1 false)
  br label %bb86
bb85:
  br label %bb87
bb86:
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t342 = load i64, ptr %l19, !tbaa !24
  %t345 = add i64 %t342, 1
  store i64 %t345, ptr %l19, !tbaa !24
  br label %bb79
bb89:
  store ptr @G_2ecompiler_2fsession_2eKeywords, ptr %l21
  store i64 0, ptr %l22, !tbaa !24
  %t348 = load ptr, ptr %l21
  store i64 62, ptr %l23, !tbaa !24
  br label %bb90
bb90:
  store %olang.scope zeroinitializer, ptr %s19
  %t351 = load i64, ptr %l22, !tbaa !24
  %t352 = load i64, ptr %l23, !tbaa !24
  %t355 = icmp slt i64 %t351, %t352
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s19)
  br label %bb96
bb92:
  br label %bb93
bb93:
  %t359 = load ptr, ptr %l21
  %t360 = load i64, ptr %l22, !tbaa !24
  %t363 = getelementptr [62 x { i64, ptr }], ptr %t359, i64 0, i64 %t360
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !37
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t368 = load i64, ptr @G_2ecompiler_2fsession_2eCompKeyword, !tbaa !24
  %t369 = load ptr, ptr @__olang_prog_scope
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %t369, ptr %s19, ptr %t366, { i64, ptr } %t364, i64 %t368, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb94
bb94:
  call void @__olang_scope_close(ptr %s19)
  br label %bb95
bb95:
  %t373 = load i64, ptr %l22, !tbaa !24
  %t376 = add i64 %t373, 1
  store i64 %t376, ptr %l22, !tbaa !24
  br label %bb90
bb96:
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2ePlaced(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca %"compiler/scope:Placement"
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca i64
  %l15 = alloca i1
  %l24 = alloca ptr
  %l32 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca i64
  %l36 = alloca i64
  %l41 = alloca %"compiler/scope:Placement"
  %l42 = alloca %"compiler/scope:Placement"
  %l43 = alloca i64
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l65 = alloca %"compiler/session:Use"
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2ector(ptr %v2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l2
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %t3, { i64, ptr } %a1)
  store i64 %t7, ptr %l12
  br label %bb2
bb2:
  %t8 = load i64, ptr %l12, !tbaa !24
  store i64 %t8, ptr %l3, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb5
bb4:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/session:Analysis", ptr %t13, i32 0, i32 3
  %t16 = load ptr, ptr %t15, !tbaa !29
  %t18 = icmp eq ptr %t16, null
  store i1 %t18, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t20 = load i1, ptr %l15, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/session:Analysis", ptr %t23, i32 0, i32 0
  %t26 = load ptr, ptr %t25, !tbaa !29
  %t28 = getelementptr %"compiler/load:Loader", ptr %t26, i32 0, i32 10
  %t29 = load i64, ptr %l3, !tbaa !24
  %t32 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store ptr %t32, ptr %l24
  br label %bb9
bb9:
  %t33 = load ptr, ptr %l24, !tbaa !29
  %t35 = getelementptr %"compiler/load:Module", ptr %t33, i32 0, i32 4
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/session:Analysis", ptr %t38, i32 0, i32 3
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = icmp eq ptr %t41, null
  br i1 %t43, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_270f5d4da41f712e_3815e2adbc47561a)
  unreachable
bb11:
  br label %bb12
bb12:
  %t45 = load ptr, ptr %l0, !tbaa !29
  %t47 = getelementptr %"compiler/session:Analysis", ptr %t45, i32 0, i32 3
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ePlacements(ptr %v0, ptr %s2, ptr %t48)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t50, ptr %l32
  br label %bb13
bb13:
  %t51 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l32
  %t52 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t51, ptr %t52
  store ptr %t52, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load i64, ptr %l6, !tbaa !24
  store i64 %t54, ptr %l34, !tbaa !24
  %t55 = load ptr, ptr %l5, !tbaa !29
  %t57 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aPlacement_3e_2eLen__H4d2672aa7d845ec0c6fc38a004384ece(ptr %s2, ptr %t55)
  store i64 %t57, ptr %l36
  br label %bb15
bb15:
  %t58 = load i64, ptr %l34, !tbaa !24
  %t59 = load i64, ptr %l36, !tbaa !24
  %t60 = icmp slt i64 %t58, %t59
  %t62 = xor i1 %t60, true
  br i1 %t62, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb37
bb17:
  br label %bb18
bb18:
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t65 = load i64, ptr %l6, !tbaa !24
  %t68 = call %"compiler/scope:Placement" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aPlacement_3e_2eAt_3ccompiler_2fscope_3aPlacement_3e(ptr %s2, ptr %s2, ptr %t64, i64 %t65)
  store %"compiler/scope:Placement" %t68, ptr %l41
  br label %bb19
bb19:
  %t69 = load %"compiler/scope:Placement", ptr %l41
  store %"compiler/scope:Placement" %t69, ptr %l42
  %t70 = call ptr @__olang_scope_hold(ptr %s3)
  %t71 = ptrtoint ptr %t70 to i64
  store i64 %t71, ptr %l43, !tbaa !24
  %t72 = load i1, ptr @olang_2esole_2ecompiler_2fscope_3aPlacement_2e4
  br i1 %t72, label %bb20, label %bb21
bb20:
  %t74 = call ptr @__olang_region_make_part(ptr %s3)
  %t75 = ptrtoint ptr %t74 to i64
  store i64 %t75, ptr %l43, !tbaa !24
  br label %bb21
bb21:
  %t76 = getelementptr %"compiler/scope:Placement", ptr %l42, i32 0, i32 4
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  store { i64, ptr } %t77, ptr %l45, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  store i64 %t79, ptr %l46, !tbaa !24
  %t80 = load i64, ptr %l46, !tbaa !24
  %t81 = mul i64 %t80, 1
  %t82 = load i64, ptr %l43
  %t83 = inttoptr i64 %t82 to ptr
  %t84 = call ptr @__olang_held_alloc(ptr %t83, i64 %t81)
  %t85 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  store { i64, ptr } %t86, ptr %l47, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = load i64, ptr %l46, !tbaa !24
  %t92 = mul i64 %t91, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t88, ptr %t90, i64 %t92, i1 false)
  %t93 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t94 = getelementptr %"compiler/scope:Placement", ptr %l42, i32 0, i32 4
  store { i64, ptr } %t93, ptr %t94, !tbaa !27
  %t95 = load i1, ptr @olang_2esole_2ecompiler_2fscope_3aPlacement_2e4
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t97 = getelementptr %"compiler/scope:Placement", ptr %l42, i32 0, i32 4
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t101 = icmp eq i64 %t99, 0
  br i1 %t101, label %bb24, label %bb25
bb23:
  %t103 = load %"compiler/scope:Placement", ptr %l42
  store %"compiler/scope:Placement" %t103, ptr %l7
  %t104 = getelementptr %"compiler/scope:Placement", ptr %l7, i32 0, i32 0
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load i64, ptr %l4, !tbaa !24
  %t109 = icmp ne i64 %t105, %t106
  br i1 %t109, label %bb26, label %bb27
bb24:
  %t111 = getelementptr %"compiler/scope:Placement", ptr %l42, i32 0, i32 4
  store { i64, ptr } zeroinitializer, ptr %t111, !tbaa !27
  br label %bb25
bb25:
  %t112 = getelementptr %"compiler/scope:Placement", ptr %l42, i32 0, i32 4
  %t113 = load i64, ptr %l43
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = load { i64, ptr }, ptr %t112
  %t116 = extractvalue { i64, ptr } %t115, 1
  %t117 = call ptr @__olang_region_or(ptr %t116, ptr null)
  %t118 = icmp ne ptr %t117, null
  %t119 = select i1 %t118, ptr %t117, ptr null
  call void @__olang_region_settle_in(ptr %t114, ptr %t119)
  br label %bb23
bb26:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb27:
  br label %bb28
bb28:
  %t120 = getelementptr %"compiler/scope:Placement", ptr %l7, i32 0, i32 5
  %t121 = load i1, ptr %t120, !tbaa !21
  br i1 %t121, label %bb29, label %bb30
bb29:
  store { i64, ptr } { i64 59, ptr getelementptr inbounds (<{ i64, [59 x i8] }>, ptr @.d66, i32 0, i32 1) }, ptr %l55, !tbaa !27
  br label %bb31
bb30:
  store { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d67, i32 0, i32 1) }, ptr %l55, !tbaa !27
  br label %bb31
bb31:
  %t123 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t123, ptr %l8, !tbaa !27
  store ptr %l2, ptr %l56, !tbaa !29
  %t124 = getelementptr %"compiler/scope:Placement", ptr %l7, i32 0, i32 1
  %t125 = load i64, ptr %t124, !tbaa !24
  store i64 %t125, ptr %l57, !tbaa !24
  %t126 = getelementptr %"compiler/scope:Placement", ptr %l7, i32 0, i32 2
  %t127 = load i64, ptr %t126, !tbaa !24
  store i64 %t127, ptr %l58, !tbaa !24
  %t128 = call ptr @__olang_scope_hold(ptr %v2)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l59, !tbaa !24
  %t130 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aUse_2e2
  br i1 %t130, label %bb32, label %bb33
bb32:
  %t132 = call ptr @__olang_region_make(ptr %v2)
  %t133 = ptrtoint ptr %t132 to i64
  store i64 %t133, ptr %l59, !tbaa !24
  br label %bb33
bb33:
  %t134 = getelementptr %"compiler/scope:Placement", ptr %l7, i32 0, i32 4
  %t135 = load { i64, ptr }, ptr %t134, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t135, 1
  %t139 = extractvalue { i64, ptr } %t135, 0
  %t141 = extractvalue { i64, ptr } %t136, 1
  %t142 = extractvalue { i64, ptr } %t136, 0
  %t143 = add i64 %t139, %t142
  %t144 = load i64, ptr %l59
  %t145 = inttoptr i64 %t144 to ptr
  %t146 = call ptr @__olang_held_alloc(ptr %t145, i64 %t143)
  call void @olang_textcopy(ptr %t146, ptr %t138, i64 %t139)
  %t147 = getelementptr i8, ptr %t146, i64 %t139
  call void @olang_textcopy(ptr %t147, ptr %t141, i64 %t142)
  %t148 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t146, 1
  %t151 = load i64, ptr %l57, !tbaa !24
  %t152 = load i64, ptr %l58, !tbaa !24
  %t154 = call %"compiler/session:Use" @compiler_2fsession_3aUse_2ector(ptr %v2, ptr %v2, i64 %t151, i64 %t152, { i64, ptr } %t149)
  store %"compiler/session:Use" %t154, ptr %l65
  br label %bb34
bb34:
  %t155 = load ptr, ptr %l56, !tbaa !29
  %t156 = load %"compiler/session:Use", ptr %l65
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2ePush_3ccompiler_2fsession_3aUse_3e(ptr %v2, ptr %v2, ptr %t155, %"compiler/session:Use" %t156)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb36
bb36:
  %t157 = load i64, ptr %l6, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l6, !tbaa !24
  br label %bb14
bb37:
  call void @__olang_scope_close(ptr %s2)
  %t162 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t162, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i32, %"compiler/session:Found" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edescribe(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [6 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [6 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i64
  %lp16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i32
  %l19 = alloca ptr
  %l20 = alloca %"compiler/typed:Local"
  %l21 = alloca i64
  %lp23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca ptr
  %l36 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l44 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l55 = alloca i1
  %l62 = alloca i64
  %l63 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i64
  %l88 = alloca ptr
  %l94 = alloca %"compiler/session:Found"
  %l104 = alloca i64
  %l111 = alloca ptr
  %l121 = alloca ptr
  %l123 = alloca i1
  %l124 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l159 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca i64
  %l171 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l196 = alloca ptr
  %l202 = alloca %"compiler/session:Found"
  %l207 = alloca %"compiler/session:memberInfo"
  %l211 = alloca %"compiler/session:memberInfo"
  %l212 = alloca i32
  %l214 = alloca i64
  %l216 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l229 = alloca %"compiler/session:Found"
  %l240 = alloca ptr
  %l245 = alloca %"compiler/typed:Local"
  %l249 = alloca i64
  %l252 = alloca { i64, ptr }
  %l253 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l267 = alloca { i64, ptr }
  %l270 = alloca { i64, ptr }
  %l271 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l279 = alloca ptr
  %l286 = alloca %"compiler/session:Found"
  %l293 = alloca i64
  %l297 = alloca { i64, ptr }
  %l298 = alloca { i64, ptr }
  %l299 = alloca i64
  %l305 = alloca ptr
  %l311 = alloca %"compiler/session:Found"
  %l319 = alloca ptr
  %l320 = alloca i64
  %l325 = alloca { i64, ptr }
  %l333 = alloca { i64, ptr }
  %l335 = alloca { i64, ptr }
  %l339 = alloca %"compiler/session:Found"
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/session:Found" }
  store ptr %a0, ptr %l0
  store { i64, [6 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [6 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [6 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64, { i64, ptr } }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l3, !tbaa !24
  %t15 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, { i64, ptr } }, ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  br label %bb35
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  store ptr %t23, ptr %l39, !tbaa !29
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/session:Analysis", ptr %t24, i32 0, i32 3
  %t27 = load ptr, ptr %t26, !tbaa !29
  %t29 = icmp eq ptr %t27, null
  br i1 %t29, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb8:
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/session:Analysis", ptr %t31, i32 0, i32 3
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l44, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/session:Analysis", ptr %t35, i32 0, i32 4
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb10, label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_34b5353ec7fa6306_74a43705b3ad61d2)
  unreachable
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/session:Analysis", ptr %t42, i32 0, i32 4
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t46 = load i64, ptr %l3, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t48 = load ptr, ptr %l39, !tbaa !29
  %t49 = load ptr, ptr %l44, !tbaa !29
  %t53 = call { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v0, ptr %v0, ptr %v1, ptr %s1, ptr %t48, ptr %t49, ptr %t45, i64 %t46, { i64, ptr } %t47)
  %t54 = extractvalue { i32, { i64, ptr } } %t53, 1
  %t55 = extractvalue { i32, { i64, ptr } } %t53, 0
  store i32 %t55, ptr %l53
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb14, label %ok.57, !prof !99
ok.57:
  store { i64, ptr } %t54, ptr %l52
  br label %bb13
bb13:
  %t58 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t58, ptr %l36, !tbaa !27
  br label %bb16
bb14:
  %t59 = load i32, ptr %l53, !tbaa !23
  %t60 = ashr i32 %t59, 16
  %t62 = icmp eq i32 %t60, 1
  store i1 %t62, ptr %l55, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  %t64 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t64, ptr %rv
  br label %ret
bb16:
  %t65 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t65, ptr %l5, !tbaa !27
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb17, label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_36d5ca6fa18785ed_2ca50b1ef1b0ebf9)
  unreachable
bb18:
  br label %bb19
bb19:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t71 = load i64, ptr %l3, !tbaa !24
  %t72 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t76 = call i64 @compiler_2fsession_2edeclOf(ptr %v0, ptr %v1, ptr %t70, i64 %t71, { i64, ptr } %t72)
  store i64 %t76, ptr %l62
  br label %bb20
bb20:
  %t77 = load i64, ptr %l62, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  %t78 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t78, ptr %l63, !tbaa !27
  %t79 = load i64, ptr %l6, !tbaa !24
  %t81 = icmp sge i64 %t79, 0
  br i1 %t81, label %bb21, label %bb22
bb21:
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i64, ptr %l3, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l69
  br label %bb23
bb22:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d68, i32 0, i32 1) }, ptr %l66, !tbaa !27
  br label %bb25
bb23:
  %t88 = load i64, ptr %l6, !tbaa !24
  %t89 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t91 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %s1, { i64, ptr } %t89, i64 %t88, i1 true)
  store { i64, ptr } %t91, ptr %l71
  br label %bb24
bb24:
  %t92 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t92, ptr %l66, !tbaa !27
  br label %bb25
bb25:
  %t94 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t96 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t94, { i64, ptr } %t95)
  store { i64, ptr } %t96, ptr %l73
  br label %bb26
bb26:
  %t97 = load ptr, ptr %l2, !tbaa !29
  %t99 = icmp eq ptr %t97, null
  br i1 %t99, label %bb27, label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_913972385efaf6d8_94fc87626a418744)
  unreachable
bb28:
  br label %bb29
bb29:
  %t101 = load ptr, ptr %l2, !tbaa !29
  %t102 = load i64, ptr %l3, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t107 = call { i64, ptr } @compiler_2fsession_2eexampleText(ptr %v0, ptr %v1, ptr %s1, ptr %t101, i64 %t102, { i64, ptr } %t103)
  store { i64, ptr } %t107, ptr %l79
  br label %bb30
bb30:
  %t108 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = add i64 %t110, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t109, i64 %t110)
  %t116 = getelementptr i8, ptr %t115, i64 %t110
  call void @olang_textcopy(ptr %t116, ptr %t112, i64 %t113)
  %t117 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t115, 1
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t119, ptr %lp7
  %t121 = load ptr, ptr %lp7
  store { i64, ptr } %t118, ptr %t121, !tbaa !27
  %t122 = load ptr, ptr %lp7
  %t123 = load { i64, ptr }, ptr %t122, !tbaa !27
  store { i64, ptr } %t123, ptr %l81, !tbaa !27
  %t124 = call ptr @__olang_scope_hold(ptr %v2)
  %t125 = ptrtoint ptr %t124 to i64
  store i64 %t125, ptr %l82, !tbaa !24
  %t126 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aFound_2e1
  br i1 %t126, label %bb31, label %bb32
bb31:
  %t128 = call ptr @__olang_region_make(ptr %v2)
  %t129 = ptrtoint ptr %t128 to i64
  store i64 %t129, ptr %l82, !tbaa !24
  br label %bb32
bb32:
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t132 = getelementptr %"compiler/session:Analysis", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/load:Loader", ptr %t133, i32 0, i32 10
  %t136 = load i64, ptr %l3, !tbaa !24
  %t139 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t135, i64 %t136)
  store ptr %t139, ptr %l88
  br label %bb33
bb33:
  %t140 = load ptr, ptr %l88, !tbaa !29
  %t142 = getelementptr %"compiler/load:Module", ptr %t140, i32 0, i32 1
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 1
  %t146 = extractvalue { i64, ptr } %t143, 0
  %t147 = load i64, ptr %l82
  %t148 = inttoptr i64 %t147 to ptr
  %t149 = call ptr @__olang_held_alloc(ptr %t148, i64 %t146)
  call void @olang_textcopy(ptr %t149, ptr %t145, i64 %t146)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = load i64, ptr %l6, !tbaa !24
  %t154 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t157 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t154, { i64, ptr } %t151, i64 %t153)
  store %"compiler/session:Found" %t157, ptr %l94
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s1)
  %t158 = load %"compiler/session:Found", ptr %l94
  %t159 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t158, 1
  store { i32, %"compiler/session:Found" } %t159, ptr %rv
  br label %ret
bb35:
  %t160 = load { i64, [6 x i64] }, ptr %l1
  %t162 = extractvalue { i64, [6 x i64] } %t160, 0
  %t163 = icmp eq i64 %t162, 2
  br i1 %t163, label %bb36, label %bb37
bb36:
  %t165 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t166 = getelementptr { i64 }, ptr %t165, i32 0, i32 0
  %t167 = load i64, ptr %t166
  store i64 %t167, ptr %l8, !tbaa !24
  br label %bb38
bb37:
  br label %bb91
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t169 = load ptr, ptr %l2, !tbaa !29
  %t171 = icmp eq ptr %t169, null
  br i1 %t171, label %bb39, label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_50b486dff56c46f7_6641abdfc6e3fb13)
  unreachable
bb40:
  br label %bb41
bb41:
  %t173 = load ptr, ptr %l2, !tbaa !29
  %t176 = getelementptr %"compiler/check:Checker", ptr %t173, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !29
  %t178 = load i64, ptr %l8, !tbaa !24
  %t181 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t177, i64 %t178)
  store i64 %t181, ptr %l104
  br label %bb42
bb42:
  %t182 = load i64, ptr %l104, !tbaa !24
  store i64 %t182, ptr %l9, !tbaa !24
  %t183 = load ptr, ptr %l2, !tbaa !29
  %t185 = icmp eq ptr %t183, null
  br i1 %t185, label %bb43, label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_e9f7bb5439d2c10a_6c9ebd98d3e3d5ee)
  unreachable
bb44:
  br label %bb45
bb45:
  %t187 = load ptr, ptr %l2, !tbaa !29
  %t190 = getelementptr %"compiler/check:Checker", ptr %t187, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !29
  %t192 = load i64, ptr %l8, !tbaa !24
  %t195 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s5, ptr %t191, i64 %t192)
  store ptr %t195, ptr %l111
  br label %bb46
bb46:
  %t196 = load ptr, ptr %l111, !tbaa !29
  %t198 = getelementptr %"compiler/ast:Func", ptr %t196, i32 0, i32 0
  %t199 = getelementptr %"compiler/source:Span", ptr %t198, i32 0, i32 0
  %t200 = load i32, ptr %t199, !tbaa !23
  %t202 = sext i32 %t200 to i64
  store i64 %t202, ptr %l10, !tbaa !24
  %t204 = load ptr, ptr %l2, !tbaa !29
  %t206 = icmp eq ptr %t204, null
  br i1 %t206, label %bb47, label %bb48
bb47:
  call void @__olang_check_failed(ptr @olang_loc_f7a7bb63ca62da11_77899a051c081195)
  unreachable
bb48:
  br label %bb49
bb49:
  %t208 = load ptr, ptr %l2, !tbaa !29
  %t211 = getelementptr %"compiler/check:Checker", ptr %t208, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !29
  %t213 = load i64, ptr %l8, !tbaa !24
  %t216 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t212, i64 %t213)
  store ptr %t216, ptr %l121
  br label %bb50
bb50:
  %t217 = load ptr, ptr %l121, !tbaa !29
  store ptr %t217, ptr %l11, !tbaa !29
  %t218 = load ptr, ptr %l11, !tbaa !29
  %t220 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t218)
  store i1 %t220, ptr %l123
  br label %bb51
bb51:
  %t221 = load i1, ptr %l123, !tbaa !21
  br i1 %t221, label %bb52, label %bb53
bb52:
  %t222 = load ptr, ptr %l11, !tbaa !29
  store ptr %t222, ptr %l125, !tbaa !29
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb54, label %bb55
bb53:
  %t227 = load ptr, ptr %l2, !tbaa !29
  %t229 = icmp eq ptr %t227, null
  br i1 %t229, label %bb62, label %bb63
bb54:
  call void @__olang_check_failed(ptr @olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980)
  unreachable
bb55:
  br label %bb56
bb56:
  %t231 = load ptr, ptr %l2, !tbaa !29
  %t234 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = getelementptr %"compiler/generic:Program", ptr %t235, i32 0, i32 0
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t240 = getelementptr %"compiler/load:Loader", ptr %t238, i32 0, i32 3
  %t241 = load ptr, ptr %t240, !tbaa !29
  %t242 = load ptr, ptr %l125, !tbaa !29
  %t244 = call { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v0, ptr %s5, ptr %t242, ptr %t241)
  store { i64, ptr } %t244, ptr %l133
  br label %bb57
bb57:
  %t245 = load ptr, ptr %l2, !tbaa !29
  %t247 = icmp eq ptr %t245, null
  br i1 %t247, label %bb58, label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980)
  unreachable
bb59:
  br label %bb60
bb60:
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t252 = getelementptr %"compiler/check:Checker", ptr %t249, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !29
  %t255 = getelementptr %"compiler/generic:Program", ptr %t253, i32 0, i32 0
  %t256 = load ptr, ptr %t255, !tbaa !29
  %t258 = getelementptr %"compiler/load:Loader", ptr %t256, i32 0, i32 3
  %t259 = load ptr, ptr %t258, !tbaa !29
  %t260 = load ptr, ptr %l11, !tbaa !29
  %t262 = getelementptr %"compiler/ast:Func", ptr %t260, i32 0, i32 9
  %t263 = load i32, ptr %t262, !tbaa !23
  %t266 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s5, ptr %t259, i32 %t263)
  store { i64, ptr } %t266, ptr %l143
  br label %bb61
bb61:
  %t267 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 1
  %t269 = extractvalue { i64, ptr } %t267, 0
  %t270 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t268, i64 %t269)
  %t278 = getelementptr i8, ptr %t277, i64 %t269
  call void @olang_textcopy(ptr %t278, ptr %t270, i64 %t271)
  %t279 = getelementptr i8, ptr %t278, i64 %t271
  call void @olang_textcopy(ptr %t279, ptr %t274, i64 %t275)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t277, 1
  store { i64, ptr } %t281, ptr %l124, !tbaa !27
  br label %bb70
bb62:
  call void @__olang_check_failed(ptr @olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980)
  unreachable
bb63:
  br label %bb64
bb64:
  %t283 = load ptr, ptr %l2, !tbaa !29
  %t284 = load i64, ptr %l8, !tbaa !24
  %t287 = call { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %s5, ptr %t283, i64 %t284)
  store { i64, ptr } %t287, ptr %l149
  br label %bb65
bb65:
  %t288 = load ptr, ptr %l2, !tbaa !29
  %t290 = icmp eq ptr %t288, null
  br i1 %t290, label %bb66, label %bb67
bb66:
  call void @__olang_check_failed(ptr @olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980)
  unreachable
bb67:
  br label %bb68
bb68:
  %t292 = load ptr, ptr %l2, !tbaa !29
  %t295 = getelementptr %"compiler/check:Checker", ptr %t292, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !29
  %t298 = getelementptr %"compiler/generic:Program", ptr %t296, i32 0, i32 0
  %t299 = load ptr, ptr %t298, !tbaa !29
  %t301 = getelementptr %"compiler/load:Loader", ptr %t299, i32 0, i32 3
  %t302 = load ptr, ptr %t301, !tbaa !29
  %t303 = load ptr, ptr %l11, !tbaa !29
  %t305 = getelementptr %"compiler/ast:Func", ptr %t303, i32 0, i32 2
  %t306 = load i32, ptr %t305, !tbaa !23
  %t309 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s5, ptr %t302, i32 %t306)
  store { i64, ptr } %t309, ptr %l159
  br label %bb69
bb69:
  %t310 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t310, 1
  %t312 = extractvalue { i64, ptr } %t310, 0
  %t313 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t314 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t315 = add i64 %t312, %t314
  %t316 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t316, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = add i64 %t315, %t318
  %t320 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t319)
  call void @olang_textcopy(ptr %t320, ptr %t311, i64 %t312)
  %t321 = getelementptr i8, ptr %t320, i64 %t312
  call void @olang_textcopy(ptr %t321, ptr %t313, i64 %t314)
  %t322 = getelementptr i8, ptr %t321, i64 %t314
  call void @olang_textcopy(ptr %t322, ptr %t317, i64 %t318)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t320, 1
  store { i64, ptr } %t324, ptr %l124, !tbaa !27
  br label %bb70
bb70:
  %t326 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t326, ptr %l12, !tbaa !27
  %t327 = load ptr, ptr %l2, !tbaa !29
  %t329 = icmp eq ptr %t327, null
  br i1 %t329, label %bb71, label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_9453126c7f8f920b_6892400c5eb9861f)
  unreachable
bb72:
  br label %bb73
bb73:
  %t331 = load ptr, ptr %l2, !tbaa !29
  %t332 = load i64, ptr %l9, !tbaa !24
  %t333 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t337 = call { i64, ptr } @compiler_2fsession_2eexampleText(ptr %v0, ptr %s5, ptr %s5, ptr %t331, i64 %t332, { i64, ptr } %t333)
  store { i64, ptr } %t337, ptr %l166
  br label %bb74
bb74:
  %t338 = load { i64, ptr }, ptr %l166, !tbaa !27
  store { i64, ptr } %t338, ptr %l13, !tbaa !27
  %t339 = call ptr @__olang_scope_hold(ptr %v2)
  %t340 = ptrtoint ptr %t339 to i64
  store i64 %t340, ptr %l167, !tbaa !24
  %t341 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aFound_2e0
  br i1 %t341, label %bb75, label %bb76
bb75:
  %t343 = call ptr @__olang_region_make(ptr %v2)
  %t344 = ptrtoint ptr %t343 to i64
  store i64 %t344, ptr %l167, !tbaa !24
  br label %bb76
bb76:
  %t345 = load ptr, ptr %l2, !tbaa !29
  %t347 = icmp eq ptr %t345, null
  br i1 %t347, label %bb77, label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_9fba17dd33d652ce_1e95afa29dd6ec2a)
  unreachable
bb78:
  br label %bb79
bb79:
  %t349 = load ptr, ptr %l2, !tbaa !29
  store ptr %t349, ptr %l171, !tbaa !29
  %t350 = load ptr, ptr %l0, !tbaa !29
  %t352 = getelementptr %"compiler/session:Analysis", ptr %t350, i32 0, i32 3
  %t353 = load ptr, ptr %t352, !tbaa !29
  %t355 = icmp eq ptr %t353, null
  br i1 %t355, label %bb80, label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_9fba17dd33d652ce_1e95afa29dd6ec2a)
  unreachable
bb81:
  br label %bb82
bb82:
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t359 = getelementptr %"compiler/session:Analysis", ptr %t357, i32 0, i32 3
  %t360 = load ptr, ptr %t359, !tbaa !29
  %t361 = load i64, ptr %l8, !tbaa !24
  %t362 = load ptr, ptr %l171, !tbaa !29
  %t365 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v0, ptr %s5, ptr %t362, ptr %t360, i64 %t361)
  store { i64, ptr } %t365, ptr %l178
  br label %bb83
bb83:
  %t366 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t366, ptr %l179, !tbaa !27
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i64, ptr %l9, !tbaa !24
  %t371 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t367, i64 %t368)
  store { i64, ptr } %t371, ptr %l182
  br label %bb84
bb84:
  %t372 = load i64, ptr %l10, !tbaa !24
  %t373 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t375 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %s5, { i64, ptr } %t373, i64 %t372)
  store { i64, ptr } %t375, ptr %l184
  br label %bb85
bb85:
  %t376 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t379 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s5, ptr %s5, ptr %s5, { i64, ptr } %t377, { i64, ptr } %t376)
  store { i64, ptr } %t379, ptr %l186
  br label %bb86
bb86:
  %t380 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t381 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t385 = extractvalue { i64, ptr } %t380, 1
  %t386 = extractvalue { i64, ptr } %t380, 0
  %t387 = add i64 %t383, %t386
  %t388 = load i64, ptr %l167
  %t389 = inttoptr i64 %t388 to ptr
  %t390 = call ptr @__olang_held_alloc(ptr %t389, i64 %t387)
  call void @olang_textcopy(ptr %t390, ptr %t382, i64 %t383)
  %t391 = getelementptr i8, ptr %t390, i64 %t383
  call void @olang_textcopy(ptr %t391, ptr %t385, i64 %t386)
  %t392 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t393 = insertvalue { i64, ptr } %t392, ptr %t390, 1
  store { i64, ptr } %t393, ptr %l189, !tbaa !27
  %t395 = call ptr @__olang_scope_hold(ptr %v2)
  %t396 = ptrtoint ptr %t395 to i64
  store i64 %t396, ptr %l190, !tbaa !24
  %t397 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aFound_2e1
  br i1 %t397, label %bb87, label %bb88
bb87:
  %t399 = call ptr @__olang_region_make(ptr %v2)
  %t400 = ptrtoint ptr %t399 to i64
  store i64 %t400, ptr %l190, !tbaa !24
  br label %bb88
bb88:
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/session:Analysis", ptr %t401, i32 0, i32 0
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = getelementptr %"compiler/load:Loader", ptr %t404, i32 0, i32 10
  %t407 = load i64, ptr %l9, !tbaa !24
  %t410 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t406, i64 %t407)
  store ptr %t410, ptr %l196
  br label %bb89
bb89:
  %t411 = load ptr, ptr %l196, !tbaa !29
  %t413 = getelementptr %"compiler/load:Module", ptr %t411, i32 0, i32 1
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !27
  %t416 = extractvalue { i64, ptr } %t414, 1
  %t417 = extractvalue { i64, ptr } %t414, 0
  %t418 = load i64, ptr %l190
  %t419 = inttoptr i64 %t418 to ptr
  %t420 = call ptr @__olang_held_alloc(ptr %t419, i64 %t417)
  call void @olang_textcopy(ptr %t420, ptr %t416, i64 %t417)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  %t424 = load i64, ptr %l10, !tbaa !24
  %t425 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t428 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t425, { i64, ptr } %t422, i64 %t424)
  store %"compiler/session:Found" %t428, ptr %l202
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s5)
  %t429 = load %"compiler/session:Found", ptr %l202
  %t430 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t429, 1
  store { i32, %"compiler/session:Found" } %t430, ptr %rv
  br label %ret
bb91:
  %t431 = load { i64, [6 x i64] }, ptr %l1
  %t433 = extractvalue { i64, [6 x i64] } %t431, 0
  %t434 = icmp eq i64 %t433, 3
  br i1 %t434, label %bb92, label %bb93
bb92:
  %t436 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t437 = getelementptr { i32, i64 }, ptr %t436, i32 0, i32 0
  %t438 = load i32, ptr %t437
  store i32 %t438, ptr %l14, !tbaa !23
  %t440 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t441 = getelementptr { i32, i64 }, ptr %t440, i32 0, i32 1
  %t442 = load i64, ptr %t441
  store i64 %t442, ptr %l15, !tbaa !24
  br label %bb94
bb93:
  br label %bb106
bb94:
  store %olang.scope zeroinitializer, ptr %s10
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr %l14, !tbaa !23
  %t446 = load i64, ptr %l15, !tbaa !24
  %t450 = call { i32, %"compiler/session:memberInfo" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efield(ptr %v0, ptr %v2, ptr %t444, i32 %t445, i64 %t446)
  %t451 = extractvalue { i32, %"compiler/session:memberInfo" } %t450, 1
  %t452 = extractvalue { i32, %"compiler/session:memberInfo" } %t450, 0
  store i32 %t452, ptr %l212
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb96, label %ok.454, !prof !99
ok.454:
  store %"compiler/session:memberInfo" %t451, ptr %l211
  br label %bb95
bb95:
  %t455 = load %"compiler/session:memberInfo", ptr %l211
  store %"compiler/session:memberInfo" %t455, ptr %l207
  br label %bb97
bb96:
  %t456 = load i32, ptr %l212, !tbaa !23
  %t457 = lshr i32 %t456, 16
  %t458 = and i32 %t456, 65535
  %t459 = icmp eq i32 %t457, 1
  %t460 = select i1 %t459, i32 1, i32 0
  %t461 = icmp eq i32 %t456, 0
  %t462 = shl i32 %t460, 16
  %t463 = or i32 %t462, %t458
  %t464 = select i1 %t461, i32 0, i32 %t463
  call void @__olang_scope_close(ptr %s10)
  %t466 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 %t464, 0
  store { i32, %"compiler/session:Found" } %t466, ptr %rv
  br label %ret
bb97:
  %t467 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 64, i64 8)
  store ptr %t467, ptr %lp16
  %t468 = load %"compiler/session:memberInfo", ptr %l207
  %t469 = load ptr, ptr %lp16
  store %"compiler/session:memberInfo" %t468, ptr %t469
  %t470 = call ptr @__olang_scope_hold(ptr %v2)
  %t471 = ptrtoint ptr %t470 to i64
  store i64 %t471, ptr %l214, !tbaa !24
  %t472 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aFound_2e0
  br i1 %t472, label %bb98, label %bb99
bb98:
  %t474 = call ptr @__olang_region_make(ptr %v2)
  %t475 = ptrtoint ptr %t474 to i64
  store i64 %t475, ptr %l214, !tbaa !24
  br label %bb99
bb99:
  %t476 = load ptr, ptr %lp16
  %t477 = getelementptr %"compiler/session:memberInfo", ptr %t476, i32 0, i32 0
  %t478 = load { i64, ptr }, ptr %t477, !tbaa !27
  store { i64, ptr } %t478, ptr %l216, !tbaa !27
  %t479 = load ptr, ptr %l2, !tbaa !29
  %t481 = icmp eq ptr %t479, null
  br i1 %t481, label %bb100, label %bb101
bb100:
  call void @__olang_check_failed(ptr @olang_loc_8be95a0084a275_27fb33976f90d831)
  unreachable
bb101:
  br label %bb102
bb102:
  %t483 = load ptr, ptr %l2, !tbaa !29
  %t484 = load ptr, ptr %lp16
  %t485 = getelementptr %"compiler/session:memberInfo", ptr %t484, i32 0, i32 1
  %t486 = load i32, ptr %t485, !tbaa !23
  %t489 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s10, ptr %t483, i32 %t486)
  store { i64, ptr } %t489, ptr %l221
  br label %bb103
bb103:
  %t490 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t491 = extractvalue { i64, ptr } %t490, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t495 = add i64 %t492, %t494
  %t496 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 1
  %t498 = extractvalue { i64, ptr } %t496, 0
  %t499 = add i64 %t495, %t498
  %t500 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t499)
  call void @olang_textcopy(ptr %t500, ptr %t491, i64 %t492)
  %t501 = getelementptr i8, ptr %t500, i64 %t492
  call void @olang_textcopy(ptr %t501, ptr %t493, i64 %t494)
  %t502 = getelementptr i8, ptr %t501, i64 %t494
  call void @olang_textcopy(ptr %t502, ptr %t497, i64 %t498)
  %t503 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t500, 1
  %t506 = load ptr, ptr %lp16
  %t507 = getelementptr %"compiler/session:memberInfo", ptr %t506, i32 0, i32 2
  %t508 = load { i64, ptr }, ptr %t507, !tbaa !27
  %t509 = load i64, ptr %l214
  %t510 = inttoptr i64 %t509 to ptr
  %t513 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s10, ptr %v2, ptr %t510, { i64, ptr } %t504, { i64, ptr } %t508)
  store { i64, ptr } %t513, ptr %l225
  br label %bb104
bb104:
  %t514 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t515 = load ptr, ptr %lp16
  %t516 = getelementptr %"compiler/session:memberInfo", ptr %t515, i32 0, i32 3
  %t517 = load { i64, ptr }, ptr %t516, !tbaa !27
  %t518 = load ptr, ptr %lp16
  %t519 = getelementptr %"compiler/session:memberInfo", ptr %t518, i32 0, i32 4
  %t520 = load i64, ptr %t519, !tbaa !24
  %t524 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t514, { i64, ptr } %t517, i64 %t520)
  store %"compiler/session:Found" %t524, ptr %l229
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s10)
  %t525 = load %"compiler/session:Found", ptr %l229
  %t526 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t525, 1
  store { i32, %"compiler/session:Found" } %t526, ptr %rv
  br label %ret
bb106:
  %t527 = load { i64, [6 x i64] }, ptr %l1
  %t529 = extractvalue { i64, [6 x i64] } %t527, 0
  %t530 = icmp eq i64 %t529, 4
  br i1 %t530, label %bb107, label %bb108
bb107:
  %t532 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t533 = getelementptr { i64, i32 }, ptr %t532, i32 0, i32 0
  %t534 = load i64, ptr %t533
  store i64 %t534, ptr %l17, !tbaa !24
  %t536 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t537 = getelementptr { i64, i32 }, ptr %t536, i32 0, i32 1
  %t538 = load i32, ptr %t537
  store i32 %t538, ptr %l18, !tbaa !23
  br label %bb109
bb108:
  br label %bb133
bb109:
  store %olang.scope zeroinitializer, ptr %s12
  %t540 = load ptr, ptr %l2, !tbaa !29
  %t542 = icmp eq ptr %t540, null
  br i1 %t542, label %bb110, label %bb111
bb110:
  call void @__olang_check_failed(ptr @olang_loc_62de0451ac433905_e234825e46030f99)
  unreachable
bb111:
  br label %bb112
bb112:
  %t544 = load ptr, ptr %l2, !tbaa !29
  %t547 = getelementptr %"compiler/check:Checker", ptr %t544, i32 0, i32 19
  %t548 = load i64, ptr %l17, !tbaa !24
  %t551 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t547, i64 %t548)
  store ptr %t551, ptr %l240
  br label %bb113
bb113:
  %t552 = load ptr, ptr %l240, !tbaa !29
  store ptr %t552, ptr %l19, !tbaa !29
  %t553 = load ptr, ptr %l19, !tbaa !29
  %t555 = getelementptr %"compiler/typed:Body", ptr %t553, i32 0, i32 7
  %t556 = load i32, ptr %l18, !tbaa !23
  %t558 = sext i32 %t556 to i64
  %t561 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t555, i64 %t558)
  store %"compiler/typed:Local" %t561, ptr %l245
  br label %bb114
bb114:
  %t562 = load %"compiler/typed:Local", ptr %l245
  store %"compiler/typed:Local" %t562, ptr %l20
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load ptr, ptr %l19, !tbaa !29
  %t566 = getelementptr %"compiler/typed:Body", ptr %t564, i32 0, i32 3
  %t567 = load i64, ptr %t566, !tbaa !24
  %t570 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %t563, i64 %t567)
  store i64 %t570, ptr %l249
  br label %bb115
bb115:
  %t571 = load i64, ptr %l249, !tbaa !24
  store i64 %t571, ptr %l21, !tbaa !24
  %t572 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 4
  %t573 = load i32, ptr %t572, !range !{i32 0, i32 7}
  %t575 = trunc i64 0 to i32
  %t576 = icmp eq i32 %t573, %t575
  br i1 %t576, label %bb116, label %bb117
bb116:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d72, i32 0, i32 1) }, ptr %l252, !tbaa !27
  br label %bb118
bb117:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d73, i32 0, i32 1) }, ptr %l252, !tbaa !27
  br label %bb118
bb118:
  %t578 = load { i64, ptr }, ptr %l252, !tbaa !27
  store { i64, ptr } %t578, ptr %l253, !tbaa !27
  %t580 = load ptr, ptr %l2, !tbaa !29
  %t582 = icmp eq ptr %t580, null
  br i1 %t582, label %bb119, label %bb120
bb119:
  call void @__olang_check_failed(ptr @olang_loc_4b7568962893615e_80e60e4246117872)
  unreachable
bb120:
  br label %bb121
bb121:
  %t584 = load ptr, ptr %l2, !tbaa !29
  %t587 = getelementptr %"compiler/check:Checker", ptr %t584, i32 0, i32 1
  %t588 = load ptr, ptr %t587, !tbaa !29
  %t590 = getelementptr %"compiler/generic:Program", ptr %t588, i32 0, i32 0
  %t591 = load ptr, ptr %t590, !tbaa !29
  %t593 = getelementptr %"compiler/load:Loader", ptr %t591, i32 0, i32 3
  %t594 = load ptr, ptr %t593, !tbaa !29
  %t595 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 0
  %t596 = load i32, ptr %t595, !tbaa !23
  %t599 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s12, ptr %t594, i32 %t596)
  store { i64, ptr } %t599, ptr %l262
  br label %bb122
bb122:
  %t600 = load ptr, ptr %l2, !tbaa !29
  %t602 = icmp eq ptr %t600, null
  br i1 %t602, label %bb123, label %bb124
bb123:
  call void @__olang_check_failed(ptr @olang_loc_4b7568962893615e_80e60e4246117872)
  unreachable
bb124:
  br label %bb125
bb125:
  %t604 = load ptr, ptr %l2, !tbaa !29
  %t605 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 2
  %t606 = load i32, ptr %t605, !tbaa !23
  %t609 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s12, ptr %t604, i32 %t606)
  store { i64, ptr } %t609, ptr %l267
  br label %bb126
bb126:
  %t610 = load { i64, ptr }, ptr %l253, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 1
  %t612 = extractvalue { i64, ptr } %t610, 0
  %t613 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t614 = extractvalue { i64, ptr } %t613, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = add i64 %t612, %t615
  %t617 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t618 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t619 = add i64 %t616, %t618
  %t620 = load { i64, ptr }, ptr %l267, !tbaa !27
  %t621 = extractvalue { i64, ptr } %t620, 1
  %t622 = extractvalue { i64, ptr } %t620, 0
  %t623 = add i64 %t619, %t622
  %t624 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t623)
  call void @olang_textcopy(ptr %t624, ptr %t611, i64 %t612)
  %t625 = getelementptr i8, ptr %t624, i64 %t612
  call void @olang_textcopy(ptr %t625, ptr %t614, i64 %t615)
  %t626 = getelementptr i8, ptr %t625, i64 %t615
  call void @olang_textcopy(ptr %t626, ptr %t617, i64 %t618)
  %t627 = getelementptr i8, ptr %t626, i64 %t618
  call void @olang_textcopy(ptr %t627, ptr %t621, i64 %t622)
  %t628 = insertvalue { i64, ptr } undef, i64 %t623, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t624, 1
  %t632 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s12, ptr %s12, ptr %v2, { i64, ptr } %t629, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store { i64, ptr } %t632, ptr %l270
  br label %bb127
bb127:
  %t633 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t633, ptr %lp23
  %t634 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t635 = load ptr, ptr %lp23
  store { i64, ptr } %t634, ptr %t635, !tbaa !27
  %t636 = load ptr, ptr %lp23
  %t637 = load { i64, ptr }, ptr %t636, !tbaa !27
  store { i64, ptr } %t637, ptr %l271, !tbaa !27
  %t638 = load i64, ptr %l21, !tbaa !24
  %t640 = icmp sge i64 %t638, 0
  br i1 %t640, label %bb128, label %bb129
bb128:
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t644 = getelementptr %"compiler/session:Analysis", ptr %t642, i32 0, i32 0
  %t645 = load ptr, ptr %t644, !tbaa !29
  %t647 = getelementptr %"compiler/load:Loader", ptr %t645, i32 0, i32 10
  %t648 = load i64, ptr %l21, !tbaa !24
  %t651 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t647, i64 %t648)
  store ptr %t651, ptr %l279
  br label %bb130
bb129:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d76, i32 0, i32 1) }, ptr %l274, !tbaa !27
  br label %bb131
bb130:
  %t652 = load ptr, ptr %l279, !tbaa !29
  %t654 = getelementptr %"compiler/load:Module", ptr %t652, i32 0, i32 1
  %t655 = load { i64, ptr }, ptr %t654, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t655, 1
  %t658 = extractvalue { i64, ptr } %t655, 0
  %t659 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t658)
  call void @olang_textcopy(ptr %t659, ptr %t657, i64 %t658)
  %t660 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t661 = insertvalue { i64, ptr } %t660, ptr %t659, 1
  store { i64, ptr } %t661, ptr %l274, !tbaa !27
  br label %bb131
bb131:
  %t664 = getelementptr %"compiler/typed:Local", ptr %l20, i32 0, i32 1
  %t665 = getelementptr %"compiler/source:Span", ptr %t664, i32 0, i32 0
  %t666 = load i32, ptr %t665, !tbaa !23
  %t668 = sext i32 %t666 to i64
  %t669 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t670 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t672 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t669, { i64, ptr } %t670, i64 %t668)
  store %"compiler/session:Found" %t672, ptr %l286
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s12)
  %t673 = load %"compiler/session:Found", ptr %l286
  %t674 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t673, 1
  store { i32, %"compiler/session:Found" } %t674, ptr %rv
  br label %ret
bb133:
  %t675 = load { i64, [6 x i64] }, ptr %l1
  %t677 = extractvalue { i64, [6 x i64] } %t675, 0
  %t678 = icmp eq i64 %t677, 5
  br i1 %t678, label %bb134, label %bb135
bb134:
  %t680 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t681 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t680, i32 0, i32 0
  %t682 = load i64, ptr %t681
  store i64 %t682, ptr %l24, !tbaa !24
  %t684 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t685 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t684, i32 0, i32 1
  %t686 = load i64, ptr %t685
  store i64 %t686, ptr %l25, !tbaa !24
  %t688 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t689 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t688, i32 0, i32 2
  %t690 = load { i64, ptr }, ptr %t689
  store { i64, ptr } %t690, ptr %l26, !tbaa !27
  %t692 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t693 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t692, i32 0, i32 3
  %t694 = load { i64, ptr }, ptr %t693
  store { i64, ptr } %t694, ptr %l27, !tbaa !27
  br label %bb136
bb135:
  br label %bb144
bb136:
  %t696 = call ptr @__olang_scope_hold(ptr %v2)
  %t697 = ptrtoint ptr %t696 to i64
  store i64 %t697, ptr %l293, !tbaa !24
  %t698 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aFound_2e0
  br i1 %t698, label %bb137, label %bb138
bb137:
  %t700 = call ptr @__olang_region_make(ptr %v2)
  %t701 = ptrtoint ptr %t700 to i64
  store i64 %t701, ptr %l293, !tbaa !24
  br label %bb138
bb138:
  %t702 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t703 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t704 = load i64, ptr %l293
  %t705 = inttoptr i64 %t704 to ptr
  %t708 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %v1, ptr %v1, ptr %t705, { i64, ptr } %t702, { i64, ptr } %t703)
  store { i64, ptr } %t708, ptr %l297
  br label %bb139
bb139:
  %t709 = load { i64, ptr }, ptr %l297, !tbaa !27
  store { i64, ptr } %t709, ptr %l298, !tbaa !27
  %t710 = call ptr @__olang_scope_hold(ptr %v2)
  %t711 = ptrtoint ptr %t710 to i64
  store i64 %t711, ptr %l299, !tbaa !24
  %t712 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aFound_2e1
  br i1 %t712, label %bb140, label %bb141
bb140:
  %t714 = call ptr @__olang_region_make(ptr %v2)
  %t715 = ptrtoint ptr %t714 to i64
  store i64 %t715, ptr %l299, !tbaa !24
  br label %bb141
bb141:
  %t716 = load ptr, ptr %l0, !tbaa !29
  %t718 = getelementptr %"compiler/session:Analysis", ptr %t716, i32 0, i32 0
  %t719 = load ptr, ptr %t718, !tbaa !29
  %t721 = getelementptr %"compiler/load:Loader", ptr %t719, i32 0, i32 10
  %t722 = load i64, ptr %l24, !tbaa !24
  %t725 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t721, i64 %t722)
  store ptr %t725, ptr %l305
  br label %bb142
bb142:
  %t726 = load ptr, ptr %l305, !tbaa !29
  %t728 = getelementptr %"compiler/load:Module", ptr %t726, i32 0, i32 1
  %t729 = load { i64, ptr }, ptr %t728, !tbaa !27
  %t731 = extractvalue { i64, ptr } %t729, 1
  %t732 = extractvalue { i64, ptr } %t729, 0
  %t733 = load i64, ptr %l299
  %t734 = inttoptr i64 %t733 to ptr
  %t735 = call ptr @__olang_held_alloc(ptr %t734, i64 %t732)
  call void @olang_textcopy(ptr %t735, ptr %t731, i64 %t732)
  %t736 = insertvalue { i64, ptr } undef, i64 %t732, 0
  %t737 = insertvalue { i64, ptr } %t736, ptr %t735, 1
  %t739 = load i64, ptr %l25, !tbaa !24
  %t740 = load { i64, ptr }, ptr %l298, !tbaa !27
  %t743 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t740, { i64, ptr } %t737, i64 %t739)
  store %"compiler/session:Found" %t743, ptr %l311
  br label %bb143
bb143:
  %t744 = load %"compiler/session:Found", ptr %l311
  %t745 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t744, 1
  store { i32, %"compiler/session:Found" } %t745, ptr %rv
  br label %ret
bb144:
  %t746 = load { i64, [6 x i64] }, ptr %l1
  %t748 = extractvalue { i64, [6 x i64] } %t746, 0
  %t749 = icmp eq i64 %t748, 6
  br i1 %t749, label %bb145, label %bb146
bb145:
  %t751 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t752 = getelementptr { i64 }, ptr %t751, i32 0, i32 0
  %t753 = load i64, ptr %t752
  store i64 %t753, ptr %l28, !tbaa !24
  br label %bb147
bb146:
  br label %bb157
bb147:
  store %olang.scope zeroinitializer, ptr %s17
  %t755 = load ptr, ptr %l0, !tbaa !29
  %t757 = getelementptr %"compiler/session:Analysis", ptr %t755, i32 0, i32 0
  %t758 = load ptr, ptr %t757, !tbaa !29
  %t760 = getelementptr %"compiler/load:Loader", ptr %t758, i32 0, i32 10
  %t761 = load i64, ptr %l28, !tbaa !24
  %t764 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t760, i64 %t761)
  store ptr %t764, ptr %l319
  br label %bb148
bb148:
  %t765 = load ptr, ptr %l319, !tbaa !29
  store ptr %t765, ptr %l29, !tbaa !29
  %t766 = call ptr @__olang_scope_hold(ptr %v2)
  %t767 = ptrtoint ptr %t766 to i64
  store i64 %t767, ptr %l320, !tbaa !24
  %t768 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aFound_2e0
  br i1 %t768, label %bb149, label %bb150
bb149:
  %t770 = call ptr @__olang_region_make(ptr %v2)
  %t771 = ptrtoint ptr %t770 to i64
  store i64 %t771, ptr %l320, !tbaa !24
  br label %bb150
bb150:
  %t772 = load ptr, ptr %l29, !tbaa !29
  %t774 = getelementptr %"compiler/load:Module", ptr %t772, i32 0, i32 2
  %t775 = load { i64, ptr }, ptr %t774, !tbaa !27
  %t776 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d77, i32 0, i32 1) }, 1
  %t777 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d77, i32 0, i32 1) }, 0
  %t779 = extractvalue { i64, ptr } %t775, 1
  %t780 = extractvalue { i64, ptr } %t775, 0
  %t781 = add i64 %t777, %t780
  %t782 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t783 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t784 = add i64 %t781, %t783
  %t785 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t784)
  call void @olang_textcopy(ptr %t785, ptr %t776, i64 %t777)
  %t786 = getelementptr i8, ptr %t785, i64 %t777
  call void @olang_textcopy(ptr %t786, ptr %t779, i64 %t780)
  %t787 = getelementptr i8, ptr %t786, i64 %t780
  call void @olang_textcopy(ptr %t787, ptr %t782, i64 %t783)
  %t788 = insertvalue { i64, ptr } undef, i64 %t784, 0
  %t789 = insertvalue { i64, ptr } %t788, ptr %t785, 1
  store { i64, ptr } %t789, ptr %l325, !tbaa !27
  %t791 = load ptr, ptr %l29, !tbaa !29
  %t793 = getelementptr %"compiler/load:Module", ptr %t791, i32 0, i32 6
  %t794 = load ptr, ptr %t793, !tbaa !29
  %t796 = icmp eq ptr %t794, null
  br i1 %t796, label %bb151, label %bb152
bb151:
  call void @__olang_check_failed(ptr @olang_loc_2674ac92e3c24a8f_ce1576bd6c3688b3)
  unreachable
bb152:
  br label %bb153
bb153:
  %t798 = load ptr, ptr %l29, !tbaa !29
  %t800 = getelementptr %"compiler/load:Module", ptr %t798, i32 0, i32 6
  %t801 = load ptr, ptr %t800, !tbaa !29
  %t804 = getelementptr %"compiler/source:Source", ptr %t801, i32 0, i32 1
  %t805 = load { i64, ptr }, ptr %t804, !tbaa !27
  %t807 = call { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %s17, { i64, ptr } %t805)
  store { i64, ptr } %t807, ptr %l333
  br label %bb154
bb154:
  %t808 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t809 = load i64, ptr %l320
  %t810 = inttoptr i64 %t809 to ptr
  %t811 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t813 = call { i64, ptr } @compiler_2fsession_2ehover(ptr %s17, ptr %s17, ptr %t810, { i64, ptr } %t811, { i64, ptr } %t808)
  store { i64, ptr } %t813, ptr %l335
  br label %bb155
bb155:
  %t814 = load { i64, ptr }, ptr %l335, !tbaa !27
  %t815 = load ptr, ptr %l29, !tbaa !29
  %t817 = getelementptr %"compiler/load:Module", ptr %t815, i32 0, i32 1
  %t818 = load { i64, ptr }, ptr %t817, !tbaa !27
  %t821 = call %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v2, ptr %v0, ptr %v2, { i64, ptr } %t814, { i64, ptr } %t818, i64 0)
  store %"compiler/session:Found" %t821, ptr %l339
  br label %bb156
bb156:
  call void @__olang_scope_close(ptr %s17)
  %t822 = load %"compiler/session:Found", ptr %l339
  %t823 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, %"compiler/session:Found" %t822, 1
  store { i32, %"compiler/session:Found" } %t823, ptr %rv
  br label %ret
bb157:
  %t824 = load { i64, [6 x i64] }, ptr %l1
  %t826 = extractvalue { i64, [6 x i64] } %t824, 0
  %t827 = icmp eq i64 %t826, 0
  br i1 %t827, label %bb158, label %bb159
bb158:
  br label %bb160
bb159:
  br label %bb161
bb160:
  %t830 = insertvalue { i32, %"compiler/session:Found" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:Found" } %t830, ptr %rv
  br label %ret
bb161:
  call void @__olang_check_failed(ptr @olang_loc_3b23b9b6a905edf7_80e5cdf9542388b)
  unreachable
ret:
  %rr = load { i32, %"compiler/session:Found" }, ptr %rv
  ret { i32, %"compiler/session:Found" } %rr
}

define dso_local { i32, %"compiler/session:memberInfo" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efield(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca %"compiler/typed:Local"
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %lp14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l26 = alloca i32
  %l29 = alloca i32
  %l37 = alloca i32
  %l46 = alloca i32
  %l58 = alloca i32
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca ptr
  %l84 = alloca i32
  %l88 = alloca i1
  %l96 = alloca i32
  %l99 = alloca i1
  %l100 = alloca i64
  %l103 = alloca i64
  %l106 = alloca ptr
  %l110 = alloca i32
  %l112 = alloca %"compiler/typed:Local"
  %l116 = alloca i64
  %l122 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l145 = alloca { i64, ptr }
  %l152 = alloca ptr
  %l160 = alloca i32
  %l161 = alloca { i64, ptr }
  %l166 = alloca i32
  %l167 = alloca { i64, ptr }
  %l171 = alloca { i64, ptr }
  %l172 = alloca i32
  %l173 = alloca i64
  %l178 = alloca { i64, ptr }
  %l179 = alloca { i64, ptr }
  %l180 = alloca i64
  %l186 = alloca ptr
  %l193 = alloca %"compiler/session:memberInfo"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/session:memberInfo" }
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l1, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l26
  br label %bb4
bb4:
  %t21 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t23 = trunc i64 20 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb7, label %bb8
bb6:
  %t30 = load i32, ptr %l1, !tbaa !23
  store i32 %t30, ptr %l29, !tbaa !23
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943)
  unreachable
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l1, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l37
  br label %bb10
bb10:
  %t43 = load i32, ptr %l37, !tbaa !23
  store i32 %t43, ptr %l29, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l29, !tbaa !23
  store i32 %t44, ptr %l4, !tbaa !23
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_e81878307a0930f8_ac6e376276a113b4)
  unreachable
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l4, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l46
  br label %bb15
bb15:
  %t60 = load i32, ptr %l46, !range !{i32 0, i32 33}
  %t62 = trunc i64 18 to i32
  %t63 = icmp eq i32 %t60, %t62
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  %t68 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:memberInfo" } %t68, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t69 = load ptr, ptr %l3, !tbaa !29
  %t71 = icmp eq ptr %t69, null
  br i1 %t71, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_cf719ce72396210d_6e539aa1951515a9)
  unreachable
bb20:
  br label %bb21
bb21:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t76 = getelementptr %"compiler/check:Checker", ptr %t73, i32 0, i32 1
  %t77 = load ptr, ptr %t76, !tbaa !29
  %t79 = getelementptr %"compiler/generic:Program", ptr %t77, i32 0, i32 2
  %t80 = load i32, ptr %l4, !tbaa !23
  %t83 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t79, i32 %t80)
  store i32 %t83, ptr %l58
  br label %bb22
bb22:
  %t84 = load i32, ptr %l58, !tbaa !23
  store i32 %t84, ptr %l5, !tbaa !23
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t87 = icmp eq ptr %t85, null
  br i1 %t87, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_90bed28a447e5726_404cd49f4fb329c2)
  unreachable
bb24:
  br label %bb25
bb25:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t92 = getelementptr %"compiler/check:Checker", ptr %t89, i32 0, i32 19
  store ptr %t92, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb26
bb26:
  %t94 = load i64, ptr %l7, !tbaa !24
  store i64 %t94, ptr %l64, !tbaa !24
  %t95 = load ptr, ptr %l6, !tbaa !29
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t95)
  store i64 %t97, ptr %l66
  br label %bb27
bb27:
  %t98 = load i64, ptr %l64, !tbaa !24
  %t99 = load i64, ptr %l66, !tbaa !24
  %t100 = icmp slt i64 %t98, %t99
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb28, label %bb29
bb28:
  br label %bb98
bb29:
  br label %bb30
bb30:
  %t104 = load ptr, ptr %l6, !tbaa !29
  %t105 = load i64, ptr %l7, !tbaa !24
  %t108 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t104, i64 %t105)
  store ptr %t108, ptr %l71
  br label %bb31
bb31:
  %t109 = load ptr, ptr %l71, !tbaa !29
  store ptr %t109, ptr %l8, !tbaa !29
  %t110 = load ptr, ptr %l8, !tbaa !29
  %t112 = getelementptr %"compiler/typed:Body", ptr %t110, i32 0, i32 1
  %t113 = load { i64, [2 x i64] }, ptr %t112
  store { i64, [2 x i64] } %t113, ptr %l9
  %t115 = load { i64, [2 x i64] }, ptr %l9
  %t117 = extractvalue { i64, [2 x i64] } %t115, 0
  %t118 = icmp eq i64 %t117, 1
  br i1 %t118, label %bb32, label %bb33
bb32:
  %t120 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t121 = getelementptr { i32, i32 }, ptr %t120, i32 0, i32 0
  %t122 = load i32, ptr %t121
  store i32 %t122, ptr %l10, !tbaa !23
  br label %bb34
bb33:
  br label %bb91
bb34:
  store %olang.scope zeroinitializer, ptr %s4
  %t124 = load ptr, ptr %l3, !tbaa !29
  %t126 = icmp eq ptr %t124, null
  br i1 %t126, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_966fb838f56733ab_5416c5dd2a23270f)
  unreachable
bb36:
  br label %bb37
bb37:
  %t128 = load ptr, ptr %l3, !tbaa !29
  %t131 = getelementptr %"compiler/check:Checker", ptr %t128, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !29
  %t134 = getelementptr %"compiler/generic:Program", ptr %t132, i32 0, i32 2
  %t135 = load i32, ptr %l10, !tbaa !23
  %t138 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t134, i32 %t135)
  store i32 %t138, ptr %l84
  br label %bb38
bb38:
  %t139 = load i32, ptr %l84, !range !{i32 0, i32 33}
  %t141 = trunc i64 18 to i32
  %t142 = icmp eq i32 %t139, %t141
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb39, label %bb40
bb39:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb45
bb40:
  %t146 = load ptr, ptr %l3, !tbaa !29
  %t148 = icmp eq ptr %t146, null
  br i1 %t148, label %bb41, label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_966fb838f56733ab_5416c5dd2a23270f)
  unreachable
bb42:
  br label %bb43
bb43:
  %t150 = load ptr, ptr %l3, !tbaa !29
  %t153 = getelementptr %"compiler/check:Checker", ptr %t150, i32 0, i32 1
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/generic:Program", ptr %t154, i32 0, i32 2
  %t157 = load i32, ptr %l10, !tbaa !23
  %t160 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t156, i32 %t157)
  store i32 %t160, ptr %l96
  br label %bb44
bb44:
  %t161 = load i32, ptr %l5, !tbaa !23
  %t162 = load i32, ptr %l96, !tbaa !23
  %t164 = icmp ne i32 %t162, %t161
  store i1 %t164, ptr %l88, !tbaa !21
  br label %bb45
bb45:
  %t166 = load i1, ptr %l88, !tbaa !21
  br i1 %t166, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb49
bb47:
  %t167 = load i64, ptr %l2, !tbaa !24
  store i64 %t167, ptr %l100, !tbaa !24
  %t168 = load ptr, ptr %l8, !tbaa !29
  %t170 = getelementptr %"compiler/typed:Body", ptr %t168, i32 0, i32 10
  %t172 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t170)
  store i64 %t172, ptr %l103
  br label %bb48
bb48:
  %t173 = load i64, ptr %l100, !tbaa !24
  %t174 = load i64, ptr %l103, !tbaa !24
  %t175 = icmp sge i64 %t173, %t174
  store i1 %t175, ptr %l99, !tbaa !21
  br label %bb49
bb49:
  %t177 = load i1, ptr %l99, !tbaa !21
  br i1 %t177, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s4)
  br label %bb97
bb51:
  br label %bb52
bb52:
  %t178 = load ptr, ptr %l8, !tbaa !29
  %t180 = getelementptr %"compiler/typed:Body", ptr %t178, i32 0, i32 7
  store ptr %t180, ptr %l106, !tbaa !29
  %t181 = load ptr, ptr %l8, !tbaa !29
  %t183 = getelementptr %"compiler/typed:Body", ptr %t181, i32 0, i32 10
  %t184 = load i64, ptr %l2, !tbaa !24
  %t187 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t183, i64 %t184)
  store i32 %t187, ptr %l110
  br label %bb53
bb53:
  %t188 = load i32, ptr %l110, !tbaa !23
  %t189 = sext i32 %t188 to i64
  %t190 = load ptr, ptr %l106, !tbaa !29
  %t192 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t190, i64 %t189)
  store %"compiler/typed:Local" %t192, ptr %l112
  br label %bb54
bb54:
  %t193 = load %"compiler/typed:Local", ptr %l112
  store %"compiler/typed:Local" %t193, ptr %l11
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l8, !tbaa !29
  %t197 = getelementptr %"compiler/typed:Body", ptr %t195, i32 0, i32 3
  %t198 = load i64, ptr %t197, !tbaa !24
  %t201 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %t194, i64 %t198)
  store i64 %t201, ptr %l116
  br label %bb55
bb55:
  %t202 = load i64, ptr %l116, !tbaa !24
  store i64 %t202, ptr %l12, !tbaa !24
  %t203 = load i64, ptr %l12, !tbaa !24
  %t205 = icmp slt i64 %t203, 0
  br i1 %t205, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s4)
  %t208 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:memberInfo" } %t208, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t210 = load i64, ptr %l12, !tbaa !24
  %t213 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store { i64, ptr } %t213, ptr %l122
  br label %bb59
bb59:
  %t214 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t214, ptr %l13, !tbaa !27
  %t215 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t216 = load i32, ptr %t215, !tbaa !23
  %t218 = icmp eq i32 %t216, 0
  br i1 %t218, label %bb60, label %bb61
bb60:
  %t220 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t220, ptr %l126, !tbaa !27
  %t221 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t222 = getelementptr %"compiler/source:Span", ptr %t221, i32 0, i32 0
  %t223 = load i32, ptr %t222, !tbaa !23
  %t225 = sext i32 %t223 to i64
  store i64 %t225, ptr %l128, !tbaa !24
  %t226 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t227 = getelementptr %"compiler/source:Span", ptr %t226, i32 0, i32 1
  %t228 = load i32, ptr %t227, !tbaa !23
  %t230 = sext i32 %t228 to i64
  store i64 %t230, ptr %l130, !tbaa !24
  %t231 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  store i64 %t232, ptr %l131, !tbaa !24
  %t233 = load i64, ptr %l128, !tbaa !24
  %t234 = icmp sge i64 %t233, 0
  br i1 %t234, label %bb62, label %bb63
bb61:
  %t236 = load ptr, ptr %l3, !tbaa !29
  %t238 = icmp eq ptr %t236, null
  br i1 %t238, label %bb68, label %bb69
bb62:
  %t240 = load i64, ptr %l128, !tbaa !24
  %t241 = load i64, ptr %l130, !tbaa !24
  %t242 = icmp sle i64 %t240, %t241
  br i1 %t242, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb64:
  %t244 = load i64, ptr %l130, !tbaa !24
  %t245 = load i64, ptr %l131, !tbaa !24
  %t246 = icmp sle i64 %t244, %t245
  br i1 %t246, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb66:
  %t248 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t249 = load ptr, ptr %t248, !tbaa !27
  %t250 = load i64, ptr %l128, !tbaa !24
  %t251 = load i64, ptr %l130, !tbaa !24
  %t252 = getelementptr i8, ptr %t249, i64 %t250
  %t253 = sub i64 %t251, %t250
  %t254 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t252, 1
  %t257 = extractvalue { i64, ptr } %t255, 1
  %t258 = extractvalue { i64, ptr } %t255, 0
  %t259 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t258)
  call void @olang_textcopy(ptr %t259, ptr %t257, i64 %t258)
  %t260 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  store { i64, ptr } %t261, ptr %l125, !tbaa !27
  br label %bb72
bb67:
  call void @__olang_check_failed(ptr @olang_loc_55b3f811cb7477b4_5dfc53d9875946d8)
  unreachable
bb68:
  call void @__olang_check_failed(ptr @olang_loc_4c52bbc768601131_90801d9bf2a41585)
  unreachable
bb69:
  br label %bb70
bb70:
  %t263 = load ptr, ptr %l3, !tbaa !29
  %t266 = getelementptr %"compiler/check:Checker", ptr %t263, i32 0, i32 1
  %t267 = load ptr, ptr %t266, !tbaa !29
  %t269 = getelementptr %"compiler/generic:Program", ptr %t267, i32 0, i32 0
  %t270 = load ptr, ptr %t269, !tbaa !29
  %t272 = getelementptr %"compiler/load:Loader", ptr %t270, i32 0, i32 3
  %t273 = load ptr, ptr %t272, !tbaa !29
  %t274 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 0
  %t275 = load i32, ptr %t274, !tbaa !23
  %t278 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s4, ptr %t273, i32 %t275)
  store { i64, ptr } %t278, ptr %l145
  br label %bb71
bb71:
  %t279 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t281)
  call void @olang_textcopy(ptr %t282, ptr %t280, i64 %t281)
  %t283 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  store { i64, ptr } %t284, ptr %l125, !tbaa !27
  br label %bb72
bb72:
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t286, ptr %lp14
  %t287 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t288 = load ptr, ptr %lp14
  store { i64, ptr } %t287, ptr %t288, !tbaa !27
  %t289 = load ptr, ptr %l3, !tbaa !29
  %t291 = icmp eq ptr %t289, null
  br i1 %t291, label %bb73, label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_42ed37d296a6252a_791781e06ef43dde)
  unreachable
bb74:
  br label %bb75
bb75:
  %t293 = load ptr, ptr %l3, !tbaa !29
  %t296 = getelementptr %"compiler/check:Checker", ptr %t293, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/generic:Program", ptr %t297, i32 0, i32 2
  store ptr %t299, ptr %l152, !tbaa !29
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t302 = icmp eq ptr %t300, null
  br i1 %t302, label %bb76, label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_42ed37d296a6252a_791781e06ef43dde)
  unreachable
bb77:
  br label %bb78
bb78:
  %t304 = load ptr, ptr %l3, !tbaa !29
  %t307 = getelementptr %"compiler/check:Checker", ptr %t304, i32 0, i32 1
  %t308 = load ptr, ptr %t307, !tbaa !29
  %t310 = getelementptr %"compiler/generic:Program", ptr %t308, i32 0, i32 2
  %t311 = load i32, ptr %l4, !tbaa !23
  %t314 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t310, i32 %t311)
  store i32 %t314, ptr %l160
  br label %bb79
bb79:
  %t315 = load ptr, ptr %l152, !tbaa !29
  %t316 = load i32, ptr %l160, !tbaa !23
  %t317 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t315, i32 %t316)
  store { i64, ptr } %t317, ptr %l161
  br label %bb80
bb80:
  %t318 = load { i64, ptr }, ptr %l161, !tbaa !27
  store { i64, ptr } %t318, ptr %l15, !tbaa !27
  %t319 = load i64, ptr %l2, !tbaa !24
  %t320 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t325 = icmp slt i64 %t319, %t322
  br i1 %t325, label %bb81, label %bb82
bb81:
  %t327 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t327, ptr %l167, !tbaa !27
  %t328 = load i64, ptr %l2, !tbaa !24
  %t330 = getelementptr { i64, ptr }, ptr %l167, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr i32, ptr %t331, i64 %t328
  %t333 = load i32, ptr %t332, !tbaa !33
  store i32 %t333, ptr %l166, !tbaa !23
  br label %bb83
bb82:
  %t335 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 2
  %t336 = load i32, ptr %t335, !tbaa !23
  store i32 %t336, ptr %l166, !tbaa !23
  br label %bb83
bb83:
  %t338 = load i32, ptr %l166, !tbaa !23
  %t339 = load ptr, ptr %lp14
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  store { i64, ptr } %t340, ptr %l171, !tbaa !27
  store i32 %t338, ptr %l172, !tbaa !23
  %t342 = call ptr @__olang_scope_hold(ptr %v1)
  %t343 = ptrtoint ptr %t342 to i64
  store i64 %t343, ptr %l173, !tbaa !24
  %t344 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3amemberInfo_2e2
  br i1 %t344, label %bb84, label %bb85
bb84:
  %t346 = call ptr @__olang_region_make(ptr %v1)
  %t347 = ptrtoint ptr %t346 to i64
  store i64 %t347, ptr %l173, !tbaa !24
  br label %bb85
bb85:
  %t348 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t349 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t350 = getelementptr %"compiler/source:Span", ptr %t349, i32 0, i32 0
  %t351 = load i32, ptr %t350, !tbaa !23
  %t353 = sext i32 %t351 to i64
  %t354 = load i64, ptr %l173
  %t355 = inttoptr i64 %t354 to ptr
  %t358 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %t355, { i64, ptr } %t348, i64 %t353, i1 true)
  store { i64, ptr } %t358, ptr %l178
  br label %bb86
bb86:
  %t359 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t360 = load i64, ptr %l173
  %t361 = inttoptr i64 %t360 to ptr
  %t362 = extractvalue { i64, ptr } %t359, 0
  %t363 = extractvalue { i64, ptr } %t359, 1
  %t364 = mul i64 %t362, 1
  %t365 = call ptr @__olang_held_alloc(ptr %t361, i64 %t364)
  call void @llvm.memcpy.p0.p0.i64(ptr %t365, ptr %t363, i64 %t364, i1 false)
  %t366 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t367 = insertvalue { i64, ptr } %t366, ptr %t365, 1
  store { i64, ptr } %t367, ptr %l179, !tbaa !27
  %t368 = call ptr @__olang_scope_hold(ptr %v1)
  %t369 = ptrtoint ptr %t368 to i64
  store i64 %t369, ptr %l180, !tbaa !24
  %t370 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3amemberInfo_2e3
  br i1 %t370, label %bb87, label %bb88
bb87:
  %t372 = call ptr @__olang_region_make(ptr %v1)
  %t373 = ptrtoint ptr %t372 to i64
  store i64 %t373, ptr %l180, !tbaa !24
  br label %bb88
bb88:
  %t374 = load ptr, ptr %l0, !tbaa !29
  %t376 = getelementptr %"compiler/session:Analysis", ptr %t374, i32 0, i32 0
  %t377 = load ptr, ptr %t376, !tbaa !29
  %t379 = getelementptr %"compiler/load:Loader", ptr %t377, i32 0, i32 10
  %t380 = load i64, ptr %l12, !tbaa !24
  %t383 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t379, i64 %t380)
  store ptr %t383, ptr %l186
  br label %bb89
bb89:
  %t384 = load ptr, ptr %l186, !tbaa !29
  %t386 = getelementptr %"compiler/load:Module", ptr %t384, i32 0, i32 1
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !27
  %t389 = extractvalue { i64, ptr } %t387, 1
  %t390 = extractvalue { i64, ptr } %t387, 0
  %t391 = load i64, ptr %l180
  %t392 = inttoptr i64 %t391 to ptr
  %t393 = call ptr @__olang_held_alloc(ptr %t392, i64 %t390)
  call void @olang_textcopy(ptr %t393, ptr %t389, i64 %t390)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t397 = getelementptr %"compiler/typed:Local", ptr %l11, i32 0, i32 1
  %t398 = getelementptr %"compiler/source:Span", ptr %t397, i32 0, i32 0
  %t399 = load i32, ptr %t398, !tbaa !23
  %t401 = sext i32 %t399 to i64
  %t402 = load { i64, ptr }, ptr %l171, !tbaa !27
  %t403 = load i32, ptr %l172, !tbaa !23
  %t404 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t407 = call %"compiler/session:memberInfo" @compiler_2fsession_3amemberInfo_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t402, i32 %t403, { i64, ptr } %t404, { i64, ptr } %t395, i64 %t401)
  store %"compiler/session:memberInfo" %t407, ptr %l193
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s4)
  %t408 = load %"compiler/session:memberInfo", ptr %l193
  %t409 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, %"compiler/session:memberInfo" %t408, 1
  store { i32, %"compiler/session:memberInfo" } %t409, ptr %rv
  br label %ret
bb91:
  br i1 true, label %bb92, label %bb93
bb92:
  br label %bb94
bb93:
  br label %bb95
bb94:
  br label %bb96
bb95:
  call void @__olang_check_failed(ptr @olang_loc_dff094d230471566_615c91b3ab3b0902)
  unreachable
bb96:
  br label %bb97
bb97:
  %t410 = load i64, ptr %l7, !tbaa !24
  %t413 = add i64 %t410, 1
  store i64 %t413, ptr %l7, !tbaa !24
  br label %bb26
bb98:
  %t416 = insertvalue { i32, %"compiler/session:memberInfo" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/session:memberInfo" } %t416, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/session:memberInfo" }, ptr %rv
  ret { i32, %"compiler/session:memberInfo" } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efieldMembers(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca { i64, [2 x i64] }
  %l10 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"compiler/typed:Local"
  %l25 = alloca { i64, ptr }
  %l35 = alloca i32
  %l41 = alloca i64
  %l43 = alloca i64
  %l48 = alloca ptr
  %l54 = alloca i1
  %l64 = alloca i32
  %l68 = alloca i1
  %l78 = alloca i32
  %l86 = alloca i64
  %l92 = alloca ptr
  %l100 = alloca i32
  %l101 = alloca { i64, ptr }
  %l104 = alloca i64
  %l108 = alloca i64
  %l111 = alloca i64
  %l130 = alloca ptr
  %l134 = alloca i32
  %l136 = alloca %"compiler/typed:Local"
  %l139 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l148 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i64
  %l164 = alloca { i64, ptr }
  %l168 = alloca i1
  %l169 = alloca { i64, ptr }
  %l171 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l175 = alloca i64
  %l178 = alloca ptr
  %l183 = alloca i32
  %l184 = alloca { i64, ptr }
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l194 = alloca i1
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_93ae806d7d0351b8_8e59b8ae3d0673ac)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l35
  br label %bb4
bb4:
  %t21 = load i32, ptr %l35, !tbaa !23
  store i32 %t21, ptr %l5, !tbaa !23
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb5, label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_9641f0facc09fdd7_c62ff0c79521a99b)
  unreachable
bb6:
  br label %bb7
bb7:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 19
  store ptr %t29, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  %t31 = load i64, ptr %l7, !tbaa !24
  store i64 %t31, ptr %l41, !tbaa !24
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l43
  br label %bb9
bb9:
  %t35 = load i64, ptr %l41, !tbaa !24
  %t36 = load i64, ptr %l43, !tbaa !24
  %t37 = icmp slt i64 %t35, %t36
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb86
bb11:
  br label %bb12
bb12:
  %t41 = load ptr, ptr %l6, !tbaa !29
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store ptr %t45, ptr %l48
  br label %bb13
bb13:
  %t46 = load ptr, ptr %l48, !tbaa !29
  store ptr %t46, ptr %l8, !tbaa !29
  %t47 = load ptr, ptr %l8, !tbaa !29
  %t49 = getelementptr %"compiler/typed:Body", ptr %t47, i32 0, i32 1
  %t50 = load { i64, [2 x i64] }, ptr %t49
  store { i64, [2 x i64] } %t50, ptr %l9
  %t52 = load { i64, [2 x i64] }, ptr %l9
  %t54 = extractvalue { i64, [2 x i64] } %t52, 0
  %t55 = icmp eq i64 %t54, 1
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l54, !tbaa !21
  br label %bb20
bb15:
  %t59 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t60 = getelementptr { i32, i32 }, ptr %t59, i32 0, i32 0
  %t61 = load i32, ptr %t60
  store i32 %t61, ptr %l10, !tbaa !23
  %t63 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t64 = getelementptr { i32, i32 }, ptr %t63, i32 0, i32 1
  %t65 = load i32, ptr %t64
  store i32 %t65, ptr %l11, !tbaa !23
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb16, label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_c5788a2fa1963e6_4f790674132263da)
  unreachable
bb17:
  br label %bb18
bb18:
  %t71 = load ptr, ptr %l4, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  %t78 = load i32, ptr %l10, !tbaa !23
  %t81 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t77, i32 %t78)
  store i32 %t81, ptr %l64
  br label %bb19
bb19:
  %t82 = load i32, ptr %l64, !range !{i32 0, i32 33}
  %t84 = trunc i64 18 to i32
  %t85 = icmp eq i32 %t82, %t84
  %t87 = xor i1 %t85, true
  store i1 %t87, ptr %l54, !tbaa !21
  br label %bb20
bb20:
  %t89 = load i1, ptr %l54, !tbaa !21
  br i1 %t89, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb27
bb22:
  %t90 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t91 = getelementptr { i32, i32 }, ptr %t90, i32 0, i32 0
  %t92 = load i32, ptr %t91
  store i32 %t92, ptr %l12, !tbaa !23
  %t94 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t95 = getelementptr { i32, i32 }, ptr %t94, i32 0, i32 1
  %t96 = load i32, ptr %t95
  store i32 %t96, ptr %l13, !tbaa !23
  %t98 = load ptr, ptr %l4, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  br i1 %t100, label %bb23, label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_c5788a2fa1963e6_4f790674132263da)
  unreachable
bb24:
  br label %bb25
bb25:
  %t102 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/check:Checker", ptr %t102, i32 0, i32 1
  %t106 = load ptr, ptr %t105, !tbaa !29
  %t108 = getelementptr %"compiler/generic:Program", ptr %t106, i32 0, i32 2
  %t109 = load i32, ptr %l12, !tbaa !23
  %t112 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t108, i32 %t109)
  store i32 %t112, ptr %l78
  br label %bb26
bb26:
  %t113 = load i32, ptr %l5, !tbaa !23
  %t114 = load i32, ptr %l78, !tbaa !23
  %t116 = icmp ne i32 %t114, %t113
  store i1 %t116, ptr %l68, !tbaa !21
  br label %bb27
bb27:
  %t118 = load i1, ptr %l68, !tbaa !21
  br i1 %t118, label %bb28, label %bb29
bb28:
  br label %bb85
bb29:
  br label %bb30
bb30:
  %t119 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t120 = getelementptr { i32, i32 }, ptr %t119, i32 0, i32 0
  %t121 = load i32, ptr %t120
  store i32 %t121, ptr %l14, !tbaa !23
  %t123 = getelementptr { i64, [2 x i64] }, ptr %l9, i32 0, i32 1
  %t124 = getelementptr { i32, i32 }, ptr %t123, i32 0, i32 1
  %t125 = load i32, ptr %t124
  store i32 %t125, ptr %l15, !tbaa !23
  %t127 = load ptr, ptr %l0, !tbaa !29
  %t128 = load ptr, ptr %l8, !tbaa !29
  %t130 = getelementptr %"compiler/typed:Body", ptr %t128, i32 0, i32 3
  %t131 = load i64, ptr %t130, !tbaa !24
  %t134 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %t127, i64 %t131)
  store i64 %t134, ptr %l86
  br label %bb31
bb31:
  %t135 = load i64, ptr %l86, !tbaa !24
  store i64 %t135, ptr %l16, !tbaa !24
  %t136 = load ptr, ptr %l4, !tbaa !29
  %t138 = icmp eq ptr %t136, null
  br i1 %t138, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_c84a3880e9ad3dcd_a55c78b5e4758561)
  unreachable
bb33:
  br label %bb34
bb34:
  %t140 = load ptr, ptr %l4, !tbaa !29
  %t143 = getelementptr %"compiler/check:Checker", ptr %t140, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !29
  %t146 = getelementptr %"compiler/generic:Program", ptr %t144, i32 0, i32 2
  store ptr %t146, ptr %l92, !tbaa !29
  %t147 = load ptr, ptr %l4, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_c84a3880e9ad3dcd_a55c78b5e4758561)
  unreachable
bb36:
  br label %bb37
bb37:
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 2
  %t158 = load i32, ptr %l2, !tbaa !23
  %t161 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t157, i32 %t158)
  store i32 %t161, ptr %l100
  br label %bb38
bb38:
  %t162 = load ptr, ptr %l92, !tbaa !29
  %t163 = load i32, ptr %l100, !tbaa !23
  %t164 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t162, i32 %t163)
  store { i64, ptr } %t164, ptr %l101
  br label %bb39
bb39:
  %t165 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t165, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t166 = load ptr, ptr %l8, !tbaa !29
  %t168 = getelementptr %"compiler/typed:Body", ptr %t166, i32 0, i32 10
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t168)
  store i64 %t170, ptr %l104
  br label %bb40
bb40:
  %t171 = load i64, ptr %l104, !tbaa !24
  store i64 %t171, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t172 = load i64, ptr %l19, !tbaa !24
  %t173 = load i64, ptr %l18, !tbaa !24
  %t176 = icmp sgt i64 %t172, %t173
  br i1 %t176, label %bb41, label %bb42
bb41:
  %t178 = load i64, ptr %l20, !tbaa !24
  %t180 = icmp sgt i64 %t178, 0
  br i1 %t180, label %bb43, label %bb44
bb42:
  store i64 0, ptr %l108, !tbaa !24
  br label %bb46
bb43:
  %t182 = load i64, ptr %l19, !tbaa !24
  %t183 = load i64, ptr %l18, !tbaa !24
  %t186 = sub i64 %t182, %t183
  %t187 = load i64, ptr %l20, !tbaa !24
  %t190 = add i64 %t186, %t187
  %t192 = sub i64 %t190, 1
  %t193 = load i64, ptr %l20, !tbaa !24
  %t196 = sdiv i64 %t192, %t193
  store i64 %t196, ptr %l111, !tbaa !24
  br label %bb45
bb44:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb45
bb45:
  %t198 = load i64, ptr %l111, !tbaa !24
  store i64 %t198, ptr %l108, !tbaa !24
  br label %bb46
bb46:
  %t199 = load i64, ptr %l108, !tbaa !24
  store i64 %t199, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s5
  %t200 = load i64, ptr %l22, !tbaa !24
  %t201 = load i64, ptr %l21, !tbaa !24
  %t204 = icmp slt i64 %t200, %t201
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb48, label %bb49
bb48:
  call void @__olang_scope_close(ptr %s5)
  br label %bb84
bb49:
  br label %bb50
bb50:
  %t208 = load i64, ptr %l18, !tbaa !24
  %t209 = load i64, ptr %l22, !tbaa !24
  %t210 = load i64, ptr %l20, !tbaa !24
  %t213 = mul i64 %t209, %t210
  %t216 = add i64 %t208, %t213
  store i64 %t216, ptr %l23, !tbaa !24
  %t218 = load ptr, ptr %l8, !tbaa !29
  %t220 = getelementptr %"compiler/typed:Body", ptr %t218, i32 0, i32 7
  store ptr %t220, ptr %l130, !tbaa !29
  %t221 = load ptr, ptr %l8, !tbaa !29
  %t223 = getelementptr %"compiler/typed:Body", ptr %t221, i32 0, i32 10
  %t224 = load i64, ptr %l23, !tbaa !24
  %t227 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %t223, i64 %t224)
  store i32 %t227, ptr %l134
  br label %bb51
bb51:
  %t228 = load i32, ptr %l134, !tbaa !23
  %t229 = sext i32 %t228 to i64
  %t230 = load ptr, ptr %l130, !tbaa !29
  %t232 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t230, i64 %t229)
  store %"compiler/typed:Local" %t232, ptr %l136
  br label %bb52
bb52:
  %t233 = load %"compiler/typed:Local", ptr %l136
  store %"compiler/typed:Local" %t233, ptr %l24
  %t234 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 0
  %t235 = load i32, ptr %t234, !tbaa !23
  %t237 = icmp eq i32 %t235, 0
  br i1 %t237, label %bb53, label %bb54
bb53:
  %t239 = load ptr, ptr %l0, !tbaa !29
  %t241 = getelementptr %"compiler/session:Analysis", ptr %t239, i32 0, i32 0
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = getelementptr %"compiler/load:Loader", ptr %t242, i32 0, i32 4
  %t245 = load ptr, ptr %t244, !tbaa !29
  %t246 = load ptr, ptr %l8, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Body", ptr %t246, i32 0, i32 3
  %t249 = load i64, ptr %t248, !tbaa !24
  %t252 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t245, i64 %t249)
  store { i64, ptr } %t252, ptr %l145
  br label %bb55
bb54:
  %t253 = load ptr, ptr %l4, !tbaa !29
  %t255 = icmp eq ptr %t253, null
  br i1 %t255, label %bb62, label %bb63
bb55:
  %t257 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t257, ptr %l146, !tbaa !27
  %t258 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 1
  %t259 = getelementptr %"compiler/source:Span", ptr %t258, i32 0, i32 0
  %t260 = load i32, ptr %t259, !tbaa !23
  %t262 = sext i32 %t260 to i64
  store i64 %t262, ptr %l148, !tbaa !24
  %t263 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 1
  %t264 = getelementptr %"compiler/source:Span", ptr %t263, i32 0, i32 1
  %t265 = load i32, ptr %t264, !tbaa !23
  %t267 = sext i32 %t265 to i64
  store i64 %t267, ptr %l150, !tbaa !24
  %t268 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  store i64 %t269, ptr %l151, !tbaa !24
  %t270 = load i64, ptr %l148, !tbaa !24
  %t271 = icmp sge i64 %t270, 0
  br i1 %t271, label %bb56, label %bb57
bb56:
  %t273 = load i64, ptr %l148, !tbaa !24
  %t274 = load i64, ptr %l150, !tbaa !24
  %t275 = icmp sle i64 %t273, %t274
  br i1 %t275, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_ba93316a311e09f4_9951ae939e9d3a90)
  unreachable
bb58:
  %t277 = load i64, ptr %l150, !tbaa !24
  %t278 = load i64, ptr %l151, !tbaa !24
  %t279 = icmp sle i64 %t277, %t278
  br i1 %t279, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @olang_loc_ba93316a311e09f4_9951ae939e9d3a90)
  unreachable
bb60:
  %t281 = getelementptr { i64, ptr }, ptr %l146, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = load i64, ptr %l148, !tbaa !24
  %t284 = load i64, ptr %l150, !tbaa !24
  %t285 = getelementptr i8, ptr %t282, i64 %t283
  %t286 = sub i64 %t284, %t283
  %t287 = insertvalue { i64, ptr } undef, i64 %t286, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t285, 1
  store { i64, ptr } %t288, ptr %l139, !tbaa !27
  br label %bb66
bb61:
  call void @__olang_check_failed(ptr @olang_loc_ba93316a311e09f4_9951ae939e9d3a90)
  unreachable
bb62:
  call void @__olang_check_failed(ptr @olang_loc_655ed1db7681c96b_c757f347e4ac2c7)
  unreachable
bb63:
  br label %bb64
bb64:
  %t290 = load ptr, ptr %l4, !tbaa !29
  %t293 = getelementptr %"compiler/check:Checker", ptr %t290, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !29
  %t296 = getelementptr %"compiler/generic:Program", ptr %t294, i32 0, i32 0
  %t297 = load ptr, ptr %t296, !tbaa !29
  %t299 = getelementptr %"compiler/load:Loader", ptr %t297, i32 0, i32 3
  %t300 = load ptr, ptr %t299, !tbaa !29
  %t301 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 0
  %t302 = load i32, ptr %t301, !tbaa !23
  %t305 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %t300, i32 %t302)
  store { i64, ptr } %t305, ptr %l164
  br label %bb65
bb65:
  %t306 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t306, ptr %l139, !tbaa !27
  br label %bb66
bb66:
  %t307 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t307, ptr %l25, !tbaa !27
  %t308 = load i64, ptr %l16, !tbaa !24
  %t312 = icmp ne i64 %t308, %a3
  br i1 %t312, label %bb67, label %bb68
bb67:
  %t314 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t314, ptr %l169, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t315, 1
  %t317 = call ptr @__olang_scope_of(ptr %t316, ptr null)
  %t318 = call ptr @__olang_scope_hold(ptr %t317)
  %t319 = ptrtoint ptr %t318 to i64
  %t321 = inttoptr i64 %t319 to ptr
  %t322 = load { i64, ptr }, ptr %l169, !tbaa !27
  %t323 = call i1 @compiler_2fdoc_2eExported(ptr %t321, { i64, ptr } %t322)
  store i1 %t323, ptr %l171
  br label %bb69
bb68:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb70
bb69:
  %t324 = load i1, ptr %l171, !tbaa !21
  %t325 = xor i1 %t324, true
  store i1 %t325, ptr %l168, !tbaa !21
  br label %bb70
bb70:
  %t327 = load i1, ptr %l168, !tbaa !21
  br i1 %t327, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s5)
  br label %bb83
bb72:
  br label %bb73
bb73:
  store ptr %a1, ptr %l173, !tbaa !29
  %t329 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t329, ptr %l174, !tbaa !27
  %t330 = load i64, ptr @G_2ecompiler_2fsession_2eCompField, !tbaa !24
  store i64 %t330, ptr %l175, !tbaa !24
  %t331 = load ptr, ptr %l4, !tbaa !29
  %t333 = icmp eq ptr %t331, null
  br i1 %t333, label %bb74, label %bb75
bb74:
  call void @__olang_check_failed(ptr @olang_loc_284eaf45fbe9e9ea_494071f23c61296)
  unreachable
bb75:
  br label %bb76
bb76:
  %t335 = load ptr, ptr %l4, !tbaa !29
  store ptr %t335, ptr %l178, !tbaa !29
  %t336 = load i64, ptr %l23, !tbaa !24
  %t337 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t342 = icmp slt i64 %t336, %t339
  br i1 %t342, label %bb77, label %bb78
bb77:
  %t344 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t344, ptr %l184, !tbaa !27
  %t345 = load i64, ptr %l23, !tbaa !24
  %t347 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr i32, ptr %t348, i64 %t345
  %t350 = load i32, ptr %t349, !tbaa !33
  store i32 %t350, ptr %l183, !tbaa !23
  br label %bb79
bb78:
  %t352 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 2
  %t353 = load i32, ptr %t352, !tbaa !23
  store i32 %t353, ptr %l183, !tbaa !23
  br label %bb79
bb79:
  %t355 = load ptr, ptr %l178, !tbaa !29
  %t356 = load i32, ptr %l183, !tbaa !23
  %t357 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t355, i32 %t356)
  store { i64, ptr } %t357, ptr %l188
  br label %bb80
bb80:
  %t358 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t358, ptr %l189, !tbaa !27
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t360 = load i64, ptr %l16, !tbaa !24
  %t361 = getelementptr %"compiler/typed:Local", ptr %l24, i32 0, i32 1
  %t362 = getelementptr %"compiler/source:Span", ptr %t361, i32 0, i32 0
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t369 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edeprecatedAt(ptr %v0, ptr %t359, i64 %t360, i64 %t365, i1 true)
  store i1 %t369, ptr %l194
  br label %bb81
bb81:
  %t370 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = call ptr @__olang_scope_of(ptr %t371, ptr null)
  %t373 = call ptr @__olang_scope_hold(ptr %t372)
  %t374 = ptrtoint ptr %t373 to i64
  %t376 = inttoptr i64 %t374 to ptr
  %t377 = load ptr, ptr %l173, !tbaa !29
  %t378 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t379 = load i64, ptr %l175, !tbaa !24
  %t380 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t381 = load i1, ptr %l194, !tbaa !21
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAddDep(ptr %v1, ptr %t376, ptr %s5, ptr %t377, { i64, ptr } %t378, i64 %t379, { i64, ptr } %t380, i1 %t381)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s5)
  br label %bb83
bb83:
  %t382 = load i64, ptr %l22, !tbaa !24
  %t385 = add i64 %t382, 1
  store i64 %t385, ptr %l22, !tbaa !24
  br label %bb47
bb84:
  br label %ret
bb85:
  %t387 = load i64, ptr %l7, !tbaa !24
  %t390 = add i64 %t387, 1
  store i64 %t390, ptr %l7, !tbaa !24
  br label %bb8
bb86:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efieldType(ptr %v0, ptr %v1, ptr %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l26 = alloca i32
  %l29 = alloca i32
  %l37 = alloca i32
  %l45 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l59 = alloca i32
  %l60 = alloca { i64, ptr }
  %l66 = alloca i64
  %l69 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca i1
  %l99 = alloca i1
  %l104 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l1, !tbaa !23
  %t2 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t5 = icmp eq i32 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i32, ptr %l1, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t7, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t11 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 2
  %t12 = load ptr, ptr %t11, !tbaa !29
  store ptr %t12, ptr %l3, !tbaa !29
  %t14 = load ptr, ptr %l3, !tbaa !29
  %t16 = icmp eq ptr %t14, null
  br i1 %t16, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_989a7bf68c7dc1d7_25d5471cbaf803d3)
  unreachable
bb5:
  br label %bb6
bb6:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t21 = getelementptr %"compiler/check:Checker", ptr %t18, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/generic:Program", ptr %t22, i32 0, i32 2
  %t25 = load i32, ptr %l1, !tbaa !23
  %t28 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t24, i32 %t25)
  store i32 %t28, ptr %l26
  br label %bb7
bb7:
  %t29 = load i32, ptr %l26, !range !{i32 0, i32 33}
  %t31 = trunc i64 20 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb8, label %bb9
bb8:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t36 = icmp eq ptr %t34, null
  br i1 %t36, label %bb10, label %bb11
bb9:
  %t38 = load i32, ptr %l1, !tbaa !23
  store i32 %t38, ptr %l29, !tbaa !23
  br label %bb14
bb10:
  call void @__olang_check_failed(ptr @olang_loc_989a7bf68c7dc1d7_25d5471cbaf803d3)
  unreachable
bb11:
  br label %bb12
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t43 = getelementptr %"compiler/check:Checker", ptr %t40, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !29
  %t46 = getelementptr %"compiler/generic:Program", ptr %t44, i32 0, i32 2
  %t47 = load i32, ptr %l1, !tbaa !23
  %t50 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t46, i32 %t47)
  store i32 %t50, ptr %l37
  br label %bb13
bb13:
  %t51 = load i32, ptr %l37, !tbaa !23
  store i32 %t51, ptr %l29, !tbaa !23
  br label %bb14
bb14:
  %t52 = load i32, ptr %l29, !tbaa !23
  store i32 %t52, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb15, label %bb16
bb15:
  call void @__olang_check_failed(ptr @olang_loc_96070b693d7715b8_3d59b06a8f6f9604)
  unreachable
bb16:
  br label %bb17
bb17:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t62 = load i32, ptr %l4, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %s0, ptr %t61, i32 %t62)
  store { i64, ptr } %t65, ptr %l45
  br label %bb18
bb18:
  %t66 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t66, ptr %l5, !tbaa !27
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  br i1 %t69, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_caa2c37caa2101cd_bb05ddde25bad6b9)
  unreachable
bb20:
  br label %bb21
bb21:
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t74 = getelementptr %"compiler/check:Checker", ptr %t71, i32 0, i32 1
  %t75 = load ptr, ptr %t74, !tbaa !29
  %t77 = getelementptr %"compiler/generic:Program", ptr %t75, i32 0, i32 2
  store ptr %t77, ptr %l51, !tbaa !29
  %t78 = load ptr, ptr %l3, !tbaa !29
  %t80 = icmp eq ptr %t78, null
  br i1 %t80, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_caa2c37caa2101cd_bb05ddde25bad6b9)
  unreachable
bb23:
  br label %bb24
bb24:
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t85 = getelementptr %"compiler/check:Checker", ptr %t82, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !29
  %t88 = getelementptr %"compiler/generic:Program", ptr %t86, i32 0, i32 2
  %t89 = load i32, ptr %l4, !tbaa !23
  %t92 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %t88, i32 %t89)
  store i32 %t92, ptr %l59
  br label %bb25
bb25:
  %t93 = load ptr, ptr %l51, !tbaa !29
  %t94 = load i32, ptr %l59, !tbaa !23
  %t95 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v0, ptr %t93, i32 %t94)
  store { i64, ptr } %t95, ptr %l60
  br label %bb26
bb26:
  %t96 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t96, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t97 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t97, 0
  store i64 %t99, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb29, label %bb30
bb28:
  store i64 0, ptr %l66, !tbaa !24
  br label %bb32
bb29:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l69, !tbaa !24
  br label %bb31
bb30:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb31
bb31:
  %t127 = load i64, ptr %l69, !tbaa !24
  store i64 %t127, ptr %l66, !tbaa !24
  br label %bb32
bb32:
  %t128 = load i64, ptr %l66, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s3
  %t129 = load i64, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s3)
  br label %bb49
bb35:
  br label %bb36
bb36:
  %t137 = load i64, ptr %l7, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l12, !tbaa !24
  %t147 = load ptr, ptr %l3, !tbaa !29
  %t149 = icmp eq ptr %t147, null
  br i1 %t149, label %bb37, label %bb38
bb37:
  call void @__olang_check_failed(ptr @olang_loc_eb0139eba8d27e6_5e0e324bb341d292)
  unreachable
bb38:
  br label %bb39
bb39:
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t154 = getelementptr %"compiler/check:Checker", ptr %t151, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !29
  %t157 = getelementptr %"compiler/generic:Program", ptr %t155, i32 0, i32 0
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/load:Loader", ptr %t158, i32 0, i32 3
  %t161 = load ptr, ptr %t160, !tbaa !29
  %t162 = load i64, ptr %l12, !tbaa !24
  %t164 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr i32, ptr %t165, i64 %t162
  %t167 = load i32, ptr %t166, !tbaa !33
  %t170 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t161, i32 %t167)
  store { i64, ptr } %t170, ptr %l96
  br label %bb40
bb40:
  %t172 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t174 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s3, ptr %v1, { i64, ptr } %t172, { i64, ptr } %a2)
  store i1 %t174, ptr %l98
  br label %bb41
bb41:
  %t175 = load i1, ptr %l98, !tbaa !21
  br i1 %t175, label %bb42, label %bb43
bb42:
  %t176 = load i64, ptr %l12, !tbaa !24
  %t177 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t182 = icmp slt i64 %t176, %t179
  store i1 %t182, ptr %l99, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l99, !tbaa !21
  br label %bb44
bb44:
  %t184 = load i1, ptr %l99, !tbaa !21
  br i1 %t184, label %bb45, label %bb46
bb45:
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t185, ptr %l104, !tbaa !27
  %t186 = load i64, ptr %l12, !tbaa !24
  %t188 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr i32, ptr %t189, i64 %t186
  %t191 = load i32, ptr %t190, !tbaa !33
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t191, ptr %rv
  br label %ret
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s3)
  br label %bb48
bb48:
  %t193 = load i64, ptr %l11, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l11, !tbaa !24
  br label %bb33
bb49:
  %t198 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t198, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/typed:Local"
  %l20 = alloca i64
  %l22 = alloca i64
  %l27 = alloca ptr
  %l34 = alloca i64
  %l38 = alloca i64
  %l41 = alloca i64
  %l62 = alloca %"compiler/typed:Local"
  %l65 = alloca i1
  %l76 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l83 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = icmp eq ptr %t4, null
  br i1 %t6, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_878a1a37f76dded1_df06407b9e0240ed)
  unreachable
bb2:
  br label %bb3
bb3:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/session:Analysis", ptr %t8, i32 0, i32 2
  %t11 = load ptr, ptr %t10, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t11, i32 0, i32 19
  store ptr %t14, ptr %l3, !tbaa !29
  store i64 0, ptr %l4, !tbaa !24
  br label %bb4
bb4:
  %t16 = load i64, ptr %l4, !tbaa !24
  store i64 %t16, ptr %l20, !tbaa !24
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t17)
  store i64 %t19, ptr %l22
  br label %bb5
bb5:
  %t20 = load i64, ptr %l20, !tbaa !24
  %t21 = load i64, ptr %l22, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  %t24 = xor i1 %t22, true
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb35
bb7:
  br label %bb8
bb8:
  %t26 = load ptr, ptr %l3, !tbaa !29
  %t27 = load i64, ptr %l4, !tbaa !24
  %t30 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t26, i64 %t27)
  store ptr %t30, ptr %l27
  br label %bb9
bb9:
  %t31 = load ptr, ptr %l27, !tbaa !29
  store ptr %t31, ptr %l5, !tbaa !29
  %t32 = load ptr, ptr %l5, !tbaa !29
  %t34 = getelementptr %"compiler/typed:Body", ptr %t32, i32 0, i32 3
  %t35 = load i64, ptr %t34, !tbaa !24
  %t39 = icmp ne i64 %t35, %a1
  br i1 %t39, label %bb10, label %bb11
bb10:
  br label %bb34
bb11:
  br label %bb12
bb12:
  store i64 0, ptr %l6, !tbaa !24
  %t41 = load ptr, ptr %l5, !tbaa !29
  %t43 = getelementptr %"compiler/typed:Body", ptr %t41, i32 0, i32 7
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l34
  br label %bb13
bb13:
  %t46 = load i64, ptr %l34, !tbaa !24
  store i64 %t46, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l7, !tbaa !24
  %t48 = load i64, ptr %l6, !tbaa !24
  %t51 = icmp sgt i64 %t47, %t48
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load i64, ptr %l8, !tbaa !24
  %t55 = icmp sgt i64 %t53, 0
  br i1 %t55, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l38, !tbaa !24
  br label %bb19
bb16:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = sub i64 %t57, %t58
  %t62 = load i64, ptr %l8, !tbaa !24
  %t65 = add i64 %t61, %t62
  %t67 = sub i64 %t65, 1
  %t68 = load i64, ptr %l8, !tbaa !24
  %t71 = sdiv i64 %t67, %t68
  store i64 %t71, ptr %l41, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb18
bb18:
  %t73 = load i64, ptr %l41, !tbaa !24
  store i64 %t73, ptr %l38, !tbaa !24
  br label %bb19
bb19:
  %t74 = load i64, ptr %l38, !tbaa !24
  store i64 %t74, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  %t75 = load i64, ptr %l10, !tbaa !24
  %t76 = load i64, ptr %l9, !tbaa !24
  %t79 = icmp slt i64 %t75, %t76
  %t81 = xor i1 %t79, true
  br i1 %t81, label %bb21, label %bb22
bb21:
  br label %bb33
bb22:
  br label %bb23
bb23:
  %t83 = load i64, ptr %l6, !tbaa !24
  %t84 = load i64, ptr %l10, !tbaa !24
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = mul i64 %t84, %t85
  %t91 = add i64 %t83, %t88
  store i64 %t91, ptr %l11, !tbaa !24
  %t93 = load ptr, ptr %l5, !tbaa !29
  %t95 = getelementptr %"compiler/typed:Body", ptr %t93, i32 0, i32 7
  %t96 = load i64, ptr %l11, !tbaa !24
  %t99 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t95, i64 %t96)
  store %"compiler/typed:Local" %t99, ptr %l62
  br label %bb24
bb24:
  %t100 = load %"compiler/typed:Local", ptr %l62
  store %"compiler/typed:Local" %t100, ptr %l12
  %t101 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 0
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = icmp ne i32 %t102, 0
  br i1 %t104, label %bb25, label %bb26
bb25:
  %t106 = getelementptr %"compiler/typed:Local", ptr %l12, i32 0, i32 1
  %t107 = getelementptr %"compiler/source:Span", ptr %t106, i32 0, i32 0
  %t108 = load i32, ptr %t107, !tbaa !23
  %t110 = sext i32 %t108 to i64
  %t114 = icmp eq i64 %t110, %a2
  store i1 %t114, ptr %l65, !tbaa !21
  br label %bb27
bb26:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb27
bb27:
  %t116 = load i1, ptr %l65, !tbaa !21
  br i1 %t116, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t119 = getelementptr %"compiler/typed:Body", ptr %t117, i32 0, i32 0
  %t120 = load i32, ptr %t119, !tbaa !23
  %t122 = sext i32 %t120 to i64
  %t123 = load i64, ptr %l11, !tbaa !24
  %t125 = trunc i64 %t123 to i32
  %t129 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %s6, i64 %t122, i32 %t125)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t129, ptr %l76
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t130 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l76
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t130, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l10, !tbaa !24
  br label %bb20
bb33:
  br label %bb34
bb34:
  %t136 = load i64, ptr %l4, !tbaa !24
  %t139 = add i64 %t136, 1
  store i64 %t139, ptr %l4, !tbaa !24
  br label %bb4
bb35:
  %t141 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %s0, i64 -1, i32 0)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t141, ptr %l83
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t142 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l83
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t142, ptr %rv
  br label %ret
ret:
  %rr = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %rv
  ret %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %rr
}

define dso_local i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emethodFor(ptr %v0, ptr %a0, i64 %a1, i32 %a2) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l19 = alloca ptr
  %l25 = alloca ptr
  %l32 = alloca i32
  %l33 = alloca i32
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l44 = alloca i32
  %l54 = alloca i32
  %l59 = alloca i64
  %l62 = alloca i64
  %l85 = alloca i1
  %l93 = alloca i1
  %l102 = alloca i32
  %l113 = alloca i32
  %l122 = alloca ptr
  %l123 = alloca i32
  %l130 = alloca ptr
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_c3a06fb660f5d63_2c40dec7065bb2a7)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  store ptr %t16, ptr %l19, !tbaa !29
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_c3a06fb660f5d63_2c40dec7065bb2a7)
  unreachable
bb5:
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t24 = getelementptr %"compiler/check:Checker", ptr %t21, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !29
  %t27 = getelementptr %"compiler/generic:Program", ptr %t25, i32 0, i32 2
  store ptr %t27, ptr %l25, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = icmp eq ptr %t28, null
  br i1 %t30, label %bb7, label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_c3a06fb660f5d63_2c40dec7065bb2a7)
  unreachable
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l3, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t37 = load i64, ptr %l1, !tbaa !24
  %t40 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t36, i64 %t37)
  store i32 %t40, ptr %l32
  br label %bb10
bb10:
  %t41 = load ptr, ptr %l25, !tbaa !29
  %t42 = load i32, ptr %l32, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %t41, i32 %t42)
  store i32 %t43, ptr %l33
  br label %bb11
bb11:
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = load i32, ptr %l33, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %s0, ptr %t44, i32 %t45)
  store { i64, ptr } %t46, ptr %l34
  br label %bb12
bb12:
  %t47 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t47, ptr %l35, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr i32, ptr %t49, i64 0
  %t51 = load i32, ptr %t50, !tbaa !33
  store i32 %t51, ptr %l4, !tbaa !23
  %t53 = load ptr, ptr %l3, !tbaa !29
  %t55 = icmp eq ptr %t53, null
  br i1 %t55, label %bb13, label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_98883a8ec488cc54_28db399b67188488)
  unreachable
bb14:
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t60 = getelementptr %"compiler/check:Checker", ptr %t57, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !29
  %t63 = getelementptr %"compiler/generic:Program", ptr %t61, i32 0, i32 2
  %t64 = load i32, ptr %l4, !tbaa !23
  %t67 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t63, i32 %t64)
  store i32 %t67, ptr %l44
  br label %bb16
bb16:
  %t68 = load i32, ptr %l44, !range !{i32 0, i32 33}
  %t70 = trunc i64 20 to i32
  %t71 = icmp eq i32 %t68, %t70
  br i1 %t71, label %bb17, label %bb18
bb17:
  %t73 = load ptr, ptr %l3, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb19, label %bb20
bb18:
  br label %bb23
bb19:
  call void @__olang_check_failed(ptr @olang_loc_98883a8ec488cc54_28db399b67188488)
  unreachable
bb20:
  br label %bb21
bb21:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = getelementptr %"compiler/generic:Program", ptr %t81, i32 0, i32 2
  %t84 = load i32, ptr %l4, !tbaa !23
  %t87 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t83, i32 %t84)
  store i32 %t87, ptr %l54
  br label %bb22
bb22:
  %t88 = load i32, ptr %l54, !tbaa !23
  store i32 %t88, ptr %l4, !tbaa !23
  br label %bb23
bb23:
  %t89 = load i32, ptr %l2, !tbaa !23
  store i32 %t89, ptr %l5, !tbaa !23
  store i64 0, ptr %l6, !tbaa !24
  store i64 32, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i64, ptr %l6, !tbaa !24
  %t95 = icmp sgt i64 %t91, %t92
  br i1 %t95, label %bb24, label %bb25
bb24:
  %t97 = load i64, ptr %l8, !tbaa !24
  %t99 = icmp sgt i64 %t97, 0
  br i1 %t99, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb29
bb26:
  %t101 = load i64, ptr %l7, !tbaa !24
  %t102 = load i64, ptr %l6, !tbaa !24
  %t105 = sub i64 %t101, %t102
  %t106 = load i64, ptr %l8, !tbaa !24
  %t109 = add i64 %t105, %t106
  %t111 = sub i64 %t109, 1
  %t112 = load i64, ptr %l8, !tbaa !24
  %t115 = sdiv i64 %t111, %t112
  store i64 %t115, ptr %l62, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb28
bb28:
  %t117 = load i64, ptr %l62, !tbaa !24
  store i64 %t117, ptr %l59, !tbaa !24
  br label %bb29
bb29:
  %t118 = load i64, ptr %l59, !tbaa !24
  store i64 %t118, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb30
bb30:
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb31, label %bb32
bb31:
  br label %bb53
bb32:
  br label %bb33
bb33:
  %t127 = load i64, ptr %l6, !tbaa !24
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l8, !tbaa !24
  %t132 = mul i64 %t128, %t129
  %t135 = add i64 %t127, %t132
  store i64 %t135, ptr %l11, !tbaa !24
  %t137 = load ptr, ptr %l3, !tbaa !29
  %t139 = icmp eq ptr %t137, null
  br i1 %t139, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_eee90b85a2ab3449_1ca471f0e2dcfa5d)
  unreachable
bb35:
  br label %bb36
bb36:
  %t141 = load ptr, ptr %l3, !tbaa !29
  %t142 = load i32, ptr %l4, !tbaa !23
  %t143 = load i32, ptr %l5, !tbaa !23
  %t147 = call i1 @compiler_2fsession_2esameShape(ptr %v0, ptr %t141, i32 %t142, i32 %t143)
  store i1 %t147, ptr %l85
  br label %bb37
bb37:
  %t148 = load i1, ptr %l85, !tbaa !21
  br i1 %t148, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb39:
  br label %bb40
bb40:
  %t150 = load ptr, ptr %l3, !tbaa !29
  %t152 = icmp eq ptr %t150, null
  br i1 %t152, label %bb41, label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e37b319ee17ac3e2_6c53c7f393475f6)
  unreachable
bb42:
  br label %bb43
bb43:
  %t154 = load ptr, ptr %l3, !tbaa !29
  %t157 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t159 = load i32, ptr %l5, !tbaa !23
  %t162 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t158, i32 %t159)
  store i1 %t162, ptr %l93
  br label %bb44
bb44:
  %t163 = load i1, ptr %l93, !tbaa !21
  %t164 = xor i1 %t163, true
  br i1 %t164, label %bb45, label %bb46
bb45:
  br label %bb53
bb46:
  br label %bb47
bb47:
  %t166 = load ptr, ptr %l3, !tbaa !29
  %t168 = icmp eq ptr %t166, null
  br i1 %t168, label %bb48, label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_82b2f05c0e10fd2f_9f8d8e81429d057b)
  unreachable
bb49:
  br label %bb50
bb50:
  %t170 = load ptr, ptr %l3, !tbaa !29
  %t173 = getelementptr %"compiler/check:Checker", ptr %t170, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !29
  %t176 = getelementptr %"compiler/generic:Program", ptr %t174, i32 0, i32 2
  %t177 = load i32, ptr %l5, !tbaa !23
  %t180 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t176, i32 %t177)
  store i32 %t180, ptr %l102
  br label %bb51
bb51:
  %t181 = load i32, ptr %l102, !tbaa !23
  store i32 %t181, ptr %l5, !tbaa !23
  br label %bb52
bb52:
  %t182 = load i64, ptr %l10, !tbaa !24
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %l10, !tbaa !24
  br label %bb30
bb53:
  %t187 = load ptr, ptr %l3, !tbaa !29
  %t189 = icmp eq ptr %t187, null
  br i1 %t189, label %bb54, label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_b19b477afd43b7d0_26f9d3d945d2830c)
  unreachable
bb55:
  br label %bb56
bb56:
  %t191 = load ptr, ptr %l3, !tbaa !29
  %t194 = getelementptr %"compiler/check:Checker", ptr %t191, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !29
  %t197 = getelementptr %"compiler/generic:Program", ptr %t195, i32 0, i32 2
  %t198 = load i32, ptr %l4, !tbaa !23
  %t201 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t197, i32 %t198)
  store i32 %t201, ptr %l113
  br label %bb57
bb57:
  %t202 = load i32, ptr %l113, !range !{i32 0, i32 33}
  %t204 = trunc i64 25 to i32
  %t205 = icmp eq i32 %t202, %t204
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb59:
  br label %bb60
bb60:
  %t210 = load ptr, ptr %l3, !tbaa !29
  %t212 = icmp eq ptr %t210, null
  br i1 %t212, label %bb61, label %bb62
bb61:
  call void @__olang_check_failed(ptr @olang_loc_639bbb695375d625_d561d256ffb09c41)
  unreachable
bb62:
  br label %bb63
bb63:
  %t214 = load ptr, ptr %l3, !tbaa !29
  %t217 = getelementptr %"compiler/check:Checker", ptr %t214, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !29
  store ptr %t218, ptr %l122, !tbaa !29
  %t219 = load i32, ptr %l2, !tbaa !23
  store i32 %t219, ptr %l123, !tbaa !23
  %t220 = load ptr, ptr %l3, !tbaa !29
  %t222 = icmp eq ptr %t220, null
  br i1 %t222, label %bb64, label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_639bbb695375d625_d561d256ffb09c41)
  unreachable
bb65:
  br label %bb66
bb66:
  %t224 = load ptr, ptr %l3, !tbaa !29
  %t227 = getelementptr %"compiler/check:Checker", ptr %t224, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !29
  %t229 = load i64, ptr %l1, !tbaa !24
  %t232 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s0, ptr %t228, i64 %t229)
  store ptr %t232, ptr %l130
  br label %bb67
bb67:
  %t233 = load ptr, ptr %l130, !tbaa !29
  %t235 = getelementptr %"compiler/ast:Func", ptr %t233, i32 0, i32 2
  %t236 = load i32, ptr %t235, !tbaa !23
  %t237 = load ptr, ptr %l122, !tbaa !29
  %t238 = load i32, ptr %l123, !tbaa !23
  %t240 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %s0, ptr %t237, i32 %t238, i32 %t236)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t240, ptr %l133
  br label %bb68
bb68:
  %t241 = load i64, ptr %l1, !tbaa !24
  %t244 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %s0, ptr %l133, i64 %t241)
  store i1 %t244, ptr %l136
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t245 = load i1, ptr %l136, !tbaa !21
  store i1 %t245, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleNames(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i64 %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca %"compiler/names:Entry"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l28 = alloca ptr
  %l31 = alloca i64
  %l33 = alloca i64
  %l38 = alloca %"compiler/names:Entry"
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l46 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca i1
  %l61 = alloca i64
  %l64 = alloca i1
  %l71 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l81 = alloca ptr
  %l88 = alloca i32
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l95 = alloca i1
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l105 = alloca i1
  %l108 = alloca i1
  %l110 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l115 = alloca i64
  %l122 = alloca i1
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_ad4014c285adba33_5f0a50bbd6dd5777)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/load:Loader", ptr %t17, i32 0, i32 3
  %t20 = load ptr, ptr %t19, !tbaa !29
  store ptr %t20, ptr %l5, !tbaa !29
  %t22 = load ptr, ptr %l4, !tbaa !29
  %t24 = icmp eq ptr %t22, null
  br i1 %t24, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_5a0f7bc549a8a64_9f8f3c14406c0758)
  unreachable
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t29 = getelementptr %"compiler/check:Checker", ptr %t26, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !29
  %t32 = getelementptr %"compiler/generic:Program", ptr %t30, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !29
  %t35 = getelementptr %"compiler/names:Resolver", ptr %t33, i32 0, i32 1
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store ptr %t39, ptr %l28
  br label %bb7
bb7:
  %t40 = load ptr, ptr %l28, !tbaa !29
  %t42 = getelementptr %"compiler/names:Table", ptr %t40, i32 0, i32 0
  store ptr %t42, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t44 = load i64, ptr %l7, !tbaa !24
  store i64 %t44, ptr %l31, !tbaa !24
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t45)
  store i64 %t47, ptr %l33
  br label %bb9
bb9:
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l33, !tbaa !24
  %t50 = icmp slt i64 %t48, %t49
  %t52 = xor i1 %t50, true
  br i1 %t52, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb75
bb11:
  br label %bb12
bb12:
  %t54 = load ptr, ptr %l6, !tbaa !29
  %t55 = load i64, ptr %l7, !tbaa !24
  %t58 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t54, i64 %t55)
  store %"compiler/names:Entry" %t58, ptr %l38
  br label %bb13
bb13:
  %t59 = load %"compiler/names:Entry", ptr %l38
  store %"compiler/names:Entry" %t59, ptr %l8
  %t60 = load ptr, ptr %l5, !tbaa !29
  %t61 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 0
  %t62 = load i32, ptr %t61, !tbaa !23
  %t65 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t60, i32 %t62)
  store { i64, ptr } %t65, ptr %l41
  br label %bb14
bb14:
  %t66 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t66, ptr %l9, !tbaa !27
  %t69 = xor i1 %a3, true
  br i1 %t69, label %bb15, label %bb16
bb15:
  %t71 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t73 = call i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %t71)
  store i1 %t73, ptr %l46
  br label %bb17
bb16:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb18
bb17:
  %t74 = load i1, ptr %l46, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l44, !tbaa !21
  br label %bb18
bb18:
  %t77 = load i1, ptr %l44, !tbaa !21
  br i1 %t77, label %bb19, label %bb20
bb19:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb20:
  br label %bb21
bb21:
  %t78 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, ptr %l50, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t82 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %s2, { i64, ptr } %t78, { i64, ptr } %t81)
  store i1 %t82, ptr %l51
  br label %bb22
bb22:
  %t83 = load i1, ptr %l51, !tbaa !21
  br i1 %t83, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb24:
  br label %bb25
bb25:
  %t84 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t85 = load i32, ptr %t84, !range !{i32 0, i32 9}
  %t87 = trunc i64 3 to i32
  %t88 = icmp eq i32 %t85, %t87
  br i1 %t88, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t90 = load ptr, ptr %l4, !tbaa !29
  %t92 = icmp eq ptr %t90, null
  br i1 %t92, label %bb28, label %bb29
bb27:
  %t94 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t95 = load i32, ptr %t94, !range !{i32 0, i32 9}
  %t97 = trunc i64 4 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb52, label %bb53
bb28:
  call void @__olang_check_failed(ptr @olang_loc_c15f20635f7a4119_452b944b82f8966d)
  unreachable
bb29:
  br label %bb30
bb30:
  %t100 = load ptr, ptr %l4, !tbaa !29
  %t103 = getelementptr %"compiler/check:Checker", ptr %t100, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t105 = load i64, ptr %l2, !tbaa !24
  %t106 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 0
  %t107 = load i32, ptr %t106, !tbaa !23
  %t111 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t104, i64 %t105, i32 %t107)
  store i64 %t111, ptr %l61
  br label %bb31
bb31:
  %t112 = load i64, ptr %l61, !tbaa !24
  store i64 %t112, ptr %l10, !tbaa !24
  %t113 = load i64, ptr %l10, !tbaa !24
  %t115 = icmp slt i64 %t113, 0
  br i1 %t115, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb38
bb33:
  %t117 = load ptr, ptr %l4, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  br i1 %t119, label %bb34, label %bb35
bb34:
  call void @__olang_check_failed(ptr @olang_loc_6010ac475f88a9f2_430aff1aa96b7386)
  unreachable
bb35:
  br label %bb36
bb36:
  %t121 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/check:Checker", ptr %t121, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !29
  %t126 = load i64, ptr %l10, !tbaa !24
  %t129 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t125, i64 %t126)
  store ptr %t129, ptr %l71
  br label %bb37
bb37:
  %t130 = load ptr, ptr %l71, !tbaa !29
  %t132 = getelementptr %"compiler/ast:Func", ptr %t130, i32 0, i32 1
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = icmp eq ptr %t133, null
  %t137 = xor i1 %t135, true
  store i1 %t137, ptr %l64, !tbaa !21
  br label %bb38
bb38:
  %t139 = load i1, ptr %l64, !tbaa !21
  br i1 %t139, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb40:
  br label %bb41
bb41:
  %t140 = load ptr, ptr %l1, !tbaa !29
  store ptr %t140, ptr %l76, !tbaa !29
  %t141 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t141, ptr %l77, !tbaa !27
  %t142 = load i64, ptr @G_2ecompiler_2fsession_2eCompFunction, !tbaa !24
  store i64 %t142, ptr %l78, !tbaa !24
  %t143 = load ptr, ptr %l4, !tbaa !29
  %t145 = icmp eq ptr %t143, null
  br i1 %t145, label %bb42, label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_64c89934b5f1bf_a2a8dc486100a28b)
  unreachable
bb43:
  br label %bb44
bb44:
  %t147 = load ptr, ptr %l4, !tbaa !29
  store ptr %t147, ptr %l81, !tbaa !29
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t150 = icmp eq ptr %t148, null
  br i1 %t150, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_64c89934b5f1bf_a2a8dc486100a28b)
  unreachable
bb46:
  br label %bb47
bb47:
  %t152 = load ptr, ptr %l4, !tbaa !29
  %t155 = getelementptr %"compiler/check:Checker", ptr %t152, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !29
  %t157 = load i64, ptr %l10, !tbaa !24
  %t160 = call i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %t156, i64 %t157)
  store i32 %t160, ptr %l88
  br label %bb48
bb48:
  %t161 = load ptr, ptr %l81, !tbaa !29
  %t162 = load i32, ptr %l88, !tbaa !23
  %t163 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %s5, ptr %t161, i32 %t162)
  store { i64, ptr } %t163, ptr %l89
  br label %bb49
bb49:
  %t164 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t164, ptr %l90, !tbaa !27
  %t165 = load ptr, ptr %l0, !tbaa !29
  %t166 = load i64, ptr %l2, !tbaa !24
  %t167 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 1
  %t168 = getelementptr %"compiler/source:Span", ptr %t167, i32 0, i32 0
  %t169 = load i32, ptr %t168, !tbaa !23
  %t171 = sext i32 %t169 to i64
  %t175 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edeprecatedAt(ptr %v0, ptr %t165, i64 %t166, i64 %t171, i1 false)
  store i1 %t175, ptr %l95
  br label %bb50
bb50:
  %t176 = load ptr, ptr %l76, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t178 = load i64, ptr %l78, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t180 = load i1, ptr %l95, !tbaa !21
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAddDep(ptr %v1, ptr %v0, ptr %s5, ptr %t176, { i64, ptr } %t177, i64 %t178, { i64, ptr } %t179, i1 %t180)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s5)
  br label %bb73
bb52:
  store %olang.scope zeroinitializer, ptr %s8
  %t181 = load ptr, ptr %l1, !tbaa !29
  store ptr %t181, ptr %l98, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t182, ptr %l99, !tbaa !27
  %t183 = load i64, ptr @G_2ecompiler_2fsession_2eCompStruct, !tbaa !24
  store i64 %t183, ptr %l100, !tbaa !24
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t185 = load i64, ptr %l2, !tbaa !24
  %t186 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 1
  %t187 = getelementptr %"compiler/source:Span", ptr %t186, i32 0, i32 0
  %t188 = load i32, ptr %t187, !tbaa !23
  %t190 = sext i32 %t188 to i64
  %t194 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edeprecatedAt(ptr %v0, ptr %t184, i64 %t185, i64 %t190, i1 false)
  store i1 %t194, ptr %l105
  br label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t195 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t196 = load i32, ptr %t195, !range !{i32 0, i32 9}
  %t198 = trunc i64 2 to i32
  %t199 = icmp eq i32 %t196, %t198
  br i1 %t199, label %bb56, label %bb57
bb54:
  %t201 = load ptr, ptr %l98, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t203 = load i64, ptr %l100, !tbaa !24
  %t204 = load i1, ptr %l105, !tbaa !21
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAddDep(ptr %v1, ptr %v0, ptr %s8, ptr %t201, { i64, ptr } %t202, i64 %t203, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d80, i32 0, i32 1) }, i1 %t204)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s8)
  br label %bb72
bb56:
  %t205 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t207 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s9, { i64, ptr } %t205, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t207, ptr %l110
  br label %bb58
bb57:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb59
bb58:
  %t208 = load i1, ptr %l110, !tbaa !21
  %t209 = xor i1 %t208, true
  store i1 %t209, ptr %l108, !tbaa !21
  br label %bb59
bb59:
  %t211 = load i1, ptr %l108, !tbaa !21
  br i1 %t211, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s10
  %t212 = load ptr, ptr %l1, !tbaa !29
  store ptr %t212, ptr %l112, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t213, ptr %l113, !tbaa !27
  %t214 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 3
  %t215 = load i1, ptr %t214, !tbaa !21
  br i1 %t215, label %bb62, label %bb63
bb61:
  %t217 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 2
  %t218 = load i32, ptr %t217, !range !{i32 0, i32 9}
  %t220 = trunc i64 5 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb67, label %bb68
bb62:
  %t223 = load i64, ptr @G_2ecompiler_2fsession_2eCompVariable, !tbaa !24
  store i64 %t223, ptr %l115, !tbaa !24
  br label %bb64
bb63:
  %t225 = load i64, ptr @G_2ecompiler_2fsession_2eCompConstant, !tbaa !24
  store i64 %t225, ptr %l115, !tbaa !24
  br label %bb64
bb64:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load i64, ptr %l2, !tbaa !24
  %t229 = getelementptr %"compiler/names:Entry", ptr %l8, i32 0, i32 1
  %t230 = getelementptr %"compiler/source:Span", ptr %t229, i32 0, i32 0
  %t231 = load i32, ptr %t230, !tbaa !23
  %t233 = sext i32 %t231 to i64
  %t237 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edeprecatedAt(ptr %v0, ptr %t227, i64 %t228, i64 %t233, i1 true)
  store i1 %t237, ptr %l122
  br label %bb65
bb65:
  %t238 = load ptr, ptr %l112, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t240 = load i64, ptr %l115, !tbaa !24
  %t241 = load i1, ptr %l122, !tbaa !21
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAddDep(ptr %v1, ptr %v0, ptr %s10, ptr %t238, { i64, ptr } %t239, i64 %t240, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d82, i32 0, i32 1) }, i1 %t241)
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s10)
  br label %bb71
bb67:
  store %olang.scope zeroinitializer, ptr %s12
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t244 = load i64, ptr @G_2ecompiler_2fsession_2eCompModule, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v0, ptr %s12, ptr %t242, { i64, ptr } %t243, i64 %t244, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s12)
  br label %bb70
bb70:
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s9)
  br label %bb72
bb72:
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s2)
  br label %bb74
bb74:
  %t248 = load i64, ptr %l7, !tbaa !24
  %t251 = add i64 %t248, 1
  store i64 %t251, ptr %l7, !tbaa !24
  br label %bb8
bb75:
  br label %ret
ret:
  ret void
}

define dso_local { { i64, ptr }, i64, i64 } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2enoteOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, [6 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [6 x i64] }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca %"compiler/session:memberInfo"
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l26 = alloca i64
  %l29 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l49 = alloca i64
  %l56 = alloca ptr
  %l60 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l76 = alloca %"compiler/session:memberInfo"
  %l80 = alloca %"compiler/session:memberInfo"
  %l81 = alloca i32
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l86 = alloca { { i64, ptr }, i64, i64 }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l95 = alloca i64
  %l103 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l109 = alloca { { i64, ptr }, i64, i64 }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, i64, i64 }
  store ptr %a0, ptr %l0
  store { i64, [6 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load { i64, [6 x i64] }, ptr %l1
  %t8 = extractvalue { i64, [6 x i64] } %t6, 0
  %t9 = icmp eq i64 %t8, 1
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t12 = getelementptr { i64, { i64, ptr } }, ptr %t11, i32 0, i32 0
  %t13 = load i64, ptr %t12
  store i64 %t13, ptr %l3, !tbaa !24
  %t15 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t16 = getelementptr { i64, { i64, ptr } }, ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l4, !tbaa !27
  br label %bb3
bb2:
  br label %bb14
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = icmp eq ptr %t19, null
  br i1 %t21, label %bb4, label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3355c36425226bea_fe115d6500f3a7ee)
  unreachable
bb5:
  br label %bb6
bb6:
  %t23 = load ptr, ptr %l2, !tbaa !29
  %t24 = load i64, ptr %l3, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = call i64 @compiler_2fsession_2edeclOf(ptr %v0, ptr %v1, ptr %t23, i64 %t24, { i64, ptr } %t25)
  store i64 %t29, ptr %l26
  br label %bb7
bb7:
  %t30 = load i64, ptr %l26, !tbaa !24
  store i64 %t30, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l5, !tbaa !24
  %t33 = icmp sge i64 %t31, 0
  br i1 %t33, label %bb8, label %bb9
bb8:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i64, ptr %l3, !tbaa !24
  %t39 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store { i64, ptr } %t39, ptr %l32
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) }, ptr %l29, !tbaa !27
  br label %bb12
bb10:
  %t40 = load i64, ptr %l5, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t43 = call { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %s1, { i64, ptr } %t41, i64 %t40, i1 true)
  store { i64, ptr } %t43, ptr %l34
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  br label %bb12
bb12:
  %t46 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t47 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %s1, ptr %v2, { i64, ptr } %t46)
  store { i64, ptr } %t47, ptr %l36
  br label %bb13
bb13:
  %t48 = load i64, ptr %l5, !tbaa !24
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t51 = insertvalue { { i64, ptr }, i64, i64 } undef, { i64, ptr } %t50, 0
  %t53 = insertvalue { { i64, ptr }, i64, i64 } %t51, i64 %t48, 1
  %t55 = insertvalue { { i64, ptr }, i64, i64 } %t53, i64 %t49, 2
  call void @__olang_scope_close(ptr %s1)
  store { { i64, ptr }, i64, i64 } %t55, ptr %rv
  br label %ret
bb14:
  %t57 = load { i64, [6 x i64] }, ptr %l1
  %t59 = extractvalue { i64, [6 x i64] } %t57, 0
  %t60 = icmp eq i64 %t59, 2
  br i1 %t60, label %bb15, label %bb16
bb15:
  %t62 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t63 = getelementptr { i64 }, ptr %t62, i32 0, i32 0
  %t64 = load i64, ptr %t63
  store i64 %t64, ptr %l6, !tbaa !24
  br label %bb17
bb16:
  br label %bb31
bb17:
  store %olang.scope zeroinitializer, ptr %s2
  %t66 = load ptr, ptr %l2, !tbaa !29
  %t68 = icmp eq ptr %t66, null
  br i1 %t68, label %bb18, label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_9d5a0cb699faa7f1_8fc39d14917e395)
  unreachable
bb19:
  br label %bb20
bb20:
  %t70 = load ptr, ptr %l2, !tbaa !29
  %t73 = getelementptr %"compiler/check:Checker", ptr %t70, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !29
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t74, i64 %t75)
  store i64 %t78, ptr %l49
  br label %bb21
bb21:
  %t79 = load i64, ptr %l49, !tbaa !24
  store i64 %t79, ptr %l7, !tbaa !24
  %t80 = load ptr, ptr %l2, !tbaa !29
  %t82 = icmp eq ptr %t80, null
  br i1 %t82, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_f7c6bb339a0b1bfc_57f909eed9cc3b80)
  unreachable
bb23:
  br label %bb24
bb24:
  %t84 = load ptr, ptr %l2, !tbaa !29
  %t87 = getelementptr %"compiler/check:Checker", ptr %t84, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load i64, ptr %l6, !tbaa !24
  %t92 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %s2, ptr %t88, i64 %t89)
  store ptr %t92, ptr %l56
  br label %bb25
bb25:
  %t93 = load ptr, ptr %l56, !tbaa !29
  %t95 = getelementptr %"compiler/ast:Func", ptr %t93, i32 0, i32 0
  %t96 = getelementptr %"compiler/source:Span", ptr %t95, i32 0, i32 0
  %t97 = load i32, ptr %t96, !tbaa !23
  %t99 = sext i32 %t97 to i64
  store i64 %t99, ptr %l8, !tbaa !24
  %t101 = call ptr @__olang_scope_hold(ptr %s2)
  %t102 = ptrtoint ptr %t101 to i64
  store i64 %t102, ptr %l60, !tbaa !24
  %t103 = load i1, ptr @olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0
  br i1 %t103, label %bb26, label %bb27
bb26:
  %t105 = call ptr @__olang_region_make(ptr %s2)
  %t106 = ptrtoint ptr %t105 to i64
  store i64 %t106, ptr %l60, !tbaa !24
  br label %bb27
bb27:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i64, ptr %l7, !tbaa !24
  %t111 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t107, i64 %t108)
  store { i64, ptr } %t111, ptr %l64
  br label %bb28
bb28:
  %t112 = load i64, ptr %l8, !tbaa !24
  %t113 = load i64, ptr %l60
  %t114 = inttoptr i64 %t113 to ptr
  %t115 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t117 = call { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %t114, { i64, ptr } %t115, i64 %t112)
  store { i64, ptr } %t117, ptr %l66
  br label %bb29
bb29:
  %t118 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t119 = load i64, ptr %l60
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = extractvalue { i64, ptr } %t118, 0
  %t122 = extractvalue { i64, ptr } %t118, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_held_alloc(ptr %t120, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %s2, ptr %v2, { i64, ptr } %t126)
  store { i64, ptr } %t128, ptr %l68
  br label %bb30
bb30:
  %t129 = load i64, ptr %l8, !tbaa !24
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t132 = insertvalue { { i64, ptr }, i64, i64 } undef, { i64, ptr } %t131, 0
  %t134 = insertvalue { { i64, ptr }, i64, i64 } %t132, i64 %t129, 1
  %t136 = insertvalue { { i64, ptr }, i64, i64 } %t134, i64 %t130, 2
  call void @__olang_scope_close(ptr %s2)
  store { { i64, ptr }, i64, i64 } %t136, ptr %rv
  br label %ret
bb31:
  %t138 = load { i64, [6 x i64] }, ptr %l1
  %t140 = extractvalue { i64, [6 x i64] } %t138, 0
  %t141 = icmp eq i64 %t140, 3
  br i1 %t141, label %bb32, label %bb33
bb32:
  %t143 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t144 = getelementptr { i32, i64 }, ptr %t143, i32 0, i32 0
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l9, !tbaa !23
  %t147 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t148 = getelementptr { i32, i64 }, ptr %t147, i32 0, i32 1
  %t149 = load i64, ptr %t148
  store i64 %t149, ptr %l10, !tbaa !24
  br label %bb34
bb33:
  br label %bb41
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t152 = load i32, ptr %l9, !tbaa !23
  %t153 = load i64, ptr %l10, !tbaa !24
  %t157 = call { i32, %"compiler/session:memberInfo" } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efield(ptr %v0, ptr %s3, ptr %t151, i32 %t152, i64 %t153)
  %t158 = extractvalue { i32, %"compiler/session:memberInfo" } %t157, 1
  %t159 = extractvalue { i32, %"compiler/session:memberInfo" } %t157, 0
  store i32 %t159, ptr %l81
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb36, label %ok.161, !prof !99
ok.161:
  store %"compiler/session:memberInfo" %t158, ptr %l80
  br label %bb35
bb35:
  %t162 = load %"compiler/session:memberInfo", ptr %l80
  store %"compiler/session:memberInfo" %t162, ptr %l76
  br label %bb38
bb36:
  %t163 = load i32, ptr %l81, !tbaa !23
  %t164 = ashr i32 %t163, 16
  %t166 = icmp eq i32 %t164, 1
  store i1 %t166, ptr %l83, !tbaa !21
  br label %bb37
bb37:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) }, ptr %l84, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t169 = insertvalue { { i64, ptr }, i64, i64 } undef, { i64, ptr } %t167, 0
  %t170 = insertvalue { { i64, ptr }, i64, i64 } %t169, i64 -1, 1
  %t171 = insertvalue { { i64, ptr }, i64, i64 } %t170, i64 -1, 2
  store { { i64, ptr }, i64, i64 } %t171, ptr %l86
  %t172 = getelementptr { { i64, ptr }, i64, i64 }, ptr %l86, i32 0, i32 0
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  store { i64, ptr } %t173, ptr %l87, !tbaa !27
  %t174 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t175 = extractvalue { i64, ptr } %t174, 0
  store i64 %t175, ptr %l88, !tbaa !24
  %t176 = load i64, ptr %l88, !tbaa !24
  %t177 = mul i64 %t176, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t177)
  %t179 = insertvalue { i64, ptr } undef, i64 %t176, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l89, !tbaa !27
  %t181 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t182 = load ptr, ptr %t181, !tbaa !27
  %t183 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t184 = load ptr, ptr %t183, !tbaa !27
  %t185 = load i64, ptr %l88, !tbaa !24
  %t186 = mul i64 %t185, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t182, ptr %t184, i64 %t186, i1 false)
  %t187 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t188 = getelementptr { { i64, ptr }, i64, i64 }, ptr %l86, i32 0, i32 0
  store { i64, ptr } %t187, ptr %t188, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  %t189 = load { { i64, ptr }, i64, i64 }, ptr %l86
  store { { i64, ptr }, i64, i64 } %t189, ptr %rv
  br label %ret
bb38:
  %t190 = load %"compiler/session:memberInfo", ptr %l76
  store %"compiler/session:memberInfo" %t190, ptr %l11
  %t191 = getelementptr %"compiler/session:memberInfo", ptr %l11, i32 0, i32 2
  %t192 = load { i64, ptr }, ptr %t191, !tbaa !27
  %t194 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %s3, ptr %v2, { i64, ptr } %t192)
  store { i64, ptr } %t194, ptr %l91
  br label %bb39
bb39:
  %t195 = getelementptr %"compiler/session:memberInfo", ptr %l11, i32 0, i32 4
  %t196 = load i64, ptr %t195, !tbaa !24
  store i64 %t196, ptr %l92, !tbaa !24
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/session:memberInfo", ptr %l11, i32 0, i32 3
  %t199 = load { i64, ptr }, ptr %t198, !tbaa !27
  %t202 = call i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %s3, ptr %t197, { i64, ptr } %t199)
  store i64 %t202, ptr %l95
  br label %bb40
bb40:
  %t203 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t204 = insertvalue { { i64, ptr }, i64, i64 } undef, { i64, ptr } %t203, 0
  %t205 = load i64, ptr %l92, !tbaa !24
  %t206 = insertvalue { { i64, ptr }, i64, i64 } %t204, i64 %t205, 1
  %t207 = load i64, ptr %l95, !tbaa !24
  %t208 = insertvalue { { i64, ptr }, i64, i64 } %t206, i64 %t207, 2
  call void @__olang_scope_close(ptr %s3)
  store { { i64, ptr }, i64, i64 } %t208, ptr %rv
  br label %ret
bb41:
  %t210 = load { i64, [6 x i64] }, ptr %l1
  %t212 = extractvalue { i64, [6 x i64] } %t210, 0
  %t213 = icmp eq i64 %t212, 5
  br i1 %t213, label %bb42, label %bb43
bb42:
  %t215 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t216 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t215, i32 0, i32 0
  %t217 = load i64, ptr %t216
  store i64 %t217, ptr %l12, !tbaa !24
  %t219 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t220 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t219, i32 0, i32 1
  %t221 = load i64, ptr %t220
  store i64 %t221, ptr %l13, !tbaa !24
  %t223 = getelementptr { i64, [6 x i64] }, ptr %l1, i32 0, i32 1
  %t224 = getelementptr { i64, i64, { i64, ptr }, { i64, ptr } }, ptr %t223, i32 0, i32 2
  %t225 = load { i64, ptr }, ptr %t224
  store { i64, ptr } %t225, ptr %l14, !tbaa !27
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t227 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t229 = call { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v1, ptr %v2, { i64, ptr } %t227)
  store { i64, ptr } %t229, ptr %l103
  br label %bb45
bb45:
  %t230 = load i64, ptr %l13, !tbaa !24
  %t231 = load i64, ptr %l12, !tbaa !24
  %t232 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t233 = insertvalue { { i64, ptr }, i64, i64 } undef, { i64, ptr } %t232, 0
  %t235 = insertvalue { { i64, ptr }, i64, i64 } %t233, i64 %t230, 1
  %t237 = insertvalue { { i64, ptr }, i64, i64 } %t235, i64 %t231, 2
  store { { i64, ptr }, i64, i64 } %t237, ptr %rv
  br label %ret
bb46:
  br i1 true, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) }, ptr %l107, !tbaa !27
  %t239 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t241 = insertvalue { { i64, ptr }, i64, i64 } undef, { i64, ptr } %t239, 0
  %t242 = insertvalue { { i64, ptr }, i64, i64 } %t241, i64 -1, 1
  %t243 = insertvalue { { i64, ptr }, i64, i64 } %t242, i64 -1, 2
  store { { i64, ptr }, i64, i64 } %t243, ptr %l109
  %t244 = getelementptr { { i64, ptr }, i64, i64 }, ptr %l109, i32 0, i32 0
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !27
  store { i64, ptr } %t245, ptr %l110, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t247 = extractvalue { i64, ptr } %t246, 0
  store i64 %t247, ptr %l111, !tbaa !24
  %t248 = load i64, ptr %l111, !tbaa !24
  %t249 = mul i64 %t248, 1
  %t250 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t249)
  %t251 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t252 = insertvalue { i64, ptr } %t251, ptr %t250, 1
  store { i64, ptr } %t252, ptr %l112, !tbaa !27
  %t253 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t256 = load ptr, ptr %t255, !tbaa !27
  %t257 = load i64, ptr %l111, !tbaa !24
  %t258 = mul i64 %t257, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t254, ptr %t256, i64 %t258, i1 false)
  %t259 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t260 = getelementptr { { i64, ptr }, i64, i64 }, ptr %l109, i32 0, i32 0
  store { i64, ptr } %t259, ptr %t260, !tbaa !27
  %t261 = load { { i64, ptr }, i64, i64 }, ptr %l109
  store { { i64, ptr }, i64, i64 } %t261, ptr %rv
  br label %ret
bb50:
  call void @__olang_check_failed(ptr @olang_loc_9563e15fbc6eea92_8818e5f6fc0bf866)
  unreachable
ret:
  %rr = load { { i64, ptr }, i64, i64 }, ptr %rv
  ret { { i64, ptr }, i64, i64 } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2esuppliedMembers(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i64
  %lp7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %lp18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %lp22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %lp26 = alloca ptr
  %l29 = alloca i64
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l64 = alloca i64
  %l67 = alloca i64
  %l91 = alloca i1
  %l100 = alloca i32
  %l111 = alloca i32
  %l114 = alloca i64
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca { i64, ptr }
  %l120 = alloca i64
  %l122 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca i64
  %l128 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l150 = alloca { i64, ptr }
  %l164 = alloca i1
  %l174 = alloca i1
  %l184 = alloca i1
  %l186 = alloca i64
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca i64
  %l191 = alloca { i64, ptr }
  %l192 = alloca i64
  %l194 = alloca { i64, ptr }
  %l195 = alloca { i64, ptr }
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %l198 = alloca i64
  %l200 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l202 = alloca i64
  %l203 = alloca { i64, ptr }
  %l204 = alloca i64
  %l206 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca i64
  %l209 = alloca { i64, ptr }
  %l210 = alloca i64
  %l212 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i64
  %l215 = alloca { i64, ptr }
  %l216 = alloca i64
  %l218 = alloca { i64, ptr }
  %l219 = alloca { i64, ptr }
  %l220 = alloca i64
  %l221 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca { i64, ptr }
  %l241 = alloca i64
  %l243 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l245 = alloca i64
  %l246 = alloca { i64, ptr }
  %l247 = alloca i64
  %l249 = alloca { i64, ptr }
  %l250 = alloca { i64, ptr }
  %l251 = alloca i64
  %l252 = alloca { i64, ptr }
  %l253 = alloca i64
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l257 = alloca i64
  %l258 = alloca { i64, ptr }
  %l259 = alloca i64
  %l261 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca i64
  %l264 = alloca { i64, ptr }
  %l265 = alloca i64
  %l267 = alloca { i64, ptr }
  %l268 = alloca { i64, ptr }
  %l269 = alloca i64
  %l270 = alloca { i64, ptr }
  %l281 = alloca { i64, ptr }
  %l282 = alloca i64
  %l283 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %t10 = alloca %olang.slotscope
  %t39 = alloca %olang.slotscope
  %t225 = alloca %olang.slotscope
  %t254 = alloca %olang.slotscope
  %t283 = alloca %olang.slotscope
  %t312 = alloca %olang.slotscope
  %t455 = alloca %olang.slotscope
  %t484 = alloca %olang.slotscope
  %t513 = alloca %olang.slotscope
  %t542 = alloca %olang.slotscope
  %t571 = alloca %olang.slotscope
  %t600 = alloca %olang.slotscope
  %t689 = alloca %olang.slotscope
  %t718 = alloca %olang.slotscope
  %t747 = alloca %olang.slotscope
  %t776 = alloca %olang.slotscope
  %t805 = alloca %olang.slotscope
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"compiler/session:Analysis", ptr %a0, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = call ptr @__olang_scope_hold(ptr %s1)
  %t7 = ptrtoint ptr %t6 to i64
  store i64 %t7, ptr %l29, !tbaa !24
  %t8 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_202_3e_2e_2d1
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t11 = load ptr, ptr %s1
  %t12 = icmp eq ptr %t11, @__olang_slot_chunk
  %t13 = getelementptr %olang.scope, ptr %s1, i32 0, i32 2
  %t14 = load ptr, ptr %t13
  %t15 = select i1 %t12, ptr %t14, ptr %s1
  store %olang.scope zeroinitializer, ptr %t10
  store ptr @__olang_slot_chunk, ptr %t10
  %t16 = getelementptr %olang.scope, ptr %t10, i32 0, i32 2
  store ptr %t15, ptr %t16
  %t17 = getelementptr %olang.slotscope, ptr %t10, i32 0, i32 1
  store i64 0, ptr %t17
  %t18 = ptrtoint ptr %t10 to i64
  store i64 %t18, ptr %l29, !tbaa !24
  br label %bb2
bb2:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d87, i32 0, i32 1) }, ptr %l31, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t19, ptr %l32, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 0
  store i64 %t21, ptr %l33, !tbaa !24
  %t22 = load i64, ptr %l33, !tbaa !24
  %t23 = mul i64 %t22, 1
  %t24 = load i64, ptr %l29
  %t25 = inttoptr i64 %t24 to ptr
  %t26 = call ptr @__olang_held_alloc(ptr %t25, i64 %t23)
  %t27 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l34, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t32 = load ptr, ptr %t31, !tbaa !27
  %t33 = load i64, ptr %l33, !tbaa !24
  %t34 = mul i64 %t33, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t30, ptr %t32, i64 %t34, i1 false)
  %t35 = call ptr @__olang_scope_hold(ptr %s1)
  %t36 = ptrtoint ptr %t35 to i64
  store i64 %t36, ptr %l35, !tbaa !24
  %t37 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_202_3e_2e_2d1
  br i1 %t37, label %bb3, label %bb4
bb3:
  %t40 = load ptr, ptr %s1
  %t41 = icmp eq ptr %t40, @__olang_slot_chunk
  %t42 = getelementptr %olang.scope, ptr %s1, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  %t44 = select i1 %t41, ptr %t43, ptr %s1
  store %olang.scope zeroinitializer, ptr %t39
  store ptr @__olang_slot_chunk, ptr %t39
  %t45 = getelementptr %olang.scope, ptr %t39, i32 0, i32 2
  store ptr %t44, ptr %t45
  %t46 = getelementptr %olang.slotscope, ptr %t39, i32 0, i32 1
  store i64 0, ptr %t46
  %t47 = ptrtoint ptr %t39 to i64
  store i64 %t47, ptr %l35, !tbaa !24
  br label %bb4
bb4:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d88, i32 0, i32 1) }, ptr %l37, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t48, ptr %l38, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l39, !tbaa !24
  %t51 = load i64, ptr %l39, !tbaa !24
  %t52 = mul i64 %t51, 1
  %t53 = load i64, ptr %l35
  %t54 = inttoptr i64 %t53 to ptr
  %t55 = call ptr @__olang_held_alloc(ptr %t54, i64 %t52)
  %t56 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l40, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t64, 0
  %t66 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t67 = insertvalue [2 x { i64, ptr }] %t65, { i64, ptr } %t66, 1
  %t69 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t67, ptr %t69
  store ptr %t69, ptr %l4
  store i64 0, ptr %l5, !tbaa !24
  %t71 = load ptr, ptr %l4
  store i64 2, ptr %l6, !tbaa !24
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t74 = load i64, ptr %l5, !tbaa !24
  %t75 = load i64, ptr %l6, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb7:
  br label %bb8
bb8:
  %t82 = load ptr, ptr %l4
  %t83 = load i64, ptr %l5, !tbaa !24
  %t86 = getelementptr [2 x { i64, ptr }], ptr %t82, i64 0, i64 %t83
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !37
  store { i64, ptr } %t87, ptr %l51, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l52, !tbaa !24
  %t90 = load i64, ptr %l52, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l53, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l52, !tbaa !24
  %t100 = mul i64 %t99, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %t98, i64 %t100, i1 false)
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t101, ptr %lp7
  %t102 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t103 = load ptr, ptr %lp7
  store { i64, ptr } %t102, ptr %t103, !tbaa !27
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t105 = load ptr, ptr %lp7
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t107 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v1, ptr %s2, ptr %t104, { i64, ptr } %t106, i64 %t107, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t111 = load i64, ptr %l5, !tbaa !24
  %t114 = add i64 %t111, 1
  store i64 %t114, ptr %l5, !tbaa !24
  br label %bb5
bb11:
  call void @__olang_scope_close(ptr %s1)
  store i32 %a2, ptr %l8, !tbaa !23
  store i64 0, ptr %l9, !tbaa !24
  store i64 32, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = icmp sgt i64 %t118, %t119
  br i1 %t122, label %bb12, label %bb13
bb12:
  %t124 = load i64, ptr %l11, !tbaa !24
  %t126 = icmp sgt i64 %t124, 0
  br i1 %t126, label %bb14, label %bb15
bb13:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb17
bb14:
  %t128 = load i64, ptr %l10, !tbaa !24
  %t129 = load i64, ptr %l9, !tbaa !24
  %t132 = sub i64 %t128, %t129
  %t133 = load i64, ptr %l11, !tbaa !24
  %t136 = add i64 %t132, %t133
  %t138 = sub i64 %t136, 1
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sdiv i64 %t138, %t139
  store i64 %t142, ptr %l67, !tbaa !24
  br label %bb16
bb15:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb16
bb16:
  %t144 = load i64, ptr %l67, !tbaa !24
  store i64 %t144, ptr %l64, !tbaa !24
  br label %bb17
bb17:
  %t145 = load i64, ptr %l64, !tbaa !24
  store i64 %t145, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb18
bb18:
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t150 = icmp slt i64 %t146, %t147
  %t152 = xor i1 %t150, true
  br i1 %t152, label %bb19, label %bb20
bb19:
  br label %bb34
bb20:
  br label %bb21
bb21:
  %t154 = load i64, ptr %l9, !tbaa !24
  %t155 = load i64, ptr %l13, !tbaa !24
  %t156 = load i64, ptr %l11, !tbaa !24
  %t159 = mul i64 %t155, %t156
  %t162 = add i64 %t154, %t159
  store i64 %t162, ptr %l14, !tbaa !24
  %t164 = load ptr, ptr %l3, !tbaa !29
  %t166 = icmp eq ptr %t164, null
  br i1 %t166, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_c4fad5f23cb43116_e9ea0caff0315a32)
  unreachable
bb23:
  br label %bb24
bb24:
  %t168 = load ptr, ptr %l3, !tbaa !29
  %t171 = getelementptr %"compiler/check:Checker", ptr %t168, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !29
  %t173 = load i32, ptr %l8, !tbaa !23
  %t176 = call i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %t172, i32 %t173)
  store i1 %t176, ptr %l91
  br label %bb25
bb25:
  %t177 = load i1, ptr %l91, !tbaa !21
  %t178 = xor i1 %t177, true
  br i1 %t178, label %bb26, label %bb27
bb26:
  br label %bb34
bb27:
  br label %bb28
bb28:
  %t180 = load ptr, ptr %l3, !tbaa !29
  %t182 = icmp eq ptr %t180, null
  br i1 %t182, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_48989d5f5646e0fd_ef1e52ba7ace6b59)
  unreachable
bb30:
  br label %bb31
bb31:
  %t184 = load ptr, ptr %l3, !tbaa !29
  %t187 = getelementptr %"compiler/check:Checker", ptr %t184, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !29
  %t190 = getelementptr %"compiler/generic:Program", ptr %t188, i32 0, i32 2
  %t191 = load i32, ptr %l8, !tbaa !23
  %t194 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %t190, i32 %t191)
  store i32 %t194, ptr %l100
  br label %bb32
bb32:
  %t195 = load i32, ptr %l100, !tbaa !23
  store i32 %t195, ptr %l8, !tbaa !23
  br label %bb33
bb33:
  %t196 = load i64, ptr %l13, !tbaa !24
  %t199 = add i64 %t196, 1
  store i64 %t199, ptr %l13, !tbaa !24
  br label %bb18
bb34:
  %t201 = load ptr, ptr %l3, !tbaa !29
  %t203 = icmp eq ptr %t201, null
  br i1 %t203, label %bb35, label %bb36
bb35:
  call void @__olang_check_failed(ptr @olang_loc_f019bff4f77dc028_28a8ece3fb472fa4)
  unreachable
bb36:
  br label %bb37
bb37:
  %t205 = load ptr, ptr %l3, !tbaa !29
  %t208 = getelementptr %"compiler/check:Checker", ptr %t205, i32 0, i32 1
  %t209 = load ptr, ptr %t208, !tbaa !29
  %t211 = getelementptr %"compiler/generic:Program", ptr %t209, i32 0, i32 2
  %t212 = load i32, ptr %l8, !tbaa !23
  %t215 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t211, i32 %t212)
  store i32 %t215, ptr %l111
  br label %bb38
bb38:
  %t216 = load i32, ptr %l111, !range !{i32 0, i32 33}
  %t218 = trunc i64 19 to i32
  %t219 = icmp eq i32 %t216, %t218
  br i1 %t219, label %bb39, label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s9
  %t221 = call ptr @__olang_scope_hold(ptr %s9)
  %t222 = ptrtoint ptr %t221 to i64
  store i64 %t222, ptr %l114, !tbaa !24
  %t223 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_204_3e_2e_2d1
  br i1 %t223, label %bb41, label %bb42
bb40:
  br label %bb56
bb41:
  %t226 = load ptr, ptr %s9
  %t227 = icmp eq ptr %t226, @__olang_slot_chunk
  %t228 = getelementptr %olang.scope, ptr %s9, i32 0, i32 2
  %t229 = load ptr, ptr %t228
  %t230 = select i1 %t227, ptr %t229, ptr %s9
  store %olang.scope zeroinitializer, ptr %t225
  store ptr @__olang_slot_chunk, ptr %t225
  %t231 = getelementptr %olang.scope, ptr %t225, i32 0, i32 2
  store ptr %t230, ptr %t231
  %t232 = getelementptr %olang.slotscope, ptr %t225, i32 0, i32 1
  store i64 0, ptr %t232
  %t233 = ptrtoint ptr %t225 to i64
  store i64 %t233, ptr %l114, !tbaa !24
  br label %bb42
bb42:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d90, i32 0, i32 1) }, ptr %l116, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t234, ptr %l117, !tbaa !27
  %t235 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  store i64 %t236, ptr %l118, !tbaa !24
  %t237 = load i64, ptr %l118, !tbaa !24
  %t238 = mul i64 %t237, 1
  %t239 = load i64, ptr %l114
  %t240 = inttoptr i64 %t239 to ptr
  %t241 = call ptr @__olang_held_alloc(ptr %t240, i64 %t238)
  %t242 = insertvalue { i64, ptr } undef, i64 %t237, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  store { i64, ptr } %t243, ptr %l119, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %l119, i32 0, i32 1
  %t245 = load ptr, ptr %t244, !tbaa !27
  %t246 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t247 = load ptr, ptr %t246, !tbaa !27
  %t248 = load i64, ptr %l118, !tbaa !24
  %t249 = mul i64 %t248, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t245, ptr %t247, i64 %t249, i1 false)
  %t250 = call ptr @__olang_scope_hold(ptr %s9)
  %t251 = ptrtoint ptr %t250 to i64
  store i64 %t251, ptr %l120, !tbaa !24
  %t252 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_204_3e_2e_2d1
  br i1 %t252, label %bb43, label %bb44
bb43:
  %t255 = load ptr, ptr %s9
  %t256 = icmp eq ptr %t255, @__olang_slot_chunk
  %t257 = getelementptr %olang.scope, ptr %s9, i32 0, i32 2
  %t258 = load ptr, ptr %t257
  %t259 = select i1 %t256, ptr %t258, ptr %s9
  store %olang.scope zeroinitializer, ptr %t254
  store ptr @__olang_slot_chunk, ptr %t254
  %t260 = getelementptr %olang.scope, ptr %t254, i32 0, i32 2
  store ptr %t259, ptr %t260
  %t261 = getelementptr %olang.slotscope, ptr %t254, i32 0, i32 1
  store i64 0, ptr %t261
  %t262 = ptrtoint ptr %t254 to i64
  store i64 %t262, ptr %l120, !tbaa !24
  br label %bb44
bb44:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d91, i32 0, i32 1) }, ptr %l122, !tbaa !27
  %t263 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t263, ptr %l123, !tbaa !27
  %t264 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 0
  store i64 %t265, ptr %l124, !tbaa !24
  %t266 = load i64, ptr %l124, !tbaa !24
  %t267 = mul i64 %t266, 1
  %t268 = load i64, ptr %l120
  %t269 = inttoptr i64 %t268 to ptr
  %t270 = call ptr @__olang_held_alloc(ptr %t269, i64 %t267)
  %t271 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t270, 1
  store { i64, ptr } %t272, ptr %l125, !tbaa !27
  %t273 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t274 = load ptr, ptr %t273, !tbaa !27
  %t275 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t276 = load ptr, ptr %t275, !tbaa !27
  %t277 = load i64, ptr %l124, !tbaa !24
  %t278 = mul i64 %t277, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t274, ptr %t276, i64 %t278, i1 false)
  %t279 = call ptr @__olang_scope_hold(ptr %s9)
  %t280 = ptrtoint ptr %t279 to i64
  store i64 %t280, ptr %l126, !tbaa !24
  %t281 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_204_3e_2e_2d1
  br i1 %t281, label %bb45, label %bb46
bb45:
  %t284 = load ptr, ptr %s9
  %t285 = icmp eq ptr %t284, @__olang_slot_chunk
  %t286 = getelementptr %olang.scope, ptr %s9, i32 0, i32 2
  %t287 = load ptr, ptr %t286
  %t288 = select i1 %t285, ptr %t287, ptr %s9
  store %olang.scope zeroinitializer, ptr %t283
  store ptr @__olang_slot_chunk, ptr %t283
  %t289 = getelementptr %olang.scope, ptr %t283, i32 0, i32 2
  store ptr %t288, ptr %t289
  %t290 = getelementptr %olang.slotscope, ptr %t283, i32 0, i32 1
  store i64 0, ptr %t290
  %t291 = ptrtoint ptr %t283 to i64
  store i64 %t291, ptr %l126, !tbaa !24
  br label %bb46
bb46:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) }, ptr %l128, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t292, ptr %l129, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 0
  store i64 %t294, ptr %l130, !tbaa !24
  %t295 = load i64, ptr %l130, !tbaa !24
  %t296 = mul i64 %t295, 1
  %t297 = load i64, ptr %l126
  %t298 = inttoptr i64 %t297 to ptr
  %t299 = call ptr @__olang_held_alloc(ptr %t298, i64 %t296)
  %t300 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, ptr } %t301, ptr %l131, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l131, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = load i64, ptr %l130, !tbaa !24
  %t307 = mul i64 %t306, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t303, ptr %t305, i64 %t307, i1 false)
  %t308 = call ptr @__olang_scope_hold(ptr %s9)
  %t309 = ptrtoint ptr %t308 to i64
  store i64 %t309, ptr %l132, !tbaa !24
  %t310 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_204_3e_2e_2d1
  br i1 %t310, label %bb47, label %bb48
bb47:
  %t313 = load ptr, ptr %s9
  %t314 = icmp eq ptr %t313, @__olang_slot_chunk
  %t315 = getelementptr %olang.scope, ptr %s9, i32 0, i32 2
  %t316 = load ptr, ptr %t315
  %t317 = select i1 %t314, ptr %t316, ptr %s9
  store %olang.scope zeroinitializer, ptr %t312
  store ptr @__olang_slot_chunk, ptr %t312
  %t318 = getelementptr %olang.scope, ptr %t312, i32 0, i32 2
  store ptr %t317, ptr %t318
  %t319 = getelementptr %olang.slotscope, ptr %t312, i32 0, i32 1
  store i64 0, ptr %t319
  %t320 = ptrtoint ptr %t312 to i64
  store i64 %t320, ptr %l132, !tbaa !24
  br label %bb48
bb48:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %l134, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t321, ptr %l135, !tbaa !27
  %t322 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t322, 0
  store i64 %t323, ptr %l136, !tbaa !24
  %t324 = load i64, ptr %l136, !tbaa !24
  %t325 = mul i64 %t324, 1
  %t326 = load i64, ptr %l132
  %t327 = inttoptr i64 %t326 to ptr
  %t328 = call ptr @__olang_held_alloc(ptr %t327, i64 %t325)
  %t329 = insertvalue { i64, ptr } undef, i64 %t324, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  store { i64, ptr } %t330, ptr %l137, !tbaa !27
  %t331 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = load i64, ptr %l136, !tbaa !24
  %t336 = mul i64 %t335, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t332, ptr %t334, i64 %t336, i1 false)
  %t337 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t338 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } %t337, 0
  %t339 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t340 = insertvalue [4 x { i64, ptr }] %t338, { i64, ptr } %t339, 1
  %t341 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t342 = insertvalue [4 x { i64, ptr }] %t340, { i64, ptr } %t341, 2
  %t343 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t344 = insertvalue [4 x { i64, ptr }] %t342, { i64, ptr } %t343, 3
  %t346 = call ptr @__olang_scope_alloc_a(ptr %s9, i64 64, i64 8)
  store [4 x { i64, ptr }] %t344, ptr %t346
  store ptr %t346, ptr %l15
  store i64 0, ptr %l16, !tbaa !24
  %t348 = load ptr, ptr %l15
  store i64 4, ptr %l17, !tbaa !24
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s10
  %t351 = load i64, ptr %l16, !tbaa !24
  %t352 = load i64, ptr %l17, !tbaa !24
  %t355 = icmp slt i64 %t351, %t352
  %t357 = xor i1 %t355, true
  br i1 %t357, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t359 = load ptr, ptr %l15
  %t360 = load i64, ptr %l16, !tbaa !24
  %t363 = getelementptr [4 x { i64, ptr }], ptr %t359, i64 0, i64 %t360
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !37
  store { i64, ptr } %t364, ptr %l148, !tbaa !27
  %t365 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t366 = extractvalue { i64, ptr } %t365, 0
  store i64 %t366, ptr %l149, !tbaa !24
  %t367 = load i64, ptr %l149, !tbaa !24
  %t368 = mul i64 %t367, 1
  %t369 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t368)
  %t370 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  store { i64, ptr } %t371, ptr %l150, !tbaa !27
  %t372 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t373 = load ptr, ptr %t372, !tbaa !27
  %t374 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t375 = load ptr, ptr %t374, !tbaa !27
  %t376 = load i64, ptr %l149, !tbaa !24
  %t377 = mul i64 %t376, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t373, ptr %t375, i64 %t377, i1 false)
  %t378 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t378, ptr %lp18
  %t379 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t380 = load ptr, ptr %lp18
  store { i64, ptr } %t379, ptr %t380, !tbaa !27
  %t381 = load ptr, ptr %l1, !tbaa !29
  %t382 = load ptr, ptr %lp18
  %t383 = load { i64, ptr }, ptr %t382, !tbaa !27
  %t384 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v1, ptr %s10, ptr %t381, { i64, ptr } %t383, i64 %t384, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s10)
  br label %bb54
bb54:
  %t388 = load i64, ptr %l16, !tbaa !24
  %t391 = add i64 %t388, 1
  store i64 %t391, ptr %l16, !tbaa !24
  br label %bb49
bb55:
  call void @__olang_scope_close(ptr %s9)
  br label %bb56
bb56:
  %t393 = load ptr, ptr %l3, !tbaa !29
  %t395 = icmp eq ptr %t393, null
  br i1 %t395, label %bb57, label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_ccdc4e079738e147_db8abba82ff0d973)
  unreachable
bb58:
  br label %bb59
bb59:
  %t397 = load ptr, ptr %l3, !tbaa !29
  %t400 = getelementptr %"compiler/check:Checker", ptr %t397, i32 0, i32 1
  %t401 = load ptr, ptr %t400, !tbaa !29
  %t403 = getelementptr %"compiler/generic:Program", ptr %t401, i32 0, i32 2
  %t404 = load i32, ptr %l8, !tbaa !23
  %t407 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %t403, i32 %t404)
  store i1 %t407, ptr %l164
  br label %bb60
bb60:
  %t408 = load i1, ptr %l164, !tbaa !21
  br i1 %t408, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s12
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t410 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v1, ptr %s12, ptr %t409, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d95, i32 0, i32 1) }, i64 %t410, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d96, i32 0, i32 1) })
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t413 = load ptr, ptr %l3, !tbaa !29
  %t415 = icmp eq ptr %t413, null
  br i1 %t415, label %bb65, label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_fdfd5472c10825a_eabe36e5f7d3d64e)
  unreachable
bb66:
  br label %bb67
bb67:
  %t417 = load ptr, ptr %l3, !tbaa !29
  %t420 = getelementptr %"compiler/check:Checker", ptr %t417, i32 0, i32 1
  %t421 = load ptr, ptr %t420, !tbaa !29
  %t423 = getelementptr %"compiler/generic:Program", ptr %t421, i32 0, i32 2
  %t424 = load i32, ptr %l8, !tbaa !23
  %t427 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %t423, i32 %t424)
  store i1 %t427, ptr %l174
  br label %bb68
bb68:
  %t428 = load i1, ptr %l174, !tbaa !21
  br i1 %t428, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s13
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t430 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v1, ptr %s13, ptr %t429, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d97, i32 0, i32 1) }, i64 %t430, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d98, i32 0, i32 1) })
  br label %bb71
bb70:
  br label %bb72
bb71:
  call void @__olang_scope_close(ptr %s13)
  br label %bb72
bb72:
  %t433 = load ptr, ptr %l3, !tbaa !29
  %t435 = icmp eq ptr %t433, null
  br i1 %t435, label %bb73, label %bb74
bb73:
  call void @__olang_check_failed(ptr @olang_loc_65c34788fd63a3e1_4b900862c48225f5)
  unreachable
bb74:
  br label %bb75
bb75:
  %t437 = load ptr, ptr %l3, !tbaa !29
  %t440 = getelementptr %"compiler/check:Checker", ptr %t437, i32 0, i32 1
  %t441 = load ptr, ptr %t440, !tbaa !29
  %t443 = getelementptr %"compiler/generic:Program", ptr %t441, i32 0, i32 2
  %t444 = load i32, ptr %l8, !tbaa !23
  %t447 = call i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %t443, i32 %t444)
  store i1 %t447, ptr %l184
  br label %bb76
bb76:
  %t448 = load i1, ptr %l184, !tbaa !21
  %t449 = xor i1 %t448, true
  br i1 %t449, label %bb77, label %bb78
bb77:
  br label %ret
bb78:
  br label %bb79
bb79:
  store %olang.scope zeroinitializer, ptr %s15
  %t451 = call ptr @__olang_scope_hold(ptr %s15)
  %t452 = ptrtoint ptr %t451 to i64
  store i64 %t452, ptr %l186, !tbaa !24
  %t453 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_206_3e_2e_2d1
  br i1 %t453, label %bb80, label %bb81
bb80:
  %t456 = load ptr, ptr %s15
  %t457 = icmp eq ptr %t456, @__olang_slot_chunk
  %t458 = getelementptr %olang.scope, ptr %s15, i32 0, i32 2
  %t459 = load ptr, ptr %t458
  %t460 = select i1 %t457, ptr %t459, ptr %s15
  store %olang.scope zeroinitializer, ptr %t455
  store ptr @__olang_slot_chunk, ptr %t455
  %t461 = getelementptr %olang.scope, ptr %t455, i32 0, i32 2
  store ptr %t460, ptr %t461
  %t462 = getelementptr %olang.slotscope, ptr %t455, i32 0, i32 1
  store i64 0, ptr %t462
  %t463 = ptrtoint ptr %t455 to i64
  store i64 %t463, ptr %l186, !tbaa !24
  br label %bb81
bb81:
  store { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d99, i32 0, i32 1) }, ptr %l188, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l188, !tbaa !27
  store { i64, ptr } %t464, ptr %l189, !tbaa !27
  %t465 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t466 = extractvalue { i64, ptr } %t465, 0
  store i64 %t466, ptr %l190, !tbaa !24
  %t467 = load i64, ptr %l190, !tbaa !24
  %t468 = mul i64 %t467, 1
  %t469 = load i64, ptr %l186
  %t470 = inttoptr i64 %t469 to ptr
  %t471 = call ptr @__olang_held_alloc(ptr %t470, i64 %t468)
  %t472 = insertvalue { i64, ptr } undef, i64 %t467, 0
  %t473 = insertvalue { i64, ptr } %t472, ptr %t471, 1
  store { i64, ptr } %t473, ptr %l191, !tbaa !27
  %t474 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t477 = load ptr, ptr %t476, !tbaa !27
  %t478 = load i64, ptr %l190, !tbaa !24
  %t479 = mul i64 %t478, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t475, ptr %t477, i64 %t479, i1 false)
  %t480 = call ptr @__olang_scope_hold(ptr %s15)
  %t481 = ptrtoint ptr %t480 to i64
  store i64 %t481, ptr %l192, !tbaa !24
  %t482 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_206_3e_2e_2d1
  br i1 %t482, label %bb82, label %bb83
bb82:
  %t485 = load ptr, ptr %s15
  %t486 = icmp eq ptr %t485, @__olang_slot_chunk
  %t487 = getelementptr %olang.scope, ptr %s15, i32 0, i32 2
  %t488 = load ptr, ptr %t487
  %t489 = select i1 %t486, ptr %t488, ptr %s15
  store %olang.scope zeroinitializer, ptr %t484
  store ptr @__olang_slot_chunk, ptr %t484
  %t490 = getelementptr %olang.scope, ptr %t484, i32 0, i32 2
  store ptr %t489, ptr %t490
  %t491 = getelementptr %olang.slotscope, ptr %t484, i32 0, i32 1
  store i64 0, ptr %t491
  %t492 = ptrtoint ptr %t484 to i64
  store i64 %t492, ptr %l192, !tbaa !24
  br label %bb83
bb83:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d100, i32 0, i32 1) }, ptr %l194, !tbaa !27
  %t493 = load { i64, ptr }, ptr %l194, !tbaa !27
  store { i64, ptr } %t493, ptr %l195, !tbaa !27
  %t494 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t495 = extractvalue { i64, ptr } %t494, 0
  store i64 %t495, ptr %l196, !tbaa !24
  %t496 = load i64, ptr %l196, !tbaa !24
  %t497 = mul i64 %t496, 1
  %t498 = load i64, ptr %l192
  %t499 = inttoptr i64 %t498 to ptr
  %t500 = call ptr @__olang_held_alloc(ptr %t499, i64 %t497)
  %t501 = insertvalue { i64, ptr } undef, i64 %t496, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  store { i64, ptr } %t502, ptr %l197, !tbaa !27
  %t503 = getelementptr { i64, ptr }, ptr %l197, i32 0, i32 1
  %t504 = load ptr, ptr %t503, !tbaa !27
  %t505 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !27
  %t507 = load i64, ptr %l196, !tbaa !24
  %t508 = mul i64 %t507, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t504, ptr %t506, i64 %t508, i1 false)
  %t509 = call ptr @__olang_scope_hold(ptr %s15)
  %t510 = ptrtoint ptr %t509 to i64
  store i64 %t510, ptr %l198, !tbaa !24
  %t511 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_206_3e_2e_2d1
  br i1 %t511, label %bb84, label %bb85
bb84:
  %t514 = load ptr, ptr %s15
  %t515 = icmp eq ptr %t514, @__olang_slot_chunk
  %t516 = getelementptr %olang.scope, ptr %s15, i32 0, i32 2
  %t517 = load ptr, ptr %t516
  %t518 = select i1 %t515, ptr %t517, ptr %s15
  store %olang.scope zeroinitializer, ptr %t513
  store ptr @__olang_slot_chunk, ptr %t513
  %t519 = getelementptr %olang.scope, ptr %t513, i32 0, i32 2
  store ptr %t518, ptr %t519
  %t520 = getelementptr %olang.slotscope, ptr %t513, i32 0, i32 1
  store i64 0, ptr %t520
  %t521 = ptrtoint ptr %t513 to i64
  store i64 %t521, ptr %l198, !tbaa !24
  br label %bb85
bb85:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d101, i32 0, i32 1) }, ptr %l200, !tbaa !27
  %t522 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t522, ptr %l201, !tbaa !27
  %t523 = load { i64, ptr }, ptr %l201, !tbaa !27
  %t524 = extractvalue { i64, ptr } %t523, 0
  store i64 %t524, ptr %l202, !tbaa !24
  %t525 = load i64, ptr %l202, !tbaa !24
  %t526 = mul i64 %t525, 1
  %t527 = load i64, ptr %l198
  %t528 = inttoptr i64 %t527 to ptr
  %t529 = call ptr @__olang_held_alloc(ptr %t528, i64 %t526)
  %t530 = insertvalue { i64, ptr } undef, i64 %t525, 0
  %t531 = insertvalue { i64, ptr } %t530, ptr %t529, 1
  store { i64, ptr } %t531, ptr %l203, !tbaa !27
  %t532 = getelementptr { i64, ptr }, ptr %l203, i32 0, i32 1
  %t533 = load ptr, ptr %t532, !tbaa !27
  %t534 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t535 = load ptr, ptr %t534, !tbaa !27
  %t536 = load i64, ptr %l202, !tbaa !24
  %t537 = mul i64 %t536, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t533, ptr %t535, i64 %t537, i1 false)
  %t538 = call ptr @__olang_scope_hold(ptr %s15)
  %t539 = ptrtoint ptr %t538 to i64
  store i64 %t539, ptr %l204, !tbaa !24
  %t540 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_206_3e_2e_2d1
  br i1 %t540, label %bb86, label %bb87
bb86:
  %t543 = load ptr, ptr %s15
  %t544 = icmp eq ptr %t543, @__olang_slot_chunk
  %t545 = getelementptr %olang.scope, ptr %s15, i32 0, i32 2
  %t546 = load ptr, ptr %t545
  %t547 = select i1 %t544, ptr %t546, ptr %s15
  store %olang.scope zeroinitializer, ptr %t542
  store ptr @__olang_slot_chunk, ptr %t542
  %t548 = getelementptr %olang.scope, ptr %t542, i32 0, i32 2
  store ptr %t547, ptr %t548
  %t549 = getelementptr %olang.slotscope, ptr %t542, i32 0, i32 1
  store i64 0, ptr %t549
  %t550 = ptrtoint ptr %t542 to i64
  store i64 %t550, ptr %l204, !tbaa !24
  br label %bb87
bb87:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d102, i32 0, i32 1) }, ptr %l206, !tbaa !27
  %t551 = load { i64, ptr }, ptr %l206, !tbaa !27
  store { i64, ptr } %t551, ptr %l207, !tbaa !27
  %t552 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t553 = extractvalue { i64, ptr } %t552, 0
  store i64 %t553, ptr %l208, !tbaa !24
  %t554 = load i64, ptr %l208, !tbaa !24
  %t555 = mul i64 %t554, 1
  %t556 = load i64, ptr %l204
  %t557 = inttoptr i64 %t556 to ptr
  %t558 = call ptr @__olang_held_alloc(ptr %t557, i64 %t555)
  %t559 = insertvalue { i64, ptr } undef, i64 %t554, 0
  %t560 = insertvalue { i64, ptr } %t559, ptr %t558, 1
  store { i64, ptr } %t560, ptr %l209, !tbaa !27
  %t561 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t562 = load ptr, ptr %t561, !tbaa !27
  %t563 = getelementptr { i64, ptr }, ptr %l207, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !27
  %t565 = load i64, ptr %l208, !tbaa !24
  %t566 = mul i64 %t565, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t562, ptr %t564, i64 %t566, i1 false)
  %t567 = call ptr @__olang_scope_hold(ptr %s15)
  %t568 = ptrtoint ptr %t567 to i64
  store i64 %t568, ptr %l210, !tbaa !24
  %t569 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_206_3e_2e_2d1
  br i1 %t569, label %bb88, label %bb89
bb88:
  %t572 = load ptr, ptr %s15
  %t573 = icmp eq ptr %t572, @__olang_slot_chunk
  %t574 = getelementptr %olang.scope, ptr %s15, i32 0, i32 2
  %t575 = load ptr, ptr %t574
  %t576 = select i1 %t573, ptr %t575, ptr %s15
  store %olang.scope zeroinitializer, ptr %t571
  store ptr @__olang_slot_chunk, ptr %t571
  %t577 = getelementptr %olang.scope, ptr %t571, i32 0, i32 2
  store ptr %t576, ptr %t577
  %t578 = getelementptr %olang.slotscope, ptr %t571, i32 0, i32 1
  store i64 0, ptr %t578
  %t579 = ptrtoint ptr %t571 to i64
  store i64 %t579, ptr %l210, !tbaa !24
  br label %bb89
bb89:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d103, i32 0, i32 1) }, ptr %l212, !tbaa !27
  %t580 = load { i64, ptr }, ptr %l212, !tbaa !27
  store { i64, ptr } %t580, ptr %l213, !tbaa !27
  %t581 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t582 = extractvalue { i64, ptr } %t581, 0
  store i64 %t582, ptr %l214, !tbaa !24
  %t583 = load i64, ptr %l214, !tbaa !24
  %t584 = mul i64 %t583, 1
  %t585 = load i64, ptr %l210
  %t586 = inttoptr i64 %t585 to ptr
  %t587 = call ptr @__olang_held_alloc(ptr %t586, i64 %t584)
  %t588 = insertvalue { i64, ptr } undef, i64 %t583, 0
  %t589 = insertvalue { i64, ptr } %t588, ptr %t587, 1
  store { i64, ptr } %t589, ptr %l215, !tbaa !27
  %t590 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t591 = load ptr, ptr %t590, !tbaa !27
  %t592 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t593 = load ptr, ptr %t592, !tbaa !27
  %t594 = load i64, ptr %l214, !tbaa !24
  %t595 = mul i64 %t594, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t591, ptr %t593, i64 %t595, i1 false)
  %t596 = call ptr @__olang_scope_hold(ptr %s15)
  %t597 = ptrtoint ptr %t596 to i64
  store i64 %t597, ptr %l216, !tbaa !24
  %t598 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_206_3e_2e_2d1
  br i1 %t598, label %bb90, label %bb91
bb90:
  %t601 = load ptr, ptr %s15
  %t602 = icmp eq ptr %t601, @__olang_slot_chunk
  %t603 = getelementptr %olang.scope, ptr %s15, i32 0, i32 2
  %t604 = load ptr, ptr %t603
  %t605 = select i1 %t602, ptr %t604, ptr %s15
  store %olang.scope zeroinitializer, ptr %t600
  store ptr @__olang_slot_chunk, ptr %t600
  %t606 = getelementptr %olang.scope, ptr %t600, i32 0, i32 2
  store ptr %t605, ptr %t606
  %t607 = getelementptr %olang.slotscope, ptr %t600, i32 0, i32 1
  store i64 0, ptr %t607
  %t608 = ptrtoint ptr %t600 to i64
  store i64 %t608, ptr %l216, !tbaa !24
  br label %bb91
bb91:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d104, i32 0, i32 1) }, ptr %l218, !tbaa !27
  %t609 = load { i64, ptr }, ptr %l218, !tbaa !27
  store { i64, ptr } %t609, ptr %l219, !tbaa !27
  %t610 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t611 = extractvalue { i64, ptr } %t610, 0
  store i64 %t611, ptr %l220, !tbaa !24
  %t612 = load i64, ptr %l220, !tbaa !24
  %t613 = mul i64 %t612, 1
  %t614 = load i64, ptr %l216
  %t615 = inttoptr i64 %t614 to ptr
  %t616 = call ptr @__olang_held_alloc(ptr %t615, i64 %t613)
  %t617 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  store { i64, ptr } %t618, ptr %l221, !tbaa !27
  %t619 = getelementptr { i64, ptr }, ptr %l221, i32 0, i32 1
  %t620 = load ptr, ptr %t619, !tbaa !27
  %t621 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t622 = load ptr, ptr %t621, !tbaa !27
  %t623 = load i64, ptr %l220, !tbaa !24
  %t624 = mul i64 %t623, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t620, ptr %t622, i64 %t624, i1 false)
  %t625 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t626 = insertvalue [6 x { i64, ptr }] undef, { i64, ptr } %t625, 0
  %t627 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t628 = insertvalue [6 x { i64, ptr }] %t626, { i64, ptr } %t627, 1
  %t629 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t630 = insertvalue [6 x { i64, ptr }] %t628, { i64, ptr } %t629, 2
  %t631 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t632 = insertvalue [6 x { i64, ptr }] %t630, { i64, ptr } %t631, 3
  %t633 = load { i64, ptr }, ptr %l215, !tbaa !27
  %t634 = insertvalue [6 x { i64, ptr }] %t632, { i64, ptr } %t633, 4
  %t635 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t636 = insertvalue [6 x { i64, ptr }] %t634, { i64, ptr } %t635, 5
  %t638 = call ptr @__olang_scope_alloc_a(ptr %s15, i64 96, i64 8)
  store [6 x { i64, ptr }] %t636, ptr %t638
  store ptr %t638, ptr %l19
  store i64 0, ptr %l20, !tbaa !24
  %t640 = load ptr, ptr %l19
  store i64 6, ptr %l21, !tbaa !24
  br label %bb92
bb92:
  store %olang.scope zeroinitializer, ptr %s16
  %t643 = load i64, ptr %l20, !tbaa !24
  %t644 = load i64, ptr %l21, !tbaa !24
  %t647 = icmp slt i64 %t643, %t644
  %t649 = xor i1 %t647, true
  br i1 %t649, label %bb93, label %bb94
bb93:
  call void @__olang_scope_close(ptr %s16)
  br label %bb98
bb94:
  br label %bb95
bb95:
  %t651 = load ptr, ptr %l19
  %t652 = load i64, ptr %l20, !tbaa !24
  %t655 = getelementptr [6 x { i64, ptr }], ptr %t651, i64 0, i64 %t652
  %t656 = load { i64, ptr }, ptr %t655, !tbaa !37
  store { i64, ptr } %t656, ptr %l232, !tbaa !27
  %t657 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t658 = extractvalue { i64, ptr } %t657, 0
  store i64 %t658, ptr %l233, !tbaa !24
  %t659 = load i64, ptr %l233, !tbaa !24
  %t660 = mul i64 %t659, 1
  %t661 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t660)
  %t662 = insertvalue { i64, ptr } undef, i64 %t659, 0
  %t663 = insertvalue { i64, ptr } %t662, ptr %t661, 1
  store { i64, ptr } %t663, ptr %l234, !tbaa !27
  %t664 = getelementptr { i64, ptr }, ptr %l234, i32 0, i32 1
  %t665 = load ptr, ptr %t664, !tbaa !27
  %t666 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t667 = load ptr, ptr %t666, !tbaa !27
  %t668 = load i64, ptr %l233, !tbaa !24
  %t669 = mul i64 %t668, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t665, ptr %t667, i64 %t669, i1 false)
  %t670 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t670, ptr %lp22
  %t671 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t672 = load ptr, ptr %lp22
  store { i64, ptr } %t671, ptr %t672, !tbaa !27
  %t673 = load ptr, ptr %l1, !tbaa !29
  %t674 = load ptr, ptr %lp22
  %t675 = load { i64, ptr }, ptr %t674, !tbaa !27
  %t676 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v1, ptr %s16, ptr %t673, { i64, ptr } %t675, i64 %t676, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d105, i32 0, i32 1) })
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s16)
  br label %bb97
bb97:
  %t680 = load i64, ptr %l20, !tbaa !24
  %t683 = add i64 %t680, 1
  store i64 %t683, ptr %l20, !tbaa !24
  br label %bb92
bb98:
  call void @__olang_scope_close(ptr %s15)
  store %olang.scope zeroinitializer, ptr %s18
  %t685 = call ptr @__olang_scope_hold(ptr %s18)
  %t686 = ptrtoint ptr %t685 to i64
  store i64 %t686, ptr %l241, !tbaa !24
  %t687 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_205_3e_2e_2d1
  br i1 %t687, label %bb99, label %bb100
bb99:
  %t690 = load ptr, ptr %s18
  %t691 = icmp eq ptr %t690, @__olang_slot_chunk
  %t692 = getelementptr %olang.scope, ptr %s18, i32 0, i32 2
  %t693 = load ptr, ptr %t692
  %t694 = select i1 %t691, ptr %t693, ptr %s18
  store %olang.scope zeroinitializer, ptr %t689
  store ptr @__olang_slot_chunk, ptr %t689
  %t695 = getelementptr %olang.scope, ptr %t689, i32 0, i32 2
  store ptr %t694, ptr %t695
  %t696 = getelementptr %olang.slotscope, ptr %t689, i32 0, i32 1
  store i64 0, ptr %t696
  %t697 = ptrtoint ptr %t689 to i64
  store i64 %t697, ptr %l241, !tbaa !24
  br label %bb100
bb100:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d106, i32 0, i32 1) }, ptr %l243, !tbaa !27
  %t698 = load { i64, ptr }, ptr %l243, !tbaa !27
  store { i64, ptr } %t698, ptr %l244, !tbaa !27
  %t699 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t700 = extractvalue { i64, ptr } %t699, 0
  store i64 %t700, ptr %l245, !tbaa !24
  %t701 = load i64, ptr %l245, !tbaa !24
  %t702 = mul i64 %t701, 1
  %t703 = load i64, ptr %l241
  %t704 = inttoptr i64 %t703 to ptr
  %t705 = call ptr @__olang_held_alloc(ptr %t704, i64 %t702)
  %t706 = insertvalue { i64, ptr } undef, i64 %t701, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  store { i64, ptr } %t707, ptr %l246, !tbaa !27
  %t708 = getelementptr { i64, ptr }, ptr %l246, i32 0, i32 1
  %t709 = load ptr, ptr %t708, !tbaa !27
  %t710 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t711 = load ptr, ptr %t710, !tbaa !27
  %t712 = load i64, ptr %l245, !tbaa !24
  %t713 = mul i64 %t712, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t709, ptr %t711, i64 %t713, i1 false)
  %t714 = call ptr @__olang_scope_hold(ptr %s18)
  %t715 = ptrtoint ptr %t714 to i64
  store i64 %t715, ptr %l247, !tbaa !24
  %t716 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_205_3e_2e_2d1
  br i1 %t716, label %bb101, label %bb102
bb101:
  %t719 = load ptr, ptr %s18
  %t720 = icmp eq ptr %t719, @__olang_slot_chunk
  %t721 = getelementptr %olang.scope, ptr %s18, i32 0, i32 2
  %t722 = load ptr, ptr %t721
  %t723 = select i1 %t720, ptr %t722, ptr %s18
  store %olang.scope zeroinitializer, ptr %t718
  store ptr @__olang_slot_chunk, ptr %t718
  %t724 = getelementptr %olang.scope, ptr %t718, i32 0, i32 2
  store ptr %t723, ptr %t724
  %t725 = getelementptr %olang.slotscope, ptr %t718, i32 0, i32 1
  store i64 0, ptr %t725
  %t726 = ptrtoint ptr %t718 to i64
  store i64 %t726, ptr %l247, !tbaa !24
  br label %bb102
bb102:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d107, i32 0, i32 1) }, ptr %l249, !tbaa !27
  %t727 = load { i64, ptr }, ptr %l249, !tbaa !27
  store { i64, ptr } %t727, ptr %l250, !tbaa !27
  %t728 = load { i64, ptr }, ptr %l250, !tbaa !27
  %t729 = extractvalue { i64, ptr } %t728, 0
  store i64 %t729, ptr %l251, !tbaa !24
  %t730 = load i64, ptr %l251, !tbaa !24
  %t731 = mul i64 %t730, 1
  %t732 = load i64, ptr %l247
  %t733 = inttoptr i64 %t732 to ptr
  %t734 = call ptr @__olang_held_alloc(ptr %t733, i64 %t731)
  %t735 = insertvalue { i64, ptr } undef, i64 %t730, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t734, 1
  store { i64, ptr } %t736, ptr %l252, !tbaa !27
  %t737 = getelementptr { i64, ptr }, ptr %l252, i32 0, i32 1
  %t738 = load ptr, ptr %t737, !tbaa !27
  %t739 = getelementptr { i64, ptr }, ptr %l250, i32 0, i32 1
  %t740 = load ptr, ptr %t739, !tbaa !27
  %t741 = load i64, ptr %l251, !tbaa !24
  %t742 = mul i64 %t741, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t738, ptr %t740, i64 %t742, i1 false)
  %t743 = call ptr @__olang_scope_hold(ptr %s18)
  %t744 = ptrtoint ptr %t743 to i64
  store i64 %t744, ptr %l253, !tbaa !24
  %t745 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_205_3e_2e_2d1
  br i1 %t745, label %bb103, label %bb104
bb103:
  %t748 = load ptr, ptr %s18
  %t749 = icmp eq ptr %t748, @__olang_slot_chunk
  %t750 = getelementptr %olang.scope, ptr %s18, i32 0, i32 2
  %t751 = load ptr, ptr %t750
  %t752 = select i1 %t749, ptr %t751, ptr %s18
  store %olang.scope zeroinitializer, ptr %t747
  store ptr @__olang_slot_chunk, ptr %t747
  %t753 = getelementptr %olang.scope, ptr %t747, i32 0, i32 2
  store ptr %t752, ptr %t753
  %t754 = getelementptr %olang.slotscope, ptr %t747, i32 0, i32 1
  store i64 0, ptr %t754
  %t755 = ptrtoint ptr %t747 to i64
  store i64 %t755, ptr %l253, !tbaa !24
  br label %bb104
bb104:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d108, i32 0, i32 1) }, ptr %l255, !tbaa !27
  %t756 = load { i64, ptr }, ptr %l255, !tbaa !27
  store { i64, ptr } %t756, ptr %l256, !tbaa !27
  %t757 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t758 = extractvalue { i64, ptr } %t757, 0
  store i64 %t758, ptr %l257, !tbaa !24
  %t759 = load i64, ptr %l257, !tbaa !24
  %t760 = mul i64 %t759, 1
  %t761 = load i64, ptr %l253
  %t762 = inttoptr i64 %t761 to ptr
  %t763 = call ptr @__olang_held_alloc(ptr %t762, i64 %t760)
  %t764 = insertvalue { i64, ptr } undef, i64 %t759, 0
  %t765 = insertvalue { i64, ptr } %t764, ptr %t763, 1
  store { i64, ptr } %t765, ptr %l258, !tbaa !27
  %t766 = getelementptr { i64, ptr }, ptr %l258, i32 0, i32 1
  %t767 = load ptr, ptr %t766, !tbaa !27
  %t768 = getelementptr { i64, ptr }, ptr %l256, i32 0, i32 1
  %t769 = load ptr, ptr %t768, !tbaa !27
  %t770 = load i64, ptr %l257, !tbaa !24
  %t771 = mul i64 %t770, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t767, ptr %t769, i64 %t771, i1 false)
  %t772 = call ptr @__olang_scope_hold(ptr %s18)
  %t773 = ptrtoint ptr %t772 to i64
  store i64 %t773, ptr %l259, !tbaa !24
  %t774 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_205_3e_2e_2d1
  br i1 %t774, label %bb105, label %bb106
bb105:
  %t777 = load ptr, ptr %s18
  %t778 = icmp eq ptr %t777, @__olang_slot_chunk
  %t779 = getelementptr %olang.scope, ptr %s18, i32 0, i32 2
  %t780 = load ptr, ptr %t779
  %t781 = select i1 %t778, ptr %t780, ptr %s18
  store %olang.scope zeroinitializer, ptr %t776
  store ptr @__olang_slot_chunk, ptr %t776
  %t782 = getelementptr %olang.scope, ptr %t776, i32 0, i32 2
  store ptr %t781, ptr %t782
  %t783 = getelementptr %olang.slotscope, ptr %t776, i32 0, i32 1
  store i64 0, ptr %t783
  %t784 = ptrtoint ptr %t776 to i64
  store i64 %t784, ptr %l259, !tbaa !24
  br label %bb106
bb106:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d109, i32 0, i32 1) }, ptr %l261, !tbaa !27
  %t785 = load { i64, ptr }, ptr %l261, !tbaa !27
  store { i64, ptr } %t785, ptr %l262, !tbaa !27
  %t786 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t787 = extractvalue { i64, ptr } %t786, 0
  store i64 %t787, ptr %l263, !tbaa !24
  %t788 = load i64, ptr %l263, !tbaa !24
  %t789 = mul i64 %t788, 1
  %t790 = load i64, ptr %l259
  %t791 = inttoptr i64 %t790 to ptr
  %t792 = call ptr @__olang_held_alloc(ptr %t791, i64 %t789)
  %t793 = insertvalue { i64, ptr } undef, i64 %t788, 0
  %t794 = insertvalue { i64, ptr } %t793, ptr %t792, 1
  store { i64, ptr } %t794, ptr %l264, !tbaa !27
  %t795 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t796 = load ptr, ptr %t795, !tbaa !27
  %t797 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t798 = load ptr, ptr %t797, !tbaa !27
  %t799 = load i64, ptr %l263, !tbaa !24
  %t800 = mul i64 %t799, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t796, ptr %t798, i64 %t800, i1 false)
  %t801 = call ptr @__olang_scope_hold(ptr %s18)
  %t802 = ptrtoint ptr %t801 to i64
  store i64 %t802, ptr %l265, !tbaa !24
  %t803 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_205_3e_2e_2d1
  br i1 %t803, label %bb107, label %bb108
bb107:
  %t806 = load ptr, ptr %s18
  %t807 = icmp eq ptr %t806, @__olang_slot_chunk
  %t808 = getelementptr %olang.scope, ptr %s18, i32 0, i32 2
  %t809 = load ptr, ptr %t808
  %t810 = select i1 %t807, ptr %t809, ptr %s18
  store %olang.scope zeroinitializer, ptr %t805
  store ptr @__olang_slot_chunk, ptr %t805
  %t811 = getelementptr %olang.scope, ptr %t805, i32 0, i32 2
  store ptr %t810, ptr %t811
  %t812 = getelementptr %olang.slotscope, ptr %t805, i32 0, i32 1
  store i64 0, ptr %t812
  %t813 = ptrtoint ptr %t805 to i64
  store i64 %t813, ptr %l265, !tbaa !24
  br label %bb108
bb108:
  store { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d110, i32 0, i32 1) }, ptr %l267, !tbaa !27
  %t814 = load { i64, ptr }, ptr %l267, !tbaa !27
  store { i64, ptr } %t814, ptr %l268, !tbaa !27
  %t815 = load { i64, ptr }, ptr %l268, !tbaa !27
  %t816 = extractvalue { i64, ptr } %t815, 0
  store i64 %t816, ptr %l269, !tbaa !24
  %t817 = load i64, ptr %l269, !tbaa !24
  %t818 = mul i64 %t817, 1
  %t819 = load i64, ptr %l265
  %t820 = inttoptr i64 %t819 to ptr
  %t821 = call ptr @__olang_held_alloc(ptr %t820, i64 %t818)
  %t822 = insertvalue { i64, ptr } undef, i64 %t817, 0
  %t823 = insertvalue { i64, ptr } %t822, ptr %t821, 1
  store { i64, ptr } %t823, ptr %l270, !tbaa !27
  %t824 = getelementptr { i64, ptr }, ptr %l270, i32 0, i32 1
  %t825 = load ptr, ptr %t824, !tbaa !27
  %t826 = getelementptr { i64, ptr }, ptr %l268, i32 0, i32 1
  %t827 = load ptr, ptr %t826, !tbaa !27
  %t828 = load i64, ptr %l269, !tbaa !24
  %t829 = mul i64 %t828, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t825, ptr %t827, i64 %t829, i1 false)
  %t830 = load { i64, ptr }, ptr %l246, !tbaa !27
  %t831 = insertvalue [5 x { i64, ptr }] undef, { i64, ptr } %t830, 0
  %t832 = load { i64, ptr }, ptr %l252, !tbaa !27
  %t833 = insertvalue [5 x { i64, ptr }] %t831, { i64, ptr } %t832, 1
  %t834 = load { i64, ptr }, ptr %l258, !tbaa !27
  %t835 = insertvalue [5 x { i64, ptr }] %t833, { i64, ptr } %t834, 2
  %t836 = load { i64, ptr }, ptr %l264, !tbaa !27
  %t837 = insertvalue [5 x { i64, ptr }] %t835, { i64, ptr } %t836, 3
  %t838 = load { i64, ptr }, ptr %l270, !tbaa !27
  %t839 = insertvalue [5 x { i64, ptr }] %t837, { i64, ptr } %t838, 4
  %t841 = call ptr @__olang_scope_alloc_a(ptr %s18, i64 80, i64 8)
  store [5 x { i64, ptr }] %t839, ptr %t841
  store ptr %t841, ptr %l23
  store i64 0, ptr %l24, !tbaa !24
  %t843 = load ptr, ptr %l23
  store i64 5, ptr %l25, !tbaa !24
  br label %bb109
bb109:
  store %olang.scope zeroinitializer, ptr %s19
  %t846 = load i64, ptr %l24, !tbaa !24
  %t847 = load i64, ptr %l25, !tbaa !24
  %t850 = icmp slt i64 %t846, %t847
  %t852 = xor i1 %t850, true
  br i1 %t852, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s19)
  br label %bb115
bb111:
  br label %bb112
bb112:
  %t854 = load ptr, ptr %l23
  %t855 = load i64, ptr %l24, !tbaa !24
  %t858 = getelementptr [5 x { i64, ptr }], ptr %t854, i64 0, i64 %t855
  %t859 = load { i64, ptr }, ptr %t858, !tbaa !37
  store { i64, ptr } %t859, ptr %l281, !tbaa !27
  %t860 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t861 = extractvalue { i64, ptr } %t860, 0
  store i64 %t861, ptr %l282, !tbaa !24
  %t862 = load i64, ptr %l282, !tbaa !24
  %t863 = mul i64 %t862, 1
  %t864 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t863)
  %t865 = insertvalue { i64, ptr } undef, i64 %t862, 0
  %t866 = insertvalue { i64, ptr } %t865, ptr %t864, 1
  store { i64, ptr } %t866, ptr %l283, !tbaa !27
  %t867 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t868 = load ptr, ptr %t867, !tbaa !27
  %t869 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t870 = load ptr, ptr %t869, !tbaa !27
  %t871 = load i64, ptr %l282, !tbaa !24
  %t872 = mul i64 %t871, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t868, ptr %t870, i64 %t872, i1 false)
  %t873 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t873, ptr %lp26
  %t874 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t875 = load ptr, ptr %lp26
  store { i64, ptr } %t874, ptr %t875, !tbaa !27
  %t876 = load ptr, ptr %l1, !tbaa !29
  %t877 = load ptr, ptr %lp26
  %t878 = load { i64, ptr }, ptr %t877, !tbaa !27
  %t879 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v1, ptr %v1, ptr %s19, ptr %t876, { i64, ptr } %t878, i64 %t879, { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d111, i32 0, i32 1) })
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s19)
  br label %bb114
bb114:
  %t883 = load i64, ptr %l24, !tbaa !24
  %t886 = add i64 %t883, 1
  store i64 %t886, ptr %l24, !tbaa !24
  br label %bb109
bb115:
  call void @__olang_scope_close(ptr %s18)
  br label %ret
ret:
  ret void
}

define dso_local { i64, [6 x i64] } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etarget(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/names:Ref"
  %l8 = alloca i32
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca %"compiler/names:Entry"
  %l14 = alloca i64
  %l15 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca ptr
  %lp23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca ptr
  %l39 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l59 = alloca %"compiler/names:Ref"
  %l65 = alloca %"compiler/names:Ref"
  %l73 = alloca i64
  %l80 = alloca ptr
  %l84 = alloca ptr
  %l88 = alloca %"compiler/names:Entry"
  %l90 = alloca { i64, ptr }
  %l104 = alloca %"compiler/source:Span"
  %l109 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l123 = alloca ptr
  %l126 = alloca i64
  %l128 = alloca i64
  %l133 = alloca %"compiler/names:Entry"
  %l137 = alloca i1
  %l148 = alloca i64
  %l151 = alloca i1
  %l154 = alloca i1
  %l161 = alloca ptr
  %l176 = alloca %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20"
  %l192 = alloca i64
  %l196 = alloca i64
  %l199 = alloca i64
  %l223 = alloca i64
  %l232 = alloca ptr
  %l234 = alloca i1
  %l235 = alloca i1
  %l245 = alloca { i64, ptr }
  %l247 = alloca i1
  %l248 = alloca i1
  %l255 = alloca i1
  %l262 = alloca i1
  %l267 = alloca i1
  %l269 = alloca i64
  %l271 = alloca { i64, ptr }
  %l273 = alloca %"compiler/source:Span"
  %l282 = alloca i1
  %l292 = alloca { i64, ptr }
  %l294 = alloca i1
  %l302 = alloca i1
  %l309 = alloca i1
  %l314 = alloca i1
  %l316 = alloca i64
  %l318 = alloca { i64, ptr }
  %l320 = alloca %"compiler/source:Span"
  %l330 = alloca i64
  %l332 = alloca i64
  %l333 = alloca { i64, ptr }
  %l337 = alloca %"compiler/session:finder"
  %l343 = alloca i64
  %l345 = alloca i64
  %l350 = alloca ptr
  %l355 = alloca i1
  %l365 = alloca i1
  %s3 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, [6 x i64] }
  %t165 = alloca { i64, [6 x i64] }, align 8
  %t181 = alloca { i64, [6 x i64] }, align 8
  %t225 = alloca { i64, [6 x i64] }, align 8
  %t241 = alloca { i64, [6 x i64] }, align 8
  %t352 = alloca { i64, [6 x i64] }, align 8
  %t386 = alloca { i64, [6 x i64] }, align 8
  %t594 = alloca { i64, [6 x i64] }, align 8
  %t704 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store %"compiler/source:Span" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_d513bc439d44d6f6_9aa74f14fc08fdfa)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  store ptr %t17, ptr %l4, !tbaa !29
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/session:Analysis", ptr %t19, i32 0, i32 0
  %t22 = load ptr, ptr %t21, !tbaa !29
  %t24 = getelementptr %"compiler/load:Loader", ptr %t22, i32 0, i32 10
  %t25 = load i64, ptr %l1, !tbaa !24
  %t28 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v0, ptr %t24, i64 %t25)
  store ptr %t28, ptr %l39
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l39, !tbaa !29
  %t31 = getelementptr %"compiler/load:Module", ptr %t29, i32 0, i32 4
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t35 = load i64, ptr %l1, !tbaa !24
  %t38 = call { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v0, ptr %t34, i64 %t35)
  store { i64, ptr } %t38, ptr %l44
  br label %bb5
bb5:
  %t39 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t39, ptr %l45, !tbaa !27
  %t40 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  %t43 = sext i32 %t41 to i64
  store i64 %t43, ptr %l47, !tbaa !24
  %t44 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l49, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l50, !tbaa !24
  %t50 = load i64, ptr %l47, !tbaa !24
  %t51 = icmp sge i64 %t50, 0
  br i1 %t51, label %bb6, label %bb7
bb6:
  %t53 = load i64, ptr %l47, !tbaa !24
  %t54 = load i64, ptr %l49, !tbaa !24
  %t55 = icmp sle i64 %t53, %t54
  br i1 %t55, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb8:
  %t57 = load i64, ptr %l49, !tbaa !24
  %t58 = load i64, ptr %l50, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb10:
  %t61 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = load i64, ptr %l47, !tbaa !24
  %t64 = load i64, ptr %l49, !tbaa !24
  %t65 = getelementptr i8, ptr %t62, i64 %t63
  %t66 = sub i64 %t64, %t63
  %t67 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t65, 1
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = extractvalue { i64, ptr } %t68, 0
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @olang_textcopy(ptr %t72, ptr %t70, i64 %t71)
  %t73 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t75 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t75, ptr %lp6
  %t77 = load ptr, ptr %lp6
  store { i64, ptr } %t74, ptr %t77, !tbaa !27
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t79 = load i64, ptr %l5, !tbaa !24
  %t80 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t81 = load i32, ptr %t80, !tbaa !23
  %t85 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %t78, i64 %t79, i32 %t81)
  store %"compiler/names:Ref" %t85, ptr %l59
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_78ada93836b36c6b_7d0979891c04300f)
  unreachable
bb12:
  %t86 = load %"compiler/names:Ref", ptr %l59
  store %"compiler/names:Ref" %t86, ptr %l7
  %t87 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t88 = load i32, ptr %t87, !range !{i32 0, i32 9}
  %t90 = trunc i64 0 to i32
  %t91 = icmp eq i32 %t88, %t90
  br i1 %t91, label %bb13, label %bb14
bb13:
  %t93 = load ptr, ptr %l4, !tbaa !29
  %t94 = load i64, ptr %l5, !tbaa !24
  %t95 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t100 = call %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %t93, i64 %t94, i32 %t96)
  store %"compiler/names:Ref" %t100, ptr %l65
  br label %bb15
bb14:
  br label %bb16
bb15:
  %t101 = load %"compiler/names:Ref", ptr %l65
  store %"compiler/names:Ref" %t101, ptr %l7
  br label %bb16
bb16:
  %t102 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 0
  %t103 = load i32, ptr %t102, !range !{i32 0, i32 9}
  store i32 %t103, ptr %l8
  %t105 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t107 = trunc i64 3 to i32
  %t108 = icmp eq i32 %t105, %t107
  br i1 %t108, label %bb17, label %bb18
bb17:
  br label %bb23
bb18:
  %t110 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t112 = trunc i64 2 to i32
  %t113 = icmp eq i32 %t110, %t112
  br i1 %t113, label %bb19, label %bb20
bb19:
  br label %bb23
bb20:
  %t115 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t117 = trunc i64 4 to i32
  %t118 = icmp eq i32 %t115, %t117
  br i1 %t118, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb30
bb23:
  store %olang.scope zeroinitializer, ptr %s3
  %t120 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t121 = load i64, ptr %t120, !tbaa !24
  store i64 %t121, ptr %l73, !tbaa !24
  %t122 = load ptr, ptr %l3, !tbaa !29
  %t124 = icmp eq ptr %t122, null
  br i1 %t124, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_f729b95fcb28e588_e9118b2581b5934c)
  unreachable
bb25:
  br label %bb26
bb26:
  %t126 = load ptr, ptr %l3, !tbaa !29
  %t129 = getelementptr %"compiler/check:Checker", ptr %t126, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !29
  %t132 = getelementptr %"compiler/generic:Program", ptr %t130, i32 0, i32 0
  %t133 = load ptr, ptr %t132, !tbaa !29
  %t135 = getelementptr %"compiler/load:Loader", ptr %t133, i32 0, i32 3
  %t136 = load ptr, ptr %t135, !tbaa !29
  store ptr %t136, ptr %l80, !tbaa !29
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = getelementptr %"compiler/names:Resolver", ptr %t137, i32 0, i32 1
  %t140 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t139, i64 %t141)
  store ptr %t144, ptr %l84
  br label %bb27
bb27:
  %t145 = load ptr, ptr %l84, !tbaa !29
  %t147 = getelementptr %"compiler/names:Table", ptr %t145, i32 0, i32 0
  %t148 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t149 = load i64, ptr %t148, !tbaa !24
  %t152 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %s3, ptr %t147, i64 %t149)
  store %"compiler/names:Entry" %t152, ptr %l88
  br label %bb28
bb28:
  %t153 = getelementptr %"compiler/names:Entry", ptr %l88, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t157 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s3, ptr %t155, i32 %t154)
  store { i64, ptr } %t157, ptr %l90
  br label %bb29
bb29:
  %t158 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t161 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t160)
  call void @olang_textcopy(ptr %t161, ptr %t159, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t160, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [6 x i64] }, ptr %t165, i32 0, i32 0
  store i64 1, ptr %t166
  %t167 = load i64, ptr %l73, !tbaa !24
  %t168 = insertvalue { i64, { i64, ptr } } undef, i64 %t167, 0
  %t170 = insertvalue { i64, { i64, ptr } } %t168, { i64, ptr } %t163, 1
  %t171 = getelementptr { i64, [6 x i64] }, ptr %t165, i32 0, i32 1
  store { i64, { i64, ptr } } %t170, ptr %t171
  %t172 = load { i64, [6 x i64] }, ptr %t165
  call void @__olang_scope_close(ptr %s3)
  store { i64, [6 x i64] } %t172, ptr %rv
  br label %ret
bb30:
  %t174 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t176 = trunc i64 5 to i32
  %t177 = icmp eq i32 %t174, %t176
  br i1 %t177, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb34
bb33:
  %t179 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 1
  %t180 = load i64, ptr %t179, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t181
  %t182 = getelementptr { i64, [6 x i64] }, ptr %t181, i32 0, i32 0
  store i64 6, ptr %t182
  %t184 = insertvalue { i64 } undef, i64 %t180, 0
  %t185 = getelementptr { i64, [6 x i64] }, ptr %t181, i32 0, i32 1
  store { i64 } %t184, ptr %t185
  %t186 = load { i64, [6 x i64] }, ptr %t181
  store { i64, [6 x i64] } %t186, ptr %rv
  br label %ret
bb34:
  %t188 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t190 = trunc i64 1 to i32
  %t191 = icmp eq i32 %t188, %t190
  br i1 %t191, label %bb35, label %bb36
bb35:
  br label %bb39
bb36:
  %t193 = load i32, ptr %l8, !range !{i32 0, i32 9}
  %t195 = trunc i64 8 to i32
  %t196 = icmp eq i32 %t193, %t195
  br i1 %t196, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb45
bb39:
  %t198 = load ptr, ptr %l4, !tbaa !29
  %t199 = getelementptr %"compiler/names:Ref", ptr %l7, i32 0, i32 2
  %t200 = load i64, ptr %t199, !tbaa !24
  %t203 = call %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %t198, i64 %t200)
  store %"compiler/source:Span" %t203, ptr %l104
  br label %bb40
bb40:
  %t204 = load %"compiler/source:Span", ptr %l104
  store %"compiler/source:Span" %t204, ptr %l9
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t206 = load i64, ptr %l5, !tbaa !24
  %t207 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t208 = load i32, ptr %t207, !tbaa !23
  %t210 = sext i32 %t208 to i64
  %t214 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %t205, i64 %t206, i64 %t210)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t214, ptr %l109
  br label %bb41
bb41:
  %t215 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l109
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t215, ptr %l10
  %t216 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 0
  %t217 = load i64, ptr %t216, !tbaa !24
  %t219 = icmp sge i64 %t217, 0
  br i1 %t219, label %bb42, label %bb43
bb42:
  %t221 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 0
  %t222 = load i64, ptr %t221, !tbaa !24
  %t223 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l10, i32 0, i32 1
  %t224 = load i32, ptr %t223, !tbaa !23
  store { i64, [6 x i64] } zeroinitializer, ptr %t225
  %t226 = getelementptr { i64, [6 x i64] }, ptr %t225, i32 0, i32 0
  store i64 4, ptr %t226
  %t228 = insertvalue { i64, i32 } undef, i64 %t222, 0
  %t230 = insertvalue { i64, i32 } %t228, i32 %t224, 1
  %t231 = getelementptr { i64, [6 x i64] }, ptr %t225, i32 0, i32 1
  store { i64, i32 } %t230, ptr %t231
  %t232 = load { i64, [6 x i64] }, ptr %t225
  store { i64, [6 x i64] } %t232, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t234 = load i64, ptr %l1, !tbaa !24
  %t235 = getelementptr %"compiler/source:Span", ptr %l9, i32 0, i32 0
  %t236 = load i32, ptr %t235, !tbaa !23
  %t238 = sext i32 %t236 to i64
  %t239 = load ptr, ptr %lp6
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t241
  %t242 = getelementptr { i64, [6 x i64] }, ptr %t241, i32 0, i32 0
  store i64 5, ptr %t242
  %t244 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } undef, i64 %t234, 0
  %t246 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t244, i64 %t238, 1
  %t247 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t246, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d112, i32 0, i32 1) }, 2
  %t249 = insertvalue { i64, i64, { i64, ptr }, { i64, ptr } } %t247, { i64, ptr } %t240, 3
  %t250 = getelementptr { i64, [6 x i64] }, ptr %t241, i32 0, i32 1
  store { i64, i64, { i64, ptr }, { i64, ptr } } %t249, ptr %t250
  %t251 = load { i64, [6 x i64] }, ptr %t241
  store { i64, [6 x i64] } %t251, ptr %rv
  br label %ret
bb45:
  br i1 true, label %bb46, label %bb47
bb46:
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb50
bb49:
  call void @__olang_check_failed(ptr @olang_loc_1e357a262dddcdbe_92aa1b1cb004b7e2)
  unreachable
bb50:
  %t253 = load ptr, ptr %l4, !tbaa !29
  %t255 = getelementptr %"compiler/names:Resolver", ptr %t253, i32 0, i32 1
  %t256 = load i64, ptr %l1, !tbaa !24
  %t259 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v0, ptr %t255, i64 %t256)
  store ptr %t259, ptr %l123
  br label %bb51
bb51:
  %t260 = load ptr, ptr %l123, !tbaa !29
  %t262 = getelementptr %"compiler/names:Table", ptr %t260, i32 0, i32 0
  store ptr %t262, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb52
bb52:
  %t264 = load i64, ptr %l12, !tbaa !24
  store i64 %t264, ptr %l126, !tbaa !24
  %t265 = load ptr, ptr %l11, !tbaa !29
  %t267 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %t265)
  store i64 %t267, ptr %l128
  br label %bb53
bb53:
  %t268 = load i64, ptr %l126, !tbaa !24
  %t269 = load i64, ptr %l128, !tbaa !24
  %t270 = icmp slt i64 %t268, %t269
  %t272 = xor i1 %t270, true
  br i1 %t272, label %bb54, label %bb55
bb54:
  br label %bb82
bb55:
  br label %bb56
bb56:
  %t274 = load ptr, ptr %l11, !tbaa !29
  %t275 = load i64, ptr %l12, !tbaa !24
  %t278 = call %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v0, ptr %t274, i64 %t275)
  store %"compiler/names:Entry" %t278, ptr %l133
  br label %bb57
bb57:
  %t279 = load %"compiler/names:Entry", ptr %l133
  store %"compiler/names:Entry" %t279, ptr %l13
  %t280 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 1
  %t281 = getelementptr %"compiler/source:Span", ptr %t280, i32 0, i32 0
  %t282 = load i32, ptr %t281, !tbaa !23
  %t283 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t284 = load i32, ptr %t283, !tbaa !23
  %t287 = icmp eq i32 %t282, %t284
  br i1 %t287, label %bb58, label %bb59
bb58:
  %t289 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 2
  %t290 = load i32, ptr %t289, !range !{i32 0, i32 9}
  %t292 = trunc i64 5 to i32
  %t293 = icmp eq i32 %t290, %t292
  %t295 = xor i1 %t293, true
  store i1 %t295, ptr %l137, !tbaa !21
  br label %bb60
bb59:
  store i1 false, ptr %l137, !tbaa !21
  br label %bb60
bb60:
  %t297 = load i1, ptr %l137, !tbaa !21
  br i1 %t297, label %bb61, label %bb62
bb61:
  %t298 = load ptr, ptr %l3, !tbaa !29
  %t300 = icmp eq ptr %t298, null
  br i1 %t300, label %bb63, label %bb64
bb62:
  br label %bb80
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a3b4800e6d7209ba_290fe7f1ef38ac36)
  unreachable
bb64:
  br label %bb65
bb65:
  %t302 = load ptr, ptr %l3, !tbaa !29
  %t305 = getelementptr %"compiler/check:Checker", ptr %t302, i32 0, i32 1
  %t306 = load ptr, ptr %t305, !tbaa !29
  %t307 = load i64, ptr %l1, !tbaa !24
  %t308 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 0
  %t309 = load i32, ptr %t308, !tbaa !23
  %t313 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %t306, i64 %t307, i32 %t309)
  store i64 %t313, ptr %l148
  br label %bb66
bb66:
  %t314 = load i64, ptr %l148, !tbaa !24
  store i64 %t314, ptr %l14, !tbaa !24
  %t315 = getelementptr %"compiler/names:Entry", ptr %l13, i32 0, i32 2
  %t316 = load i32, ptr %t315, !range !{i32 0, i32 9}
  %t318 = trunc i64 3 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb67, label %bb68
bb67:
  %t321 = load i64, ptr %l14, !tbaa !24
  %t323 = icmp slt i64 %t321, 0
  br i1 %t323, label %bb69, label %bb70
bb68:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb76
bb69:
  store i1 true, ptr %l154, !tbaa !21
  br label %bb75
bb70:
  %t325 = load ptr, ptr %l3, !tbaa !29
  %t327 = icmp eq ptr %t325, null
  br i1 %t327, label %bb71, label %bb72
bb71:
  call void @__olang_check_failed(ptr @olang_loc_a3b0521b63c0fd41_ee4db74cec265b9d)
  unreachable
bb72:
  br label %bb73
bb73:
  %t329 = load ptr, ptr %l3, !tbaa !29
  %t332 = getelementptr %"compiler/check:Checker", ptr %t329, i32 0, i32 1
  %t333 = load ptr, ptr %t332, !tbaa !29
  %t334 = load i64, ptr %l14, !tbaa !24
  %t337 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t333, i64 %t334)
  store ptr %t337, ptr %l161
  br label %bb74
bb74:
  %t338 = load ptr, ptr %l161, !tbaa !29
  %t340 = getelementptr %"compiler/ast:Func", ptr %t338, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !29
  %t343 = icmp eq ptr %t341, null
  %t345 = xor i1 %t343, true
  store i1 %t345, ptr %l154, !tbaa !21
  br label %bb75
bb75:
  %t347 = load i1, ptr %l154, !tbaa !21
  store i1 %t347, ptr %l151, !tbaa !21
  br label %bb76
bb76:
  %t348 = load i1, ptr %l151, !tbaa !21
  br i1 %t348, label %bb77, label %bb78
bb77:
  br label %bb82
bb78:
  br label %bb79
bb79:
  %t349 = load i64, ptr %l1, !tbaa !24
  %t350 = load ptr, ptr %lp6
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t352
  %t353 = getelementptr { i64, [6 x i64] }, ptr %t352, i32 0, i32 0
  store i64 1, ptr %t353
  %t355 = insertvalue { i64, { i64, ptr } } undef, i64 %t349, 0
  %t357 = insertvalue { i64, { i64, ptr } } %t355, { i64, ptr } %t351, 1
  %t358 = getelementptr { i64, [6 x i64] }, ptr %t352, i32 0, i32 1
  store { i64, { i64, ptr } } %t357, ptr %t358
  %t359 = load { i64, [6 x i64] }, ptr %t352
  store { i64, [6 x i64] } %t359, ptr %rv
  br label %ret
bb80:
  br label %bb81
bb81:
  %t361 = load i64, ptr %l12, !tbaa !24
  %t364 = add i64 %t361, 1
  store i64 %t364, ptr %l12, !tbaa !24
  br label %bb52
bb82:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t367 = load i64, ptr %l5, !tbaa !24
  %t368 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t369 = load i32, ptr %t368, !tbaa !23
  %t371 = sext i32 %t369 to i64
  %t375 = call %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2elocalAt(ptr %v0, ptr %t366, i64 %t367, i64 %t371)
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t375, ptr %l176
  br label %bb83
bb83:
  %t376 = load %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l176
  store %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" %t376, ptr %l15
  %t377 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l15, i32 0, i32 0
  %t378 = load i64, ptr %t377, !tbaa !24
  %t380 = icmp sge i64 %t378, 0
  br i1 %t380, label %bb84, label %bb85
bb84:
  %t382 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l15, i32 0, i32 0
  %t383 = load i64, ptr %t382, !tbaa !24
  %t384 = getelementptr %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20", ptr %l15, i32 0, i32 1
  %t385 = load i32, ptr %t384, !tbaa !23
  store { i64, [6 x i64] } zeroinitializer, ptr %t386
  %t387 = getelementptr { i64, [6 x i64] }, ptr %t386, i32 0, i32 0
  store i64 4, ptr %t387
  %t389 = insertvalue { i64, i32 } undef, i64 %t383, 0
  %t391 = insertvalue { i64, i32 } %t389, i32 %t385, 1
  %t392 = getelementptr { i64, [6 x i64] }, ptr %t386, i32 0, i32 1
  store { i64, i32 } %t391, ptr %t392
  %t393 = load { i64, [6 x i64] }, ptr %t386
  store { i64, [6 x i64] } %t393, ptr %rv
  br label %ret
bb85:
  br label %bb86
bb86:
  %t395 = load ptr, ptr %l3, !tbaa !29
  %t397 = icmp eq ptr %t395, null
  br i1 %t397, label %bb87, label %bb88
bb87:
  call void @__olang_check_failed(ptr @olang_loc_f548539da9e2e40c_6a57728f427e36c8)
  unreachable
bb88:
  br label %bb89
bb89:
  %t399 = load ptr, ptr %l3, !tbaa !29
  %t402 = getelementptr %"compiler/check:Checker", ptr %t399, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t403)
  br label %bb90
bb90:
  store i64 0, ptr %l16, !tbaa !24
  %t405 = load ptr, ptr %l3, !tbaa !29
  %t407 = icmp eq ptr %t405, null
  br i1 %t407, label %bb91, label %bb92
bb91:
  call void @__olang_check_failed(ptr @olang_loc_6ddc0e45a6ad667b_c7aac46097de5ae7)
  unreachable
bb92:
  br label %bb93
bb93:
  %t409 = load ptr, ptr %l3, !tbaa !29
  %t412 = getelementptr %"compiler/check:Checker", ptr %t409, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !29
  %t415 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t413)
  store i64 %t415, ptr %l192
  br label %bb94
bb94:
  %t416 = load i64, ptr %l192, !tbaa !24
  store i64 %t416, ptr %l17, !tbaa !24
  store i64 1, ptr %l18, !tbaa !24
  %t417 = load i64, ptr %l17, !tbaa !24
  %t418 = load i64, ptr %l16, !tbaa !24
  %t421 = icmp sgt i64 %t417, %t418
  br i1 %t421, label %bb95, label %bb96
bb95:
  %t423 = load i64, ptr %l18, !tbaa !24
  %t425 = icmp sgt i64 %t423, 0
  br i1 %t425, label %bb97, label %bb98
bb96:
  store i64 0, ptr %l196, !tbaa !24
  br label %bb100
bb97:
  %t427 = load i64, ptr %l17, !tbaa !24
  %t428 = load i64, ptr %l16, !tbaa !24
  %t431 = sub i64 %t427, %t428
  %t432 = load i64, ptr %l18, !tbaa !24
  %t435 = add i64 %t431, %t432
  %t437 = sub i64 %t435, 1
  %t438 = load i64, ptr %l18, !tbaa !24
  %t441 = sdiv i64 %t437, %t438
  store i64 %t441, ptr %l199, !tbaa !24
  br label %bb99
bb98:
  store i64 0, ptr %l199, !tbaa !24
  br label %bb99
bb99:
  %t443 = load i64, ptr %l199, !tbaa !24
  store i64 %t443, ptr %l196, !tbaa !24
  br label %bb100
bb100:
  %t444 = load i64, ptr %l196, !tbaa !24
  store i64 %t444, ptr %l19, !tbaa !24
  store i64 0, ptr %l20, !tbaa !24
  br label %bb101
bb101:
  store %olang.scope zeroinitializer, ptr %s16
  %t445 = load i64, ptr %l20, !tbaa !24
  %t446 = load i64, ptr %l19, !tbaa !24
  %t449 = icmp slt i64 %t445, %t446
  %t451 = xor i1 %t449, true
  br i1 %t451, label %bb102, label %bb103
bb102:
  call void @__olang_scope_close(ptr %s16)
  br label %bb166
bb103:
  br label %bb104
bb104:
  %t453 = load i64, ptr %l16, !tbaa !24
  %t454 = load i64, ptr %l20, !tbaa !24
  %t455 = load i64, ptr %l18, !tbaa !24
  %t458 = mul i64 %t454, %t455
  %t461 = add i64 %t453, %t458
  store i64 %t461, ptr %l21, !tbaa !24
  %t463 = load ptr, ptr %l3, !tbaa !29
  %t465 = icmp eq ptr %t463, null
  br i1 %t465, label %bb105, label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_be0af37330f35afe_68a0a057b8d4cca2)
  unreachable
bb106:
  br label %bb107
bb107:
  %t467 = load ptr, ptr %l3, !tbaa !29
  %t470 = getelementptr %"compiler/check:Checker", ptr %t467, i32 0, i32 1
  %t471 = load ptr, ptr %t470, !tbaa !29
  %t472 = load i64, ptr %l21, !tbaa !24
  %t475 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t471, i64 %t472)
  store i64 %t475, ptr %l223
  br label %bb108
bb108:
  %t476 = load i64, ptr %l1, !tbaa !24
  %t477 = load i64, ptr %l223, !tbaa !24
  %t479 = icmp ne i64 %t477, %t476
  br i1 %t479, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s16)
  br label %bb165
bb110:
  br label %bb111
bb111:
  %t481 = load ptr, ptr %l3, !tbaa !29
  %t483 = icmp eq ptr %t481, null
  br i1 %t483, label %bb112, label %bb113
bb112:
  call void @__olang_check_failed(ptr @olang_loc_7be9b74a0a4337a5_af051c2067e0d709)
  unreachable
bb113:
  br label %bb114
bb114:
  %t485 = load ptr, ptr %l3, !tbaa !29
  %t488 = getelementptr %"compiler/check:Checker", ptr %t485, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !29
  %t490 = load i64, ptr %l21, !tbaa !24
  %t493 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t489, i64 %t490)
  store ptr %t493, ptr %l232
  br label %bb115
bb115:
  %t494 = load ptr, ptr %l232, !tbaa !29
  store ptr %t494, ptr %l22, !tbaa !29
  %t495 = load ptr, ptr %l22, !tbaa !29
  %t497 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %t495)
  store i1 %t497, ptr %l234
  br label %bb116
bb116:
  %t498 = load i1, ptr %l234, !tbaa !21
  br i1 %t498, label %bb117, label %bb118
bb117:
  %t499 = load ptr, ptr %l3, !tbaa !29
  %t501 = icmp eq ptr %t499, null
  br i1 %t501, label %bb119, label %bb120
bb118:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb124
bb119:
  call void @__olang_check_failed(ptr @olang_loc_a0e32d5552598bb5_d1b40570995ef0d1)
  unreachable
bb120:
  br label %bb121
bb121:
  %t503 = load ptr, ptr %l3, !tbaa !29
  %t506 = getelementptr %"compiler/check:Checker", ptr %t503, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !29
  %t509 = getelementptr %"compiler/generic:Program", ptr %t507, i32 0, i32 0
  %t510 = load ptr, ptr %t509, !tbaa !29
  %t512 = getelementptr %"compiler/load:Loader", ptr %t510, i32 0, i32 3
  %t513 = load ptr, ptr %t512, !tbaa !29
  %t514 = load ptr, ptr %l22, !tbaa !29
  %t516 = getelementptr %"compiler/ast:Func", ptr %t514, i32 0, i32 9
  %t517 = load i32, ptr %t516, !tbaa !23
  %t520 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s16, ptr %t513, i32 %t517)
  store { i64, ptr } %t520, ptr %l245
  br label %bb122
bb122:
  %t521 = load ptr, ptr %lp6
  %t522 = load { i64, ptr }, ptr %t521, !tbaa !27
  %t523 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t525 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s16, ptr %v1, { i64, ptr } %t523, { i64, ptr } %t522)
  store i1 %t525, ptr %l247
  br label %bb123
bb123:
  %t526 = load i1, ptr %l247, !tbaa !21
  store i1 %t526, ptr %l235, !tbaa !21
  br label %bb124
bb124:
  %t527 = load i1, ptr %l235, !tbaa !21
  br i1 %t527, label %bb125, label %bb126
bb125:
  %t528 = load ptr, ptr %l22, !tbaa !29
  %t530 = getelementptr %"compiler/ast:Func", ptr %t528, i32 0, i32 0
  %t531 = getelementptr %"compiler/source:Span", ptr %t530, i32 0, i32 0
  %t532 = load i32, ptr %t531, !tbaa !23
  %t534 = sext i32 %t532 to i64
  %t535 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t536 = load i32, ptr %t535, !tbaa !23
  %t538 = sext i32 %t536 to i64
  %t541 = icmp sle i64 %t534, %t538
  store i1 %t541, ptr %l248, !tbaa !21
  br label %bb127
bb126:
  store i1 false, ptr %l248, !tbaa !21
  br label %bb127
bb127:
  %t543 = load i1, ptr %l248, !tbaa !21
  br i1 %t543, label %bb128, label %bb129
bb128:
  %t544 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t545 = load i32, ptr %t544, !tbaa !23
  %t547 = sext i32 %t545 to i64
  %t548 = load ptr, ptr %l22, !tbaa !29
  %t550 = getelementptr %"compiler/ast:Func", ptr %t548, i32 0, i32 0
  %t551 = getelementptr %"compiler/source:Span", ptr %t550, i32 0, i32 1
  %t552 = load i32, ptr %t551, !tbaa !23
  %t554 = sext i32 %t552 to i64
  %t557 = icmp slt i64 %t547, %t554
  store i1 %t557, ptr %l255, !tbaa !21
  br label %bb130
bb129:
  store i1 false, ptr %l255, !tbaa !21
  br label %bb130
bb130:
  %t559 = load i1, ptr %l255, !tbaa !21
  br i1 %t559, label %bb131, label %bb132
bb131:
  %t560 = load ptr, ptr %l22, !tbaa !29
  %t562 = getelementptr %"compiler/ast:Func", ptr %t560, i32 0, i32 4
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  %t565 = extractvalue { i64, ptr } %t563, 0
  %t567 = icmp eq i64 %t565, 0
  br i1 %t567, label %bb133, label %bb134
bb132:
  store i1 false, ptr %l262, !tbaa !21
  br label %bb137
bb133:
  store i1 true, ptr %l267, !tbaa !21
  br label %bb136
bb134:
  %t569 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t570 = load i32, ptr %t569, !tbaa !23
  %t572 = sext i32 %t570 to i64
  store i64 %t572, ptr %l269, !tbaa !24
  %t573 = load ptr, ptr %l22, !tbaa !29
  %t575 = getelementptr %"compiler/ast:Func", ptr %t573, i32 0, i32 4
  %t576 = load { i64, ptr }, ptr %t575, !tbaa !27
  store { i64, ptr } %t576, ptr %l271, !tbaa !27
  %t577 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t578 = load ptr, ptr %t577, !tbaa !27
  %t579 = getelementptr ptr, ptr %t578, i64 0
  %t580 = load ptr, ptr %t579, !tbaa !39
  %t582 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %t580)
  store %"compiler/source:Span" %t582, ptr %l273
  br label %bb135
bb135:
  %t583 = getelementptr %"compiler/source:Span", ptr %l273, i32 0, i32 0
  %t584 = load i32, ptr %t583, !tbaa !23
  %t586 = sext i32 %t584 to i64
  %t587 = load i64, ptr %l269, !tbaa !24
  %t589 = icmp slt i64 %t587, %t586
  store i1 %t589, ptr %l267, !tbaa !21
  br label %bb136
bb136:
  %t591 = load i1, ptr %l267, !tbaa !21
  store i1 %t591, ptr %l262, !tbaa !21
  br label %bb137
bb137:
  %t592 = load i1, ptr %l262, !tbaa !21
  br i1 %t592, label %bb138, label %bb139
bb138:
  %t593 = load i64, ptr %l21, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t594
  %t595 = getelementptr { i64, [6 x i64] }, ptr %t594, i32 0, i32 0
  store i64 2, ptr %t595
  %t597 = insertvalue { i64 } undef, i64 %t593, 0
  %t598 = getelementptr { i64, [6 x i64] }, ptr %t594, i32 0, i32 1
  store { i64 } %t597, ptr %t598
  %t599 = load { i64, [6 x i64] }, ptr %t594
  call void @__olang_scope_close(ptr %s16)
  store { i64, [6 x i64] } %t599, ptr %rv
  br label %ret
bb139:
  br label %bb140
bb140:
  %t601 = load ptr, ptr %l22, !tbaa !29
  %t603 = getelementptr %"compiler/ast:Func", ptr %t601, i32 0, i32 1
  %t604 = load ptr, ptr %t603, !tbaa !29
  %t606 = icmp eq ptr %t604, null
  br i1 %t606, label %bb141, label %bb142
bb141:
  store i1 true, ptr %l282, !tbaa !21
  br label %bb148
bb142:
  %t608 = load ptr, ptr %l3, !tbaa !29
  %t610 = icmp eq ptr %t608, null
  br i1 %t610, label %bb143, label %bb144
bb143:
  call void @__olang_check_failed(ptr @olang_loc_90517919cad2500e_b5e04c9858b7f7ca)
  unreachable
bb144:
  br label %bb145
bb145:
  %t612 = load ptr, ptr %l3, !tbaa !29
  %t615 = getelementptr %"compiler/check:Checker", ptr %t612, i32 0, i32 1
  %t616 = load ptr, ptr %t615, !tbaa !29
  %t618 = getelementptr %"compiler/generic:Program", ptr %t616, i32 0, i32 0
  %t619 = load ptr, ptr %t618, !tbaa !29
  %t621 = getelementptr %"compiler/load:Loader", ptr %t619, i32 0, i32 3
  %t622 = load ptr, ptr %t621, !tbaa !29
  %t623 = load ptr, ptr %l22, !tbaa !29
  %t625 = getelementptr %"compiler/ast:Func", ptr %t623, i32 0, i32 2
  %t626 = load i32, ptr %t625, !tbaa !23
  %t629 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s16, ptr %t622, i32 %t626)
  store { i64, ptr } %t629, ptr %l292
  br label %bb146
bb146:
  %t630 = load ptr, ptr %lp6
  %t631 = load { i64, ptr }, ptr %t630, !tbaa !27
  %t632 = load { i64, ptr }, ptr %l292, !tbaa !27
  %t634 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s16, ptr %v1, { i64, ptr } %t632, { i64, ptr } %t631)
  store i1 %t634, ptr %l294
  br label %bb147
bb147:
  %t635 = load i1, ptr %l294, !tbaa !21
  %t636 = xor i1 %t635, true
  store i1 %t636, ptr %l282, !tbaa !21
  br label %bb148
bb148:
  %t638 = load i1, ptr %l282, !tbaa !21
  br i1 %t638, label %bb149, label %bb150
bb149:
  call void @__olang_scope_close(ptr %s16)
  br label %bb165
bb150:
  br label %bb151
bb151:
  %t639 = load ptr, ptr %l22, !tbaa !29
  %t641 = getelementptr %"compiler/ast:Func", ptr %t639, i32 0, i32 0
  %t642 = getelementptr %"compiler/source:Span", ptr %t641, i32 0, i32 0
  %t643 = load i32, ptr %t642, !tbaa !23
  %t645 = sext i32 %t643 to i64
  %t646 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t647 = load i32, ptr %t646, !tbaa !23
  %t649 = sext i32 %t647 to i64
  %t652 = icmp sle i64 %t645, %t649
  br i1 %t652, label %bb152, label %bb153
bb152:
  %t654 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t655 = load i32, ptr %t654, !tbaa !23
  %t657 = sext i32 %t655 to i64
  %t658 = load ptr, ptr %l22, !tbaa !29
  %t660 = getelementptr %"compiler/ast:Func", ptr %t658, i32 0, i32 0
  %t661 = getelementptr %"compiler/source:Span", ptr %t660, i32 0, i32 1
  %t662 = load i32, ptr %t661, !tbaa !23
  %t664 = sext i32 %t662 to i64
  %t667 = icmp slt i64 %t657, %t664
  store i1 %t667, ptr %l302, !tbaa !21
  br label %bb154
bb153:
  store i1 false, ptr %l302, !tbaa !21
  br label %bb154
bb154:
  %t669 = load i1, ptr %l302, !tbaa !21
  br i1 %t669, label %bb155, label %bb156
bb155:
  %t670 = load ptr, ptr %l22, !tbaa !29
  %t672 = getelementptr %"compiler/ast:Func", ptr %t670, i32 0, i32 4
  %t673 = load { i64, ptr }, ptr %t672, !tbaa !27
  %t675 = extractvalue { i64, ptr } %t673, 0
  %t677 = icmp eq i64 %t675, 0
  br i1 %t677, label %bb157, label %bb158
bb156:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb161
bb157:
  store i1 true, ptr %l314, !tbaa !21
  br label %bb160
bb158:
  %t679 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t680 = load i32, ptr %t679, !tbaa !23
  %t682 = sext i32 %t680 to i64
  store i64 %t682, ptr %l316, !tbaa !24
  %t683 = load ptr, ptr %l22, !tbaa !29
  %t685 = getelementptr %"compiler/ast:Func", ptr %t683, i32 0, i32 4
  %t686 = load { i64, ptr }, ptr %t685, !tbaa !27
  store { i64, ptr } %t686, ptr %l318, !tbaa !27
  %t687 = getelementptr { i64, ptr }, ptr %l318, i32 0, i32 1
  %t688 = load ptr, ptr %t687, !tbaa !27
  %t689 = getelementptr ptr, ptr %t688, i64 0
  %t690 = load ptr, ptr %t689, !tbaa !39
  %t692 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %t690)
  store %"compiler/source:Span" %t692, ptr %l320
  br label %bb159
bb159:
  %t693 = getelementptr %"compiler/source:Span", ptr %l320, i32 0, i32 0
  %t694 = load i32, ptr %t693, !tbaa !23
  %t696 = sext i32 %t694 to i64
  %t697 = load i64, ptr %l316, !tbaa !24
  %t699 = icmp slt i64 %t697, %t696
  store i1 %t699, ptr %l314, !tbaa !21
  br label %bb160
bb160:
  %t701 = load i1, ptr %l314, !tbaa !21
  store i1 %t701, ptr %l309, !tbaa !21
  br label %bb161
bb161:
  %t702 = load i1, ptr %l309, !tbaa !21
  br i1 %t702, label %bb162, label %bb163
bb162:
  %t703 = load i64, ptr %l21, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t704
  %t705 = getelementptr { i64, [6 x i64] }, ptr %t704, i32 0, i32 0
  store i64 2, ptr %t705
  %t707 = insertvalue { i64 } undef, i64 %t703, 0
  %t708 = getelementptr { i64, [6 x i64] }, ptr %t704, i32 0, i32 1
  store { i64 } %t707, ptr %t708
  %t709 = load { i64, [6 x i64] }, ptr %t704
  call void @__olang_scope_close(ptr %s16)
  store { i64, [6 x i64] } %t709, ptr %rv
  br label %ret
bb163:
  br label %bb164
bb164:
  call void @__olang_scope_close(ptr %s16)
  br label %bb165
bb165:
  %t711 = load i64, ptr %l20, !tbaa !24
  %t714 = add i64 %t711, 1
  store i64 %t714, ptr %l20, !tbaa !24
  br label %bb101
bb166:
  %t716 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t717 = load i32, ptr %t716, !tbaa !23
  %t719 = sext i32 %t717 to i64
  store i64 %t719, ptr %l330, !tbaa !24
  %t720 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t721 = load i32, ptr %t720, !tbaa !23
  %t723 = sext i32 %t721 to i64
  store i64 %t723, ptr %l332, !tbaa !24
  %t724 = load ptr, ptr %lp6
  %t725 = load { i64, ptr }, ptr %t724, !tbaa !27
  store { i64, ptr } %t725, ptr %l333, !tbaa !27
  %t726 = load ptr, ptr %l3, !tbaa !29
  %t728 = icmp eq ptr %t726, null
  br i1 %t728, label %bb167, label %bb168
bb167:
  call void @__olang_check_failed(ptr @olang_loc_ce3fd8c720c212bf_60e6469ff90569cb)
  unreachable
bb168:
  br label %bb169
bb169:
  %t730 = load ptr, ptr %l3, !tbaa !29
  %t731 = load i64, ptr %l330, !tbaa !24
  %t732 = load i64, ptr %l332, !tbaa !24
  %t733 = load { i64, ptr }, ptr %l333, !tbaa !27
  %t735 = call %"compiler/session:finder" @compiler_2fsession_3afinder_2ector(ptr %v1, ptr %v0, ptr %v1, i64 %t731, i64 %t732, { i64, ptr } %t733, ptr %t730)
  store %"compiler/session:finder" %t735, ptr %l337
  br label %bb170
bb170:
  %t736 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 112, i64 8)
  store ptr %t736, ptr %lp23
  %t737 = load %"compiler/session:finder", ptr %l337
  %t738 = load ptr, ptr %lp23
  store %"compiler/session:finder" %t737, ptr %t738
  %t739 = load ptr, ptr %l3, !tbaa !29
  %t741 = icmp eq ptr %t739, null
  br i1 %t741, label %bb171, label %bb172
bb171:
  call void @__olang_check_failed(ptr @olang_loc_d27ec903618be0a0_36ec6c4f051caedc)
  unreachable
bb172:
  br label %bb173
bb173:
  %t743 = load ptr, ptr %l3, !tbaa !29
  %t746 = getelementptr %"compiler/check:Checker", ptr %t743, i32 0, i32 19
  store ptr %t746, ptr %l24, !tbaa !29
  store i64 0, ptr %l25, !tbaa !24
  br label %bb174
bb174:
  %t748 = load i64, ptr %l25, !tbaa !24
  store i64 %t748, ptr %l343, !tbaa !24
  %t749 = load ptr, ptr %l24, !tbaa !29
  %t751 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t749)
  store i64 %t751, ptr %l345
  br label %bb175
bb175:
  %t752 = load i64, ptr %l343, !tbaa !24
  %t753 = load i64, ptr %l345, !tbaa !24
  %t754 = icmp slt i64 %t752, %t753
  %t756 = xor i1 %t754, true
  br i1 %t756, label %bb176, label %bb177
bb176:
  br label %bb194
bb177:
  br label %bb178
bb178:
  %t758 = load ptr, ptr %l24, !tbaa !29
  %t759 = load i64, ptr %l25, !tbaa !24
  %t762 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t758, i64 %t759)
  store ptr %t762, ptr %l350
  br label %bb179
bb179:
  %t763 = load ptr, ptr %l350, !tbaa !29
  store ptr %t763, ptr %l26, !tbaa !29
  %t764 = load ptr, ptr %l26, !tbaa !29
  %t766 = getelementptr %"compiler/typed:Body", ptr %t764, i32 0, i32 3
  %t767 = load i64, ptr %t766, !tbaa !24
  %t768 = load i64, ptr %l5, !tbaa !24
  %t771 = icmp ne i64 %t767, %t768
  br i1 %t771, label %bb180, label %bb181
bb180:
  store i1 true, ptr %l355, !tbaa !21
  br label %bb182
bb181:
  %t773 = load ptr, ptr %l26, !tbaa !29
  %t775 = getelementptr %"compiler/typed:Body", ptr %t773, i32 0, i32 11
  %t776 = load ptr, ptr %t775, !tbaa !29
  %t778 = icmp eq ptr %t776, null
  store i1 %t778, ptr %l355, !tbaa !21
  br label %bb182
bb182:
  %t780 = load i1, ptr %l355, !tbaa !21
  br i1 %t780, label %bb183, label %bb184
bb183:
  br label %bb193
bb184:
  br label %bb185
bb185:
  %t781 = load ptr, ptr %l26, !tbaa !29
  %t783 = getelementptr %"compiler/typed:Body", ptr %t781, i32 0, i32 4
  %t784 = getelementptr %"compiler/source:Span", ptr %t783, i32 0, i32 1
  %t785 = load i32, ptr %t784, !tbaa !23
  %t787 = sext i32 %t785 to i64
  %t788 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 0
  %t789 = load i32, ptr %t788, !tbaa !23
  %t791 = sext i32 %t789 to i64
  %t794 = icmp slt i64 %t787, %t791
  br i1 %t794, label %bb186, label %bb187
bb186:
  store i1 true, ptr %l365, !tbaa !21
  br label %bb188
bb187:
  %t796 = load ptr, ptr %l26, !tbaa !29
  %t798 = getelementptr %"compiler/typed:Body", ptr %t796, i32 0, i32 4
  %t799 = getelementptr %"compiler/source:Span", ptr %t798, i32 0, i32 0
  %t800 = load i32, ptr %t799, !tbaa !23
  %t802 = sext i32 %t800 to i64
  %t803 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t804 = load i32, ptr %t803, !tbaa !23
  %t806 = sext i32 %t804 to i64
  %t809 = icmp sgt i64 %t802, %t806
  store i1 %t809, ptr %l365, !tbaa !21
  br label %bb188
bb188:
  %t811 = load i1, ptr %l365, !tbaa !21
  br i1 %t811, label %bb189, label %bb190
bb189:
  br label %bb193
bb190:
  br label %bb191
bb191:
  %t812 = load ptr, ptr %l26, !tbaa !29
  %t814 = getelementptr %"compiler/typed:Body", ptr %t812, i32 0, i32 0
  %t815 = load i32, ptr %t814, !tbaa !23
  %t817 = sext i32 %t815 to i64
  %t819 = load ptr, ptr %lp23
  %t820 = getelementptr %"compiler/session:finder", ptr %t819, i32 0, i32 4
  store i64 %t817, ptr %t820, !tbaa !24
  %t821 = load ptr, ptr %lp23
  %t822 = load ptr, ptr %l26, !tbaa !29
  %t824 = getelementptr %"compiler/typed:Body", ptr %t822, i32 0, i32 11
  %t825 = load ptr, ptr %t824, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v1, ptr %v0, ptr %v0, ptr %v1, ptr %t821, ptr %t825)
  br label %bb192
bb192:
  br label %bb193
bb193:
  %t829 = load i64, ptr %l25, !tbaa !24
  %t832 = add i64 %t829, 1
  store i64 %t832, ptr %l25, !tbaa !24
  br label %bb174
bb194:
  %t834 = load ptr, ptr %lp23
  %t835 = getelementptr %"compiler/session:finder", ptr %t834, i32 0, i32 5
  %t836 = load { i64, [6 x i64] }, ptr %t835
  store { i64, [6 x i64] } %t836, ptr %rv
  br label %ret
ret:
  %rr = load { i64, [6 x i64] }, ptr %rv
  ret { i64, [6 x i64] } %rr
}

define dso_local i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeEndingAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca %"compiler/session:typeFinder"
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/source:Span"
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca %"compiler/typed:Local"
  %l17 = alloca %"compiler/session:typeFinder"
  %l25 = alloca i64
  %l27 = alloca i64
  %l32 = alloca ptr
  %l37 = alloca i1
  %l56 = alloca { i64, ptr }
  %l59 = alloca %"compiler/source:Span"
  %l63 = alloca i1
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l81 = alloca i1
  %l82 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l94 = alloca i32
  %l96 = alloca i32
  %l104 = alloca i64
  %l106 = alloca i64
  %l111 = alloca ptr
  %l116 = alloca i1
  %l122 = alloca i1
  %l130 = alloca i64
  %l132 = alloca i64
  %l137 = alloca %"compiler/typed:Local"
  %l140 = alloca i1
  %l151 = alloca { i64, ptr }
  %l153 = alloca i1
  %l154 = alloca i1
  %s0 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l2, !tbaa !24
  %t3 = call %"compiler/session:typeFinder" @compiler_2fsession_3atypeFinder_2ector(ptr %s0, i64 %t1)
  store %"compiler/session:typeFinder" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"compiler/session:typeFinder", ptr %l17
  store %"compiler/session:typeFinder" %t4, ptr %l3
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:Analysis", ptr %t5, i32 0, i32 2
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  br i1 %t10, label %bb2, label %bb3
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cf04846f3952f731_2a54d968229bc665)
  unreachable
bb3:
  br label %bb4
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/session:Analysis", ptr %t12, i32 0, i32 2
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t18 = getelementptr %"compiler/check:Checker", ptr %t15, i32 0, i32 19
  store ptr %t18, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb5
bb5:
  %t20 = load i64, ptr %l5, !tbaa !24
  store i64 %t20, ptr %l25, !tbaa !24
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t23 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t21)
  store i64 %t23, ptr %l27
  br label %bb6
bb6:
  %t24 = load i64, ptr %l25, !tbaa !24
  %t25 = load i64, ptr %l27, !tbaa !24
  %t26 = icmp slt i64 %t24, %t25
  %t28 = xor i1 %t26, true
  br i1 %t28, label %bb7, label %bb8
bb7:
  br label %bb19
bb8:
  br label %bb9
bb9:
  %t30 = load ptr, ptr %l4, !tbaa !29
  %t31 = load i64, ptr %l5, !tbaa !24
  %t34 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t30, i64 %t31)
  store ptr %t34, ptr %l32
  br label %bb10
bb10:
  %t35 = load ptr, ptr %l32, !tbaa !29
  store ptr %t35, ptr %l6, !tbaa !29
  %t36 = load ptr, ptr %l6, !tbaa !29
  %t38 = getelementptr %"compiler/typed:Body", ptr %t36, i32 0, i32 3
  %t39 = load i64, ptr %t38, !tbaa !24
  %t40 = load i64, ptr %l1, !tbaa !24
  %t43 = icmp ne i64 %t39, %t40
  br i1 %t43, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  %t45 = load ptr, ptr %l6, !tbaa !29
  %t47 = getelementptr %"compiler/typed:Body", ptr %t45, i32 0, i32 11
  %t48 = load ptr, ptr %t47, !tbaa !29
  %t50 = icmp eq ptr %t48, null
  store i1 %t50, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t52 = load i1, ptr %l37, !tbaa !21
  br i1 %t52, label %bb14, label %bb15
bb14:
  br label %bb18
bb15:
  br label %bb16
bb16:
  %t53 = load ptr, ptr %l6, !tbaa !29
  %t55 = getelementptr %"compiler/typed:Body", ptr %t53, i32 0, i32 11
  %t56 = load ptr, ptr %t55, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %s0, ptr %v0, ptr %l3, ptr %t56)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = add i64 %t60, 1
  store i64 %t63, ptr %l5, !tbaa !24
  br label %bb5
bb19:
  %t65 = getelementptr %"compiler/session:typeFinder", ptr %l3, i32 0, i32 1
  %t66 = load i32, ptr %t65, !tbaa !23
  %t67 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t70 = icmp ne i32 %t66, %t67
  br i1 %t70, label %bb20, label %bb21
bb20:
  %t72 = getelementptr %"compiler/session:typeFinder", ptr %l3, i32 0, i32 1
  %t73 = load i32, ptr %t72, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t73, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/session:Analysis", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/load:Loader", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t82 = load i64, ptr %l1, !tbaa !24
  %t85 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v0, ptr %t81, i64 %t82)
  store { i64, ptr } %t85, ptr %l56
  br label %bb23
bb23:
  %t86 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t86, ptr %l7, !tbaa !27
  %t87 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = call %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %t87, i64 %t88)
  store %"compiler/source:Span" %t91, ptr %l59
  br label %bb24
bb24:
  %t92 = load %"compiler/source:Span", ptr %l59
  store %"compiler/source:Span" %t92, ptr %l8
  %t93 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t94 = load i32, ptr %t93, !tbaa !23
  %t95 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t96 = load i32, ptr %t95, !tbaa !23
  %t99 = icmp eq i32 %t94, %t96
  br i1 %t99, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb27
bb26:
  %t101 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t102 = load i32, ptr %t101, !tbaa !23
  %t104 = sext i32 %t102 to i64
  %t105 = load i64, ptr %l2, !tbaa !24
  %t108 = icmp ne i64 %t104, %t105
  store i1 %t108, ptr %l63, !tbaa !21
  br label %bb27
bb27:
  %t110 = load i1, ptr %l63, !tbaa !21
  br i1 %t110, label %bb28, label %bb29
bb28:
  %t111 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t111, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t113 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t113, ptr %l69, !tbaa !27
  %t114 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t115 = load i32, ptr %t114, !tbaa !23
  %t117 = sext i32 %t115 to i64
  store i64 %t117, ptr %l71, !tbaa !24
  %t118 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 1
  %t119 = load i32, ptr %t118, !tbaa !23
  %t121 = sext i32 %t119 to i64
  store i64 %t121, ptr %l73, !tbaa !24
  %t122 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t123 = extractvalue { i64, ptr } %t122, 0
  store i64 %t123, ptr %l74, !tbaa !24
  %t124 = load i64, ptr %l71, !tbaa !24
  %t125 = icmp sge i64 %t124, 0
  br i1 %t125, label %bb31, label %bb32
bb31:
  %t127 = load i64, ptr %l71, !tbaa !24
  %t128 = load i64, ptr %l73, !tbaa !24
  %t129 = icmp sle i64 %t127, %t128
  br i1 %t129, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_77695651a3cbe722_713723fe03dd0eb6)
  unreachable
bb33:
  %t131 = load i64, ptr %l73, !tbaa !24
  %t132 = load i64, ptr %l74, !tbaa !24
  %t133 = icmp sle i64 %t131, %t132
  br i1 %t133, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @olang_loc_77695651a3cbe722_713723fe03dd0eb6)
  unreachable
bb35:
  %t135 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = load i64, ptr %l71, !tbaa !24
  %t138 = load i64, ptr %l73, !tbaa !24
  %t139 = getelementptr i8, ptr %t136, i64 %t137
  %t140 = sub i64 %t138, %t137
  %t141 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t139, 1
  store { i64, ptr } %t142, ptr %l9, !tbaa !27
  %t144 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t145 = load i32, ptr %t144, !tbaa !23
  %t147 = icmp sgt i32 %t145, 0
  br i1 %t147, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @olang_loc_77695651a3cbe722_713723fe03dd0eb6)
  unreachable
bb37:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t149, ptr %l82, !tbaa !27
  %t150 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t151 = load i32, ptr %t150, !tbaa !23
  %t153 = sext i32 %t151 to i64
  %t155 = sub i64 %t153, 1
  %t157 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i8, ptr %t158, i64 %t155
  %t160 = load i8, ptr %t159, !tbaa !32
  %t162 = icmp eq i8 %t160, 46
  store i1 %t162, ptr %l81, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb39
bb39:
  %t164 = load i1, ptr %l81, !tbaa !21
  br i1 %t164, label %bb40, label %bb41
bb40:
  %t165 = load ptr, ptr %l0, !tbaa !29
  store ptr %t165, ptr %l88, !tbaa !29
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load i64, ptr %l1, !tbaa !24
  %t168 = getelementptr %"compiler/source:Span", ptr %l8, i32 0, i32 0
  %t169 = load i32, ptr %t168, !tbaa !23
  %t171 = sext i32 %t169 to i64
  %t173 = sub i64 %t171, 1
  %t177 = call i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeEndingAt(ptr %v0, ptr %t166, i64 %t167, i64 %t173)
  store i32 %t177, ptr %l94
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t178 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t179 = load ptr, ptr %l88, !tbaa !29
  %t180 = load i32, ptr %l94, !tbaa !23
  %t182 = call i32 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efieldType(ptr %v0, ptr %v0, ptr %t179, i32 %t180, { i64, ptr } %t178)
  store i32 %t182, ptr %l96
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t183 = load i32, ptr %l96, !tbaa !23
  store i32 %t183, ptr %rv
  br label %ret
bb44:
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/session:Analysis", ptr %t184, i32 0, i32 2
  %t187 = load ptr, ptr %t186, !tbaa !29
  %t189 = icmp eq ptr %t187, null
  br i1 %t189, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_192180e0c65a19ab_79011e5b413ec96f)
  unreachable
bb46:
  br label %bb47
bb47:
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/session:Analysis", ptr %t191, i32 0, i32 2
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t197 = getelementptr %"compiler/check:Checker", ptr %t194, i32 0, i32 19
  store ptr %t197, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb48
bb48:
  %t199 = load i64, ptr %l11, !tbaa !24
  store i64 %t199, ptr %l104, !tbaa !24
  %t200 = load ptr, ptr %l10, !tbaa !29
  %t202 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %t200)
  store i64 %t202, ptr %l106
  br label %bb49
bb49:
  %t203 = load i64, ptr %l104, !tbaa !24
  %t204 = load i64, ptr %l106, !tbaa !24
  %t205 = icmp slt i64 %t203, %t204
  %t207 = xor i1 %t205, true
  br i1 %t207, label %bb50, label %bb51
bb50:
  br label %bb86
bb51:
  br label %bb52
bb52:
  %t209 = load ptr, ptr %l10, !tbaa !29
  %t210 = load i64, ptr %l11, !tbaa !24
  %t213 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v0, ptr %t209, i64 %t210)
  store ptr %t213, ptr %l111
  br label %bb53
bb53:
  %t214 = load ptr, ptr %l111, !tbaa !29
  store ptr %t214, ptr %l12, !tbaa !29
  %t215 = load ptr, ptr %l12, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Body", ptr %t215, i32 0, i32 3
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr %l1, !tbaa !24
  %t222 = icmp ne i64 %t218, %t219
  br i1 %t222, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l116, !tbaa !21
  br label %bb56
bb55:
  %t224 = load ptr, ptr %l12, !tbaa !29
  %t226 = getelementptr %"compiler/typed:Body", ptr %t224, i32 0, i32 4
  %t227 = getelementptr %"compiler/source:Span", ptr %t226, i32 0, i32 0
  %t228 = load i32, ptr %t227, !tbaa !23
  %t230 = sext i32 %t228 to i64
  %t231 = load i64, ptr %l2, !tbaa !24
  %t234 = icmp sgt i64 %t230, %t231
  store i1 %t234, ptr %l116, !tbaa !21
  br label %bb56
bb56:
  %t236 = load i1, ptr %l116, !tbaa !21
  br i1 %t236, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb59
bb58:
  %t237 = load i64, ptr %l2, !tbaa !24
  %t238 = load ptr, ptr %l12, !tbaa !29
  %t240 = getelementptr %"compiler/typed:Body", ptr %t238, i32 0, i32 4
  %t241 = getelementptr %"compiler/source:Span", ptr %t240, i32 0, i32 1
  %t242 = load i32, ptr %t241, !tbaa !23
  %t244 = sext i32 %t242 to i64
  %t247 = icmp sgt i64 %t237, %t244
  store i1 %t247, ptr %l122, !tbaa !21
  br label %bb59
bb59:
  %t249 = load i1, ptr %l122, !tbaa !21
  br i1 %t249, label %bb60, label %bb61
bb60:
  br label %bb85
bb61:
  br label %bb62
bb62:
  %t250 = load ptr, ptr %l12, !tbaa !29
  %t252 = getelementptr %"compiler/typed:Body", ptr %t250, i32 0, i32 7
  store ptr %t252, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s12
  %t254 = load i64, ptr %l14, !tbaa !24
  store i64 %t254, ptr %l130, !tbaa !24
  %t255 = load ptr, ptr %l13, !tbaa !29
  %t257 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t255)
  store i64 %t257, ptr %l132
  br label %bb64
bb64:
  %t258 = load i64, ptr %l130, !tbaa !24
  %t259 = load i64, ptr %l132, !tbaa !24
  %t260 = icmp slt i64 %t258, %t259
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb66:
  br label %bb67
bb67:
  %t264 = load ptr, ptr %l13, !tbaa !29
  %t265 = load i64, ptr %l14, !tbaa !24
  %t268 = call %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %t264, i64 %t265)
  store %"compiler/typed:Local" %t268, ptr %l137
  br label %bb68
bb68:
  %t269 = load %"compiler/typed:Local", ptr %l137
  store %"compiler/typed:Local" %t269, ptr %l15
  %t270 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 0
  %t271 = load i32, ptr %t270, !tbaa !23
  %t273 = icmp ne i32 %t271, 0
  br i1 %t273, label %bb69, label %bb70
bb69:
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/session:Analysis", ptr %t275, i32 0, i32 2
  %t278 = load ptr, ptr %t277, !tbaa !29
  %t280 = icmp eq ptr %t278, null
  br i1 %t280, label %bb71, label %bb72
bb70:
  store i1 false, ptr %l140, !tbaa !21
  br label %bb76
bb71:
  call void @__olang_check_failed(ptr @olang_loc_41c9e4d1a5402e3c_f7f654128ad00b10)
  unreachable
bb72:
  br label %bb73
bb73:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = getelementptr %"compiler/session:Analysis", ptr %t282, i32 0, i32 2
  %t285 = load ptr, ptr %t284, !tbaa !29
  %t288 = getelementptr %"compiler/check:Checker", ptr %t285, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !29
  %t291 = getelementptr %"compiler/generic:Program", ptr %t289, i32 0, i32 0
  %t292 = load ptr, ptr %t291, !tbaa !29
  %t294 = getelementptr %"compiler/load:Loader", ptr %t292, i32 0, i32 3
  %t295 = load ptr, ptr %t294, !tbaa !29
  %t296 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 0
  %t297 = load i32, ptr %t296, !tbaa !23
  %t300 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %s12, ptr %t295, i32 %t297)
  store { i64, ptr } %t300, ptr %l151
  br label %bb74
bb74:
  %t301 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t304 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s12, ptr %v0, { i64, ptr } %t302, { i64, ptr } %t301)
  store i1 %t304, ptr %l153
  br label %bb75
bb75:
  %t305 = load i1, ptr %l153, !tbaa !21
  store i1 %t305, ptr %l140, !tbaa !21
  br label %bb76
bb76:
  %t306 = load i1, ptr %l140, !tbaa !21
  br i1 %t306, label %bb77, label %bb78
bb77:
  %t307 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 1
  %t308 = getelementptr %"compiler/source:Span", ptr %t307, i32 0, i32 0
  %t309 = load i32, ptr %t308, !tbaa !23
  %t311 = sext i32 %t309 to i64
  %t312 = load i64, ptr %l2, !tbaa !24
  %t315 = icmp slt i64 %t311, %t312
  store i1 %t315, ptr %l154, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l154, !tbaa !21
  br label %bb79
bb79:
  %t317 = load i1, ptr %l154, !tbaa !21
  br i1 %t317, label %bb80, label %bb81
bb80:
  %t318 = getelementptr %"compiler/typed:Local", ptr %l15, i32 0, i32 2
  %t319 = load i32, ptr %t318, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t319, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb83:
  %t321 = load i64, ptr %l14, !tbaa !24
  %t324 = add i64 %t321, 1
  store i64 %t324, ptr %l14, !tbaa !24
  br label %bb63
bb84:
  br label %bb85
bb85:
  %t326 = load i64, ptr %l11, !tbaa !24
  %t329 = add i64 %t326, 1
  store i64 %t329, ptr %l11, !tbaa !24
  br label %bb48
bb86:
  %t331 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t331, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2etypeMembers(ptr %v0, ptr %v1, ptr %a0, ptr %a1, i32 %a2, i64 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l23 = alloca i32
  %l26 = alloca i32
  %l34 = alloca i32
  %l43 = alloca i32
  %l60 = alloca i64
  %l64 = alloca i64
  %l67 = alloca i64
  %l91 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l106 = alloca i1
  %l108 = alloca i1
  %l115 = alloca i64
  %l121 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l125 = alloca i64
  %l128 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l146 = alloca i64
  %l150 = alloca i1
  %s3 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store i32 %a2, ptr %l2
  store i64 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Analysis", ptr %t1, i32 0, i32 2
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = icmp eq ptr %t6, null
  br i1 %t8, label %bb1, label %bb2
bb1:
  call void @__olang_check_failed(ptr @olang_loc_65524a0775fa0c24_67802a16d5ac44c0)
  unreachable
bb2:
  br label %bb3
bb3:
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t13 = getelementptr %"compiler/check:Checker", ptr %t10, i32 0, i32 1
  %t14 = load ptr, ptr %t13, !tbaa !29
  %t16 = getelementptr %"compiler/generic:Program", ptr %t14, i32 0, i32 2
  %t17 = load i32, ptr %l2, !tbaa !23
  %t20 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t16, i32 %t17)
  store i32 %t20, ptr %l23
  br label %bb4
bb4:
  %t21 = load i32, ptr %l23, !range !{i32 0, i32 33}
  %t23 = trunc i64 20 to i32
  %t24 = icmp eq i32 %t21, %t23
  br i1 %t24, label %bb5, label %bb6
bb5:
  %t26 = load ptr, ptr %l4, !tbaa !29
  %t28 = icmp eq ptr %t26, null
  br i1 %t28, label %bb7, label %bb8
bb6:
  %t30 = load i32, ptr %l2, !tbaa !23
  store i32 %t30, ptr %l26, !tbaa !23
  br label %bb11
bb7:
  call void @__olang_check_failed(ptr @olang_loc_65524a0775fa0c24_67802a16d5ac44c0)
  unreachable
bb8:
  br label %bb9
bb9:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t35 = getelementptr %"compiler/check:Checker", ptr %t32, i32 0, i32 1
  %t36 = load ptr, ptr %t35, !tbaa !29
  %t38 = getelementptr %"compiler/generic:Program", ptr %t36, i32 0, i32 2
  %t39 = load i32, ptr %l2, !tbaa !23
  %t42 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %t38, i32 %t39)
  store i32 %t42, ptr %l34
  br label %bb10
bb10:
  %t43 = load i32, ptr %l34, !tbaa !23
  store i32 %t43, ptr %l26, !tbaa !23
  br label %bb11
bb11:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %l5, !tbaa !23
  %t45 = load ptr, ptr %l4, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  br i1 %t47, label %bb12, label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_183418cbaaa3b5f3_579c8efa30db605f)
  unreachable
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l4, !tbaa !29
  %t52 = getelementptr %"compiler/check:Checker", ptr %t49, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/generic:Program", ptr %t53, i32 0, i32 2
  %t56 = load i32, ptr %l5, !tbaa !23
  %t59 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t55, i32 %t56)
  store i32 %t59, ptr %l43
  br label %bb15
bb15:
  %t60 = load i32, ptr %l43, !range !{i32 0, i32 33}
  %t62 = trunc i64 18 to i32
  %t63 = icmp eq i32 %t60, %t62
  br i1 %t63, label %bb16, label %bb17
bb16:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t67 = load i32, ptr %l5, !tbaa !23
  %t68 = load i64, ptr %l3, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2efieldMembers(ptr %v0, ptr %v1, ptr %t65, ptr %t66, i32 %t67, i64 %t68)
  br label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb19
bb19:
  %t73 = load ptr, ptr %l4, !tbaa !29
  %t75 = icmp eq ptr %t73, null
  br i1 %t75, label %bb20, label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_269369d36ae436b2_2e7a039021f1ff2e)
  unreachable
bb21:
  br label %bb22
bb22:
  %t77 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/check:Checker", ptr %t77, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !29
  call void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %t81)
  br label %bb23
bb23:
  store i64 0, ptr %l6, !tbaa !24
  %t83 = load ptr, ptr %l4, !tbaa !29
  %t85 = icmp eq ptr %t83, null
  br i1 %t85, label %bb24, label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_2bc7afddf58147d9_c9ac3d0f6598ded5)
  unreachable
bb25:
  br label %bb26
bb26:
  %t87 = load ptr, ptr %l4, !tbaa !29
  %t90 = getelementptr %"compiler/check:Checker", ptr %t87, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !29
  %t93 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %t91)
  store i64 %t93, ptr %l60
  br label %bb27
bb27:
  %t94 = load i64, ptr %l60, !tbaa !24
  store i64 %t94, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l7, !tbaa !24
  %t96 = load i64, ptr %l6, !tbaa !24
  %t99 = icmp sgt i64 %t95, %t96
  br i1 %t99, label %bb28, label %bb29
bb28:
  %t101 = load i64, ptr %l8, !tbaa !24
  %t103 = icmp sgt i64 %t101, 0
  br i1 %t103, label %bb30, label %bb31
bb29:
  store i64 0, ptr %l64, !tbaa !24
  br label %bb33
bb30:
  %t105 = load i64, ptr %l7, !tbaa !24
  %t106 = load i64, ptr %l6, !tbaa !24
  %t109 = sub i64 %t105, %t106
  %t110 = load i64, ptr %l8, !tbaa !24
  %t113 = add i64 %t109, %t110
  %t115 = sub i64 %t113, 1
  %t116 = load i64, ptr %l8, !tbaa !24
  %t119 = sdiv i64 %t115, %t116
  store i64 %t119, ptr %l67, !tbaa !24
  br label %bb32
bb31:
  store i64 0, ptr %l67, !tbaa !24
  br label %bb32
bb32:
  %t121 = load i64, ptr %l67, !tbaa !24
  store i64 %t121, ptr %l64, !tbaa !24
  br label %bb33
bb33:
  %t122 = load i64, ptr %l64, !tbaa !24
  store i64 %t122, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  %t123 = load i64, ptr %l10, !tbaa !24
  %t124 = load i64, ptr %l9, !tbaa !24
  %t127 = icmp slt i64 %t123, %t124
  %t129 = xor i1 %t127, true
  br i1 %t129, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s3)
  br label %bb79
bb36:
  br label %bb37
bb37:
  %t131 = load i64, ptr %l6, !tbaa !24
  %t132 = load i64, ptr %l10, !tbaa !24
  %t133 = load i64, ptr %l8, !tbaa !24
  %t136 = mul i64 %t132, %t133
  %t139 = add i64 %t131, %t136
  store i64 %t139, ptr %l11, !tbaa !24
  %t141 = load ptr, ptr %l4, !tbaa !29
  %t143 = icmp eq ptr %t141, null
  br i1 %t143, label %bb38, label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_843b58ccd5037a60_511f1c08fd361084)
  unreachable
bb39:
  br label %bb40
bb40:
  %t145 = load ptr, ptr %l4, !tbaa !29
  %t148 = getelementptr %"compiler/check:Checker", ptr %t145, i32 0, i32 1
  %t149 = load ptr, ptr %t148, !tbaa !29
  %t150 = load i64, ptr %l11, !tbaa !24
  %t153 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v0, ptr %t149, i64 %t150)
  store ptr %t153, ptr %l91
  br label %bb41
bb41:
  %t154 = load ptr, ptr %l91, !tbaa !29
  store ptr %t154, ptr %l12, !tbaa !29
  %t155 = load ptr, ptr %l12, !tbaa !29
  %t157 = getelementptr %"compiler/ast:Func", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = icmp eq ptr %t158, null
  br i1 %t160, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb43:
  br label %bb44
bb44:
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t164 = icmp eq ptr %t162, null
  br i1 %t164, label %bb45, label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_237e374d945d777f_399ab2bb28be7e53)
  unreachable
bb46:
  br label %bb47
bb47:
  %t166 = load ptr, ptr %l4, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t166, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  %t172 = getelementptr %"compiler/generic:Program", ptr %t170, i32 0, i32 0
  %t173 = load ptr, ptr %t172, !tbaa !29
  %t175 = getelementptr %"compiler/load:Loader", ptr %t173, i32 0, i32 3
  %t176 = load ptr, ptr %t175, !tbaa !29
  %t177 = load ptr, ptr %l12, !tbaa !29
  %t179 = getelementptr %"compiler/ast:Func", ptr %t177, i32 0, i32 2
  %t180 = load i32, ptr %t179, !tbaa !23
  %t183 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t176, i32 %t180)
  store { i64, ptr } %t183, ptr %l104
  br label %bb48
bb48:
  %t184 = load { i64, ptr }, ptr %l104, !tbaa !27
  store { i64, ptr } %t184, ptr %l13, !tbaa !27
  %t185 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t187 = call i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %t185)
  store i1 %t187, ptr %l106
  br label %bb49
bb49:
  %t188 = load i1, ptr %l106, !tbaa !21
  %t189 = xor i1 %t188, true
  br i1 %t189, label %bb50, label %bb51
bb50:
  %t191 = load ptr, ptr %l4, !tbaa !29
  %t193 = icmp eq ptr %t191, null
  br i1 %t193, label %bb52, label %bb53
bb51:
  store i1 false, ptr %l108, !tbaa !21
  br label %bb56
bb52:
  call void @__olang_check_failed(ptr @olang_loc_276794097286b2ce_71d39dea21084d12)
  unreachable
bb53:
  br label %bb54
bb54:
  %t195 = load ptr, ptr %l4, !tbaa !29
  %t198 = getelementptr %"compiler/check:Checker", ptr %t195, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !29
  %t200 = load i64, ptr %l11, !tbaa !24
  %t203 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t199, i64 %t200)
  store i64 %t203, ptr %l115
  br label %bb55
bb55:
  %t204 = load i64, ptr %l3, !tbaa !24
  %t205 = load i64, ptr %l115, !tbaa !24
  %t207 = icmp ne i64 %t205, %t204
  store i1 %t207, ptr %l108, !tbaa !21
  br label %bb56
bb56:
  %t209 = load i1, ptr %l108, !tbaa !21
  br i1 %t209, label %bb57, label %bb58
bb57:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb58:
  br label %bb59
bb59:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t211 = load i64, ptr %l11, !tbaa !24
  %t212 = load i32, ptr %l5, !tbaa !23
  %t216 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emethodFor(ptr %v0, ptr %t210, i64 %t211, i32 %t212)
  store i1 %t216, ptr %l121
  br label %bb60
bb60:
  %t217 = load i1, ptr %l121, !tbaa !21
  %t218 = xor i1 %t217, true
  br i1 %t218, label %bb61, label %bb62
bb61:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb62:
  br label %bb63
bb63:
  %t220 = load ptr, ptr %l1, !tbaa !29
  store ptr %t220, ptr %l123, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t221, ptr %l124, !tbaa !27
  %t222 = load i64, ptr @G_2ecompiler_2fsession_2eCompMethod, !tbaa !24
  store i64 %t222, ptr %l125, !tbaa !24
  %t223 = load ptr, ptr %l4, !tbaa !29
  %t225 = icmp eq ptr %t223, null
  br i1 %t225, label %bb64, label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_883965863f350275_cecb497c93815139)
  unreachable
bb65:
  br label %bb66
bb66:
  %t227 = load ptr, ptr %l4, !tbaa !29
  store ptr %t227, ptr %l128, !tbaa !29
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/session:Analysis", ptr %t228, i32 0, i32 3
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = icmp eq ptr %t231, null
  br i1 %t233, label %bb67, label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_883965863f350275_cecb497c93815139)
  unreachable
bb68:
  br label %bb69
bb69:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/session:Analysis", ptr %t235, i32 0, i32 3
  %t238 = load ptr, ptr %t237, !tbaa !29
  %t239 = load i64, ptr %l11, !tbaa !24
  %t240 = load ptr, ptr %l128, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v0, ptr %s3, ptr %t240, ptr %t238, i64 %t239)
  store { i64, ptr } %t243, ptr %l135
  br label %bb70
bb70:
  %t244 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t246 = call { i64, ptr } @compiler_2fsession_2efirstLine(ptr %s3, ptr %s3, { i64, ptr } %t244)
  store { i64, ptr } %t246, ptr %l137
  br label %bb71
bb71:
  %t247 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t247, ptr %l138, !tbaa !27
  %t248 = load ptr, ptr %l0, !tbaa !29
  store ptr %t248, ptr %l139, !tbaa !29
  %t249 = load ptr, ptr %l4, !tbaa !29
  %t251 = icmp eq ptr %t249, null
  br i1 %t251, label %bb72, label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_883965863f350275_cecb497c93815139)
  unreachable
bb73:
  br label %bb74
bb74:
  %t253 = load ptr, ptr %l4, !tbaa !29
  %t256 = getelementptr %"compiler/check:Checker", ptr %t253, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !29
  %t258 = load i64, ptr %l11, !tbaa !24
  %t261 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %t257, i64 %t258)
  store i64 %t261, ptr %l146
  br label %bb75
bb75:
  %t262 = load ptr, ptr %l12, !tbaa !29
  %t264 = getelementptr %"compiler/ast:Func", ptr %t262, i32 0, i32 0
  %t265 = getelementptr %"compiler/source:Span", ptr %t264, i32 0, i32 0
  %t266 = load i32, ptr %t265, !tbaa !23
  %t268 = sext i32 %t266 to i64
  %t269 = load ptr, ptr %l139, !tbaa !29
  %t270 = load i64, ptr %l146, !tbaa !24
  %t272 = call i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edeprecatedAt(ptr %v0, ptr %t269, i64 %t270, i64 %t268, i1 false)
  store i1 %t272, ptr %l150
  br label %bb76
bb76:
  %t273 = load ptr, ptr %l123, !tbaa !29
  %t274 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t275 = load i64, ptr %l125, !tbaa !24
  %t276 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t277 = load i1, ptr %l150, !tbaa !21
  call void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAddDep(ptr %v1, ptr %v0, ptr %s3, ptr %t273, { i64, ptr } %t274, i64 %t275, { i64, ptr } %t276, i1 %t277)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s3)
  br label %bb78
bb78:
  %t278 = load i64, ptr %l10, !tbaa !24
  %t281 = add i64 %t278, 1
  store i64 %t281, ptr %l10, !tbaa !24
  br label %bb34
bb79:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t284 = load ptr, ptr %l1, !tbaa !29
  %t285 = load i32, ptr %l5, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2esuppliedMembers(ptr %v0, ptr %v1, ptr %t283, ptr %t284, i32 %t285)
  br label %bb80
bb80:
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNext(ptr %v0, ptr %v1, ptr noalias dereferenceable(48) align 8 %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"std/prelude/text:LineIter"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca { i64, ptr }
  %l25 = alloca i1
  %l26 = alloca { i64, ptr }
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca { i64, ptr }
  %l65 = alloca %"std/prelude/text:LineIter"
  %l66 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l71 = alloca i1
  %l73 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l82 = alloca i64
  %l83 = alloca i64
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l90 = alloca i32
  %l91 = alloca i64
  %l92 = alloca i32
  %l106 = alloca { i64, ptr }
  %l107 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t3)
  store { i64, ptr } %t5, ptr %l13
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t13 = add i64 %t11, 3
  %t14 = load i64, ptr %l2, !tbaa !24
  %t17 = icmp slt i64 %t13, %t14
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l21, !tbaa !27
  %t20 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t20
  %t25 = load i8, ptr %t24, !tbaa !32
  %t27 = icmp eq i8 %t25, 13
  br i1 %t27, label %bb5, label %bb6
bb4:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb14
bb5:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %l26, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  %t32 = add i64 %t30, 1
  %t34 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr i8, ptr %t35, i64 %t32
  %t37 = load i8, ptr %t36, !tbaa !32
  %t39 = icmp eq i8 %t37, 10
  store i1 %t39, ptr %l25, !tbaa !21
  br label %bb7
bb6:
  store i1 false, ptr %l25, !tbaa !21
  br label %bb7
bb7:
  %t41 = load i1, ptr %l25, !tbaa !21
  br i1 %t41, label %bb8, label %bb9
bb8:
  %t42 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t42, ptr %l32, !tbaa !27
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = add i64 %t43, 2
  %t47 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t52 = icmp eq i8 %t50, 13
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb10
bb9:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t54 = load i1, ptr %l31, !tbaa !21
  br i1 %t54, label %bb11, label %bb12
bb11:
  %t55 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load i64, ptr %l3, !tbaa !24
  %t58 = add i64 %t56, 3
  %t60 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp eq i8 %t63, 10
  store i1 %t65, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t67 = load i1, ptr %l37, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l20, !tbaa !21
  br label %bb14
bb14:
  %t70 = load i1, ptr %l20, !tbaa !21
  %t71 = xor i1 %t70, true
  br i1 %t71, label %bb15, label %bb16
bb15:
  br label %bb19
bb16:
  br label %bb17
bb17:
  %t73 = load i64, ptr %l3, !tbaa !24
  %t76 = add i64 %t73, 1
  store i64 %t76, ptr %l3, !tbaa !24
  br label %bb18
bb18:
  br label %bb2
bb19:
  %t78 = load i64, ptr %l3, !tbaa !24
  %t80 = add i64 %t78, 3
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = icmp sge i64 %t80, %t81
  br i1 %t84, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t87 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t87, ptr %rv
  br label %ret
bb21:
  br label %bb22
bb22:
  %t88 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t88, ptr %l53, !tbaa !27
  %t89 = load i64, ptr %l3, !tbaa !24
  store i64 %t89, ptr %l54, !tbaa !24
  %t90 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l55, !tbaa !24
  %t92 = icmp sge i64 0, 0
  br i1 %t92, label %bb23, label %bb24
bb23:
  %t94 = load i64, ptr %l54, !tbaa !24
  %t95 = icmp sle i64 0, %t94
  br i1 %t95, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb25:
  %t97 = load i64, ptr %l54, !tbaa !24
  %t98 = load i64, ptr %l55, !tbaa !24
  %t99 = icmp sle i64 %t97, %t98
  br i1 %t99, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb27:
  %t101 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l54, !tbaa !24
  %t104 = getelementptr i8, ptr %t102, i64 0
  %t105 = sub i64 %t103, 0
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l60, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l61, !tbaa !24
  %t111 = load i64, ptr %l61, !tbaa !24
  %t112 = mul i64 %t111, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t111, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l62, !tbaa !27
  %t116 = getelementptr { i64, ptr }, ptr %l62, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %l60, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = load i64, ptr %l61, !tbaa !24
  %t121 = mul i64 %t120, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t117, ptr %t119, i64 %t121, i1 false)
  %t122 = load { i64, ptr }, ptr %l62, !tbaa !27
  store i64 -1, ptr %l5, !tbaa !24
  %t126 = call %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %s0, ptr %s0, { i64, ptr } %t122)
  store %"std/prelude/text:LineIter" %t126, ptr %l65
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb)
  unreachable
bb29:
  %t127 = load %"std/prelude/text:LineIter", ptr %l65
  store %"std/prelude/text:LineIter" %t127, ptr %l6
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s4
  %t129 = call { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %s0, ptr %s0, ptr %l6)
  %t130 = extractvalue { i32, { i64, ptr } } %t129, 1
  %t131 = extractvalue { i32, { i64, ptr } } %t129, 0
  store i32 %t131, ptr %l69
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb32, label %ok.133, !prof !99
ok.133:
  store { i64, ptr } %t130, ptr %l68
  br label %bb31
bb31:
  %t134 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t134, ptr %l66, !tbaa !27
  br label %bb34
bb32:
  %t135 = load i32, ptr %l69, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l71, !tbaa !21
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s4)
  br label %bb55
bb34:
  %t139 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t142 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s0, { i64, ptr } %t139)
  store { i64, ptr } %t142, ptr %l73
  br label %bb35
bb35:
  %t143 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t143, ptr %l8, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t146 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %s0, ptr %s4, { i64, ptr } %t144)
  store { i64, ptr } %t146, ptr %l75
  br label %bb36
bb36:
  %t147 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t149 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s4, ptr %s4, { i64, ptr } %t147, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d113, i32 0, i32 1) })
  store i1 %t149, ptr %l77
  br label %bb37
bb37:
  %t150 = load i1, ptr %l77, !tbaa !21
  br i1 %t150, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s5
  %t151 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t151, ptr %l79, !tbaa !27
  %t152 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t152, 0
  store i64 %t155, ptr %l82, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  store i64 %t157, ptr %l83, !tbaa !24
  %t158 = icmp sge i64 15, 0
  br i1 %t158, label %bb40, label %bb41
bb39:
  br label %bb53
bb40:
  %t160 = load i64, ptr %l82, !tbaa !24
  %t161 = icmp sle i64 15, %t160
  br i1 %t161, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb42:
  %t163 = load i64, ptr %l82, !tbaa !24
  %t164 = load i64, ptr %l83, !tbaa !24
  %t165 = icmp sle i64 %t163, %t164
  br i1 %t165, label %bb44, label %bb45
bb43:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb44:
  %t167 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = load i64, ptr %l82, !tbaa !24
  %t170 = getelementptr i8, ptr %t168, i64 15
  %t171 = sub i64 %t169, 15
  %t172 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t170, 1
  %t175 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %s0, ptr %s5, { i64, ptr } %t173)
  store { i64, ptr } %t175, ptr %l88
  br label %bb46
bb45:
  call void @__olang_check_failed(ptr @olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e)
  unreachable
bb46:
  %t176 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s5, i64 10)
  %t177 = extractvalue { i32, i64 } %t176, 1
  %t178 = extractvalue { i32, i64 } %t176, 0
  store i32 %t178, ptr %l90
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb48, label %ok.180, !prof !99
ok.180:
  store i64 %t177, ptr %l89
  br label %bb47
bb47:
  %t181 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t182 = load i64, ptr %l89, !tbaa !24
  %t183 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %s5, { i64, ptr } %t181, i64 %t182)
  %t184 = extractvalue { i32, i64 } %t183, 1
  %t185 = extractvalue { i32, i64 } %t183, 0
  store i32 %t185, ptr %l92
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb51, label %ok.187, !prof !99
ok.187:
  store i64 %t184, ptr %l91
  br label %bb50
bb48:
  br label %bb49
bb49:
  store i64 -1, ptr %l78, !tbaa !24
  br label %bb52
bb50:
  %t188 = load i64, ptr %l91, !tbaa !24
  store i64 %t188, ptr %l78, !tbaa !24
  br label %bb52
bb51:
  br label %bb49
bb52:
  %t189 = load i64, ptr %l78, !tbaa !24
  store i64 %t189, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s4)
  br label %bb54
bb54:
  br label %bb30
bb55:
  %t190 = load i64, ptr %l3, !tbaa !24
  %t192 = add i64 %t190, 4
  store i64 %t192, ptr %l9, !tbaa !24
  %t194 = load i64, ptr %l5, !tbaa !24
  %t196 = icmp slt i64 %t194, 0
  br i1 %t196, label %bb56, label %bb57
bb56:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i64, ptr %l9, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t198, i64 %t199)
  br label %bb58
bb57:
  br label %bb59
bb58:
  call void @__olang_scope_close(ptr %s0)
  %t203 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t203, ptr %rv
  br label %ret
bb59:
  %t204 = load i64, ptr %l2, !tbaa !24
  %t205 = load i64, ptr %l9, !tbaa !24
  %t206 = load i64, ptr %l5, !tbaa !24
  %t209 = add i64 %t205, %t206
  %t212 = icmp slt i64 %t204, %t209
  br i1 %t212, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t215 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t215, ptr %rv
  br label %ret
bb61:
  br label %bb62
bb62:
  %t216 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t216, ptr %l106, !tbaa !27
  %t217 = load i64, ptr %l9, !tbaa !24
  store i64 %t217, ptr %l107, !tbaa !24
  %t218 = load i64, ptr %l9, !tbaa !24
  %t219 = load i64, ptr %l5, !tbaa !24
  %t222 = add i64 %t218, %t219
  store i64 %t222, ptr %l110, !tbaa !24
  %t223 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t223, 0
  store i64 %t224, ptr %l111, !tbaa !24
  %t225 = load i64, ptr %l107, !tbaa !24
  %t226 = icmp sge i64 %t225, 0
  br i1 %t226, label %bb63, label %bb64
bb63:
  %t228 = load i64, ptr %l107, !tbaa !24
  %t229 = load i64, ptr %l110, !tbaa !24
  %t230 = icmp sle i64 %t228, %t229
  br i1 %t230, label %bb65, label %bb66
bb64:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb65:
  %t232 = load i64, ptr %l110, !tbaa !24
  %t233 = load i64, ptr %l111, !tbaa !24
  %t234 = icmp sle i64 %t232, %t233
  br i1 %t234, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb67:
  %t236 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = load i64, ptr %l107, !tbaa !24
  %t239 = load i64, ptr %l110, !tbaa !24
  %t240 = getelementptr i8, ptr %t237, i64 %t238
  %t241 = sub i64 %t239, %t238
  %t242 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  store { i64, ptr } %t243, ptr %l116, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  store i64 %t246, ptr %l117, !tbaa !24
  %t247 = load i64, ptr %l117, !tbaa !24
  %t248 = mul i64 %t247, 1
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  %t250 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  store { i64, ptr } %t251, ptr %l118, !tbaa !27
  %t252 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = load i64, ptr %l117, !tbaa !24
  %t257 = mul i64 %t256, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t253, ptr %t255, i64 %t257, i1 false)
  %t258 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t258, 1
  %t261 = extractvalue { i64, ptr } %t258, 0
  %t262 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t260, i64 %t261)
  %t263 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t262, 1
  store { i64, ptr } %t264, ptr %l10, !tbaa !27
  %t266 = load ptr, ptr %l0, !tbaa !29
  %t267 = load i64, ptr %l9, !tbaa !24
  %t268 = load i64, ptr %l5, !tbaa !24
  %t271 = add i64 %t267, %t268
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t266, i64 %t271)
  br label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_7fa1338bfb5c4549_286381a3bde0b91d)
  unreachable
bb69:
  %t274 = load { i64, ptr }, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t276 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t274, 1
  store { i32, { i64, ptr } } %t276, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fsession_2ecompiler_2fsession_3aReader_2eNextLine(ptr %v0, ptr %v1, ptr noalias dereferenceable(48) align 8 %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l5 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l35 = alloca i64
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca i64
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:Reader", ptr %t1, i32 0, i32 1
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v0, ptr %t3)
  store { i64, ptr } %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  store i64 %t9, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l2, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  br i1 %t15, label %bb3, label %bb4
bb3:
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  %t25 = icmp ne i8 %t23, 10
  store i1 %t25, ptr %l14, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l14, !tbaa !21
  br label %bb5
bb5:
  %t27 = load i1, ptr %l14, !tbaa !21
  %t28 = xor i1 %t27, true
  br i1 %t28, label %bb6, label %bb7
bb6:
  br label %bb10
bb7:
  br label %bb8
bb8:
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = add i64 %t30, 1
  store i64 %t33, ptr %l3, !tbaa !24
  br label %bb9
bb9:
  br label %bb2
bb10:
  %t35 = load i64, ptr %l3, !tbaa !24
  %t36 = load i64, ptr %l2, !tbaa !24
  %t39 = icmp sge i64 %t35, %t36
  br i1 %t39, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t43 = load i64, ptr %l3, !tbaa !24
  %t45 = icmp sgt i64 %t43, 0
  br i1 %t45, label %bb14, label %bb15
bb14:
  %t47 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t47, ptr %l30, !tbaa !27
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = sub i64 %t48, 1
  %t52 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr i8, ptr %t53, i64 %t50
  %t55 = load i8, ptr %t54, !tbaa !32
  %t57 = icmp eq i8 %t55, 13
  store i1 %t57, ptr %l29, !tbaa !21
  br label %bb16
bb15:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb16
bb16:
  %t59 = load i1, ptr %l29, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  %t60 = load i64, ptr %l3, !tbaa !24
  %t62 = sub i64 %t60, 1
  store i64 %t62, ptr %l35, !tbaa !24
  br label %bb19
bb18:
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %l35, !tbaa !24
  br label %bb19
bb19:
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t67, ptr %l39, !tbaa !27
  store i64 %t66, ptr %l40, !tbaa !24
  %t69 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  store i64 %t70, ptr %l41, !tbaa !24
  %t71 = icmp sge i64 0, 0
  br i1 %t71, label %bb20, label %bb21
bb20:
  %t73 = load i64, ptr %l40, !tbaa !24
  %t74 = icmp sle i64 0, %t73
  br i1 %t74, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb22:
  %t76 = load i64, ptr %l40, !tbaa !24
  %t77 = load i64, ptr %l41, !tbaa !24
  %t78 = icmp sle i64 %t76, %t77
  br i1 %t78, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb24:
  %t80 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l40, !tbaa !24
  %t83 = getelementptr i8, ptr %t81, i64 0
  %t84 = sub i64 %t82, 0
  %t85 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t83, 1
  store { i64, ptr } %t86, ptr %l46, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  store i64 %t89, ptr %l47, !tbaa !24
  %t90 = load i64, ptr %l47, !tbaa !24
  %t91 = mul i64 %t90, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l48, !tbaa !27
  %t95 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l47, !tbaa !24
  %t100 = mul i64 %t99, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t96, ptr %t98, i64 %t100, i1 false)
  %t101 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = extractvalue { i64, ptr } %t101, 0
  %t105 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t103, i64 %t104)
  %t106 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l5, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i64, ptr %l3, !tbaa !24
  %t112 = add i64 %t110, 1
  call void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %t109, i64 %t112)
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_98e1614ed1d054f5_86eb50e982cc0441)
  unreachable
bb26:
  %t115 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t117 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t115, 1
  store { i32, { i64, ptr } } %t117, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ebodyCallee(ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"compiler/source:Span" %a1, { i64, [2 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca { i64, [2 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l6 = alloca i32
  %l12 = alloca ptr
  %l15 = alloca i64
  %l18 = alloca ptr
  %l24 = alloca ptr
  %l26 = alloca i1
  %l31 = alloca ptr
  %l34 = alloca ptr
  %l37 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l58 = alloca ptr
  %l61 = alloca ptr
  %l64 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l76 = alloca i1
  %l80 = alloca ptr
  %l86 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca %"compiler/source:Span"
  %l99 = alloca ptr
  %l102 = alloca i64
  %l112 = alloca ptr
  %l115 = alloca i32
  %l122 = alloca ptr
  %l125 = alloca i32
  %l130 = alloca ptr
  %l134 = alloca ptr
  %l137 = alloca i32
  %l142 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l147 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca %"compiler/source:Span"
  %l152 = alloca ptr
  %l155 = alloca i64
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %t142 = alloca { i64, [6 x i64] }, align 8
  %t267 = alloca { i64, [6 x i64] }, align 8
  %t299 = alloca { i64, [6 x i64] }, align 8
  %t461 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store { i64, [2 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, [2 x i64] }, ptr %l2
  %t3 = extractvalue { i64, [2 x i64] } %t1, 0
  %t4 = icmp eq i64 %t3, 0
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l3, !tbaa !24
  br label %bb3
bb2:
  br label %bb30
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/session:finder", ptr %t10, i32 0, i32 3
  %t13 = load ptr, ptr %t12, !tbaa !29
  %t15 = getelementptr %"compiler/check:Checker", ptr %t13, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !29
  store ptr %t16, ptr %l12, !tbaa !29
  %t17 = load i64, ptr %l3, !tbaa !24
  %t18 = load ptr, ptr %l12, !tbaa !29
  %t19 = call ptr @__olang_scope_or(ptr %v1, ptr %t18)
  %t20 = call ptr @__olang_scope_hold(ptr %t19)
  %t21 = ptrtoint ptr %t20 to i64
  %t23 = inttoptr i64 %t21 to ptr
  %t24 = load ptr, ptr %l12, !tbaa !29
  %t26 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %t23, ptr %t24, i64 %t17)
  store i64 %t26, ptr %l15
  br label %bb4
bb4:
  %t27 = load i64, ptr %l15, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/session:finder", ptr %t28, i32 0, i32 3
  %t31 = load ptr, ptr %t30, !tbaa !29
  %t33 = getelementptr %"compiler/check:Checker", ptr %t31, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t35 = load i64, ptr %l4, !tbaa !24
  %t36 = load ptr, ptr %l18, !tbaa !29
  %t37 = call ptr @__olang_scope_or(ptr %v1, ptr %t36)
  %t38 = call ptr @__olang_scope_hold(ptr %t37)
  %t39 = ptrtoint ptr %t38 to i64
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/session:finder", ptr %t40, i32 0, i32 3
  %t43 = load ptr, ptr %t42, !tbaa !29
  %t45 = call ptr @__olang_scope_or(ptr %v1, ptr %t43)
  %t46 = call ptr @__olang_scope_hold(ptr %t45)
  %t47 = ptrtoint ptr %t46 to i64
  %t49 = inttoptr i64 %t39 to ptr
  %t51 = inttoptr i64 %t47 to ptr
  %t52 = load ptr, ptr %l18, !tbaa !29
  %t54 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %t49, ptr %t51, ptr %t52, i64 %t35)
  store ptr %t54, ptr %l24
  br label %bb5
bb5:
  %t55 = load ptr, ptr %l24, !tbaa !29
  %t56 = call ptr @__olang_scope_or(ptr %v1, ptr %t55)
  %t57 = call ptr @__olang_scope_hold(ptr %t56)
  %t58 = ptrtoint ptr %t57 to i64
  %t60 = inttoptr i64 %t58 to ptr
  %t61 = load ptr, ptr %l24, !tbaa !29
  %t62 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %t60, ptr %t61)
  store i1 %t62, ptr %l26
  br label %bb6
bb6:
  %t63 = load i1, ptr %l26, !tbaa !21
  br i1 %t63, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/session:finder", ptr %t64, i32 0, i32 3
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = getelementptr %"compiler/check:Checker", ptr %t67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = getelementptr %"compiler/generic:Program", ptr %t70, i32 0, i32 0
  %t73 = load ptr, ptr %t72, !tbaa !29
  %t75 = getelementptr %"compiler/load:Loader", ptr %t73, i32 0, i32 3
  %t76 = load ptr, ptr %t75, !tbaa !29
  store ptr %t76, ptr %l31, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/session:finder", ptr %t77, i32 0, i32 3
  %t80 = load ptr, ptr %t79, !tbaa !29
  %t82 = getelementptr %"compiler/check:Checker", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  store ptr %t83, ptr %l34, !tbaa !29
  %t84 = load i64, ptr %l4, !tbaa !24
  %t85 = load ptr, ptr %l34, !tbaa !29
  %t86 = call ptr @__olang_scope_or(ptr %v1, ptr %t85)
  %t87 = call ptr @__olang_scope_hold(ptr %t86)
  %t88 = ptrtoint ptr %t87 to i64
  %t90 = inttoptr i64 %t88 to ptr
  %t91 = load ptr, ptr %l34, !tbaa !29
  %t93 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %t90, ptr %s2, ptr %t91, i64 %t84)
  store ptr %t93, ptr %l37
  br label %bb9
bb8:
  br label %bb16
bb9:
  %t94 = load ptr, ptr %l37, !tbaa !29
  %t96 = getelementptr %"compiler/ast:Func", ptr %t94, i32 0, i32 9
  %t97 = load i32, ptr %t96, !tbaa !23
  %t98 = load ptr, ptr %l31, !tbaa !29
  %t99 = call ptr @__olang_scope_or(ptr %v1, ptr %t98)
  %t100 = call ptr @__olang_scope_hold(ptr %t99)
  %t101 = ptrtoint ptr %t100 to i64
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/session:finder", ptr %t102, i32 0, i32 3
  %t105 = load ptr, ptr %t104, !tbaa !29
  %t107 = call ptr @__olang_scope_or(ptr %v1, ptr %t105)
  %t108 = call ptr @__olang_scope_hold(ptr %t107)
  %t109 = ptrtoint ptr %t108 to i64
  %t111 = inttoptr i64 %t101 to ptr
  %t113 = inttoptr i64 %t109 to ptr
  %t114 = load ptr, ptr %l31, !tbaa !29
  %t116 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t111, ptr %t113, ptr %t114, i32 %t97)
  store { i64, ptr } %t116, ptr %l44
  br label %bb10
bb10:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/session:finder", ptr %t117, i32 0, i32 2
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l46, !tbaa !27
  %t121 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 1
  %t123 = call ptr @__olang_scope_or(ptr %v1, ptr %t122)
  %t124 = call ptr @__olang_scope_hold(ptr %t123)
  %t125 = ptrtoint ptr %t124 to i64
  %t126 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = call ptr @__olang_scope_or(ptr %v2, ptr %t127)
  %t129 = call ptr @__olang_scope_hold(ptr %t128)
  %t130 = ptrtoint ptr %t129 to i64
  %t132 = inttoptr i64 %t125 to ptr
  %t134 = inttoptr i64 %t130 to ptr
  %t135 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t137 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t132, ptr %t134, { i64, ptr } %t135, { i64, ptr } %t136)
  store i1 %t137, ptr %l49
  br label %bb11
bb11:
  %t138 = load i1, ptr %l49, !tbaa !21
  br i1 %t138, label %bb12, label %bb13
bb12:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load %"compiler/source:Span", ptr %l1
  %t141 = load i64, ptr %l4, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t142
  %t143 = getelementptr { i64, [6 x i64] }, ptr %t142, i32 0, i32 0
  store i64 2, ptr %t143
  %t145 = insertvalue { i64 } undef, i64 %t141, 0
  %t146 = getelementptr { i64, [6 x i64] }, ptr %t142, i32 0, i32 1
  store { i64 } %t145, ptr %t146
  %t147 = load { i64, [6 x i64] }, ptr %t142
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t139, %"compiler/source:Span" %t140, { i64, [6 x i64] } %t147)
  br label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb16:
  %t151 = load ptr, ptr %l0, !tbaa !29
  %t153 = getelementptr %"compiler/session:finder", ptr %t151, i32 0, i32 3
  %t154 = load ptr, ptr %t153, !tbaa !29
  %t156 = getelementptr %"compiler/check:Checker", ptr %t154, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !29
  %t159 = getelementptr %"compiler/generic:Program", ptr %t157, i32 0, i32 0
  %t160 = load ptr, ptr %t159, !tbaa !29
  %t162 = getelementptr %"compiler/load:Loader", ptr %t160, i32 0, i32 3
  %t163 = load ptr, ptr %t162, !tbaa !29
  store ptr %t163, ptr %l58, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/session:finder", ptr %t164, i32 0, i32 3
  %t167 = load ptr, ptr %t166, !tbaa !29
  %t169 = getelementptr %"compiler/check:Checker", ptr %t167, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !29
  store ptr %t170, ptr %l61, !tbaa !29
  %t171 = load i64, ptr %l4, !tbaa !24
  %t172 = load ptr, ptr %l61, !tbaa !29
  %t173 = call ptr @__olang_scope_or(ptr %v1, ptr %t172)
  %t174 = call ptr @__olang_scope_hold(ptr %t173)
  %t175 = ptrtoint ptr %t174 to i64
  %t177 = inttoptr i64 %t175 to ptr
  %t178 = load ptr, ptr %l61, !tbaa !29
  %t180 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %t177, ptr %s1, ptr %t178, i64 %t171)
  store ptr %t180, ptr %l64
  br label %bb17
bb17:
  %t181 = load ptr, ptr %l64, !tbaa !29
  %t183 = getelementptr %"compiler/ast:Func", ptr %t181, i32 0, i32 2
  %t184 = load i32, ptr %t183, !tbaa !23
  %t185 = load ptr, ptr %l58, !tbaa !29
  %t186 = call ptr @__olang_scope_or(ptr %v1, ptr %t185)
  %t187 = call ptr @__olang_scope_hold(ptr %t186)
  %t188 = ptrtoint ptr %t187 to i64
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/session:finder", ptr %t189, i32 0, i32 3
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = call ptr @__olang_scope_or(ptr %v1, ptr %t192)
  %t195 = call ptr @__olang_scope_hold(ptr %t194)
  %t196 = ptrtoint ptr %t195 to i64
  %t198 = inttoptr i64 %t188 to ptr
  %t200 = inttoptr i64 %t196 to ptr
  %t201 = load ptr, ptr %l58, !tbaa !29
  %t203 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t198, ptr %t200, ptr %t201, i32 %t184)
  store { i64, ptr } %t203, ptr %l71
  br label %bb18
bb18:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t206 = getelementptr %"compiler/session:finder", ptr %t204, i32 0, i32 2
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  store { i64, ptr } %t207, ptr %l73, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t209 = extractvalue { i64, ptr } %t208, 1
  %t210 = call ptr @__olang_scope_or(ptr %v1, ptr %t209)
  %t211 = call ptr @__olang_scope_hold(ptr %t210)
  %t212 = ptrtoint ptr %t211 to i64
  %t213 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t213, 1
  %t215 = call ptr @__olang_scope_or(ptr %v2, ptr %t214)
  %t216 = call ptr @__olang_scope_hold(ptr %t215)
  %t217 = ptrtoint ptr %t216 to i64
  %t219 = inttoptr i64 %t212 to ptr
  %t221 = inttoptr i64 %t217 to ptr
  %t222 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t219, ptr %t221, { i64, ptr } %t222, { i64, ptr } %t223)
  store i1 %t224, ptr %l76
  br label %bb19
bb19:
  %t225 = load i1, ptr %l76, !tbaa !21
  %t226 = xor i1 %t225, true
  br i1 %t226, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s1)
  br label %ret
bb21:
  br label %bb22
bb22:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/session:finder", ptr %t228, i32 0, i32 3
  %t231 = load ptr, ptr %t230, !tbaa !29
  %t233 = getelementptr %"compiler/check:Checker", ptr %t231, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !29
  store ptr %t234, ptr %l80, !tbaa !29
  %t235 = load i64, ptr %l4, !tbaa !24
  %t236 = load ptr, ptr %l80, !tbaa !29
  %t237 = call ptr @__olang_scope_or(ptr %v1, ptr %t236)
  %t238 = call ptr @__olang_scope_hold(ptr %t237)
  %t239 = ptrtoint ptr %t238 to i64
  %t240 = load ptr, ptr %l0, !tbaa !29
  %t242 = getelementptr %"compiler/session:finder", ptr %t240, i32 0, i32 3
  %t243 = load ptr, ptr %t242, !tbaa !29
  %t245 = call ptr @__olang_scope_or(ptr %v1, ptr %t243)
  %t246 = call ptr @__olang_scope_hold(ptr %t245)
  %t247 = ptrtoint ptr %t246 to i64
  %t249 = inttoptr i64 %t239 to ptr
  %t251 = inttoptr i64 %t247 to ptr
  %t252 = load ptr, ptr %l80, !tbaa !29
  %t254 = call ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %t249, ptr %t251, ptr %t252, i64 %t235)
  store ptr %t254, ptr %l86
  br label %bb23
bb23:
  %t255 = load ptr, ptr %l86, !tbaa !29
  %t257 = getelementptr %"compiler/ast:Func", ptr %t255, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !29
  %t260 = icmp eq ptr %t258, null
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb24, label %bb25
bb24:
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load %"compiler/source:Span", ptr %l1
  %t266 = load i64, ptr %l4, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [6 x i64] }, ptr %t267, i32 0, i32 0
  store i64 2, ptr %t268
  %t270 = insertvalue { i64 } undef, i64 %t266, 0
  %t271 = getelementptr { i64, [6 x i64] }, ptr %t267, i32 0, i32 1
  store { i64 } %t270, ptr %t271
  %t272 = load { i64, [6 x i64] }, ptr %t267
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t264, %"compiler/source:Span" %t265, { i64, [6 x i64] } %t272)
  br label %bb26
bb25:
  %t276 = load ptr, ptr %l0, !tbaa !29
  store ptr %t276, ptr %l95, !tbaa !29
  %t277 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t277, ptr %l96
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/session:finder", ptr %t278, i32 0, i32 3
  %t281 = load ptr, ptr %t280, !tbaa !29
  %t283 = getelementptr %"compiler/check:Checker", ptr %t281, i32 0, i32 1
  %t284 = load ptr, ptr %t283, !tbaa !29
  store ptr %t284, ptr %l99, !tbaa !29
  %t285 = load i64, ptr %l4, !tbaa !24
  %t286 = load ptr, ptr %l99, !tbaa !29
  %t287 = call ptr @__olang_scope_or(ptr %v1, ptr %t286)
  %t288 = call ptr @__olang_scope_hold(ptr %t287)
  %t289 = ptrtoint ptr %t288 to i64
  %t291 = inttoptr i64 %t289 to ptr
  %t292 = load ptr, ptr %l99, !tbaa !29
  %t294 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %t291, ptr %t292, i64 %t285)
  store i64 %t294, ptr %l102
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/session:finder", ptr %t295, i32 0, i32 2
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t299
  %t300 = getelementptr { i64, [6 x i64] }, ptr %t299, i32 0, i32 0
  store i64 1, ptr %t300
  %t301 = load i64, ptr %l102, !tbaa !24
  %t302 = insertvalue { i64, { i64, ptr } } undef, i64 %t301, 0
  %t304 = insertvalue { i64, { i64, ptr } } %t302, { i64, ptr } %t298, 1
  %t305 = getelementptr { i64, [6 x i64] }, ptr %t299, i32 0, i32 1
  store { i64, { i64, ptr } } %t304, ptr %t305
  %t306 = load { i64, [6 x i64] }, ptr %t299
  %t307 = load ptr, ptr %l95, !tbaa !29
  %t308 = load %"compiler/source:Span", ptr %l96
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t307, %"compiler/source:Span" %t308, { i64, [6 x i64] } %t306)
  br label %bb28
bb28:
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s1)
  br label %bb52
bb30:
  %t310 = load { i64, [2 x i64] }, ptr %l2
  %t312 = extractvalue { i64, [2 x i64] } %t310, 0
  %t313 = icmp eq i64 %t312, 1
  br i1 %t313, label %bb31, label %bb32
bb31:
  %t315 = getelementptr { i64, [2 x i64] }, ptr %l2, i32 0, i32 1
  %t316 = getelementptr { i32, i32 }, ptr %t315, i32 0, i32 0
  %t317 = load i32, ptr %t316
  store i32 %t317, ptr %l5, !tbaa !23
  br label %bb33
bb32:
  br label %bb47
bb33:
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t321 = getelementptr %"compiler/session:finder", ptr %t319, i32 0, i32 3
  %t322 = load ptr, ptr %t321, !tbaa !29
  %t324 = getelementptr %"compiler/check:Checker", ptr %t322, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !29
  %t327 = getelementptr %"compiler/generic:Program", ptr %t325, i32 0, i32 2
  store ptr %t327, ptr %l112, !tbaa !29
  %t328 = load i32, ptr %l5, !tbaa !23
  %t329 = load ptr, ptr %l112, !tbaa !29
  %t330 = call ptr @__olang_scope_or(ptr %v1, ptr %t329)
  %t331 = call ptr @__olang_scope_hold(ptr %t330)
  %t332 = ptrtoint ptr %t331 to i64
  %t334 = inttoptr i64 %t332 to ptr
  %t335 = load ptr, ptr %l112, !tbaa !29
  %t337 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %t334, ptr %t335, i32 %t328)
  store i32 %t337, ptr %l115
  br label %bb34
bb34:
  %t338 = load i32, ptr %l115, !range !{i32 0, i32 33}
  %t340 = trunc i64 18 to i32
  %t341 = icmp eq i32 %t338, %t340
  %t343 = xor i1 %t341, true
  br i1 %t343, label %bb35, label %bb36
bb35:
  br label %ret
bb36:
  br label %bb37
bb37:
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = getelementptr %"compiler/session:finder", ptr %t345, i32 0, i32 3
  %t348 = load ptr, ptr %t347, !tbaa !29
  %t350 = getelementptr %"compiler/check:Checker", ptr %t348, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !29
  %t353 = getelementptr %"compiler/generic:Program", ptr %t351, i32 0, i32 2
  store ptr %t353, ptr %l122, !tbaa !29
  %t354 = load i32, ptr %l5, !tbaa !23
  %t355 = load ptr, ptr %l122, !tbaa !29
  %t356 = call ptr @__olang_scope_or(ptr %v1, ptr %t355)
  %t357 = call ptr @__olang_scope_hold(ptr %t356)
  %t358 = ptrtoint ptr %t357 to i64
  %t360 = inttoptr i64 %t358 to ptr
  %t361 = load ptr, ptr %l122, !tbaa !29
  %t363 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %t360, ptr %t361, i32 %t354)
  store i32 %t363, ptr %l125
  br label %bb38
bb38:
  %t364 = load i32, ptr %l125, !tbaa !23
  store i32 %t364, ptr %l6, !tbaa !23
  %t365 = load ptr, ptr %l0, !tbaa !29
  %t367 = getelementptr %"compiler/session:finder", ptr %t365, i32 0, i32 3
  %t368 = load ptr, ptr %t367, !tbaa !29
  %t370 = getelementptr %"compiler/check:Checker", ptr %t368, i32 0, i32 1
  %t371 = load ptr, ptr %t370, !tbaa !29
  %t373 = getelementptr %"compiler/generic:Program", ptr %t371, i32 0, i32 0
  %t374 = load ptr, ptr %t373, !tbaa !29
  %t376 = getelementptr %"compiler/load:Loader", ptr %t374, i32 0, i32 3
  %t377 = load ptr, ptr %t376, !tbaa !29
  store ptr %t377, ptr %l130, !tbaa !29
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = getelementptr %"compiler/session:finder", ptr %t378, i32 0, i32 3
  %t381 = load ptr, ptr %t380, !tbaa !29
  %t383 = getelementptr %"compiler/check:Checker", ptr %t381, i32 0, i32 1
  %t384 = load ptr, ptr %t383, !tbaa !29
  %t386 = getelementptr %"compiler/generic:Program", ptr %t384, i32 0, i32 2
  store ptr %t386, ptr %l134, !tbaa !29
  %t387 = load i32, ptr %l6, !tbaa !23
  %t388 = load ptr, ptr %l134, !tbaa !29
  %t389 = call ptr @__olang_scope_or(ptr %v1, ptr %t388)
  %t390 = call ptr @__olang_scope_hold(ptr %t389)
  %t391 = ptrtoint ptr %t390 to i64
  %t393 = inttoptr i64 %t391 to ptr
  %t394 = load ptr, ptr %l134, !tbaa !29
  %t396 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %t393, ptr %t394, i32 %t387)
  store i32 %t396, ptr %l137
  br label %bb39
bb39:
  %t397 = load ptr, ptr %l130, !tbaa !29
  %t398 = call ptr @__olang_scope_or(ptr %v1, ptr %t397)
  %t399 = call ptr @__olang_scope_hold(ptr %t398)
  %t400 = ptrtoint ptr %t399 to i64
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/session:finder", ptr %t401, i32 0, i32 3
  %t404 = load ptr, ptr %t403, !tbaa !29
  %t406 = call ptr @__olang_scope_or(ptr %v1, ptr %t404)
  %t407 = call ptr @__olang_scope_hold(ptr %t406)
  %t408 = ptrtoint ptr %t407 to i64
  %t410 = inttoptr i64 %t400 to ptr
  %t412 = inttoptr i64 %t408 to ptr
  %t413 = load ptr, ptr %l130, !tbaa !29
  %t414 = load i32, ptr %l137, !tbaa !23
  %t415 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t410, ptr %t412, ptr %t413, i32 %t414)
  store { i64, ptr } %t415, ptr %l142
  br label %bb40
bb40:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/session:finder", ptr %t416, i32 0, i32 2
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !27
  store { i64, ptr } %t419, ptr %l144, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t420, 1
  %t422 = call ptr @__olang_scope_or(ptr %v1, ptr %t421)
  %t423 = call ptr @__olang_scope_hold(ptr %t422)
  %t424 = ptrtoint ptr %t423 to i64
  %t425 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t426 = extractvalue { i64, ptr } %t425, 1
  %t427 = call ptr @__olang_scope_or(ptr %v2, ptr %t426)
  %t428 = call ptr @__olang_scope_hold(ptr %t427)
  %t429 = ptrtoint ptr %t428 to i64
  %t431 = inttoptr i64 %t424 to ptr
  %t433 = inttoptr i64 %t429 to ptr
  %t434 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t435 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t436 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t431, ptr %t433, { i64, ptr } %t434, { i64, ptr } %t435)
  store i1 %t436, ptr %l147
  br label %bb41
bb41:
  %t437 = load i1, ptr %l147, !tbaa !21
  br i1 %t437, label %bb42, label %bb43
bb42:
  %t438 = load ptr, ptr %l0, !tbaa !29
  store ptr %t438, ptr %l148, !tbaa !29
  %t439 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t439, ptr %l149
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/session:finder", ptr %t440, i32 0, i32 3
  %t443 = load ptr, ptr %t442, !tbaa !29
  %t445 = getelementptr %"compiler/check:Checker", ptr %t443, i32 0, i32 1
  %t446 = load ptr, ptr %t445, !tbaa !29
  store ptr %t446, ptr %l152, !tbaa !29
  %t447 = load i32, ptr %l6, !tbaa !23
  %t448 = load ptr, ptr %l152, !tbaa !29
  %t449 = call ptr @__olang_scope_or(ptr %v1, ptr %t448)
  %t450 = call ptr @__olang_scope_hold(ptr %t449)
  %t451 = ptrtoint ptr %t450 to i64
  %t453 = inttoptr i64 %t451 to ptr
  %t454 = load ptr, ptr %l152, !tbaa !29
  %t456 = call i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %t453, ptr %t454, i32 %t447)
  store i64 %t456, ptr %l155
  br label %bb44
bb43:
  br label %bb46
bb44:
  %t457 = load ptr, ptr %l0, !tbaa !29
  %t459 = getelementptr %"compiler/session:finder", ptr %t457, i32 0, i32 2
  %t460 = load { i64, ptr }, ptr %t459, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t461
  %t462 = getelementptr { i64, [6 x i64] }, ptr %t461, i32 0, i32 0
  store i64 1, ptr %t462
  %t463 = load i64, ptr %l155, !tbaa !24
  %t464 = insertvalue { i64, { i64, ptr } } undef, i64 %t463, 0
  %t466 = insertvalue { i64, { i64, ptr } } %t464, { i64, ptr } %t460, 1
  %t467 = getelementptr { i64, [6 x i64] }, ptr %t461, i32 0, i32 1
  store { i64, { i64, ptr } } %t466, ptr %t467
  %t468 = load { i64, [6 x i64] }, ptr %t461
  %t469 = load ptr, ptr %l148, !tbaa !29
  %t470 = load %"compiler/source:Span", ptr %l149
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t469, %"compiler/source:Span" %t470, { i64, [6 x i64] } %t468)
  br label %bb45
bb45:
  br label %bb46
bb46:
  br label %bb52
bb47:
  br i1 true, label %bb48, label %bb49
bb48:
  br label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_68ddcf9e12618436_cff7fbf614d16d4a)
  unreachable
bb52:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, %"compiler/source:Span" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/source:Span"
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca ptr
  %l10 = alloca i1
  %l16 = alloca ptr
  %l17 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca %"compiler/source:Span"
  %l26 = alloca ptr
  %l33 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i1
  store ptr %a0, ptr %l0
  store %"compiler/source:Span" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 0
  %t2 = load i32, ptr %t1, !tbaa !23
  %t4 = sext i32 %t2 to i64
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/session:finder", ptr %t5, i32 0, i32 0
  %t8 = load i64, ptr %t7, !tbaa !24
  %t11 = icmp sgt i64 %t4, %t8
  br i1 %t11, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb3
bb2:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/session:finder", ptr %t13, i32 0, i32 1
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = getelementptr %"compiler/source:Span", ptr %l1, i32 0, i32 1
  %t18 = load i32, ptr %t17, !tbaa !23
  %t20 = sext i32 %t18 to i64
  %t23 = icmp sgt i64 %t16, %t20
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  %t25 = load i1, ptr %l10, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  br label %ret
bb5:
  br label %bb6
bb6:
  %t26 = load ptr, ptr %l2, !tbaa !29
  store ptr %t26, ptr %l16, !tbaa !29
  store i1 false, ptr %l17, !tbaa !21
  %t27 = load ptr, ptr %l16, !tbaa !29
  %t28 = icmp ne ptr %t27, null
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t30 = load ptr, ptr %l16, !tbaa !29
  %t31 = load i64, ptr %t30, !range !{i64 0, i64 5}
  %t33 = icmp eq i64 %t31, 0
  store i1 %t33, ptr %l17, !tbaa !21
  br label %bb8
bb8:
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr { i64, [3 x i64] }, ptr %t35, i32 0, i32 1
  %t38 = getelementptr { i32 }, ptr %t37, i32 0, i32 0
  %t39 = load i32, ptr %t38
  store i32 %t39, ptr %l3, !tbaa !23
  br label %bb11
bb10:
  br label %bb14
bb11:
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l22, !tbaa !29
  %t42 = load %"compiler/source:Span", ptr %l1
  store %"compiler/source:Span" %t42, ptr %l23
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/session:finder", ptr %t43, i32 0, i32 3
  %t46 = load ptr, ptr %t45, !tbaa !29
  %t48 = getelementptr %"compiler/check:Checker", ptr %t46, i32 0, i32 19
  store ptr %t48, ptr %l26, !tbaa !29
  %t49 = load i32, ptr %l3, !tbaa !23
  %t51 = sext i32 %t49 to i64
  %t52 = load ptr, ptr %l26, !tbaa !29
  %t53 = call ptr @__olang_scope_or(ptr %v2, ptr %t52)
  %t54 = call ptr @__olang_scope_hold(ptr %t53)
  %t55 = ptrtoint ptr %t54 to i64
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/session:finder", ptr %t56, i32 0, i32 3
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = call ptr @__olang_scope_or(ptr %v2, ptr %t59)
  %t62 = call ptr @__olang_scope_hold(ptr %t61)
  %t63 = ptrtoint ptr %t62 to i64
  %t65 = inttoptr i64 %t55 to ptr
  %t67 = inttoptr i64 %t63 to ptr
  %t68 = load ptr, ptr %l26, !tbaa !29
  %t70 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %t65, ptr %t67, ptr %t68, i64 %t51)
  store ptr %t70, ptr %l33
  br label %bb12
bb12:
  %t71 = load ptr, ptr %l33, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Body", ptr %t71, i32 0, i32 1
  %t74 = load { i64, [2 x i64] }, ptr %t73
  %t75 = load ptr, ptr %l22, !tbaa !29
  %t76 = load %"compiler/source:Span", ptr %l23
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ebodyCallee(ptr %v0, ptr %v2, ptr %v3, ptr %t75, %"compiler/source:Span" %t76, { i64, [2 x i64] } %t74)
  br label %bb13
bb13:
  br label %bb26
bb14:
  %t78 = load ptr, ptr %l2, !tbaa !29
  store ptr %t78, ptr %l36, !tbaa !29
  store i1 false, ptr %l37, !tbaa !21
  %t79 = load ptr, ptr %l36, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l36, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 5}
  %t85 = icmp eq i64 %t83, 2
  store i1 %t85, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb17, label %bb18
bb17:
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [3 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { ptr }, ptr %t89, i32 0, i32 0
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l4, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t94 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t93, ptr %t94)
  br label %bb20
bb20:
  br label %bb26
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_a3421b14f56bfb72_e21214c32a246516)
  unreachable
bb26:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l50 = alloca %"compiler/source:Span"
  %l51 = alloca ptr
  %l52 = alloca i32
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca i1
  %l120 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca i1
  %l143 = alloca { i64, ptr }
  %l155 = alloca ptr
  %l156 = alloca i1
  %l168 = alloca ptr
  %l169 = alloca i1
  %l181 = alloca { i64, ptr }
  %l190 = alloca ptr
  %l191 = alloca i1
  %l208 = alloca ptr
  %l209 = alloca i1
  %l225 = alloca ptr
  %l226 = alloca i1
  %l239 = alloca { i64, ptr }
  %l251 = alloca ptr
  %l252 = alloca i1
  %l265 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l319 = alloca ptr
  %l327 = alloca ptr
  %l335 = alloca ptr
  %l336 = alloca i1
  %l352 = alloca { i64, ptr }
  %l366 = alloca { i64, ptr }
  %l378 = alloca ptr
  %l379 = alloca i1
  %l386 = alloca ptr
  %l387 = alloca i1
  %l397 = alloca ptr
  %l398 = alloca i1
  %l412 = alloca { i64, ptr }
  %l424 = alloca ptr
  %l431 = alloca ptr
  %l439 = alloca ptr
  %l441 = alloca ptr
  %l442 = alloca i1
  %l450 = alloca ptr
  %l451 = alloca i1
  %l464 = alloca { i64, ptr }
  %l467 = alloca ptr
  %l468 = alloca i1
  %l479 = alloca ptr
  %l480 = alloca i1
  %s42 = alloca %olang.scope
  %t728 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l69, !tbaa !29
  store i1 false, ptr %l70, !tbaa !21
  %t6 = load ptr, ptr %l69, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l69, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 18}
  %t12 = icmp eq i64 %t10, 2
  store i1 %t12, ptr %l70, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l70, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [5 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t16, i32 0, i32 2
  %t18 = load ptr, ptr %t17
  store ptr %t18, ptr %l2, !tbaa !29
  br label %bb16
bb7:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l75, !tbaa !29
  store i1 false, ptr %l76, !tbaa !21
  %t21 = load ptr, ptr %l75, !tbaa !29
  %t22 = icmp ne ptr %t21, null
  br i1 %t22, label %bb8, label %bb9
bb8:
  %t24 = load ptr, ptr %l75, !tbaa !29
  %t25 = load i64, ptr %t24, !range !{i64 0, i64 18}
  %t27 = icmp eq i64 %t25, 3
  store i1 %t27, ptr %l76, !tbaa !21
  br label %bb9
bb9:
  %t28 = load i1, ptr %l76, !tbaa !21
  br i1 %t28, label %bb10, label %bb11
bb10:
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr { i64, [5 x i64] }, ptr %t29, i32 0, i32 1
  %t32 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t31, i32 0, i32 2
  %t33 = load ptr, ptr %t32
  store ptr %t33, ptr %l2, !tbaa !29
  br label %bb16
bb11:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l81, !tbaa !29
  store i1 false, ptr %l82, !tbaa !21
  %t36 = load ptr, ptr %l81, !tbaa !29
  %t37 = icmp ne ptr %t36, null
  br i1 %t37, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l81, !tbaa !29
  %t40 = load i64, ptr %t39, !range !{i64 0, i64 18}
  %t42 = icmp eq i64 %t40, 4
  store i1 %t42, ptr %l82, !tbaa !21
  br label %bb13
bb13:
  %t43 = load i1, ptr %l82, !tbaa !21
  br i1 %t43, label %bb14, label %bb15
bb14:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t46 = getelementptr { i64, [5 x i64] }, ptr %t44, i32 0, i32 1
  %t47 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t46, i32 0, i32 2
  %t48 = load ptr, ptr %t47
  store ptr %t48, ptr %l2, !tbaa !29
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t50, ptr %t51)
  br label %bb17
bb17:
  br label %bb235
bb18:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l90, !tbaa !29
  store i1 false, ptr %l91, !tbaa !21
  %t56 = load ptr, ptr %l90, !tbaa !29
  %t57 = icmp ne ptr %t56, null
  br i1 %t57, label %bb19, label %bb20
bb19:
  %t59 = load ptr, ptr %l90, !tbaa !29
  %t60 = load i64, ptr %t59, !range !{i64 0, i64 18}
  %t62 = icmp eq i64 %t60, 5
  store i1 %t62, ptr %l91, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l91, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr { i64, [5 x i64] }, ptr %t64, i32 0, i32 1
  %t67 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t66, i32 0, i32 2
  %t68 = load ptr, ptr %t67
  store ptr %t68, ptr %l3, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t71 = load ptr, ptr %l3, !tbaa !29
  %t73 = getelementptr %"compiler/typed:Promote", ptr %t71, i32 0, i32 0
  %t74 = load ptr, ptr %t73, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t70, ptr %t74)
  br label %bb24
bb24:
  br label %bb235
bb25:
  %t78 = load ptr, ptr %l1, !tbaa !29
  store ptr %t78, ptr %l100, !tbaa !29
  store i1 false, ptr %l101, !tbaa !21
  %t79 = load ptr, ptr %l100, !tbaa !29
  %t80 = icmp ne ptr %t79, null
  br i1 %t80, label %bb26, label %bb27
bb26:
  %t82 = load ptr, ptr %l100, !tbaa !29
  %t83 = load i64, ptr %t82, !range !{i64 0, i64 18}
  %t85 = icmp eq i64 %t83, 6
  store i1 %t85, ptr %l101, !tbaa !21
  br label %bb27
bb27:
  %t86 = load i1, ptr %l101, !tbaa !21
  br i1 %t86, label %bb28, label %bb29
bb28:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t89 = getelementptr { i64, [5 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t89, i32 0, i32 0
  %t91 = load %"compiler/source:Span", ptr %t90
  store %"compiler/source:Span" %t91, ptr %l4
  %t93 = load ptr, ptr %l1, !tbaa !29
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t95, i32 0, i32 2
  %t97 = load ptr, ptr %t96
  store ptr %t97, ptr %l5, !tbaa !29
  br label %bb30
bb29:
  br label %bb39
bb30:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load %"compiler/source:Span", ptr %l4
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr %"compiler/typed:Call", ptr %t101, i32 0, i32 0
  %t104 = load ptr, ptr %t103, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t99, %"compiler/source:Span" %t100, ptr %t104)
  br label %bb31
bb31:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/typed:Call", ptr %t108, i32 0, i32 1
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  store { i64, ptr } %t111, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t113, 0
  store i64 %t115, ptr %l8, !tbaa !24
  br label %bb32
bb32:
  %t117 = load i64, ptr %l7, !tbaa !24
  %t118 = load i64, ptr %l8, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb33, label %bb34
bb33:
  br label %bb38
bb34:
  br label %bb35
bb35:
  %t125 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t125, ptr %l120, !tbaa !27
  %t126 = load i64, ptr %l7, !tbaa !24
  %t128 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = getelementptr ptr, ptr %t129, i64 %t126
  %t131 = load ptr, ptr %t130, !tbaa !39
  %t133 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t133, ptr %t131)
  br label %bb36
bb36:
  br label %bb37
bb37:
  %t138 = load i64, ptr %l7, !tbaa !24
  %t141 = add i64 %t138, 1
  store i64 %t141, ptr %l7, !tbaa !24
  br label %bb32
bb38:
  br label %bb235
bb39:
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l129, !tbaa !29
  store i1 false, ptr %l130, !tbaa !21
  %t144 = load ptr, ptr %l129, !tbaa !29
  %t145 = icmp ne ptr %t144, null
  br i1 %t145, label %bb40, label %bb41
bb40:
  %t147 = load ptr, ptr %l129, !tbaa !29
  %t148 = load i64, ptr %t147, !range !{i64 0, i64 18}
  %t150 = icmp eq i64 %t148, 7
  store i1 %t150, ptr %l130, !tbaa !21
  br label %bb41
bb41:
  %t151 = load i1, ptr %l130, !tbaa !21
  br i1 %t151, label %bb42, label %bb43
bb42:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr { i64, [5 x i64] }, ptr %t152, i32 0, i32 1
  %t155 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t154, i32 0, i32 2
  %t156 = load ptr, ptr %t155
  store ptr %t156, ptr %l10, !tbaa !29
  br label %bb44
bb43:
  br label %bb53
bb44:
  %t158 = load ptr, ptr %l10, !tbaa !29
  %t160 = getelementptr %"compiler/typed:Make", ptr %t158, i32 0, i32 2
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t163, 0
  store i64 %t165, ptr %l13, !tbaa !24
  br label %bb45
bb45:
  %t167 = load i64, ptr %l12, !tbaa !24
  %t168 = load i64, ptr %l13, !tbaa !24
  %t171 = icmp slt i64 %t167, %t168
  %t173 = xor i1 %t171, true
  br i1 %t173, label %bb46, label %bb47
bb46:
  br label %bb51
bb47:
  br label %bb48
bb48:
  %t175 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t175, ptr %l143, !tbaa !27
  %t176 = load i64, ptr %l12, !tbaa !24
  %t178 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr ptr, ptr %t179, i64 %t176
  %t181 = load ptr, ptr %t180, !tbaa !39
  %t183 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t183, ptr %t181)
  br label %bb49
bb49:
  br label %bb50
bb50:
  %t188 = load i64, ptr %l12, !tbaa !24
  %t191 = add i64 %t188, 1
  store i64 %t191, ptr %l12, !tbaa !24
  br label %bb45
bb51:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load ptr, ptr %l10, !tbaa !29
  %t196 = getelementptr %"compiler/typed:Make", ptr %t194, i32 0, i32 3
  %t197 = load ptr, ptr %t196, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t193, ptr %t197)
  br label %bb52
bb52:
  br label %bb235
bb53:
  %t200 = load ptr, ptr %l1, !tbaa !29
  store ptr %t200, ptr %l155, !tbaa !29
  store i1 false, ptr %l156, !tbaa !21
  %t201 = load ptr, ptr %l155, !tbaa !29
  %t202 = icmp ne ptr %t201, null
  br i1 %t202, label %bb54, label %bb55
bb54:
  %t204 = load ptr, ptr %l155, !tbaa !29
  %t205 = load i64, ptr %t204, !range !{i64 0, i64 18}
  %t207 = icmp eq i64 %t205, 8
  store i1 %t207, ptr %l156, !tbaa !21
  br label %bb55
bb55:
  %t208 = load i1, ptr %l156, !tbaa !21
  br i1 %t208, label %bb56, label %bb57
bb56:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr { i64, [5 x i64] }, ptr %t209, i32 0, i32 1
  %t212 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t211, i32 0, i32 2
  %t213 = load ptr, ptr %t212
  store ptr %t213, ptr %l15, !tbaa !29
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load ptr, ptr %l15, !tbaa !29
  %t218 = getelementptr %"compiler/typed:Collect", ptr %t216, i32 0, i32 0
  %t219 = load ptr, ptr %t218, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t215, ptr %t219)
  br label %bb59
bb59:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l15, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Collect", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t222, ptr %t226)
  br label %bb60
bb60:
  br label %bb235
bb61:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l168, !tbaa !29
  store i1 false, ptr %l169, !tbaa !21
  %t231 = load ptr, ptr %l168, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb62, label %bb63
bb62:
  %t234 = load ptr, ptr %l168, !tbaa !29
  %t235 = load i64, ptr %t234, !range !{i64 0, i64 18}
  %t237 = icmp eq i64 %t235, 9
  store i1 %t237, ptr %l169, !tbaa !21
  br label %bb63
bb63:
  %t238 = load i1, ptr %l169, !tbaa !21
  br i1 %t238, label %bb64, label %bb65
bb64:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [5 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t241, i32 0, i32 4
  %t243 = load { i64, ptr }, ptr %t242
  store { i64, ptr } %t243, ptr %l16, !tbaa !27
  br label %bb66
bb65:
  br label %bb74
bb66:
  %t245 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t245, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  store i64 %t249, ptr %l19, !tbaa !24
  br label %bb67
bb67:
  %t251 = load i64, ptr %l18, !tbaa !24
  %t252 = load i64, ptr %l19, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb68, label %bb69
bb68:
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t259 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t259, ptr %l181, !tbaa !27
  %t260 = load i64, ptr %l18, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr ptr, ptr %t263, i64 %t260
  %t265 = load ptr, ptr %t264, !tbaa !39
  %t267 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t267, ptr %t265)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t272 = load i64, ptr %l18, !tbaa !24
  %t275 = add i64 %t272, 1
  store i64 %t275, ptr %l18, !tbaa !24
  br label %bb67
bb73:
  br label %bb235
bb74:
  %t277 = load ptr, ptr %l1, !tbaa !29
  store ptr %t277, ptr %l190, !tbaa !29
  store i1 false, ptr %l191, !tbaa !21
  %t278 = load ptr, ptr %l190, !tbaa !29
  %t279 = icmp ne ptr %t278, null
  br i1 %t279, label %bb75, label %bb76
bb75:
  %t281 = load ptr, ptr %l190, !tbaa !29
  %t282 = load i64, ptr %t281, !range !{i64 0, i64 18}
  %t284 = icmp eq i64 %t282, 10
  store i1 %t284, ptr %l191, !tbaa !21
  br label %bb76
bb76:
  %t285 = load i1, ptr %l191, !tbaa !21
  br i1 %t285, label %bb77, label %bb78
bb77:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t288 = getelementptr { i64, [5 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t288, i32 0, i32 2
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l21, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t293 = load ptr, ptr %l21, !tbaa !29
  %t295 = getelementptr %"compiler/typed:Slice", ptr %t293, i32 0, i32 0
  %t296 = load ptr, ptr %t295, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t292, ptr %t296)
  br label %bb80
bb80:
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t301 = load ptr, ptr %l21, !tbaa !29
  %t303 = getelementptr %"compiler/typed:Slice", ptr %t301, i32 0, i32 1
  %t304 = load ptr, ptr %t303, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t300, ptr %t304)
  br label %bb81
bb81:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t309 = load ptr, ptr %l21, !tbaa !29
  %t311 = getelementptr %"compiler/typed:Slice", ptr %t309, i32 0, i32 2
  %t312 = load ptr, ptr %t311, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t308, ptr %t312)
  br label %bb82
bb82:
  br label %bb235
bb83:
  %t316 = load ptr, ptr %l1, !tbaa !29
  store ptr %t316, ptr %l208, !tbaa !29
  store i1 false, ptr %l209, !tbaa !21
  %t317 = load ptr, ptr %l208, !tbaa !29
  %t318 = icmp ne ptr %t317, null
  br i1 %t318, label %bb84, label %bb85
bb84:
  %t320 = load ptr, ptr %l208, !tbaa !29
  %t321 = load i64, ptr %t320, !range !{i64 0, i64 18}
  %t323 = icmp eq i64 %t321, 11
  store i1 %t323, ptr %l209, !tbaa !21
  br label %bb85
bb85:
  %t324 = load i1, ptr %l209, !tbaa !21
  br i1 %t324, label %bb86, label %bb87
bb86:
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr { i64, [5 x i64] }, ptr %t325, i32 0, i32 1
  %t328 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t327, i32 0, i32 2
  %t329 = load ptr, ptr %t328
  store ptr %t329, ptr %l22, !tbaa !29
  br label %bb88
bb87:
  br label %bb92
bb88:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load ptr, ptr %l22, !tbaa !29
  %t334 = getelementptr %"compiler/typed:Cond", ptr %t332, i32 0, i32 0
  %t335 = load ptr, ptr %t334, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t331, ptr %t335)
  br label %bb89
bb89:
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t340 = load ptr, ptr %l22, !tbaa !29
  %t342 = getelementptr %"compiler/typed:Cond", ptr %t340, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t339, ptr %t343)
  br label %bb90
bb90:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l22, !tbaa !29
  %t349 = getelementptr %"compiler/typed:Cond", ptr %t347, i32 0, i32 2
  %t350 = load ptr, ptr %t349, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t346, ptr %t350)
  br label %bb91
bb91:
  br label %bb235
bb92:
  %t354 = load ptr, ptr %l1, !tbaa !29
  store ptr %t354, ptr %l225, !tbaa !29
  store i1 false, ptr %l226, !tbaa !21
  %t355 = load ptr, ptr %l225, !tbaa !29
  %t356 = icmp ne ptr %t355, null
  br i1 %t356, label %bb93, label %bb94
bb93:
  %t358 = load ptr, ptr %l225, !tbaa !29
  %t359 = load i64, ptr %t358, !range !{i64 0, i64 18}
  %t361 = icmp eq i64 %t359, 12
  store i1 %t361, ptr %l226, !tbaa !21
  br label %bb94
bb94:
  %t362 = load i1, ptr %l226, !tbaa !21
  br i1 %t362, label %bb95, label %bb96
bb95:
  %t363 = load ptr, ptr %l1, !tbaa !29
  %t365 = getelementptr { i64, [5 x i64] }, ptr %t363, i32 0, i32 1
  %t366 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t365, i32 0, i32 2
  %t367 = load ptr, ptr %t366
  store ptr %t367, ptr %l23, !tbaa !29
  br label %bb97
bb96:
  br label %bb106
bb97:
  %t369 = load ptr, ptr %l23, !tbaa !29
  %t371 = getelementptr %"compiler/typed:Seq", ptr %t369, i32 0, i32 0
  %t372 = load { i64, ptr }, ptr %t371, !tbaa !27
  store { i64, ptr } %t372, ptr %l24, !tbaa !27
  store i64 0, ptr %l25, !tbaa !24
  %t374 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 0
  store i64 %t376, ptr %l26, !tbaa !24
  br label %bb98
bb98:
  %t378 = load i64, ptr %l25, !tbaa !24
  %t379 = load i64, ptr %l26, !tbaa !24
  %t382 = icmp slt i64 %t378, %t379
  %t384 = xor i1 %t382, true
  br i1 %t384, label %bb99, label %bb100
bb99:
  br label %bb104
bb100:
  br label %bb101
bb101:
  %t386 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t386, ptr %l239, !tbaa !27
  %t387 = load i64, ptr %l25, !tbaa !24
  %t389 = getelementptr { i64, ptr }, ptr %l239, i32 0, i32 1
  %t390 = load ptr, ptr %t389, !tbaa !27
  %t391 = getelementptr ptr, ptr %t390, i64 %t387
  %t392 = load ptr, ptr %t391, !tbaa !39
  %t394 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t394, ptr %t392)
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t399 = load i64, ptr %l25, !tbaa !24
  %t402 = add i64 %t399, 1
  store i64 %t402, ptr %l25, !tbaa !24
  br label %bb98
bb104:
  %t404 = load ptr, ptr %l0, !tbaa !29
  %t405 = load ptr, ptr %l23, !tbaa !29
  %t407 = getelementptr %"compiler/typed:Seq", ptr %t405, i32 0, i32 1
  %t408 = load ptr, ptr %t407, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t404, ptr %t408)
  br label %bb105
bb105:
  br label %bb235
bb106:
  %t411 = load ptr, ptr %l1, !tbaa !29
  store ptr %t411, ptr %l251, !tbaa !29
  store i1 false, ptr %l252, !tbaa !21
  %t412 = load ptr, ptr %l251, !tbaa !29
  %t413 = icmp ne ptr %t412, null
  br i1 %t413, label %bb107, label %bb108
bb107:
  %t415 = load ptr, ptr %l251, !tbaa !29
  %t416 = load i64, ptr %t415, !range !{i64 0, i64 18}
  %t418 = icmp eq i64 %t416, 13
  store i1 %t418, ptr %l252, !tbaa !21
  br label %bb108
bb108:
  %t419 = load i1, ptr %l252, !tbaa !21
  br i1 %t419, label %bb109, label %bb110
bb109:
  %t420 = load ptr, ptr %l1, !tbaa !29
  %t422 = getelementptr { i64, [5 x i64] }, ptr %t420, i32 0, i32 1
  %t423 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t422, i32 0, i32 2
  %t424 = load ptr, ptr %t423
  store ptr %t424, ptr %l28, !tbaa !29
  br label %bb111
bb110:
  br label %bb146
bb111:
  %t426 = load ptr, ptr %l28, !tbaa !29
  %t428 = getelementptr %"compiler/typed:Match", ptr %t426, i32 0, i32 0
  %t429 = load { i64, ptr }, ptr %t428, !tbaa !27
  store { i64, ptr } %t429, ptr %l29, !tbaa !27
  store i64 0, ptr %l30, !tbaa !24
  %t431 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t433 = extractvalue { i64, ptr } %t431, 0
  store i64 %t433, ptr %l31, !tbaa !24
  br label %bb112
bb112:
  %t435 = load i64, ptr %l30, !tbaa !24
  %t436 = load i64, ptr %l31, !tbaa !24
  %t439 = icmp slt i64 %t435, %t436
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb113, label %bb114
bb113:
  br label %bb118
bb114:
  br label %bb115
bb115:
  %t443 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t443, ptr %l265, !tbaa !27
  %t444 = load i64, ptr %l30, !tbaa !24
  %t446 = getelementptr { i64, ptr }, ptr %l265, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr ptr, ptr %t447, i64 %t444
  %t449 = load ptr, ptr %t448, !tbaa !39
  %t451 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t451, ptr %t449)
  br label %bb116
bb116:
  br label %bb117
bb117:
  %t456 = load i64, ptr %l30, !tbaa !24
  %t459 = add i64 %t456, 1
  store i64 %t459, ptr %l30, !tbaa !24
  br label %bb112
bb118:
  %t461 = load ptr, ptr %l28, !tbaa !29
  %t463 = getelementptr %"compiler/typed:Match", ptr %t461, i32 0, i32 1
  %t464 = load { i64, ptr }, ptr %t463, !tbaa !27
  store { i64, ptr } %t464, ptr %l33, !tbaa !27
  store i64 0, ptr %l34, !tbaa !24
  %t466 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t468 = extractvalue { i64, ptr } %t466, 0
  store i64 %t468, ptr %l35, !tbaa !24
  br label %bb119
bb119:
  %t470 = load i64, ptr %l34, !tbaa !24
  %t471 = load i64, ptr %l35, !tbaa !24
  %t474 = icmp slt i64 %t470, %t471
  %t476 = xor i1 %t474, true
  br i1 %t476, label %bb120, label %bb121
bb120:
  br label %bb134
bb121:
  br label %bb122
bb122:
  %t478 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t478, ptr %l282, !tbaa !27
  %t479 = load i64, ptr %l34, !tbaa !24
  %t481 = getelementptr { i64, ptr }, ptr %l282, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = getelementptr ptr, ptr %t482, i64 %t479
  %t484 = load ptr, ptr %t483, !tbaa !39
  store ptr %t484, ptr %l36, !tbaa !29
  %t486 = load ptr, ptr %l36, !tbaa !29
  %t488 = getelementptr %"compiler/typed:Arm", ptr %t486, i32 0, i32 1
  %t489 = load { i64, ptr }, ptr %t488, !tbaa !27
  store { i64, ptr } %t489, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t491 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t493 = extractvalue { i64, ptr } %t491, 0
  store i64 %t493, ptr %l39, !tbaa !24
  br label %bb123
bb123:
  %t495 = load i64, ptr %l38, !tbaa !24
  %t496 = load i64, ptr %l39, !tbaa !24
  %t499 = icmp slt i64 %t495, %t496
  %t501 = xor i1 %t499, true
  br i1 %t501, label %bb124, label %bb125
bb124:
  br label %bb129
bb125:
  br label %bb126
bb126:
  %t503 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t503, ptr %l293, !tbaa !27
  %t504 = load i64, ptr %l38, !tbaa !24
  %t506 = getelementptr { i64, ptr }, ptr %l293, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = getelementptr ptr, ptr %t507, i64 %t504
  %t509 = load ptr, ptr %t508, !tbaa !39
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/typed:Alt", ptr %t509, i32 0, i32 0
  %t515 = load ptr, ptr %t514, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t511, ptr %t515)
  br label %bb127
bb127:
  br label %bb128
bb128:
  %t519 = load i64, ptr %l38, !tbaa !24
  %t522 = add i64 %t519, 1
  store i64 %t522, ptr %l38, !tbaa !24
  br label %bb123
bb129:
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load ptr, ptr %l36, !tbaa !29
  %t527 = getelementptr %"compiler/typed:Arm", ptr %t525, i32 0, i32 2
  %t528 = load ptr, ptr %t527, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t524, ptr %t528)
  br label %bb130
bb130:
  %t531 = load ptr, ptr %l0, !tbaa !29
  %t532 = load ptr, ptr %l36, !tbaa !29
  %t534 = getelementptr %"compiler/typed:Arm", ptr %t532, i32 0, i32 3
  %t535 = load ptr, ptr %t534, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t531, ptr %t535)
  br label %bb131
bb131:
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load ptr, ptr %l36, !tbaa !29
  %t541 = getelementptr %"compiler/typed:Arm", ptr %t539, i32 0, i32 4
  %t542 = load ptr, ptr %t541, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t538, ptr %t542)
  br label %bb132
bb132:
  br label %bb133
bb133:
  %t545 = load i64, ptr %l34, !tbaa !24
  %t548 = add i64 %t545, 1
  store i64 %t548, ptr %l34, !tbaa !24
  br label %bb119
bb134:
  %t550 = load ptr, ptr %l28, !tbaa !29
  %t552 = getelementptr %"compiler/typed:Match", ptr %t550, i32 0, i32 2
  %t553 = load ptr, ptr %t552, !tbaa !29
  %t555 = icmp eq ptr %t553, null
  %t557 = xor i1 %t555, true
  br i1 %t557, label %bb135, label %bb136
bb135:
  %t559 = load ptr, ptr %l0, !tbaa !29
  store ptr %t559, ptr %l319, !tbaa !29
  %t560 = load ptr, ptr %l28, !tbaa !29
  %t562 = getelementptr %"compiler/typed:Match", ptr %t560, i32 0, i32 2
  %t563 = load ptr, ptr %t562, !tbaa !29
  %t565 = icmp eq ptr %t563, null
  br i1 %t565, label %bb137, label %bb138
bb136:
  br label %bb145
bb137:
  call void @__olang_check_failed(ptr @olang_loc_6c2d06947719abd6_25c6135ab70ee42)
  unreachable
bb138:
  br label %bb139
bb139:
  %t567 = load ptr, ptr %l28, !tbaa !29
  %t569 = getelementptr %"compiler/typed:Match", ptr %t567, i32 0, i32 2
  %t570 = load ptr, ptr %t569, !tbaa !29
  %t573 = getelementptr %"compiler/typed:Arm", ptr %t570, i32 0, i32 3
  %t574 = load ptr, ptr %t573, !tbaa !29
  %t575 = load ptr, ptr %l319, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t575, ptr %t574)
  br label %bb140
bb140:
  %t577 = load ptr, ptr %l0, !tbaa !29
  store ptr %t577, ptr %l327, !tbaa !29
  %t578 = load ptr, ptr %l28, !tbaa !29
  %t580 = getelementptr %"compiler/typed:Match", ptr %t578, i32 0, i32 2
  %t581 = load ptr, ptr %t580, !tbaa !29
  %t583 = icmp eq ptr %t581, null
  br i1 %t583, label %bb141, label %bb142
bb141:
  call void @__olang_check_failed(ptr @olang_loc_a4411270f97f17bd_30632737f0d2da29)
  unreachable
bb142:
  br label %bb143
bb143:
  %t585 = load ptr, ptr %l28, !tbaa !29
  %t587 = getelementptr %"compiler/typed:Match", ptr %t585, i32 0, i32 2
  %t588 = load ptr, ptr %t587, !tbaa !29
  %t591 = getelementptr %"compiler/typed:Arm", ptr %t588, i32 0, i32 4
  %t592 = load ptr, ptr %t591, !tbaa !29
  %t593 = load ptr, ptr %l327, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t593, ptr %t592)
  br label %bb144
bb144:
  br label %bb145
bb145:
  br label %bb235
bb146:
  %t595 = load ptr, ptr %l1, !tbaa !29
  store ptr %t595, ptr %l335, !tbaa !29
  store i1 false, ptr %l336, !tbaa !21
  %t596 = load ptr, ptr %l335, !tbaa !29
  %t597 = icmp ne ptr %t596, null
  br i1 %t597, label %bb147, label %bb148
bb147:
  %t599 = load ptr, ptr %l335, !tbaa !29
  %t600 = load i64, ptr %t599, !range !{i64 0, i64 18}
  %t602 = icmp eq i64 %t600, 14
  store i1 %t602, ptr %l336, !tbaa !21
  br label %bb148
bb148:
  %t603 = load i1, ptr %l336, !tbaa !21
  br i1 %t603, label %bb149, label %bb150
bb149:
  %t604 = load ptr, ptr %l1, !tbaa !29
  %t606 = getelementptr { i64, [5 x i64] }, ptr %t604, i32 0, i32 1
  %t607 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t606, i32 0, i32 2
  %t608 = load ptr, ptr %t607
  store ptr %t608, ptr %l41, !tbaa !29
  br label %bb151
bb150:
  br label %bb167
bb151:
  %t610 = load ptr, ptr %l0, !tbaa !29
  %t611 = load ptr, ptr %l41, !tbaa !29
  %t613 = getelementptr %"compiler/typed:Try", ptr %t611, i32 0, i32 0
  %t614 = load ptr, ptr %t613, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t610, ptr %t614)
  br label %bb152
bb152:
  %t617 = load ptr, ptr %l41, !tbaa !29
  %t619 = getelementptr %"compiler/typed:Try", ptr %t617, i32 0, i32 1
  %t620 = load { i64, ptr }, ptr %t619, !tbaa !27
  store { i64, ptr } %t620, ptr %l42, !tbaa !27
  store i64 0, ptr %l43, !tbaa !24
  %t622 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t624 = extractvalue { i64, ptr } %t622, 0
  store i64 %t624, ptr %l44, !tbaa !24
  br label %bb153
bb153:
  %t626 = load i64, ptr %l43, !tbaa !24
  %t627 = load i64, ptr %l44, !tbaa !24
  %t630 = icmp slt i64 %t626, %t627
  %t632 = xor i1 %t630, true
  br i1 %t632, label %bb154, label %bb155
bb154:
  br label %bb166
bb155:
  br label %bb156
bb156:
  %t634 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t634, ptr %l352, !tbaa !27
  %t635 = load i64, ptr %l43, !tbaa !24
  %t637 = getelementptr { i64, ptr }, ptr %l352, i32 0, i32 1
  %t638 = load ptr, ptr %t637, !tbaa !27
  %t639 = getelementptr ptr, ptr %t638, i64 %t635
  %t640 = load ptr, ptr %t639, !tbaa !39
  store ptr %t640, ptr %l45, !tbaa !29
  %t642 = load ptr, ptr %l0, !tbaa !29
  %t643 = load ptr, ptr %l45, !tbaa !29
  %t645 = getelementptr %"compiler/typed:Clause", ptr %t643, i32 0, i32 3
  %t646 = load ptr, ptr %t645, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t642, ptr %t646)
  br label %bb157
bb157:
  %t649 = load ptr, ptr %l45, !tbaa !29
  %t651 = getelementptr %"compiler/typed:Clause", ptr %t649, i32 0, i32 4
  %t652 = load { i64, ptr }, ptr %t651, !tbaa !27
  store { i64, ptr } %t652, ptr %l46, !tbaa !27
  store i64 0, ptr %l47, !tbaa !24
  %t654 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t656 = extractvalue { i64, ptr } %t654, 0
  store i64 %t656, ptr %l48, !tbaa !24
  br label %bb158
bb158:
  %t658 = load i64, ptr %l47, !tbaa !24
  %t659 = load i64, ptr %l48, !tbaa !24
  %t662 = icmp slt i64 %t658, %t659
  %t664 = xor i1 %t662, true
  br i1 %t664, label %bb159, label %bb160
bb159:
  br label %bb164
bb160:
  br label %bb161
bb161:
  %t666 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t666, ptr %l366, !tbaa !27
  %t667 = load i64, ptr %l47, !tbaa !24
  %t669 = getelementptr { i64, ptr }, ptr %l366, i32 0, i32 1
  %t670 = load ptr, ptr %t669, !tbaa !27
  %t671 = getelementptr ptr, ptr %t670, i64 %t667
  %t672 = load ptr, ptr %t671, !tbaa !39
  %t674 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t674, ptr %t672)
  br label %bb162
bb162:
  br label %bb163
bb163:
  %t679 = load i64, ptr %l47, !tbaa !24
  %t682 = add i64 %t679, 1
  store i64 %t682, ptr %l47, !tbaa !24
  br label %bb158
bb164:
  br label %bb165
bb165:
  %t684 = load i64, ptr %l43, !tbaa !24
  %t687 = add i64 %t684, 1
  store i64 %t687, ptr %l43, !tbaa !24
  br label %bb153
bb166:
  br label %bb235
bb167:
  %t689 = load ptr, ptr %l1, !tbaa !29
  store ptr %t689, ptr %l378, !tbaa !29
  store i1 false, ptr %l379, !tbaa !21
  %t690 = load ptr, ptr %l378, !tbaa !29
  %t691 = icmp ne ptr %t690, null
  br i1 %t691, label %bb168, label %bb169
bb168:
  %t693 = load ptr, ptr %l378, !tbaa !29
  %t694 = load i64, ptr %t693, !range !{i64 0, i64 18}
  %t696 = icmp eq i64 %t694, 15
  store i1 %t696, ptr %l379, !tbaa !21
  br label %bb169
bb169:
  %t697 = load i1, ptr %l379, !tbaa !21
  br i1 %t697, label %bb170, label %bb171
bb170:
  %t698 = load ptr, ptr %l1, !tbaa !29
  %t700 = getelementptr { i64, [5 x i64] }, ptr %t698, i32 0, i32 1
  %t701 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t700, i32 0, i32 0
  %t702 = load %"compiler/source:Span", ptr %t701
  store %"compiler/source:Span" %t702, ptr %l50
  %t704 = load ptr, ptr %l1, !tbaa !29
  %t706 = getelementptr { i64, [5 x i64] }, ptr %t704, i32 0, i32 1
  %t707 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t706, i32 0, i32 2
  %t708 = load ptr, ptr %t707
  store ptr %t708, ptr %l51, !tbaa !29
  br label %bb172
bb171:
  br label %bb206
bb172:
  %t710 = load ptr, ptr %l51, !tbaa !29
  store ptr %t710, ptr %l386, !tbaa !29
  store i1 false, ptr %l387, !tbaa !21
  %t711 = load ptr, ptr %l386, !tbaa !29
  %t712 = icmp ne ptr %t711, null
  br i1 %t712, label %bb173, label %bb174
bb173:
  %t714 = load ptr, ptr %l386, !tbaa !29
  %t715 = load i64, ptr %t714, !range !{i64 0, i64 3}
  %t717 = icmp eq i64 %t715, 0
  store i1 %t717, ptr %l387, !tbaa !21
  br label %bb174
bb174:
  %t718 = load i1, ptr %l387, !tbaa !21
  br i1 %t718, label %bb175, label %bb176
bb175:
  %t719 = load ptr, ptr %l51, !tbaa !29
  %t721 = getelementptr { i64, [4 x i64] }, ptr %t719, i32 0, i32 1
  %t722 = getelementptr { i32 }, ptr %t721, i32 0, i32 0
  %t723 = load i32, ptr %t722
  store i32 %t723, ptr %l52, !tbaa !23
  br label %bb177
bb176:
  br label %bb179
bb177:
  store %olang.scope zeroinitializer, ptr %s42
  %t725 = load ptr, ptr %l0, !tbaa !29
  %t726 = load %"compiler/source:Span", ptr %l50
  %t727 = load i32, ptr %l52, !tbaa !23
  store { i64, [3 x i64] } zeroinitializer, ptr %t728
  %t729 = getelementptr { i64, [3 x i64] }, ptr %t728, i32 0, i32 0
  store i64 0, ptr %t729
  %t731 = insertvalue { i32 } undef, i32 %t727, 0
  %t732 = getelementptr { i64, [3 x i64] }, ptr %t728, i32 0, i32 1
  store { i32 } %t731, ptr %t732
  %t733 = load { i64, [3 x i64] }, ptr %t728
  %t735 = call ptr @__olang_scope_alloc_a(ptr %s42, i64 32, i64 8)
  store { i64, [3 x i64] } %t733, ptr %t735
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2ecallee(ptr %v0, ptr %s42, ptr %v2, ptr %v3, ptr %t725, %"compiler/source:Span" %t726, ptr %t735)
  br label %bb178
bb178:
  call void @__olang_scope_close(ptr %s42)
  br label %bb205
bb179:
  %t739 = load ptr, ptr %l51, !tbaa !29
  store ptr %t739, ptr %l397, !tbaa !29
  store i1 false, ptr %l398, !tbaa !21
  %t740 = load ptr, ptr %l397, !tbaa !29
  %t741 = icmp ne ptr %t740, null
  br i1 %t741, label %bb180, label %bb181
bb180:
  %t743 = load ptr, ptr %l397, !tbaa !29
  %t744 = load i64, ptr %t743, !range !{i64 0, i64 3}
  %t746 = icmp eq i64 %t744, 1
  store i1 %t746, ptr %l398, !tbaa !21
  br label %bb181
bb181:
  %t747 = load i1, ptr %l398, !tbaa !21
  br i1 %t747, label %bb182, label %bb183
bb182:
  %t748 = load ptr, ptr %l51, !tbaa !29
  %t750 = getelementptr { i64, [4 x i64] }, ptr %t748, i32 0, i32 1
  %t751 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t750, i32 0, i32 0
  %t752 = load i32, ptr %t751
  store i32 %t752, ptr %l53, !tbaa !23
  %t754 = load ptr, ptr %l51, !tbaa !29
  %t756 = getelementptr { i64, [4 x i64] }, ptr %t754, i32 0, i32 1
  %t757 = getelementptr { i32, { i64, ptr }, i32 }, ptr %t756, i32 0, i32 1
  %t758 = load { i64, ptr }, ptr %t757
  store { i64, ptr } %t758, ptr %l54, !tbaa !27
  br label %bb184
bb183:
  br label %bb197
bb184:
  %t760 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t760, ptr %l55, !tbaa !27
  store i64 0, ptr %l56, !tbaa !24
  %t762 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t764 = extractvalue { i64, ptr } %t762, 0
  store i64 %t764, ptr %l57, !tbaa !24
  br label %bb185
bb185:
  %t766 = load i64, ptr %l56, !tbaa !24
  %t767 = load i64, ptr %l57, !tbaa !24
  %t770 = icmp slt i64 %t766, %t767
  %t772 = xor i1 %t770, true
  br i1 %t772, label %bb186, label %bb187
bb186:
  br label %bb191
bb187:
  br label %bb188
bb188:
  %t774 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t774, ptr %l412, !tbaa !27
  %t775 = load i64, ptr %l56, !tbaa !24
  %t777 = getelementptr { i64, ptr }, ptr %l412, i32 0, i32 1
  %t778 = load ptr, ptr %t777, !tbaa !27
  %t779 = getelementptr ptr, ptr %t778, i64 %t775
  %t780 = load ptr, ptr %t779, !tbaa !39
  %t782 = load ptr, ptr %l0, !tbaa !29
  %t785 = getelementptr %"compiler/typed:Capture", ptr %t780, i32 0, i32 1
  %t786 = load ptr, ptr %t785, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t782, ptr %t786)
  br label %bb189
bb189:
  br label %bb190
bb190:
  %t790 = load i64, ptr %l56, !tbaa !24
  %t793 = add i64 %t790, 1
  store i64 %t793, ptr %l56, !tbaa !24
  br label %bb185
bb191:
  %t795 = load ptr, ptr %l0, !tbaa !29
  %t797 = getelementptr %"compiler/session:finder", ptr %t795, i32 0, i32 3
  %t798 = load ptr, ptr %t797, !tbaa !29
  %t800 = getelementptr %"compiler/check:Checker", ptr %t798, i32 0, i32 19
  store ptr %t800, ptr %l424, !tbaa !29
  %t801 = load i32, ptr %l53, !tbaa !23
  %t803 = sext i32 %t801 to i64
  %t804 = load ptr, ptr %l424, !tbaa !29
  %t805 = call ptr @__olang_scope_or(ptr %v2, ptr %t804)
  %t806 = call ptr @__olang_scope_hold(ptr %t805)
  %t807 = ptrtoint ptr %t806 to i64
  %t808 = load ptr, ptr %l0, !tbaa !29
  %t810 = getelementptr %"compiler/session:finder", ptr %t808, i32 0, i32 3
  %t811 = load ptr, ptr %t810, !tbaa !29
  %t813 = call ptr @__olang_scope_or(ptr %v2, ptr %t811)
  %t814 = call ptr @__olang_scope_hold(ptr %t813)
  %t815 = ptrtoint ptr %t814 to i64
  %t817 = inttoptr i64 %t807 to ptr
  %t819 = inttoptr i64 %t815 to ptr
  %t820 = load ptr, ptr %l424, !tbaa !29
  %t822 = call ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %t817, ptr %t819, ptr %t820, i64 %t803)
  store ptr %t822, ptr %l431
  br label %bb192
bb192:
  %t823 = load ptr, ptr %l431, !tbaa !29
  store ptr %t823, ptr %l59, !tbaa !29
  %t824 = load ptr, ptr %l59, !tbaa !29
  %t826 = getelementptr %"compiler/typed:Body", ptr %t824, i32 0, i32 11
  %t827 = load ptr, ptr %t826, !tbaa !29
  %t829 = icmp eq ptr %t827, null
  %t831 = xor i1 %t829, true
  br i1 %t831, label %bb193, label %bb194
bb193:
  %t833 = load ptr, ptr %l0, !tbaa !29
  %t834 = load ptr, ptr %l59, !tbaa !29
  %t836 = getelementptr %"compiler/typed:Body", ptr %t834, i32 0, i32 11
  %t837 = load ptr, ptr %t836, !tbaa !29
  store ptr %t837, ptr %l439, !tbaa !29
  %t839 = load ptr, ptr %l439, !tbaa !29
  %t840 = call ptr @__olang_scope_or(ptr %v2, ptr %t839)
  %t841 = call ptr @__olang_scope_hold(ptr %t840)
  %t842 = ptrtoint ptr %t841 to i64
  %t844 = inttoptr i64 %t842 to ptr
  %t846 = load ptr, ptr %l439, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %t844, ptr %v2, ptr %v3, ptr %t833, ptr %t846)
  br label %bb195
bb194:
  br label %bb196
bb195:
  br label %bb196
bb196:
  br label %bb205
bb197:
  %t847 = load ptr, ptr %l51, !tbaa !29
  store ptr %t847, ptr %l441, !tbaa !29
  store i1 false, ptr %l442, !tbaa !21
  %t848 = load ptr, ptr %l441, !tbaa !29
  %t849 = icmp ne ptr %t848, null
  br i1 %t849, label %bb198, label %bb199
bb198:
  %t851 = load ptr, ptr %l441, !tbaa !29
  %t852 = load i64, ptr %t851, !range !{i64 0, i64 3}
  %t854 = icmp eq i64 %t852, 2
  store i1 %t854, ptr %l442, !tbaa !21
  br label %bb199
bb199:
  %t855 = load i1, ptr %l442, !tbaa !21
  br i1 %t855, label %bb200, label %bb201
bb200:
  %t856 = load ptr, ptr %l51, !tbaa !29
  %t858 = getelementptr { i64, [4 x i64] }, ptr %t856, i32 0, i32 1
  %t859 = getelementptr { i32, ptr, i32 }, ptr %t858, i32 0, i32 1
  %t860 = load ptr, ptr %t859
  store ptr %t860, ptr %l60, !tbaa !29
  br label %bb202
bb201:
  br label %bb204
bb202:
  %t862 = load ptr, ptr %l0, !tbaa !29
  %t863 = load ptr, ptr %l60, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t862, ptr %t863)
  br label %bb203
bb203:
  br label %bb205
bb204:
  call void @__olang_check_failed(ptr @olang_loc_e2f597d466b9781f_44eca8a2d4aa1b5b)
  unreachable
bb205:
  br label %bb235
bb206:
  %t867 = load ptr, ptr %l1, !tbaa !29
  store ptr %t867, ptr %l450, !tbaa !29
  store i1 false, ptr %l451, !tbaa !21
  %t868 = load ptr, ptr %l450, !tbaa !29
  %t869 = icmp ne ptr %t868, null
  br i1 %t869, label %bb207, label %bb208
bb207:
  %t871 = load ptr, ptr %l450, !tbaa !29
  %t872 = load i64, ptr %t871, !range !{i64 0, i64 18}
  %t874 = icmp eq i64 %t872, 16
  store i1 %t874, ptr %l451, !tbaa !21
  br label %bb208
bb208:
  %t875 = load i1, ptr %l451, !tbaa !21
  br i1 %t875, label %bb209, label %bb210
bb209:
  %t876 = load ptr, ptr %l1, !tbaa !29
  %t878 = getelementptr { i64, [5 x i64] }, ptr %t876, i32 0, i32 1
  %t879 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t878, i32 0, i32 2
  %t880 = load ptr, ptr %t879
  store ptr %t880, ptr %l61, !tbaa !29
  br label %bb211
bb210:
  br label %bb224
bb211:
  %t882 = load ptr, ptr %l61, !tbaa !29
  %t884 = getelementptr %"compiler/typed:Text", ptr %t882, i32 0, i32 0
  %t885 = load { i64, ptr }, ptr %t884, !tbaa !27
  store { i64, ptr } %t885, ptr %l62, !tbaa !27
  store i64 0, ptr %l63, !tbaa !24
  %t887 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t889 = extractvalue { i64, ptr } %t887, 0
  store i64 %t889, ptr %l64, !tbaa !24
  br label %bb212
bb212:
  %t891 = load i64, ptr %l63, !tbaa !24
  %t892 = load i64, ptr %l64, !tbaa !24
  %t895 = icmp slt i64 %t891, %t892
  %t897 = xor i1 %t895, true
  br i1 %t897, label %bb213, label %bb214
bb213:
  br label %bb223
bb214:
  br label %bb215
bb215:
  %t899 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t899, ptr %l464, !tbaa !27
  %t900 = load i64, ptr %l63, !tbaa !24
  %t902 = getelementptr { i64, ptr }, ptr %l464, i32 0, i32 1
  %t903 = load ptr, ptr %t902, !tbaa !27
  %t904 = getelementptr ptr, ptr %t903, i64 %t900
  %t905 = load ptr, ptr %t904, !tbaa !39
  store ptr %t905, ptr %l65, !tbaa !29
  %t907 = load ptr, ptr %l65, !tbaa !29
  store ptr %t907, ptr %l467, !tbaa !29
  store i1 false, ptr %l468, !tbaa !21
  %t908 = load ptr, ptr %l467, !tbaa !29
  %t909 = icmp ne ptr %t908, null
  br i1 %t909, label %bb216, label %bb217
bb216:
  %t911 = load ptr, ptr %l467, !tbaa !29
  %t912 = load i64, ptr %t911, !range !{i64 0, i64 2}
  %t914 = icmp eq i64 %t912, 1
  store i1 %t914, ptr %l468, !tbaa !21
  br label %bb217
bb217:
  %t915 = load i1, ptr %l468, !tbaa !21
  br i1 %t915, label %bb218, label %bb219
bb218:
  %t916 = load ptr, ptr %l65, !tbaa !29
  %t918 = getelementptr { i64, [2 x i64] }, ptr %t916, i32 0, i32 1
  %t919 = getelementptr { ptr }, ptr %t918, i32 0, i32 0
  %t920 = load ptr, ptr %t919
  %t922 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t922, ptr %t920)
  br label %bb220
bb219:
  br label %bb221
bb220:
  br label %bb221
bb221:
  br label %bb222
bb222:
  %t927 = load i64, ptr %l63, !tbaa !24
  %t930 = add i64 %t927, 1
  store i64 %t930, ptr %l63, !tbaa !24
  br label %bb212
bb223:
  br label %bb235
bb224:
  %t932 = load ptr, ptr %l1, !tbaa !29
  store ptr %t932, ptr %l479, !tbaa !29
  store i1 false, ptr %l480, !tbaa !21
  %t933 = load ptr, ptr %l479, !tbaa !29
  %t934 = icmp ne ptr %t933, null
  br i1 %t934, label %bb225, label %bb226
bb225:
  %t936 = load ptr, ptr %l479, !tbaa !29
  %t937 = load i64, ptr %t936, !range !{i64 0, i64 18}
  %t939 = icmp eq i64 %t937, 17
  store i1 %t939, ptr %l480, !tbaa !21
  br label %bb226
bb226:
  %t940 = load i1, ptr %l480, !tbaa !21
  br i1 %t940, label %bb227, label %bb228
bb227:
  br label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb235
bb230:
  br i1 true, label %bb231, label %bb232
bb231:
  br label %bb233
bb232:
  br label %bb234
bb233:
  br label %bb235
bb234:
  call void @__olang_check_failed(ptr @olang_loc_7a96973d190d0d9e_4b6d703943f97c5a)
  unreachable
bb235:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca %"compiler/source:Span"
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i1
  %l29 = alloca i1
  %l34 = alloca ptr
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca %"compiler/source:Span"
  %l79 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca i1
  %l109 = alloca ptr
  %l110 = alloca i1
  %t107 = alloca { i64, [6 x i64] }, align 8
  %t183 = alloca { i64, [6 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l14, !tbaa !29
  store i1 false, ptr %l15, !tbaa !21
  %t6 = load ptr, ptr %l14, !tbaa !29
  %t7 = icmp ne ptr %t6, null
  br i1 %t7, label %bb4, label %bb5
bb4:
  %t9 = load ptr, ptr %l14, !tbaa !29
  %t10 = load i64, ptr %t9, !range !{i64 0, i64 8}
  %t12 = icmp eq i64 %t10, 1
  store i1 %t12, ptr %l15, !tbaa !21
  br label %bb5
bb5:
  %t13 = load i1, ptr %l15, !tbaa !21
  br i1 %t13, label %bb6, label %bb7
bb6:
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = getelementptr { i64, [4 x i64] }, ptr %t14, i32 0, i32 1
  %t17 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t16, i32 0, i32 0
  %t18 = load %"compiler/source:Span", ptr %t17
  store %"compiler/source:Span" %t18, ptr %l2
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t22 = getelementptr { i64, [4 x i64] }, ptr %t20, i32 0, i32 1
  %t23 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t22, i32 0, i32 2
  %t24 = load i64, ptr %t23
  store i64 %t24, ptr %l3, !tbaa !24
  %t26 = load ptr, ptr %l1, !tbaa !29
  %t28 = getelementptr { i64, [4 x i64] }, ptr %t26, i32 0, i32 1
  %t29 = getelementptr { %"compiler/source:Span", i32, i64, i32 }, ptr %t28, i32 0, i32 3
  %t30 = load i32, ptr %t29
  store i32 %t30, ptr %l4, !tbaa !23
  br label %bb8
bb7:
  br label %bb18
bb8:
  %t32 = getelementptr %"compiler/source:Span", ptr %l2, i32 0, i32 1
  %t33 = load i32, ptr %t32, !tbaa !23
  %t35 = sext i32 %t33 to i64
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/session:finder", ptr %t36, i32 0, i32 1
  %t39 = load i64, ptr %t38, !tbaa !24
  %t42 = icmp eq i64 %t35, %t39
  br i1 %t42, label %bb9, label %bb10
bb9:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/session:finder", ptr %t44, i32 0, i32 3
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/check:Checker", ptr %t47, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/generic:Program", ptr %t50, i32 0, i32 0
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/load:Loader", ptr %t53, i32 0, i32 3
  %t56 = load ptr, ptr %t55, !tbaa !29
  store ptr %t56, ptr %l34, !tbaa !29
  %t57 = load i32, ptr %l4, !tbaa !23
  %t58 = load ptr, ptr %l34, !tbaa !29
  %t59 = call ptr @__olang_scope_or(ptr %v2, ptr %t58)
  %t60 = call ptr @__olang_scope_hold(ptr %t59)
  %t61 = ptrtoint ptr %t60 to i64
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/session:finder", ptr %t62, i32 0, i32 3
  %t65 = load ptr, ptr %t64, !tbaa !29
  %t67 = call ptr @__olang_scope_or(ptr %v2, ptr %t65)
  %t68 = call ptr @__olang_scope_hold(ptr %t67)
  %t69 = ptrtoint ptr %t68 to i64
  %t71 = inttoptr i64 %t61 to ptr
  %t73 = inttoptr i64 %t69 to ptr
  %t74 = load ptr, ptr %l34, !tbaa !29
  %t76 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %t71, ptr %t73, ptr %t74, i32 %t57)
  store { i64, ptr } %t76, ptr %l40
  br label %bb11
bb10:
  store i1 false, ptr %l29, !tbaa !21
  br label %bb13
bb11:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/session:finder", ptr %t77, i32 0, i32 2
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  store { i64, ptr } %t80, ptr %l42, !tbaa !27
  %t81 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = call ptr @__olang_scope_or(ptr %v2, ptr %t82)
  %t84 = call ptr @__olang_scope_hold(ptr %t83)
  %t85 = ptrtoint ptr %t84 to i64
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = call ptr @__olang_scope_or(ptr %v3, ptr %t87)
  %t89 = call ptr @__olang_scope_hold(ptr %t88)
  %t90 = ptrtoint ptr %t89 to i64
  %t92 = inttoptr i64 %t85 to ptr
  %t94 = inttoptr i64 %t90 to ptr
  %t95 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t92, ptr %t94, { i64, ptr } %t95, { i64, ptr } %t96)
  store i1 %t97, ptr %l45
  br label %bb12
bb12:
  %t98 = load i1, ptr %l45, !tbaa !21
  store i1 %t98, ptr %l29, !tbaa !21
  br label %bb13
bb13:
  %t99 = load i1, ptr %l29, !tbaa !21
  br i1 %t99, label %bb14, label %bb15
bb14:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t101 = load %"compiler/source:Span", ptr %l2
  %t102 = load i64, ptr %l3, !tbaa !24
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/session:finder", ptr %t103, i32 0, i32 2
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, [6 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [6 x i64] }, ptr %t107, i32 0, i32 0
  store i64 1, ptr %t108
  %t110 = insertvalue { i64, { i64, ptr } } undef, i64 %t102, 0
  %t112 = insertvalue { i64, { i64, ptr } } %t110, { i64, ptr } %t106, 1
  %t113 = getelementptr { i64, [6 x i64] }, ptr %t107, i32 0, i32 1
  store { i64, { i64, ptr } } %t112, ptr %t113
  %t114 = load { i64, [6 x i64] }, ptr %t107
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t100, %"compiler/source:Span" %t101, { i64, [6 x i64] } %t114)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  br label %bb64
bb18:
  %t118 = load ptr, ptr %l1, !tbaa !29
  store ptr %t118, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t119 = load ptr, ptr %l52, !tbaa !29
  %t120 = icmp ne ptr %t119, null
  br i1 %t120, label %bb19, label %bb20
bb19:
  %t122 = load ptr, ptr %l52, !tbaa !29
  %t123 = load i64, ptr %t122, !range !{i64 0, i64 8}
  %t125 = icmp eq i64 %t123, 2
  store i1 %t125, ptr %l53, !tbaa !21
  br label %bb20
bb20:
  %t126 = load i1, ptr %l53, !tbaa !21
  br i1 %t126, label %bb21, label %bb22
bb21:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t127, i32 0, i32 1
  %t130 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t129, i32 0, i32 2
  %t131 = load ptr, ptr %t130
  store ptr %t131, ptr %l5, !tbaa !29
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t133, ptr %t134)
  br label %bb24
bb24:
  br label %bb64
bb25:
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t139 = load ptr, ptr %l61, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb26, label %bb27
bb26:
  %t142 = load ptr, ptr %l61, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 8}
  %t145 = icmp eq i64 %t143, 3
  store i1 %t145, ptr %l62, !tbaa !21
  br label %bb27
bb27:
  %t146 = load i1, ptr %l62, !tbaa !21
  br i1 %t146, label %bb28, label %bb29
bb28:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [4 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t149, i32 0, i32 0
  %t151 = load %"compiler/source:Span", ptr %t150
  store %"compiler/source:Span" %t151, ptr %l6
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr { i64, [4 x i64] }, ptr %t153, i32 0, i32 1
  %t156 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t155, i32 0, i32 2
  %t157 = load ptr, ptr %t156
  store ptr %t157, ptr %l7, !tbaa !29
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t159, i32 0, i32 1
  %t162 = getelementptr { %"compiler/source:Span", i32, ptr, i64 }, ptr %t161, i32 0, i32 3
  %t163 = load i64, ptr %t162
  store i64 %t163, ptr %l8, !tbaa !24
  br label %bb30
bb29:
  br label %bb37
bb30:
  %t165 = getelementptr %"compiler/source:Span", ptr %l6, i32 0, i32 1
  %t166 = load i32, ptr %t165, !tbaa !23
  %t168 = sext i32 %t166 to i64
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t171 = getelementptr %"compiler/session:finder", ptr %t169, i32 0, i32 1
  %t172 = load i64, ptr %t171, !tbaa !24
  %t175 = icmp eq i64 %t168, %t172
  br i1 %t175, label %bb31, label %bb32
bb31:
  %t177 = load ptr, ptr %l0, !tbaa !29
  store ptr %t177, ptr %l76, !tbaa !29
  %t178 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t178, ptr %l77
  %t179 = load ptr, ptr %l7, !tbaa !29
  %t181 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v1, ptr %t179)
  store i32 %t181, ptr %l79
  br label %bb33
bb32:
  br label %bb35
bb33:
  %t182 = load i64, ptr %l8, !tbaa !24
  store { i64, [6 x i64] } zeroinitializer, ptr %t183
  %t184 = getelementptr { i64, [6 x i64] }, ptr %t183, i32 0, i32 0
  store i64 3, ptr %t184
  %t185 = load i32, ptr %l79, !tbaa !23
  %t186 = insertvalue { i32, i64 } undef, i32 %t185, 0
  %t188 = insertvalue { i32, i64 } %t186, i64 %t182, 1
  %t189 = getelementptr { i64, [6 x i64] }, ptr %t183, i32 0, i32 1
  store { i32, i64 } %t188, ptr %t189
  %t190 = load { i64, [6 x i64] }, ptr %t183
  %t191 = load ptr, ptr %l76, !tbaa !29
  %t192 = load %"compiler/source:Span", ptr %l77
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v0, ptr %t191, %"compiler/source:Span" %t192, { i64, [6 x i64] } %t190)
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t194 = load ptr, ptr %l0, !tbaa !29
  %t195 = load ptr, ptr %l7, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t194, ptr %t195)
  br label %bb36
bb36:
  br label %bb64
bb37:
  %t199 = load ptr, ptr %l1, !tbaa !29
  store ptr %t199, ptr %l85, !tbaa !29
  store i1 false, ptr %l86, !tbaa !21
  %t200 = load ptr, ptr %l85, !tbaa !29
  %t201 = icmp ne ptr %t200, null
  br i1 %t201, label %bb38, label %bb39
bb38:
  %t203 = load ptr, ptr %l85, !tbaa !29
  %t204 = load i64, ptr %t203, !range !{i64 0, i64 8}
  %t206 = icmp eq i64 %t204, 4
  store i1 %t206, ptr %l86, !tbaa !21
  br label %bb39
bb39:
  %t207 = load i1, ptr %l86, !tbaa !21
  br i1 %t207, label %bb40, label %bb41
bb40:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr { i64, [4 x i64] }, ptr %t208, i32 0, i32 1
  %t211 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t210, i32 0, i32 2
  %t212 = load ptr, ptr %t211
  store ptr %t212, ptr %l9, !tbaa !29
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t214 = load ptr, ptr %l0, !tbaa !29
  %t215 = load ptr, ptr %l9, !tbaa !29
  %t217 = getelementptr %"compiler/typed:Elem", ptr %t215, i32 0, i32 0
  %t218 = load ptr, ptr %t217, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t214, ptr %t218)
  br label %bb43
bb43:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load ptr, ptr %l9, !tbaa !29
  %t225 = getelementptr %"compiler/typed:Elem", ptr %t223, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t222, ptr %t226)
  br label %bb44
bb44:
  br label %bb64
bb45:
  %t230 = load ptr, ptr %l1, !tbaa !29
  store ptr %t230, ptr %l99, !tbaa !29
  store i1 false, ptr %l100, !tbaa !21
  %t231 = load ptr, ptr %l99, !tbaa !29
  %t232 = icmp ne ptr %t231, null
  br i1 %t232, label %bb46, label %bb47
bb46:
  %t234 = load ptr, ptr %l99, !tbaa !29
  %t235 = load i64, ptr %t234, !range !{i64 0, i64 8}
  %t237 = icmp eq i64 %t235, 5
  store i1 %t237, ptr %l100, !tbaa !21
  br label %bb47
bb47:
  %t238 = load i1, ptr %l100, !tbaa !21
  br i1 %t238, label %bb48, label %bb49
bb48:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t239, i32 0, i32 1
  %t242 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t241, i32 0, i32 2
  %t243 = load ptr, ptr %t242
  store ptr %t243, ptr %l10, !tbaa !29
  br label %bb50
bb49:
  br label %bb52
bb50:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load ptr, ptr %l10, !tbaa !29
  %t248 = getelementptr %"compiler/typed:Payload", ptr %t246, i32 0, i32 0
  %t249 = load ptr, ptr %t248, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eplace(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t245, ptr %t249)
  br label %bb51
bb51:
  br label %bb64
bb52:
  %t253 = load ptr, ptr %l1, !tbaa !29
  store ptr %t253, ptr %l109, !tbaa !29
  store i1 false, ptr %l110, !tbaa !21
  %t254 = load ptr, ptr %l109, !tbaa !29
  %t255 = icmp ne ptr %t254, null
  br i1 %t255, label %bb53, label %bb54
bb53:
  %t257 = load ptr, ptr %l109, !tbaa !29
  %t258 = load i64, ptr %t257, !range !{i64 0, i64 8}
  %t260 = icmp eq i64 %t258, 6
  store i1 %t260, ptr %l110, !tbaa !21
  br label %bb54
bb54:
  %t261 = load i1, ptr %l110, !tbaa !21
  br i1 %t261, label %bb55, label %bb56
bb55:
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr { i64, [4 x i64] }, ptr %t262, i32 0, i32 1
  %t265 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t264, i32 0, i32 2
  %t266 = load ptr, ptr %t265
  store ptr %t266, ptr %l11, !tbaa !29
  br label %bb57
bb56:
  br label %bb59
bb57:
  %t268 = load ptr, ptr %l0, !tbaa !29
  %t269 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eexpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t268, ptr %t269)
  br label %bb58
bb58:
  br label %bb64
bb59:
  br i1 true, label %bb60, label %bb61
bb60:
  br label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @olang_loc_f2f4caf0087f76e9_23d5843dfc5c1e5)
  unreachable
bb64:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca ptr
  %l17 = alloca %"compiler/session:symWriter"
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca %"compiler/source:Span"
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca %"compiler/source:Span"
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca %"compiler/session:symWriter"
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/source:Span"
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca i1
  %l60 = alloca ptr
  %l61 = alloca i1
  %l69 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca { i64, ptr }
  %l82 = alloca i1
  %l92 = alloca i64
  %l94 = alloca { i64, ptr }
  %l105 = alloca %"compiler/source:Span"
  %l107 = alloca i64
  %l118 = alloca %"compiler/source:Span"
  %l120 = alloca i64
  %l121 = alloca i64
  %l126 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca i1
  %l134 = alloca i64
  %l136 = alloca { i64, ptr }
  %l142 = alloca %"compiler/source:Span"
  %l144 = alloca i64
  %l150 = alloca %"compiler/source:Span"
  %l152 = alloca i64
  %l153 = alloca i64
  %l158 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l174 = alloca %"compiler/source:Span"
  %l178 = alloca i64
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca { i64, ptr }
  %l186 = alloca i1
  %l188 = alloca i1
  %l189 = alloca i64
  %l205 = alloca ptr
  %l206 = alloca i1
  %l216 = alloca { i64, ptr }
  %l221 = alloca i64
  %l229 = alloca i64
  %l230 = alloca ptr
  %l231 = alloca i1
  %l235 = alloca ptr
  %l236 = alloca i1
  %l240 = alloca ptr
  %l241 = alloca i1
  %l261 = alloca %"compiler/session:symWriter"
  %l266 = alloca ptr
  %l267 = alloca ptr
  %l275 = alloca ptr
  %l276 = alloca i1
  %l286 = alloca { i64, ptr }
  %l287 = alloca { i64, ptr }
  %l290 = alloca %"compiler/source:Span"
  %l294 = alloca i64
  %l295 = alloca ptr
  %l296 = alloca ptr
  %l297 = alloca { i64, ptr }
  %l298 = alloca i64
  %l300 = alloca i64
  %l302 = alloca i64
  %l303 = alloca i64
  %l307 = alloca i64
  %l308 = alloca { i64, ptr }
  %l311 = alloca %"compiler/source:Span"
  %l313 = alloca i64
  %l316 = alloca %"compiler/source:Span"
  %l318 = alloca i64
  %l319 = alloca i64
  %l326 = alloca ptr
  %l327 = alloca i1
  %l340 = alloca i64
  %l343 = alloca i64
  %l362 = alloca { i64, ptr }
  %l365 = alloca ptr
  %l366 = alloca ptr
  %l369 = alloca { i64, ptr }
  %l372 = alloca { i64, ptr }
  %l385 = alloca ptr
  %l386 = alloca i1
  %l397 = alloca { i64, ptr }
  %l402 = alloca i64
  %l418 = alloca %"compiler/session:symWriter"
  %l426 = alloca { i64, ptr }
  %l431 = alloca { i64, ptr }
  %l438 = alloca i64
  %l459 = alloca ptr
  %l460 = alloca i1
  %l467 = alloca ptr
  %l468 = alloca ptr
  %l469 = alloca { i64, ptr }
  %l471 = alloca i64
  %l473 = alloca i64
  %l474 = alloca i64
  %l490 = alloca ptr
  %l491 = alloca i1
  %l501 = alloca ptr
  %l502 = alloca i1
  %l514 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s24 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l54, !tbaa !29
  store i1 false, ptr %l55, !tbaa !21
  %t10 = load ptr, ptr %l54, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l54, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 12}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l55, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l55, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [8 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { ptr }, ptr %t20, i32 0, i32 0
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l5, !tbaa !29
  br label %bb9
bb4:
  %t24 = load ptr, ptr %l2, !tbaa !29
  store ptr %t24, ptr %l60, !tbaa !29
  store i1 false, ptr %l61, !tbaa !21
  %t25 = load ptr, ptr %l60, !tbaa !29
  %t26 = icmp ne ptr %t25, null
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l60, !tbaa !29
  %t29 = load i64, ptr %t28, !range !{i64 0, i64 12}
  %t31 = icmp eq i64 %t29, 1
  store i1 %t31, ptr %l61, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l61, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = getelementptr { i64, [8 x i64] }, ptr %t33, i32 0, i32 1
  %t36 = getelementptr { ptr }, ptr %t35, i32 0, i32 0
  %t37 = load ptr, ptr %t36
  store ptr %t37, ptr %l5, !tbaa !29
  br label %bb9
bb8:
  br label %bb89
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t40 = load ptr, ptr %l5, !tbaa !29
  %t42 = getelementptr %"compiler/ast:Func", ptr %t40, i32 0, i32 2
  %t43 = load i32, ptr %t42, !tbaa !23
  %t46 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t39, i32 %t43)
  store { i64, ptr } %t46, ptr %l69
  br label %bb10
bb10:
  %t47 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t47, ptr %l6, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = getelementptr %"compiler/ast:Func", ptr %t49, i32 0, i32 0
  %t52 = getelementptr %"compiler/source:Span", ptr %t51, i32 0, i32 0
  %t53 = load i32, ptr %t52, !tbaa !23
  %t55 = sext i32 %t53 to i64
  %t56 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t60 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t48, i64 %t55, { i64, ptr } %t56)
  store i64 %t60, ptr %l75
  br label %bb11
bb11:
  %t61 = load i64, ptr %l75, !tbaa !24
  store i64 %t61, ptr %l7, !tbaa !24
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l76, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t62, ptr %l8, !tbaa !27
  %t64 = load ptr, ptr %l5, !tbaa !29
  %t66 = getelementptr %"compiler/ast:Func", ptr %t64, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = icmp eq ptr %t67, null
  %t71 = xor i1 %t69, true
  br i1 %t71, label %bb12, label %bb13
bb12:
  %t73 = load ptr, ptr %l5, !tbaa !29
  %t75 = getelementptr %"compiler/ast:Func", ptr %t73, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !29
  %t78 = icmp eq ptr %t76, null
  br i1 %t78, label %bb14, label %bb15
bb13:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb17
bb14:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb15:
  br label %bb16
bb16:
  %t80 = load ptr, ptr %l5, !tbaa !29
  %t82 = getelementptr %"compiler/ast:Func", ptr %t80, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !29
  %t86 = getelementptr %"compiler/ast:Param", ptr %t83, i32 0, i32 2
  %t87 = load ptr, ptr %t86, !tbaa !29
  %t89 = icmp eq ptr %t87, null
  %t91 = xor i1 %t89, true
  store i1 %t91, ptr %l82, !tbaa !21
  br label %bb17
bb17:
  %t93 = load i1, ptr %l82, !tbaa !21
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t94 = call ptr @__olang_scope_hold(ptr %s1)
  %t95 = ptrtoint ptr %t94 to i64
  store i64 %t95, ptr %l92, !tbaa !24
  %t96 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2ecompiler__2fsession__3asymWriter__2edecl_2elocal_2e8
  br i1 %t96, label %bb20, label %bb21
bb19:
  br label %bb48
bb20:
  %t98 = call ptr @__olang_region_make(ptr %s1)
  %t99 = ptrtoint ptr %t98 to i64
  store i64 %t99, ptr %l92, !tbaa !24
  br label %bb21
bb21:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l94, !tbaa !27
  %t101 = load ptr, ptr %l5, !tbaa !29
  %t103 = getelementptr %"compiler/ast:Func", ptr %t101, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !29
  %t106 = icmp eq ptr %t104, null
  br i1 %t106, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb23:
  br label %bb24
bb24:
  %t108 = load ptr, ptr %l5, !tbaa !29
  %t110 = getelementptr %"compiler/ast:Func", ptr %t108, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !29
  %t114 = getelementptr %"compiler/ast:Param", ptr %t111, i32 0, i32 2
  %t115 = load ptr, ptr %t114, !tbaa !29
  store ptr %t115, ptr %l9, !tbaa !29
  %t117 = load ptr, ptr %l9, !tbaa !29
  %t119 = icmp eq ptr %t117, null
  br i1 %t119, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb26:
  br label %bb27
bb27:
  %t121 = load ptr, ptr %l9, !tbaa !29
  %t123 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t121)
  store %"compiler/source:Span" %t123, ptr %l105
  br label %bb28
bb28:
  %t124 = getelementptr %"compiler/source:Span", ptr %l105, i32 0, i32 0
  %t125 = load i32, ptr %t124, !tbaa !23
  %t127 = sext i32 %t125 to i64
  store i64 %t127, ptr %l107, !tbaa !24
  %t128 = load ptr, ptr %l5, !tbaa !29
  %t130 = getelementptr %"compiler/ast:Func", ptr %t128, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !29
  %t133 = icmp eq ptr %t131, null
  br i1 %t133, label %bb29, label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb30:
  br label %bb31
bb31:
  %t135 = load ptr, ptr %l5, !tbaa !29
  %t137 = getelementptr %"compiler/ast:Func", ptr %t135, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !29
  %t141 = getelementptr %"compiler/ast:Param", ptr %t138, i32 0, i32 2
  %t142 = load ptr, ptr %t141, !tbaa !29
  store ptr %t142, ptr %l10, !tbaa !29
  %t144 = load ptr, ptr %l10, !tbaa !29
  %t146 = icmp eq ptr %t144, null
  br i1 %t146, label %bb32, label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9)
  unreachable
bb33:
  br label %bb34
bb34:
  %t148 = load ptr, ptr %l10, !tbaa !29
  %t150 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t148)
  store %"compiler/source:Span" %t150, ptr %l118
  br label %bb35
bb35:
  %t151 = getelementptr %"compiler/source:Span", ptr %l118, i32 0, i32 1
  %t152 = load i32, ptr %t151, !tbaa !23
  %t154 = sext i32 %t152 to i64
  store i64 %t154, ptr %l120, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  store i64 %t156, ptr %l121, !tbaa !24
  %t157 = load i64, ptr %l107, !tbaa !24
  %t158 = icmp sge i64 %t157, 0
  br i1 %t158, label %bb36, label %bb37
bb36:
  %t160 = load i64, ptr %l107, !tbaa !24
  %t161 = load i64, ptr %l120, !tbaa !24
  %t162 = icmp sle i64 %t160, %t161
  br i1 %t162, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb38:
  %t164 = load i64, ptr %l120, !tbaa !24
  %t165 = load i64, ptr %l121, !tbaa !24
  %t166 = icmp sle i64 %t164, %t165
  br i1 %t166, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb40:
  %t168 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = load i64, ptr %l107, !tbaa !24
  %t171 = load i64, ptr %l120, !tbaa !24
  %t172 = getelementptr i8, ptr %t169, i64 %t170
  %t173 = sub i64 %t171, %t170
  %t174 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t172, 1
  %t177 = extractvalue { i64, ptr } %t175, 1
  %t178 = extractvalue { i64, ptr } %t175, 0
  %t179 = load i64, ptr %l92
  %t180 = inttoptr i64 %t179 to ptr
  %t181 = call ptr @__olang_held_alloc(ptr %t180, i64 %t178)
  call void @olang_textcopy(ptr %t181, ptr %t177, i64 %t178)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l126, !tbaa !27
  %t184 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2ecompiler__2fsession__3asymWriter__2edecl_2elocal_2e8
  br i1 %t184, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca)
  unreachable
bb42:
  %t186 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t189 = icmp eq i64 %t187, 0
  br i1 %t189, label %bb44, label %bb45
bb43:
  %t191 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t191, ptr %l130, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t192, ptr %l8, !tbaa !27
  %t193 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2ecompiler__2fsession__3asymWriter__2edecl_2elocal_2e8
  br i1 %t193, label %bb46, label %bb47
bb44:
  store { i64, ptr } zeroinitializer, ptr %l126, !tbaa !27
  br label %bb45
bb45:
  %t195 = load i64, ptr %l92
  %t196 = inttoptr i64 %t195 to ptr
  %t197 = load { i64, ptr }, ptr %l126
  %t198 = extractvalue { i64, ptr } %t197, 1
  %t199 = call ptr @__olang_region_or(ptr %t198, ptr null)
  %t200 = icmp ne ptr %t199, null
  %t201 = select i1 %t200, ptr %t199, ptr null
  call void @__olang_region_settle_in(ptr %t196, ptr %t201)
  br label %bb43
bb46:
  %t202 = load { i64, ptr }, ptr %l130
  %t203 = extractvalue { i64, ptr } %t202, 1
  call void @__olang_region_release(ptr %t203)
  store { i64, ptr } zeroinitializer, ptr %l130
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t204 = load ptr, ptr %l5, !tbaa !29
  %t206 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v2, ptr %t204)
  store i1 %t206, ptr %l133
  br label %bb49
bb49:
  %t207 = load i1, ptr %l133, !tbaa !21
  br i1 %t207, label %bb50, label %bb51
bb50:
  %t208 = call ptr @__olang_scope_hold(ptr %s1)
  %t209 = ptrtoint ptr %t208 to i64
  store i64 %t209, ptr %l134, !tbaa !24
  %t210 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2ecompiler__2fsession__3asymWriter__2edecl_2elocal_2e8
  br i1 %t210, label %bb52, label %bb53
bb51:
  br label %bb80
bb52:
  %t212 = call ptr @__olang_region_make(ptr %s1)
  %t213 = ptrtoint ptr %t212 to i64
  store i64 %t213, ptr %l134, !tbaa !24
  br label %bb53
bb53:
  %t214 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t214, ptr %l136, !tbaa !27
  %t215 = load ptr, ptr %l5, !tbaa !29
  %t217 = getelementptr %"compiler/ast:Func", ptr %t215, i32 0, i32 8
  %t218 = load ptr, ptr %t217, !tbaa !29
  %t220 = icmp eq ptr %t218, null
  br i1 %t220, label %bb54, label %bb55
bb54:
  call void @__olang_check_failed(ptr @olang_loc_20935b6efc97b92f_a6b75dda1390d5f3)
  unreachable
bb55:
  br label %bb56
bb56:
  %t222 = load ptr, ptr %l5, !tbaa !29
  %t224 = getelementptr %"compiler/ast:Func", ptr %t222, i32 0, i32 8
  %t225 = load ptr, ptr %t224, !tbaa !29
  %t227 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t225)
  store %"compiler/source:Span" %t227, ptr %l142
  br label %bb57
bb57:
  %t228 = getelementptr %"compiler/source:Span", ptr %l142, i32 0, i32 0
  %t229 = load i32, ptr %t228, !tbaa !23
  %t231 = sext i32 %t229 to i64
  store i64 %t231, ptr %l144, !tbaa !24
  %t232 = load ptr, ptr %l5, !tbaa !29
  %t234 = getelementptr %"compiler/ast:Func", ptr %t232, i32 0, i32 8
  %t235 = load ptr, ptr %t234, !tbaa !29
  %t237 = icmp eq ptr %t235, null
  br i1 %t237, label %bb58, label %bb59
bb58:
  call void @__olang_check_failed(ptr @olang_loc_20935b6efc97b92f_a6b75dda1390d5f3)
  unreachable
bb59:
  br label %bb60
bb60:
  %t239 = load ptr, ptr %l5, !tbaa !29
  %t241 = getelementptr %"compiler/ast:Func", ptr %t239, i32 0, i32 8
  %t242 = load ptr, ptr %t241, !tbaa !29
  %t244 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t242)
  store %"compiler/source:Span" %t244, ptr %l150
  br label %bb61
bb61:
  %t245 = getelementptr %"compiler/source:Span", ptr %l150, i32 0, i32 1
  %t246 = load i32, ptr %t245, !tbaa !23
  %t248 = sext i32 %t246 to i64
  store i64 %t248, ptr %l152, !tbaa !24
  %t249 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 0
  store i64 %t250, ptr %l153, !tbaa !24
  %t251 = load i64, ptr %l144, !tbaa !24
  %t252 = icmp sge i64 %t251, 0
  br i1 %t252, label %bb62, label %bb63
bb62:
  %t254 = load i64, ptr %l144, !tbaa !24
  %t255 = load i64, ptr %l152, !tbaa !24
  %t256 = icmp sle i64 %t254, %t255
  br i1 %t256, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_d4784f9ecdded0f8_efac4001dd272cfc)
  unreachable
bb64:
  %t258 = load i64, ptr %l152, !tbaa !24
  %t259 = load i64, ptr %l153, !tbaa !24
  %t260 = icmp sle i64 %t258, %t259
  br i1 %t260, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_d4784f9ecdded0f8_efac4001dd272cfc)
  unreachable
bb66:
  %t262 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = load i64, ptr %l144, !tbaa !24
  %t265 = load i64, ptr %l152, !tbaa !24
  %t266 = getelementptr i8, ptr %t263, i64 %t264
  %t267 = sub i64 %t265, %t264
  %t268 = insertvalue { i64, ptr } undef, i64 %t267, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t266, 1
  %t271 = extractvalue { i64, ptr } %t269, 1
  %t272 = extractvalue { i64, ptr } %t269, 0
  %t273 = load i64, ptr %l134
  %t274 = inttoptr i64 %t273 to ptr
  %t275 = call ptr @__olang_held_alloc(ptr %t274, i64 %t272)
  call void @olang_textcopy(ptr %t275, ptr %t271, i64 %t272)
  %t276 = insertvalue { i64, ptr } undef, i64 %t272, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  store { i64, ptr } %t277, ptr %l158, !tbaa !27
  %t278 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2ecompiler__2fsession__3asymWriter__2edecl_2elocal_2e8
  br i1 %t278, label %bb68, label %bb69
bb67:
  call void @__olang_check_failed(ptr @olang_loc_d4784f9ecdded0f8_efac4001dd272cfc)
  unreachable
bb68:
  %t280 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  %t283 = icmp eq i64 %t281, 0
  br i1 %t283, label %bb70, label %bb71
bb69:
  %t285 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t285, ptr %l162, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l158, !tbaa !27
  store { i64, ptr } %t286, ptr %l8, !tbaa !27
  %t287 = load i1, ptr @olang_2esole_2ecompiler__2fsession__2ecompiler__2fsession__3asymWriter__2edecl_2elocal_2e8
  br i1 %t287, label %bb72, label %bb73
bb70:
  store { i64, ptr } zeroinitializer, ptr %l158, !tbaa !27
  br label %bb71
bb71:
  %t289 = load i64, ptr %l134
  %t290 = inttoptr i64 %t289 to ptr
  %t291 = load { i64, ptr }, ptr %l158
  %t292 = extractvalue { i64, ptr } %t291, 1
  %t293 = call ptr @__olang_region_or(ptr %t292, ptr null)
  %t294 = icmp ne ptr %t293, null
  %t295 = select i1 %t294, ptr %t293, ptr null
  call void @__olang_region_settle_in(ptr %t290, ptr %t295)
  br label %bb69
bb72:
  %t296 = load { i64, ptr }, ptr %l162
  %t297 = extractvalue { i64, ptr } %t296, 1
  call void @__olang_region_release(ptr %t297)
  store { i64, ptr } zeroinitializer, ptr %l162
  br label %bb73
bb73:
  %t298 = load ptr, ptr %l3, !tbaa !29
  %t299 = load ptr, ptr %l5, !tbaa !29
  %t301 = getelementptr %"compiler/ast:Func", ptr %t299, i32 0, i32 9
  %t302 = load i32, ptr %t301, !tbaa !23
  %t305 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %s1, ptr %t298, i32 %t302)
  store { i64, ptr } %t305, ptr %l167
  br label %bb74
bb74:
  %t306 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t306, ptr %l6, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t307, ptr %l168, !tbaa !27
  %t308 = load ptr, ptr %l5, !tbaa !29
  %t310 = getelementptr %"compiler/ast:Func", ptr %t308, i32 0, i32 8
  %t311 = load ptr, ptr %t310, !tbaa !29
  %t313 = icmp eq ptr %t311, null
  br i1 %t313, label %bb75, label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_8cc976989131f049_16bcaa94a8222275)
  unreachable
bb76:
  br label %bb77
bb77:
  %t315 = load ptr, ptr %l5, !tbaa !29
  %t317 = getelementptr %"compiler/ast:Func", ptr %t315, i32 0, i32 8
  %t318 = load ptr, ptr %t317, !tbaa !29
  %t320 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t318)
  store %"compiler/source:Span" %t320, ptr %l174
  br label %bb78
bb78:
  %t321 = getelementptr %"compiler/source:Span", ptr %l174, i32 0, i32 1
  %t322 = load i32, ptr %t321, !tbaa !23
  %t324 = sext i32 %t322 to i64
  %t325 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t326 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t329 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %s1, { i64, ptr } %t326, i64 %t324, { i64, ptr } %t325)
  store i64 %t329, ptr %l178
  br label %bb79
bb79:
  %t330 = load i64, ptr %l178, !tbaa !24
  store i64 %t330, ptr %l7, !tbaa !24
  br label %bb80
bb80:
  %t331 = load ptr, ptr %l0, !tbaa !29
  store ptr %t331, ptr %l179, !tbaa !29
  %t332 = load ptr, ptr %l1, !tbaa !29
  store ptr %t332, ptr %l180, !tbaa !29
  %t333 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t333, ptr %l181, !tbaa !27
  %t334 = load ptr, ptr %l5, !tbaa !29
  %t336 = getelementptr %"compiler/ast:Func", ptr %t334, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !29
  %t339 = icmp eq ptr %t337, null
  %t341 = xor i1 %t339, true
  br i1 %t341, label %bb81, label %bb82
bb81:
  store i1 true, ptr %l186, !tbaa !21
  br label %bb84
bb82:
  %t343 = load ptr, ptr %l5, !tbaa !29
  %t345 = call i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v2, ptr %t343)
  store i1 %t345, ptr %l188
  br label %bb83
bb83:
  %t346 = load i1, ptr %l188, !tbaa !21
  store i1 %t346, ptr %l186, !tbaa !21
  br label %bb84
bb84:
  %t347 = load i1, ptr %l186, !tbaa !21
  br i1 %t347, label %bb85, label %bb86
bb85:
  %t348 = load i64, ptr @G_2ecompiler_2fsession_2eKindMethod, !tbaa !24
  store i64 %t348, ptr %l189, !tbaa !24
  br label %bb87
bb86:
  %t350 = load i64, ptr @G_2ecompiler_2fsession_2eKindFunction, !tbaa !24
  store i64 %t350, ptr %l189, !tbaa !24
  br label %bb87
bb87:
  %t352 = load ptr, ptr %l5, !tbaa !29
  %t354 = getelementptr %"compiler/ast:Func", ptr %t352, i32 0, i32 0
  %t355 = getelementptr %"compiler/source:Span", ptr %t354, i32 0, i32 0
  %t356 = load i32, ptr %t355, !tbaa !23
  %t358 = sext i32 %t356 to i64
  %t359 = load ptr, ptr %l5, !tbaa !29
  %t361 = getelementptr %"compiler/ast:Func", ptr %t359, i32 0, i32 0
  %t362 = getelementptr %"compiler/source:Span", ptr %t361, i32 0, i32 1
  %t363 = load i32, ptr %t362, !tbaa !23
  %t365 = sext i32 %t363 to i64
  %t366 = load i64, ptr %l7, !tbaa !24
  %t367 = load i64, ptr %l7, !tbaa !24
  %t368 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t370 = extractvalue { i64, ptr } %t368, 0
  %t373 = add i64 %t367, %t370
  %t374 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t375, 1
  %t377 = call ptr @__olang_scope_of(ptr %t376, ptr null)
  %t378 = call ptr @__olang_scope_hold(ptr %t377)
  %t379 = ptrtoint ptr %t378 to i64
  %t381 = inttoptr i64 %t379 to ptr
  %t382 = load ptr, ptr %l179, !tbaa !29
  %t383 = load ptr, ptr %l180, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t385 = load i64, ptr %l189, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %t381, ptr %s1, ptr %t382, ptr %t383, { i64, ptr } %t384, i64 %t385, i64 %t358, i64 %t365, i64 %t366, i64 %t373, { i64, ptr } %t374)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s1)
  br label %bb232
bb89:
  %t391 = load ptr, ptr %l2, !tbaa !29
  store ptr %t391, ptr %l205, !tbaa !29
  store i1 false, ptr %l206, !tbaa !21
  %t392 = load ptr, ptr %l205, !tbaa !29
  %t393 = icmp ne ptr %t392, null
  br i1 %t393, label %bb90, label %bb91
bb90:
  %t395 = load ptr, ptr %l205, !tbaa !29
  %t396 = load i64, ptr %t395, !range !{i64 0, i64 12}
  %t398 = icmp eq i64 %t396, 2
  store i1 %t398, ptr %l206, !tbaa !21
  br label %bb91
bb91:
  %t399 = load i1, ptr %l206, !tbaa !21
  br i1 %t399, label %bb92, label %bb93
bb92:
  %t400 = load ptr, ptr %l2, !tbaa !29
  %t402 = getelementptr { i64, [8 x i64] }, ptr %t400, i32 0, i32 1
  %t403 = getelementptr { %"compiler/source:Span", ptr }, ptr %t402, i32 0, i32 0
  %t404 = load %"compiler/source:Span", ptr %t403
  store %"compiler/source:Span" %t404, ptr %l11
  %t406 = load ptr, ptr %l2, !tbaa !29
  %t408 = getelementptr { i64, [8 x i64] }, ptr %t406, i32 0, i32 1
  %t409 = getelementptr { %"compiler/source:Span", ptr }, ptr %t408, i32 0, i32 1
  %t410 = load ptr, ptr %t409
  store ptr %t410, ptr %l12, !tbaa !29
  br label %bb94
bb93:
  br label %bb133
bb94:
  store %olang.scope zeroinitializer, ptr %s6
  %t412 = load ptr, ptr %l3, !tbaa !29
  %t413 = load ptr, ptr %l12, !tbaa !29
  %t415 = getelementptr %"compiler/ast:TypeDecl", ptr %t413, i32 0, i32 0
  %t416 = load i32, ptr %t415, !tbaa !23
  %t419 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t412, i32 %t416)
  store { i64, ptr } %t419, ptr %l216
  br label %bb95
bb95:
  %t420 = load { i64, ptr }, ptr %l216, !tbaa !27
  store { i64, ptr } %t420, ptr %l13, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t422 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t423 = load i32, ptr %t422, !tbaa !23
  %t425 = sext i32 %t423 to i64
  %t426 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t430 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t421, i64 %t425, { i64, ptr } %t426)
  store i64 %t430, ptr %l221
  br label %bb96
bb96:
  %t431 = load i64, ptr %l221, !tbaa !24
  store i64 %t431, ptr %l14, !tbaa !24
  %t432 = load i64, ptr @G_2ecompiler_2fsession_2eKindClass, !tbaa !24
  store i64 %t432, ptr %l15, !tbaa !24
  %t434 = load ptr, ptr %l12, !tbaa !29
  %t436 = getelementptr %"compiler/ast:TypeDecl", ptr %t434, i32 0, i32 3
  %t437 = load ptr, ptr %t436, !tbaa !29
  %t439 = icmp eq ptr %t437, null
  %t441 = xor i1 %t439, true
  br i1 %t441, label %bb97, label %bb98
bb97:
  %t443 = load ptr, ptr %l12, !tbaa !29
  %t445 = getelementptr %"compiler/ast:TypeDecl", ptr %t443, i32 0, i32 3
  %t446 = load ptr, ptr %t445, !tbaa !29
  store ptr %t446, ptr %l16, !tbaa !29
  %t448 = load ptr, ptr %l16, !tbaa !29
  store ptr %t448, ptr %l230, !tbaa !29
  store i1 false, ptr %l231, !tbaa !21
  %t449 = load ptr, ptr %l230, !tbaa !29
  %t450 = icmp ne ptr %t449, null
  br i1 %t450, label %bb99, label %bb100
bb98:
  br label %bb122
bb99:
  %t452 = load ptr, ptr %l230, !tbaa !29
  %t453 = load i64, ptr %t452, !range !{i64 0, i64 5}
  %t455 = icmp eq i64 %t453, 0
  store i1 %t455, ptr %l231, !tbaa !21
  br label %bb100
bb100:
  %t456 = load i1, ptr %l231, !tbaa !21
  br i1 %t456, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  br label %bb104
bb103:
  %t457 = load i64, ptr @G_2ecompiler_2fsession_2eKindStruct, !tbaa !24
  store i64 %t457, ptr %l229, !tbaa !24
  br label %bb121
bb104:
  %t459 = load ptr, ptr %l16, !tbaa !29
  store ptr %t459, ptr %l235, !tbaa !29
  store i1 false, ptr %l236, !tbaa !21
  %t460 = load ptr, ptr %l235, !tbaa !29
  %t461 = icmp ne ptr %t460, null
  br i1 %t461, label %bb105, label %bb106
bb105:
  %t463 = load ptr, ptr %l235, !tbaa !29
  %t464 = load i64, ptr %t463, !range !{i64 0, i64 5}
  %t466 = icmp eq i64 %t464, 1
  store i1 %t466, ptr %l236, !tbaa !21
  br label %bb106
bb106:
  %t467 = load i1, ptr %l236, !tbaa !21
  br i1 %t467, label %bb107, label %bb108
bb107:
  br label %bb109
bb108:
  br label %bb110
bb109:
  %t468 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnum, !tbaa !24
  store i64 %t468, ptr %l229, !tbaa !24
  br label %bb121
bb110:
  %t470 = load ptr, ptr %l16, !tbaa !29
  store ptr %t470, ptr %l240, !tbaa !29
  store i1 false, ptr %l241, !tbaa !21
  %t471 = load ptr, ptr %l240, !tbaa !29
  %t472 = icmp ne ptr %t471, null
  br i1 %t472, label %bb111, label %bb112
bb111:
  %t474 = load ptr, ptr %l240, !tbaa !29
  %t475 = load i64, ptr %t474, !range !{i64 0, i64 5}
  %t477 = icmp eq i64 %t475, 2
  store i1 %t477, ptr %l241, !tbaa !21
  br label %bb112
bb112:
  %t478 = load i1, ptr %l241, !tbaa !21
  br i1 %t478, label %bb113, label %bb114
bb113:
  br label %bb115
bb114:
  br label %bb116
bb115:
  %t479 = load i64, ptr @G_2ecompiler_2fsession_2eKindInterface, !tbaa !24
  store i64 %t479, ptr %l229, !tbaa !24
  br label %bb121
bb116:
  br i1 true, label %bb117, label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb120
bb119:
  %t481 = load i64, ptr @G_2ecompiler_2fsession_2eKindClass, !tbaa !24
  store i64 %t481, ptr %l229, !tbaa !24
  br label %bb121
bb120:
  call void @__olang_check_failed(ptr @olang_loc_6d13c8aa31bd5d91_e2d0bffb643f3edd)
  unreachable
bb121:
  %t483 = load i64, ptr %l229, !tbaa !24
  store i64 %t483, ptr %l15, !tbaa !24
  br label %bb122
bb122:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load ptr, ptr %l1, !tbaa !29
  %t486 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t487 = load i64, ptr %l15, !tbaa !24
  %t488 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 0
  %t489 = load i32, ptr %t488, !tbaa !23
  %t491 = sext i32 %t489 to i64
  %t492 = getelementptr %"compiler/source:Span", ptr %l11, i32 0, i32 1
  %t493 = load i32, ptr %t492, !tbaa !23
  %t495 = sext i32 %t493 to i64
  %t496 = load i64, ptr %l14, !tbaa !24
  %t497 = load i64, ptr %l14, !tbaa !24
  %t498 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t498, 0
  %t503 = add i64 %t497, %t500
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v3, ptr %s6, ptr %t484, ptr %t485, { i64, ptr } %t486, i64 %t487, i64 %t491, i64 %t495, i64 %t496, i64 %t503, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d115, i32 0, i32 1) })
  br label %bb123
bb123:
  %t512 = load ptr, ptr %l0, !tbaa !29
  %t514 = getelementptr %"compiler/session:symWriter", ptr %t512, i32 0, i32 0
  %t515 = load ptr, ptr %t514, !tbaa !29
  %t517 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %s6, ptr %t515)
  store %"compiler/session:symWriter" %t517, ptr %l261
  br label %bb124
bb124:
  %t518 = load %"compiler/session:symWriter", ptr %l261
  store %"compiler/session:symWriter" %t518, ptr %l17
  %t519 = load ptr, ptr %l12, !tbaa !29
  %t521 = getelementptr %"compiler/ast:TypeDecl", ptr %t519, i32 0, i32 3
  %t522 = load ptr, ptr %t521, !tbaa !29
  %t524 = icmp eq ptr %t522, null
  %t526 = xor i1 %t524, true
  br i1 %t526, label %bb125, label %bb126
bb125:
  store ptr %l17, ptr %l266, !tbaa !29
  %t528 = load ptr, ptr %l1, !tbaa !29
  store ptr %t528, ptr %l267, !tbaa !29
  %t529 = load ptr, ptr %l12, !tbaa !29
  %t531 = getelementptr %"compiler/ast:TypeDecl", ptr %t529, i32 0, i32 3
  %t532 = load ptr, ptr %t531, !tbaa !29
  %t534 = icmp eq ptr %t532, null
  br i1 %t534, label %bb127, label %bb128
bb126:
  br label %bb131
bb127:
  call void @__olang_check_failed(ptr @olang_loc_aa1a720e54961963_b2017c5bfd4a977f)
  unreachable
bb128:
  br label %bb129
bb129:
  %t536 = load ptr, ptr %l12, !tbaa !29
  %t538 = getelementptr %"compiler/ast:TypeDecl", ptr %t536, i32 0, i32 3
  %t539 = load ptr, ptr %t538, !tbaa !29
  %t540 = load ptr, ptr %l3, !tbaa !29
  %t541 = load ptr, ptr %l266, !tbaa !29
  %t542 = load ptr, ptr %l267, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2emembers(ptr %s6, ptr %v1, ptr %v2, ptr %v3, ptr %t541, ptr %t542, ptr %t539, ptr %t540)
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t545 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s6, ptr %t545, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d116, i32 0, i32 1) })
  br label %bb132
bb132:
  call void @__olang_scope_close(ptr %s6)
  br label %bb232
bb133:
  %t547 = load ptr, ptr %l2, !tbaa !29
  store ptr %t547, ptr %l275, !tbaa !29
  store i1 false, ptr %l276, !tbaa !21
  %t548 = load ptr, ptr %l275, !tbaa !29
  %t549 = icmp ne ptr %t548, null
  br i1 %t549, label %bb134, label %bb135
bb134:
  %t551 = load ptr, ptr %l275, !tbaa !29
  %t552 = load i64, ptr %t551, !range !{i64 0, i64 12}
  %t554 = icmp eq i64 %t552, 3
  store i1 %t554, ptr %l276, !tbaa !21
  br label %bb135
bb135:
  %t555 = load i1, ptr %l276, !tbaa !21
  br i1 %t555, label %bb136, label %bb137
bb136:
  %t556 = load ptr, ptr %l2, !tbaa !29
  %t558 = getelementptr { i64, [8 x i64] }, ptr %t556, i32 0, i32 1
  %t559 = getelementptr { %"compiler/source:Span", ptr }, ptr %t558, i32 0, i32 0
  %t560 = load %"compiler/source:Span", ptr %t559
  store %"compiler/source:Span" %t560, ptr %l18
  %t562 = load ptr, ptr %l2, !tbaa !29
  %t564 = getelementptr { i64, [8 x i64] }, ptr %t562, i32 0, i32 1
  %t565 = getelementptr { %"compiler/source:Span", ptr }, ptr %t564, i32 0, i32 1
  %t566 = load ptr, ptr %t565
  store ptr %t566, ptr %l19, !tbaa !29
  br label %bb138
bb137:
  br label %bb151
bb138:
  store %olang.scope zeroinitializer, ptr %s13
  %t568 = load ptr, ptr %l3, !tbaa !29
  %t569 = load ptr, ptr %l19, !tbaa !29
  %t571 = getelementptr %"compiler/ast:MemberDecl", ptr %t569, i32 0, i32 1
  %t572 = load i32, ptr %t571, !tbaa !23
  %t575 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t568, i32 %t572)
  store { i64, ptr } %t575, ptr %l286
  br label %bb139
bb139:
  %t576 = load { i64, ptr }, ptr %l286, !tbaa !27
  store { i64, ptr } %t576, ptr %l20, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t577, ptr %l287, !tbaa !27
  %t578 = load ptr, ptr %l19, !tbaa !29
  %t580 = getelementptr %"compiler/ast:MemberDecl", ptr %t578, i32 0, i32 0
  %t581 = load ptr, ptr %t580, !tbaa !29
  %t583 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t581)
  store %"compiler/source:Span" %t583, ptr %l290
  br label %bb140
bb140:
  %t584 = getelementptr %"compiler/source:Span", ptr %l290, i32 0, i32 1
  %t585 = load i32, ptr %t584, !tbaa !23
  %t587 = sext i32 %t585 to i64
  %t588 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t589 = load { i64, ptr }, ptr %l287, !tbaa !27
  %t592 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t589, i64 %t587, { i64, ptr } %t588)
  store i64 %t592, ptr %l294
  br label %bb141
bb141:
  %t593 = load i64, ptr %l294, !tbaa !24
  store i64 %t593, ptr %l21, !tbaa !24
  %t594 = load ptr, ptr %l0, !tbaa !29
  store ptr %t594, ptr %l295, !tbaa !29
  %t595 = load ptr, ptr %l1, !tbaa !29
  store ptr %t595, ptr %l296, !tbaa !29
  %t596 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t596, ptr %l297, !tbaa !27
  %t597 = load i64, ptr @G_2ecompiler_2fsession_2eKindTypeParameter, !tbaa !24
  store i64 %t597, ptr %l298, !tbaa !24
  %t598 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t599 = load i32, ptr %t598, !tbaa !23
  %t601 = sext i32 %t599 to i64
  store i64 %t601, ptr %l300, !tbaa !24
  %t602 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t603 = load i32, ptr %t602, !tbaa !23
  %t605 = sext i32 %t603 to i64
  store i64 %t605, ptr %l302, !tbaa !24
  %t606 = load i64, ptr %l21, !tbaa !24
  store i64 %t606, ptr %l303, !tbaa !24
  %t607 = load i64, ptr %l21, !tbaa !24
  %t608 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t610 = extractvalue { i64, ptr } %t608, 0
  %t613 = add i64 %t607, %t610
  store i64 %t613, ptr %l307, !tbaa !24
  %t614 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t614, ptr %l308, !tbaa !27
  %t615 = load ptr, ptr %l19, !tbaa !29
  %t617 = getelementptr %"compiler/ast:MemberDecl", ptr %t615, i32 0, i32 0
  %t618 = load ptr, ptr %t617, !tbaa !29
  %t620 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t618)
  store %"compiler/source:Span" %t620, ptr %l311
  br label %bb142
bb142:
  %t621 = getelementptr %"compiler/source:Span", ptr %l311, i32 0, i32 0
  %t622 = load i32, ptr %t621, !tbaa !23
  %t624 = sext i32 %t622 to i64
  store i64 %t624, ptr %l313, !tbaa !24
  %t625 = load ptr, ptr %l19, !tbaa !29
  %t627 = getelementptr %"compiler/ast:MemberDecl", ptr %t625, i32 0, i32 0
  %t628 = load ptr, ptr %t627, !tbaa !29
  %t630 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v2, ptr %t628)
  store %"compiler/source:Span" %t630, ptr %l316
  br label %bb143
bb143:
  %t631 = getelementptr %"compiler/source:Span", ptr %l316, i32 0, i32 1
  %t632 = load i32, ptr %t631, !tbaa !23
  %t634 = sext i32 %t632 to i64
  store i64 %t634, ptr %l318, !tbaa !24
  %t635 = load { i64, ptr }, ptr %l308, !tbaa !27
  %t636 = extractvalue { i64, ptr } %t635, 0
  store i64 %t636, ptr %l319, !tbaa !24
  %t637 = load i64, ptr %l313, !tbaa !24
  %t638 = icmp sge i64 %t637, 0
  br i1 %t638, label %bb144, label %bb145
bb144:
  %t640 = load i64, ptr %l313, !tbaa !24
  %t641 = load i64, ptr %l318, !tbaa !24
  %t642 = icmp sle i64 %t640, %t641
  br i1 %t642, label %bb146, label %bb147
bb145:
  call void @__olang_check_failed(ptr @olang_loc_a8f128570d4ee58c_72533cb80a04a368)
  unreachable
bb146:
  %t644 = load i64, ptr %l318, !tbaa !24
  %t645 = load i64, ptr %l319, !tbaa !24
  %t646 = icmp sle i64 %t644, %t645
  br i1 %t646, label %bb148, label %bb149
bb147:
  call void @__olang_check_failed(ptr @olang_loc_a8f128570d4ee58c_72533cb80a04a368)
  unreachable
bb148:
  %t648 = getelementptr { i64, ptr }, ptr %l308, i32 0, i32 1
  %t649 = load ptr, ptr %t648, !tbaa !27
  %t650 = load i64, ptr %l313, !tbaa !24
  %t651 = load i64, ptr %l318, !tbaa !24
  %t652 = getelementptr i8, ptr %t649, i64 %t650
  %t653 = sub i64 %t651, %t650
  %t654 = insertvalue { i64, ptr } undef, i64 %t653, 0
  %t655 = insertvalue { i64, ptr } %t654, ptr %t652, 1
  %t657 = extractvalue { i64, ptr } %t655, 1
  %t658 = extractvalue { i64, ptr } %t655, 0
  %t659 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t658)
  call void @olang_textcopy(ptr %t659, ptr %t657, i64 %t658)
  %t660 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t661 = insertvalue { i64, ptr } %t660, ptr %t659, 1
  %t663 = load ptr, ptr %l295, !tbaa !29
  %t664 = load ptr, ptr %l296, !tbaa !29
  %t665 = load { i64, ptr }, ptr %l297, !tbaa !27
  %t666 = load i64, ptr %l298, !tbaa !24
  %t667 = load i64, ptr %l300, !tbaa !24
  %t668 = load i64, ptr %l302, !tbaa !24
  %t669 = load i64, ptr %l303, !tbaa !24
  %t670 = load i64, ptr %l307, !tbaa !24
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s13, ptr %t663, ptr %t664, { i64, ptr } %t665, i64 %t666, i64 %t667, i64 %t668, i64 %t669, i64 %t670, { i64, ptr } %t661)
  br label %bb150
bb149:
  call void @__olang_check_failed(ptr @olang_loc_a8f128570d4ee58c_72533cb80a04a368)
  unreachable
bb150:
  call void @__olang_scope_close(ptr %s13)
  br label %bb232
bb151:
  %t672 = load ptr, ptr %l2, !tbaa !29
  store ptr %t672, ptr %l326, !tbaa !29
  store i1 false, ptr %l327, !tbaa !21
  %t673 = load ptr, ptr %l326, !tbaa !29
  %t674 = icmp ne ptr %t673, null
  br i1 %t674, label %bb152, label %bb153
bb152:
  %t676 = load ptr, ptr %l326, !tbaa !29
  %t677 = load i64, ptr %t676, !range !{i64 0, i64 12}
  %t679 = icmp eq i64 %t677, 4
  store i1 %t679, ptr %l327, !tbaa !21
  br label %bb153
bb153:
  %t680 = load i1, ptr %l327, !tbaa !21
  br i1 %t680, label %bb154, label %bb155
bb154:
  %t681 = load ptr, ptr %l2, !tbaa !29
  %t683 = getelementptr { i64, [8 x i64] }, ptr %t681, i32 0, i32 1
  %t684 = getelementptr { %"compiler/source:Span", ptr }, ptr %t683, i32 0, i32 0
  %t685 = load %"compiler/source:Span", ptr %t684
  store %"compiler/source:Span" %t685, ptr %l22
  %t687 = load ptr, ptr %l2, !tbaa !29
  %t689 = getelementptr { i64, [8 x i64] }, ptr %t687, i32 0, i32 1
  %t690 = getelementptr { %"compiler/source:Span", ptr }, ptr %t689, i32 0, i32 1
  %t691 = load ptr, ptr %t690
  store ptr %t691, ptr %l23, !tbaa !29
  br label %bb156
bb155:
  br label %bb171
bb156:
  store i64 0, ptr %l24, !tbaa !24
  %t693 = load ptr, ptr %l23, !tbaa !29
  %t695 = getelementptr %"compiler/ast:VarDecl", ptr %t693, i32 0, i32 0
  %t696 = load { i64, ptr }, ptr %t695, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t696, 0
  store i64 %t698, ptr %l25, !tbaa !24
  store i64 1, ptr %l26, !tbaa !24
  %t700 = load i64, ptr %l25, !tbaa !24
  %t701 = load i64, ptr %l24, !tbaa !24
  %t704 = icmp sgt i64 %t700, %t701
  br i1 %t704, label %bb157, label %bb158
bb157:
  %t706 = load i64, ptr %l26, !tbaa !24
  %t708 = icmp sgt i64 %t706, 0
  br i1 %t708, label %bb159, label %bb160
bb158:
  store i64 0, ptr %l340, !tbaa !24
  br label %bb162
bb159:
  %t710 = load i64, ptr %l25, !tbaa !24
  %t711 = load i64, ptr %l24, !tbaa !24
  %t714 = sub i64 %t710, %t711
  %t715 = load i64, ptr %l26, !tbaa !24
  %t718 = add i64 %t714, %t715
  %t720 = sub i64 %t718, 1
  %t721 = load i64, ptr %l26, !tbaa !24
  %t724 = sdiv i64 %t720, %t721
  store i64 %t724, ptr %l343, !tbaa !24
  br label %bb161
bb160:
  store i64 0, ptr %l343, !tbaa !24
  br label %bb161
bb161:
  %t726 = load i64, ptr %l343, !tbaa !24
  store i64 %t726, ptr %l340, !tbaa !24
  br label %bb162
bb162:
  %t727 = load i64, ptr %l340, !tbaa !24
  store i64 %t727, ptr %l27, !tbaa !24
  store i64 0, ptr %l28, !tbaa !24
  br label %bb163
bb163:
  store %olang.scope zeroinitializer, ptr %s17
  %t728 = load i64, ptr %l28, !tbaa !24
  %t729 = load i64, ptr %l27, !tbaa !24
  %t732 = icmp slt i64 %t728, %t729
  %t734 = xor i1 %t732, true
  br i1 %t734, label %bb164, label %bb165
bb164:
  call void @__olang_scope_close(ptr %s17)
  br label %bb170
bb165:
  br label %bb166
bb166:
  %t736 = load i64, ptr %l24, !tbaa !24
  %t737 = load i64, ptr %l28, !tbaa !24
  %t738 = load i64, ptr %l26, !tbaa !24
  %t741 = mul i64 %t737, %t738
  %t744 = add i64 %t736, %t741
  store i64 %t744, ptr %l29, !tbaa !24
  %t746 = load ptr, ptr %l23, !tbaa !29
  %t748 = getelementptr %"compiler/ast:VarDecl", ptr %t746, i32 0, i32 1
  %t749 = load { i64, ptr }, ptr %t748, !tbaa !27
  store { i64, ptr } %t749, ptr %l362, !tbaa !27
  %t750 = load i64, ptr %l29, !tbaa !24
  %t752 = getelementptr { i64, ptr }, ptr %l362, i32 0, i32 1
  %t753 = load ptr, ptr %t752, !tbaa !27
  %t754 = getelementptr %"compiler/source:Span", ptr %t753, i64 %t750
  %t755 = load %"compiler/source:Span", ptr %t754
  store %"compiler/source:Span" %t755, ptr %l30
  %t757 = load ptr, ptr %l0, !tbaa !29
  store ptr %t757, ptr %l365, !tbaa !29
  %t758 = load ptr, ptr %l1, !tbaa !29
  store ptr %t758, ptr %l366, !tbaa !29
  %t759 = load ptr, ptr %l3, !tbaa !29
  %t760 = load ptr, ptr %l23, !tbaa !29
  %t762 = getelementptr %"compiler/ast:VarDecl", ptr %t760, i32 0, i32 0
  %t763 = load { i64, ptr }, ptr %t762, !tbaa !27
  store { i64, ptr } %t763, ptr %l369, !tbaa !27
  %t764 = load i64, ptr %l29, !tbaa !24
  %t766 = getelementptr { i64, ptr }, ptr %l369, i32 0, i32 1
  %t767 = load ptr, ptr %t766, !tbaa !27
  %t768 = getelementptr i32, ptr %t767, i64 %t764
  %t769 = load i32, ptr %t768, !tbaa !33
  %t772 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t759, i32 %t769)
  store { i64, ptr } %t772, ptr %l372
  br label %bb167
bb167:
  %t773 = load i64, ptr @G_2ecompiler_2fsession_2eKindVariable, !tbaa !24
  %t774 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t775 = load i32, ptr %t774, !tbaa !23
  %t777 = sext i32 %t775 to i64
  %t778 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 1
  %t779 = load i32, ptr %t778, !tbaa !23
  %t781 = sext i32 %t779 to i64
  %t782 = getelementptr %"compiler/source:Span", ptr %l30, i32 0, i32 0
  %t783 = load i32, ptr %t782, !tbaa !23
  %t785 = sext i32 %t783 to i64
  %t786 = getelementptr %"compiler/source:Span", ptr %l30, i32 0, i32 1
  %t787 = load i32, ptr %t786, !tbaa !23
  %t789 = sext i32 %t787 to i64
  %t790 = load ptr, ptr %l365, !tbaa !29
  %t791 = load ptr, ptr %l366, !tbaa !29
  %t792 = load { i64, ptr }, ptr %l372, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s17, ptr %t790, ptr %t791, { i64, ptr } %t792, i64 %t773, i64 %t777, i64 %t781, i64 %t785, i64 %t789, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) })
  br label %bb168
bb168:
  call void @__olang_scope_close(ptr %s17)
  br label %bb169
bb169:
  %t798 = load i64, ptr %l28, !tbaa !24
  %t801 = add i64 %t798, 1
  store i64 %t801, ptr %l28, !tbaa !24
  br label %bb163
bb170:
  br label %bb232
bb171:
  %t803 = load ptr, ptr %l2, !tbaa !29
  store ptr %t803, ptr %l385, !tbaa !29
  store i1 false, ptr %l386, !tbaa !21
  %t804 = load ptr, ptr %l385, !tbaa !29
  %t805 = icmp ne ptr %t804, null
  br i1 %t805, label %bb172, label %bb173
bb172:
  %t807 = load ptr, ptr %l385, !tbaa !29
  %t808 = load i64, ptr %t807, !range !{i64 0, i64 12}
  %t810 = icmp eq i64 %t808, 6
  store i1 %t810, ptr %l386, !tbaa !21
  br label %bb173
bb173:
  %t811 = load i1, ptr %l386, !tbaa !21
  br i1 %t811, label %bb174, label %bb175
bb174:
  %t812 = load ptr, ptr %l2, !tbaa !29
  %t814 = getelementptr { i64, [8 x i64] }, ptr %t812, i32 0, i32 1
  %t815 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t814, i32 0, i32 0
  %t816 = load %"compiler/source:Span", ptr %t815
  store %"compiler/source:Span" %t816, ptr %l31
  %t818 = load ptr, ptr %l2, !tbaa !29
  %t820 = getelementptr { i64, [8 x i64] }, ptr %t818, i32 0, i32 1
  %t821 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t820, i32 0, i32 1
  %t822 = load i32, ptr %t821
  store i32 %t822, ptr %l32, !tbaa !23
  %t824 = load ptr, ptr %l2, !tbaa !29
  %t826 = getelementptr { i64, [8 x i64] }, ptr %t824, i32 0, i32 1
  %t827 = getelementptr { %"compiler/source:Span", i32, { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t826, i32 0, i32 2
  %t828 = load { i64, ptr }, ptr %t827
  store { i64, ptr } %t828, ptr %l33, !tbaa !27
  br label %bb176
bb175:
  br label %bb194
bb176:
  store %olang.scope zeroinitializer, ptr %s19
  %t830 = load ptr, ptr %l3, !tbaa !29
  %t831 = load i32, ptr %l32, !tbaa !23
  %t834 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t830, i32 %t831)
  store { i64, ptr } %t834, ptr %l397
  br label %bb177
bb177:
  %t835 = load { i64, ptr }, ptr %l397, !tbaa !27
  store { i64, ptr } %t835, ptr %l34, !tbaa !27
  %t836 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t837 = getelementptr %"compiler/source:Span", ptr %l31, i32 0, i32 0
  %t838 = load i32, ptr %t837, !tbaa !23
  %t840 = sext i32 %t838 to i64
  %t841 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t845 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t836, i64 %t840, { i64, ptr } %t841)
  store i64 %t845, ptr %l402
  br label %bb178
bb178:
  %t846 = load i64, ptr %l402, !tbaa !24
  store i64 %t846, ptr %l35, !tbaa !24
  %t847 = load ptr, ptr %l0, !tbaa !29
  %t848 = load ptr, ptr %l1, !tbaa !29
  %t849 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t850 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnum, !tbaa !24
  %t851 = getelementptr %"compiler/source:Span", ptr %l31, i32 0, i32 0
  %t852 = load i32, ptr %t851, !tbaa !23
  %t854 = sext i32 %t852 to i64
  %t855 = getelementptr %"compiler/source:Span", ptr %l31, i32 0, i32 1
  %t856 = load i32, ptr %t855, !tbaa !23
  %t858 = sext i32 %t856 to i64
  %t859 = load i64, ptr %l35, !tbaa !24
  %t860 = load i64, ptr %l35, !tbaa !24
  %t861 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t863 = extractvalue { i64, ptr } %t861, 0
  %t866 = add i64 %t860, %t863
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v3, ptr %s19, ptr %t847, ptr %t848, { i64, ptr } %t849, i64 %t850, i64 %t854, i64 %t858, i64 %t859, i64 %t866, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d118, i32 0, i32 1) })
  br label %bb179
bb179:
  %t875 = load ptr, ptr %l0, !tbaa !29
  %t877 = getelementptr %"compiler/session:symWriter", ptr %t875, i32 0, i32 0
  %t878 = load ptr, ptr %t877, !tbaa !29
  %t880 = call %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %s19, ptr %t878)
  store %"compiler/session:symWriter" %t880, ptr %l418
  br label %bb180
bb180:
  %t881 = load %"compiler/session:symWriter", ptr %l418
  store %"compiler/session:symWriter" %t881, ptr %l36
  %t882 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t882, ptr %l37, !tbaa !27
  store i64 0, ptr %l38, !tbaa !24
  %t884 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t886 = extractvalue { i64, ptr } %t884, 0
  store i64 %t886, ptr %l39, !tbaa !24
  br label %bb181
bb181:
  %t888 = load i64, ptr %l38, !tbaa !24
  %t889 = load i64, ptr %l39, !tbaa !24
  %t892 = icmp slt i64 %t888, %t889
  %t894 = xor i1 %t892, true
  br i1 %t894, label %bb182, label %bb183
bb182:
  br label %bb192
bb183:
  br label %bb184
bb184:
  %t896 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t896, ptr %l426, !tbaa !27
  %t897 = load i64, ptr %l38, !tbaa !24
  %t899 = getelementptr { i64, ptr }, ptr %l426, i32 0, i32 1
  %t900 = load ptr, ptr %t899, !tbaa !27
  %t901 = getelementptr i32, ptr %t900, i64 %t897
  %t902 = load i32, ptr %t901, !tbaa !33
  %t904 = load ptr, ptr %l3, !tbaa !29
  %t908 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t904, i32 %t902)
  store { i64, ptr } %t908, ptr %l431
  br label %bb185
bb185:
  %t909 = load { i64, ptr }, ptr %l431, !tbaa !27
  store { i64, ptr } %t909, ptr %l41, !tbaa !27
  %t910 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t911 = load i64, ptr %l35, !tbaa !24
  %t912 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t914 = extractvalue { i64, ptr } %t912, 0
  %t917 = add i64 %t911, %t914
  %t918 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t922 = call i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v3, { i64, ptr } %t910, i64 %t917, { i64, ptr } %t918)
  store i64 %t922, ptr %l438
  br label %bb186
bb186:
  %t923 = load i64, ptr %l438, !tbaa !24
  store i64 %t923, ptr %l42, !tbaa !24
  %t924 = load i64, ptr %l42, !tbaa !24
  %t926 = icmp sge i64 %t924, 0
  br i1 %t926, label %bb187, label %bb188
bb187:
  store %olang.scope zeroinitializer, ptr %s22
  %t928 = load ptr, ptr %l1, !tbaa !29
  %t929 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t930 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnumMember, !tbaa !24
  %t931 = load i64, ptr %l42, !tbaa !24
  %t932 = load i64, ptr %l42, !tbaa !24
  %t933 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t935 = extractvalue { i64, ptr } %t933, 0
  %t938 = add i64 %t932, %t935
  %t939 = load i64, ptr %l42, !tbaa !24
  %t940 = load i64, ptr %l42, !tbaa !24
  %t941 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t943 = extractvalue { i64, ptr } %t941, 0
  %t946 = add i64 %t940, %t943
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %s19, ptr %v1, ptr %v3, ptr %s22, ptr %l36, ptr %t928, { i64, ptr } %t929, i64 %t930, i64 %t931, i64 %t938, i64 %t939, i64 %t946, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d119, i32 0, i32 1) })
  br label %bb189
bb188:
  br label %bb190
bb189:
  call void @__olang_scope_close(ptr %s22)
  br label %bb190
bb190:
  br label %bb191
bb191:
  %t955 = load i64, ptr %l38, !tbaa !24
  %t958 = add i64 %t955, 1
  store i64 %t958, ptr %l38, !tbaa !24
  br label %bb181
bb192:
  %t960 = load ptr, ptr %l1, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s19, ptr %t960, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) })
  br label %bb193
bb193:
  call void @__olang_scope_close(ptr %s19)
  br label %bb232
bb194:
  %t962 = load ptr, ptr %l2, !tbaa !29
  store ptr %t962, ptr %l459, !tbaa !29
  store i1 false, ptr %l460, !tbaa !21
  %t963 = load ptr, ptr %l459, !tbaa !29
  %t964 = icmp ne ptr %t963, null
  br i1 %t964, label %bb195, label %bb196
bb195:
  %t966 = load ptr, ptr %l459, !tbaa !29
  %t967 = load i64, ptr %t966, !range !{i64 0, i64 12}
  %t969 = icmp eq i64 %t967, 7
  store i1 %t969, ptr %l460, !tbaa !21
  br label %bb196
bb196:
  %t970 = load i1, ptr %l460, !tbaa !21
  br i1 %t970, label %bb197, label %bb198
bb197:
  %t971 = load ptr, ptr %l2, !tbaa !29
  %t973 = getelementptr { i64, [8 x i64] }, ptr %t971, i32 0, i32 1
  %t974 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t973, i32 0, i32 0
  %t975 = load %"compiler/source:Span", ptr %t974
  store %"compiler/source:Span" %t975, ptr %l43
  %t977 = load ptr, ptr %l2, !tbaa !29
  %t979 = getelementptr { i64, [8 x i64] }, ptr %t977, i32 0, i32 1
  %t980 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr }, ptr }, ptr %t979, i32 0, i32 1
  %t981 = load %"compiler/source:Span", ptr %t980
  store %"compiler/source:Span" %t981, ptr %l44
  br label %bb199
bb198:
  br label %bb207
bb199:
  store %olang.scope zeroinitializer, ptr %s24
  %t983 = load ptr, ptr %l0, !tbaa !29
  store ptr %t983, ptr %l467, !tbaa !29
  %t984 = load ptr, ptr %l1, !tbaa !29
  store ptr %t984, ptr %l468, !tbaa !29
  %t985 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t985, ptr %l469, !tbaa !27
  %t986 = getelementptr %"compiler/source:Span", ptr %l44, i32 0, i32 0
  %t987 = load i32, ptr %t986, !tbaa !23
  %t989 = sext i32 %t987 to i64
  store i64 %t989, ptr %l471, !tbaa !24
  %t990 = getelementptr %"compiler/source:Span", ptr %l44, i32 0, i32 1
  %t991 = load i32, ptr %t990, !tbaa !23
  %t993 = sext i32 %t991 to i64
  store i64 %t993, ptr %l473, !tbaa !24
  %t994 = load { i64, ptr }, ptr %l469, !tbaa !27
  %t995 = extractvalue { i64, ptr } %t994, 0
  store i64 %t995, ptr %l474, !tbaa !24
  %t996 = load i64, ptr %l471, !tbaa !24
  %t997 = icmp sge i64 %t996, 0
  br i1 %t997, label %bb200, label %bb201
bb200:
  %t999 = load i64, ptr %l471, !tbaa !24
  %t1000 = load i64, ptr %l473, !tbaa !24
  %t1001 = icmp sle i64 %t999, %t1000
  br i1 %t1001, label %bb202, label %bb203
bb201:
  call void @__olang_check_failed(ptr @olang_loc_a1b1115ef3955beb_c10ad3dd013eb27f)
  unreachable
bb202:
  %t1003 = load i64, ptr %l473, !tbaa !24
  %t1004 = load i64, ptr %l474, !tbaa !24
  %t1005 = icmp sle i64 %t1003, %t1004
  br i1 %t1005, label %bb204, label %bb205
bb203:
  call void @__olang_check_failed(ptr @olang_loc_a1b1115ef3955beb_c10ad3dd013eb27f)
  unreachable
bb204:
  %t1007 = getelementptr { i64, ptr }, ptr %l469, i32 0, i32 1
  %t1008 = load ptr, ptr %t1007, !tbaa !27
  %t1009 = load i64, ptr %l471, !tbaa !24
  %t1010 = load i64, ptr %l473, !tbaa !24
  %t1011 = getelementptr i8, ptr %t1008, i64 %t1009
  %t1012 = sub i64 %t1010, %t1009
  %t1013 = insertvalue { i64, ptr } undef, i64 %t1012, 0
  %t1014 = insertvalue { i64, ptr } %t1013, ptr %t1011, 1
  %t1015 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, 1
  %t1016 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d121, i32 0, i32 1) }, 0
  %t1018 = extractvalue { i64, ptr } %t1014, 1
  %t1019 = extractvalue { i64, ptr } %t1014, 0
  %t1020 = add i64 %t1016, %t1019
  %t1021 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t1020)
  call void @olang_textcopy(ptr %t1021, ptr %t1015, i64 %t1016)
  %t1022 = getelementptr i8, ptr %t1021, i64 %t1016
  call void @olang_textcopy(ptr %t1022, ptr %t1018, i64 %t1019)
  %t1023 = insertvalue { i64, ptr } undef, i64 %t1020, 0
  %t1024 = insertvalue { i64, ptr } %t1023, ptr %t1021, 1
  %t1026 = load i64, ptr @G_2ecompiler_2fsession_2eKindFunction, !tbaa !24
  %t1027 = getelementptr %"compiler/source:Span", ptr %l43, i32 0, i32 0
  %t1028 = load i32, ptr %t1027, !tbaa !23
  %t1030 = sext i32 %t1028 to i64
  %t1031 = getelementptr %"compiler/source:Span", ptr %l43, i32 0, i32 1
  %t1032 = load i32, ptr %t1031, !tbaa !23
  %t1034 = sext i32 %t1032 to i64
  %t1035 = getelementptr %"compiler/source:Span", ptr %l44, i32 0, i32 0
  %t1036 = load i32, ptr %t1035, !tbaa !23
  %t1038 = sext i32 %t1036 to i64
  %t1039 = getelementptr %"compiler/source:Span", ptr %l44, i32 0, i32 1
  %t1040 = load i32, ptr %t1039, !tbaa !23
  %t1042 = sext i32 %t1040 to i64
  %t1043 = load ptr, ptr %l467, !tbaa !29
  %t1044 = load ptr, ptr %l468, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %s24, ptr %s24, ptr %t1043, ptr %t1044, { i64, ptr } %t1024, i64 %t1026, i64 %t1030, i64 %t1034, i64 %t1038, i64 %t1042, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d122, i32 0, i32 1) })
  br label %bb206
bb205:
  call void @__olang_check_failed(ptr @olang_loc_a1b1115ef3955beb_c10ad3dd013eb27f)
  unreachable
bb206:
  call void @__olang_scope_close(ptr %s24)
  br label %bb232
bb207:
  %t1051 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1051, ptr %l490, !tbaa !29
  store i1 false, ptr %l491, !tbaa !21
  %t1052 = load ptr, ptr %l490, !tbaa !29
  %t1053 = icmp ne ptr %t1052, null
  br i1 %t1053, label %bb208, label %bb209
bb208:
  %t1055 = load ptr, ptr %l490, !tbaa !29
  %t1056 = load i64, ptr %t1055, !range !{i64 0, i64 12}
  %t1058 = icmp eq i64 %t1056, 8
  store i1 %t1058, ptr %l491, !tbaa !21
  br label %bb209
bb209:
  %t1059 = load i1, ptr %l491, !tbaa !21
  br i1 %t1059, label %bb210, label %bb211
bb210:
  %t1060 = load ptr, ptr %l2, !tbaa !29
  %t1062 = getelementptr { i64, [8 x i64] }, ptr %t1060, i32 0, i32 1
  %t1063 = getelementptr { %"compiler/source:Span", ptr }, ptr %t1062, i32 0, i32 1
  %t1064 = load ptr, ptr %t1063
  store ptr %t1064, ptr %l45, !tbaa !29
  br label %bb212
bb211:
  br label %bb214
bb212:
  %t1066 = load ptr, ptr %l0, !tbaa !29
  %t1067 = load ptr, ptr %l1, !tbaa !29
  %t1068 = load ptr, ptr %l45, !tbaa !29
  %t1070 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1066, ptr %t1067, ptr %t1068, ptr %t1070)
  br label %bb213
bb213:
  br label %bb232
bb214:
  %t1075 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1075, ptr %l501, !tbaa !29
  store i1 false, ptr %l502, !tbaa !21
  %t1076 = load ptr, ptr %l501, !tbaa !29
  %t1077 = icmp ne ptr %t1076, null
  br i1 %t1077, label %bb215, label %bb216
bb215:
  %t1079 = load ptr, ptr %l501, !tbaa !29
  %t1080 = load i64, ptr %t1079, !range !{i64 0, i64 12}
  %t1082 = icmp eq i64 %t1080, 11
  store i1 %t1082, ptr %l502, !tbaa !21
  br label %bb216
bb216:
  %t1083 = load i1, ptr %l502, !tbaa !21
  br i1 %t1083, label %bb217, label %bb218
bb217:
  %t1084 = load ptr, ptr %l2, !tbaa !29
  %t1086 = getelementptr { i64, [8 x i64] }, ptr %t1084, i32 0, i32 1
  %t1087 = getelementptr { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } }, ptr %t1086, i32 0, i32 2
  %t1088 = load { i64, ptr }, ptr %t1087
  store { i64, ptr } %t1088, ptr %l46, !tbaa !27
  br label %bb219
bb218:
  br label %bb227
bb219:
  %t1090 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t1090, ptr %l47, !tbaa !27
  store i64 0, ptr %l48, !tbaa !24
  %t1092 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t1094 = extractvalue { i64, ptr } %t1092, 0
  store i64 %t1094, ptr %l49, !tbaa !24
  br label %bb220
bb220:
  %t1096 = load i64, ptr %l48, !tbaa !24
  %t1097 = load i64, ptr %l49, !tbaa !24
  %t1100 = icmp slt i64 %t1096, %t1097
  %t1102 = xor i1 %t1100, true
  br i1 %t1102, label %bb221, label %bb222
bb221:
  br label %bb226
bb222:
  br label %bb223
bb223:
  %t1104 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t1104, ptr %l514, !tbaa !27
  %t1105 = load i64, ptr %l48, !tbaa !24
  %t1107 = getelementptr { i64, ptr }, ptr %l514, i32 0, i32 1
  %t1108 = load ptr, ptr %t1107, !tbaa !27
  %t1109 = getelementptr ptr, ptr %t1108, i64 %t1105
  %t1110 = load ptr, ptr %t1109, !tbaa !39
  %t1112 = load ptr, ptr %l0, !tbaa !29
  %t1113 = load ptr, ptr %l1, !tbaa !29
  %t1115 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t1112, ptr %t1113, ptr %t1110, ptr %t1115)
  br label %bb224
bb224:
  br label %bb225
bb225:
  %t1120 = load i64, ptr %l48, !tbaa !24
  %t1123 = add i64 %t1120, 1
  store i64 %t1123, ptr %l48, !tbaa !24
  br label %bb220
bb226:
  br label %bb232
bb227:
  br i1 true, label %bb228, label %bb229
bb228:
  br label %bb230
bb229:
  br label %bb231
bb230:
  br label %bb232
bb231:
  call void @__olang_check_failed(ptr @olang_loc_d921cd6da7eb22f5_584e6aeeea9cbb69)
  unreachable
bb232:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2emembers(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca %"compiler/source:Span"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l35 = alloca ptr
  %l36 = alloca i1
  %l53 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l57 = alloca i1
  %l72 = alloca i64
  %l75 = alloca i64
  %l95 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca %"compiler/source:Span"
  %l111 = alloca %"compiler/source:Span"
  %l124 = alloca ptr
  %l125 = alloca i1
  %l137 = alloca { i64, ptr }
  %l143 = alloca { i64, ptr }
  %l166 = alloca ptr
  %l167 = alloca i1
  %l179 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l191 = alloca i64
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/session:symWriter", ptr %t1, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/session:Positions", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l4, !tbaa !27
  %t9 = load ptr, ptr %l2, !tbaa !29
  store ptr %t9, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t10 = load ptr, ptr %l35, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb1, label %bb2
bb1:
  %t13 = load ptr, ptr %l35, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 5}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l36, !tbaa !21
  br label %bb2
bb2:
  %t17 = load i1, ptr %l36, !tbaa !21
  br i1 %t17, label %bb3, label %bb4
bb3:
  %t18 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr { i64, [6 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { ptr }, ptr %t20, i32 0, i32 0
  %t22 = load ptr, ptr %t21
  store ptr %t22, ptr %l5, !tbaa !29
  br label %bb5
bb4:
  br label %bb34
bb5:
  %t24 = load ptr, ptr %l5, !tbaa !29
  %t26 = getelementptr %"compiler/ast:StructBody", ptr %t24, i32 0, i32 2
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t31 = icmp eq i64 %t29, 0
  br i1 %t31, label %bb6, label %bb7
bb6:
  br label %ret
bb7:
  br label %bb8
bb8:
  %t33 = load ptr, ptr %l5, !tbaa !29
  %t35 = getelementptr %"compiler/ast:StructBody", ptr %t33, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l8, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb10, label %bb11
bb10:
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t50 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t50, ptr %l53, !tbaa !27
  %t51 = load i64, ptr %l7, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr ptr, ptr %t54, i64 %t51
  %t56 = load ptr, ptr %t55, !tbaa !39
  store ptr %t56, ptr %l9, !tbaa !29
  %t58 = load ptr, ptr %l9, !tbaa !29
  store ptr %t58, ptr %l56, !tbaa !29
  store i1 false, ptr %l57, !tbaa !21
  %t59 = load ptr, ptr %l56, !tbaa !29
  %t60 = icmp ne ptr %t59, null
  br i1 %t60, label %bb13, label %bb14
bb13:
  %t62 = load ptr, ptr %l56, !tbaa !29
  %t63 = load i64, ptr %t62, !range !{i64 0, i64 22}
  %t65 = icmp eq i64 %t63, 1
  store i1 %t65, ptr %l57, !tbaa !21
  br label %bb14
bb14:
  %t66 = load i1, ptr %l57, !tbaa !21
  %t67 = xor i1 %t66, true
  br i1 %t67, label %bb15, label %bb16
bb15:
  br label %bb32
bb16:
  br label %bb17
bb17:
  %t69 = load ptr, ptr %l9, !tbaa !29
  %t71 = getelementptr { i64, [4 x i64] }, ptr %t69, i32 0, i32 1
  %t72 = getelementptr { %"compiler/source:Span", ptr }, ptr %t71, i32 0, i32 0
  %t73 = load %"compiler/source:Span", ptr %t72
  store %"compiler/source:Span" %t73, ptr %l10
  %t75 = load ptr, ptr %l9, !tbaa !29
  %t77 = getelementptr { i64, [4 x i64] }, ptr %t75, i32 0, i32 1
  %t78 = getelementptr { %"compiler/source:Span", ptr }, ptr %t77, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  store ptr %t79, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  %t81 = load ptr, ptr %l11, !tbaa !29
  %t84 = getelementptr %"compiler/ast:VarDecl", ptr %t81, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 0
  store i64 %t87, ptr %l13, !tbaa !24
  store i64 1, ptr %l14, !tbaa !24
  %t89 = load i64, ptr %l13, !tbaa !24
  %t90 = load i64, ptr %l12, !tbaa !24
  %t93 = icmp sgt i64 %t89, %t90
  br i1 %t93, label %bb18, label %bb19
bb18:
  %t95 = load i64, ptr %l14, !tbaa !24
  %t97 = icmp sgt i64 %t95, 0
  br i1 %t97, label %bb20, label %bb21
bb19:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb23
bb20:
  %t99 = load i64, ptr %l13, !tbaa !24
  %t100 = load i64, ptr %l12, !tbaa !24
  %t103 = sub i64 %t99, %t100
  %t104 = load i64, ptr %l14, !tbaa !24
  %t107 = add i64 %t103, %t104
  %t109 = sub i64 %t107, 1
  %t110 = load i64, ptr %l14, !tbaa !24
  %t113 = sdiv i64 %t109, %t110
  store i64 %t113, ptr %l75, !tbaa !24
  br label %bb22
bb21:
  store i64 0, ptr %l75, !tbaa !24
  br label %bb22
bb22:
  %t115 = load i64, ptr %l75, !tbaa !24
  store i64 %t115, ptr %l72, !tbaa !24
  br label %bb23
bb23:
  %t116 = load i64, ptr %l72, !tbaa !24
  store i64 %t116, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t117 = load i64, ptr %l16, !tbaa !24
  %t118 = load i64, ptr %l15, !tbaa !24
  %t121 = icmp slt i64 %t117, %t118
  %t123 = xor i1 %t121, true
  br i1 %t123, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s7)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t125 = load i64, ptr %l12, !tbaa !24
  %t126 = load i64, ptr %l16, !tbaa !24
  %t127 = load i64, ptr %l14, !tbaa !24
  %t130 = mul i64 %t126, %t127
  %t133 = add i64 %t125, %t130
  store i64 %t133, ptr %l17, !tbaa !24
  %t135 = load ptr, ptr %l11, !tbaa !29
  %t138 = getelementptr %"compiler/ast:VarDecl", ptr %t135, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l95, !tbaa !27
  %t140 = load i64, ptr %l17, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr %"compiler/source:Span", ptr %t143, i64 %t140
  %t145 = load %"compiler/source:Span", ptr %t144
  store %"compiler/source:Span" %t145, ptr %l18
  %t147 = load ptr, ptr %l0, !tbaa !29
  store ptr %t147, ptr %l98, !tbaa !29
  %t148 = load ptr, ptr %l1, !tbaa !29
  store ptr %t148, ptr %l99, !tbaa !29
  %t149 = load ptr, ptr %l3, !tbaa !29
  %t150 = load ptr, ptr %l11, !tbaa !29
  %t153 = getelementptr %"compiler/ast:VarDecl", ptr %t150, i32 0, i32 0
  %t154 = load { i64, ptr }, ptr %t153, !tbaa !27
  store { i64, ptr } %t154, ptr %l103, !tbaa !27
  %t155 = load i64, ptr %l17, !tbaa !24
  %t157 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = getelementptr i32, ptr %t158, i64 %t155
  %t160 = load i32, ptr %t159, !tbaa !33
  %t163 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t149, i32 %t160)
  store { i64, ptr } %t163, ptr %l106
  br label %bb28
bb28:
  %t164 = load i64, ptr @G_2ecompiler_2fsession_2eKindField, !tbaa !24
  %t165 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t165, ptr %l108
  %t166 = getelementptr %"compiler/source:Span", ptr %l108, i32 0, i32 0
  %t167 = load i32, ptr %t166, !tbaa !23
  %t169 = sext i32 %t167 to i64
  %t170 = load %"compiler/source:Span", ptr %l10
  store %"compiler/source:Span" %t170, ptr %l111
  %t171 = getelementptr %"compiler/source:Span", ptr %l111, i32 0, i32 1
  %t172 = load i32, ptr %t171, !tbaa !23
  %t174 = sext i32 %t172 to i64
  %t175 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 0
  %t176 = load i32, ptr %t175, !tbaa !23
  %t178 = sext i32 %t176 to i64
  %t179 = getelementptr %"compiler/source:Span", ptr %l18, i32 0, i32 1
  %t180 = load i32, ptr %t179, !tbaa !23
  %t182 = sext i32 %t180 to i64
  %t183 = load ptr, ptr %l98, !tbaa !29
  %t184 = load ptr, ptr %l99, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l106, !tbaa !27
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s7, ptr %t183, ptr %t184, { i64, ptr } %t185, i64 %t164, i64 %t169, i64 %t174, i64 %t178, i64 %t182, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) })
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s7)
  br label %bb30
bb30:
  %t191 = load i64, ptr %l16, !tbaa !24
  %t194 = add i64 %t191, 1
  store i64 %t194, ptr %l16, !tbaa !24
  br label %bb24
bb31:
  br label %bb32
bb32:
  %t196 = load i64, ptr %l7, !tbaa !24
  %t199 = add i64 %t196, 1
  store i64 %t199, ptr %l7, !tbaa !24
  br label %bb9
bb33:
  br label %bb68
bb34:
  %t201 = load ptr, ptr %l2, !tbaa !29
  store ptr %t201, ptr %l124, !tbaa !29
  store i1 false, ptr %l125, !tbaa !21
  %t202 = load ptr, ptr %l124, !tbaa !29
  %t203 = icmp ne ptr %t202, null
  br i1 %t203, label %bb35, label %bb36
bb35:
  %t205 = load ptr, ptr %l124, !tbaa !29
  %t206 = load i64, ptr %t205, !range !{i64 0, i64 5}
  %t208 = icmp eq i64 %t206, 1
  store i1 %t208, ptr %l125, !tbaa !21
  br label %bb36
bb36:
  %t209 = load i1, ptr %l125, !tbaa !21
  br i1 %t209, label %bb37, label %bb38
bb37:
  %t210 = load ptr, ptr %l2, !tbaa !29
  %t212 = getelementptr { i64, [6 x i64] }, ptr %t210, i32 0, i32 1
  %t213 = getelementptr { { i64, ptr }, ptr }, ptr %t212, i32 0, i32 0
  %t214 = load { i64, ptr }, ptr %t213
  store { i64, ptr } %t214, ptr %l19, !tbaa !27
  br label %bb39
bb38:
  br label %bb48
bb39:
  %t216 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t216, ptr %l20, !tbaa !27
  store i64 0, ptr %l21, !tbaa !24
  %t218 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t218, 0
  store i64 %t220, ptr %l22, !tbaa !24
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s12
  %t222 = load i64, ptr %l21, !tbaa !24
  %t223 = load i64, ptr %l22, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  %t228 = xor i1 %t226, true
  br i1 %t228, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s12)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t230 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t230, ptr %l137, !tbaa !27
  %t231 = load i64, ptr %l21, !tbaa !24
  %t233 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = getelementptr ptr, ptr %t234, i64 %t231
  %t236 = load ptr, ptr %t235, !tbaa !39
  store ptr %t236, ptr %l23, !tbaa !29
  %t238 = load ptr, ptr %l3, !tbaa !29
  %t239 = load ptr, ptr %l23, !tbaa !29
  %t241 = getelementptr %"compiler/ast:CaseDecl", ptr %t239, i32 0, i32 1
  %t242 = load i32, ptr %t241, !tbaa !23
  %t245 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t238, i32 %t242)
  store { i64, ptr } %t245, ptr %l143
  br label %bb44
bb44:
  %t246 = load { i64, ptr }, ptr %l143, !tbaa !27
  store { i64, ptr } %t246, ptr %l24, !tbaa !27
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t249 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t250 = load i64, ptr @G_2ecompiler_2fsession_2eKindEnumMember, !tbaa !24
  %t251 = load ptr, ptr %l23, !tbaa !29
  %t253 = getelementptr %"compiler/ast:CaseDecl", ptr %t251, i32 0, i32 0
  %t254 = getelementptr %"compiler/source:Span", ptr %t253, i32 0, i32 0
  %t255 = load i32, ptr %t254, !tbaa !23
  %t257 = sext i32 %t255 to i64
  %t258 = load ptr, ptr %l23, !tbaa !29
  %t260 = getelementptr %"compiler/ast:CaseDecl", ptr %t258, i32 0, i32 0
  %t261 = getelementptr %"compiler/source:Span", ptr %t260, i32 0, i32 1
  %t262 = load i32, ptr %t261, !tbaa !23
  %t264 = sext i32 %t262 to i64
  %t265 = load ptr, ptr %l23, !tbaa !29
  %t267 = getelementptr %"compiler/ast:CaseDecl", ptr %t265, i32 0, i32 0
  %t268 = getelementptr %"compiler/source:Span", ptr %t267, i32 0, i32 0
  %t269 = load i32, ptr %t268, !tbaa !23
  %t271 = sext i32 %t269 to i64
  %t272 = load ptr, ptr %l23, !tbaa !29
  %t274 = getelementptr %"compiler/ast:CaseDecl", ptr %t272, i32 0, i32 0
  %t275 = getelementptr %"compiler/source:Span", ptr %t274, i32 0, i32 0
  %t276 = load i32, ptr %t275, !tbaa !23
  %t278 = sext i32 %t276 to i64
  %t279 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t284 = add i64 %t278, %t281
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s12, ptr %t247, ptr %t248, { i64, ptr } %t249, i64 %t250, i64 %t257, i64 %t264, i64 %t271, i64 %t284, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d124, i32 0, i32 1) })
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s12)
  br label %bb46
bb46:
  %t293 = load i64, ptr %l21, !tbaa !24
  %t296 = add i64 %t293, 1
  store i64 %t296, ptr %l21, !tbaa !24
  br label %bb40
bb47:
  br label %bb68
bb48:
  %t298 = load ptr, ptr %l2, !tbaa !29
  store ptr %t298, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t299 = load ptr, ptr %l166, !tbaa !29
  %t300 = icmp ne ptr %t299, null
  br i1 %t300, label %bb49, label %bb50
bb49:
  %t302 = load ptr, ptr %l166, !tbaa !29
  %t303 = load i64, ptr %t302, !range !{i64 0, i64 5}
  %t305 = icmp eq i64 %t303, 2
  store i1 %t305, ptr %l167, !tbaa !21
  br label %bb50
bb50:
  %t306 = load i1, ptr %l167, !tbaa !21
  br i1 %t306, label %bb51, label %bb52
bb51:
  %t307 = load ptr, ptr %l2, !tbaa !29
  %t309 = getelementptr { i64, [6 x i64] }, ptr %t307, i32 0, i32 1
  %t310 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr } }, ptr %t309, i32 0, i32 0
  %t311 = load { i64, ptr }, ptr %t310
  store { i64, ptr } %t311, ptr %l25, !tbaa !27
  br label %bb53
bb52:
  br label %bb63
bb53:
  %t313 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t313, ptr %l26, !tbaa !27
  store i64 0, ptr %l27, !tbaa !24
  %t315 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t317 = extractvalue { i64, ptr } %t315, 0
  store i64 %t317, ptr %l28, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s16
  %t319 = load i64, ptr %l27, !tbaa !24
  %t320 = load i64, ptr %l28, !tbaa !24
  %t323 = icmp slt i64 %t319, %t320
  %t325 = xor i1 %t323, true
  br i1 %t325, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s16)
  br label %bb62
bb56:
  br label %bb57
bb57:
  %t327 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t327, ptr %l179, !tbaa !27
  %t328 = load i64, ptr %l27, !tbaa !24
  %t330 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = getelementptr ptr, ptr %t331, i64 %t328
  %t333 = load ptr, ptr %t332, !tbaa !39
  store ptr %t333, ptr %l29, !tbaa !29
  %t335 = load ptr, ptr %l3, !tbaa !29
  %t336 = load ptr, ptr %l29, !tbaa !29
  %t338 = getelementptr %"compiler/ast:Func", ptr %t336, i32 0, i32 2
  %t339 = load i32, ptr %t338, !tbaa !23
  %t342 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v3, ptr %v3, ptr %t335, i32 %t339)
  store { i64, ptr } %t342, ptr %l185
  br label %bb58
bb58:
  %t343 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t343, ptr %l30, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t345 = load ptr, ptr %l29, !tbaa !29
  %t347 = getelementptr %"compiler/ast:Func", ptr %t345, i32 0, i32 0
  %t348 = getelementptr %"compiler/source:Span", ptr %t347, i32 0, i32 0
  %t349 = load i32, ptr %t348, !tbaa !23
  %t351 = sext i32 %t349 to i64
  %t352 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t356 = call i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v3, { i64, ptr } %t344, i64 %t351, { i64, ptr } %t352)
  store i64 %t356, ptr %l191
  br label %bb59
bb59:
  %t357 = load i64, ptr %l191, !tbaa !24
  store i64 %t357, ptr %l31, !tbaa !24
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t359 = load ptr, ptr %l1, !tbaa !29
  %t360 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t361 = load i64, ptr @G_2ecompiler_2fsession_2eKindMethod, !tbaa !24
  %t362 = load ptr, ptr %l29, !tbaa !29
  %t364 = getelementptr %"compiler/ast:Func", ptr %t362, i32 0, i32 0
  %t365 = getelementptr %"compiler/source:Span", ptr %t364, i32 0, i32 0
  %t366 = load i32, ptr %t365, !tbaa !23
  %t368 = sext i32 %t366 to i64
  %t369 = load ptr, ptr %l29, !tbaa !29
  %t371 = getelementptr %"compiler/ast:Func", ptr %t369, i32 0, i32 0
  %t372 = getelementptr %"compiler/source:Span", ptr %t371, i32 0, i32 1
  %t373 = load i32, ptr %t372, !tbaa !23
  %t375 = sext i32 %t373 to i64
  %t376 = load i64, ptr %l31, !tbaa !24
  %t377 = load i64, ptr %l31, !tbaa !24
  %t378 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t378, 0
  %t383 = add i64 %t377, %t380
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v3, ptr %s16, ptr %t358, ptr %t359, { i64, ptr } %t360, i64 %t361, i64 %t368, i64 %t375, i64 %t376, i64 %t383, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d125, i32 0, i32 1) })
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s16)
  br label %bb61
bb61:
  %t392 = load i64, ptr %l27, !tbaa !24
  %t395 = add i64 %t392, 1
  store i64 %t395, ptr %l27, !tbaa !24
  br label %bb54
bb62:
  br label %bb68
bb63:
  br i1 true, label %bb64, label %bb65
bb64:
  br label %bb66
bb65:
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_check_failed(ptr @olang_loc_59453385dbeab0f1_a10e94e6ba58edc5)
  unreachable
bb68:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l18 = alloca i1
  %l41 = alloca { i64, ptr }
  %l60 = alloca i1
  %l83 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"compiler/ast:TopIf", ptr %t5, i32 0, i32 1
  %t8 = load ptr, ptr %t7, !tbaa !29
  %t10 = icmp eq ptr %t8, null
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb4, label %bb5
bb4:
  %t14 = load ptr, ptr %l2, !tbaa !29
  %t16 = getelementptr %"compiler/ast:TopIf", ptr %t14, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = icmp eq ptr %t17, null
  br i1 %t19, label %bb6, label %bb7
bb5:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb9
bb6:
  call void @__olang_check_failed(ptr @olang_loc_d9881facfbc222b9_fdfa0d9fbca7f5d5)
  unreachable
bb7:
  br label %bb8
bb8:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t23 = getelementptr %"compiler/ast:TopIf", ptr %t21, i32 0, i32 1
  %t24 = load ptr, ptr %t23, !tbaa !29
  %t27 = getelementptr %"compiler/ast:TopBranch", ptr %t24, i32 0, i32 1
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 0
  %t32 = icmp sgt i64 %t30, 0
  store i1 %t32, ptr %l18, !tbaa !21
  br label %bb9
bb9:
  %t34 = load i1, ptr %l18, !tbaa !21
  br i1 %t34, label %bb10, label %bb11
bb10:
  %t35 = load ptr, ptr %l2, !tbaa !29
  %t37 = getelementptr %"compiler/ast:TopIf", ptr %t35, i32 0, i32 1
  %t38 = load ptr, ptr %t37, !tbaa !29
  %t40 = icmp eq ptr %t38, null
  br i1 %t40, label %bb12, label %bb13
bb11:
  br label %bb22
bb12:
  call void @__olang_check_failed(ptr @olang_loc_7c90741a89491e92_62c7d4207901162e)
  unreachable
bb13:
  br label %bb14
bb14:
  %t42 = load ptr, ptr %l2, !tbaa !29
  %t44 = getelementptr %"compiler/ast:TopIf", ptr %t42, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t48 = getelementptr %"compiler/ast:TopBranch", ptr %t45, i32 0, i32 1
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  store { i64, ptr } %t49, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 0
  store i64 %t53, ptr %l6, !tbaa !24
  br label %bb15
bb15:
  %t55 = load i64, ptr %l5, !tbaa !24
  %t56 = load i64, ptr %l6, !tbaa !24
  %t59 = icmp slt i64 %t55, %t56
  %t61 = xor i1 %t59, true
  br i1 %t61, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t63 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t63, ptr %l41, !tbaa !27
  %t64 = load i64, ptr %l5, !tbaa !24
  %t66 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr ptr, ptr %t67, i64 %t64
  %t69 = load ptr, ptr %t68, !tbaa !39
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t71, ptr %t72, ptr %t69, ptr %t74)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t79 = load i64, ptr %l5, !tbaa !24
  %t82 = add i64 %t79, 1
  store i64 %t82, ptr %l5, !tbaa !24
  br label %bb15
bb21:
  br label %bb22
bb22:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t86 = load ptr, ptr %l2, !tbaa !29
  %t88 = getelementptr %"compiler/ast:TopIf", ptr %t86, i32 0, i32 2
  %t89 = load ptr, ptr %t88, !tbaa !29
  %t90 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2etopIf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t84, ptr %t85, ptr %t89, ptr %t90)
  br label %bb23
bb23:
  %t95 = load ptr, ptr %l2, !tbaa !29
  %t97 = getelementptr %"compiler/ast:TopIf", ptr %t95, i32 0, i32 3
  %t98 = load ptr, ptr %t97, !tbaa !29
  %t100 = icmp eq ptr %t98, null
  %t102 = xor i1 %t100, true
  br i1 %t102, label %bb24, label %bb25
bb24:
  %t104 = load ptr, ptr %l2, !tbaa !29
  %t106 = getelementptr %"compiler/ast:TopIf", ptr %t104, i32 0, i32 3
  %t107 = load ptr, ptr %t106, !tbaa !29
  %t109 = icmp eq ptr %t107, null
  br i1 %t109, label %bb26, label %bb27
bb25:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb29
bb26:
  call void @__olang_check_failed(ptr @olang_loc_445788eb90ff4fd3_8bea5f8a87ea775f)
  unreachable
bb27:
  br label %bb28
bb28:
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t113 = getelementptr %"compiler/ast:TopIf", ptr %t111, i32 0, i32 3
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t117 = getelementptr %"compiler/ast:TopBranch", ptr %t114, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t122 = icmp sgt i64 %t120, 0
  store i1 %t122, ptr %l60, !tbaa !21
  br label %bb29
bb29:
  %t124 = load i1, ptr %l60, !tbaa !21
  br i1 %t124, label %bb30, label %bb31
bb30:
  %t125 = load ptr, ptr %l2, !tbaa !29
  %t127 = getelementptr %"compiler/ast:TopIf", ptr %t125, i32 0, i32 3
  %t128 = load ptr, ptr %t127, !tbaa !29
  %t130 = icmp eq ptr %t128, null
  br i1 %t130, label %bb32, label %bb33
bb31:
  br label %bb42
bb32:
  call void @__olang_check_failed(ptr @olang_loc_5bdbf2396576e204_9bcdfaa72cbb5bc0)
  unreachable
bb33:
  br label %bb34
bb34:
  %t132 = load ptr, ptr %l2, !tbaa !29
  %t134 = getelementptr %"compiler/ast:TopIf", ptr %t132, i32 0, i32 3
  %t135 = load ptr, ptr %t134, !tbaa !29
  %t138 = getelementptr %"compiler/ast:TopBranch", ptr %t135, i32 0, i32 1
  %t139 = load { i64, ptr }, ptr %t138, !tbaa !27
  store { i64, ptr } %t139, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t141 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l10, !tbaa !24
  br label %bb35
bb35:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l10, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb36, label %bb37
bb36:
  br label %bb41
bb37:
  br label %bb38
bb38:
  %t153 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t153, ptr %l83, !tbaa !27
  %t154 = load i64, ptr %l9, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr ptr, ptr %t157, i64 %t154
  %t159 = load ptr, ptr %t158, !tbaa !39
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2edecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t161, ptr %t162, ptr %t159, ptr %t164)
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t169 = load i64, ptr %l9, !tbaa !24
  %t172 = add i64 %t169, 1
  store i64 %t172, ptr %l9, !tbaa !24
  br label %bb35
bb41:
  br label %bb42
bb42:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca ptr
  %l35 = alloca ptr
  %l37 = alloca %"compiler/source:Span"
  %l39 = alloca i32
  %l40 = alloca ptr
  %l41 = alloca i1
  %l46 = alloca ptr
  %l47 = alloca i1
  %l52 = alloca ptr
  %l53 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l71 = alloca ptr
  %l72 = alloca i1
  %l85 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca i1
  %l108 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca i1
  %l130 = alloca { i64, ptr }
  %l139 = alloca ptr
  %l140 = alloca i1
  %l149 = alloca ptr
  %l150 = alloca i1
  %l166 = alloca ptr
  %l167 = alloca i1
  %l180 = alloca { i64, ptr }
  %l192 = alloca ptr
  %l193 = alloca i1
  %l201 = alloca ptr
  %l202 = alloca i1
  %l215 = alloca { i64, ptr }
  %l218 = alloca ptr
  %l219 = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = icmp eq ptr %t1, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l35, !tbaa !29
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v1, ptr %t6)
  store %"compiler/source:Span" %t8, ptr %l37
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = call i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v1, ptr %t9)
  store i32 %t11, ptr %l39
  br label %bb5
bb5:
  %t12 = load ptr, ptr %l35, !tbaa !29
  %t13 = load %"compiler/source:Span", ptr %l37
  %t14 = load i32, ptr %l39, !tbaa !23
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %t12, %"compiler/source:Span" %t13, i32 %t14)
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l1, !tbaa !29
  store ptr %t15, ptr %l40, !tbaa !29
  store i1 false, ptr %l41, !tbaa !21
  %t16 = load ptr, ptr %l40, !tbaa !29
  %t17 = icmp ne ptr %t16, null
  br i1 %t17, label %bb7, label %bb8
bb7:
  %t19 = load ptr, ptr %l40, !tbaa !29
  %t20 = load i64, ptr %t19, !range !{i64 0, i64 18}
  %t22 = icmp eq i64 %t20, 2
  store i1 %t22, ptr %l41, !tbaa !21
  br label %bb8
bb8:
  %t23 = load i1, ptr %l41, !tbaa !21
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t24 = load ptr, ptr %l1, !tbaa !29
  %t26 = getelementptr { i64, [5 x i64] }, ptr %t24, i32 0, i32 1
  %t27 = getelementptr { %"compiler/source:Span", i32, ptr, i32 }, ptr %t26, i32 0, i32 2
  %t28 = load ptr, ptr %t27
  store ptr %t28, ptr %l2, !tbaa !29
  br label %bb19
bb10:
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l46, !tbaa !29
  store i1 false, ptr %l47, !tbaa !21
  %t31 = load ptr, ptr %l46, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb11, label %bb12
bb11:
  %t34 = load ptr, ptr %l46, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 18}
  %t37 = icmp eq i64 %t35, 3
  store i1 %t37, ptr %l47, !tbaa !21
  br label %bb12
bb12:
  %t38 = load i1, ptr %l47, !tbaa !21
  br i1 %t38, label %bb13, label %bb14
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr { i64, [5 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t41, i32 0, i32 2
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l2, !tbaa !29
  br label %bb19
bb14:
  %t45 = load ptr, ptr %l1, !tbaa !29
  store ptr %t45, ptr %l52, !tbaa !29
  store i1 false, ptr %l53, !tbaa !21
  %t46 = load ptr, ptr %l52, !tbaa !29
  %t47 = icmp ne ptr %t46, null
  br i1 %t47, label %bb15, label %bb16
bb15:
  %t49 = load ptr, ptr %l52, !tbaa !29
  %t50 = load i64, ptr %t49, !range !{i64 0, i64 18}
  %t52 = icmp eq i64 %t50, 4
  store i1 %t52, ptr %l53, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l53, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr { i64, [5 x i64] }, ptr %t54, i32 0, i32 1
  %t57 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t56, i32 0, i32 2
  %t58 = load ptr, ptr %t57
  store ptr %t58, ptr %l2, !tbaa !29
  br label %bb19
bb18:
  br label %bb21
bb19:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t61 = load ptr, ptr %l2, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t60, ptr %t61)
  br label %bb20
bb20:
  br label %bb127
bb21:
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l61, !tbaa !29
  store i1 false, ptr %l62, !tbaa !21
  %t66 = load ptr, ptr %l61, !tbaa !29
  %t67 = icmp ne ptr %t66, null
  br i1 %t67, label %bb22, label %bb23
bb22:
  %t69 = load ptr, ptr %l61, !tbaa !29
  %t70 = load i64, ptr %t69, !range !{i64 0, i64 18}
  %t72 = icmp eq i64 %t70, 5
  store i1 %t72, ptr %l62, !tbaa !21
  br label %bb23
bb23:
  %t73 = load i1, ptr %l62, !tbaa !21
  br i1 %t73, label %bb24, label %bb25
bb24:
  %t74 = load ptr, ptr %l1, !tbaa !29
  %t76 = getelementptr { i64, [5 x i64] }, ptr %t74, i32 0, i32 1
  %t77 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t76, i32 0, i32 2
  %t78 = load ptr, ptr %t77
  store ptr %t78, ptr %l3, !tbaa !29
  br label %bb26
bb25:
  br label %bb28
bb26:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t83 = getelementptr %"compiler/typed:Promote", ptr %t81, i32 0, i32 0
  %t84 = load ptr, ptr %t83, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t80, ptr %t84)
  br label %bb27
bb27:
  br label %bb127
bb28:
  %t88 = load ptr, ptr %l1, !tbaa !29
  store ptr %t88, ptr %l71, !tbaa !29
  store i1 false, ptr %l72, !tbaa !21
  %t89 = load ptr, ptr %l71, !tbaa !29
  %t90 = icmp ne ptr %t89, null
  br i1 %t90, label %bb29, label %bb30
bb29:
  %t92 = load ptr, ptr %l71, !tbaa !29
  %t93 = load i64, ptr %t92, !range !{i64 0, i64 18}
  %t95 = icmp eq i64 %t93, 6
  store i1 %t95, ptr %l72, !tbaa !21
  br label %bb30
bb30:
  %t96 = load i1, ptr %l72, !tbaa !21
  br i1 %t96, label %bb31, label %bb32
bb31:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr { i64, [5 x i64] }, ptr %t97, i32 0, i32 1
  %t100 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t99, i32 0, i32 2
  %t101 = load ptr, ptr %t100
  store ptr %t101, ptr %l4, !tbaa !29
  br label %bb33
bb32:
  br label %bb41
bb33:
  %t103 = load ptr, ptr %l4, !tbaa !29
  %t105 = getelementptr %"compiler/typed:Call", ptr %t103, i32 0, i32 1
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  store { i64, ptr } %t106, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t108 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t108, 0
  store i64 %t110, ptr %l7, !tbaa !24
  br label %bb34
bb34:
  %t112 = load i64, ptr %l6, !tbaa !24
  %t113 = load i64, ptr %l7, !tbaa !24
  %t116 = icmp slt i64 %t112, %t113
  %t118 = xor i1 %t116, true
  br i1 %t118, label %bb35, label %bb36
bb35:
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t120 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t120, ptr %l85, !tbaa !27
  %t121 = load i64, ptr %l6, !tbaa !24
  %t123 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t124 = load ptr, ptr %t123, !tbaa !27
  %t125 = getelementptr ptr, ptr %t124, i64 %t121
  %t126 = load ptr, ptr %t125, !tbaa !39
  %t128 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t128, ptr %t126)
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t133 = load i64, ptr %l6, !tbaa !24
  %t136 = add i64 %t133, 1
  store i64 %t136, ptr %l6, !tbaa !24
  br label %bb34
bb40:
  br label %bb127
bb41:
  %t138 = load ptr, ptr %l1, !tbaa !29
  store ptr %t138, ptr %l94, !tbaa !29
  store i1 false, ptr %l95, !tbaa !21
  %t139 = load ptr, ptr %l94, !tbaa !29
  %t140 = icmp ne ptr %t139, null
  br i1 %t140, label %bb42, label %bb43
bb42:
  %t142 = load ptr, ptr %l94, !tbaa !29
  %t143 = load i64, ptr %t142, !range !{i64 0, i64 18}
  %t145 = icmp eq i64 %t143, 7
  store i1 %t145, ptr %l95, !tbaa !21
  br label %bb43
bb43:
  %t146 = load i1, ptr %l95, !tbaa !21
  br i1 %t146, label %bb44, label %bb45
bb44:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr { i64, [5 x i64] }, ptr %t147, i32 0, i32 1
  %t150 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t149, i32 0, i32 2
  %t151 = load ptr, ptr %t150
  store ptr %t151, ptr %l9, !tbaa !29
  br label %bb46
bb45:
  br label %bb54
bb46:
  %t153 = load ptr, ptr %l9, !tbaa !29
  %t155 = getelementptr %"compiler/typed:Make", ptr %t153, i32 0, i32 2
  %t156 = load { i64, ptr }, ptr %t155, !tbaa !27
  store { i64, ptr } %t156, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  store i64 %t160, ptr %l12, !tbaa !24
  br label %bb47
bb47:
  %t162 = load i64, ptr %l11, !tbaa !24
  %t163 = load i64, ptr %l12, !tbaa !24
  %t166 = icmp slt i64 %t162, %t163
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb48, label %bb49
bb48:
  br label %bb53
bb49:
  br label %bb50
bb50:
  %t170 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t170, ptr %l108, !tbaa !27
  %t171 = load i64, ptr %l11, !tbaa !24
  %t173 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = getelementptr ptr, ptr %t174, i64 %t171
  %t176 = load ptr, ptr %t175, !tbaa !39
  %t178 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t178, ptr %t176)
  br label %bb51
bb51:
  br label %bb52
bb52:
  %t183 = load i64, ptr %l11, !tbaa !24
  %t186 = add i64 %t183, 1
  store i64 %t186, ptr %l11, !tbaa !24
  br label %bb47
bb53:
  br label %bb127
bb54:
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l117, !tbaa !29
  store i1 false, ptr %l118, !tbaa !21
  %t189 = load ptr, ptr %l117, !tbaa !29
  %t190 = icmp ne ptr %t189, null
  br i1 %t190, label %bb55, label %bb56
bb55:
  %t192 = load ptr, ptr %l117, !tbaa !29
  %t193 = load i64, ptr %t192, !range !{i64 0, i64 18}
  %t195 = icmp eq i64 %t193, 9
  store i1 %t195, ptr %l118, !tbaa !21
  br label %bb56
bb56:
  %t196 = load i1, ptr %l118, !tbaa !21
  br i1 %t196, label %bb57, label %bb58
bb57:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t199 = getelementptr { i64, [5 x i64] }, ptr %t197, i32 0, i32 1
  %t200 = getelementptr { %"compiler/source:Span", i32, i32, i32, { i64, ptr } }, ptr %t199, i32 0, i32 4
  %t201 = load { i64, ptr }, ptr %t200
  store { i64, ptr } %t201, ptr %l14, !tbaa !27
  br label %bb59
bb58:
  br label %bb67
bb59:
  %t203 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t203, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t205 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t205, 0
  store i64 %t207, ptr %l17, !tbaa !24
  br label %bb60
bb60:
  %t209 = load i64, ptr %l16, !tbaa !24
  %t210 = load i64, ptr %l17, !tbaa !24
  %t213 = icmp slt i64 %t209, %t210
  %t215 = xor i1 %t213, true
  br i1 %t215, label %bb61, label %bb62
bb61:
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t217 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t217, ptr %l130, !tbaa !27
  %t218 = load i64, ptr %l16, !tbaa !24
  %t220 = getelementptr { i64, ptr }, ptr %l130, i32 0, i32 1
  %t221 = load ptr, ptr %t220, !tbaa !27
  %t222 = getelementptr ptr, ptr %t221, i64 %t218
  %t223 = load ptr, ptr %t222, !tbaa !39
  %t225 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t225, ptr %t223)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t230 = load i64, ptr %l16, !tbaa !24
  %t233 = add i64 %t230, 1
  store i64 %t233, ptr %l16, !tbaa !24
  br label %bb60
bb66:
  br label %bb127
bb67:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l139, !tbaa !29
  store i1 false, ptr %l140, !tbaa !21
  %t236 = load ptr, ptr %l139, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb68, label %bb69
bb68:
  %t239 = load ptr, ptr %l139, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 18}
  %t242 = icmp eq i64 %t240, 10
  store i1 %t242, ptr %l140, !tbaa !21
  br label %bb69
bb69:
  %t243 = load i1, ptr %l140, !tbaa !21
  br i1 %t243, label %bb70, label %bb71
bb70:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr { i64, [5 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t246, i32 0, i32 2
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l19, !tbaa !29
  br label %bb72
bb71:
  br label %bb74
bb72:
  %t250 = load ptr, ptr %l0, !tbaa !29
  %t251 = load ptr, ptr %l19, !tbaa !29
  %t253 = getelementptr %"compiler/typed:Slice", ptr %t251, i32 0, i32 0
  %t254 = load ptr, ptr %t253, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %t250, ptr %t254)
  br label %bb73
bb73:
  br label %bb127
bb74:
  %t258 = load ptr, ptr %l1, !tbaa !29
  store ptr %t258, ptr %l149, !tbaa !29
  store i1 false, ptr %l150, !tbaa !21
  %t259 = load ptr, ptr %l149, !tbaa !29
  %t260 = icmp ne ptr %t259, null
  br i1 %t260, label %bb75, label %bb76
bb75:
  %t262 = load ptr, ptr %l149, !tbaa !29
  %t263 = load i64, ptr %t262, !range !{i64 0, i64 18}
  %t265 = icmp eq i64 %t263, 11
  store i1 %t265, ptr %l150, !tbaa !21
  br label %bb76
bb76:
  %t266 = load i1, ptr %l150, !tbaa !21
  br i1 %t266, label %bb77, label %bb78
bb77:
  %t267 = load ptr, ptr %l1, !tbaa !29
  %t269 = getelementptr { i64, [5 x i64] }, ptr %t267, i32 0, i32 1
  %t270 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t269, i32 0, i32 2
  %t271 = load ptr, ptr %t270
  store ptr %t271, ptr %l20, !tbaa !29
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t274 = load ptr, ptr %l20, !tbaa !29
  %t276 = getelementptr %"compiler/typed:Cond", ptr %t274, i32 0, i32 0
  %t277 = load ptr, ptr %t276, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t273, ptr %t277)
  br label %bb80
bb80:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load ptr, ptr %l20, !tbaa !29
  %t284 = getelementptr %"compiler/typed:Cond", ptr %t282, i32 0, i32 1
  %t285 = load ptr, ptr %t284, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t281, ptr %t285)
  br label %bb81
bb81:
  %t288 = load ptr, ptr %l0, !tbaa !29
  %t289 = load ptr, ptr %l20, !tbaa !29
  %t291 = getelementptr %"compiler/typed:Cond", ptr %t289, i32 0, i32 2
  %t292 = load ptr, ptr %t291, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t288, ptr %t292)
  br label %bb82
bb82:
  br label %bb127
bb83:
  %t296 = load ptr, ptr %l1, !tbaa !29
  store ptr %t296, ptr %l166, !tbaa !29
  store i1 false, ptr %l167, !tbaa !21
  %t297 = load ptr, ptr %l166, !tbaa !29
  %t298 = icmp ne ptr %t297, null
  br i1 %t298, label %bb84, label %bb85
bb84:
  %t300 = load ptr, ptr %l166, !tbaa !29
  %t301 = load i64, ptr %t300, !range !{i64 0, i64 18}
  %t303 = icmp eq i64 %t301, 12
  store i1 %t303, ptr %l167, !tbaa !21
  br label %bb85
bb85:
  %t304 = load i1, ptr %l167, !tbaa !21
  br i1 %t304, label %bb86, label %bb87
bb86:
  %t305 = load ptr, ptr %l1, !tbaa !29
  %t307 = getelementptr { i64, [5 x i64] }, ptr %t305, i32 0, i32 1
  %t308 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t307, i32 0, i32 2
  %t309 = load ptr, ptr %t308
  store ptr %t309, ptr %l21, !tbaa !29
  br label %bb88
bb87:
  br label %bb97
bb88:
  %t311 = load ptr, ptr %l21, !tbaa !29
  %t313 = getelementptr %"compiler/typed:Seq", ptr %t311, i32 0, i32 0
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  store { i64, ptr } %t314, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t316 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t318 = extractvalue { i64, ptr } %t316, 0
  store i64 %t318, ptr %l24, !tbaa !24
  br label %bb89
bb89:
  %t320 = load i64, ptr %l23, !tbaa !24
  %t321 = load i64, ptr %l24, !tbaa !24
  %t324 = icmp slt i64 %t320, %t321
  %t326 = xor i1 %t324, true
  br i1 %t326, label %bb90, label %bb91
bb90:
  br label %bb95
bb91:
  br label %bb92
bb92:
  %t328 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t328, ptr %l180, !tbaa !27
  %t329 = load i64, ptr %l23, !tbaa !24
  %t331 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t332 = load ptr, ptr %t331, !tbaa !27
  %t333 = getelementptr ptr, ptr %t332, i64 %t329
  %t334 = load ptr, ptr %t333, !tbaa !39
  %t336 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %t336, ptr %t334)
  br label %bb93
bb93:
  br label %bb94
bb94:
  %t341 = load i64, ptr %l23, !tbaa !24
  %t344 = add i64 %t341, 1
  store i64 %t344, ptr %l23, !tbaa !24
  br label %bb89
bb95:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load ptr, ptr %l21, !tbaa !29
  %t349 = getelementptr %"compiler/typed:Seq", ptr %t347, i32 0, i32 1
  %t350 = load ptr, ptr %t349, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t346, ptr %t350)
  br label %bb96
bb96:
  br label %bb127
bb97:
  %t353 = load ptr, ptr %l1, !tbaa !29
  store ptr %t353, ptr %l192, !tbaa !29
  store i1 false, ptr %l193, !tbaa !21
  %t354 = load ptr, ptr %l192, !tbaa !29
  %t355 = icmp ne ptr %t354, null
  br i1 %t355, label %bb98, label %bb99
bb98:
  %t357 = load ptr, ptr %l192, !tbaa !29
  %t358 = load i64, ptr %t357, !range !{i64 0, i64 18}
  %t360 = icmp eq i64 %t358, 14
  store i1 %t360, ptr %l193, !tbaa !21
  br label %bb99
bb99:
  %t361 = load i1, ptr %l193, !tbaa !21
  br i1 %t361, label %bb100, label %bb101
bb100:
  %t362 = load ptr, ptr %l1, !tbaa !29
  %t364 = getelementptr { i64, [5 x i64] }, ptr %t362, i32 0, i32 1
  %t365 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t364, i32 0, i32 2
  %t366 = load ptr, ptr %t365
  store ptr %t366, ptr %l26, !tbaa !29
  br label %bb102
bb101:
  br label %bb104
bb102:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t369 = load ptr, ptr %l26, !tbaa !29
  %t371 = getelementptr %"compiler/typed:Try", ptr %t369, i32 0, i32 0
  %t372 = load ptr, ptr %t371, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t368, ptr %t372)
  br label %bb103
bb103:
  br label %bb127
bb104:
  %t375 = load ptr, ptr %l1, !tbaa !29
  store ptr %t375, ptr %l201, !tbaa !29
  store i1 false, ptr %l202, !tbaa !21
  %t376 = load ptr, ptr %l201, !tbaa !29
  %t377 = icmp ne ptr %t376, null
  br i1 %t377, label %bb105, label %bb106
bb105:
  %t379 = load ptr, ptr %l201, !tbaa !29
  %t380 = load i64, ptr %t379, !range !{i64 0, i64 18}
  %t382 = icmp eq i64 %t380, 16
  store i1 %t382, ptr %l202, !tbaa !21
  br label %bb106
bb106:
  %t383 = load i1, ptr %l202, !tbaa !21
  br i1 %t383, label %bb107, label %bb108
bb107:
  %t384 = load ptr, ptr %l1, !tbaa !29
  %t386 = getelementptr { i64, [5 x i64] }, ptr %t384, i32 0, i32 1
  %t387 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t386, i32 0, i32 2
  %t388 = load ptr, ptr %t387
  store ptr %t388, ptr %l27, !tbaa !29
  br label %bb109
bb108:
  br label %bb122
bb109:
  %t390 = load ptr, ptr %l27, !tbaa !29
  %t392 = getelementptr %"compiler/typed:Text", ptr %t390, i32 0, i32 0
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !27
  store { i64, ptr } %t393, ptr %l28, !tbaa !27
  store i64 0, ptr %l29, !tbaa !24
  %t395 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t395, 0
  store i64 %t397, ptr %l30, !tbaa !24
  br label %bb110
bb110:
  %t399 = load i64, ptr %l29, !tbaa !24
  %t400 = load i64, ptr %l30, !tbaa !24
  %t403 = icmp slt i64 %t399, %t400
  %t405 = xor i1 %t403, true
  br i1 %t405, label %bb111, label %bb112
bb111:
  br label %bb121
bb112:
  br label %bb113
bb113:
  %t407 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t407, ptr %l215, !tbaa !27
  %t408 = load i64, ptr %l29, !tbaa !24
  %t410 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t411 = load ptr, ptr %t410, !tbaa !27
  %t412 = getelementptr ptr, ptr %t411, i64 %t408
  %t413 = load ptr, ptr %t412, !tbaa !39
  store ptr %t413, ptr %l31, !tbaa !29
  %t415 = load ptr, ptr %l31, !tbaa !29
  store ptr %t415, ptr %l218, !tbaa !29
  store i1 false, ptr %l219, !tbaa !21
  %t416 = load ptr, ptr %l218, !tbaa !29
  %t417 = icmp ne ptr %t416, null
  br i1 %t417, label %bb114, label %bb115
bb114:
  %t419 = load ptr, ptr %l218, !tbaa !29
  %t420 = load i64, ptr %t419, !range !{i64 0, i64 2}
  %t422 = icmp eq i64 %t420, 1
  store i1 %t422, ptr %l219, !tbaa !21
  br label %bb115
bb115:
  %t423 = load i1, ptr %l219, !tbaa !21
  br i1 %t423, label %bb116, label %bb117
bb116:
  %t424 = load ptr, ptr %l31, !tbaa !29
  %t426 = getelementptr { i64, [2 x i64] }, ptr %t424, i32 0, i32 1
  %t427 = getelementptr { ptr }, ptr %t426, i32 0, i32 0
  %t428 = load ptr, ptr %t427
  %t430 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eexpr(ptr %v0, ptr %v1, ptr %t430, ptr %t428)
  br label %bb118
bb117:
  br label %bb119
bb118:
  br label %bb119
bb119:
  br label %bb120
bb120:
  %t435 = load i64, ptr %l29, !tbaa !24
  %t438 = add i64 %t435, 1
  store i64 %t438, ptr %l29, !tbaa !24
  br label %bb110
bb121:
  br label %bb127
bb122:
  br i1 true, label %bb123, label %bb124
bb123:
  br label %bb125
bb124:
  br label %bb126
bb125:
  br label %bb127
bb126:
  call void @__olang_check_failed(ptr @olang_loc_df797fad9b49105d_2a8f7c5ad36c2889)
  unreachable
bb127:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fsession_2edocPage(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca %"compiler/doc:Module"
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l16 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l18 = alloca ptr
  %l20 = alloca i64
  %l22 = alloca i1
  %l26 = alloca i1
  %l31 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l43 = alloca ptr
  %l52 = alloca %"compiler/doc:Module"
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l57 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i32
  %l70 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l8
  br label %bb1
bb1:
  %t3 = load i1, ptr %l8, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l9, ptr %t2, i64 704, i1 false)
  br label %bb2
bb2:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 704, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t4, ptr %l9, i64 704, i1 false)
  store ptr %t4, ptr %l3, !tbaa !29
  store { i64, ptr } %a0, ptr %l11, !tbaa !27
  store ptr %a1, ptr %l12, !tbaa !29
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l13, !tbaa !29
  %t9 = call ptr @__olang_scope_hold(ptr %s0)
  %t10 = ptrtoint ptr %t9 to i64
  store i64 %t10, ptr %l14, !tbaa !24
  %t11 = load i1, ptr @olang_2esole_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2c_20std_Hae258982e94f82c7c4916579e261fcef
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = call ptr @__olang_region_make(ptr %s0)
  %t14 = ptrtoint ptr %t13 to i64
  store i64 %t14, ptr %l14, !tbaa !24
  br label %bb4
bb4:
  %t15 = load i64, ptr %l14
  %t16 = inttoptr i64 %t15 to ptr
  %t17 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t16)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t17, ptr %l16
  br label %bb5
bb5:
  %t18 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l16
  %t19 = load i64, ptr %l14
  %t20 = inttoptr i64 %t19 to ptr
  %t21 = call ptr @__olang_scope_alloc_a(ptr %t20, i64 72, i64 8)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t18, ptr %t21
  %t22 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t23 = load ptr, ptr %l12, !tbaa !29
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t26 = call ptr @compiler_2fsession_2eAnalysis_2eAnalyze(ptr %v0, ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t22, ptr %t23, ptr %t24, ptr %t21, i1 true, i1 false)
  store ptr %t26, ptr %l18
  br label %bb6
bb6:
  %t27 = load ptr, ptr %l18, !tbaa !29
  store ptr %t27, ptr %l4, !tbaa !29
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %s0, ptr %t28)
  store i64 %t30, ptr %l20
  br label %bb7
bb7:
  %t31 = load i64, ptr %l20, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb10
bb9:
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = getelementptr %"compiler/session:Analysis", ptr %t34, i32 0, i32 2
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = icmp eq ptr %t37, null
  store i1 %t39, ptr %l22, !tbaa !21
  br label %bb10
bb10:
  %t41 = load i1, ptr %l22, !tbaa !21
  br i1 %t41, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb13
bb12:
  %t42 = load ptr, ptr %l4, !tbaa !29
  %t44 = getelementptr %"compiler/session:Analysis", ptr %t42, i32 0, i32 3
  %t45 = load ptr, ptr %t44, !tbaa !29
  %t47 = icmp eq ptr %t45, null
  store i1 %t47, ptr %l26, !tbaa !21
  br label %bb13
bb13:
  %t49 = load i1, ptr %l26, !tbaa !21
  br i1 %t49, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s1
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %s0, ptr %s1, ptr %t50)
  store { i64, ptr } %t52, ptr %l31
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t53 = load { i64, ptr }, ptr %l31, !tbaa !27
  call void @compiler_2fsession_2esay(ptr %s1, { i64, ptr } %t53)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb18:
  %t56 = load ptr, ptr %l4, !tbaa !29
  %t58 = getelementptr %"compiler/session:Analysis", ptr %t56, i32 0, i32 2
  %t59 = load ptr, ptr %t58, !tbaa !29
  %t61 = icmp eq ptr %t59, null
  br i1 %t61, label %bb19, label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb20:
  br label %bb21
bb21:
  %t63 = load ptr, ptr %l4, !tbaa !29
  %t65 = getelementptr %"compiler/session:Analysis", ptr %t63, i32 0, i32 2
  %t66 = load ptr, ptr %t65, !tbaa !29
  store ptr %t66, ptr %l38, !tbaa !29
  %t67 = load ptr, ptr %l4, !tbaa !29
  %t69 = getelementptr %"compiler/session:Analysis", ptr %t67, i32 0, i32 3
  %t70 = load ptr, ptr %t69, !tbaa !29
  %t72 = icmp eq ptr %t70, null
  br i1 %t72, label %bb22, label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb23:
  br label %bb24
bb24:
  %t74 = load ptr, ptr %l4, !tbaa !29
  %t76 = getelementptr %"compiler/session:Analysis", ptr %t74, i32 0, i32 3
  %t77 = load ptr, ptr %t76, !tbaa !29
  store ptr %t77, ptr %l43, !tbaa !29
  %t78 = load ptr, ptr %l4, !tbaa !29
  %t80 = getelementptr %"compiler/session:Analysis", ptr %t78, i32 0, i32 4
  %t81 = load ptr, ptr %t80, !tbaa !29
  %t83 = icmp eq ptr %t81, null
  br i1 %t83, label %bb25, label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_e6936df67b662b33_7a0885fa2c8953cf)
  unreachable
bb26:
  br label %bb27
bb27:
  %t85 = load ptr, ptr %l4, !tbaa !29
  %t87 = getelementptr %"compiler/session:Analysis", ptr %t85, i32 0, i32 4
  %t88 = load ptr, ptr %t87, !tbaa !29
  %t89 = load ptr, ptr %l4, !tbaa !29
  %t91 = getelementptr %"compiler/session:Analysis", ptr %t89, i32 0, i32 0
  %t92 = load ptr, ptr %t91, !tbaa !29
  %t94 = getelementptr %"compiler/load:Loader", ptr %t92, i32 0, i32 12
  %t95 = load i64, ptr %t94, !tbaa !24
  %t96 = load ptr, ptr %l38, !tbaa !29
  %t97 = load ptr, ptr %l43, !tbaa !29
  %t100 = call %"compiler/doc:Module" @compiler_2fdoc_2eModule_2eOf(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t96, ptr %t97, ptr %t88, i64 %t95, i1 false)
  store %"compiler/doc:Module" %t100, ptr %l52
  br label %bb28
bb28:
  %t101 = load %"compiler/doc:Module", ptr %l52
  store %"compiler/doc:Module" %t101, ptr %l5
  store { i64, ptr } %a2, ptr %l53, !tbaa !27
  %t103 = call ptr @__olang_scope_hold(ptr %s0)
  %t104 = ptrtoint ptr %t103 to i64
  store i64 %t104, ptr %l54, !tbaa !24
  %t105 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1
  br i1 %t105, label %bb29, label %bb30
bb29:
  %t107 = call ptr @__olang_region_make(ptr %s0)
  %t108 = ptrtoint ptr %t107 to i64
  store i64 %t108, ptr %l54, !tbaa !24
  br label %bb30
bb30:
  %t109 = getelementptr %"compiler/doc:Module", ptr %l5, i32 0, i32 0
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = load i64, ptr %l54
  %t112 = inttoptr i64 %t111 to ptr
  %t114 = call { i64, ptr } @compiler_2fdoc_2ePageName(ptr %s0, ptr %t112, { i64, ptr } %t110)
  store { i64, ptr } %t114, ptr %l57
  br label %bb31
bb31:
  %t115 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t117 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t116, 0
  %t119 = insertvalue [2 x { i64, ptr }] %t117, { i64, ptr } %t115, 1
  store [2 x { i64, ptr }] %t119, ptr %l6
  %t122 = insertvalue { i64, ptr } undef, i64 2, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %l6, 1
  %t125 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t123)
  store { i64, ptr } %t125, ptr %l62
  br label %bb32
bb32:
  %t126 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t126, ptr %l7, !tbaa !27
  %t127 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t127, ptr %l63, !tbaa !27
  %t129 = call { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t129, ptr %l65
  br label %bb33
bb33:
  %t130 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } %t130, 1
  %t134 = mul i64 %t132, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t133, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  %t138 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t140 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t138, { i64, ptr } %t137)
  store i32 %t140, ptr %l68
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb35, label %ok.142, !prof !99
ok.142:
  br label %bb34
bb34:
  br label %bb40
bb35:
  %t143 = load i32, ptr %l68, !tbaa !23
  %t144 = ashr i32 %t143, 16
  %t146 = icmp eq i32 %t144, 1
  store i1 %t146, ptr %l70, !tbaa !21
  %t147 = load i32, ptr %l68, !tbaa !23
  %t148 = ashr i32 %t147, 16
  %t150 = icmp eq i32 %t148, 1
  br i1 %t150, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s2
  %t152 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t153 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t156 = extractvalue { i64, ptr } %t152, 1
  %t157 = extractvalue { i64, ptr } %t152, 0
  %t158 = add i64 %t154, %t157
  %t159 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t160 = extractvalue { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t161 = add i64 %t158, %t160
  %t162 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t161)
  call void @olang_textcopy(ptr %t162, ptr %t153, i64 %t154)
  %t163 = getelementptr i8, ptr %t162, i64 %t154
  call void @olang_textcopy(ptr %t163, ptr %t156, i64 %t157)
  %t164 = getelementptr i8, ptr %t163, i64 %t157
  call void @olang_textcopy(ptr %t164, ptr %t159, i64 %t160)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t162, 1
  call void @compiler_2fsession_2esay(ptr %s2, { i64, ptr } %t166)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb40:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2eexampleText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/text:StringBuilder"
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca %"std/prelude/text:StringBuilder"
  %l17 = alloca ptr
  %l19 = alloca %"compiler/doc:Example"
  %l20 = alloca { i64, ptr }
  %l22 = alloca %"compiler/doc:Example"
  %l27 = alloca i64
  %l29 = alloca ptr
  %l31 = alloca i64
  %l32 = alloca i64
  %l34 = alloca i64
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %s0, ptr %a0, i64 %a1, { i64, ptr } %a2)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l8
  br label %bb1
bb1:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t10, ptr %l10
  br label %bb2
bb2:
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = icmp eq i64 %t11, 0
  br i1 %t12, label %bb3, label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %l13, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l14, !tbaa !24
  %t17 = load i64, ptr %l14, !tbaa !24
  %t18 = mul i64 %t17, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t18)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l15, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = load i64, ptr %l14, !tbaa !24
  %t27 = mul i64 %t26, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t23, ptr %t25, i64 %t27, i1 false)
  %t28 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t28, ptr %l13, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t30 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t30, ptr %l16
  br label %bb6
bb6:
  %t31 = load %"std/prelude/text:StringBuilder", ptr %l16
  store %"std/prelude/text:StringBuilder" %t31, ptr %l4
  store ptr %l4, ptr %l17, !tbaa !29
  %t33 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store %"compiler/doc:Example" %t33, ptr %l19
  br label %bb7
bb7:
  %t34 = getelementptr %"compiler/doc:Example", ptr %l19, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l20, !tbaa !27
  %t37 = call %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %s0, ptr %l3, i64 0)
  store %"compiler/doc:Example" %t37, ptr %l22
  br label %bb8
bb8:
  %t38 = getelementptr %"compiler/doc:Example", ptr %l22, i32 0, i32 1
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t40 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t42 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t50 = extractvalue { i64, ptr } %t39, 1
  %t51 = extractvalue { i64, ptr } %t39, 0
  %t52 = add i64 %t48, %t51
  %t53 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t54 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t55 = add i64 %t52, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  call void @olang_textcopy(ptr %t57, ptr %t43, i64 %t44)
  %t58 = getelementptr i8, ptr %t57, i64 %t44
  call void @olang_textcopy(ptr %t58, ptr %t46, i64 %t47)
  %t59 = getelementptr i8, ptr %t58, i64 %t47
  call void @olang_textcopy(ptr %t59, ptr %t50, i64 %t51)
  %t60 = getelementptr i8, ptr %t59, i64 %t51
  call void @olang_textcopy(ptr %t60, ptr %t53, i64 %t54)
  %t61 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t56, 1
  %t64 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t64, { i64, ptr } %t62)
  br label %bb9
bb9:
  %t67 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t67, ptr %l27
  br label %bb10
bb10:
  %t68 = load i64, ptr %l27, !tbaa !24
  %t69 = icmp sgt i64 %t68, 1
  br i1 %t69, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store ptr %l4, ptr %l29, !tbaa !29
  %t72 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t72, ptr %l31
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t73 = load i64, ptr %l31, !tbaa !24
  %t74 = sub i64 %t73, 1
  store i64 %t74, ptr %l32, !tbaa !24
  %t76 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %s0, ptr %l3)
  store i64 %t76, ptr %l34
  br label %bb14
bb14:
  %t77 = load i64, ptr %l34, !tbaa !24
  %t78 = icmp eq i64 %t77, 2
  br i1 %t78, label %bb15, label %bb16
bb15:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) }, ptr %l36, !tbaa !27
  br label %bb17
bb16:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d133, i32 0, i32 1) }, ptr %l36, !tbaa !27
  br label %bb17
bb17:
  %t80 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t82 = load i64, ptr %l32, !tbaa !24
  %t83 = call i64 @__olang_fmt_i64(ptr null, i64 %t82)
  %t84 = add i64 %t81, %t83
  %t85 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t91)
  call void @olang_textcopy(ptr %t92, ptr %t80, i64 %t81)
  %t93 = getelementptr i8, ptr %t92, i64 %t81
  %t94 = call i64 @__olang_fmt_i64(ptr %t93, i64 %t82)
  %t95 = getelementptr i8, ptr %t93, i64 %t83
  call void @olang_textcopy(ptr %t95, ptr %t85, i64 %t86)
  %t96 = getelementptr i8, ptr %t95, i64 %t86
  call void @olang_textcopy(ptr %t96, ptr %t89, i64 %t90)
  %t97 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t92, 1
  %t100 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s3, ptr %t100, { i64, ptr } %t98)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t103 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l4)
  store { i64, ptr } %t103, ptr %l40
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t104 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t104, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fsession_2ehover(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l10 = alloca i1
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l3
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store ptr %l2, ptr %l4, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %s0, { i64, ptr } %a0)
  store { i64, ptr } %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t11 = add i64 %t7, %t10
  %t12 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t13 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t14 = add i64 %t11, %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t6, i64 %t7)
  %t16 = getelementptr i8, ptr %t15, i64 %t7
  call void @olang_textcopy(ptr %t16, ptr %t9, i64 %t10)
  %t17 = getelementptr i8, ptr %t16, i64 %t10
  call void @olang_textcopy(ptr %t17, ptr %t12, i64 %t13)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t15, 1
  %t21 = load ptr, ptr %l4, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t21, { i64, ptr } %t19)
  br label %bb3
bb3:
  %t23 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t23, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d138, i32 0, i32 1) })
  store i1 %t25, ptr %l10
  br label %bb4
bb4:
  %t26 = load i1, ptr %l10, !tbaa !21
  %t27 = xor i1 %t26, true
  br i1 %t27, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t30 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t31 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t33 = extractvalue { i64, ptr } %t29, 1
  %t34 = extractvalue { i64, ptr } %t29, 0
  %t35 = add i64 %t31, %t34
  %t36 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t35)
  call void @olang_textcopy(ptr %t36, ptr %t30, i64 %t31)
  %t37 = getelementptr i8, ptr %t36, i64 %t31
  call void @olang_textcopy(ptr %t37, ptr %t33, i64 %t34)
  %t38 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t36, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s2, ptr %l2, { i64, ptr } %t39)
  br label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb8
bb8:
  %t44 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l2)
  store { i64, ptr } %t44, ptr %l17
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t45 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t45, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fsession_2esameShape(ptr %v0, ptr %a0, i32 %a1, i32 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i32
  %l17 = alloca i1
  %l24 = alloca i32
  %l29 = alloca i32
  %l34 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store i32 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/generic:Program", ptr %t4, i32 0, i32 2
  %t7 = load i32, ptr %l1, !tbaa !23
  %t10 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t6, i32 %t7)
  store i32 %t10, ptr %l9
  br label %bb1
bb1:
  %t11 = load i32, ptr %l9, !range !{i32 0, i32 33}
  store i32 %t11, ptr %l3
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/check:Checker", ptr %t12, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !29
  %t17 = getelementptr %"compiler/generic:Program", ptr %t15, i32 0, i32 2
  %t18 = load i32, ptr %l2, !tbaa !23
  %t21 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %t17, i32 %t18)
  store i32 %t21, ptr %l14
  br label %bb2
bb2:
  %t22 = load i32, ptr %l14, !range !{i32 0, i32 33}
  store i32 %t22, ptr %l4
  %t23 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t25 = trunc i64 18 to i32
  %t26 = icmp eq i32 %t23, %t25
  br i1 %t26, label %bb3, label %bb4
bb3:
  %t28 = load i32, ptr %l4, !range !{i32 0, i32 33}
  %t30 = trunc i64 18 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l17, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb5
bb5:
  %t33 = load i1, ptr %l17, !tbaa !21
  br i1 %t33, label %bb6, label %bb7
bb6:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/check:Checker", ptr %t34, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !29
  %t39 = getelementptr %"compiler/generic:Program", ptr %t37, i32 0, i32 2
  %t40 = load i32, ptr %l1, !tbaa !23
  %t43 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t39, i32 %t40)
  store i32 %t43, ptr %l24
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/check:Checker", ptr %t44, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !29
  %t49 = getelementptr %"compiler/generic:Program", ptr %t47, i32 0, i32 2
  %t50 = load i32, ptr %l2, !tbaa !23
  %t53 = call i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %t49, i32 %t50)
  store i32 %t53, ptr %l29
  br label %bb9
bb9:
  %t54 = load i32, ptr %l24, !tbaa !23
  %t55 = load i32, ptr %l29, !tbaa !23
  %t56 = icmp eq i32 %t54, %t55
  store i1 %t56, ptr %rv
  br label %ret
bb10:
  %t58 = load i32, ptr %l3, !range !{i32 0, i32 33}
  %t60 = trunc i64 25 to i32
  %t61 = icmp eq i32 %t58, %t60
  br i1 %t61, label %bb11, label %bb12
bb11:
  store i1 false, ptr %rv
  br label %ret
bb12:
  br label %bb13
bb13:
  %t64 = load i32, ptr %l3, !range !{i32 0, i32 33}
  store i32 %t64, ptr %l34
  %t65 = load i32, ptr %l4, !range !{i32 0, i32 33}
  store i32 %t65, ptr %l36
  %t68 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %l34, ptr %l36)
  store i1 %t68, ptr %l38
  br label %bb14
bb14:
  %t69 = load i1, ptr %l38, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local ptr @compiler_2fsession_2escoper(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca %"compiler/scope:Scoper"
  %rv = alloca ptr
  %t11 = alloca %"compiler/scope:Scoper", align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/check:Checker", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l3, !tbaa !29
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/check:Checker", ptr %t5, i32 0, i32 19
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l5
  %t10 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v1, ptr %l5)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l7
  br label %bb1
bb1:
  %t12 = load ptr, ptr %l3, !tbaa !29
  %t13 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  call void @compiler_2fscope_3aScoper_2ector(ptr %t11, ptr %v0, ptr %v1, ptr %v1, ptr %t12, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t11, i64 12080, i1 false)
  br label %bb2
bb2:
  %t14 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 12080, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t14, ptr %l8, i64 12080, i1 false)
  store ptr %t14, ptr %l1, !tbaa !29
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t19 = ptrtoint ptr %t18 to i64
  %t20 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t19, i64 8)
  %t21 = getelementptr { ptr, ptr }, ptr %t20, i32 0, i32 0
  store ptr %t17, ptr %t21, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t23 = call ptr @__olang_scope_hold(ptr %v0)
  %t24 = getelementptr { ptr, ptr }, ptr %t20, i32 0, i32 1
  store ptr %t23, ptr %t24, !tbaa !28
  %t25 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_140, 0
  %t26 = insertvalue { ptr, ptr } %t25, ptr %t20, 1
  %t30 = getelementptr %"compiler/scope:Scoper", ptr %t16, i32 0, i32 4
  store { ptr, ptr } %t26, ptr %t30
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr { ptr, ptr }, ptr null, i32 1
  %t34 = ptrtoint ptr %t33 to i64
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 %t34, i64 8)
  %t36 = getelementptr { ptr, ptr }, ptr %t35, i32 0, i32 0
  store ptr %t32, ptr %t36, !tbaa !28
  call void @__olang_scope_escape(ptr %v0)
  %t38 = call ptr @__olang_scope_hold(ptr %v0)
  %t39 = getelementptr { ptr, ptr }, ptr %t35, i32 0, i32 1
  store ptr %t38, ptr %t39, !tbaa !28
  %t40 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_141, 0
  %t41 = insertvalue { ptr, ptr } %t40, ptr %t35, 1
  %t45 = getelementptr %"compiler/scope:Scoper", ptr %t31, i32 0, i32 5
  store { ptr, ptr } %t41, ptr %t45
  %t46 = load ptr, ptr %l1, !tbaa !29
  store ptr %t46, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local void @compiler_2fsession_2estdModules(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca [2 x { i64, ptr }]
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca [2 x { i64, ptr }]
  %l14 = alloca { i64, ptr }
  %l27 = alloca i1
  %l29 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l43 = alloca i1
  %l53 = alloca { i64, ptr }
  %l57 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca i64
  %l66 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s0)
  store { i64, ptr } %t1, ptr %l14
  br label %bb1
bb1:
  %t2 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t2, ptr %l1, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) }, 0
  %t4 = insertvalue [2 x { i64, ptr }] %t3, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t6 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store [2 x { i64, ptr }] %t4, ptr %t6
  store ptr %t6, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  %t8 = load ptr, ptr %l2
  store i64 2, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = icmp slt i64 %t11, %t12
  %t17 = xor i1 %t15, true
  br i1 %t17, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb32
bb4:
  br label %bb5
bb5:
  %t19 = load ptr, ptr %l2
  %t20 = load i64, ptr %l3, !tbaa !24
  %t23 = getelementptr [2 x { i64, ptr }], ptr %t19, i64 0, i64 %t20
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !37
  store { i64, ptr } %t24, ptr %l5, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t27 = load ptr, ptr @__olang_prog_scope
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %t27, ptr %s2, { i64, ptr } %t26, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d144, i32 0, i32 1) })
  store i1 %t29, ptr %l27
  br label %bb6
bb6:
  %t30 = load i1, ptr %l27, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb7, label %bb8
bb7:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t36 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t33, 0
  %t38 = insertvalue [2 x { i64, ptr }] %t36, { i64, ptr } %t34, 1
  store [2 x { i64, ptr }] %t38, ptr %l6
  %t41 = insertvalue { i64, ptr } undef, i64 2, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %l6, 1
  %t44 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s2, ptr %s2, { i64, ptr } %t42)
  store { i64, ptr } %t44, ptr %l35
  br label %bb9
bb8:
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 1
  %t48 = extractvalue { i64, ptr } %t45, 0
  %t49 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t48)
  call void @olang_textcopy(ptr %t49, ptr %t47, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  br label %bb10
bb9:
  %t53 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t53, ptr %l29, !tbaa !27
  br label %bb10
bb10:
  %t54 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t57 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %s2, ptr %s2, { i64, ptr } %t55)
  %t58 = extractvalue { i32, { i64, ptr } } %t57, 1
  %t59 = extractvalue { i32, { i64, ptr } } %t57, 0
  store i32 %t59, ptr %l41
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb12, label %ok.61, !prof !99
ok.61:
  store { i64, ptr } %t58, ptr %l40
  br label %bb11
bb11:
  %t62 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t62, ptr %l38, !tbaa !27
  br label %bb16
bb12:
  %t63 = load i32, ptr %l41, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l43, !tbaa !21
  %t67 = load i32, ptr %l41, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb16:
  %t72 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t72, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 0
  store i64 %t77, ptr %l11, !tbaa !24
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s6
  %t79 = load i64, ptr %l10, !tbaa !24
  %t80 = load i64, ptr %l11, !tbaa !24
  %t83 = icmp slt i64 %t79, %t80
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb30
bb19:
  br label %bb20
bb20:
  %t87 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t87, ptr %l53, !tbaa !27
  %t88 = load i64, ptr %l10, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %t91, i64 %t88
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !37
  store { i64, ptr } %t93, ptr %l12, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t97 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s2, ptr %s6, { i64, ptr } %t95, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d145, i32 0, i32 1) })
  store i1 %t97, ptr %l57
  br label %bb21
bb21:
  %t98 = load i1, ptr %l57, !tbaa !21
  br i1 %t98, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %a0, ptr %l58, !tbaa !29
  %t100 = call ptr @__olang_scope_hold(ptr %v0)
  %t101 = ptrtoint ptr %t100 to i64
  store i64 %t101, ptr %l59, !tbaa !24
  %t102 = load i1, ptr @olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1
  br i1 %t102, label %bb24, label %bb25
bb23:
  br label %bb28
bb24:
  %t104 = call ptr @__olang_region_make(ptr %v0)
  %t105 = ptrtoint ptr %t104 to i64
  store i64 %t105, ptr %l59, !tbaa !24
  br label %bb25
bb25:
  %t106 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t109 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t106, 0
  %t111 = insertvalue [2 x { i64, ptr }] %t109, { i64, ptr } %t107, 1
  store [2 x { i64, ptr }] %t111, ptr %l13
  %t114 = insertvalue { i64, ptr } undef, i64 2, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %l13, 1
  %t116 = load i64, ptr %l59
  %t117 = inttoptr i64 %t116 to ptr
  %t119 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s7, ptr %t117, { i64, ptr } %t115)
  store { i64, ptr } %t119, ptr %l66
  br label %bb26
bb26:
  %t120 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t121 = load i64, ptr %l59
  %t122 = inttoptr i64 %t121 to ptr
  %t123 = extractvalue { i64, ptr } %t120, 0
  %t124 = extractvalue { i64, ptr } %t120, 1
  %t125 = mul i64 %t123, 1
  %t126 = call ptr @__olang_held_alloc(ptr %t122, i64 %t125)
  call void @llvm.memcpy.p0.p0.i64(ptr %t126, ptr %t124, i64 %t125, i1 false)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t129 = load ptr, ptr %l58, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t129, { i64, ptr } %t128)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s7)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  %t131 = load i64, ptr %l10, !tbaa !24
  %t134 = add i64 %t131, 1
  store i64 %t134, ptr %l10, !tbaa !24
  br label %bb17
bb30:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb31:
  %t136 = load i64, ptr %l3, !tbaa !24
  %t139 = add i64 %t136, 1
  store i64 %t139, ptr %l3, !tbaa !24
  br label %bb2
bb32:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/session:Analysis" @compiler_2fsession_3aAnalysis_2ector(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l7 = alloca i64
  %rv = alloca %"compiler/session:Analysis"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l1, !tbaa !29
  %t3 = call ptr @__olang_scope_hold(ptr %v1)
  %t4 = ptrtoint ptr %t3 to i64
  store i64 %t4, ptr %l7, !tbaa !24
  %t5 = load i1, ptr @olang_2esole_2ecompiler_2fsession_3aAnalysis_2e1
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = call ptr @__olang_region_make(ptr %v1)
  %t8 = ptrtoint ptr %t7 to i64
  store i64 %t8, ptr %l7, !tbaa !24
  br label %bb2
bb2:
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t11 = icmp sle i64 0, 576460752303423487
  br i1 %t11, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_9a26179cadaeaa7b_4750967a6fc1a6b7)
  unreachable
bb5:
  %t13 = mul i64 0, 16
  %t14 = load i64, ptr %l7
  %t15 = inttoptr i64 %t14 to ptr
  %t16 = insertvalue { i64, ptr } undef, i64 0, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t19 = load ptr, ptr %l1, !tbaa !29
  %t20 = insertvalue %"compiler/session:Analysis" undef, ptr %t19, 0
  %t22 = insertvalue %"compiler/session:Analysis" %t20, { i64, ptr } %t17, 1
  %t24 = insertvalue %"compiler/session:Analysis" %t22, ptr null, 2
  %t26 = insertvalue %"compiler/session:Analysis" %t24, ptr null, 3
  %t28 = insertvalue %"compiler/session:Analysis" %t26, ptr null, 4
  store %"compiler/session:Analysis" %t28, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_9a26179cadaeaa7b_4750967a6fc1a6b7)
  unreachable
ret:
  %rr = load %"compiler/session:Analysis", ptr %rv
  ret %"compiler/session:Analysis" %rr
}

define dso_local %"compiler/session:Found" @compiler_2fsession_3aFound_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %rv = alloca %"compiler/session:Found"
  br label %start
start:
  br label %bb0
bb0:
  %t8 = insertvalue %"compiler/session:Found" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/session:Found" %t8, { i64, ptr } %a1, 1
  %t12 = insertvalue %"compiler/session:Found" %t10, i64 %a2, 2
  store %"compiler/session:Found" %t12, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:Found", ptr %rv
  ret %"compiler/session:Found" %rr
}

define dso_local %"compiler/session:finder" @compiler_2fsession_3afinder_2ector(ptr %v0, ptr %v1, ptr %v2, i64 %a0, i64 %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %rv = alloca %"compiler/session:finder"
  %t9 = alloca { i64, [6 x i64] }, align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, [6 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [6 x i64] }, ptr %t9, i32 0, i32 0
  store i64 0, ptr %t10
  %t11 = load { i64, [6 x i64] }, ptr %t9
  %t14 = insertvalue %"compiler/session:finder" undef, i64 %a0, 0
  %t16 = insertvalue %"compiler/session:finder" %t14, i64 %a1, 1
  %t18 = insertvalue %"compiler/session:finder" %t16, { i64, ptr } %a2, 2
  %t20 = insertvalue %"compiler/session:finder" %t18, ptr %a3, 3
  %t22 = insertvalue %"compiler/session:finder" %t20, i64 -1, 4
  %t24 = insertvalue %"compiler/session:finder" %t22, { i64, [6 x i64] } %t11, 5
  %t26 = insertvalue %"compiler/session:finder" %t24, i64 9223372036854775807, 6
  store %"compiler/session:finder" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:finder", ptr %rv
  ret %"compiler/session:finder" %rr
}

define dso_local %"compiler/session:memberInfo" @compiler_2fsession_3amemberInfo_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, i64 %a4) #0 {
entry:
  %rv = alloca %"compiler/session:memberInfo"
  br label %start
start:
  br label %bb0
bb0:
  %t12 = insertvalue %"compiler/session:memberInfo" undef, { i64, ptr } %a0, 0
  %t14 = insertvalue %"compiler/session:memberInfo" %t12, i32 %a1, 1
  %t16 = insertvalue %"compiler/session:memberInfo" %t14, { i64, ptr } %a2, 2
  %t18 = insertvalue %"compiler/session:memberInfo" %t16, { i64, ptr } %a3, 3
  %t20 = insertvalue %"compiler/session:memberInfo" %t18, i64 %a4, 4
  store %"compiler/session:memberInfo" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:memberInfo", ptr %rv
  ret %"compiler/session:memberInfo" %rr
}

define dso_local %"compiler/session:typeFinder" @compiler_2fsession_3atypeFinder_2ector(ptr %v0, i64 %a0) #0 {
entry:
  %rv = alloca %"compiler/session:typeFinder"
  br label %start
start:
  br label %bb0
bb0:
  %t3 = load i32, ptr @G_2ecompiler_2ftypes_2eUnknownT, !tbaa !23
  %t6 = insertvalue %"compiler/session:typeFinder" undef, i64 %a0, 0
  %t8 = insertvalue %"compiler/session:typeFinder" %t6, i32 %t3, 1
  %t10 = insertvalue %"compiler/session:typeFinder" %t8, i64 -1, 2
  store %"compiler/session:typeFinder" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/session:typeFinder", ptr %rv
  ret %"compiler/session:typeFinder" %rr
}

define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e1 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2ffetch_3aFetcher_2e2 = weak hidden constant i1 false
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@olang_2esole_2ecompiler_2fload_3aLoader_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fload_3aLoader_2e20 = weak hidden constant i1 false
declare void @__olang_region_release(ptr) noinline
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"loaded " }>, align 8
@.d1 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" (" }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d2 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c" modules) in " }>, align 8
@.d3 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ms" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@olang_2esole_2ecompiler_2fsession_3aAnalysis_2e1 = weak hidden constant i1 false
@.d4 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"checked in " }>, align 8
@.d5 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ms" }>, align 8
declare i32 @fork()
declare void @__olang_errpay_pop()
declare void @_exit(i32) noreturn
declare void @__olang_check_failed(ptr) cold noreturn
@.d6 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2c_20std_Hae258982e94f82c7c4916579e261fcef = weak hidden constant i1 false
@.d7 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d8 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d9 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c": cannot be made\0A" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i32 @olang_lambda_10(ptr %env) #0 {
entry:
  %l6 = alloca i32
  %rv = alloca i32
  %cp0 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load ptr, ptr %cp1, !tbaa !28
  %cp2 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load { i64, ptr }, ptr %cp2, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, ptr, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  %t7 = call i32 @compiler_2fsession_2edocPage(ptr %vc0, ptr %vc1, ptr %vc2, { i64, ptr } %cv0, ptr %cv1, { i64, ptr } %cv2)
  store i32 %t7, ptr %l6
  br label %bb1
bb1:
  %t8 = load i32, ptr %l6, !tbaa !23
  store i32 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

@olang_2esole_2ecompiler_2fdoc_3aModule_2e0 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fdoc_3aModule_2e2 = weak hidden constant i1 false
define internal i1 @olang_lambda_11(ptr %env, ptr %v0, ptr %v1, %"compiler/doc:Module" %a0, %"compiler/doc:Module" %a1) #0 {
entry:
  %l0 = alloca %"compiler/doc:Module"
  %l1 = alloca %"compiler/doc:Module"
  %l4 = alloca i1
  %rv = alloca i1
  store %"compiler/doc:Module" %a0, ptr %l0
  store %"compiler/doc:Module" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr %"compiler/doc:Module", ptr %l0, i32 0, i32 0
  %t2 = load { i64, ptr }, ptr %t1, !tbaa !27
  %t3 = getelementptr %"compiler/doc:Module", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t7, ptr %l4
  br label %bb1
bb1:
  %t8 = load i1, ptr %l4, !tbaa !21
  store i1 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d12 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"index.html" }>, align 8
@.d13 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c"olang standard library" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"olang" }>, align 8
@.d15 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d16 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@olang_2esole_2ecompiler__2fsession__2eHold_2elocal_2e5 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
declare void @__olang_region_drop(ptr) noinline
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e0 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMapEntry_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1 = weak hidden constant i1 false
declare void @__olang_region_release_part(ptr, i64) noinline
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2e2 = weak hidden constant i1 false
@.d17 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"held to section 8 in " }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" ms (" }>, align 8
@.d19 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c" judgings from records)" }>, align 8
@olang_2esole_2ecompiler_2finterp_3aExec_2e10 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make_part(ptr) noinline
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e1 = weak hidden constant i1 false
@olang_2esole_2estd_2fprelude_2fmap_3aMap_3cI64_2c_20Bool_3e_2e2 = weak hidden constant i1 false
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e4 = weak hidden constant i1 false
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d25 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@olang_2esole_2ecompiler__2fsession__2eIdentityOf_2elocal_2e5 = weak hidden constant i1 false
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d28 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"std has it: '" }>, align 8
@.d29 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d30 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@olang_2esole_2ecompiler__2fsession__2eImportFix_2elocal_2e9 = weak hidden constant i1 false
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d32 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d33 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_203_3e_2e_2d1 = weak hidden constant i1 false
@__olang_slot_chunk = external global %olang.chunk
@.d34 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d35 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d36 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"../" }>, align 8
@.d37 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@olang_2esole_2ecompiler__2fsession__2eImportPaths_2elocal_2e9 = weak hidden constant i1 false
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d41 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d42 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"../" }>, align 8
@.d43 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d44 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d45 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@.d46 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d47 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"import " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d53 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"fn" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d55 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"keeps" }>, align 8
@.d56 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"borrows" }>, align 8
@.d57 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"in" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2e_2d1 = weak hidden constant i1 false
define linkonce_odr %"<poll.h>:pollfd" @olang_2emir_2eHelperKind_2eZero_2e_3cpoll_2eh_3e_3apollfd() #0 {
entry:
  %l0 = alloca %"<poll.h>:pollfd"
  %rv = alloca %"<poll.h>:pollfd"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %t1)
  store %"<poll.h>:pollfd" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"<poll.h>:pollfd", ptr %l0
  store %"<poll.h>:pollfd" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"<poll.h>:pollfd", ptr %rv
  ret %"<poll.h>:pollfd" %rr
}

declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare i32 @poll(ptr, i64, i32)
@.d58 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"std/" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_26_2c_202_3e_2e_2d1 = weak hidden constant i1 false
@.d59 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d60 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"no type" }>, align 8
@.d63 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"completion after a '.' at " }>, align 8
@.d64 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c": " }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fscope_3aPlacement_2e4 = weak hidden constant i1 false
@.d66 = private constant <{ i64, [59 x i8] }> <{ i64 0, [59 x i8] c" - handing on a value instead would let it go with its step" }>, align 8
@.d67 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c" - a copy of what is kept ('$x') would let it go with its turn" }>, align 8
@olang_2esole_2ecompiler_2fsession_3aUse_2e2 = weak hidden constant i1 false
@.d68 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler_2fsession_3aFound_2e1 = weak hidden constant i1 false
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@olang_2esole_2ecompiler_2fsession_3aFound_2e0 = weak hidden constant i1 false
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d72 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"parameter " }>, align 8
@.d73 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d74 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d77 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"import \22" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\22" }>, align 8
@olang_2esole_2ecompiler_2fsession_3amemberInfo_2e2 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fsession_3amemberInfo_2e3 = weak hidden constant i1 false
declare ptr @__olang_scope_of(ptr, ptr) noinline
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"$" }>, align 8
@.d80 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d81 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"@" }>, align 8
@.d82 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2estd_2fprelude_2ftext_3aLineIter_2e0 = weak hidden constant i1 false
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_202_3e_2e_2d1 = weak hidden constant i1 false
@.d87 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Copy" }>, align 8
@.d88 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Hash" }>, align 8
@.d89 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"supplied" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_204_3e_2e_2d1 = weak hidden constant i1 false
@.d90 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Len" }>, align 8
@.d91 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Get" }>, align 8
@.d92 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Set" }>, align 8
@.d93 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"SliceOf" }>, align 8
@.d94 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"supplied" }>, align 8
@.d95 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Narrow" }>, align 8
@.d96 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"supplied" }>, align 8
@.d97 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d98 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"supplied" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_206_3e_2e_2d1 = weak hidden constant i1 false
@.d99 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"LeadingZeros" }>, align 8
@.d100 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"TrailingZeros" }>, align 8
@.d101 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"PopCount" }>, align 8
@.d102 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"RotateLeft" }>, align 8
@.d103 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"RotateRight" }>, align 8
@.d104 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"ByteSwap" }>, align 8
@.d105 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"supplied" }>, align 8
@olang_2esole_2eArray_3cstd_2fprelude_2ftext_3aString_2c_205_3e_2e_2d1 = weak hidden constant i1 false
@.d106 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicLoad" }>, align 8
@.d107 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"AtomicStore" }>, align 8
@.d108 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"AtomicAdd" }>, align 8
@.d109 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"AtomicSwap" }>, align 8
@.d110 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"AtomicCompareSwap" }>, align 8
@.d111 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"supplied" }>, align 8
@.d112 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d113 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"content-length:" }>, align 8
declare ptr @__olang_scope_or(ptr, ptr)
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@olang_2esole_2ecompiler__2fsession__2ecompiler__2fsession__3asymWriter__2edecl_2elocal_2e8 = weak hidden constant i1 false
@.d115 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d116 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"error" }>, align 8
@.d119 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"]}" }>, align 8
@.d121 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"test " }>, align 8
@.d122 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d125 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d126 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d127 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c": cannot be written\0A" }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"\0A\0AExample: " }>, align 8
@.d130 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"\0A```olang\0A" }>, align 8
@.d131 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0A```" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"s" }>, align 8
@.d134 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A\0A+" }>, align 8
@.d135 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c" more test" }>, align 8
@.d136 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"```olang\0A" }>, align 8
@.d137 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"\0A```" }>, align 8
@.d138 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d139 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\0A\0A" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftypes_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0, !range !{i32 0, i32 33}
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1, !range !{i32 0, i32 33}
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define internal { i64, ptr } @olang_lambda_140(ptr %env, ptr %v0, i64 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %vc0, ptr %v0, ptr %cv0, i64 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define internal { i64, ptr } @olang_lambda_141(ptr %env, ptr %v0, i32 %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  %cp0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load ptr, ptr %cp0, !tbaa !28
  %vq0 = getelementptr { ptr, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %vc0, ptr %v0, ptr %cv0, i32 %a0)
  store { i64, ptr } %t5, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d143 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"prelude" }>, align 8
@.d144 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d145 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i64, ptr } @compiler_2fload_2eLockPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ffetch_2eCacheDir(ptr %v0)
declare { i64, ptr } @compiler_2ffetch_2eGitBase(ptr %v0)
declare void @compiler_2ffetch_3aFetcher_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3, i1 %a4)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare void @compiler_2fload_3aLoader_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, { i64, ptr } %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"std/prelude/map:MapIter.bf5835bb10600fe6a7fc1da14a6360d9" @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H233962476a3191cb30d917b30cae0288(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" } @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMapIter_3cstd_2fprelude_2ftext_3aString_26_2_H2ebf6f1d68886862a568a520c713bfce(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6f7a2f8d839c49b6e7a19c287d4b190c(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare i64 @std_2ftime_2eNow()
declare i64 @compiler_2fload_2ecompiler_2fload_3aLoader_2eLoad(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_Hb2d19b6b5ea5ab5a85c5720545345bd4(ptr %v0, ptr %a0)
declare i64 @std_2ftime_2eSince(i64 %a0)
declare void @compiler_2fsession_2eLog(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHasFatal(ptr %v0, ptr %a0)
declare void @compiler_2fviews_3aKept_2ector(ptr %out, ptr %v0)
declare void @compiler_2finterp_2eAnalyze(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, i1 %a1, ptr %a2)
declare { i64, ptr } @compiler_2frecords_2eModuleKeys(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare void @compiler_2frecords_2eFrontRecords(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
declare void @compiler_2finterp_2eJudgeViews(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fpair_3aPair_3cI64_2c_20I64_3e_2c_20Bool_3e_2ector(ptr %v0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideValues(ptr %v0, ptr %a0)
declare i64 @compiler_2finterp_2eDecideAsserts(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20compiler_2feval_3aImage_3e_2ector(ptr %v0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2finterp_2eBake(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2frecords_2eKeepFront(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4, ptr %a5)
declare { i32, i32 } @compiler_2fsession_2ePipe()
declare void @compiler_2fsession_2eCloseFd(i32 %a0)
declare void @compiler_2fsession_2eDup2(i32 %a0, i32 %a1)
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
@olang_loc_35fd852a81194674_cc9a5a6794b34358 = external constant [0 x i8]
declare %"compiler/session:Reader" @compiler_2fsession_3aReader_2ector(ptr %v0, i32 %a0)
declare i1 @compiler_2fsession_2ecompiler_2fsession_3aReader_2eFill(ptr %v0, ptr %a0)
declare i32 @compiler_2fsession_2eReap(i32 %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU8_3e_2eView_3cU8_3e(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fsession_2esay(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_3107e0baf714f587_4e2de6149db597f3 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fdoc_2eItemText(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDocNoItem(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
@olang_loc_6636dd2b26b29868_9b4c1750690bee24 = external constant [0 x i8]
declare %"compiler/doc:Module" @compiler_2fdoc_2eModule_2eOf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2, i64 %a3, i1 %a4)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eText(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ector(ptr %v0, i64 %a0)
declare i32 @compiler_2fsession_2eInChild(ptr %v0, ptr %a0c, ptr %a0e)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2eModuleDoc(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/doc:Module" @compiler_2fdoc_3aModule_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2ePush_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/doc:Module" %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eSort_3cco_Hfcfbe33647fb7db48e9022f22b0d44cf(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aModule_3e_2eToArray_3ccompiler_2fdoc_3aModule_3e(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fdoc_2eIndexHtml(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_35f6bc648a66c5f9_fb290a2b6e993705 = external constant [0 x i8]
@olang_loc_7df5e84b4c633bd2_e3c06e6feae95f5e = external constant [0 x i8]
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @compiler_2frecords_2eScopeRecords(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eFieldMarks(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_6f935d255f99d513_bebfb26ca618488f = external constant [0 x i8]
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eRun(ptr %v0, ptr %a0)
@olang_loc_9e4e38a802f76144_ff726f2d97618db0 = external constant [0 x i8]
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare void @compiler_2fscope_2ecompiler_2fscope_3aScoper_2eSetFieldMarks(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_80db4b4ab4bdeb95_d8fc8731110a3729 = external constant [0 x i8]
@olang_loc_75f06ede6c99afee_aaf5c12ecba84b42 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0)
declare void @compiler_2frecords_2eKeepScope(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
declare void @compiler_2frecords_2eTrimRecords(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2)
@olang_loc_71e3f151f76f601f_4a33fa6849f13ac3 = external constant [0 x i8]
declare void @compiler_2finterp_3aExec_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2)
@olang_loc_cfd81b6845724380_171723f1f2963534 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fsession_2eRealOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_41308d8b43e86301_faf6b9f2c6bbac3d = external constant [0 x i8]
@olang_loc_18466e7707586594_33576ced7420fee0 = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_decc2d78854299ff_a983c2831d86fddb = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_11adf005d01e014e_cb232ed18e8bcffa = external constant [0 x i8]
@olang_loc_49d3d4d897a09f4b_e833dc78ed36a5d7 = external constant [0 x i8]
@olang_loc_99d7ad80954f16d0_3de5076c8923a26c = external constant [0 x i8]
@olang_loc_a69546661a842dad_144c74a8276b4119 = external constant [0 x i8]
@G_2ecompiler_2fsession_2eCompFolder = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\13\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3)
@olang_loc_478261abf26af98f_fc848126d7caf56b = external constant [0 x i8]
@olang_loc_3c61ac8d706d9f92_284cc560dda6476e = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eIsDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_7b2af1307c65a991_42bd59c234e619cd = external constant [0 x i8]
@G_2ecompiler_2fsession_2eCompFile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\11\00\00\00\00\00\00\00" }>, align 8
@olang_loc_e7281b11a7ac5d7_4fa3836323ed2ea3 = external constant [0 x i8]
@olang_loc_f161d409bbcfeffa_eff8e4c73ed9b6c6 = external constant [0 x i8]
@olang_loc_5667240f2322ee2f_f3539aae4c478ceb = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrimEnd(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @compiler_2fsession_2eWordChar(i8 %a0)
@olang_loc_eb90226238b175b2_1f1bdee85222deee = external constant [0 x i8]
@olang_loc_6afc88ea1ac145e8_494a63ded86193f4 = external constant [0 x i8]
@G_2e_3cpoll_2eh_3e_2ePOLLIN = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
@olang_loc_cd9998fc5b6bf5d5_fa43d55bb2deeb01 = external constant [0 x i8]
@G_2e_3cpoll_2eh_3e_2ePOLLERR = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\08\00\00\00" }>, align 8
@G_2e_3cpoll_2eh_3e_2ePOLLHUP = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\10\00\00\00" }>, align 8
@olang_loc_b18535922df9c451_739a4491ef7ea55d = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2ector(ptr %v0, i64 %a0)
declare i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eModuleOf(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fload_3aModule_26_3e_2_H7bcf2aeb09afa796f4333e6ec8c3f63f(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eDeprecatedNames(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @compiler_2fdoc_2eLineEnd(ptr %v0, { i64, ptr } %a0, i64 %a1)
@olang_loc_7ada9cad4f5dae06_e1e48e82a4e1a6ca = external constant [0 x i8]
declare i64 @compiler_2fdoc_2eCommentColumn(ptr %v0, { i64, ptr } %a0)
@olang_loc_7b32137e1a8558e3_9274687faf6829a7 = external constant [0 x i8]
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i64 @compiler_2fdoc_2eLineStart(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/session:Use" @compiler_2fsession_3aUse_2ector(ptr %v0, ptr %v1, i64 %a0, i64 %a1, { i64, ptr } %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsession_3aUse_3e_2ePush_3ccompiler_2fsession_3aUse_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/session:Use" %a1)
declare %"compiler/source:Span" @compiler_2fsession_2eWordAt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eUse(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare %"compiler/names:Ref" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eMember(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclFor(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSelfType(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eBuildersOf(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare ptr @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnDecl(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare i1 @compiler_2fdoc_2eExported(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnModule(ptr %v0, ptr %a0, i64 %a1)
@G_2ecompiler_2fsession_2eCompMethod = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@olang_loc_3178b68d0296f164_92041ef9c14564d0 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fexplain_2eFnText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2)
declare { i64, ptr } @compiler_2fsession_2efirstLine(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2edeprecatedAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i1 %a3)
declare void @compiler_2fsession_2ecompiler_2fsession_3aItems_2eAddDep(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3, i1 %a4)
@G_2ecompiler_2ftypes_2eUnknownT = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eTy(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_804f8b0fb45e435f_c5484f8454187243 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_Ha1ef0e278819e2a81939c80ef5438e96(ptr %v0, ptr %a0)
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2ftyped_3aBody_26_3e_2e_He4283c245933e28cdc2fc55a6cc24bf1(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eLen_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0)
declare %"compiler/typed:Local" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocal_3e_2eAt_3ccompiler_2ftyped_3aLocal_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9033262c592f27c0_922b790dfcbd6cb4 = external constant [0 x i8]
@G_2ecompiler_2fsession_2eCompVariable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eLen_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %a0)
declare %"compiler/load:Import" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fload_3aImport_3e_2eAt_3ccompiler_2fload_3aImport_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@G_2ecompiler_2fsession_2eCompModule = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKeywords = external constant <{ [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr, [8 x i8], ptr }>
@G_2ecompiler_2fsession_2eCompKeyword = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
@olang_loc_270f5d4da41f712e_3815e2adbc47561a = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fscope_2ecompiler_2fscope_3aScoper_2ePlacements(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aPlacement_3e_2eLen__H4d2672aa7d845ec0c6fc38a004384ece(ptr %v0, ptr %a0)
declare %"compiler/scope:Placement" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aPlacement_3e_2eAt_3ccompiler_2fscope_3aPlacement_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_34b5353ec7fa6306_74a43705b3ad61d2 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fexplain_2eItem(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, i64 %a3, { i64, ptr } %a4)
@olang_loc_36d5ca6fa18785ed_2ca50b1ef1b0ebf9 = external constant [0 x i8]
declare i64 @compiler_2fsession_2edeclOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare { i64, ptr } @compiler_2fdoc_2eComment(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i1 %a2)
@olang_loc_913972385efaf6d8_94fc87626a418744 = external constant [0 x i8]
@olang_loc_50b486dff56c46f7_6641abdfc6e3fb13 = external constant [0 x i8]
@olang_loc_e9f7bb5439d2c10a_6c9ebd98d3e3d5ee = external constant [0 x i8]
@olang_loc_f7a7bb63ca62da11_77899a051c081195 = external constant [0 x i8]
declare i1 @compiler_2fast_2ecompiler_2fast_3aFunc_2eIsBuilder(ptr %v0, ptr %a0)
@olang_loc_6d2a6542ebcc5b1c_c6866a22acbc6980 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fast_2eOwnerTarget(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fdoc_2eReceiverName(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_9453126c7f8f920b_6892400c5eb9861f = external constant [0 x i8]
@olang_loc_9fba17dd33d652ce_1e95afa29dd6ec2a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2eAbove(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1)
@olang_loc_8be95a0084a275_27fb33976f90d831 = external constant [0 x i8]
@olang_loc_62de0451ac433905_e234825e46030f99 = external constant [0 x i8]
declare i64 @compiler_2fsession_2ecompiler_2fsession_3aAnalysis_2emoduleOfFile(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_4b7568962893615e_80e60e4246117872 = external constant [0 x i8]
@olang_loc_2674ac92e3c24a8f_ce1576bd6c3688b3 = external constant [0 x i8]
@olang_loc_3b23b9b6a905edf7_80e5cdf9542388b = external constant [0 x i8]
@olang_loc_b16f220e0018fd17_df8b0dd8cdfc1943 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eKindOf(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eReferent(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_e81878307a0930f8_ac6e376276a113b4 = external constant [0 x i8]
@olang_loc_cf719ce72396210d_6e539aa1951515a9 = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclOf(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_90bed28a447e5726_404cd49f4fb329c2 = external constant [0 x i8]
@olang_loc_966fb838f56733ab_5416c5dd2a23270f = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eLen_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aLocalId_3e_2eAt_3ccompiler_2ftyped_3aLocalId_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_55b3f811cb7477b4_5dfc53d9875946d8 = external constant [0 x i8]
@olang_loc_4c52bbc768601131_90801d9bf2a41585 = external constant [0 x i8]
@olang_loc_42ed37d296a6252a_791781e06ef43dde = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eFields(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eItems(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_dff094d230471566_615c91b3ab3b0902 = external constant [0 x i8]
@olang_loc_93ae806d7d0351b8_8e59b8ae3d0673ac = external constant [0 x i8]
@olang_loc_9641f0facc09fdd7_c62ff0c79521a99b = external constant [0 x i8]
@olang_loc_c5788a2fa1963e6_4f790674132263da = external constant [0 x i8]
@olang_loc_c84a3880e9ad3dcd_a55c78b5e4758561 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eTextOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_ba93316a311e09f4_9951ae939e9d3a90 = external constant [0 x i8]
@olang_loc_655ed1db7681c96b_c757f347e4ac2c7 = external constant [0 x i8]
@G_2ecompiler_2fsession_2eCompField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@olang_loc_284eaf45fbe9e9ea_494071f23c61296 = external constant [0 x i8]
@olang_loc_989a7bf68c7dc1d7_25d5471cbaf803d3 = external constant [0 x i8]
@olang_loc_96070b693d7715b8_3d59b06a8f6f9604 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFieldNames(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
@olang_loc_caa2c37caa2101cd_bb05ddde25bad6b9 = external constant [0 x i8]
@olang_loc_eb0139eba8d27e6_5e0e324bb341d292 = external constant [0 x i8]
@olang_loc_878a1a37f76dded1_df06407b9e0240ed = external constant [0 x i8]
declare %"std/pair:Pair.d0636885f2b44490dbc61e56fa468a20" @std_2fpair_3aPair_3cI64_2c_20compiler_2ftyped_3aLocalId_3e_2ector(ptr %v0, i64 %a0, i32 %a1)
@olang_loc_c3a06fb660f5d63_2c40dec7065bb2a7 = external constant [0 x i8]
declare i32 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eSig(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eParams(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_98883a8ec488cc54_28db399b67188488 = external constant [0 x i8]
@olang_loc_eee90b85a2ab3449_1ca471f0e2dcfa5d = external constant [0 x i8]
@olang_loc_e37b319ee17ac3e2_6c53c7f393475f6 = external constant [0 x i8]
declare i1 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eExtends(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_82b2f05c0e10fd2f_9f8d8e81429d057b = external constant [0 x i8]
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eBase(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_b19b477afd43b7d0_26f9d3d945d2830c = external constant [0 x i8]
@olang_loc_639bbb695375d625_d561d256ffb09c41 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDefaultMethods(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eHas_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_ad4014c285adba33_5f0a50bbd6dd5777 = external constant [0 x i8]
@olang_loc_5a0f7bc549a8a64_9f8f3c14406c0758 = external constant [0 x i8]
declare ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cmut_20compiler_2fnames_3aTable_26_3e_2_Hc2ccbbc5952c057a60f016e9cc1626d2(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eLen_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %a0)
declare %"compiler/names:Entry" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fnames_3aEntry_3e_2eAt_3ccompiler_2fnames_3aEntry_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
@olang_loc_c15f20635f7a4119_452b944b82f8966d = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnNamed(ptr %v0, ptr %a0, i64 %a1, i32 %a2)
@olang_loc_6010ac475f88a9f2_430aff1aa96b7386 = external constant [0 x i8]
@G_2ecompiler_2fsession_2eCompFunction = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
@olang_loc_64c89934b5f1bf_a2a8dc486100a28b = external constant [0 x i8]
@G_2ecompiler_2fsession_2eCompStruct = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eCompConstant = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\15\00\00\00\00\00\00\00" }>, align 8
@olang_loc_3355c36425226bea_fe115d6500f3a7ee = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2eDeprecation(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_9d5a0cb699faa7f1_8fc39d14917e395 = external constant [0 x i8]
@olang_loc_f7c6bb339a0b1bfc_57f909eed9cc3b80 = external constant [0 x i8]
@olang_loc_9563e15fbc6eea92_8818e5f6fc0bf866 = external constant [0 x i8]
@olang_loc_c4fad5f23cb43116_e9ea0caff0315a32 = external constant [0 x i8]
@olang_loc_48989d5f5646e0fd_ef1e52ba7ace6b59 = external constant [0 x i8]
@olang_loc_f019bff4f77dc028_28a8ece3fb472fa4 = external constant [0 x i8]
@olang_loc_ccdc4e079738e147_db8abba82ff0d973 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsNumber(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_fdfd5472c10825a_eabe36e5f7d3d64e = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsFloat(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_65c34788fd63a3e1_4b900862c48225f5 = external constant [0 x i8]
declare i1 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eIsInt(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_d513bc439d44d6f6_9aa74f14fc08fdfa = external constant [0 x i8]
@olang_loc_78ada93836b36c6b_7d0979891c04300f = external constant [0 x i8]
@olang_loc_f729b95fcb28e588_e9118b2581b5934c = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fnames_2ecompiler_2fnames_3aResolver_2eLocalSpan(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1e357a262dddcdbe_92aa1b1cb004b7e2 = external constant [0 x i8]
@olang_loc_a3b4800e6d7209ba_290fe7f1ef38ac36 = external constant [0 x i8]
@olang_loc_a3b0521b63c0fd41_ee4db74cec265b9d = external constant [0 x i8]
@olang_loc_f548539da9e2e40c_6a57728f427e36c8 = external constant [0 x i8]
declare void @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eAllFns(ptr %v0, ptr %a0)
@olang_loc_6ddc0e45a6ad667b_c7aac46097de5ae7 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eFnCount(ptr %v0, ptr %a0)
@olang_loc_be0af37330f35afe_68a0a057b8d4cca2 = external constant [0 x i8]
@olang_loc_7be9b74a0a4337a5_af051c2067e0d709 = external constant [0 x i8]
@olang_loc_a0e32d5552598bb5_d1b40570995ef0d1 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aStmt_2eSpan(ptr %v0, ptr %a0)
@olang_loc_90517919cad2500e_b5e04c9858b7f7ca = external constant [0 x i8]
@olang_loc_ce3fd8c720c212bf_60e6469ff90569cb = external constant [0 x i8]
@olang_loc_d27ec903618be0a0_36ec6c4f051caedc = external constant [0 x i8]
declare void @compiler_2fsession_2ecompiler_2fsession_3afinder_2eblock(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_cf04846f3952f731_2a54d968229bc665 = external constant [0 x i8]
declare void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eblock(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_77695651a3cbe722_713723fe03dd0eb6 = external constant [0 x i8]
@olang_loc_192180e0c65a19ab_79011e5b413ec96f = external constant [0 x i8]
@olang_loc_41c9e4d1a5402e3c_f7f654128ad00b10 = external constant [0 x i8]
@olang_loc_65524a0775fa0c24_67802a16d5ac44c0 = external constant [0 x i8]
@olang_loc_183418cbaaa3b5f3_579c8efa30db605f = external constant [0 x i8]
@olang_loc_269369d36ae436b2_2e7a039021f1ff2e = external constant [0 x i8]
@olang_loc_2bc7afddf58147d9_c9ac3d0f6598ded5 = external constant [0 x i8]
@olang_loc_843b58ccd5037a60_511f1c08fd361084 = external constant [0 x i8]
@olang_loc_237e374d945d777f_399ab2bb28be7e53 = external constant [0 x i8]
@olang_loc_276794097286b2ce_71d39dea21084d12 = external constant [0 x i8]
@olang_loc_883965863f350275_cecb497c93815139 = external constant [0 x i8]
@olang_loc_36ec2fbf7c558d87_ca970629ee3fcabb = external constant [0 x i8]
declare %"std/prelude/text:LineIter" @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLines(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aLineIter_2eNext(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eTrim(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eToLower(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_757e008d51ce27aa_df9e4b2b6fbab93e = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eParseInt(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare void @compiler_2fsession_2ecompiler_2fsession_3aReader_2edrop(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7fa1338bfb5c4549_286381a3bde0b91d = external constant [0 x i8]
@olang_loc_98e1614ed1d054f5_86eb50e982cc0441 = external constant [0 x i8]
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eInstanceFn(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fsession_2ecompiler_2fsession_3afinder_2etake(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1, { i64, [6 x i64] } %a2)
declare i32 @compiler_2ftypes_2ecompiler_2ftypes_3aTable_2eDeclName(ptr %v0, ptr %a0, i32 %a1)
declare i64 @compiler_2fgeneric_2ecompiler_2fgeneric_3aProgram_2eDeclModule(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_68ddcf9e12618436_cff7fbf614d16d4a = external constant [0 x i8]
@olang_loc_a3421b14f56bfb72_e21214c32a246516 = external constant [0 x i8]
declare void @compiler_2fsession_2ecompiler_2fsession_3afinder_2estmt(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1)
@olang_loc_6c2d06947719abd6_25c6135ab70ee42 = external constant [0 x i8]
@olang_loc_a4411270f97f17bd_30632737f0d2da29 = external constant [0 x i8]
@olang_loc_e2f597d466b9781f_44eca8a2d4aa1b5b = external constant [0 x i8]
@olang_loc_7a96973d190d0d9e_4b6d703943f97c5a = external constant [0 x i8]
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aLvalue_2eType(ptr %v0, ptr %a0)
@olang_loc_f2f4caf0087f76e9_23d5843dfc5c1e5 = external constant [0 x i8]
declare i64 @compiler_2fsession_2enameIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
@olang_loc_17c267c41fc9225_ba4af4ec5e6e67d9 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eSpan(ptr %v0, ptr %a0)
@olang_loc_e2fdffbec4ffc6f6_d7c57975026acfca = external constant [0 x i8]
@olang_loc_20935b6efc97b92f_a6b75dda1390d5f3 = external constant [0 x i8]
@olang_loc_d4784f9ecdded0f8_efac4001dd272cfc = external constant [0 x i8]
@olang_loc_8cc976989131f049_16bcaa94a8222275 = external constant [0 x i8]
@G_2ecompiler_2fsession_2eKindMethod = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindFunction = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eleaf(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8)
@G_2ecompiler_2fsession_2eKindClass = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindStruct = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\17\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindEnum = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fsession_2eKindInterface = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
@olang_loc_6d13c8aa31bd5d91_e2d0bffb643f3edd = external constant [0 x i8]
declare void @compiler_2fsession_2ecompiler_2fsession_3asymWriter_2eopen(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6, i64 %a7, { i64, ptr } %a8)
declare %"compiler/session:symWriter" @compiler_2fsession_3asymWriter_2ector(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_aa1a720e54961963_b2017c5bfd4a977f = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2fsession_2eKindTypeParameter = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\1A\00\00\00\00\00\00\00" }>, align 8
@olang_loc_a8f128570d4ee58c_72533cb80a04a368 = external constant [0 x i8]
@G_2ecompiler_2fsession_2eKindVariable = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
declare i64 @compiler_2fdoc_2eWordIn(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2)
@G_2ecompiler_2fsession_2eKindEnumMember = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\16\00\00\00\00\00\00\00" }>, align 8
@olang_loc_a1b1115ef3955beb_c10ad3dd013eb27f = external constant [0 x i8]
@olang_loc_d921cd6da7eb22f5_584e6aeeea9cbb69 = external constant [0 x i8]
@G_2ecompiler_2fsession_2eKindField = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
@olang_loc_59453385dbeab0f1_a10e94e6ba58edc5 = external constant [0 x i8]
@olang_loc_d9881facfbc222b9_fdfa0d9fbca7f5d5 = external constant [0 x i8]
@olang_loc_7c90741a89491e92_62c7d4207901162e = external constant [0 x i8]
@olang_loc_445788eb90ff4fd3_8bea5f8a87ea775f = external constant [0 x i8]
@olang_loc_5bdbf2396576e204_9bcdfaa72cbb5bc0 = external constant [0 x i8]
declare %"compiler/source:Span" @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare i32 @compiler_2ftyped_2ecompiler_2ftyped_3aExpr_2eType(ptr %v0, ptr %a0)
declare void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2etake(ptr %v0, ptr %a0, %"compiler/source:Span" %a1, i32 %a2)
declare void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2eplace(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare void @compiler_2fsession_2ecompiler_2fsession_3atypeFinder_2estmt(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_df797fad9b49105d_2a8f7c5ad36c2889 = external constant [0 x i8]
@olang_loc_e6936df67b662b33_7a0885fa2c8953cf = external constant [0 x i8]
declare { i64, ptr } @compiler_2fdoc_2ePageName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdoc_2ecompiler_2fdoc_3aModule_2eHtml(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdoc_2eExamplesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i64 %a1, { i64, ptr } %a2)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eLen_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare %"compiler/doc:Example" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdoc_3aExample_3e_2eAt_3ccompiler_2fdoc_3aExample_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fscope_3aScoper_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %a1)
@olang_loc_9a26179cadaeaa7b_4750967a6fc1a6b7 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI64_2c_20std_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"<poll.h>:pollfd" @_3cpoll_2eh_3e_3apollfd_2ector(ptr %v0)
declare { i64, ptr } @compiler_2fcheck_2ecompiler_2fcheck_3aChecker_2eInstNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
