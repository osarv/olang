; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64, ptr }
%olang.home = type { ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/source:Span" = type { i32, i32 }
%"compiler/token:Token" = type { i32, i8, i32, i32 }
%"compiler/parse:Parser" = type { ptr, ptr, ptr, ptr, ptr, i64, i64, i32, i32, i32, i32, i1, i1, i1, i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, i64, i1, i64, i1, i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i1, i1, i1, i1 }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/ast:Chain" = type { { i64, ptr }, { i64, ptr } }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/parse:stackMarks" = type { i64, i64, i64, i64, i64, i64, i64 }
%"compiler/ast:CaseDecl" = type { %"compiler/source:Span", i32, { i64, ptr }, i1, ptr }
%"compiler/ast:Multi" = type { { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/ast:VarDecl" = type { { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, i1, i1, i1 }
%"compiler/parse:NameList" = type { { i64, ptr }, { i64, ptr } }
%"compiler/ast:TypeDecl" = type { i32, { i64, ptr }, i1, ptr, i32, i1, ptr, i32 }
%"compiler/ast:ForIn" = type { i32, i32, ptr, i1, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/ast:For3" = type { ptr, ptr, ptr, { i64, ptr } }
%"compiler/ast:Sig" = type { { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1, { i64, ptr }, i1 }
%"compiler/ast:If" = type { ptr, ptr, ptr }
%"compiler/ast:Branch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/scan:Tokens" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/source:Source" = type { { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/ast:Case" = type { %"compiler/source:Span", { i64, ptr }, { i64, ptr }, ptr, { i64, ptr }, ptr }
%"compiler/ast:Match" = type { %"compiler/source:Span", ptr, i1, { i64, ptr } }
%"compiler/ast:Param" = type { %"compiler/source:Span", i32, ptr, ptr }
%"compiler/parse:Oracle" = type { %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/ast:Promise" = type { %"compiler/source:Span", i32, { i64, ptr } }
%"compiler/ast:TopBranch" = type { %"compiler/source:Span", { i64, ptr }, i64 }
%"compiler/source:Names" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
define dso_local i1 @compiler_2fparse_2ecomparison(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i1
  %l10 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  store i1 false, ptr %l3, !tbaa !21
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 5
  store i1 %t8, ptr %l3, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l3, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 116}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb22
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 95 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb6, label %bb7
bb6:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t23 = trunc i64 96 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  %t26 = load i1, ptr %l10, !tbaa !21
  br i1 %t26, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb11
bb10:
  %t27 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t29 = trunc i64 28 to i32
  %t30 = icmp eq i32 %t27, %t29
  store i1 %t30, ptr %l13, !tbaa !21
  br label %bb11
bb11:
  %t32 = load i1, ptr %l13, !tbaa !21
  br i1 %t32, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb14
bb13:
  %t33 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t35 = trunc i64 106 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l16, !tbaa !21
  br label %bb14
bb14:
  %t38 = load i1, ptr %l16, !tbaa !21
  br i1 %t38, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb18
bb16:
  %t39 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t41 = call i1 @compiler_2fparse_2eisOrdering(i32 %t39)
  store i1 %t41, ptr %l21
  br label %bb17
bb17:
  %t42 = load i1, ptr %l21, !tbaa !21
  store i1 %t42, ptr %l19, !tbaa !21
  br label %bb18
bb18:
  %t43 = load i1, ptr %l19, !tbaa !21
  br i1 %t43, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb21
bb20:
  %t44 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t46 = trunc i64 27 to i32
  %t47 = icmp eq i32 %t44, %t46
  store i1 %t47, ptr %l22, !tbaa !21
  br label %bb21
bb21:
  %t49 = load i1, ptr %l22, !tbaa !21
  store i1 %t49, ptr %rv
  br label %ret
bb22:
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l25, !tbaa !29
  store i1 false, ptr %l26, !tbaa !21
  %t51 = load ptr, ptr %l25, !tbaa !29
  %t52 = icmp ne ptr %t51, null
  br i1 %t52, label %bb23, label %bb24
bb23:
  %t54 = load ptr, ptr %l25, !tbaa !29
  %t55 = load i64, ptr %t54, !range !{i64 0, i64 28}
  %t57 = icmp eq i64 %t55, 7
  store i1 %t57, ptr %l26, !tbaa !21
  br label %bb24
bb24:
  %t58 = load i1, ptr %l26, !tbaa !21
  br i1 %t58, label %bb25, label %bb26
bb25:
  br label %bb31
bb26:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l29, !tbaa !29
  store i1 false, ptr %l30, !tbaa !21
  %t60 = load ptr, ptr %l29, !tbaa !29
  %t61 = icmp ne ptr %t60, null
  br i1 %t61, label %bb27, label %bb28
bb27:
  %t63 = load ptr, ptr %l29, !tbaa !29
  %t64 = load i64, ptr %t63, !range !{i64 0, i64 28}
  %t66 = icmp eq i64 %t64, 6
  store i1 %t66, ptr %l30, !tbaa !21
  br label %bb28
bb28:
  %t67 = load i1, ptr %l30, !tbaa !21
  br i1 %t67, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store i1 true, ptr %rv
  br label %ret
bb32:
  br i1 true, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store i1 false, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @olang_loc_1b8b9060a075dfbb_f19ba567ef63a0af)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l33 = alloca i64
  %l36 = alloca i1
  %l41 = alloca i1
  %l43 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l54 = alloca i1
  %l56 = alloca i32
  %l60 = alloca %"compiler/token:Token"
  %l62 = alloca i32
  %l64 = alloca i32
  %l65 = alloca i32
  %l69 = alloca ptr
  %l79 = alloca i32
  %l80 = alloca ptr
  %l82 = alloca ptr
  %l83 = alloca i32
  %l87 = alloca ptr
  %l97 = alloca ptr
  %l100 = alloca %"compiler/source:Span"
  %l105 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca i32
  %l112 = alloca ptr
  %l122 = alloca i1
  %l124 = alloca %"compiler/source:Span"
  %l126 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i32
  %l136 = alloca ptr
  %l148 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i32
  %l156 = alloca ptr
  %l169 = alloca ptr
  %l177 = alloca i1
  %l182 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l186 = alloca i32
  %l191 = alloca i32
  %l195 = alloca { i64, ptr }
  %s23 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t91 = alloca { i64, [4 x i64] }, align 8
  %t211 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 110)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l16
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l15
  br label %bb1
bb1:
  %t9 = load i32, ptr %l15, !tbaa !23
  store i32 %t9, ptr %l12, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l16, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t18, 0
  store { i32, { i64, ptr } } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 11
  %t24 = load i1, ptr %t23, !tbaa !21
  store i1 %t24, ptr %l1, !tbaa !21
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 11
  store i1 false, ptr %t28, !tbaa !21
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l21, !tbaa !29
  %t30 = load ptr, ptr %l21, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 21
  %t32 = load i64, ptr %t31, !tbaa !24
  %t35 = add i64 %t32, 1
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 21
  store i64 %t35, ptr %t38, !tbaa !24
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/parse:Parser", ptr %t39, i32 0, i32 22
  %t42 = load i1, ptr %t41, !tbaa !21
  store i1 %t42, ptr %l2, !tbaa !21
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = getelementptr %"compiler/parse:Parser", ptr %t44, i32 0, i32 23
  %t47 = load i1, ptr %t46, !tbaa !21
  store i1 %t47, ptr %l3, !tbaa !21
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 22
  store i1 false, ptr %t51, !tbaa !21
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 23
  store i1 true, ptr %t54, !tbaa !21
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/parse:Parser", ptr %t55, i32 0, i32 34
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t57)
  store i64 %t59, ptr %l33
  br label %bb4
bb4:
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t64 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t61, i32 111)
  store i1 %t64, ptr %l36
  br label %bb6
bb6:
  %t65 = load i1, ptr %l36, !tbaa !21
  %t66 = xor i1 %t65, true
  %t68 = xor i1 %t66, true
  br i1 %t68, label %bb7, label %bb8
bb7:
  br label %bb64
bb8:
  br label %bb9
bb9:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t73 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t70, i32 44)
  store i1 %t73, ptr %l41
  br label %bb10
bb10:
  %t74 = load i1, ptr %l41, !tbaa !21
  br i1 %t74, label %bb11, label %bb12
bb11:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t75)
  store i32 %t77, ptr %l43
  br label %bb13
bb12:
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t78, i32 1)
  store i1 %t81, ptr %l53
  br label %bb16
bb13:
  %t82 = load i32, ptr %l43, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 34
  store ptr %t85, ptr %l45, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t90 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t86, i32 %t82)
  store %"compiler/source:Span" %t90, ptr %l48
  br label %bb14
bb14:
  store { i64, [4 x i64] } zeroinitializer, ptr %t91
  %t92 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 0
  store i64 23, ptr %t92
  %t93 = load %"compiler/source:Span", ptr %l48
  %t94 = insertvalue { %"compiler/source:Span" } undef, %"compiler/source:Span" %t93, 0
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t91, i32 0, i32 1
  store { %"compiler/source:Span" } %t94, ptr %t95
  %t96 = load { i64, [4 x i64] }, ptr %t91
  %t98 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t96, ptr %t98
  %t99 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t99, ptr %t98)
  br label %bb15
bb15:
  br label %bb54
bb16:
  %t101 = load i1, ptr %l53, !tbaa !21
  br i1 %t101, label %bb17, label %bb18
bb17:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t102, i64 1)
  store i32 %t104, ptr %l56
  br label %bb19
bb18:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb20
bb19:
  %t105 = load i32, ptr %l56, !range !{i32 0, i32 116}
  %t107 = trunc i64 78 to i32
  %t108 = icmp eq i32 %t105, %t107
  store i1 %t108, ptr %l54, !tbaa !21
  br label %bb20
bb20:
  %t110 = load i1, ptr %l54, !tbaa !21
  br i1 %t110, label %bb21, label %bb22
bb21:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t111)
  store %"compiler/token:Token" %t113, ptr %l60
  br label %bb23
bb22:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t114)
  %t117 = extractvalue { i32, ptr } %t116, 1
  %t118 = extractvalue { i32, ptr } %t116, 0
  store i32 %t118, ptr %l108
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb38, label %ok.120, !prof !99
ok.120:
  store ptr %t117, ptr %l107
  br label %bb37
bb23:
  %t121 = getelementptr %"compiler/token:Token", ptr %l60, i32 0, i32 2
  %t122 = load i32, ptr %t121, !tbaa !23
  store i32 %t122, ptr %l6, !tbaa !23
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t124)
  %t127 = extractvalue { i32, i32 } %t126, 1
  %t128 = extractvalue { i32, i32 } %t126, 0
  store i32 %t128, ptr %l65
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb25, label %ok.130, !prof !99
ok.130:
  store i32 %t127, ptr %l64
  br label %bb24
bb24:
  %t131 = load i32, ptr %l64, !tbaa !23
  store i32 %t131, ptr %l62, !tbaa !23
  br label %bb28
bb25:
  br label %bb26
bb26:
  %t132 = load ptr, ptr %l0, !tbaa !29
  %t134 = getelementptr %"compiler/parse:Parser", ptr %t132, i32 0, i32 34
  %t135 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t134, i64 %t135)
  br label %bb27
bb27:
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l69, !tbaa !29
  %t139 = load ptr, ptr %l69, !tbaa !29
  %t140 = getelementptr %"compiler/parse:Parser", ptr %t139, i32 0, i32 21
  %t141 = load i64, ptr %t140, !tbaa !24
  %t144 = sub i64 %t141, 1
  %t146 = load ptr, ptr %l69, !tbaa !29
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t146, i32 0, i32 21
  store i64 %t144, ptr %t147, !tbaa !24
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i1, ptr %l2, !tbaa !21
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 22
  store i1 %t149, ptr %t152, !tbaa !21
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t154 = load i1, ptr %l3, !tbaa !21
  %t157 = getelementptr %"compiler/parse:Parser", ptr %t153, i32 0, i32 23
  store i1 %t154, ptr %t157, !tbaa !21
  %t159 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t159, ptr %rv
  br label %ret
bb28:
  %t160 = load i32, ptr %l62, !tbaa !23
  store i32 %t160, ptr %l7, !tbaa !23
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t163 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t161)
  store i32 %t163, ptr %l79
  br label %bb29
bb29:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t164)
  %t167 = extractvalue { i32, ptr } %t166, 1
  %t168 = extractvalue { i32, ptr } %t166, 0
  store i32 %t168, ptr %l83
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb31, label %ok.170, !prof !99
ok.170:
  store ptr %t167, ptr %l82
  br label %bb30
bb30:
  %t171 = load ptr, ptr %l82, !tbaa !29
  store ptr %t171, ptr %l80, !tbaa !29
  br label %bb34
bb31:
  br label %bb32
bb32:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = getelementptr %"compiler/parse:Parser", ptr %t172, i32 0, i32 34
  %t175 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t174, i64 %t175)
  br label %bb33
bb33:
  %t178 = load ptr, ptr %l0, !tbaa !29
  store ptr %t178, ptr %l87, !tbaa !29
  %t179 = load ptr, ptr %l87, !tbaa !29
  %t180 = getelementptr %"compiler/parse:Parser", ptr %t179, i32 0, i32 21
  %t181 = load i64, ptr %t180, !tbaa !24
  %t184 = sub i64 %t181, 1
  %t186 = load ptr, ptr %l87, !tbaa !29
  %t187 = getelementptr %"compiler/parse:Parser", ptr %t186, i32 0, i32 21
  store i64 %t184, ptr %t187, !tbaa !24
  %t188 = load ptr, ptr %l0, !tbaa !29
  %t189 = load i1, ptr %l2, !tbaa !21
  %t192 = getelementptr %"compiler/parse:Parser", ptr %t188, i32 0, i32 22
  store i1 %t189, ptr %t192, !tbaa !21
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i1, ptr %l3, !tbaa !21
  %t197 = getelementptr %"compiler/parse:Parser", ptr %t193, i32 0, i32 23
  store i1 %t194, ptr %t197, !tbaa !21
  %t199 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t199, ptr %rv
  br label %ret
bb34:
  %t200 = load ptr, ptr %l80, !tbaa !29
  store ptr %t200, ptr %l8, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/parse:Parser", ptr %t201, i32 0, i32 34
  store ptr %t203, ptr %l97, !tbaa !29
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i32, ptr %l6, !tbaa !23
  %t208 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t204, i32 %t205)
  store %"compiler/source:Span" %t208, ptr %l100
  br label %bb35
bb35:
  %t209 = load i32, ptr %l7, !tbaa !23
  %t210 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t211
  %t212 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 0
  store i64 24, ptr %t212
  %t213 = load %"compiler/source:Span", ptr %l100
  %t214 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t213, 0
  %t216 = insertvalue { %"compiler/source:Span", i32, ptr } %t214, i32 %t209, 1
  %t218 = insertvalue { %"compiler/source:Span", i32, ptr } %t216, ptr %t210, 2
  %t219 = getelementptr { i64, [4 x i64] }, ptr %t211, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t218, ptr %t219
  %t220 = load { i64, [4 x i64] }, ptr %t211
  %t222 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t220, ptr %t222
  %t223 = load ptr, ptr %l97, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t223, ptr %t222)
  br label %bb36
bb36:
  br label %bb53
bb37:
  %t225 = load ptr, ptr %l107, !tbaa !29
  store ptr %t225, ptr %l105, !tbaa !29
  br label %bb41
bb38:
  br label %bb39
bb39:
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t228 = getelementptr %"compiler/parse:Parser", ptr %t226, i32 0, i32 34
  %t229 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t228, i64 %t229)
  br label %bb40
bb40:
  %t232 = load ptr, ptr %l0, !tbaa !29
  store ptr %t232, ptr %l112, !tbaa !29
  %t233 = load ptr, ptr %l112, !tbaa !29
  %t234 = getelementptr %"compiler/parse:Parser", ptr %t233, i32 0, i32 21
  %t235 = load i64, ptr %t234, !tbaa !24
  %t238 = sub i64 %t235, 1
  %t240 = load ptr, ptr %l112, !tbaa !29
  %t241 = getelementptr %"compiler/parse:Parser", ptr %t240, i32 0, i32 21
  store i64 %t238, ptr %t241, !tbaa !24
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t243 = load i1, ptr %l2, !tbaa !21
  %t246 = getelementptr %"compiler/parse:Parser", ptr %t242, i32 0, i32 22
  store i1 %t243, ptr %t246, !tbaa !21
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i1, ptr %l3, !tbaa !21
  %t251 = getelementptr %"compiler/parse:Parser", ptr %t247, i32 0, i32 23
  store i1 %t248, ptr %t251, !tbaa !21
  %t253 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t253, ptr %rv
  br label %ret
bb41:
  %t254 = load ptr, ptr %l105, !tbaa !29
  store ptr %t254, ptr %l9, !tbaa !29
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t255)
  store i1 %t257, ptr %l122
  br label %bb42
bb42:
  %t258 = load i1, ptr %l122, !tbaa !21
  br i1 %t258, label %bb43, label %bb44
bb43:
  %t259 = load ptr, ptr %l9, !tbaa !29
  %t261 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t259)
  store %"compiler/source:Span" %t261, ptr %l124
  br label %bb45
bb44:
  br label %bb51
bb45:
  %t262 = getelementptr %"compiler/source:Span", ptr %l124, i32 0, i32 0
  %t263 = load i32, ptr %t262, !tbaa !23
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = load ptr, ptr %l9, !tbaa !29
  %t272 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %t265, i32 %t263, ptr null, ptr %t267, i32 111)
  %t273 = extractvalue { i32, ptr } %t272, 1
  %t274 = extractvalue { i32, ptr } %t272, 0
  store i32 %t274, ptr %l132
  %t275 = icmp ne i32 %t274, 0
  br i1 %t275, label %bb47, label %ok.276, !prof !99
ok.276:
  store ptr %t273, ptr %l131
  br label %bb46
bb46:
  %t277 = load ptr, ptr %l131, !tbaa !29
  store ptr %t277, ptr %l126, !tbaa !29
  br label %bb50
bb47:
  br label %bb48
bb48:
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t280 = getelementptr %"compiler/parse:Parser", ptr %t278, i32 0, i32 34
  %t281 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t280, i64 %t281)
  br label %bb49
bb49:
  %t284 = load ptr, ptr %l0, !tbaa !29
  store ptr %t284, ptr %l136, !tbaa !29
  %t285 = load ptr, ptr %l136, !tbaa !29
  %t286 = getelementptr %"compiler/parse:Parser", ptr %t285, i32 0, i32 21
  %t287 = load i64, ptr %t286, !tbaa !24
  %t290 = sub i64 %t287, 1
  %t292 = load ptr, ptr %l136, !tbaa !29
  %t293 = getelementptr %"compiler/parse:Parser", ptr %t292, i32 0, i32 21
  store i64 %t290, ptr %t293, !tbaa !24
  %t294 = load ptr, ptr %l0, !tbaa !29
  %t295 = load i1, ptr %l2, !tbaa !21
  %t298 = getelementptr %"compiler/parse:Parser", ptr %t294, i32 0, i32 22
  store i1 %t295, ptr %t298, !tbaa !21
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t300 = load i1, ptr %l3, !tbaa !21
  %t303 = getelementptr %"compiler/parse:Parser", ptr %t299, i32 0, i32 23
  store i1 %t300, ptr %t303, !tbaa !21
  %t305 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t305, ptr %rv
  br label %ret
bb50:
  %t306 = load ptr, ptr %l126, !tbaa !29
  store ptr %t306, ptr %l9, !tbaa !29
  br label %bb51
bb51:
  %t307 = load ptr, ptr %l0, !tbaa !29
  %t309 = getelementptr %"compiler/parse:Parser", ptr %t307, i32 0, i32 34
  %t310 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t309, ptr %t310)
  br label %bb52
bb52:
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t316 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t313, i32 111)
  %t317 = extractvalue { i32, i1 } %t316, 1
  %t318 = extractvalue { i32, i1 } %t316, 0
  store i32 %t318, ptr %l152
  %t319 = icmp ne i32 %t318, 0
  br i1 %t319, label %bb56, label %ok.320, !prof !99
ok.320:
  store i1 %t317, ptr %l151
  br label %bb55
bb55:
  %t321 = load i1, ptr %l151, !tbaa !21
  store i1 %t321, ptr %l148, !tbaa !21
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t322 = load ptr, ptr %l0, !tbaa !29
  %t324 = getelementptr %"compiler/parse:Parser", ptr %t322, i32 0, i32 34
  %t325 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t324, i64 %t325)
  br label %bb58
bb58:
  %t328 = load ptr, ptr %l0, !tbaa !29
  store ptr %t328, ptr %l156, !tbaa !29
  %t329 = load ptr, ptr %l156, !tbaa !29
  %t330 = getelementptr %"compiler/parse:Parser", ptr %t329, i32 0, i32 21
  %t331 = load i64, ptr %t330, !tbaa !24
  %t334 = sub i64 %t331, 1
  %t336 = load ptr, ptr %l156, !tbaa !29
  %t337 = getelementptr %"compiler/parse:Parser", ptr %t336, i32 0, i32 21
  store i64 %t334, ptr %t337, !tbaa !24
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load i1, ptr %l2, !tbaa !21
  %t342 = getelementptr %"compiler/parse:Parser", ptr %t338, i32 0, i32 22
  store i1 %t339, ptr %t342, !tbaa !21
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t344 = load i1, ptr %l3, !tbaa !21
  %t347 = getelementptr %"compiler/parse:Parser", ptr %t343, i32 0, i32 23
  store i1 %t344, ptr %t347, !tbaa !21
  %t349 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t349, ptr %rv
  br label %ret
bb59:
  %t350 = load i1, ptr %l148, !tbaa !21
  %t353 = xor i1 %t350, true
  br i1 %t353, label %bb60, label %bb61
bb60:
  br label %bb64
bb61:
  br label %bb62
bb62:
  br label %bb63
bb63:
  br label %bb5
bb64:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t356 = load i1, ptr %l2, !tbaa !21
  %t359 = getelementptr %"compiler/parse:Parser", ptr %t355, i32 0, i32 22
  store i1 %t356, ptr %t359, !tbaa !21
  %t360 = load ptr, ptr %l0, !tbaa !29
  store ptr %t360, ptr %l169, !tbaa !29
  %t361 = load ptr, ptr %l169, !tbaa !29
  %t362 = getelementptr %"compiler/parse:Parser", ptr %t361, i32 0, i32 21
  %t363 = load i64, ptr %t362, !tbaa !24
  %t366 = sub i64 %t363, 1
  %t368 = load ptr, ptr %l169, !tbaa !29
  %t369 = getelementptr %"compiler/parse:Parser", ptr %t368, i32 0, i32 21
  store i64 %t366, ptr %t369, !tbaa !24
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i1, ptr %l1, !tbaa !21
  %t374 = getelementptr %"compiler/parse:Parser", ptr %t370, i32 0, i32 11
  store i1 %t371, ptr %t374, !tbaa !21
  %t375 = load ptr, ptr %l0, !tbaa !29
  %t378 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t375, i32 111)
  store i1 %t378, ptr %l177
  br label %bb65
bb65:
  %t379 = load i1, ptr %l177, !tbaa !21
  %t380 = xor i1 %t379, true
  br i1 %t380, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s23
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = getelementptr %"compiler/parse:Parser", ptr %t382, i32 0, i32 34
  %t385 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t384, i64 %t385)
  br label %bb68
bb67:
  br label %bb73
bb68:
  %t388 = load ptr, ptr %l0, !tbaa !29
  store ptr %t388, ptr %l182, !tbaa !29
  %t390 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s23, i32 111)
  store { i64, ptr } %t390, ptr %l184
  br label %bb69
bb69:
  %t391 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t392 = load ptr, ptr %l182, !tbaa !29
  %t394 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s23, ptr %t392, { i64, ptr } %t391)
  store i32 %t394, ptr %l186
  %t395 = icmp ne i32 %t394, 0
  br i1 %t395, label %bb71, label %ok.396, !prof !99
ok.396:
  br label %bb70
bb70:
  br label %bb72
bb71:
  %t397 = load i32, ptr %l186, !tbaa !23
  %t398 = lshr i32 %t397, 16
  %t399 = and i32 %t397, 65535
  %t400 = icmp eq i32 %t398, 1
  %t401 = select i1 %t400, i32 1, i32 0
  %t402 = icmp eq i32 %t397, 0
  %t403 = shl i32 %t401, 16
  %t404 = or i32 %t403, %t399
  %t405 = select i1 %t402, i32 0, i32 %t404
  call void @__olang_scope_close(ptr %s23)
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t407 = load i1, ptr %l3, !tbaa !21
  %t410 = getelementptr %"compiler/parse:Parser", ptr %t406, i32 0, i32 23
  store i1 %t407, ptr %t410, !tbaa !21
  %t412 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t405, 0
  store { i32, { i64, ptr } } %t412, ptr %rv
  br label %ret
bb72:
  call void @__olang_scope_close(ptr %s23)
  br label %bb73
bb73:
  %t413 = load ptr, ptr %l0, !tbaa !29
  %t415 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t413)
  store i32 %t415, ptr %l191
  br label %bb74
bb74:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr %"compiler/parse:Parser", ptr %t416, i32 0, i32 34
  %t419 = load i64, ptr %l4, !tbaa !24
  %t422 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t418, i64 %t419)
  store { i64, ptr } %t422, ptr %l195
  br label %bb75
bb75:
  %t423 = load ptr, ptr %l0, !tbaa !29
  %t424 = load i1, ptr %l3, !tbaa !21
  %t427 = getelementptr %"compiler/parse:Parser", ptr %t423, i32 0, i32 23
  store i1 %t424, ptr %t427, !tbaa !21
  %t428 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t429 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t428, 1
  store { i32, { i64, ptr } } %t429, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebareLit(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca i32
  %l12 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l21 = alloca ptr
  %l33 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l39 = alloca i32
  %l43 = alloca i32
  %l45 = alloca ptr
  %l48 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i1
  %l61 = alloca i1
  %l62 = alloca ptr
  %l64 = alloca { i64, ptr }
  %l66 = alloca i32
  %l68 = alloca ptr
  %l78 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca i32
  %l83 = alloca ptr
  %l94 = alloca i1
  %l95 = alloca ptr
  %l100 = alloca ptr
  %l101 = alloca i32
  %l103 = alloca ptr
  %l113 = alloca ptr
  %l125 = alloca i1
  %l127 = alloca ptr
  %l130 = alloca ptr
  %l131 = alloca i32
  %l133 = alloca ptr
  %l144 = alloca i1
  %l146 = alloca i1
  %l147 = alloca ptr
  %l152 = alloca ptr
  %l153 = alloca i32
  %l155 = alloca ptr
  %l165 = alloca ptr
  %l178 = alloca i1
  %l181 = alloca i1
  %l182 = alloca i32
  %l184 = alloca ptr
  %l195 = alloca ptr
  %l197 = alloca ptr
  %l198 = alloca i32
  %l200 = alloca ptr
  %l211 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca i32
  %l217 = alloca ptr
  %l232 = alloca i1
  %l237 = alloca ptr
  %l239 = alloca { i64, ptr }
  %l241 = alloca i32
  %l243 = alloca ptr
  %l254 = alloca i32
  %l257 = alloca %"compiler/source:Span"
  %l261 = alloca { i64, ptr }
  %l264 = alloca ptr
  %s4 = alloca %olang.scope
  %s30 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t95 = alloca { i64, [4 x i64] }, align 8
  %t655 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t5, i32 112)
  %t9 = extractvalue { i32, i32 } %t8, 1
  %t10 = extractvalue { i32, i32 } %t8, 0
  store i32 %t10, ptr %l16
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb3, label %ok.12, !prof !99
ok.12:
  store i32 %t9, ptr %l15
  br label %bb2
bb2:
  %t13 = load i32, ptr %l15, !tbaa !23
  store i32 %t13, ptr %l12, !tbaa !23
  br label %bb4
bb3:
  %t14 = load i32, ptr %l16, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, ptr } zeroinitializer, i32 %t22, 0
  store { i32, ptr } %t24, ptr %rv
  br label %ret
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 11
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 11
  store i1 false, ptr %t32, !tbaa !21
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  %t34 = load ptr, ptr %l21, !tbaa !29
  %t35 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 21
  %t36 = load i64, ptr %t35, !tbaa !24
  %t39 = add i64 %t36, 1
  %t41 = load ptr, ptr %l21, !tbaa !29
  %t42 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 21
  store i64 %t39, ptr %t42, !tbaa !24
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 22
  %t46 = load i1, ptr %t45, !tbaa !21
  store i1 %t46, ptr %l3, !tbaa !21
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 23
  %t51 = load i1, ptr %t50, !tbaa !21
  store i1 %t51, ptr %l4, !tbaa !21
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 22
  store i1 false, ptr %t55, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 23
  store i1 true, ptr %t58, !tbaa !21
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 34
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t61)
  store i64 %t63, ptr %l33
  br label %bb5
bb5:
  %t64 = load i64, ptr %l33, !tbaa !24
  store i64 %t64, ptr %l5, !tbaa !24
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t68 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t65, i32 79)
  store i1 %t68, ptr %l36
  br label %bb6
bb6:
  %t69 = load i1, ptr %l36, !tbaa !21
  br i1 %t69, label %bb7, label %bb8
bb7:
  %t70 = load ptr, ptr %l0, !tbaa !29
  %t72 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t70, i64 1)
  store i32 %t72, ptr %l39
  br label %bb9
bb8:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb10
bb9:
  %t73 = load i32, ptr %l39, !range !{i32 0, i32 116}
  %t75 = trunc i64 113 to i32
  %t76 = icmp eq i32 %t73, %t75
  store i1 %t76, ptr %l37, !tbaa !21
  br label %bb10
bb10:
  %t78 = load i1, ptr %l37, !tbaa !21
  br i1 %t78, label %bb11, label %bb12
bb11:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t79)
  store i32 %t81, ptr %l43
  br label %bb13
bb12:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t85 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t82, i32 113)
  store i1 %t85, ptr %l53
  br label %bb16
bb13:
  %t86 = load i32, ptr %l43, !tbaa !23
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 34
  store ptr %t89, ptr %l45, !tbaa !29
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t94 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t90, i32 %t86)
  store %"compiler/source:Span" %t94, ptr %l48
  br label %bb14
bb14:
  store { i64, [4 x i64] } zeroinitializer, ptr %t95
  %t96 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 0
  store i64 15, ptr %t96
  %t97 = load %"compiler/source:Span", ptr %l48
  %t98 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t97, 0
  %t99 = insertvalue { %"compiler/source:Span", ptr, ptr } %t98, ptr null, 1
  %t100 = insertvalue { %"compiler/source:Span", ptr, ptr } %t99, ptr null, 2
  %t101 = getelementptr { i64, [4 x i64] }, ptr %t95, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t100, ptr %t101
  %t102 = load { i64, [4 x i64] }, ptr %t95
  %t104 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t102, ptr %t104
  %t105 = load ptr, ptr %l45, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t105, ptr %t104)
  br label %bb15
bb15:
  br label %bb79
bb16:
  %t107 = load i1, ptr %l53, !tbaa !21
  %t108 = xor i1 %t107, true
  br i1 %t108, label %bb17, label %bb18
bb17:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t113 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t110, i32 111)
  store i1 %t113, ptr %l57
  br label %bb19
bb18:
  br label %bb78
bb19:
  %t114 = load i1, ptr %l57, !tbaa !21
  br i1 %t114, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l58, !tbaa !21
  br label %bb23
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t118 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t115, i32 115)
  store i1 %t118, ptr %l61
  br label %bb22
bb22:
  %t119 = load i1, ptr %l61, !tbaa !21
  store i1 %t119, ptr %l58, !tbaa !21
  br label %bb23
bb23:
  %t120 = load i1, ptr %l58, !tbaa !21
  br i1 %t120, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t121 = load ptr, ptr %l0, !tbaa !29
  store ptr %t121, ptr %l62, !tbaa !29
  %t123 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 113)
  store { i64, ptr } %t123, ptr %l64
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t124 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t125 = load ptr, ptr %l62, !tbaa !29
  %t127 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t125, { i64, ptr } %t124)
  store i32 %t127, ptr %l66
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb28, label %ok.129, !prof !99
ok.129:
  br label %bb27
bb27:
  br label %bb29
bb28:
  %t130 = load i32, ptr %l66, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  call void @__olang_scope_close(ptr %s4)
  %t139 = load ptr, ptr %l0, !tbaa !29
  store ptr %t139, ptr %l68, !tbaa !29
  %t140 = load ptr, ptr %l68, !tbaa !29
  %t141 = getelementptr %"compiler/parse:Parser", ptr %t140, i32 0, i32 21
  %t142 = load i64, ptr %t141, !tbaa !24
  %t145 = sub i64 %t142, 1
  %t147 = load ptr, ptr %l68, !tbaa !29
  %t148 = getelementptr %"compiler/parse:Parser", ptr %t147, i32 0, i32 21
  store i64 %t145, ptr %t148, !tbaa !24
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t150 = load i1, ptr %l2, !tbaa !21
  %t153 = getelementptr %"compiler/parse:Parser", ptr %t149, i32 0, i32 11
  store i1 %t150, ptr %t153, !tbaa !21
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i1, ptr %l3, !tbaa !21
  %t158 = getelementptr %"compiler/parse:Parser", ptr %t154, i32 0, i32 22
  store i1 %t155, ptr %t158, !tbaa !21
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i1, ptr %l4, !tbaa !21
  %t163 = getelementptr %"compiler/parse:Parser", ptr %t159, i32 0, i32 23
  store i1 %t160, ptr %t163, !tbaa !21
  %t165 = insertvalue { i32, ptr } zeroinitializer, i32 %t138, 0
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb30:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v1, ptr %t166)
  %t169 = extractvalue { i32, ptr } %t168, 1
  %t170 = extractvalue { i32, ptr } %t168, 0
  store i32 %t170, ptr %l81
  %t171 = icmp ne i32 %t170, 0
  br i1 %t171, label %bb32, label %ok.172, !prof !99
ok.172:
  store ptr %t169, ptr %l80
  br label %bb31
bb31:
  %t173 = load ptr, ptr %l80, !tbaa !29
  store ptr %t173, ptr %l78, !tbaa !29
  br label %bb33
bb32:
  %t174 = load i32, ptr %l81, !tbaa !23
  %t175 = lshr i32 %t174, 16
  %t176 = and i32 %t174, 65535
  %t177 = icmp eq i32 %t175, 1
  %t178 = select i1 %t177, i32 1, i32 0
  %t179 = icmp eq i32 %t174, 0
  %t180 = shl i32 %t178, 16
  %t181 = or i32 %t180, %t176
  %t182 = select i1 %t179, i32 0, i32 %t181
  %t183 = load ptr, ptr %l0, !tbaa !29
  store ptr %t183, ptr %l83, !tbaa !29
  %t184 = load ptr, ptr %l83, !tbaa !29
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t184, i32 0, i32 21
  %t186 = load i64, ptr %t185, !tbaa !24
  %t189 = sub i64 %t186, 1
  %t191 = load ptr, ptr %l83, !tbaa !29
  %t192 = getelementptr %"compiler/parse:Parser", ptr %t191, i32 0, i32 21
  store i64 %t189, ptr %t192, !tbaa !24
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i1, ptr %l2, !tbaa !21
  %t197 = getelementptr %"compiler/parse:Parser", ptr %t193, i32 0, i32 11
  store i1 %t194, ptr %t197, !tbaa !21
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load i1, ptr %l3, !tbaa !21
  %t202 = getelementptr %"compiler/parse:Parser", ptr %t198, i32 0, i32 22
  store i1 %t199, ptr %t202, !tbaa !21
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t204 = load i1, ptr %l4, !tbaa !21
  %t207 = getelementptr %"compiler/parse:Parser", ptr %t203, i32 0, i32 23
  store i1 %t204, ptr %t207, !tbaa !21
  %t209 = insertvalue { i32, ptr } zeroinitializer, i32 %t182, 0
  store { i32, ptr } %t209, ptr %rv
  br label %ret
bb33:
  %t210 = load ptr, ptr %l78, !tbaa !29
  store ptr %t210, ptr %l7, !tbaa !29
  %t211 = load ptr, ptr %l0, !tbaa !29
  %t213 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t211)
  store i1 %t213, ptr %l94
  br label %bb34
bb34:
  %t214 = load i1, ptr %l94, !tbaa !21
  br i1 %t214, label %bb35, label %bb36
bb35:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i32, ptr %l1, !tbaa !23
  %t217 = load ptr, ptr %l7, !tbaa !29
  %t222 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t215, i32 %t216, ptr null, ptr %t217, i32 113)
  %t223 = extractvalue { i32, ptr } %t222, 1
  %t224 = extractvalue { i32, ptr } %t222, 0
  store i32 %t224, ptr %l101
  %t225 = icmp ne i32 %t224, 0
  br i1 %t225, label %bb38, label %ok.226, !prof !99
ok.226:
  store ptr %t223, ptr %l100
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t227 = load ptr, ptr %l100, !tbaa !29
  store ptr %t227, ptr %l95, !tbaa !29
  br label %bb39
bb38:
  %t228 = load i32, ptr %l101, !tbaa !23
  %t229 = lshr i32 %t228, 16
  %t230 = and i32 %t228, 65535
  %t231 = icmp eq i32 %t229, 1
  %t232 = select i1 %t231, i32 1, i32 0
  %t233 = icmp eq i32 %t228, 0
  %t234 = shl i32 %t232, 16
  %t235 = or i32 %t234, %t230
  %t236 = select i1 %t233, i32 0, i32 %t235
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l103, !tbaa !29
  %t238 = load ptr, ptr %l103, !tbaa !29
  %t239 = getelementptr %"compiler/parse:Parser", ptr %t238, i32 0, i32 21
  %t240 = load i64, ptr %t239, !tbaa !24
  %t243 = sub i64 %t240, 1
  %t245 = load ptr, ptr %l103, !tbaa !29
  %t246 = getelementptr %"compiler/parse:Parser", ptr %t245, i32 0, i32 21
  store i64 %t243, ptr %t246, !tbaa !24
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load i1, ptr %l2, !tbaa !21
  %t251 = getelementptr %"compiler/parse:Parser", ptr %t247, i32 0, i32 11
  store i1 %t248, ptr %t251, !tbaa !21
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t253 = load i1, ptr %l3, !tbaa !21
  %t256 = getelementptr %"compiler/parse:Parser", ptr %t252, i32 0, i32 22
  store i1 %t253, ptr %t256, !tbaa !21
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t258 = load i1, ptr %l4, !tbaa !21
  %t261 = getelementptr %"compiler/parse:Parser", ptr %t257, i32 0, i32 23
  store i1 %t258, ptr %t261, !tbaa !21
  %t263 = insertvalue { i32, ptr } zeroinitializer, i32 %t236, 0
  store { i32, ptr } %t263, ptr %rv
  br label %ret
bb39:
  %t264 = load ptr, ptr %l0, !tbaa !29
  store ptr %t264, ptr %l113, !tbaa !29
  %t265 = load ptr, ptr %l113, !tbaa !29
  %t266 = getelementptr %"compiler/parse:Parser", ptr %t265, i32 0, i32 21
  %t267 = load i64, ptr %t266, !tbaa !24
  %t270 = sub i64 %t267, 1
  %t272 = load ptr, ptr %l113, !tbaa !29
  %t273 = getelementptr %"compiler/parse:Parser", ptr %t272, i32 0, i32 21
  store i64 %t270, ptr %t273, !tbaa !24
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i1, ptr %l2, !tbaa !21
  %t278 = getelementptr %"compiler/parse:Parser", ptr %t274, i32 0, i32 11
  store i1 %t275, ptr %t278, !tbaa !21
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i1, ptr %l3, !tbaa !21
  %t283 = getelementptr %"compiler/parse:Parser", ptr %t279, i32 0, i32 22
  store i1 %t280, ptr %t283, !tbaa !21
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i1, ptr %l4, !tbaa !21
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 23
  store i1 %t285, ptr %t288, !tbaa !21
  %t289 = load ptr, ptr %l95, !tbaa !29
  %t290 = insertvalue { i32, ptr } zeroinitializer, ptr %t289, 1
  store { i32, ptr } %t290, ptr %rv
  br label %ret
bb40:
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t294 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t291, i32 79)
  store i1 %t294, ptr %l125
  br label %bb41
bb41:
  %t295 = load i1, ptr %l125, !tbaa !21
  store i1 %t295, ptr %l8, !tbaa !21
  %t296 = load i1, ptr %l8, !tbaa !21
  br i1 %t296, label %bb42, label %bb43
bb42:
  %t298 = load ptr, ptr %l0, !tbaa !29
  %t299 = load ptr, ptr %l7, !tbaa !29
  %t302 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v1, ptr %v1, ptr %t298, ptr %t299)
  %t303 = extractvalue { i32, ptr } %t302, 1
  %t304 = extractvalue { i32, ptr } %t302, 0
  store i32 %t304, ptr %l131
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb45, label %ok.306, !prof !99
ok.306:
  store ptr %t303, ptr %l130
  br label %bb44
bb43:
  br label %bb47
bb44:
  %t307 = load ptr, ptr %l130, !tbaa !29
  store ptr %t307, ptr %l127, !tbaa !29
  br label %bb46
bb45:
  %t308 = load i32, ptr %l131, !tbaa !23
  %t309 = lshr i32 %t308, 16
  %t310 = and i32 %t308, 65535
  %t311 = icmp eq i32 %t309, 1
  %t312 = select i1 %t311, i32 1, i32 0
  %t313 = icmp eq i32 %t308, 0
  %t314 = shl i32 %t312, 16
  %t315 = or i32 %t314, %t310
  %t316 = select i1 %t313, i32 0, i32 %t315
  %t317 = load ptr, ptr %l0, !tbaa !29
  store ptr %t317, ptr %l133, !tbaa !29
  %t318 = load ptr, ptr %l133, !tbaa !29
  %t319 = getelementptr %"compiler/parse:Parser", ptr %t318, i32 0, i32 21
  %t320 = load i64, ptr %t319, !tbaa !24
  %t323 = sub i64 %t320, 1
  %t325 = load ptr, ptr %l133, !tbaa !29
  %t326 = getelementptr %"compiler/parse:Parser", ptr %t325, i32 0, i32 21
  store i64 %t323, ptr %t326, !tbaa !24
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i1, ptr %l2, !tbaa !21
  %t331 = getelementptr %"compiler/parse:Parser", ptr %t327, i32 0, i32 11
  store i1 %t328, ptr %t331, !tbaa !21
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i1, ptr %l3, !tbaa !21
  %t336 = getelementptr %"compiler/parse:Parser", ptr %t332, i32 0, i32 22
  store i1 %t333, ptr %t336, !tbaa !21
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i1, ptr %l4, !tbaa !21
  %t341 = getelementptr %"compiler/parse:Parser", ptr %t337, i32 0, i32 23
  store i1 %t338, ptr %t341, !tbaa !21
  %t343 = insertvalue { i32, ptr } zeroinitializer, i32 %t316, 0
  store { i32, ptr } %t343, ptr %rv
  br label %ret
bb46:
  %t344 = load ptr, ptr %l127, !tbaa !29
  store ptr %t344, ptr %l7, !tbaa !29
  br label %bb47
bb47:
  %t345 = load i1, ptr %l8, !tbaa !21
  br i1 %t345, label %bb48, label %bb49
bb48:
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %t347)
  store i1 %t349, ptr %l146
  br label %bb50
bb49:
  store i1 false, ptr %l144, !tbaa !21
  br label %bb51
bb50:
  %t350 = load i1, ptr %l146, !tbaa !21
  store i1 %t350, ptr %l144, !tbaa !21
  br label %bb51
bb51:
  %t351 = load i1, ptr %l144, !tbaa !21
  br i1 %t351, label %bb52, label %bb53
bb52:
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i32, ptr %l1, !tbaa !23
  %t354 = load ptr, ptr %l7, !tbaa !29
  %t359 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v1, ptr %v1, ptr %v1, ptr %t352, i32 %t353, ptr null, ptr %t354, i32 113)
  %t360 = extractvalue { i32, ptr } %t359, 1
  %t361 = extractvalue { i32, ptr } %t359, 0
  store i32 %t361, ptr %l153
  %t362 = icmp ne i32 %t361, 0
  br i1 %t362, label %bb55, label %ok.363, !prof !99
ok.363:
  store ptr %t360, ptr %l152
  br label %bb54
bb53:
  br label %bb57
bb54:
  %t364 = load ptr, ptr %l152, !tbaa !29
  store ptr %t364, ptr %l147, !tbaa !29
  br label %bb56
bb55:
  %t365 = load i32, ptr %l153, !tbaa !23
  %t366 = lshr i32 %t365, 16
  %t367 = and i32 %t365, 65535
  %t368 = icmp eq i32 %t366, 1
  %t369 = select i1 %t368, i32 1, i32 0
  %t370 = icmp eq i32 %t365, 0
  %t371 = shl i32 %t369, 16
  %t372 = or i32 %t371, %t367
  %t373 = select i1 %t370, i32 0, i32 %t372
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l155, !tbaa !29
  %t375 = load ptr, ptr %l155, !tbaa !29
  %t376 = getelementptr %"compiler/parse:Parser", ptr %t375, i32 0, i32 21
  %t377 = load i64, ptr %t376, !tbaa !24
  %t380 = sub i64 %t377, 1
  %t382 = load ptr, ptr %l155, !tbaa !29
  %t383 = getelementptr %"compiler/parse:Parser", ptr %t382, i32 0, i32 21
  store i64 %t380, ptr %t383, !tbaa !24
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t385 = load i1, ptr %l2, !tbaa !21
  %t388 = getelementptr %"compiler/parse:Parser", ptr %t384, i32 0, i32 11
  store i1 %t385, ptr %t388, !tbaa !21
  %t389 = load ptr, ptr %l0, !tbaa !29
  %t390 = load i1, ptr %l3, !tbaa !21
  %t393 = getelementptr %"compiler/parse:Parser", ptr %t389, i32 0, i32 22
  store i1 %t390, ptr %t393, !tbaa !21
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t395 = load i1, ptr %l4, !tbaa !21
  %t398 = getelementptr %"compiler/parse:Parser", ptr %t394, i32 0, i32 23
  store i1 %t395, ptr %t398, !tbaa !21
  %t400 = insertvalue { i32, ptr } zeroinitializer, i32 %t373, 0
  store { i32, ptr } %t400, ptr %rv
  br label %ret
bb56:
  %t401 = load ptr, ptr %l0, !tbaa !29
  store ptr %t401, ptr %l165, !tbaa !29
  %t402 = load ptr, ptr %l165, !tbaa !29
  %t403 = getelementptr %"compiler/parse:Parser", ptr %t402, i32 0, i32 21
  %t404 = load i64, ptr %t403, !tbaa !24
  %t407 = sub i64 %t404, 1
  %t409 = load ptr, ptr %l165, !tbaa !29
  %t410 = getelementptr %"compiler/parse:Parser", ptr %t409, i32 0, i32 21
  store i64 %t407, ptr %t410, !tbaa !24
  %t411 = load ptr, ptr %l0, !tbaa !29
  %t412 = load i1, ptr %l2, !tbaa !21
  %t415 = getelementptr %"compiler/parse:Parser", ptr %t411, i32 0, i32 11
  store i1 %t412, ptr %t415, !tbaa !21
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t417 = load i1, ptr %l3, !tbaa !21
  %t420 = getelementptr %"compiler/parse:Parser", ptr %t416, i32 0, i32 22
  store i1 %t417, ptr %t420, !tbaa !21
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t422 = load i1, ptr %l4, !tbaa !21
  %t425 = getelementptr %"compiler/parse:Parser", ptr %t421, i32 0, i32 23
  store i1 %t422, ptr %t425, !tbaa !21
  %t426 = load ptr, ptr %l147, !tbaa !29
  %t427 = insertvalue { i32, ptr } zeroinitializer, ptr %t426, 1
  store { i32, ptr } %t427, ptr %rv
  br label %ret
bb57:
  %t428 = load ptr, ptr %l0, !tbaa !29
  %t430 = getelementptr %"compiler/parse:Parser", ptr %t428, i32 0, i32 34
  %t431 = load ptr, ptr %l7, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t430, ptr %t431)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t437 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t434, i32 113)
  %t438 = extractvalue { i32, i1 } %t437, 1
  %t439 = extractvalue { i32, i1 } %t437, 0
  store i32 %t439, ptr %l182
  %t440 = icmp ne i32 %t439, 0
  br i1 %t440, label %bb61, label %ok.441, !prof !99
ok.441:
  store i1 %t438, ptr %l181
  br label %bb60
bb60:
  %t442 = load i1, ptr %l181, !tbaa !21
  store i1 %t442, ptr %l178, !tbaa !21
  br label %bb62
bb61:
  %t443 = load i32, ptr %l182, !tbaa !23
  %t444 = lshr i32 %t443, 16
  %t445 = and i32 %t443, 65535
  %t446 = icmp eq i32 %t444, 1
  %t447 = select i1 %t446, i32 1, i32 0
  %t448 = icmp eq i32 %t443, 0
  %t449 = shl i32 %t447, 16
  %t450 = or i32 %t449, %t445
  %t451 = select i1 %t448, i32 0, i32 %t450
  %t452 = load ptr, ptr %l0, !tbaa !29
  store ptr %t452, ptr %l184, !tbaa !29
  %t453 = load ptr, ptr %l184, !tbaa !29
  %t454 = getelementptr %"compiler/parse:Parser", ptr %t453, i32 0, i32 21
  %t455 = load i64, ptr %t454, !tbaa !24
  %t458 = sub i64 %t455, 1
  %t460 = load ptr, ptr %l184, !tbaa !29
  %t461 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 21
  store i64 %t458, ptr %t461, !tbaa !24
  %t462 = load ptr, ptr %l0, !tbaa !29
  %t463 = load i1, ptr %l2, !tbaa !21
  %t466 = getelementptr %"compiler/parse:Parser", ptr %t462, i32 0, i32 11
  store i1 %t463, ptr %t466, !tbaa !21
  %t467 = load ptr, ptr %l0, !tbaa !29
  %t468 = load i1, ptr %l3, !tbaa !21
  %t471 = getelementptr %"compiler/parse:Parser", ptr %t467, i32 0, i32 22
  store i1 %t468, ptr %t471, !tbaa !21
  %t472 = load ptr, ptr %l0, !tbaa !29
  %t473 = load i1, ptr %l4, !tbaa !21
  %t476 = getelementptr %"compiler/parse:Parser", ptr %t472, i32 0, i32 23
  store i1 %t473, ptr %t476, !tbaa !21
  %t478 = insertvalue { i32, ptr } zeroinitializer, i32 %t451, 0
  store { i32, ptr } %t478, ptr %rv
  br label %ret
bb62:
  %t479 = load i1, ptr %l178, !tbaa !21
  %t480 = xor i1 %t479, true
  br i1 %t480, label %bb63, label %bb64
bb63:
  br label %bb77
bb64:
  br label %bb65
bb65:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v0, ptr %t482)
  %t485 = extractvalue { i32, ptr } %t484, 1
  %t486 = extractvalue { i32, ptr } %t484, 0
  store i32 %t486, ptr %l198
  %t487 = icmp ne i32 %t486, 0
  br i1 %t487, label %bb67, label %ok.488, !prof !99
ok.488:
  store ptr %t485, ptr %l197
  br label %bb66
bb66:
  %t489 = load ptr, ptr %l197, !tbaa !29
  store ptr %t489, ptr %l195, !tbaa !29
  br label %bb68
bb67:
  %t490 = load i32, ptr %l198, !tbaa !23
  %t491 = lshr i32 %t490, 16
  %t492 = and i32 %t490, 65535
  %t493 = icmp eq i32 %t491, 1
  %t494 = select i1 %t493, i32 1, i32 0
  %t495 = icmp eq i32 %t490, 0
  %t496 = shl i32 %t494, 16
  %t497 = or i32 %t496, %t492
  %t498 = select i1 %t495, i32 0, i32 %t497
  %t499 = load ptr, ptr %l0, !tbaa !29
  store ptr %t499, ptr %l200, !tbaa !29
  %t500 = load ptr, ptr %l200, !tbaa !29
  %t501 = getelementptr %"compiler/parse:Parser", ptr %t500, i32 0, i32 21
  %t502 = load i64, ptr %t501, !tbaa !24
  %t505 = sub i64 %t502, 1
  %t507 = load ptr, ptr %l200, !tbaa !29
  %t508 = getelementptr %"compiler/parse:Parser", ptr %t507, i32 0, i32 21
  store i64 %t505, ptr %t508, !tbaa !24
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load i1, ptr %l2, !tbaa !21
  %t513 = getelementptr %"compiler/parse:Parser", ptr %t509, i32 0, i32 11
  store i1 %t510, ptr %t513, !tbaa !21
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i1, ptr %l3, !tbaa !21
  %t518 = getelementptr %"compiler/parse:Parser", ptr %t514, i32 0, i32 22
  store i1 %t515, ptr %t518, !tbaa !21
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load i1, ptr %l4, !tbaa !21
  %t523 = getelementptr %"compiler/parse:Parser", ptr %t519, i32 0, i32 23
  store i1 %t520, ptr %t523, !tbaa !21
  %t525 = insertvalue { i32, ptr } zeroinitializer, i32 %t498, 0
  store { i32, ptr } %t525, ptr %rv
  br label %ret
bb68:
  %t526 = load ptr, ptr %l195, !tbaa !29
  store ptr %t526, ptr %l9, !tbaa !29
  %t527 = load i1, ptr %l8, !tbaa !21
  br i1 %t527, label %bb69, label %bb70
bb69:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t530 = load ptr, ptr %l9, !tbaa !29
  %t533 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v0, ptr %v0, ptr %t529, ptr %t530)
  %t534 = extractvalue { i32, ptr } %t533, 1
  %t535 = extractvalue { i32, ptr } %t533, 0
  store i32 %t535, ptr %l215
  %t536 = icmp ne i32 %t535, 0
  br i1 %t536, label %bb72, label %ok.537, !prof !99
ok.537:
  store ptr %t534, ptr %l214
  br label %bb71
bb70:
  br label %bb74
bb71:
  %t538 = load ptr, ptr %l214, !tbaa !29
  store ptr %t538, ptr %l211, !tbaa !29
  br label %bb73
bb72:
  %t539 = load i32, ptr %l215, !tbaa !23
  %t540 = lshr i32 %t539, 16
  %t541 = and i32 %t539, 65535
  %t542 = icmp eq i32 %t540, 1
  %t543 = select i1 %t542, i32 1, i32 0
  %t544 = icmp eq i32 %t539, 0
  %t545 = shl i32 %t543, 16
  %t546 = or i32 %t545, %t541
  %t547 = select i1 %t544, i32 0, i32 %t546
  %t548 = load ptr, ptr %l0, !tbaa !29
  store ptr %t548, ptr %l217, !tbaa !29
  %t549 = load ptr, ptr %l217, !tbaa !29
  %t550 = getelementptr %"compiler/parse:Parser", ptr %t549, i32 0, i32 21
  %t551 = load i64, ptr %t550, !tbaa !24
  %t554 = sub i64 %t551, 1
  %t556 = load ptr, ptr %l217, !tbaa !29
  %t557 = getelementptr %"compiler/parse:Parser", ptr %t556, i32 0, i32 21
  store i64 %t554, ptr %t557, !tbaa !24
  %t558 = load ptr, ptr %l0, !tbaa !29
  %t559 = load i1, ptr %l2, !tbaa !21
  %t562 = getelementptr %"compiler/parse:Parser", ptr %t558, i32 0, i32 11
  store i1 %t559, ptr %t562, !tbaa !21
  %t563 = load ptr, ptr %l0, !tbaa !29
  %t564 = load i1, ptr %l3, !tbaa !21
  %t567 = getelementptr %"compiler/parse:Parser", ptr %t563, i32 0, i32 22
  store i1 %t564, ptr %t567, !tbaa !21
  %t568 = load ptr, ptr %l0, !tbaa !29
  %t569 = load i1, ptr %l4, !tbaa !21
  %t572 = getelementptr %"compiler/parse:Parser", ptr %t568, i32 0, i32 23
  store i1 %t569, ptr %t572, !tbaa !21
  %t574 = insertvalue { i32, ptr } zeroinitializer, i32 %t547, 0
  store { i32, ptr } %t574, ptr %rv
  br label %ret
bb73:
  %t575 = load ptr, ptr %l211, !tbaa !29
  store ptr %t575, ptr %l9, !tbaa !29
  br label %bb74
bb74:
  %t576 = load ptr, ptr %l0, !tbaa !29
  %t578 = getelementptr %"compiler/parse:Parser", ptr %t576, i32 0, i32 34
  %t579 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t578, ptr %t579)
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb59
bb77:
  br label %bb78
bb78:
  br label %bb79
bb79:
  %t582 = load ptr, ptr %l0, !tbaa !29
  %t585 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t582, i32 113)
  store i1 %t585, ptr %l232
  br label %bb80
bb80:
  %t586 = load i1, ptr %l232, !tbaa !21
  %t587 = xor i1 %t586, true
  br i1 %t587, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s30
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/parse:Parser", ptr %t589, i32 0, i32 34
  %t592 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t591, i64 %t592)
  br label %bb83
bb82:
  br label %bb88
bb83:
  %t595 = load ptr, ptr %l0, !tbaa !29
  store ptr %t595, ptr %l237, !tbaa !29
  %t597 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s30, i32 113)
  store { i64, ptr } %t597, ptr %l239
  br label %bb84
bb84:
  %t598 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t599 = load ptr, ptr %l237, !tbaa !29
  %t601 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s30, ptr %t599, { i64, ptr } %t598)
  store i32 %t601, ptr %l241
  %t602 = icmp ne i32 %t601, 0
  br i1 %t602, label %bb86, label %ok.603, !prof !99
ok.603:
  br label %bb85
bb85:
  br label %bb87
bb86:
  %t604 = load i32, ptr %l241, !tbaa !23
  %t605 = lshr i32 %t604, 16
  %t606 = and i32 %t604, 65535
  %t607 = icmp eq i32 %t605, 1
  %t608 = select i1 %t607, i32 1, i32 0
  %t609 = icmp eq i32 %t604, 0
  %t610 = shl i32 %t608, 16
  %t611 = or i32 %t610, %t606
  %t612 = select i1 %t609, i32 0, i32 %t611
  call void @__olang_scope_close(ptr %s30)
  %t613 = load ptr, ptr %l0, !tbaa !29
  store ptr %t613, ptr %l243, !tbaa !29
  %t614 = load ptr, ptr %l243, !tbaa !29
  %t615 = getelementptr %"compiler/parse:Parser", ptr %t614, i32 0, i32 21
  %t616 = load i64, ptr %t615, !tbaa !24
  %t619 = sub i64 %t616, 1
  %t621 = load ptr, ptr %l243, !tbaa !29
  %t622 = getelementptr %"compiler/parse:Parser", ptr %t621, i32 0, i32 21
  store i64 %t619, ptr %t622, !tbaa !24
  %t623 = load ptr, ptr %l0, !tbaa !29
  %t624 = load i1, ptr %l2, !tbaa !21
  %t627 = getelementptr %"compiler/parse:Parser", ptr %t623, i32 0, i32 11
  store i1 %t624, ptr %t627, !tbaa !21
  %t628 = load ptr, ptr %l0, !tbaa !29
  %t629 = load i1, ptr %l3, !tbaa !21
  %t632 = getelementptr %"compiler/parse:Parser", ptr %t628, i32 0, i32 22
  store i1 %t629, ptr %t632, !tbaa !21
  %t633 = load ptr, ptr %l0, !tbaa !29
  %t634 = load i1, ptr %l4, !tbaa !21
  %t637 = getelementptr %"compiler/parse:Parser", ptr %t633, i32 0, i32 23
  store i1 %t634, ptr %t637, !tbaa !21
  %t639 = insertvalue { i32, ptr } zeroinitializer, i32 %t612, 0
  store { i32, ptr } %t639, ptr %rv
  br label %ret
bb87:
  call void @__olang_scope_close(ptr %s30)
  br label %bb88
bb88:
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t640)
  store i32 %t642, ptr %l254
  br label %bb89
bb89:
  %t643 = load ptr, ptr %l0, !tbaa !29
  %t644 = load i32, ptr %l1, !tbaa !23
  %t647 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t643, i32 %t644)
  store %"compiler/source:Span" %t647, ptr %l257
  br label %bb90
bb90:
  %t648 = load ptr, ptr %l0, !tbaa !29
  %t650 = getelementptr %"compiler/parse:Parser", ptr %t648, i32 0, i32 34
  %t651 = load i64, ptr %l5, !tbaa !24
  %t654 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t650, i64 %t651)
  store { i64, ptr } %t654, ptr %l261
  br label %bb91
bb91:
  store { i64, [4 x i64] } zeroinitializer, ptr %t655
  %t656 = getelementptr { i64, [4 x i64] }, ptr %t655, i32 0, i32 0
  store i64 17, ptr %t656
  %t657 = load %"compiler/source:Span", ptr %l257
  %t658 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t657, 0
  %t659 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t660 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t658, { i64, ptr } %t659, 1
  %t661 = getelementptr { i64, [4 x i64] }, ptr %t655, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t660, ptr %t661
  %t662 = load { i64, [4 x i64] }, ptr %t655
  %t664 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t662, ptr %t664
  %t665 = load ptr, ptr %l0, !tbaa !29
  store ptr %t665, ptr %l264, !tbaa !29
  %t666 = load ptr, ptr %l264, !tbaa !29
  %t667 = getelementptr %"compiler/parse:Parser", ptr %t666, i32 0, i32 21
  %t668 = load i64, ptr %t667, !tbaa !24
  %t671 = sub i64 %t668, 1
  %t673 = load ptr, ptr %l264, !tbaa !29
  %t674 = getelementptr %"compiler/parse:Parser", ptr %t673, i32 0, i32 21
  store i64 %t671, ptr %t674, !tbaa !24
  %t675 = load ptr, ptr %l0, !tbaa !29
  %t676 = load i1, ptr %l2, !tbaa !21
  %t679 = getelementptr %"compiler/parse:Parser", ptr %t675, i32 0, i32 11
  store i1 %t676, ptr %t679, !tbaa !21
  %t680 = load ptr, ptr %l0, !tbaa !29
  %t681 = load i1, ptr %l3, !tbaa !21
  %t684 = getelementptr %"compiler/parse:Parser", ptr %t680, i32 0, i32 22
  store i1 %t681, ptr %t684, !tbaa !21
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load i1, ptr %l4, !tbaa !21
  %t689 = getelementptr %"compiler/parse:Parser", ptr %t685, i32 0, i32 23
  store i1 %t686, ptr %t689, !tbaa !21
  %t691 = insertvalue { i32, ptr } zeroinitializer, ptr %t664, 1
  store { i32, ptr } %t691, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca %"compiler/source:Span"
  %l18 = alloca i1
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca %"compiler/source:Span"
  %l27 = alloca i32
  %l30 = alloca i64
  %l33 = alloca i1
  %l38 = alloca ptr
  %l45 = alloca i1
  %l47 = alloca i32
  %l52 = alloca ptr
  %l58 = alloca i32
  %l62 = alloca i32
  %l63 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i32
  %l70 = alloca ptr
  %l78 = alloca %"compiler/source:Span"
  %l84 = alloca i32
  %l86 = alloca ptr
  %l96 = alloca i1
  %l99 = alloca i1
  %l101 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca i32
  %l108 = alloca ptr
  %l114 = alloca i1
  %l115 = alloca i1
  %l117 = alloca i32
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca ptr
  %l122 = alloca i32
  %l123 = alloca i64
  %l125 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l131 = alloca i64
  %l134 = alloca ptr
  %l140 = alloca i32
  %l142 = alloca ptr
  %l151 = alloca i32
  %l152 = alloca i1
  %l153 = alloca i1
  %l154 = alloca ptr
  %l156 = alloca i32
  %l157 = alloca i64
  %l160 = alloca ptr
  %l162 = alloca i32
  %l164 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca i32
  %l174 = alloca ptr
  %l180 = alloca i32
  %l182 = alloca ptr
  %l193 = alloca %"compiler/source:Span"
  %l195 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l200 = alloca %"compiler/ast:Chain"
  %l206 = alloca i1
  %l209 = alloca i1
  %l210 = alloca ptr
  %l212 = alloca i1
  %l213 = alloca i1
  %l215 = alloca i1
  %l218 = alloca i32
  %l223 = alloca i1
  %l226 = alloca i1
  %l227 = alloca ptr
  %l229 = alloca i1
  %l230 = alloca i1
  %l232 = alloca i1
  %l233 = alloca ptr
  %l234 = alloca ptr
  %l236 = alloca %"compiler/source:Span"
  %l237 = alloca i32
  %l239 = alloca %"compiler/source:Span"
  %l240 = alloca i32
  %l243 = alloca %"compiler/diagmsg:Msg"
  %l246 = alloca i1
  %l249 = alloca i1
  %l252 = alloca ptr
  %l254 = alloca i1
  %l256 = alloca ptr
  %l257 = alloca ptr
  %l259 = alloca %"compiler/source:Span"
  %l261 = alloca i1
  %l263 = alloca ptr
  %l265 = alloca %"compiler/source:Span"
  %l269 = alloca %"compiler/source:Span"
  %l276 = alloca i32
  %l278 = alloca ptr
  %s17 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t157 = alloca { i64, [4 x i64] }, align 8
  %t462 = alloca { i64, [4 x i64] }, align 8
  %t626 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l14
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l4, !tbaa !23
  store i64 0, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/parse:Parser", ptr %t9, i32 0, i32 54
  %t12 = load i1, ptr %t11, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sgt i64 %t14, 0
  store i1 %t16, ptr %l18, !tbaa !21
  br label %bb5
bb4:
  store i1 false, ptr %l18, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l18, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/parse:Parser", ptr %t19, i32 0, i32 55
  store ptr %t21, ptr %l22, !tbaa !29
  %t22 = load ptr, ptr %l3, !tbaa !29
  store ptr %t22, ptr %l23, !tbaa !29
  %t23 = load ptr, ptr %l23, !tbaa !29
  %t24 = call ptr @__olang_scope_of(ptr %t23, ptr null)
  %t25 = call ptr @__olang_scope_hold(ptr %t24)
  %t26 = ptrtoint ptr %t25 to i64
  %t28 = inttoptr i64 %t26 to ptr
  %t29 = load ptr, ptr %l23, !tbaa !29
  %t30 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %t28, ptr %t29)
  store %"compiler/source:Span" %t30, ptr %l25
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t31 = load ptr, ptr %l22, !tbaa !29
  %t32 = load %"compiler/source:Span", ptr %l25
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t31, %"compiler/source:Span" %t32)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t33)
  store i32 %t35, ptr %l27
  br label %bb11
bb11:
  %t36 = load i32, ptr %l27, !range !{i32 0, i32 116}
  store i32 %t36, ptr %l6
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t38 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t41 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t37, i32 %t38)
  store i64 %t41, ptr %l30
  br label %bb12
bb12:
  %t42 = load i64, ptr %l30, !tbaa !24
  store i64 %t42, ptr %l7, !tbaa !24
  %t43 = load i64, ptr %l7, !tbaa !24
  %t45 = icmp eq i64 %t43, 0
  br i1 %t45, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l33, !tbaa !21
  br label %bb15
bb14:
  %t47 = load i64, ptr %l7, !tbaa !24
  %t51 = icmp slt i64 %t47, %a2
  store i1 %t51, ptr %l33, !tbaa !21
  br label %bb15
bb15:
  %t53 = load i1, ptr %l33, !tbaa !21
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t54 = load ptr, ptr %l3, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l38, !tbaa !29
  %t56 = load ptr, ptr %l38, !tbaa !29
  %t57 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 24
  %t58 = load i64, ptr %t57, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = sub i64 %t58, %t60
  %t65 = load ptr, ptr %l38, !tbaa !29
  %t66 = getelementptr %"compiler/parse:Parser", ptr %t65, i32 0, i32 24
  store i64 %t63, ptr %t66, !tbaa !24
  %t68 = insertvalue { i32, ptr } zeroinitializer, ptr %t54, 1
  store { i32, ptr } %t68, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t69 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t71 = trunc i64 48 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb19, label %bb20
bb19:
  %t74 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t74, i64 1)
  store i32 %t76, ptr %l47
  br label %bb21
bb20:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb22
bb21:
  %t77 = load i32, ptr %l47, !range !{i32 0, i32 116}
  %t79 = trunc i64 27 to i32
  %t80 = icmp eq i32 %t77, %t79
  %t82 = xor i1 %t80, true
  store i1 %t82, ptr %l45, !tbaa !21
  br label %bb22
bb22:
  %t84 = load i1, ptr %l45, !tbaa !21
  br i1 %t84, label %bb23, label %bb24
bb23:
  %t85 = load ptr, ptr %l3, !tbaa !29
  %t86 = load ptr, ptr %l0, !tbaa !29
  store ptr %t86, ptr %l52, !tbaa !29
  %t87 = load ptr, ptr %l52, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 24
  %t89 = load i64, ptr %t88, !tbaa !24
  %t91 = load i64, ptr %l5, !tbaa !24
  %t94 = sub i64 %t89, %t91
  %t96 = load ptr, ptr %l52, !tbaa !29
  %t97 = getelementptr %"compiler/parse:Parser", ptr %t96, i32 0, i32 24
  store i64 %t94, ptr %t97, !tbaa !24
  %t99 = insertvalue { i32, ptr } zeroinitializer, ptr %t85, 1
  store { i32, ptr } %t99, ptr %rv
  br label %ret
bb24:
  br label %bb25
bb25:
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t100)
  store i32 %t102, ptr %l58
  br label %bb26
bb26:
  %t103 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t105 = trunc i64 48 to i32
  %t106 = icmp eq i32 %t103, %t105
  br i1 %t106, label %bb27, label %bb28
bb27:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t110 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t108)
  store i32 %t110, ptr %l62
  br label %bb29
bb28:
  br label %bb37
bb29:
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t112 = load i64, ptr %l7, !tbaa !24
  %t114 = add i64 %t112, 1
  %t117 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v2, ptr %t111, i64 %t114)
  %t118 = extractvalue { i32, ptr } %t117, 1
  %t119 = extractvalue { i32, ptr } %t117, 0
  store i32 %t119, ptr %l68
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb31, label %ok.121, !prof !99
ok.121:
  store ptr %t118, ptr %l67
  br label %bb30
bb30:
  %t122 = load ptr, ptr %l67, !tbaa !29
  store ptr %t122, ptr %l63, !tbaa !29
  br label %bb32
bb31:
  %t123 = load i32, ptr %l68, !tbaa !23
  %t124 = lshr i32 %t123, 16
  %t125 = and i32 %t123, 65535
  %t126 = icmp eq i32 %t124, 1
  %t127 = select i1 %t126, i32 1, i32 0
  %t128 = icmp eq i32 %t123, 0
  %t129 = shl i32 %t127, 16
  %t130 = or i32 %t129, %t125
  %t131 = select i1 %t128, i32 0, i32 %t130
  %t132 = load ptr, ptr %l0, !tbaa !29
  store ptr %t132, ptr %l70, !tbaa !29
  %t133 = load ptr, ptr %l70, !tbaa !29
  %t134 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 24
  %t135 = load i64, ptr %t134, !tbaa !24
  %t137 = load i64, ptr %l5, !tbaa !24
  %t140 = sub i64 %t135, %t137
  %t142 = load ptr, ptr %l70, !tbaa !29
  %t143 = getelementptr %"compiler/parse:Parser", ptr %t142, i32 0, i32 24
  store i64 %t140, ptr %t143, !tbaa !24
  %t145 = insertvalue { i32, ptr } zeroinitializer, i32 %t131, 0
  store { i32, ptr } %t145, ptr %rv
  br label %ret
bb32:
  %t146 = load ptr, ptr %l63, !tbaa !29
  store ptr %t146, ptr %l8, !tbaa !29
  %t147 = load i32, ptr %l4, !tbaa !23
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 10
  %t151 = load i32, ptr %t150, !tbaa !23
  %t154 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 %t147, i32 %t151)
  store %"compiler/source:Span" %t154, ptr %l78
  br label %bb33
bb33:
  %t155 = load ptr, ptr %l3, !tbaa !29
  %t156 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t157
  %t158 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 0
  store i64 6, ptr %t158
  %t159 = load %"compiler/source:Span", ptr %l78
  %t160 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t159, 0
  %t162 = insertvalue { %"compiler/source:Span", ptr, ptr } %t160, ptr %t155, 1
  %t164 = insertvalue { %"compiler/source:Span", ptr, ptr } %t162, ptr %t156, 2
  %t165 = getelementptr { i64, [4 x i64] }, ptr %t157, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t164, ptr %t165
  %t166 = load { i64, [4 x i64] }, ptr %t157
  %t168 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t166, ptr %t168
  store ptr %t168, ptr %l3, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l84
  %t173 = icmp ne i32 %t172, 0
  br i1 %t173, label %bb35, label %ok.174, !prof !99
ok.174:
  br label %bb34
bb34:
  br label %bb36
bb35:
  %t175 = load i32, ptr %l84, !tbaa !23
  %t176 = lshr i32 %t175, 16
  %t177 = and i32 %t175, 65535
  %t178 = icmp eq i32 %t176, 1
  %t179 = select i1 %t178, i32 1, i32 0
  %t180 = icmp eq i32 %t175, 0
  %t181 = shl i32 %t179, 16
  %t182 = or i32 %t181, %t177
  %t183 = select i1 %t180, i32 0, i32 %t182
  %t184 = load ptr, ptr %l0, !tbaa !29
  store ptr %t184, ptr %l86, !tbaa !29
  %t185 = load ptr, ptr %l86, !tbaa !29
  %t186 = getelementptr %"compiler/parse:Parser", ptr %t185, i32 0, i32 24
  %t187 = load i64, ptr %t186, !tbaa !24
  %t189 = load i64, ptr %l5, !tbaa !24
  %t192 = sub i64 %t187, %t189
  %t194 = load ptr, ptr %l86, !tbaa !29
  %t195 = getelementptr %"compiler/parse:Parser", ptr %t194, i32 0, i32 24
  store i64 %t192, ptr %t195, !tbaa !24
  %t197 = insertvalue { i32, ptr } zeroinitializer, i32 %t183, 0
  store { i32, ptr } %t197, ptr %rv
  br label %ret
bb36:
  %t198 = load i64, ptr %l5, !tbaa !24
  %t201 = add i64 %t198, 1
  store i64 %t201, ptr %l5, !tbaa !24
  br label %bb157
bb37:
  %t203 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t205 = trunc i64 28 to i32
  %t206 = icmp eq i32 %t203, %t205
  br i1 %t206, label %bb38, label %bb39
bb38:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t211 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t208, i32 48)
  store i1 %t211, ptr %l99
  br label %bb40
bb39:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb41
bb40:
  %t212 = load i1, ptr %l99, !tbaa !21
  store i1 %t212, ptr %l96, !tbaa !21
  br label %bb41
bb41:
  %t213 = load i1, ptr %l96, !tbaa !21
  br i1 %t213, label %bb42, label %bb43
bb42:
  store i32 106, ptr %l6
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t215 = load ptr, ptr %l0, !tbaa !29
  %t216 = load i64, ptr %l7, !tbaa !24
  %t218 = add i64 %t216, 1
  %t221 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v0, ptr %t215, i64 %t218)
  %t222 = extractvalue { i32, ptr } %t221, 1
  %t223 = extractvalue { i32, ptr } %t221, 0
  store i32 %t223, ptr %l106
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb46, label %ok.225, !prof !99
ok.225:
  store ptr %t222, ptr %l105
  br label %bb45
bb45:
  %t226 = load ptr, ptr %l105, !tbaa !29
  store ptr %t226, ptr %l101, !tbaa !29
  br label %bb47
bb46:
  %t227 = load i32, ptr %l106, !tbaa !23
  %t228 = lshr i32 %t227, 16
  %t229 = and i32 %t227, 65535
  %t230 = icmp eq i32 %t228, 1
  %t231 = select i1 %t230, i32 1, i32 0
  %t232 = icmp eq i32 %t227, 0
  %t233 = shl i32 %t231, 16
  %t234 = or i32 %t233, %t229
  %t235 = select i1 %t232, i32 0, i32 %t234
  %t236 = load ptr, ptr %l0, !tbaa !29
  store ptr %t236, ptr %l108, !tbaa !29
  %t237 = load ptr, ptr %l108, !tbaa !29
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t237, i32 0, i32 24
  %t239 = load i64, ptr %t238, !tbaa !24
  %t241 = load i64, ptr %l5, !tbaa !24
  %t244 = sub i64 %t239, %t241
  %t246 = load ptr, ptr %l108, !tbaa !29
  %t247 = getelementptr %"compiler/parse:Parser", ptr %t246, i32 0, i32 24
  store i64 %t244, ptr %t247, !tbaa !24
  %t249 = insertvalue { i32, ptr } zeroinitializer, i32 %t235, 0
  store { i32, ptr } %t249, ptr %rv
  br label %ret
bb47:
  %t250 = load ptr, ptr %l101, !tbaa !29
  store ptr %t250, ptr %l9, !tbaa !29
  %t251 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t253 = call i1 @compiler_2fparse_2eisOrdering(i32 %t251)
  store i1 %t253, ptr %l114
  br label %bb48
bb48:
  %t254 = load i1, ptr %l114, !tbaa !21
  br i1 %t254, label %bb49, label %bb50
bb49:
  %t255 = load ptr, ptr %l0, !tbaa !29
  %t257 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t255)
  store i32 %t257, ptr %l117
  br label %bb51
bb50:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb53
bb51:
  %t258 = load i32, ptr %l117, !range !{i32 0, i32 116}
  %t259 = call i1 @compiler_2fparse_2eisOrdering(i32 %t258)
  store i1 %t259, ptr %l118
  br label %bb52
bb52:
  %t260 = load i1, ptr %l118, !tbaa !21
  store i1 %t260, ptr %l115, !tbaa !21
  br label %bb53
bb53:
  %t261 = load i1, ptr %l115, !tbaa !21
  br i1 %t261, label %bb54, label %bb55
bb54:
  %t262 = load ptr, ptr %l0, !tbaa !29
  store ptr %t262, ptr %l120, !tbaa !29
  %t263 = load ptr, ptr %l0, !tbaa !29
  %t265 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t263)
  store i32 %t265, ptr %l122
  br label %bb56
bb55:
  store i1 false, ptr %l119, !tbaa !21
  br label %bb58
bb56:
  %t266 = load ptr, ptr %l120, !tbaa !29
  %t267 = load i32, ptr %l122, !range !{i32 0, i32 116}
  %t268 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t266, i32 %t267)
  store i64 %t268, ptr %l123
  br label %bb57
bb57:
  %t269 = load i64, ptr %l123, !tbaa !24
  %t270 = icmp sgt i64 %t269, 0
  store i1 %t270, ptr %l119, !tbaa !21
  br label %bb58
bb58:
  %t272 = load i1, ptr %l119, !tbaa !21
  br i1 %t272, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s17
  %t273 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %s17, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %l125
  br label %bb61
bb60:
  br label %bb96
bb61:
  %t274 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l125
  %t275 = call ptr @__olang_scope_alloc_a(ptr %s17, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %t275
  store ptr %t275, ptr %l10, !tbaa !29
  %t277 = load ptr, ptr %l10, !tbaa !29
  %t278 = load i32, ptr %l6, !range !{i32 0, i32 116}
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %s17, ptr %t277, i32 %t278)
  br label %bb62
bb62:
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t283 = getelementptr %"compiler/parse:Parser", ptr %t281, i32 0, i32 34
  %t285 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t283)
  store i64 %t285, ptr %l131
  br label %bb63
bb63:
  %t286 = load i64, ptr %l131, !tbaa !24
  store i64 %t286, ptr %l11, !tbaa !24
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/parse:Parser", ptr %t287, i32 0, i32 34
  %t290 = load ptr, ptr %l3, !tbaa !29
  store ptr %t290, ptr %l134, !tbaa !29
  %t291 = load ptr, ptr %l134, !tbaa !29
  %t292 = call ptr @__olang_scope_of(ptr %t291, ptr null)
  %t293 = call ptr @__olang_scope_hold(ptr %t292)
  %t294 = ptrtoint ptr %t293 to i64
  %t296 = inttoptr i64 %t294 to ptr
  %t298 = load ptr, ptr %l134, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t296, ptr %t289, ptr %t298)
  br label %bb64
bb64:
  %t299 = load ptr, ptr %l0, !tbaa !29
  %t301 = getelementptr %"compiler/parse:Parser", ptr %t299, i32 0, i32 34
  %t302 = load ptr, ptr %l9, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t301, ptr %t302)
  br label %bb65
bb65:
  %t305 = load ptr, ptr %l0, !tbaa !29
  %t307 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t305)
  store i32 %t307, ptr %l140
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb67, label %ok.309, !prof !99
ok.309:
  br label %bb66
bb66:
  br label %bb68
bb67:
  %t310 = load i32, ptr %l140, !tbaa !23
  %t311 = lshr i32 %t310, 16
  %t312 = and i32 %t310, 65535
  %t313 = icmp eq i32 %t311, 1
  %t314 = select i1 %t313, i32 1, i32 0
  %t315 = icmp eq i32 %t310, 0
  %t316 = shl i32 %t314, 16
  %t317 = or i32 %t316, %t312
  %t318 = select i1 %t315, i32 0, i32 %t317
  call void @__olang_scope_close(ptr %s17)
  %t319 = load ptr, ptr %l0, !tbaa !29
  store ptr %t319, ptr %l142, !tbaa !29
  %t320 = load ptr, ptr %l142, !tbaa !29
  %t321 = getelementptr %"compiler/parse:Parser", ptr %t320, i32 0, i32 24
  %t322 = load i64, ptr %t321, !tbaa !24
  %t324 = load i64, ptr %l5, !tbaa !24
  %t327 = sub i64 %t322, %t324
  %t329 = load ptr, ptr %l142, !tbaa !29
  %t330 = getelementptr %"compiler/parse:Parser", ptr %t329, i32 0, i32 24
  store i64 %t327, ptr %t330, !tbaa !24
  %t332 = insertvalue { i32, ptr } zeroinitializer, i32 %t318, 0
  store { i32, ptr } %t332, ptr %rv
  br label %ret
bb68:
  %t333 = load i64, ptr %l5, !tbaa !24
  %t336 = add i64 %t333, 1
  store i64 %t336, ptr %l5, !tbaa !24
  br label %bb69
bb69:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t340 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t338)
  store i32 %t340, ptr %l151
  br label %bb70
bb70:
  %t341 = load i32, ptr %l151, !range !{i32 0, i32 116}
  %t342 = call i1 @compiler_2fparse_2eisOrdering(i32 %t341)
  store i1 %t342, ptr %l152
  br label %bb71
bb71:
  %t343 = load i1, ptr %l152, !tbaa !21
  br i1 %t343, label %bb72, label %bb73
bb72:
  %t344 = load ptr, ptr %l0, !tbaa !29
  store ptr %t344, ptr %l154, !tbaa !29
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t347 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t345)
  store i32 %t347, ptr %l156
  br label %bb74
bb73:
  store i1 false, ptr %l153, !tbaa !21
  br label %bb76
bb74:
  %t348 = load ptr, ptr %l154, !tbaa !29
  %t349 = load i32, ptr %l156, !range !{i32 0, i32 116}
  %t350 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %t348, i32 %t349)
  store i64 %t350, ptr %l157
  br label %bb75
bb75:
  %t351 = load i64, ptr %l157, !tbaa !24
  %t352 = icmp sgt i64 %t351, 0
  store i1 %t352, ptr %l153, !tbaa !21
  br label %bb76
bb76:
  %t354 = load i1, ptr %l153, !tbaa !21
  %t355 = xor i1 %t354, true
  br i1 %t355, label %bb77, label %bb78
bb77:
  br label %bb91
bb78:
  br label %bb79
bb79:
  %t357 = load ptr, ptr %l10, !tbaa !29
  store ptr %t357, ptr %l160, !tbaa !29
  %t358 = load ptr, ptr %l0, !tbaa !29
  %t360 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t358)
  store i32 %t360, ptr %l162
  br label %bb80
bb80:
  %t361 = load ptr, ptr %l160, !tbaa !29
  %t362 = load i32, ptr %l162, !range !{i32 0, i32 116}
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %s17, ptr %t361, i32 %t362)
  br label %bb81
bb81:
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t363)
  store i32 %t365, ptr %l164
  br label %bb82
bb82:
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = getelementptr %"compiler/parse:Parser", ptr %t366, i32 0, i32 34
  store ptr %t368, ptr %l166, !tbaa !29
  %t369 = load ptr, ptr %l0, !tbaa !29
  %t370 = load i64, ptr %l7, !tbaa !24
  %t372 = add i64 %t370, 1
  %t375 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v0, ptr %t369, i64 %t372)
  %t376 = extractvalue { i32, ptr } %t375, 1
  %t377 = extractvalue { i32, ptr } %t375, 0
  store i32 %t377, ptr %l172
  %t378 = icmp ne i32 %t377, 0
  br i1 %t378, label %bb84, label %ok.379, !prof !99
ok.379:
  store ptr %t376, ptr %l171
  br label %bb83
bb83:
  %t380 = load ptr, ptr %l171, !tbaa !29
  store ptr %t380, ptr %l167, !tbaa !29
  br label %bb85
bb84:
  %t381 = load i32, ptr %l172, !tbaa !23
  %t382 = lshr i32 %t381, 16
  %t383 = and i32 %t381, 65535
  %t384 = icmp eq i32 %t382, 1
  %t385 = select i1 %t384, i32 1, i32 0
  %t386 = icmp eq i32 %t381, 0
  %t387 = shl i32 %t385, 16
  %t388 = or i32 %t387, %t383
  %t389 = select i1 %t386, i32 0, i32 %t388
  call void @__olang_scope_close(ptr %s17)
  %t390 = load ptr, ptr %l0, !tbaa !29
  store ptr %t390, ptr %l174, !tbaa !29
  %t391 = load ptr, ptr %l174, !tbaa !29
  %t392 = getelementptr %"compiler/parse:Parser", ptr %t391, i32 0, i32 24
  %t393 = load i64, ptr %t392, !tbaa !24
  %t395 = load i64, ptr %l5, !tbaa !24
  %t398 = sub i64 %t393, %t395
  %t400 = load ptr, ptr %l174, !tbaa !29
  %t401 = getelementptr %"compiler/parse:Parser", ptr %t400, i32 0, i32 24
  store i64 %t398, ptr %t401, !tbaa !24
  %t403 = insertvalue { i32, ptr } zeroinitializer, i32 %t389, 0
  store { i32, ptr } %t403, ptr %rv
  br label %ret
bb85:
  %t404 = load ptr, ptr %l166, !tbaa !29
  %t405 = load ptr, ptr %l167, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t404, ptr %t405)
  br label %bb86
bb86:
  %t406 = load ptr, ptr %l0, !tbaa !29
  %t408 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t406)
  store i32 %t408, ptr %l180
  %t409 = icmp ne i32 %t408, 0
  br i1 %t409, label %bb88, label %ok.410, !prof !99
ok.410:
  br label %bb87
bb87:
  br label %bb89
bb88:
  %t411 = load i32, ptr %l180, !tbaa !23
  %t412 = lshr i32 %t411, 16
  %t413 = and i32 %t411, 65535
  %t414 = icmp eq i32 %t412, 1
  %t415 = select i1 %t414, i32 1, i32 0
  %t416 = icmp eq i32 %t411, 0
  %t417 = shl i32 %t415, 16
  %t418 = or i32 %t417, %t413
  %t419 = select i1 %t416, i32 0, i32 %t418
  call void @__olang_scope_close(ptr %s17)
  %t420 = load ptr, ptr %l0, !tbaa !29
  store ptr %t420, ptr %l182, !tbaa !29
  %t421 = load ptr, ptr %l182, !tbaa !29
  %t422 = getelementptr %"compiler/parse:Parser", ptr %t421, i32 0, i32 24
  %t423 = load i64, ptr %t422, !tbaa !24
  %t425 = load i64, ptr %l5, !tbaa !24
  %t428 = sub i64 %t423, %t425
  %t430 = load ptr, ptr %l182, !tbaa !29
  %t431 = getelementptr %"compiler/parse:Parser", ptr %t430, i32 0, i32 24
  store i64 %t428, ptr %t431, !tbaa !24
  %t433 = insertvalue { i32, ptr } zeroinitializer, i32 %t419, 0
  store { i32, ptr } %t433, ptr %rv
  br label %ret
bb89:
  %t434 = load i64, ptr %l5, !tbaa !24
  %t437 = add i64 %t434, 1
  store i64 %t437, ptr %l5, !tbaa !24
  br label %bb90
bb90:
  br label %bb69
bb91:
  %t439 = load i32, ptr %l4, !tbaa !23
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t442 = getelementptr %"compiler/parse:Parser", ptr %t440, i32 0, i32 10
  %t443 = load i32, ptr %t442, !tbaa !23
  %t446 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 %t439, i32 %t443)
  store %"compiler/source:Span" %t446, ptr %l193
  br label %bb92
bb92:
  %t447 = load ptr, ptr %l10, !tbaa !29
  %t449 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %s17, ptr %v2, ptr %t447)
  store { i64, ptr } %t449, ptr %l195
  br label %bb93
bb93:
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = getelementptr %"compiler/parse:Parser", ptr %t450, i32 0, i32 34
  %t453 = load i64, ptr %l11, !tbaa !24
  %t456 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t452, i64 %t453)
  store { i64, ptr } %t456, ptr %l199
  br label %bb94
bb94:
  %t457 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t458 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t459 = call %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v2, ptr %v0, ptr %v2, { i64, ptr } %t457, { i64, ptr } %t458)
  store %"compiler/ast:Chain" %t459, ptr %l200
  br label %bb95
bb95:
  %t460 = load %"compiler/ast:Chain", ptr %l200
  %t461 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/ast:Chain" %t460, ptr %t461
  store { i64, [4 x i64] } zeroinitializer, ptr %t462
  %t463 = getelementptr { i64, [4 x i64] }, ptr %t462, i32 0, i32 0
  store i64 7, ptr %t463
  %t464 = load %"compiler/source:Span", ptr %l193
  %t465 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t464, 0
  %t467 = insertvalue { %"compiler/source:Span", ptr } %t465, ptr %t461, 1
  %t468 = getelementptr { i64, [4 x i64] }, ptr %t462, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t467, ptr %t468
  %t469 = load { i64, [4 x i64] }, ptr %t462
  %t471 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t469, ptr %t471
  store ptr %t471, ptr %l3, !tbaa !29
  call void @__olang_scope_close(ptr %s17)
  br label %bb157
bb96:
  %t473 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t475 = trunc i64 28 to i32
  %t476 = icmp eq i32 %t473, %t475
  br i1 %t476, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l206, !tbaa !21
  br label %bb99
bb98:
  %t478 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t480 = trunc i64 106 to i32
  %t481 = icmp eq i32 %t478, %t480
  store i1 %t481, ptr %l206, !tbaa !21
  br label %bb99
bb99:
  %t483 = load i1, ptr %l206, !tbaa !21
  br i1 %t483, label %bb100, label %bb101
bb100:
  %t484 = load ptr, ptr %l3, !tbaa !29
  store ptr %t484, ptr %l210, !tbaa !29
  %t485 = load ptr, ptr %l210, !tbaa !29
  %t486 = call ptr @__olang_scope_of(ptr %t485, ptr null)
  %t487 = call ptr @__olang_scope_hold(ptr %t486)
  %t488 = ptrtoint ptr %t487 to i64
  %t490 = inttoptr i64 %t488 to ptr
  %t491 = load ptr, ptr %l210, !tbaa !29
  %t492 = call i1 @compiler_2fparse_2enullLit(ptr %t490, ptr %t491)
  store i1 %t492, ptr %l212
  br label %bb102
bb101:
  store i1 false, ptr %l209, !tbaa !21
  br label %bb107
bb102:
  %t493 = load i1, ptr %l212, !tbaa !21
  br i1 %t493, label %bb103, label %bb104
bb103:
  store i1 true, ptr %l213, !tbaa !21
  br label %bb106
bb104:
  %t494 = load ptr, ptr %l9, !tbaa !29
  %t496 = call i1 @compiler_2fparse_2enullLit(ptr %v0, ptr %t494)
  store i1 %t496, ptr %l215
  br label %bb105
bb105:
  %t497 = load i1, ptr %l215, !tbaa !21
  store i1 %t497, ptr %l213, !tbaa !21
  br label %bb106
bb106:
  %t498 = load i1, ptr %l213, !tbaa !21
  store i1 %t498, ptr %l209, !tbaa !21
  br label %bb107
bb107:
  %t499 = load i1, ptr %l209, !tbaa !21
  br i1 %t499, label %bb108, label %bb109
bb108:
  %t500 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t502 = trunc i64 28 to i32
  %t503 = icmp eq i32 %t500, %t502
  br i1 %t503, label %bb110, label %bb111
bb109:
  %t505 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t507 = trunc i64 95 to i32
  %t508 = icmp eq i32 %t505, %t507
  br i1 %t508, label %bb113, label %bb114
bb110:
  store i32 95, ptr %l218
  br label %bb112
bb111:
  store i32 96, ptr %l218
  br label %bb112
bb112:
  %t512 = load i32, ptr %l218, !range !{i32 0, i32 116}
  store i32 %t512, ptr %l6
  br label %bb131
bb113:
  store i1 true, ptr %l223, !tbaa !21
  br label %bb115
bb114:
  %t513 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t515 = trunc i64 96 to i32
  %t516 = icmp eq i32 %t513, %t515
  store i1 %t516, ptr %l223, !tbaa !21
  br label %bb115
bb115:
  %t518 = load i1, ptr %l223, !tbaa !21
  br i1 %t518, label %bb116, label %bb117
bb116:
  %t519 = load ptr, ptr %l3, !tbaa !29
  store ptr %t519, ptr %l227, !tbaa !29
  %t520 = load ptr, ptr %l227, !tbaa !29
  %t521 = call ptr @__olang_scope_of(ptr %t520, ptr null)
  %t522 = call ptr @__olang_scope_hold(ptr %t521)
  %t523 = ptrtoint ptr %t522 to i64
  %t525 = inttoptr i64 %t523 to ptr
  %t526 = load ptr, ptr %l227, !tbaa !29
  %t527 = call i1 @compiler_2fparse_2enullLit(ptr %t525, ptr %t526)
  store i1 %t527, ptr %l229
  br label %bb118
bb117:
  store i1 false, ptr %l226, !tbaa !21
  br label %bb123
bb118:
  %t528 = load i1, ptr %l229, !tbaa !21
  br i1 %t528, label %bb119, label %bb120
bb119:
  store i1 true, ptr %l230, !tbaa !21
  br label %bb122
bb120:
  %t529 = load ptr, ptr %l9, !tbaa !29
  %t531 = call i1 @compiler_2fparse_2enullLit(ptr %v0, ptr %t529)
  store i1 %t531, ptr %l232
  br label %bb121
bb121:
  %t532 = load i1, ptr %l232, !tbaa !21
  store i1 %t532, ptr %l230, !tbaa !21
  br label %bb122
bb122:
  %t533 = load i1, ptr %l230, !tbaa !21
  store i1 %t533, ptr %l226, !tbaa !21
  br label %bb123
bb123:
  %t534 = load i1, ptr %l226, !tbaa !21
  br i1 %t534, label %bb124, label %bb125
bb124:
  %t535 = load ptr, ptr %l0, !tbaa !29
  store ptr %t535, ptr %l233, !tbaa !29
  %t536 = load ptr, ptr %l3, !tbaa !29
  store ptr %t536, ptr %l234, !tbaa !29
  %t537 = load ptr, ptr %l234, !tbaa !29
  %t538 = call ptr @__olang_scope_of(ptr %t537, ptr null)
  %t539 = call ptr @__olang_scope_hold(ptr %t538)
  %t540 = ptrtoint ptr %t539 to i64
  %t542 = inttoptr i64 %t540 to ptr
  %t543 = load ptr, ptr %l234, !tbaa !29
  %t544 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %t542, ptr %t543)
  store %"compiler/source:Span" %t544, ptr %l236
  br label %bb126
bb125:
  br label %bb130
bb126:
  %t545 = getelementptr %"compiler/source:Span", ptr %l236, i32 0, i32 1
  %t546 = load i32, ptr %t545, !tbaa !23
  store i32 %t546, ptr %l237, !tbaa !23
  %t547 = load ptr, ptr %l9, !tbaa !29
  %t549 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t547)
  store %"compiler/source:Span" %t549, ptr %l239
  br label %bb127
bb127:
  %t550 = getelementptr %"compiler/source:Span", ptr %l239, i32 0, i32 0
  %t551 = load i32, ptr %t550, !tbaa !23
  store i32 %t551, ptr %l240, !tbaa !23
  %t552 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t554 = trunc i64 96 to i32
  %t555 = icmp eq i32 %t552, %t554
  %t557 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullTestEq(ptr %v0, i1 %t555)
  store %"compiler/diagmsg:Msg" %t557, ptr %l243
  br label %bb128
bb128:
  %t558 = load ptr, ptr %l233, !tbaa !29
  %t559 = load i32, ptr %l237, !tbaa !23
  %t560 = load i32, ptr %l240, !tbaa !23
  %t561 = load %"compiler/diagmsg:Msg", ptr %l243
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t558, i32 %t559, i32 %t560, %"compiler/diagmsg:Msg" %t561)
  br label %bb129
bb129:
  br label %bb130
bb130:
  br label %bb131
bb131:
  %t562 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t564 = trunc i64 102 to i32
  %t565 = icmp eq i32 %t562, %t564
  br i1 %t565, label %bb132, label %bb133
bb132:
  store i1 true, ptr %l246, !tbaa !21
  br label %bb134
bb133:
  %t567 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t569 = trunc i64 103 to i32
  %t570 = icmp eq i32 %t567, %t569
  store i1 %t570, ptr %l246, !tbaa !21
  br label %bb134
bb134:
  %t572 = load i1, ptr %l246, !tbaa !21
  br i1 %t572, label %bb135, label %bb136
bb135:
  store i1 true, ptr %l249, !tbaa !21
  br label %bb137
bb136:
  %t573 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t575 = trunc i64 104 to i32
  %t576 = icmp eq i32 %t573, %t575
  store i1 %t576, ptr %l249, !tbaa !21
  br label %bb137
bb137:
  %t578 = load i1, ptr %l249, !tbaa !21
  br i1 %t578, label %bb138, label %bb139
bb138:
  %t579 = load ptr, ptr %l3, !tbaa !29
  store ptr %t579, ptr %l252, !tbaa !29
  %t580 = load ptr, ptr %l252, !tbaa !29
  %t581 = call ptr @__olang_scope_of(ptr %t580, ptr null)
  %t582 = call ptr @__olang_scope_hold(ptr %t581)
  %t583 = ptrtoint ptr %t582 to i64
  %t585 = inttoptr i64 %t583 to ptr
  %t586 = load ptr, ptr %l252, !tbaa !29
  %t587 = call i1 @compiler_2fparse_2ecomparison(ptr %t585, ptr %t586)
  store i1 %t587, ptr %l254
  br label %bb140
bb139:
  br label %bb152
bb140:
  %t588 = load i1, ptr %l254, !tbaa !21
  br i1 %t588, label %bb141, label %bb142
bb141:
  %t589 = load ptr, ptr %l0, !tbaa !29
  %t591 = getelementptr %"compiler/parse:Parser", ptr %t589, i32 0, i32 48
  store ptr %t591, ptr %l256, !tbaa !29
  %t592 = load ptr, ptr %l3, !tbaa !29
  store ptr %t592, ptr %l257, !tbaa !29
  %t593 = load ptr, ptr %l257, !tbaa !29
  %t594 = call ptr @__olang_scope_of(ptr %t593, ptr null)
  %t595 = call ptr @__olang_scope_hold(ptr %t594)
  %t596 = ptrtoint ptr %t595 to i64
  %t598 = inttoptr i64 %t596 to ptr
  %t599 = load ptr, ptr %l257, !tbaa !29
  %t600 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %t598, ptr %t599)
  store %"compiler/source:Span" %t600, ptr %l259
  br label %bb143
bb142:
  br label %bb145
bb143:
  %t601 = load ptr, ptr %l256, !tbaa !29
  %t602 = load %"compiler/source:Span", ptr %l259
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t601, %"compiler/source:Span" %t602)
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t603 = load ptr, ptr %l9, !tbaa !29
  %t605 = call i1 @compiler_2fparse_2ecomparison(ptr %v0, ptr %t603)
  store i1 %t605, ptr %l261
  br label %bb146
bb146:
  %t606 = load i1, ptr %l261, !tbaa !21
  br i1 %t606, label %bb147, label %bb148
bb147:
  %t607 = load ptr, ptr %l0, !tbaa !29
  %t609 = getelementptr %"compiler/parse:Parser", ptr %t607, i32 0, i32 48
  store ptr %t609, ptr %l263, !tbaa !29
  %t610 = load ptr, ptr %l9, !tbaa !29
  %t612 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t610)
  store %"compiler/source:Span" %t612, ptr %l265
  br label %bb149
bb148:
  br label %bb151
bb149:
  %t613 = load ptr, ptr %l263, !tbaa !29
  %t614 = load %"compiler/source:Span", ptr %l265
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t613, %"compiler/source:Span" %t614)
  br label %bb150
bb150:
  br label %bb151
bb151:
  br label %bb152
bb152:
  %t615 = load i32, ptr %l4, !tbaa !23
  %t616 = load ptr, ptr %l0, !tbaa !29
  %t618 = getelementptr %"compiler/parse:Parser", ptr %t616, i32 0, i32 10
  %t619 = load i32, ptr %t618, !tbaa !23
  %t622 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 %t615, i32 %t619)
  store %"compiler/source:Span" %t622, ptr %l269
  br label %bb153
bb153:
  %t623 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t624 = load ptr, ptr %l3, !tbaa !29
  %t625 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t626
  %t627 = getelementptr { i64, [4 x i64] }, ptr %t626, i32 0, i32 0
  store i64 5, ptr %t627
  %t628 = load %"compiler/source:Span", ptr %l269
  %t629 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t628, 0
  %t631 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t629, i32 %t623, 1
  %t633 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t631, ptr %t624, 2
  %t635 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t633, ptr %t625, 3
  %t636 = getelementptr { i64, [4 x i64] }, ptr %t626, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t635, ptr %t636
  %t637 = load { i64, [4 x i64] }, ptr %t626
  %t639 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t637, ptr %t639
  store ptr %t639, ptr %l3, !tbaa !29
  %t641 = load ptr, ptr %l0, !tbaa !29
  %t643 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t641)
  store i32 %t643, ptr %l276
  %t644 = icmp ne i32 %t643, 0
  br i1 %t644, label %bb155, label %ok.645, !prof !99
ok.645:
  br label %bb154
bb154:
  br label %bb156
bb155:
  %t646 = load i32, ptr %l276, !tbaa !23
  %t647 = lshr i32 %t646, 16
  %t648 = and i32 %t646, 65535
  %t649 = icmp eq i32 %t647, 1
  %t650 = select i1 %t649, i32 1, i32 0
  %t651 = icmp eq i32 %t646, 0
  %t652 = shl i32 %t650, 16
  %t653 = or i32 %t652, %t648
  %t654 = select i1 %t651, i32 0, i32 %t653
  %t655 = load ptr, ptr %l0, !tbaa !29
  store ptr %t655, ptr %l278, !tbaa !29
  %t656 = load ptr, ptr %l278, !tbaa !29
  %t657 = getelementptr %"compiler/parse:Parser", ptr %t656, i32 0, i32 24
  %t658 = load i64, ptr %t657, !tbaa !24
  %t660 = load i64, ptr %l5, !tbaa !24
  %t663 = sub i64 %t658, %t660
  %t665 = load ptr, ptr %l278, !tbaa !29
  %t666 = getelementptr %"compiler/parse:Parser", ptr %t665, i32 0, i32 24
  store i64 %t663, ptr %t666, !tbaa !24
  %t668 = insertvalue { i32, ptr } zeroinitializer, i32 %t654, 0
  store { i32, ptr } %t668, ptr %rv
  br label %ret
bb156:
  %t669 = load i64, ptr %l5, !tbaa !24
  %t672 = add i64 %t669, 1
  store i64 %t672, ptr %l5, !tbaa !24
  br label %bb157
bb157:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eblock(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca %"compiler/token:Token"
  %l20 = alloca %"compiler/parse:stackMarks"
  %l21 = alloca i64
  %l25 = alloca i1
  %l27 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l31 = alloca i32
  %l34 = alloca i32
  %l37 = alloca %"compiler/token:Token"
  %l39 = alloca i32
  %l77 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l87 = alloca i1
  %l91 = alloca i1
  %l98 = alloca i32
  %l100 = alloca %"compiler/token:Token"
  %l109 = alloca ptr
  %l110 = alloca { i64, [3 x i64] }
  %l112 = alloca i64
  %l114 = alloca { i64, ptr }
  %l116 = alloca %"compiler/diagmsg:Msg"
  %l117 = alloca i64
  %l122 = alloca i32
  %l143 = alloca %"compiler/parse:stackMarks"
  %l146 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca i32
  %l152 = alloca i1
  %l158 = alloca i32
  %l188 = alloca i1
  %l193 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l197 = alloca i32
  %l198 = alloca i32
  %l219 = alloca i32
  %l223 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t205 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 114)
  store i1 %t4, ptr %l25
  br label %bb1
bb1:
  %t5 = load i1, ptr %l25, !tbaa !21
  %t6 = xor i1 %t5, true
  br i1 %t6, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l27, !tbaa !29
  %t10 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s1, i32 114)
  store { i64, ptr } %t10, ptr %l29
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t11 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t12 = load ptr, ptr %l27, !tbaa !29
  %t14 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t12, { i64, ptr } %t11)
  store i32 %t14, ptr %l31
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16, !prof !99
ok.16:
  br label %bb5
bb5:
  br label %bb7
bb6:
  %t17 = load i32, ptr %l31, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  call void @__olang_scope_close(ptr %s1)
  %t27 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t25, 0
  store { i32, { i64, ptr } } %t27, ptr %rv
  br label %ret
bb7:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t28)
  store i32 %t30, ptr %l34
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb10, label %ok.32, !prof !99
ok.32:
  br label %bb9
bb9:
  br label %bb11
bb10:
  %t33 = load i32, ptr %l34, !tbaa !23
  %t34 = lshr i32 %t33, 16
  %t35 = and i32 %t33, 65535
  %t36 = icmp eq i32 %t34, 1
  %t37 = select i1 %t36, i32 1, i32 0
  %t38 = icmp eq i32 %t33, 0
  %t39 = shl i32 %t37, 16
  %t40 = or i32 %t39, %t35
  %t41 = select i1 %t38, i32 0, i32 %t40
  %t43 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t41, 0
  store { i32, { i64, ptr } } %t43, ptr %rv
  br label %ret
bb11:
  %t44 = load ptr, ptr %l0, !tbaa !29
  %t46 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t44)
  store %"compiler/token:Token" %t46, ptr %l37
  br label %bb12
bb12:
  %t47 = load %"compiler/token:Token", ptr %l37
  store %"compiler/token:Token" %t47, ptr %l1
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t48)
  store i32 %t50, ptr %l39
  br label %bb13
bb13:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 12
  %t54 = load i1, ptr %t53, !tbaa !21
  store i1 %t54, ptr %l2, !tbaa !21
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 20
  %t60 = load i1, ptr %t59, !tbaa !21
  %t63 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 12
  store i1 %t60, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/parse:Parser", ptr %t64, i32 0, i32 20
  store i1 false, ptr %t66, !tbaa !21
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t67, i32 0, i32 21
  %t70 = load i64, ptr %t69, !tbaa !24
  store i64 %t70, ptr %l3, !tbaa !24
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 21
  store i64 0, ptr %t74, !tbaa !24
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t75, i32 0, i32 22
  %t78 = load i1, ptr %t77, !tbaa !21
  store i1 %t78, ptr %l4, !tbaa !21
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 22
  store i1 false, ptr %t82, !tbaa !21
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t85 = getelementptr %"compiler/parse:Parser", ptr %t83, i32 0, i32 23
  %t86 = load i1, ptr %t85, !tbaa !21
  store i1 %t86, ptr %l5, !tbaa !21
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/parse:Parser", ptr %t88, i32 0, i32 23
  store i1 false, ptr %t90, !tbaa !21
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/parse:Parser", ptr %t91, i32 0, i32 15
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l6, !tbaa !21
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/parse:Parser", ptr %t96, i32 0, i32 18
  %t99 = load i1, ptr %t98, !tbaa !21
  store i1 %t99, ptr %l7, !tbaa !21
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/parse:Parser", ptr %t101, i32 0, i32 19
  %t104 = load i1, ptr %t103, !tbaa !21
  store i1 %t104, ptr %l8, !tbaa !21
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t110 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 15
  store i1 false, ptr %t110, !tbaa !21
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 18
  store i1 false, ptr %t115, !tbaa !21
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr %"compiler/parse:Parser", ptr %t116, i32 0, i32 19
  store i1 false, ptr %t120, !tbaa !21
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/parse:Parser", ptr %t121, i32 0, i32 17
  %t124 = load i1, ptr %t123, !tbaa !21
  store i1 %t124, ptr %l12, !tbaa !21
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t128 = getelementptr %"compiler/parse:Parser", ptr %t126, i32 0, i32 16
  %t129 = load i1, ptr %t128, !tbaa !21
  store i1 %t129, ptr %l13, !tbaa !21
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/parse:Parser", ptr %t131, i32 0, i32 17
  store i1 false, ptr %t135, !tbaa !21
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t140 = getelementptr %"compiler/parse:Parser", ptr %t136, i32 0, i32 16
  store i1 false, ptr %t140, !tbaa !21
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t143 = getelementptr %"compiler/parse:Parser", ptr %t141, i32 0, i32 35
  %t145 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t143)
  store i64 %t145, ptr %l77
  br label %bb14
bb14:
  %t146 = load i64, ptr %l77, !tbaa !24
  store i64 %t146, ptr %l16, !tbaa !24
  br label %bb15
bb15:
  %t147 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t147)
  br label %bb16
bb16:
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t152 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t149, i32 115)
  store i1 %t152, ptr %l81
  br label %bb17
bb17:
  %t153 = load i1, ptr %l81, !tbaa !21
  br i1 %t153, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb21
bb19:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t157 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t154, i32 0)
  store i1 %t157, ptr %l85
  br label %bb20
bb20:
  %t158 = load i1, ptr %l85, !tbaa !21
  store i1 %t158, ptr %l82, !tbaa !21
  br label %bb21
bb21:
  %t159 = load i1, ptr %l82, !tbaa !21
  br i1 %t159, label %bb22, label %bb23
bb22:
  br label %bb59
bb23:
  br label %bb24
bb24:
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t162 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %t160)
  store i1 %t162, ptr %l87
  br label %bb25
bb25:
  %t163 = load i1, ptr %l87, !tbaa !21
  br i1 %t163, label %bb26, label %bb27
bb26:
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 25
  %t167 = load i1, ptr %t166, !tbaa !21
  %t169 = xor i1 %t167, true
  br i1 %t169, label %bb28, label %bb29
bb27:
  br label %bb41
bb28:
  %t171 = load ptr, ptr %l0, !tbaa !29
  %t173 = getelementptr %"compiler/parse:Parser", ptr %t171, i32 0, i32 27
  %t174 = load i1, ptr %t173, !tbaa !21
  %t176 = xor i1 %t174, true
  store i1 %t176, ptr %l91, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l91, !tbaa !21
  br label %bb30
bb30:
  %t178 = load i1, ptr %l91, !tbaa !21
  br i1 %t178, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s5
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr %"compiler/parse:Parser", ptr %t179, i32 0, i32 0
  %t182 = load ptr, ptr %t181, !tbaa !29
  %t183 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t184 = load i32, ptr %t183, !tbaa !23
  %t187 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t182, i32 %t184)
  store i32 %t187, ptr %l98
  br label %bb33
bb32:
  br label %bb38
bb33:
  %t188 = load i32, ptr %l98, !tbaa !23
  store i32 %t188, ptr %l17, !tbaa !23
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t189)
  store %"compiler/token:Token" %t191, ptr %l100
  br label %bb34
bb34:
  %t192 = load %"compiler/token:Token", ptr %l100
  store %"compiler/token:Token" %t192, ptr %l18
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t195 = getelementptr %"compiler/parse:Parser", ptr %t193, i32 0, i32 5
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = getelementptr %"compiler/token:Token", ptr %l18, i32 0, i32 2
  %t198 = load i32, ptr %t197, !tbaa !23
  %t200 = sext i32 %t198 to i64
  %t201 = getelementptr %"compiler/token:Token", ptr %l18, i32 0, i32 3
  %t202 = load i32, ptr %t201, !tbaa !23
  %t204 = sext i32 %t202 to i64
  store { i64, [3 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 0
  store i64 3, ptr %t206
  %t208 = insertvalue { i64, i64, i64 } undef, i64 %t196, 0
  %t210 = insertvalue { i64, i64, i64 } %t208, i64 %t200, 1
  %t212 = insertvalue { i64, i64, i64 } %t210, i64 %t204, 2
  %t213 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 1
  store { i64, i64, i64 } %t212, ptr %t213
  %t214 = load { i64, [3 x i64] }, ptr %t205
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t218 = getelementptr %"compiler/parse:Parser", ptr %t216, i32 0, i32 4
  %t219 = load ptr, ptr %t218, !tbaa !29
  store ptr %t219, ptr %l109, !tbaa !29
  store { i64, [3 x i64] } %t214, ptr %l110
  %t221 = load i32, ptr %l17, !tbaa !23
  %t223 = sext i32 %t221 to i64
  store i64 %t223, ptr %l112, !tbaa !24
  %t224 = load ptr, ptr %l0, !tbaa !29
  %t226 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %s5, ptr %t224)
  store { i64, ptr } %t226, ptr %l114
  br label %bb35
bb35:
  %t227 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t228 = load i64, ptr %l112, !tbaa !24
  %t230 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %s5, ptr %v0, i64 %t228, { i64, ptr } %t227)
  store %"compiler/diagmsg:Msg" %t230, ptr %l116
  br label %bb36
bb36:
  %t231 = load ptr, ptr %l109, !tbaa !29
  %t232 = load { i64, [3 x i64] }, ptr %l110
  %t233 = load %"compiler/diagmsg:Msg", ptr %l116
  %t234 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v0, ptr %t231, { i64, [3 x i64] } %t232, %"compiler/diagmsg:Msg" %t233)
  store i64 %t234, ptr %l117
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  br label %bb38
bb38:
  %t235 = load ptr, ptr %l0, !tbaa !29
  %t237 = getelementptr %"compiler/parse:Parser", ptr %t235, i32 0, i32 35
  %t238 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t237, i64 %t238)
  br label %bb39
bb39:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/parse:Parser", ptr %t241, i32 0, i32 27
  store i1 true, ptr %t243, !tbaa !21
  store i32 65536, ptr %l122, !tbaa !23
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load i1, ptr %l12, !tbaa !21
  %t248 = getelementptr %"compiler/parse:Parser", ptr %t244, i32 0, i32 17
  store i1 %t245, ptr %t248, !tbaa !21
  %t249 = load ptr, ptr %l0, !tbaa !29
  %t250 = load i1, ptr %l13, !tbaa !21
  %t253 = getelementptr %"compiler/parse:Parser", ptr %t249, i32 0, i32 16
  store i1 %t250, ptr %t253, !tbaa !21
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t255 = load i1, ptr %l6, !tbaa !21
  %t258 = getelementptr %"compiler/parse:Parser", ptr %t254, i32 0, i32 15
  store i1 %t255, ptr %t258, !tbaa !21
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i1, ptr %l7, !tbaa !21
  %t263 = getelementptr %"compiler/parse:Parser", ptr %t259, i32 0, i32 18
  store i1 %t260, ptr %t263, !tbaa !21
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t265 = load i1, ptr %l8, !tbaa !21
  %t268 = getelementptr %"compiler/parse:Parser", ptr %t264, i32 0, i32 19
  store i1 %t265, ptr %t268, !tbaa !21
  %t269 = load ptr, ptr %l0, !tbaa !29
  %t270 = load i1, ptr %l5, !tbaa !21
  %t273 = getelementptr %"compiler/parse:Parser", ptr %t269, i32 0, i32 23
  store i1 %t270, ptr %t273, !tbaa !21
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load i1, ptr %l4, !tbaa !21
  %t278 = getelementptr %"compiler/parse:Parser", ptr %t274, i32 0, i32 22
  store i1 %t275, ptr %t278, !tbaa !21
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t280 = load i64, ptr %l3, !tbaa !24
  %t283 = getelementptr %"compiler/parse:Parser", ptr %t279, i32 0, i32 21
  store i64 %t280, ptr %t283, !tbaa !24
  %t284 = load ptr, ptr %l0, !tbaa !29
  %t285 = load i1, ptr %l2, !tbaa !21
  %t288 = getelementptr %"compiler/parse:Parser", ptr %t284, i32 0, i32 12
  store i1 %t285, ptr %t288, !tbaa !21
  %t289 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t289)
  br label %bb40
bb40:
  %t291 = load i32, ptr %l122, !tbaa !23
  %t292 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t291, 0
  store { i32, { i64, ptr } } %t292, ptr %rv
  br label %ret
bb41:
  %t293 = load ptr, ptr %l0, !tbaa !29
  %t295 = call %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %t293)
  store %"compiler/parse:stackMarks" %t295, ptr %l143
  br label %bb42
bb42:
  %t296 = load %"compiler/parse:stackMarks", ptr %l143
  store %"compiler/parse:stackMarks" %t296, ptr %l20
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/parse:Parser", ptr %t297, i32 0, i32 6
  %t300 = load i64, ptr %t299, !tbaa !24
  store i64 %t300, ptr %l21, !tbaa !24
  %t302 = load ptr, ptr %l0, !tbaa !29
  %t304 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %v0, ptr %t302)
  %t305 = extractvalue { i32, ptr } %t304, 1
  %t306 = extractvalue { i32, ptr } %t304, 0
  store i32 %t306, ptr %l149
  %t307 = icmp ne i32 %t306, 0
  br i1 %t307, label %bb44, label %ok.308, !prof !99
ok.308:
  store ptr %t305, ptr %l148
  br label %bb43
bb43:
  %t309 = load ptr, ptr %l148, !tbaa !29
  store ptr %t309, ptr %l146, !tbaa !29
  br label %bb56
bb44:
  br label %bb45
bb45:
  %t310 = load ptr, ptr %l0, !tbaa !29
  %t312 = getelementptr %"compiler/parse:Parser", ptr %t310, i32 0, i32 25
  %t313 = load i1, ptr %t312, !tbaa !21
  br i1 %t313, label %bb46, label %bb47
bb46:
  store i1 true, ptr %l152, !tbaa !21
  br label %bb48
bb47:
  %t315 = load ptr, ptr %l0, !tbaa !29
  %t317 = getelementptr %"compiler/parse:Parser", ptr %t315, i32 0, i32 27
  %t318 = load i1, ptr %t317, !tbaa !21
  store i1 %t318, ptr %l152, !tbaa !21
  br label %bb48
bb48:
  %t320 = load i1, ptr %l152, !tbaa !21
  br i1 %t320, label %bb49, label %bb50
bb49:
  %t321 = load ptr, ptr %l0, !tbaa !29
  %t323 = getelementptr %"compiler/parse:Parser", ptr %t321, i32 0, i32 35
  %t324 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t323, i64 %t324)
  br label %bb51
bb50:
  br label %bb53
bb51:
  store i32 65536, ptr %l158, !tbaa !23
  %t327 = load ptr, ptr %l0, !tbaa !29
  %t328 = load i1, ptr %l12, !tbaa !21
  %t331 = getelementptr %"compiler/parse:Parser", ptr %t327, i32 0, i32 17
  store i1 %t328, ptr %t331, !tbaa !21
  %t332 = load ptr, ptr %l0, !tbaa !29
  %t333 = load i1, ptr %l13, !tbaa !21
  %t336 = getelementptr %"compiler/parse:Parser", ptr %t332, i32 0, i32 16
  store i1 %t333, ptr %t336, !tbaa !21
  %t337 = load ptr, ptr %l0, !tbaa !29
  %t338 = load i1, ptr %l6, !tbaa !21
  %t341 = getelementptr %"compiler/parse:Parser", ptr %t337, i32 0, i32 15
  store i1 %t338, ptr %t341, !tbaa !21
  %t342 = load ptr, ptr %l0, !tbaa !29
  %t343 = load i1, ptr %l7, !tbaa !21
  %t346 = getelementptr %"compiler/parse:Parser", ptr %t342, i32 0, i32 18
  store i1 %t343, ptr %t346, !tbaa !21
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t348 = load i1, ptr %l8, !tbaa !21
  %t351 = getelementptr %"compiler/parse:Parser", ptr %t347, i32 0, i32 19
  store i1 %t348, ptr %t351, !tbaa !21
  %t352 = load ptr, ptr %l0, !tbaa !29
  %t353 = load i1, ptr %l5, !tbaa !21
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t352, i32 0, i32 23
  store i1 %t353, ptr %t356, !tbaa !21
  %t357 = load ptr, ptr %l0, !tbaa !29
  %t358 = load i1, ptr %l4, !tbaa !21
  %t361 = getelementptr %"compiler/parse:Parser", ptr %t357, i32 0, i32 22
  store i1 %t358, ptr %t361, !tbaa !21
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t363 = load i64, ptr %l3, !tbaa !24
  %t366 = getelementptr %"compiler/parse:Parser", ptr %t362, i32 0, i32 21
  store i64 %t363, ptr %t366, !tbaa !24
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i1, ptr %l2, !tbaa !21
  %t371 = getelementptr %"compiler/parse:Parser", ptr %t367, i32 0, i32 12
  store i1 %t368, ptr %t371, !tbaa !21
  %t372 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t372)
  br label %bb52
bb52:
  %t374 = load i32, ptr %l158, !tbaa !23
  %t375 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t374, 0
  store { i32, { i64, ptr } } %t375, ptr %rv
  br label %ret
bb53:
  %t376 = load ptr, ptr %l0, !tbaa !29
  %t377 = load %"compiler/parse:stackMarks", ptr %l20
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %t376, %"compiler/parse:stackMarks" %t377)
  br label %bb54
bb54:
  %t380 = load ptr, ptr %l0, !tbaa !29
  %t382 = getelementptr %"compiler/parse:Parser", ptr %t380, i32 0, i32 22
  store i1 false, ptr %t382, !tbaa !21
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t384 = load i64, ptr %l21, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %t383, i64 %t384)
  br label %bb55
bb55:
  br label %bb58
bb56:
  %t387 = load ptr, ptr %l146, !tbaa !29
  %t388 = load ptr, ptr %l0, !tbaa !29
  %t390 = getelementptr %"compiler/parse:Parser", ptr %t388, i32 0, i32 35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t390, ptr %t387)
  br label %bb57
bb57:
  br label %bb58
bb58:
  br label %bb15
bb59:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t397 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t394, i32 115)
  store i1 %t397, ptr %l188
  br label %bb60
bb60:
  %t398 = load i1, ptr %l188, !tbaa !21
  %t399 = xor i1 %t398, true
  br i1 %t399, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s34
  %t401 = load ptr, ptr %l0, !tbaa !29
  %t403 = getelementptr %"compiler/parse:Parser", ptr %t401, i32 0, i32 35
  %t404 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t403, i64 %t404)
  br label %bb63
bb62:
  br label %bb69
bb63:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l193, !tbaa !29
  %t409 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s34, i32 115)
  store { i64, ptr } %t409, ptr %l195
  br label %bb64
bb64:
  %t410 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t411 = load ptr, ptr %l193, !tbaa !29
  %t413 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s34, ptr %t411, { i64, ptr } %t410)
  store i32 %t413, ptr %l197
  %t414 = icmp ne i32 %t413, 0
  br i1 %t414, label %bb66, label %ok.415, !prof !99
ok.415:
  br label %bb65
bb65:
  br label %bb68
bb66:
  %t416 = load i32, ptr %l197, !tbaa !23
  %t417 = lshr i32 %t416, 16
  %t418 = and i32 %t416, 65535
  %t419 = icmp eq i32 %t417, 1
  %t420 = select i1 %t419, i32 1, i32 0
  %t421 = icmp eq i32 %t416, 0
  %t422 = shl i32 %t420, 16
  %t423 = or i32 %t422, %t418
  %t424 = select i1 %t421, i32 0, i32 %t423
  store i32 %t424, ptr %l198, !tbaa !23
  call void @__olang_scope_close(ptr %s34)
  %t425 = load ptr, ptr %l0, !tbaa !29
  %t426 = load i1, ptr %l12, !tbaa !21
  %t429 = getelementptr %"compiler/parse:Parser", ptr %t425, i32 0, i32 17
  store i1 %t426, ptr %t429, !tbaa !21
  %t430 = load ptr, ptr %l0, !tbaa !29
  %t431 = load i1, ptr %l13, !tbaa !21
  %t434 = getelementptr %"compiler/parse:Parser", ptr %t430, i32 0, i32 16
  store i1 %t431, ptr %t434, !tbaa !21
  %t435 = load ptr, ptr %l0, !tbaa !29
  %t436 = load i1, ptr %l6, !tbaa !21
  %t439 = getelementptr %"compiler/parse:Parser", ptr %t435, i32 0, i32 15
  store i1 %t436, ptr %t439, !tbaa !21
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i1, ptr %l7, !tbaa !21
  %t444 = getelementptr %"compiler/parse:Parser", ptr %t440, i32 0, i32 18
  store i1 %t441, ptr %t444, !tbaa !21
  %t445 = load ptr, ptr %l0, !tbaa !29
  %t446 = load i1, ptr %l8, !tbaa !21
  %t449 = getelementptr %"compiler/parse:Parser", ptr %t445, i32 0, i32 19
  store i1 %t446, ptr %t449, !tbaa !21
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load i1, ptr %l5, !tbaa !21
  %t454 = getelementptr %"compiler/parse:Parser", ptr %t450, i32 0, i32 23
  store i1 %t451, ptr %t454, !tbaa !21
  %t455 = load ptr, ptr %l0, !tbaa !29
  %t456 = load i1, ptr %l4, !tbaa !21
  %t459 = getelementptr %"compiler/parse:Parser", ptr %t455, i32 0, i32 22
  store i1 %t456, ptr %t459, !tbaa !21
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i64, ptr %l3, !tbaa !24
  %t464 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 21
  store i64 %t461, ptr %t464, !tbaa !24
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t466 = load i1, ptr %l2, !tbaa !21
  %t469 = getelementptr %"compiler/parse:Parser", ptr %t465, i32 0, i32 12
  store i1 %t466, ptr %t469, !tbaa !21
  %t470 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t470)
  br label %bb67
bb67:
  %t472 = load i32, ptr %l198, !tbaa !23
  %t473 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t472, 0
  store { i32, { i64, ptr } } %t473, ptr %rv
  br label %ret
bb68:
  call void @__olang_scope_close(ptr %s34)
  br label %bb69
bb69:
  %t474 = load ptr, ptr %l0, !tbaa !29
  %t476 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t474)
  store i32 %t476, ptr %l219
  br label %bb70
bb70:
  %t477 = load ptr, ptr %l0, !tbaa !29
  %t479 = getelementptr %"compiler/parse:Parser", ptr %t477, i32 0, i32 35
  %t480 = load i64, ptr %l16, !tbaa !24
  %t483 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %t479, i64 %t480)
  store { i64, ptr } %t483, ptr %l223
  br label %bb71
bb71:
  %t484 = load ptr, ptr %l0, !tbaa !29
  %t485 = load i1, ptr %l12, !tbaa !21
  %t488 = getelementptr %"compiler/parse:Parser", ptr %t484, i32 0, i32 17
  store i1 %t485, ptr %t488, !tbaa !21
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load i1, ptr %l13, !tbaa !21
  %t493 = getelementptr %"compiler/parse:Parser", ptr %t489, i32 0, i32 16
  store i1 %t490, ptr %t493, !tbaa !21
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load i1, ptr %l6, !tbaa !21
  %t498 = getelementptr %"compiler/parse:Parser", ptr %t494, i32 0, i32 15
  store i1 %t495, ptr %t498, !tbaa !21
  %t499 = load ptr, ptr %l0, !tbaa !29
  %t500 = load i1, ptr %l7, !tbaa !21
  %t503 = getelementptr %"compiler/parse:Parser", ptr %t499, i32 0, i32 18
  store i1 %t500, ptr %t503, !tbaa !21
  %t504 = load ptr, ptr %l0, !tbaa !29
  %t505 = load i1, ptr %l8, !tbaa !21
  %t508 = getelementptr %"compiler/parse:Parser", ptr %t504, i32 0, i32 19
  store i1 %t505, ptr %t508, !tbaa !21
  %t509 = load ptr, ptr %l0, !tbaa !29
  %t510 = load i1, ptr %l5, !tbaa !21
  %t513 = getelementptr %"compiler/parse:Parser", ptr %t509, i32 0, i32 23
  store i1 %t510, ptr %t513, !tbaa !21
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load i1, ptr %l4, !tbaa !21
  %t518 = getelementptr %"compiler/parse:Parser", ptr %t514, i32 0, i32 22
  store i1 %t515, ptr %t518, !tbaa !21
  %t519 = load ptr, ptr %l0, !tbaa !29
  %t520 = load i64, ptr %l3, !tbaa !24
  %t523 = getelementptr %"compiler/parse:Parser", ptr %t519, i32 0, i32 21
  store i64 %t520, ptr %t523, !tbaa !24
  %t524 = load ptr, ptr %l0, !tbaa !29
  %t525 = load i1, ptr %l2, !tbaa !21
  %t528 = getelementptr %"compiler/parse:Parser", ptr %t524, i32 0, i32 12
  store i1 %t525, ptr %t528, !tbaa !21
  %t529 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t529)
  br label %bb72
bb72:
  %t531 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t532 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t531, 1
  store { i32, { i64, ptr } } %t532, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %a0)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l1, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = insertvalue { i32, ptr } zeroinitializer, ptr %t20, 1
  store { i32, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseTypeRef(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %lp3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca [0 x ptr]
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca { i64, ptr }
  %rv = alloca ptr
  %t94 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 39
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i64, ptr %l8, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  store [0 x ptr] zeroinitializer, ptr %l9
  %t7 = mul i64 0, 8
  %t8 = insertvalue { i64, ptr } undef, i64 0, 0
  %t9 = insertvalue { i64, ptr } %t8, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t9, ptr %l10, !tbaa !27
  %t10 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = mul i64 0, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t11, ptr %l9, i64 %t12, i1 false)
  %t13 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 16, i64 8)
  store ptr %t13, ptr %lp3
  %t14 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t15 = load ptr, ptr %lp3
  store { i64, ptr } %t14, ptr %t15, !tbaa !27
  %t16 = load ptr, ptr %l1, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  store i1 false, ptr %l12, !tbaa !21
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = icmp ne ptr %t17, null
  br i1 %t18, label %bb2, label %bb3
bb2:
  %t20 = load ptr, ptr %l11, !tbaa !29
  %t21 = load i64, ptr %t20, !range !{i64 0, i64 28}
  %t23 = icmp eq i64 %t21, 11
  store i1 %t23, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t25 = load ptr, ptr %l1, !tbaa !29
  %t27 = getelementptr { i64, [4 x i64] }, ptr %t25, i32 0, i32 1
  %t28 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t27, i32 0, i32 1
  %t29 = load ptr, ptr %t28
  store ptr %t29, ptr %l4, !tbaa !29
  %t31 = load ptr, ptr %l1, !tbaa !29
  %t33 = getelementptr { i64, [4 x i64] }, ptr %t31, i32 0, i32 1
  %t34 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t33, i32 0, i32 2
  %t35 = load { i64, ptr }, ptr %t34
  store { i64, ptr } %t35, ptr %l5, !tbaa !27
  br label %bb6
bb5:
  br label %bb11
bb6:
  %t37 = load ptr, ptr %l4, !tbaa !29
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 39
  call void @compiler_2fparse_2epathIds(ptr %v1, ptr %v0, ptr %t37, ptr %t40)
  br label %bb7
bb7:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l23, !tbaa !27
  %t45 = load ptr, ptr %lp3
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 0
  %t48 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 0
  store i64 %t49, ptr %l25, !tbaa !24
  %t51 = load i64, ptr %l25, !tbaa !24
  %t52 = icmp eq i64 %t47, %t51
  br i1 %t52, label %bb8, label %bb9
bb8:
  %t54 = load ptr, ptr %lp3
  %t55 = getelementptr { i64, ptr }, ptr %t54, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t58 = load ptr, ptr %t57, !tbaa !27
  %t59 = load i64, ptr %l25, !tbaa !24
  %t60 = mul i64 %t59, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t56, ptr %t58, i64 %t60, i1 false)
  br label %bb10
bb9:
  %t61 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l27, !tbaa !24
  %t63 = load i64, ptr %l27, !tbaa !24
  %t64 = mul i64 %t63, 8
  %t65 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  store { i64, ptr } %t67, ptr %l28, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = load i64, ptr %l27, !tbaa !24
  %t73 = mul i64 %t72, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t69, ptr %t71, i64 %t73, i1 false)
  %t74 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t75 = load ptr, ptr %lp3
  store { i64, ptr } %t74, ptr %t75, !tbaa !27
  br label %bb10
bb10:
  br label %bb17
bb11:
  br i1 true, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/parse:Parser", ptr %t77, i32 0, i32 39
  call void @compiler_2fparse_2epathIds(ptr %v1, ptr %v0, ptr %t76, ptr %t79)
  br label %bb15
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_34fec3df9092f56c_7b6dc988b92a4ce8)
  unreachable
bb17:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t82)
  store %"compiler/source:Span" %t84, ptr %l33
  br label %bb18
bb18:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 39
  %t88 = load i64, ptr %l2, !tbaa !24
  %t91 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v2, ptr %t87, i64 %t88)
  store { i64, ptr } %t91, ptr %l37
  br label %bb19
bb19:
  %t92 = load ptr, ptr %lp3
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t94
  %t95 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 0
  store i64 0, ptr %t95
  %t96 = load %"compiler/source:Span", ptr %l33
  %t97 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t96, 0
  %t98 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t99 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t97, { i64, ptr } %t98, 1
  %t101 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t99, { i64, ptr } %t93, 2
  %t102 = getelementptr { i64, [5 x i64] }, ptr %t94, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t101, ptr %t102
  %t103 = load { i64, [5 x i64] }, ptr %t94
  %t105 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t103, ptr %t105
  store ptr %t105, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i32
  %l8 = alloca i32
  %l15 = alloca i64
  %l20 = alloca i1
  %l23 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i1
  %l35 = alloca i1
  %l43 = alloca i1
  %l46 = alloca i1
  %l57 = alloca i1
  %l62 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t6 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t8 = trunc i64 75 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t14, i64 %t15)
  store i64 %t18, ptr %l15
  br label %bb5
bb5:
  %t19 = load i64, ptr %l15, !tbaa !24
  store i64 %t19, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l1, !tbaa !24
  %t22 = sub i64 %t20, 1
  store i64 %t22, ptr %l4, !tbaa !24
  br label %bb6
bb6:
  %t24 = load i64, ptr %l4, !tbaa !24
  %t26 = icmp sge i64 %t24, 0
  br i1 %t26, label %bb7, label %bb8
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t29 = load i64, ptr %l4, !tbaa !24
  %t32 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t28, i64 %t29)
  store i64 %t32, ptr %l23
  br label %bb9
bb8:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb10
bb9:
  %t33 = load i64, ptr %l2, !tbaa !24
  %t34 = load i64, ptr %l23, !tbaa !24
  %t36 = icmp eq i64 %t34, %t33
  store i1 %t36, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t38 = load i1, ptr %l20, !tbaa !21
  %t39 = xor i1 %t38, true
  br i1 %t39, label %bb11, label %bb12
bb11:
  br label %bb44
bb12:
  br label %bb13
bb13:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t42 = load i64, ptr %l4, !tbaa !24
  %t45 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t41, i64 %t42)
  store i32 %t45, ptr %l29
  br label %bb14
bb14:
  %t46 = load i32, ptr %l29, !range !{i32 0, i32 116}
  store i32 %t46, ptr %l5
  %t47 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t49 = trunc i64 111 to i32
  %t50 = icmp eq i32 %t47, %t49
  br i1 %t50, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l32, !tbaa !21
  br label %bb17
bb16:
  %t52 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t54 = trunc i64 113 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l32, !tbaa !21
  br label %bb17
bb17:
  %t57 = load i1, ptr %l32, !tbaa !21
  br i1 %t57, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb20
bb19:
  %t58 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t60 = trunc i64 115 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l35, !tbaa !21
  br label %bb20
bb20:
  %t63 = load i1, ptr %l35, !tbaa !21
  br i1 %t63, label %bb21, label %bb22
bb21:
  %t64 = load i64, ptr %l3, !tbaa !24
  %t67 = add i64 %t64, 1
  store i64 %t67, ptr %l3, !tbaa !24
  br label %bb42
bb22:
  %t69 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t71 = trunc i64 110 to i32
  %t72 = icmp eq i32 %t69, %t71
  br i1 %t72, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb25
bb24:
  %t74 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t76 = trunc i64 112 to i32
  %t77 = icmp eq i32 %t74, %t76
  store i1 %t77, ptr %l43, !tbaa !21
  br label %bb25
bb25:
  %t79 = load i1, ptr %l43, !tbaa !21
  br i1 %t79, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb28
bb27:
  %t80 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t82 = trunc i64 114 to i32
  %t83 = icmp eq i32 %t80, %t82
  store i1 %t83, ptr %l46, !tbaa !21
  br label %bb28
bb28:
  %t85 = load i1, ptr %l46, !tbaa !21
  br i1 %t85, label %bb29, label %bb30
bb29:
  %t86 = load i64, ptr %l3, !tbaa !24
  %t88 = icmp eq i64 %t86, 0
  br i1 %t88, label %bb31, label %bb32
bb30:
  %t90 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t92 = trunc i64 79 to i32
  %t93 = icmp eq i32 %t90, %t92
  br i1 %t93, label %bb34, label %bb35
bb31:
  store i1 false, ptr %rv
  br label %ret
bb32:
  br label %bb33
bb33:
  %t96 = load i64, ptr %l3, !tbaa !24
  %t99 = sub i64 %t96, 1
  store i64 %t99, ptr %l3, !tbaa !24
  br label %bb41
bb34:
  %t101 = load i64, ptr %l3, !tbaa !24
  %t103 = icmp eq i64 %t101, 0
  store i1 %t103, ptr %l57, !tbaa !21
  br label %bb36
bb35:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb36
bb36:
  %t105 = load i1, ptr %l57, !tbaa !21
  br i1 %t105, label %bb37, label %bb38
bb37:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t107 = load i64, ptr %l4, !tbaa !24
  %t110 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineStartsCase(ptr %v0, ptr %t106, i64 %t107)
  store i1 %t110, ptr %l62
  br label %bb39
bb38:
  br label %bb40
bb39:
  %t111 = load i1, ptr %l62, !tbaa !21
  store i1 %t111, ptr %rv
  br label %ret
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t112 = load i64, ptr %l4, !tbaa !24
  %t115 = sub i64 %t112, 1
  store i64 %t115, ptr %l4, !tbaa !24
  br label %bb43
bb43:
  br label %bb6
bb44:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclHere(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l8 = alloca i1
  %l12 = alloca i1
  %l16 = alloca i32
  %l21 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3, !range !{i32 0, i32 116}
  store i32 %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 12
  %t8 = load i1, ptr %t7, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %t10)
  store i1 %t12, ptr %l8
  br label %bb4
bb3:
  store i1 false, ptr %l6, !tbaa !21
  br label %bb5
bb4:
  %t13 = load i1, ptr %l8, !tbaa !21
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb5
bb5:
  %t14 = load i1, ptr %l6, !tbaa !21
  br i1 %t14, label %bb6, label %bb7
bb6:
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 37 to i32
  %t19 = icmp eq i32 %t16, %t18
  br i1 %t19, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb11
bb10:
  %t21 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t23 = trunc i64 33 to i32
  %t24 = icmp eq i32 %t21, %t23
  store i1 %t24, ptr %l12, !tbaa !21
  br label %bb11
bb11:
  %t26 = load i1, ptr %l12, !tbaa !21
  br i1 %t26, label %bb12, label %bb13
bb12:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t27, i64 1)
  store i32 %t29, ptr %l16
  br label %bb14
bb13:
  br label %bb15
bb14:
  %t30 = load i32, ptr %l16, !range !{i32 0, i32 116}
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %rv
  br label %ret
bb15:
  %t35 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t37 = trunc i64 41 to i32
  %t38 = icmp eq i32 %t35, %t37
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb18
bb17:
  %t40 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t42 = trunc i64 40 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb18
bb18:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb21
bb20:
  %t46 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t48 = trunc i64 43 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb21
bb21:
  %t51 = load i1, ptr %l24, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l4 = alloca i32
  %l10 = alloca i1
  %l15 = alloca i32
  %l18 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %l36 = alloca i1
  %l39 = alloca i1
  %l42 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i1
  %l55 = alloca i1
  %l57 = alloca i1
  %l58 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l62 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i32, ptr %l4, !range !{i32 0, i32 116}
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t7 = trunc i64 8 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 17
  %t13 = load i1, ptr %t12, !tbaa !21
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb3:
  br label %bb11
bb4:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 18
  %t20 = load i1, ptr %t19, !tbaa !21
  %t22 = xor i1 %t20, true
  store i1 %t22, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t25)
  store i32 %t27, ptr %l15
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb11:
  %t28 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t30 = trunc i64 115 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb14
bb13:
  %t33 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t35 = trunc i64 0 to i32
  %t36 = icmp eq i32 %t33, %t35
  store i1 %t36, ptr %l18, !tbaa !21
  br label %bb14
bb14:
  %t38 = load i1, ptr %l18, !tbaa !21
  br i1 %t38, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/parse:Parser", ptr %t39, i32 0, i32 15
  %t42 = load i1, ptr %t41, !tbaa !21
  br i1 %t42, label %bb18, label %bb19
bb18:
  %t44 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t46 = trunc i64 10 to i32
  %t47 = icmp eq i32 %t44, %t46
  br i1 %t47, label %bb20, label %bb21
bb19:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb23
bb20:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb22
bb21:
  %t49 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t51 = trunc i64 12 to i32
  %t52 = icmp eq i32 %t49, %t51
  store i1 %t52, ptr %l26, !tbaa !21
  br label %bb22
bb22:
  %t54 = load i1, ptr %l26, !tbaa !21
  store i1 %t54, ptr %l23, !tbaa !21
  br label %bb23
bb23:
  %t55 = load i1, ptr %l23, !tbaa !21
  br i1 %t55, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb25:
  br label %bb26
bb26:
  %t56 = load ptr, ptr %l0, !tbaa !29
  %t58 = getelementptr %"compiler/parse:Parser", ptr %t56, i32 0, i32 19
  %t59 = load i1, ptr %t58, !tbaa !21
  br i1 %t59, label %bb27, label %bb28
bb27:
  %t61 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t63 = trunc i64 25 to i32
  %t64 = icmp eq i32 %t61, %t63
  store i1 %t64, ptr %l31, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb29
bb29:
  %t66 = load i1, ptr %l31, !tbaa !21
  br i1 %t66, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb31:
  br label %bb32
bb32:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = getelementptr %"compiler/parse:Parser", ptr %t67, i32 0, i32 17
  %t70 = load i1, ptr %t69, !tbaa !21
  br i1 %t70, label %bb33, label %bb34
bb33:
  %t72 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t74 = trunc i64 111 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb35, label %bb36
bb34:
  store i1 false, ptr %l36, !tbaa !21
  br label %bb41
bb35:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb37
bb36:
  %t77 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t79 = trunc i64 113 to i32
  %t80 = icmp eq i32 %t77, %t79
  store i1 %t80, ptr %l39, !tbaa !21
  br label %bb37
bb37:
  %t82 = load i1, ptr %l39, !tbaa !21
  br i1 %t82, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l42, !tbaa !21
  br label %bb40
bb39:
  %t83 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t85 = trunc i64 75 to i32
  %t86 = icmp eq i32 %t83, %t85
  store i1 %t86, ptr %l42, !tbaa !21
  br label %bb40
bb40:
  %t88 = load i1, ptr %l42, !tbaa !21
  store i1 %t88, ptr %l36, !tbaa !21
  br label %bb41
bb41:
  %t89 = load i1, ptr %l36, !tbaa !21
  br i1 %t89, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb43:
  br label %bb44
bb44:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t92 = getelementptr %"compiler/parse:Parser", ptr %t90, i32 0, i32 9
  %t93 = load i32, ptr %t92, !range !{i32 0, i32 116}
  store i32 %t93, ptr %l2
  %t95 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t97 = trunc i64 102 to i32
  %t98 = icmp eq i32 %t95, %t97
  br i1 %t98, label %bb45, label %bb46
bb45:
  store i1 true, ptr %l49, !tbaa !21
  br label %bb47
bb46:
  %t100 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t102 = trunc i64 100 to i32
  %t103 = icmp eq i32 %t100, %t102
  store i1 %t103, ptr %l49, !tbaa !21
  br label %bb47
bb47:
  %t105 = load i1, ptr %l49, !tbaa !21
  br i1 %t105, label %bb48, label %bb49
bb48:
  store i1 true, ptr %l52, !tbaa !21
  br label %bb50
bb49:
  %t106 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t108 = trunc i64 115 to i32
  %t109 = icmp eq i32 %t106, %t108
  store i1 %t109, ptr %l52, !tbaa !21
  br label %bb50
bb50:
  %t111 = load i1, ptr %l52, !tbaa !21
  br i1 %t111, label %bb51, label %bb52
bb51:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %t112)
  store i1 %t114, ptr %l57
  br label %bb53
bb52:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb54
bb53:
  %t115 = load i1, ptr %l57, !tbaa !21
  store i1 %t115, ptr %l55, !tbaa !21
  br label %bb54
bb54:
  %t116 = load i1, ptr %l55, !tbaa !21
  br i1 %t116, label %bb55, label %bb56
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb56:
  br label %bb57
bb57:
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l58, !tbaa !29
  %t119 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t119, ptr %l60
  br label %bb58
bb58:
  %t120 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t121 = load ptr, ptr %l58, !tbaa !29
  %t123 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s0, ptr %t121, { i64, ptr } %t120)
  store i32 %t123, ptr %l62
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb60, label %ok.125, !prof !99
ok.125:
  br label %bb59
bb59:
  br label %bb61
bb60:
  %t126 = load i32, ptr %l62, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  call void @__olang_scope_close(ptr %s0)
  store i32 %t134, ptr %rv
  br label %ret
bb61:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorWords(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %l14 = alloca i1
  %l16 = alloca i32
  %l20 = alloca i1
  %l24 = alloca i32
  %l25 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i32
  %l41 = alloca ptr
  %l44 = alloca %"compiler/source:Span"
  %l47 = alloca %"compiler/ast:CaseDecl"
  %l50 = alloca i32
  %l53 = alloca i32
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 114)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l9
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l8
  br label %bb1
bb1:
  %t9 = load i32, ptr %l8, !tbaa !23
  store i32 %t9, ptr %l5, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l9, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t20)
  br label %bb4
bb4:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 115)
  store i1 %t25, ptr %l14
  br label %bb5
bb5:
  %t26 = load i1, ptr %l14, !tbaa !21
  br i1 %t26, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s1, ptr %t27, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d0, i32 0, i32 1) })
  store i32 %t29, ptr %l16
  %t30 = icmp ne i32 %t29, 0
  br i1 %t30, label %bb9, label %ok.31, !prof !99
ok.31:
  br label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb10
bb9:
  %t32 = load i32, ptr %l16, !tbaa !23
  %t33 = lshr i32 %t32, 16
  %t34 = and i32 %t32, 65535
  %t35 = icmp eq i32 %t33, 1
  %t36 = select i1 %t35, i32 1, i32 0
  %t37 = icmp eq i32 %t32, 0
  %t38 = shl i32 %t36, 16
  %t39 = or i32 %t38, %t34
  %t40 = select i1 %t37, i32 0, i32 %t39
  call void @__olang_scope_close(ptr %s1)
  store i32 %t40, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t42, i32 115)
  store i1 %t45, ptr %l20
  br label %bb13
bb13:
  %t46 = load i1, ptr %l20, !tbaa !21
  %t47 = xor i1 %t46, true
  %t49 = xor i1 %t47, true
  br i1 %t49, label %bb14, label %bb15
bb14:
  br label %bb39
bb15:
  br label %bb16
bb16:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t51)
  store i32 %t53, ptr %l24
  br label %bb17
bb17:
  %t54 = load i32, ptr %l24, !tbaa !23
  store i32 %t54, ptr %l2, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t55)
  %t58 = extractvalue { i32, i32 } %t57, 1
  %t59 = extractvalue { i32, i32 } %t57, 0
  store i32 %t59, ptr %l28
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb19, label %ok.61, !prof !99
ok.61:
  store i32 %t58, ptr %l27
  br label %bb18
bb18:
  %t62 = load i32, ptr %l27, !tbaa !23
  store i32 %t62, ptr %l25, !tbaa !23
  br label %bb20
bb19:
  %t63 = load i32, ptr %l28, !tbaa !23
  %t64 = lshr i32 %t63, 16
  %t65 = and i32 %t63, 65535
  %t66 = icmp eq i32 %t64, 1
  %t67 = select i1 %t66, i32 1, i32 0
  %t68 = icmp eq i32 %t63, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t65
  %t71 = select i1 %t68, i32 0, i32 %t70
  store i32 %t71, ptr %rv
  br label %ret
bb20:
  %t73 = load i32, ptr %l25, !tbaa !23
  store i32 %t73, ptr %l3, !tbaa !23
  %t74 = icmp sge i64 0, 0
  br i1 %t74, label %bb21, label %bb22
bb21:
  %t76 = icmp sle i64 0, 1152921504606846975
  br i1 %t76, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @olang_loc_e134f20c62dd29bf_7d644e0c862b15db)
  unreachable
bb23:
  %t78 = mul i64 0, 8
  %t79 = insertvalue { i64, ptr } undef, i64 0, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t85 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t82, i32 110)
  store i1 %t85, ptr %l35
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_e134f20c62dd29bf_7d644e0c862b15db)
  unreachable
bb25:
  %t86 = load i1, ptr %l35, !tbaa !21
  br i1 %t86, label %bb26, label %bb27
bb26:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %t87, i1 false)
  %t90 = extractvalue { i32, { i64, ptr } } %t89, 1
  %t91 = extractvalue { i32, { i64, ptr } } %t89, 0
  store i32 %t91, ptr %l39
  %t92 = icmp ne i32 %t91, 0
  br i1 %t92, label %bb29, label %ok.93, !prof !99
ok.93:
  store { i64, ptr } %t90, ptr %l38
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t94 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t94, ptr %l36, !tbaa !27
  br label %bb30
bb29:
  %t95 = load i32, ptr %l39, !tbaa !23
  %t96 = lshr i32 %t95, 16
  %t97 = and i32 %t95, 65535
  %t98 = icmp eq i32 %t96, 1
  %t99 = select i1 %t98, i32 1, i32 0
  %t100 = icmp eq i32 %t95, 0
  %t101 = shl i32 %t99, 16
  %t102 = or i32 %t101, %t97
  %t103 = select i1 %t100, i32 0, i32 %t102
  store i32 %t103, ptr %rv
  br label %ret
bb30:
  %t105 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t105, ptr %l4, !tbaa !27
  br label %bb31
bb31:
  store ptr %a1, ptr %l41, !tbaa !29
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t108 = load i32, ptr %l2, !tbaa !23
  %t111 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t107, i32 %t108)
  store %"compiler/source:Span" %t111, ptr %l44
  br label %bb32
bb32:
  %t112 = load i32, ptr %l3, !tbaa !23
  %t113 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t114 = load %"compiler/source:Span", ptr %l44
  %t117 = call %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t114, i32 %t112, { i64, ptr } %t113, i1 false, ptr null)
  store %"compiler/ast:CaseDecl" %t117, ptr %l47
  br label %bb33
bb33:
  %t118 = load %"compiler/ast:CaseDecl", ptr %l47
  %t119 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store %"compiler/ast:CaseDecl" %t118, ptr %t119
  %t120 = load ptr, ptr %l41, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ePush_H43bc1cace347592514b4248ffd44c907(ptr %v1, ptr %v1, ptr %t120, ptr %t119)
  br label %bb34
bb34:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %t122)
  store i32 %t124, ptr %l50
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb36, label %ok.126, !prof !99
ok.126:
  br label %bb35
bb35:
  br label %bb37
bb36:
  %t127 = load i32, ptr %l50, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  store i32 %t135, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  br label %bb12
bb39:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t137)
  store i32 %t139, ptr %l53
  br label %bb40
bb40:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l17 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca i1
  %l28 = alloca ptr
  %l29 = alloca i1
  %l44 = alloca i32
  %l49 = alloca { i64, ptr }
  %l51 = alloca i64
  %l60 = alloca i64
  %l63 = alloca i64
  %l72 = alloca i64
  %l75 = alloca i1
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l98 = alloca %"compiler/source:Span"
  %l99 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t201 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 39
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l17
  br label %bb1
bb1:
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  store ptr %t7, ptr %l3, !tbaa !29
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l3, !tbaa !29
  store ptr %t9, ptr %l19, !tbaa !29
  store i1 false, ptr %l20, !tbaa !21
  %t10 = load ptr, ptr %l19, !tbaa !29
  %t11 = icmp ne ptr %t10, null
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l19, !tbaa !29
  %t14 = load i64, ptr %t13, !range !{i64 0, i64 28}
  %t16 = icmp eq i64 %t14, 0
  store i1 %t16, ptr %l20, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l20, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t18 = load ptr, ptr %l3, !tbaa !29
  %t20 = getelementptr { i64, [4 x i64] }, ptr %t18, i32 0, i32 1
  %t21 = getelementptr { %"compiler/source:Span", i32 }, ptr %t20, i32 0, i32 1
  %t22 = load i32, ptr %t21
  store i32 %t22, ptr %l4, !tbaa !23
  br label %bb7
bb6:
  br label %bb9
bb7:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t24, i32 0, i32 39
  %t27 = load i32, ptr %l4, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t26, i32 %t27)
  br label %bb8
bb8:
  br label %bb27
bb9:
  %t30 = load ptr, ptr %l3, !tbaa !29
  store ptr %t30, ptr %l28, !tbaa !29
  store i1 false, ptr %l29, !tbaa !21
  %t31 = load ptr, ptr %l28, !tbaa !29
  %t32 = icmp ne ptr %t31, null
  br i1 %t32, label %bb10, label %bb11
bb10:
  %t34 = load ptr, ptr %l28, !tbaa !29
  %t35 = load i64, ptr %t34, !range !{i64 0, i64 28}
  %t37 = icmp eq i64 %t35, 12
  store i1 %t37, ptr %l29, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l29, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  %t39 = load ptr, ptr %l3, !tbaa !29
  %t41 = getelementptr { i64, [4 x i64] }, ptr %t39, i32 0, i32 1
  %t42 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t41, i32 0, i32 1
  %t43 = load ptr, ptr %t42
  store ptr %t43, ptr %l5, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t47 = getelementptr { i64, [4 x i64] }, ptr %t45, i32 0, i32 1
  %t48 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t47, i32 0, i32 2
  %t49 = load i32, ptr %t48
  store i32 %t49, ptr %l6, !tbaa !23
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 39
  %t54 = load i32, ptr %l6, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t53, i32 %t54)
  br label %bb15
bb15:
  %t57 = load ptr, ptr %l5, !tbaa !29
  store ptr %t57, ptr %l3, !tbaa !29
  br label %bb25
bb16:
  br i1 true, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb24
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 39
  %t62 = load i64, ptr %l2, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t61, i64 %t62)
  br label %bb20
bb20:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t65, { i64, ptr } { i64 60, ptr getelementptr inbounds (<{ i64, [60 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i32 %t67, ptr %l44
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb22, label %ok.69, !prof !99
ok.69:
  br label %bb21
bb21:
  br label %bb23
bb22:
  %t70 = load i32, ptr %l44, !tbaa !23
  %t71 = lshr i32 %t70, 16
  %t72 = and i32 %t70, 65535
  %t73 = icmp eq i32 %t71, 1
  %t74 = select i1 %t73, i32 1, i32 0
  %t75 = icmp eq i32 %t70, 0
  %t76 = shl i32 %t74, 16
  %t77 = or i32 %t76, %t72
  %t78 = select i1 %t75, i32 0, i32 %t77
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t80 = insertvalue { i32, ptr } zeroinitializer, i32 %t78, 0
  store { i32, ptr } %t80, ptr %rv
  br label %ret
bb23:
  call void @__olang_scope_close(ptr %s4)
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_7f479cc541fc1ad4_6e65e2fdc3321828)
  unreachable
bb25:
  br label %bb26
bb26:
  br label %bb2
bb27:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 39
  %t84 = load i64, ptr %l2, !tbaa !24
  %t87 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %s0, ptr %t83, i64 %t84)
  store { i64, ptr } %t87, ptr %l49
  br label %bb28
bb28:
  %t88 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t88, ptr %l7, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 0
  store i64 %t91, ptr %l51, !tbaa !24
  %t92 = load i64, ptr %l51, !tbaa !24
  %t93 = icmp sge i64 %t92, 0
  br i1 %t93, label %bb29, label %bb30
bb29:
  %t95 = load i64, ptr %l51, !tbaa !24
  %t96 = icmp sle i64 %t95, 2305843009213693951
  br i1 %t96, label %bb31, label %bb32
bb30:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
bb31:
  %t98 = load i64, ptr %l51, !tbaa !24
  %t99 = mul i64 %t98, 4
  %t100 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t99)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t100, 1
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t104 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l10, !tbaa !24
  %t109 = load i64, ptr %l9, !tbaa !24
  %t112 = icmp sgt i64 %t108, %t109
  br i1 %t112, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a)
  unreachable
bb33:
  %t114 = load i64, ptr %l11, !tbaa !24
  %t116 = icmp sgt i64 %t114, 0
  br i1 %t116, label %bb35, label %bb36
bb34:
  store i64 0, ptr %l60, !tbaa !24
  br label %bb38
bb35:
  %t118 = load i64, ptr %l10, !tbaa !24
  %t119 = load i64, ptr %l9, !tbaa !24
  %t122 = sub i64 %t118, %t119
  %t123 = load i64, ptr %l11, !tbaa !24
  %t126 = add i64 %t122, %t123
  %t128 = sub i64 %t126, 1
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = sdiv i64 %t128, %t129
  store i64 %t132, ptr %l63, !tbaa !24
  br label %bb37
bb36:
  store i64 0, ptr %l63, !tbaa !24
  br label %bb37
bb37:
  %t134 = load i64, ptr %l63, !tbaa !24
  store i64 %t134, ptr %l60, !tbaa !24
  br label %bb38
bb38:
  %t135 = load i64, ptr %l60, !tbaa !24
  store i64 %t135, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  %t136 = load i64, ptr %l12, !tbaa !24
  %t137 = sub i64 %t136, 1
  store i64 %t137, ptr %l72, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = icmp slt i64 %t138, 2147483648
  %t140 = load i64, ptr %l13, !tbaa !24
  %t141 = icmp sge i64 %t140, 0
  %t144 = and i1 %t139, %t141
  store i1 %t144, ptr %l75, !tbaa !21
  br label %bb39
bb39:
  %t145 = load i64, ptr %l13, !tbaa !24
  %t146 = load i64, ptr %l12, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb40, label %bb41
bb40:
  br label %bb44
bb41:
  br label %bb42
bb42:
  %t153 = load i64, ptr %l9, !tbaa !24
  %t154 = load i64, ptr %l13, !tbaa !24
  %t155 = load i64, ptr %l11, !tbaa !24
  %t158 = mul i64 %t154, %t155
  %t161 = add i64 %t153, %t158
  store i64 %t161, ptr %l14, !tbaa !24
  %t163 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t163, ptr %l85, !tbaa !27
  %t164 = load i64, ptr %l14, !tbaa !24
  %t165 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t165, ptr %l87, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t170 = sub i64 %t168, 1
  %t171 = load i64, ptr %l14, !tbaa !24
  %t174 = sub i64 %t170, %t171
  %t176 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t177 = load ptr, ptr %t176, !tbaa !27
  %t178 = getelementptr i32, ptr %t177, i64 %t174
  %t179 = load i32, ptr %t178, !tbaa !33
  %t182 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t183 = load ptr, ptr %t182, !tbaa !27
  %t184 = getelementptr i32, ptr %t183, i64 %t164
  store i32 %t179, ptr %t184, !tbaa !33
  br label %bb43
bb43:
  %t185 = load i64, ptr %l13, !tbaa !24
  %t188 = add i64 %t185, 1
  store i64 %t188, ptr %l13, !tbaa !24
  br label %bb39
bb44:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t192 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t190)
  store %"compiler/source:Span" %t192, ptr %l98
  br label %bb45
bb45:
  %t193 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t193, ptr %l99, !tbaa !27
  %t194 = icmp sge i64 0, 0
  br i1 %t194, label %bb46, label %bb47
bb46:
  %t196 = icmp sle i64 0, 1152921504606846975
  br i1 %t196, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_6c22b543e414e27d_3e5c1ca73c24bcf9)
  unreachable
bb48:
  %t198 = mul i64 0, 8
  %t199 = insertvalue { i64, ptr } undef, i64 0, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [5 x i64] } zeroinitializer, ptr %t201
  %t202 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 0
  store i64 0, ptr %t202
  %t203 = load %"compiler/source:Span", ptr %l98
  %t204 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t203, 0
  %t205 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t206 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t204, { i64, ptr } %t205, 1
  %t208 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t206, { i64, ptr } %t200, 2
  %t209 = getelementptr { i64, [5 x i64] }, ptr %t201, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t208, ptr %t209
  %t210 = load { i64, [5 x i64] }, ptr %t201
  %t212 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t210, ptr %t212
  call void @__olang_scope_close(ptr %s0)
  %t214 = insertvalue { i32, ptr } zeroinitializer, ptr %t212, 1
  store { i32, ptr } %t214, ptr %rv
  br label %ret
bb49:
  call void @__olang_check_failed(ptr @olang_loc_6c22b543e414e27d_3e5c1ca73c24bcf9)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca ptr
  %l11 = alloca %"compiler/source:Span"
  %l12 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca %"compiler/source:Span"
  %l17 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i64
  %l34 = alloca i1
  %l37 = alloca ptr
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i32
  %l46 = alloca { i64, ptr }
  %l49 = alloca i1
  %l50 = alloca i1
  %l53 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l59 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i32
  %l68 = alloca i1
  %l69 = alloca i1
  %l72 = alloca i1
  %l73 = alloca i1
  %l76 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i32
  %l93 = alloca %"compiler/source:Span"
  %l95 = alloca i32
  %l97 = alloca %"compiler/source:Span"
  %l102 = alloca %"compiler/ast:Multi"
  %l106 = alloca ptr
  %l109 = alloca ptr
  %l110 = alloca i32
  %l114 = alloca i1
  %l117 = alloca i1
  %l118 = alloca i1
  %l121 = alloca i1
  %l122 = alloca i1
  %l125 = alloca i1
  %l128 = alloca %"compiler/source:Span"
  %l130 = alloca i32
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l140 = alloca %"compiler/ast:VarDecl"
  %l144 = alloca ptr
  %l148 = alloca ptr
  %l149 = alloca i32
  %l152 = alloca i32
  %l154 = alloca i1
  %l156 = alloca i32
  %l157 = alloca ptr
  %l159 = alloca ptr
  %l160 = alloca i32
  %l164 = alloca %"compiler/source:Span"
  %l166 = alloca i32
  %l176 = alloca %"compiler/source:Span"
  %l178 = alloca i32
  %rv = alloca { i32, ptr }
  %t233 = alloca { i64, [4 x i64] }, align 8
  %t334 = alloca { i64, [4 x i64] }, align 8
  %t428 = alloca { i64, [4 x i64] }, align 8
  %t468 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load i32, ptr %l17, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t5)
  %t8 = extractvalue { i32, ptr } %t7, 1
  %t9 = extractvalue { i32, ptr } %t7, 0
  store i32 %t9, ptr %l21
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store ptr %t8, ptr %l20
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l20, !tbaa !29
  store ptr %t12, ptr %l18, !tbaa !29
  br label %bb4
bb3:
  %t13 = load i32, ptr %l21, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load ptr, ptr %l18, !tbaa !29
  store ptr %t24, ptr %l2, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 75)
  store i1 %t28, ptr %l25
  br label %bb5
bb5:
  %t29 = load i1, ptr %l25, !tbaa !21
  br i1 %t29, label %bb6, label %bb7
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 34
  %t34 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t32)
  store i64 %t34, ptr %l28
  br label %bb8
bb7:
  br label %bb86
bb8:
  %t35 = load i64, ptr %l28, !tbaa !24
  store i64 %t35, ptr %l3, !tbaa !24
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 34
  %t39 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t38, ptr %t39)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t45 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t42, i32 75)
  store i1 %t45, ptr %l34
  br label %bb11
bb11:
  %t46 = load i1, ptr %l34, !tbaa !21
  %t47 = xor i1 %t46, true
  br i1 %t47, label %bb12, label %bb13
bb12:
  br label %bb20
bb13:
  br label %bb14
bb14:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"compiler/parse:Parser", ptr %t49, i32 0, i32 34
  store ptr %t51, ptr %l37, !tbaa !29
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v0, ptr %t52)
  %t55 = extractvalue { i32, ptr } %t54, 1
  %t56 = extractvalue { i32, ptr } %t54, 0
  store i32 %t56, ptr %l41
  %t57 = icmp ne i32 %t56, 0
  br i1 %t57, label %bb16, label %ok.58, !prof !99
ok.58:
  store ptr %t55, ptr %l40
  br label %bb15
bb15:
  %t59 = load ptr, ptr %l40, !tbaa !29
  store ptr %t59, ptr %l38, !tbaa !29
  br label %bb17
bb16:
  %t60 = load i32, ptr %l41, !tbaa !23
  %t61 = lshr i32 %t60, 16
  %t62 = and i32 %t60, 65535
  %t63 = icmp eq i32 %t61, 1
  %t64 = select i1 %t63, i32 1, i32 0
  %t65 = icmp eq i32 %t60, 0
  %t66 = shl i32 %t64, 16
  %t67 = or i32 %t66, %t62
  %t68 = select i1 %t65, i32 0, i32 %t67
  %t70 = insertvalue { i32, ptr } zeroinitializer, i32 %t68, 0
  store { i32, ptr } %t70, ptr %rv
  br label %ret
bb17:
  %t71 = load ptr, ptr %l37, !tbaa !29
  %t72 = load ptr, ptr %l38, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v0, ptr %t71, ptr %t72)
  br label %bb18
bb18:
  br label %bb19
bb19:
  br label %bb10
bb20:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/parse:Parser", ptr %t73, i32 0, i32 34
  %t76 = load i64, ptr %l3, !tbaa !24
  %t79 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %t75, i64 %t76)
  store { i64, ptr } %t79, ptr %l46
  br label %bb21
bb21:
  %t80 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t80, ptr %l4, !tbaa !27
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t84 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t81, i32 80)
  store i1 %t84, ptr %l49
  br label %bb22
bb22:
  %t85 = load i1, ptr %l49, !tbaa !21
  br i1 %t85, label %bb23, label %bb24
bb23:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t88 = getelementptr %"compiler/parse:Parser", ptr %t86, i32 0, i32 12
  %t89 = load i1, ptr %t88, !tbaa !21
  store i1 %t89, ptr %l50, !tbaa !21
  br label %bb25
bb24:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb25
bb25:
  %t91 = load i1, ptr %l50, !tbaa !21
  br i1 %t91, label %bb26, label %bb27
bb26:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t96 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %v1, ptr %t92, { i64, ptr } %t93)
  %t97 = extractvalue { i32, ptr } %t96, 1
  %t98 = extractvalue { i32, ptr } %t96, 0
  store i32 %t98, ptr %l57
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb29, label %ok.100, !prof !99
ok.100:
  store ptr %t97, ptr %l56
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t101 = load ptr, ptr %l56, !tbaa !29
  store ptr %t101, ptr %l53, !tbaa !29
  br label %bb30
bb29:
  %t102 = load i32, ptr %l57, !tbaa !23
  %t103 = lshr i32 %t102, 16
  %t104 = and i32 %t102, 65535
  %t105 = icmp eq i32 %t103, 1
  %t106 = select i1 %t105, i32 1, i32 0
  %t107 = icmp eq i32 %t102, 0
  %t108 = shl i32 %t106, 16
  %t109 = or i32 %t108, %t104
  %t110 = select i1 %t107, i32 0, i32 %t109
  %t112 = insertvalue { i32, ptr } zeroinitializer, i32 %t110, 0
  store { i32, ptr } %t112, ptr %rv
  br label %ret
bb30:
  %t113 = load ptr, ptr %l53, !tbaa !29
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t115 = load i32, ptr %l1, !tbaa !23
  %t120 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v1, ptr %t114, i32 %t115, ptr %t113)
  %t121 = extractvalue { i32, ptr } %t120, 1
  %t122 = extractvalue { i32, ptr } %t120, 0
  store i32 %t122, ptr %l64
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb32, label %ok.124, !prof !99
ok.124:
  store ptr %t121, ptr %l63
  br label %bb31
bb31:
  %t125 = load ptr, ptr %l63, !tbaa !29
  store ptr %t125, ptr %l59, !tbaa !29
  br label %bb33
bb32:
  %t126 = load i32, ptr %l64, !tbaa !23
  %t127 = lshr i32 %t126, 16
  %t128 = and i32 %t126, 65535
  %t129 = icmp eq i32 %t127, 1
  %t130 = select i1 %t129, i32 1, i32 0
  %t131 = icmp eq i32 %t126, 0
  %t132 = shl i32 %t130, 16
  %t133 = or i32 %t132, %t128
  %t134 = select i1 %t131, i32 0, i32 %t133
  %t136 = insertvalue { i32, ptr } zeroinitializer, i32 %t134, 0
  store { i32, ptr } %t136, ptr %rv
  br label %ret
bb33:
  %t137 = load ptr, ptr %l59, !tbaa !29
  %t138 = insertvalue { i32, ptr } zeroinitializer, ptr %t137, 1
  store { i32, ptr } %t138, ptr %rv
  br label %ret
bb34:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t142 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t139, i32 80)
  store i1 %t142, ptr %l68
  br label %bb35
bb35:
  %t143 = load i1, ptr %l68, !tbaa !21
  br i1 %t143, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l69, !tbaa !21
  br label %bb39
bb37:
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t144, i32 78)
  store i1 %t147, ptr %l72
  br label %bb38
bb38:
  %t148 = load i1, ptr %l72, !tbaa !21
  store i1 %t148, ptr %l69, !tbaa !21
  br label %bb39
bb39:
  %t149 = load i1, ptr %l69, !tbaa !21
  br i1 %t149, label %bb40, label %bb41
bb40:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb43
bb41:
  %t150 = load ptr, ptr %l0, !tbaa !29
  %t153 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t150, i32 105)
  store i1 %t153, ptr %l76
  br label %bb42
bb42:
  %t154 = load i1, ptr %l76, !tbaa !21
  store i1 %t154, ptr %l73, !tbaa !21
  br label %bb43
bb43:
  %t155 = load i1, ptr %l73, !tbaa !21
  br i1 %t155, label %bb44, label %bb45
bb44:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t158 = getelementptr %"compiler/parse:Parser", ptr %t156, i32 0, i32 9
  %t159 = load i32, ptr %t158, !range !{i32 0, i32 116}
  %t161 = trunc i64 80 to i32
  %t162 = icmp eq i32 %t159, %t161
  store i1 %t162, ptr %l6, !tbaa !21
  %t164 = load ptr, ptr %l0, !tbaa !29
  %t166 = getelementptr %"compiler/parse:Parser", ptr %t164, i32 0, i32 9
  %t167 = load i32, ptr %t166, !range !{i32 0, i32 116}
  %t169 = trunc i64 105 to i32
  %t170 = icmp eq i32 %t167, %t169
  store i1 %t170, ptr %l7, !tbaa !21
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l83, !tbaa !29
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t173)
  store i32 %t175, ptr %l85
  br label %bb46
bb45:
  br label %bb55
bb46:
  %t176 = load i32, ptr %l85, !tbaa !23
  %t177 = load ptr, ptr %l83, !tbaa !29
  %t178 = getelementptr %"compiler/parse:Parser", ptr %t177, i32 0, i32 28
  store i32 %t176, ptr %t178, !tbaa !23
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v1, ptr %t179)
  %t182 = extractvalue { i32, { i64, ptr } } %t181, 1
  %t183 = extractvalue { i32, { i64, ptr } } %t181, 0
  store i32 %t183, ptr %l89
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb48, label %ok.185, !prof !99
ok.185:
  store { i64, ptr } %t182, ptr %l88
  br label %bb47
bb47:
  %t186 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t186, ptr %l86, !tbaa !27
  br label %bb49
bb48:
  %t187 = load i32, ptr %l89, !tbaa !23
  %t188 = lshr i32 %t187, 16
  %t189 = and i32 %t187, 65535
  %t190 = icmp eq i32 %t188, 1
  %t191 = select i1 %t190, i32 1, i32 0
  %t192 = icmp eq i32 %t187, 0
  %t193 = shl i32 %t191, 16
  %t194 = or i32 %t193, %t189
  %t195 = select i1 %t192, i32 0, i32 %t194
  %t197 = insertvalue { i32, ptr } zeroinitializer, i32 %t195, 0
  store { i32, ptr } %t197, ptr %rv
  br label %ret
bb49:
  %t198 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t198, ptr %l8, !tbaa !27
  %t199 = load ptr, ptr %l0, !tbaa !29
  %t200 = load i32, ptr %l1, !tbaa !23
  %t203 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t199, i32 %t200)
  store %"compiler/source:Span" %t203, ptr %l93
  br label %bb50
bb50:
  %t204 = load %"compiler/source:Span", ptr %l93
  store %"compiler/source:Span" %t204, ptr %l9
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t205)
  store i32 %t207, ptr %l95
  %t208 = icmp ne i32 %t207, 0
  br i1 %t208, label %bb52, label %ok.209, !prof !99
ok.209:
  br label %bb51
bb51:
  br label %bb53
bb52:
  %t210 = load i32, ptr %l95, !tbaa !23
  %t211 = lshr i32 %t210, 16
  %t212 = and i32 %t210, 65535
  %t213 = icmp eq i32 %t211, 1
  %t214 = select i1 %t213, i32 1, i32 0
  %t215 = icmp eq i32 %t210, 0
  %t216 = shl i32 %t214, 16
  %t217 = or i32 %t216, %t212
  %t218 = select i1 %t215, i32 0, i32 %t217
  %t220 = insertvalue { i32, ptr } zeroinitializer, i32 %t218, 0
  store { i32, ptr } %t220, ptr %rv
  br label %ret
bb53:
  %t221 = load %"compiler/source:Span", ptr %l9
  store %"compiler/source:Span" %t221, ptr %l97
  %t222 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t223 = load i1, ptr %l6, !tbaa !21
  %t224 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t225 = load i1, ptr %l7, !tbaa !21
  %t230 = call %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t222, i1 %t223, { i64, ptr } %t224, i1 %t225)
  store %"compiler/ast:Multi" %t230, ptr %l102
  br label %bb54
bb54:
  %t231 = load %"compiler/ast:Multi", ptr %l102
  %t232 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store %"compiler/ast:Multi" %t231, ptr %t232
  store { i64, [4 x i64] } zeroinitializer, ptr %t233
  %t234 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 0
  store i64 2, ptr %t234
  %t235 = load %"compiler/source:Span", ptr %l97
  %t236 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t235, 0
  %t238 = insertvalue { %"compiler/source:Span", ptr } %t236, ptr %t232, 1
  %t239 = getelementptr { i64, [4 x i64] }, ptr %t233, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t238, ptr %t239
  %t240 = load { i64, [4 x i64] }, ptr %t233
  %t242 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t240, ptr %t242
  %t244 = insertvalue { i32, ptr } zeroinitializer, ptr %t242, 1
  store { i32, ptr } %t244, ptr %rv
  br label %ret
bb55:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t249 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %v1, ptr %t245, { i64, ptr } %t246)
  %t250 = extractvalue { i32, ptr } %t249, 1
  %t251 = extractvalue { i32, ptr } %t249, 0
  store i32 %t251, ptr %l110
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb57, label %ok.253, !prof !99
ok.253:
  store ptr %t250, ptr %l109
  br label %bb56
bb56:
  %t254 = load ptr, ptr %l109, !tbaa !29
  store ptr %t254, ptr %l106, !tbaa !29
  br label %bb58
bb57:
  %t255 = load i32, ptr %l110, !tbaa !23
  %t256 = lshr i32 %t255, 16
  %t257 = and i32 %t255, 65535
  %t258 = icmp eq i32 %t256, 1
  %t259 = select i1 %t258, i32 1, i32 0
  %t260 = icmp eq i32 %t255, 0
  %t261 = shl i32 %t259, 16
  %t262 = or i32 %t261, %t257
  %t263 = select i1 %t260, i32 0, i32 %t262
  %t265 = insertvalue { i32, ptr } zeroinitializer, i32 %t263, 0
  store { i32, ptr } %t265, ptr %rv
  br label %ret
bb58:
  %t266 = load ptr, ptr %l106, !tbaa !29
  store ptr %t266, ptr %l10, !tbaa !29
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/parse:Parser", ptr %t267, i32 0, i32 12
  %t270 = load i1, ptr %t269, !tbaa !21
  br i1 %t270, label %bb59, label %bb60
bb59:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t275 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t272, i32 8)
  store i1 %t275, ptr %l117
  br label %bb61
bb60:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb70
bb61:
  %t276 = load i1, ptr %l117, !tbaa !21
  br i1 %t276, label %bb62, label %bb63
bb62:
  store i1 true, ptr %l118, !tbaa !21
  br label %bb65
bb63:
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t280 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t277, i32 115)
  store i1 %t280, ptr %l121
  br label %bb64
bb64:
  %t281 = load i1, ptr %l121, !tbaa !21
  store i1 %t281, ptr %l118, !tbaa !21
  br label %bb65
bb65:
  %t282 = load i1, ptr %l118, !tbaa !21
  br i1 %t282, label %bb66, label %bb67
bb66:
  store i1 true, ptr %l122, !tbaa !21
  br label %bb69
bb67:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t286 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t283, i32 0)
  store i1 %t286, ptr %l125
  br label %bb68
bb68:
  %t287 = load i1, ptr %l125, !tbaa !21
  store i1 %t287, ptr %l122, !tbaa !21
  br label %bb69
bb69:
  %t288 = load i1, ptr %l122, !tbaa !21
  store i1 %t288, ptr %l114, !tbaa !21
  br label %bb70
bb70:
  %t289 = load i1, ptr %l114, !tbaa !21
  br i1 %t289, label %bb71, label %bb72
bb71:
  %t290 = load ptr, ptr %l0, !tbaa !29
  %t291 = load i32, ptr %l1, !tbaa !23
  %t294 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t290, i32 %t291)
  store %"compiler/source:Span" %t294, ptr %l128
  br label %bb73
bb72:
  br label %bb82
bb73:
  %t295 = load %"compiler/source:Span", ptr %l128
  store %"compiler/source:Span" %t295, ptr %l11
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t296)
  store i32 %t298, ptr %l130
  %t299 = icmp ne i32 %t298, 0
  br i1 %t299, label %bb75, label %ok.300, !prof !99
ok.300:
  br label %bb74
bb74:
  br label %bb76
bb75:
  %t301 = load i32, ptr %l130, !tbaa !23
  %t302 = lshr i32 %t301, 16
  %t303 = and i32 %t301, 65535
  %t304 = icmp eq i32 %t302, 1
  %t305 = select i1 %t304, i32 1, i32 0
  %t306 = icmp eq i32 %t301, 0
  %t307 = shl i32 %t305, 16
  %t308 = or i32 %t307, %t303
  %t309 = select i1 %t306, i32 0, i32 %t308
  %t311 = insertvalue { i32, ptr } zeroinitializer, i32 %t309, 0
  store { i32, ptr } %t311, ptr %rv
  br label %ret
bb76:
  %t312 = load %"compiler/source:Span", ptr %l11
  store %"compiler/source:Span" %t312, ptr %l132
  %t313 = load ptr, ptr %l10, !tbaa !29
  %t315 = getelementptr %"compiler/parse:NameList", ptr %t313, i32 0, i32 0
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  store { i64, ptr } %t316, ptr %l134, !tbaa !27
  %t317 = load ptr, ptr %l10, !tbaa !29
  %t319 = getelementptr %"compiler/parse:NameList", ptr %t317, i32 0, i32 1
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  store { i64, ptr } %t320, ptr %l136, !tbaa !27
  %t321 = icmp sge i64 0, 0
  br i1 %t321, label %bb77, label %bb78
bb77:
  %t323 = icmp sle i64 0, 1152921504606846975
  br i1 %t323, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb79:
  %t325 = mul i64 0, 8
  %t326 = insertvalue { i64, ptr } undef, i64 0, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t328 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t331 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t328, { i64, ptr } %t329, ptr null, { i64, ptr } %t327, i1 false, i1 true, i1 false)
  store %"compiler/ast:VarDecl" %t331, ptr %l140
  br label %bb81
bb80:
  call void @__olang_check_failed(ptr @olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9)
  unreachable
bb81:
  %t332 = load %"compiler/ast:VarDecl", ptr %l140
  %t333 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t332, ptr %t333
  store { i64, [4 x i64] } zeroinitializer, ptr %t334
  %t335 = getelementptr { i64, [4 x i64] }, ptr %t334, i32 0, i32 0
  store i64 1, ptr %t335
  %t336 = load %"compiler/source:Span", ptr %l132
  %t337 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t336, 0
  %t339 = insertvalue { %"compiler/source:Span", ptr } %t337, ptr %t333, 1
  %t340 = getelementptr { i64, [4 x i64] }, ptr %t334, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t339, ptr %t340
  %t341 = load { i64, [4 x i64] }, ptr %t334
  %t343 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t341, ptr %t343
  %t345 = insertvalue { i32, ptr } zeroinitializer, ptr %t343, 1
  store { i32, ptr } %t345, ptr %rv
  br label %ret
bb82:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t347 = load i32, ptr %l1, !tbaa !23
  %t348 = load ptr, ptr %l10, !tbaa !29
  %t352 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v1, ptr %t346, i32 %t347, ptr %t348)
  %t353 = extractvalue { i32, ptr } %t352, 1
  %t354 = extractvalue { i32, ptr } %t352, 0
  store i32 %t354, ptr %l149
  %t355 = icmp ne i32 %t354, 0
  br i1 %t355, label %bb84, label %ok.356, !prof !99
ok.356:
  store ptr %t353, ptr %l148
  br label %bb83
bb83:
  %t357 = load ptr, ptr %l148, !tbaa !29
  store ptr %t357, ptr %l144, !tbaa !29
  br label %bb85
bb84:
  %t358 = load i32, ptr %l149, !tbaa !23
  %t359 = lshr i32 %t358, 16
  %t360 = and i32 %t358, 65535
  %t361 = icmp eq i32 %t359, 1
  %t362 = select i1 %t361, i32 1, i32 0
  %t363 = icmp eq i32 %t358, 0
  %t364 = shl i32 %t362, 16
  %t365 = or i32 %t364, %t360
  %t366 = select i1 %t363, i32 0, i32 %t365
  %t368 = insertvalue { i32, ptr } zeroinitializer, i32 %t366, 0
  store { i32, ptr } %t368, ptr %rv
  br label %ret
bb85:
  %t369 = load ptr, ptr %l144, !tbaa !29
  %t370 = insertvalue { i32, ptr } zeroinitializer, ptr %t369, 1
  store { i32, ptr } %t370, ptr %rv
  br label %ret
bb86:
  %t371 = load ptr, ptr %l0, !tbaa !29
  %t373 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t371)
  store i32 %t373, ptr %l152
  br label %bb87
bb87:
  %t374 = load i32, ptr %l152, !range !{i32 0, i32 116}
  store i32 %t374, ptr %l12
  %t375 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t377 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t375)
  store i1 %t377, ptr %l154
  br label %bb88
bb88:
  %t378 = load i1, ptr %l154, !tbaa !21
  br i1 %t378, label %bb89, label %bb90
bb89:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t379)
  store i32 %t381, ptr %l156
  br label %bb91
bb90:
  br label %bb99
bb91:
  %t382 = load ptr, ptr %l0, !tbaa !29
  %t384 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t382)
  %t385 = extractvalue { i32, ptr } %t384, 1
  %t386 = extractvalue { i32, ptr } %t384, 0
  store i32 %t386, ptr %l160
  %t387 = icmp ne i32 %t386, 0
  br i1 %t387, label %bb93, label %ok.388, !prof !99
ok.388:
  store ptr %t385, ptr %l159
  br label %bb92
bb92:
  %t389 = load ptr, ptr %l159, !tbaa !29
  store ptr %t389, ptr %l157, !tbaa !29
  br label %bb94
bb93:
  %t390 = load i32, ptr %l160, !tbaa !23
  %t391 = lshr i32 %t390, 16
  %t392 = and i32 %t390, 65535
  %t393 = icmp eq i32 %t391, 1
  %t394 = select i1 %t393, i32 1, i32 0
  %t395 = icmp eq i32 %t390, 0
  %t396 = shl i32 %t394, 16
  %t397 = or i32 %t396, %t392
  %t398 = select i1 %t395, i32 0, i32 %t397
  %t400 = insertvalue { i32, ptr } zeroinitializer, i32 %t398, 0
  store { i32, ptr } %t400, ptr %rv
  br label %ret
bb94:
  %t401 = load ptr, ptr %l157, !tbaa !29
  store ptr %t401, ptr %l13, !tbaa !29
  %t402 = load ptr, ptr %l0, !tbaa !29
  %t403 = load i32, ptr %l1, !tbaa !23
  %t406 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t402, i32 %t403)
  store %"compiler/source:Span" %t406, ptr %l164
  br label %bb95
bb95:
  %t407 = load %"compiler/source:Span", ptr %l164
  store %"compiler/source:Span" %t407, ptr %l14
  %t408 = load ptr, ptr %l0, !tbaa !29
  %t410 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t408)
  store i32 %t410, ptr %l166
  %t411 = icmp ne i32 %t410, 0
  br i1 %t411, label %bb97, label %ok.412, !prof !99
ok.412:
  br label %bb96
bb96:
  br label %bb98
bb97:
  %t413 = load i32, ptr %l166, !tbaa !23
  %t414 = lshr i32 %t413, 16
  %t415 = and i32 %t413, 65535
  %t416 = icmp eq i32 %t414, 1
  %t417 = select i1 %t416, i32 1, i32 0
  %t418 = icmp eq i32 %t413, 0
  %t419 = shl i32 %t417, 16
  %t420 = or i32 %t419, %t415
  %t421 = select i1 %t418, i32 0, i32 %t420
  %t423 = insertvalue { i32, ptr } zeroinitializer, i32 %t421, 0
  store { i32, ptr } %t423, ptr %rv
  br label %ret
bb98:
  %t424 = load %"compiler/source:Span", ptr %l14
  %t425 = load i32, ptr %l12, !range !{i32 0, i32 116}
  %t426 = load ptr, ptr %l2, !tbaa !29
  %t427 = load ptr, ptr %l13, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t428
  %t429 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 0
  store i64 3, ptr %t429
  %t431 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t424, 0
  %t433 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t431, i32 %t425, 1
  %t435 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t433, ptr %t426, 2
  %t437 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t435, ptr %t427, 3
  %t438 = getelementptr { i64, [4 x i64] }, ptr %t428, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t437, ptr %t438
  %t439 = load { i64, [4 x i64] }, ptr %t428
  %t441 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t439, ptr %t441
  %t443 = insertvalue { i32, ptr } zeroinitializer, ptr %t441, 1
  store { i32, ptr } %t443, ptr %rv
  br label %ret
bb99:
  %t444 = load ptr, ptr %l0, !tbaa !29
  %t445 = load i32, ptr %l1, !tbaa !23
  %t448 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t444, i32 %t445)
  store %"compiler/source:Span" %t448, ptr %l176
  br label %bb100
bb100:
  %t449 = load %"compiler/source:Span", ptr %l176
  store %"compiler/source:Span" %t449, ptr %l15
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t452 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t450)
  store i32 %t452, ptr %l178
  %t453 = icmp ne i32 %t452, 0
  br i1 %t453, label %bb102, label %ok.454, !prof !99
ok.454:
  br label %bb101
bb101:
  br label %bb103
bb102:
  %t455 = load i32, ptr %l178, !tbaa !23
  %t456 = lshr i32 %t455, 16
  %t457 = and i32 %t455, 65535
  %t458 = icmp eq i32 %t456, 1
  %t459 = select i1 %t458, i32 1, i32 0
  %t460 = icmp eq i32 %t455, 0
  %t461 = shl i32 %t459, 16
  %t462 = or i32 %t461, %t457
  %t463 = select i1 %t460, i32 0, i32 %t462
  %t465 = insertvalue { i32, ptr } zeroinitializer, i32 %t463, 0
  store { i32, ptr } %t465, ptr %rv
  br label %ret
bb103:
  %t466 = load %"compiler/source:Span", ptr %l15
  %t467 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t468
  %t469 = getelementptr { i64, [4 x i64] }, ptr %t468, i32 0, i32 0
  store i64 0, ptr %t469
  %t471 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t466, 0
  %t473 = insertvalue { %"compiler/source:Span", ptr } %t471, ptr %t467, 1
  %t474 = getelementptr { i64, [4 x i64] }, ptr %t468, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t473, ptr %t474
  %t475 = load { i64, [4 x i64] }, ptr %t468
  %t477 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t475, ptr %t477
  %t479 = insertvalue { i32, ptr } zeroinitializer, ptr %t477, 1
  store { i32, ptr } %t479, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternBlock(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l15 = alloca i64
  %l19 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l29 = alloca i32
  %l32 = alloca i32
  %l35 = alloca i1
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l42 = alloca ptr
  %l45 = alloca %"compiler/source:Span"
  %l46 = alloca i32
  %l53 = alloca %"compiler/ast:TypeDecl"
  %l59 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca i32
  %l71 = alloca i32
  %l74 = alloca i32
  %l78 = alloca i32
  %l82 = alloca { i64, ptr }
  %l85 = alloca %"compiler/source:Span"
  %s2 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t112 = alloca { i64, [6 x i64] }, align 8
  %t124 = alloca { i64, [8 x i64] }, align 8
  %t166 = alloca { i64, [8 x i64] }, align 8
  %t223 = alloca { i64, [8 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 114)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 41
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l15
  br label %bb4
bb4:
  %t26 = load i64, ptr %l15, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t27)
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t29, i32 115)
  store i1 %t32, ptr %l19
  br label %bb7
bb7:
  %t33 = load i1, ptr %l19, !tbaa !21
  %t34 = xor i1 %t33, true
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb8, label %bb9
bb8:
  br label %bb50
bb9:
  br label %bb10
bb10:
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t38, i32 0)
  store i1 %t41, ptr %l24
  br label %bb11
bb11:
  %t42 = load i1, ptr %l24, !tbaa !21
  br i1 %t42, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t45 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 115)
  store { i64, ptr } %t45, ptr %l27
  br label %bb14
bb13:
  br label %bb18
bb14:
  %t46 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t47 = load ptr, ptr %l25, !tbaa !29
  %t49 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t47, { i64, ptr } %t46)
  store i32 %t49, ptr %l29
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb16, label %ok.51, !prof !99
ok.51:
  br label %bb15
bb15:
  br label %bb17
bb16:
  %t52 = load i32, ptr %l29, !tbaa !23
  %t53 = lshr i32 %t52, 16
  %t54 = and i32 %t52, 65535
  %t55 = icmp eq i32 %t53, 1
  %t56 = select i1 %t55, i32 1, i32 0
  %t57 = icmp eq i32 %t52, 0
  %t58 = shl i32 %t56, 16
  %t59 = or i32 %t58, %t54
  %t60 = select i1 %t57, i32 0, i32 %t59
  call void @__olang_scope_close(ptr %s2)
  %t62 = insertvalue { i32, ptr } zeroinitializer, i32 %t60, 0
  store { i32, ptr } %t62, ptr %rv
  br label %ret
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t63)
  store i32 %t65, ptr %l32
  br label %bb19
bb19:
  %t66 = load i32, ptr %l32, !tbaa !23
  store i32 %t66, ptr %l4, !tbaa !23
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t67, i32 33)
  store i1 %t70, ptr %l35
  br label %bb20
bb20:
  %t71 = load i1, ptr %l35, !tbaa !21
  br i1 %t71, label %bb21, label %bb22
bb21:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t72)
  %t75 = extractvalue { i32, i32 } %t74, 1
  %t76 = extractvalue { i32, i32 } %t74, 0
  store i32 %t76, ptr %l39
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb24, label %ok.78, !prof !99
ok.78:
  store i32 %t75, ptr %l38
  br label %bb23
bb22:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t82 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t79, i32 37)
  store i1 %t82, ptr %l59
  br label %bb33
bb23:
  %t83 = load i32, ptr %l38, !tbaa !23
  store i32 %t83, ptr %l36, !tbaa !23
  br label %bb25
bb24:
  %t84 = load i32, ptr %l39, !tbaa !23
  %t85 = lshr i32 %t84, 16
  %t86 = and i32 %t84, 65535
  %t87 = icmp eq i32 %t85, 1
  %t88 = select i1 %t87, i32 1, i32 0
  %t89 = icmp eq i32 %t84, 0
  %t90 = shl i32 %t88, 16
  %t91 = or i32 %t90, %t86
  %t92 = select i1 %t89, i32 0, i32 %t91
  %t94 = insertvalue { i32, ptr } zeroinitializer, i32 %t92, 0
  store { i32, ptr } %t94, ptr %rv
  br label %ret
bb25:
  %t95 = load i32, ptr %l36, !tbaa !23
  store i32 %t95, ptr %l5, !tbaa !23
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/parse:Parser", ptr %t96, i32 0, i32 41
  store ptr %t98, ptr %l42, !tbaa !29
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t100 = load i32, ptr %l4, !tbaa !23
  %t103 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t99, i32 %t100)
  store %"compiler/source:Span" %t103, ptr %l45
  br label %bb26
bb26:
  %t104 = load i32, ptr %l5, !tbaa !23
  store i32 %t104, ptr %l46, !tbaa !23
  %t105 = icmp sge i64 0, 0
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = icmp sle i64 0, 1152921504606846975
  br i1 %t107, label %bb29, label %bb30
bb28:
  call void @__olang_check_failed(ptr @olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd)
  unreachable
bb29:
  %t109 = mul i64 0, 8
  %t110 = insertvalue { i64, ptr } undef, i64 0, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, [6 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [6 x i64] }, ptr %t112, i32 0, i32 0
  store i64 4, ptr %t113
  %t114 = load { i64, [6 x i64] }, ptr %t112
  %t116 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 56, i64 8)
  store { i64, [6 x i64] } %t114, ptr %t116
  %t117 = load i32, ptr %l46, !tbaa !23
  %t121 = call %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, i32 %t117, { i64, ptr } %t111, i1 false, ptr %t116, i32 0, i1 false, ptr null, i32 0)
  store %"compiler/ast:TypeDecl" %t121, ptr %l53
  br label %bb31
bb30:
  call void @__olang_check_failed(ptr @olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd)
  unreachable
bb31:
  %t122 = load %"compiler/ast:TypeDecl", ptr %l53
  %t123 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store %"compiler/ast:TypeDecl" %t122, ptr %t123
  store { i64, [8 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [8 x i64] }, ptr %t124, i32 0, i32 0
  store i64 2, ptr %t125
  %t126 = load %"compiler/source:Span", ptr %l45
  %t127 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t126, 0
  %t129 = insertvalue { %"compiler/source:Span", ptr } %t127, ptr %t123, 1
  %t130 = getelementptr { i64, [8 x i64] }, ptr %t124, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t129, ptr %t130
  %t131 = load { i64, [8 x i64] }, ptr %t124
  %t133 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store { i64, [8 x i64] } %t131, ptr %t133
  %t134 = load ptr, ptr %l42, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t134, ptr %t133)
  br label %bb32
bb32:
  br label %bb44
bb33:
  %t136 = load i1, ptr %l59, !tbaa !21
  br i1 %t136, label %bb34, label %bb35
bb34:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t139 = getelementptr %"compiler/parse:Parser", ptr %t137, i32 0, i32 41
  store ptr %t139, ptr %l61, !tbaa !29
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t141 = load i32, ptr %l4, !tbaa !23
  %t144 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %v0, ptr %t140, i32 %t141)
  %t145 = extractvalue { i32, ptr } %t144, 1
  %t146 = extractvalue { i32, ptr } %t144, 0
  store i32 %t146, ptr %l66
  %t147 = icmp ne i32 %t146, 0
  br i1 %t147, label %bb37, label %ok.148, !prof !99
ok.148:
  store ptr %t145, ptr %l65
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s6
  %t149 = load ptr, ptr %l0, !tbaa !29
  %t151 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s6, ptr %t149, { i64, ptr } { i64 65, ptr getelementptr inbounds (<{ i64, [65 x i8] }>, ptr @.d2, i32 0, i32 1) })
  store i32 %t151, ptr %l71
  %t152 = icmp ne i32 %t151, 0
  br i1 %t152, label %bb41, label %ok.153, !prof !99
ok.153:
  br label %bb40
bb36:
  %t154 = load ptr, ptr %l65, !tbaa !29
  store ptr %t154, ptr %l62, !tbaa !29
  br label %bb38
bb37:
  %t155 = load i32, ptr %l66, !tbaa !23
  %t156 = lshr i32 %t155, 16
  %t157 = and i32 %t155, 65535
  %t158 = icmp eq i32 %t156, 1
  %t159 = select i1 %t158, i32 1, i32 0
  %t160 = icmp eq i32 %t155, 0
  %t161 = shl i32 %t159, 16
  %t162 = or i32 %t161, %t157
  %t163 = select i1 %t160, i32 0, i32 %t162
  %t165 = insertvalue { i32, ptr } zeroinitializer, i32 %t163, 0
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb38:
  store { i64, [8 x i64] } zeroinitializer, ptr %t166
  %t167 = getelementptr { i64, [8 x i64] }, ptr %t166, i32 0, i32 0
  store i64 1, ptr %t167
  %t168 = load ptr, ptr %l62, !tbaa !29
  %t169 = insertvalue { ptr } undef, ptr %t168, 0
  %t170 = getelementptr { i64, [8 x i64] }, ptr %t166, i32 0, i32 1
  store { ptr } %t169, ptr %t170
  %t171 = load { i64, [8 x i64] }, ptr %t166
  %t173 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 72, i64 8)
  store { i64, [8 x i64] } %t171, ptr %t173
  %t174 = load ptr, ptr %l61, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t174, ptr %t173)
  br label %bb39
bb39:
  br label %bb43
bb40:
  br label %bb42
bb41:
  %t176 = load i32, ptr %l71, !tbaa !23
  %t177 = lshr i32 %t176, 16
  %t178 = and i32 %t176, 65535
  %t179 = icmp eq i32 %t177, 1
  %t180 = select i1 %t179, i32 1, i32 0
  %t181 = icmp eq i32 %t176, 0
  %t182 = shl i32 %t180, 16
  %t183 = or i32 %t182, %t178
  %t184 = select i1 %t181, i32 0, i32 %t183
  call void @__olang_scope_close(ptr %s6)
  %t186 = insertvalue { i32, ptr } zeroinitializer, i32 %t184, 0
  store { i32, ptr } %t186, ptr %rv
  br label %ret
bb42:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t187 = load ptr, ptr %l0, !tbaa !29
  %t189 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t187)
  store i32 %t189, ptr %l74
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb46, label %ok.191, !prof !99
ok.191:
  br label %bb45
bb45:
  br label %bb47
bb46:
  %t192 = load i32, ptr %l74, !tbaa !23
  %t193 = lshr i32 %t192, 16
  %t194 = and i32 %t192, 65535
  %t195 = icmp eq i32 %t193, 1
  %t196 = select i1 %t195, i32 1, i32 0
  %t197 = icmp eq i32 %t192, 0
  %t198 = shl i32 %t196, 16
  %t199 = or i32 %t198, %t194
  %t200 = select i1 %t197, i32 0, i32 %t199
  %t202 = insertvalue { i32, ptr } zeroinitializer, i32 %t200, 0
  store { i32, ptr } %t202, ptr %rv
  br label %ret
bb47:
  %t203 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t203)
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb6
bb50:
  %t205 = load ptr, ptr %l0, !tbaa !29
  %t207 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t205)
  store i32 %t207, ptr %l78
  br label %bb51
bb51:
  %t208 = load ptr, ptr %l0, !tbaa !29
  %t210 = getelementptr %"compiler/parse:Parser", ptr %t208, i32 0, i32 41
  %t211 = load i64, ptr %l3, !tbaa !24
  %t214 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %t210, i64 %t211)
  store { i64, ptr } %t214, ptr %l82
  br label %bb52
bb52:
  %t215 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t215, ptr %l6, !tbaa !27
  %t216 = load ptr, ptr %l0, !tbaa !29
  %t220 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t216, i32 %a1)
  store %"compiler/source:Span" %t220, ptr %l85
  br label %bb53
bb53:
  %t222 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [8 x i64] } zeroinitializer, ptr %t223
  %t224 = getelementptr { i64, [8 x i64] }, ptr %t223, i32 0, i32 0
  store i64 11, ptr %t224
  %t225 = load %"compiler/source:Span", ptr %l85
  %t226 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t225, 0
  %t228 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t226, %"compiler/source:Span" %a2, 1
  %t230 = insertvalue { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t228, { i64, ptr } %t222, 2
  %t231 = getelementptr { i64, [8 x i64] }, ptr %t223, i32 0, i32 1
  store { %"compiler/source:Span", %"compiler/source:Span", { i64, ptr } } %t230, ptr %t231
  %t232 = load { i64, [8 x i64] }, ptr %t223
  %t234 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store { i64, [8 x i64] } %t232, ptr %t234
  %t236 = insertvalue { i32, ptr } zeroinitializer, ptr %t234, 1
  store { i32, ptr } %t236, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l5 = alloca i1
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i32
  %l15 = alloca %"compiler/source:Span"
  %l19 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i32
  %rv = alloca { i32, ptr }
  %t36 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 30)
  store i1 %t4, ptr %l5
  br label %bb1
bb1:
  %t5 = load i1, ptr %l5, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t6)
  store i32 %t8, ptr %l7
  br label %bb4
bb3:
  br label %bb9
bb4:
  %t9 = load i32, ptr %l7, !tbaa !23
  store i32 %t9, ptr %l1, !tbaa !23
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v1, ptr %t10)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l11
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb6, label %ok.16, !prof !99
ok.16:
  store { i64, ptr } %t13, ptr %l10
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l8, !tbaa !27
  br label %bb7
bb6:
  %t18 = load i32, ptr %l11, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb7:
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t29, ptr %l2, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t31 = load i32, ptr %l1, !tbaa !23
  %t34 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t30, i32 %t31)
  store %"compiler/source:Span" %t34, ptr %l15
  br label %bb8
bb8:
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t36
  %t37 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 0
  store i64 22, ptr %t37
  %t38 = load %"compiler/source:Span", ptr %l15
  %t39 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t38, 0
  %t41 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t39, { i64, ptr } %t35, 1
  %t42 = getelementptr { i64, [4 x i64] }, ptr %t36, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t41, ptr %t42
  %t43 = load { i64, [4 x i64] }, ptr %t36
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t43, ptr %t45
  %t47 = insertvalue { i32, ptr } zeroinitializer, ptr %t45, 1
  store { i32, ptr } %t47, ptr %rv
  br label %ret
bb9:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t48)
  %t51 = extractvalue { i32, ptr } %t50, 1
  %t52 = extractvalue { i32, ptr } %t50, 0
  store i32 %t52, ptr %l22
  %t53 = icmp ne i32 %t52, 0
  br i1 %t53, label %bb11, label %ok.54, !prof !99
ok.54:
  store ptr %t51, ptr %l21
  br label %bb10
bb10:
  %t55 = load ptr, ptr %l21, !tbaa !29
  store ptr %t55, ptr %l19, !tbaa !29
  br label %bb12
bb11:
  %t56 = load i32, ptr %l22, !tbaa !23
  %t57 = lshr i32 %t56, 16
  %t58 = and i32 %t56, 65535
  %t59 = icmp eq i32 %t57, 1
  %t60 = select i1 %t59, i32 1, i32 0
  %t61 = icmp eq i32 %t56, 0
  %t62 = shl i32 %t60, 16
  %t63 = or i32 %t62, %t58
  %t64 = select i1 %t61, i32 0, i32 %t63
  %t66 = insertvalue { i32, ptr } zeroinitializer, i32 %t64, 0
  store { i32, ptr } %t66, ptr %rv
  br label %ret
bb12:
  %t67 = load ptr, ptr %l19, !tbaa !29
  %t68 = insertvalue { i32, ptr } zeroinitializer, ptr %t67, 1
  store { i32, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforStmt(ptr %v0, ptr %v1, ptr %a0, i32 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/source:Span"
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i1
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca i32
  %l16 = alloca %"compiler/token:Token"
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i1
  %l22 = alloca ptr
  %lp24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/source:Span"
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca %"compiler/source:Span"
  %l32 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l44 = alloca i1
  %l45 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca i32
  %l56 = alloca %"compiler/source:Span"
  %l59 = alloca i1
  %l61 = alloca i32
  %l68 = alloca i1
  %l70 = alloca i32
  %l73 = alloca i1
  %l76 = alloca i32
  %l78 = alloca i32
  %l79 = alloca i32
  %l83 = alloca i1
  %l85 = alloca i32
  %l87 = alloca i32
  %l88 = alloca i32
  %l90 = alloca i32
  %l93 = alloca i32
  %l94 = alloca i32
  %l98 = alloca i1
  %l99 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca i32
  %l106 = alloca i64
  %l109 = alloca i1
  %l113 = alloca { i64, ptr }
  %l115 = alloca { i64, ptr }
  %l116 = alloca i32
  %l128 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca i32
  %l135 = alloca %"compiler/source:Span"
  %l138 = alloca i1
  %l140 = alloca i32
  %l141 = alloca %"compiler/source:Span"
  %l149 = alloca %"compiler/ast:ForIn"
  %l155 = alloca i1
  %l158 = alloca i1
  %l161 = alloca i1
  %l165 = alloca i32
  %l167 = alloca %"compiler/token:Token"
  %l168 = alloca i32
  %l170 = alloca i32
  %l171 = alloca i32
  %l173 = alloca ptr
  %l174 = alloca i32
  %l177 = alloca %"compiler/source:Span"
  %l178 = alloca ptr
  %l181 = alloca i1
  %l182 = alloca i1
  %l185 = alloca i1
  %l189 = alloca ptr
  %l191 = alloca ptr
  %l192 = alloca i32
  %l199 = alloca { i64, ptr }
  %l201 = alloca %"compiler/ast:VarDecl"
  %l203 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca i32
  %l208 = alloca i32
  %l211 = alloca i32
  %l212 = alloca i32
  %l214 = alloca ptr
  %l216 = alloca ptr
  %l217 = alloca i32
  %l226 = alloca { i64, ptr }
  %l227 = alloca %"compiler/ast:VarDecl"
  %l231 = alloca %"compiler/source:Span"
  %l236 = alloca i32
  %l239 = alloca i32
  %l240 = alloca i32
  %l242 = alloca ptr
  %l244 = alloca ptr
  %l245 = alloca i32
  %l247 = alloca i32
  %l250 = alloca i32
  %l251 = alloca i32
  %l253 = alloca ptr
  %l255 = alloca ptr
  %l256 = alloca i32
  %l258 = alloca { i64, ptr }
  %l260 = alloca { i64, ptr }
  %l261 = alloca i32
  %l265 = alloca %"compiler/source:Span"
  %l268 = alloca i1
  %l270 = alloca i32
  %l271 = alloca %"compiler/source:Span"
  %l277 = alloca %"compiler/ast:For3"
  %l283 = alloca i32
  %l285 = alloca ptr
  %l287 = alloca ptr
  %l288 = alloca i32
  %l290 = alloca { i64, ptr }
  %l292 = alloca { i64, ptr }
  %l293 = alloca i32
  %l297 = alloca %"compiler/source:Span"
  %l300 = alloca i1
  %l302 = alloca i32
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t77 = alloca { i64, [4 x i64] }, align 8
  %t304 = alloca { i64, [4 x i64] }, align 8
  %t543 = alloca { i64, [4 x i64] }, align 8
  %t681 = alloca { i64, [4 x i64] }, align 8
  %t768 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 25)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l36
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l35
  br label %bb1
bb1:
  %t9 = load i32, ptr %l35, !tbaa !23
  store i32 %t9, ptr %l32, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l36, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l32, !tbaa !23
  store i32 %t21, ptr %l2, !tbaa !23
  %t22 = load i32, ptr %l1, !tbaa !23
  %t24 = icmp sge i32 %t22, 0
  store i1 %t24, ptr %l3, !tbaa !21
  %t26 = load i1, ptr %l3, !tbaa !21
  br i1 %t26, label %bb4, label %bb5
bb4:
  %t28 = load i32, ptr %l1, !tbaa !23
  store i32 %t28, ptr %l2, !tbaa !23
  br label %bb6
bb5:
  br label %bb6
bb6:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t30, i32 114)
  store i1 %t33, ptr %l44
  br label %bb7
bb7:
  %t34 = load i1, ptr %l44, !tbaa !21
  br i1 %t34, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb11
bb9:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t38 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t35, i32 79)
  store i1 %t38, ptr %l48
  br label %bb10
bb10:
  %t39 = load i1, ptr %l48, !tbaa !21
  store i1 %t39, ptr %l45, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l45, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb12:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t41)
  %t44 = extractvalue { i32, { i64, ptr } } %t43, 1
  %t45 = extractvalue { i32, { i64, ptr } } %t43, 0
  store i32 %t45, ptr %l52
  %t46 = icmp ne i32 %t45, 0
  br i1 %t46, label %bb15, label %ok.47, !prof !99
ok.47:
  store { i64, ptr } %t44, ptr %l51
  br label %bb14
bb13:
  br label %bb23
bb14:
  %t48 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t48, ptr %l49, !tbaa !27
  br label %bb16
bb15:
  %t49 = load i32, ptr %l52, !tbaa !23
  %t50 = lshr i32 %t49, 16
  %t51 = and i32 %t49, 65535
  %t52 = icmp eq i32 %t50, 1
  %t53 = select i1 %t52, i32 1, i32 0
  %t54 = icmp eq i32 %t49, 0
  %t55 = shl i32 %t53, 16
  %t56 = or i32 %t55, %t51
  %t57 = select i1 %t54, i32 0, i32 %t56
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t57, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb16:
  %t60 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t60, ptr %l4, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l2, !tbaa !23
  %t65 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t61, i32 %t62)
  store %"compiler/source:Span" %t65, ptr %l56
  br label %bb17
bb17:
  %t66 = load %"compiler/source:Span", ptr %l56
  store %"compiler/source:Span" %t66, ptr %l5
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t67, i32 8)
  store i1 %t70, ptr %l59
  br label %bb18
bb18:
  %t71 = load i1, ptr %l59, !tbaa !21
  br i1 %t71, label %bb19, label %bb20
bb19:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t72)
  store i32 %t74, ptr %l61
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  %t75 = load %"compiler/source:Span", ptr %l5
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t77
  %t78 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 0
  store i64 6, ptr %t78
  %t80 = insertvalue { %"compiler/source:Span", { i64, ptr } } undef, %"compiler/source:Span" %t75, 0
  %t82 = insertvalue { %"compiler/source:Span", { i64, ptr } } %t80, { i64, ptr } %t76, 1
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t77, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr } } %t82, ptr %t83
  %t84 = load { i64, [4 x i64] }, ptr %t77
  %t86 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t84, ptr %t86
  %t88 = insertvalue { i32, ptr } zeroinitializer, ptr %t86, 1
  store { i32, ptr } %t88, ptr %rv
  br label %ret
bb23:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t89, i32 1)
  store i1 %t92, ptr %l68
  br label %bb24
bb24:
  %t93 = load i1, ptr %l68, !tbaa !21
  br i1 %t93, label %bb25, label %bb26
bb25:
  %t94 = load ptr, ptr %l0, !tbaa !29
  %t96 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t94, i64 1)
  store i32 %t96, ptr %l70
  br label %bb27
bb26:
  br label %bb147
bb27:
  %t97 = load i32, ptr %l70, !range !{i32 0, i32 116}
  store i32 %t97, ptr %l6
  %t98 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t100 = trunc i64 27 to i32
  %t101 = icmp eq i32 %t98, %t100
  br i1 %t101, label %bb28, label %bb29
bb28:
  store i1 true, ptr %l73, !tbaa !21
  br label %bb30
bb29:
  %t103 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t105 = trunc i64 75 to i32
  %t106 = icmp eq i32 %t103, %t105
  store i1 %t106, ptr %l73, !tbaa !21
  br label %bb30
bb30:
  %t108 = load i1, ptr %l73, !tbaa !21
  br i1 %t108, label %bb31, label %bb32
bb31:
  store i32 0, ptr %l7, !tbaa !23
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t109)
  %t112 = extractvalue { i32, i32 } %t111, 1
  %t113 = extractvalue { i32, i32 } %t111, 0
  store i32 %t113, ptr %l79
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb34, label %ok.115, !prof !99
ok.115:
  store i32 %t112, ptr %l78
  br label %bb33
bb32:
  br label %bb79
bb33:
  %t116 = load i32, ptr %l78, !tbaa !23
  store i32 %t116, ptr %l76, !tbaa !23
  br label %bb35
bb34:
  %t117 = load i32, ptr %l79, !tbaa !23
  %t118 = lshr i32 %t117, 16
  %t119 = and i32 %t117, 65535
  %t120 = icmp eq i32 %t118, 1
  %t121 = select i1 %t120, i32 1, i32 0
  %t122 = icmp eq i32 %t117, 0
  %t123 = shl i32 %t121, 16
  %t124 = or i32 %t123, %t119
  %t125 = select i1 %t122, i32 0, i32 %t124
  %t127 = insertvalue { i32, ptr } zeroinitializer, i32 %t125, 0
  store { i32, ptr } %t127, ptr %rv
  br label %ret
bb35:
  %t128 = load i32, ptr %l76, !tbaa !23
  store i32 %t128, ptr %l8, !tbaa !23
  %t129 = load ptr, ptr %l0, !tbaa !29
  %t132 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t129, i32 75)
  store i1 %t132, ptr %l83
  br label %bb36
bb36:
  %t133 = load i1, ptr %l83, !tbaa !21
  br i1 %t133, label %bb37, label %bb38
bb37:
  %t134 = load i32, ptr %l8, !tbaa !23
  store i32 %t134, ptr %l7, !tbaa !23
  %t136 = load ptr, ptr %l0, !tbaa !29
  %t138 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t136)
  %t139 = extractvalue { i32, i32 } %t138, 1
  %t140 = extractvalue { i32, i32 } %t138, 0
  store i32 %t140, ptr %l88
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb40, label %ok.142, !prof !99
ok.142:
  store i32 %t139, ptr %l87
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t143 = load i32, ptr %l87, !tbaa !23
  store i32 %t143, ptr %l85, !tbaa !23
  br label %bb41
bb40:
  %t144 = load i32, ptr %l88, !tbaa !23
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 1, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  %t154 = insertvalue { i32, ptr } zeroinitializer, i32 %t152, 0
  store { i32, ptr } %t154, ptr %rv
  br label %ret
bb41:
  %t155 = load i32, ptr %l85, !tbaa !23
  store i32 %t155, ptr %l8, !tbaa !23
  br label %bb42
bb42:
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t159 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t156, i32 27)
  %t160 = extractvalue { i32, i32 } %t159, 1
  %t161 = extractvalue { i32, i32 } %t159, 0
  store i32 %t161, ptr %l94
  %t162 = icmp ne i32 %t161, 0
  br i1 %t162, label %bb44, label %ok.163, !prof !99
ok.163:
  store i32 %t160, ptr %l93
  br label %bb43
bb43:
  %t164 = load i32, ptr %l93, !tbaa !23
  store i32 %t164, ptr %l90, !tbaa !23
  br label %bb45
bb44:
  %t165 = load i32, ptr %l94, !tbaa !23
  %t166 = lshr i32 %t165, 16
  %t167 = and i32 %t165, 65535
  %t168 = icmp eq i32 %t166, 1
  %t169 = select i1 %t168, i32 1, i32 0
  %t170 = icmp eq i32 %t165, 0
  %t171 = shl i32 %t169, 16
  %t172 = or i32 %t171, %t167
  %t173 = select i1 %t170, i32 0, i32 %t172
  %t175 = insertvalue { i32, ptr } zeroinitializer, i32 %t173, 0
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb45:
  %t176 = load ptr, ptr %l0, !tbaa !29
  %t179 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t176, i32 11)
  store i1 %t179, ptr %l98
  br label %bb46
bb46:
  %t180 = load i1, ptr %l98, !tbaa !21
  store i1 %t180, ptr %l9, !tbaa !21
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t183 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eforSource(ptr %v0, ptr %v1, ptr %t181)
  %t184 = extractvalue { i32, ptr } %t183, 1
  %t185 = extractvalue { i32, ptr } %t183, 0
  store i32 %t185, ptr %l102
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb48, label %ok.187, !prof !99
ok.187:
  store ptr %t184, ptr %l101
  br label %bb47
bb47:
  %t188 = load ptr, ptr %l101, !tbaa !29
  store ptr %t188, ptr %l99, !tbaa !29
  br label %bb49
bb48:
  %t189 = load i32, ptr %l102, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  %t199 = insertvalue { i32, ptr } zeroinitializer, i32 %t197, 0
  store { i32, ptr } %t199, ptr %rv
  br label %ret
bb49:
  %t200 = load ptr, ptr %l99, !tbaa !29
  store ptr %t200, ptr %l10, !tbaa !29
  %t201 = load ptr, ptr %l0, !tbaa !29
  %t203 = getelementptr %"compiler/parse:Parser", ptr %t201, i32 0, i32 33
  %t205 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t203)
  store i64 %t205, ptr %l106
  br label %bb50
bb50:
  %t206 = load i64, ptr %l106, !tbaa !24
  store i64 %t206, ptr %l11, !tbaa !24
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load ptr, ptr %l10, !tbaa !29
  %t211 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereflListPath(ptr %v0, ptr %v1, ptr %t207, ptr %t208)
  store i1 %t211, ptr %l109
  br label %bb51
bb51:
  %t212 = load i1, ptr %l109, !tbaa !21
  br i1 %t212, label %bb52, label %bb53
bb52:
  %t213 = load ptr, ptr %l0, !tbaa !29
  %t215 = getelementptr %"compiler/parse:Parser", ptr %t213, i32 0, i32 33
  %t216 = load i32, ptr %l8, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t215, i32 %t216)
  br label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb55
bb55:
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t221 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t219)
  %t222 = extractvalue { i32, { i64, ptr } } %t221, 1
  %t223 = extractvalue { i32, { i64, ptr } } %t221, 0
  store i32 %t223, ptr %l116
  %t224 = icmp ne i32 %t223, 0
  br i1 %t224, label %bb57, label %ok.225, !prof !99
ok.225:
  store { i64, ptr } %t222, ptr %l115
  br label %bb56
bb56:
  %t226 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t226, ptr %l113, !tbaa !27
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/parse:Parser", ptr %t227, i32 0, i32 33
  %t230 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t229, i64 %t230)
  br label %bb59
bb59:
  %t234 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t234, ptr %rv
  br label %ret
bb60:
  %t235 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t235, ptr %l12, !tbaa !27
  %t236 = load ptr, ptr %l0, !tbaa !29
  %t238 = getelementptr %"compiler/parse:Parser", ptr %t236, i32 0, i32 33
  %t239 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t238, i64 %t239)
  br label %bb61
bb61:
  %t242 = icmp sge i64 0, 0
  br i1 %t242, label %bb62, label %bb63
bb62:
  %t244 = icmp sle i64 0, 1152921504606846975
  br i1 %t244, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb64:
  %t246 = mul i64 0, 8
  %t247 = insertvalue { i64, ptr } undef, i64 0, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t248, ptr %l13, !tbaa !27
  %t250 = load i1, ptr %l9, !tbaa !21
  br i1 %t250, label %bb66, label %bb67
bb65:
  call void @__olang_check_failed(ptr @olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87)
  unreachable
bb66:
  %t252 = load ptr, ptr %l0, !tbaa !29
  %t254 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t252, i1 false)
  %t255 = extractvalue { i32, { i64, ptr } } %t254, 1
  %t256 = extractvalue { i32, { i64, ptr } } %t254, 0
  store i32 %t256, ptr %l131
  %t257 = icmp ne i32 %t256, 0
  br i1 %t257, label %bb69, label %ok.258, !prof !99
ok.258:
  store { i64, ptr } %t255, ptr %l130
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t259 = load { i64, ptr }, ptr %l130, !tbaa !27
  store { i64, ptr } %t259, ptr %l128, !tbaa !27
  br label %bb70
bb69:
  %t260 = load i32, ptr %l131, !tbaa !23
  %t261 = lshr i32 %t260, 16
  %t262 = and i32 %t260, 65535
  %t263 = icmp eq i32 %t261, 1
  %t264 = select i1 %t263, i32 1, i32 0
  %t265 = icmp eq i32 %t260, 0
  %t266 = shl i32 %t264, 16
  %t267 = or i32 %t266, %t262
  %t268 = select i1 %t265, i32 0, i32 %t267
  %t270 = insertvalue { i32, ptr } zeroinitializer, i32 %t268, 0
  store { i32, ptr } %t270, ptr %rv
  br label %ret
bb70:
  %t271 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t271, ptr %l13, !tbaa !27
  br label %bb71
bb71:
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t273 = load i32, ptr %l2, !tbaa !23
  %t276 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t272, i32 %t273)
  store %"compiler/source:Span" %t276, ptr %l135
  br label %bb72
bb72:
  %t277 = load %"compiler/source:Span", ptr %l135
  store %"compiler/source:Span" %t277, ptr %l14
  %t278 = load ptr, ptr %l0, !tbaa !29
  %t281 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t278, i32 8)
  store i1 %t281, ptr %l138
  br label %bb73
bb73:
  %t282 = load i1, ptr %l138, !tbaa !21
  br i1 %t282, label %bb74, label %bb75
bb74:
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t283)
  store i32 %t285, ptr %l140
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb77
bb77:
  %t286 = load %"compiler/source:Span", ptr %l14
  store %"compiler/source:Span" %t286, ptr %l141
  %t287 = load i32, ptr %l7, !tbaa !23
  %t288 = load i32, ptr %l8, !tbaa !23
  %t289 = load ptr, ptr %l10, !tbaa !29
  %t290 = load i1, ptr %l9, !tbaa !21
  %t291 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t292 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t293 = load i1, ptr %l3, !tbaa !21
  %t301 = call %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, i32 %t287, i32 %t288, ptr %t289, i1 %t290, { i64, ptr } %t291, { i64, ptr } %t292, i1 %t293)
  store %"compiler/ast:ForIn" %t301, ptr %l149
  br label %bb78
bb78:
  %t302 = load %"compiler/ast:ForIn", ptr %l149
  %t303 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:ForIn" %t302, ptr %t303
  store { i64, [4 x i64] } zeroinitializer, ptr %t304
  %t305 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 0
  store i64 9, ptr %t305
  %t306 = load %"compiler/source:Span", ptr %l141
  %t307 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t306, 0
  %t309 = insertvalue { %"compiler/source:Span", ptr } %t307, ptr %t303, 1
  %t310 = getelementptr { i64, [4 x i64] }, ptr %t304, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t309, ptr %t310
  %t311 = load { i64, [4 x i64] }, ptr %t304
  %t313 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t311, ptr %t313
  %t315 = insertvalue { i32, ptr } zeroinitializer, ptr %t313, 1
  store { i32, ptr } %t315, ptr %rv
  br label %ret
bb79:
  %t316 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t318 = trunc i64 80 to i32
  %t319 = icmp eq i32 %t316, %t318
  br i1 %t319, label %bb80, label %bb81
bb80:
  store i1 true, ptr %l155, !tbaa !21
  br label %bb82
bb81:
  %t321 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t323 = trunc i64 81 to i32
  %t324 = icmp eq i32 %t321, %t323
  store i1 %t324, ptr %l155, !tbaa !21
  br label %bb82
bb82:
  %t326 = load i1, ptr %l155, !tbaa !21
  br i1 %t326, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l158, !tbaa !21
  br label %bb85
bb84:
  %t327 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t329 = trunc i64 1 to i32
  %t330 = icmp eq i32 %t327, %t329
  store i1 %t330, ptr %l158, !tbaa !21
  br label %bb85
bb85:
  %t332 = load i1, ptr %l158, !tbaa !21
  br i1 %t332, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l161, !tbaa !21
  br label %bb88
bb87:
  %t333 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t335 = trunc i64 39 to i32
  %t336 = icmp eq i32 %t333, %t335
  store i1 %t336, ptr %l161, !tbaa !21
  br label %bb88
bb88:
  %t338 = load i1, ptr %l161, !tbaa !21
  br i1 %t338, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s11
  %t339 = load ptr, ptr %l0, !tbaa !29
  %t341 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t339)
  store i32 %t341, ptr %l165
  br label %bb91
bb90:
  br label %bb146
bb91:
  %t342 = load i32, ptr %l165, !tbaa !23
  store i32 %t342, ptr %l15, !tbaa !23
  %t343 = load ptr, ptr %l0, !tbaa !29
  %t345 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t343)
  store %"compiler/token:Token" %t345, ptr %l167
  br label %bb92
bb92:
  %t346 = load %"compiler/token:Token", ptr %l167
  store %"compiler/token:Token" %t346, ptr %l16
  %t347 = load ptr, ptr %l0, !tbaa !29
  %t349 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t347)
  %t350 = extractvalue { i32, i32 } %t349, 1
  %t351 = extractvalue { i32, i32 } %t349, 0
  store i32 %t351, ptr %l171
  %t352 = icmp ne i32 %t351, 0
  br i1 %t352, label %bb94, label %ok.353, !prof !99
ok.353:
  store i32 %t350, ptr %l170
  br label %bb93
bb93:
  %t354 = load i32, ptr %l170, !tbaa !23
  store i32 %t354, ptr %l168, !tbaa !23
  br label %bb95
bb94:
  %t355 = load i32, ptr %l171, !tbaa !23
  %t356 = lshr i32 %t355, 16
  %t357 = and i32 %t355, 65535
  %t358 = icmp eq i32 %t356, 1
  %t359 = select i1 %t358, i32 1, i32 0
  %t360 = icmp eq i32 %t355, 0
  %t361 = shl i32 %t359, 16
  %t362 = or i32 %t361, %t357
  %t363 = select i1 %t360, i32 0, i32 %t362
  call void @__olang_scope_close(ptr %s11)
  %t365 = insertvalue { i32, ptr } zeroinitializer, i32 %t363, 0
  store { i32, ptr } %t365, ptr %rv
  br label %ret
bb95:
  %t366 = load i32, ptr %l168, !tbaa !23
  %t367 = load ptr, ptr %l0, !tbaa !29
  store ptr %t367, ptr %l173, !tbaa !29
  store i32 %t366, ptr %l174, !tbaa !23
  %t369 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 2
  %t370 = load i32, ptr %t369, !tbaa !23
  %t371 = getelementptr %"compiler/token:Token", ptr %l16, i32 0, i32 3
  %t372 = load i32, ptr %t371, !tbaa !23
  %t375 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s11, i32 %t370, i32 %t372)
  store %"compiler/source:Span" %t375, ptr %l177
  br label %bb96
bb96:
  %t376 = load ptr, ptr %l173, !tbaa !29
  %t377 = load i32, ptr %l174, !tbaa !23
  %t378 = load %"compiler/source:Span", ptr %l177
  %t379 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %v1, ptr %t376, i32 %t377, %"compiler/source:Span" %t378)
  store ptr %t379, ptr %l178
  br label %bb97
bb97:
  %t380 = load ptr, ptr %l178, !tbaa !29
  store ptr %t380, ptr %l18, !tbaa !29
  store ptr null, ptr %l19, !tbaa !29
  %t381 = load ptr, ptr %l0, !tbaa !29
  %t384 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t381, i32 80)
  store i1 %t384, ptr %l181
  br label %bb98
bb98:
  %t385 = load i1, ptr %l181, !tbaa !21
  br i1 %t385, label %bb99, label %bb100
bb99:
  store i1 true, ptr %l182, !tbaa !21
  br label %bb102
bb100:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t389 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t386, i32 81)
  store i1 %t389, ptr %l185
  br label %bb101
bb101:
  %t390 = load i1, ptr %l185, !tbaa !21
  store i1 %t390, ptr %l182, !tbaa !21
  br label %bb102
bb102:
  %t391 = load i1, ptr %l182, !tbaa !21
  br i1 %t391, label %bb103, label %bb104
bb103:
  %t392 = load ptr, ptr %l0, !tbaa !29
  %t394 = getelementptr %"compiler/parse:Parser", ptr %t392, i32 0, i32 9
  %t395 = load i32, ptr %t394, !range !{i32 0, i32 116}
  %t397 = trunc i64 81 to i32
  %t398 = icmp eq i32 %t395, %t397
  store i1 %t398, ptr %l20, !tbaa !21
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t400)
  %t403 = extractvalue { i32, ptr } %t402, 1
  %t404 = extractvalue { i32, ptr } %t402, 0
  store i32 %t404, ptr %l192
  %t405 = icmp ne i32 %t404, 0
  br i1 %t405, label %bb106, label %ok.406, !prof !99
ok.406:
  store ptr %t403, ptr %l191
  br label %bb105
bb104:
  %t407 = load ptr, ptr %l0, !tbaa !29
  %t409 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t407)
  %t410 = extractvalue { i32, ptr } %t409, 1
  %t411 = extractvalue { i32, ptr } %t409, 0
  store i32 %t411, ptr %l206
  %t412 = icmp ne i32 %t411, 0
  br i1 %t412, label %bb110, label %ok.413, !prof !99
ok.413:
  store ptr %t410, ptr %l205
  br label %bb109
bb105:
  %t414 = load ptr, ptr %l191, !tbaa !29
  store ptr %t414, ptr %l189, !tbaa !29
  br label %bb107
bb106:
  %t415 = load i32, ptr %l192, !tbaa !23
  %t416 = lshr i32 %t415, 16
  %t417 = and i32 %t415, 65535
  %t418 = icmp eq i32 %t416, 1
  %t419 = select i1 %t418, i32 1, i32 0
  %t420 = icmp eq i32 %t415, 0
  %t421 = shl i32 %t419, 16
  %t422 = or i32 %t421, %t417
  %t423 = select i1 %t420, i32 0, i32 %t422
  call void @__olang_scope_close(ptr %s11)
  %t425 = insertvalue { i32, ptr } zeroinitializer, i32 %t423, 0
  store { i32, ptr } %t425, ptr %rv
  br label %ret
bb107:
  %t426 = load ptr, ptr %l189, !tbaa !29
  %t427 = load ptr, ptr %l18, !tbaa !29
  %t429 = getelementptr %"compiler/parse:NameList", ptr %t427, i32 0, i32 0
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !27
  %t431 = load ptr, ptr %l18, !tbaa !29
  %t433 = getelementptr %"compiler/parse:NameList", ptr %t431, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !27
  %t436 = mul i64 1, 8
  %t437 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t436)
  %t438 = insertvalue { i64, ptr } undef, i64 1, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t437, 1
  store { i64, ptr } %t439, ptr %l199, !tbaa !27
  %t441 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = getelementptr ptr, ptr %t442, i64 0
  store ptr %t426, ptr %t443, !tbaa !39
  %t444 = load i1, ptr %l20, !tbaa !21
  %t447 = load { i64, ptr }, ptr %l199, !tbaa !27
  %t449 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t430, { i64, ptr } %t434, ptr null, { i64, ptr } %t447, i1 true, i1 false, i1 %t444)
  store %"compiler/ast:VarDecl" %t449, ptr %l201
  br label %bb108
bb108:
  %t450 = load %"compiler/ast:VarDecl", ptr %l201
  %t451 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t450, ptr %t451
  store ptr %t451, ptr %l19, !tbaa !29
  br label %bb119
bb109:
  %t453 = load ptr, ptr %l205, !tbaa !29
  store ptr %t453, ptr %l203, !tbaa !29
  br label %bb111
bb110:
  %t454 = load i32, ptr %l206, !tbaa !23
  %t455 = lshr i32 %t454, 16
  %t456 = and i32 %t454, 65535
  %t457 = icmp eq i32 %t455, 1
  %t458 = select i1 %t457, i32 1, i32 0
  %t459 = icmp eq i32 %t454, 0
  %t460 = shl i32 %t458, 16
  %t461 = or i32 %t460, %t456
  %t462 = select i1 %t459, i32 0, i32 %t461
  call void @__olang_scope_close(ptr %s11)
  %t464 = insertvalue { i32, ptr } zeroinitializer, i32 %t462, 0
  store { i32, ptr } %t464, ptr %rv
  br label %ret
bb111:
  %t465 = load ptr, ptr %l203, !tbaa !29
  store ptr %t465, ptr %l22, !tbaa !29
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t469 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t466, i32 78)
  %t470 = extractvalue { i32, i32 } %t469, 1
  %t471 = extractvalue { i32, i32 } %t469, 0
  store i32 %t471, ptr %l212
  %t472 = icmp ne i32 %t471, 0
  br i1 %t472, label %bb113, label %ok.473, !prof !99
ok.473:
  store i32 %t470, ptr %l211
  br label %bb112
bb112:
  %t474 = load i32, ptr %l211, !tbaa !23
  store i32 %t474, ptr %l208, !tbaa !23
  br label %bb114
bb113:
  %t475 = load i32, ptr %l212, !tbaa !23
  %t476 = lshr i32 %t475, 16
  %t477 = and i32 %t475, 65535
  %t478 = icmp eq i32 %t476, 1
  %t479 = select i1 %t478, i32 1, i32 0
  %t480 = icmp eq i32 %t475, 0
  %t481 = shl i32 %t479, 16
  %t482 = or i32 %t481, %t477
  %t483 = select i1 %t480, i32 0, i32 %t482
  call void @__olang_scope_close(ptr %s11)
  %t485 = insertvalue { i32, ptr } zeroinitializer, i32 %t483, 0
  store { i32, ptr } %t485, ptr %rv
  br label %ret
bb114:
  %t486 = load ptr, ptr %l0, !tbaa !29
  %t488 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t486)
  %t489 = extractvalue { i32, ptr } %t488, 1
  %t490 = extractvalue { i32, ptr } %t488, 0
  store i32 %t490, ptr %l217
  %t491 = icmp ne i32 %t490, 0
  br i1 %t491, label %bb116, label %ok.492, !prof !99
ok.492:
  store ptr %t489, ptr %l216
  br label %bb115
bb115:
  %t493 = load ptr, ptr %l216, !tbaa !29
  store ptr %t493, ptr %l214, !tbaa !29
  br label %bb117
bb116:
  %t494 = load i32, ptr %l217, !tbaa !23
  %t495 = lshr i32 %t494, 16
  %t496 = and i32 %t494, 65535
  %t497 = icmp eq i32 %t495, 1
  %t498 = select i1 %t497, i32 1, i32 0
  %t499 = icmp eq i32 %t494, 0
  %t500 = shl i32 %t498, 16
  %t501 = or i32 %t500, %t496
  %t502 = select i1 %t499, i32 0, i32 %t501
  call void @__olang_scope_close(ptr %s11)
  %t504 = insertvalue { i32, ptr } zeroinitializer, i32 %t502, 0
  store { i32, ptr } %t504, ptr %rv
  br label %ret
bb117:
  %t505 = load ptr, ptr %l214, !tbaa !29
  %t506 = load ptr, ptr %l18, !tbaa !29
  %t508 = getelementptr %"compiler/parse:NameList", ptr %t506, i32 0, i32 0
  %t509 = load { i64, ptr }, ptr %t508, !tbaa !27
  %t510 = load ptr, ptr %l18, !tbaa !29
  %t512 = getelementptr %"compiler/parse:NameList", ptr %t510, i32 0, i32 1
  %t513 = load { i64, ptr }, ptr %t512, !tbaa !27
  %t514 = load ptr, ptr %l22, !tbaa !29
  %t517 = mul i64 1, 8
  %t518 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t517)
  %t519 = insertvalue { i64, ptr } undef, i64 1, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l226, !tbaa !27
  %t522 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t523 = load ptr, ptr %t522, !tbaa !27
  %t524 = getelementptr ptr, ptr %t523, i64 0
  store ptr %t505, ptr %t524, !tbaa !39
  %t528 = load { i64, ptr }, ptr %l226, !tbaa !27
  %t529 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t509, { i64, ptr } %t513, ptr %t514, { i64, ptr } %t528, i1 false, i1 false, i1 false)
  store %"compiler/ast:VarDecl" %t529, ptr %l227
  br label %bb118
bb118:
  %t530 = load %"compiler/ast:VarDecl", ptr %l227
  %t531 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 64, i64 8)
  store %"compiler/ast:VarDecl" %t530, ptr %t531
  store ptr %t531, ptr %l19, !tbaa !29
  br label %bb119
bb119:
  %t533 = load ptr, ptr %l0, !tbaa !29
  %t534 = load i32, ptr %l15, !tbaa !23
  %t537 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t533, i32 %t534)
  store %"compiler/source:Span" %t537, ptr %l231
  br label %bb120
bb120:
  %t538 = load ptr, ptr %l19, !tbaa !29
  %t540 = icmp eq ptr %t538, null
  br i1 %t540, label %bb121, label %bb122
bb121:
  call void @__olang_check_failed(ptr @olang_loc_d6bd877ff3d1e116_b58b2107b9da08f2)
  unreachable
bb122:
  br label %bb123
bb123:
  %t542 = load ptr, ptr %l19, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t543
  %t544 = getelementptr { i64, [4 x i64] }, ptr %t543, i32 0, i32 0
  store i64 1, ptr %t544
  %t545 = load %"compiler/source:Span", ptr %l231
  %t546 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t545, 0
  %t548 = insertvalue { %"compiler/source:Span", ptr } %t546, ptr %t542, 1
  %t549 = getelementptr { i64, [4 x i64] }, ptr %t543, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t548, ptr %t549
  %t550 = load { i64, [4 x i64] }, ptr %t543
  %t551 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t551, ptr %lp24
  %t553 = load ptr, ptr %lp24
  store { i64, [4 x i64] } %t550, ptr %t553
  %t554 = load ptr, ptr %l0, !tbaa !29
  %t557 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t554, i32 75)
  %t558 = extractvalue { i32, i32 } %t557, 1
  %t559 = extractvalue { i32, i32 } %t557, 0
  store i32 %t559, ptr %l240
  %t560 = icmp ne i32 %t559, 0
  br i1 %t560, label %bb125, label %ok.561, !prof !99
ok.561:
  store i32 %t558, ptr %l239
  br label %bb124
bb124:
  %t562 = load i32, ptr %l239, !tbaa !23
  store i32 %t562, ptr %l236, !tbaa !23
  br label %bb126
bb125:
  %t563 = load i32, ptr %l240, !tbaa !23
  %t564 = lshr i32 %t563, 16
  %t565 = and i32 %t563, 65535
  %t566 = icmp eq i32 %t564, 1
  %t567 = select i1 %t566, i32 1, i32 0
  %t568 = icmp eq i32 %t563, 0
  %t569 = shl i32 %t567, 16
  %t570 = or i32 %t569, %t565
  %t571 = select i1 %t568, i32 0, i32 %t570
  call void @__olang_scope_close(ptr %s11)
  %t573 = insertvalue { i32, ptr } zeroinitializer, i32 %t571, 0
  store { i32, ptr } %t573, ptr %rv
  br label %ret
bb126:
  %t574 = load ptr, ptr %l0, !tbaa !29
  %t576 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t574)
  %t577 = extractvalue { i32, ptr } %t576, 1
  %t578 = extractvalue { i32, ptr } %t576, 0
  store i32 %t578, ptr %l245
  %t579 = icmp ne i32 %t578, 0
  br i1 %t579, label %bb128, label %ok.580, !prof !99
ok.580:
  store ptr %t577, ptr %l244
  br label %bb127
bb127:
  %t581 = load ptr, ptr %l244, !tbaa !29
  store ptr %t581, ptr %l242, !tbaa !29
  br label %bb129
bb128:
  %t582 = load i32, ptr %l245, !tbaa !23
  %t583 = lshr i32 %t582, 16
  %t584 = and i32 %t582, 65535
  %t585 = icmp eq i32 %t583, 1
  %t586 = select i1 %t585, i32 1, i32 0
  %t587 = icmp eq i32 %t582, 0
  %t588 = shl i32 %t586, 16
  %t589 = or i32 %t588, %t584
  %t590 = select i1 %t587, i32 0, i32 %t589
  call void @__olang_scope_close(ptr %s11)
  %t592 = insertvalue { i32, ptr } zeroinitializer, i32 %t590, 0
  store { i32, ptr } %t592, ptr %rv
  br label %ret
bb129:
  %t593 = load ptr, ptr %l242, !tbaa !29
  store ptr %t593, ptr %l25, !tbaa !29
  %t594 = load ptr, ptr %l0, !tbaa !29
  %t597 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t594, i32 75)
  %t598 = extractvalue { i32, i32 } %t597, 1
  %t599 = extractvalue { i32, i32 } %t597, 0
  store i32 %t599, ptr %l251
  %t600 = icmp ne i32 %t599, 0
  br i1 %t600, label %bb131, label %ok.601, !prof !99
ok.601:
  store i32 %t598, ptr %l250
  br label %bb130
bb130:
  %t602 = load i32, ptr %l250, !tbaa !23
  store i32 %t602, ptr %l247, !tbaa !23
  br label %bb132
bb131:
  %t603 = load i32, ptr %l251, !tbaa !23
  %t604 = lshr i32 %t603, 16
  %t605 = and i32 %t603, 65535
  %t606 = icmp eq i32 %t604, 1
  %t607 = select i1 %t606, i32 1, i32 0
  %t608 = icmp eq i32 %t603, 0
  %t609 = shl i32 %t607, 16
  %t610 = or i32 %t609, %t605
  %t611 = select i1 %t608, i32 0, i32 %t610
  call void @__olang_scope_close(ptr %s11)
  %t613 = insertvalue { i32, ptr } zeroinitializer, i32 %t611, 0
  store { i32, ptr } %t613, ptr %rv
  br label %ret
bb132:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %v1, ptr %t614)
  %t617 = extractvalue { i32, ptr } %t616, 1
  %t618 = extractvalue { i32, ptr } %t616, 0
  store i32 %t618, ptr %l256
  %t619 = icmp ne i32 %t618, 0
  br i1 %t619, label %bb134, label %ok.620, !prof !99
ok.620:
  store ptr %t617, ptr %l255
  br label %bb133
bb133:
  %t621 = load ptr, ptr %l255, !tbaa !29
  store ptr %t621, ptr %l253, !tbaa !29
  br label %bb135
bb134:
  %t622 = load i32, ptr %l256, !tbaa !23
  %t623 = lshr i32 %t622, 16
  %t624 = and i32 %t622, 65535
  %t625 = icmp eq i32 %t623, 1
  %t626 = select i1 %t625, i32 1, i32 0
  %t627 = icmp eq i32 %t622, 0
  %t628 = shl i32 %t626, 16
  %t629 = or i32 %t628, %t624
  %t630 = select i1 %t627, i32 0, i32 %t629
  call void @__olang_scope_close(ptr %s11)
  %t632 = insertvalue { i32, ptr } zeroinitializer, i32 %t630, 0
  store { i32, ptr } %t632, ptr %rv
  br label %ret
bb135:
  %t633 = load ptr, ptr %l253, !tbaa !29
  store ptr %t633, ptr %l26, !tbaa !29
  %t634 = load ptr, ptr %l0, !tbaa !29
  %t636 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t634)
  %t637 = extractvalue { i32, { i64, ptr } } %t636, 1
  %t638 = extractvalue { i32, { i64, ptr } } %t636, 0
  store i32 %t638, ptr %l261
  %t639 = icmp ne i32 %t638, 0
  br i1 %t639, label %bb137, label %ok.640, !prof !99
ok.640:
  store { i64, ptr } %t637, ptr %l260
  br label %bb136
bb136:
  %t641 = load { i64, ptr }, ptr %l260, !tbaa !27
  store { i64, ptr } %t641, ptr %l258, !tbaa !27
  br label %bb138
bb137:
  %t642 = load i32, ptr %l261, !tbaa !23
  %t643 = lshr i32 %t642, 16
  %t644 = and i32 %t642, 65535
  %t645 = icmp eq i32 %t643, 1
  %t646 = select i1 %t645, i32 1, i32 0
  %t647 = icmp eq i32 %t642, 0
  %t648 = shl i32 %t646, 16
  %t649 = or i32 %t648, %t644
  %t650 = select i1 %t647, i32 0, i32 %t649
  call void @__olang_scope_close(ptr %s11)
  %t652 = insertvalue { i32, ptr } zeroinitializer, i32 %t650, 0
  store { i32, ptr } %t652, ptr %rv
  br label %ret
bb138:
  %t653 = load { i64, ptr }, ptr %l258, !tbaa !27
  store { i64, ptr } %t653, ptr %l27, !tbaa !27
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load i32, ptr %l2, !tbaa !23
  %t658 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t654, i32 %t655)
  store %"compiler/source:Span" %t658, ptr %l265
  br label %bb139
bb139:
  %t659 = load %"compiler/source:Span", ptr %l265
  store %"compiler/source:Span" %t659, ptr %l28
  %t660 = load ptr, ptr %l0, !tbaa !29
  %t663 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t660, i32 8)
  store i1 %t663, ptr %l268
  br label %bb140
bb140:
  %t664 = load i1, ptr %l268, !tbaa !21
  br i1 %t664, label %bb141, label %bb142
bb141:
  %t665 = load ptr, ptr %l0, !tbaa !29
  %t667 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t665)
  store i32 %t667, ptr %l270
  br label %bb143
bb142:
  br label %bb144
bb143:
  br label %bb144
bb144:
  %t668 = load %"compiler/source:Span", ptr %l28
  store %"compiler/source:Span" %t668, ptr %l271
  %t669 = load ptr, ptr %lp24
  %t670 = load ptr, ptr %l25, !tbaa !29
  %t672 = load ptr, ptr %l26, !tbaa !29
  %t673 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t678 = call %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t669, ptr %t670, ptr %t672, { i64, ptr } %t673)
  store %"compiler/ast:For3" %t678, ptr %l277
  br label %bb145
bb145:
  %t679 = load %"compiler/ast:For3", ptr %l277
  %t680 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store %"compiler/ast:For3" %t679, ptr %t680
  store { i64, [4 x i64] } zeroinitializer, ptr %t681
  %t682 = getelementptr { i64, [4 x i64] }, ptr %t681, i32 0, i32 0
  store i64 8, ptr %t682
  %t683 = load %"compiler/source:Span", ptr %l271
  %t684 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t683, 0
  %t686 = insertvalue { %"compiler/source:Span", ptr } %t684, ptr %t680, 1
  %t687 = getelementptr { i64, [4 x i64] }, ptr %t681, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t686, ptr %t687
  %t688 = load { i64, [4 x i64] }, ptr %t681
  %t690 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t688, ptr %t690
  call void @__olang_scope_close(ptr %s11)
  %t692 = insertvalue { i32, ptr } zeroinitializer, ptr %t690, 1
  store { i32, ptr } %t692, ptr %rv
  br label %ret
bb146:
  br label %bb147
bb147:
  %t693 = load i1, ptr %l3, !tbaa !21
  br i1 %t693, label %bb148, label %bb149
bb148:
  store %olang.scope zeroinitializer, ptr %s15
  %t695 = load ptr, ptr %l0, !tbaa !29
  %t697 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s15, ptr %t695, { i64, ptr } { i64 30, ptr getelementptr inbounds (<{ i64, [30 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i32 %t697, ptr %l283
  %t698 = icmp ne i32 %t697, 0
  br i1 %t698, label %bb151, label %ok.699, !prof !99
ok.699:
  br label %bb150
bb149:
  br label %bb153
bb150:
  br label %bb152
bb151:
  %t700 = load i32, ptr %l283, !tbaa !23
  %t701 = lshr i32 %t700, 16
  %t702 = and i32 %t700, 65535
  %t703 = icmp eq i32 %t701, 1
  %t704 = select i1 %t703, i32 1, i32 0
  %t705 = icmp eq i32 %t700, 0
  %t706 = shl i32 %t704, 16
  %t707 = or i32 %t706, %t702
  %t708 = select i1 %t705, i32 0, i32 %t707
  call void @__olang_scope_close(ptr %s15)
  %t710 = insertvalue { i32, ptr } zeroinitializer, i32 %t708, 0
  store { i32, ptr } %t710, ptr %rv
  br label %ret
bb152:
  call void @__olang_scope_close(ptr %s15)
  br label %bb153
bb153:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t713 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t711)
  %t714 = extractvalue { i32, ptr } %t713, 1
  %t715 = extractvalue { i32, ptr } %t713, 0
  store i32 %t715, ptr %l288
  %t716 = icmp ne i32 %t715, 0
  br i1 %t716, label %bb155, label %ok.717, !prof !99
ok.717:
  store ptr %t714, ptr %l287
  br label %bb154
bb154:
  %t718 = load ptr, ptr %l287, !tbaa !29
  store ptr %t718, ptr %l285, !tbaa !29
  br label %bb156
bb155:
  %t719 = load i32, ptr %l288, !tbaa !23
  %t720 = lshr i32 %t719, 16
  %t721 = and i32 %t719, 65535
  %t722 = icmp eq i32 %t720, 1
  %t723 = select i1 %t722, i32 1, i32 0
  %t724 = icmp eq i32 %t719, 0
  %t725 = shl i32 %t723, 16
  %t726 = or i32 %t725, %t721
  %t727 = select i1 %t724, i32 0, i32 %t726
  %t729 = insertvalue { i32, ptr } zeroinitializer, i32 %t727, 0
  store { i32, ptr } %t729, ptr %rv
  br label %ret
bb156:
  %t730 = load ptr, ptr %l285, !tbaa !29
  store ptr %t730, ptr %l29, !tbaa !29
  %t731 = load ptr, ptr %l0, !tbaa !29
  %t733 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %t731)
  %t734 = extractvalue { i32, { i64, ptr } } %t733, 1
  %t735 = extractvalue { i32, { i64, ptr } } %t733, 0
  store i32 %t735, ptr %l293
  %t736 = icmp ne i32 %t735, 0
  br i1 %t736, label %bb158, label %ok.737, !prof !99
ok.737:
  store { i64, ptr } %t734, ptr %l292
  br label %bb157
bb157:
  %t738 = load { i64, ptr }, ptr %l292, !tbaa !27
  store { i64, ptr } %t738, ptr %l290, !tbaa !27
  br label %bb159
bb158:
  %t739 = load i32, ptr %l293, !tbaa !23
  %t740 = lshr i32 %t739, 16
  %t741 = and i32 %t739, 65535
  %t742 = icmp eq i32 %t740, 1
  %t743 = select i1 %t742, i32 1, i32 0
  %t744 = icmp eq i32 %t739, 0
  %t745 = shl i32 %t743, 16
  %t746 = or i32 %t745, %t741
  %t747 = select i1 %t744, i32 0, i32 %t746
  %t749 = insertvalue { i32, ptr } zeroinitializer, i32 %t747, 0
  store { i32, ptr } %t749, ptr %rv
  br label %ret
bb159:
  %t750 = load { i64, ptr }, ptr %l290, !tbaa !27
  store { i64, ptr } %t750, ptr %l30, !tbaa !27
  %t751 = load ptr, ptr %l0, !tbaa !29
  %t752 = load i32, ptr %l2, !tbaa !23
  %t755 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t751, i32 %t752)
  store %"compiler/source:Span" %t755, ptr %l297
  br label %bb160
bb160:
  %t756 = load %"compiler/source:Span", ptr %l297
  store %"compiler/source:Span" %t756, ptr %l31
  %t757 = load ptr, ptr %l0, !tbaa !29
  %t760 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t757, i32 8)
  store i1 %t760, ptr %l300
  br label %bb161
bb161:
  %t761 = load i1, ptr %l300, !tbaa !21
  br i1 %t761, label %bb162, label %bb163
bb162:
  %t762 = load ptr, ptr %l0, !tbaa !29
  %t764 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t762)
  store i32 %t764, ptr %l302
  br label %bb164
bb163:
  br label %bb165
bb164:
  br label %bb165
bb165:
  %t765 = load %"compiler/source:Span", ptr %l31
  %t766 = load ptr, ptr %l29, !tbaa !29
  %t767 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t768
  %t769 = getelementptr { i64, [4 x i64] }, ptr %t768, i32 0, i32 0
  store i64 7, ptr %t769
  %t771 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t765, 0
  %t773 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t771, ptr %t766, 1
  %t775 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t773, { i64, ptr } %t767, 2
  %t776 = getelementptr { i64, [4 x i64] }, ptr %t768, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t775, ptr %t776
  %t777 = load { i64, [4 x i64] }, ptr %t768
  %t779 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t777, ptr %t779
  %t781 = insertvalue { i32, ptr } zeroinitializer, ptr %t779, 1
  store { i32, ptr } %t781, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca ptr
  %l4 = alloca ptr
  %l12 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eFuncSig(ptr %v1, ptr %v1, ptr %a1)
  store ptr %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load ptr, ptr %l4, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t7 = icmp eq ptr %t5, null
  br i1 %t7, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l2, !tbaa !29
  %t12 = getelementptr %"compiler/ast:Sig", ptr %t10, i32 0, i32 1
  %t13 = load { i64, ptr }, ptr %t12, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t17 = icmp sgt i64 %t15, 1
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t21 = getelementptr %"compiler/ast:Sig", ptr %t19, i32 0, i32 3
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t26 = icmp sgt i64 %t24, 1
  store i1 %t26, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l12, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  store i1 true, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t30 = load ptr, ptr %l2, !tbaa !29
  %t32 = getelementptr %"compiler/ast:Sig", ptr %t30, i32 0, i32 2
  %t33 = load i1, ptr %t32, !tbaa !21
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb11, label %bb12
bb11:
  %t40 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 77)
  store i1 %t40, ptr %l24
  br label %bb13
bb12:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t41 = load i1, ptr %l24, !tbaa !21
  store i1 %t41, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t42 = load i1, ptr %l21, !tbaa !21
  store i1 %t42, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehint(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca i64
  %l17 = alloca i32
  %l20 = alloca i64
  %l25 = alloca i32
  %l28 = alloca i64
  %l30 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %l34 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca i64
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/diagmsg:Msg"
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca %"compiler/diagmsg:Msg"
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i64
  %l63 = alloca %"compiler/diagmsg:Msg"
  %l67 = alloca i1
  %l68 = alloca i1
  %l72 = alloca i1
  %l76 = alloca i64
  %l79 = alloca i1
  %l82 = alloca i1
  %l85 = alloca i1
  %l88 = alloca i1
  %l91 = alloca i1
  %l94 = alloca i1
  %l97 = alloca i1
  %l100 = alloca i1
  %l103 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca i64
  %l110 = alloca { i64, ptr }
  %l112 = alloca %"compiler/diagmsg:Msg"
  %l116 = alloca i1
  %l117 = alloca i1
  %l121 = alloca i1
  %l123 = alloca i1
  %l124 = alloca i1
  %l128 = alloca i64
  %l131 = alloca i1
  %l135 = alloca i32
  %l138 = alloca i1
  %l142 = alloca i32
  %l145 = alloca i1
  %l149 = alloca i32
  %l152 = alloca ptr
  %l153 = alloca i64
  %l156 = alloca { i64, ptr }
  %l158 = alloca %"compiler/diagmsg:Msg"
  %l162 = alloca i1
  %l166 = alloca i1
  %l169 = alloca i1
  %l171 = alloca i1
  %l172 = alloca ptr
  %l173 = alloca i64
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l182 = alloca %"compiler/diagmsg:Msg"
  %l186 = alloca ptr
  %l187 = alloca i64
  %l188 = alloca %"compiler/diagmsg:Msg"
  %l192 = alloca i1
  %l195 = alloca i1
  %l198 = alloca i1
  %l202 = alloca ptr
  %l203 = alloca i64
  %l206 = alloca { i64, ptr }
  %l208 = alloca %"compiler/diagmsg:Msg"
  %l212 = alloca i1
  %l215 = alloca ptr
  %l216 = alloca i64
  %l217 = alloca %"compiler/diagmsg:Msg"
  %l221 = alloca i1
  %l222 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l226 = alloca i1
  %l227 = alloca i1
  %l230 = alloca i1
  %l233 = alloca i1
  %l236 = alloca i1
  %l242 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 7
  %t4 = load i32, ptr %t3, !range !{i32 0, i32 116}
  %t6 = trunc i64 0 to i32
  %t7 = icmp eq i32 %t4, %t6
  %t9 = xor i1 %t7, true
  br i1 %t9, label %bb1, label %bb2
bb1:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/parse:Parser", ptr %t12, i32 0, i32 6
  %t15 = load i64, ptr %t14, !tbaa !24
  store i64 %t15, ptr %l2, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t18 = load i64, ptr %l2, !tbaa !24
  %t21 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t17, i64 %t18)
  store i32 %t21, ptr %l17
  br label %bb4
bb4:
  %t22 = load i32, ptr %l17, !range !{i32 0, i32 116}
  store i32 %t22, ptr %l3
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t24 = load i64, ptr %l2, !tbaa !24
  %t27 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t23, i64 %t24)
  store i64 %t27, ptr %l20
  br label %bb5
bb5:
  %t28 = load i64, ptr %l20, !tbaa !24
  store i64 %t28, ptr %l4, !tbaa !24
  %t29 = load i64, ptr %l2, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l5, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t33, i64 %t34)
  store i32 %t37, ptr %l25
  br label %bb6
bb6:
  %t38 = load i32, ptr %l25, !range !{i32 0, i32 116}
  store i32 %t38, ptr %l6
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load i64, ptr %l5, !tbaa !24
  %t43 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t39, i64 %t40)
  store i64 %t43, ptr %l28
  br label %bb7
bb7:
  %t44 = load i64, ptr %l28, !tbaa !24
  store i64 %t44, ptr %l7, !tbaa !24
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t47 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t45)
  store i1 %t47, ptr %l30
  br label %bb8
bb8:
  %t48 = load i1, ptr %l30, !tbaa !21
  br i1 %t48, label %bb9, label %bb10
bb9:
  %t49 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t51 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t49, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d4, i32 0, i32 1) })
  store i1 %t51, ptr %l33
  br label %bb11
bb10:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb12
bb11:
  %t52 = load i1, ptr %l33, !tbaa !21
  store i1 %t52, ptr %l31, !tbaa !21
  br label %bb12
bb12:
  %t53 = load i1, ptr %l31, !tbaa !21
  br i1 %t53, label %bb13, label %bb14
bb13:
  %t54 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t56 = trunc i64 79 to i32
  %t57 = icmp eq i32 %t54, %t56
  %t59 = xor i1 %t57, true
  store i1 %t59, ptr %l34, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l34, !tbaa !21
  br label %bb15
bb15:
  %t61 = load i1, ptr %l34, !tbaa !21
  br i1 %t61, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s2
  %t62 = load ptr, ptr %l0, !tbaa !29
  store ptr %t62, ptr %l38, !tbaa !29
  %t63 = load i64, ptr %l2, !tbaa !24
  store i64 %t63, ptr %l39, !tbaa !24
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i64, ptr %l2, !tbaa !24
  %t68 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s2, ptr %t64, i64 %t65)
  store { i64, ptr } %t68, ptr %l42
  br label %bb18
bb17:
  br label %bb21
bb18:
  %t69 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t71 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %s2, ptr %v0, { i64, ptr } %t69)
  store %"compiler/diagmsg:Msg" %t71, ptr %l44
  br label %bb19
bb19:
  %t72 = load ptr, ptr %l38, !tbaa !29
  %t73 = load i64, ptr %l39, !tbaa !24
  %t74 = load %"compiler/diagmsg:Msg", ptr %l44
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t72, i64 %t73, %"compiler/diagmsg:Msg" %t74)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t76 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t78 = trunc i64 79 to i32
  %t79 = icmp eq i32 %t76, %t78
  br i1 %t79, label %bb22, label %bb23
bb22:
  %t81 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t81, ptr %l49, !tbaa !27
  %t83 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 114)
  store { i64, ptr } %t83, ptr %l51
  br label %bb24
bb23:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb26
bb24:
  %t84 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t85, { i64, ptr } %t84)
  store i1 %t87, ptr %l53
  br label %bb25
bb25:
  %t88 = load i1, ptr %l53, !tbaa !21
  store i1 %t88, ptr %l48, !tbaa !21
  br label %bb26
bb26:
  %t89 = load i1, ptr %l48, !tbaa !21
  br i1 %t89, label %bb27, label %bb28
bb27:
  %t90 = load ptr, ptr %l0, !tbaa !29
  store ptr %t90, ptr %l54, !tbaa !29
  %t91 = load i64, ptr %l2, !tbaa !24
  store i64 %t91, ptr %l55, !tbaa !24
  %t92 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoLineBody(ptr %v0)
  store %"compiler/diagmsg:Msg" %t92, ptr %l56
  br label %bb29
bb28:
  br label %bb31
bb29:
  %t93 = load ptr, ptr %l54, !tbaa !29
  %t94 = load i64, ptr %l55, !tbaa !24
  %t95 = load %"compiler/diagmsg:Msg", ptr %l56
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t93, i64 %t94, %"compiler/diagmsg:Msg" %t95)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb31:
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t98 = load i64, ptr %l2, !tbaa !24
  %t101 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseValueComma(ptr %v0, ptr %t97, i64 %t98)
  store i1 %t101, ptr %l60
  br label %bb32
bb32:
  %t102 = load i1, ptr %l60, !tbaa !21
  br i1 %t102, label %bb33, label %bb34
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l61, !tbaa !29
  %t104 = load i64, ptr %l2, !tbaa !24
  store i64 %t104, ptr %l62, !tbaa !24
  %t105 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0)
  store %"compiler/diagmsg:Msg" %t105, ptr %l63
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t106 = load ptr, ptr %l61, !tbaa !29
  %t107 = load i64, ptr %l62, !tbaa !24
  %t108 = load %"compiler/diagmsg:Msg", ptr %l63
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t106, i64 %t107, %"compiler/diagmsg:Msg" %t108)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb37:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load i64, ptr %l5, !tbaa !24
  %t114 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t110, i64 %t111)
  store i1 %t114, ptr %l67
  br label %bb38
bb38:
  %t115 = load i1, ptr %l67, !tbaa !21
  br i1 %t115, label %bb39, label %bb40
bb39:
  %t116 = load i64, ptr %l7, !tbaa !24
  %t117 = load i64, ptr %l4, !tbaa !24
  %t120 = icmp eq i64 %t116, %t117
  store i1 %t120, ptr %l68, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb41
bb41:
  %t122 = load i1, ptr %l68, !tbaa !21
  br i1 %t122, label %bb42, label %bb43
bb42:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t124 = load i64, ptr %l5, !tbaa !24
  %t126 = sub i64 %t124, 1
  %t129 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t123, i64 %t126)
  store i64 %t129, ptr %l76
  br label %bb44
bb43:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb45
bb44:
  %t130 = load i64, ptr %l7, !tbaa !24
  %t131 = load i64, ptr %l76, !tbaa !24
  %t133 = icmp slt i64 %t131, %t130
  store i1 %t133, ptr %l72, !tbaa !21
  br label %bb45
bb45:
  %t135 = load i1, ptr %l72, !tbaa !21
  br i1 %t135, label %bb46, label %bb47
bb46:
  %t136 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t138 = trunc i64 39 to i32
  %t139 = icmp eq i32 %t136, %t138
  br i1 %t139, label %bb48, label %bb49
bb47:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb72
bb48:
  store i1 true, ptr %l82, !tbaa !21
  br label %bb50
bb49:
  %t141 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t143 = trunc i64 80 to i32
  %t144 = icmp eq i32 %t141, %t143
  store i1 %t144, ptr %l82, !tbaa !21
  br label %bb50
bb50:
  %t146 = load i1, ptr %l82, !tbaa !21
  br i1 %t146, label %bb51, label %bb52
bb51:
  store i1 true, ptr %l85, !tbaa !21
  br label %bb53
bb52:
  %t147 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t149 = trunc i64 78 to i32
  %t150 = icmp eq i32 %t147, %t149
  store i1 %t150, ptr %l85, !tbaa !21
  br label %bb53
bb53:
  %t152 = load i1, ptr %l85, !tbaa !21
  br i1 %t152, label %bb54, label %bb55
bb54:
  store i1 true, ptr %l88, !tbaa !21
  br label %bb56
bb55:
  %t153 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t155 = trunc i64 75 to i32
  %t156 = icmp eq i32 %t153, %t155
  store i1 %t156, ptr %l88, !tbaa !21
  br label %bb56
bb56:
  %t158 = load i1, ptr %l88, !tbaa !21
  br i1 %t158, label %bb57, label %bb58
bb57:
  store i1 true, ptr %l91, !tbaa !21
  br label %bb71
bb58:
  %t159 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t161 = trunc i64 1 to i32
  %t162 = icmp eq i32 %t159, %t161
  br i1 %t162, label %bb59, label %bb60
bb59:
  %t164 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t166 = trunc i64 19 to i32
  %t167 = icmp eq i32 %t164, %t166
  br i1 %t167, label %bb61, label %bb62
bb60:
  store i1 false, ptr %l94, !tbaa !21
  br label %bb70
bb61:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb63
bb62:
  %t169 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t171 = trunc i64 20 to i32
  %t172 = icmp eq i32 %t169, %t171
  store i1 %t172, ptr %l97, !tbaa !21
  br label %bb63
bb63:
  %t174 = load i1, ptr %l97, !tbaa !21
  br i1 %t174, label %bb64, label %bb65
bb64:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb66
bb65:
  %t175 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t177 = trunc i64 21 to i32
  %t178 = icmp eq i32 %t175, %t177
  store i1 %t178, ptr %l100, !tbaa !21
  br label %bb66
bb66:
  %t180 = load i1, ptr %l100, !tbaa !21
  br i1 %t180, label %bb67, label %bb68
bb67:
  store i1 true, ptr %l103, !tbaa !21
  br label %bb69
bb68:
  %t181 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t183 = trunc i64 14 to i32
  %t184 = icmp eq i32 %t181, %t183
  store i1 %t184, ptr %l103, !tbaa !21
  br label %bb69
bb69:
  %t186 = load i1, ptr %l103, !tbaa !21
  store i1 %t186, ptr %l94, !tbaa !21
  br label %bb70
bb70:
  %t187 = load i1, ptr %l94, !tbaa !21
  store i1 %t187, ptr %l91, !tbaa !21
  br label %bb71
bb71:
  %t188 = load i1, ptr %l91, !tbaa !21
  store i1 %t188, ptr %l79, !tbaa !21
  br label %bb72
bb72:
  %t189 = load i1, ptr %l79, !tbaa !21
  br i1 %t189, label %bb73, label %bb74
bb73:
  store %olang.scope zeroinitializer, ptr %s5
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l106, !tbaa !29
  %t191 = load i64, ptr %l5, !tbaa !24
  store i64 %t191, ptr %l107, !tbaa !24
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t193 = load i64, ptr %l5, !tbaa !24
  %t196 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s5, ptr %t192, i64 %t193)
  store { i64, ptr } %t196, ptr %l110
  br label %bb75
bb74:
  br label %bb78
bb75:
  %t197 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t199 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s5, ptr %v0, { i64, ptr } %t197)
  store %"compiler/diagmsg:Msg" %t199, ptr %l112
  br label %bb76
bb76:
  %t200 = load ptr, ptr %l106, !tbaa !29
  %t201 = load i64, ptr %l107, !tbaa !24
  %t202 = load %"compiler/diagmsg:Msg", ptr %l112
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t200, i64 %t201, %"compiler/diagmsg:Msg" %t202)
  br label %bb77
bb77:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb78:
  %t204 = load ptr, ptr %l0, !tbaa !29
  %t205 = load i64, ptr %l2, !tbaa !24
  %t208 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %t204, i64 %t205)
  store i1 %t208, ptr %l116
  br label %bb79
bb79:
  %t209 = load i1, ptr %l116, !tbaa !21
  br i1 %t209, label %bb80, label %bb81
bb80:
  %t210 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t212 = trunc i64 39 to i32
  %t213 = icmp eq i32 %t210, %t212
  %t215 = xor i1 %t213, true
  store i1 %t215, ptr %l117, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l117, !tbaa !21
  br label %bb82
bb82:
  %t217 = load i1, ptr %l117, !tbaa !21
  br i1 %t217, label %bb83, label %bb84
bb83:
  %t218 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t218, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t220, ptr %l123
  br label %bb85
bb84:
  store i1 false, ptr %l121, !tbaa !21
  br label %bb102
bb85:
  %t221 = load i1, ptr %l123, !tbaa !21
  br i1 %t221, label %bb86, label %bb87
bb86:
  store i1 true, ptr %l124, !tbaa !21
  br label %bb101
bb87:
  %t222 = load ptr, ptr %l0, !tbaa !29
  %t223 = load i64, ptr %l2, !tbaa !24
  %t225 = add i64 %t223, 1
  %t228 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t222, i64 %t225)
  store i64 %t228, ptr %l128
  br label %bb88
bb88:
  %t229 = load i64, ptr %l4, !tbaa !24
  %t230 = load i64, ptr %l128, !tbaa !24
  %t232 = icmp eq i64 %t230, %t229
  br i1 %t232, label %bb89, label %bb90
bb89:
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t235 = load i64, ptr %l2, !tbaa !24
  %t237 = add i64 %t235, 1
  %t240 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t234, i64 %t237)
  store i32 %t240, ptr %l135
  br label %bb91
bb90:
  store i1 false, ptr %l131, !tbaa !21
  br label %bb100
bb91:
  %t241 = load i32, ptr %l135, !range !{i32 0, i32 116}
  %t243 = trunc i64 1 to i32
  %t244 = icmp eq i32 %t241, %t243
  br i1 %t244, label %bb92, label %bb93
bb92:
  store i1 true, ptr %l138, !tbaa !21
  br label %bb95
bb93:
  %t246 = load ptr, ptr %l0, !tbaa !29
  %t247 = load i64, ptr %l2, !tbaa !24
  %t249 = add i64 %t247, 1
  %t252 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t246, i64 %t249)
  store i32 %t252, ptr %l142
  br label %bb94
bb94:
  %t253 = load i32, ptr %l142, !range !{i32 0, i32 116}
  %t255 = trunc i64 39 to i32
  %t256 = icmp eq i32 %t253, %t255
  store i1 %t256, ptr %l138, !tbaa !21
  br label %bb95
bb95:
  %t258 = load i1, ptr %l138, !tbaa !21
  br i1 %t258, label %bb96, label %bb97
bb96:
  store i1 true, ptr %l145, !tbaa !21
  br label %bb99
bb97:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load i64, ptr %l2, !tbaa !24
  %t262 = add i64 %t260, 1
  %t265 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t259, i64 %t262)
  store i32 %t265, ptr %l149
  br label %bb98
bb98:
  %t266 = load i32, ptr %l149, !range !{i32 0, i32 116}
  %t268 = trunc i64 80 to i32
  %t269 = icmp eq i32 %t266, %t268
  store i1 %t269, ptr %l145, !tbaa !21
  br label %bb99
bb99:
  %t271 = load i1, ptr %l145, !tbaa !21
  store i1 %t271, ptr %l131, !tbaa !21
  br label %bb100
bb100:
  %t272 = load i1, ptr %l131, !tbaa !21
  store i1 %t272, ptr %l124, !tbaa !21
  br label %bb101
bb101:
  %t273 = load i1, ptr %l124, !tbaa !21
  store i1 %t273, ptr %l121, !tbaa !21
  br label %bb102
bb102:
  %t274 = load i1, ptr %l121, !tbaa !21
  br i1 %t274, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s6
  %t275 = load ptr, ptr %l0, !tbaa !29
  store ptr %t275, ptr %l152, !tbaa !29
  %t276 = load i64, ptr %l2, !tbaa !24
  store i64 %t276, ptr %l153, !tbaa !24
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t278 = load i64, ptr %l2, !tbaa !24
  %t281 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s6, ptr %t277, i64 %t278)
  store { i64, ptr } %t281, ptr %l156
  br label %bb105
bb104:
  br label %bb108
bb105:
  %t282 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t284 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %s6, ptr %v0, { i64, ptr } %t282)
  store %"compiler/diagmsg:Msg" %t284, ptr %l158
  br label %bb106
bb106:
  %t285 = load ptr, ptr %l152, !tbaa !29
  %t286 = load i64, ptr %l153, !tbaa !24
  %t287 = load %"compiler/diagmsg:Msg", ptr %l158
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t285, i64 %t286, %"compiler/diagmsg:Msg" %t287)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb108:
  %t289 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t291 = trunc i64 8 to i32
  %t292 = icmp eq i32 %t289, %t291
  br i1 %t292, label %bb109, label %bb110
bb109:
  store i1 true, ptr %l162, !tbaa !21
  br label %bb111
bb110:
  %t294 = load i64, ptr %l7, !tbaa !24
  %t295 = load i64, ptr %l4, !tbaa !24
  %t298 = icmp slt i64 %t294, %t295
  store i1 %t298, ptr %l162, !tbaa !21
  br label %bb111
bb111:
  %t300 = load i1, ptr %l162, !tbaa !21
  br i1 %t300, label %bb112, label %bb113
bb112:
  %t301 = load i64, ptr %l4, !tbaa !24
  %t303 = icmp sgt i64 %t301, 0
  store i1 %t303, ptr %l166, !tbaa !21
  br label %bb114
bb113:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb114
bb114:
  %t305 = load i1, ptr %l166, !tbaa !21
  br i1 %t305, label %bb115, label %bb116
bb115:
  %t306 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t308 = call i1 @compiler_2fparse_2eisJoiningOp(i32 %t306)
  store i1 %t308, ptr %l171
  br label %bb117
bb116:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb118
bb117:
  %t309 = load i1, ptr %l171, !tbaa !21
  store i1 %t309, ptr %l169, !tbaa !21
  br label %bb118
bb118:
  %t310 = load i1, ptr %l169, !tbaa !21
  br i1 %t310, label %bb119, label %bb120
bb119:
  store %olang.scope zeroinitializer, ptr %s7
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l172, !tbaa !29
  %t312 = load i64, ptr %l2, !tbaa !24
  store i64 %t312, ptr %l173, !tbaa !24
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load i64, ptr %l2, !tbaa !24
  %t317 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s7, ptr %t313, i64 %t314)
  store { i64, ptr } %t317, ptr %l176
  br label %bb121
bb120:
  br label %bb125
bb121:
  %t318 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t318, ptr %l177, !tbaa !27
  %t319 = load ptr, ptr %l0, !tbaa !29
  %t320 = load i64, ptr %l2, !tbaa !24
  %t323 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s7, ptr %t319, i64 %t320)
  store { i64, ptr } %t323, ptr %l180
  br label %bb122
bb122:
  %t324 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t327 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %s7, ptr %s7, ptr %v0, { i64, ptr } %t325, { i64, ptr } %t324)
  store %"compiler/diagmsg:Msg" %t327, ptr %l182
  br label %bb123
bb123:
  %t328 = load ptr, ptr %l172, !tbaa !29
  %t329 = load i64, ptr %l173, !tbaa !24
  %t330 = load %"compiler/diagmsg:Msg", ptr %l182
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t328, i64 %t329, %"compiler/diagmsg:Msg" %t330)
  br label %bb124
bb124:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb125:
  %t332 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t334 = trunc i64 42 to i32
  %t335 = icmp eq i32 %t332, %t334
  br i1 %t335, label %bb126, label %bb127
bb126:
  %t337 = load ptr, ptr %l0, !tbaa !29
  store ptr %t337, ptr %l186, !tbaa !29
  %t338 = load i64, ptr %l2, !tbaa !24
  store i64 %t338, ptr %l187, !tbaa !24
  %t339 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0)
  store %"compiler/diagmsg:Msg" %t339, ptr %l188
  br label %bb128
bb127:
  br label %bb130
bb128:
  %t340 = load ptr, ptr %l186, !tbaa !29
  %t341 = load i64, ptr %l187, !tbaa !24
  %t342 = load %"compiler/diagmsg:Msg", ptr %l188
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t340, i64 %t341, %"compiler/diagmsg:Msg" %t342)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb130:
  %t344 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t346 = trunc i64 111 to i32
  %t347 = icmp eq i32 %t344, %t346
  br i1 %t347, label %bb131, label %bb132
bb131:
  store i1 true, ptr %l192, !tbaa !21
  br label %bb133
bb132:
  %t349 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t351 = trunc i64 113 to i32
  %t352 = icmp eq i32 %t349, %t351
  store i1 %t352, ptr %l192, !tbaa !21
  br label %bb133
bb133:
  %t354 = load i1, ptr %l192, !tbaa !21
  br i1 %t354, label %bb134, label %bb135
bb134:
  %t355 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t357 = trunc i64 75 to i32
  %t358 = icmp eq i32 %t355, %t357
  store i1 %t358, ptr %l195, !tbaa !21
  br label %bb136
bb135:
  store i1 false, ptr %l195, !tbaa !21
  br label %bb136
bb136:
  %t360 = load i1, ptr %l195, !tbaa !21
  br i1 %t360, label %bb137, label %bb138
bb137:
  %t361 = load i64, ptr %l7, !tbaa !24
  %t362 = load i64, ptr %l4, !tbaa !24
  %t365 = icmp eq i64 %t361, %t362
  store i1 %t365, ptr %l198, !tbaa !21
  br label %bb139
bb138:
  store i1 false, ptr %l198, !tbaa !21
  br label %bb139
bb139:
  %t367 = load i1, ptr %l198, !tbaa !21
  br i1 %t367, label %bb140, label %bb141
bb140:
  store %olang.scope zeroinitializer, ptr %s9
  %t368 = load ptr, ptr %l0, !tbaa !29
  store ptr %t368, ptr %l202, !tbaa !29
  %t369 = load i64, ptr %l5, !tbaa !24
  store i64 %t369, ptr %l203, !tbaa !24
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t371 = load i64, ptr %l2, !tbaa !24
  %t374 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %s9, ptr %t370, i64 %t371)
  store { i64, ptr } %t374, ptr %l206
  br label %bb142
bb141:
  br label %bb145
bb142:
  %t375 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t377 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %s9, ptr %v0, { i64, ptr } %t375)
  store %"compiler/diagmsg:Msg" %t377, ptr %l208
  br label %bb143
bb143:
  %t378 = load ptr, ptr %l202, !tbaa !29
  %t379 = load i64, ptr %l203, !tbaa !24
  %t380 = load %"compiler/diagmsg:Msg", ptr %l208
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t378, i64 %t379, %"compiler/diagmsg:Msg" %t380)
  br label %bb144
bb144:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb145:
  %t382 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t384 = trunc i64 38 to i32
  %t385 = icmp eq i32 %t382, %t384
  br i1 %t385, label %bb146, label %bb147
bb146:
  %t387 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t389 = trunc i64 77 to i32
  %t390 = icmp eq i32 %t387, %t389
  store i1 %t390, ptr %l212, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l212, !tbaa !21
  br label %bb148
bb148:
  %t392 = load i1, ptr %l212, !tbaa !21
  br i1 %t392, label %bb149, label %bb150
bb149:
  %t393 = load ptr, ptr %l0, !tbaa !29
  store ptr %t393, ptr %l215, !tbaa !29
  %t394 = load i64, ptr %l2, !tbaa !24
  store i64 %t394, ptr %l216, !tbaa !24
  %t395 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0)
  store %"compiler/diagmsg:Msg" %t395, ptr %l217
  br label %bb151
bb150:
  br label %bb153
bb151:
  %t396 = load ptr, ptr %l215, !tbaa !29
  %t397 = load i64, ptr %l216, !tbaa !24
  %t398 = load %"compiler/diagmsg:Msg", ptr %l217
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t396, i64 %t397, %"compiler/diagmsg:Msg" %t398)
  br label %bb152
bb152:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb153:
  %t400 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t402 = trunc i64 110 to i32
  %t403 = icmp eq i32 %t400, %t402
  br i1 %t403, label %bb154, label %bb155
bb154:
  %t405 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t405, ptr %l222, !tbaa !27
  %t407 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s0, i32 8)
  store { i64, ptr } %t407, ptr %l224
  br label %bb156
bb155:
  store i1 false, ptr %l221, !tbaa !21
  br label %bb158
bb156:
  %t408 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t409 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t411 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t409, { i64, ptr } %t408)
  store i1 %t411, ptr %l226
  br label %bb157
bb157:
  %t412 = load i1, ptr %l226, !tbaa !21
  store i1 %t412, ptr %l221, !tbaa !21
  br label %bb158
bb158:
  %t413 = load i1, ptr %l221, !tbaa !21
  br i1 %t413, label %bb159, label %bb160
bb159:
  %t414 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t416 = trunc i64 100 to i32
  %t417 = icmp eq i32 %t414, %t416
  br i1 %t417, label %bb161, label %bb162
bb160:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb167
bb161:
  store i1 true, ptr %l230, !tbaa !21
  br label %bb163
bb162:
  %t419 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t421 = trunc i64 109 to i32
  %t422 = icmp eq i32 %t419, %t421
  store i1 %t422, ptr %l230, !tbaa !21
  br label %bb163
bb163:
  %t424 = load i1, ptr %l230, !tbaa !21
  br i1 %t424, label %bb164, label %bb165
bb164:
  store i1 true, ptr %l233, !tbaa !21
  br label %bb166
bb165:
  %t425 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t427 = trunc i64 1 to i32
  %t428 = icmp eq i32 %t425, %t427
  store i1 %t428, ptr %l233, !tbaa !21
  br label %bb166
bb166:
  %t430 = load i1, ptr %l233, !tbaa !21
  store i1 %t430, ptr %l227, !tbaa !21
  br label %bb167
bb167:
  %t431 = load i1, ptr %l227, !tbaa !21
  br i1 %t431, label %bb168, label %bb169
bb168:
  %t432 = load i64, ptr %l7, !tbaa !24
  %t433 = load i64, ptr %l4, !tbaa !24
  %t436 = icmp eq i64 %t432, %t433
  store i1 %t436, ptr %l236, !tbaa !21
  br label %bb170
bb169:
  store i1 false, ptr %l236, !tbaa !21
  br label %bb170
bb170:
  %t438 = load i1, ptr %l236, !tbaa !21
  br i1 %t438, label %bb171, label %bb172
bb171:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t440 = load i64, ptr %l2, !tbaa !24
  %t443 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %t439, i64 %t440)
  store i1 %t443, ptr %l242
  br label %bb173
bb172:
  br label %bb174
bb173:
  call void @__olang_scope_close(ptr %s0)
  %t444 = load i1, ptr %l242, !tbaa !21
  store i1 %t444, ptr %rv
  br label %ret
bb174:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"compiler/source:Span"
  %l7 = alloca i32
  %l10 = alloca i32
  %l11 = alloca i32
  %l13 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i32
  %l18 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca i1
  %l28 = alloca i1
  %l29 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca i32
  %l35 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca %"compiler/source:Span"
  %l44 = alloca %"compiler/ast:If"
  %l50 = alloca %"compiler/source:Span"
  %l53 = alloca i1
  %l55 = alloca i32
  %l56 = alloca %"compiler/source:Span"
  %l62 = alloca %"compiler/ast:If"
  %rv = alloca { i32, ptr }
  %t123 = alloca { i64, [4 x i64] }, align 8
  %t160 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 9)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l11
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l10
  br label %bb1
bb1:
  %t9 = load i32, ptr %l10, !tbaa !23
  store i32 %t9, ptr %l7, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l11, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l7, !tbaa !23
  store i32 %t21, ptr %l1, !tbaa !23
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t22)
  %t25 = extractvalue { i32, ptr } %t24, 1
  %t26 = extractvalue { i32, ptr } %t24, 0
  store i32 %t26, ptr %l16
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb5, label %ok.28, !prof !99
ok.28:
  store ptr %t25, ptr %l15
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l15, !tbaa !29
  store ptr %t29, ptr %l13, !tbaa !29
  br label %bb6
bb5:
  %t30 = load i32, ptr %l16, !tbaa !23
  %t31 = lshr i32 %t30, 16
  %t32 = and i32 %t30, 65535
  %t33 = icmp eq i32 %t31, 1
  %t34 = select i1 %t33, i32 1, i32 0
  %t35 = icmp eq i32 %t30, 0
  %t36 = shl i32 %t34, 16
  %t37 = or i32 %t36, %t32
  %t38 = select i1 %t35, i32 0, i32 %t37
  %t40 = insertvalue { i32, ptr } zeroinitializer, i32 %t38, 0
  store { i32, ptr } %t40, ptr %rv
  br label %ret
bb6:
  %t41 = load ptr, ptr %l13, !tbaa !29
  store ptr %t41, ptr %l2, !tbaa !29
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %v1, ptr %t42)
  %t45 = extractvalue { i32, ptr } %t44, 1
  %t46 = extractvalue { i32, ptr } %t44, 0
  store i32 %t46, ptr %l21
  %t47 = icmp ne i32 %t46, 0
  br i1 %t47, label %bb8, label %ok.48, !prof !99
ok.48:
  store ptr %t45, ptr %l20
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l20, !tbaa !29
  store ptr %t49, ptr %l18, !tbaa !29
  br label %bb9
bb8:
  %t50 = load i32, ptr %l21, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  %t60 = insertvalue { i32, ptr } zeroinitializer, i32 %t58, 0
  store { i32, ptr } %t60, ptr %rv
  br label %ret
bb9:
  %t61 = load ptr, ptr %l18, !tbaa !29
  store ptr %t61, ptr %l3, !tbaa !29
  store ptr null, ptr %l4, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t65 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t62, i32 10)
  store i1 %t65, ptr %l25
  br label %bb10
bb10:
  %t66 = load i1, ptr %l25, !tbaa !21
  br i1 %t66, label %bb11, label %bb12
bb11:
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t70 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t67, i32 9)
  store i1 %t70, ptr %l28
  br label %bb13
bb12:
  br label %bb24
bb13:
  %t71 = load i1, ptr %l28, !tbaa !21
  br i1 %t71, label %bb14, label %bb15
bb14:
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eifStmt(ptr %v0, ptr %v1, ptr %t72)
  %t75 = extractvalue { i32, ptr } %t74, 1
  %t76 = extractvalue { i32, ptr } %t74, 0
  store i32 %t76, ptr %l32
  %t77 = icmp ne i32 %t76, 0
  br i1 %t77, label %bb17, label %ok.78, !prof !99
ok.78:
  store ptr %t75, ptr %l31
  br label %bb16
bb15:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %v1, ptr %t79)
  %t82 = extractvalue { i32, ptr } %t81, 1
  %t83 = extractvalue { i32, ptr } %t81, 0
  store i32 %t83, ptr %l38
  %t84 = icmp ne i32 %t83, 0
  br i1 %t84, label %bb20, label %ok.85, !prof !99
ok.85:
  store ptr %t82, ptr %l37
  br label %bb19
bb16:
  %t86 = load ptr, ptr %l31, !tbaa !29
  store ptr %t86, ptr %l29, !tbaa !29
  br label %bb18
bb17:
  %t87 = load i32, ptr %l32, !tbaa !23
  %t88 = lshr i32 %t87, 16
  %t89 = and i32 %t87, 65535
  %t90 = icmp eq i32 %t88, 1
  %t91 = select i1 %t90, i32 1, i32 0
  %t92 = icmp eq i32 %t87, 0
  %t93 = shl i32 %t91, 16
  %t94 = or i32 %t93, %t89
  %t95 = select i1 %t92, i32 0, i32 %t94
  %t97 = insertvalue { i32, ptr } zeroinitializer, i32 %t95, 0
  store { i32, ptr } %t97, ptr %rv
  br label %ret
bb18:
  %t98 = load ptr, ptr %l29, !tbaa !29
  store ptr %t98, ptr %l4, !tbaa !29
  br label %bb23
bb19:
  %t100 = load ptr, ptr %l37, !tbaa !29
  store ptr %t100, ptr %l35, !tbaa !29
  br label %bb21
bb20:
  %t101 = load i32, ptr %l38, !tbaa !23
  %t102 = lshr i32 %t101, 16
  %t103 = and i32 %t101, 65535
  %t104 = icmp eq i32 %t102, 1
  %t105 = select i1 %t104, i32 1, i32 0
  %t106 = icmp eq i32 %t101, 0
  %t107 = shl i32 %t105, 16
  %t108 = or i32 %t107, %t103
  %t109 = select i1 %t106, i32 0, i32 %t108
  %t111 = insertvalue { i32, ptr } zeroinitializer, i32 %t109, 0
  store { i32, ptr } %t111, ptr %rv
  br label %ret
bb21:
  %t112 = load ptr, ptr %l35, !tbaa !29
  store ptr %t112, ptr %l5, !tbaa !29
  %t113 = load ptr, ptr %l5, !tbaa !29
  %t115 = getelementptr %"compiler/ast:Branch", ptr %t113, i32 0, i32 0
  %t116 = load %"compiler/source:Span", ptr %t115
  store %"compiler/source:Span" %t116, ptr %l41
  %t117 = load ptr, ptr %l5, !tbaa !29
  %t120 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr null, ptr %t117, ptr null)
  store %"compiler/ast:If" %t120, ptr %l44
  br label %bb22
bb22:
  %t121 = load %"compiler/ast:If", ptr %l44
  %t122 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t121, ptr %t122
  store { i64, [4 x i64] } zeroinitializer, ptr %t123
  %t124 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 0
  store i64 5, ptr %t124
  %t125 = load %"compiler/source:Span", ptr %l41
  %t126 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t125, 0
  %t128 = insertvalue { %"compiler/source:Span", ptr } %t126, ptr %t122, 1
  %t129 = getelementptr { i64, [4 x i64] }, ptr %t123, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t128, ptr %t129
  %t130 = load { i64, [4 x i64] }, ptr %t123
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t130, ptr %t132
  store ptr %t132, ptr %l4, !tbaa !29
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t135 = load i32, ptr %l1, !tbaa !23
  %t138 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t134, i32 %t135)
  store %"compiler/source:Span" %t138, ptr %l50
  br label %bb25
bb25:
  %t139 = load %"compiler/source:Span", ptr %l50
  store %"compiler/source:Span" %t139, ptr %l6
  %t140 = load ptr, ptr %l0, !tbaa !29
  %t143 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t140, i32 8)
  store i1 %t143, ptr %l53
  br label %bb26
bb26:
  %t144 = load i1, ptr %l53, !tbaa !21
  br i1 %t144, label %bb27, label %bb28
bb27:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t145)
  store i32 %t147, ptr %l55
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t148 = load %"compiler/source:Span", ptr %l6
  store %"compiler/source:Span" %t148, ptr %l56
  %t149 = load ptr, ptr %l2, !tbaa !29
  %t151 = load ptr, ptr %l3, !tbaa !29
  %t153 = load ptr, ptr %l4, !tbaa !29
  %t157 = call %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %t149, ptr %t151, ptr %t153)
  store %"compiler/ast:If" %t157, ptr %l62
  br label %bb31
bb31:
  %t158 = load %"compiler/ast:If", ptr %l62
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 24, i64 8)
  store %"compiler/ast:If" %t158, ptr %t159
  store { i64, [4 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 0
  store i64 5, ptr %t161
  %t162 = load %"compiler/source:Span", ptr %l56
  %t163 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t162, 0
  %t165 = insertvalue { %"compiler/source:Span", ptr } %t163, ptr %t159, 1
  %t166 = getelementptr { i64, [4 x i64] }, ptr %t160, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t165, ptr %t166
  %t167 = load { i64, [4 x i64] }, ptr %t160
  %t169 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t167, ptr %t169
  %t171 = insertvalue { i32, ptr } zeroinitializer, ptr %t169, 1
  store { i32, ptr } %t171, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisKw(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l3 = alloca %"compiler/token:Token"
  %l6 = alloca i32
  %l9 = alloca i1
  %l12 = alloca i1
  %l18 = alloca { i64, ptr }
  %l24 = alloca i1
  %l27 = alloca { i64, ptr }
  %l30 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i32, ptr %l6, !range !{i32 0, i32 116}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t9 = trunc i64 1 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb4
bb3:
  %t12 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t14 = trunc i64 0 to i32
  %t15 = icmp eq i32 %t12, %t14
  store i1 %t15, ptr %l9, !tbaa !21
  br label %bb4
bb4:
  %t17 = load i1, ptr %l9, !tbaa !21
  br i1 %t17, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb7
bb6:
  %t18 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t20 = trunc i64 8 to i32
  %t21 = icmp eq i32 %t18, %t20
  store i1 %t21, ptr %l12, !tbaa !21
  br label %bb7
bb7:
  %t23 = load i1, ptr %l12, !tbaa !21
  br i1 %t23, label %bb8, label %bb9
bb8:
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !29
  %t30 = getelementptr %"compiler/scan:Tokens", ptr %t28, i32 0, i32 0
  %t31 = load { i64, ptr }, ptr %t30, !tbaa !27
  store { i64, ptr } %t31, ptr %l18, !tbaa !27
  %t32 = load i64, ptr %l1, !tbaa !24
  %t34 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/token:Token", ptr %t35, i64 %t32
  %t37 = load %"compiler/token:Token", ptr %t36
  store %"compiler/token:Token" %t37, ptr %l3
  %t39 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t40 = load i32, ptr %t39, !tbaa !23
  %t41 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = icmp sgt i32 %t40, %t42
  br i1 %t45, label %bb11, label %bb12
bb11:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/parse:Parser", ptr %t47, i32 0, i32 0
  %t50 = load ptr, ptr %t49, !tbaa !29
  %t52 = getelementptr %"compiler/source:Source", ptr %t50, i32 0, i32 1
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l27, !tbaa !27
  %t54 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t55 = load i32, ptr %t54, !tbaa !23
  %t57 = sext i32 %t55 to i64
  %t58 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 %t57
  %t61 = load i8, ptr %t60, !tbaa !32
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t61)
  store i1 %t63, ptr %l30
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb14
bb13:
  %t64 = load i1, ptr %l30, !tbaa !21
  store i1 %t64, ptr %l24, !tbaa !21
  br label %bb14
bb14:
  %t65 = load i1, ptr %l24, !tbaa !21
  store i1 %t65, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineStartsCase(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %l14 = alloca i64
  %l23 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t1, i64 %t2)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp sgt i64 %t9, 0
  br i1 %t11, label %bb3, label %bb4
bb3:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t14 = load i64, ptr %l3, !tbaa !24
  %t16 = sub i64 %t14, 1
  %t19 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t13, i64 %t16)
  store i64 %t19, ptr %l14
  br label %bb5
bb4:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb6
bb5:
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr %l14, !tbaa !24
  %t23 = icmp eq i64 %t21, %t20
  store i1 %t23, ptr %l10, !tbaa !21
  br label %bb6
bb6:
  %t25 = load i1, ptr %l10, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t28 = load i64, ptr %l3, !tbaa !24
  %t31 = sub i64 %t28, 1
  store i64 %t31, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  br label %bb2
bb11:
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t34 = load i64, ptr %l3, !tbaa !24
  %t37 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t33, i64 %t34)
  store i32 %t37, ptr %l23
  br label %bb12
bb12:
  %t38 = load i32, ptr %l23, !range !{i32 0, i32 116}
  %t40 = trunc i64 32 to i32
  %t41 = icmp eq i32 %t38, %t40
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l11 = alloca i1
  %l13 = alloca i1
  %l15 = alloca i32
  %l21 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i32
  %l37 = alloca i1
  %l40 = alloca i1
  %l42 = alloca i32
  %l47 = alloca ptr
  %l48 = alloca i1
  %l59 = alloca i64
  %l63 = alloca %"compiler/source:Span"
  %l67 = alloca { i64, ptr }
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l79 = alloca ptr
  %l80 = alloca i32
  %rv = alloca { i32, ptr }
  %t120 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  store i32 %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t1)
  store i1 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i1, ptr %l11, !tbaa !21
  %t5 = xor i1 %t4, true
  br i1 %t5, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l13, !tbaa !21
  br label %bb5
bb3:
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t7, i64 2)
  store i32 %t9, ptr %l15
  br label %bb4
bb4:
  %t10 = load i32, ptr %l15, !range !{i32 0, i32 116}
  %t12 = trunc i64 112 to i32
  %t13 = icmp eq i32 %t10, %t12
  %t15 = xor i1 %t13, true
  store i1 %t15, ptr %l13, !tbaa !21
  br label %bb5
bb5:
  %t17 = load i1, ptr %l13, !tbaa !21
  br i1 %t17, label %bb6, label %bb7
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t21 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t18, i32 102)
  store i1 %t21, ptr %l21
  br label %bb8
bb7:
  br label %bb31
bb8:
  %t22 = load i1, ptr %l21, !tbaa !21
  %t23 = xor i1 %t22, true
  br i1 %t23, label %bb9, label %bb10
bb9:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 112)
  store i1 %t28, ptr %l26
  br label %bb11
bb10:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb12
bb11:
  %t29 = load i1, ptr %l26, !tbaa !21
  %t30 = xor i1 %t29, true
  store i1 %t30, ptr %l23, !tbaa !21
  br label %bb12
bb12:
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb13, label %bb14
bb13:
  %t33 = load ptr, ptr %l2, !tbaa !29
  %t35 = insertvalue { i32, ptr } zeroinitializer, ptr %t33, 1
  store { i32, ptr } %t35, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t39 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t36, i32 102)
  store i1 %t39, ptr %l31
  br label %bb16
bb16:
  %t40 = load i1, ptr %l31, !tbaa !21
  br i1 %t40, label %bb17, label %bb18
bb17:
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t41, i64 1)
  store i32 %t43, ptr %l33
  br label %bb19
bb18:
  br label %bb30
bb19:
  %t44 = load i32, ptr %l33, !range !{i32 0, i32 116}
  store i32 %t44, ptr %l3
  %t45 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t47 = trunc i64 112 to i32
  %t48 = icmp eq i32 %t45, %t47
  %t50 = xor i1 %t48, true
  br i1 %t50, label %bb20, label %bb21
bb20:
  %t52 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t54 = trunc i64 1 to i32
  %t55 = icmp eq i32 %t52, %t54
  br i1 %t55, label %bb22, label %bb23
bb21:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb26
bb22:
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t57, i64 2)
  store i32 %t59, ptr %l42
  br label %bb24
bb23:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb25
bb24:
  %t60 = load i32, ptr %l42, !range !{i32 0, i32 116}
  %t62 = trunc i64 112 to i32
  %t63 = icmp eq i32 %t60, %t62
  store i1 %t63, ptr %l40, !tbaa !21
  br label %bb25
bb25:
  %t65 = load i1, ptr %l40, !tbaa !21
  %t66 = xor i1 %t65, true
  store i1 %t66, ptr %l37, !tbaa !21
  br label %bb26
bb26:
  %t68 = load i1, ptr %l37, !tbaa !21
  br i1 %t68, label %bb27, label %bb28
bb27:
  %t69 = load ptr, ptr %l2, !tbaa !29
  %t71 = insertvalue { i32, ptr } zeroinitializer, ptr %t69, 1
  store { i32, ptr } %t71, ptr %rv
  br label %ret
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t72 = load ptr, ptr %l2, !tbaa !29
  store ptr %t72, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t73 = load ptr, ptr %l47, !tbaa !29
  %t74 = icmp ne ptr %t73, null
  br i1 %t74, label %bb32, label %bb33
bb32:
  %t76 = load ptr, ptr %l47, !tbaa !29
  %t77 = load i64, ptr %t76, !range !{i64 0, i64 28}
  %t79 = icmp eq i64 %t77, 11
  store i1 %t79, ptr %l48, !tbaa !21
  br label %bb33
bb33:
  %t80 = load i1, ptr %l48, !tbaa !21
  br i1 %t80, label %bb34, label %bb35
bb34:
  %t81 = load ptr, ptr %l2, !tbaa !29
  %t83 = getelementptr { i64, [4 x i64] }, ptr %t81, i32 0, i32 1
  %t84 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t83, i32 0, i32 0
  %t85 = load %"compiler/source:Span", ptr %t84
  store %"compiler/source:Span" %t85, ptr %l4
  %t87 = load ptr, ptr %l2, !tbaa !29
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t87, i32 0, i32 1
  %t90 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t89, i32 0, i32 1
  %t91 = load ptr, ptr %t90
  store ptr %t91, ptr %l5, !tbaa !29
  %t93 = load ptr, ptr %l2, !tbaa !29
  %t95 = getelementptr { i64, [4 x i64] }, ptr %t93, i32 0, i32 1
  %t96 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t95, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  br label %bb36
bb35:
  br label %bb44
bb36:
  %t99 = load ptr, ptr %l0, !tbaa !29
  %t101 = getelementptr %"compiler/parse:Parser", ptr %t99, i32 0, i32 39
  %t103 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t101)
  store i64 %t103, ptr %l59
  br label %bb37
bb37:
  %t104 = load i64, ptr %l59, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  %t105 = load ptr, ptr %l5, !tbaa !29
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 39
  call void @compiler_2fparse_2epathIds(ptr %v1, ptr %v0, ptr %t105, ptr %t108)
  br label %bb38
bb38:
  %t111 = load %"compiler/source:Span", ptr %l4
  store %"compiler/source:Span" %t111, ptr %l63
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/parse:Parser", ptr %t112, i32 0, i32 39
  %t115 = load i64, ptr %l7, !tbaa !24
  %t118 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v2, ptr %t114, i64 %t115)
  store { i64, ptr } %t118, ptr %l67
  br label %bb39
bb39:
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t120
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 0
  store i64 0, ptr %t121
  %t122 = load %"compiler/source:Span", ptr %l63
  %t123 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t122, 0
  %t124 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t125 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t123, { i64, ptr } %t124, 1
  %t127 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t125, { i64, ptr } %t119, 2
  %t128 = getelementptr { i64, [5 x i64] }, ptr %t120, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t127, ptr %t128
  %t129 = load { i64, [5 x i64] }, ptr %t120
  %t131 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 48, i64 8)
  store { i64, [5 x i64] } %t129, ptr %t131
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i32, ptr %l1, !tbaa !23
  %t139 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v2, ptr %v2, ptr %t133, i32 %t134, ptr %t131)
  store ptr %t139, ptr %l74
  br label %bb40
bb40:
  %t140 = load ptr, ptr %l74, !tbaa !29
  %t141 = load ptr, ptr %l0, !tbaa !29
  %t142 = load i32, ptr %l1, !tbaa !23
  %t147 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v2, ptr %v2, ptr %t141, i32 %t142, ptr %t140)
  %t148 = extractvalue { i32, ptr } %t147, 1
  %t149 = extractvalue { i32, ptr } %t147, 0
  store i32 %t149, ptr %l80
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb42, label %ok.151, !prof !99
ok.151:
  store ptr %t148, ptr %l79
  br label %bb41
bb41:
  %t152 = load ptr, ptr %l79, !tbaa !29
  store ptr %t152, ptr %l75, !tbaa !29
  br label %bb43
bb42:
  %t153 = load i32, ptr %l80, !tbaa !23
  %t154 = lshr i32 %t153, 16
  %t155 = and i32 %t153, 65535
  %t156 = icmp eq i32 %t154, 1
  %t157 = select i1 %t156, i32 1, i32 0
  %t158 = icmp eq i32 %t153, 0
  %t159 = shl i32 %t157, 16
  %t160 = or i32 %t159, %t155
  %t161 = select i1 %t158, i32 0, i32 %t160
  %t163 = insertvalue { i32, ptr } zeroinitializer, i32 %t161, 0
  store { i32, ptr } %t163, ptr %rv
  br label %ret
bb43:
  %t164 = load ptr, ptr %l75, !tbaa !29
  %t165 = insertvalue { i32, ptr } zeroinitializer, ptr %t164, 1
  store { i32, ptr } %t165, ptr %rv
  br label %ret
bb44:
  br i1 true, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  %t166 = load ptr, ptr %l2, !tbaa !29
  %t168 = insertvalue { i32, ptr } zeroinitializer, ptr %t166, 1
  store { i32, ptr } %t168, ptr %rv
  br label %ret
bb48:
  call void @__olang_check_failed(ptr @olang_loc_824bfdca782f89b4_8a051d8e1bdc5e78)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local %"compiler/parse:stackMarks" @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarks(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca i64
  %l6 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l15 = alloca i64
  %l18 = alloca i64
  %l21 = alloca i64
  %l22 = alloca %"compiler/parse:stackMarks"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/parse:stackMarks"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 34
  %t5 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 35
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t8)
  store i64 %t10, ptr %l6
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/parse:Parser", ptr %t11, i32 0, i32 36
  %t15 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t13)
  store i64 %t15, ptr %l9
  br label %bb3
bb3:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 37
  %t20 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t18)
  store i64 %t20, ptr %l12
  br label %bb4
bb4:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/parse:Parser", ptr %t21, i32 0, i32 38
  %t25 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t23)
  store i64 %t25, ptr %l15
  br label %bb5
bb5:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/parse:Parser", ptr %t26, i32 0, i32 39
  %t30 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t28)
  store i64 %t30, ptr %l18
  br label %bb6
bb6:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/parse:Parser", ptr %t31, i32 0, i32 40
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t33)
  store i64 %t35, ptr %l21
  br label %bb7
bb7:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t37 = load i64, ptr %l6, !tbaa !24
  %t38 = load i64, ptr %l9, !tbaa !24
  %t39 = load i64, ptr %l12, !tbaa !24
  %t40 = load i64, ptr %l15, !tbaa !24
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = call %"compiler/parse:stackMarks" @compiler_2fparse_3astackMarks_2ector(ptr %s0, i64 %t36, i64 %t37, i64 %t38, i64 %t39, i64 %t40, i64 %t41, i64 %t42)
  store %"compiler/parse:stackMarks" %t43, ptr %l22
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load %"compiler/parse:stackMarks", ptr %l22
  store %"compiler/parse:stackMarks" %t44, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:stackMarks", ptr %rv
  ret %"compiler/parse:stackMarks" %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ematchBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca i32
  %l5 = alloca ptr
  %l6 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca i1
  %l18 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i32
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca i32
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca { { i64, ptr }, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca ptr
  %l38 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l46 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i32
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l56 = alloca %"compiler/token:Token"
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l61 = alloca i64
  %l63 = alloca i64
  %l68 = alloca i32
  %l77 = alloca i1
  %l80 = alloca i1
  %l81 = alloca i1
  %l83 = alloca i32
  %l89 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i32
  %l100 = alloca i64
  %l102 = alloca i64
  %l107 = alloca i32
  %l116 = alloca i64
  %l118 = alloca i64
  %l123 = alloca i32
  %l135 = alloca i1
  %l138 = alloca { i64, ptr }
  %l142 = alloca i1
  %l145 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca i1
  %l169 = alloca i1
  %l172 = alloca i1
  %l175 = alloca { i64, ptr }
  %l179 = alloca ptr
  %l181 = alloca ptr
  %l182 = alloca i32
  %l184 = alloca i32
  %l187 = alloca i32
  %l188 = alloca i32
  %l196 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l201 = alloca i1
  %l202 = alloca i1
  %l205 = alloca i1
  %l207 = alloca i32
  %l208 = alloca i32
  %l211 = alloca i32
  %l212 = alloca i32
  %l216 = alloca i64
  %l219 = alloca i64
  %l222 = alloca ptr
  %l223 = alloca ptr
  %l225 = alloca ptr
  %l226 = alloca i32
  %l228 = alloca ptr
  %l230 = alloca ptr
  %l231 = alloca i32
  %l234 = alloca i1
  %l235 = alloca i1
  %l238 = alloca i1
  %l239 = alloca i1
  %l241 = alloca %"compiler/token:Token"
  %l243 = alloca i1
  %l246 = alloca i32
  %l247 = alloca i32
  %l249 = alloca i32
  %l250 = alloca i32
  %l254 = alloca ptr
  %l256 = alloca ptr
  %l258 = alloca %"compiler/source:Span"
  %l262 = alloca %"compiler/source:Span"
  %l263 = alloca ptr
  %l264 = alloca i32
  %l267 = alloca %"compiler/source:Span"
  %l271 = alloca ptr
  %l274 = alloca ptr
  %l277 = alloca i1
  %l280 = alloca i1
  %l283 = alloca i32
  %l286 = alloca i1
  %l289 = alloca i1
  %l292 = alloca i1
  %l295 = alloca i1
  %l298 = alloca i1
  %l302 = alloca i32
  %l306 = alloca { i64, ptr }
  %l310 = alloca { i64, ptr }
  %l313 = alloca i1
  %l314 = alloca ptr
  %l316 = alloca ptr
  %l317 = alloca i32
  %l320 = alloca { { i64, ptr }, ptr }
  %l323 = alloca { { i64, ptr }, ptr }
  %l324 = alloca i32
  %l328 = alloca ptr
  %l331 = alloca %"compiler/source:Span"
  %l337 = alloca %"compiler/ast:Case"
  %l341 = alloca i1
  %l343 = alloca i32
  %l344 = alloca i32
  %l347 = alloca i32
  %l348 = alloca i32
  %l356 = alloca %"compiler/source:Span"
  %l357 = alloca ptr
  %l358 = alloca i1
  %l360 = alloca { i64, ptr }
  %l361 = alloca %"compiler/ast:Match"
  %rv = alloca { i32, ptr }
  %t542 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t1, i32 31)
  %t5 = extractvalue { i32, i32 } %t4, 1
  %t6 = extractvalue { i32, i32 } %t4, 0
  store i32 %t6, ptr %l42
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  store i32 %t5, ptr %l41
  br label %bb1
bb1:
  %t9 = load i32, ptr %l41, !tbaa !23
  store i32 %t9, ptr %l38, !tbaa !23
  br label %bb3
bb2:
  %t10 = load i32, ptr %l42, !tbaa !23
  %t11 = lshr i32 %t10, 16
  %t12 = and i32 %t10, 65535
  %t13 = icmp eq i32 %t11, 1
  %t14 = select i1 %t13, i32 1, i32 0
  %t15 = icmp eq i32 %t10, 0
  %t16 = shl i32 %t14, 16
  %t17 = or i32 %t16, %t12
  %t18 = select i1 %t15, i32 0, i32 %t17
  %t20 = insertvalue { i32, ptr } zeroinitializer, i32 %t18, 0
  store { i32, ptr } %t20, ptr %rv
  br label %ret
bb3:
  %t21 = load i32, ptr %l38, !tbaa !23
  store i32 %t21, ptr %l2, !tbaa !23
  store i1 false, ptr %l3, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t25 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t22, i32 1)
  store i1 %t25, ptr %l46
  br label %bb4
bb4:
  %t26 = load i1, ptr %l46, !tbaa !21
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t27, i64 1)
  store i32 %t29, ptr %l49
  br label %bb7
bb6:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb8
bb7:
  %t30 = load i32, ptr %l49, !range !{i32 0, i32 116}
  %t32 = trunc i64 114 to i32
  %t33 = icmp eq i32 %t30, %t32
  store i1 %t33, ptr %l47, !tbaa !21
  br label %bb8
bb8:
  %t35 = load i1, ptr %l47, !tbaa !21
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 2
  %t39 = load ptr, ptr %t38, !tbaa !29
  store ptr %t39, ptr %l53, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l54, !tbaa !29
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t41)
  store %"compiler/token:Token" %t43, ptr %l56
  br label %bb11
bb10:
  br label %bb25
bb11:
  %t44 = load ptr, ptr %l54, !tbaa !29
  %t45 = load %"compiler/token:Token", ptr %l56
  %t46 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t44, %"compiler/token:Token" %t45)
  store { i64, ptr } %t46, ptr %l57
  br label %bb12
bb12:
  %t47 = load ptr, ptr %l53, !tbaa !29
  %t48 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t49 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t47, { i64, ptr } %t48)
  store i32 %t49, ptr %l58
  br label %bb13
bb13:
  %t50 = load i32, ptr %l58, !tbaa !23
  store i32 %t50, ptr %l4, !tbaa !23
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 32
  store ptr %t53, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb14
bb14:
  %t55 = load i64, ptr %l6, !tbaa !24
  store i64 %t55, ptr %l61, !tbaa !24
  %t56 = load ptr, ptr %l5, !tbaa !29
  %t58 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t56)
  store i64 %t58, ptr %l63
  br label %bb15
bb15:
  %t59 = load i64, ptr %l61, !tbaa !24
  %t60 = load i64, ptr %l63, !tbaa !24
  %t61 = icmp slt i64 %t59, %t60
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb16, label %bb17
bb16:
  br label %bb24
bb17:
  br label %bb18
bb18:
  %t65 = load ptr, ptr %l5, !tbaa !29
  %t66 = load i64, ptr %l6, !tbaa !24
  %t69 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t65, i64 %t66)
  store i32 %t69, ptr %l68
  br label %bb19
bb19:
  %t70 = load i32, ptr %l68, !tbaa !23
  %t72 = load i32, ptr %l4, !tbaa !23
  %t75 = icmp eq i32 %t70, %t72
  br i1 %t75, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb22
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t80 = add i64 %t77, 1
  store i64 %t80, ptr %l6, !tbaa !24
  br label %bb14
bb24:
  br label %bb25
bb25:
  %t82 = load i1, ptr %l3, !tbaa !21
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb26, label %bb27
bb26:
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t89 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t86, i32 1)
  store i1 %t89, ptr %l80
  br label %bb28
bb27:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb29
bb28:
  %t90 = load i1, ptr %l80, !tbaa !21
  store i1 %t90, ptr %l77, !tbaa !21
  br label %bb29
bb29:
  %t91 = load i1, ptr %l77, !tbaa !21
  br i1 %t91, label %bb30, label %bb31
bb30:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t94 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t92, i64 1)
  store i32 %t94, ptr %l83
  br label %bb32
bb31:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb33
bb32:
  %t95 = load i32, ptr %l83, !range !{i32 0, i32 116}
  %t97 = trunc i64 76 to i32
  %t98 = icmp eq i32 %t95, %t97
  store i1 %t98, ptr %l81, !tbaa !21
  br label %bb33
bb33:
  %t100 = load i1, ptr %l81, !tbaa !21
  br i1 %t100, label %bb34, label %bb35
bb34:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/parse:Parser", ptr %t101, i32 0, i32 6
  %t104 = load i64, ptr %t103, !tbaa !24
  store i64 %t104, ptr %l8, !tbaa !24
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/parse:Parser", ptr %t106, i32 0, i32 2
  %t109 = load ptr, ptr %t108, !tbaa !29
  store ptr %t109, ptr %l89, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t111 = load ptr, ptr %l0, !tbaa !29
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t111, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !29
  %t116 = getelementptr %"compiler/scan:Tokens", ptr %t114, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l93, !tbaa !27
  %t118 = load i64, ptr %l8, !tbaa !24
  %t120 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t121 = load ptr, ptr %t120, !tbaa !27
  %t122 = getelementptr %"compiler/token:Token", ptr %t121, i64 %t118
  %t123 = load %"compiler/token:Token", ptr %t122
  %t126 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t110, %"compiler/token:Token" %t123)
  store { i64, ptr } %t126, ptr %l96
  br label %bb36
bb35:
  br label %bb86
bb36:
  %t127 = load ptr, ptr %l89, !tbaa !29
  %t128 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t129 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v0, ptr %t127, { i64, ptr } %t128)
  store i32 %t129, ptr %l97
  br label %bb37
bb37:
  %t130 = load i32, ptr %l97, !tbaa !23
  store i32 %t130, ptr %l9, !tbaa !23
  store i1 false, ptr %l10, !tbaa !21
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t133 = getelementptr %"compiler/parse:Parser", ptr %t131, i32 0, i32 32
  store ptr %t133, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb38
bb38:
  %t135 = load i64, ptr %l12, !tbaa !24
  store i64 %t135, ptr %l100, !tbaa !24
  %t136 = load ptr, ptr %l11, !tbaa !29
  %t138 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t136)
  store i64 %t138, ptr %l102
  br label %bb39
bb39:
  %t139 = load i64, ptr %l100, !tbaa !24
  %t140 = load i64, ptr %l102, !tbaa !24
  %t141 = icmp slt i64 %t139, %t140
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb40, label %bb41
bb40:
  br label %bb48
bb41:
  br label %bb42
bb42:
  %t145 = load ptr, ptr %l11, !tbaa !29
  %t146 = load i64, ptr %l12, !tbaa !24
  %t149 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t145, i64 %t146)
  store i32 %t149, ptr %l107
  br label %bb43
bb43:
  %t150 = load i32, ptr %l107, !tbaa !23
  %t152 = load i32, ptr %l9, !tbaa !23
  %t155 = icmp eq i32 %t150, %t152
  br i1 %t155, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  br label %bb47
bb47:
  %t157 = load i64, ptr %l12, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l12, !tbaa !24
  br label %bb38
bb48:
  %t162 = load ptr, ptr %l0, !tbaa !29
  %t164 = getelementptr %"compiler/parse:Parser", ptr %t162, i32 0, i32 33
  store ptr %t164, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb49
bb49:
  %t166 = load i64, ptr %l15, !tbaa !24
  store i64 %t166, ptr %l116, !tbaa !24
  %t167 = load ptr, ptr %l14, !tbaa !29
  %t169 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t167)
  store i64 %t169, ptr %l118
  br label %bb50
bb50:
  %t170 = load i64, ptr %l116, !tbaa !24
  %t171 = load i64, ptr %l118, !tbaa !24
  %t172 = icmp slt i64 %t170, %t171
  %t174 = xor i1 %t172, true
  br i1 %t174, label %bb51, label %bb52
bb51:
  br label %bb59
bb52:
  br label %bb53
bb53:
  %t176 = load ptr, ptr %l14, !tbaa !29
  %t177 = load i64, ptr %l15, !tbaa !24
  %t180 = call i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t176, i64 %t177)
  store i32 %t180, ptr %l123
  br label %bb54
bb54:
  %t181 = load i32, ptr %l123, !tbaa !23
  %t183 = load i32, ptr %l9, !tbaa !23
  %t186 = icmp eq i32 %t181, %t183
  br i1 %t186, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l10, !tbaa !21
  br label %bb57
bb56:
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t188 = load i64, ptr %l15, !tbaa !24
  %t191 = add i64 %t188, 1
  store i64 %t191, ptr %l15, !tbaa !24
  br label %bb49
bb59:
  %t193 = load i64, ptr %l8, !tbaa !24
  %t196 = add i64 %t193, 1
  store i64 %t196, ptr %l8, !tbaa !24
  %t198 = load i1, ptr %l10, !tbaa !21
  store i1 %t198, ptr %l17, !tbaa !21
  store i64 0, ptr %l18, !tbaa !24
  br label %bb60
bb60:
  %t200 = load i1, ptr %l17, !tbaa !21
  br i1 %t200, label %bb61, label %bb62
bb61:
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/parse:Parser", ptr %t202, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !29
  %t207 = getelementptr %"compiler/scan:Tokens", ptr %t205, i32 0, i32 0
  %t208 = load { i64, ptr }, ptr %t207, !tbaa !27
  store { i64, ptr } %t208, ptr %l138, !tbaa !27
  %t209 = load i64, ptr %l8, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l138, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr %"compiler/token:Token", ptr %t212, i64 %t209
  %t214 = getelementptr %"compiler/token:Token", ptr %t213, i32 0, i32 0
  %t215 = load i32, ptr %t214, !range !{i32 0, i32 116}
  %t217 = trunc i64 76 to i32
  %t218 = icmp eq i32 %t215, %t217
  store i1 %t218, ptr %l135, !tbaa !21
  br label %bb63
bb62:
  store i1 false, ptr %l135, !tbaa !21
  br label %bb63
bb63:
  %t220 = load i1, ptr %l135, !tbaa !21
  br i1 %t220, label %bb64, label %bb65
bb64:
  %t221 = load ptr, ptr %l0, !tbaa !29
  %t223 = getelementptr %"compiler/parse:Parser", ptr %t221, i32 0, i32 1
  %t224 = load ptr, ptr %t223, !tbaa !29
  %t226 = getelementptr %"compiler/scan:Tokens", ptr %t224, i32 0, i32 0
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  store { i64, ptr } %t227, ptr %l145, !tbaa !27
  %t228 = load i64, ptr %l8, !tbaa !24
  %t230 = add i64 %t228, 1
  %t232 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr %"compiler/token:Token", ptr %t233, i64 %t230
  %t235 = getelementptr %"compiler/token:Token", ptr %t234, i32 0, i32 0
  %t236 = load i32, ptr %t235, !range !{i32 0, i32 116}
  %t238 = trunc i64 1 to i32
  %t239 = icmp eq i32 %t236, %t238
  store i1 %t239, ptr %l142, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l142, !tbaa !21
  br label %bb66
bb66:
  %t241 = load i1, ptr %l142, !tbaa !21
  %t242 = xor i1 %t241, true
  br i1 %t242, label %bb67, label %bb68
bb67:
  br label %bb76
bb68:
  br label %bb69
bb69:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/parse:Parser", ptr %t245, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !29
  %t250 = getelementptr %"compiler/scan:Tokens", ptr %t248, i32 0, i32 0
  %t251 = load { i64, ptr }, ptr %t250, !tbaa !27
  store { i64, ptr } %t251, ptr %l154, !tbaa !27
  %t252 = load i64, ptr %l8, !tbaa !24
  %t254 = add i64 %t252, 1
  %t256 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr %"compiler/token:Token", ptr %t257, i64 %t254
  %t259 = load %"compiler/token:Token", ptr %t258
  %t262 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t244, %"compiler/token:Token" %t259)
  store { i64, ptr } %t262, ptr %l158
  br label %bb70
bb70:
  %t263 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t266 = call i1 @compiler_2fparse_2etypeWord(ptr %v0, { i64, ptr } %t263)
  store i1 %t266, ptr %l160
  br label %bb71
bb71:
  %t267 = load i1, ptr %l160, !tbaa !21
  %t268 = xor i1 %t267, true
  br i1 %t268, label %bb72, label %bb73
bb72:
  store i1 false, ptr %l17, !tbaa !21
  br label %bb74
bb73:
  br label %bb74
bb74:
  %t270 = load i64, ptr %l8, !tbaa !24
  %t273 = add i64 %t270, 2
  store i64 %t273, ptr %l8, !tbaa !24
  %t275 = load i64, ptr %l18, !tbaa !24
  %t278 = add i64 %t275, 1
  store i64 %t278, ptr %l18, !tbaa !24
  br label %bb75
bb75:
  br label %bb60
bb76:
  %t280 = load i1, ptr %l17, !tbaa !21
  br i1 %t280, label %bb77, label %bb78
bb77:
  %t282 = load i64, ptr %l18, !tbaa !24
  %t284 = icmp sgt i64 %t282, 0
  store i1 %t284, ptr %l169, !tbaa !21
  br label %bb79
bb78:
  store i1 false, ptr %l169, !tbaa !21
  br label %bb79
bb79:
  %t286 = load i1, ptr %l169, !tbaa !21
  br i1 %t286, label %bb80, label %bb81
bb80:
  %t287 = load ptr, ptr %l0, !tbaa !29
  %t289 = getelementptr %"compiler/parse:Parser", ptr %t287, i32 0, i32 1
  %t290 = load ptr, ptr %t289, !tbaa !29
  %t292 = getelementptr %"compiler/scan:Tokens", ptr %t290, i32 0, i32 0
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  store { i64, ptr } %t293, ptr %l175, !tbaa !27
  %t294 = load i64, ptr %l8, !tbaa !24
  %t296 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr %"compiler/token:Token", ptr %t297, i64 %t294
  %t299 = getelementptr %"compiler/token:Token", ptr %t298, i32 0, i32 0
  %t300 = load i32, ptr %t299, !range !{i32 0, i32 116}
  %t302 = trunc i64 114 to i32
  %t303 = icmp eq i32 %t300, %t302
  store i1 %t303, ptr %l172, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l172, !tbaa !21
  br label %bb82
bb82:
  %t305 = load i1, ptr %l172, !tbaa !21
  br i1 %t305, label %bb83, label %bb84
bb83:
  store i1 true, ptr %l3, !tbaa !21
  br label %bb85
bb84:
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t308 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t306)
  %t309 = extractvalue { i32, ptr } %t308, 1
  %t310 = extractvalue { i32, ptr } %t308, 0
  store i32 %t310, ptr %l182
  %t311 = icmp ne i32 %t310, 0
  br i1 %t311, label %bb88, label %ok.312, !prof !99
ok.312:
  store ptr %t309, ptr %l181
  br label %bb87
bb87:
  %t313 = load ptr, ptr %l181, !tbaa !29
  store ptr %t313, ptr %l179, !tbaa !29
  br label %bb89
bb88:
  %t314 = load i32, ptr %l182, !tbaa !23
  %t315 = lshr i32 %t314, 16
  %t316 = and i32 %t314, 65535
  %t317 = icmp eq i32 %t315, 1
  %t318 = select i1 %t317, i32 1, i32 0
  %t319 = icmp eq i32 %t314, 0
  %t320 = shl i32 %t318, 16
  %t321 = or i32 %t320, %t316
  %t322 = select i1 %t319, i32 0, i32 %t321
  %t324 = insertvalue { i32, ptr } zeroinitializer, i32 %t322, 0
  store { i32, ptr } %t324, ptr %rv
  br label %ret
bb89:
  %t325 = load ptr, ptr %l179, !tbaa !29
  store ptr %t325, ptr %l20, !tbaa !29
  %t326 = load ptr, ptr %l0, !tbaa !29
  %t329 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t326, i32 114)
  %t330 = extractvalue { i32, i32 } %t329, 1
  %t331 = extractvalue { i32, i32 } %t329, 0
  store i32 %t331, ptr %l188
  %t332 = icmp ne i32 %t331, 0
  br i1 %t332, label %bb91, label %ok.333, !prof !99
ok.333:
  store i32 %t330, ptr %l187
  br label %bb90
bb90:
  %t334 = load i32, ptr %l187, !tbaa !23
  store i32 %t334, ptr %l184, !tbaa !23
  br label %bb92
bb91:
  %t335 = load i32, ptr %l188, !tbaa !23
  %t336 = lshr i32 %t335, 16
  %t337 = and i32 %t335, 65535
  %t338 = icmp eq i32 %t336, 1
  %t339 = select i1 %t338, i32 1, i32 0
  %t340 = icmp eq i32 %t335, 0
  %t341 = shl i32 %t339, 16
  %t342 = or i32 %t341, %t337
  %t343 = select i1 %t340, i32 0, i32 %t342
  %t345 = insertvalue { i32, ptr } zeroinitializer, i32 %t343, 0
  store { i32, ptr } %t345, ptr %rv
  br label %ret
bb92:
  %t346 = load ptr, ptr %l0, !tbaa !29
  %t348 = getelementptr %"compiler/parse:Parser", ptr %t346, i32 0, i32 21
  %t349 = load i64, ptr %t348, !tbaa !24
  store i64 %t349, ptr %l21, !tbaa !24
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t353 = getelementptr %"compiler/parse:Parser", ptr %t351, i32 0, i32 21
  store i64 0, ptr %t353, !tbaa !24
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t354, i32 0, i32 22
  %t357 = load i1, ptr %t356, !tbaa !21
  store i1 %t357, ptr %l22, !tbaa !21
  %t359 = load ptr, ptr %l0, !tbaa !29
  %t361 = getelementptr %"compiler/parse:Parser", ptr %t359, i32 0, i32 22
  store i1 false, ptr %t361, !tbaa !21
  %t362 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t362, ptr %l196
  br label %bb93
bb93:
  %t363 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l196
  %t364 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t363, ptr %t364
  store ptr %t364, ptr %l23, !tbaa !29
  br label %bb94
bb94:
  %t366 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t366)
  br label %bb95
bb95:
  %t368 = load ptr, ptr %l0, !tbaa !29
  %t371 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t368, i32 115)
  store i1 %t371, ptr %l201
  br label %bb96
bb96:
  %t372 = load i1, ptr %l201, !tbaa !21
  br i1 %t372, label %bb97, label %bb98
bb97:
  store i1 true, ptr %l202, !tbaa !21
  br label %bb100
bb98:
  %t373 = load ptr, ptr %l0, !tbaa !29
  %t376 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t373, i32 0)
  store i1 %t376, ptr %l205
  br label %bb99
bb99:
  %t377 = load i1, ptr %l205, !tbaa !21
  store i1 %t377, ptr %l202, !tbaa !21
  br label %bb100
bb100:
  %t378 = load i1, ptr %l202, !tbaa !21
  br i1 %t378, label %bb101, label %bb102
bb101:
  br label %bb196
bb102:
  br label %bb103
bb103:
  %t379 = load ptr, ptr %l0, !tbaa !29
  %t381 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t379)
  store i32 %t381, ptr %l207
  br label %bb104
bb104:
  %t382 = load i32, ptr %l207, !tbaa !23
  store i32 %t382, ptr %l24, !tbaa !23
  %t383 = load ptr, ptr %l0, !tbaa !29
  %t386 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t383, i32 32)
  %t387 = extractvalue { i32, i32 } %t386, 1
  %t388 = extractvalue { i32, i32 } %t386, 0
  store i32 %t388, ptr %l212
  %t389 = icmp ne i32 %t388, 0
  br i1 %t389, label %bb106, label %ok.390, !prof !99
ok.390:
  store i32 %t387, ptr %l211
  br label %bb105
bb105:
  %t391 = load i32, ptr %l211, !tbaa !23
  store i32 %t391, ptr %l208, !tbaa !23
  br label %bb107
bb106:
  %t392 = load i32, ptr %l212, !tbaa !23
  %t393 = lshr i32 %t392, 16
  %t394 = and i32 %t392, 65535
  %t395 = icmp eq i32 %t393, 1
  %t396 = select i1 %t395, i32 1, i32 0
  %t397 = icmp eq i32 %t392, 0
  %t398 = shl i32 %t396, 16
  %t399 = or i32 %t398, %t394
  %t400 = select i1 %t397, i32 0, i32 %t399
  %t402 = insertvalue { i32, ptr } zeroinitializer, i32 %t400, 0
  store { i32, ptr } %t402, ptr %rv
  br label %ret
bb107:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/parse:Parser", ptr %t403, i32 0, i32 38
  %t407 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %t405)
  store i64 %t407, ptr %l216
  br label %bb108
bb108:
  %t408 = load i64, ptr %l216, !tbaa !24
  store i64 %t408, ptr %l25, !tbaa !24
  %t409 = load ptr, ptr %l0, !tbaa !29
  %t411 = getelementptr %"compiler/parse:Parser", ptr %t409, i32 0, i32 36
  %t413 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t411)
  store i64 %t413, ptr %l219
  br label %bb109
bb109:
  %t414 = load i64, ptr %l219, !tbaa !24
  store i64 %t414, ptr %l26, !tbaa !24
  br label %bb110
bb110:
  %t415 = load i1, ptr %l3, !tbaa !21
  br i1 %t415, label %bb111, label %bb112
bb111:
  %t417 = load ptr, ptr %l0, !tbaa !29
  %t419 = getelementptr %"compiler/parse:Parser", ptr %t417, i32 0, i32 36
  store ptr %t419, ptr %l222, !tbaa !29
  %t420 = load ptr, ptr %l0, !tbaa !29
  %t422 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseType(ptr %v0, ptr %v0, ptr %t420)
  %t423 = extractvalue { i32, ptr } %t422, 1
  %t424 = extractvalue { i32, ptr } %t422, 0
  store i32 %t424, ptr %l226
  %t425 = icmp ne i32 %t424, 0
  br i1 %t425, label %bb114, label %ok.426, !prof !99
ok.426:
  store ptr %t423, ptr %l225
  br label %bb113
bb112:
  %t427 = load ptr, ptr %l0, !tbaa !29
  %t429 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v0, ptr %t427, i64 1)
  %t430 = extractvalue { i32, ptr } %t429, 1
  %t431 = extractvalue { i32, ptr } %t429, 0
  store i32 %t431, ptr %l231
  %t432 = icmp ne i32 %t431, 0
  br i1 %t432, label %bb118, label %ok.433, !prof !99
ok.433:
  store ptr %t430, ptr %l230
  br label %bb117
bb113:
  %t434 = load ptr, ptr %l225, !tbaa !29
  store ptr %t434, ptr %l223, !tbaa !29
  br label %bb115
bb114:
  %t435 = load i32, ptr %l226, !tbaa !23
  %t436 = lshr i32 %t435, 16
  %t437 = and i32 %t435, 65535
  %t438 = icmp eq i32 %t436, 1
  %t439 = select i1 %t438, i32 1, i32 0
  %t440 = icmp eq i32 %t435, 0
  %t441 = shl i32 %t439, 16
  %t442 = or i32 %t441, %t437
  %t443 = select i1 %t440, i32 0, i32 %t442
  %t445 = insertvalue { i32, ptr } zeroinitializer, i32 %t443, 0
  store { i32, ptr } %t445, ptr %rv
  br label %ret
bb115:
  %t446 = load ptr, ptr %l222, !tbaa !29
  %t447 = load ptr, ptr %l223, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t446, ptr %t447)
  br label %bb116
bb116:
  br label %bb144
bb117:
  %t448 = load ptr, ptr %l230, !tbaa !29
  store ptr %t448, ptr %l228, !tbaa !29
  br label %bb119
bb118:
  %t449 = load i32, ptr %l231, !tbaa !23
  %t450 = lshr i32 %t449, 16
  %t451 = and i32 %t449, 65535
  %t452 = icmp eq i32 %t450, 1
  %t453 = select i1 %t452, i32 1, i32 0
  %t454 = icmp eq i32 %t449, 0
  %t455 = shl i32 %t453, 16
  %t456 = or i32 %t455, %t451
  %t457 = select i1 %t454, i32 0, i32 %t456
  %t459 = insertvalue { i32, ptr } zeroinitializer, i32 %t457, 0
  store { i32, ptr } %t459, ptr %rv
  br label %ret
bb119:
  %t460 = load ptr, ptr %l228, !tbaa !29
  store ptr %t460, ptr %l27, !tbaa !29
  %t461 = load ptr, ptr %l27, !tbaa !29
  %t463 = call i1 @compiler_2fparse_2eisTypeCasePath(ptr %v0, ptr %t461)
  store i1 %t463, ptr %l234
  br label %bb120
bb120:
  %t464 = load i1, ptr %l234, !tbaa !21
  br i1 %t464, label %bb121, label %bb122
bb121:
  %t465 = load ptr, ptr %l0, !tbaa !29
  %t468 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t465, i32 1)
  store i1 %t468, ptr %l238
  br label %bb123
bb122:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb124
bb123:
  %t469 = load i1, ptr %l238, !tbaa !21
  store i1 %t469, ptr %l235, !tbaa !21
  br label %bb124
bb124:
  %t470 = load i1, ptr %l235, !tbaa !21
  br i1 %t470, label %bb125, label %bb126
bb125:
  %t471 = load ptr, ptr %l0, !tbaa !29
  %t473 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t471)
  store %"compiler/token:Token" %t473, ptr %l241
  br label %bb127
bb126:
  store i1 false, ptr %l239, !tbaa !21
  br label %bb129
bb127:
  %t474 = load i8, ptr @G_2ecompiler_2ftoken_2eLineBreak, !tbaa !22
  %t475 = load %"compiler/token:Token", ptr %l241
  %t477 = call i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %t475, i8 %t474)
  store i1 %t477, ptr %l243
  br label %bb128
bb128:
  %t478 = load i1, ptr %l243, !tbaa !21
  %t479 = xor i1 %t478, true
  store i1 %t479, ptr %l239, !tbaa !21
  br label %bb129
bb129:
  %t481 = load i1, ptr %l239, !tbaa !21
  br i1 %t481, label %bb130, label %bb131
bb130:
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t484 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t482)
  store i32 %t484, ptr %l246
  br label %bb132
bb131:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/parse:Parser", ptr %t485, i32 0, i32 38
  store ptr %t487, ptr %l271, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l27, !tbaa !29
  %t492 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v0, ptr %v0, ptr %t488, ptr %t489, i1 true)
  store ptr %t492, ptr %l274
  br label %bb141
bb132:
  %t493 = load i32, ptr %l246, !tbaa !23
  store i32 %t493, ptr %l28, !tbaa !23
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t496 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t494)
  %t497 = extractvalue { i32, i32 } %t496, 1
  %t498 = extractvalue { i32, i32 } %t496, 0
  store i32 %t498, ptr %l250
  %t499 = icmp ne i32 %t498, 0
  br i1 %t499, label %bb134, label %ok.500, !prof !99
ok.500:
  store i32 %t497, ptr %l249
  br label %bb133
bb133:
  %t501 = load i32, ptr %l249, !tbaa !23
  store i32 %t501, ptr %l247, !tbaa !23
  br label %bb135
bb134:
  %t502 = load i32, ptr %l250, !tbaa !23
  %t503 = lshr i32 %t502, 16
  %t504 = and i32 %t502, 65535
  %t505 = icmp eq i32 %t503, 1
  %t506 = select i1 %t505, i32 1, i32 0
  %t507 = icmp eq i32 %t502, 0
  %t508 = shl i32 %t506, 16
  %t509 = or i32 %t508, %t504
  %t510 = select i1 %t507, i32 0, i32 %t509
  %t512 = insertvalue { i32, ptr } zeroinitializer, i32 %t510, 0
  store { i32, ptr } %t512, ptr %rv
  br label %ret
bb135:
  %t513 = load i32, ptr %l247, !tbaa !23
  store i32 %t513, ptr %l29, !tbaa !23
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t515 = load ptr, ptr %l27, !tbaa !29
  %t518 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseTypeRef(ptr %v0, ptr %v0, ptr %v0, ptr %t514, ptr %t515)
  store ptr %t518, ptr %l254
  br label %bb136
bb136:
  %t519 = load ptr, ptr %l254, !tbaa !29
  store ptr %t519, ptr %l30, !tbaa !29
  %t520 = load ptr, ptr %l0, !tbaa !29
  %t522 = getelementptr %"compiler/parse:Parser", ptr %t520, i32 0, i32 38
  store ptr %t522, ptr %l256, !tbaa !29
  %t523 = load ptr, ptr %l27, !tbaa !29
  %t525 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %t523)
  store %"compiler/source:Span" %t525, ptr %l258
  br label %bb137
bb137:
  %t526 = getelementptr %"compiler/source:Span", ptr %l258, i32 0, i32 0
  %t527 = load i32, ptr %t526, !tbaa !23
  %t528 = load ptr, ptr %l0, !tbaa !29
  %t530 = getelementptr %"compiler/parse:Parser", ptr %t528, i32 0, i32 10
  %t531 = load i32, ptr %t530, !tbaa !23
  %t534 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %t527, i32 %t531)
  store %"compiler/source:Span" %t534, ptr %l262
  br label %bb138
bb138:
  %t535 = load ptr, ptr %l30, !tbaa !29
  store ptr %t535, ptr %l263, !tbaa !29
  %t536 = load i32, ptr %l29, !tbaa !23
  store i32 %t536, ptr %l264, !tbaa !23
  %t537 = load ptr, ptr %l0, !tbaa !29
  %t538 = load i32, ptr %l28, !tbaa !23
  %t541 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t537, i32 %t538)
  store %"compiler/source:Span" %t541, ptr %l267
  br label %bb139
bb139:
  store { i64, [4 x i64] } zeroinitializer, ptr %t542
  %t543 = getelementptr { i64, [4 x i64] }, ptr %t542, i32 0, i32 0
  store i64 5, ptr %t543
  %t544 = load %"compiler/source:Span", ptr %l262
  %t545 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } undef, %"compiler/source:Span" %t544, 0
  %t546 = load ptr, ptr %l263, !tbaa !29
  %t547 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t545, ptr %t546, 1
  %t548 = load i32, ptr %l264, !tbaa !23
  %t549 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t547, i32 %t548, 2
  %t550 = load %"compiler/source:Span", ptr %l267
  %t551 = insertvalue { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t549, %"compiler/source:Span" %t550, 3
  %t552 = getelementptr { i64, [4 x i64] }, ptr %t542, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32, %"compiler/source:Span" } %t551, ptr %t552
  %t553 = load { i64, [4 x i64] }, ptr %t542
  %t555 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t553, ptr %t555
  %t556 = load ptr, ptr %l256, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t556, ptr %t555)
  br label %bb140
bb140:
  br label %bb143
bb141:
  %t558 = load ptr, ptr %l271, !tbaa !29
  %t559 = load ptr, ptr %l274, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v0, ptr %t558, ptr %t559)
  br label %bb142
bb142:
  br label %bb143
bb143:
  br label %bb144
bb144:
  %t560 = load ptr, ptr %l0, !tbaa !29
  %t563 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t560, i32 75)
  store i1 %t563, ptr %l277
  br label %bb145
bb145:
  %t564 = load i1, ptr %l277, !tbaa !21
  br i1 %t564, label %bb146, label %bb147
bb146:
  br label %bb173
bb147:
  br label %bb148
bb148:
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t568 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t565, i32 8)
  store i1 %t568, ptr %l280
  br label %bb149
bb149:
  %t569 = load i1, ptr %l280, !tbaa !21
  %t570 = xor i1 %t569, true
  br i1 %t570, label %bb150, label %bb151
bb150:
  br label %bb174
bb151:
  br label %bb152
bb152:
  %t572 = load ptr, ptr %l0, !tbaa !29
  %t574 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t572, i64 1)
  store i32 %t574, ptr %l283
  br label %bb153
bb153:
  %t575 = load i32, ptr %l283, !range !{i32 0, i32 116}
  store i32 %t575, ptr %l31
  %t576 = load i32, ptr %l31, !range !{i32 0, i32 116}
  %t578 = trunc i64 114 to i32
  %t579 = icmp eq i32 %t576, %t578
  br i1 %t579, label %bb154, label %bb155
bb154:
  store i1 true, ptr %l286, !tbaa !21
  br label %bb156
bb155:
  %t581 = load i32, ptr %l31, !range !{i32 0, i32 116}
  %t583 = trunc i64 79 to i32
  %t584 = icmp eq i32 %t581, %t583
  store i1 %t584, ptr %l286, !tbaa !21
  br label %bb156
bb156:
  %t586 = load i1, ptr %l286, !tbaa !21
  br i1 %t586, label %bb157, label %bb158
bb157:
  store i1 true, ptr %l289, !tbaa !21
  br label %bb159
bb158:
  %t587 = load i32, ptr %l31, !range !{i32 0, i32 116}
  %t589 = trunc i64 9 to i32
  %t590 = icmp eq i32 %t587, %t589
  store i1 %t590, ptr %l289, !tbaa !21
  br label %bb159
bb159:
  %t592 = load i1, ptr %l289, !tbaa !21
  br i1 %t592, label %bb160, label %bb161
bb160:
  store i1 true, ptr %l292, !tbaa !21
  br label %bb162
bb161:
  %t593 = load i32, ptr %l31, !range !{i32 0, i32 116}
  %t595 = trunc i64 115 to i32
  %t596 = icmp eq i32 %t593, %t595
  store i1 %t596, ptr %l292, !tbaa !21
  br label %bb162
bb162:
  %t598 = load i1, ptr %l292, !tbaa !21
  br i1 %t598, label %bb163, label %bb164
bb163:
  store i1 true, ptr %l295, !tbaa !21
  br label %bb165
bb164:
  %t599 = load i32, ptr %l31, !range !{i32 0, i32 116}
  %t601 = trunc i64 32 to i32
  %t602 = icmp eq i32 %t599, %t601
  store i1 %t602, ptr %l295, !tbaa !21
  br label %bb165
bb165:
  %t604 = load i1, ptr %l295, !tbaa !21
  br i1 %t604, label %bb166, label %bb167
bb166:
  store i1 true, ptr %l298, !tbaa !21
  br label %bb168
bb167:
  %t605 = load i32, ptr %l31, !range !{i32 0, i32 116}
  %t607 = trunc i64 0 to i32
  %t608 = icmp eq i32 %t605, %t607
  store i1 %t608, ptr %l298, !tbaa !21
  br label %bb168
bb168:
  %t610 = load i1, ptr %l298, !tbaa !21
  br i1 %t610, label %bb169, label %bb170
bb169:
  br label %bb174
bb170:
  br label %bb171
bb171:
  %t611 = load ptr, ptr %l0, !tbaa !29
  %t613 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t611)
  store i32 %t613, ptr %l302
  br label %bb172
bb172:
  br label %bb173
bb173:
  br label %bb110
bb174:
  %t614 = load ptr, ptr %l0, !tbaa !29
  %t616 = getelementptr %"compiler/parse:Parser", ptr %t614, i32 0, i32 38
  %t617 = load i64, ptr %l25, !tbaa !24
  %t620 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %t616, i64 %t617)
  store { i64, ptr } %t620, ptr %l306
  br label %bb175
bb175:
  %t621 = load { i64, ptr }, ptr %l306, !tbaa !27
  store { i64, ptr } %t621, ptr %l32, !tbaa !27
  %t622 = load ptr, ptr %l0, !tbaa !29
  %t624 = getelementptr %"compiler/parse:Parser", ptr %t622, i32 0, i32 36
  %t625 = load i64, ptr %l26, !tbaa !24
  %t628 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %t624, i64 %t625)
  store { i64, ptr } %t628, ptr %l310
  br label %bb176
bb176:
  %t629 = load { i64, ptr }, ptr %l310, !tbaa !27
  store { i64, ptr } %t629, ptr %l33, !tbaa !27
  store ptr null, ptr %l34, !tbaa !29
  %t630 = load ptr, ptr %l0, !tbaa !29
  %t633 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t630, i32 9)
  store i1 %t633, ptr %l313
  br label %bb177
bb177:
  %t634 = load i1, ptr %l313, !tbaa !21
  br i1 %t634, label %bb178, label %bb179
bb178:
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t637 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t635)
  %t638 = extractvalue { i32, ptr } %t637, 1
  %t639 = extractvalue { i32, ptr } %t637, 0
  store i32 %t639, ptr %l317
  %t640 = icmp ne i32 %t639, 0
  br i1 %t640, label %bb181, label %ok.641, !prof !99
ok.641:
  store ptr %t638, ptr %l316
  br label %bb180
bb179:
  br label %bb183
bb180:
  %t642 = load ptr, ptr %l316, !tbaa !29
  store ptr %t642, ptr %l314, !tbaa !29
  br label %bb182
bb181:
  %t643 = load i32, ptr %l317, !tbaa !23
  %t644 = lshr i32 %t643, 16
  %t645 = and i32 %t643, 65535
  %t646 = icmp eq i32 %t644, 1
  %t647 = select i1 %t646, i32 1, i32 0
  %t648 = icmp eq i32 %t643, 0
  %t649 = shl i32 %t647, 16
  %t650 = or i32 %t649, %t645
  %t651 = select i1 %t648, i32 0, i32 %t650
  %t653 = insertvalue { i32, ptr } zeroinitializer, i32 %t651, 0
  store { i32, ptr } %t653, ptr %rv
  br label %ret
bb182:
  %t654 = load ptr, ptr %l314, !tbaa !29
  store ptr %t654, ptr %l34, !tbaa !29
  br label %bb183
bb183:
  %t656 = load ptr, ptr %l0, !tbaa !29
  %t660 = call { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %v1, ptr %t656, i1 %a1)
  %t661 = extractvalue { i32, { { i64, ptr }, ptr } } %t660, 1
  %t662 = extractvalue { i32, { { i64, ptr }, ptr } } %t660, 0
  store i32 %t662, ptr %l324
  %t663 = icmp ne i32 %t662, 0
  br i1 %t663, label %bb185, label %ok.664, !prof !99
ok.664:
  store { { i64, ptr }, ptr } %t661, ptr %l323
  br label %bb184
bb184:
  %t665 = load { { i64, ptr }, ptr }, ptr %l323
  store { { i64, ptr }, ptr } %t665, ptr %l320
  br label %bb186
bb185:
  %t666 = load i32, ptr %l324, !tbaa !23
  %t667 = lshr i32 %t666, 16
  %t668 = and i32 %t666, 65535
  %t669 = icmp eq i32 %t667, 1
  %t670 = select i1 %t669, i32 1, i32 0
  %t671 = icmp eq i32 %t666, 0
  %t672 = shl i32 %t670, 16
  %t673 = or i32 %t672, %t668
  %t674 = select i1 %t671, i32 0, i32 %t673
  %t676 = insertvalue { i32, ptr } zeroinitializer, i32 %t674, 0
  store { i32, ptr } %t676, ptr %rv
  br label %ret
bb186:
  %t677 = load { { i64, ptr }, ptr }, ptr %l320
  store { { i64, ptr }, ptr } %t677, ptr %l35
  %t678 = getelementptr { { i64, ptr }, ptr }, ptr %l35, i32 0, i32 0
  %t679 = load { i64, ptr }, ptr %t678, !tbaa !27
  store { i64, ptr } %t679, ptr %l36, !tbaa !27
  %t681 = getelementptr { { i64, ptr }, ptr }, ptr %l35, i32 0, i32 1
  %t682 = load ptr, ptr %t681, !tbaa !29
  store ptr %t682, ptr %l37, !tbaa !29
  %t684 = load ptr, ptr %l23, !tbaa !29
  store ptr %t684, ptr %l328, !tbaa !29
  %t685 = load ptr, ptr %l0, !tbaa !29
  %t686 = load i32, ptr %l24, !tbaa !23
  %t689 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t685, i32 %t686)
  store %"compiler/source:Span" %t689, ptr %l331
  br label %bb187
bb187:
  %t690 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t691 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t692 = load ptr, ptr %l34, !tbaa !29
  %t693 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t694 = load ptr, ptr %l37, !tbaa !29
  %t695 = load %"compiler/source:Span", ptr %l331
  %t701 = call %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t695, { i64, ptr } %t690, { i64, ptr } %t691, ptr %t692, { i64, ptr } %t693, ptr %t694)
  store %"compiler/ast:Case" %t701, ptr %l337
  br label %bb188
bb188:
  %t702 = load %"compiler/ast:Case", ptr %l337
  %t703 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 72, i64 8)
  store %"compiler/ast:Case" %t702, ptr %t703
  %t704 = load ptr, ptr %l328, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v1, ptr %v1, ptr %t704, ptr %t703)
  br label %bb189
bb189:
  %t706 = load ptr, ptr %l0, !tbaa !29
  %t709 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t706, i32 8)
  store i1 %t709, ptr %l341
  br label %bb190
bb190:
  %t710 = load i1, ptr %l341, !tbaa !21
  br i1 %t710, label %bb191, label %bb192
bb191:
  %t711 = load ptr, ptr %l0, !tbaa !29
  %t713 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t711)
  store i32 %t713, ptr %l343
  br label %bb193
bb192:
  br label %bb194
bb193:
  br label %bb194
bb194:
  br label %bb195
bb195:
  br label %bb94
bb196:
  %t714 = load ptr, ptr %l0, !tbaa !29
  %t717 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t714, i32 115)
  %t718 = extractvalue { i32, i32 } %t717, 1
  %t719 = extractvalue { i32, i32 } %t717, 0
  store i32 %t719, ptr %l348
  %t720 = icmp ne i32 %t719, 0
  br i1 %t720, label %bb198, label %ok.721, !prof !99
ok.721:
  store i32 %t718, ptr %l347
  br label %bb197
bb197:
  %t722 = load i32, ptr %l347, !tbaa !23
  store i32 %t722, ptr %l344, !tbaa !23
  br label %bb199
bb198:
  %t723 = load i32, ptr %l348, !tbaa !23
  %t724 = lshr i32 %t723, 16
  %t725 = and i32 %t723, 65535
  %t726 = icmp eq i32 %t724, 1
  %t727 = select i1 %t726, i32 1, i32 0
  %t728 = icmp eq i32 %t723, 0
  %t729 = shl i32 %t727, 16
  %t730 = or i32 %t729, %t725
  %t731 = select i1 %t728, i32 0, i32 %t730
  %t733 = insertvalue { i32, ptr } zeroinitializer, i32 %t731, 0
  store { i32, ptr } %t733, ptr %rv
  br label %ret
bb199:
  %t734 = load ptr, ptr %l0, !tbaa !29
  %t735 = load i64, ptr %l21, !tbaa !24
  %t738 = getelementptr %"compiler/parse:Parser", ptr %t734, i32 0, i32 21
  store i64 %t735, ptr %t738, !tbaa !24
  %t739 = load ptr, ptr %l0, !tbaa !29
  %t740 = load i1, ptr %l22, !tbaa !21
  %t743 = getelementptr %"compiler/parse:Parser", ptr %t739, i32 0, i32 22
  store i1 %t740, ptr %t743, !tbaa !21
  %t744 = load ptr, ptr %l0, !tbaa !29
  %t745 = load i32, ptr %l2, !tbaa !23
  %t748 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t744, i32 %t745)
  store %"compiler/source:Span" %t748, ptr %l356
  br label %bb200
bb200:
  %t749 = load ptr, ptr %l20, !tbaa !29
  store ptr %t749, ptr %l357, !tbaa !29
  %t750 = load i1, ptr %l3, !tbaa !21
  store i1 %t750, ptr %l358, !tbaa !21
  %t751 = load ptr, ptr %l23, !tbaa !29
  %t753 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v1, ptr %v1, ptr %t751)
  store { i64, ptr } %t753, ptr %l360
  br label %bb201
bb201:
  %t754 = load %"compiler/source:Span", ptr %l356
  %t755 = load ptr, ptr %l357, !tbaa !29
  %t756 = load i1, ptr %l358, !tbaa !21
  %t757 = load { i64, ptr }, ptr %l360, !tbaa !27
  %t758 = call %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t754, ptr %t755, i1 %t756, { i64, ptr } %t757)
  store %"compiler/ast:Match" %t758, ptr %l361
  br label %bb202
bb202:
  %t759 = load %"compiler/ast:Match", ptr %l361
  %t760 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store %"compiler/ast:Match" %t759, ptr %t760
  %t762 = insertvalue { i32, ptr } zeroinitializer, ptr %t760, 1
  store { i32, ptr } %t762, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l4 = alloca %"compiler/token:Token"
  %l18 = alloca i32
  %l24 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i1
  %l32 = alloca i32
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t1, i64 1)
  store %"compiler/token:Token" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l4
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 0
  %t6 = load i32, ptr %t5, !range !{i32 0, i32 116}
  %t8 = trunc i64 1 to i32
  %t9 = icmp eq i32 %t6, %t8
  %t11 = xor i1 %t9, true
  br i1 %t11, label %bb2, label %bb3
bb2:
  store i1 false, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/parse:Parser", ptr %t14, i32 0, i32 0
  %t17 = load ptr, ptr %t16, !tbaa !29
  %t19 = getelementptr %"compiler/source:Source", ptr %t17, i32 0, i32 1
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  %t21 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t22 = load i32, ptr %t21, !tbaa !23
  %t24 = sext i32 %t22 to i64
  %t25 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t26 = load i32, ptr %t25, !tbaa !23
  %t27 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t28 = load i32, ptr %t27, !tbaa !23
  %t31 = sub i32 %t26, %t28
  %t33 = sext i32 %t31 to i64
  %t37 = call i32 @compiler_2ftoken_2eTok_2eKeyword(ptr %v0, { i64, ptr } %t20, i64 %t24, i64 %t33)
  store i32 %t37, ptr %l18
  br label %bb5
bb5:
  %t38 = load i32, ptr %l18, !range !{i32 0, i32 116}
  store i32 %t38, ptr %l2
  %t39 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t41 = trunc i64 1 to i32
  %t42 = icmp eq i32 %t39, %t41
  br i1 %t42, label %bb6, label %bb7
bb6:
  store i1 true, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t45 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t47 = trunc i64 6 to i32
  %t48 = icmp eq i32 %t45, %t47
  br i1 %t48, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb11
bb10:
  %t50 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t52 = trunc i64 7 to i32
  %t53 = icmp eq i32 %t50, %t52
  store i1 %t53, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  %t55 = load i1, ptr %l24, !tbaa !21
  br i1 %t55, label %bb12, label %bb13
bb12:
  store i1 false, ptr %rv
  br label %ret
bb13:
  br label %bb14
bb14:
  %t57 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t59 = call i1 @compiler_2fparse_2ekeywordNamesField(i32 %t57)
  store i1 %t59, ptr %l29
  br label %bb15
bb15:
  %t60 = load i1, ptr %l29, !tbaa !21
  br i1 %t60, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb19
bb17:
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t61, i64 2)
  store i32 %t63, ptr %l32
  br label %bb18
bb18:
  %t64 = load i32, ptr %l32, !range !{i32 0, i32 116}
  %t66 = trunc i64 110 to i32
  %t67 = icmp eq i32 %t64, %t66
  store i1 %t67, ptr %l30, !tbaa !21
  br label %bb19
bb19:
  %t69 = load i1, ptr %l30, !tbaa !21
  store i1 %t69, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamed(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i32
  %l5 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %l1, !tbaa !24
  %t5 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %t1, i64 %t2)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !range !{i32 0, i32 116}
  store i32 %t6, ptr %l2
  %t7 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t9 = trunc i64 8 to i32
  %t10 = icmp eq i32 %t7, %t9
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfLine, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  store i64 %t14, ptr %l9, !tbaa !24
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = mul i64 %t15, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t16)
  %t18 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l10, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = load i64, ptr %l9, !tbaa !24
  %t25 = mul i64 %t24, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t21, ptr %t23, i64 %t25, i1 false)
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %l8, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t27, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t28 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t30 = trunc i64 0 to i32
  %t31 = icmp eq i32 %t28, %t30
  br i1 %t31, label %bb5, label %bb6
bb5:
  %t33 = load { i64, ptr }, ptr @G_2ecompiler_2fmsgs_2eEndOfFile, !tbaa !27
  store { i64, ptr } %t33, ptr %l13, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  store i64 %t35, ptr %l14, !tbaa !24
  %t36 = load i64, ptr %l14, !tbaa !24
  %t37 = mul i64 %t36, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t37)
  %t39 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l15, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t42 = load ptr, ptr %t41, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = load i64, ptr %l14, !tbaa !24
  %t46 = mul i64 %t45, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t42, ptr %t44, i64 %t46, i1 false)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %l13, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/parse:Parser", ptr %t50, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !29
  %t55 = getelementptr %"compiler/scan:Tokens", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  %t57 = load i64, ptr %l1, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr %"compiler/token:Token", ptr %t60, i64 %t57
  %t62 = load %"compiler/token:Token", ptr %t61
  %t65 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v0, ptr %t49, %"compiler/token:Token" %t62)
  store { i64, ptr } %t65, ptr %l22
  br label %bb8
bb8:
  %t66 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t67 = call { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %t66)
  store { i64, ptr } %t67, ptr %l23
  br label %bb9
bb9:
  %t68 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t68, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2enamesOf(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca %"compiler/source:Span"
  %l10 = alloca i32
  %l12 = alloca i64
  %l17 = alloca i64
  %l18 = alloca %"compiler/source:Span"
  %l20 = alloca %"compiler/source:Span"
  %l32 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca i1
  %l43 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l53 = alloca i32
  %l60 = alloca %"compiler/parse:NameList"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t34 = alloca i64
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l12, !tbaa !24
  %t4 = load i64, ptr %l12, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l12, !tbaa !24
  %t8 = icmp sle i64 %t7, 2305843009213693951
  br i1 %t8, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb3:
  %t10 = load i64, ptr %l12, !tbaa !24
  %t11 = mul i64 %t10, 4
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l2, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  store i64 %t18, ptr %l17, !tbaa !24
  store %"compiler/source:Span" zeroinitializer, ptr %l18
  %t19 = load i64, ptr %l17, !tbaa !24
  %t20 = icmp sgt i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_97d42995c5706fd7_20b731538cf045b)
  unreachable
bb5:
  %t22 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 0, i32 0)
  store %"compiler/source:Span" %t22, ptr %l20
  br label %bb7
bb6:
  %t23 = load i64, ptr %l17, !tbaa !24
  %t24 = icmp sge i64 %t23, 0
  br i1 %t24, label %bb8, label %bb9
bb7:
  %t26 = load %"compiler/source:Span", ptr %l20
  store %"compiler/source:Span" %t26, ptr %l18
  br label %bb6
bb8:
  %t27 = load i64, ptr %l17, !tbaa !24
  %t28 = icmp sle i64 %t27, 1152921504606846975
  br i1 %t28, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb10:
  %t30 = load i64, ptr %l17, !tbaa !24
  %t31 = mul i64 %t30, 8
  %t32 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t31)
  %t33 = load %"compiler/source:Span", ptr %l18
  store i64 0, ptr %t34
  br label %fill.35
fill.35:
  %t38 = load i64, ptr %t34
  %t39 = icmp slt i64 %t38, %t30
  br i1 %t39, label %fillb.36, label %filld.37
fillb.36:
  %t40 = getelementptr %"compiler/source:Span", ptr %t32, i64 %t38
  store %"compiler/source:Span" %t33, ptr %t40
  %t41 = add i64 %t38, 1
  store i64 %t41, ptr %t34
  br label %fill.35
filld.37:
  %t42 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t32, 1
  store { i64, ptr } %t43, ptr %l3, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t47, 0
  store i64 %t49, ptr %l6, !tbaa !24
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_787ae3c3318fe322_f2232752b79280c6)
  unreachable
bb12:
  %t51 = load i64, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  %t55 = icmp slt i64 %t51, %t52
  %t57 = xor i1 %t55, true
  br i1 %t57, label %bb13, label %bb14
bb13:
  br label %bb32
bb14:
  br label %bb15
bb15:
  %t59 = load i64, ptr %l5, !tbaa !24
  store i64 %t59, ptr %l7, !tbaa !24
  %t61 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t61, ptr %l32, !tbaa !27
  %t62 = load i64, ptr %l5, !tbaa !24
  %t64 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = getelementptr ptr, ptr %t65, i64 %t62
  %t67 = load ptr, ptr %t66, !tbaa !39
  store ptr %t67, ptr %l8, !tbaa !29
  %t69 = load ptr, ptr %l8, !tbaa !29
  store ptr %t69, ptr %l35, !tbaa !29
  store i1 false, ptr %l36, !tbaa !21
  %t70 = load ptr, ptr %l35, !tbaa !29
  %t71 = icmp ne ptr %t70, null
  br i1 %t71, label %bb16, label %bb17
bb16:
  %t73 = load ptr, ptr %l35, !tbaa !29
  %t74 = load i64, ptr %t73, !range !{i64 0, i64 28}
  %t76 = icmp eq i64 %t74, 0
  store i1 %t76, ptr %l36, !tbaa !21
  br label %bb17
bb17:
  %t77 = load i1, ptr %l36, !tbaa !21
  br i1 %t77, label %bb18, label %bb19
bb18:
  %t78 = load ptr, ptr %l8, !tbaa !29
  %t80 = getelementptr { i64, [4 x i64] }, ptr %t78, i32 0, i32 1
  %t81 = getelementptr { %"compiler/source:Span", i32 }, ptr %t80, i32 0, i32 0
  %t82 = load %"compiler/source:Span", ptr %t81
  store %"compiler/source:Span" %t82, ptr %l9
  %t84 = load ptr, ptr %l8, !tbaa !29
  %t86 = getelementptr { i64, [4 x i64] }, ptr %t84, i32 0, i32 1
  %t87 = getelementptr { %"compiler/source:Span", i32 }, ptr %t86, i32 0, i32 1
  %t88 = load i32, ptr %t87
  store i32 %t88, ptr %l10, !tbaa !23
  br label %bb20
bb19:
  br label %bb21
bb20:
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t90, ptr %l43, !tbaa !27
  %t91 = load i64, ptr %l7, !tbaa !24
  %t92 = load i32, ptr %l10, !tbaa !23
  %t95 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr i32, ptr %t96, i64 %t91
  store i32 %t92, ptr %t97, !tbaa !33
  %t98 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t98, ptr %l46, !tbaa !27
  %t99 = load i64, ptr %l7, !tbaa !24
  %t100 = load %"compiler/source:Span", ptr %l9
  %t103 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = getelementptr %"compiler/source:Span", ptr %t104, i64 %t99
  store %"compiler/source:Span" %t100, ptr %t105
  br label %bb30
bb21:
  br i1 true, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  br label %bb29
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  store ptr %a0, ptr %l49, !tbaa !29
  %t108 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s4, i32 78)
  store { i64, ptr } %t108, ptr %l51
  br label %bb25
bb25:
  %t109 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t110 = load ptr, ptr %l49, !tbaa !29
  %t112 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s4, ptr %t110, { i64, ptr } %t109)
  store i32 %t112, ptr %l53
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb27, label %ok.114, !prof !99
ok.114:
  br label %bb26
bb26:
  br label %bb28
bb27:
  %t115 = load i32, ptr %l53, !tbaa !23
  %t116 = lshr i32 %t115, 16
  %t117 = and i32 %t115, 65535
  %t118 = icmp eq i32 %t116, 1
  %t119 = select i1 %t118, i32 1, i32 0
  %t120 = icmp eq i32 %t115, 0
  %t121 = shl i32 %t119, 16
  %t122 = or i32 %t121, %t117
  %t123 = select i1 %t120, i32 0, i32 %t122
  call void @__olang_scope_close(ptr %s4)
  %t125 = insertvalue { i32, ptr } zeroinitializer, i32 %t123, 0
  store { i32, ptr } %t125, ptr %rv
  br label %ret
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb30
bb29:
  call void @__olang_check_failed(ptr @olang_loc_afe07cd3f11f5e9a_d335478c7d935166)
  unreachable
bb30:
  br label %bb31
bb31:
  %t126 = load i64, ptr %l5, !tbaa !24
  %t129 = add i64 %t126, 1
  store i64 %t129, ptr %l5, !tbaa !24
  br label %bb12
bb32:
  %t131 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t135 = call %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v2, ptr %v2, ptr %v2, { i64, ptr } %t131, { i64, ptr } %t132)
  store %"compiler/parse:NameList" %t135, ptr %l60
  br label %bb33
bb33:
  %t136 = load %"compiler/parse:NameList", ptr %l60
  %t137 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store %"compiler/parse:NameList" %t136, ptr %t137
  %t139 = insertvalue { i32, ptr } zeroinitializer, ptr %t137, 1
  store { i32, ptr } %t139, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparam(ptr %v0, ptr %v1, ptr %a0, i1 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l22 = alloca i1
  %l24 = alloca i32
  %l28 = alloca i64
  %l31 = alloca i64
  %l50 = alloca i32
  %l54 = alloca ptr
  %l56 = alloca ptr
  %l57 = alloca i32
  %l61 = alloca %"compiler/source:Span"
  %l66 = alloca i1
  %l69 = alloca i1
  %l70 = alloca i1
  %l73 = alloca i1
  %l74 = alloca i1
  %l77 = alloca i1
  %l79 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i32
  %l87 = alloca i1
  %l88 = alloca ptr
  %l90 = alloca ptr
  %l91 = alloca i32
  %l96 = alloca %"compiler/source:Span"
  %l100 = alloca %"compiler/ast:Param"
  %rv = alloca { i32, ptr }
  %t115 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l15
  br label %bb1
bb1:
  %t4 = load i32, ptr %l15, !tbaa !23
  store i32 %t4, ptr %l2, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t5)
  %t8 = extractvalue { i32, i32 } %t7, 1
  %t9 = extractvalue { i32, i32 } %t7, 0
  store i32 %t9, ptr %l19
  %t10 = icmp ne i32 %t9, 0
  br i1 %t10, label %bb3, label %ok.11, !prof !99
ok.11:
  store i32 %t8, ptr %l18
  br label %bb2
bb2:
  %t12 = load i32, ptr %l18, !tbaa !23
  store i32 %t12, ptr %l16, !tbaa !23
  br label %bb4
bb3:
  %t13 = load i32, ptr %l19, !tbaa !23
  %t14 = lshr i32 %t13, 16
  %t15 = and i32 %t13, 65535
  %t16 = icmp eq i32 %t14, 1
  %t17 = select i1 %t16, i32 1, i32 0
  %t18 = icmp eq i32 %t13, 0
  %t19 = shl i32 %t17, 16
  %t20 = or i32 %t19, %t15
  %t21 = select i1 %t18, i32 0, i32 %t20
  %t23 = insertvalue { i32, ptr } zeroinitializer, i32 %t21, 0
  store { i32, ptr } %t23, ptr %rv
  br label %ret
bb4:
  %t24 = load i32, ptr %l16, !tbaa !23
  store i32 %t24, ptr %l3, !tbaa !23
  store ptr null, ptr %l4, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %t25)
  store i1 %t27, ptr %l22
  br label %bb5
bb5:
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb6, label %bb7
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t29)
  store i32 %t31, ptr %l24
  br label %bb8
bb7:
  br i1 %a1, label %bb26, label %bb27
bb8:
  %t34 = load i32, ptr %l24, !tbaa !23
  store i32 %t34, ptr %l5, !tbaa !23
  store i64 0, ptr %l6, !tbaa !24
  store i64 3, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t35 = load i64, ptr %l7, !tbaa !24
  %t36 = load i64, ptr %l6, !tbaa !24
  %t39 = icmp sgt i64 %t35, %t36
  br i1 %t39, label %bb9, label %bb10
bb9:
  %t41 = load i64, ptr %l8, !tbaa !24
  %t43 = icmp sgt i64 %t41, 0
  br i1 %t43, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb14
bb11:
  %t45 = load i64, ptr %l7, !tbaa !24
  %t46 = load i64, ptr %l6, !tbaa !24
  %t49 = sub i64 %t45, %t46
  %t50 = load i64, ptr %l8, !tbaa !24
  %t53 = add i64 %t49, %t50
  %t55 = sub i64 %t53, 1
  %t56 = load i64, ptr %l8, !tbaa !24
  %t59 = sdiv i64 %t55, %t56
  store i64 %t59, ptr %l31, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb13
bb13:
  %t61 = load i64, ptr %l31, !tbaa !24
  store i64 %t61, ptr %l28, !tbaa !24
  br label %bb14
bb14:
  %t62 = load i64, ptr %l28, !tbaa !24
  store i64 %t62, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb15
bb15:
  %t63 = load i64, ptr %l10, !tbaa !24
  %t64 = load i64, ptr %l9, !tbaa !24
  %t67 = icmp slt i64 %t63, %t64
  %t69 = xor i1 %t67, true
  br i1 %t69, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t71 = load i64, ptr %l6, !tbaa !24
  %t72 = load i64, ptr %l10, !tbaa !24
  %t73 = load i64, ptr %l8, !tbaa !24
  %t76 = mul i64 %t72, %t73
  %t79 = add i64 %t71, %t76
  store i64 %t79, ptr %l11, !tbaa !24
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t81)
  store i32 %t83, ptr %l50
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t84 = load i64, ptr %l10, !tbaa !24
  %t87 = add i64 %t84, 1
  store i64 %t87, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t89)
  %t92 = extractvalue { i32, ptr } %t91, 1
  %t93 = extractvalue { i32, ptr } %t91, 0
  store i32 %t93, ptr %l57
  %t94 = icmp ne i32 %t93, 0
  br i1 %t94, label %bb23, label %ok.95, !prof !99
ok.95:
  store ptr %t92, ptr %l56
  br label %bb22
bb22:
  %t96 = load ptr, ptr %l56, !tbaa !29
  store ptr %t96, ptr %l54, !tbaa !29
  br label %bb24
bb23:
  %t97 = load i32, ptr %l57, !tbaa !23
  %t98 = lshr i32 %t97, 16
  %t99 = and i32 %t97, 65535
  %t100 = icmp eq i32 %t98, 1
  %t101 = select i1 %t100, i32 1, i32 0
  %t102 = icmp eq i32 %t97, 0
  %t103 = shl i32 %t101, 16
  %t104 = or i32 %t103, %t99
  %t105 = select i1 %t102, i32 0, i32 %t104
  %t107 = insertvalue { i32, ptr } zeroinitializer, i32 %t105, 0
  store { i32, ptr } %t107, ptr %rv
  br label %ret
bb24:
  %t108 = load ptr, ptr %l54, !tbaa !29
  store ptr %t108, ptr %l12, !tbaa !29
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i32, ptr %l5, !tbaa !23
  %t113 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t109, i32 %t110)
  store %"compiler/source:Span" %t113, ptr %l61
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l12, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t115
  %t116 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 0
  store i64 7, ptr %t116
  %t117 = load %"compiler/source:Span", ptr %l61
  %t118 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t117, 0
  %t120 = insertvalue { %"compiler/source:Span", ptr } %t118, ptr %t114, 1
  %t121 = getelementptr { i64, [5 x i64] }, ptr %t115, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t120, ptr %t121
  %t122 = load { i64, [5 x i64] }, ptr %t115
  %t124 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t122, ptr %t124
  store ptr %t124, ptr %l4, !tbaa !29
  br label %bb44
bb26:
  %t126 = load ptr, ptr %l0, !tbaa !29
  %t129 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t126, i32 75)
  store i1 %t129, ptr %l69
  br label %bb28
bb27:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb37
bb28:
  %t130 = load i1, ptr %l69, !tbaa !21
  br i1 %t130, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb32
bb30:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t131, i32 111)
  store i1 %t134, ptr %l73
  br label %bb31
bb31:
  %t135 = load i1, ptr %l73, !tbaa !21
  store i1 %t135, ptr %l70, !tbaa !21
  br label %bb32
bb32:
  %t136 = load i1, ptr %l70, !tbaa !21
  br i1 %t136, label %bb33, label %bb34
bb33:
  store i1 true, ptr %l74, !tbaa !21
  br label %bb36
bb34:
  %t137 = load ptr, ptr %l0, !tbaa !29
  %t140 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t137, i32 8)
  store i1 %t140, ptr %l77
  br label %bb35
bb35:
  %t141 = load i1, ptr %l77, !tbaa !21
  store i1 %t141, ptr %l74, !tbaa !21
  br label %bb36
bb36:
  %t142 = load i1, ptr %l74, !tbaa !21
  store i1 %t142, ptr %l66, !tbaa !21
  br label %bb37
bb37:
  %t143 = load i1, ptr %l66, !tbaa !21
  %t144 = xor i1 %t143, true
  br i1 %t144, label %bb38, label %bb39
bb38:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t146)
  %t149 = extractvalue { i32, ptr } %t148, 1
  %t150 = extractvalue { i32, ptr } %t148, 0
  store i32 %t150, ptr %l82
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb41, label %ok.152, !prof !99
ok.152:
  store ptr %t149, ptr %l81
  br label %bb40
bb39:
  br label %bb43
bb40:
  %t153 = load ptr, ptr %l81, !tbaa !29
  store ptr %t153, ptr %l79, !tbaa !29
  br label %bb42
bb41:
  %t154 = load i32, ptr %l82, !tbaa !23
  %t155 = lshr i32 %t154, 16
  %t156 = and i32 %t154, 65535
  %t157 = icmp eq i32 %t155, 1
  %t158 = select i1 %t157, i32 1, i32 0
  %t159 = icmp eq i32 %t154, 0
  %t160 = shl i32 %t158, 16
  %t161 = or i32 %t160, %t156
  %t162 = select i1 %t159, i32 0, i32 %t161
  %t164 = insertvalue { i32, ptr } zeroinitializer, i32 %t162, 0
  store { i32, ptr } %t164, ptr %rv
  br label %ret
bb42:
  %t165 = load ptr, ptr %l79, !tbaa !29
  store ptr %t165, ptr %l4, !tbaa !29
  br label %bb43
bb43:
  br label %bb44
bb44:
  store ptr null, ptr %l13, !tbaa !29
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t170 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t167, i32 78)
  store i1 %t170, ptr %l87
  br label %bb45
bb45:
  %t171 = load i1, ptr %l87, !tbaa !21
  br i1 %t171, label %bb46, label %bb47
bb46:
  %t172 = load ptr, ptr %l0, !tbaa !29
  %t174 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t172)
  %t175 = extractvalue { i32, ptr } %t174, 1
  %t176 = extractvalue { i32, ptr } %t174, 0
  store i32 %t176, ptr %l91
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb49, label %ok.178, !prof !99
ok.178:
  store ptr %t175, ptr %l90
  br label %bb48
bb47:
  br label %bb51
bb48:
  %t179 = load ptr, ptr %l90, !tbaa !29
  store ptr %t179, ptr %l88, !tbaa !29
  br label %bb50
bb49:
  %t180 = load i32, ptr %l91, !tbaa !23
  %t181 = lshr i32 %t180, 16
  %t182 = and i32 %t180, 65535
  %t183 = icmp eq i32 %t181, 1
  %t184 = select i1 %t183, i32 1, i32 0
  %t185 = icmp eq i32 %t180, 0
  %t186 = shl i32 %t184, 16
  %t187 = or i32 %t186, %t182
  %t188 = select i1 %t185, i32 0, i32 %t187
  %t190 = insertvalue { i32, ptr } zeroinitializer, i32 %t188, 0
  store { i32, ptr } %t190, ptr %rv
  br label %ret
bb50:
  %t191 = load ptr, ptr %l88, !tbaa !29
  store ptr %t191, ptr %l13, !tbaa !29
  br label %bb51
bb51:
  %t193 = load ptr, ptr %l0, !tbaa !29
  %t194 = load i32, ptr %l2, !tbaa !23
  %t197 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t193, i32 %t194)
  store %"compiler/source:Span" %t197, ptr %l96
  br label %bb52
bb52:
  %t198 = load i32, ptr %l3, !tbaa !23
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t200 = load ptr, ptr %l13, !tbaa !29
  %t201 = load %"compiler/source:Span", ptr %l96
  %t205 = call %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v1, ptr %v1, ptr %v1, %"compiler/source:Span" %t201, i32 %t198, ptr %t199, ptr %t200)
  store %"compiler/ast:Param" %t205, ptr %l100
  br label %bb53
bb53:
  %t206 = load %"compiler/ast:Param", ptr %l100
  %t207 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:Param" %t206, ptr %t207
  %t209 = insertvalue { i32, ptr } zeroinitializer, ptr %t207, 1
  store { i32, ptr } %t209, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfixFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca ptr
  %l15 = alloca %"compiler/source:Span"
  %l18 = alloca i32
  %l21 = alloca ptr
  %l23 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i32
  %l31 = alloca i1
  %l35 = alloca i32
  %l36 = alloca i32
  %l38 = alloca i32
  %l39 = alloca i32
  %l43 = alloca %"compiler/source:Span"
  %l50 = alloca i1
  %l51 = alloca i1
  %l54 = alloca i1
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i32
  %l62 = alloca %"compiler/source:Span"
  %l67 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i32
  %l76 = alloca i1
  %l77 = alloca i1
  %l79 = alloca i1
  %l80 = alloca i1
  %l83 = alloca ptr
  %l85 = alloca ptr
  %l87 = alloca %"compiler/source:Span"
  %l88 = alloca { i64, ptr }
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i32
  %l97 = alloca %"compiler/source:Span"
  %l103 = alloca i1
  %l104 = alloca i1
  %l106 = alloca i1
  %l108 = alloca i1
  %l109 = alloca ptr
  %l111 = alloca i32
  %l113 = alloca %"compiler/token:Token"
  %l114 = alloca i32
  %l118 = alloca { i64, ptr }
  %l119 = alloca %"compiler/diagmsg:Msg"
  %l120 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i32
  %l127 = alloca %"compiler/source:Span"
  %l134 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l137 = alloca i32
  %l141 = alloca %"compiler/source:Span"
  %l153 = alloca i32
  %l155 = alloca i32
  %l158 = alloca %"compiler/source:Span"
  %l166 = alloca i32
  %l167 = alloca ptr
  %l169 = alloca ptr
  %l170 = alloca i32
  %l174 = alloca %"compiler/source:Span"
  %l186 = alloca ptr
  %l188 = alloca i1
  %l190 = alloca i1
  %l192 = alloca i32
  %l197 = alloca ptr
  %l199 = alloca ptr
  %l201 = alloca ptr
  %l202 = alloca i32
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca i32
  %l210 = alloca ptr
  %l211 = alloca ptr
  %l212 = alloca i32
  %rv = alloca { i32, ptr }
  %t90 = alloca { i64, [4 x i64] }, align 8
  %t146 = alloca { i64, [4 x i64] }, align 8
  %t240 = alloca { i64, [4 x i64] }, align 8
  %t313 = alloca { i64, [4 x i64] }, align 8
  %t358 = alloca { i64, [4 x i64] }, align 8
  %t400 = alloca { i64, [4 x i64] }, align 8
  %t448 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t3)
  store %"compiler/source:Span" %t5, ptr %l15
  br label %bb1
bb1:
  %t6 = getelementptr %"compiler/source:Span", ptr %l15, i32 0, i32 0
  %t7 = load i32, ptr %t6, !tbaa !23
  store i32 %t7, ptr %l3, !tbaa !23
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l18
  br label %bb3
bb3:
  %t12 = load i32, ptr %l18, !range !{i32 0, i32 116}
  store i32 %t12, ptr %l4
  %t13 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t15 = trunc i64 112 to i32
  %t16 = icmp eq i32 %t13, %t15
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  br label %bb10
bb6:
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t19 = load ptr, ptr %l2, !tbaa !29
  store ptr %t19, ptr %l23, !tbaa !29
  %t20 = load ptr, ptr %l23, !tbaa !29
  %t21 = call ptr @__olang_scope_of(ptr %t20, ptr null)
  %t22 = call ptr @__olang_scope_hold(ptr %t21)
  %t23 = ptrtoint ptr %t22 to i64
  %t25 = inttoptr i64 %t23 to ptr
  %t27 = load ptr, ptr %l23, !tbaa !29
  %t28 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %t25, ptr %v2, ptr %t18, ptr %t27)
  %t29 = extractvalue { i32, ptr } %t28, 1
  %t30 = extractvalue { i32, ptr } %t28, 0
  store i32 %t30, ptr %l26
  %t31 = icmp ne i32 %t30, 0
  br i1 %t31, label %bb8, label %ok.32, !prof !99
ok.32:
  store ptr %t29, ptr %l25
  br label %bb7
bb7:
  %t33 = load ptr, ptr %l25, !tbaa !29
  store ptr %t33, ptr %l21, !tbaa !29
  br label %bb9
bb8:
  %t34 = load i32, ptr %l26, !tbaa !23
  %t35 = lshr i32 %t34, 16
  %t36 = and i32 %t34, 65535
  %t37 = icmp eq i32 %t35, 1
  %t38 = select i1 %t37, i32 1, i32 0
  %t39 = icmp eq i32 %t34, 0
  %t40 = shl i32 %t38, 16
  %t41 = or i32 %t40, %t36
  %t42 = select i1 %t39, i32 0, i32 %t41
  %t44 = insertvalue { i32, ptr } zeroinitializer, i32 %t42, 0
  store { i32, ptr } %t44, ptr %rv
  br label %ret
bb9:
  %t45 = load ptr, ptr %l21, !tbaa !29
  store ptr %t45, ptr %l2, !tbaa !29
  br label %bb132
bb10:
  %t46 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t48 = trunc i64 76 to i32
  %t49 = icmp eq i32 %t46, %t48
  br i1 %t49, label %bb11, label %bb12
bb11:
  br label %bb13
bb12:
  br label %bb77
bb13:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ememberNext(ptr %v0, ptr %t51)
  store i1 %t53, ptr %l31
  br label %bb14
bb14:
  %t54 = load i1, ptr %l31, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb15, label %bb16
bb15:
  %t57 = load ptr, ptr %l2, !tbaa !29
  %t59 = insertvalue { i32, ptr } zeroinitializer, ptr %t57, 1
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t60)
  store i32 %t62, ptr %l35
  br label %bb18
bb18:
  %t63 = load ptr, ptr %l0, !tbaa !29
  %t65 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %t63)
  %t66 = extractvalue { i32, i32 } %t65, 1
  %t67 = extractvalue { i32, i32 } %t65, 0
  store i32 %t67, ptr %l39
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb20, label %ok.69, !prof !99
ok.69:
  store i32 %t66, ptr %l38
  br label %bb19
bb19:
  %t70 = load i32, ptr %l38, !tbaa !23
  store i32 %t70, ptr %l36, !tbaa !23
  br label %bb21
bb20:
  %t71 = load i32, ptr %l39, !tbaa !23
  %t72 = lshr i32 %t71, 16
  %t73 = and i32 %t71, 65535
  %t74 = icmp eq i32 %t72, 1
  %t75 = select i1 %t74, i32 1, i32 0
  %t76 = icmp eq i32 %t71, 0
  %t77 = shl i32 %t75, 16
  %t78 = or i32 %t77, %t73
  %t79 = select i1 %t76, i32 0, i32 %t78
  %t81 = insertvalue { i32, ptr } zeroinitializer, i32 %t79, 0
  store { i32, ptr } %t81, ptr %rv
  br label %ret
bb21:
  %t82 = load i32, ptr %l36, !tbaa !23
  store i32 %t82, ptr %l5, !tbaa !23
  %t83 = load ptr, ptr %l0, !tbaa !29
  %t84 = load i32, ptr %l3, !tbaa !23
  %t87 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t83, i32 %t84)
  store %"compiler/source:Span" %t87, ptr %l43
  br label %bb22
bb22:
  %t88 = load ptr, ptr %l2, !tbaa !29
  %t89 = load i32, ptr %l5, !tbaa !23
  store { i64, [4 x i64] } zeroinitializer, ptr %t90
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 0
  store i64 12, ptr %t91
  %t92 = load %"compiler/source:Span", ptr %l43
  %t93 = insertvalue { %"compiler/source:Span", ptr, i32 } undef, %"compiler/source:Span" %t92, 0
  %t95 = insertvalue { %"compiler/source:Span", ptr, i32 } %t93, ptr %t88, 1
  %t97 = insertvalue { %"compiler/source:Span", ptr, i32 } %t95, i32 %t89, 2
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t90, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i32 } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t90
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  store ptr %t101, ptr %l2, !tbaa !29
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t106 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t103, i32 98)
  store i1 %t106, ptr %l50
  br label %bb23
bb23:
  %t107 = load i1, ptr %l50, !tbaa !21
  br i1 %t107, label %bb24, label %bb25
bb24:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load ptr, ptr %l2, !tbaa !29
  %t112 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v2, ptr %t108, ptr %t109)
  store i1 %t112, ptr %l54
  br label %bb26
bb25:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb27
bb26:
  %t113 = load i1, ptr %l54, !tbaa !21
  store i1 %t113, ptr %l51, !tbaa !21
  br label %bb27
bb27:
  %t114 = load i1, ptr %l51, !tbaa !21
  br i1 %t114, label %bb28, label %bb29
bb28:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t117 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v2, ptr %t115)
  %t118 = extractvalue { i32, { i64, ptr } } %t117, 1
  %t119 = extractvalue { i32, { i64, ptr } } %t117, 0
  store i32 %t119, ptr %l58
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb31, label %ok.121, !prof !99
ok.121:
  store { i64, ptr } %t118, ptr %l57
  br label %bb30
bb29:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t125 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t122, i32 98)
  store i1 %t125, ptr %l76
  br label %bb37
bb30:
  %t126 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t126, ptr %l55, !tbaa !27
  br label %bb32
bb31:
  %t127 = load i32, ptr %l58, !tbaa !23
  %t128 = lshr i32 %t127, 16
  %t129 = and i32 %t127, 65535
  %t130 = icmp eq i32 %t128, 1
  %t131 = select i1 %t130, i32 1, i32 0
  %t132 = icmp eq i32 %t127, 0
  %t133 = shl i32 %t131, 16
  %t134 = or i32 %t133, %t129
  %t135 = select i1 %t132, i32 0, i32 %t134
  %t137 = insertvalue { i32, ptr } zeroinitializer, i32 %t135, 0
  store { i32, ptr } %t137, ptr %rv
  br label %ret
bb32:
  %t138 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t138, ptr %l6, !tbaa !27
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i32, ptr %l3, !tbaa !23
  %t143 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t139, i32 %t140)
  store %"compiler/source:Span" %t143, ptr %l62
  br label %bb33
bb33:
  %t144 = load ptr, ptr %l2, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t146
  %t147 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 0
  store i64 11, ptr %t147
  %t148 = load %"compiler/source:Span", ptr %l62
  %t149 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t148, 0
  %t151 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t149, ptr %t144, 1
  %t153 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t151, { i64, ptr } %t145, 2
  %t154 = getelementptr { i64, [4 x i64] }, ptr %t146, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t153, ptr %t154
  %t155 = load { i64, [4 x i64] }, ptr %t146
  %t157 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t155, ptr %t157
  store ptr %t157, ptr %l2, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t160 = load i32, ptr %l3, !tbaa !23
  %t161 = load ptr, ptr %l2, !tbaa !29
  %t165 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eliteralAfterType(ptr %v0, ptr %v2, ptr %v2, ptr %t159, i32 %t160, ptr %t161)
  %t166 = extractvalue { i32, ptr } %t165, 1
  %t167 = extractvalue { i32, ptr } %t165, 0
  store i32 %t167, ptr %l72
  %t168 = icmp ne i32 %t167, 0
  br i1 %t168, label %bb35, label %ok.169, !prof !99
ok.169:
  store ptr %t166, ptr %l71
  br label %bb34
bb34:
  %t170 = load ptr, ptr %l71, !tbaa !29
  store ptr %t170, ptr %l67, !tbaa !29
  br label %bb36
bb35:
  %t171 = load i32, ptr %l72, !tbaa !23
  %t172 = lshr i32 %t171, 16
  %t173 = and i32 %t171, 65535
  %t174 = icmp eq i32 %t172, 1
  %t175 = select i1 %t174, i32 1, i32 0
  %t176 = icmp eq i32 %t171, 0
  %t177 = shl i32 %t175, 16
  %t178 = or i32 %t177, %t173
  %t179 = select i1 %t176, i32 0, i32 %t178
  %t181 = insertvalue { i32, ptr } zeroinitializer, i32 %t179, 0
  store { i32, ptr } %t181, ptr %rv
  br label %ret
bb36:
  %t182 = load ptr, ptr %l67, !tbaa !29
  store ptr %t182, ptr %l2, !tbaa !29
  br label %bb76
bb37:
  %t183 = load i1, ptr %l76, !tbaa !21
  br i1 %t183, label %bb38, label %bb39
bb38:
  %t184 = load ptr, ptr %l2, !tbaa !29
  %t186 = call i1 @compiler_2fparse_2eisPath(ptr %v2, ptr %t184)
  store i1 %t186, ptr %l79
  br label %bb40
bb39:
  store i1 false, ptr %l77, !tbaa !21
  br label %bb41
bb40:
  %t187 = load i1, ptr %l79, !tbaa !21
  store i1 %t187, ptr %l77, !tbaa !21
  br label %bb41
bb41:
  %t188 = load i1, ptr %l77, !tbaa !21
  br i1 %t188, label %bb42, label %bb43
bb42:
  %t189 = load ptr, ptr %l0, !tbaa !29
  %t191 = getelementptr %"compiler/parse:Parser", ptr %t189, i32 0, i32 3
  %t192 = load ptr, ptr %t191, !tbaa !29
  %t194 = getelementptr %"compiler/parse:Oracle", ptr %t192, i32 0, i32 3
  store ptr %t194, ptr %l83, !tbaa !29
  %t195 = load ptr, ptr %l0, !tbaa !29
  %t197 = getelementptr %"compiler/parse:Parser", ptr %t195, i32 0, i32 0
  %t198 = load ptr, ptr %t197, !tbaa !29
  store ptr %t198, ptr %l85, !tbaa !29
  %t199 = load ptr, ptr %l2, !tbaa !29
  %t201 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v2, ptr %t199)
  store %"compiler/source:Span" %t201, ptr %l87
  br label %bb44
bb43:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb47
bb44:
  %t202 = load ptr, ptr %l85, !tbaa !29
  %t203 = load %"compiler/source:Span", ptr %l87
  %t204 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v0, ptr %t202, %"compiler/source:Span" %t203)
  store { i64, ptr } %t204, ptr %l88
  br label %bb45
bb45:
  %t205 = load ptr, ptr %l83, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t207 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v0, ptr %t205, { i64, ptr } %t206)
  store i1 %t207, ptr %l89
  br label %bb46
bb46:
  %t208 = load i1, ptr %l89, !tbaa !21
  store i1 %t208, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t209 = load i1, ptr %l80, !tbaa !21
  br i1 %t209, label %bb48, label %bb49
bb48:
  %t210 = load ptr, ptr %l0, !tbaa !29
  %t212 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v2, ptr %t210)
  %t213 = extractvalue { i32, { i64, ptr } } %t212, 1
  %t214 = extractvalue { i32, { i64, ptr } } %t212, 0
  store i32 %t214, ptr %l93
  %t215 = icmp ne i32 %t214, 0
  br i1 %t215, label %bb51, label %ok.216, !prof !99
ok.216:
  store { i64, ptr } %t213, ptr %l92
  br label %bb50
bb49:
  %t217 = load ptr, ptr %l0, !tbaa !29
  %t219 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %t217, i64 0)
  store i1 %t219, ptr %l103
  br label %bb54
bb50:
  %t220 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t220, ptr %l90, !tbaa !27
  br label %bb52
bb51:
  %t221 = load i32, ptr %l93, !tbaa !23
  %t222 = lshr i32 %t221, 16
  %t223 = and i32 %t221, 65535
  %t224 = icmp eq i32 %t222, 1
  %t225 = select i1 %t224, i32 1, i32 0
  %t226 = icmp eq i32 %t221, 0
  %t227 = shl i32 %t225, 16
  %t228 = or i32 %t227, %t223
  %t229 = select i1 %t226, i32 0, i32 %t228
  %t231 = insertvalue { i32, ptr } zeroinitializer, i32 %t229, 0
  store { i32, ptr } %t231, ptr %rv
  br label %ret
bb52:
  %t232 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t232, ptr %l7, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l3, !tbaa !23
  %t237 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t233, i32 %t234)
  store %"compiler/source:Span" %t237, ptr %l97
  br label %bb53
bb53:
  %t238 = load ptr, ptr %l2, !tbaa !29
  %t239 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t240
  %t241 = getelementptr { i64, [4 x i64] }, ptr %t240, i32 0, i32 0
  store i64 11, ptr %t241
  %t242 = load %"compiler/source:Span", ptr %l97
  %t243 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t242, 0
  %t245 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t243, ptr %t238, 1
  %t247 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t245, { i64, ptr } %t239, 2
  %t248 = getelementptr { i64, [4 x i64] }, ptr %t240, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t247, ptr %t248
  %t249 = load { i64, [4 x i64] }, ptr %t240
  %t251 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t249, ptr %t251
  store ptr %t251, ptr %l2, !tbaa !29
  br label %bb75
bb54:
  %t253 = load i1, ptr %l103, !tbaa !21
  br i1 %t253, label %bb55, label %bb56
bb55:
  store i1 true, ptr %l104, !tbaa !21
  br label %bb58
bb56:
  %t254 = load ptr, ptr %l0, !tbaa !29
  %t256 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t254, i64 0)
  store i1 %t256, ptr %l106
  br label %bb57
bb57:
  %t257 = load i1, ptr %l106, !tbaa !21
  store i1 %t257, ptr %l104, !tbaa !21
  br label %bb58
bb58:
  %t258 = load i1, ptr %l104, !tbaa !21
  br i1 %t258, label %bb59, label %bb60
bb59:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %t259, i64 0)
  store i1 %t261, ptr %l108
  br label %bb61
bb60:
  br label %bb74
bb61:
  %t262 = load i1, ptr %l108, !tbaa !21
  br i1 %t262, label %bb62, label %bb63
bb62:
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l109, !tbaa !29
  %t264 = load ptr, ptr %l0, !tbaa !29
  %t266 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t264)
  store i32 %t266, ptr %l111
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %t267, i64 0)
  store %"compiler/token:Token" %t269, ptr %l113
  br label %bb65
bb65:
  %t270 = getelementptr %"compiler/token:Token", ptr %l113, i32 0, i32 3
  %t271 = load i32, ptr %t270, !tbaa !23
  store i32 %t271, ptr %l114, !tbaa !23
  %t272 = load ptr, ptr %l0, !tbaa !29
  %t274 = getelementptr %"compiler/parse:Parser", ptr %t272, i32 0, i32 2
  %t275 = load ptr, ptr %t274, !tbaa !29
  %t276 = load i32, ptr %l5, !tbaa !23
  %t279 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t275, i32 %t276)
  store { i64, ptr } %t279, ptr %l118
  br label %bb66
bb66:
  %t280 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t281 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v0, { i64, ptr } %t280)
  store %"compiler/diagmsg:Msg" %t281, ptr %l119
  br label %bb67
bb67:
  %t282 = load ptr, ptr %l109, !tbaa !29
  %t283 = load i32, ptr %l111, !tbaa !23
  %t284 = load i32, ptr %l114, !tbaa !23
  %t285 = load %"compiler/diagmsg:Msg", ptr %l119
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t282, i32 %t283, i32 %t284, %"compiler/diagmsg:Msg" %t285)
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v2, ptr %t286)
  %t289 = extractvalue { i32, { i64, ptr } } %t288, 1
  %t290 = extractvalue { i32, { i64, ptr } } %t288, 0
  store i32 %t290, ptr %l123
  %t291 = icmp ne i32 %t290, 0
  br i1 %t291, label %bb71, label %ok.292, !prof !99
ok.292:
  store { i64, ptr } %t289, ptr %l122
  br label %bb70
bb70:
  %t293 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t293, ptr %l120, !tbaa !27
  br label %bb72
bb71:
  %t294 = load i32, ptr %l123, !tbaa !23
  %t295 = lshr i32 %t294, 16
  %t296 = and i32 %t294, 65535
  %t297 = icmp eq i32 %t295, 1
  %t298 = select i1 %t297, i32 1, i32 0
  %t299 = icmp eq i32 %t294, 0
  %t300 = shl i32 %t298, 16
  %t301 = or i32 %t300, %t296
  %t302 = select i1 %t299, i32 0, i32 %t301
  %t304 = insertvalue { i32, ptr } zeroinitializer, i32 %t302, 0
  store { i32, ptr } %t304, ptr %rv
  br label %ret
bb72:
  %t305 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t305, ptr %l8, !tbaa !27
  %t306 = load ptr, ptr %l0, !tbaa !29
  %t307 = load i32, ptr %l3, !tbaa !23
  %t310 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t306, i32 %t307)
  store %"compiler/source:Span" %t310, ptr %l127
  br label %bb73
bb73:
  %t311 = load ptr, ptr %l2, !tbaa !29
  %t312 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t313
  %t314 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 0
  store i64 11, ptr %t314
  %t315 = load %"compiler/source:Span", ptr %l127
  %t316 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t315, 0
  %t318 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t316, ptr %t311, 1
  %t320 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t318, { i64, ptr } %t312, 2
  %t321 = getelementptr { i64, [4 x i64] }, ptr %t313, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t320, ptr %t321
  %t322 = load { i64, [4 x i64] }, ptr %t313
  %t324 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t322, ptr %t324
  store ptr %t324, ptr %l2, !tbaa !29
  br label %bb74
bb74:
  br label %bb75
bb75:
  br label %bb76
bb76:
  br label %bb132
bb77:
  %t326 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t328 = trunc i64 110 to i32
  %t329 = icmp eq i32 %t326, %t328
  br i1 %t329, label %bb78, label %bb79
bb78:
  br label %bb80
bb79:
  br label %bb85
bb80:
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eargs(ptr %v0, ptr %v2, ptr %t331)
  %t334 = extractvalue { i32, { i64, ptr } } %t333, 1
  %t335 = extractvalue { i32, { i64, ptr } } %t333, 0
  store i32 %t335, ptr %l137
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb82, label %ok.337, !prof !99
ok.337:
  store { i64, ptr } %t334, ptr %l136
  br label %bb81
bb81:
  %t338 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t338, ptr %l134, !tbaa !27
  br label %bb83
bb82:
  %t339 = load i32, ptr %l137, !tbaa !23
  %t340 = lshr i32 %t339, 16
  %t341 = and i32 %t339, 65535
  %t342 = icmp eq i32 %t340, 1
  %t343 = select i1 %t342, i32 1, i32 0
  %t344 = icmp eq i32 %t339, 0
  %t345 = shl i32 %t343, 16
  %t346 = or i32 %t345, %t341
  %t347 = select i1 %t344, i32 0, i32 %t346
  %t349 = insertvalue { i32, ptr } zeroinitializer, i32 %t347, 0
  store { i32, ptr } %t349, ptr %rv
  br label %ret
bb83:
  %t350 = load { i64, ptr }, ptr %l134, !tbaa !27
  store { i64, ptr } %t350, ptr %l9, !tbaa !27
  %t351 = load ptr, ptr %l0, !tbaa !29
  %t352 = load i32, ptr %l3, !tbaa !23
  %t355 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t351, i32 %t352)
  store %"compiler/source:Span" %t355, ptr %l141
  br label %bb84
bb84:
  %t356 = load ptr, ptr %l2, !tbaa !29
  %t357 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t358
  %t359 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 0
  store i64 10, ptr %t359
  %t360 = load %"compiler/source:Span", ptr %l141
  %t361 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t360, 0
  %t363 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t361, ptr %t356, 1
  %t365 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t363, { i64, ptr } %t357, 2
  %t366 = getelementptr { i64, [4 x i64] }, ptr %t358, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t365, ptr %t366
  %t367 = load { i64, [4 x i64] }, ptr %t358
  %t369 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t367, ptr %t369
  store ptr %t369, ptr %l2, !tbaa !29
  br label %bb132
bb85:
  %t371 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t373 = trunc i64 93 to i32
  %t374 = icmp eq i32 %t371, %t373
  br i1 %t374, label %bb86, label %bb87
bb86:
  br label %bb92
bb87:
  %t376 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t378 = trunc i64 94 to i32
  %t379 = icmp eq i32 %t376, %t378
  br i1 %t379, label %bb88, label %bb89
bb88:
  br label %bb92
bb89:
  %t381 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t383 = trunc i64 97 to i32
  %t384 = icmp eq i32 %t381, %t383
  br i1 %t384, label %bb90, label %bb91
bb90:
  br label %bb92
bb91:
  br label %bb96
bb92:
  %t386 = load ptr, ptr %l0, !tbaa !29
  %t388 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t386)
  store i32 %t388, ptr %l153
  br label %bb93
bb93:
  %t389 = load i32, ptr %l153, !range !{i32 0, i32 116}
  store i32 %t389, ptr %l10
  %t390 = load ptr, ptr %l0, !tbaa !29
  %t392 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t390)
  store i32 %t392, ptr %l155
  br label %bb94
bb94:
  %t393 = load ptr, ptr %l0, !tbaa !29
  %t394 = load i32, ptr %l3, !tbaa !23
  %t397 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t393, i32 %t394)
  store %"compiler/source:Span" %t397, ptr %l158
  br label %bb95
bb95:
  %t398 = load i32, ptr %l10, !range !{i32 0, i32 116}
  %t399 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t400
  %t401 = getelementptr { i64, [4 x i64] }, ptr %t400, i32 0, i32 0
  store i64 4, ptr %t401
  %t402 = load %"compiler/source:Span", ptr %l158
  %t403 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t402, 0
  %t405 = insertvalue { %"compiler/source:Span", i32, ptr } %t403, i32 %t398, 1
  %t407 = insertvalue { %"compiler/source:Span", i32, ptr } %t405, ptr %t399, 2
  %t408 = getelementptr { i64, [4 x i64] }, ptr %t400, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t407, ptr %t408
  %t409 = load { i64, [4 x i64] }, ptr %t400
  %t411 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t409, ptr %t411
  store ptr %t411, ptr %l2, !tbaa !29
  br label %bb132
bb96:
  %t413 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t415 = trunc i64 29 to i32
  %t416 = icmp eq i32 %t413, %t415
  br i1 %t416, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  br label %bb105
bb99:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t418)
  store i32 %t420, ptr %l166
  br label %bb100
bb100:
  %t421 = load ptr, ptr %l0, !tbaa !29
  %t423 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v2, ptr %t421)
  %t424 = extractvalue { i32, ptr } %t423, 1
  %t425 = extractvalue { i32, ptr } %t423, 0
  store i32 %t425, ptr %l170
  %t426 = icmp ne i32 %t425, 0
  br i1 %t426, label %bb102, label %ok.427, !prof !99
ok.427:
  store ptr %t424, ptr %l169
  br label %bb101
bb101:
  %t428 = load ptr, ptr %l169, !tbaa !29
  store ptr %t428, ptr %l167, !tbaa !29
  br label %bb103
bb102:
  %t429 = load i32, ptr %l170, !tbaa !23
  %t430 = lshr i32 %t429, 16
  %t431 = and i32 %t429, 65535
  %t432 = icmp eq i32 %t430, 1
  %t433 = select i1 %t432, i32 1, i32 0
  %t434 = icmp eq i32 %t429, 0
  %t435 = shl i32 %t433, 16
  %t436 = or i32 %t435, %t431
  %t437 = select i1 %t434, i32 0, i32 %t436
  %t439 = insertvalue { i32, ptr } zeroinitializer, i32 %t437, 0
  store { i32, ptr } %t439, ptr %rv
  br label %ret
bb103:
  %t440 = load ptr, ptr %l167, !tbaa !29
  store ptr %t440, ptr %l11, !tbaa !29
  %t441 = load ptr, ptr %l0, !tbaa !29
  %t442 = load i32, ptr %l3, !tbaa !23
  %t445 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t441, i32 %t442)
  store %"compiler/source:Span" %t445, ptr %l174
  br label %bb104
bb104:
  %t446 = load ptr, ptr %l2, !tbaa !29
  %t447 = load ptr, ptr %l11, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t448
  %t449 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 0
  store i64 9, ptr %t449
  %t450 = load %"compiler/source:Span", ptr %l174
  %t451 = insertvalue { %"compiler/source:Span", ptr, ptr } undef, %"compiler/source:Span" %t450, 0
  %t453 = insertvalue { %"compiler/source:Span", ptr, ptr } %t451, ptr %t446, 1
  %t455 = insertvalue { %"compiler/source:Span", ptr, ptr } %t453, ptr %t447, 2
  %t456 = getelementptr { i64, [4 x i64] }, ptr %t448, i32 0, i32 1
  store { %"compiler/source:Span", ptr, ptr } %t455, ptr %t456
  %t457 = load { i64, [4 x i64] }, ptr %t448
  %t459 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t457, ptr %t459
  store ptr %t459, ptr %l2, !tbaa !29
  br label %bb132
bb105:
  %t461 = load i32, ptr %l4, !range !{i32 0, i32 116}
  %t463 = trunc i64 102 to i32
  %t464 = icmp eq i32 %t461, %t463
  br i1 %t464, label %bb106, label %bb107
bb106:
  br label %bb108
bb107:
  br label %bb127
bb108:
  %t466 = load ptr, ptr %l0, !tbaa !29
  %t468 = getelementptr %"compiler/parse:Parser", ptr %t466, i32 0, i32 7
  %t469 = load i32, ptr %t468, !range !{i32 0, i32 116}
  %t471 = trunc i64 0 to i32
  %t472 = icmp eq i32 %t469, %t471
  %t474 = xor i1 %t472, true
  br i1 %t474, label %bb109, label %bb110
bb109:
  %t476 = load ptr, ptr %l2, !tbaa !29
  %t478 = insertvalue { i32, ptr } zeroinitializer, ptr %t476, 1
  store { i32, ptr } %t478, ptr %rv
  br label %ret
bb110:
  br label %bb111
bb111:
  %t479 = load ptr, ptr %l2, !tbaa !29
  store ptr %t479, ptr %l186, !tbaa !29
  %t480 = load ptr, ptr %l186, !tbaa !29
  %t481 = call ptr @__olang_scope_of(ptr %t480, ptr null)
  %t482 = call ptr @__olang_scope_hold(ptr %t481)
  %t483 = ptrtoint ptr %t482 to i64
  %t485 = inttoptr i64 %t483 to ptr
  %t486 = load ptr, ptr %l186, !tbaa !29
  %t487 = call i1 @compiler_2fparse_2eisPath(ptr %t485, ptr %t486)
  store i1 %t487, ptr %l188
  br label %bb112
bb112:
  %t488 = load i1, ptr %l188, !tbaa !21
  %t489 = xor i1 %t488, true
  br i1 %t489, label %bb113, label %bb114
bb113:
  store i1 true, ptr %l190, !tbaa !21
  br label %bb116
bb114:
  %t491 = load ptr, ptr %l0, !tbaa !29
  %t493 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %t491, i64 1)
  store i32 %t493, ptr %l192
  br label %bb115
bb115:
  %t494 = load i32, ptr %l192, !range !{i32 0, i32 116}
  %t496 = trunc i64 112 to i32
  %t497 = icmp eq i32 %t494, %t496
  %t499 = xor i1 %t497, true
  store i1 %t499, ptr %l190, !tbaa !21
  br label %bb116
bb116:
  %t501 = load i1, ptr %l190, !tbaa !21
  br i1 %t501, label %bb117, label %bb118
bb117:
  %t502 = load ptr, ptr %l2, !tbaa !29
  %t504 = insertvalue { i32, ptr } zeroinitializer, ptr %t502, 1
  store { i32, ptr } %t504, ptr %rv
  br label %ret
bb118:
  br label %bb119
bb119:
  %t505 = load ptr, ptr %l0, !tbaa !29
  %t506 = load ptr, ptr %l2, !tbaa !29
  store ptr %t506, ptr %l199, !tbaa !29
  %t507 = load ptr, ptr %l199, !tbaa !29
  %t508 = call ptr @__olang_scope_of(ptr %t507, ptr null)
  %t509 = call ptr @__olang_scope_hold(ptr %t508)
  %t510 = ptrtoint ptr %t509 to i64
  %t512 = inttoptr i64 %t510 to ptr
  %t514 = load ptr, ptr %l199, !tbaa !29
  %t515 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprAsType(ptr %v0, ptr %t512, ptr %v2, ptr %t505, ptr %t514)
  %t516 = extractvalue { i32, ptr } %t515, 1
  %t517 = extractvalue { i32, ptr } %t515, 0
  store i32 %t517, ptr %l202
  %t518 = icmp ne i32 %t517, 0
  br i1 %t518, label %bb121, label %ok.519, !prof !99
ok.519:
  store ptr %t516, ptr %l201
  br label %bb120
bb120:
  %t520 = load ptr, ptr %l201, !tbaa !29
  store ptr %t520, ptr %l197, !tbaa !29
  br label %bb122
bb121:
  %t521 = load i32, ptr %l202, !tbaa !23
  %t522 = lshr i32 %t521, 16
  %t523 = and i32 %t521, 65535
  %t524 = icmp eq i32 %t522, 1
  %t525 = select i1 %t524, i32 1, i32 0
  %t526 = icmp eq i32 %t521, 0
  %t527 = shl i32 %t525, 16
  %t528 = or i32 %t527, %t523
  %t529 = select i1 %t526, i32 0, i32 %t528
  %t531 = insertvalue { i32, ptr } zeroinitializer, i32 %t529, 0
  store { i32, ptr } %t531, ptr %rv
  br label %ret
bb122:
  %t532 = load ptr, ptr %l197, !tbaa !29
  %t533 = load ptr, ptr %l0, !tbaa !29
  store ptr %t533, ptr %l205, !tbaa !29
  %t534 = load i32, ptr %l3, !tbaa !23
  store i32 %t534, ptr %l206, !tbaa !23
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load i32, ptr %l3, !tbaa !23
  %t541 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v2, ptr %v2, ptr %t535, i32 %t536, ptr %t532)
  store ptr %t541, ptr %l210
  br label %bb123
bb123:
  %t542 = load ptr, ptr %l205, !tbaa !29
  %t543 = load i32, ptr %l206, !tbaa !23
  %t544 = load ptr, ptr %l210, !tbaa !29
  %t545 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v2, ptr %v2, ptr %t542, i32 %t543, ptr %t544)
  %t546 = extractvalue { i32, ptr } %t545, 1
  %t547 = extractvalue { i32, ptr } %t545, 0
  store i32 %t547, ptr %l212
  %t548 = icmp ne i32 %t547, 0
  br i1 %t548, label %bb125, label %ok.549, !prof !99
ok.549:
  store ptr %t546, ptr %l211
  br label %bb124
bb124:
  %t550 = load ptr, ptr %l211, !tbaa !29
  store ptr %t550, ptr %l204, !tbaa !29
  br label %bb126
bb125:
  %t551 = load i32, ptr %l212, !tbaa !23
  %t552 = lshr i32 %t551, 16
  %t553 = and i32 %t551, 65535
  %t554 = icmp eq i32 %t552, 1
  %t555 = select i1 %t554, i32 1, i32 0
  %t556 = icmp eq i32 %t551, 0
  %t557 = shl i32 %t555, 16
  %t558 = or i32 %t557, %t553
  %t559 = select i1 %t556, i32 0, i32 %t558
  %t561 = insertvalue { i32, ptr } zeroinitializer, i32 %t559, 0
  store { i32, ptr } %t561, ptr %rv
  br label %ret
bb126:
  %t562 = load ptr, ptr %l204, !tbaa !29
  store ptr %t562, ptr %l2, !tbaa !29
  br label %bb132
bb127:
  br i1 true, label %bb128, label %bb129
bb128:
  br label %bb130
bb129:
  br label %bb131
bb130:
  %t563 = load ptr, ptr %l2, !tbaa !29
  %t565 = insertvalue { i32, ptr } zeroinitializer, ptr %t563, 1
  store { i32, ptr } %t565, ptr %rv
  br label %ret
bb131:
  call void @__olang_check_failed(ptr @olang_loc_148080230b4c6cc_b965c2d4ca1d1020)
  unreachable
bb132:
  br label %bb133
bb133:
  br label %bb2
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epower(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/source:Span"
  %l4 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca i32
  %l11 = alloca i1
  %l15 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca %"compiler/source:Span"
  %l26 = alloca %"compiler/source:Span"
  %l28 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t88 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t1)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l6, !tbaa !29
  store ptr %t8, ptr %l4, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  call void @__olang_scope_close(ptr %s0)
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l4, !tbaa !29
  store ptr %t20, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t21, i32 71)
  store i1 %t24, ptr %l11
  br label %bb4
bb4:
  %t25 = load i1, ptr %l11, !tbaa !21
  %t26 = xor i1 %t25, true
  br i1 %t26, label %bb5, label %bb6
bb5:
  %t28 = load ptr, ptr %l1, !tbaa !29
  call void @__olang_scope_close(ptr %s0)
  %t30 = insertvalue { i32, ptr } zeroinitializer, ptr %t28, 1
  store { i32, ptr } %t30, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t31)
  store i32 %t33, ptr %l15
  br label %bb8
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t34)
  %t37 = extractvalue { i32, ptr } %t36, 1
  %t38 = extractvalue { i32, ptr } %t36, 0
  store i32 %t38, ptr %l19
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb10, label %ok.40, !prof !99
ok.40:
  store ptr %t37, ptr %l18
  br label %bb9
bb9:
  %t41 = load ptr, ptr %l18, !tbaa !29
  store ptr %t41, ptr %l16, !tbaa !29
  br label %bb11
bb10:
  %t42 = load i32, ptr %l19, !tbaa !23
  %t43 = lshr i32 %t42, 16
  %t44 = and i32 %t42, 65535
  %t45 = icmp eq i32 %t43, 1
  %t46 = select i1 %t45, i32 1, i32 0
  %t47 = icmp eq i32 %t42, 0
  %t48 = shl i32 %t46, 16
  %t49 = or i32 %t48, %t44
  %t50 = select i1 %t47, i32 0, i32 %t49
  call void @__olang_scope_close(ptr %s0)
  %t52 = insertvalue { i32, ptr } zeroinitializer, i32 %t50, 0
  store { i32, ptr } %t52, ptr %rv
  br label %ret
bb11:
  %t53 = load ptr, ptr %l16, !tbaa !29
  store ptr %t53, ptr %l2, !tbaa !29
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t54)
  store %"compiler/source:Span" %t56, ptr %l22
  br label %bb12
bb12:
  %t57 = getelementptr %"compiler/source:Span", ptr %l22, i32 0, i32 0
  %t58 = load i32, ptr %t57, !tbaa !23
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = getelementptr %"compiler/parse:Parser", ptr %t59, i32 0, i32 10
  %t62 = load i32, ptr %t61, !tbaa !23
  %t65 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %s0, i32 %t58, i32 %t62)
  store %"compiler/source:Span" %t65, ptr %l26
  br label %bb13
bb13:
  %t66 = load %"compiler/source:Span", ptr %l26
  store %"compiler/source:Span" %t66, ptr %l3
  %t67 = load ptr, ptr %l0, !tbaa !29
  %t69 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t67)
  store i32 %t69, ptr %l28
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb15, label %ok.71, !prof !99
ok.71:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t72 = load i32, ptr %l28, !tbaa !23
  %t73 = lshr i32 %t72, 16
  %t74 = and i32 %t72, 65535
  %t75 = icmp eq i32 %t73, 1
  %t76 = select i1 %t75, i32 1, i32 0
  %t77 = icmp eq i32 %t72, 0
  %t78 = shl i32 %t76, 16
  %t79 = or i32 %t78, %t74
  %t80 = select i1 %t77, i32 0, i32 %t79
  call void @__olang_scope_close(ptr %s0)
  %t82 = insertvalue { i32, ptr } zeroinitializer, i32 %t80, 0
  store { i32, ptr } %t82, ptr %rv
  br label %ret
bb16:
  %t83 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t83)
  br label %bb17
bb17:
  %t85 = load %"compiler/source:Span", ptr %l3
  %t86 = load ptr, ptr %l1, !tbaa !29
  %t87 = load ptr, ptr %l2, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t88
  %t89 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 0
  store i64 5, ptr %t89
  %t91 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t85, 0
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t91, i32 71, 1
  %t95 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t93, ptr %t86, 2
  %t97 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t95, ptr %t87, 3
  %t98 = getelementptr { i64, [4 x i64] }, ptr %t88, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t97, ptr %t98
  %t99 = load { i64, [4 x i64] }, ptr %t88
  %t101 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t99, ptr %t101
  call void @__olang_scope_close(ptr %s0)
  %t103 = insertvalue { i32, ptr } zeroinitializer, ptr %t101, 1
  store { i32, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereflListPath(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l13 = alloca { i64, ptr }
  %l15 = alloca i1
  %l16 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l24 = alloca i1
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  store i1 false, ptr %l5, !tbaa !21
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 12
  store i1 %t8, ptr %l5, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l5, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l1, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, i32 }, ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l2, !tbaa !23
  br label %bb5
bb4:
  br label %bb20
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = getelementptr %"compiler/parse:Parser", ptr %a0, i32 0, i32 2
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = load i32, ptr %l2, !tbaa !23
  %t23 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v0, ptr %t19, i32 %t20)
  store { i64, ptr } %t23, ptr %l13
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t25, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t27, ptr %l15
  br label %bb7
bb7:
  %t28 = load i1, ptr %l15, !tbaa !21
  br i1 %t28, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb11
bb9:
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t29, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb10
bb10:
  %t32 = load i1, ptr %l18, !tbaa !21
  store i1 %t32, ptr %l16, !tbaa !21
  br label %bb11
bb11:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l19, !tbaa !21
  br label %bb15
bb13:
  %t34 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t34, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t36, ptr %l21
  br label %bb14
bb14:
  %t37 = load i1, ptr %l21, !tbaa !21
  store i1 %t37, ptr %l19, !tbaa !21
  br label %bb15
bb15:
  %t38 = load i1, ptr %l19, !tbaa !21
  br i1 %t38, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l22, !tbaa !21
  br label %bb19
bb17:
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s1, { i64, ptr } %t39, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d9, i32 0, i32 1) })
  store i1 %t41, ptr %l24
  br label %bb18
bb18:
  %t42 = load i1, ptr %l24, !tbaa !21
  store i1 %t42, ptr %l22, !tbaa !21
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t43 = load i1, ptr %l22, !tbaa !21
  store i1 %t43, ptr %rv
  br label %ret
bb20:
  br i1 true, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store i1 false, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_952e32d6f93638f1_595c141b0c1c5b3d)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2erelease(ptr %v0, ptr %a0, %"compiler/parse:stackMarks" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/parse:stackMarks"
  store ptr %a0, ptr %l0
  store %"compiler/parse:stackMarks" %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 34
  %t4 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 0
  %t5 = load i64, ptr %t4, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %t3, i64 %t5)
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t8, i32 0, i32 35
  %t11 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 1
  %t12 = load i64, ptr %t11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %t10, i64 %t12)
  br label %bb2
bb2:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t17 = getelementptr %"compiler/parse:Parser", ptr %t15, i32 0, i32 36
  %t18 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %t17, i64 %t19)
  br label %bb3
bb3:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 37
  %t25 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 3
  %t26 = load i64, ptr %t25, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eTruncate_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %t24, i64 %t26)
  br label %bb4
bb4:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 38
  %t32 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 4
  %t33 = load i64, ptr %t32, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %t31, i64 %t33)
  br label %bb5
bb5:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = getelementptr %"compiler/parse:Parser", ptr %t36, i32 0, i32 39
  %t39 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 5
  %t40 = load i64, ptr %t39, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %t38, i64 %t40)
  br label %bb6
bb6:
  %t43 = load ptr, ptr %l0, !tbaa !29
  %t45 = getelementptr %"compiler/parse:Parser", ptr %t43, i32 0, i32 40
  %t46 = getelementptr %"compiler/parse:stackMarks", ptr %l1, i32 0, i32 6
  %t47 = load i64, ptr %t46, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eTruncate_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %t45, i64 %t47)
  br label %bb7
bb7:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %a0, i1 %a1, i1 %a2, i1 %a3, i1 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca i64
  %l12 = alloca i1
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca i1
  %l22 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l44 = alloca i1
  %l47 = alloca i1
  %l49 = alloca i1
  %l52 = alloca i64
  %l56 = alloca ptr
  %l58 = alloca ptr
  %l59 = alloca i32
  %l70 = alloca i1
  %l73 = alloca i1
  %l80 = alloca { i64, ptr }
  %l82 = alloca i1
  %l86 = alloca i1
  %l89 = alloca i1
  %l91 = alloca i32
  %l92 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i32
  %l106 = alloca i1
  %l108 = alloca i1
  %l111 = alloca i1
  %l114 = alloca { i64, ptr }
  %l116 = alloca ptr
  %l118 = alloca i32
  %l120 = alloca i32
  %l123 = alloca { i64, ptr }
  %l124 = alloca %"compiler/diagmsg:Msg"
  %l136 = alloca %"compiler/ast:Sig"
  %s6 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  store i1 %a1, ptr %l1
  store i1 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i1, ptr %l2, !tbaa !21
  br i1 %t1, label %bb1, label %bb2
bb1:
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 23
  %t6 = load i1, ptr %t5, !tbaa !21
  store i1 %t6, ptr %l19, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l19, !tbaa !21
  br label %bb3
bb3:
  %t8 = load i1, ptr %l19, !tbaa !21
  store i1 %t8, ptr %l6, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t12 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t9, i32 110)
  %t13 = extractvalue { i32, i32 } %t12, 1
  %t14 = extractvalue { i32, i32 } %t12, 0
  store i32 %t14, ptr %l26
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  store i32 %t13, ptr %l25
  br label %bb4
bb4:
  %t17 = load i32, ptr %l25, !tbaa !23
  store i32 %t17, ptr %l22, !tbaa !23
  br label %bb6
bb5:
  %t18 = load i32, ptr %l26, !tbaa !23
  %t19 = lshr i32 %t18, 16
  %t20 = and i32 %t18, 65535
  %t21 = icmp eq i32 %t19, 1
  %t22 = select i1 %t21, i32 1, i32 0
  %t23 = icmp eq i32 %t18, 0
  %t24 = shl i32 %t22, 16
  %t25 = or i32 %t24, %t20
  %t26 = select i1 %t23, i32 0, i32 %t25
  %t28 = insertvalue { i32, ptr } zeroinitializer, i32 %t26, 0
  store { i32, ptr } %t28, ptr %rv
  br label %ret
bb6:
  %t29 = load ptr, ptr %l0, !tbaa !29
  %t31 = getelementptr %"compiler/parse:Parser", ptr %t29, i32 0, i32 59
  store i1 false, ptr %t31, !tbaa !21
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/parse:Parser", ptr %t32, i32 0, i32 60
  store i1 true, ptr %t34, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t36 = load i1, ptr %l1, !tbaa !21
  %t39 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %t35, i1 %t36)
  %t40 = extractvalue { i32, { i64, ptr } } %t39, 1
  %t41 = extractvalue { i32, { i64, ptr } } %t39, 0
  store i32 %t41, ptr %l34
  %t42 = icmp ne i32 %t41, 0
  br i1 %t42, label %bb8, label %ok.43, !prof !99
ok.43:
  store { i64, ptr } %t40, ptr %l33
  br label %bb7
bb7:
  %t44 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t44, ptr %l30, !tbaa !27
  br label %bb9
bb8:
  %t45 = load i32, ptr %l34, !tbaa !23
  %t46 = lshr i32 %t45, 16
  %t47 = and i32 %t45, 65535
  %t48 = icmp eq i32 %t46, 1
  %t49 = select i1 %t48, i32 1, i32 0
  %t50 = icmp eq i32 %t45, 0
  %t51 = shl i32 %t49, 16
  %t52 = or i32 %t51, %t47
  %t53 = select i1 %t50, i32 0, i32 %t52
  %t55 = insertvalue { i32, ptr } zeroinitializer, i32 %t53, 0
  store { i32, ptr } %t55, ptr %rv
  br label %ret
bb9:
  %t56 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t56, ptr %l7, !tbaa !27
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = getelementptr %"compiler/parse:Parser", ptr %t57, i32 0, i32 59
  %t60 = load i1, ptr %t59, !tbaa !21
  store i1 %t60, ptr %l8, !tbaa !21
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/parse:Parser", ptr %t62, i32 0, i32 59
  store i1 false, ptr %t64, !tbaa !21
  %t65 = icmp sge i64 0, 0
  br i1 %t65, label %bb10, label %bb11
bb10:
  %t67 = icmp sle i64 0, 1152921504606846975
  br i1 %t67, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb12:
  %t69 = mul i64 0, 8
  %t70 = insertvalue { i64, ptr } undef, i64 0, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t71, ptr %l9, !tbaa !27
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t76 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t73, i32 23)
  store i1 %t76, ptr %l44
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @olang_loc_682b81c4be20c47_acb581c54a6720db)
  unreachable
bb14:
  %t77 = load i1, ptr %l44, !tbaa !21
  store i1 %t77, ptr %l10, !tbaa !21
  %t78 = load i1, ptr %l10, !tbaa !21
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %t82)
  store i1 %t84, ptr %l49
  br label %bb17
bb16:
  store i1 false, ptr %l47, !tbaa !21
  br label %bb18
bb17:
  %t85 = load i1, ptr %l49, !tbaa !21
  store i1 %t85, ptr %l47, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l47, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 36
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l52
  br label %bb21
bb20:
  br label %bb39
bb21:
  %t92 = load i64, ptr %l52, !tbaa !24
  store i64 %t92, ptr %l11, !tbaa !24
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = getelementptr %"compiler/parse:Parser", ptr %t93, i32 0, i32 23
  %t96 = load i1, ptr %t95, !tbaa !21
  store i1 %t96, ptr %l12, !tbaa !21
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"compiler/parse:Parser", ptr %t98, i32 0, i32 23
  store i1 true, ptr %t100, !tbaa !21
  br label %bb22
bb22:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v0, ptr %t101)
  %t104 = extractvalue { i32, ptr } %t103, 1
  %t105 = extractvalue { i32, ptr } %t103, 0
  store i32 %t105, ptr %l59
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb24, label %ok.107, !prof !99
ok.107:
  store ptr %t104, ptr %l58
  br label %bb23
bb23:
  %t108 = load ptr, ptr %l58, !tbaa !29
  store ptr %t108, ptr %l56, !tbaa !29
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load i1, ptr %l12, !tbaa !21
  %t113 = getelementptr %"compiler/parse:Parser", ptr %t109, i32 0, i32 23
  store i1 %t110, ptr %t113, !tbaa !21
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/parse:Parser", ptr %t114, i32 0, i32 36
  %t117 = load i64, ptr %l11, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %t116, i64 %t117)
  br label %bb26
bb26:
  %t121 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t121, ptr %rv
  br label %ret
bb27:
  %t122 = load ptr, ptr %l56, !tbaa !29
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/parse:Parser", ptr %t123, i32 0, i32 36
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t125, ptr %t122)
  br label %bb28
bb28:
  %t129 = load i1, ptr %l6, !tbaa !21
  br i1 %t129, label %bb29, label %bb30
bb29:
  store i1 true, ptr %l70, !tbaa !21
  br label %bb32
bb30:
  %t131 = load ptr, ptr %l0, !tbaa !29
  %t134 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %t131, i32 75)
  store i1 %t134, ptr %l73
  br label %bb31
bb31:
  %t135 = load i1, ptr %l73, !tbaa !21
  %t136 = xor i1 %t135, true
  store i1 %t136, ptr %l70, !tbaa !21
  br label %bb32
bb32:
  %t138 = load i1, ptr %l70, !tbaa !21
  br i1 %t138, label %bb33, label %bb34
bb33:
  br label %bb37
bb34:
  br label %bb35
bb35:
  br label %bb36
bb36:
  br label %bb22
bb37:
  %t139 = load ptr, ptr %l0, !tbaa !29
  %t140 = load i1, ptr %l12, !tbaa !21
  %t143 = getelementptr %"compiler/parse:Parser", ptr %t139, i32 0, i32 23
  store i1 %t140, ptr %t143, !tbaa !21
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t146 = getelementptr %"compiler/parse:Parser", ptr %t144, i32 0, i32 36
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %t146, i64 %t147)
  store { i64, ptr } %t150, ptr %l80
  br label %bb38
bb38:
  %t151 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t151, ptr %l9, !tbaa !27
  br label %bb39
bb39:
  store i1 false, ptr %l14, !tbaa !21
  br i1 %a3, label %bb40, label %bb41
bb40:
  %t154 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t158 = icmp sgt i64 %t156, 0
  store i1 %t158, ptr %l82, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l82, !tbaa !21
  br label %bb42
bb42:
  %t160 = load i1, ptr %l82, !tbaa !21
  br i1 %t160, label %bb43, label %bb44
bb43:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t164 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t161, i32 56)
  store i1 %t164, ptr %l89
  br label %bb45
bb44:
  store i1 false, ptr %l86, !tbaa !21
  br label %bb46
bb45:
  %t165 = load i1, ptr %l89, !tbaa !21
  store i1 %t165, ptr %l86, !tbaa !21
  br label %bb46
bb46:
  %t166 = load i1, ptr %l86, !tbaa !21
  br i1 %t166, label %bb47, label %bb48
bb47:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t167)
  store i32 %t169, ptr %l91
  br label %bb49
bb48:
  br label %bb50
bb49:
  store i1 true, ptr %l14, !tbaa !21
  br label %bb50
bb50:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load i1, ptr %l6, !tbaa !21
  %t174 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %v1, ptr %t170, i1 %t171)
  %t175 = extractvalue { i32, ptr } %t174, 1
  %t176 = extractvalue { i32, ptr } %t174, 0
  store i32 %t176, ptr %l96
  %t177 = icmp ne i32 %t176, 0
  br i1 %t177, label %bb52, label %ok.178, !prof !99
ok.178:
  store ptr %t175, ptr %l95
  br label %bb51
bb51:
  %t179 = load ptr, ptr %l95, !tbaa !29
  store ptr %t179, ptr %l92, !tbaa !29
  br label %bb53
bb52:
  %t180 = load i32, ptr %l96, !tbaa !23
  %t181 = lshr i32 %t180, 16
  %t182 = and i32 %t180, 65535
  %t183 = icmp eq i32 %t181, 1
  %t184 = select i1 %t183, i32 1, i32 0
  %t185 = icmp eq i32 %t180, 0
  %t186 = shl i32 %t184, 16
  %t187 = or i32 %t186, %t182
  %t188 = select i1 %t185, i32 0, i32 %t187
  %t190 = insertvalue { i32, ptr } zeroinitializer, i32 %t188, 0
  store { i32, ptr } %t190, ptr %rv
  br label %ret
bb53:
  %t191 = load ptr, ptr %l92, !tbaa !29
  store ptr %t191, ptr %l15, !tbaa !29
  %t192 = load ptr, ptr %l0, !tbaa !29
  %t194 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epromises(ptr %v0, ptr %v1, ptr %t192)
  %t195 = extractvalue { i32, { i64, ptr } } %t194, 1
  %t196 = extractvalue { i32, { i64, ptr } } %t194, 0
  store i32 %t196, ptr %l101
  %t197 = icmp ne i32 %t196, 0
  br i1 %t197, label %bb55, label %ok.198, !prof !99
ok.198:
  store { i64, ptr } %t195, ptr %l100
  br label %bb54
bb54:
  %t199 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t199, ptr %l98, !tbaa !27
  br label %bb56
bb55:
  %t200 = load i32, ptr %l101, !tbaa !23
  %t201 = lshr i32 %t200, 16
  %t202 = and i32 %t200, 65535
  %t203 = icmp eq i32 %t201, 1
  %t204 = select i1 %t203, i32 1, i32 0
  %t205 = icmp eq i32 %t200, 0
  %t206 = shl i32 %t204, 16
  %t207 = or i32 %t206, %t202
  %t208 = select i1 %t205, i32 0, i32 %t207
  %t210 = insertvalue { i32, ptr } zeroinitializer, i32 %t208, 0
  store { i32, ptr } %t210, ptr %rv
  br label %ret
bb56:
  %t211 = load { i64, ptr }, ptr %l98, !tbaa !27
  store { i64, ptr } %t211, ptr %l16, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t216 = icmp sgt i64 %t214, 0
  br i1 %t216, label %bb57, label %bb58
bb57:
  %t218 = load i1, ptr %l1, !tbaa !21
  br i1 %t218, label %bb59, label %bb60
bb58:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb62
bb59:
  store i1 true, ptr %l108, !tbaa !21
  br label %bb61
bb60:
  %t220 = load i1, ptr %l2, !tbaa !21
  %t222 = xor i1 %t220, true
  store i1 %t222, ptr %l108, !tbaa !21
  br label %bb61
bb61:
  %t224 = load i1, ptr %l108, !tbaa !21
  store i1 %t224, ptr %l106, !tbaa !21
  br label %bb62
bb62:
  %t225 = load i1, ptr %l106, !tbaa !21
  br i1 %t225, label %bb63, label %bb64
bb63:
  %t228 = xor i1 %a4, true
  store i1 %t228, ptr %l111, !tbaa !21
  br label %bb65
bb64:
  store i1 false, ptr %l111, !tbaa !21
  br label %bb65
bb65:
  %t230 = load i1, ptr %l111, !tbaa !21
  br i1 %t230, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s6
  %t231 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t231, ptr %l114, !tbaa !27
  %t232 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr ptr, ptr %t233, i64 0
  %t235 = load ptr, ptr %t234, !tbaa !39
  store ptr %t235, ptr %l17, !tbaa !29
  %t237 = load ptr, ptr %l0, !tbaa !29
  store ptr %t237, ptr %l116, !tbaa !29
  %t238 = load ptr, ptr %l17, !tbaa !29
  %t240 = getelementptr %"compiler/ast:Promise", ptr %t238, i32 0, i32 0
  %t241 = getelementptr %"compiler/source:Span", ptr %t240, i32 0, i32 0
  %t242 = load i32, ptr %t241, !tbaa !23
  store i32 %t242, ptr %l118, !tbaa !23
  %t243 = load ptr, ptr %l17, !tbaa !29
  %t245 = getelementptr %"compiler/ast:Promise", ptr %t243, i32 0, i32 0
  %t246 = getelementptr %"compiler/source:Span", ptr %t245, i32 0, i32 1
  %t247 = load i32, ptr %t246, !tbaa !23
  store i32 %t247, ptr %l120, !tbaa !23
  %t248 = load ptr, ptr %l17, !tbaa !29
  %t250 = getelementptr %"compiler/ast:Promise", ptr %t248, i32 0, i32 1
  %t251 = load i32, ptr %t250, !range !{i32 0, i32 116}
  %t253 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s6, i32 %t251)
  store { i64, ptr } %t253, ptr %l123
  br label %bb68
bb67:
  br label %bb71
bb68:
  %t254 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t255 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseMisplaced(ptr %s6, ptr %v0, { i64, ptr } %t254)
  store %"compiler/diagmsg:Msg" %t255, ptr %l124
  br label %bb69
bb69:
  %t256 = load ptr, ptr %l116, !tbaa !29
  %t257 = load i32, ptr %l118, !tbaa !23
  %t258 = load i32, ptr %l120, !tbaa !23
  %t259 = load %"compiler/diagmsg:Msg", ptr %l124
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t256, i32 %t257, i32 %t258, %"compiler/diagmsg:Msg" %t259)
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb71:
  %t260 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t262 = load ptr, ptr %l15, !tbaa !29
  %t264 = getelementptr %"compiler/ast:Sig", ptr %t262, i32 0, i32 2
  %t265 = load i1, ptr %t264, !tbaa !21
  %t266 = load ptr, ptr %l15, !tbaa !29
  %t268 = getelementptr %"compiler/ast:Sig", ptr %t266, i32 0, i32 3
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !27
  %t270 = load i1, ptr %l10, !tbaa !21
  %t271 = load i1, ptr %l14, !tbaa !21
  %t272 = load i1, ptr %l8, !tbaa !21
  %t273 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t284 = call %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v1, ptr %v1, ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t260, { i64, ptr } %t261, i1 %t265, { i64, ptr } %t269, i1 %t270, i1 %t271, i1 %t272, { i64, ptr } %t273, i1 %a5)
  store %"compiler/ast:Sig" %t284, ptr %l136
  br label %bb72
bb72:
  %t285 = load %"compiler/ast:Sig", ptr %l136
  %t286 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 88, i64 8)
  store %"compiler/ast:Sig" %t285, ptr %t286
  %t288 = insertvalue { i32, ptr } zeroinitializer, ptr %t286, 1
  store { i32, ptr } %t288, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2espread(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca ptr
  %l11 = alloca i32
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca i32
  %l42 = alloca i32
  %l45 = alloca i1
  %l48 = alloca i1
  %l51 = alloca i1
  %l56 = alloca %"compiler/source:Span"
  %l59 = alloca %"compiler/source:Span"
  %l62 = alloca i32
  %l67 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i32
  %l74 = alloca %"compiler/source:Span"
  %s4 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t102 = alloca { i64, [4 x i64] }, align 8
  %t112 = alloca { i64, [4 x i64] }, align 8
  %t150 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l11
  br label %bb1
bb1:
  %t4 = load i32, ptr %l11, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  store i64 0, ptr %l2, !tbaa !24
  store i64 3, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = icmp sgt i64 %t5, %t6
  br i1 %t9, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t11, 0
  br i1 %t13, label %bb4, label %bb5
bb3:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb7
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = sub i64 %t15, %t16
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = add i64 %t19, %t20
  %t25 = sub i64 %t23, 1
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = sdiv i64 %t25, %t26
  store i64 %t29, ptr %l18, !tbaa !24
  br label %bb6
bb5:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb6
bb6:
  %t31 = load i64, ptr %l18, !tbaa !24
  store i64 %t31, ptr %l15, !tbaa !24
  br label %bb7
bb7:
  %t32 = load i64, ptr %l15, !tbaa !24
  store i64 %t32, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  %t33 = load i64, ptr %l6, !tbaa !24
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp slt i64 %t33, %t34
  %t39 = xor i1 %t37, true
  br i1 %t39, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t41 = load i64, ptr %l2, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t43 = load i64, ptr %l4, !tbaa !24
  %t46 = mul i64 %t42, %t43
  %t49 = add i64 %t41, %t46
  store i64 %t49, ptr %l7, !tbaa !24
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t51)
  store i32 %t53, ptr %l37
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t54 = load i64, ptr %l6, !tbaa !24
  %t57 = add i64 %t54, 1
  store i64 %t57, ptr %l6, !tbaa !24
  br label %bb8
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  %t61 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t59)
  store i32 %t61, ptr %l42
  br label %bb15
bb15:
  %t62 = load i32, ptr %l42, !range !{i32 0, i32 116}
  store i32 %t62, ptr %l8
  %t63 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t65 = trunc i64 75 to i32
  %t66 = icmp eq i32 %t63, %t65
  br i1 %t66, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l45, !tbaa !21
  br label %bb18
bb17:
  %t68 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t70 = trunc i64 113 to i32
  %t71 = icmp eq i32 %t68, %t70
  store i1 %t71, ptr %l45, !tbaa !21
  br label %bb18
bb18:
  %t73 = load i1, ptr %l45, !tbaa !21
  br i1 %t73, label %bb19, label %bb20
bb19:
  store i1 true, ptr %l48, !tbaa !21
  br label %bb21
bb20:
  %t74 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t76 = trunc i64 111 to i32
  %t77 = icmp eq i32 %t74, %t76
  store i1 %t77, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t79 = load i1, ptr %l48, !tbaa !21
  br i1 %t79, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb24
bb23:
  %t80 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t82 = trunc i64 8 to i32
  %t83 = icmp eq i32 %t80, %t82
  store i1 %t83, ptr %l51, !tbaa !21
  br label %bb24
bb24:
  %t85 = load i1, ptr %l51, !tbaa !21
  br i1 %t85, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t87 = load i32, ptr %l1, !tbaa !23
  %t90 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t86, i32 %t87)
  store %"compiler/source:Span" %t90, ptr %l56
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t92 = load i32, ptr %l1, !tbaa !23
  %t95 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t91, i32 %t92)
  store %"compiler/source:Span" %t95, ptr %l59
  br label %bb28
bb28:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/parse:Parser", ptr %t96, i32 0, i32 2
  %t99 = load ptr, ptr %t98, !tbaa !29
  %t101 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %s4, ptr %t99, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d10, i32 0, i32 1) })
  store i32 %t101, ptr %l62
  br label %bb29
bb29:
  store { i64, [4 x i64] } zeroinitializer, ptr %t102
  %t103 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 0
  store i64 0, ptr %t103
  %t104 = load %"compiler/source:Span", ptr %l59
  %t105 = insertvalue { %"compiler/source:Span", i32 } undef, %"compiler/source:Span" %t104, 0
  %t106 = load i32, ptr %l62, !tbaa !23
  %t107 = insertvalue { %"compiler/source:Span", i32 } %t105, i32 %t106, 1
  %t108 = getelementptr { i64, [4 x i64] }, ptr %t102, i32 0, i32 1
  store { %"compiler/source:Span", i32 } %t107, ptr %t108
  %t109 = load { i64, [4 x i64] }, ptr %t102
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t109, ptr %t111
  store { i64, [4 x i64] } zeroinitializer, ptr %t112
  %t113 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 0
  store i64 26, ptr %t113
  %t114 = load %"compiler/source:Span", ptr %l56
  %t115 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t114, 0
  %t117 = insertvalue { %"compiler/source:Span", ptr } %t115, ptr %t111, 1
  %t118 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t117, ptr %t118
  %t119 = load { i64, [4 x i64] }, ptr %t112
  %t121 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t119, ptr %t121
  call void @__olang_scope_close(ptr %s4)
  %t123 = insertvalue { i32, ptr } zeroinitializer, ptr %t121, 1
  store { i32, ptr } %t123, ptr %rv
  br label %ret
bb30:
  %t124 = load ptr, ptr %l0, !tbaa !29
  %t126 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t124)
  %t127 = extractvalue { i32, ptr } %t126, 1
  %t128 = extractvalue { i32, ptr } %t126, 0
  store i32 %t128, ptr %l70
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb32, label %ok.130, !prof !99
ok.130:
  store ptr %t127, ptr %l69
  br label %bb31
bb31:
  %t131 = load ptr, ptr %l69, !tbaa !29
  store ptr %t131, ptr %l67, !tbaa !29
  br label %bb33
bb32:
  %t132 = load i32, ptr %l70, !tbaa !23
  %t133 = lshr i32 %t132, 16
  %t134 = and i32 %t132, 65535
  %t135 = icmp eq i32 %t133, 1
  %t136 = select i1 %t135, i32 1, i32 0
  %t137 = icmp eq i32 %t132, 0
  %t138 = shl i32 %t136, 16
  %t139 = or i32 %t138, %t134
  %t140 = select i1 %t137, i32 0, i32 %t139
  %t142 = insertvalue { i32, ptr } zeroinitializer, i32 %t140, 0
  store { i32, ptr } %t142, ptr %rv
  br label %ret
bb33:
  %t143 = load ptr, ptr %l67, !tbaa !29
  store ptr %t143, ptr %l9, !tbaa !29
  %t144 = load ptr, ptr %l0, !tbaa !29
  %t145 = load i32, ptr %l1, !tbaa !23
  %t148 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t144, i32 %t145)
  store %"compiler/source:Span" %t148, ptr %l74
  br label %bb34
bb34:
  %t149 = load ptr, ptr %l9, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t150
  %t151 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 0
  store i64 26, ptr %t151
  %t152 = load %"compiler/source:Span", ptr %l74
  %t153 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t152, 0
  %t155 = insertvalue { %"compiler/source:Span", ptr } %t153, ptr %t149, 1
  %t156 = getelementptr { i64, [4 x i64] }, ptr %t150, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t155, ptr %t156
  %t157 = load { i64, [4 x i64] }, ptr %t150
  %t159 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t157, ptr %t159
  %t161 = insertvalue { i32, ptr } zeroinitializer, ptr %t159, 1
  store { i32, ptr } %t161, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2estartsResult(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l9 = alloca i1
  %l12 = alloca i1
  %l15 = alloca i1
  %l18 = alloca i1
  %l21 = alloca i1
  %l24 = alloca i1
  %l27 = alloca i1
  %l30 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3, !range !{i32 0, i32 116}
  store i32 %t4, ptr %l1
  %t5 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t7 = trunc i64 1 to i32
  %t8 = icmp eq i32 %t5, %t7
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t12 = trunc i64 39 to i32
  %t13 = icmp eq i32 %t10, %t12
  store i1 %t13, ptr %l6, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l6, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb7
bb6:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 37 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l9, !tbaa !21
  br label %bb7
bb7:
  %t21 = load i1, ptr %l9, !tbaa !21
  br i1 %t21, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb10
bb9:
  %t22 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t24 = trunc i64 110 to i32
  %t25 = icmp eq i32 %t22, %t24
  store i1 %t25, ptr %l12, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l12, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb13
bb12:
  %t28 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t30 = trunc i64 35 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l15, !tbaa !21
  br label %bb13
bb13:
  %t33 = load i1, ptr %l15, !tbaa !21
  br i1 %t33, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l18, !tbaa !21
  br label %bb16
bb15:
  %t34 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t36 = trunc i64 34 to i32
  %t37 = icmp eq i32 %t34, %t36
  store i1 %t37, ptr %l18, !tbaa !21
  br label %bb16
bb16:
  %t39 = load i1, ptr %l18, !tbaa !21
  br i1 %t39, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb19
bb18:
  %t40 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t42 = trunc i64 36 to i32
  %t43 = icmp eq i32 %t40, %t42
  store i1 %t43, ptr %l21, !tbaa !21
  br label %bb19
bb19:
  %t45 = load i1, ptr %l21, !tbaa !21
  br i1 %t45, label %bb20, label %bb21
bb20:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb22
bb21:
  %t46 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t48 = trunc i64 52 to i32
  %t49 = icmp eq i32 %t46, %t48
  store i1 %t49, ptr %l24, !tbaa !21
  br label %bb22
bb22:
  %t51 = load i1, ptr %l24, !tbaa !21
  br i1 %t51, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb25
bb24:
  %t52 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t54 = trunc i64 67 to i32
  %t55 = icmp eq i32 %t52, %t54
  store i1 %t55, ptr %l27, !tbaa !21
  br label %bb25
bb25:
  %t57 = load i1, ptr %l27, !tbaa !21
  br i1 %t57, label %bb26, label %bb27
bb26:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb28
bb27:
  %t58 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t60 = trunc i64 43 to i32
  %t61 = icmp eq i32 %t58, %t60
  store i1 %t61, ptr %l30, !tbaa !21
  br label %bb28
bb28:
  %t63 = load i1, ptr %l30, !tbaa !21
  store i1 %t63, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esubItem(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l3 = alloca i32
  %l6 = alloca i1
  %l7 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i32
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca i32
  %l16 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca i32
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i32, ptr %l3, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t5, i32 79)
  store i1 %t8, ptr %l6
  br label %bb2
bb2:
  %t9 = load i1, ptr %l6, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = load i32, ptr %l1, !tbaa !23
  %t14 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaxisItem(ptr %v0, ptr %v1, ptr %v1, ptr %t10, i32 %t11, ptr null)
  %t15 = extractvalue { i32, ptr } %t14, 1
  %t16 = extractvalue { i32, ptr } %t14, 0
  store i32 %t16, ptr %l11
  %t17 = icmp ne i32 %t16, 0
  br i1 %t17, label %bb6, label %ok.18, !prof !99
ok.18:
  store ptr %t15, ptr %l10
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t19 = load ptr, ptr %l10, !tbaa !29
  store ptr %t19, ptr %l7, !tbaa !29
  br label %bb7
bb6:
  %t20 = load i32, ptr %l11, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 1, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  %t30 = insertvalue { i32, ptr } zeroinitializer, i32 %t28, 0
  store { i32, ptr } %t30, ptr %rv
  br label %ret
bb7:
  %t31 = load ptr, ptr %l7, !tbaa !29
  %t32 = insertvalue { i32, ptr } zeroinitializer, ptr %t31, 1
  store { i32, ptr } %t32, ptr %rv
  br label %ret
bb8:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l14, !tbaa !29
  %t34 = load i32, ptr %l1, !tbaa !23
  store i32 %t34, ptr %l15, !tbaa !23
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v1, ptr %t35)
  %t38 = extractvalue { i32, ptr } %t37, 1
  %t39 = extractvalue { i32, ptr } %t37, 0
  store i32 %t39, ptr %l19
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb10, label %ok.41, !prof !99
ok.41:
  store ptr %t38, ptr %l18
  br label %bb9
bb9:
  %t42 = load ptr, ptr %l18, !tbaa !29
  store ptr %t42, ptr %l16, !tbaa !29
  br label %bb11
bb10:
  %t43 = load i32, ptr %l19, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  %t53 = insertvalue { i32, ptr } zeroinitializer, i32 %t51, 0
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb11:
  %t54 = load ptr, ptr %l16, !tbaa !29
  %t55 = load ptr, ptr %l14, !tbaa !29
  %t56 = load i32, ptr %l15, !tbaa !23
  %t58 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaxisItem(ptr %v0, ptr %v1, ptr %v1, ptr %t55, i32 %t56, ptr %t54)
  %t59 = extractvalue { i32, ptr } %t58, 1
  %t60 = extractvalue { i32, ptr } %t58, 0
  store i32 %t60, ptr %l23
  %t61 = icmp ne i32 %t60, 0
  br i1 %t61, label %bb13, label %ok.62, !prof !99
ok.62:
  store ptr %t59, ptr %l22
  br label %bb12
bb12:
  %t63 = load ptr, ptr %l22, !tbaa !29
  store ptr %t63, ptr %l13, !tbaa !29
  br label %bb14
bb13:
  %t64 = load i32, ptr %l23, !tbaa !23
  %t65 = lshr i32 %t64, 16
  %t66 = and i32 %t64, 65535
  %t67 = icmp eq i32 %t65, 1
  %t68 = select i1 %t67, i32 1, i32 0
  %t69 = icmp eq i32 %t64, 0
  %t70 = shl i32 %t68, 16
  %t71 = or i32 %t70, %t66
  %t72 = select i1 %t69, i32 0, i32 %t71
  %t74 = insertvalue { i32, ptr } zeroinitializer, i32 %t72, 0
  store { i32, ptr } %t74, ptr %rv
  br label %ret
bb14:
  %t75 = load ptr, ptr %l13, !tbaa !29
  %t76 = insertvalue { i32, ptr } zeroinitializer, ptr %t75, 1
  store { i32, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncStmt(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 6
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/parse:Parser", ptr %t6, i32 0, i32 6
  store i64 %a1, ptr %t10, !tbaa !24
  %t11 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t11)
  br label %bb1
bb1:
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/parse:Parser", ptr %t13, i32 0, i32 6
  %t16 = load i64, ptr %t15, !tbaa !24
  %t17 = load i64, ptr %l2, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  br i1 %t20, label %bb2, label %bb3
bb2:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l2, !tbaa !24
  %t26 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 6
  store i64 %t23, ptr %t26, !tbaa !24
  %t27 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %t27)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopBranch(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca %"compiler/source:Span"
  %l8 = alloca i1
  %l9 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i32
  %l16 = alloca i1
  %l18 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l32 = alloca i64
  %l35 = alloca i64
  %l39 = alloca i1
  %l40 = alloca i1
  %l43 = alloca i1
  %l47 = alloca i32
  %l50 = alloca i32
  %l51 = alloca i32
  %l55 = alloca %"compiler/source:Span"
  %l59 = alloca { i64, ptr }
  %l63 = alloca %"compiler/ast:TopBranch"
  %s2 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t4 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t1, i32 79)
  store i1 %t4, ptr %l8
  br label %bb1
bb1:
  %t5 = load i1, ptr %l8, !tbaa !21
  br i1 %t5, label %bb2, label %bb3
bb2:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopLine(ptr %v0, ptr %v1, ptr %t6)
  %t9 = extractvalue { i32, ptr } %t8, 1
  %t10 = extractvalue { i32, ptr } %t8, 0
  store i32 %t10, ptr %l12
  %t11 = icmp ne i32 %t10, 0
  br i1 %t11, label %bb5, label %ok.12, !prof !99
ok.12:
  store ptr %t9, ptr %l11
  br label %bb4
bb3:
  br label %bb7
bb4:
  %t13 = load ptr, ptr %l11, !tbaa !29
  store ptr %t13, ptr %l9, !tbaa !29
  br label %bb6
bb5:
  %t14 = load i32, ptr %l12, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 1, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  %t24 = insertvalue { i32, ptr } zeroinitializer, i32 %t22, 0
  store { i32, ptr } %t24, ptr %rv
  br label %ret
bb6:
  %t25 = load ptr, ptr %l9, !tbaa !29
  %t26 = insertvalue { i32, ptr } zeroinitializer, ptr %t25, 1
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb7:
  %t27 = load ptr, ptr %l0, !tbaa !29
  %t30 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t27, i32 114)
  store i1 %t30, ptr %l16
  br label %bb8
bb8:
  %t31 = load i1, ptr %l16, !tbaa !21
  %t32 = xor i1 %t31, true
  br i1 %t32, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l18, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %s2, i32 114)
  store { i64, ptr } %t36, ptr %l20
  br label %bb11
bb10:
  br label %bb15
bb11:
  %t37 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t38 = load ptr, ptr %l18, !tbaa !29
  %t40 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t38, { i64, ptr } %t37)
  store i32 %t40, ptr %l22
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb13, label %ok.42, !prof !99
ok.42:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t43 = load i32, ptr %l22, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 1, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  call void @__olang_scope_close(ptr %s2)
  %t53 = insertvalue { i32, ptr } zeroinitializer, i32 %t51, 0
  store { i32, ptr } %t53, ptr %rv
  br label %ret
bb14:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb15:
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t54, i32 114)
  %t58 = extractvalue { i32, i32 } %t57, 1
  %t59 = extractvalue { i32, i32 } %t57, 0
  store i32 %t59, ptr %l28
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb17, label %ok.61, !prof !99
ok.61:
  store i32 %t58, ptr %l27
  br label %bb16
bb16:
  %t62 = load i32, ptr %l27, !tbaa !23
  store i32 %t62, ptr %l24, !tbaa !23
  br label %bb18
bb17:
  %t63 = load i32, ptr %l28, !tbaa !23
  %t64 = lshr i32 %t63, 16
  %t65 = and i32 %t63, 65535
  %t66 = icmp eq i32 %t64, 1
  %t67 = select i1 %t66, i32 1, i32 0
  %t68 = icmp eq i32 %t63, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t65
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t73 = insertvalue { i32, ptr } zeroinitializer, i32 %t71, 0
  store { i32, ptr } %t73, ptr %rv
  br label %ret
bb18:
  %t74 = load i32, ptr %l24, !tbaa !23
  store i32 %t74, ptr %l1, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t75, i32 0, i32 4
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t78)
  store i64 %t80, ptr %l32
  br label %bb19
bb19:
  %t81 = load i64, ptr %l32, !tbaa !24
  store i64 %t81, ptr %l2, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t82, i32 0, i32 41
  %t86 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t84)
  store i64 %t86, ptr %l35
  br label %bb20
bb20:
  %t87 = load i64, ptr %l35, !tbaa !24
  store i64 %t87, ptr %l3, !tbaa !24
  br label %bb21
bb21:
  %t88 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %t88)
  br label %bb22
bb22:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t93 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t90, i32 115)
  store i1 %t93, ptr %l39
  br label %bb23
bb23:
  %t94 = load i1, ptr %l39, !tbaa !21
  br i1 %t94, label %bb24, label %bb25
bb24:
  store i1 true, ptr %l40, !tbaa !21
  br label %bb27
bb25:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t98 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t95, i32 0)
  store i1 %t98, ptr %l43
  br label %bb26
bb26:
  %t99 = load i1, ptr %l43, !tbaa !21
  store i1 %t99, ptr %l40, !tbaa !21
  br label %bb27
bb27:
  %t100 = load i1, ptr %l40, !tbaa !21
  br i1 %t100, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t101 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %t101)
  br label %bb31
bb31:
  br label %bb32
bb32:
  br label %bb21
bb33:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/parse:Parser", ptr %t103, i32 0, i32 4
  %t106 = load ptr, ptr %t105, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t106)
  br label %bb34
bb34:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t111 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t108, i32 115)
  %t112 = extractvalue { i32, i32 } %t111, 1
  %t113 = extractvalue { i32, i32 } %t111, 0
  store i32 %t113, ptr %l51
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb36, label %ok.115, !prof !99
ok.115:
  store i32 %t112, ptr %l50
  br label %bb35
bb35:
  %t116 = load i32, ptr %l50, !tbaa !23
  store i32 %t116, ptr %l47, !tbaa !23
  br label %bb37
bb36:
  %t117 = load i32, ptr %l51, !tbaa !23
  %t118 = lshr i32 %t117, 16
  %t119 = and i32 %t117, 65535
  %t120 = icmp eq i32 %t118, 1
  %t121 = select i1 %t120, i32 1, i32 0
  %t122 = icmp eq i32 %t117, 0
  %t123 = shl i32 %t121, 16
  %t124 = or i32 %t123, %t119
  %t125 = select i1 %t122, i32 0, i32 %t124
  %t127 = insertvalue { i32, ptr } zeroinitializer, i32 %t125, 0
  store { i32, ptr } %t127, ptr %rv
  br label %ret
bb37:
  %t128 = load ptr, ptr %l0, !tbaa !29
  %t129 = load i32, ptr %l1, !tbaa !23
  %t132 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t128, i32 %t129)
  store %"compiler/source:Span" %t132, ptr %l55
  br label %bb38
bb38:
  %t133 = load %"compiler/source:Span", ptr %l55
  store %"compiler/source:Span" %t133, ptr %l4
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/parse:Parser", ptr %t134, i32 0, i32 41
  %t137 = load i64, ptr %l3, !tbaa !24
  %t140 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %t136, i64 %t137)
  store { i64, ptr } %t140, ptr %l59
  br label %bb39
bb39:
  %t141 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t142 = load %"compiler/source:Span", ptr %l4
  %t144 = load i64, ptr %l2, !tbaa !24
  %t148 = call %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v1, ptr %v1, %"compiler/source:Span" %t142, { i64, ptr } %t141, i64 %t144)
  store %"compiler/ast:TopBranch" %t148, ptr %l63
  br label %bb40
bb40:
  %t149 = load %"compiler/ast:TopBranch", ptr %l63
  %t150 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:TopBranch" %t149, ptr %t150
  %t152 = insertvalue { i32, ptr } zeroinitializer, ptr %t150, 1
  store { i32, ptr } %t152, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etopLine(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/token:Token"
  %l2 = alloca i32
  %l3 = alloca %"compiler/token:Token"
  %l4 = alloca i32
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca %"compiler/token:Token"
  %l17 = alloca %"compiler/token:Token"
  %l19 = alloca i32
  %l21 = alloca i32
  %l23 = alloca %"compiler/token:Token"
  %l27 = alloca i32
  %l30 = alloca i1
  %l31 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i1
  %l39 = alloca i32
  %l42 = alloca ptr
  %l43 = alloca i32
  %l44 = alloca i32
  %l45 = alloca %"compiler/diagmsg:Msg"
  %l49 = alloca i64
  %l52 = alloca i64
  %l69 = alloca i64
  %l72 = alloca i64
  %l92 = alloca { i64, ptr }
  %l97 = alloca i1
  %l101 = alloca i32
  %l104 = alloca ptr
  %l105 = alloca i32
  %l106 = alloca i32
  %l107 = alloca %"compiler/diagmsg:Msg"
  %l114 = alloca %"compiler/source:Span"
  %l118 = alloca { i64, ptr }
  %l120 = alloca %"compiler/ast:TopBranch"
  %rv = alloca { i32, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t1)
  store %"compiler/token:Token" %t3, ptr %l17
  br label %bb1
bb1:
  %t4 = load %"compiler/token:Token", ptr %l17
  store %"compiler/token:Token" %t4, ptr %l1
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t5)
  store i32 %t7, ptr %l19
  br label %bb2
bb2:
  %t8 = load i32, ptr %l19, !tbaa !23
  store i32 %t8, ptr %l2, !tbaa !23
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t9)
  store i32 %t11, ptr %l21
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %t12)
  store %"compiler/token:Token" %t14, ptr %l23
  br label %bb4
bb4:
  %t15 = load %"compiler/token:Token", ptr %l23
  store %"compiler/token:Token" %t15, ptr %l3
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/parse:Parser", ptr %t16, i32 0, i32 0
  %t19 = load ptr, ptr %t18, !tbaa !29
  %t20 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t21 = load i32, ptr %t20, !tbaa !23
  %t24 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t19, i32 %t21)
  store i32 %t24, ptr %l27
  br label %bb5
bb5:
  %t25 = load i32, ptr %l27, !tbaa !23
  store i32 %t25, ptr %l4, !tbaa !23
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t29 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t26, i32 8)
  store i1 %t29, ptr %l30
  br label %bb6
bb6:
  %t30 = load i1, ptr %l30, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb10
bb8:
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t31, i32 0)
  store i1 %t34, ptr %l34
  br label %bb9
bb9:
  %t35 = load i1, ptr %l34, !tbaa !21
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb10
bb10:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb14
bb12:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/parse:Parser", ptr %t37, i32 0, i32 0
  %t40 = load ptr, ptr %t39, !tbaa !29
  %t41 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t42 = load i32, ptr %t41, !tbaa !23
  %t45 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t40, i32 %t42)
  store i32 %t45, ptr %l39
  br label %bb13
bb13:
  %t46 = load i32, ptr %l4, !tbaa !23
  %t47 = load i32, ptr %l39, !tbaa !23
  %t49 = icmp ne i32 %t47, %t46
  store i1 %t49, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t51 = load i1, ptr %l35, !tbaa !21
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l42, !tbaa !29
  %t53 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 2
  %t54 = load i32, ptr %t53, !tbaa !23
  store i32 %t54, ptr %l43, !tbaa !23
  %t55 = getelementptr %"compiler/token:Token", ptr %l1, i32 0, i32 3
  %t56 = load i32, ptr %t55, !tbaa !23
  store i32 %t56, ptr %l44, !tbaa !23
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0)
  store %"compiler/diagmsg:Msg" %t57, ptr %l45
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t58 = load ptr, ptr %l42, !tbaa !29
  %t59 = load i32, ptr %l43, !tbaa !23
  %t60 = load i32, ptr %l44, !tbaa !23
  %t61 = load %"compiler/diagmsg:Msg", ptr %l45
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t58, i32 %t59, i32 %t60, %"compiler/diagmsg:Msg" %t61)
  br label %bb18
bb18:
  %t63 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t63, ptr %rv
  br label %ret
bb19:
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/parse:Parser", ptr %t64, i32 0, i32 4
  %t67 = load ptr, ptr %t66, !tbaa !29
  %t69 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %t67)
  store i64 %t69, ptr %l49
  br label %bb20
bb20:
  %t70 = load i64, ptr %l49, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  %t71 = load ptr, ptr %l0, !tbaa !29
  %t73 = getelementptr %"compiler/parse:Parser", ptr %t71, i32 0, i32 41
  %t75 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %t73)
  store i64 %t75, ptr %l52
  br label %bb21
bb21:
  %t76 = load i64, ptr %l52, !tbaa !24
  store i64 %t76, ptr %l6, !tbaa !24
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/parse:Parser", ptr %t77, i32 0, i32 6
  %t80 = load i64, ptr %t79, !tbaa !24
  store i64 %t80, ptr %l7, !tbaa !24
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/parse:Parser", ptr %t82, i32 0, i32 15
  %t85 = load i1, ptr %t84, !tbaa !21
  store i1 %t85, ptr %l8, !tbaa !21
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/parse:Parser", ptr %t87, i32 0, i32 15
  store i1 true, ptr %t89, !tbaa !21
  %t90 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %t90)
  br label %bb22
bb22:
  %t92 = load ptr, ptr %l0, !tbaa !29
  %t93 = load i1, ptr %l8, !tbaa !21
  %t96 = getelementptr %"compiler/parse:Parser", ptr %t92, i32 0, i32 15
  store i1 %t93, ptr %t96, !tbaa !21
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/parse:Parser", ptr %t97, i32 0, i32 4
  %t100 = load ptr, ptr %t99, !tbaa !29
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %t100)
  br label %bb23
bb23:
  %t102 = load i64, ptr %l7, !tbaa !24
  store i64 %t102, ptr %l9, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"compiler/parse:Parser", ptr %t104, i32 0, i32 6
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l10, !tbaa !24
  store i64 1, ptr %l11, !tbaa !24
  %t109 = load i64, ptr %l10, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t113 = icmp sgt i64 %t109, %t110
  br i1 %t113, label %bb24, label %bb25
bb24:
  %t115 = load i64, ptr %l11, !tbaa !24
  %t117 = icmp sgt i64 %t115, 0
  br i1 %t117, label %bb26, label %bb27
bb25:
  store i64 0, ptr %l69, !tbaa !24
  br label %bb29
bb26:
  %t119 = load i64, ptr %l10, !tbaa !24
  %t120 = load i64, ptr %l9, !tbaa !24
  %t123 = sub i64 %t119, %t120
  %t124 = load i64, ptr %l11, !tbaa !24
  %t127 = add i64 %t123, %t124
  %t129 = sub i64 %t127, 1
  %t130 = load i64, ptr %l11, !tbaa !24
  %t133 = sdiv i64 %t129, %t130
  store i64 %t133, ptr %l72, !tbaa !24
  br label %bb28
bb27:
  store i64 0, ptr %l72, !tbaa !24
  br label %bb28
bb28:
  %t135 = load i64, ptr %l72, !tbaa !24
  store i64 %t135, ptr %l69, !tbaa !24
  br label %bb29
bb29:
  %t136 = load i64, ptr %l69, !tbaa !24
  store i64 %t136, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb30
bb30:
  %t137 = load i64, ptr %l13, !tbaa !24
  %t138 = load i64, ptr %l12, !tbaa !24
  %t141 = icmp slt i64 %t137, %t138
  %t143 = xor i1 %t141, true
  br i1 %t143, label %bb31, label %bb32
bb31:
  br label %bb44
bb32:
  br label %bb33
bb33:
  %t145 = load i64, ptr %l9, !tbaa !24
  %t146 = load i64, ptr %l13, !tbaa !24
  %t147 = load i64, ptr %l11, !tbaa !24
  %t150 = mul i64 %t146, %t147
  %t153 = add i64 %t145, %t150
  %t155 = load ptr, ptr %l0, !tbaa !29
  %t157 = getelementptr %"compiler/parse:Parser", ptr %t155, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !29
  %t160 = getelementptr %"compiler/scan:Tokens", ptr %t158, i32 0, i32 0
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !27
  store { i64, ptr } %t161, ptr %l92, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr %"compiler/token:Token", ptr %t165, i64 %t153
  %t167 = load %"compiler/token:Token", ptr %t166
  store %"compiler/token:Token" %t167, ptr %l15
  %t169 = getelementptr %"compiler/token:Token", ptr %l15, i32 0, i32 0
  %t170 = load i32, ptr %t169, !range !{i32 0, i32 116}
  %t172 = trunc i64 8 to i32
  %t173 = icmp eq i32 %t170, %t172
  br i1 %t173, label %bb34, label %bb35
bb34:
  store i1 true, ptr %l97, !tbaa !21
  br label %bb37
bb35:
  %t175 = load ptr, ptr %l0, !tbaa !29
  %t177 = getelementptr %"compiler/parse:Parser", ptr %t175, i32 0, i32 0
  %t178 = load ptr, ptr %t177, !tbaa !29
  %t179 = getelementptr %"compiler/token:Token", ptr %l15, i32 0, i32 2
  %t180 = load i32, ptr %t179, !tbaa !23
  %t183 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %t178, i32 %t180)
  store i32 %t183, ptr %l101
  br label %bb36
bb36:
  %t184 = load i32, ptr %l4, !tbaa !23
  %t185 = load i32, ptr %l101, !tbaa !23
  %t187 = icmp eq i32 %t185, %t184
  store i1 %t187, ptr %l97, !tbaa !21
  br label %bb37
bb37:
  %t189 = load i1, ptr %l97, !tbaa !21
  br i1 %t189, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t190 = load ptr, ptr %l0, !tbaa !29
  store ptr %t190, ptr %l104, !tbaa !29
  %t191 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 2
  %t192 = load i32, ptr %t191, !tbaa !23
  store i32 %t192, ptr %l105, !tbaa !23
  %t193 = getelementptr %"compiler/token:Token", ptr %l3, i32 0, i32 3
  %t194 = load i32, ptr %t193, !tbaa !23
  store i32 %t194, ptr %l106, !tbaa !23
  %t195 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopLineOne(ptr %v0)
  store %"compiler/diagmsg:Msg" %t195, ptr %l107
  br label %bb41
bb41:
  %t196 = load ptr, ptr %l104, !tbaa !29
  %t197 = load i32, ptr %l105, !tbaa !23
  %t198 = load i32, ptr %l106, !tbaa !23
  %t199 = load %"compiler/diagmsg:Msg", ptr %l107
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t196, i32 %t197, i32 %t198, %"compiler/diagmsg:Msg" %t199)
  br label %bb42
bb42:
  %t201 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t201, ptr %rv
  br label %ret
bb43:
  %t202 = load i64, ptr %l13, !tbaa !24
  %t205 = add i64 %t202, 1
  store i64 %t205, ptr %l13, !tbaa !24
  br label %bb30
bb44:
  %t207 = load ptr, ptr %l0, !tbaa !29
  %t208 = load i32, ptr %l2, !tbaa !23
  %t211 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t207, i32 %t208)
  store %"compiler/source:Span" %t211, ptr %l114
  br label %bb45
bb45:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = getelementptr %"compiler/parse:Parser", ptr %t212, i32 0, i32 41
  %t215 = load i64, ptr %l6, !tbaa !24
  %t218 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v0, ptr %t214, i64 %t215)
  store { i64, ptr } %t218, ptr %l118
  br label %bb46
bb46:
  %t219 = load i64, ptr %l5, !tbaa !24
  %t220 = load %"compiler/source:Span", ptr %l114
  %t221 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t223 = call %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %t220, { i64, ptr } %t221, i64 %t219)
  store %"compiler/ast:TopBranch" %t223, ptr %l120
  br label %bb47
bb47:
  %t224 = load %"compiler/ast:TopBranch", ptr %l120
  %t225 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"compiler/ast:TopBranch" %t224, ptr %t225
  %t227 = insertvalue { i32, ptr } zeroinitializer, ptr %t225, 1
  store { i32, ptr } %t227, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etryStmt(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %lp5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/source:Span"
  %l8 = alloca ptr
  %l9 = alloca i32
  %l10 = alloca ptr
  %lp11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/source:Span"
  %l14 = alloca i32
  %lp15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/source:Span"
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca %"compiler/source:Span"
  %l23 = alloca i32
  %l37 = alloca i1
  %l38 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i32
  %l47 = alloca %"compiler/source:Span"
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l60 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca i32
  %l68 = alloca %"compiler/source:Span"
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l80 = alloca %"compiler/source:Span"
  %l82 = alloca i32
  %l93 = alloca ptr
  %l95 = alloca ptr
  %l96 = alloca i32
  %l101 = alloca i32
  %l103 = alloca i1
  %l105 = alloca i32
  %l106 = alloca ptr
  %l108 = alloca ptr
  %l109 = alloca i32
  %l114 = alloca %"compiler/source:Span"
  %l118 = alloca %"compiler/source:Span"
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca i32
  %l132 = alloca %"compiler/source:Span"
  %l134 = alloca i32
  %l145 = alloca ptr
  %l146 = alloca i1
  %l153 = alloca i1
  %l157 = alloca %"compiler/source:Span"
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l163 = alloca i32
  %l169 = alloca %"compiler/source:Span"
  %l171 = alloca i32
  %l182 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i32
  %l190 = alloca ptr
  %l193 = alloca ptr
  %l194 = alloca i32
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l203 = alloca i32
  %l210 = alloca i1
  %l220 = alloca %"compiler/source:Span"
  %l227 = alloca %"compiler/source:Span"
  %l229 = alloca i32
  %rv = alloca { i32, ptr }
  %t67 = alloca { i64, [4 x i64] }, align 8
  %t124 = alloca { i64, [4 x i64] }, align 8
  %t190 = alloca { i64, [4 x i64] }, align 8
  %t285 = alloca { i64, [4 x i64] }, align 8
  %t355 = alloca { i64, [4 x i64] }, align 8
  %t404 = alloca { i64, [4 x i64] }, align 8
  %t470 = alloca { i64, [4 x i64] }, align 8
  %t602 = alloca { i64, [4 x i64] }, align 8
  %t644 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l23
  br label %bb1
bb1:
  %t4 = load i32, ptr %l23, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 24
  %t8 = load i64, ptr %t7, !tbaa !24
  %t10 = add i64 %t8, 2
  %t11 = load i64, ptr @G_2ecompiler_2fparse_2eMaxNesting, !tbaa !24
  %t14 = icmp sgt i64 %t10, %t11
  br i1 %t14, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 6
  %t20 = load i64, ptr %t19, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t16, i64 %t20)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/parse:Parser", ptr %t23, i32 0, i32 26
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l2, !tbaa !24
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t30 = getelementptr %"compiler/parse:Parser", ptr %t28, i32 0, i32 26
  store i64 -1, ptr %t30, !tbaa !24
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t31, i32 14)
  store i1 %t34, ptr %l37
  br label %bb6
bb6:
  %t35 = load i1, ptr %l37, !tbaa !21
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t36 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %v1, ptr %t36, i1 true)
  %t39 = extractvalue { i32, ptr } %t38, 1
  %t40 = extractvalue { i32, ptr } %t38, 0
  store i32 %t40, ptr %l41
  %t41 = icmp ne i32 %t40, 0
  br i1 %t41, label %bb10, label %ok.42, !prof !99
ok.42:
  store ptr %t39, ptr %l40
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t43 = load ptr, ptr %l40, !tbaa !29
  store ptr %t43, ptr %l38, !tbaa !29
  br label %bb11
bb10:
  %t44 = load i32, ptr %l41, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 1, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t54 = load i64, ptr %l2, !tbaa !24
  %t57 = getelementptr %"compiler/parse:Parser", ptr %t53, i32 0, i32 26
  store i64 %t54, ptr %t57, !tbaa !24
  %t59 = insertvalue { i32, ptr } zeroinitializer, i32 %t52, 0
  store { i32, ptr } %t59, ptr %rv
  br label %ret
bb11:
  %t60 = load ptr, ptr %l38, !tbaa !29
  store ptr %t60, ptr %l3, !tbaa !29
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t62 = load i32, ptr %l1, !tbaa !23
  %t65 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t61, i32 %t62)
  store %"compiler/source:Span" %t65, ptr %l47
  br label %bb12
bb12:
  %t66 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 0
  store i64 18, ptr %t68
  %t69 = load %"compiler/source:Span", ptr %l47
  %t70 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t69, 0
  %t72 = insertvalue { %"compiler/source:Span", ptr } %t70, ptr %t66, 1
  %t73 = getelementptr { i64, [4 x i64] }, ptr %t67, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t72, ptr %t73
  %t74 = load { i64, [4 x i64] }, ptr %t67
  %t76 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t74, ptr %t76
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load i64, ptr %l2, !tbaa !24
  %t81 = getelementptr %"compiler/parse:Parser", ptr %t77, i32 0, i32 26
  store i64 %t78, ptr %t81, !tbaa !24
  %t83 = insertvalue { i32, ptr } zeroinitializer, ptr %t76, 1
  store { i32, ptr } %t83, ptr %rv
  br label %ret
bb13:
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t87 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t84, i32 93)
  store i1 %t87, ptr %l55
  br label %bb14
bb14:
  %t88 = load i1, ptr %l55, !tbaa !21
  br i1 %t88, label %bb15, label %bb16
bb15:
  store i1 true, ptr %l56, !tbaa !21
  br label %bb18
bb16:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t92 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t89, i32 94)
  store i1 %t92, ptr %l59
  br label %bb17
bb17:
  %t93 = load i1, ptr %l59, !tbaa !21
  store i1 %t93, ptr %l56, !tbaa !21
  br label %bb18
bb18:
  %t94 = load i1, ptr %l56, !tbaa !21
  br i1 %t94, label %bb19, label %bb20
bb19:
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t95)
  %t98 = extractvalue { i32, ptr } %t97, 1
  %t99 = extractvalue { i32, ptr } %t97, 0
  store i32 %t99, ptr %l63
  %t100 = icmp ne i32 %t99, 0
  br i1 %t100, label %bb22, label %ok.101, !prof !99
ok.101:
  store ptr %t98, ptr %l62
  br label %bb21
bb20:
  br label %bb32
bb21:
  %t102 = load ptr, ptr %l62, !tbaa !29
  store ptr %t102, ptr %l60, !tbaa !29
  br label %bb23
bb22:
  %t103 = load i32, ptr %l63, !tbaa !23
  %t104 = lshr i32 %t103, 16
  %t105 = and i32 %t103, 65535
  %t106 = icmp eq i32 %t104, 1
  %t107 = select i1 %t106, i32 1, i32 0
  %t108 = icmp eq i32 %t103, 0
  %t109 = shl i32 %t107, 16
  %t110 = or i32 %t109, %t105
  %t111 = select i1 %t108, i32 0, i32 %t110
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t113 = load i64, ptr %l2, !tbaa !24
  %t116 = getelementptr %"compiler/parse:Parser", ptr %t112, i32 0, i32 26
  store i64 %t113, ptr %t116, !tbaa !24
  %t118 = insertvalue { i32, ptr } zeroinitializer, i32 %t111, 0
  store { i32, ptr } %t118, ptr %rv
  br label %ret
bb23:
  %t119 = load ptr, ptr %l60, !tbaa !29
  store ptr %t119, ptr %l4, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t122 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t120)
  store %"compiler/source:Span" %t122, ptr %l68
  br label %bb24
bb24:
  %t123 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t124
  %t125 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 0
  store i64 0, ptr %t125
  %t126 = load %"compiler/source:Span", ptr %l68
  %t127 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t126, 0
  %t129 = insertvalue { %"compiler/source:Span", ptr } %t127, ptr %t123, 1
  %t130 = getelementptr { i64, [4 x i64] }, ptr %t124, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t129, ptr %t130
  %t131 = load { i64, [4 x i64] }, ptr %t124
  %t132 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t132, ptr %lp5
  %t134 = load ptr, ptr %lp5
  store { i64, [4 x i64] } %t131, ptr %t134
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t137 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t135, i1 false)
  %t138 = extractvalue { i32, { i64, ptr } } %t137, 1
  %t139 = extractvalue { i32, { i64, ptr } } %t137, 0
  store i32 %t139, ptr %l74
  %t140 = icmp ne i32 %t139, 0
  br i1 %t140, label %bb26, label %ok.141, !prof !99
ok.141:
  store { i64, ptr } %t138, ptr %l73
  br label %bb25
bb25:
  %t142 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t142, ptr %l71, !tbaa !27
  br label %bb27
bb26:
  %t143 = load i32, ptr %l74, !tbaa !23
  %t144 = lshr i32 %t143, 16
  %t145 = and i32 %t143, 65535
  %t146 = icmp eq i32 %t144, 1
  %t147 = select i1 %t146, i32 1, i32 0
  %t148 = icmp eq i32 %t143, 0
  %t149 = shl i32 %t147, 16
  %t150 = or i32 %t149, %t145
  %t151 = select i1 %t148, i32 0, i32 %t150
  %t152 = load ptr, ptr %l0, !tbaa !29
  %t153 = load i64, ptr %l2, !tbaa !24
  %t156 = getelementptr %"compiler/parse:Parser", ptr %t152, i32 0, i32 26
  store i64 %t153, ptr %t156, !tbaa !24
  %t158 = insertvalue { i32, ptr } zeroinitializer, i32 %t151, 0
  store { i32, ptr } %t158, ptr %rv
  br label %ret
bb27:
  %t159 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t159, ptr %l6, !tbaa !27
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load i32, ptr %l1, !tbaa !23
  %t164 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t160, i32 %t161)
  store %"compiler/source:Span" %t164, ptr %l80
  br label %bb28
bb28:
  %t165 = load %"compiler/source:Span", ptr %l80
  store %"compiler/source:Span" %t165, ptr %l7
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t168 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t166)
  store i32 %t168, ptr %l82
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb30, label %ok.170, !prof !99
ok.170:
  br label %bb29
bb29:
  br label %bb31
bb30:
  %t171 = load i32, ptr %l82, !tbaa !23
  %t172 = lshr i32 %t171, 16
  %t173 = and i32 %t171, 65535
  %t174 = icmp eq i32 %t172, 1
  %t175 = select i1 %t174, i32 1, i32 0
  %t176 = icmp eq i32 %t171, 0
  %t177 = shl i32 %t175, 16
  %t178 = or i32 %t177, %t173
  %t179 = select i1 %t176, i32 0, i32 %t178
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t181 = load i64, ptr %l2, !tbaa !24
  %t184 = getelementptr %"compiler/parse:Parser", ptr %t180, i32 0, i32 26
  store i64 %t181, ptr %t184, !tbaa !24
  %t186 = insertvalue { i32, ptr } zeroinitializer, i32 %t179, 0
  store { i32, ptr } %t186, ptr %rv
  br label %ret
bb31:
  %t187 = load %"compiler/source:Span", ptr %l7
  %t188 = load ptr, ptr %lp5
  %t189 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t190
  %t191 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 0
  store i64 4, ptr %t191
  %t193 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t187, 0
  %t195 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t193, ptr %t188, 1
  %t197 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t195, { i64, ptr } %t189, 2
  %t198 = getelementptr { i64, [4 x i64] }, ptr %t190, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t197, ptr %t198
  %t199 = load { i64, [4 x i64] }, ptr %t190
  %t201 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t199, ptr %t201
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t203 = load i64, ptr %l2, !tbaa !24
  %t206 = getelementptr %"compiler/parse:Parser", ptr %t202, i32 0, i32 26
  store i64 %t203, ptr %t206, !tbaa !24
  %t208 = insertvalue { i32, ptr } zeroinitializer, ptr %t201, 1
  store { i32, ptr } %t208, ptr %rv
  br label %ret
bb32:
  %t209 = load ptr, ptr %l0, !tbaa !29
  %t211 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t209)
  %t212 = extractvalue { i32, ptr } %t211, 1
  %t213 = extractvalue { i32, ptr } %t211, 0
  store i32 %t213, ptr %l96
  %t214 = icmp ne i32 %t213, 0
  br i1 %t214, label %bb34, label %ok.215, !prof !99
ok.215:
  store ptr %t212, ptr %l95
  br label %bb33
bb33:
  %t216 = load ptr, ptr %l95, !tbaa !29
  store ptr %t216, ptr %l93, !tbaa !29
  br label %bb35
bb34:
  %t217 = load i32, ptr %l96, !tbaa !23
  %t218 = lshr i32 %t217, 16
  %t219 = and i32 %t217, 65535
  %t220 = icmp eq i32 %t218, 1
  %t221 = select i1 %t220, i32 1, i32 0
  %t222 = icmp eq i32 %t217, 0
  %t223 = shl i32 %t221, 16
  %t224 = or i32 %t223, %t219
  %t225 = select i1 %t222, i32 0, i32 %t224
  %t226 = load ptr, ptr %l0, !tbaa !29
  %t227 = load i64, ptr %l2, !tbaa !24
  %t230 = getelementptr %"compiler/parse:Parser", ptr %t226, i32 0, i32 26
  store i64 %t227, ptr %t230, !tbaa !24
  %t232 = insertvalue { i32, ptr } zeroinitializer, i32 %t225, 0
  store { i32, ptr } %t232, ptr %rv
  br label %ret
bb35:
  %t233 = load ptr, ptr %l93, !tbaa !29
  store ptr %t233, ptr %l8, !tbaa !29
  %t234 = load ptr, ptr %l0, !tbaa !29
  %t236 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t234)
  store i32 %t236, ptr %l101
  br label %bb36
bb36:
  %t237 = load i32, ptr %l101, !range !{i32 0, i32 116}
  store i32 %t237, ptr %l9
  %t238 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t240 = call i1 @compiler_2fparse_2eisAssignOp(i32 %t238)
  store i1 %t240, ptr %l103
  br label %bb37
bb37:
  %t241 = load i1, ptr %l103, !tbaa !21
  br i1 %t241, label %bb38, label %bb39
bb38:
  %t242 = load ptr, ptr %l0, !tbaa !29
  %t244 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t242)
  store i32 %t244, ptr %l105
  br label %bb40
bb39:
  br label %bb53
bb40:
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %t245)
  %t248 = extractvalue { i32, ptr } %t247, 1
  %t249 = extractvalue { i32, ptr } %t247, 0
  store i32 %t249, ptr %l109
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb42, label %ok.251, !prof !99
ok.251:
  store ptr %t248, ptr %l108
  br label %bb41
bb41:
  %t252 = load ptr, ptr %l108, !tbaa !29
  store ptr %t252, ptr %l106, !tbaa !29
  br label %bb43
bb42:
  %t253 = load i32, ptr %l109, !tbaa !23
  %t254 = lshr i32 %t253, 16
  %t255 = and i32 %t253, 65535
  %t256 = icmp eq i32 %t254, 1
  %t257 = select i1 %t256, i32 1, i32 0
  %t258 = icmp eq i32 %t253, 0
  %t259 = shl i32 %t257, 16
  %t260 = or i32 %t259, %t255
  %t261 = select i1 %t258, i32 0, i32 %t260
  %t262 = load ptr, ptr %l0, !tbaa !29
  %t263 = load i64, ptr %l2, !tbaa !24
  %t266 = getelementptr %"compiler/parse:Parser", ptr %t262, i32 0, i32 26
  store i64 %t263, ptr %t266, !tbaa !24
  %t268 = insertvalue { i32, ptr } zeroinitializer, i32 %t261, 0
  store { i32, ptr } %t268, ptr %rv
  br label %ret
bb43:
  %t269 = load ptr, ptr %l106, !tbaa !29
  store ptr %t269, ptr %l10, !tbaa !29
  %t270 = load ptr, ptr %l8, !tbaa !29
  %t272 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t270)
  store %"compiler/source:Span" %t272, ptr %l114
  br label %bb44
bb44:
  %t273 = getelementptr %"compiler/source:Span", ptr %l114, i32 0, i32 0
  %t274 = load i32, ptr %t273, !tbaa !23
  %t275 = load ptr, ptr %l0, !tbaa !29
  %t277 = getelementptr %"compiler/parse:Parser", ptr %t275, i32 0, i32 10
  %t278 = load i32, ptr %t277, !tbaa !23
  %t281 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v1, i32 %t274, i32 %t278)
  store %"compiler/source:Span" %t281, ptr %l118
  br label %bb45
bb45:
  %t282 = load i32, ptr %l9, !range !{i32 0, i32 116}
  %t283 = load ptr, ptr %l8, !tbaa !29
  %t284 = load ptr, ptr %l10, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t285
  %t286 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 0
  store i64 3, ptr %t286
  %t287 = load %"compiler/source:Span", ptr %l118
  %t288 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } undef, %"compiler/source:Span" %t287, 0
  %t290 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t288, i32 %t282, 1
  %t292 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t290, ptr %t283, 2
  %t294 = insertvalue { %"compiler/source:Span", i32, ptr, ptr } %t292, ptr %t284, 3
  %t295 = getelementptr { i64, [4 x i64] }, ptr %t285, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr, ptr } %t294, ptr %t295
  %t296 = load { i64, [4 x i64] }, ptr %t285
  %t297 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t297, ptr %lp11
  %t299 = load ptr, ptr %lp11
  store { i64, [4 x i64] } %t296, ptr %t299
  %t300 = load ptr, ptr %l0, !tbaa !29
  %t302 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t300, i1 false)
  %t303 = extractvalue { i32, { i64, ptr } } %t302, 1
  %t304 = extractvalue { i32, { i64, ptr } } %t302, 0
  store i32 %t304, ptr %l126
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb47, label %ok.306, !prof !99
ok.306:
  store { i64, ptr } %t303, ptr %l125
  br label %bb46
bb46:
  %t307 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t307, ptr %l123, !tbaa !27
  br label %bb48
bb47:
  %t308 = load i32, ptr %l126, !tbaa !23
  %t309 = lshr i32 %t308, 16
  %t310 = and i32 %t308, 65535
  %t311 = icmp eq i32 %t309, 1
  %t312 = select i1 %t311, i32 1, i32 0
  %t313 = icmp eq i32 %t308, 0
  %t314 = shl i32 %t312, 16
  %t315 = or i32 %t314, %t310
  %t316 = select i1 %t313, i32 0, i32 %t315
  %t317 = load ptr, ptr %l0, !tbaa !29
  %t318 = load i64, ptr %l2, !tbaa !24
  %t321 = getelementptr %"compiler/parse:Parser", ptr %t317, i32 0, i32 26
  store i64 %t318, ptr %t321, !tbaa !24
  %t323 = insertvalue { i32, ptr } zeroinitializer, i32 %t316, 0
  store { i32, ptr } %t323, ptr %rv
  br label %ret
bb48:
  %t324 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t324, ptr %l12, !tbaa !27
  %t325 = load ptr, ptr %l0, !tbaa !29
  %t326 = load i32, ptr %l1, !tbaa !23
  %t329 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t325, i32 %t326)
  store %"compiler/source:Span" %t329, ptr %l132
  br label %bb49
bb49:
  %t330 = load %"compiler/source:Span", ptr %l132
  store %"compiler/source:Span" %t330, ptr %l13
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t333 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t331)
  store i32 %t333, ptr %l134
  %t334 = icmp ne i32 %t333, 0
  br i1 %t334, label %bb51, label %ok.335, !prof !99
ok.335:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t336 = load i32, ptr %l134, !tbaa !23
  %t337 = lshr i32 %t336, 16
  %t338 = and i32 %t336, 65535
  %t339 = icmp eq i32 %t337, 1
  %t340 = select i1 %t339, i32 1, i32 0
  %t341 = icmp eq i32 %t336, 0
  %t342 = shl i32 %t340, 16
  %t343 = or i32 %t342, %t338
  %t344 = select i1 %t341, i32 0, i32 %t343
  %t345 = load ptr, ptr %l0, !tbaa !29
  %t346 = load i64, ptr %l2, !tbaa !24
  %t349 = getelementptr %"compiler/parse:Parser", ptr %t345, i32 0, i32 26
  store i64 %t346, ptr %t349, !tbaa !24
  %t351 = insertvalue { i32, ptr } zeroinitializer, i32 %t344, 0
  store { i32, ptr } %t351, ptr %rv
  br label %ret
bb52:
  %t352 = load %"compiler/source:Span", ptr %l13
  %t353 = load ptr, ptr %lp11
  %t354 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t355
  %t356 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 0
  store i64 4, ptr %t356
  %t358 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t352, 0
  %t360 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t358, ptr %t353, 1
  %t362 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t360, { i64, ptr } %t354, 2
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t355, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t362, ptr %t363
  %t364 = load { i64, [4 x i64] }, ptr %t355
  %t366 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t364, ptr %t366
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t368 = load i64, ptr %l2, !tbaa !24
  %t371 = getelementptr %"compiler/parse:Parser", ptr %t367, i32 0, i32 26
  store i64 %t368, ptr %t371, !tbaa !24
  %t373 = insertvalue { i32, ptr } zeroinitializer, ptr %t366, 1
  store { i32, ptr } %t373, ptr %rv
  br label %ret
bb53:
  %t374 = load ptr, ptr %l8, !tbaa !29
  store ptr %t374, ptr %l145, !tbaa !29
  store i1 false, ptr %l146, !tbaa !21
  %t375 = load ptr, ptr %l145, !tbaa !29
  %t376 = icmp ne ptr %t375, null
  br i1 %t376, label %bb54, label %bb55
bb54:
  %t378 = load ptr, ptr %l145, !tbaa !29
  %t379 = load i64, ptr %t378, !range !{i64 0, i64 28}
  %t381 = icmp eq i64 %t379, 4
  store i1 %t381, ptr %l146, !tbaa !21
  br label %bb55
bb55:
  %t382 = load i1, ptr %l146, !tbaa !21
  br i1 %t382, label %bb56, label %bb57
bb56:
  %t383 = load ptr, ptr %l8, !tbaa !29
  %t385 = getelementptr { i64, [4 x i64] }, ptr %t383, i32 0, i32 1
  %t386 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t385, i32 0, i32 1
  %t387 = load i32, ptr %t386, !range !{i32 0, i32 116}
  store i32 %t387, ptr %l14
  br label %bb58
bb57:
  br label %bb73
bb58:
  %t389 = load i32, ptr %l14, !range !{i32 0, i32 116}
  %t391 = trunc i64 93 to i32
  %t392 = icmp eq i32 %t389, %t391
  br i1 %t392, label %bb59, label %bb60
bb59:
  store i1 true, ptr %l153, !tbaa !21
  br label %bb61
bb60:
  %t394 = load i32, ptr %l14, !range !{i32 0, i32 116}
  %t396 = trunc i64 94 to i32
  %t397 = icmp eq i32 %t394, %t396
  store i1 %t397, ptr %l153, !tbaa !21
  br label %bb61
bb61:
  %t399 = load i1, ptr %l153, !tbaa !21
  br i1 %t399, label %bb62, label %bb63
bb62:
  %t400 = load ptr, ptr %l8, !tbaa !29
  %t402 = call %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v1, ptr %t400)
  store %"compiler/source:Span" %t402, ptr %l157
  br label %bb64
bb63:
  br label %bb72
bb64:
  %t403 = load ptr, ptr %l8, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t404
  %t405 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 0
  store i64 0, ptr %t405
  %t406 = load %"compiler/source:Span", ptr %l157
  %t407 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t406, 0
  %t409 = insertvalue { %"compiler/source:Span", ptr } %t407, ptr %t403, 1
  %t410 = getelementptr { i64, [4 x i64] }, ptr %t404, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t409, ptr %t410
  %t411 = load { i64, [4 x i64] }, ptr %t404
  %t412 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store ptr %t412, ptr %lp15
  %t414 = load ptr, ptr %lp15
  store { i64, [4 x i64] } %t411, ptr %t414
  %t415 = load ptr, ptr %l0, !tbaa !29
  %t417 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t415, i1 false)
  %t418 = extractvalue { i32, { i64, ptr } } %t417, 1
  %t419 = extractvalue { i32, { i64, ptr } } %t417, 0
  store i32 %t419, ptr %l163
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb66, label %ok.421, !prof !99
ok.421:
  store { i64, ptr } %t418, ptr %l162
  br label %bb65
bb65:
  %t422 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t422, ptr %l160, !tbaa !27
  br label %bb67
bb66:
  %t423 = load i32, ptr %l163, !tbaa !23
  %t424 = lshr i32 %t423, 16
  %t425 = and i32 %t423, 65535
  %t426 = icmp eq i32 %t424, 1
  %t427 = select i1 %t426, i32 1, i32 0
  %t428 = icmp eq i32 %t423, 0
  %t429 = shl i32 %t427, 16
  %t430 = or i32 %t429, %t425
  %t431 = select i1 %t428, i32 0, i32 %t430
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load i64, ptr %l2, !tbaa !24
  %t436 = getelementptr %"compiler/parse:Parser", ptr %t432, i32 0, i32 26
  store i64 %t433, ptr %t436, !tbaa !24
  %t438 = insertvalue { i32, ptr } zeroinitializer, i32 %t431, 0
  store { i32, ptr } %t438, ptr %rv
  br label %ret
bb67:
  %t439 = load { i64, ptr }, ptr %l160, !tbaa !27
  store { i64, ptr } %t439, ptr %l16, !tbaa !27
  %t440 = load ptr, ptr %l0, !tbaa !29
  %t441 = load i32, ptr %l1, !tbaa !23
  %t444 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t440, i32 %t441)
  store %"compiler/source:Span" %t444, ptr %l169
  br label %bb68
bb68:
  %t445 = load %"compiler/source:Span", ptr %l169
  store %"compiler/source:Span" %t445, ptr %l17
  %t446 = load ptr, ptr %l0, !tbaa !29
  %t448 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t446)
  store i32 %t448, ptr %l171
  %t449 = icmp ne i32 %t448, 0
  br i1 %t449, label %bb70, label %ok.450, !prof !99
ok.450:
  br label %bb69
bb69:
  br label %bb71
bb70:
  %t451 = load i32, ptr %l171, !tbaa !23
  %t452 = lshr i32 %t451, 16
  %t453 = and i32 %t451, 65535
  %t454 = icmp eq i32 %t452, 1
  %t455 = select i1 %t454, i32 1, i32 0
  %t456 = icmp eq i32 %t451, 0
  %t457 = shl i32 %t455, 16
  %t458 = or i32 %t457, %t453
  %t459 = select i1 %t456, i32 0, i32 %t458
  %t460 = load ptr, ptr %l0, !tbaa !29
  %t461 = load i64, ptr %l2, !tbaa !24
  %t464 = getelementptr %"compiler/parse:Parser", ptr %t460, i32 0, i32 26
  store i64 %t461, ptr %t464, !tbaa !24
  %t466 = insertvalue { i32, ptr } zeroinitializer, i32 %t459, 0
  store { i32, ptr } %t466, ptr %rv
  br label %ret
bb71:
  %t467 = load %"compiler/source:Span", ptr %l17
  %t468 = load ptr, ptr %lp15
  %t469 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t470
  %t471 = getelementptr { i64, [4 x i64] }, ptr %t470, i32 0, i32 0
  store i64 4, ptr %t471
  %t473 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t467, 0
  %t475 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t473, ptr %t468, 1
  %t477 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t475, { i64, ptr } %t469, 2
  %t478 = getelementptr { i64, [4 x i64] }, ptr %t470, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t477, ptr %t478
  %t479 = load { i64, [4 x i64] }, ptr %t470
  %t481 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t479, ptr %t481
  %t482 = load ptr, ptr %l0, !tbaa !29
  %t483 = load i64, ptr %l2, !tbaa !24
  %t486 = getelementptr %"compiler/parse:Parser", ptr %t482, i32 0, i32 26
  store i64 %t483, ptr %t486, !tbaa !24
  %t488 = insertvalue { i32, ptr } zeroinitializer, ptr %t481, 1
  store { i32, ptr } %t488, ptr %rv
  br label %ret
bb72:
  br label %bb78
bb73:
  br i1 true, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_e98eee410cc159b2_377f58609bf35bd6)
  unreachable
bb78:
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t490 = load ptr, ptr %l8, !tbaa !29
  %t493 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinaryFrom(ptr %v0, ptr %v1, ptr %v1, ptr %t489, ptr %t490, i64 1)
  %t494 = extractvalue { i32, ptr } %t493, 1
  %t495 = extractvalue { i32, ptr } %t493, 0
  store i32 %t495, ptr %l186
  %t496 = icmp ne i32 %t495, 0
  br i1 %t496, label %bb80, label %ok.497, !prof !99
ok.497:
  store ptr %t494, ptr %l185
  br label %bb79
bb79:
  %t498 = load ptr, ptr %l185, !tbaa !29
  store ptr %t498, ptr %l182, !tbaa !29
  br label %bb81
bb80:
  %t499 = load i32, ptr %l186, !tbaa !23
  %t500 = lshr i32 %t499, 16
  %t501 = and i32 %t499, 65535
  %t502 = icmp eq i32 %t500, 1
  %t503 = select i1 %t502, i32 1, i32 0
  %t504 = icmp eq i32 %t499, 0
  %t505 = shl i32 %t503, 16
  %t506 = or i32 %t505, %t501
  %t507 = select i1 %t504, i32 0, i32 %t506
  %t508 = load ptr, ptr %l0, !tbaa !29
  %t509 = load i64, ptr %l2, !tbaa !24
  %t512 = getelementptr %"compiler/parse:Parser", ptr %t508, i32 0, i32 26
  store i64 %t509, ptr %t512, !tbaa !24
  %t514 = insertvalue { i32, ptr } zeroinitializer, i32 %t507, 0
  store { i32, ptr } %t514, ptr %rv
  br label %ret
bb81:
  %t515 = load ptr, ptr %l182, !tbaa !29
  store ptr %t515, ptr %l8, !tbaa !29
  %t516 = load ptr, ptr %l0, !tbaa !29
  %t517 = load ptr, ptr %l8, !tbaa !29
  %t520 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %v1, ptr %v1, ptr %t516, ptr %t517)
  %t521 = extractvalue { i32, ptr } %t520, 1
  %t522 = extractvalue { i32, ptr } %t520, 0
  store i32 %t522, ptr %l194
  %t523 = icmp ne i32 %t522, 0
  br i1 %t523, label %bb83, label %ok.524, !prof !99
ok.524:
  store ptr %t521, ptr %l193
  br label %bb82
bb82:
  %t525 = load ptr, ptr %l193, !tbaa !29
  store ptr %t525, ptr %l190, !tbaa !29
  br label %bb84
bb83:
  %t526 = load i32, ptr %l194, !tbaa !23
  %t527 = lshr i32 %t526, 16
  %t528 = and i32 %t526, 65535
  %t529 = icmp eq i32 %t527, 1
  %t530 = select i1 %t529, i32 1, i32 0
  %t531 = icmp eq i32 %t526, 0
  %t532 = shl i32 %t530, 16
  %t533 = or i32 %t532, %t528
  %t534 = select i1 %t531, i32 0, i32 %t533
  %t535 = load ptr, ptr %l0, !tbaa !29
  %t536 = load i64, ptr %l2, !tbaa !24
  %t539 = getelementptr %"compiler/parse:Parser", ptr %t535, i32 0, i32 26
  store i64 %t536, ptr %t539, !tbaa !24
  %t541 = insertvalue { i32, ptr } zeroinitializer, i32 %t534, 0
  store { i32, ptr } %t541, ptr %rv
  br label %ret
bb84:
  %t542 = load ptr, ptr %l190, !tbaa !29
  store ptr %t542, ptr %l8, !tbaa !29
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t545 = getelementptr %"compiler/parse:Parser", ptr %t543, i32 0, i32 26
  %t546 = load i64, ptr %t545, !tbaa !24
  store i64 %t546, ptr %l18, !tbaa !24
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t550 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %t548, i1 false)
  %t551 = extractvalue { i32, { i64, ptr } } %t550, 1
  %t552 = extractvalue { i32, { i64, ptr } } %t550, 0
  store i32 %t552, ptr %l203
  %t553 = icmp ne i32 %t552, 0
  br i1 %t553, label %bb86, label %ok.554, !prof !99
ok.554:
  store { i64, ptr } %t551, ptr %l202
  br label %bb85
bb85:
  %t555 = load { i64, ptr }, ptr %l202, !tbaa !27
  store { i64, ptr } %t555, ptr %l200, !tbaa !27
  br label %bb87
bb86:
  %t556 = load i32, ptr %l203, !tbaa !23
  %t557 = lshr i32 %t556, 16
  %t558 = and i32 %t556, 65535
  %t559 = icmp eq i32 %t557, 1
  %t560 = select i1 %t559, i32 1, i32 0
  %t561 = icmp eq i32 %t556, 0
  %t562 = shl i32 %t560, 16
  %t563 = or i32 %t562, %t558
  %t564 = select i1 %t561, i32 0, i32 %t563
  %t565 = load ptr, ptr %l0, !tbaa !29
  %t566 = load i64, ptr %l2, !tbaa !24
  %t569 = getelementptr %"compiler/parse:Parser", ptr %t565, i32 0, i32 26
  store i64 %t566, ptr %t569, !tbaa !24
  %t571 = insertvalue { i32, ptr } zeroinitializer, i32 %t564, 0
  store { i32, ptr } %t571, ptr %rv
  br label %ret
bb87:
  %t572 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t572, ptr %l19, !tbaa !27
  %t573 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t575 = extractvalue { i64, ptr } %t573, 0
  %t577 = icmp eq i64 %t575, 0
  br i1 %t577, label %bb88, label %bb89
bb88:
  %t579 = load i64, ptr %l18, !tbaa !24
  %t581 = icmp sge i64 %t579, 0
  store i1 %t581, ptr %l210, !tbaa !21
  br label %bb90
bb89:
  store i1 false, ptr %l210, !tbaa !21
  br label %bb90
bb90:
  %t583 = load i1, ptr %l210, !tbaa !21
  br i1 %t583, label %bb91, label %bb92
bb91:
  %t584 = load ptr, ptr %l0, !tbaa !29
  %t585 = load i64, ptr %l18, !tbaa !24
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %t584, i64 %t585)
  br label %bb93
bb92:
  br label %bb94
bb93:
  %t588 = load ptr, ptr %l0, !tbaa !29
  %t589 = load i64, ptr %l2, !tbaa !24
  %t592 = getelementptr %"compiler/parse:Parser", ptr %t588, i32 0, i32 26
  store i64 %t589, ptr %t592, !tbaa !24
  %t594 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t594, ptr %rv
  br label %ret
bb94:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load i32, ptr %l1, !tbaa !23
  %t599 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t595, i32 %t596)
  store %"compiler/source:Span" %t599, ptr %l220
  br label %bb95
bb95:
  %t600 = load ptr, ptr %l8, !tbaa !29
  %t601 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, [4 x i64] } zeroinitializer, ptr %t602
  %t603 = getelementptr { i64, [4 x i64] }, ptr %t602, i32 0, i32 0
  store i64 19, ptr %t603
  %t604 = load %"compiler/source:Span", ptr %l220
  %t605 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } undef, %"compiler/source:Span" %t604, 0
  %t607 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t605, ptr %t600, 1
  %t609 = insertvalue { %"compiler/source:Span", ptr, { i64, ptr } } %t607, { i64, ptr } %t601, 2
  %t610 = getelementptr { i64, [4 x i64] }, ptr %t602, i32 0, i32 1
  store { %"compiler/source:Span", ptr, { i64, ptr } } %t609, ptr %t610
  %t611 = load { i64, [4 x i64] }, ptr %t602
  %t613 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t611, ptr %t613
  store ptr %t613, ptr %l20, !tbaa !29
  %t615 = load ptr, ptr %l0, !tbaa !29
  %t616 = load i32, ptr %l1, !tbaa !23
  %t619 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t615, i32 %t616)
  store %"compiler/source:Span" %t619, ptr %l227
  br label %bb96
bb96:
  %t620 = load %"compiler/source:Span", ptr %l227
  store %"compiler/source:Span" %t620, ptr %l21
  %t621 = load ptr, ptr %l0, !tbaa !29
  %t623 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t621)
  store i32 %t623, ptr %l229
  %t624 = icmp ne i32 %t623, 0
  br i1 %t624, label %bb98, label %ok.625, !prof !99
ok.625:
  br label %bb97
bb97:
  br label %bb99
bb98:
  %t626 = load i32, ptr %l229, !tbaa !23
  %t627 = lshr i32 %t626, 16
  %t628 = and i32 %t626, 65535
  %t629 = icmp eq i32 %t627, 1
  %t630 = select i1 %t629, i32 1, i32 0
  %t631 = icmp eq i32 %t626, 0
  %t632 = shl i32 %t630, 16
  %t633 = or i32 %t632, %t628
  %t634 = select i1 %t631, i32 0, i32 %t633
  %t635 = load ptr, ptr %l0, !tbaa !29
  %t636 = load i64, ptr %l2, !tbaa !24
  %t639 = getelementptr %"compiler/parse:Parser", ptr %t635, i32 0, i32 26
  store i64 %t636, ptr %t639, !tbaa !24
  %t641 = insertvalue { i32, ptr } zeroinitializer, i32 %t634, 0
  store { i32, ptr } %t641, ptr %rv
  br label %ret
bb99:
  %t642 = load %"compiler/source:Span", ptr %l21
  %t643 = load ptr, ptr %l20, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t644
  %t645 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 0
  store i64 0, ptr %t645
  %t647 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t642, 0
  %t649 = insertvalue { %"compiler/source:Span", ptr } %t647, ptr %t643, 1
  %t650 = getelementptr { i64, [4 x i64] }, ptr %t644, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t649, ptr %t650
  %t651 = load { i64, [4 x i64] }, ptr %t644
  %t653 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t651, ptr %t653
  %t654 = load ptr, ptr %l0, !tbaa !29
  %t655 = load i64, ptr %l2, !tbaa !24
  %t658 = getelementptr %"compiler/parse:Parser", ptr %t654, i32 0, i32 26
  store i64 %t655, ptr %t658, !tbaa !24
  %t660 = insertvalue { i32, ptr } zeroinitializer, ptr %t653, 1
  store { i32, ptr } %t660, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i32
  %rv = alloca { i32, ptr }
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %a0)
  %t4 = extractvalue { i32, ptr } %t3, 1
  %t5 = extractvalue { i32, ptr } %t3, 0
  store i32 %t5, ptr %l4
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store ptr %t4, ptr %l3
  br label %bb1
bb1:
  %t8 = load ptr, ptr %l3, !tbaa !29
  store ptr %t8, ptr %l1, !tbaa !29
  br label %bb3
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = lshr i32 %t9, 16
  %t11 = and i32 %t9, 65535
  %t12 = icmp eq i32 %t10, 1
  %t13 = select i1 %t12, i32 1, i32 0
  %t14 = icmp eq i32 %t9, 0
  %t15 = shl i32 %t13, 16
  %t16 = or i32 %t15, %t11
  %t17 = select i1 %t14, i32 0, i32 %t16
  %t19 = insertvalue { i32, ptr } zeroinitializer, i32 %t17, 0
  store { i32, ptr } %t19, ptr %rv
  br label %ret
bb3:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = insertvalue { i32, ptr } zeroinitializer, ptr %t20, 1
  store { i32, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca i1
  %l4 = alloca i64
  %l6 = alloca i32
  %l19 = alloca i64
  %l22 = alloca i1
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i32
  %l58 = alloca i32
  %l65 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l6
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t6 = load i32, ptr %l6, !tbaa !23
  %t7 = lshr i32 %t6, 16
  %t8 = and i32 %t6, 65535
  %t9 = icmp eq i32 %t7, 1
  %t10 = select i1 %t9, i32 1, i32 0
  %t11 = icmp eq i32 %t6, 0
  %t12 = shl i32 %t10, 16
  %t13 = or i32 %t12, %t8
  %t14 = select i1 %t11, i32 0, i32 %t13
  %t16 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t14, 0
  store { i32, { i64, ptr } } %t16, ptr %rv
  br label %ret
bb3:
  %t17 = load ptr, ptr %l0, !tbaa !29
  %t19 = getelementptr %"compiler/parse:Parser", ptr %t17, i32 0, i32 11
  %t20 = load i1, ptr %t19, !tbaa !21
  store i1 %t20, ptr %l1, !tbaa !21
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = getelementptr %"compiler/parse:Parser", ptr %t22, i32 0, i32 11
  store i1 true, ptr %t24, !tbaa !21
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/parse:Parser", ptr %t25, i32 0, i32 22
  %t28 = load i1, ptr %t27, !tbaa !21
  store i1 %t28, ptr %l2, !tbaa !21
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = getelementptr %"compiler/parse:Parser", ptr %t30, i32 0, i32 23
  %t33 = load i1, ptr %t32, !tbaa !21
  store i1 %t33, ptr %l3, !tbaa !21
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/parse:Parser", ptr %t35, i32 0, i32 22
  store i1 false, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 23
  store i1 true, ptr %t40, !tbaa !21
  %t41 = load ptr, ptr %l0, !tbaa !29
  %t43 = getelementptr %"compiler/parse:Parser", ptr %t41, i32 0, i32 36
  %t45 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %t43)
  store i64 %t45, ptr %l19
  br label %bb4
bb4:
  %t46 = load i64, ptr %l19, !tbaa !24
  store i64 %t46, ptr %l4, !tbaa !24
  br label %bb5
bb5:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t50 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t47, i32 77)
  store i1 %t50, ptr %l22
  br label %bb6
bb6:
  %t51 = load i1, ptr %l22, !tbaa !21
  br i1 %t51, label %bb7, label %bb8
bb7:
  %t52 = load ptr, ptr %l0, !tbaa !29
  %t54 = getelementptr %"compiler/parse:Parser", ptr %t52, i32 0, i32 36
  store ptr %t54, ptr %l24, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %v0, ptr %t55)
  %t58 = extractvalue { i32, ptr } %t57, 1
  %t59 = extractvalue { i32, ptr } %t57, 0
  store i32 %t59, ptr %l28
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb10, label %ok.61, !prof !99
ok.61:
  store ptr %t58, ptr %l27
  br label %bb9
bb8:
  br label %bb13
bb9:
  %t62 = load ptr, ptr %l27, !tbaa !29
  store ptr %t62, ptr %l25, !tbaa !29
  br label %bb11
bb10:
  %t63 = load i32, ptr %l28, !tbaa !23
  %t64 = lshr i32 %t63, 16
  %t65 = and i32 %t63, 65535
  %t66 = icmp eq i32 %t64, 1
  %t67 = select i1 %t66, i32 1, i32 0
  %t68 = icmp eq i32 %t63, 0
  %t69 = shl i32 %t67, 16
  %t70 = or i32 %t69, %t65
  %t71 = select i1 %t68, i32 0, i32 %t70
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t73 = load i1, ptr %l3, !tbaa !21
  %t76 = getelementptr %"compiler/parse:Parser", ptr %t72, i32 0, i32 23
  store i1 %t73, ptr %t76, !tbaa !21
  %t78 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t71, 0
  store { i32, { i64, ptr } } %t78, ptr %rv
  br label %ret
bb11:
  %t79 = load ptr, ptr %l24, !tbaa !29
  %t80 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t79, ptr %t80)
  br label %bb12
bb12:
  br label %bb29
bb13:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/parse:Parser", ptr %t81, i32 0, i32 36
  store ptr %t83, ptr %l33, !tbaa !29
  %t84 = load ptr, ptr %l0, !tbaa !29
  %t86 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArg(ptr %v0, ptr %v0, ptr %t84)
  %t87 = extractvalue { i32, ptr } %t86, 1
  %t88 = extractvalue { i32, ptr } %t86, 0
  store i32 %t88, ptr %l37
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb15, label %ok.90, !prof !99
ok.90:
  store ptr %t87, ptr %l36
  br label %bb14
bb14:
  %t91 = load ptr, ptr %l36, !tbaa !29
  store ptr %t91, ptr %l34, !tbaa !29
  br label %bb16
bb15:
  %t92 = load i32, ptr %l37, !tbaa !23
  %t93 = lshr i32 %t92, 16
  %t94 = and i32 %t92, 65535
  %t95 = icmp eq i32 %t93, 1
  %t96 = select i1 %t95, i32 1, i32 0
  %t97 = icmp eq i32 %t92, 0
  %t98 = shl i32 %t96, 16
  %t99 = or i32 %t98, %t94
  %t100 = select i1 %t97, i32 0, i32 %t99
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t102 = load i1, ptr %l3, !tbaa !21
  %t105 = getelementptr %"compiler/parse:Parser", ptr %t101, i32 0, i32 23
  store i1 %t102, ptr %t105, !tbaa !21
  %t107 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t100, 0
  store { i32, { i64, ptr } } %t107, ptr %rv
  br label %ret
bb16:
  %t108 = load ptr, ptr %l33, !tbaa !29
  %t109 = load ptr, ptr %l34, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v0, ptr %t108, ptr %t109)
  br label %bb17
bb17:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t113 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t110, i32 77)
  store i1 %t113, ptr %l43
  br label %bb18
bb18:
  %t114 = load i1, ptr %l43, !tbaa !21
  br i1 %t114, label %bb19, label %bb20
bb19:
  br label %bb28
bb20:
  br label %bb21
bb21:
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t118 = call { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %t115, i32 100)
  %t119 = extractvalue { i32, i1 } %t118, 1
  %t120 = extractvalue { i32, i1 } %t118, 0
  store i32 %t120, ptr %l48
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb23, label %ok.122, !prof !99
ok.122:
  store i1 %t119, ptr %l47
  br label %bb22
bb22:
  %t123 = load i1, ptr %l47, !tbaa !21
  store i1 %t123, ptr %l44, !tbaa !21
  br label %bb24
bb23:
  %t124 = load i32, ptr %l48, !tbaa !23
  %t125 = lshr i32 %t124, 16
  %t126 = and i32 %t124, 65535
  %t127 = icmp eq i32 %t125, 1
  %t128 = select i1 %t127, i32 1, i32 0
  %t129 = icmp eq i32 %t124, 0
  %t130 = shl i32 %t128, 16
  %t131 = or i32 %t130, %t126
  %t132 = select i1 %t129, i32 0, i32 %t131
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t134 = load i1, ptr %l3, !tbaa !21
  %t137 = getelementptr %"compiler/parse:Parser", ptr %t133, i32 0, i32 23
  store i1 %t134, ptr %t137, !tbaa !21
  %t139 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t132, 0
  store { i32, { i64, ptr } } %t139, ptr %rv
  br label %ret
bb24:
  %t140 = load i1, ptr %l44, !tbaa !21
  %t141 = xor i1 %t140, true
  br i1 %t141, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  br label %bb28
bb28:
  br label %bb5
bb29:
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t144 = load i1, ptr %l2, !tbaa !21
  %t147 = getelementptr %"compiler/parse:Parser", ptr %t143, i32 0, i32 22
  store i1 %t144, ptr %t147, !tbaa !21
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t149 = load i1, ptr %l1, !tbaa !21
  %t152 = getelementptr %"compiler/parse:Parser", ptr %t148, i32 0, i32 11
  store i1 %t149, ptr %t152, !tbaa !21
  %t153 = load ptr, ptr %l0, !tbaa !29
  %t155 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %t153)
  store i32 %t155, ptr %l58
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb31, label %ok.157, !prof !99
ok.157:
  br label %bb30
bb30:
  br label %bb32
bb31:
  %t158 = load i32, ptr %l58, !tbaa !23
  %t159 = lshr i32 %t158, 16
  %t160 = and i32 %t158, 65535
  %t161 = icmp eq i32 %t159, 1
  %t162 = select i1 %t161, i32 1, i32 0
  %t163 = icmp eq i32 %t158, 0
  %t164 = shl i32 %t162, 16
  %t165 = or i32 %t164, %t160
  %t166 = select i1 %t163, i32 0, i32 %t165
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t168 = load i1, ptr %l3, !tbaa !21
  %t171 = getelementptr %"compiler/parse:Parser", ptr %t167, i32 0, i32 23
  store i1 %t168, ptr %t171, !tbaa !21
  %t173 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t166, 0
  store { i32, { i64, ptr } } %t173, ptr %rv
  br label %ret
bb32:
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = getelementptr %"compiler/parse:Parser", ptr %t174, i32 0, i32 36
  %t177 = load i64, ptr %l4, !tbaa !24
  %t180 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l65
  br label %bb33
bb33:
  %t181 = load ptr, ptr %l0, !tbaa !29
  %t182 = load i1, ptr %l3, !tbaa !21
  %t185 = getelementptr %"compiler/parse:Parser", ptr %t181, i32 0, i32 23
  store i1 %t182, ptr %t185, !tbaa !21
  %t186 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t187 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t186, 1
  store { i32, { i64, ptr } } %t187, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %lp8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca ptr
  %l18 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i32
  %l30 = alloca i1
  %l33 = alloca i32
  %l36 = alloca ptr
  %l38 = alloca ptr
  %l39 = alloca i32
  %l44 = alloca i32
  %l50 = alloca i1
  %l51 = alloca i1
  %l53 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i32
  %l62 = alloca i32
  %l63 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca i32
  %l71 = alloca %"compiler/source:Span"
  %l77 = alloca %"compiler/source:Span"
  %l87 = alloca ptr
  %l88 = alloca i32
  %l90 = alloca i32
  %l93 = alloca { i64, ptr }
  %l96 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l107 = alloca %"compiler/diagmsg:Msg"
  %l115 = alloca ptr
  %l117 = alloca ptr
  %l118 = alloca i32
  %l122 = alloca %"compiler/source:Span"
  %l131 = alloca i32
  %l132 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca i32
  %l139 = alloca %"compiler/source:Span"
  %l147 = alloca i64
  %l149 = alloca ptr
  %l150 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i32
  %l157 = alloca i1
  %l160 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca i32
  %l165 = alloca i32
  %l166 = alloca i32
  %l171 = alloca { i64, ptr }
  %l177 = alloca i1
  %l178 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca i32
  %l185 = alloca %"compiler/source:Span"
  %l193 = alloca ptr
  %l197 = alloca i64
  %l199 = alloca i32
  %l206 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca i32
  %l221 = alloca i1
  %l223 = alloca i1
  %l225 = alloca i1
  %l227 = alloca ptr
  %l228 = alloca i32
  %l230 = alloca i32
  %l231 = alloca %"compiler/diagmsg:Msg"
  %l233 = alloca i32
  %l236 = alloca i32
  %l237 = alloca i32
  %l241 = alloca i1
  %l243 = alloca ptr
  %l244 = alloca i32
  %l246 = alloca i32
  %l247 = alloca %"compiler/diagmsg:Msg"
  %l253 = alloca i32
  %l256 = alloca i32
  %s2 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca { i32, ptr }
  %t141 = alloca { i64, [5 x i64] }, align 8
  %t161 = alloca { i64, [5 x i64] }, align 8
  %t291 = alloca { i64, [5 x i64] }, align 8
  %t337 = alloca { i64, [5 x i64] }, align 8
  %t466 = alloca { i64, [5 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l18
  br label %bb1
bb1:
  %t4 = load i32, ptr %l18, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/parse:Parser", ptr %t5, i32 0, i32 13
  %t8 = load i1, ptr %t7, !tbaa !21
  store i1 %t8, ptr %l2, !tbaa !21
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr %"compiler/parse:Parser", ptr %t10, i32 0, i32 13
  store i1 false, ptr %t12, !tbaa !21
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t13)
  store i32 %t15, ptr %l23
  br label %bb2
bb2:
  %t16 = load i32, ptr %l23, !range !{i32 0, i32 116}
  store i32 %t16, ptr %l3
  %t17 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t19 = trunc i64 43 to i32
  %t20 = icmp eq i32 %t17, %t19
  br i1 %t20, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb17
bb5:
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t22)
  store i32 %t24, ptr %l27
  br label %bb6
bb6:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t28 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t25, i32 37)
  store i1 %t28, ptr %l30
  br label %bb7
bb7:
  %t29 = load i1, ptr %l30, !tbaa !21
  %t30 = xor i1 %t29, true
  br i1 %t30, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s2, ptr %t32, { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i32 %t34, ptr %l33
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb11, label %ok.36, !prof !99
ok.36:
  br label %bb10
bb9:
  br label %bb13
bb10:
  br label %bb12
bb11:
  %t37 = load i32, ptr %l33, !tbaa !23
  %t38 = lshr i32 %t37, 16
  %t39 = and i32 %t37, 65535
  %t40 = icmp eq i32 %t38, 1
  %t41 = select i1 %t40, i32 1, i32 0
  %t42 = icmp eq i32 %t37, 0
  %t43 = shl i32 %t41, 16
  %t44 = or i32 %t43, %t39
  %t45 = select i1 %t42, i32 0, i32 %t44
  call void @__olang_scope_close(ptr %s2)
  %t47 = insertvalue { i32, ptr } zeroinitializer, i32 %t45, 0
  store { i32, ptr } %t47, ptr %rv
  br label %ret
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb13:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/parse:Parser", ptr %t48, i32 0, i32 14
  store i1 true, ptr %t50, !tbaa !21
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %v1, ptr %t51)
  %t54 = extractvalue { i32, ptr } %t53, 1
  %t55 = extractvalue { i32, ptr } %t53, 0
  store i32 %t55, ptr %l39
  %t56 = icmp ne i32 %t55, 0
  br i1 %t56, label %bb15, label %ok.57, !prof !99
ok.57:
  store ptr %t54, ptr %l38
  br label %bb14
bb14:
  %t58 = load ptr, ptr %l38, !tbaa !29
  store ptr %t58, ptr %l36, !tbaa !29
  br label %bb16
bb15:
  %t59 = load i32, ptr %l39, !tbaa !23
  %t60 = lshr i32 %t59, 16
  %t61 = and i32 %t59, 65535
  %t62 = icmp eq i32 %t60, 1
  %t63 = select i1 %t62, i32 1, i32 0
  %t64 = icmp eq i32 %t59, 0
  %t65 = shl i32 %t63, 16
  %t66 = or i32 %t65, %t61
  %t67 = select i1 %t64, i32 0, i32 %t66
  %t69 = insertvalue { i32, ptr } zeroinitializer, i32 %t67, 0
  store { i32, ptr } %t69, ptr %rv
  br label %ret
bb16:
  %t70 = load ptr, ptr %l36, !tbaa !29
  %t71 = insertvalue { i32, ptr } zeroinitializer, ptr %t70, 1
  store { i32, ptr } %t71, ptr %rv
  br label %ret
bb17:
  %t72 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t74 = trunc i64 37 to i32
  %t75 = icmp eq i32 %t72, %t74
  br i1 %t75, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb56
bb20:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t77)
  store i32 %t79, ptr %l44
  br label %bb21
bb21:
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t82 = getelementptr %"compiler/parse:Parser", ptr %t80, i32 0, i32 14
  %t83 = load i1, ptr %t82, !tbaa !21
  store i1 %t83, ptr %l4, !tbaa !21
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/parse:Parser", ptr %t85, i32 0, i32 14
  store i1 false, ptr %t87, !tbaa !21
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t91 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t88, i32 102)
  store i1 %t91, ptr %l50
  br label %bb22
bb22:
  %t92 = load i1, ptr %l50, !tbaa !21
  br i1 %t92, label %bb23, label %bb24
bb23:
  store i1 true, ptr %l51, !tbaa !21
  br label %bb26
bb24:
  %t93 = load ptr, ptr %l0, !tbaa !29
  %t95 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %t93)
  store i1 %t95, ptr %l53
  br label %bb25
bb25:
  %t96 = load i1, ptr %l53, !tbaa !21
  store i1 %t96, ptr %l51, !tbaa !21
  br label %bb26
bb26:
  %t97 = load i1, ptr %l51, !tbaa !21
  store i1 %t97, ptr %l5, !tbaa !21
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t101 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t98, i32 77)
  store i1 %t101, ptr %l56
  br label %bb27
bb27:
  %t102 = load i1, ptr %l56, !tbaa !21
  store i1 %t102, ptr %l6, !tbaa !21
  %t103 = load i1, ptr %l6, !tbaa !21
  br i1 %t103, label %bb28, label %bb29
bb28:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t105)
  store i32 %t107, ptr %l59
  br label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb31
bb31:
  %t108 = load i1, ptr %l5, !tbaa !21
  br i1 %t108, label %bb32, label %bb33
bb32:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t110)
  store i32 %t112, ptr %l62
  br label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb35
bb35:
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t114 = load i1, ptr %l4, !tbaa !21
  %t117 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esig(ptr %v0, ptr %v1, ptr %t113, i1 false, i1 true, i1 false, i1 false, i1 %t114)
  %t118 = extractvalue { i32, ptr } %t117, 1
  %t119 = extractvalue { i32, ptr } %t117, 0
  store i32 %t119, ptr %l67
  %t120 = icmp ne i32 %t119, 0
  br i1 %t120, label %bb37, label %ok.121, !prof !99
ok.121:
  store ptr %t118, ptr %l66
  br label %bb36
bb36:
  %t122 = load ptr, ptr %l66, !tbaa !29
  store ptr %t122, ptr %l63, !tbaa !29
  br label %bb38
bb37:
  %t123 = load i32, ptr %l67, !tbaa !23
  %t124 = lshr i32 %t123, 16
  %t125 = and i32 %t123, 65535
  %t126 = icmp eq i32 %t124, 1
  %t127 = select i1 %t126, i32 1, i32 0
  %t128 = icmp eq i32 %t123, 0
  %t129 = shl i32 %t127, 16
  %t130 = or i32 %t129, %t125
  %t131 = select i1 %t128, i32 0, i32 %t130
  %t133 = insertvalue { i32, ptr } zeroinitializer, i32 %t131, 0
  store { i32, ptr } %t133, ptr %rv
  br label %ret
bb38:
  %t134 = load ptr, ptr %l63, !tbaa !29
  store ptr %t134, ptr %l7, !tbaa !29
  %t135 = load ptr, ptr %l0, !tbaa !29
  %t136 = load i32, ptr %l1, !tbaa !23
  %t139 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t135, i32 %t136)
  store %"compiler/source:Span" %t139, ptr %l71
  br label %bb39
bb39:
  %t140 = load ptr, ptr %l7, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t141
  %t142 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 0
  store i64 1, ptr %t142
  %t143 = load %"compiler/source:Span", ptr %l71
  %t144 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t143, 0
  %t146 = insertvalue { %"compiler/source:Span", ptr } %t144, ptr %t140, 1
  %t147 = getelementptr { i64, [5 x i64] }, ptr %t141, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t146, ptr %t147
  %t148 = load { i64, [5 x i64] }, ptr %t141
  %t149 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store ptr %t149, ptr %lp8
  %t151 = load ptr, ptr %lp8
  store { i64, [5 x i64] } %t148, ptr %t151
  %t152 = load i1, ptr %l5, !tbaa !21
  br i1 %t152, label %bb40, label %bb41
bb40:
  %t154 = load ptr, ptr %l0, !tbaa !29
  %t155 = load i32, ptr %l1, !tbaa !23
  %t158 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t154, i32 %t155)
  store %"compiler/source:Span" %t158, ptr %l77
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t159 = load ptr, ptr %lp8
  %t160 = load i1, ptr %l6, !tbaa !21
  store { i64, [5 x i64] } zeroinitializer, ptr %t161
  %t162 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 0
  store i64 3, ptr %t162
  %t163 = load %"compiler/source:Span", ptr %l77
  %t164 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } undef, %"compiler/source:Span" %t163, 0
  %t166 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t164, ptr %t159, 1
  %t168 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t166, i1 %t160, 2
  %t169 = insertvalue { %"compiler/source:Span", ptr, i1, i1 } %t168, i1 false, 3
  %t170 = getelementptr { i64, [5 x i64] }, ptr %t161, i32 0, i32 1
  store { %"compiler/source:Span", ptr, i1, i1 } %t169, ptr %t170
  %t171 = load { i64, [5 x i64] }, ptr %t161
  %t173 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t171, ptr %t173
  %t175 = insertvalue { i32, ptr } zeroinitializer, ptr %t173, 1
  store { i32, ptr } %t175, ptr %rv
  br label %ret
bb43:
  %t176 = load i1, ptr %l2, !tbaa !21
  %t178 = xor i1 %t176, true
  br i1 %t178, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t180 = load ptr, ptr %l0, !tbaa !29
  %t182 = getelementptr %"compiler/parse:Parser", ptr %t180, i32 0, i32 56
  %t183 = load i32, ptr %l1, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %t182, i32 %t183)
  br label %bb46
bb45:
  br label %bb55
bb46:
  %t186 = load ptr, ptr %l0, !tbaa !29
  store ptr %t186, ptr %l87, !tbaa !29
  %t187 = load i32, ptr %l1, !tbaa !23
  store i32 %t187, ptr %l88, !tbaa !23
  %t188 = load i32, ptr %l1, !tbaa !23
  %t190 = add i32 %t188, 2
  store i32 %t190, ptr %l90, !tbaa !23
  %t191 = load ptr, ptr %l0, !tbaa !29
  %t193 = getelementptr %"compiler/parse:Parser", ptr %t191, i32 0, i32 0
  %t194 = load ptr, ptr %t193, !tbaa !29
  %t196 = getelementptr %"compiler/source:Source", ptr %t194, i32 0, i32 1
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  store { i64, ptr } %t197, ptr %l93, !tbaa !27
  %t198 = load i32, ptr %l1, !tbaa !23
  %t200 = sext i32 %t198 to i64
  %t202 = add i64 %t200, 2
  store i64 %t202, ptr %l96, !tbaa !24
  %t203 = load ptr, ptr %l0, !tbaa !29
  %t205 = getelementptr %"compiler/parse:Parser", ptr %t203, i32 0, i32 10
  %t206 = load i32, ptr %t205, !tbaa !23
  %t208 = sext i32 %t206 to i64
  store i64 %t208, ptr %l99, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  store i64 %t210, ptr %l100, !tbaa !24
  %t211 = load i64, ptr %l96, !tbaa !24
  %t212 = icmp sge i64 %t211, 0
  br i1 %t212, label %bb47, label %bb48
bb47:
  %t214 = load i64, ptr %l96, !tbaa !24
  %t215 = load i64, ptr %l99, !tbaa !24
  %t216 = icmp sle i64 %t214, %t215
  br i1 %t216, label %bb49, label %bb50
bb48:
  call void @__olang_check_failed(ptr @olang_loc_8764526ae5415d75_f5a9948c86d2d3b9)
  unreachable
bb49:
  %t218 = load i64, ptr %l99, !tbaa !24
  %t219 = load i64, ptr %l100, !tbaa !24
  %t220 = icmp sle i64 %t218, %t219
  br i1 %t220, label %bb51, label %bb52
bb50:
  call void @__olang_check_failed(ptr @olang_loc_8764526ae5415d75_f5a9948c86d2d3b9)
  unreachable
bb51:
  %t222 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t223 = load ptr, ptr %t222, !tbaa !27
  %t224 = load i64, ptr %l96, !tbaa !24
  %t225 = load i64, ptr %l99, !tbaa !24
  %t226 = getelementptr i8, ptr %t223, i64 %t224
  %t227 = sub i64 %t225, %t224
  %t228 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t226, 1
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = extractvalue { i64, ptr } %t229, 0
  %t233 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t231, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t238 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncTypeBare(ptr %s7, ptr %v0, { i64, ptr } %t235)
  store %"compiler/diagmsg:Msg" %t238, ptr %l107
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_8764526ae5415d75_f5a9948c86d2d3b9)
  unreachable
bb53:
  %t239 = load ptr, ptr %l87, !tbaa !29
  %t240 = load i32, ptr %l88, !tbaa !23
  %t241 = load i32, ptr %l90, !tbaa !23
  %t242 = load %"compiler/diagmsg:Msg", ptr %l107
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t239, i32 %t240, i32 %t241, %"compiler/diagmsg:Msg" %t242)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s7)
  br label %bb55
bb55:
  %t243 = load ptr, ptr %lp8
  %t245 = insertvalue { i32, ptr } zeroinitializer, ptr %t243, 1
  store { i32, ptr } %t245, ptr %rv
  br label %ret
bb56:
  %t246 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t248 = trunc i64 35 to i32
  %t249 = icmp eq i32 %t246, %t248
  br i1 %t249, label %bb57, label %bb58
bb57:
  br label %bb63
bb58:
  %t251 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t253 = trunc i64 34 to i32
  %t254 = icmp eq i32 %t251, %t253
  br i1 %t254, label %bb59, label %bb60
bb59:
  br label %bb63
bb60:
  %t256 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t258 = trunc i64 36 to i32
  %t259 = icmp eq i32 %t256, %t258
  br i1 %t259, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  br label %bb71
bb63:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %v1, ptr %t261)
  %t264 = extractvalue { i32, ptr } %t263, 1
  %t265 = extractvalue { i32, ptr } %t263, 0
  store i32 %t265, ptr %l118
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb65, label %ok.267, !prof !99
ok.267:
  store ptr %t264, ptr %l117
  br label %bb64
bb64:
  %t268 = load ptr, ptr %l117, !tbaa !29
  store ptr %t268, ptr %l115, !tbaa !29
  br label %bb66
bb65:
  %t269 = load i32, ptr %l118, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  %t279 = insertvalue { i32, ptr } zeroinitializer, i32 %t277, 0
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb66:
  %t280 = load ptr, ptr %l115, !tbaa !29
  store ptr %t280, ptr %l9, !tbaa !29
  %t281 = load ptr, ptr %l0, !tbaa !29
  %t282 = load i32, ptr %l1, !tbaa !23
  %t285 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t281, i32 %t282)
  store %"compiler/source:Span" %t285, ptr %l122
  br label %bb67
bb67:
  %t286 = load ptr, ptr %l9, !tbaa !29
  %t288 = icmp eq ptr %t286, null
  br i1 %t288, label %bb68, label %bb69
bb68:
  call void @__olang_check_failed(ptr @olang_loc_ead0ed9b34ee6f0_4abfb82b89e87654)
  unreachable
bb69:
  br label %bb70
bb70:
  %t290 = load ptr, ptr %l9, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t291
  %t292 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 0
  store i64 2, ptr %t292
  %t293 = load %"compiler/source:Span", ptr %l122
  %t294 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t293, 0
  %t296 = insertvalue { %"compiler/source:Span", ptr } %t294, ptr %t290, 1
  %t297 = getelementptr { i64, [5 x i64] }, ptr %t291, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t296, ptr %t297
  %t298 = load { i64, [5 x i64] }, ptr %t291
  %t300 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t298, ptr %t300
  %t302 = insertvalue { i32, ptr } zeroinitializer, ptr %t300, 1
  store { i32, ptr } %t302, ptr %rv
  br label %ret
bb71:
  %t303 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t305 = trunc i64 52 to i32
  %t306 = icmp eq i32 %t303, %t305
  br i1 %t306, label %bb72, label %bb73
bb72:
  br label %bb74
bb73:
  br label %bb80
bb74:
  %t308 = load ptr, ptr %l0, !tbaa !29
  %t310 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t308)
  store i32 %t310, ptr %l131
  br label %bb75
bb75:
  %t311 = load ptr, ptr %l0, !tbaa !29
  %t313 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBase(ptr %v0, ptr %v1, ptr %t311)
  %t314 = extractvalue { i32, ptr } %t313, 1
  %t315 = extractvalue { i32, ptr } %t313, 0
  store i32 %t315, ptr %l135
  %t316 = icmp ne i32 %t315, 0
  br i1 %t316, label %bb77, label %ok.317, !prof !99
ok.317:
  store ptr %t314, ptr %l134
  br label %bb76
bb76:
  %t318 = load ptr, ptr %l134, !tbaa !29
  store ptr %t318, ptr %l132, !tbaa !29
  br label %bb78
bb77:
  %t319 = load i32, ptr %l135, !tbaa !23
  %t320 = lshr i32 %t319, 16
  %t321 = and i32 %t319, 65535
  %t322 = icmp eq i32 %t320, 1
  %t323 = select i1 %t322, i32 1, i32 0
  %t324 = icmp eq i32 %t319, 0
  %t325 = shl i32 %t323, 16
  %t326 = or i32 %t325, %t321
  %t327 = select i1 %t324, i32 0, i32 %t326
  %t329 = insertvalue { i32, ptr } zeroinitializer, i32 %t327, 0
  store { i32, ptr } %t329, ptr %rv
  br label %ret
bb78:
  %t330 = load ptr, ptr %l132, !tbaa !29
  store ptr %t330, ptr %l10, !tbaa !29
  %t331 = load ptr, ptr %l0, !tbaa !29
  %t332 = load i32, ptr %l1, !tbaa !23
  %t335 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t331, i32 %t332)
  store %"compiler/source:Span" %t335, ptr %l139
  br label %bb79
bb79:
  %t336 = load ptr, ptr %l10, !tbaa !29
  store { i64, [5 x i64] } zeroinitializer, ptr %t337
  %t338 = getelementptr { i64, [5 x i64] }, ptr %t337, i32 0, i32 0
  store i64 5, ptr %t338
  %t339 = load %"compiler/source:Span", ptr %l139
  %t340 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t339, 0
  %t342 = insertvalue { %"compiler/source:Span", ptr } %t340, ptr %t336, 1
  %t343 = getelementptr { i64, [5 x i64] }, ptr %t337, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t342, ptr %t343
  %t344 = load { i64, [5 x i64] }, ptr %t337
  %t346 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t344, ptr %t346
  %t348 = insertvalue { i32, ptr } zeroinitializer, ptr %t346, 1
  store { i32, ptr } %t348, ptr %rv
  br label %ret
bb80:
  %t349 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t351 = trunc i64 1 to i32
  %t352 = icmp eq i32 %t349, %t351
  br i1 %t352, label %bb81, label %bb82
bb81:
  br label %bb83
bb82:
  br label %bb114
bb83:
  %t354 = load ptr, ptr %l0, !tbaa !29
  %t356 = getelementptr %"compiler/parse:Parser", ptr %t354, i32 0, i32 39
  %t358 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t356)
  store i64 %t358, ptr %l147
  br label %bb84
bb84:
  %t359 = load i64, ptr %l147, !tbaa !24
  store i64 %t359, ptr %l11, !tbaa !24
  %t360 = load ptr, ptr %l0, !tbaa !29
  %t362 = getelementptr %"compiler/parse:Parser", ptr %t360, i32 0, i32 39
  store ptr %t362, ptr %l149, !tbaa !29
  %t363 = load ptr, ptr %l0, !tbaa !29
  %t365 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t363)
  %t366 = extractvalue { i32, i32 } %t365, 1
  %t367 = extractvalue { i32, i32 } %t365, 0
  store i32 %t367, ptr %l153
  %t368 = icmp ne i32 %t367, 0
  br i1 %t368, label %bb86, label %ok.369, !prof !99
ok.369:
  store i32 %t366, ptr %l152
  br label %bb85
bb85:
  %t370 = load i32, ptr %l152, !tbaa !23
  store i32 %t370, ptr %l150, !tbaa !23
  br label %bb87
bb86:
  %t371 = load i32, ptr %l153, !tbaa !23
  %t372 = lshr i32 %t371, 16
  %t373 = and i32 %t371, 65535
  %t374 = icmp eq i32 %t372, 1
  %t375 = select i1 %t374, i32 1, i32 0
  %t376 = icmp eq i32 %t371, 0
  %t377 = shl i32 %t375, 16
  %t378 = or i32 %t377, %t373
  %t379 = select i1 %t376, i32 0, i32 %t378
  %t381 = insertvalue { i32, ptr } zeroinitializer, i32 %t379, 0
  store { i32, ptr } %t381, ptr %rv
  br label %ret
bb87:
  %t382 = load ptr, ptr %l149, !tbaa !29
  %t383 = load i32, ptr %l150, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t382, i32 %t383)
  br label %bb88
bb88:
  br label %bb89
bb89:
  %t384 = load ptr, ptr %l0, !tbaa !29
  %t387 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t384, i32 76)
  store i1 %t387, ptr %l157
  br label %bb90
bb90:
  %t388 = load i1, ptr %l157, !tbaa !21
  %t389 = xor i1 %t388, true
  br i1 %t389, label %bb91, label %bb92
bb91:
  br label %bb100
bb92:
  br label %bb93
bb93:
  %t391 = load ptr, ptr %l0, !tbaa !29
  %t393 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t391)
  store i32 %t393, ptr %l160
  br label %bb94
bb94:
  %t394 = load ptr, ptr %l0, !tbaa !29
  %t396 = getelementptr %"compiler/parse:Parser", ptr %t394, i32 0, i32 39
  store ptr %t396, ptr %l162, !tbaa !29
  %t397 = load ptr, ptr %l0, !tbaa !29
  %t399 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %t397)
  %t400 = extractvalue { i32, i32 } %t399, 1
  %t401 = extractvalue { i32, i32 } %t399, 0
  store i32 %t401, ptr %l166
  %t402 = icmp ne i32 %t401, 0
  br i1 %t402, label %bb96, label %ok.403, !prof !99
ok.403:
  store i32 %t400, ptr %l165
  br label %bb95
bb95:
  %t404 = load i32, ptr %l165, !tbaa !23
  store i32 %t404, ptr %l163, !tbaa !23
  br label %bb97
bb96:
  %t405 = load i32, ptr %l166, !tbaa !23
  %t406 = lshr i32 %t405, 16
  %t407 = and i32 %t405, 65535
  %t408 = icmp eq i32 %t406, 1
  %t409 = select i1 %t408, i32 1, i32 0
  %t410 = icmp eq i32 %t405, 0
  %t411 = shl i32 %t409, 16
  %t412 = or i32 %t411, %t407
  %t413 = select i1 %t410, i32 0, i32 %t412
  %t415 = insertvalue { i32, ptr } zeroinitializer, i32 %t413, 0
  store { i32, ptr } %t415, ptr %rv
  br label %ret
bb97:
  %t416 = load ptr, ptr %l162, !tbaa !29
  %t417 = load i32, ptr %l163, !tbaa !23
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %t416, i32 %t417)
  br label %bb98
bb98:
  br label %bb99
bb99:
  br label %bb89
bb100:
  %t418 = load ptr, ptr %l0, !tbaa !29
  %t420 = getelementptr %"compiler/parse:Parser", ptr %t418, i32 0, i32 39
  %t421 = load i64, ptr %l11, !tbaa !24
  %t424 = call { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v1, ptr %t420, i64 %t421)
  store { i64, ptr } %t424, ptr %l171
  br label %bb101
bb101:
  %t425 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t425, ptr %l12, !tbaa !27
  %t426 = icmp sge i64 0, 0
  br i1 %t426, label %bb102, label %bb103
bb102:
  %t428 = icmp sle i64 0, 1152921504606846975
  br i1 %t428, label %bb104, label %bb105
bb103:
  call void @__olang_check_failed(ptr @olang_loc_ae62324d96d86fcb_b2eaa0dd969a6637)
  unreachable
bb104:
  %t430 = mul i64 0, 8
  %t431 = insertvalue { i64, ptr } undef, i64 0, 0
  %t432 = insertvalue { i64, ptr } %t431, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t432, ptr %l13, !tbaa !27
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t437 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t434, i32 98)
  store i1 %t437, ptr %l177
  br label %bb106
bb105:
  call void @__olang_check_failed(ptr @olang_loc_ae62324d96d86fcb_b2eaa0dd969a6637)
  unreachable
bb106:
  %t438 = load i1, ptr %l177, !tbaa !21
  br i1 %t438, label %bb107, label %bb108
bb107:
  %t439 = load ptr, ptr %l0, !tbaa !29
  %t441 = call { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgs(ptr %v0, ptr %v1, ptr %t439)
  %t442 = extractvalue { i32, { i64, ptr } } %t441, 1
  %t443 = extractvalue { i32, { i64, ptr } } %t441, 0
  store i32 %t443, ptr %l181
  %t444 = icmp ne i32 %t443, 0
  br i1 %t444, label %bb110, label %ok.445, !prof !99
ok.445:
  store { i64, ptr } %t442, ptr %l180
  br label %bb109
bb108:
  br label %bb112
bb109:
  %t446 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t446, ptr %l178, !tbaa !27
  br label %bb111
bb110:
  %t447 = load i32, ptr %l181, !tbaa !23
  %t448 = lshr i32 %t447, 16
  %t449 = and i32 %t447, 65535
  %t450 = icmp eq i32 %t448, 1
  %t451 = select i1 %t450, i32 1, i32 0
  %t452 = icmp eq i32 %t447, 0
  %t453 = shl i32 %t451, 16
  %t454 = or i32 %t453, %t449
  %t455 = select i1 %t452, i32 0, i32 %t454
  %t457 = insertvalue { i32, ptr } zeroinitializer, i32 %t455, 0
  store { i32, ptr } %t457, ptr %rv
  br label %ret
bb111:
  %t458 = load { i64, ptr }, ptr %l178, !tbaa !27
  store { i64, ptr } %t458, ptr %l13, !tbaa !27
  br label %bb112
bb112:
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t460 = load i32, ptr %l1, !tbaa !23
  %t463 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t459, i32 %t460)
  store %"compiler/source:Span" %t463, ptr %l185
  br label %bb113
bb113:
  %t464 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t465 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, [5 x i64] } zeroinitializer, ptr %t466
  %t467 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 0
  store i64 0, ptr %t467
  %t468 = load %"compiler/source:Span", ptr %l185
  %t469 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } undef, %"compiler/source:Span" %t468, 0
  %t471 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t469, { i64, ptr } %t464, 1
  %t473 = insertvalue { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t471, { i64, ptr } %t465, 2
  %t474 = getelementptr { i64, [5 x i64] }, ptr %t466, i32 0, i32 1
  store { %"compiler/source:Span", { i64, ptr }, { i64, ptr } } %t473, ptr %t474
  %t475 = load { i64, [5 x i64] }, ptr %t466
  %t477 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 48, i64 8)
  store { i64, [5 x i64] } %t475, ptr %t477
  %t479 = insertvalue { i32, ptr } zeroinitializer, ptr %t477, 1
  store { i32, ptr } %t479, ptr %rv
  br label %ret
bb114:
  %t480 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t482 = trunc i64 110 to i32
  %t483 = icmp eq i32 %t480, %t482
  br i1 %t483, label %bb115, label %bb116
bb115:
  br label %bb117
bb116:
  br label %bb144
bb117:
  %t485 = load ptr, ptr %l0, !tbaa !29
  %t487 = getelementptr %"compiler/parse:Parser", ptr %t485, i32 0, i32 47
  store ptr %t487, ptr %l193, !tbaa !29
  %t488 = load ptr, ptr %l0, !tbaa !29
  %t489 = load ptr, ptr %l0, !tbaa !29
  %t491 = getelementptr %"compiler/parse:Parser", ptr %t489, i32 0, i32 6
  %t492 = load i64, ptr %t491, !tbaa !24
  %t495 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %t488, i64 %t492)
  store i64 %t495, ptr %l197
  br label %bb118
bb118:
  %t496 = load ptr, ptr %l193, !tbaa !29
  %t497 = load i64, ptr %l197, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t496, i64 %t497)
  br label %bb119
bb119:
  %t498 = load ptr, ptr %l0, !tbaa !29
  %t500 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t498)
  store i32 %t500, ptr %l199
  br label %bb120
bb120:
  %t501 = load ptr, ptr %l0, !tbaa !29
  %t503 = getelementptr %"compiler/parse:Parser", ptr %t501, i32 0, i32 23
  %t504 = load i1, ptr %t503, !tbaa !21
  store i1 %t504, ptr %l14, !tbaa !21
  %t506 = load ptr, ptr %l0, !tbaa !29
  %t508 = getelementptr %"compiler/parse:Parser", ptr %t506, i32 0, i32 22
  %t509 = load i1, ptr %t508, !tbaa !21
  store i1 %t509, ptr %l15, !tbaa !21
  %t511 = load ptr, ptr %l0, !tbaa !29
  %t513 = getelementptr %"compiler/parse:Parser", ptr %t511, i32 0, i32 23
  store i1 false, ptr %t513, !tbaa !21
  %t514 = load ptr, ptr %l0, !tbaa !29
  %t516 = getelementptr %"compiler/parse:Parser", ptr %t514, i32 0, i32 22
  store i1 false, ptr %t516, !tbaa !21
  %t517 = load ptr, ptr %l0, !tbaa !29
  %t519 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %t517)
  %t520 = extractvalue { i32, ptr } %t519, 1
  %t521 = extractvalue { i32, ptr } %t519, 0
  store i32 %t521, ptr %l209
  %t522 = icmp ne i32 %t521, 0
  br i1 %t522, label %bb122, label %ok.523, !prof !99
ok.523:
  store ptr %t520, ptr %l208
  br label %bb121
bb121:
  %t524 = load ptr, ptr %l208, !tbaa !29
  store ptr %t524, ptr %l206, !tbaa !29
  br label %bb124
bb122:
  br label %bb123
bb123:
  %t525 = load ptr, ptr %l0, !tbaa !29
  %t526 = load i1, ptr %l14, !tbaa !21
  %t529 = getelementptr %"compiler/parse:Parser", ptr %t525, i32 0, i32 23
  store i1 %t526, ptr %t529, !tbaa !21
  %t530 = load ptr, ptr %l0, !tbaa !29
  %t531 = load i1, ptr %l15, !tbaa !21
  %t534 = getelementptr %"compiler/parse:Parser", ptr %t530, i32 0, i32 22
  store i1 %t531, ptr %t534, !tbaa !21
  %t536 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t536, ptr %rv
  br label %ret
bb124:
  %t537 = load ptr, ptr %l206, !tbaa !29
  store ptr %t537, ptr %l16, !tbaa !29
  %t538 = load ptr, ptr %l0, !tbaa !29
  %t539 = load i1, ptr %l14, !tbaa !21
  %t542 = getelementptr %"compiler/parse:Parser", ptr %t538, i32 0, i32 23
  store i1 %t539, ptr %t542, !tbaa !21
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load i1, ptr %l15, !tbaa !21
  %t547 = getelementptr %"compiler/parse:Parser", ptr %t543, i32 0, i32 22
  store i1 %t544, ptr %t547, !tbaa !21
  %t548 = load ptr, ptr %l0, !tbaa !29
  %t551 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t548, i32 111)
  store i1 %t551, ptr %l221
  br label %bb125
bb125:
  %t552 = load i1, ptr %l221, !tbaa !21
  %t553 = xor i1 %t552, true
  br i1 %t553, label %bb126, label %bb127
bb126:
  %t555 = load ptr, ptr %l16, !tbaa !29
  %t557 = call i1 @compiler_2fparse_2eisFuncType(ptr %v1, ptr %t555)
  store i1 %t557, ptr %l225
  br label %bb128
bb127:
  store i1 false, ptr %l223, !tbaa !21
  br label %bb129
bb128:
  %t558 = load i1, ptr %l225, !tbaa !21
  %t559 = xor i1 %t558, true
  store i1 %t559, ptr %l223, !tbaa !21
  br label %bb129
bb129:
  %t561 = load i1, ptr %l223, !tbaa !21
  br i1 %t561, label %bb130, label %bb131
bb130:
  %t562 = load ptr, ptr %l0, !tbaa !29
  store ptr %t562, ptr %l227, !tbaa !29
  %t563 = load i32, ptr %l1, !tbaa !23
  store i32 %t563, ptr %l228, !tbaa !23
  %t564 = load ptr, ptr %l0, !tbaa !29
  %t566 = getelementptr %"compiler/parse:Parser", ptr %t564, i32 0, i32 10
  %t567 = load i32, ptr %t566, !tbaa !23
  store i32 %t567, ptr %l230, !tbaa !23
  %t568 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0)
  store %"compiler/diagmsg:Msg" %t568, ptr %l231
  br label %bb132
bb131:
  br label %bb134
bb132:
  %t569 = load ptr, ptr %l227, !tbaa !29
  %t570 = load i32, ptr %l228, !tbaa !23
  %t571 = load i32, ptr %l230, !tbaa !23
  %t572 = load %"compiler/diagmsg:Msg", ptr %l231
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t569, i32 %t570, i32 %t571, %"compiler/diagmsg:Msg" %t572)
  br label %bb133
bb133:
  %t574 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t574, ptr %rv
  br label %ret
bb134:
  %t575 = load ptr, ptr %l0, !tbaa !29
  %t578 = call { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %t575, i32 111)
  %t579 = extractvalue { i32, i32 } %t578, 1
  %t580 = extractvalue { i32, i32 } %t578, 0
  store i32 %t580, ptr %l237
  %t581 = icmp ne i32 %t580, 0
  br i1 %t581, label %bb136, label %ok.582, !prof !99
ok.582:
  store i32 %t579, ptr %l236
  br label %bb135
bb135:
  %t583 = load i32, ptr %l236, !tbaa !23
  store i32 %t583, ptr %l233, !tbaa !23
  br label %bb137
bb136:
  %t584 = load i32, ptr %l237, !tbaa !23
  %t585 = lshr i32 %t584, 16
  %t586 = and i32 %t584, 65535
  %t587 = icmp eq i32 %t585, 1
  %t588 = select i1 %t587, i32 1, i32 0
  %t589 = icmp eq i32 %t584, 0
  %t590 = shl i32 %t588, 16
  %t591 = or i32 %t590, %t586
  %t592 = select i1 %t589, i32 0, i32 %t591
  %t594 = insertvalue { i32, ptr } zeroinitializer, i32 %t592, 0
  store { i32, ptr } %t594, ptr %rv
  br label %ret
bb137:
  %t595 = load ptr, ptr %l0, !tbaa !29
  %t596 = load ptr, ptr %l16, !tbaa !29
  %t599 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2egrouped(ptr %v0, ptr %v1, ptr %t595, ptr %t596)
  store i1 %t599, ptr %l241
  br label %bb138
bb138:
  %t600 = load i1, ptr %l241, !tbaa !21
  %t601 = xor i1 %t600, true
  br i1 %t601, label %bb139, label %bb140
bb139:
  %t603 = load ptr, ptr %l0, !tbaa !29
  store ptr %t603, ptr %l243, !tbaa !29
  %t604 = load i32, ptr %l1, !tbaa !23
  store i32 %t604, ptr %l244, !tbaa !23
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = getelementptr %"compiler/parse:Parser", ptr %t605, i32 0, i32 10
  %t608 = load i32, ptr %t607, !tbaa !23
  store i32 %t608, ptr %l246, !tbaa !23
  %t609 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0)
  store %"compiler/diagmsg:Msg" %t609, ptr %l247
  br label %bb141
bb140:
  br label %bb143
bb141:
  %t610 = load ptr, ptr %l243, !tbaa !29
  %t611 = load i32, ptr %l244, !tbaa !23
  %t612 = load i32, ptr %l246, !tbaa !23
  %t613 = load %"compiler/diagmsg:Msg", ptr %l247
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v0, ptr %t610, i32 %t611, i32 %t612, %"compiler/diagmsg:Msg" %t613)
  br label %bb142
bb142:
  %t615 = insertvalue { i32, ptr } zeroinitializer, i32 65536, 0
  store { i32, ptr } %t615, ptr %rv
  br label %ret
bb143:
  %t616 = load ptr, ptr %l16, !tbaa !29
  %t618 = insertvalue { i32, ptr } zeroinitializer, ptr %t616, 1
  store { i32, ptr } %t618, ptr %rv
  br label %ret
bb144:
  %t619 = load i32, ptr %l3, !range !{i32 0, i32 116}
  %t621 = trunc i64 98 to i32
  %t622 = icmp eq i32 %t619, %t621
  br i1 %t622, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  br label %bb151
bb147:
  store %olang.scope zeroinitializer, ptr %s18
  %t624 = load ptr, ptr %l0, !tbaa !29
  %t626 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s18, ptr %t624, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i32 %t626, ptr %l253
  %t627 = icmp ne i32 %t626, 0
  br i1 %t627, label %bb149, label %ok.628, !prof !99
ok.628:
  br label %bb148
bb148:
  br label %bb150
bb149:
  %t629 = load i32, ptr %l253, !tbaa !23
  %t630 = lshr i32 %t629, 16
  %t631 = and i32 %t629, 65535
  %t632 = icmp eq i32 %t630, 1
  %t633 = select i1 %t632, i32 1, i32 0
  %t634 = icmp eq i32 %t629, 0
  %t635 = shl i32 %t633, 16
  %t636 = or i32 %t635, %t631
  %t637 = select i1 %t634, i32 0, i32 %t636
  call void @__olang_scope_close(ptr %s18)
  %t639 = insertvalue { i32, ptr } zeroinitializer, i32 %t637, 0
  store { i32, ptr } %t639, ptr %rv
  br label %ret
bb150:
  call void @__olang_scope_close(ptr %s18)
  br label %bb159
bb151:
  br i1 true, label %bb152, label %bb153
bb152:
  br label %bb154
bb153:
  br label %bb158
bb154:
  store %olang.scope zeroinitializer, ptr %s19
  %t640 = load ptr, ptr %l0, !tbaa !29
  %t642 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %s19, ptr %t640, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) })
  store i32 %t642, ptr %l256
  %t643 = icmp ne i32 %t642, 0
  br i1 %t643, label %bb156, label %ok.644, !prof !99
ok.644:
  br label %bb155
bb155:
  br label %bb157
bb156:
  %t645 = load i32, ptr %l256, !tbaa !23
  %t646 = lshr i32 %t645, 16
  %t647 = and i32 %t645, 65535
  %t648 = icmp eq i32 %t646, 1
  %t649 = select i1 %t648, i32 1, i32 0
  %t650 = icmp eq i32 %t645, 0
  %t651 = shl i32 %t649, 16
  %t652 = or i32 %t651, %t647
  %t653 = select i1 %t650, i32 0, i32 %t652
  call void @__olang_scope_close(ptr %s19)
  %t655 = insertvalue { i32, ptr } zeroinitializer, i32 %t653, 0
  store { i32, ptr } %t655, ptr %rv
  br label %ret
bb157:
  call void @__olang_scope_close(ptr %s19)
  br label %bb159
bb158:
  call void @__olang_check_failed(ptr @olang_loc_c7048dff8864462d_6ca6baed1a8cf791)
  unreachable
bb159:
  call void @__olang_check_failed(ptr @olang_loc_6811a11f54350b9a_640e4e5711fedc76)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca ptr
  %l8 = alloca i32
  %l10 = alloca i1
  %l11 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i32
  %l17 = alloca i32
  %l21 = alloca i32
  %l23 = alloca i32
  %l25 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i32
  %l29 = alloca i32
  %l33 = alloca %"compiler/source:Span"
  %l37 = alloca ptr
  %l42 = alloca i32
  %l43 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i32
  %l50 = alloca %"compiler/source:Span"
  %l64 = alloca i32
  %l66 = alloca i32
  %l67 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca i32
  %l74 = alloca %"compiler/source:Span"
  %l85 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca i32
  %l99 = alloca ptr
  %l101 = alloca ptr
  %l102 = alloca i32
  %l104 = alloca ptr
  %l106 = alloca ptr
  %l107 = alloca i32
  %rv = alloca { i32, ptr }
  %t86 = alloca { i64, [4 x i64] }, align 8
  %t136 = alloca { i64, [4 x i64] }, align 8
  %t204 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %t1)
  store i32 %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load i32, ptr %l8, !tbaa !23
  store i32 %t4, ptr %l1, !tbaa !23
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %t5)
  store i1 %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load i1, ptr %l10, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2espread(ptr %v0, ptr %v1, ptr %t9)
  %t12 = extractvalue { i32, ptr } %t11, 1
  %t13 = extractvalue { i32, ptr } %t11, 0
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb6, label %ok.15, !prof !99
ok.15:
  store ptr %t12, ptr %l13
  br label %bb5
bb4:
  br label %bb8
bb5:
  %t16 = load ptr, ptr %l13, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  br label %bb7
bb6:
  %t17 = load i32, ptr %l14, !tbaa !23
  %t18 = lshr i32 %t17, 16
  %t19 = and i32 %t17, 65535
  %t20 = icmp eq i32 %t18, 1
  %t21 = select i1 %t20, i32 1, i32 0
  %t22 = icmp eq i32 %t17, 0
  %t23 = shl i32 %t21, 16
  %t24 = or i32 %t23, %t19
  %t25 = select i1 %t22, i32 0, i32 %t24
  %t27 = insertvalue { i32, ptr } zeroinitializer, i32 %t25, 0
  store { i32, ptr } %t27, ptr %rv
  br label %ret
bb7:
  %t28 = load ptr, ptr %l11, !tbaa !29
  %t29 = insertvalue { i32, ptr } zeroinitializer, ptr %t28, 1
  store { i32, ptr } %t29, ptr %rv
  br label %ret
bb8:
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t30)
  store i32 %t32, ptr %l17
  br label %bb9
bb9:
  %t33 = load i32, ptr %l17, !range !{i32 0, i32 116}
  store i32 %t33, ptr %l2
  %t34 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t36 = trunc i64 48 to i32
  %t37 = icmp eq i32 %t34, %t36
  br i1 %t37, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  br label %bb23
bb12:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t39)
  store i32 %t41, ptr %l21
  br label %bb13
bb13:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %t42)
  store i32 %t44, ptr %l23
  %t45 = icmp ne i32 %t44, 0
  br i1 %t45, label %bb15, label %ok.46, !prof !99
ok.46:
  br label %bb14
bb14:
  br label %bb16
bb15:
  %t47 = load i32, ptr %l23, !tbaa !23
  %t48 = lshr i32 %t47, 16
  %t49 = and i32 %t47, 65535
  %t50 = icmp eq i32 %t48, 1
  %t51 = select i1 %t50, i32 1, i32 0
  %t52 = icmp eq i32 %t47, 0
  %t53 = shl i32 %t51, 16
  %t54 = or i32 %t53, %t49
  %t55 = select i1 %t52, i32 0, i32 %t54
  %t57 = insertvalue { i32, ptr } zeroinitializer, i32 %t55, 0
  store { i32, ptr } %t57, ptr %rv
  br label %ret
bb16:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %t58, i64 4)
  %t61 = extractvalue { i32, ptr } %t60, 1
  %t62 = extractvalue { i32, ptr } %t60, 0
  store i32 %t62, ptr %l28
  %t63 = icmp ne i32 %t62, 0
  br i1 %t63, label %bb18, label %ok.64, !prof !99
ok.64:
  store ptr %t61, ptr %l27
  br label %bb17
bb17:
  %t65 = load ptr, ptr %l27, !tbaa !29
  store ptr %t65, ptr %l25, !tbaa !29
  br label %bb20
bb18:
  %t66 = load i32, ptr %l28, !tbaa !23
  %t67 = lshr i32 %t66, 16
  %t68 = and i32 %t66, 65535
  %t69 = icmp eq i32 %t67, 1
  %t70 = select i1 %t69, i32 1, i32 0
  %t71 = icmp eq i32 %t66, 0
  %t72 = shl i32 %t70, 16
  %t73 = or i32 %t72, %t68
  %t74 = select i1 %t71, i32 0, i32 %t73
  store i32 %t74, ptr %l29, !tbaa !23
  %t75 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t75)
  br label %bb19
bb19:
  %t77 = load i32, ptr %l29, !tbaa !23
  %t78 = insertvalue { i32, ptr } zeroinitializer, i32 %t77, 0
  store { i32, ptr } %t78, ptr %rv
  br label %ret
bb20:
  %t79 = load ptr, ptr %l25, !tbaa !29
  store ptr %t79, ptr %l3, !tbaa !29
  %t80 = load ptr, ptr %l0, !tbaa !29
  %t81 = load i32, ptr %l1, !tbaa !23
  %t84 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t80, i32 %t81)
  store %"compiler/source:Span" %t84, ptr %l33
  br label %bb21
bb21:
  %t85 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t86
  %t87 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 0
  store i64 3, ptr %t87
  %t88 = load %"compiler/source:Span", ptr %l33
  %t89 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t88, 0
  %t91 = insertvalue { %"compiler/source:Span", i32, ptr } %t89, i32 48, 1
  %t93 = insertvalue { %"compiler/source:Span", i32, ptr } %t91, ptr %t85, 2
  %t94 = getelementptr { i64, [4 x i64] }, ptr %t86, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t93, ptr %t94
  %t95 = load { i64, [4 x i64] }, ptr %t86
  %t97 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t95, ptr %t97
  store ptr %t97, ptr %l37, !tbaa !29
  %t98 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %t98)
  br label %bb22
bb22:
  %t100 = load ptr, ptr %l37, !tbaa !29
  %t101 = insertvalue { i32, ptr } zeroinitializer, ptr %t100, 1
  store { i32, ptr } %t101, ptr %rv
  br label %ret
bb23:
  %t102 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t104 = trunc i64 18 to i32
  %t105 = icmp eq i32 %t102, %t104
  br i1 %t105, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  br label %bb32
bb26:
  %t107 = load ptr, ptr %l0, !tbaa !29
  %t109 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t107)
  store i32 %t109, ptr %l42
  br label %bb27
bb27:
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t110)
  %t113 = extractvalue { i32, ptr } %t112, 1
  %t114 = extractvalue { i32, ptr } %t112, 0
  store i32 %t114, ptr %l46
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb29, label %ok.116, !prof !99
ok.116:
  store ptr %t113, ptr %l45
  br label %bb28
bb28:
  %t117 = load ptr, ptr %l45, !tbaa !29
  store ptr %t117, ptr %l43, !tbaa !29
  br label %bb30
bb29:
  %t118 = load i32, ptr %l46, !tbaa !23
  %t119 = lshr i32 %t118, 16
  %t120 = and i32 %t118, 65535
  %t121 = icmp eq i32 %t119, 1
  %t122 = select i1 %t121, i32 1, i32 0
  %t123 = icmp eq i32 %t118, 0
  %t124 = shl i32 %t122, 16
  %t125 = or i32 %t124, %t120
  %t126 = select i1 %t123, i32 0, i32 %t125
  %t128 = insertvalue { i32, ptr } zeroinitializer, i32 %t126, 0
  store { i32, ptr } %t128, ptr %rv
  br label %ret
bb30:
  %t129 = load ptr, ptr %l43, !tbaa !29
  store ptr %t129, ptr %l4, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  %t131 = load i32, ptr %l1, !tbaa !23
  %t134 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t130, i32 %t131)
  store %"compiler/source:Span" %t134, ptr %l50
  br label %bb31
bb31:
  %t135 = load ptr, ptr %l4, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t136
  %t137 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 0
  store i64 3, ptr %t137
  %t138 = load %"compiler/source:Span", ptr %l50
  %t139 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t138, 0
  %t141 = insertvalue { %"compiler/source:Span", i32, ptr } %t139, i32 18, 1
  %t143 = insertvalue { %"compiler/source:Span", i32, ptr } %t141, ptr %t135, 2
  %t144 = getelementptr { i64, [4 x i64] }, ptr %t136, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t143, ptr %t144
  %t145 = load { i64, [4 x i64] }, ptr %t136
  %t147 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t145, ptr %t147
  %t149 = insertvalue { i32, ptr } zeroinitializer, ptr %t147, 1
  store { i32, ptr } %t149, ptr %rv
  br label %ret
bb32:
  %t150 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t152 = trunc i64 69 to i32
  %t153 = icmp eq i32 %t150, %t152
  br i1 %t153, label %bb33, label %bb34
bb33:
  br label %bb41
bb34:
  %t155 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t157 = trunc i64 105 to i32
  %t158 = icmp eq i32 %t155, %t157
  br i1 %t158, label %bb35, label %bb36
bb35:
  br label %bb41
bb36:
  %t160 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t162 = trunc i64 93 to i32
  %t163 = icmp eq i32 %t160, %t162
  br i1 %t163, label %bb37, label %bb38
bb37:
  br label %bb41
bb38:
  %t165 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t167 = trunc i64 94 to i32
  %t168 = icmp eq i32 %t165, %t167
  br i1 %t168, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb48
bb41:
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t172 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %t170)
  store i32 %t172, ptr %l64
  br label %bb42
bb42:
  %t173 = load i32, ptr %l64, !range !{i32 0, i32 116}
  store i32 %t173, ptr %l5
  %t174 = load ptr, ptr %l0, !tbaa !29
  %t176 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t174)
  store i32 %t176, ptr %l66
  br label %bb43
bb43:
  %t177 = load ptr, ptr %l0, !tbaa !29
  %t179 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eunary(ptr %v0, ptr %v1, ptr %t177)
  %t180 = extractvalue { i32, ptr } %t179, 1
  %t181 = extractvalue { i32, ptr } %t179, 0
  store i32 %t181, ptr %l70
  %t182 = icmp ne i32 %t181, 0
  br i1 %t182, label %bb45, label %ok.183, !prof !99
ok.183:
  store ptr %t180, ptr %l69
  br label %bb44
bb44:
  %t184 = load ptr, ptr %l69, !tbaa !29
  store ptr %t184, ptr %l67, !tbaa !29
  br label %bb46
bb45:
  %t185 = load i32, ptr %l70, !tbaa !23
  %t186 = lshr i32 %t185, 16
  %t187 = and i32 %t185, 65535
  %t188 = icmp eq i32 %t186, 1
  %t189 = select i1 %t188, i32 1, i32 0
  %t190 = icmp eq i32 %t185, 0
  %t191 = shl i32 %t189, 16
  %t192 = or i32 %t191, %t187
  %t193 = select i1 %t190, i32 0, i32 %t192
  %t195 = insertvalue { i32, ptr } zeroinitializer, i32 %t193, 0
  store { i32, ptr } %t195, ptr %rv
  br label %ret
bb46:
  %t196 = load ptr, ptr %l67, !tbaa !29
  store ptr %t196, ptr %l6, !tbaa !29
  %t197 = load ptr, ptr %l0, !tbaa !29
  %t198 = load i32, ptr %l1, !tbaa !23
  %t201 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t197, i32 %t198)
  store %"compiler/source:Span" %t201, ptr %l74
  br label %bb47
bb47:
  %t202 = load i32, ptr %l5, !range !{i32 0, i32 116}
  %t203 = load ptr, ptr %l6, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t204
  %t205 = getelementptr { i64, [4 x i64] }, ptr %t204, i32 0, i32 0
  store i64 3, ptr %t205
  %t206 = load %"compiler/source:Span", ptr %l74
  %t207 = insertvalue { %"compiler/source:Span", i32, ptr } undef, %"compiler/source:Span" %t206, 0
  %t209 = insertvalue { %"compiler/source:Span", i32, ptr } %t207, i32 %t202, 1
  %t211 = insertvalue { %"compiler/source:Span", i32, ptr } %t209, ptr %t203, 2
  %t212 = getelementptr { i64, [4 x i64] }, ptr %t204, i32 0, i32 1
  store { %"compiler/source:Span", i32, ptr } %t211, ptr %t212
  %t213 = load { i64, [4 x i64] }, ptr %t204
  %t215 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 40, i64 8)
  store { i64, [4 x i64] } %t213, ptr %t215
  %t217 = insertvalue { i32, ptr } zeroinitializer, ptr %t215, 1
  store { i32, ptr } %t217, ptr %rv
  br label %ret
bb48:
  %t218 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t220 = trunc i64 5 to i32
  %t221 = icmp eq i32 %t218, %t220
  br i1 %t221, label %bb49, label %bb50
bb49:
  br label %bb53
bb50:
  %t223 = load i32, ptr %l2, !range !{i32 0, i32 116}
  %t225 = trunc i64 107 to i32
  %t226 = icmp eq i32 %t223, %t225
  br i1 %t226, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  br label %bb70
bb53:
  %t228 = load ptr, ptr %l0, !tbaa !29
  %t230 = getelementptr %"compiler/parse:Parser", ptr %t228, i32 0, i32 50
  %t231 = load i1, ptr %t230, !tbaa !21
  br i1 %t231, label %bb54, label %bb55
bb54:
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t234 = load i32, ptr %l1, !tbaa !23
  %t237 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadjacent(ptr %v0, ptr %v1, ptr %t233, i32 %t234)
  %t238 = extractvalue { i32, ptr } %t237, 1
  %t239 = extractvalue { i32, ptr } %t237, 0
  store i32 %t239, ptr %l89
  %t240 = icmp ne i32 %t239, 0
  br i1 %t240, label %bb57, label %ok.241, !prof !99
ok.241:
  store ptr %t238, ptr %l88
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t242 = load ptr, ptr %l88, !tbaa !29
  store ptr %t242, ptr %l85, !tbaa !29
  br label %bb58
bb57:
  %t243 = load i32, ptr %l89, !tbaa !23
  %t244 = lshr i32 %t243, 16
  %t245 = and i32 %t243, 65535
  %t246 = icmp eq i32 %t244, 1
  %t247 = select i1 %t246, i32 1, i32 0
  %t248 = icmp eq i32 %t243, 0
  %t249 = shl i32 %t247, 16
  %t250 = or i32 %t249, %t245
  %t251 = select i1 %t248, i32 0, i32 %t250
  %t253 = insertvalue { i32, ptr } zeroinitializer, i32 %t251, 0
  store { i32, ptr } %t253, ptr %rv
  br label %ret
bb58:
  %t254 = load ptr, ptr %l85, !tbaa !29
  %t255 = insertvalue { i32, ptr } zeroinitializer, ptr %t254, 1
  store { i32, ptr } %t255, ptr %rv
  br label %ret
bb59:
  %t256 = load ptr, ptr %l0, !tbaa !29
  %t259 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t256, i32 5)
  store i1 %t259, ptr %l93
  br label %bb60
bb60:
  %t260 = load i1, ptr %l93, !tbaa !21
  br i1 %t260, label %bb61, label %bb62
bb61:
  %t261 = load ptr, ptr %l0, !tbaa !29
  %t263 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %t261)
  %t264 = extractvalue { i32, ptr } %t263, 1
  %t265 = extractvalue { i32, ptr } %t263, 0
  store i32 %t265, ptr %l97
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb64, label %ok.267, !prof !99
ok.267:
  store ptr %t264, ptr %l96
  br label %bb63
bb62:
  br label %bb66
bb63:
  %t268 = load ptr, ptr %l96, !tbaa !29
  store ptr %t268, ptr %l94, !tbaa !29
  br label %bb65
bb64:
  %t269 = load i32, ptr %l97, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 1, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  %t279 = insertvalue { i32, ptr } zeroinitializer, i32 %t277, 0
  store { i32, ptr } %t279, ptr %rv
  br label %ret
bb65:
  %t280 = load ptr, ptr %l94, !tbaa !29
  %t281 = insertvalue { i32, ptr } zeroinitializer, ptr %t280, 1
  store { i32, ptr } %t281, ptr %rv
  br label %ret
bb66:
  %t282 = load ptr, ptr %l0, !tbaa !29
  %t284 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2erendering(ptr %v0, ptr %v1, ptr %t282)
  %t285 = extractvalue { i32, ptr } %t284, 1
  %t286 = extractvalue { i32, ptr } %t284, 0
  store i32 %t286, ptr %l102
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb68, label %ok.288, !prof !99
ok.288:
  store ptr %t285, ptr %l101
  br label %bb67
bb67:
  %t289 = load ptr, ptr %l101, !tbaa !29
  store ptr %t289, ptr %l99, !tbaa !29
  br label %bb69
bb68:
  %t290 = load i32, ptr %l102, !tbaa !23
  %t291 = lshr i32 %t290, 16
  %t292 = and i32 %t290, 65535
  %t293 = icmp eq i32 %t291, 1
  %t294 = select i1 %t293, i32 1, i32 0
  %t295 = icmp eq i32 %t290, 0
  %t296 = shl i32 %t294, 16
  %t297 = or i32 %t296, %t292
  %t298 = select i1 %t295, i32 0, i32 %t297
  %t300 = insertvalue { i32, ptr } zeroinitializer, i32 %t298, 0
  store { i32, ptr } %t300, ptr %rv
  br label %ret
bb69:
  %t301 = load ptr, ptr %l99, !tbaa !29
  %t302 = insertvalue { i32, ptr } zeroinitializer, ptr %t301, 1
  store { i32, ptr } %t302, ptr %rv
  br label %ret
bb70:
  br i1 true, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  br label %bb77
bb73:
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epower(ptr %v0, ptr %v1, ptr %t303)
  %t306 = extractvalue { i32, ptr } %t305, 1
  %t307 = extractvalue { i32, ptr } %t305, 0
  store i32 %t307, ptr %l107
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb75, label %ok.309, !prof !99
ok.309:
  store ptr %t306, ptr %l106
  br label %bb74
bb74:
  %t310 = load ptr, ptr %l106, !tbaa !29
  store ptr %t310, ptr %l104, !tbaa !29
  br label %bb76
bb75:
  %t311 = load i32, ptr %l107, !tbaa !23
  %t312 = lshr i32 %t311, 16
  %t313 = and i32 %t311, 65535
  %t314 = icmp eq i32 %t312, 1
  %t315 = select i1 %t314, i32 1, i32 0
  %t316 = icmp eq i32 %t311, 0
  %t317 = shl i32 %t315, 16
  %t318 = or i32 %t317, %t313
  %t319 = select i1 %t316, i32 0, i32 %t318
  %t321 = insertvalue { i32, ptr } zeroinitializer, i32 %t319, 0
  store { i32, ptr } %t321, ptr %rv
  br label %ret
bb76:
  %t322 = load ptr, ptr %l104, !tbaa !29
  %t323 = insertvalue { i32, ptr } zeroinitializer, ptr %t322, 1
  store { i32, ptr } %t323, ptr %rv
  br label %ret
bb77:
  call void @__olang_check_failed(ptr @olang_loc_5787450c8afeca22_493a6afca2796a86)
  unreachable
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2evalueAfterEq(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l32 = alloca i64
  %l34 = alloca i32
  %l43 = alloca i1
  %l46 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l71 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l84 = alloca i1
  %l85 = alloca { i64, ptr }
  %l97 = alloca i1
  %l98 = alloca { i64, ptr }
  %l102 = alloca i1
  %l103 = alloca { i64, ptr }
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l120 = alloca i1
  %l121 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l130 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l139 = alloca i1
  %l146 = alloca i1
  %l147 = alloca { i64, ptr }
  %l160 = alloca i1
  %l161 = alloca { i64, ptr }
  %l173 = alloca i1
  %l183 = alloca i64
  %l186 = alloca i64
  %l195 = alloca i64
  %l198 = alloca i1
  %l208 = alloca { i64, ptr }
  %l212 = alloca i1
  %l213 = alloca { i64, ptr }
  %l217 = alloca i1
  %l218 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l254 = alloca { i64, ptr }
  %l255 = alloca i64
  %l256 = alloca i64
  %l257 = alloca i64
  %l261 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca i64
  %l265 = alloca i64
  %l266 = alloca i64
  %l272 = alloca ptr
  %l273 = alloca i64
  %l274 = alloca { i64, ptr }
  %l275 = alloca i64
  %l276 = alloca i64
  %l277 = alloca i64
  %l281 = alloca { i64, ptr }
  %l282 = alloca { i64, ptr }
  %l283 = alloca { i64, ptr }
  %l284 = alloca i64
  %l285 = alloca i64
  %l286 = alloca i64
  %l292 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/parse:Parser", ptr %t1, i32 0, i32 1
  %t4 = load ptr, ptr %t3, !tbaa !29
  %t6 = getelementptr %"compiler/scan:Tokens", ptr %t4, i32 0, i32 0
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l24, !tbaa !27
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t11 = load ptr, ptr %t10, !tbaa !27
  %t12 = getelementptr %"compiler/token:Token", ptr %t11, i64 %t8
  %t13 = getelementptr %"compiler/token:Token", ptr %t12, i32 0, i32 2
  %t14 = load i32, ptr %t13, !tbaa !23
  %t16 = sext i32 %t14 to i64
  store i64 %t16, ptr %l2, !tbaa !24
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/parse:Parser", ptr %t18, i32 0, i32 0
  %t21 = load ptr, ptr %t20, !tbaa !29
  store ptr %t21, ptr %l29, !tbaa !29
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t23 = load i64, ptr %l1, !tbaa !24
  %t26 = call i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %t22, i64 %t23)
  store i64 %t26, ptr %l32
  br label %bb1
bb1:
  %t27 = load i64, ptr %l32, !tbaa !24
  %t28 = trunc i64 %t27 to i32
  %t29 = load ptr, ptr %l29, !tbaa !29
  %t31 = call i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %t29, i32 %t28)
  store i32 %t31, ptr %l34
  br label %bb2
bb2:
  %t32 = load i32, ptr %l34, !tbaa !23
  %t33 = sext i32 %t32 to i64
  store i64 %t33, ptr %l3, !tbaa !24
  %t35 = load i64, ptr %l2, !tbaa !24
  store i64 %t35, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load ptr, ptr %l0, !tbaa !29
  %t40 = getelementptr %"compiler/parse:Parser", ptr %t38, i32 0, i32 0
  %t41 = load ptr, ptr %t40, !tbaa !29
  %t43 = getelementptr %"compiler/source:Source", ptr %t41, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  %t49 = icmp slt i64 %t37, %t46
  br i1 %t49, label %bb4, label %bb5
bb4:
  %t51 = load ptr, ptr %l0, !tbaa !29
  %t53 = getelementptr %"compiler/parse:Parser", ptr %t51, i32 0, i32 0
  %t54 = load ptr, ptr %t53, !tbaa !29
  %t56 = getelementptr %"compiler/source:Source", ptr %t54, i32 0, i32 1
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  store { i64, ptr } %t57, ptr %l46, !tbaa !27
  %t58 = load i64, ptr %l4, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr i8, ptr %t61, i64 %t58
  %t63 = load i8, ptr %t62, !tbaa !32
  %t65 = icmp ne i8 %t63, 10
  store i1 %t65, ptr %l43, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l43, !tbaa !21
  br label %bb6
bb6:
  %t67 = load i1, ptr %l43, !tbaa !21
  %t68 = xor i1 %t67, true
  br i1 %t68, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t70 = load i64, ptr %l4, !tbaa !24
  %t73 = add i64 %t70, 1
  store i64 %t73, ptr %l4, !tbaa !24
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t75 = load ptr, ptr %l0, !tbaa !29
  %t77 = getelementptr %"compiler/parse:Parser", ptr %t75, i32 0, i32 0
  %t78 = load ptr, ptr %t77, !tbaa !29
  %t80 = getelementptr %"compiler/source:Source", ptr %t78, i32 0, i32 1
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  store { i64, ptr } %t81, ptr %l56, !tbaa !27
  %t82 = load i64, ptr %l3, !tbaa !24
  store i64 %t82, ptr %l57, !tbaa !24
  %t83 = load i64, ptr %l4, !tbaa !24
  store i64 %t83, ptr %l58, !tbaa !24
  %t84 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 0
  store i64 %t85, ptr %l59, !tbaa !24
  %t86 = load i64, ptr %l57, !tbaa !24
  %t87 = icmp sge i64 %t86, 0
  br i1 %t87, label %bb12, label %bb13
bb12:
  %t89 = load i64, ptr %l57, !tbaa !24
  %t90 = load i64, ptr %l58, !tbaa !24
  %t91 = icmp sle i64 %t89, %t90
  br i1 %t91, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb14:
  %t93 = load i64, ptr %l58, !tbaa !24
  %t94 = load i64, ptr %l59, !tbaa !24
  %t95 = icmp sle i64 %t93, %t94
  br i1 %t95, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb16:
  %t97 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = load i64, ptr %l57, !tbaa !24
  %t100 = load i64, ptr %l58, !tbaa !24
  %t101 = getelementptr i8, ptr %t98, i64 %t99
  %t102 = sub i64 %t100, %t99
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  store { i64, ptr } %t104, ptr %l5, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 0
  store i64 %t108, ptr %l6, !tbaa !24
  %t110 = load i64, ptr %l2, !tbaa !24
  %t111 = load i64, ptr %l3, !tbaa !24
  %t114 = sub i64 %t110, %t111
  store i64 %t114, ptr %l7, !tbaa !24
  %t116 = load i64, ptr %l7, !tbaa !24
  %t118 = icmp sle i64 %t116, 0
  br i1 %t118, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_4582cd3e20803687_2be8b05c8d066113)
  unreachable
bb18:
  store i1 true, ptr %l71, !tbaa !21
  br label %bb20
bb19:
  %t120 = load i64, ptr %l7, !tbaa !24
  %t121 = load i64, ptr %l6, !tbaa !24
  %t124 = icmp sge i64 %t120, %t121
  store i1 %t124, ptr %l71, !tbaa !21
  br label %bb20
bb20:
  %t126 = load i1, ptr %l71, !tbaa !21
  br i1 %t126, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb22:
  br label %bb23
bb23:
  store i64 0, ptr %l8, !tbaa !24
  br label %bb24
bb24:
  %t128 = load i64, ptr %l8, !tbaa !24
  %t129 = load i64, ptr %l7, !tbaa !24
  %t132 = icmp slt i64 %t128, %t129
  br i1 %t132, label %bb25, label %bb26
bb25:
  %t134 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t134, ptr %l80, !tbaa !27
  %t135 = load i64, ptr %l8, !tbaa !24
  %t137 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t138 = load ptr, ptr %t137, !tbaa !27
  %t139 = getelementptr i8, ptr %t138, i64 %t135
  %t140 = load i8, ptr %t139, !tbaa !32
  %t142 = icmp eq i8 %t140, 32
  br i1 %t142, label %bb27, label %bb28
bb26:
  store i1 false, ptr %l79, !tbaa !21
  br label %bb30
bb27:
  store i1 true, ptr %l84, !tbaa !21
  br label %bb29
bb28:
  %t144 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t144, ptr %l85, !tbaa !27
  %t145 = load i64, ptr %l8, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t145
  %t150 = load i8, ptr %t149, !tbaa !32
  %t152 = icmp eq i8 %t150, 9
  store i1 %t152, ptr %l84, !tbaa !21
  br label %bb29
bb29:
  %t154 = load i1, ptr %l84, !tbaa !21
  store i1 %t154, ptr %l79, !tbaa !21
  br label %bb30
bb30:
  %t155 = load i1, ptr %l79, !tbaa !21
  %t156 = xor i1 %t155, true
  br i1 %t156, label %bb31, label %bb32
bb31:
  br label %bb35
bb32:
  br label %bb33
bb33:
  %t158 = load i64, ptr %l8, !tbaa !24
  %t161 = add i64 %t158, 1
  store i64 %t161, ptr %l8, !tbaa !24
  br label %bb34
bb34:
  br label %bb24
bb35:
  %t163 = load i64, ptr %l8, !tbaa !24
  store i64 %t163, ptr %l9, !tbaa !24
  br label %bb36
bb36:
  %t165 = load i64, ptr %l8, !tbaa !24
  %t166 = load i64, ptr %l7, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  br i1 %t169, label %bb37, label %bb38
bb37:
  %t171 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t171, ptr %l98, !tbaa !27
  %t172 = load i64, ptr %l8, !tbaa !24
  %t174 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t175 = load ptr, ptr %t174, !tbaa !27
  %t176 = getelementptr i8, ptr %t175, i64 %t172
  %t177 = load i8, ptr %t176, !tbaa !32
  %t179 = icmp ne i8 %t177, 32
  store i1 %t179, ptr %l97, !tbaa !21
  br label %bb39
bb38:
  store i1 false, ptr %l97, !tbaa !21
  br label %bb39
bb39:
  %t181 = load i1, ptr %l97, !tbaa !21
  br i1 %t181, label %bb40, label %bb41
bb40:
  %t182 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t182, ptr %l103, !tbaa !27
  %t183 = load i64, ptr %l8, !tbaa !24
  %t185 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr i8, ptr %t186, i64 %t183
  %t188 = load i8, ptr %t187, !tbaa !32
  %t190 = icmp ne i8 %t188, 9
  store i1 %t190, ptr %l102, !tbaa !21
  br label %bb42
bb41:
  store i1 false, ptr %l102, !tbaa !21
  br label %bb42
bb42:
  %t192 = load i1, ptr %l102, !tbaa !21
  %t193 = xor i1 %t192, true
  br i1 %t193, label %bb43, label %bb44
bb43:
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t195 = load i64, ptr %l8, !tbaa !24
  %t198 = add i64 %t195, 1
  store i64 %t198, ptr %l8, !tbaa !24
  br label %bb46
bb46:
  br label %bb36
bb47:
  %t200 = load i64, ptr %l8, !tbaa !24
  store i64 %t200, ptr %l10, !tbaa !24
  br label %bb48
bb48:
  %t202 = load i64, ptr %l8, !tbaa !24
  %t203 = load i64, ptr %l7, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  br i1 %t206, label %bb49, label %bb50
bb49:
  %t208 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t208, ptr %l116, !tbaa !27
  %t209 = load i64, ptr %l8, !tbaa !24
  %t211 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t212 = load ptr, ptr %t211, !tbaa !27
  %t213 = getelementptr i8, ptr %t212, i64 %t209
  %t214 = load i8, ptr %t213, !tbaa !32
  %t216 = icmp eq i8 %t214, 32
  br i1 %t216, label %bb51, label %bb52
bb50:
  store i1 false, ptr %l115, !tbaa !21
  br label %bb54
bb51:
  store i1 true, ptr %l120, !tbaa !21
  br label %bb53
bb52:
  %t218 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t218, ptr %l121, !tbaa !27
  %t219 = load i64, ptr %l8, !tbaa !24
  %t221 = getelementptr { i64, ptr }, ptr %l121, i32 0, i32 1
  %t222 = load ptr, ptr %t221, !tbaa !27
  %t223 = getelementptr i8, ptr %t222, i64 %t219
  %t224 = load i8, ptr %t223, !tbaa !32
  %t226 = icmp eq i8 %t224, 9
  store i1 %t226, ptr %l120, !tbaa !21
  br label %bb53
bb53:
  %t228 = load i1, ptr %l120, !tbaa !21
  store i1 %t228, ptr %l115, !tbaa !21
  br label %bb54
bb54:
  %t229 = load i1, ptr %l115, !tbaa !21
  %t230 = xor i1 %t229, true
  br i1 %t230, label %bb55, label %bb56
bb55:
  br label %bb59
bb56:
  br label %bb57
bb57:
  %t232 = load i64, ptr %l8, !tbaa !24
  %t235 = add i64 %t232, 1
  store i64 %t235, ptr %l8, !tbaa !24
  br label %bb58
bb58:
  br label %bb48
bb59:
  %t237 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t237, ptr %l129, !tbaa !27
  %t238 = load i64, ptr %l8, !tbaa !24
  store i64 %t238, ptr %l130, !tbaa !24
  %t239 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t239, 0
  store i64 %t242, ptr %l133, !tbaa !24
  %t243 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 0
  store i64 %t244, ptr %l134, !tbaa !24
  %t245 = load i64, ptr %l130, !tbaa !24
  %t246 = icmp sge i64 %t245, 0
  br i1 %t246, label %bb60, label %bb61
bb60:
  %t248 = load i64, ptr %l130, !tbaa !24
  %t249 = load i64, ptr %l133, !tbaa !24
  %t250 = icmp sle i64 %t248, %t249
  br i1 %t250, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb62:
  %t252 = load i64, ptr %l133, !tbaa !24
  %t253 = load i64, ptr %l134, !tbaa !24
  %t254 = icmp sle i64 %t252, %t253
  br i1 %t254, label %bb64, label %bb65
bb63:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb64:
  %t256 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = load i64, ptr %l130, !tbaa !24
  %t259 = load i64, ptr %l133, !tbaa !24
  %t260 = getelementptr i8, ptr %t257, i64 %t258
  %t261 = sub i64 %t259, %t258
  %t262 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t260, 1
  %t265 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t263, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d14, i32 0, i32 1) })
  store i1 %t265, ptr %l139
  br label %bb66
bb65:
  call void @__olang_check_failed(ptr @olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6)
  unreachable
bb66:
  %t266 = load i1, ptr %l139, !tbaa !21
  br i1 %t266, label %bb67, label %bb68
bb67:
  %t267 = load i64, ptr %l8, !tbaa !24
  %t270 = add i64 %t267, 4
  store i64 %t270, ptr %l8, !tbaa !24
  br label %bb69
bb68:
  br label %bb78
bb69:
  %t272 = load i64, ptr %l8, !tbaa !24
  %t273 = load i64, ptr %l7, !tbaa !24
  %t276 = icmp slt i64 %t272, %t273
  br i1 %t276, label %bb70, label %bb71
bb70:
  %t278 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t278, ptr %l147, !tbaa !27
  %t279 = load i64, ptr %l8, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr i8, ptr %t282, i64 %t279
  %t284 = load i8, ptr %t283, !tbaa !32
  %t286 = icmp eq i8 %t284, 32
  store i1 %t286, ptr %l146, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l146, !tbaa !21
  br label %bb72
bb72:
  %t288 = load i1, ptr %l146, !tbaa !21
  %t289 = xor i1 %t288, true
  br i1 %t289, label %bb73, label %bb74
bb73:
  br label %bb77
bb74:
  br label %bb75
bb75:
  %t291 = load i64, ptr %l8, !tbaa !24
  %t294 = add i64 %t291, 1
  store i64 %t294, ptr %l8, !tbaa !24
  br label %bb76
bb76:
  br label %bb69
bb77:
  br label %bb78
bb78:
  %t296 = load i64, ptr %l8, !tbaa !24
  store i64 %t296, ptr %l11, !tbaa !24
  %t298 = load i64, ptr %l7, !tbaa !24
  store i64 %t298, ptr %l12, !tbaa !24
  br label %bb79
bb79:
  %t300 = load i64, ptr %l12, !tbaa !24
  %t301 = load i64, ptr %l11, !tbaa !24
  %t304 = icmp sgt i64 %t300, %t301
  br i1 %t304, label %bb80, label %bb81
bb80:
  %t306 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t306, ptr %l161, !tbaa !27
  %t307 = load i64, ptr %l12, !tbaa !24
  %t309 = sub i64 %t307, 1
  %t311 = getelementptr { i64, ptr }, ptr %l161, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr i8, ptr %t312, i64 %t309
  %t314 = load i8, ptr %t313, !tbaa !32
  %t316 = icmp eq i8 %t314, 32
  store i1 %t316, ptr %l160, !tbaa !21
  br label %bb82
bb81:
  store i1 false, ptr %l160, !tbaa !21
  br label %bb82
bb82:
  %t318 = load i1, ptr %l160, !tbaa !21
  %t319 = xor i1 %t318, true
  br i1 %t319, label %bb83, label %bb84
bb83:
  br label %bb87
bb84:
  br label %bb85
bb85:
  %t321 = load i64, ptr %l12, !tbaa !24
  %t324 = sub i64 %t321, 1
  store i64 %t324, ptr %l12, !tbaa !24
  br label %bb86
bb86:
  br label %bb79
bb87:
  %t326 = load i64, ptr %l10, !tbaa !24
  %t327 = load i64, ptr %l9, !tbaa !24
  %t330 = icmp eq i64 %t326, %t327
  br i1 %t330, label %bb88, label %bb89
bb88:
  store i1 true, ptr %l173, !tbaa !21
  br label %bb90
bb89:
  %t332 = load i64, ptr %l12, !tbaa !24
  %t333 = load i64, ptr %l11, !tbaa !24
  %t336 = icmp eq i64 %t332, %t333
  store i1 %t336, ptr %l173, !tbaa !21
  br label %bb90
bb90:
  %t338 = load i1, ptr %l173, !tbaa !21
  br i1 %t338, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t340 = load i64, ptr %l9, !tbaa !24
  store i64 %t340, ptr %l13, !tbaa !24
  %t342 = load i64, ptr %l7, !tbaa !24
  store i64 %t342, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t344 = load i64, ptr %l14, !tbaa !24
  %t345 = load i64, ptr %l13, !tbaa !24
  %t348 = icmp sgt i64 %t344, %t345
  br i1 %t348, label %bb94, label %bb95
bb94:
  %t350 = load i64, ptr %l15, !tbaa !24
  %t352 = icmp sgt i64 %t350, 0
  br i1 %t352, label %bb96, label %bb97
bb95:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb99
bb96:
  %t354 = load i64, ptr %l14, !tbaa !24
  %t355 = load i64, ptr %l13, !tbaa !24
  %t358 = sub i64 %t354, %t355
  %t359 = load i64, ptr %l15, !tbaa !24
  %t362 = add i64 %t358, %t359
  %t364 = sub i64 %t362, 1
  %t365 = load i64, ptr %l15, !tbaa !24
  %t368 = sdiv i64 %t364, %t365
  store i64 %t368, ptr %l186, !tbaa !24
  br label %bb98
bb97:
  store i64 0, ptr %l186, !tbaa !24
  br label %bb98
bb98:
  %t370 = load i64, ptr %l186, !tbaa !24
  store i64 %t370, ptr %l183, !tbaa !24
  br label %bb99
bb99:
  %t371 = load i64, ptr %l183, !tbaa !24
  store i64 %t371, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  %t372 = load i64, ptr %l16, !tbaa !24
  %t373 = sub i64 %t372, 1
  store i64 %t373, ptr %l195, !tbaa !24
  %t374 = load i64, ptr %l16, !tbaa !24
  %t375 = icmp slt i64 %t374, 2147483648
  %t376 = load i64, ptr %l17, !tbaa !24
  %t377 = icmp sge i64 %t376, 0
  %t380 = and i1 %t375, %t377
  store i1 %t380, ptr %l198, !tbaa !21
  br label %bb100
bb100:
  %t381 = load i64, ptr %l17, !tbaa !24
  %t382 = load i64, ptr %l16, !tbaa !24
  %t385 = icmp slt i64 %t381, %t382
  %t387 = xor i1 %t385, true
  br i1 %t387, label %bb101, label %bb102
bb101:
  br label %bb114
bb102:
  br label %bb103
bb103:
  %t389 = load i64, ptr %l13, !tbaa !24
  %t390 = load i64, ptr %l17, !tbaa !24
  %t391 = load i64, ptr %l15, !tbaa !24
  %t394 = mul i64 %t390, %t391
  %t397 = add i64 %t389, %t394
  store i64 %t397, ptr %l18, !tbaa !24
  %t399 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t399, ptr %l208, !tbaa !27
  %t400 = load i64, ptr %l18, !tbaa !24
  %t402 = getelementptr { i64, ptr }, ptr %l208, i32 0, i32 1
  %t403 = load ptr, ptr %t402, !tbaa !27
  %t404 = getelementptr i8, ptr %t403, i64 %t400
  %t405 = load i8, ptr %t404, !tbaa !32
  %t407 = icmp eq i8 %t405, 61
  br i1 %t407, label %bb104, label %bb105
bb104:
  store i1 true, ptr %l212, !tbaa !21
  br label %bb106
bb105:
  %t409 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t409, ptr %l213, !tbaa !27
  %t410 = load i64, ptr %l18, !tbaa !24
  %t412 = getelementptr { i64, ptr }, ptr %l213, i32 0, i32 1
  %t413 = load ptr, ptr %t412, !tbaa !27
  %t414 = getelementptr i8, ptr %t413, i64 %t410
  %t415 = load i8, ptr %t414, !tbaa !32
  %t417 = icmp eq i8 %t415, 58
  store i1 %t417, ptr %l212, !tbaa !21
  br label %bb106
bb106:
  %t419 = load i1, ptr %l212, !tbaa !21
  br i1 %t419, label %bb107, label %bb108
bb107:
  store i1 true, ptr %l217, !tbaa !21
  br label %bb109
bb108:
  %t420 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t420, ptr %l218, !tbaa !27
  %t421 = load i64, ptr %l18, !tbaa !24
  %t423 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t424 = load ptr, ptr %t423, !tbaa !27
  %t425 = getelementptr i8, ptr %t424, i64 %t421
  %t426 = load i8, ptr %t425, !tbaa !32
  %t428 = icmp eq i8 %t426, 40
  store i1 %t428, ptr %l217, !tbaa !21
  br label %bb109
bb109:
  %t430 = load i1, ptr %l217, !tbaa !21
  br i1 %t430, label %bb110, label %bb111
bb110:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb111:
  br label %bb112
bb112:
  br label %bb113
bb113:
  %t432 = load i64, ptr %l17, !tbaa !24
  %t435 = add i64 %t432, 1
  store i64 %t435, ptr %l17, !tbaa !24
  br label %bb100
bb114:
  store i64 0, ptr %l19, !tbaa !24
  %t437 = load i64, ptr %l7, !tbaa !24
  store i64 %t437, ptr %l20, !tbaa !24
  br label %bb115
bb115:
  %t439 = load i64, ptr %l20, !tbaa !24
  %t440 = load i64, ptr %l6, !tbaa !24
  %t443 = icmp slt i64 %t439, %t440
  %t445 = xor i1 %t443, true
  br i1 %t445, label %bb116, label %bb117
bb116:
  br label %bb129
bb117:
  br label %bb118
bb118:
  %t447 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t447, ptr %l231, !tbaa !27
  %t448 = load i64, ptr %l20, !tbaa !24
  %t450 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t451 = load ptr, ptr %t450, !tbaa !27
  %t452 = getelementptr i8, ptr %t451, i64 %t448
  %t453 = load i8, ptr %t452, !tbaa !32
  %t455 = icmp eq i8 %t453, 40
  br i1 %t455, label %bb119, label %bb120
bb119:
  %t457 = load i64, ptr %l19, !tbaa !24
  %t460 = add i64 %t457, 1
  store i64 %t460, ptr %l19, !tbaa !24
  br label %bb127
bb120:
  %t462 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t462, ptr %l238, !tbaa !27
  %t463 = load i64, ptr %l20, !tbaa !24
  %t465 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr i8, ptr %t466, i64 %t463
  %t468 = load i8, ptr %t467, !tbaa !32
  %t470 = icmp eq i8 %t468, 41
  br i1 %t470, label %bb121, label %bb122
bb121:
  %t472 = load i64, ptr %l19, !tbaa !24
  %t475 = sub i64 %t472, 1
  store i64 %t475, ptr %l19, !tbaa !24
  %t477 = load i64, ptr %l19, !tbaa !24
  %t479 = icmp eq i64 %t477, 0
  br i1 %t479, label %bb123, label %bb124
bb122:
  br label %bb126
bb123:
  br label %bb129
bb124:
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t481 = load i64, ptr %l20, !tbaa !24
  %t484 = add i64 %t481, 1
  store i64 %t484, ptr %l20, !tbaa !24
  br label %bb128
bb128:
  br label %bb115
bb129:
  %t486 = load i64, ptr %l20, !tbaa !24
  %t487 = load i64, ptr %l6, !tbaa !24
  %t490 = icmp sge i64 %t486, %t487
  br i1 %t490, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t493 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t493, ptr %l254, !tbaa !27
  %t494 = load i64, ptr %l11, !tbaa !24
  store i64 %t494, ptr %l255, !tbaa !24
  %t495 = load i64, ptr %l12, !tbaa !24
  store i64 %t495, ptr %l256, !tbaa !24
  %t496 = load { i64, ptr }, ptr %l254, !tbaa !27
  %t497 = extractvalue { i64, ptr } %t496, 0
  store i64 %t497, ptr %l257, !tbaa !24
  %t498 = load i64, ptr %l255, !tbaa !24
  %t499 = icmp sge i64 %t498, 0
  br i1 %t499, label %bb133, label %bb134
bb133:
  %t501 = load i64, ptr %l255, !tbaa !24
  %t502 = load i64, ptr %l256, !tbaa !24
  %t503 = icmp sle i64 %t501, %t502
  br i1 %t503, label %bb135, label %bb136
bb134:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb135:
  %t505 = load i64, ptr %l256, !tbaa !24
  %t506 = load i64, ptr %l257, !tbaa !24
  %t507 = icmp sle i64 %t505, %t506
  br i1 %t507, label %bb137, label %bb138
bb136:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb137:
  %t509 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t510 = load ptr, ptr %t509, !tbaa !27
  %t511 = load i64, ptr %l255, !tbaa !24
  %t512 = load i64, ptr %l256, !tbaa !24
  %t513 = getelementptr i8, ptr %t510, i64 %t511
  %t514 = sub i64 %t512, %t511
  %t515 = insertvalue { i64, ptr } undef, i64 %t514, 0
  %t516 = insertvalue { i64, ptr } %t515, ptr %t513, 1
  store { i64, ptr } %t516, ptr %l261, !tbaa !27
  %t517 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t517, ptr %l262, !tbaa !27
  %t518 = load i64, ptr %l7, !tbaa !24
  store i64 %t518, ptr %l263, !tbaa !24
  %t519 = load i64, ptr %l20, !tbaa !24
  %t521 = add i64 %t519, 1
  store i64 %t521, ptr %l265, !tbaa !24
  %t522 = load { i64, ptr }, ptr %l262, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t522, 0
  store i64 %t523, ptr %l266, !tbaa !24
  %t524 = load i64, ptr %l263, !tbaa !24
  %t525 = icmp sge i64 %t524, 0
  br i1 %t525, label %bb139, label %bb140
bb138:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb139:
  %t527 = load i64, ptr %l263, !tbaa !24
  %t528 = load i64, ptr %l265, !tbaa !24
  %t529 = icmp sle i64 %t527, %t528
  br i1 %t529, label %bb141, label %bb142
bb140:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb141:
  %t531 = load i64, ptr %l265, !tbaa !24
  %t532 = load i64, ptr %l266, !tbaa !24
  %t533 = icmp sle i64 %t531, %t532
  br i1 %t533, label %bb143, label %bb144
bb142:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb143:
  %t535 = getelementptr { i64, ptr }, ptr %l262, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = load i64, ptr %l263, !tbaa !24
  %t538 = load i64, ptr %l265, !tbaa !24
  %t539 = getelementptr i8, ptr %t536, i64 %t537
  %t540 = sub i64 %t538, %t537
  %t541 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t542 = insertvalue { i64, ptr } %t541, ptr %t539, 1
  %t543 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t544 = extractvalue { i64, ptr } %t543, 1
  %t545 = extractvalue { i64, ptr } %t543, 0
  %t547 = extractvalue { i64, ptr } %t542, 1
  %t548 = extractvalue { i64, ptr } %t542, 0
  %t549 = add i64 %t545, %t548
  %t550 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t549)
  call void @olang_textcopy(ptr %t550, ptr %t544, i64 %t545)
  %t551 = getelementptr i8, ptr %t550, i64 %t545
  call void @olang_textcopy(ptr %t551, ptr %t547, i64 %t548)
  %t552 = insertvalue { i64, ptr } undef, i64 %t549, 0
  %t553 = insertvalue { i64, ptr } %t552, ptr %t550, 1
  store { i64, ptr } %t553, ptr %l21, !tbaa !27
  %t555 = load ptr, ptr %l0, !tbaa !29
  store ptr %t555, ptr %l272, !tbaa !29
  %t556 = load i64, ptr %l1, !tbaa !24
  store i64 %t556, ptr %l273, !tbaa !24
  %t557 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t557, ptr %l274, !tbaa !27
  %t558 = load i64, ptr %l9, !tbaa !24
  store i64 %t558, ptr %l275, !tbaa !24
  %t559 = load i64, ptr %l12, !tbaa !24
  store i64 %t559, ptr %l276, !tbaa !24
  %t560 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t561 = extractvalue { i64, ptr } %t560, 0
  store i64 %t561, ptr %l277, !tbaa !24
  %t562 = load i64, ptr %l275, !tbaa !24
  %t563 = icmp sge i64 %t562, 0
  br i1 %t563, label %bb145, label %bb146
bb144:
  call void @__olang_check_failed(ptr @olang_loc_8e37d10a9f86ee49_f510a1627c721295)
  unreachable
bb145:
  %t565 = load i64, ptr %l275, !tbaa !24
  %t566 = load i64, ptr %l276, !tbaa !24
  %t567 = icmp sle i64 %t565, %t566
  br i1 %t567, label %bb147, label %bb148
bb146:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb147:
  %t569 = load i64, ptr %l276, !tbaa !24
  %t570 = load i64, ptr %l277, !tbaa !24
  %t571 = icmp sle i64 %t569, %t570
  br i1 %t571, label %bb149, label %bb150
bb148:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb149:
  %t573 = getelementptr { i64, ptr }, ptr %l274, i32 0, i32 1
  %t574 = load ptr, ptr %t573, !tbaa !27
  %t575 = load i64, ptr %l275, !tbaa !24
  %t576 = load i64, ptr %l276, !tbaa !24
  %t577 = getelementptr i8, ptr %t574, i64 %t575
  %t578 = sub i64 %t576, %t575
  %t579 = insertvalue { i64, ptr } undef, i64 %t578, 0
  %t580 = insertvalue { i64, ptr } %t579, ptr %t577, 1
  store { i64, ptr } %t580, ptr %l281, !tbaa !27
  %t581 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t581, ptr %l282, !tbaa !27
  %t582 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t582, ptr %l283, !tbaa !27
  %t583 = load i64, ptr %l9, !tbaa !24
  store i64 %t583, ptr %l284, !tbaa !24
  %t584 = load i64, ptr %l10, !tbaa !24
  store i64 %t584, ptr %l285, !tbaa !24
  %t585 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t586 = extractvalue { i64, ptr } %t585, 0
  store i64 %t586, ptr %l286, !tbaa !24
  %t587 = load i64, ptr %l284, !tbaa !24
  %t588 = icmp sge i64 %t587, 0
  br i1 %t588, label %bb151, label %bb152
bb150:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb151:
  %t590 = load i64, ptr %l284, !tbaa !24
  %t591 = load i64, ptr %l285, !tbaa !24
  %t592 = icmp sle i64 %t590, %t591
  br i1 %t592, label %bb153, label %bb154
bb152:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb153:
  %t594 = load i64, ptr %l285, !tbaa !24
  %t595 = load i64, ptr %l286, !tbaa !24
  %t596 = icmp sle i64 %t594, %t595
  br i1 %t596, label %bb155, label %bb156
bb154:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb155:
  %t598 = getelementptr { i64, ptr }, ptr %l283, i32 0, i32 1
  %t599 = load ptr, ptr %t598, !tbaa !27
  %t600 = load i64, ptr %l284, !tbaa !24
  %t601 = load i64, ptr %l285, !tbaa !24
  %t602 = getelementptr i8, ptr %t599, i64 %t600
  %t603 = sub i64 %t601, %t600
  %t604 = insertvalue { i64, ptr } undef, i64 %t603, 0
  %t605 = insertvalue { i64, ptr } %t604, ptr %t602, 1
  %t606 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t607 = load { i64, ptr }, ptr %l281, !tbaa !27
  %t608 = load { i64, ptr }, ptr %l282, !tbaa !27
  %t611 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %s0, ptr %v0, ptr %s0, ptr %v0, { i64, ptr } %t607, { i64, ptr } %t608, { i64, ptr } %t605, { i64, ptr } %t606)
  store %"compiler/diagmsg:Msg" %t611, ptr %l292
  br label %bb157
bb156:
  call void @__olang_check_failed(ptr @olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8)
  unreachable
bb157:
  %t612 = load ptr, ptr %l272, !tbaa !29
  %t613 = load i64, ptr %l273, !tbaa !24
  %t614 = load %"compiler/diagmsg:Msg", ptr %l292
  call void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v0, ptr %t612, i64 %t613, %"compiler/diagmsg:Msg" %t614)
  br label %bb158
bb158:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2evarDecl(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/source:Span"
  %lp13 = alloca ptr
  %l14 = alloca %"compiler/source:Span"
  %l15 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i32
  %l25 = alloca %"compiler/source:Span"
  %l28 = alloca i1
  %l31 = alloca i1
  %l37 = alloca i1
  %l47 = alloca i64
  %l50 = alloca i64
  %l69 = alloca { i64, ptr }
  %l72 = alloca i64
  %l75 = alloca { i64, ptr }
  %l77 = alloca i32
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l83 = alloca %"compiler/source:Span"
  %l86 = alloca { i64, ptr }
  %l90 = alloca %"compiler/ast:VarDecl"
  %l101 = alloca { i64, ptr }
  %l106 = alloca i32
  %l109 = alloca %"compiler/source:Span"
  %l113 = alloca { i64, ptr }
  %l118 = alloca ptr
  %l122 = alloca i32
  %l128 = alloca i32
  %rv = alloca { i32, ptr }
  %t152 = alloca i64
  %t178 = alloca i64
  %t207 = alloca { i64, [4 x i64] }, align 8
  %t267 = alloca { i64, [4 x i64] }, align 8
  %t284 = alloca { i64, [4 x i64] }, align 8
  %t314 = alloca { i64, [4 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/parse:Parser", ptr %t3, i32 0, i32 12
  %t6 = load i1, ptr %t5, !tbaa !21
  %t10 = call { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %v2, ptr %t1, ptr %t2, i1 %t6)
  %t11 = extractvalue { i32, ptr } %t10, 1
  %t12 = extractvalue { i32, ptr } %t10, 0
  store i32 %t12, ptr %l21
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  store ptr %t11, ptr %l20
  br label %bb1
bb1:
  %t15 = load ptr, ptr %l20, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  br label %bb3
bb2:
  %t16 = load i32, ptr %l21, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 1, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, ptr } zeroinitializer, i32 %t24, 0
  store { i32, ptr } %t26, ptr %rv
  br label %ret
bb3:
  %t27 = load ptr, ptr %l15, !tbaa !29
  store ptr %t27, ptr %l3, !tbaa !29
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t32 = call %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %t28, i32 %a1)
  store %"compiler/source:Span" %t32, ptr %l25
  br label %bb4
bb4:
  %t33 = load %"compiler/source:Span", ptr %l25
  store %"compiler/source:Span" %t33, ptr %l4
  %t34 = load ptr, ptr %l0, !tbaa !29
  %t36 = getelementptr %"compiler/parse:Parser", ptr %t34, i32 0, i32 12
  %t37 = load i1, ptr %t36, !tbaa !21
  br i1 %t37, label %bb5, label %bb6
bb5:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t42 = call i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %t39, i32 75)
  store i1 %t42, ptr %l31
  br label %bb7
bb6:
  store i1 false, ptr %l28, !tbaa !21
  br label %bb8
bb7:
  %t43 = load i1, ptr %l31, !tbaa !21
  store i1 %t43, ptr %l28, !tbaa !21
  br label %bb8
bb8:
  %t44 = load i1, ptr %l28, !tbaa !21
  br i1 %t44, label %bb9, label %bb10
bb9:
  %t45 = load ptr, ptr %l2, !tbaa !29
  %t47 = getelementptr %"compiler/parse:NameList", ptr %t45, i32 0, i32 0
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t48, 0
  store i64 %t50, ptr %l5, !tbaa !24
  %t52 = load i64, ptr %l5, !tbaa !24
  %t54 = icmp sgt i64 %t52, 1
  br i1 %t54, label %bb11, label %bb12
bb10:
  br label %bb51
bb11:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = getelementptr %"compiler/ast:VarDecl", ptr %t56, i32 0, i32 3
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t59, 0
  %t63 = icmp eq i64 %t61, 0
  store i1 %t63, ptr %l37, !tbaa !21
  br label %bb13
bb12:
  store i1 false, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  %t65 = load i1, ptr %l37, !tbaa !21
  br i1 %t65, label %bb14, label %bb15
bb14:
  store i64 0, ptr %l6, !tbaa !24
  %t66 = load i64, ptr %l5, !tbaa !24
  %t68 = sub i64 %t66, 1
  store i64 %t68, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t70 = load i64, ptr %l7, !tbaa !24
  %t71 = load i64, ptr %l6, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb16, label %bb17
bb15:
  br label %bb49
bb16:
  %t76 = load i64, ptr %l8, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l47, !tbaa !24
  br label %bb21
bb18:
  %t80 = load i64, ptr %l7, !tbaa !24
  %t81 = load i64, ptr %l6, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l8, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l8, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l50, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l50, !tbaa !24
  br label %bb20
bb20:
  %t96 = load i64, ptr %l50, !tbaa !24
  store i64 %t96, ptr %l47, !tbaa !24
  br label %bb21
bb21:
  %t97 = load i64, ptr %l47, !tbaa !24
  store i64 %t97, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb22
bb22:
  %t98 = load i64, ptr %l10, !tbaa !24
  %t99 = load i64, ptr %l9, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb23, label %bb24
bb23:
  br label %bb45
bb24:
  br label %bb25
bb25:
  %t106 = load i64, ptr %l6, !tbaa !24
  %t107 = load i64, ptr %l10, !tbaa !24
  %t108 = load i64, ptr %l8, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l11, !tbaa !24
  %t116 = load ptr, ptr %l2, !tbaa !29
  %t118 = getelementptr %"compiler/parse:NameList", ptr %t116, i32 0, i32 1
  %t119 = load { i64, ptr }, ptr %t118, !tbaa !27
  store { i64, ptr } %t119, ptr %l69, !tbaa !27
  %t120 = load i64, ptr %l11, !tbaa !24
  %t122 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = getelementptr %"compiler/source:Span", ptr %t123, i64 %t120
  %t125 = load %"compiler/source:Span", ptr %t124
  store %"compiler/source:Span" %t125, ptr %l12
  %t127 = call ptr @__olang_scope_hold(ptr %v0)
  %t128 = ptrtoint ptr %t127 to i64
  store i64 %t128, ptr %l72, !tbaa !24
  %t129 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e0
  br i1 %t129, label %bb26, label %bb27
bb26:
  %t131 = call ptr @__olang_region_make(ptr %v0)
  %t132 = ptrtoint ptr %t131 to i64
  store i64 %t132, ptr %l72, !tbaa !24
  br label %bb27
bb27:
  %t133 = load ptr, ptr %l2, !tbaa !29
  %t135 = getelementptr %"compiler/parse:NameList", ptr %t133, i32 0, i32 0
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  store { i64, ptr } %t136, ptr %l75, !tbaa !27
  %t137 = load i64, ptr %l11, !tbaa !24
  %t139 = getelementptr { i64, ptr }, ptr %l75, i32 0, i32 1
  %t140 = load ptr, ptr %t139, !tbaa !27
  %t141 = getelementptr i32, ptr %t140, i64 %t137
  %t142 = load i32, ptr %t141, !tbaa !33
  store i32 %t142, ptr %l77, !tbaa !23
  %t143 = icmp sge i64 1, 0
  br i1 %t143, label %bb28, label %bb29
bb28:
  %t145 = icmp sle i64 1, 2305843009213693951
  br i1 %t145, label %bb30, label %bb31
bb29:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb30:
  %t147 = mul i64 1, 4
  %t148 = load i64, ptr %l72
  %t149 = inttoptr i64 %t148 to ptr
  %t150 = call ptr @__olang_held_alloc(ptr %t149, i64 %t147)
  %t151 = load i32, ptr %l77, !tbaa !23
  store i64 0, ptr %t152
  br label %fill.153
fill.153:
  %t156 = load i64, ptr %t152
  %t157 = icmp slt i64 %t156, 1
  br i1 %t157, label %fillb.154, label %filld.155
fillb.154:
  %t158 = getelementptr i32, ptr %t150, i64 %t156
  store i32 %t151, ptr %t158
  %t159 = add i64 %t156, 1
  store i64 %t159, ptr %t152
  br label %fill.153
filld.155:
  %t160 = insertvalue { i64, ptr } undef, i64 1, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t150, 1
  store { i64, ptr } %t161, ptr %l80, !tbaa !27
  %t162 = call ptr @__olang_scope_hold(ptr %v0)
  %t163 = ptrtoint ptr %t162 to i64
  store i64 %t163, ptr %l81, !tbaa !24
  %t164 = load i1, ptr @olang_2esole_2ecompiler_2fast_3aVarDecl_2e1
  br i1 %t164, label %bb32, label %bb33
bb31:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb32:
  %t166 = call ptr @__olang_region_make(ptr %v0)
  %t167 = ptrtoint ptr %t166 to i64
  store i64 %t167, ptr %l81, !tbaa !24
  br label %bb33
bb33:
  %t168 = load %"compiler/source:Span", ptr %l12
  store %"compiler/source:Span" %t168, ptr %l83
  %t169 = icmp sge i64 1, 0
  br i1 %t169, label %bb34, label %bb35
bb34:
  %t171 = icmp sle i64 1, 1152921504606846975
  br i1 %t171, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb36:
  %t173 = mul i64 1, 8
  %t174 = load i64, ptr %l81
  %t175 = inttoptr i64 %t174 to ptr
  %t176 = call ptr @__olang_held_alloc(ptr %t175, i64 %t173)
  %t177 = load %"compiler/source:Span", ptr %l83
  store i64 0, ptr %t178
  br label %fill.179
fill.179:
  %t182 = load i64, ptr %t178
  %t183 = icmp slt i64 %t182, 1
  br i1 %t183, label %fillb.180, label %filld.181
fillb.180:
  %t184 = getelementptr %"compiler/source:Span", ptr %t176, i64 %t182
  store %"compiler/source:Span" %t177, ptr %t184
  %t185 = add i64 %t182, 1
  store i64 %t185, ptr %t178
  br label %fill.179
filld.181:
  %t186 = insertvalue { i64, ptr } undef, i64 1, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t176, 1
  store { i64, ptr } %t187, ptr %l86, !tbaa !27
  %t188 = icmp sge i64 0, 0
  br i1 %t188, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53)
  unreachable
bb38:
  %t190 = icmp sle i64 0, 1152921504606846975
  br i1 %t190, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb40:
  %t192 = mul i64 0, 8
  %t193 = insertvalue { i64, ptr } undef, i64 0, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t195 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t198 = call %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v0, ptr %v0, ptr %v0, ptr %v0, { i64, ptr } %t195, { i64, ptr } %t196, ptr null, { i64, ptr } %t194, i1 false, i1 true, i1 false)
  store %"compiler/ast:VarDecl" %t198, ptr %l90
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e)
  unreachable
bb42:
  %t199 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 64, i64 8)
  store ptr %t199, ptr %lp13
  %t200 = load %"compiler/ast:VarDecl", ptr %l90
  %t201 = load ptr, ptr %lp13
  store %"compiler/ast:VarDecl" %t200, ptr %t201
  %t202 = load ptr, ptr %l0, !tbaa !29
  %t204 = getelementptr %"compiler/parse:Parser", ptr %t202, i32 0, i32 35
  %t205 = load %"compiler/source:Span", ptr %l12
  %t206 = load ptr, ptr %lp13
  store { i64, [4 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 0
  store i64 1, ptr %t208
  %t210 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t205, 0
  %t212 = insertvalue { %"compiler/source:Span", ptr } %t210, ptr %t206, 1
  %t213 = getelementptr { i64, [4 x i64] }, ptr %t207, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t212, ptr %t213
  %t214 = load { i64, [4 x i64] }, ptr %t207
  %t216 = call ptr @__olang_scope_alloc_a(ptr %v0, i64 40, i64 8)
  store { i64, [4 x i64] } %t214, ptr %t216
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v0, ptr %t204, ptr %t216)
  br label %bb43
bb43:
  br label %bb44
bb44:
  %t219 = load i64, ptr %l10, !tbaa !24
  %t222 = add i64 %t219, 1
  store i64 %t222, ptr %l10, !tbaa !24
  br label %bb22
bb45:
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t226 = getelementptr %"compiler/parse:NameList", ptr %t224, i32 0, i32 1
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  store { i64, ptr } %t227, ptr %l101, !tbaa !27
  %t228 = load i64, ptr %l5, !tbaa !24
  %t230 = sub i64 %t228, 1
  %t232 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t233 = load ptr, ptr %t232, !tbaa !27
  %t234 = getelementptr %"compiler/source:Span", ptr %t233, i64 %t230
  %t235 = load %"compiler/source:Span", ptr %t234
  store %"compiler/source:Span" %t235, ptr %l14
  %t237 = load ptr, ptr %l0, !tbaa !29
  %t239 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t237)
  store i32 %t239, ptr %l106
  br label %bb46
bb46:
  %t240 = getelementptr %"compiler/source:Span", ptr %l14, i32 0, i32 0
  %t241 = load i32, ptr %t240, !tbaa !23
  %t242 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t243 = load i32, ptr %t242, !tbaa !23
  %t246 = call %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v2, i32 %t241, i32 %t243)
  store %"compiler/source:Span" %t246, ptr %l109
  br label %bb47
bb47:
  %t247 = load ptr, ptr %l0, !tbaa !29
  %t248 = load ptr, ptr %l3, !tbaa !29
  %t249 = load ptr, ptr %l2, !tbaa !29
  %t251 = getelementptr %"compiler/parse:NameList", ptr %t249, i32 0, i32 0
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  store { i64, ptr } %t252, ptr %l113, !tbaa !27
  %t253 = load i64, ptr %l5, !tbaa !24
  %t255 = sub i64 %t253, 1
  %t257 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t258 = load ptr, ptr %t257, !tbaa !27
  %t259 = getelementptr i32, ptr %t258, i64 %t255
  %t260 = load i32, ptr %t259, !tbaa !33
  %t261 = load %"compiler/source:Span", ptr %l14
  %t266 = call ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %v2, ptr %v2, ptr %t247, ptr %t248, i32 %t260, %"compiler/source:Span" %t261)
  store ptr %t266, ptr %l118
  br label %bb48
bb48:
  store { i64, [4 x i64] } zeroinitializer, ptr %t267
  %t268 = getelementptr { i64, [4 x i64] }, ptr %t267, i32 0, i32 0
  store i64 1, ptr %t268
  %t269 = load %"compiler/source:Span", ptr %l109
  %t270 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t269, 0
  %t271 = load ptr, ptr %l118, !tbaa !29
  %t272 = insertvalue { %"compiler/source:Span", ptr } %t270, ptr %t271, 1
  %t273 = getelementptr { i64, [4 x i64] }, ptr %t267, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t272, ptr %t273
  %t274 = load { i64, [4 x i64] }, ptr %t267
  %t276 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t274, ptr %t276
  %t278 = insertvalue { i32, ptr } zeroinitializer, ptr %t276, 1
  store { i32, ptr } %t278, ptr %rv
  br label %ret
bb49:
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %t279)
  store i32 %t281, ptr %l122
  br label %bb50
bb50:
  %t282 = load %"compiler/source:Span", ptr %l4
  %t283 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [4 x i64] }, ptr %t284, i32 0, i32 0
  store i64 1, ptr %t285
  %t287 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t282, 0
  %t289 = insertvalue { %"compiler/source:Span", ptr } %t287, ptr %t283, 1
  %t290 = getelementptr { i64, [4 x i64] }, ptr %t284, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t289, ptr %t290
  %t291 = load { i64, [4 x i64] }, ptr %t284
  %t293 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t291, ptr %t293
  %t295 = insertvalue { i32, ptr } zeroinitializer, ptr %t293, 1
  store { i32, ptr } %t295, ptr %rv
  br label %ret
bb51:
  %t296 = load ptr, ptr %l0, !tbaa !29
  %t298 = call i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eendStmt(ptr %v0, ptr %t296)
  store i32 %t298, ptr %l128
  %t299 = icmp ne i32 %t298, 0
  br i1 %t299, label %bb53, label %ok.300, !prof !99
ok.300:
  br label %bb52
bb52:
  br label %bb54
bb53:
  %t301 = load i32, ptr %l128, !tbaa !23
  %t302 = lshr i32 %t301, 16
  %t303 = and i32 %t301, 65535
  %t304 = icmp eq i32 %t302, 1
  %t305 = select i1 %t304, i32 1, i32 0
  %t306 = icmp eq i32 %t301, 0
  %t307 = shl i32 %t305, 16
  %t308 = or i32 %t307, %t303
  %t309 = select i1 %t306, i32 0, i32 %t308
  %t311 = insertvalue { i32, ptr } zeroinitializer, i32 %t309, 0
  store { i32, ptr } %t311, ptr %rv
  br label %ret
bb54:
  %t312 = load %"compiler/source:Span", ptr %l4
  %t313 = load ptr, ptr %l3, !tbaa !29
  store { i64, [4 x i64] } zeroinitializer, ptr %t314
  %t315 = getelementptr { i64, [4 x i64] }, ptr %t314, i32 0, i32 0
  store i64 1, ptr %t315
  %t317 = insertvalue { %"compiler/source:Span", ptr } undef, %"compiler/source:Span" %t312, 0
  %t319 = insertvalue { %"compiler/source:Span", ptr } %t317, ptr %t313, 1
  %t320 = getelementptr { i64, [4 x i64] }, ptr %t314, i32 0, i32 1
  store { %"compiler/source:Span", ptr } %t319, ptr %t320
  %t321 = load { i64, [4 x i64] }, ptr %t314
  %t323 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 40, i64 8)
  store { i64, [4 x i64] } %t321, ptr %t323
  %t325 = insertvalue { i32, ptr } zeroinitializer, ptr %t323, 1
  store { i32, ptr } %t325, ptr %rv
  br label %ret
ret:
  %rr = load { i32, ptr }, ptr %rv
  ret { i32, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2eisFuncType(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsFunc(ptr %v0, ptr %a0)
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  store i1 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2eisTypeCasePath(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %l10 = alloca i1
  %l12 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 11
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t12, i32 0, i32 1
  %t14 = load ptr, ptr %t13
  store ptr %t14, ptr %l1, !tbaa !29
  br label %bb5
bb4:
  br label %bb7
bb5:
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t18 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t16)
  store i1 %t18, ptr %l10
  br label %bb6
bb6:
  %t19 = load i1, ptr %l10, !tbaa !21
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb13
bb7:
  br i1 true, label %bb8, label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb12
bb10:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t22 = call i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %t20)
  store i1 %t22, ptr %l12
  br label %bb11
bb11:
  %t23 = load i1, ptr %l12, !tbaa !21
  store i1 %t23, ptr %l2, !tbaa !21
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_9ddb86cdc3200de1_dc174b333c4dad15)
  unreachable
bb13:
  %t24 = load i1, ptr %l2, !tbaa !21
  store i1 %t24, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fparse_2enullLit(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i32
  %l2 = alloca i1
  %l3 = alloca ptr
  %l4 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  store i1 false, ptr %l4, !tbaa !21
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 1
  store i1 %t8, ptr %l4, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l4, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13, !range !{i32 0, i32 116}
  store i32 %t14, ptr %l1
  br label %bb5
bb4:
  br label %bb6
bb5:
  %t16 = load i32, ptr %l1, !range !{i32 0, i32 116}
  %t18 = trunc i64 7 to i32
  %t19 = icmp eq i32 %t16, %t18
  store i1 %t19, ptr %l2, !tbaa !21
  br label %bb11
bb6:
  br i1 true, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  br label %bb10
bb9:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_a90b8672e6678ca2_64dc780a504a1e7e)
  unreachable
bb11:
  %t21 = load i1, ptr %l2, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca %"compiler/source:Span"
  %l5 = alloca ptr
  %l6 = alloca i32
  %l7 = alloca ptr
  %l8 = alloca i32
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca ptr
  %l21 = alloca i1
  %l28 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca i1
  %l36 = alloca { i64, ptr }
  %l38 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca ptr
  %l58 = alloca i1
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca i1
  %l83 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca i1
  %l103 = alloca ptr
  %l104 = alloca i1
  %l116 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca i1
  %l137 = alloca { i64, ptr }
  %l141 = alloca ptr
  %l142 = alloca i1
  %l152 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l158 = alloca i64
  %l159 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  store i1 false, ptr %l21, !tbaa !21
  %t2 = load ptr, ptr %l20, !tbaa !29
  %t3 = icmp ne ptr %t2, null
  br i1 %t3, label %bb1, label %bb2
bb1:
  %t5 = load ptr, ptr %l20, !tbaa !29
  %t6 = load i64, ptr %t5, !range !{i64 0, i64 28}
  %t8 = icmp eq i64 %t6, 0
  store i1 %t8, ptr %l21, !tbaa !21
  br label %bb2
bb2:
  %t9 = load i1, ptr %l21, !tbaa !21
  br i1 %t9, label %bb3, label %bb4
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t12 = getelementptr { i64, [4 x i64] }, ptr %t10, i32 0, i32 1
  %t13 = getelementptr { %"compiler/source:Span", i32 }, ptr %t12, i32 0, i32 1
  %t14 = load i32, ptr %t13
  store i32 %t14, ptr %l3, !tbaa !23
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t16 = load ptr, ptr %l1, !tbaa !29
  %t17 = load i32, ptr %l3, !tbaa !23
  %t20 = call { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v1, ptr %s1, ptr %t16, i32 %t17)
  store { i64, ptr } %t20, ptr %l28
  br label %bb6
bb6:
  %t21 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t22, i64 %t23)
  %t25 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t24, 1
  store { i64, ptr } %t26, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb77
bb7:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l30, !tbaa !29
  store i1 false, ptr %l31, !tbaa !21
  %t29 = load ptr, ptr %l30, !tbaa !29
  %t30 = icmp ne ptr %t29, null
  br i1 %t30, label %bb8, label %bb9
bb8:
  %t32 = load ptr, ptr %l30, !tbaa !29
  %t33 = load i64, ptr %t32, !range !{i64 0, i64 28}
  %t35 = icmp eq i64 %t33, 1
  store i1 %t35, ptr %l31, !tbaa !21
  br label %bb9
bb9:
  %t36 = load i1, ptr %l31, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr { i64, [4 x i64] }, ptr %t37, i32 0, i32 1
  %t40 = getelementptr { %"compiler/source:Span", i32 }, ptr %t39, i32 0, i32 0
  %t41 = load %"compiler/source:Span", ptr %t40
  store %"compiler/source:Span" %t41, ptr %l4
  br label %bb12
bb11:
  br label %bb19
bb12:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t43, ptr %l36, !tbaa !27
  %t44 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  %t47 = sext i32 %t45 to i64
  store i64 %t47, ptr %l38, !tbaa !24
  %t48 = getelementptr %"compiler/source:Span", ptr %l4, i32 0, i32 1
  %t49 = load i32, ptr %t48, !tbaa !23
  %t51 = sext i32 %t49 to i64
  store i64 %t51, ptr %l40, !tbaa !24
  %t52 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 0
  store i64 %t53, ptr %l41, !tbaa !24
  %t54 = load i64, ptr %l38, !tbaa !24
  %t55 = icmp sge i64 %t54, 0
  br i1 %t55, label %bb13, label %bb14
bb13:
  %t57 = load i64, ptr %l38, !tbaa !24
  %t58 = load i64, ptr %l40, !tbaa !24
  %t59 = icmp sle i64 %t57, %t58
  br i1 %t59, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb15:
  %t61 = load i64, ptr %l40, !tbaa !24
  %t62 = load i64, ptr %l41, !tbaa !24
  %t63 = icmp sle i64 %t61, %t62
  br i1 %t63, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb17:
  %t65 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = getelementptr i8, ptr %t66, i64 %t67
  %t70 = sub i64 %t68, %t67
  %t71 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t69, 1
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = extractvalue { i64, ptr } %t72, 0
  %t76 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t74, i64 %t75)
  %t77 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  store { i64, ptr } %t78, ptr %l19, !tbaa !27
  br label %bb77
bb18:
  call void @__olang_check_failed(ptr @olang_loc_95becaa34f722781_c104ec8a8e14f09d)
  unreachable
bb19:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l47, !tbaa !29
  store i1 false, ptr %l48, !tbaa !21
  %t81 = load ptr, ptr %l47, !tbaa !29
  %t82 = icmp ne ptr %t81, null
  br i1 %t82, label %bb20, label %bb21
bb20:
  %t84 = load ptr, ptr %l47, !tbaa !29
  %t85 = load i64, ptr %t84, !range !{i64 0, i64 28}
  %t87 = icmp eq i64 %t85, 2
  store i1 %t87, ptr %l48, !tbaa !21
  br label %bb21
bb21:
  %t88 = load i1, ptr %l48, !tbaa !21
  br i1 %t88, label %bb22, label %bb23
bb22:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = getelementptr { i64, [4 x i64] }, ptr %t89, i32 0, i32 1
  %t92 = getelementptr { %"compiler/source:Span", ptr }, ptr %t91, i32 0, i32 1
  %t93 = load ptr, ptr %t92
  store ptr %t93, ptr %l5, !tbaa !29
  br label %bb24
bb23:
  br label %bb26
bb24:
  %t95 = load ptr, ptr %l5, !tbaa !29
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t97 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t101 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %t95, ptr %t96, { i64, ptr } %t97)
  store { i64, ptr } %t101, ptr %l56
  br label %bb25
bb25:
  %t102 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t102, ptr %l19, !tbaa !27
  br label %bb77
bb26:
  %t103 = load ptr, ptr %l0, !tbaa !29
  store ptr %t103, ptr %l57, !tbaa !29
  store i1 false, ptr %l58, !tbaa !21
  %t104 = load ptr, ptr %l57, !tbaa !29
  %t105 = icmp ne ptr %t104, null
  br i1 %t105, label %bb27, label %bb28
bb27:
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load i64, ptr %t107, !range !{i64 0, i64 28}
  %t110 = icmp eq i64 %t108, 3
  store i1 %t110, ptr %l58, !tbaa !21
  br label %bb28
bb28:
  %t111 = load i1, ptr %l58, !tbaa !21
  br i1 %t111, label %bb29, label %bb30
bb29:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr { i64, [4 x i64] }, ptr %t112, i32 0, i32 1
  %t115 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t114, i32 0, i32 1
  %t116 = load i32, ptr %t115, !range !{i32 0, i32 116}
  store i32 %t116, ptr %l6
  %t118 = load ptr, ptr %l0, !tbaa !29
  %t120 = getelementptr { i64, [4 x i64] }, ptr %t118, i32 0, i32 1
  %t121 = getelementptr { %"compiler/source:Span", i32, ptr }, ptr %t120, i32 0, i32 2
  %t122 = load ptr, ptr %t121
  store ptr %t122, ptr %l7, !tbaa !29
  br label %bb31
bb30:
  br label %bb34
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t124 = load i32, ptr %l6, !range !{i32 0, i32 116}
  %t126 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s6, i32 %t124)
  store { i64, ptr } %t126, ptr %l66
  br label %bb32
bb32:
  %t127 = load ptr, ptr %l7, !tbaa !29
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t129 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t133 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s6, ptr %t127, ptr %t128, { i64, ptr } %t129)
  store { i64, ptr } %t133, ptr %l70
  br label %bb33
bb33:
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d15, i32 0, i32 1) }, 0
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 1
  %t138 = extractvalue { i64, ptr } %t136, 0
  %t139 = add i64 %t135, %t138
  %t140 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t141 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t142 = add i64 %t139, %t141
  %t143 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t144, i64 %t145)
  %t154 = getelementptr i8, ptr %t153, i64 %t145
  call void @olang_textcopy(ptr %t154, ptr %t147, i64 %t148)
  %t155 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t150, 1
  store { i64, ptr } %t156, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb77
bb34:
  %t158 = load ptr, ptr %l0, !tbaa !29
  store ptr %t158, ptr %l72, !tbaa !29
  store i1 false, ptr %l73, !tbaa !21
  %t159 = load ptr, ptr %l72, !tbaa !29
  %t160 = icmp ne ptr %t159, null
  br i1 %t160, label %bb35, label %bb36
bb35:
  %t162 = load ptr, ptr %l72, !tbaa !29
  %t163 = load i64, ptr %t162, !range !{i64 0, i64 28}
  %t165 = icmp eq i64 %t163, 5
  store i1 %t165, ptr %l73, !tbaa !21
  br label %bb36
bb36:
  %t166 = load i1, ptr %l73, !tbaa !21
  br i1 %t166, label %bb37, label %bb38
bb37:
  %t167 = load ptr, ptr %l0, !tbaa !29
  %t169 = getelementptr { i64, [4 x i64] }, ptr %t167, i32 0, i32 1
  %t170 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t169, i32 0, i32 1
  %t171 = load i32, ptr %t170, !range !{i32 0, i32 116}
  store i32 %t171, ptr %l8
  %t173 = load ptr, ptr %l0, !tbaa !29
  %t175 = getelementptr { i64, [4 x i64] }, ptr %t173, i32 0, i32 1
  %t176 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t175, i32 0, i32 2
  %t177 = load ptr, ptr %t176
  store ptr %t177, ptr %l9, !tbaa !29
  %t179 = load ptr, ptr %l0, !tbaa !29
  %t181 = getelementptr { i64, [4 x i64] }, ptr %t179, i32 0, i32 1
  %t182 = getelementptr { %"compiler/source:Span", i32, ptr, ptr }, ptr %t181, i32 0, i32 3
  %t183 = load ptr, ptr %t182
  store ptr %t183, ptr %l10, !tbaa !29
  br label %bb39
bb38:
  br label %bb43
bb39:
  store %olang.scope zeroinitializer, ptr %s8
  %t185 = load i32, ptr %l8, !range !{i32 0, i32 116}
  %t187 = call { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %s8, i32 %t185)
  store { i64, ptr } %t187, ptr %l83
  br label %bb40
bb40:
  %t188 = load ptr, ptr %l9, !tbaa !29
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t194 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t188, ptr %t189, { i64, ptr } %t190)
  store { i64, ptr } %t194, ptr %l87
  br label %bb41
bb41:
  %t195 = load ptr, ptr %l10, !tbaa !29
  %t196 = load ptr, ptr %l1, !tbaa !29
  %t197 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t201 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s8, ptr %t195, ptr %t196, { i64, ptr } %t197)
  store { i64, ptr } %t201, ptr %l91
  br label %bb42
bb42:
  %t202 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t203 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t204 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 1
  %t206 = extractvalue { i64, ptr } %t204, 0
  %t207 = add i64 %t203, %t206
  %t208 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t219 = extractvalue { i64, ptr } %t218, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = add i64 %t217, %t220
  %t222 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t224 = add i64 %t221, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t202, i64 %t203)
  %t226 = getelementptr i8, ptr %t225, i64 %t203
  call void @olang_textcopy(ptr %t226, ptr %t205, i64 %t206)
  %t227 = getelementptr i8, ptr %t226, i64 %t206
  call void @olang_textcopy(ptr %t227, ptr %t208, i64 %t209)
  %t228 = getelementptr i8, ptr %t227, i64 %t209
  call void @olang_textcopy(ptr %t228, ptr %t212, i64 %t213)
  %t229 = getelementptr i8, ptr %t228, i64 %t213
  call void @olang_textcopy(ptr %t229, ptr %t215, i64 %t216)
  %t230 = getelementptr i8, ptr %t229, i64 %t216
  call void @olang_textcopy(ptr %t230, ptr %t219, i64 %t220)
  %t231 = getelementptr i8, ptr %t230, i64 %t220
  call void @olang_textcopy(ptr %t231, ptr %t222, i64 %t223)
  %t232 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t225, 1
  store { i64, ptr } %t233, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb77
bb43:
  %t235 = load ptr, ptr %l0, !tbaa !29
  store ptr %t235, ptr %l93, !tbaa !29
  store i1 false, ptr %l94, !tbaa !21
  %t236 = load ptr, ptr %l93, !tbaa !29
  %t237 = icmp ne ptr %t236, null
  br i1 %t237, label %bb44, label %bb45
bb44:
  %t239 = load ptr, ptr %l93, !tbaa !29
  %t240 = load i64, ptr %t239, !range !{i64 0, i64 28}
  %t242 = icmp eq i64 %t240, 7
  store i1 %t242, ptr %l94, !tbaa !21
  br label %bb45
bb45:
  %t243 = load i1, ptr %l94, !tbaa !21
  br i1 %t243, label %bb46, label %bb47
bb46:
  %t244 = load ptr, ptr %l0, !tbaa !29
  %t246 = getelementptr { i64, [4 x i64] }, ptr %t244, i32 0, i32 1
  %t247 = getelementptr { %"compiler/source:Span", ptr }, ptr %t246, i32 0, i32 1
  %t248 = load ptr, ptr %t247
  store ptr %t248, ptr %l11, !tbaa !29
  br label %bb48
bb47:
  br label %bb49
bb48:
  %t250 = load ptr, ptr %l11, !tbaa !29
  %t252 = getelementptr %"compiler/ast:Chain", ptr %t250, i32 0, i32 0
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t253, 0
  %t256 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d21, i32 0, i32 1) }, 0
  %t259 = call i64 @__olang_fmt_i64(ptr null, i64 %t255)
  %t260 = add i64 %t257, %t259
  %t261 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d22, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @olang_textcopy(ptr %t264, ptr %t256, i64 %t257)
  %t265 = getelementptr i8, ptr %t264, i64 %t257
  %t266 = call i64 @__olang_fmt_i64(ptr %t265, i64 %t255)
  %t267 = getelementptr i8, ptr %t265, i64 %t259
  call void @olang_textcopy(ptr %t267, ptr %t261, i64 %t262)
  %t268 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t264, 1
  store { i64, ptr } %t269, ptr %l19, !tbaa !27
  br label %bb77
bb49:
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l103, !tbaa !29
  store i1 false, ptr %l104, !tbaa !21
  %t272 = load ptr, ptr %l103, !tbaa !29
  %t273 = icmp ne ptr %t272, null
  br i1 %t273, label %bb50, label %bb51
bb50:
  %t275 = load ptr, ptr %l103, !tbaa !29
  %t276 = load i64, ptr %t275, !range !{i64 0, i64 28}
  %t278 = icmp eq i64 %t276, 8
  store i1 %t278, ptr %l104, !tbaa !21
  br label %bb51
bb51:
  %t279 = load i1, ptr %l104, !tbaa !21
  br i1 %t279, label %bb52, label %bb53
bb52:
  %t280 = load ptr, ptr %l0, !tbaa !29
  %t282 = getelementptr { i64, [4 x i64] }, ptr %t280, i32 0, i32 1
  %t283 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t282, i32 0, i32 1
  %t284 = load ptr, ptr %t283
  store ptr %t284, ptr %l12, !tbaa !29
  %t286 = load ptr, ptr %l0, !tbaa !29
  %t288 = getelementptr { i64, [4 x i64] }, ptr %t286, i32 0, i32 1
  %t289 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t288, i32 0, i32 2
  %t290 = load ptr, ptr %t289
  store ptr %t290, ptr %l13, !tbaa !29
  %t292 = load ptr, ptr %l0, !tbaa !29
  %t294 = getelementptr { i64, [4 x i64] }, ptr %t292, i32 0, i32 1
  %t295 = getelementptr { %"compiler/source:Span", ptr, ptr, ptr }, ptr %t294, i32 0, i32 3
  %t296 = load ptr, ptr %t295
  store ptr %t296, ptr %l14, !tbaa !29
  br label %bb54
bb53:
  br label %bb58
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t304 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t298, ptr %t299, { i64, ptr } %t300)
  store { i64, ptr } %t304, ptr %l116
  br label %bb55
bb55:
  %t305 = load ptr, ptr %l12, !tbaa !29
  %t306 = load ptr, ptr %l1, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t311 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t305, ptr %t306, { i64, ptr } %t307)
  store { i64, ptr } %t311, ptr %l120
  br label %bb56
bb56:
  %t312 = load ptr, ptr %l14, !tbaa !29
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t318 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s12, ptr %t312, ptr %t313, { i64, ptr } %t314)
  store { i64, ptr } %t318, ptr %l124
  br label %bb57
bb57:
  %t319 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 1
  %t320 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d23, i32 0, i32 1) }, 0
  %t321 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = add i64 %t320, %t323
  %t325 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t326 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t327 = add i64 %t324, %t326
  %t328 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t329 = extractvalue { i64, ptr } %t328, 1
  %t330 = extractvalue { i64, ptr } %t328, 0
  %t331 = add i64 %t327, %t330
  %t332 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t333 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t334 = add i64 %t331, %t333
  %t335 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = add i64 %t334, %t337
  %t339 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t340 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t341 = add i64 %t338, %t340
  %t342 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t341)
  call void @olang_textcopy(ptr %t342, ptr %t319, i64 %t320)
  %t343 = getelementptr i8, ptr %t342, i64 %t320
  call void @olang_textcopy(ptr %t343, ptr %t322, i64 %t323)
  %t344 = getelementptr i8, ptr %t343, i64 %t323
  call void @olang_textcopy(ptr %t344, ptr %t325, i64 %t326)
  %t345 = getelementptr i8, ptr %t344, i64 %t326
  call void @olang_textcopy(ptr %t345, ptr %t329, i64 %t330)
  %t346 = getelementptr i8, ptr %t345, i64 %t330
  call void @olang_textcopy(ptr %t346, ptr %t332, i64 %t333)
  %t347 = getelementptr i8, ptr %t346, i64 %t333
  call void @olang_textcopy(ptr %t347, ptr %t336, i64 %t337)
  %t348 = getelementptr i8, ptr %t347, i64 %t337
  call void @olang_textcopy(ptr %t348, ptr %t339, i64 %t340)
  %t349 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t342, 1
  store { i64, ptr } %t350, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb77
bb58:
  %t352 = load ptr, ptr %l0, !tbaa !29
  store ptr %t352, ptr %l126, !tbaa !29
  store i1 false, ptr %l127, !tbaa !21
  %t353 = load ptr, ptr %l126, !tbaa !29
  %t354 = icmp ne ptr %t353, null
  br i1 %t354, label %bb59, label %bb60
bb59:
  %t356 = load ptr, ptr %l126, !tbaa !29
  %t357 = load i64, ptr %t356, !range !{i64 0, i64 28}
  %t359 = icmp eq i64 %t357, 10
  store i1 %t359, ptr %l127, !tbaa !21
  br label %bb60
bb60:
  %t360 = load i1, ptr %l127, !tbaa !21
  br i1 %t360, label %bb61, label %bb62
bb61:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr { i64, [4 x i64] }, ptr %t361, i32 0, i32 1
  %t364 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t363, i32 0, i32 1
  %t365 = load ptr, ptr %t364
  store ptr %t365, ptr %l15, !tbaa !29
  %t367 = load ptr, ptr %l0, !tbaa !29
  %t369 = getelementptr { i64, [4 x i64] }, ptr %t367, i32 0, i32 1
  %t370 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t369, i32 0, i32 2
  %t371 = load { i64, ptr }, ptr %t370
  store { i64, ptr } %t371, ptr %l16, !tbaa !27
  br label %bb63
bb62:
  br label %bb65
bb63:
  store %olang.scope zeroinitializer, ptr %s14
  %t373 = load ptr, ptr %l15, !tbaa !29
  %t374 = load ptr, ptr %l1, !tbaa !29
  %t375 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t379 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s14, ptr %t373, ptr %t374, { i64, ptr } %t375)
  store { i64, ptr } %t379, ptr %l137
  br label %bb64
bb64:
  %t380 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t380, 0
  %t383 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t384 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t385 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t386 = extractvalue { i64, ptr } %t385, 1
  %t387 = extractvalue { i64, ptr } %t385, 0
  %t388 = add i64 %t384, %t387
  %t389 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t390 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t391 = add i64 %t388, %t390
  %t393 = call i64 @__olang_fmt_i64(ptr null, i64 %t382)
  %t394 = add i64 %t391, %t393
  %t395 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 1
  %t396 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d28, i32 0, i32 1) }, 0
  %t397 = add i64 %t394, %t396
  %t398 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t397)
  call void @olang_textcopy(ptr %t398, ptr %t383, i64 %t384)
  %t399 = getelementptr i8, ptr %t398, i64 %t384
  call void @olang_textcopy(ptr %t399, ptr %t386, i64 %t387)
  %t400 = getelementptr i8, ptr %t399, i64 %t387
  call void @olang_textcopy(ptr %t400, ptr %t389, i64 %t390)
  %t401 = getelementptr i8, ptr %t400, i64 %t390
  %t402 = call i64 @__olang_fmt_i64(ptr %t401, i64 %t382)
  %t403 = getelementptr i8, ptr %t401, i64 %t393
  call void @olang_textcopy(ptr %t403, ptr %t395, i64 %t396)
  %t404 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t398, 1
  store { i64, ptr } %t405, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb77
bb65:
  %t407 = load ptr, ptr %l0, !tbaa !29
  store ptr %t407, ptr %l141, !tbaa !29
  store i1 false, ptr %l142, !tbaa !21
  %t408 = load ptr, ptr %l141, !tbaa !29
  %t409 = icmp ne ptr %t408, null
  br i1 %t409, label %bb66, label %bb67
bb66:
  %t411 = load ptr, ptr %l141, !tbaa !29
  %t412 = load i64, ptr %t411, !range !{i64 0, i64 28}
  %t414 = icmp eq i64 %t412, 11
  store i1 %t414, ptr %l142, !tbaa !21
  br label %bb67
bb67:
  %t415 = load i1, ptr %l142, !tbaa !21
  br i1 %t415, label %bb68, label %bb69
bb68:
  %t416 = load ptr, ptr %l0, !tbaa !29
  %t418 = getelementptr { i64, [4 x i64] }, ptr %t416, i32 0, i32 1
  %t419 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t418, i32 0, i32 1
  %t420 = load ptr, ptr %t419
  store ptr %t420, ptr %l17, !tbaa !29
  %t422 = load ptr, ptr %l0, !tbaa !29
  %t424 = getelementptr { i64, [4 x i64] }, ptr %t422, i32 0, i32 1
  %t425 = getelementptr { %"compiler/source:Span", ptr, { i64, ptr } }, ptr %t424, i32 0, i32 2
  %t426 = load { i64, ptr }, ptr %t425
  store { i64, ptr } %t426, ptr %l18, !tbaa !27
  br label %bb70
bb69:
  br label %bb72
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t428 = load ptr, ptr %l17, !tbaa !29
  %t429 = load ptr, ptr %l1, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t434 = call { i64, ptr } @compiler_2fparse_2eshapeExpr(ptr %v0, ptr %v1, ptr %v2, ptr %s16, ptr %t428, ptr %t429, { i64, ptr } %t430)
  store { i64, ptr } %t434, ptr %l152
  br label %bb71
bb71:
  %t435 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) }, 1
  %t439 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d29, i32 0, i32 1) }, 0
  %t440 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t441 = extractvalue { i64, ptr } %t440, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = add i64 %t439, %t442
  %t444 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t446 = add i64 %t443, %t445
  %t448 = call i64 @__olang_fmt_i64(ptr null, i64 %t437)
  %t449 = add i64 %t446, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t452 = add i64 %t449, %t451
  %t453 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t438, i64 %t439)
  %t454 = getelementptr i8, ptr %t453, i64 %t439
  call void @olang_textcopy(ptr %t454, ptr %t441, i64 %t442)
  %t455 = getelementptr i8, ptr %t454, i64 %t442
  call void @olang_textcopy(ptr %t455, ptr %t444, i64 %t445)
  %t456 = getelementptr i8, ptr %t455, i64 %t445
  %t457 = call i64 @__olang_fmt_i64(ptr %t456, i64 %t437)
  %t458 = getelementptr i8, ptr %t456, i64 %t448
  call void @olang_textcopy(ptr %t458, ptr %t450, i64 %t451)
  %t459 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t453, 1
  store { i64, ptr } %t460, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s16)
  br label %bb77
bb72:
  br i1 true, label %bb73, label %bb74
bb73:
  br label %bb75
bb74:
  br label %bb76
bb75:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l156, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l156, !tbaa !27
  store { i64, ptr } %t462, ptr %l19, !tbaa !27
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_a6e4b06ca3f2f7b3_b26c102023f13b6f)
  unreachable
bb77:
  %t464 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  store i64 %t465, ptr %l158, !tbaa !24
  %t466 = load i64, ptr %l158, !tbaa !24
  %t467 = mul i64 %t466, 1
  %t468 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t467)
  %t469 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t470 = insertvalue { i64, ptr } %t469, ptr %t468, 1
  store { i64, ptr } %t470, ptr %l159, !tbaa !27
  %t471 = getelementptr { i64, ptr }, ptr %l159, i32 0, i32 1
  %t472 = load ptr, ptr %t471, !tbaa !27
  %t473 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t474 = load ptr, ptr %t473, !tbaa !27
  %t475 = load i64, ptr %l158, !tbaa !24
  %t476 = mul i64 %t475, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t472, ptr %t474, i64 %t476, i1 false)
  %t477 = load { i64, ptr }, ptr %l159, !tbaa !27
  store { i64, ptr } %t477, ptr %l19, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t478, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fparse_2eshapeOf(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2) #0 {
entry:
  %l3 = alloca %"compiler/source:Source"
  %l4 = alloca %"compiler/source:Names"
  %l5 = alloca %"compiler/parse:Oracle"
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/diag:Diagnostics"
  %l11 = alloca i64
  %l12 = alloca %"compiler/scan:Tokens"
  %l13 = alloca %"compiler/parse:Parser"
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"std/prelude/text:StringBuilder"
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca %"compiler/diag:Said"
  %l24 = alloca %"compiler/source:Source"
  %l25 = alloca %"compiler/source:Names"
  %l26 = alloca %"compiler/parse:Oracle"
  %l28 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l47 = alloca %"compiler/diag:Diagnostics"
  %l51 = alloca i64
  %l53 = alloca %"compiler/scan:Tokens"
  %l60 = alloca %"compiler/parse:Parser"
  %l62 = alloca { i64, ptr }
  %l65 = alloca %"std/prelude/text:StringBuilder"
  %l73 = alloca { i64, ptr }
  %l77 = alloca i64
  %l80 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l94 = alloca i64
  %l99 = alloca %"compiler/diag:Said"
  %l108 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t7 = alloca %"compiler/parse:Oracle", align 8
  %t47 = alloca %"compiler/diag:Diagnostics", align 8
  %t63 = alloca %"compiler/parse:Parser", align 8
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %s0, ptr %v0, ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) }, { i64, ptr } %a0)
  store %"compiler/source:Source" %t3, ptr %l24
  br label %bb1
bb1:
  %t4 = load %"compiler/source:Source", ptr %l24
  store %"compiler/source:Source" %t4, ptr %l3
  %t5 = call %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %s0)
  store %"compiler/source:Names" %t5, ptr %l25
  br label %bb2
bb2:
  %t6 = load %"compiler/source:Names", ptr %l25
  store %"compiler/source:Names" %t6, ptr %l4
  call void @compiler_2fparse_3aOracle_2ector(ptr %t7, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l26, ptr %t7, i64 288, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l5, ptr %l26, i64 288, i1 false)
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v1, ptr %s1, ptr %s1, { i64, ptr } %a1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) })
  store { i64, ptr } %t10, ptr %l28
  br label %bb4
bb4:
  %t11 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t11, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t12 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t12, 0
  store i64 %t14, ptr %l8, !tbaa !24
  br label %bb5
bb5:
  %t16 = load i64, ptr %l7, !tbaa !24
  %t17 = load i64, ptr %l8, !tbaa !24
  %t20 = icmp slt i64 %t16, %t17
  %t22 = xor i1 %t20, true
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb14
bb7:
  br label %bb8
bb8:
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t24, ptr %l35, !tbaa !27
  %t25 = load i64, ptr %l7, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr { i64, ptr }, ptr %t28, i64 %t25
  %t30 = load { i64, ptr }, ptr %t29, !tbaa !37
  store { i64, ptr } %t30, ptr %l9, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t36 = icmp sgt i64 %t34, 0
  br i1 %t36, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t38 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %s0, ptr %s0, ptr %s3, ptr %s1, ptr %l5, ptr %l4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) }, { i64, ptr } %t38)
  br label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t42 = load i64, ptr %l7, !tbaa !24
  %t45 = add i64 %t42, 1
  store i64 %t45, ptr %l7, !tbaa !24
  br label %bb5
bb14:
  call void @__olang_scope_close(ptr %s1)
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t47, ptr %s0, i1 false)
  call void @llvm.memmove.p0.p0.i64(ptr %l47, ptr %t47, i64 704, i1 false)
  br label %bb15
bb15:
  call void @llvm.memmove.p0.p0.i64(ptr %l10, ptr %l47, i64 704, i1 false)
  %t48 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 0
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t50 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t55 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %s0, ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t49, { i64, ptr } %t51, i1 false)
  store i64 %t55, ptr %l51
  br label %bb16
bb16:
  %t56 = load i64, ptr %l51, !tbaa !24
  store i64 %t56, ptr %l11, !tbaa !24
  %t57 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  %t60 = call %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %s0, ptr %s0, { i64, ptr } %t58)
  store %"compiler/scan:Tokens" %t60, ptr %l53
  br label %bb17
bb17:
  %t61 = load %"compiler/scan:Tokens", ptr %l53
  store %"compiler/scan:Tokens" %t61, ptr %l12
  %t62 = load i64, ptr %l11, !tbaa !24
  call void @compiler_2fparse_3aParser_2ector(ptr %t63, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %l3, ptr %l12, ptr %l4, ptr %l5, ptr %l10, i64 %t62)
  call void @llvm.memmove.p0.p0.i64(ptr %l60, ptr %t63, i64 1016, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l60, i64 1016, i1 false)
  %t71 = call { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %s0, ptr %s0, ptr %l13)
  store { i64, ptr } %t71, ptr %l62
  br label %bb19
bb19:
  %t72 = load { i64, ptr }, ptr %l62, !tbaa !27
  store { i64, ptr } %t72, ptr %l14, !tbaa !27
  br i1 %a2, label %bb20, label %bb21
bb20:
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %s0, ptr %l10)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t76 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t76, ptr %l65
  br label %bb24
bb24:
  %t77 = load %"std/prelude/text:StringBuilder", ptr %l65
  store %"std/prelude/text:StringBuilder" %t77, ptr %l15
  %t78 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t78, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t80 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 0
  store i64 %t82, ptr %l18, !tbaa !24
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t84 = load i64, ptr %l17, !tbaa !24
  %t85 = load i64, ptr %l18, !tbaa !24
  %t88 = icmp slt i64 %t84, %t85
  %t90 = xor i1 %t88, true
  br i1 %t90, label %bb26, label %bb27
bb26:
  call void @__olang_scope_close(ptr %s7)
  br label %bb37
bb27:
  br label %bb28
bb28:
  %t92 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t92, ptr %l73, !tbaa !27
  %t93 = load i64, ptr %l17, !tbaa !24
  %t95 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t96 = load ptr, ptr %t95, !tbaa !27
  %t97 = getelementptr ptr, ptr %t96, i64 %t93
  %t98 = load ptr, ptr %t97, !tbaa !39
  store ptr %t98, ptr %l19, !tbaa !29
  %t101 = call i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %s0, ptr %l15)
  store i64 %t101, ptr %l77
  br label %bb29
bb29:
  %t102 = load i64, ptr %l77, !tbaa !24
  %t103 = icmp sgt i64 %t102, 0
  br i1 %t103, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s8
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s8, ptr %l15, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d36, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_scope_close(ptr %s8)
  br label %bb33
bb33:
  store ptr %l15, ptr %l80, !tbaa !29
  %t106 = load ptr, ptr %l19, !tbaa !29
  %t107 = getelementptr %"compiler/source:Source", ptr %l3, i32 0, i32 1
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t112 = call { i64, ptr } @compiler_2fparse_2eshapeDecl(ptr %s0, ptr %s0, ptr %s0, ptr %s7, ptr %t106, ptr %l4, { i64, ptr } %t108)
  store { i64, ptr } %t112, ptr %l84
  br label %bb34
bb34:
  %t113 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t114 = load ptr, ptr %l80, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s7, ptr %t114, { i64, ptr } %t113)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  %t116 = load i64, ptr %l17, !tbaa !24
  %t119 = add i64 %t116, 1
  store i64 %t119, ptr %l17, !tbaa !24
  br label %bb25
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t122 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %s0, ptr %s10, ptr %l10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t122, ptr %l90
  br label %bb38
bb38:
  %t123 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  %t124 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t123, ptr %t124
  store ptr %t124, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb39
bb39:
  store %olang.scope zeroinitializer, ptr %s11
  %t126 = load i64, ptr %l21, !tbaa !24
  store i64 %t126, ptr %l92, !tbaa !24
  %t127 = load ptr, ptr %l20, !tbaa !29
  %t129 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %s10, ptr %t127)
  store i64 %t129, ptr %l94
  br label %bb40
bb40:
  %t130 = load i64, ptr %l92, !tbaa !24
  %t131 = load i64, ptr %l94, !tbaa !24
  %t132 = icmp slt i64 %t130, %t131
  %t134 = xor i1 %t132, true
  br i1 %t134, label %bb41, label %bb42
bb41:
  call void @__olang_scope_close(ptr %s11)
  br label %bb47
bb42:
  br label %bb43
bb43:
  %t136 = load ptr, ptr %l20, !tbaa !29
  %t137 = load i64, ptr %l21, !tbaa !24
  %t140 = call %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %s10, ptr %s10, ptr %t136, i64 %t137)
  store %"compiler/diag:Said" %t140, ptr %l99
  br label %bb44
bb44:
  %t141 = load %"compiler/diag:Said", ptr %l99
  store %"compiler/diag:Said" %t141, ptr %l22
  %t142 = getelementptr %"compiler/diag:Said", ptr %l22, i32 0, i32 0
  %t143 = load { i64, ptr }, ptr %t142, !tbaa !27
  %t144 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t145 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t147 = extractvalue { i64, ptr } %t143, 1
  %t148 = extractvalue { i64, ptr } %t143, 0
  %t149 = add i64 %t145, %t148
  %t150 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t144, i64 %t145)
  %t151 = getelementptr i8, ptr %t150, i64 %t145
  call void @olang_textcopy(ptr %t151, ptr %t147, i64 %t148)
  %t152 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t150, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s11, ptr %l15, { i64, ptr } %t153)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s11)
  br label %bb46
bb46:
  %t157 = load i64, ptr %l21, !tbaa !24
  %t160 = add i64 %t157, 1
  store i64 %t160, ptr %l21, !tbaa !24
  br label %bb39
bb47:
  call void @__olang_scope_close(ptr %s10)
  %t163 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %l15)
  store { i64, ptr } %t163, ptr %l108
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t164 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t164, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fparse_2etypeWord(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca i64
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l17 = alloca [27 x { i64, ptr }]
  %l30 = alloca i1
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t5 = icmp eq i64 %t3, 0
  br i1 %t5, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb3
bb2:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  %t13 = icmp ult i8 %t11, 65
  store i1 %t13, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l12, !tbaa !21
  br label %bb6
bb5:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 0
  %t20 = load i8, ptr %t19, !tbaa !32
  %t22 = icmp ugt i8 %t20, 90
  store i1 %t22, ptr %l12, !tbaa !21
  br label %bb6
bb6:
  %t24 = load i1, ptr %l12, !tbaa !21
  br i1 %t24, label %bb7, label %bb8
bb7:
  store i1 false, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 0
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %t26
  %t27 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %t27
  %t28 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 2
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %t28
  %t29 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 3
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %t29
  %t30 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 4
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %t30
  %t31 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 5
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %t31
  %t32 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 6
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d44, i32 0, i32 1) }, ptr %t32
  %t33 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 7
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d45, i32 0, i32 1) }, ptr %t33
  %t34 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 8
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d46, i32 0, i32 1) }, ptr %t34
  %t35 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 9
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d47, i32 0, i32 1) }, ptr %t35
  %t36 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 10
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t36
  %t37 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 11
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %t37
  %t38 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 12
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t38
  %t39 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 13
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d51, i32 0, i32 1) }, ptr %t39
  %t40 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 14
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d52, i32 0, i32 1) }, ptr %t40
  %t41 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 15
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d53, i32 0, i32 1) }, ptr %t41
  %t42 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 16
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d54, i32 0, i32 1) }, ptr %t42
  %t43 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 17
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d55, i32 0, i32 1) }, ptr %t43
  %t44 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 18
  store { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %t44
  %t45 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 19
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %t45
  %t46 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 20
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d58, i32 0, i32 1) }, ptr %t46
  %t47 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 21
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d59, i32 0, i32 1) }, ptr %t47
  %t48 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 22
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d60, i32 0, i32 1) }, ptr %t48
  %t49 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 23
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %t49
  %t50 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 24
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d62, i32 0, i32 1) }, ptr %t50
  %t51 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 25
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d63, i32 0, i32 1) }, ptr %t51
  %t52 = getelementptr [27 x { i64, ptr }], ptr %l17, i64 0, i64 26
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d64, i32 0, i32 1) }, ptr %t52
  %t53 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 432, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %l17, i64 432, i1 false)
  store ptr %t53, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  %t55 = load ptr, ptr %l1
  store i64 27, ptr %l3, !tbaa !24
  br label %bb10
bb10:
  %t58 = load i64, ptr %l2, !tbaa !24
  %t59 = load i64, ptr %l3, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb11, label %bb12
bb11:
  br label %bb19
bb12:
  br label %bb13
bb13:
  %t66 = load ptr, ptr %l1
  %t67 = load i64, ptr %l2, !tbaa !24
  %t70 = getelementptr [27 x { i64, ptr }], ptr %t66, i64 0, i64 %t67
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !37
  %t73 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t75 = load ptr, ptr @__olang_prog_scope
  %t78 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %t75, { i64, ptr } %t73, { i64, ptr } %t71)
  store i1 %t78, ptr %l30
  br label %bb14
bb14:
  %t79 = load i1, ptr %l30, !tbaa !21
  br i1 %t79, label %bb15, label %bb16
bb15:
  call void @__olang_scope_close(ptr %s2)
  store i1 false, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t81 = load i64, ptr %l2, !tbaa !24
  %t84 = add i64 %t81, 1
  store i64 %t84, ptr %l2, !tbaa !24
  br label %bb10
bb19:
  call void @__olang_scope_close(ptr %s2)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fparse_3aParser_2ector(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, ptr %a3, ptr %a4, i64 %a5) #0 {
entry:
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca i64
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i32
  %l35 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l37 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l38 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l39 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l43 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l44 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l46 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca { i64, ptr }
  %l50 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l52 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l54 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l59 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca i1
  %l61 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l62 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l76 = alloca i64
  %l78 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l80 = alloca i64
  %l82 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i64
  %l86 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %l88 = alloca i64
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l92 = alloca i64
  %l94 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l96 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l97 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l99 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l101 = alloca i64
  %l103 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l105 = alloca i64
  %l107 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l109 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l110 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l114 = alloca i64
  %l116 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l118 = alloca i64
  %l120 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l122 = alloca i64
  %l124 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l126 = alloca i64
  %l128 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l130 = alloca i64
  %l132 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l134 = alloca i64
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l138 = alloca i64
  %l140 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l142 = alloca i64
  %l144 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l146 = alloca i64
  %l148 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l150 = alloca i64
  %l152 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l154 = alloca i64
  %l156 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l158 = alloca %"compiler/parse:Parser"
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l6, !tbaa !29
  store ptr %a1, ptr %l7, !tbaa !29
  store ptr %a2, ptr %l8, !tbaa !29
  store ptr %a3, ptr %l9, !tbaa !29
  store ptr %a4, ptr %l10, !tbaa !29
  store i64 %a5, ptr %l11, !tbaa !24
  store i64 0, ptr %l12, !tbaa !24
  store i32 0, ptr %l13
  store i32 0, ptr %l14, !tbaa !23
  store i32 0, ptr %l15
  store i32 0, ptr %l16, !tbaa !23
  store i1 false, ptr %l17, !tbaa !21
  store i1 false, ptr %l18, !tbaa !21
  store i1 false, ptr %l19, !tbaa !21
  store i1 false, ptr %l20, !tbaa !21
  store i1 false, ptr %l21, !tbaa !21
  store i1 false, ptr %l22, !tbaa !21
  store i1 false, ptr %l23, !tbaa !21
  store i1 false, ptr %l24, !tbaa !21
  store i1 false, ptr %l25, !tbaa !21
  store i1 false, ptr %l26, !tbaa !21
  store i64 0, ptr %l27, !tbaa !24
  store i1 false, ptr %l28, !tbaa !21
  store i1 false, ptr %l29, !tbaa !21
  store i64 0, ptr %l30, !tbaa !24
  store i1 false, ptr %l31, !tbaa !21
  store i64 -1, ptr %l32, !tbaa !24
  store i1 false, ptr %l33, !tbaa !21
  store i32 -1, ptr %l34, !tbaa !23
  %t15 = call ptr @__olang_scope_hold(ptr %v5)
  %t16 = ptrtoint ptr %t15 to i64
  store i64 %t16, ptr %l76, !tbaa !24
  %t17 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e29
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = call ptr @__olang_region_make(ptr %v5)
  %t20 = ptrtoint ptr %t19 to i64
  store i64 %t20, ptr %l76, !tbaa !24
  br label %bb2
bb2:
  %t21 = load i64, ptr %l76
  %t22 = inttoptr i64 %t21 to ptr
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t22, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l78
  br label %bb3
bb3:
  %t24 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e29
  br i1 %t24, label %bb4, label %bb5
bb4:
  %t26 = load i64, ptr %l76
  %t27 = inttoptr i64 %t26 to ptr
  %t28 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78, i32 0, i32 0
  %t29 = load { i64, ptr }, ptr %t28
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = call ptr @__olang_region_or(ptr %t30, ptr null)
  %t32 = call ptr @__olang_region_home(ptr %t31)
  %t33 = icmp ne ptr %t32, null
  %t34 = select i1 %t33, ptr %t32, ptr null
  call void @__olang_region_settle_in(ptr %t27, ptr %t34)
  br label %bb5
bb5:
  %t35 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l78
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t35, ptr %l35
  %t36 = call ptr @__olang_scope_hold(ptr %v5)
  %t37 = ptrtoint ptr %t36 to i64
  store i64 %t37, ptr %l80, !tbaa !24
  %t38 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e30
  br i1 %t38, label %bb6, label %bb7
bb6:
  %t40 = call ptr @__olang_region_make(ptr %v5)
  %t41 = ptrtoint ptr %t40 to i64
  store i64 %t41, ptr %l80, !tbaa !24
  br label %bb7
bb7:
  %t42 = load i64, ptr %l80
  %t43 = inttoptr i64 %t42 to ptr
  %t44 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %t43, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t44, ptr %l82
  br label %bb8
bb8:
  %t45 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e30
  br i1 %t45, label %bb9, label %bb10
bb9:
  %t47 = load i64, ptr %l80
  %t48 = inttoptr i64 %t47 to ptr
  %t49 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82, i32 0, i32 0
  %t50 = load { i64, ptr }, ptr %t49
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = call ptr @__olang_region_or(ptr %t51, ptr null)
  %t53 = call ptr @__olang_region_home(ptr %t52)
  %t54 = icmp ne ptr %t53, null
  %t55 = select i1 %t54, ptr %t53, ptr null
  call void @__olang_region_settle_in(ptr %t48, ptr %t55)
  br label %bb10
bb10:
  %t56 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l82
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t56, ptr %l36
  %t57 = call ptr @__olang_scope_hold(ptr %v5)
  %t58 = ptrtoint ptr %t57 to i64
  store i64 %t58, ptr %l84, !tbaa !24
  %t59 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e31
  br i1 %t59, label %bb11, label %bb12
bb11:
  %t61 = call ptr @__olang_region_make(ptr %v5)
  %t62 = ptrtoint ptr %t61 to i64
  store i64 %t62, ptr %l84, !tbaa !24
  br label %bb12
bb12:
  %t63 = load i64, ptr %l84
  %t64 = inttoptr i64 %t63 to ptr
  %t65 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %t64)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t65, ptr %l86
  br label %bb13
bb13:
  %t66 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e31
  br i1 %t66, label %bb14, label %bb15
bb14:
  %t68 = load i64, ptr %l84
  %t69 = inttoptr i64 %t68 to ptr
  %t70 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86, i32 0, i32 2
  %t71 = load { i64, ptr }, ptr %t70
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = call ptr @__olang_region_or(ptr %t72, ptr null)
  %t74 = call ptr @__olang_region_home(ptr %t73)
  %t75 = icmp ne ptr %t74, null
  %t76 = select i1 %t75, ptr %t74, ptr null
  %t77 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86, i32 0, i32 1
  %t78 = load { i64, ptr }, ptr %t77
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = call ptr @__olang_region_or(ptr %t79, ptr null)
  %t81 = call ptr @__olang_region_home(ptr %t80)
  %t82 = icmp ne ptr %t81, null
  %t83 = select i1 %t82, ptr %t81, ptr %t76
  %t84 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86, i32 0, i32 0
  %t85 = load { i64, ptr }, ptr %t84
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = call ptr @__olang_region_or(ptr %t86, ptr null)
  %t88 = call ptr @__olang_region_home(ptr %t87)
  %t89 = icmp ne ptr %t88, null
  %t90 = select i1 %t89, ptr %t88, ptr %t83
  call void @__olang_region_settle_in(ptr %t69, ptr %t90)
  br label %bb15
bb15:
  %t91 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l86
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t91, ptr %l37
  %t92 = call ptr @__olang_scope_hold(ptr %v5)
  %t93 = ptrtoint ptr %t92 to i64
  store i64 %t93, ptr %l88, !tbaa !24
  %t94 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e32
  br i1 %t94, label %bb16, label %bb17
bb16:
  %t96 = call ptr @__olang_region_make(ptr %v5)
  %t97 = ptrtoint ptr %t96 to i64
  store i64 %t97, ptr %l88, !tbaa !24
  br label %bb17
bb17:
  %t98 = load i64, ptr %l88
  %t99 = inttoptr i64 %t98 to ptr
  %t100 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t99, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t100, ptr %l90
  br label %bb18
bb18:
  %t101 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e32
  br i1 %t101, label %bb19, label %bb20
bb19:
  %t103 = load i64, ptr %l88
  %t104 = inttoptr i64 %t103 to ptr
  %t105 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90, i32 0, i32 0
  %t106 = load { i64, ptr }, ptr %t105
  %t107 = extractvalue { i64, ptr } %t106, 1
  %t108 = call ptr @__olang_region_or(ptr %t107, ptr null)
  %t109 = call ptr @__olang_region_home(ptr %t108)
  %t110 = icmp ne ptr %t109, null
  %t111 = select i1 %t110, ptr %t109, ptr null
  call void @__olang_region_settle_in(ptr %t104, ptr %t111)
  br label %bb20
bb20:
  %t112 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l38
  %t113 = call ptr @__olang_scope_hold(ptr %v5)
  %t114 = ptrtoint ptr %t113 to i64
  store i64 %t114, ptr %l92, !tbaa !24
  %t115 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e33
  br i1 %t115, label %bb21, label %bb22
bb21:
  %t117 = call ptr @__olang_region_make(ptr %v5)
  %t118 = ptrtoint ptr %t117 to i64
  store i64 %t118, ptr %l92, !tbaa !24
  br label %bb22
bb22:
  %t119 = load i64, ptr %l92
  %t120 = inttoptr i64 %t119 to ptr
  %t121 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t120, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t121, ptr %l94
  br label %bb23
bb23:
  %t122 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e33
  br i1 %t122, label %bb24, label %bb25
bb24:
  %t124 = load i64, ptr %l92
  %t125 = inttoptr i64 %t124 to ptr
  %t126 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94, i32 0, i32 0
  %t127 = load { i64, ptr }, ptr %t126
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = call ptr @__olang_region_or(ptr %t128, ptr null)
  %t130 = call ptr @__olang_region_home(ptr %t129)
  %t131 = icmp ne ptr %t130, null
  %t132 = select i1 %t131, ptr %t130, ptr null
  call void @__olang_region_settle_in(ptr %t125, ptr %t132)
  br label %bb25
bb25:
  %t133 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l94
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t133, ptr %l39
  %t134 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l96
  br label %bb26
bb26:
  %t135 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l96
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t135, ptr %l40
  %t136 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t136, ptr %l97
  br label %bb27
bb27:
  %t137 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l97
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t137, ptr %l41
  %t138 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t138, ptr %l98
  br label %bb28
bb28:
  %t139 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l98
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l42
  %t140 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %l99
  br label %bb29
bb29:
  %t141 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l99
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t141, ptr %l43
  %t142 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t142, ptr %l100
  br label %bb30
bb30:
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l44
  %t144 = call ptr @__olang_scope_hold(ptr %v5)
  %t145 = ptrtoint ptr %t144 to i64
  store i64 %t145, ptr %l101, !tbaa !24
  %t146 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e39
  br i1 %t146, label %bb31, label %bb32
bb31:
  %t148 = call ptr @__olang_region_make(ptr %v5)
  %t149 = ptrtoint ptr %t148 to i64
  store i64 %t149, ptr %l101, !tbaa !24
  br label %bb32
bb32:
  %t150 = load i64, ptr %l101
  %t151 = inttoptr i64 %t150 to ptr
  %t152 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %t151, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t152, ptr %l103
  br label %bb33
bb33:
  %t153 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e39
  br i1 %t153, label %bb34, label %bb35
bb34:
  %t155 = load i64, ptr %l101
  %t156 = inttoptr i64 %t155 to ptr
  %t157 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103, i32 0, i32 0
  %t158 = load { i64, ptr }, ptr %t157
  %t159 = extractvalue { i64, ptr } %t158, 1
  %t160 = call ptr @__olang_region_or(ptr %t159, ptr null)
  %t161 = call ptr @__olang_region_home(ptr %t160)
  %t162 = icmp ne ptr %t161, null
  %t163 = select i1 %t162, ptr %t161, ptr null
  call void @__olang_region_settle_in(ptr %t156, ptr %t163)
  br label %bb35
bb35:
  %t164 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l103
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t164, ptr %l45
  %t165 = call ptr @__olang_scope_hold(ptr %v5)
  %t166 = ptrtoint ptr %t165 to i64
  store i64 %t166, ptr %l105, !tbaa !24
  %t167 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e40
  br i1 %t167, label %bb36, label %bb37
bb36:
  %t169 = call ptr @__olang_region_make(ptr %v5)
  %t170 = ptrtoint ptr %t169 to i64
  store i64 %t170, ptr %l105, !tbaa !24
  br label %bb37
bb37:
  %t171 = load i64, ptr %l105
  %t172 = inttoptr i64 %t171 to ptr
  %t173 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t172, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %l107
  br label %bb38
bb38:
  %t174 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e40
  br i1 %t174, label %bb39, label %bb40
bb39:
  %t176 = load i64, ptr %l105
  %t177 = inttoptr i64 %t176 to ptr
  %t178 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107, i32 0, i32 0
  %t179 = load { i64, ptr }, ptr %t178
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = call ptr @__olang_region_or(ptr %t180, ptr null)
  %t182 = call ptr @__olang_region_home(ptr %t181)
  %t183 = icmp ne ptr %t182, null
  %t184 = select i1 %t183, ptr %t182, ptr null
  call void @__olang_region_settle_in(ptr %t177, ptr %t184)
  br label %bb40
bb40:
  %t185 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l107
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t185, ptr %l46
  %t186 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t186, ptr %l109
  br label %bb41
bb41:
  %t187 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l109
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t187, ptr %l47
  %t188 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v5, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t188, ptr %l110
  br label %bb42
bb42:
  %t189 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l110
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t189, ptr %l48
  %t190 = icmp sge i64 0, 0
  br i1 %t190, label %bb43, label %bb44
bb43:
  %t192 = icmp sle i64 0, 1152921504606846975
  br i1 %t192, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb45:
  %t194 = mul i64 0, 8
  %t195 = insertvalue { i64, ptr } undef, i64 0, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t196, ptr %l49, !tbaa !27
  %t198 = call ptr @__olang_scope_hold(ptr %v5)
  %t199 = ptrtoint ptr %t198 to i64
  store i64 %t199, ptr %l114, !tbaa !24
  %t200 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e44
  br i1 %t200, label %bb47, label %bb48
bb46:
  call void @__olang_check_failed(ptr @olang_loc_936bfbc19493319b_da93a9696e3b504f)
  unreachable
bb47:
  %t202 = call ptr @__olang_region_make(ptr %v5)
  %t203 = ptrtoint ptr %t202 to i64
  store i64 %t203, ptr %l114, !tbaa !24
  br label %bb48
bb48:
  %t204 = load i64, ptr %l114
  %t205 = inttoptr i64 %t204 to ptr
  %t206 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t205, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t206, ptr %l116
  br label %bb49
bb49:
  %t207 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e44
  br i1 %t207, label %bb50, label %bb51
bb50:
  %t209 = load i64, ptr %l114
  %t210 = inttoptr i64 %t209 to ptr
  %t211 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l116, i32 0, i32 0
  %t212 = load { i64, ptr }, ptr %t211
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = call ptr @__olang_region_or(ptr %t213, ptr null)
  %t215 = call ptr @__olang_region_home(ptr %t214)
  %t216 = icmp ne ptr %t215, null
  %t217 = select i1 %t216, ptr %t215, ptr null
  call void @__olang_region_settle_in(ptr %t210, ptr %t217)
  br label %bb51
bb51:
  %t218 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l116
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t218, ptr %l50
  %t219 = call ptr @__olang_scope_hold(ptr %v5)
  %t220 = ptrtoint ptr %t219 to i64
  store i64 %t220, ptr %l118, !tbaa !24
  %t221 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e45
  br i1 %t221, label %bb52, label %bb53
bb52:
  %t223 = call ptr @__olang_region_make(ptr %v5)
  %t224 = ptrtoint ptr %t223 to i64
  store i64 %t224, ptr %l118, !tbaa !24
  br label %bb53
bb53:
  %t225 = load i64, ptr %l118
  %t226 = inttoptr i64 %t225 to ptr
  %t227 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t226, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t227, ptr %l120
  br label %bb54
bb54:
  %t228 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e45
  br i1 %t228, label %bb55, label %bb56
bb55:
  %t230 = load i64, ptr %l118
  %t231 = inttoptr i64 %t230 to ptr
  %t232 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120, i32 0, i32 0
  %t233 = load { i64, ptr }, ptr %t232
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = call ptr @__olang_region_or(ptr %t234, ptr null)
  %t236 = call ptr @__olang_region_home(ptr %t235)
  %t237 = icmp ne ptr %t236, null
  %t238 = select i1 %t237, ptr %t236, ptr null
  call void @__olang_region_settle_in(ptr %t231, ptr %t238)
  br label %bb56
bb56:
  %t239 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t239, ptr %l51
  %t240 = call ptr @__olang_scope_hold(ptr %v5)
  %t241 = ptrtoint ptr %t240 to i64
  store i64 %t241, ptr %l122, !tbaa !24
  %t242 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e46
  br i1 %t242, label %bb57, label %bb58
bb57:
  %t244 = call ptr @__olang_region_make(ptr %v5)
  %t245 = ptrtoint ptr %t244 to i64
  store i64 %t245, ptr %l122, !tbaa !24
  br label %bb58
bb58:
  %t246 = load i64, ptr %l122
  %t247 = inttoptr i64 %t246 to ptr
  %t248 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t247, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t248, ptr %l124
  br label %bb59
bb59:
  %t249 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e46
  br i1 %t249, label %bb60, label %bb61
bb60:
  %t251 = load i64, ptr %l122
  %t252 = inttoptr i64 %t251 to ptr
  %t253 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124, i32 0, i32 0
  %t254 = load { i64, ptr }, ptr %t253
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = call ptr @__olang_region_or(ptr %t255, ptr null)
  %t257 = call ptr @__olang_region_home(ptr %t256)
  %t258 = icmp ne ptr %t257, null
  %t259 = select i1 %t258, ptr %t257, ptr null
  call void @__olang_region_settle_in(ptr %t252, ptr %t259)
  br label %bb61
bb61:
  %t260 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l124
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t260, ptr %l52
  %t261 = call ptr @__olang_scope_hold(ptr %v5)
  %t262 = ptrtoint ptr %t261 to i64
  store i64 %t262, ptr %l126, !tbaa !24
  %t263 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e47
  br i1 %t263, label %bb62, label %bb63
bb62:
  %t265 = call ptr @__olang_region_make(ptr %v5)
  %t266 = ptrtoint ptr %t265 to i64
  store i64 %t266, ptr %l126, !tbaa !24
  br label %bb63
bb63:
  %t267 = load i64, ptr %l126
  %t268 = inttoptr i64 %t267 to ptr
  %t269 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t268, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t269, ptr %l128
  br label %bb64
bb64:
  %t270 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e47
  br i1 %t270, label %bb65, label %bb66
bb65:
  %t272 = load i64, ptr %l126
  %t273 = inttoptr i64 %t272 to ptr
  %t274 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l128, i32 0, i32 0
  %t275 = load { i64, ptr }, ptr %t274
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = call ptr @__olang_region_or(ptr %t276, ptr null)
  %t278 = call ptr @__olang_region_home(ptr %t277)
  %t279 = icmp ne ptr %t278, null
  %t280 = select i1 %t279, ptr %t278, ptr null
  call void @__olang_region_settle_in(ptr %t273, ptr %t280)
  br label %bb66
bb66:
  %t281 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l128
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t281, ptr %l53
  %t282 = call ptr @__olang_scope_hold(ptr %v5)
  %t283 = ptrtoint ptr %t282 to i64
  store i64 %t283, ptr %l130, !tbaa !24
  %t284 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e48
  br i1 %t284, label %bb67, label %bb68
bb67:
  %t286 = call ptr @__olang_region_make(ptr %v5)
  %t287 = ptrtoint ptr %t286 to i64
  store i64 %t287, ptr %l130, !tbaa !24
  br label %bb68
bb68:
  %t288 = load i64, ptr %l130
  %t289 = inttoptr i64 %t288 to ptr
  %t290 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t289, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t290, ptr %l132
  br label %bb69
bb69:
  %t291 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e48
  br i1 %t291, label %bb70, label %bb71
bb70:
  %t293 = load i64, ptr %l130
  %t294 = inttoptr i64 %t293 to ptr
  %t295 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132, i32 0, i32 0
  %t296 = load { i64, ptr }, ptr %t295
  %t297 = extractvalue { i64, ptr } %t296, 1
  %t298 = call ptr @__olang_region_or(ptr %t297, ptr null)
  %t299 = call ptr @__olang_region_home(ptr %t298)
  %t300 = icmp ne ptr %t299, null
  %t301 = select i1 %t300, ptr %t299, ptr null
  call void @__olang_region_settle_in(ptr %t294, ptr %t301)
  br label %bb71
bb71:
  %t302 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l132
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t302, ptr %l54
  store i1 false, ptr %l55, !tbaa !21
  store i1 false, ptr %l56, !tbaa !21
  %t303 = call ptr @__olang_scope_hold(ptr %v5)
  %t304 = ptrtoint ptr %t303 to i64
  store i64 %t304, ptr %l134, !tbaa !24
  %t305 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e51
  br i1 %t305, label %bb72, label %bb73
bb72:
  %t307 = call ptr @__olang_region_make(ptr %v5)
  %t308 = ptrtoint ptr %t307 to i64
  store i64 %t308, ptr %l134, !tbaa !24
  br label %bb73
bb73:
  %t309 = load i64, ptr %l134
  %t310 = inttoptr i64 %t309 to ptr
  %t311 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t310, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t311, ptr %l136
  br label %bb74
bb74:
  %t312 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e51
  br i1 %t312, label %bb75, label %bb76
bb75:
  %t314 = load i64, ptr %l134
  %t315 = inttoptr i64 %t314 to ptr
  %t316 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l136, i32 0, i32 0
  %t317 = load { i64, ptr }, ptr %t316
  %t318 = extractvalue { i64, ptr } %t317, 1
  %t319 = call ptr @__olang_region_or(ptr %t318, ptr null)
  %t320 = call ptr @__olang_region_home(ptr %t319)
  %t321 = icmp ne ptr %t320, null
  %t322 = select i1 %t321, ptr %t320, ptr null
  call void @__olang_region_settle_in(ptr %t315, ptr %t322)
  br label %bb76
bb76:
  %t323 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l136
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t323, ptr %l57
  %t324 = call ptr @__olang_scope_hold(ptr %v5)
  %t325 = ptrtoint ptr %t324 to i64
  store i64 %t325, ptr %l138, !tbaa !24
  %t326 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e52
  br i1 %t326, label %bb77, label %bb78
bb77:
  %t328 = call ptr @__olang_region_make(ptr %v5)
  %t329 = ptrtoint ptr %t328 to i64
  store i64 %t329, ptr %l138, !tbaa !24
  br label %bb78
bb78:
  %t330 = load i64, ptr %l138
  %t331 = inttoptr i64 %t330 to ptr
  %t332 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t331, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t332, ptr %l140
  br label %bb79
bb79:
  %t333 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e52
  br i1 %t333, label %bb80, label %bb81
bb80:
  %t335 = load i64, ptr %l138
  %t336 = inttoptr i64 %t335 to ptr
  %t337 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140, i32 0, i32 0
  %t338 = load { i64, ptr }, ptr %t337
  %t339 = extractvalue { i64, ptr } %t338, 1
  %t340 = call ptr @__olang_region_or(ptr %t339, ptr null)
  %t341 = call ptr @__olang_region_home(ptr %t340)
  %t342 = icmp ne ptr %t341, null
  %t343 = select i1 %t342, ptr %t341, ptr null
  call void @__olang_region_settle_in(ptr %t336, ptr %t343)
  br label %bb81
bb81:
  %t344 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l140
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t344, ptr %l58
  %t345 = call ptr @__olang_scope_hold(ptr %v5)
  %t346 = ptrtoint ptr %t345 to i64
  store i64 %t346, ptr %l142, !tbaa !24
  %t347 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e53
  br i1 %t347, label %bb82, label %bb83
bb82:
  %t349 = call ptr @__olang_region_make(ptr %v5)
  %t350 = ptrtoint ptr %t349 to i64
  store i64 %t350, ptr %l142, !tbaa !24
  br label %bb83
bb83:
  %t351 = load i64, ptr %l142
  %t352 = inttoptr i64 %t351 to ptr
  %t353 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t352, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t353, ptr %l144
  br label %bb84
bb84:
  %t354 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e53
  br i1 %t354, label %bb85, label %bb86
bb85:
  %t356 = load i64, ptr %l142
  %t357 = inttoptr i64 %t356 to ptr
  %t358 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l144, i32 0, i32 0
  %t359 = load { i64, ptr }, ptr %t358
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = call ptr @__olang_region_or(ptr %t360, ptr null)
  %t362 = call ptr @__olang_region_home(ptr %t361)
  %t363 = icmp ne ptr %t362, null
  %t364 = select i1 %t363, ptr %t362, ptr null
  call void @__olang_region_settle_in(ptr %t357, ptr %t364)
  br label %bb86
bb86:
  %t365 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l144
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t365, ptr %l59
  store i1 false, ptr %l60, !tbaa !21
  %t366 = call ptr @__olang_scope_hold(ptr %v5)
  %t367 = ptrtoint ptr %t366 to i64
  store i64 %t367, ptr %l146, !tbaa !24
  %t368 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e55
  br i1 %t368, label %bb87, label %bb88
bb87:
  %t370 = call ptr @__olang_region_make(ptr %v5)
  %t371 = ptrtoint ptr %t370 to i64
  store i64 %t371, ptr %l146, !tbaa !24
  br label %bb88
bb88:
  %t372 = load i64, ptr %l146
  %t373 = inttoptr i64 %t372 to ptr
  %t374 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %t373, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t374, ptr %l148
  br label %bb89
bb89:
  %t375 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e55
  br i1 %t375, label %bb90, label %bb91
bb90:
  %t377 = load i64, ptr %l146
  %t378 = inttoptr i64 %t377 to ptr
  %t379 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l148, i32 0, i32 0
  %t380 = load { i64, ptr }, ptr %t379
  %t381 = extractvalue { i64, ptr } %t380, 1
  %t382 = call ptr @__olang_region_or(ptr %t381, ptr null)
  %t383 = call ptr @__olang_region_home(ptr %t382)
  %t384 = icmp ne ptr %t383, null
  %t385 = select i1 %t384, ptr %t383, ptr null
  call void @__olang_region_settle_in(ptr %t378, ptr %t385)
  br label %bb91
bb91:
  %t386 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l148
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t386, ptr %l61
  %t387 = call ptr @__olang_scope_hold(ptr %v5)
  %t388 = ptrtoint ptr %t387 to i64
  store i64 %t388, ptr %l150, !tbaa !24
  %t389 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e56
  br i1 %t389, label %bb92, label %bb93
bb92:
  %t391 = call ptr @__olang_region_make(ptr %v5)
  %t392 = ptrtoint ptr %t391 to i64
  store i64 %t392, ptr %l150, !tbaa !24
  br label %bb93
bb93:
  %t393 = load i64, ptr %l150
  %t394 = inttoptr i64 %t393 to ptr
  %t395 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %t394, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t395, ptr %l152
  br label %bb94
bb94:
  %t396 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e56
  br i1 %t396, label %bb95, label %bb96
bb95:
  %t398 = load i64, ptr %l150
  %t399 = inttoptr i64 %t398 to ptr
  %t400 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l152, i32 0, i32 0
  %t401 = load { i64, ptr }, ptr %t400
  %t402 = extractvalue { i64, ptr } %t401, 1
  %t403 = call ptr @__olang_region_or(ptr %t402, ptr null)
  %t404 = call ptr @__olang_region_home(ptr %t403)
  %t405 = icmp ne ptr %t404, null
  %t406 = select i1 %t405, ptr %t404, ptr null
  call void @__olang_region_settle_in(ptr %t399, ptr %t406)
  br label %bb96
bb96:
  %t407 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l152
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t407, ptr %l62
  %t408 = call ptr @__olang_scope_hold(ptr %v5)
  %t409 = ptrtoint ptr %t408 to i64
  store i64 %t409, ptr %l154, !tbaa !24
  %t410 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e57
  br i1 %t410, label %bb97, label %bb98
bb97:
  %t412 = call ptr @__olang_region_make(ptr %v5)
  %t413 = ptrtoint ptr %t412 to i64
  store i64 %t413, ptr %l154, !tbaa !24
  br label %bb98
bb98:
  %t414 = load i64, ptr %l154
  %t415 = inttoptr i64 %t414 to ptr
  %t416 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %t415, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t416, ptr %l156
  br label %bb99
bb99:
  %t417 = load i1, ptr @olang_2esole_2ecompiler_2fparse_3aParser_2e57
  br i1 %t417, label %bb100, label %bb101
bb100:
  %t419 = load i64, ptr %l154
  %t420 = inttoptr i64 %t419 to ptr
  %t421 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156, i32 0, i32 0
  %t422 = load { i64, ptr }, ptr %t421
  %t423 = extractvalue { i64, ptr } %t422, 1
  %t424 = call ptr @__olang_region_or(ptr %t423, ptr null)
  %t425 = call ptr @__olang_region_home(ptr %t424)
  %t426 = icmp ne ptr %t425, null
  %t427 = select i1 %t426, ptr %t425, ptr null
  call void @__olang_region_settle_in(ptr %t420, ptr %t427)
  br label %bb101
bb101:
  %t428 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l156
  %t429 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 0
  %t430 = load ptr, ptr %l6, !tbaa !29
  store ptr %t430, ptr %t429, !tbaa !29
  %t431 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 1
  %t432 = load ptr, ptr %l7, !tbaa !29
  store ptr %t432, ptr %t431, !tbaa !29
  %t433 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 2
  %t434 = load ptr, ptr %l8, !tbaa !29
  store ptr %t434, ptr %t433, !tbaa !29
  %t435 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 3
  %t436 = load ptr, ptr %l9, !tbaa !29
  store ptr %t436, ptr %t435, !tbaa !29
  %t437 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 4
  %t438 = load ptr, ptr %l10, !tbaa !29
  store ptr %t438, ptr %t437, !tbaa !29
  %t439 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 5
  %t440 = load i64, ptr %l11, !tbaa !24
  store i64 %t440, ptr %t439, !tbaa !24
  %t441 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 6
  %t442 = load i64, ptr %l12, !tbaa !24
  store i64 %t442, ptr %t441, !tbaa !24
  %t443 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 7
  %t444 = load i32, ptr %l13, !range !{i32 0, i32 116}
  store i32 %t444, ptr %t443
  %t445 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 8
  %t446 = load i32, ptr %l14, !tbaa !23
  store i32 %t446, ptr %t445, !tbaa !23
  %t447 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 9
  %t448 = load i32, ptr %l15, !range !{i32 0, i32 116}
  store i32 %t448, ptr %t447
  %t449 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 10
  %t450 = load i32, ptr %l16, !tbaa !23
  store i32 %t450, ptr %t449, !tbaa !23
  %t451 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 11
  %t452 = load i1, ptr %l17, !tbaa !21
  store i1 %t452, ptr %t451, !tbaa !21
  %t453 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 12
  %t454 = load i1, ptr %l18, !tbaa !21
  store i1 %t454, ptr %t453, !tbaa !21
  %t455 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 13
  %t456 = load i1, ptr %l19, !tbaa !21
  store i1 %t456, ptr %t455, !tbaa !21
  %t457 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 14
  %t458 = load i1, ptr %l20, !tbaa !21
  store i1 %t458, ptr %t457, !tbaa !21
  %t459 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 15
  %t460 = load i1, ptr %l21, !tbaa !21
  store i1 %t460, ptr %t459, !tbaa !21
  %t461 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 16
  %t462 = load i1, ptr %l22, !tbaa !21
  store i1 %t462, ptr %t461, !tbaa !21
  %t463 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 17
  %t464 = load i1, ptr %l23, !tbaa !21
  store i1 %t464, ptr %t463, !tbaa !21
  %t465 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 18
  %t466 = load i1, ptr %l24, !tbaa !21
  store i1 %t466, ptr %t465, !tbaa !21
  %t467 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 19
  %t468 = load i1, ptr %l25, !tbaa !21
  store i1 %t468, ptr %t467, !tbaa !21
  %t469 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 20
  %t470 = load i1, ptr %l26, !tbaa !21
  store i1 %t470, ptr %t469, !tbaa !21
  %t471 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 21
  %t472 = load i64, ptr %l27, !tbaa !24
  store i64 %t472, ptr %t471, !tbaa !24
  %t473 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 22
  %t474 = load i1, ptr %l28, !tbaa !21
  store i1 %t474, ptr %t473, !tbaa !21
  %t475 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 23
  %t476 = load i1, ptr %l29, !tbaa !21
  store i1 %t476, ptr %t475, !tbaa !21
  %t477 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 24
  %t478 = load i64, ptr %l30, !tbaa !24
  store i64 %t478, ptr %t477, !tbaa !24
  %t479 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 25
  %t480 = load i1, ptr %l31, !tbaa !21
  store i1 %t480, ptr %t479, !tbaa !21
  %t481 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 26
  %t482 = load i64, ptr %l32, !tbaa !24
  store i64 %t482, ptr %t481, !tbaa !24
  %t483 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 27
  %t484 = load i1, ptr %l33, !tbaa !21
  store i1 %t484, ptr %t483, !tbaa !21
  %t485 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 28
  %t486 = load i32, ptr %l34, !tbaa !23
  store i32 %t486, ptr %t485, !tbaa !23
  %t487 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 29
  %t488 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l35
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t488, ptr %t487
  %t489 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 30
  %t490 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t490, ptr %t489
  %t491 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 31
  %t492 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l37
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t492, ptr %t491
  %t493 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 32
  %t494 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l38
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t494, ptr %t493
  %t495 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 33
  %t496 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l39
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t496, ptr %t495
  %t497 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 34
  %t498 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t498, ptr %t497
  %t499 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 35
  %t500 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t500, ptr %t499
  %t501 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 36
  %t502 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t502, ptr %t501
  %t503 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 37
  %t504 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l43
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t504, ptr %t503
  %t505 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 38
  %t506 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l44
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t506, ptr %t505
  %t507 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 39
  %t508 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l45
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t508, ptr %t507
  %t509 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 40
  %t510 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l46
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t510, ptr %t509
  %t511 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 41
  %t512 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t512, ptr %t511
  %t513 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 42
  %t514 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t514, ptr %t513
  %t515 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 43
  %t516 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t516, ptr %t515, !tbaa !27
  %t517 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 44
  %t518 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l50
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t518, ptr %t517
  %t519 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 45
  %t520 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l51
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t520, ptr %t519
  %t521 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 46
  %t522 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l52
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t522, ptr %t521
  %t523 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 47
  %t524 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t524, ptr %t523
  %t525 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 48
  %t526 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l54
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t526, ptr %t525
  %t527 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 49
  %t528 = load i1, ptr %l55, !tbaa !21
  store i1 %t528, ptr %t527, !tbaa !21
  %t529 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 50
  %t530 = load i1, ptr %l56, !tbaa !21
  store i1 %t530, ptr %t529, !tbaa !21
  %t531 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 51
  %t532 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t532, ptr %t531
  %t533 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 52
  %t534 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l58
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t534, ptr %t533
  %t535 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 53
  %t536 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l59
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t536, ptr %t535
  %t537 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 54
  %t538 = load i1, ptr %l60, !tbaa !21
  store i1 %t538, ptr %t537, !tbaa !21
  %t539 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 55
  %t540 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t540, ptr %t539
  %t541 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 56
  %t542 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l62
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t542, ptr %t541
  %t543 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 57
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t428, ptr %t543
  %t545 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 58
  store i1 false, ptr %t545, !tbaa !21
  %t547 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 59
  store i1 false, ptr %t547, !tbaa !21
  %t549 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 60
  store i1 false, ptr %t549, !tbaa !21
  %t551 = getelementptr %"compiler/parse:Parser", ptr %l158, i32 0, i32 61
  store i1 false, ptr %t551, !tbaa !21
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l158, i64 1016, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/parse:stackMarks" @compiler_2fparse_3astackMarks_2ector(ptr %v0, i64 %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4, i64 %a5, i64 %a6) #0 {
entry:
  %rv = alloca %"compiler/parse:stackMarks"
  br label %start
start:
  br label %bb0
bb0:
  %t16 = insertvalue %"compiler/parse:stackMarks" undef, i64 %a0, 0
  %t18 = insertvalue %"compiler/parse:stackMarks" %t16, i64 %a1, 1
  %t20 = insertvalue %"compiler/parse:stackMarks" %t18, i64 %a2, 2
  %t22 = insertvalue %"compiler/parse:stackMarks" %t20, i64 %a3, 3
  %t24 = insertvalue %"compiler/parse:stackMarks" %t22, i64 %a4, 4
  %t26 = insertvalue %"compiler/parse:stackMarks" %t24, i64 %a5, 5
  %t28 = insertvalue %"compiler/parse:stackMarks" %t26, i64 %a6, 6
  store %"compiler/parse:stackMarks" %t28, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/parse:stackMarks", ptr %rv
  ret %"compiler/parse:stackMarks" %rr
}

declare void @__olang_check_failed(ptr) cold noreturn
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %dh = load ptr, ptr %dheadptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  %hasd = icmp ne ptr %dh, null
  %owns = or i1 %hasf, %hasd
  br i1 %owns, label %owned, label %chunks
owned:
  call void @__olang_scope_close_owned(ptr %scope)
  br label %chunks
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
declare ptr @__olang_scope_of(ptr, ptr) noinline
define available_externally ptr @__olang_scope_hold(ptr %s) alwaysinline {
entry:
  %none = icmp eq ptr %s, null
  br i1 %none, label %plain, label %look
look:
  ; atomic: on a scope that is no stand-in this word is its parts list, which other threads push onto (__olang_scope_part)
  %mp = getelementptr %olang.scope, ptr %s, i32 0, i32 4
  %m = load atomic ptr, ptr %mp monotonic, align 8
  %fresh = icmp eq ptr %m, @__olang_standin_mark
  br i1 %fresh, label %make, label %kept
kept:
  %mi = ptrtoint ptr %m to i64
  %bit = and i64 %mi, 1
  %has = icmp ne i64 %bit, 0
  br i1 %has, label %keeper, label %plain
keeper:
  %ki = and i64 %mi, -2
  %k = inttoptr i64 %ki to ptr
  ret ptr %k
make:
  %f = call ptr @__olang_standin_keeper(ptr %s)
  ret ptr %f
plain:
  ret ptr %s
}
@__olang_empty_array = external constant [16 x i64]
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@.d0 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an error word" }>, align 8
@.d1 = private constant <{ i64, [60 x i8] }> <{ i64 0, [60 x i8] c"the type a literal makes before the [, as in Array<I32>[...]" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d2 = private constant <{ i64, [65 x i8] }> <{ i64 0, [65 x i8] c"'fn' or 'type' - an extern block declares C's functions and types" }>, align 8
@.d3 = private constant <{ i64, [30 x i8] }> <{ i64 0, [30 x i8] c"'for NAME in' after 'comptime'" }>, align 8
@.d4 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"an expression" }>, align 8
@.d5 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d7 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d8 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d9 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d10 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"_" }>, align 8
@.d11 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"'fn' after 'extern' in a type" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
@.d12 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a name" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"a type" }>, align 8
@.d14 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"mut " }>, align 8
@olang_2esole_2ecompiler_2fast_3aVarDecl_2e0 = weak hidden constant i1 false
declare ptr @__olang_region_make(ptr) noinline
define available_externally noalias ptr @__olang_held_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@olang_2esole_2ecompiler_2fast_3aVarDecl_2e1 = weak hidden constant i1 false
@.d15 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d16 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d18 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"(" }>, align 8
@.d19 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d20 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d21 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"(chain " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d22 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d23 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"(if " }>, align 8
@.d24 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d26 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"(call " }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d28 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d29 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"(generic " }>, align 8
@.d30 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d31 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d32 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"expr" }>, align 8
@.d33 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"t.olang" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"; " }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c" !" }>, align 8
@.d38 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Name" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Kind" }>, align 8
@.d40 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Length" }>, align 8
@.d41 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"Nullable" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Size" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Align" }>, align 8
@.d44 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Fields" }>, align 8
@.d45 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Cases" }>, align 8
@.d46 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Params" }>, align 8
@.d47 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Results" }>, align 8
@.d48 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Methods" }>, align 8
@.d49 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Functions" }>, align 8
@.d50 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Errors" }>, align 8
@.d51 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Min" }>, align 8
@.d52 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Max" }>, align 8
@.d53 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"Inf" }>, align 8
@.d54 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"NaN" }>, align 8
@.d55 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Epsilon" }>, align 8
@.d56 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"SmallestNormal" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Here" }>, align 8
@.d58 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Offset" }>, align 8
@.d59 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"BitOffset" }>, align 8
@.d60 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Bits" }>, align 8
@.d61 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"HasDefault" }>, align 8
@.d62 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Default" }>, align 8
@.d63 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"Value" }>, align 8
@.d64 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"HasMember" }>, align 8
@__olang_prog_scope = external thread_local(initialexec) global ptr
@olang_2esole_2ecompiler_2fparse_3aParser_2e29 = weak hidden constant i1 false
declare ptr @__olang_region_or(ptr, ptr)
declare ptr @__olang_region_home(ptr)
declare void @__olang_region_settle_in(ptr, ptr)
@olang_2esole_2ecompiler_2fparse_3aParser_2e30 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e31 = weak hidden constant i1 false
define linkonce_odr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @olang_2emir_2eHelperKind_2eZero_2estd_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  %rv = alloca %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %l0
  store %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %rv
  ret %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" %rr
}

@olang_2esole_2ecompiler_2fparse_3aParser_2e32 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e33 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e39 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e40 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e44 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e45 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e46 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e47 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e48 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e51 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e52 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e53 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e55 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e56 = weak hidden constant i1 false
@olang_2esole_2ecompiler_2fparse_3aParser_2e57 = weak hidden constant i1 false
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @__olang_scope_close_owned(ptr) noinline
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_standin_mark = external global i64
declare ptr @__olang_standin_keeper(ptr) noinline
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally noalias ptr @__olang_held_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  %head = load ptr, ptr %scope, !tbaa !59
  %isslot = icmp eq ptr %head, @__olang_slot_chunk
  br i1 %isslot, label %slot, label %plain
slot:
  %s = call ptr @__olang_slot_alloc(ptr %scope, i64 %rawsize)
  ret ptr %s
plain:
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
@__olang_slot_chunk = external global %olang.chunk
declare noalias ptr @__olang_slot_alloc(ptr, i64) noinline
declare i1 @compiler_2fparse_2eisOrdering(i32 %a0)
@olang_loc_1b8b9060a075dfbb_f19ba567ef63a0af = external constant [0 x i8]
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ewant(ptr %v0, ptr %a0, i32 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eLen_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2esees(ptr %v0, ptr %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadvance(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fparse_2ecompiler_2fparse_3aParser_2efrom(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ePush_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elook(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2etk(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexpr(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ename(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2eTruncate_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehends(ptr %v0, ptr %a0)
declare %"compiler/source:Span" @compiler_2fast_2ecompiler_2fast_3aExpr_2eSpan(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecomprehension(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, ptr %a2, ptr %a3, i32 %a4)
declare { i32, i1 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esep(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eDescribe(ptr %v0, i32 %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2efail(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aExpr_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ehere(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eelem(ptr %v0, ptr %v1, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentry(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ePush_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, %"compiler/source:Span" %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2epeek(ptr %v0, ptr %a0)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eprec(ptr %v0, ptr %a0, i32 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebinary(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/source:Span" @compiler_2fsource_3aSpan_2ector(ptr %v0, i32 %a0, i32 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eenter(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaccept(ptr %v0, ptr %a0, i32 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2ePush_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftoken_3aTok_3e_2eToArray_3ccompiler_2ftoken_3aTok_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Chain" @compiler_2fast_3aChain_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNullTestEq(ptr %v0, i1 %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereport(ptr %v0, ptr %v1, ptr %a0, i32 %a1, i32 %a2, %"compiler/diagmsg:Msg" %a3)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eLen_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipEnds(ptr %v0, ptr %a0)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLine(ptr %v0, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2efound(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eBlockNotClosed(ptr %v0, ptr %v1, i64 %a0, { i64, ptr } %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2eTruncate_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eleave(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2estmt(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ePush_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aStmt_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeExpr(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eLen_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2epathIds(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_34fec3df9092f56c_7b6dc988b92a4ce8 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekindAt(ptr %v0, ptr %a0, i64 %a1)
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2elineAt(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ekeywordFieldHere(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebreakBefore(ptr %v0, ptr %a0)
@olang_loc_e134f20c62dd29bf_7d644e0c862b15db = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eparams(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/ast:CaseDecl" @compiler_2fast_3aCaseDecl_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, { i64, ptr } %a2, i1 %a3, ptr %a4)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCaseDecl_26_3e_2ePush_H43bc1cace347592514b4248ffd44c907(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eentryEnd(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ePush_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i32 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eTrunca_H0175749ab7aa0aad23a4aa22bc447819(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_7f479cc541fc1ad4_6e65e2fdc3321828 = external constant [0 x i8]
@olang_loc_85a40113c80e7e3e_834c2ee7dcdf6d7a = external constant [0 x i8]
@olang_loc_6c22b543e414e27d_3e5c1ca73c24bcf9 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexprList(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Multi" @compiler_2fast_3aMulti_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i1 %a1, { i64, ptr } %a2, i1 %a3)
@olang_loc_2f9cebe9c997fb45_8e0297a0e5dae7e9 = external constant [0 x i8]
declare %"compiler/ast:VarDecl" @compiler_2fast_3aVarDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, i1 %a5, i1 %a6)
declare i1 @compiler_2fparse_2eisAssignOp(i32 %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2eLen_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %a0)
@olang_loc_3ab225d58e3cfe31_e99e7d1082de1bd = external constant [0 x i8]
declare %"compiler/ast:TypeDecl" @compiler_2fast_3aTypeDecl_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, { i64, ptr } %a1, i1 %a2, ptr %a3, i32 %a4, i1 %a5, ptr %a6, i32 %a7)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ePush_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eexternFn(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aDecl_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebody(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_a242a306f172fb83_ec0e5b3ff97fbb87 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eclauses(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/ast:ForIn" @compiler_2fast_3aForIn_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, i32 %a0, i32 %a1, ptr %a2, i1 %a3, { i64, ptr } %a4, { i64, ptr } %a5, i1 %a6)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2eone(ptr %v0, ptr %v1, ptr %a0, i32 %a1, %"compiler/source:Span" %a2)
@olang_loc_d6bd877ff3d1e116_b58b2107b9da08f2 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2esimpleStmt(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:For3" @compiler_2fast_3aFor3_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3)
declare ptr @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eFuncSig(ptr %v0, ptr %v1, ptr %a0)
declare i1 @compiler_2fparse_2ekeywordNamesField(i32 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eKeywordFieldRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2ereportAt(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/diagmsg:Msg" %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoLineBody(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eMatchValueOne(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eKeywordAsName(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @compiler_2fparse_2eisJoiningOp(i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineStartsWithOperator(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eDestructInBody(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTrailingComma(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eErrorAfterQuestion(ptr %v0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ebranch(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:If" @compiler_2fast_3aIf_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2enullMark(ptr %v0, ptr %a0)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2emarkers(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2earrayLit(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
@olang_loc_824bfdca782f89b4_8a051d8e1bdc5e78 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eLen_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eLen_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eLen_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eLen_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etext(ptr %v0, ptr %v1, ptr %a0, %"compiler/token:Token" %a1)
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aNames_2eIntern(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2eAt_3ccompiler_2fsource_3aNameId_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ePush_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@G_2ecompiler_2ftoken_2eLineBreak = available_externally constant <{ [1 x i8] }> <{ [1 x i8] c"\01" }>, align 8
declare i1 @compiler_2ftoken_2ecompiler_2ftoken_3aToken_2eHas(%"compiler/token:Token" %a0, i8 %a1)
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2epattern(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ePush_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aPattern_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fparse_2egather_3ccompiler_2fast_3aTypeRef_26_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { { i64, ptr }, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecaseBody(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/ast:Case" @compiler_2fast_3aCase_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, %"compiler/source:Span" %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4, ptr %a5)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2ePush_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aCase_26_3e_2eToArray_3ccompiler_2fast_3aCase_26_3e(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/ast:Match" @compiler_2fast_3aMatch_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, ptr %a1, i1 %a2, { i64, ptr } %a3)
declare %"compiler/token:Token" @compiler_2fparse_2ecompiler_2fparse_3aParser_2elookTok(ptr %v0, ptr %a0, i64 %a1)
declare i32 @compiler_2ftoken_2eTok_2eKeyword(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
@G_2ecompiler_2fmsgs_2eEndOfLine = external constant <{ [8 x i8], ptr }>
@G_2ecompiler_2fmsgs_2eEndOfFile = external constant <{ [8 x i8], ptr }>
declare { i64, ptr } @compiler_2fmsgs_2eTok(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_97d42995c5706fd7_20b731538cf045b = external constant [0 x i8]
@olang_loc_787ae3c3318fe322_f2232752b79280c6 = external constant [0 x i8]
@olang_loc_afe07cd3f11f5e9a_d335478c7d935166 = external constant [0 x i8]
declare %"compiler/parse:NameList" @compiler_2fparse_3aNameList_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eellipsis(ptr %v0, ptr %a0)
declare %"compiler/ast:Param" @compiler_2fast_3aParam_2ector(ptr %v0, ptr %v1, ptr %v2, %"compiler/source:Span" %a0, i32 %a1, ptr %a2, ptr %a3)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eindex(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i32, i32 } @compiler_2fparse_2ecompiler_2fparse_3aParser_2emethodName(ptr %v0, ptr %a0)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eisQualifiedType(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare i1 @compiler_2fparse_2eisPath(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aSource_2eTextOf(ptr %v0, ptr %v1, ptr %a0, %"compiler/source:Span" %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H6b5ccacad8db807339a3579aa8c82ff8(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeArgsCall(ptr %v0, ptr %a0, i64 %a1)
declare i1 @compiler_2fparse_2ecompiler_2fparse_3aParser_2espacedTypeArgs(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2ecompiler_2fsource_3aNames_2eText(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTypeArgsSpaced(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_148080230b4c6cc_b965c2d4ca1d1020 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epostfix(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_952e32d6f93638f1_595c141b0c1c5b3d = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2eTrunc_H8c52d56c2ff2ec1f038dbe3d42a0a9e1(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2eTruncate_3ccompiler_2fast_3aParam_26_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2eTrunc_H311fd53ced078d1b110127cfa5549832(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2eTruncate_3ccompiler_2fsource_3aSpan_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_682b81c4be20c47_acb581c54a6720db = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrorSet(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare { i32, { i64, ptr } } @compiler_2fparse_2ecompiler_2fparse_3aParser_2epromises(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2ftoken_2ecompiler_2ftoken_3aTok_2eText(ptr %v0, i32 %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2ePromiseMisplaced(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/ast:Sig" @compiler_2fast_3aSig_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3, i1 %a4, i1 %a5, i1 %a6, { i64, ptr } %a7, i1 %a8)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eaxisItem(ptr %v0, ptr %v1, ptr %v2, ptr %a0, i32 %a1, ptr %a2)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2esyncFrom(ptr %v0, ptr %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0)
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2eitem(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0)
declare %"compiler/ast:TopBranch" @compiler_2fast_3aTopBranch_2ector(ptr %v0, ptr %v1, %"compiler/source:Span" %a0, { i64, ptr } %a1, i64 %a2)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLineBodyOnLine(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTopLineOne(ptr %v0)
@G_2ecompiler_2fparse_2eMaxNesting = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\20\4E\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fparse_2ecompiler_2fparse_3aParser_2etooDeepAt(ptr %v0, ptr %a0, i64 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2ejoinRest(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
@olang_loc_e98eee410cc159b2_377f58609bf35bd6 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2econdFrom(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eopenAngle(ptr %v0, ptr %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eerrsArg(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fparse_2ecompiler_2fparse_3aParser_2ecloseAngle(ptr %v0, ptr %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI32_3e_2ePush_3cI32_3e(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_8764526ae5415d75_f5a9948c86d2d3b9 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eFuncTypeBare(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2etypeBody(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_ead0ed9b34ee6f0_4abfb82b89e87654 = external constant [0 x i8]
@olang_loc_ae62324d96d86fcb_b2eaa0dd969a6637 = external constant [0 x i8]
declare i64 @compiler_2fparse_2ecompiler_2fparse_3aParser_2eskipFrom(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNeedlessGroup(ptr %v0)
@olang_loc_c7048dff8864462d_6ca6baed1a8cf791 = external constant [0 x i8]
@olang_loc_6811a11f54350b9a_640e4e5711fedc76 = external constant [0 x i8]
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eadjacent(ptr %v0, ptr %v1, ptr %a0, i32 %a1)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2erendering(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_5787450c8afeca22_493a6afca2796a86 = external constant [0 x i8]
declare i32 @compiler_2fsource_2ecompiler_2fsource_3aSource_2eLineStart(ptr %v0, ptr %a0, i32 %a1)
@olang_loc_4582cd3e20803687_2be8b05c8d066113 = external constant [0 x i8]
@olang_loc_84149e0bf5f8d0aa_2bd7ba413482fcb6 = external constant [0 x i8]
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8e37d10a9f86ee49_f510a1627c721295 = external constant [0 x i8]
@olang_loc_f8a87ee7efbd8dc_1d33de4ca651bcb8 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eValueAfterEq(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i32, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2edeclRest(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i1 %a2)
@olang_loc_27f714d6bf6116e7_8d792a4c0b0d9f53 = external constant [0 x i8]
@olang_loc_d00b0c1989dce2f2_291a9b7532a6cf1e = external constant [0 x i8]
declare ptr @compiler_2fparse_2ecompiler_2fparse_3aParser_2elastField(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, i32 %a2, %"compiler/source:Span" %a3)
declare i1 @compiler_2fast_2ecompiler_2fast_3aTypeRef_2eIsFunc(ptr %v0, ptr %a0)
@olang_loc_9ddb86cdc3200de1_dc174b333c4dad15 = external constant [0 x i8]
@olang_loc_a90b8672e6678ca2_64dc780a504a1e7e = external constant [0 x i8]
@olang_loc_95becaa34f722781_c104ec8a8e14f09d = external constant [0 x i8]
@olang_loc_a6e4b06ca3f2f7b3_b26c102023f13b6f = external constant [0 x i8]
declare %"compiler/source:Source" @compiler_2fsource_3aSource_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/source:Names" @compiler_2fsource_3aNames_2ector(ptr %v0)
declare void @compiler_2fparse_3aOracle_2ector(ptr %out, ptr %v0)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eSplit(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @compiler_2fparse_2ecompiler_2fparse_3aOracle_2eAdd(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare %"compiler/scan:Tokens" @compiler_2fscan_2eTokens_2eScan(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fparse_2ecompiler_2fparse_3aParser_2eFile(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChooseAll(ptr %v0, ptr %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i64 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eLen(ptr %v0, ptr %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fparse_2eshapeDecl(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eLen_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:Said" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fdiag_3aSaid_3e_2eAt_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI32_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cBool_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aNameId_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aExpr_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aStmt_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aTypeRef_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aParam_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aPattern_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fsource_3aSpan_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fast_3aDecl_26_3e_2ector(ptr %v0, i64 %a0)
@olang_loc_936bfbc19493319b_da93a9696e3b504f = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" @std_2fprelude_2fmap_3aMap_3cI32_2c_20I64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
