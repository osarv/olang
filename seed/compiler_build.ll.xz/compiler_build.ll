; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Sha256" = type { [8 x i32], [64 x i8], i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"std/chan:Chan<I64>" = type { { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, [8 x i64], [8 x i64], [8 x i64] }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/cond:Value>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"std/prelude/list:List<compiler/cond:Value>" = type { ptr }
%"std/prelude/list:List<Bool>" = type { ptr }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr } }
%"compiler/build:compiles" = type { %"std/prelude/list:List<Array<std/prelude/text:String&>&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"std/prelude/list:List<Array<std/prelude/text:String&>&>" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Program" = type { %"std/prelude/list:List<compiler/build:Unit>", { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<compiler/build:Unit>" = type { ptr }
@G_2ecompiler_2fbuild_2eShaK = global [64 x i32] zeroinitializer
@G_2ecompiler_2fbuild_2eThinFrom = global i64 zeroinitializer
define dso_local { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Sha256"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca [1 x i8]
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l8
  store %"compiler/build:Sha256" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l11, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %l12, !tbaa !24
  %t7 = load ptr, ptr %l11, !tbaa !29
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  br label %bb8
bb4:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l15, !tbaa !23
  %t17 = load i32, ptr %l15, !tbaa !23
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l16, !tbaa !21
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb8:
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l17, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l18, !tbaa !24
  %t24 = load i64, ptr %l18, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  store i64 %t25, ptr %l19, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l20, !tbaa !24
  %t27 = load i64, ptr %l19, !tbaa !24
  %t28 = load i64, ptr %l20, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l21, !tbaa !21
  %t30 = load i1, ptr %l21, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l22, !tbaa !21
  %t32 = load i1, ptr %l22, !tbaa !21
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load i64, ptr %l24, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t35
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t40, ptr %l7, !tbaa !27
  store ptr %l1, ptr %l26, !tbaa !29
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t41, ptr %l27, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t42, ptr %l28, !tbaa !27
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %t43, { i64, ptr } %t44)
  br label %bb13
bb13:
  store ptr %l1, ptr %l29, !tbaa !29
  %t45 = insertvalue [1 x i8] undef, i8 0, 0
  store [1 x i8] %t45, ptr %l30
  %t46 = load [1 x i8], ptr %l30
  %t47 = load ptr, ptr @__olang_prog_scope
  %t48 = call ptr @__olang_scope_alloc(ptr %t47, i64 1)
  store [1 x i8] %t46, ptr %t48
  %t49 = insertvalue { i64, ptr } undef, i64 1, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l31, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32, !tbaa !27
  %t58 = load ptr, ptr %l29, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l32, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %s3, ptr %t58, { i64, ptr } %t59)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = load i64, ptr %l6, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  %t61 = load i64, ptr %l33, !tbaa !24
  %t62 = add i64 %t61, 1
  store i64 %t62, ptr %l34, !tbaa !24
  %t63 = load i64, ptr %l34, !tbaa !24
  store i64 %t63, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb9
bb16:
  %t64 = load i64, ptr %l3, !tbaa !24
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  store i64 %t65, ptr %l36, !tbaa !24
  %t66 = load i64, ptr %l35, !tbaa !24
  %t67 = load i64, ptr %l36, !tbaa !24
  %t68 = add i64 %t66, %t67
  store i64 %t68, ptr %l37, !tbaa !24
  %t69 = load i64, ptr %l37, !tbaa !24
  store i64 %t69, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb2
bb18:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l38, !tbaa !29
  %t70 = load ptr, ptr %l38, !tbaa !29
  %t71 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %t70)
  store { i64, ptr } %t71, ptr %l39
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca ptr
  %l18 = alloca i8
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i8
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i8
  %l28 = alloca i1
  %l29 = alloca i8
  %l30 = alloca i8
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t3, ptr %l7, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  store i64 %t8, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l10, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l11, !tbaa !24
  %t11 = load i64, ptr %l10, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l12, !tbaa !21
  %t14 = load i1, ptr %l12, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l13, !tbaa !21
  %t16 = load i1, ptr %l13, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l15, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t19
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l16, !tbaa !22
  %t24 = load i8, ptr %l16, !tbaa !22
  store i8 %t24, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  store i8 %t25, ptr %l18, !tbaa !22
  %t26 = load i8, ptr %l18, !tbaa !22
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t26)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t29 = load i8, ptr %l5, !tbaa !22
  store i8 %t29, ptr %l21, !tbaa !22
  %t30 = load i8, ptr %l21, !tbaa !22
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t30)
  store i1 %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load i1, ptr %l22, !tbaa !21
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i8, ptr %l5, !tbaa !22
  store i8 %t34, ptr %l24, !tbaa !22
  %t35 = load i8, ptr %l24, !tbaa !22
  %t36 = icmp eq i8 %t35, 95
  store i1 %t36, ptr %l25, !tbaa !21
  %t37 = load i1, ptr %l25, !tbaa !21
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t39 = load i8, ptr %l5, !tbaa !22
  store i8 %t39, ptr %l27, !tbaa !22
  %t40 = load i8, ptr %l27, !tbaa !22
  %t41 = icmp eq i8 %t40, 45
  store i1 %t41, ptr %l28, !tbaa !21
  %t42 = load i1, ptr %l28, !tbaa !21
  store i1 %t42, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t44 = load i8, ptr %l5, !tbaa !22
  store i8 %t44, ptr %l30, !tbaa !22
  %t45 = load i8, ptr %l30, !tbaa !22
  store i8 %t45, ptr %l29, !tbaa !22
  br label %bb19
bb18:
  store i8 95, ptr %l29, !tbaa !22
  br label %bb19
bb19:
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t47 = load i8, ptr %l29, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t46, i8 %t47)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l3, !tbaa !24
  store i64 %t48, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l31, !tbaa !24
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l32, !tbaa !24
  %t51 = load i64, ptr %l32, !tbaa !24
  store i64 %t51, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb2
bb22:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l33, !tbaa !29
  %t52 = load ptr, ptr %l33, !tbaa !29
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t52)
  store { i64, ptr } %t53, ptr %l34
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { { i64, ptr }, { i64, ptr } }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca %"std/chan:Chan<I64>"
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca { { i64, ptr }, { i64, ptr } }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %jh6 = alloca ptr
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t93 = alloca %"std/chan:Chan<I64>", align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l19, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l20, !tbaa !24
  %t4 = load i64, ptr %l20, !tbaa !24
  store i64 %t4, ptr %l2, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l21, !tbaa !24
  %t6 = load i64, ptr %l21, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  store i1 %t7, ptr %l22, !tbaa !21
  %t8 = load i1, ptr %l22, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l21, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  store i1 %t10, ptr %l23, !tbaa !21
  %t11 = load i1, ptr %l23, !tbaa !21
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb3:
  %t12 = load i64, ptr %l21, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l24, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 4
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l25, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t24, ptr %l3, !tbaa !27
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l26, !tbaa !24
  %t26 = load i64, ptr %l26, !tbaa !24
  %t27 = icmp sge i64 %t26, 0
  store i1 %t27, ptr %l27, !tbaa !21
  %t28 = load i1, ptr %l27, !tbaa !21
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb5:
  %t29 = load i64, ptr %l26, !tbaa !24
  %t30 = icmp sle i64 %t29, 576460752303423487
  store i1 %t30, ptr %l28, !tbaa !21
  %t31 = load i1, ptr %l28, !tbaa !21
  br i1 %t31, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb7:
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = mul i64 %t32, 16
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l29, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 16
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t44, ptr %l4, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l31, !tbaa !24
  %t46 = load i64, ptr %l31, !tbaa !24
  %t47 = icmp eq i64 %t46, 0
  store i1 %t47, ptr %l32, !tbaa !21
  %t48 = load i1, ptr %l32, !tbaa !21
  br i1 %t48, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t49, ptr %l33, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t50, ptr %l34, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t51, ptr %l35, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t52, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t54 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t53, 0
  %t55 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t56 = insertvalue { { i64, ptr }, { i64, ptr } } %t54, { i64, ptr } %t55, 1
  store { { i64, ptr }, { i64, ptr } } %t56, ptr %l37
  %t57 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l38, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l39, !tbaa !24
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = mul i64 %t61, 4
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l40, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l39, !tbaa !24
  %t71 = mul i64 %t70, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t73 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 0
  store { i64, ptr } %t72, ptr %t73, !tbaa !27
  %t74 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 1
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  store { i64, ptr } %t75, ptr %l41, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l42, !tbaa !24
  %t78 = load i64, ptr %l42, !tbaa !24
  %t79 = mul i64 %t78, 16
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l43, !tbaa !27
  %t83 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t84 = load ptr, ptr %t83, !tbaa !27
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = load i64, ptr %l42, !tbaa !24
  %t88 = mul i64 %t87, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t90 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 1
  store { i64, ptr } %t89, ptr %t90, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t91 = load { { i64, ptr }, { i64, ptr } }, ptr %l37
  store { { i64, ptr }, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t92 = load i64, ptr %l2, !tbaa !24
  store i64 %t92, ptr %l44, !tbaa !24
  %t94 = load i64, ptr %l44, !tbaa !24
  call void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %t93, ptr %s0, i64 %t94)
  %t95 = load %"std/chan:Chan<I64>", ptr %t93
  store %"std/chan:Chan<I64>" %t95, ptr %l45
  br label %bb12
bb12:
  %t96 = load %"std/chan:Chan<I64>", ptr %l45
  %t97 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 264, i64 8)
  store %"std/chan:Chan<I64>" %t96, ptr %t97
  store ptr %t97, ptr %l46, !tbaa !29
  %t98 = load ptr, ptr %l46, !tbaa !29
  store ptr %t98, ptr %l5, !tbaa !29
  %t99 = load ptr, ptr %l5, !tbaa !29
  store ptr %t99, ptr %l47, !tbaa !29
  %t100 = load ptr, ptr %l47, !tbaa !29
  call void @std_2fchan_2eInit_3cI64_3e(ptr %s0, ptr %t100)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l6, !tbaa !24
  %t101 = load i64, ptr %l2, !tbaa !24
  store i64 %t101, ptr %l48, !tbaa !24
  %t102 = load i64, ptr %l48, !tbaa !24
  store i64 %t102, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t103 = load i64, ptr %l7, !tbaa !24
  store i64 %t103, ptr %l49, !tbaa !24
  %t104 = load i64, ptr %l6, !tbaa !24
  store i64 %t104, ptr %l50, !tbaa !24
  %t105 = load i64, ptr %l49, !tbaa !24
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = icmp sgt i64 %t105, %t106
  store i1 %t107, ptr %l51, !tbaa !21
  %t108 = load i1, ptr %l51, !tbaa !21
  br i1 %t108, label %bb14, label %bb15
bb14:
  %t109 = load i64, ptr %l8, !tbaa !24
  store i64 %t109, ptr %l53, !tbaa !24
  %t110 = load i64, ptr %l53, !tbaa !24
  %t111 = icmp sgt i64 %t110, 0
  store i1 %t111, ptr %l54, !tbaa !21
  %t112 = load i1, ptr %l54, !tbaa !21
  br i1 %t112, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l52, !tbaa !24
  br label %bb19
bb16:
  %t113 = load i64, ptr %l7, !tbaa !24
  store i64 %t113, ptr %l56, !tbaa !24
  %t114 = load i64, ptr %l6, !tbaa !24
  store i64 %t114, ptr %l57, !tbaa !24
  %t115 = load i64, ptr %l56, !tbaa !24
  %t116 = load i64, ptr %l57, !tbaa !24
  %t117 = sub i64 %t115, %t116
  store i64 %t117, ptr %l58, !tbaa !24
  %t118 = load i64, ptr %l8, !tbaa !24
  store i64 %t118, ptr %l59, !tbaa !24
  %t119 = load i64, ptr %l58, !tbaa !24
  %t120 = load i64, ptr %l59, !tbaa !24
  %t121 = add i64 %t119, %t120
  store i64 %t121, ptr %l60, !tbaa !24
  %t122 = load i64, ptr %l60, !tbaa !24
  %t123 = sub i64 %t122, 1
  store i64 %t123, ptr %l61, !tbaa !24
  %t124 = load i64, ptr %l8, !tbaa !24
  store i64 %t124, ptr %l62, !tbaa !24
  %t125 = load i64, ptr %l61, !tbaa !24
  %t126 = load i64, ptr %l62, !tbaa !24
  %t127 = sdiv i64 %t125, %t126
  store i64 %t127, ptr %l63, !tbaa !24
  %t128 = load i64, ptr %l63, !tbaa !24
  store i64 %t128, ptr %l55, !tbaa !24
  br label %bb18
bb17:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb18
bb18:
  %t129 = load i64, ptr %l55, !tbaa !24
  store i64 %t129, ptr %l52, !tbaa !24
  br label %bb19
bb19:
  %t130 = load i64, ptr %l52, !tbaa !24
  store i64 %t130, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t131 = load i64, ptr %l10, !tbaa !24
  store i64 %t131, ptr %l64, !tbaa !24
  %t132 = load i64, ptr %l9, !tbaa !24
  store i64 %t132, ptr %l65, !tbaa !24
  %t133 = load i64, ptr %l64, !tbaa !24
  %t134 = load i64, ptr %l65, !tbaa !24
  %t135 = icmp slt i64 %t133, %t134
  store i1 %t135, ptr %l66, !tbaa !21
  %t136 = load i1, ptr %l66, !tbaa !21
  %t137 = xor i1 %t136, true
  store i1 %t137, ptr %l67, !tbaa !21
  %t138 = load i1, ptr %l67, !tbaa !21
  br i1 %t138, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb22:
  br label %bb23
bb23:
  %t139 = load i64, ptr %l6, !tbaa !24
  store i64 %t139, ptr %l68, !tbaa !24
  %t140 = load i64, ptr %l10, !tbaa !24
  store i64 %t140, ptr %l69, !tbaa !24
  %t141 = load i64, ptr %l8, !tbaa !24
  store i64 %t141, ptr %l70, !tbaa !24
  %t142 = load i64, ptr %l69, !tbaa !24
  %t143 = load i64, ptr %l70, !tbaa !24
  %t144 = mul i64 %t142, %t143
  store i64 %t144, ptr %l71, !tbaa !24
  %t145 = load i64, ptr %l68, !tbaa !24
  %t146 = load i64, ptr %l71, !tbaa !24
  %t147 = add i64 %t145, %t146
  store i64 %t147, ptr %l72, !tbaa !24
  %t148 = load i64, ptr %l72, !tbaa !24
  store i64 %t148, ptr %l11, !tbaa !24
  %t149 = load ptr, ptr %l5, !tbaa !29
  store ptr %t149, ptr %l73, !tbaa !29
  %t150 = load i64, ptr %l11, !tbaa !24
  store i64 %t150, ptr %l74, !tbaa !24
  %t151 = load ptr, ptr %l73, !tbaa !29
  %t152 = load i64, ptr %l74, !tbaa !24
  %t153 = call i32 @std_2fchan_2eSend_3cI64_3e(ptr %s0, ptr %t151, i64 %t152)
  store i32 %t153, ptr %l75
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb25, label %ok.155
ok.155:
  br label %bb24
bb24:
  br label %bb29
bb25:
  %t156 = load i32, ptr %l75, !tbaa !23
  %t157 = ashr i32 %t156, 16
  store i32 %t157, ptr %l76, !tbaa !23
  %t158 = load i32, ptr %l76, !tbaa !23
  %t159 = icmp eq i32 %t158, 1
  store i1 %t159, ptr %l77, !tbaa !21
  %t160 = load i1, ptr %l77, !tbaa !21
  br i1 %t160, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t161 = load i64, ptr %l10, !tbaa !24
  store i64 %t161, ptr %l78, !tbaa !24
  %t162 = load i64, ptr %l78, !tbaa !24
  %t163 = add i64 %t162, 1
  store i64 %t163, ptr %l79, !tbaa !24
  %t164 = load i64, ptr %l79, !tbaa !24
  store i64 %t164, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t165 = load i64, ptr %l1, !tbaa !24
  store i64 %t165, ptr %l80, !tbaa !24
  %t166 = load i64, ptr %l2, !tbaa !24
  store i64 %t166, ptr %l81, !tbaa !24
  %t167 = load i64, ptr %l80, !tbaa !24
  %t168 = load i64, ptr %l81, !tbaa !24
  %t169 = icmp slt i64 %t167, %t168
  store i1 %t169, ptr %l82, !tbaa !21
  %t170 = load i1, ptr %l82, !tbaa !21
  br i1 %t170, label %bb32, label %bb33
bb32:
  %t171 = load i64, ptr %l1, !tbaa !24
  store i64 %t171, ptr %l84, !tbaa !24
  %t172 = load i64, ptr %l84, !tbaa !24
  store i64 %t172, ptr %l83, !tbaa !24
  br label %bb34
bb33:
  %t173 = load i64, ptr %l2, !tbaa !24
  store i64 %t173, ptr %l85, !tbaa !24
  %t174 = load i64, ptr %l85, !tbaa !24
  store i64 %t174, ptr %l83, !tbaa !24
  br label %bb34
bb34:
  %t175 = load i64, ptr %l83, !tbaa !24
  store i64 %t175, ptr %l12, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s6
  store ptr null, ptr %jh6
  store %olang.scope zeroinitializer, ptr %s7
  store i64 0, ptr %l13, !tbaa !24
  %t176 = load i64, ptr %l12, !tbaa !24
  store i64 %t176, ptr %l86, !tbaa !24
  %t177 = load i64, ptr %l86, !tbaa !24
  store i64 %t177, ptr %l14, !tbaa !24
  store i64 1, ptr %l15, !tbaa !24
  %t178 = load i64, ptr %l14, !tbaa !24
  store i64 %t178, ptr %l87, !tbaa !24
  %t179 = load i64, ptr %l13, !tbaa !24
  store i64 %t179, ptr %l88, !tbaa !24
  %t180 = load i64, ptr %l87, !tbaa !24
  %t181 = load i64, ptr %l88, !tbaa !24
  %t182 = icmp sgt i64 %t180, %t181
  store i1 %t182, ptr %l89, !tbaa !21
  %t183 = load i1, ptr %l89, !tbaa !21
  br i1 %t183, label %bb35, label %bb36
bb35:
  %t184 = load i64, ptr %l15, !tbaa !24
  store i64 %t184, ptr %l91, !tbaa !24
  %t185 = load i64, ptr %l91, !tbaa !24
  %t186 = icmp sgt i64 %t185, 0
  store i1 %t186, ptr %l92, !tbaa !21
  %t187 = load i1, ptr %l92, !tbaa !21
  br i1 %t187, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l90, !tbaa !24
  br label %bb40
bb37:
  %t188 = load i64, ptr %l14, !tbaa !24
  store i64 %t188, ptr %l94, !tbaa !24
  %t189 = load i64, ptr %l13, !tbaa !24
  store i64 %t189, ptr %l95, !tbaa !24
  %t190 = load i64, ptr %l94, !tbaa !24
  %t191 = load i64, ptr %l95, !tbaa !24
  %t192 = sub i64 %t190, %t191
  store i64 %t192, ptr %l96, !tbaa !24
  %t193 = load i64, ptr %l15, !tbaa !24
  store i64 %t193, ptr %l97, !tbaa !24
  %t194 = load i64, ptr %l96, !tbaa !24
  %t195 = load i64, ptr %l97, !tbaa !24
  %t196 = add i64 %t194, %t195
  store i64 %t196, ptr %l98, !tbaa !24
  %t197 = load i64, ptr %l98, !tbaa !24
  %t198 = sub i64 %t197, 1
  store i64 %t198, ptr %l99, !tbaa !24
  %t199 = load i64, ptr %l15, !tbaa !24
  store i64 %t199, ptr %l100, !tbaa !24
  %t200 = load i64, ptr %l99, !tbaa !24
  %t201 = load i64, ptr %l100, !tbaa !24
  %t202 = sdiv i64 %t200, %t201
  store i64 %t202, ptr %l101, !tbaa !24
  %t203 = load i64, ptr %l101, !tbaa !24
  store i64 %t203, ptr %l93, !tbaa !24
  br label %bb39
bb38:
  store i64 0, ptr %l93, !tbaa !24
  br label %bb39
bb39:
  %t204 = load i64, ptr %l93, !tbaa !24
  store i64 %t204, ptr %l90, !tbaa !24
  br label %bb40
bb40:
  %t205 = load i64, ptr %l90, !tbaa !24
  store i64 %t205, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t206 = load i64, ptr %l17, !tbaa !24
  store i64 %t206, ptr %l102, !tbaa !24
  %t207 = load i64, ptr %l16, !tbaa !24
  store i64 %t207, ptr %l103, !tbaa !24
  %t208 = load i64, ptr %l102, !tbaa !24
  %t209 = load i64, ptr %l103, !tbaa !24
  %t210 = icmp slt i64 %t208, %t209
  store i1 %t210, ptr %l104, !tbaa !21
  %t211 = load i1, ptr %l104, !tbaa !21
  %t212 = xor i1 %t211, true
  store i1 %t212, ptr %l105, !tbaa !21
  %t213 = load i1, ptr %l105, !tbaa !21
  br i1 %t213, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t214 = load i64, ptr %l13, !tbaa !24
  store i64 %t214, ptr %l106, !tbaa !24
  %t215 = load i64, ptr %l17, !tbaa !24
  store i64 %t215, ptr %l107, !tbaa !24
  %t216 = load i64, ptr %l15, !tbaa !24
  store i64 %t216, ptr %l108, !tbaa !24
  %t217 = load i64, ptr %l107, !tbaa !24
  %t218 = load i64, ptr %l108, !tbaa !24
  %t219 = mul i64 %t217, %t218
  store i64 %t219, ptr %l109, !tbaa !24
  %t220 = load i64, ptr %l106, !tbaa !24
  %t221 = load i64, ptr %l109, !tbaa !24
  %t222 = add i64 %t220, %t221
  store i64 %t222, ptr %l110, !tbaa !24
  %t223 = load i64, ptr %l110, !tbaa !24
  store i64 %t223, ptr %l18, !tbaa !24
  %t224 = load ptr, ptr %l5, !tbaa !29
  store ptr %t224, ptr %l111, !tbaa !29
  %t225 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t225, ptr %l112, !tbaa !27
  %t226 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t226, ptr %l113, !tbaa !27
  %t227 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t227, ptr %l114, !tbaa !27
  %t228 = load ptr, ptr %l111, !tbaa !29
  %t229 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t230 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t231 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t232 = call ptr @__olang_standin(ptr %s0)
  %t233 = call ptr @__olang_standin(ptr %v0)
  %t234 = call ptr @__olang_standin(ptr %v1)
  %t235 = call ptr @__olang_standin(ptr %v1)
  %t236 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t237 = ptrtoint ptr %t236 to i64
  %t238 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 %t237, i64 8)
  %t239 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 0
  store ptr %t228, ptr %t239
  %t240 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 1
  store { i64, ptr } %t229, ptr %t240
  %t241 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 2
  store { i64, ptr } %t230, ptr %t241
  %t242 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 3
  store { i64, ptr } %t231, ptr %t242
  %t243 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 4
  store ptr %t232, ptr %t243
  %t244 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 5
  store ptr %t233, ptr %t244
  %t245 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 6
  store ptr %t234, ptr %t245
  %t246 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 7
  store ptr %t235, ptr %t246
  %t247 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  %t248 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr null, ptr %t248
  %t249 = getelementptr { ptr, ptr }, ptr %t248, i32 0, i32 1
  store ptr %t232, ptr %t249
  %t250 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr %t248, ptr %t250
  %t251 = getelementptr { ptr, ptr }, ptr %t250, i32 0, i32 1
  store ptr %t233, ptr %t251
  %t252 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr %t250, ptr %t252
  %t253 = getelementptr { ptr, ptr }, ptr %t252, i32 0, i32 1
  store ptr %t234, ptr %t253
  %t254 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr %t252, ptr %t254
  %t255 = getelementptr { ptr, ptr }, ptr %t254, i32 0, i32 1
  store ptr %t235, ptr %t255
  %t256 = getelementptr { ptr, i64, ptr, i64 }, ptr %t247, i32 0, i32 2
  store ptr %t254, ptr %t256
  %t257 = getelementptr { ptr, i64, ptr, i64 }, ptr %t247, i32 0, i32 1
  store i64 0, ptr %t257
  %t258 = getelementptr { ptr, i64, ptr, i64 }, ptr %t247, i32 0, i32 3
  store i64 0, ptr %t258
  %t259 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t259, ptr @olang_task4, ptr %t238, ptr %t247)
  %t260 = load ptr, ptr %jh6
  store ptr %t260, ptr %t247
  store ptr %t247, ptr %jh6
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t261 = load i64, ptr %l17, !tbaa !24
  store i64 %t261, ptr %l115, !tbaa !24
  %t262 = load i64, ptr %l115, !tbaa !24
  %t263 = add i64 %t262, 1
  store i64 %t263, ptr %l116, !tbaa !24
  %t264 = load i64, ptr %l116, !tbaa !24
  store i64 %t264, ptr %l17, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb46:
  call void @__olang_scope_close(ptr %s7)
  %t265 = load ptr, ptr %l5, !tbaa !29
  store ptr %t265, ptr %l117, !tbaa !29
  %t266 = load ptr, ptr %l117, !tbaa !29
  call void @std_2fchan_2eClose_3cI64_3e(ptr %s0, ptr %t266)
  br label %bb47
bb47:
  %t267 = call i64 @__olang_join_tasks(ptr %jh6)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t268 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t268, ptr %l118, !tbaa !27
  %t269 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t269, ptr %l119, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t270, ptr %l120, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t271, ptr %l121, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t273 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t272, 0
  %t274 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t275 = insertvalue { { i64, ptr }, { i64, ptr } } %t273, { i64, ptr } %t274, 1
  store { { i64, ptr }, { i64, ptr } } %t275, ptr %l122
  %t276 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 0
  %t277 = load { i64, ptr }, ptr %t276, !tbaa !27
  store { i64, ptr } %t277, ptr %l123, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  store i64 %t279, ptr %l124, !tbaa !24
  %t280 = load i64, ptr %l124, !tbaa !24
  %t281 = mul i64 %t280, 4
  %t282 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t281)
  %t283 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  store { i64, ptr } %t284, ptr %l125, !tbaa !27
  %t285 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t286 = load ptr, ptr %t285, !tbaa !27
  %t287 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = load i64, ptr %l124, !tbaa !24
  %t290 = mul i64 %t289, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t286, ptr %t288, i64 %t290, i1 false)
  %t291 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t292 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 0
  store { i64, ptr } %t291, ptr %t292, !tbaa !27
  %t293 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 1
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  store { i64, ptr } %t294, ptr %l126, !tbaa !27
  %t295 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 0
  store i64 %t296, ptr %l127, !tbaa !24
  %t297 = load i64, ptr %l127, !tbaa !24
  %t298 = mul i64 %t297, 16
  %t299 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t298)
  %t300 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, ptr } %t301, ptr %l128, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = load i64, ptr %l127, !tbaa !24
  %t307 = mul i64 %t306, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t303, ptr %t305, i64 %t307, i1 false)
  %t308 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t309 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 1
  store { i64, ptr } %t308, ptr %t309, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t310 = load { { i64, ptr }, { i64, ptr } }, ptr %l122
  store { { i64, ptr }, { i64, ptr } } %t310, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbuild_2eShaK_2einit() #0 {
entry:
  %l0 = alloca [64 x i32]
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr [64 x i32], ptr %l0, i64 0, i64 0
  store i32 1116352408, ptr %t1
  %t2 = getelementptr [64 x i32], ptr %l0, i64 0, i64 1
  store i32 1899447441, ptr %t2
  %t3 = getelementptr [64 x i32], ptr %l0, i64 0, i64 2
  store i32 -1245643825, ptr %t3
  %t4 = getelementptr [64 x i32], ptr %l0, i64 0, i64 3
  store i32 -373957723, ptr %t4
  %t5 = getelementptr [64 x i32], ptr %l0, i64 0, i64 4
  store i32 961987163, ptr %t5
  %t6 = getelementptr [64 x i32], ptr %l0, i64 0, i64 5
  store i32 1508970993, ptr %t6
  %t7 = getelementptr [64 x i32], ptr %l0, i64 0, i64 6
  store i32 -1841331548, ptr %t7
  %t8 = getelementptr [64 x i32], ptr %l0, i64 0, i64 7
  store i32 -1424204075, ptr %t8
  %t9 = getelementptr [64 x i32], ptr %l0, i64 0, i64 8
  store i32 -670586216, ptr %t9
  %t10 = getelementptr [64 x i32], ptr %l0, i64 0, i64 9
  store i32 310598401, ptr %t10
  %t11 = getelementptr [64 x i32], ptr %l0, i64 0, i64 10
  store i32 607225278, ptr %t11
  %t12 = getelementptr [64 x i32], ptr %l0, i64 0, i64 11
  store i32 1426881987, ptr %t12
  %t13 = getelementptr [64 x i32], ptr %l0, i64 0, i64 12
  store i32 1925078388, ptr %t13
  %t14 = getelementptr [64 x i32], ptr %l0, i64 0, i64 13
  store i32 -2132889090, ptr %t14
  %t15 = getelementptr [64 x i32], ptr %l0, i64 0, i64 14
  store i32 -1680079193, ptr %t15
  %t16 = getelementptr [64 x i32], ptr %l0, i64 0, i64 15
  store i32 -1046744716, ptr %t16
  %t17 = getelementptr [64 x i32], ptr %l0, i64 0, i64 16
  store i32 -459576895, ptr %t17
  %t18 = getelementptr [64 x i32], ptr %l0, i64 0, i64 17
  store i32 -272742522, ptr %t18
  %t19 = getelementptr [64 x i32], ptr %l0, i64 0, i64 18
  store i32 264347078, ptr %t19
  %t20 = getelementptr [64 x i32], ptr %l0, i64 0, i64 19
  store i32 604807628, ptr %t20
  %t21 = getelementptr [64 x i32], ptr %l0, i64 0, i64 20
  store i32 770255983, ptr %t21
  %t22 = getelementptr [64 x i32], ptr %l0, i64 0, i64 21
  store i32 1249150122, ptr %t22
  %t23 = getelementptr [64 x i32], ptr %l0, i64 0, i64 22
  store i32 1555081692, ptr %t23
  %t24 = getelementptr [64 x i32], ptr %l0, i64 0, i64 23
  store i32 1996064986, ptr %t24
  %t25 = getelementptr [64 x i32], ptr %l0, i64 0, i64 24
  store i32 -1740746414, ptr %t25
  %t26 = getelementptr [64 x i32], ptr %l0, i64 0, i64 25
  store i32 -1473132947, ptr %t26
  %t27 = getelementptr [64 x i32], ptr %l0, i64 0, i64 26
  store i32 -1341970488, ptr %t27
  %t28 = getelementptr [64 x i32], ptr %l0, i64 0, i64 27
  store i32 -1084653625, ptr %t28
  %t29 = getelementptr [64 x i32], ptr %l0, i64 0, i64 28
  store i32 -958395405, ptr %t29
  %t30 = getelementptr [64 x i32], ptr %l0, i64 0, i64 29
  store i32 -710438585, ptr %t30
  %t31 = getelementptr [64 x i32], ptr %l0, i64 0, i64 30
  store i32 113926993, ptr %t31
  %t32 = getelementptr [64 x i32], ptr %l0, i64 0, i64 31
  store i32 338241895, ptr %t32
  %t33 = getelementptr [64 x i32], ptr %l0, i64 0, i64 32
  store i32 666307205, ptr %t33
  %t34 = getelementptr [64 x i32], ptr %l0, i64 0, i64 33
  store i32 773529912, ptr %t34
  %t35 = getelementptr [64 x i32], ptr %l0, i64 0, i64 34
  store i32 1294757372, ptr %t35
  %t36 = getelementptr [64 x i32], ptr %l0, i64 0, i64 35
  store i32 1396182291, ptr %t36
  %t37 = getelementptr [64 x i32], ptr %l0, i64 0, i64 36
  store i32 1695183700, ptr %t37
  %t38 = getelementptr [64 x i32], ptr %l0, i64 0, i64 37
  store i32 1986661051, ptr %t38
  %t39 = getelementptr [64 x i32], ptr %l0, i64 0, i64 38
  store i32 -2117940946, ptr %t39
  %t40 = getelementptr [64 x i32], ptr %l0, i64 0, i64 39
  store i32 -1838011259, ptr %t40
  %t41 = getelementptr [64 x i32], ptr %l0, i64 0, i64 40
  store i32 -1564481375, ptr %t41
  %t42 = getelementptr [64 x i32], ptr %l0, i64 0, i64 41
  store i32 -1474664885, ptr %t42
  %t43 = getelementptr [64 x i32], ptr %l0, i64 0, i64 42
  store i32 -1035236496, ptr %t43
  %t44 = getelementptr [64 x i32], ptr %l0, i64 0, i64 43
  store i32 -949202525, ptr %t44
  %t45 = getelementptr [64 x i32], ptr %l0, i64 0, i64 44
  store i32 -778901479, ptr %t45
  %t46 = getelementptr [64 x i32], ptr %l0, i64 0, i64 45
  store i32 -694614492, ptr %t46
  %t47 = getelementptr [64 x i32], ptr %l0, i64 0, i64 46
  store i32 -200395387, ptr %t47
  %t48 = getelementptr [64 x i32], ptr %l0, i64 0, i64 47
  store i32 275423344, ptr %t48
  %t49 = getelementptr [64 x i32], ptr %l0, i64 0, i64 48
  store i32 430227734, ptr %t49
  %t50 = getelementptr [64 x i32], ptr %l0, i64 0, i64 49
  store i32 506948616, ptr %t50
  %t51 = getelementptr [64 x i32], ptr %l0, i64 0, i64 50
  store i32 659060556, ptr %t51
  %t52 = getelementptr [64 x i32], ptr %l0, i64 0, i64 51
  store i32 883997877, ptr %t52
  %t53 = getelementptr [64 x i32], ptr %l0, i64 0, i64 52
  store i32 958139571, ptr %t53
  %t54 = getelementptr [64 x i32], ptr %l0, i64 0, i64 53
  store i32 1322822218, ptr %t54
  %t55 = getelementptr [64 x i32], ptr %l0, i64 0, i64 54
  store i32 1537002063, ptr %t55
  %t56 = getelementptr [64 x i32], ptr %l0, i64 0, i64 55
  store i32 1747873779, ptr %t56
  %t57 = getelementptr [64 x i32], ptr %l0, i64 0, i64 56
  store i32 1955562222, ptr %t57
  %t58 = getelementptr [64 x i32], ptr %l0, i64 0, i64 57
  store i32 2024104815, ptr %t58
  %t59 = getelementptr [64 x i32], ptr %l0, i64 0, i64 58
  store i32 -2067236844, ptr %t59
  %t60 = getelementptr [64 x i32], ptr %l0, i64 0, i64 59
  store i32 -1933114872, ptr %t60
  %t61 = getelementptr [64 x i32], ptr %l0, i64 0, i64 60
  store i32 -1866530822, ptr %t61
  %t62 = getelementptr [64 x i32], ptr %l0, i64 0, i64 61
  store i32 -1538233109, ptr %t62
  %t63 = getelementptr [64 x i32], ptr %l0, i64 0, i64 62
  store i32 -1090935817, ptr %t63
  %t64 = getelementptr [64 x i32], ptr %l0, i64 0, i64 63
  store i32 -965641998, ptr %t64
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fbuild_2eShaK, ptr %l0, i64 256, i1 false)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 1, ptr @.d5 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l4, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l5, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  br label %bb4
bb3:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d6 }, 1
  %t18 = extractvalue { i64, ptr } { i64 2, ptr @.d6 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t17, i64 %t18)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  call void @__olang_sb_put(ptr %s2, ptr %t20, i64 %t21)
  %t22 = load ptr, ptr %s2
  %t23 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t24 = load i64, ptr %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t22, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l7, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t28 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t28, ptr %l3, !tbaa !27
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %l2, !tbaa !23
  %t2 = load i32, ptr %l2, !tbaa !23
  %t3 = icmp eq i32 %t2, 1
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 6, ptr @.d7 }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l5, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb4:
  %t7 = load i32, ptr %l0, !tbaa !23
  store i32 %t7, ptr %l6, !tbaa !23
  %t8 = load i32, ptr %l6, !tbaa !23
  %t9 = icmp eq i32 %t8, 2
  store i1 %t9, ptr %l7, !tbaa !21
  %t10 = load i1, ptr %l7, !tbaa !21
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 9, ptr @.d8 }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l9, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t12, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb57
bb8:
  %t13 = load i32, ptr %l0, !tbaa !23
  store i32 %t13, ptr %l10, !tbaa !23
  %t14 = load i32, ptr %l10, !tbaa !23
  %t15 = icmp eq i32 %t14, 3
  store i1 %t15, ptr %l11, !tbaa !21
  %t16 = load i1, ptr %l11, !tbaa !21
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 4, ptr @.d9 }, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l13, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t18, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb12:
  %t19 = load i32, ptr %l0, !tbaa !23
  store i32 %t19, ptr %l14, !tbaa !23
  %t20 = load i32, ptr %l14, !tbaa !23
  %t21 = icmp eq i32 %t20, 4
  store i1 %t21, ptr %l15, !tbaa !21
  %t22 = load i1, ptr %l15, !tbaa !21
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 19, ptr @.d10 }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb16:
  %t25 = load i32, ptr %l0, !tbaa !23
  store i32 %t25, ptr %l18, !tbaa !23
  %t26 = load i32, ptr %l18, !tbaa !23
  %t27 = icmp eq i32 %t26, 5
  store i1 %t27, ptr %l19, !tbaa !21
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 21, ptr @.d11 }, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t30, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb20:
  %t31 = load i32, ptr %l0, !tbaa !23
  store i32 %t31, ptr %l22, !tbaa !23
  %t32 = load i32, ptr %l22, !tbaa !23
  %t33 = icmp eq i32 %t32, 6
  store i1 %t33, ptr %l23, !tbaa !21
  %t34 = load i1, ptr %l23, !tbaa !21
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store { i64, ptr } { i64 7, ptr @.d12 }, ptr %l24, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t35, ptr %l25, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t36, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb24:
  %t37 = load i32, ptr %l0, !tbaa !23
  store i32 %t37, ptr %l26, !tbaa !23
  %t38 = load i32, ptr %l26, !tbaa !23
  %t39 = icmp eq i32 %t38, 7
  store i1 %t39, ptr %l27, !tbaa !21
  %t40 = load i1, ptr %l27, !tbaa !21
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 9, ptr @.d13 }, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l29, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t42, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb28:
  %t43 = load i32, ptr %l0, !tbaa !23
  store i32 %t43, ptr %l30, !tbaa !23
  %t44 = load i32, ptr %l30, !tbaa !23
  %t45 = icmp eq i32 %t44, 8
  store i1 %t45, ptr %l31, !tbaa !21
  %t46 = load i1, ptr %l31, !tbaa !21
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 24, ptr @.d14 }, ptr %l32, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t47, ptr %l33, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t48, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  br label %bb57
bb32:
  %t49 = load i32, ptr %l0, !tbaa !23
  store i32 %t49, ptr %l34, !tbaa !23
  %t50 = load i32, ptr %l34, !tbaa !23
  %t51 = icmp eq i32 %t50, 9
  store i1 %t51, ptr %l35, !tbaa !21
  %t52 = load i1, ptr %l35, !tbaa !21
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  store { i64, ptr } { i64 6, ptr @.d15 }, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t54, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb36:
  %t55 = load i32, ptr %l0, !tbaa !23
  store i32 %t55, ptr %l38, !tbaa !23
  %t56 = load i32, ptr %l38, !tbaa !23
  %t57 = icmp eq i32 %t56, 11
  store i1 %t57, ptr %l39, !tbaa !21
  %t58 = load i1, ptr %l39, !tbaa !21
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  store { i64, ptr } { i64 18, ptr @.d16 }, ptr %l40, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t59, ptr %l41, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t60, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb40:
  %t61 = load i32, ptr %l0, !tbaa !23
  store i32 %t61, ptr %l42, !tbaa !23
  %t62 = load i32, ptr %l42, !tbaa !23
  %t63 = icmp eq i32 %t62, 13
  store i1 %t63, ptr %l43, !tbaa !21
  %t64 = load i1, ptr %l43, !tbaa !21
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  store { i64, ptr } { i64 11, ptr @.d17 }, ptr %l44, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t65, ptr %l45, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t66, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb44:
  %t67 = load i32, ptr %l0, !tbaa !23
  store i32 %t67, ptr %l46, !tbaa !23
  %t68 = load i32, ptr %l46, !tbaa !23
  %t69 = icmp eq i32 %t68, 14
  store i1 %t69, ptr %l47, !tbaa !21
  %t70 = load i1, ptr %l47, !tbaa !21
  br i1 %t70, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s12
  store { i64, ptr } { i64 11, ptr @.d18 }, ptr %l48, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t71, ptr %l49, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t72, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s12)
  br label %bb57
bb48:
  %t73 = load i32, ptr %l0, !tbaa !23
  store i32 %t73, ptr %l50, !tbaa !23
  %t74 = load i32, ptr %l50, !tbaa !23
  %t75 = icmp eq i32 %t74, 15
  store i1 %t75, ptr %l51, !tbaa !21
  %t76 = load i1, ptr %l51, !tbaa !21
  br i1 %t76, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s13
  store { i64, ptr } { i64 10, ptr @.d19 }, ptr %l52, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t77, ptr %l53, !tbaa !27
  %t78 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t78, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s14
  %t79 = load i32, ptr %l0, !tbaa !23
  store i32 %t79, ptr %l54, !tbaa !23
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t80 = extractvalue { i64, ptr } { i64 15, ptr @.d20 }, 1
  %t81 = extractvalue { i64, ptr } { i64 15, ptr @.d20 }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t80, i64 %t81)
  %t82 = load i32, ptr %l54, !tbaa !23
  %t83 = sext i32 %t82 to i64
  %t84 = call ptr @__olang_sb_room(ptr %s15, i64 24)
  %t85 = call i64 @__olang_fmt_i64(ptr %t84, i64 %t83)
  call void @__olang_sb_add(ptr %s15, i64 %t85)
  %t86 = load ptr, ptr %s15
  %t87 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t88 = load i64, ptr %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t86, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l55, !tbaa !27
  call void @__olang_sb_done(ptr %s15)
  %t92 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t92, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s14)
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca %"std/os:Output"
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"std/os:Output"
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i1
  %l81 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 false, ptr %l4, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t1, ptr %l15, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t2, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t3, ptr %l16, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l17, !tbaa !24
  %t6 = load i64, ptr %l17, !tbaa !24
  store i64 %t6, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l6, !tbaa !24
  store i64 %t7, ptr %l18, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l19, !tbaa !24
  %t9 = load i64, ptr %l18, !tbaa !24
  %t10 = load i64, ptr %l19, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l20, !tbaa !21
  %t12 = load i1, ptr %l20, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l21, !tbaa !21
  %t14 = load i1, ptr %l21, !tbaa !21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l22, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  store i64 %t16, ptr %l23, !tbaa !24
  %t17 = load i64, ptr %l23, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t17
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  store { i64, ptr } %t21, ptr %l24, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t22, ptr %l8, !tbaa !27
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t23)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t24, ptr %l25
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l25
  store %"std/prelude/list:List<std/prelude/text:String&>" %t25, ptr %l9
  store ptr %l9, ptr %l26, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t26, ptr %l27, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t27 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  call void @__olang_sb_put(ptr %s3, ptr %t28, i64 %t29)
  %t30 = load ptr, ptr %s3
  %t31 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t32 = load i64, ptr %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t30, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l28, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t36 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l29, !tbaa !27
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t43, { i64, ptr } %t44)
  br label %bb6
bb6:
  store ptr %l9, ptr %l30, !tbaa !29
  %t45 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t45, { i64, ptr } { i64 4, ptr @.d22 })
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t46, ptr %l31, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l31, !tbaa !27
  store { i64, ptr } %t47, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t48, ptr %l32, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l33, !tbaa !24
  %t51 = load i64, ptr %l33, !tbaa !24
  store i64 %t51, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s5
  %t52 = load i64, ptr %l11, !tbaa !24
  store i64 %t52, ptr %l34, !tbaa !24
  %t53 = load i64, ptr %l12, !tbaa !24
  store i64 %t53, ptr %l35, !tbaa !24
  %t54 = load i64, ptr %l34, !tbaa !24
  %t55 = load i64, ptr %l35, !tbaa !24
  %t56 = icmp slt i64 %t54, %t55
  store i1 %t56, ptr %l36, !tbaa !21
  %t57 = load i1, ptr %l36, !tbaa !21
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l37, !tbaa !21
  %t59 = load i1, ptr %l37, !tbaa !21
  br i1 %t59, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t60 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t60, ptr %l38, !tbaa !27
  %t61 = load i64, ptr %l11, !tbaa !24
  store i64 %t61, ptr %l39, !tbaa !24
  %t62 = load i64, ptr %l39, !tbaa !24
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = getelementptr { i64, ptr }, ptr %t64, i64 %t62
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !37
  store { i64, ptr } %t66, ptr %l40, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t67, ptr %l13, !tbaa !27
  store ptr %l9, ptr %l41, !tbaa !29
  %t68 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t68, ptr %l42, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t69 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  call void @__olang_sb_put(ptr %s6, ptr %t70, i64 %t71)
  %t72 = load ptr, ptr %s6
  %t73 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t74 = load i64, ptr %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t72, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l43, !tbaa !27
  call void @__olang_sb_done(ptr %s6)
  %t78 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l44, !tbaa !27
  %t85 = load ptr, ptr %l41, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l44, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t85, { i64, ptr } %t86)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = load i64, ptr %l11, !tbaa !24
  store i64 %t87, ptr %l45, !tbaa !24
  %t88 = load i64, ptr %l45, !tbaa !24
  %t89 = add i64 %t88, 1
  store i64 %t89, ptr %l46, !tbaa !24
  %t90 = load i64, ptr %l46, !tbaa !24
  store i64 %t90, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb8
bb14:
  call void @__olang_scope_close(ptr %s4)
  store ptr %l9, ptr %l47, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t91, ptr %l48, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t92 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  call void @__olang_sb_put(ptr %s8, ptr %t93, i64 %t94)
  %t95 = load ptr, ptr %s8
  %t96 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t97 = load i64, ptr %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t95, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l49, !tbaa !27
  call void @__olang_sb_done(ptr %s8)
  %t101 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l50, !tbaa !27
  %t108 = load ptr, ptr %l47, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l50, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t108, { i64, ptr } %t109)
  br label %bb15
bb15:
  store ptr %l9, ptr %l52, !tbaa !29
  %t110 = load ptr, ptr %l52, !tbaa !29
  %t111 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s2, ptr %s2, ptr %t110)
  store { i64, ptr } %t111, ptr %l53
  br label %bb16
bb16:
  store { i64, ptr } { i64 0, ptr @.d23 }, ptr %l54, !tbaa !27
  %t112 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t114 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t112, { i64, ptr } %t113, i1 false, { i64, ptr } { i64 0, ptr @.d24 })
  %t115 = extractvalue { i32, %"std/os:Output" } %t114, 1
  %t116 = extractvalue { i32, %"std/os:Output" } %t114, 0
  store i32 %t116, ptr %l56
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb18, label %ok.118
ok.118:
  store %"std/os:Output" %t115, ptr %l55
  br label %bb17
bb17:
  %t119 = load %"std/os:Output", ptr %l55
  store %"std/os:Output" %t119, ptr %l51
  br label %bb24
bb18:
  %t120 = load i32, ptr %l56, !tbaa !23
  %t121 = ashr i32 %t120, 16
  store i32 %t121, ptr %l57, !tbaa !23
  %t122 = load i32, ptr %l57, !tbaa !23
  %t123 = icmp eq i32 %t122, 1
  store i1 %t123, ptr %l58, !tbaa !21
  %t124 = load i1, ptr %l58, !tbaa !21
  br i1 %t124, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb21:
  store %olang.scope zeroinitializer, ptr %s9
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l59, !tbaa !29
  %t126 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t126, ptr %l60, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t127 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  call void @__olang_sb_put(ptr %s10, ptr %t128, i64 %t129)
  %t130 = extractvalue { i64, ptr } { i64 35, ptr @.d26 }, 1
  %t131 = extractvalue { i64, ptr } { i64 35, ptr @.d26 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t130, i64 %t131)
  %t132 = load ptr, ptr %s10
  %t133 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t134 = load i64, ptr %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t132, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l61, !tbaa !27
  call void @__olang_sb_done(ptr %s10)
  %t138 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l62, !tbaa !27
  %t145 = load ptr, ptr %l59, !tbaa !29
  %t146 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t147 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %t145, { i64, ptr } { i64 2, ptr @.d27 }, { i64, ptr } %t146)
  store { i64, ptr } %t147, ptr %l63
  br label %bb22
bb22:
  %t148 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t149 = extractvalue { i64, ptr } %t148, 0
  %t150 = extractvalue { i64, ptr } %t148, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l64, !tbaa !27
  %t155 = load { i64, ptr }, ptr %l64, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s9, { i64, ptr } %t155)
  br label %bb23
bb23:
  store i1 true, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb24:
  %t156 = load %"std/os:Output", ptr %l51
  store %"std/os:Output" %t156, ptr %l14
  %t157 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t158 = load i32, ptr %t157, !tbaa !23
  store i32 %t158, ptr %l65, !tbaa !23
  %t159 = load i32, ptr %l65, !tbaa !23
  %t160 = icmp sgt i32 %t159, 128
  store i1 %t160, ptr %l66, !tbaa !21
  %t161 = load i1, ptr %l66, !tbaa !21
  br i1 %t161, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s11
  %t162 = load ptr, ptr %l0, !tbaa !29
  store ptr %t162, ptr %l67, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t163, ptr %l68, !tbaa !27
  %t164 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t165 = load i32, ptr %t164, !tbaa !23
  store i32 %t165, ptr %l69, !tbaa !23
  %t166 = load i32, ptr %l69, !tbaa !23
  %t167 = sub i32 %t166, 128
  store i32 %t167, ptr %l70, !tbaa !23
  %t168 = load i32, ptr %l70, !tbaa !23
  %t169 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t168)
  store { i64, ptr } %t169, ptr %l71
  br label %bb27
bb26:
  br label %bb30
bb27:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t170 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  call void @__olang_sb_put(ptr %s12, ptr %t171, i64 %t172)
  %t173 = extractvalue { i64, ptr } { i64 22, ptr @.d28 }, 1
  %t174 = extractvalue { i64, ptr } { i64 22, ptr @.d28 }, 0
  call void @__olang_sb_put(ptr %s12, ptr %t173, i64 %t174)
  %t175 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  call void @__olang_sb_put(ptr %s12, ptr %t176, i64 %t177)
  %t178 = extractvalue { i64, ptr } { i64 11, ptr @.d29 }, 1
  %t179 = extractvalue { i64, ptr } { i64 11, ptr @.d29 }, 0
  call void @__olang_sb_put(ptr %s12, ptr %t178, i64 %t179)
  %t180 = load ptr, ptr %s12
  %t181 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t182 = load i64, ptr %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t180, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l72, !tbaa !27
  call void @__olang_sb_done(ptr %s12)
  %t186 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l73, !tbaa !27
  %t193 = load ptr, ptr %l67, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t195 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %t193, { i64, ptr } { i64 2, ptr @.d30 }, { i64, ptr } %t194)
  store { i64, ptr } %t195, ptr %l74
  br label %bb28
bb28:
  %t196 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t197 = extractvalue { i64, ptr } %t196, 0
  %t198 = extractvalue { i64, ptr } %t196, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l75, !tbaa !27
  %t203 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t203)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s11)
  br label %bb30
bb30:
  %t204 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t205 = load i32, ptr %t204, !tbaa !23
  store i32 %t205, ptr %l76, !tbaa !23
  %t206 = load i32, ptr %l76, !tbaa !23
  %t207 = icmp ne i32 %t206, 0
  store i1 %t207, ptr %l77, !tbaa !21
  %t208 = load i1, ptr %l77, !tbaa !21
  br i1 %t208, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s13
  store i1 true, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s14
  %t209 = load i64, ptr %l6, !tbaa !24
  store i64 %t209, ptr %l78, !tbaa !24
  %t210 = load i64, ptr %l78, !tbaa !24
  %t211 = add i64 %t210, 1
  store i64 %t211, ptr %l79, !tbaa !24
  %t212 = load i64, ptr %l79, !tbaa !24
  store i64 %t212, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb1
bb35:
  call void @__olang_scope_close(ptr %s1)
  %t213 = load i1, ptr %l4, !tbaa !21
  store i1 %t213, ptr %l80, !tbaa !21
  %t214 = load i1, ptr %l80, !tbaa !21
  br i1 %t214, label %bb36, label %bb37
bb36:
  store i32 1, ptr %l81, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l81, !tbaa !23
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t215 = load i32, ptr %l81, !tbaa !23
  store i32 %t215, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2eThinFrom_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 8388608, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 62, ptr @.d31 }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr @.d31 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l2, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t20)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = call %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v2, ptr %t2)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l4
  %t6 = load ptr, ptr %lp2
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  store i1 %t10, ptr %l6, !tbaa !21
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  store { i64, ptr } { i64 6, ptr @.d32 }, ptr %l10, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t14, { i64, ptr } %t15)
  store i1 %t16, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %lp2
  store ptr %t19, ptr %l12, !tbaa !29
  %t20 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t20, { i64, ptr } { i64 6, ptr @.d33 })
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %lp2
  store ptr %t21, ptr %l13, !tbaa !29
  %t22 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t22, { i64, ptr } { i64 16, ptr @.d34 })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t23 = load ptr, ptr %lp2
  %t24 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t23
  store %"std/prelude/list:List<std/prelude/text:String&>" %t24, ptr %l14
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l14
  store %"std/prelude/list:List<std/prelude/text:String&>" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/os:Output"
  %l27 = alloca %"std/os:FileInfo"
  %l28 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca ptr
  %l67 = alloca { i64, ptr }
  %l68 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca i32
  %l81 = alloca i32
  %l82 = alloca i1
  %l83 = alloca i32
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i1
  %l89 = alloca i1
  %l90 = alloca { i64, ptr }
  %l91 = alloca i64
  %l92 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca ptr
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca i1
  %l106 = alloca ptr
  %l107 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca ptr
  %l111 = alloca i64
  %l112 = alloca { i64, ptr }
  %l113 = alloca i32
  %l114 = alloca i32
  %l115 = alloca i1
  %l116 = alloca i32
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i1
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca ptr
  %l134 = alloca ptr
  %l135 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i1
  %l144 = alloca { i64, ptr }
  %l145 = alloca i32
  %l146 = alloca i32
  %l147 = alloca i1
  %l148 = alloca i32
  %l149 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l151 = alloca i1
  %l152 = alloca i32
  %l153 = alloca %"std/os:Output"
  %l154 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca %"std/os:Output"
  %l158 = alloca i32
  %l159 = alloca i32
  %l160 = alloca i1
  %l161 = alloca i32
  %l162 = alloca i32
  %l163 = alloca i32
  %l164 = alloca i1
  %l165 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca %"std/os:FileInfo"
  %l170 = alloca { i64, ptr }
  %l171 = alloca %"std/os:FileInfo"
  %l172 = alloca i32
  %l173 = alloca i32
  %l174 = alloca i1
  %l175 = alloca i32
  %l176 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca { i64, ptr }
  %l183 = alloca i32
  %l184 = alloca i32
  %l185 = alloca i1
  %l186 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.builder
  %s9room = alloca [64 x i8], align 8
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.builder
  %s20room = alloca [64 x i8], align 8
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s27 = alloca %olang.builder
  %s27room = alloca [64 x i8], align 8
  %s28 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l28
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l28
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l4
  store ptr %l4, ptr %l29, !tbaa !29
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l30, !tbaa !29
  %t5 = load ptr, ptr %l30, !tbaa !29
  %t6 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l31, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t8 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l32, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l33, !tbaa !27
  %t24 = load ptr, ptr %l29, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l33, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t24, { i64, ptr } %t25)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0, !tbaa !29
  store ptr %t26, ptr %l34, !tbaa !29
  %t27 = load ptr, ptr %l34, !tbaa !29
  %t28 = call %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s2, ptr %t27)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t28, ptr %l35
  br label %bb3
bb3:
  %t29 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l35
  %t30 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t29, ptr %t30
  store ptr %t30, ptr %l36, !tbaa !29
  %t31 = load ptr, ptr %l36, !tbaa !29
  store ptr %t31, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l5, !tbaa !29
  store ptr %t32, ptr %l38, !tbaa !29
  %t33 = load i64, ptr %l6, !tbaa !24
  store i64 %t33, ptr %l39, !tbaa !24
  %t34 = load ptr, ptr %l38, !tbaa !29
  %t35 = load i64, ptr %l39, !tbaa !24
  %t36 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s2, ptr %t34, i64 %t35)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l41
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb6, label %ok.40
ok.40:
  store { i64, ptr } %t37, ptr %l40
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t41, ptr %l37, !tbaa !27
  br label %bb10
bb6:
  %t42 = load i32, ptr %l41, !tbaa !23
  %t43 = ashr i32 %t42, 16
  store i32 %t43, ptr %l42, !tbaa !23
  %t44 = load i32, ptr %l42, !tbaa !23
  %t45 = icmp eq i32 %t44, 1
  store i1 %t45, ptr %l43, !tbaa !21
  %t46 = load i1, ptr %l43, !tbaa !21
  br i1 %t46, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  %t47 = load i32, ptr %l41, !tbaa !23
  %t48 = lshr i32 %t47, 16
  %t49 = and i32 %t47, 65535
  %t50 = icmp eq i32 %t48, 1
  %t51 = select i1 %t50, i32 0, i32 0
  %t52 = icmp eq i32 %t47, 0
  %t53 = shl i32 %t51, 16
  %t54 = or i32 %t53, %t49
  %t55 = select i1 %t52, i32 0, i32 %t54
  store i32 %t55, ptr %l44, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t56 = load i32, ptr %l44, !tbaa !23
  store i32 %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb10:
  %t57 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t57, ptr %l7, !tbaa !27
  %t58 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t58, ptr %l45, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l46, !tbaa !24
  %t61 = load i64, ptr %l46, !tbaa !24
  store i64 %t61, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t62 = load i64, ptr %l9, !tbaa !24
  store i64 %t62, ptr %l47, !tbaa !24
  %t63 = load i64, ptr %l8, !tbaa !24
  store i64 %t63, ptr %l48, !tbaa !24
  %t64 = load i64, ptr %l47, !tbaa !24
  %t65 = load i64, ptr %l48, !tbaa !24
  %t66 = icmp slt i64 %t64, %t65
  store i1 %t66, ptr %l49, !tbaa !21
  %t67 = load i1, ptr %l49, !tbaa !21
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l50, !tbaa !21
  %t69 = load i1, ptr %l50, !tbaa !21
  br i1 %t69, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t70, ptr %l51, !tbaa !27
  %t71 = load i64, ptr %l9, !tbaa !24
  store i64 %t71, ptr %l52, !tbaa !24
  %t72 = load i64, ptr %l52, !tbaa !24
  %t73 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = getelementptr { i64, ptr }, ptr %t74, i64 %t72
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !37
  store { i64, ptr } %t76, ptr %l53, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t77, ptr %l10, !tbaa !27
  store ptr %l4, ptr %l54, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t78, ptr %l55, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t79 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  call void @__olang_sb_put(ptr %s5, ptr %t80, i64 %t81)
  %t82 = load ptr, ptr %s5
  %t83 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t84 = load i64, ptr %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t82, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l56, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t88 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l57, !tbaa !27
  %t95 = load ptr, ptr %l54, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l57, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t95, { i64, ptr } %t96)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l9, !tbaa !24
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load i64, ptr %l58, !tbaa !24
  %t99 = add i64 %t98, 1
  store i64 %t99, ptr %l59, !tbaa !24
  %t100 = load i64, ptr %l59, !tbaa !24
  store i64 %t100, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb11
bb17:
  %t101 = load i64, ptr %l6, !tbaa !24
  store i64 %t101, ptr %l60, !tbaa !24
  %t102 = load i64, ptr %l8, !tbaa !24
  store i64 %t102, ptr %l61, !tbaa !24
  %t103 = load i64, ptr %l60, !tbaa !24
  %t104 = load i64, ptr %l61, !tbaa !24
  %t105 = add i64 %t103, %t104
  store i64 %t105, ptr %l62, !tbaa !24
  %t106 = load i64, ptr %l62, !tbaa !24
  store i64 %t106, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb4
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t107 = load ptr, ptr %l0, !tbaa !29
  store ptr %t107, ptr %l63, !tbaa !29
  %t108 = load ptr, ptr %l63, !tbaa !29
  %t109 = getelementptr %"compiler/build:Config", ptr %t108, i32 0, i32 16
  %t110 = load i1, ptr %t109, !tbaa !21
  store i1 %t110, ptr %l64, !tbaa !21
  %t111 = load i1, ptr %l64, !tbaa !21
  br i1 %t111, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l4, ptr %l65, !tbaa !29
  %t112 = load ptr, ptr %l0, !tbaa !29
  store ptr %t112, ptr %l66, !tbaa !29
  %t113 = load ptr, ptr %l66, !tbaa !29
  %t114 = getelementptr %"compiler/build:Config", ptr %t113, i32 0, i32 0
  %t115 = load { i64, ptr }, ptr %t114, !tbaa !27
  store { i64, ptr } %t115, ptr %l67, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t116 = extractvalue { i64, ptr } { i64 26, ptr @.d35 }, 1
  %t117 = extractvalue { i64, ptr } { i64 26, ptr @.d35 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t116, i64 %t117)
  %t118 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  call void @__olang_sb_put(ptr %s8, ptr %t119, i64 %t120)
  %t121 = extractvalue { i64, ptr } { i64 8, ptr @.d36 }, 1
  %t122 = extractvalue { i64, ptr } { i64 8, ptr @.d36 }, 0
  call void @__olang_sb_put(ptr %s8, ptr %t121, i64 %t122)
  %t123 = load ptr, ptr %s8
  %t124 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t125 = load i64, ptr %t124
  %t126 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t125)
  call void @llvm.memcpy.p0.p0.i64(ptr %t126, ptr %t123, i64 %t125, i1 false)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  store { i64, ptr } %t128, ptr %l68, !tbaa !27
  call void @__olang_sb_done(ptr %s8)
  %t129 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t130 = extractvalue { i64, ptr } %t129, 0
  %t131 = extractvalue { i64, ptr } %t129, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l69, !tbaa !27
  %t136 = load ptr, ptr %l65, !tbaa !29
  %t137 = load { i64, ptr }, ptr %l69, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t136, { i64, ptr } %t137)
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb23:
  store ptr %l4, ptr %l70, !tbaa !29
  %t138 = load ptr, ptr %l70, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t138, { i64, ptr } { i64 2, ptr @.d37 })
  br label %bb24
bb24:
  store ptr %l4, ptr %l71, !tbaa !29
  %t139 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t139, ptr %l72, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s9
  store ptr %s9room, ptr %s9
  %t140 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  call void @__olang_sb_put(ptr %s9, ptr %t141, i64 %t142)
  %t143 = load ptr, ptr %s9
  %t144 = getelementptr %olang.builder, ptr %s9, i32 0, i32 1
  %t145 = load i64, ptr %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t143, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  store { i64, ptr } %t148, ptr %l73, !tbaa !27
  call void @__olang_sb_done(ptr %s9)
  %t149 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t150 = extractvalue { i64, ptr } %t149, 0
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = mul i64 %t150, 1
  %t153 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t152)
  call void @llvm.memcpy.p0.p0.i64(ptr %t153, ptr %t151, i64 %t152, i1 false)
  %t154 = insertvalue { i64, ptr } undef, i64 %t150, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t153, 1
  store { i64, ptr } %t155, ptr %l74, !tbaa !27
  %t156 = load ptr, ptr %l71, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l74, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t156, { i64, ptr } %t157)
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s10
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l75, !tbaa !29
  %t159 = load ptr, ptr %l75, !tbaa !29
  store ptr %t159, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb26
bb26:
  store %olang.scope zeroinitializer, ptr %s11
  %t160 = load ptr, ptr %l11, !tbaa !29
  store ptr %t160, ptr %l77, !tbaa !29
  %t161 = load i64, ptr %l12, !tbaa !24
  store i64 %t161, ptr %l78, !tbaa !24
  %t162 = load ptr, ptr %l77, !tbaa !29
  %t163 = load i64, ptr %l78, !tbaa !24
  %t164 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t162, i64 %t163)
  %t165 = extractvalue { i32, { i64, ptr } } %t164, 1
  %t166 = extractvalue { i32, { i64, ptr } } %t164, 0
  store i32 %t166, ptr %l80
  %t167 = icmp ne i32 %t166, 0
  br i1 %t167, label %bb28, label %ok.168
ok.168:
  store { i64, ptr } %t165, ptr %l79
  br label %bb27
bb27:
  %t169 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t169, ptr %l76, !tbaa !27
  br label %bb32
bb28:
  %t170 = load i32, ptr %l80, !tbaa !23
  %t171 = ashr i32 %t170, 16
  store i32 %t171, ptr %l81, !tbaa !23
  %t172 = load i32, ptr %l81, !tbaa !23
  %t173 = icmp eq i32 %t172, 1
  store i1 %t173, ptr %l82, !tbaa !21
  %t174 = load i1, ptr %l82, !tbaa !21
  br i1 %t174, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  %t175 = load i32, ptr %l80, !tbaa !23
  %t176 = lshr i32 %t175, 16
  %t177 = and i32 %t175, 65535
  %t178 = icmp eq i32 %t176, 1
  %t179 = select i1 %t178, i32 0, i32 0
  %t180 = icmp eq i32 %t175, 0
  %t181 = shl i32 %t179, 16
  %t182 = or i32 %t181, %t177
  %t183 = select i1 %t180, i32 0, i32 %t182
  store i32 %t183, ptr %l83, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t184 = load i32, ptr %l83, !tbaa !23
  store i32 %t184, ptr %rv
  br label %ret
bb31:
  call void @__olang_scope_close(ptr %s11)
  br label %bb41
bb32:
  %t185 = load { i64, ptr }, ptr %l76, !tbaa !27
  store { i64, ptr } %t185, ptr %l13, !tbaa !27
  %t186 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t186, ptr %l84, !tbaa !27
  %t187 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  store i64 %t188, ptr %l85, !tbaa !24
  %t189 = load i64, ptr %l85, !tbaa !24
  store i64 %t189, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s12
  %t190 = load i64, ptr %l15, !tbaa !24
  store i64 %t190, ptr %l86, !tbaa !24
  %t191 = load i64, ptr %l14, !tbaa !24
  store i64 %t191, ptr %l87, !tbaa !24
  %t192 = load i64, ptr %l86, !tbaa !24
  %t193 = load i64, ptr %l87, !tbaa !24
  %t194 = icmp slt i64 %t192, %t193
  store i1 %t194, ptr %l88, !tbaa !21
  %t195 = load i1, ptr %l88, !tbaa !21
  %t196 = xor i1 %t195, true
  store i1 %t196, ptr %l89, !tbaa !21
  %t197 = load i1, ptr %l89, !tbaa !21
  br i1 %t197, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s12)
  br label %bb39
bb35:
  br label %bb36
bb36:
  %t198 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t198, ptr %l90, !tbaa !27
  %t199 = load i64, ptr %l15, !tbaa !24
  store i64 %t199, ptr %l91, !tbaa !24
  %t200 = load i64, ptr %l91, !tbaa !24
  %t201 = getelementptr { i64, ptr }, ptr %l90, i32 0, i32 1
  %t202 = load ptr, ptr %t201, !tbaa !27
  %t203 = getelementptr { i64, ptr }, ptr %t202, i64 %t200
  %t204 = load { i64, ptr }, ptr %t203, !tbaa !37
  store { i64, ptr } %t204, ptr %l92, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t205, ptr %l16, !tbaa !27
  store ptr %l4, ptr %l93, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t206, ptr %l94, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t207 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  call void @__olang_sb_put(ptr %s13, ptr %t208, i64 %t209)
  %t210 = load ptr, ptr %s13
  %t211 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t212 = load i64, ptr %t211
  %t213 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t210, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  store { i64, ptr } %t215, ptr %l95, !tbaa !27
  call void @__olang_sb_done(ptr %s13)
  %t216 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 0
  %t218 = extractvalue { i64, ptr } %t216, 1
  %t219 = mul i64 %t217, 1
  %t220 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t219)
  call void @llvm.memcpy.p0.p0.i64(ptr %t220, ptr %t218, i64 %t219, i1 false)
  %t221 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t220, 1
  store { i64, ptr } %t222, ptr %l96, !tbaa !27
  %t223 = load ptr, ptr %l93, !tbaa !29
  %t224 = load { i64, ptr }, ptr %l96, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t223, { i64, ptr } %t224)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s12)
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s14
  %t225 = load i64, ptr %l15, !tbaa !24
  store i64 %t225, ptr %l97, !tbaa !24
  %t226 = load i64, ptr %l97, !tbaa !24
  %t227 = add i64 %t226, 1
  store i64 %t227, ptr %l98, !tbaa !24
  %t228 = load i64, ptr %l98, !tbaa !24
  store i64 %t228, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s14)
  br label %bb33
bb39:
  %t229 = load i64, ptr %l12, !tbaa !24
  store i64 %t229, ptr %l99, !tbaa !24
  %t230 = load i64, ptr %l14, !tbaa !24
  store i64 %t230, ptr %l100, !tbaa !24
  %t231 = load i64, ptr %l99, !tbaa !24
  %t232 = load i64, ptr %l100, !tbaa !24
  %t233 = add i64 %t231, %t232
  store i64 %t233, ptr %l101, !tbaa !24
  %t234 = load i64, ptr %l101, !tbaa !24
  store i64 %t234, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb40
bb40:
  br label %bb26
bb41:
  call void @__olang_scope_close(ptr %s10)
  store ptr %l4, ptr %l102, !tbaa !29
  %t235 = load ptr, ptr %l102, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t235, { i64, ptr } { i64 3, ptr @.d38 })
  br label %bb42
bb42:
  store ptr %l4, ptr %l103, !tbaa !29
  %t236 = load ptr, ptr %l103, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t236, { i64, ptr } { i64 9, ptr @.d39 })
  br label %bb43
bb43:
  store ptr %l4, ptr %l104, !tbaa !29
  %t237 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t237, { i64, ptr } { i64 4, ptr @.d40 })
  br label %bb44
bb44:
  %t238 = load i1, ptr %l3, !tbaa !21
  store i1 %t238, ptr %l105, !tbaa !21
  %t239 = load i1, ptr %l105, !tbaa !21
  br i1 %t239, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s15
  store ptr %l4, ptr %l106, !tbaa !29
  %t240 = load ptr, ptr %l106, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t240, { i64, ptr } { i64 5, ptr @.d41 })
  br label %bb47
bb46:
  br label %bb48
bb47:
  call void @__olang_scope_close(ptr %s15)
  br label %bb48
bb48:
  %t241 = load ptr, ptr @__olang_prog_scope
  %t242 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t241)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t242, ptr %l107
  br label %bb49
bb49:
  %t243 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l107
  store %"std/prelude/list:List<std/prelude/text:String&>" %t243, ptr %l17
  store %olang.scope zeroinitializer, ptr %s16
  store ptr %l4, ptr %l108, !tbaa !29
  %t244 = load ptr, ptr %l108, !tbaa !29
  store ptr %t244, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s17
  %t245 = load ptr, ptr %l18, !tbaa !29
  store ptr %t245, ptr %l110, !tbaa !29
  %t246 = load i64, ptr %l19, !tbaa !24
  store i64 %t246, ptr %l111, !tbaa !24
  %t247 = load ptr, ptr %l110, !tbaa !29
  %t248 = load i64, ptr %l111, !tbaa !24
  %t249 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t247, i64 %t248)
  %t250 = extractvalue { i32, { i64, ptr } } %t249, 1
  %t251 = extractvalue { i32, { i64, ptr } } %t249, 0
  store i32 %t251, ptr %l113
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb52, label %ok.253
ok.253:
  store { i64, ptr } %t250, ptr %l112
  br label %bb51
bb51:
  %t254 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t254, ptr %l109, !tbaa !27
  br label %bb56
bb52:
  %t255 = load i32, ptr %l113, !tbaa !23
  %t256 = ashr i32 %t255, 16
  store i32 %t256, ptr %l114, !tbaa !23
  %t257 = load i32, ptr %l114, !tbaa !23
  %t258 = icmp eq i32 %t257, 1
  store i1 %t258, ptr %l115, !tbaa !21
  %t259 = load i1, ptr %l115, !tbaa !21
  br i1 %t259, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  %t260 = load i32, ptr %l113, !tbaa !23
  %t261 = lshr i32 %t260, 16
  %t262 = and i32 %t260, 65535
  %t263 = icmp eq i32 %t261, 1
  %t264 = select i1 %t263, i32 0, i32 0
  %t265 = icmp eq i32 %t260, 0
  %t266 = shl i32 %t264, 16
  %t267 = or i32 %t266, %t262
  %t268 = select i1 %t265, i32 0, i32 %t267
  store i32 %t268, ptr %l116, !tbaa !23
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t269 = load i32, ptr %l116, !tbaa !23
  store i32 %t269, ptr %rv
  br label %ret
bb55:
  call void @__olang_scope_close(ptr %s17)
  br label %bb65
bb56:
  %t270 = load { i64, ptr }, ptr %l109, !tbaa !27
  store { i64, ptr } %t270, ptr %l20, !tbaa !27
  %t271 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t271, ptr %l117, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  store i64 %t273, ptr %l118, !tbaa !24
  %t274 = load i64, ptr %l118, !tbaa !24
  store i64 %t274, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s18
  %t275 = load i64, ptr %l22, !tbaa !24
  store i64 %t275, ptr %l119, !tbaa !24
  %t276 = load i64, ptr %l21, !tbaa !24
  store i64 %t276, ptr %l120, !tbaa !24
  %t277 = load i64, ptr %l119, !tbaa !24
  %t278 = load i64, ptr %l120, !tbaa !24
  %t279 = icmp slt i64 %t277, %t278
  store i1 %t279, ptr %l121, !tbaa !21
  %t280 = load i1, ptr %l121, !tbaa !21
  %t281 = xor i1 %t280, true
  store i1 %t281, ptr %l122, !tbaa !21
  %t282 = load i1, ptr %l122, !tbaa !21
  br i1 %t282, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s18)
  br label %bb63
bb59:
  br label %bb60
bb60:
  %t283 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t283, ptr %l123, !tbaa !27
  %t284 = load i64, ptr %l22, !tbaa !24
  store i64 %t284, ptr %l124, !tbaa !24
  %t285 = load i64, ptr %l124, !tbaa !24
  %t286 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t287 = load ptr, ptr %t286, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %t287, i64 %t285
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !37
  store { i64, ptr } %t289, ptr %l125, !tbaa !27
  %t290 = load { i64, ptr }, ptr %l125, !tbaa !27
  store { i64, ptr } %t290, ptr %l23, !tbaa !27
  store ptr %l17, ptr %l126, !tbaa !29
  %t291 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t291, ptr %l127, !tbaa !27
  %t292 = load ptr, ptr %l126, !tbaa !29
  %t293 = load { i64, ptr }, ptr %l127, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t292, { i64, ptr } %t293)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s18)
  br label %bb62
bb62:
  store %olang.scope zeroinitializer, ptr %s19
  %t294 = load i64, ptr %l22, !tbaa !24
  store i64 %t294, ptr %l128, !tbaa !24
  %t295 = load i64, ptr %l128, !tbaa !24
  %t296 = add i64 %t295, 1
  store i64 %t296, ptr %l129, !tbaa !24
  %t297 = load i64, ptr %l129, !tbaa !24
  store i64 %t297, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb57
bb63:
  %t298 = load i64, ptr %l19, !tbaa !24
  store i64 %t298, ptr %l130, !tbaa !24
  %t299 = load i64, ptr %l21, !tbaa !24
  store i64 %t299, ptr %l131, !tbaa !24
  %t300 = load i64, ptr %l130, !tbaa !24
  %t301 = load i64, ptr %l131, !tbaa !24
  %t302 = add i64 %t300, %t301
  store i64 %t302, ptr %l132, !tbaa !24
  %t303 = load i64, ptr %l132, !tbaa !24
  store i64 %t303, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb64
bb64:
  br label %bb50
bb65:
  call void @__olang_scope_close(ptr %s16)
  store ptr %l17, ptr %l133, !tbaa !29
  %t304 = load ptr, ptr %l0, !tbaa !29
  store ptr %t304, ptr %l134, !tbaa !29
  %t305 = load ptr, ptr %l134, !tbaa !29
  %t306 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t305)
  store { i64, ptr } %t306, ptr %l135
  br label %bb66
bb66:
  %t307 = load ptr, ptr %l133, !tbaa !29
  %t308 = load { i64, ptr }, ptr %l135, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t307, { i64, ptr } %t308)
  br label %bb67
bb67:
  store ptr %l17, ptr %l136, !tbaa !29
  %t309 = load ptr, ptr %l136, !tbaa !29
  %t310 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %t309)
  store { i64, ptr } %t310, ptr %l137
  br label %bb68
bb68:
  %t311 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t311, ptr %l24, !tbaa !27
  %t312 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t312, ptr %l138, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s20
  store ptr %s20room, ptr %s20
  %t313 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t314 = extractvalue { i64, ptr } %t313, 1
  %t315 = extractvalue { i64, ptr } %t313, 0
  call void @__olang_sb_put(ptr %s20, ptr %t314, i64 %t315)
  %t316 = extractvalue { i64, ptr } { i64 5, ptr @.d42 }, 1
  %t317 = extractvalue { i64, ptr } { i64 5, ptr @.d42 }, 0
  call void @__olang_sb_put(ptr %s20, ptr %t316, i64 %t317)
  %t318 = load ptr, ptr %s20
  %t319 = getelementptr %olang.builder, ptr %s20, i32 0, i32 1
  %t320 = load i64, ptr %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t318, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  store { i64, ptr } %t323, ptr %l139, !tbaa !27
  call void @__olang_sb_done(ptr %s20)
  %t324 = load { i64, ptr }, ptr %l139, !tbaa !27
  store { i64, ptr } %t324, ptr %l25, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t325, ptr %l140, !tbaa !27
  %t326 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t326, ptr %l141, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t327, ptr %l142, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t331 = call i1 @compiler_2fbuild_2elinkCurrent(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t328, { i64, ptr } %t329, { i64, ptr } %t330)
  store i1 %t331, ptr %l143
  br label %bb69
bb69:
  %t332 = load i1, ptr %l143, !tbaa !21
  br i1 %t332, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s21
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  %t333 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t333, ptr %l144, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t335 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t334)
  store i32 %t335, ptr %l145
  %t336 = icmp ne i32 %t335, 0
  br i1 %t336, label %bb74, label %ok.337
ok.337:
  br label %bb73
bb73:
  br label %bb78
bb74:
  %t338 = load i32, ptr %l145, !tbaa !23
  %t339 = ashr i32 %t338, 16
  store i32 %t339, ptr %l146, !tbaa !23
  %t340 = load i32, ptr %l146, !tbaa !23
  %t341 = icmp eq i32 %t340, 1
  store i1 %t341, ptr %l147, !tbaa !21
  %t342 = load i1, ptr %l147, !tbaa !21
  br i1 %t342, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  %t343 = load i32, ptr %l145, !tbaa !23
  %t344 = lshr i32 %t343, 16
  %t345 = and i32 %t343, 65535
  %t346 = icmp eq i32 %t344, 1
  %t347 = select i1 %t346, i32 0, i32 0
  %t348 = icmp eq i32 %t343, 0
  %t349 = shl i32 %t347, 16
  %t350 = or i32 %t349, %t345
  %t351 = select i1 %t348, i32 0, i32 %t350
  store i32 %t351, ptr %l148, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t352 = load i32, ptr %l148, !tbaa !23
  store i32 %t352, ptr %rv
  br label %ret
bb77:
  store %olang.scope zeroinitializer, ptr %s22
  call void @__olang_scope_close(ptr %s22)
  br label %bb78
bb78:
  %t353 = load ptr, ptr %l0, !tbaa !29
  store ptr %t353, ptr %l149, !tbaa !29
  %t354 = load ptr, ptr %l149, !tbaa !29
  %t355 = getelementptr %"compiler/build:Config", ptr %t354, i32 0, i32 1
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !27
  store { i64, ptr } %t356, ptr %l150, !tbaa !27
  %t357 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t358 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t357, { i64, ptr } { i64 0, ptr @.d43 })
  store i1 %t358, ptr %l151
  br label %bb79
bb79:
  %t359 = load i1, ptr %l151, !tbaa !21
  br i1 %t359, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s23
  store i32 65537, ptr %l152, !tbaa !23
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t360 = load i32, ptr %l152, !tbaa !23
  store i32 %t360, ptr %rv
  br label %ret
bb81:
  br label %bb82
bb82:
  store ptr %l4, ptr %l154, !tbaa !29
  %t361 = load ptr, ptr %l154, !tbaa !29
  %t362 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s0, ptr %s0, ptr %t361)
  store { i64, ptr } %t362, ptr %l155
  br label %bb83
bb83:
  store { i64, ptr } { i64 0, ptr @.d44 }, ptr %l156, !tbaa !27
  %t363 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t365 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t363, { i64, ptr } %t364, i1 false, { i64, ptr } { i64 0, ptr @.d45 })
  %t366 = extractvalue { i32, %"std/os:Output" } %t365, 1
  %t367 = extractvalue { i32, %"std/os:Output" } %t365, 0
  store i32 %t367, ptr %l158
  %t368 = icmp ne i32 %t367, 0
  br i1 %t368, label %bb85, label %ok.369
ok.369:
  store %"std/os:Output" %t366, ptr %l157
  br label %bb84
bb84:
  %t370 = load %"std/os:Output", ptr %l157
  store %"std/os:Output" %t370, ptr %l153
  br label %bb89
bb85:
  %t371 = load i32, ptr %l158, !tbaa !23
  %t372 = ashr i32 %t371, 16
  store i32 %t372, ptr %l159, !tbaa !23
  %t373 = load i32, ptr %l159, !tbaa !23
  %t374 = icmp eq i32 %t373, 1
  store i1 %t374, ptr %l160, !tbaa !21
  %t375 = load i1, ptr %l160, !tbaa !21
  br i1 %t375, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  %t376 = load i32, ptr %l158, !tbaa !23
  %t377 = lshr i32 %t376, 16
  %t378 = and i32 %t376, 65535
  %t379 = icmp eq i32 %t377, 1
  %t380 = select i1 %t379, i32 0, i32 0
  %t381 = icmp eq i32 %t376, 0
  %t382 = shl i32 %t380, 16
  %t383 = or i32 %t382, %t378
  %t384 = select i1 %t381, i32 0, i32 %t383
  store i32 %t384, ptr %l161, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t385 = load i32, ptr %l161, !tbaa !23
  store i32 %t385, ptr %rv
  br label %ret
bb88:
  store %olang.scope zeroinitializer, ptr %s24
  store i32 65536, ptr %l162, !tbaa !23
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t386 = load i32, ptr %l162, !tbaa !23
  store i32 %t386, ptr %rv
  br label %ret
bb89:
  %t387 = load %"std/os:Output", ptr %l153
  store %"std/os:Output" %t387, ptr %l26
  %t388 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 0
  %t389 = load i32, ptr %t388, !tbaa !23
  store i32 %t389, ptr %l163, !tbaa !23
  %t390 = load i32, ptr %l163, !tbaa !23
  %t391 = icmp ne i32 %t390, 0
  store i1 %t391, ptr %l164, !tbaa !21
  %t392 = load i1, ptr %l164, !tbaa !21
  br i1 %t392, label %bb90, label %bb91
bb90:
  store %olang.scope zeroinitializer, ptr %s25
  store i32 65536, ptr %l165, !tbaa !23
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t393 = load i32, ptr %l165, !tbaa !23
  store i32 %t393, ptr %rv
  br label %ret
bb91:
  br label %bb92
bb92:
  %t394 = load ptr, ptr %l0, !tbaa !29
  store ptr %t394, ptr %l166, !tbaa !29
  %t395 = load ptr, ptr %l166, !tbaa !29
  %t396 = getelementptr %"compiler/build:Config", ptr %t395, i32 0, i32 15
  %t397 = load i64, ptr %t396, !tbaa !24
  store i64 %t397, ptr %l167, !tbaa !24
  %t398 = load i64, ptr %l167, !tbaa !24
  %t399 = add i64 %t398, 1
  store i64 %t399, ptr %l168, !tbaa !24
  %t400 = load i64, ptr %l168, !tbaa !24
  %t401 = load ptr, ptr %l166, !tbaa !29
  %t402 = getelementptr %"compiler/build:Config", ptr %t401, i32 0, i32 15
  store i64 %t400, ptr %t402, !tbaa !24
  %t403 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t403, ptr %l170, !tbaa !27
  %t404 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t405 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t404)
  %t406 = extractvalue { i32, %"std/os:FileInfo" } %t405, 1
  %t407 = extractvalue { i32, %"std/os:FileInfo" } %t405, 0
  store i32 %t407, ptr %l172
  %t408 = icmp ne i32 %t407, 0
  br i1 %t408, label %bb94, label %ok.409
ok.409:
  store %"std/os:FileInfo" %t406, ptr %l171
  br label %bb93
bb93:
  %t410 = load %"std/os:FileInfo", ptr %l171
  store %"std/os:FileInfo" %t410, ptr %l169
  br label %bb98
bb94:
  %t411 = load i32, ptr %l172, !tbaa !23
  %t412 = ashr i32 %t411, 16
  store i32 %t412, ptr %l173, !tbaa !23
  %t413 = load i32, ptr %l173, !tbaa !23
  %t414 = icmp eq i32 %t413, 1
  store i1 %t414, ptr %l174, !tbaa !21
  %t415 = load i1, ptr %l174, !tbaa !21
  br i1 %t415, label %bb95, label %bb96
bb95:
  br label %bb97
bb96:
  %t416 = load i32, ptr %l172, !tbaa !23
  %t417 = lshr i32 %t416, 16
  %t418 = and i32 %t416, 65535
  %t419 = icmp eq i32 %t417, 1
  %t420 = select i1 %t419, i32 0, i32 0
  %t421 = icmp eq i32 %t416, 0
  %t422 = shl i32 %t420, 16
  %t423 = or i32 %t422, %t418
  %t424 = select i1 %t421, i32 0, i32 %t423
  store i32 %t424, ptr %l175, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t425 = load i32, ptr %l175, !tbaa !23
  store i32 %t425, ptr %rv
  br label %ret
bb97:
  store %olang.scope zeroinitializer, ptr %s26
  call void @__olang_scope_close(ptr %s26)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb98:
  %t426 = load %"std/os:FileInfo", ptr %l169
  store %"std/os:FileInfo" %t426, ptr %l27
  %t427 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t427, ptr %l176, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t428, ptr %l177, !tbaa !27
  %t429 = getelementptr %"std/os:FileInfo", ptr %l27, i32 0, i32 1
  %t430 = load i64, ptr %t429, !tbaa !24
  store i64 %t430, ptr %l178, !tbaa !24
  %t431 = getelementptr %"std/os:FileInfo", ptr %l27, i32 0, i32 2
  %t432 = load i64, ptr %t431, !tbaa !24
  store i64 %t432, ptr %l179, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s27
  store ptr %s27room, ptr %s27
  %t433 = load { i64, ptr }, ptr %l177, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 1
  %t435 = extractvalue { i64, ptr } %t433, 0
  call void @__olang_sb_put(ptr %s27, ptr %t434, i64 %t435)
  %t436 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t437 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  call void @__olang_sb_put(ptr %s27, ptr %t436, i64 %t437)
  %t438 = load i64, ptr %l178, !tbaa !24
  %t439 = call ptr @__olang_sb_room(ptr %s27, i64 24)
  %t440 = call i64 @__olang_fmt_i64(ptr %t439, i64 %t438)
  call void @__olang_sb_add(ptr %s27, i64 %t440)
  %t441 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 1
  %t442 = extractvalue { i64, ptr } { i64 1, ptr @.d47 }, 0
  call void @__olang_sb_put(ptr %s27, ptr %t441, i64 %t442)
  %t443 = load i64, ptr %l179, !tbaa !24
  %t444 = call ptr @__olang_sb_room(ptr %s27, i64 24)
  %t445 = call i64 @__olang_fmt_i64(ptr %t444, i64 %t443)
  call void @__olang_sb_add(ptr %s27, i64 %t445)
  %t446 = extractvalue { i64, ptr } { i64 1, ptr @.d48 }, 1
  %t447 = extractvalue { i64, ptr } { i64 1, ptr @.d48 }, 0
  call void @__olang_sb_put(ptr %s27, ptr %t446, i64 %t447)
  %t448 = load ptr, ptr %s27
  %t449 = getelementptr %olang.builder, ptr %s27, i32 0, i32 1
  %t450 = load i64, ptr %t449
  %t451 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t450)
  call void @llvm.memcpy.p0.p0.i64(ptr %t451, ptr %t448, i64 %t450, i1 false)
  %t452 = insertvalue { i64, ptr } undef, i64 %t450, 0
  %t453 = insertvalue { i64, ptr } %t452, ptr %t451, 1
  store { i64, ptr } %t453, ptr %l180, !tbaa !27
  call void @__olang_sb_done(ptr %s27)
  %t454 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t454, ptr %l181, !tbaa !27
  %t455 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t455, 0
  %t457 = extractvalue { i64, ptr } %t455, 1
  %t458 = mul i64 %t456, 1
  %t459 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t458)
  call void @llvm.memcpy.p0.p0.i64(ptr %t459, ptr %t457, i64 %t458, i1 false)
  %t460 = insertvalue { i64, ptr } undef, i64 %t456, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t459, 1
  store { i64, ptr } %t461, ptr %l182, !tbaa !27
  %t462 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t463 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t464 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t462, { i64, ptr } %t463)
  store i32 %t464, ptr %l183
  %t465 = icmp ne i32 %t464, 0
  br i1 %t465, label %bb100, label %ok.466
ok.466:
  br label %bb99
bb99:
  br label %bb104
bb100:
  %t467 = load i32, ptr %l183, !tbaa !23
  %t468 = ashr i32 %t467, 16
  store i32 %t468, ptr %l184, !tbaa !23
  %t469 = load i32, ptr %l184, !tbaa !23
  %t470 = icmp eq i32 %t469, 1
  store i1 %t470, ptr %l185, !tbaa !21
  %t471 = load i1, ptr %l185, !tbaa !21
  br i1 %t471, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  %t472 = load i32, ptr %l183, !tbaa !23
  %t473 = lshr i32 %t472, 16
  %t474 = and i32 %t472, 65535
  %t475 = icmp eq i32 %t473, 1
  %t476 = select i1 %t475, i32 0, i32 0
  %t477 = icmp eq i32 %t472, 0
  %t478 = shl i32 %t476, 16
  %t479 = or i32 %t478, %t474
  %t480 = select i1 %t477, i32 0, i32 %t479
  store i32 %t480, ptr %l186, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t481 = load i32, ptr %l186, !tbaa !23
  store i32 %t481, ptr %rv
  br label %ret
bb103:
  store %olang.scope zeroinitializer, ptr %s28
  call void @__olang_scope_close(ptr %s28)
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l2
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List<std/prelude/text:String&>" %t4, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l3, !tbaa !29
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 2
  %t9 = getelementptr %"compiler/target:Target", ptr %t8, i32 0, i32 9
  %t10 = load i1, ptr %t9, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  %t11 = load i1, ptr %l4, !tbaa !21
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %lp1
  store ptr %t12, ptr %l5, !tbaa !29
  %t13 = load ptr, ptr %l0, !tbaa !29
  store ptr %t13, ptr %l6, !tbaa !29
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = getelementptr %"compiler/build:Config", ptr %t14, i32 0, i32 2
  %t16 = getelementptr %"compiler/target:Target", ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  store { i64, ptr } %t17, ptr %l7, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t18 = extractvalue { i64, ptr } { i64 9, ptr @.d49 }, 1
  %t19 = extractvalue { i64, ptr } { i64 9, ptr @.d49 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s2, ptr %t21, i64 %t22)
  %t23 = load ptr, ptr %s2
  %t24 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t25 = load i64, ptr %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t23, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l8, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t29 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l9, !tbaa !27
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t37 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l0, !tbaa !29
  store ptr %t38, ptr %l10, !tbaa !29
  %t39 = load ptr, ptr %l10, !tbaa !29
  %t40 = getelementptr %"compiler/build:Config", ptr %t39, i32 0, i32 2
  %t41 = getelementptr %"compiler/target:Target", ptr %t40, i32 0, i32 6
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l11, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr @.d50 })
  store i1 %t44, ptr %l12
  br label %bb6
bb6:
  %t45 = load i1, ptr %l12, !tbaa !21
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l13, !tbaa !21
  %t47 = load i1, ptr %l13, !tbaa !21
  br i1 %t47, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %lp1
  store ptr %t48, ptr %l14, !tbaa !29
  %t49 = load ptr, ptr %l0, !tbaa !29
  store ptr %t49, ptr %l15, !tbaa !29
  %t50 = load ptr, ptr %l15, !tbaa !29
  %t51 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 2
  %t52 = getelementptr %"compiler/target:Target", ptr %t51, i32 0, i32 6
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !27
  store { i64, ptr } %t53, ptr %l16, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t54 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  call void @__olang_sb_put(ptr %s4, ptr %t55, i64 %t56)
  %t57 = load ptr, ptr %s4
  %t58 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t59 = load i64, ptr %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t57, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l17, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  %t63 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l18, !tbaa !27
  %t70 = load ptr, ptr %l14, !tbaa !29
  %t71 = load { i64, ptr }, ptr %l18, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t70, { i64, ptr } %t71)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l19, !tbaa !29
  %t73 = load ptr, ptr %l19, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  store i1 %t75, ptr %l20, !tbaa !21
  %t76 = load i1, ptr %l20, !tbaa !21
  br i1 %t76, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t77 = load ptr, ptr %lp1
  store ptr %t77, ptr %l21, !tbaa !29
  %t78 = load ptr, ptr %l21, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t78, { i64, ptr } { i64 3, ptr @.d51 })
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t79 = load ptr, ptr %lp1
  store ptr %t79, ptr %l22, !tbaa !29
  %t80 = load ptr, ptr %l22, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t80, { i64, ptr } { i64 2, ptr @.d52 })
  br label %bb14
bb14:
  %t81 = load ptr, ptr %l0, !tbaa !29
  store ptr %t81, ptr %l23, !tbaa !29
  %t82 = load ptr, ptr %l23, !tbaa !29
  %t83 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 5
  %t84 = load i1, ptr %t83, !tbaa !21
  store i1 %t84, ptr %l24, !tbaa !21
  %t85 = load i1, ptr %l24, !tbaa !21
  br i1 %t85, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %lp1
  store ptr %t86, ptr %l25, !tbaa !29
  %t87 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t87, { i64, ptr } { i64 17, ptr @.d53 })
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  %t88 = load ptr, ptr %lp1
  %t89 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t88
  store %"std/prelude/list:List<std/prelude/text:String&>" %t89, ptr %l26
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l26
  store %"std/prelude/list:List<std/prelude/text:String&>" %t90, ptr %rv
  br label %ret
bb19:
  %t91 = load ptr, ptr %l0, !tbaa !29
  store ptr %t91, ptr %l27, !tbaa !29
  %t92 = load ptr, ptr %l27, !tbaa !29
  %t93 = getelementptr %"compiler/build:Config", ptr %t92, i32 0, i32 5
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l28, !tbaa !21
  %t95 = load i1, ptr %l28, !tbaa !21
  br i1 %t95, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  %t96 = load ptr, ptr %lp1
  store ptr %t96, ptr %l29, !tbaa !29
  %t97 = load ptr, ptr %l29, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t97, { i64, ptr } { i64 3, ptr @.d54 })
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t98 = load ptr, ptr %lp1
  store ptr %t98, ptr %l30, !tbaa !29
  %t99 = load ptr, ptr %l30, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t99, { i64, ptr } { i64 17, ptr @.d55 })
  br label %bb23
bb23:
  %t100 = load ptr, ptr %lp1
  %t101 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t100
  store %"std/prelude/list:List<std/prelude/text:String&>" %t101, ptr %l31
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l31
  store %"std/prelude/list:List<std/prelude/text:String&>" %t102, ptr %rv
  br label %ret
bb24:
  %t103 = load ptr, ptr %lp1
  store ptr %t103, ptr %l32, !tbaa !29
  %t104 = load ptr, ptr %l32, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t104, { i64, ptr } { i64 3, ptr @.d56 })
  br label %bb25
bb25:
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l33, !tbaa !29
  %t106 = load ptr, ptr %l33, !tbaa !29
  %t107 = getelementptr %"compiler/build:Config", ptr %t106, i32 0, i32 16
  %t108 = load i1, ptr %t107, !tbaa !21
  store i1 %t108, ptr %l34, !tbaa !21
  %t109 = load i1, ptr %l34, !tbaa !21
  br i1 %t109, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s8
  %t110 = load ptr, ptr %lp1
  store ptr %t110, ptr %l35, !tbaa !29
  %t111 = load ptr, ptr %l35, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t111, { i64, ptr } { i64 10, ptr @.d57 })
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s9
  %t112 = load ptr, ptr %lp1
  store ptr %t112, ptr %l36, !tbaa !29
  %t113 = load ptr, ptr %l36, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t113, { i64, ptr } { i64 5, ptr @.d58 })
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s8)
  br label %bb30
bb29:
  call void @__olang_scope_close(ptr %s9)
  br label %bb30
bb30:
  %t114 = load ptr, ptr %lp1
  %t115 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t114
  store %"std/prelude/list:List<std/prelude/text:String&>" %t115, ptr %l37
  call void @__olang_scope_close(ptr %s0)
  %t116 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l37
  store %"std/prelude/list:List<std/prelude/text:String&>" %t116, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l13
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l13
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l5
  store ptr %l5, ptr %l14, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t4, ptr %l15, !tbaa !27
  %t5 = load ptr, ptr %l14, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v2, ptr %t5, { i64, ptr } %t6)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l4, !tbaa !29
  store ptr %t7, ptr %l16, !tbaa !29
  %t8 = load ptr, ptr %l16, !tbaa !29
  store ptr %t8, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load ptr, ptr %l6, !tbaa !29
  store ptr %t9, ptr %l18, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  store i64 %t10, ptr %l19, !tbaa !24
  %t11 = load ptr, ptr %l18, !tbaa !29
  %t12 = load i64, ptr %l19, !tbaa !24
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t11, i64 %t12)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l21
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l20
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  br label %bb9
bb5:
  %t19 = load i32, ptr %l21, !tbaa !23
  %t20 = ashr i32 %t19, 16
  store i32 %t20, ptr %l22, !tbaa !23
  %t21 = load i32, ptr %l22, !tbaa !23
  %t22 = icmp eq i32 %t21, 1
  store i1 %t22, ptr %l23, !tbaa !21
  %t23 = load i1, ptr %l23, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c59)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb9:
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t25, ptr %l24, !tbaa !27
  %t26 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l25, !tbaa !24
  %t28 = load i64, ptr %l25, !tbaa !24
  store i64 %t28, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l10, !tbaa !24
  store i64 %t29, ptr %l26, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  store i64 %t30, ptr %l27, !tbaa !24
  %t31 = load i64, ptr %l26, !tbaa !24
  %t32 = load i64, ptr %l27, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l28, !tbaa !21
  %t34 = load i1, ptr %l28, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l29, !tbaa !21
  %t36 = load i1, ptr %l29, !tbaa !21
  br i1 %t36, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t37 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t37, ptr %l30, !tbaa !27
  %t38 = load i64, ptr %l10, !tbaa !24
  store i64 %t38, ptr %l31, !tbaa !24
  %t39 = load i64, ptr %l31, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t39
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  store { i64, ptr } %t43, ptr %l32, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t44, ptr %l11, !tbaa !27
  store ptr %l5, ptr %l33, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t45, ptr %l34, !tbaa !27
  %t46 = load ptr, ptr %l33, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l34, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v3, ptr %t46, { i64, ptr } %t47)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l10, !tbaa !24
  store i64 %t48, ptr %l35, !tbaa !24
  %t49 = load i64, ptr %l35, !tbaa !24
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l36, !tbaa !24
  %t51 = load i64, ptr %l36, !tbaa !24
  store i64 %t51, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb10
bb16:
  %t52 = load i64, ptr %l7, !tbaa !24
  store i64 %t52, ptr %l37, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  store i64 %t53, ptr %l38, !tbaa !24
  %t54 = load i64, ptr %l37, !tbaa !24
  %t55 = load i64, ptr %l38, !tbaa !24
  %t56 = add i64 %t54, %t55
  store i64 %t56, ptr %l39, !tbaa !24
  %t57 = load i64, ptr %l39, !tbaa !24
  store i64 %t57, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb3
bb18:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l5, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l41, !tbaa !29
  %t59 = load ptr, ptr %l41, !tbaa !29
  %t60 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t59)
  store { i64, ptr } %t60, ptr %l42
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t61, { i64, ptr } %t62)
  br label %bb20
bb20:
  store ptr %l5, ptr %l43, !tbaa !29
  %t63 = load ptr, ptr %l43, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %t63)
  store { i64, ptr } %t64, ptr %l44
  br label %bb21
bb21:
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  store ptr %t66, ptr %l45, !tbaa !29
  %t67 = load ptr, ptr %l45, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t67, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t70, ptr %l47, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l48, !tbaa !24
  %t73 = icmp sge i64 0, 0
  store i1 %t73, ptr %l49, !tbaa !21
  %t74 = load i1, ptr %l49, !tbaa !21
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = icmp sle i64 0, 16
  store i1 %t75, ptr %l50, !tbaa !21
  %t76 = load i1, ptr %l50, !tbaa !21
  br i1 %t76, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c60)
  unreachable
bb24:
  %t77 = load i64, ptr %l48, !tbaa !24
  %t78 = icmp sle i64 16, %t77
  store i1 %t78, ptr %l51, !tbaa !21
  %t79 = load i1, ptr %l51, !tbaa !21
  br i1 %t79, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c60)
  unreachable
bb26:
  %t80 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 0
  %t83 = sub i64 16, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l52, !tbaa !27
  %t86 = load i32, ptr %l2
  store i32 %t86, ptr %l53
  %t87 = load i32, ptr %l53
  %t88 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %t87)
  store { i64, ptr } %t88, ptr %l54
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c60)
  unreachable
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load ptr, ptr %l55, !tbaa !29
  %t91 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t90)
  store { i64, ptr } %t91, ptr %l56
  br label %bb29
bb29:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t92 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  call void @__olang_sb_put(ptr %s5, ptr %t93, i64 %t94)
  %t95 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 1
  %t96 = extractvalue { i64, ptr } { i64 1, ptr @.d61 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t95, i64 %t96)
  %t97 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  call void @__olang_sb_put(ptr %s5, ptr %t98, i64 %t99)
  %t100 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t100, i64 %t101)
  %t102 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  call void @__olang_sb_put(ptr %s5, ptr %t103, i64 %t104)
  %t105 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  call void @__olang_sb_put(ptr %s5, ptr %t106, i64 %t107)
  %t108 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  call void @__olang_sb_put(ptr %s5, ptr %t109, i64 %t110)
  %t111 = extractvalue { i64, ptr } { i64 2, ptr @.d63 }, 1
  %t112 = extractvalue { i64, ptr } { i64 2, ptr @.d63 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t111, i64 %t112)
  %t113 = load ptr, ptr %s5
  %t114 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t115 = load i64, ptr %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t113, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l57, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t119, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/list:List<std/prelude/text:String&>" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/build:Unit"
  %l10 = alloca %"compiler/build:compiles"
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/build:Unit"
  %l18 = alloca { { i64, ptr }, { i64, ptr } }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i1
  %l37 = alloca i32
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca %"compiler/build:Unit"
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca i1
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca %"compiler/build:compiles"
  %l69 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca { i64, ptr }
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l77 = alloca i32
  %l78 = alloca i1
  %l79 = alloca i32
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i1
  %l85 = alloca i1
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca %"compiler/build:Unit"
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l101 = alloca i32
  %l102 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l110 = alloca i1
  %l111 = alloca i1
  %l112 = alloca ptr
  %l113 = alloca { i64, ptr }
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca i32
  %l117 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l121 = alloca i32
  %l122 = alloca i32
  %l123 = alloca { i64, ptr }
  %l124 = alloca ptr
  %l125 = alloca { i64, ptr }
  %l126 = alloca i1
  %l127 = alloca i1
  %l128 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l130 = alloca ptr
  %l131 = alloca ptr
  %l132 = alloca i32
  %l133 = alloca ptr
  %l134 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l136 = alloca { i64, ptr }
  %l137 = alloca i32
  %l138 = alloca i32
  %l139 = alloca { i64, ptr }
  %l140 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l143 = alloca i64
  %l144 = alloca { { i64, ptr }, { i64, ptr } }
  %l145 = alloca { i64, ptr }
  %l146 = alloca i64
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l150 = alloca { i64, ptr }
  %l151 = alloca ptr
  %l152 = alloca i64
  %l153 = alloca ptr
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %l157 = alloca i64
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i1
  %l161 = alloca i64
  %l162 = alloca i64
  %l163 = alloca i1
  %l164 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca i64
  %l170 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i1
  %l176 = alloca i1
  %l177 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i32
  %l184 = alloca i1
  %l185 = alloca i64
  %l186 = alloca { i64, ptr }
  %l187 = alloca i1
  %l188 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca { i64, [3 x i64] }
  %l191 = alloca ptr
  %l192 = alloca i64
  %l193 = alloca { i64, ptr }
  %l194 = alloca %"compiler/msgs:Msg"
  %l195 = alloca ptr
  %l196 = alloca i64
  %l197 = alloca { i64, ptr }
  %l198 = alloca i32
  %l199 = alloca i32
  %l200 = alloca i1
  %l201 = alloca i32
  %l202 = alloca i64
  %l203 = alloca { i64, ptr }
  %l204 = alloca i1
  %l205 = alloca i1
  %l206 = alloca i64
  %l207 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l209 = alloca i64
  %l210 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l212 = alloca i64
  %l213 = alloca { i64, ptr }
  %l214 = alloca i32
  %l215 = alloca i32
  %l216 = alloca i1
  %l217 = alloca i32
  %l218 = alloca i1
  %l219 = alloca i1
  %l220 = alloca ptr
  %l221 = alloca i64
  %l222 = alloca { i64, ptr }
  %l223 = alloca %"compiler/msgs:Msg"
  %l224 = alloca ptr
  %l225 = alloca i64
  %l226 = alloca i64
  %l227 = alloca i1
  %l228 = alloca i32
  %l229 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/list:List<std/prelude/text:String&>" }
  %t434 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l28, !tbaa !29
  %t2 = load ptr, ptr %l28, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l29, !tbaa !29
  %t4 = load ptr, ptr %l29, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l4, !tbaa !29
  store ptr %t5, ptr %l31, !tbaa !29
  %t6 = load i64, ptr %l5, !tbaa !24
  store i64 %t6, ptr %l32, !tbaa !24
  %t7 = load ptr, ptr %l31, !tbaa !29
  %t8 = load i64, ptr %l32, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l34
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l33
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t14, ptr %l30, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l34, !tbaa !23
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l35, !tbaa !23
  %t17 = load i32, ptr %l35, !tbaa !23
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l36, !tbaa !21
  %t19 = load i1, ptr %l36, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load i32, ptr %l34, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 0, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  store i32 %t28, ptr %l37, !tbaa !23
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l37, !tbaa !23
  %t30 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t29, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t30, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb7:
  %t31 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t32, ptr %l38, !tbaa !27
  %t33 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 0
  store i64 %t34, ptr %l39, !tbaa !24
  %t35 = load i64, ptr %l39, !tbaa !24
  store i64 %t35, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l8, !tbaa !24
  store i64 %t36, ptr %l40, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  store i64 %t37, ptr %l41, !tbaa !24
  %t38 = load i64, ptr %l40, !tbaa !24
  %t39 = load i64, ptr %l41, !tbaa !24
  %t40 = icmp slt i64 %t38, %t39
  store i1 %t40, ptr %l42, !tbaa !21
  %t41 = load i1, ptr %l42, !tbaa !21
  %t42 = xor i1 %t41, true
  store i1 %t42, ptr %l43, !tbaa !21
  %t43 = load i1, ptr %l43, !tbaa !21
  br i1 %t43, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l44, !tbaa !27
  %t45 = load i64, ptr %l8, !tbaa !24
  store i64 %t45, ptr %l45, !tbaa !24
  %t46 = load i64, ptr %l45, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/build:Unit", ptr %t48, i64 %t46
  %t50 = load %"compiler/build:Unit", ptr %t49
  store %"compiler/build:Unit" %t50, ptr %l46
  %t51 = load %"compiler/build:Unit", ptr %l46
  store %"compiler/build:Unit" %t51, ptr %l9
  %t52 = load i64, ptr %l3, !tbaa !24
  store i64 %t52, ptr %l47, !tbaa !24
  %t53 = getelementptr %"compiler/build:Unit", ptr %l9, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l48, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l49, !tbaa !24
  %t57 = load i64, ptr %l47, !tbaa !24
  %t58 = load i64, ptr %l49, !tbaa !24
  %t59 = add i64 %t57, %t58
  store i64 %t59, ptr %l50, !tbaa !24
  %t60 = load i64, ptr %l50, !tbaa !24
  store i64 %t60, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = load i64, ptr %l8, !tbaa !24
  store i64 %t61, ptr %l51, !tbaa !24
  %t62 = load i64, ptr %l51, !tbaa !24
  %t63 = add i64 %t62, 1
  store i64 %t63, ptr %l52, !tbaa !24
  %t64 = load i64, ptr %l52, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb13:
  %t65 = load i64, ptr %l5, !tbaa !24
  store i64 %t65, ptr %l53, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  store i64 %t66, ptr %l54, !tbaa !24
  %t67 = load i64, ptr %l53, !tbaa !24
  %t68 = load i64, ptr %l54, !tbaa !24
  %t69 = add i64 %t67, %t68
  store i64 %t69, ptr %l55, !tbaa !24
  %t70 = load i64, ptr %l55, !tbaa !24
  store i64 %t70, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb1
bb15:
  call void @__olang_scope_close(ptr %s1)
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l56, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  store ptr %t72, ptr %l57, !tbaa !29
  %t73 = load ptr, ptr %l57, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  store i1 %t75, ptr %l58, !tbaa !21
  %t76 = load i1, ptr %l58, !tbaa !21
  %t77 = xor i1 %t76, true
  store i1 %t77, ptr %l59, !tbaa !21
  %t78 = load i1, ptr %l59, !tbaa !21
  br i1 %t78, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  store ptr %t79, ptr %l61, !tbaa !29
  %t80 = load ptr, ptr %l61, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t80, i32 0, i32 5
  %t82 = load i1, ptr %t81, !tbaa !21
  store i1 %t82, ptr %l62, !tbaa !21
  %t83 = load i1, ptr %l62, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l63, !tbaa !21
  %t85 = load i1, ptr %l63, !tbaa !21
  store i1 %t85, ptr %l60, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l60, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t87 = load i64, ptr %l3, !tbaa !24
  store i64 %t87, ptr %l65, !tbaa !24
  %t88 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  store i64 %t88, ptr %l66, !tbaa !24
  %t89 = load i64, ptr %l65, !tbaa !24
  %t90 = load i64, ptr %l66, !tbaa !24
  %t91 = icmp sge i64 %t89, %t90
  store i1 %t91, ptr %l67, !tbaa !21
  %t92 = load i1, ptr %l67, !tbaa !21
  store i1 %t92, ptr %l64, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l64, !tbaa !21
  %t94 = load ptr, ptr %l56, !tbaa !29
  %t95 = getelementptr %"compiler/build:Config", ptr %t94, i32 0, i32 16
  store i1 %t93, ptr %t95, !tbaa !21
  %t96 = call %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %s0)
  store %"compiler/build:compiles" %t96, ptr %l68
  br label %bb22
bb22:
  %t97 = load %"compiler/build:compiles", ptr %l68
  store %"compiler/build:compiles" %t97, ptr %l10
  %t98 = load ptr, ptr @__olang_prog_scope
  %t99 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t98)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t99, ptr %l69
  br label %bb23
bb23:
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t100, ptr %lp11
  %t101 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l69
  %t102 = load ptr, ptr %lp11
  store %"std/prelude/list:List<std/prelude/text:String&>" %t101, ptr %t102
  store %olang.scope zeroinitializer, ptr %s5
  %t103 = load ptr, ptr %l1, !tbaa !29
  store ptr %t103, ptr %l70, !tbaa !29
  %t104 = load ptr, ptr %l70, !tbaa !29
  %t105 = getelementptr %"compiler/build:Program", ptr %t104, i32 0, i32 0
  store ptr %t105, ptr %l71, !tbaa !29
  %t106 = load ptr, ptr %l71, !tbaa !29
  store ptr %t106, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l12, !tbaa !29
  store ptr %t107, ptr %l73, !tbaa !29
  %t108 = load i64, ptr %l13, !tbaa !24
  store i64 %t108, ptr %l74, !tbaa !24
  %t109 = load ptr, ptr %l73, !tbaa !29
  %t110 = load i64, ptr %l74, !tbaa !24
  %t111 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t109, i64 %t110)
  %t112 = extractvalue { i32, { i64, ptr } } %t111, 1
  %t113 = extractvalue { i32, { i64, ptr } } %t111, 0
  store i32 %t113, ptr %l76
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb26, label %ok.115
ok.115:
  store { i64, ptr } %t112, ptr %l75
  br label %bb25
bb25:
  %t116 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t116, ptr %l72, !tbaa !27
  br label %bb30
bb26:
  %t117 = load i32, ptr %l76, !tbaa !23
  %t118 = ashr i32 %t117, 16
  store i32 %t118, ptr %l77, !tbaa !23
  %t119 = load i32, ptr %l77, !tbaa !23
  %t120 = icmp eq i32 %t119, 1
  store i1 %t120, ptr %l78, !tbaa !21
  %t121 = load i1, ptr %l78, !tbaa !21
  br i1 %t121, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  %t122 = load i32, ptr %l76, !tbaa !23
  %t123 = lshr i32 %t122, 16
  %t124 = and i32 %t122, 65535
  %t125 = icmp eq i32 %t123, 1
  %t126 = select i1 %t125, i32 0, i32 0
  %t127 = icmp eq i32 %t122, 0
  %t128 = shl i32 %t126, 16
  %t129 = or i32 %t128, %t124
  %t130 = select i1 %t127, i32 0, i32 %t129
  store i32 %t130, ptr %l79, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t131 = load i32, ptr %l79, !tbaa !23
  %t132 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t131, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t132, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb30:
  %t133 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t133, ptr %l14, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t134, ptr %l80, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 0
  store i64 %t136, ptr %l81, !tbaa !24
  %t137 = load i64, ptr %l81, !tbaa !24
  store i64 %t137, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t138 = load i64, ptr %l16, !tbaa !24
  store i64 %t138, ptr %l82, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  store i64 %t139, ptr %l83, !tbaa !24
  %t140 = load i64, ptr %l82, !tbaa !24
  %t141 = load i64, ptr %l83, !tbaa !24
  %t142 = icmp slt i64 %t140, %t141
  store i1 %t142, ptr %l84, !tbaa !21
  %t143 = load i1, ptr %l84, !tbaa !21
  %t144 = xor i1 %t143, true
  store i1 %t144, ptr %l85, !tbaa !21
  %t145 = load i1, ptr %l85, !tbaa !21
  br i1 %t145, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t146 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t146, ptr %l86, !tbaa !27
  %t147 = load i64, ptr %l16, !tbaa !24
  store i64 %t147, ptr %l87, !tbaa !24
  %t148 = load i64, ptr %l87, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/build:Unit", ptr %t150, i64 %t148
  %t152 = load %"compiler/build:Unit", ptr %t151
  store %"compiler/build:Unit" %t152, ptr %l88
  %t153 = load %"compiler/build:Unit", ptr %l88
  store %"compiler/build:Unit" %t153, ptr %l17
  %t154 = load ptr, ptr %lp11
  store ptr %t154, ptr %l89, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l91, !tbaa !29
  store ptr %l10, ptr %l92, !tbaa !29
  %t156 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l93, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t159 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %v3, { i64, ptr } %t158)
  store { i64, ptr } %t159, ptr %l94
  br label %bb35
bb35:
  %t160 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  store { i64, ptr } %t166, ptr %l95, !tbaa !27
  %t167 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 1
  %t168 = load i32, ptr %t167
  store i32 %t168, ptr %l96
  %t169 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  store { i64, ptr } %t170, ptr %l97, !tbaa !27
  %t171 = load ptr, ptr %l2, !tbaa !29
  store ptr %t171, ptr %l98, !tbaa !29
  %t172 = load ptr, ptr %l91, !tbaa !29
  %t173 = load ptr, ptr %l92, !tbaa !29
  %t174 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t175 = load i32, ptr %l96
  %t176 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t177 = load ptr, ptr %l98, !tbaa !29
  %t178 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t172, ptr %t173, { i64, ptr } %t174, i32 %t175, { i64, ptr } %t176, ptr %t177)
  %t179 = extractvalue { i32, { i64, ptr } } %t178, 1
  %t180 = extractvalue { i32, { i64, ptr } } %t178, 0
  store i32 %t180, ptr %l100
  %t181 = icmp ne i32 %t180, 0
  br i1 %t181, label %bb37, label %ok.182
ok.182:
  store { i64, ptr } %t179, ptr %l99
  br label %bb36
bb36:
  %t183 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t183, ptr %l90, !tbaa !27
  br label %bb38
bb37:
  %t184 = load i32, ptr %l100, !tbaa !23
  %t185 = lshr i32 %t184, 16
  %t186 = and i32 %t184, 65535
  %t187 = icmp eq i32 %t185, 1
  %t188 = select i1 %t187, i32 1, i32 0
  %t189 = icmp eq i32 %t184, 0
  %t190 = shl i32 %t188, 16
  %t191 = or i32 %t190, %t186
  %t192 = select i1 %t189, i32 0, i32 %t191
  store i32 %t192, ptr %l101, !tbaa !23
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t193 = load i32, ptr %l101, !tbaa !23
  %t194 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t193, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t194, ptr %rv
  br label %ret
bb38:
  %t195 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t195, 0
  %t197 = extractvalue { i64, ptr } %t195, 1
  %t198 = mul i64 %t196, 1
  %t199 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t198)
  call void @llvm.memcpy.p0.p0.i64(ptr %t199, ptr %t197, i64 %t198, i1 false)
  %t200 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t201 = insertvalue { i64, ptr } %t200, ptr %t199, 1
  store { i64, ptr } %t201, ptr %l102, !tbaa !27
  %t202 = load ptr, ptr %l89, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l102, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t202, { i64, ptr } %t203)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  store %olang.scope zeroinitializer, ptr %s8
  %t204 = load i64, ptr %l16, !tbaa !24
  store i64 %t204, ptr %l103, !tbaa !24
  %t205 = load i64, ptr %l103, !tbaa !24
  %t206 = add i64 %t205, 1
  store i64 %t206, ptr %l104, !tbaa !24
  %t207 = load i64, ptr %l104, !tbaa !24
  store i64 %t207, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb31
bb41:
  %t208 = load i64, ptr %l13, !tbaa !24
  store i64 %t208, ptr %l105, !tbaa !24
  %t209 = load i64, ptr %l15, !tbaa !24
  store i64 %t209, ptr %l106, !tbaa !24
  %t210 = load i64, ptr %l105, !tbaa !24
  %t211 = load i64, ptr %l106, !tbaa !24
  %t212 = add i64 %t210, %t211
  store i64 %t212, ptr %l107, !tbaa !24
  %t213 = load i64, ptr %l107, !tbaa !24
  store i64 %t213, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb42:
  br label %bb24
bb43:
  call void @__olang_scope_close(ptr %s5)
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l108, !tbaa !29
  %t215 = load ptr, ptr %l108, !tbaa !29
  %t216 = getelementptr %"compiler/build:Program", ptr %t215, i32 0, i32 1
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l109, !tbaa !27
  %t218 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t219 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t218, { i64, ptr } { i64 0, ptr @.d64 })
  store i1 %t219, ptr %l110
  br label %bb44
bb44:
  %t220 = load i1, ptr %l110, !tbaa !21
  %t221 = xor i1 %t220, true
  store i1 %t221, ptr %l111, !tbaa !21
  %t222 = load i1, ptr %l111, !tbaa !21
  br i1 %t222, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t223 = load ptr, ptr %lp11
  store ptr %t223, ptr %l112, !tbaa !29
  %t224 = load ptr, ptr %l0, !tbaa !29
  store ptr %t224, ptr %l114, !tbaa !29
  store ptr %l10, ptr %l115, !tbaa !29
  store i32 0, ptr %l116
  %t225 = load ptr, ptr %l1, !tbaa !29
  store ptr %t225, ptr %l117, !tbaa !29
  %t226 = load ptr, ptr %l117, !tbaa !29
  %t227 = getelementptr %"compiler/build:Program", ptr %t226, i32 0, i32 1
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l118, !tbaa !27
  %t229 = load ptr, ptr %l2, !tbaa !29
  store ptr %t229, ptr %l119, !tbaa !29
  %t230 = load ptr, ptr %l114, !tbaa !29
  %t231 = load ptr, ptr %l115, !tbaa !29
  %t232 = load i32, ptr %l116
  %t233 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t234 = load ptr, ptr %l119, !tbaa !29
  %t235 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t230, ptr %t231, { i64, ptr } { i64 13, ptr @.d65 }, i32 %t232, { i64, ptr } %t233, ptr %t234)
  %t236 = extractvalue { i32, { i64, ptr } } %t235, 1
  %t237 = extractvalue { i32, { i64, ptr } } %t235, 0
  store i32 %t237, ptr %l121
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb48, label %ok.239
ok.239:
  store { i64, ptr } %t236, ptr %l120
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t240 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t240, ptr %l113, !tbaa !27
  br label %bb49
bb48:
  %t241 = load i32, ptr %l121, !tbaa !23
  %t242 = lshr i32 %t241, 16
  %t243 = and i32 %t241, 65535
  %t244 = icmp eq i32 %t242, 1
  %t245 = select i1 %t244, i32 1, i32 0
  %t246 = icmp eq i32 %t241, 0
  %t247 = shl i32 %t245, 16
  %t248 = or i32 %t247, %t243
  %t249 = select i1 %t246, i32 0, i32 %t248
  store i32 %t249, ptr %l122, !tbaa !23
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t250 = load i32, ptr %l122, !tbaa !23
  %t251 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t250, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t251, ptr %rv
  br label %ret
bb49:
  %t252 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t253 = extractvalue { i64, ptr } %t252, 0
  %t254 = extractvalue { i64, ptr } %t252, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  store { i64, ptr } %t258, ptr %l123, !tbaa !27
  %t259 = load ptr, ptr %l112, !tbaa !29
  %t260 = load { i64, ptr }, ptr %l123, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t259, { i64, ptr } %t260)
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  br label %bb51
bb51:
  %t261 = load ptr, ptr %l1, !tbaa !29
  store ptr %t261, ptr %l124, !tbaa !29
  %t262 = load ptr, ptr %l124, !tbaa !29
  %t263 = getelementptr %"compiler/build:Program", ptr %t262, i32 0, i32 2
  %t264 = load { i64, ptr }, ptr %t263, !tbaa !27
  store { i64, ptr } %t264, ptr %l125, !tbaa !27
  %t265 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t266 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t265, { i64, ptr } { i64 0, ptr @.d66 })
  store i1 %t266, ptr %l126
  br label %bb52
bb52:
  %t267 = load i1, ptr %l126, !tbaa !21
  %t268 = xor i1 %t267, true
  store i1 %t268, ptr %l127, !tbaa !21
  %t269 = load i1, ptr %l127, !tbaa !21
  br i1 %t269, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s10
  %t270 = load ptr, ptr %lp11
  store ptr %t270, ptr %l128, !tbaa !29
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l130, !tbaa !29
  store ptr %l10, ptr %l131, !tbaa !29
  store i32 0, ptr %l132
  %t272 = load ptr, ptr %l1, !tbaa !29
  store ptr %t272, ptr %l133, !tbaa !29
  %t273 = load ptr, ptr %l133, !tbaa !29
  %t274 = getelementptr %"compiler/build:Program", ptr %t273, i32 0, i32 2
  %t275 = load { i64, ptr }, ptr %t274, !tbaa !27
  store { i64, ptr } %t275, ptr %l134, !tbaa !27
  %t276 = load ptr, ptr %l2, !tbaa !29
  store ptr %t276, ptr %l135, !tbaa !29
  %t277 = load ptr, ptr %l130, !tbaa !29
  %t278 = load ptr, ptr %l131, !tbaa !29
  %t279 = load i32, ptr %l132
  %t280 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t281 = load ptr, ptr %l135, !tbaa !29
  %t282 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t277, ptr %t278, { i64, ptr } { i64 13, ptr @.d67 }, i32 %t279, { i64, ptr } %t280, ptr %t281)
  %t283 = extractvalue { i32, { i64, ptr } } %t282, 1
  %t284 = extractvalue { i32, { i64, ptr } } %t282, 0
  store i32 %t284, ptr %l137
  %t285 = icmp ne i32 %t284, 0
  br i1 %t285, label %bb56, label %ok.286
ok.286:
  store { i64, ptr } %t283, ptr %l136
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t287 = load { i64, ptr }, ptr %l136, !tbaa !27
  store { i64, ptr } %t287, ptr %l129, !tbaa !27
  br label %bb57
bb56:
  %t288 = load i32, ptr %l137, !tbaa !23
  %t289 = lshr i32 %t288, 16
  %t290 = and i32 %t288, 65535
  %t291 = icmp eq i32 %t289, 1
  %t292 = select i1 %t291, i32 1, i32 0
  %t293 = icmp eq i32 %t288, 0
  %t294 = shl i32 %t292, 16
  %t295 = or i32 %t294, %t290
  %t296 = select i1 %t293, i32 0, i32 %t295
  store i32 %t296, ptr %l138, !tbaa !23
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t297 = load i32, ptr %l138, !tbaa !23
  %t298 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t297, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t298, ptr %rv
  br label %ret
bb57:
  %t299 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t300 = extractvalue { i64, ptr } %t299, 0
  %t301 = extractvalue { i64, ptr } %t299, 1
  %t302 = mul i64 %t300, 1
  %t303 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t302)
  call void @llvm.memcpy.p0.p0.i64(ptr %t303, ptr %t301, i64 %t302, i1 false)
  %t304 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t305 = insertvalue { i64, ptr } %t304, ptr %t303, 1
  store { i64, ptr } %t305, ptr %l139, !tbaa !27
  %t306 = load ptr, ptr %l128, !tbaa !29
  %t307 = load { i64, ptr }, ptr %l139, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t306, { i64, ptr } %t307)
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s10)
  br label %bb59
bb59:
  %t308 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 0
  store ptr %t308, ptr %l140, !tbaa !29
  %t309 = load ptr, ptr %l140, !tbaa !29
  %t310 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %t309)
  store { i64, ptr } %t310, ptr %l141
  br label %bb60
bb60:
  %t311 = load ptr, ptr %l0, !tbaa !29
  store ptr %t311, ptr %l142, !tbaa !29
  %t312 = load ptr, ptr %l142, !tbaa !29
  %t313 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t312)
  store i64 %t313, ptr %l143
  br label %bb61
bb61:
  %t314 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t315 = load i64, ptr %l143, !tbaa !24
  %t316 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %s0, ptr %s0, { i64, ptr } %t314, i64 %t315)
  store { { i64, ptr }, { i64, ptr } } %t316, ptr %l144
  br label %bb62
bb62:
  %t317 = load { { i64, ptr }, { i64, ptr } }, ptr %l144
  store { { i64, ptr }, { i64, ptr } } %t317, ptr %l18
  %t318 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l18, i32 0, i32 0
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  store { i64, ptr } %t319, ptr %l145, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t321 = extractvalue { i64, ptr } %t320, 0
  store i64 %t321, ptr %l146, !tbaa !24
  %t322 = load i64, ptr %l146, !tbaa !24
  %t323 = mul i64 %t322, 4
  %t324 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t323)
  %t325 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t326 = insertvalue { i64, ptr } %t325, ptr %t324, 1
  store { i64, ptr } %t326, ptr %l147, !tbaa !27
  %t327 = getelementptr { i64, ptr }, ptr %l147, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr { i64, ptr }, ptr %l145, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = load i64, ptr %l146, !tbaa !24
  %t332 = mul i64 %t331, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t328, ptr %t330, i64 %t332, i1 false)
  %t333 = load { i64, ptr }, ptr %l147, !tbaa !27
  store { i64, ptr } %t333, ptr %l19, !tbaa !27
  %t334 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l18, i32 0, i32 1
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l148, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  store i64 %t337, ptr %l149, !tbaa !24
  %t338 = load i64, ptr %l149, !tbaa !24
  %t339 = mul i64 %t338, 16
  %t340 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t339)
  %t341 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  store { i64, ptr } %t342, ptr %l150, !tbaa !27
  %t343 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = load i64, ptr %l149, !tbaa !24
  %t348 = mul i64 %t347, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t344, ptr %t346, i64 %t348, i1 false)
  %t349 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t349, ptr %l20, !tbaa !27
  %t350 = load ptr, ptr %l0, !tbaa !29
  store ptr %t350, ptr %l151, !tbaa !29
  %t351 = load ptr, ptr %l151, !tbaa !29
  %t352 = getelementptr %"compiler/build:Config", ptr %t351, i32 0, i32 14
  %t353 = load i64, ptr %t352, !tbaa !24
  store i64 %t353, ptr %l152, !tbaa !24
  %t354 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 0
  store ptr %t354, ptr %l153, !tbaa !29
  %t355 = load ptr, ptr %l153, !tbaa !29
  %t356 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %s0, ptr %t355)
  store i64 %t356, ptr %l154
  br label %bb63
bb63:
  %t357 = load i64, ptr %l152, !tbaa !24
  %t358 = load i64, ptr %l154, !tbaa !24
  %t359 = add i64 %t357, %t358
  store i64 %t359, ptr %l155, !tbaa !24
  %t360 = load i64, ptr %l155, !tbaa !24
  %t361 = load ptr, ptr %l151, !tbaa !29
  %t362 = getelementptr %"compiler/build:Config", ptr %t361, i32 0, i32 14
  store i64 %t360, ptr %t362, !tbaa !24
  store i1 false, ptr %l21, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s11
  store i64 0, ptr %l22, !tbaa !24
  %t363 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t363, ptr %l156, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  store i64 %t365, ptr %l157, !tbaa !24
  %t366 = load i64, ptr %l157, !tbaa !24
  store i64 %t366, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t367 = load i64, ptr %l23, !tbaa !24
  store i64 %t367, ptr %l158, !tbaa !24
  %t368 = load i64, ptr %l22, !tbaa !24
  store i64 %t368, ptr %l159, !tbaa !24
  %t369 = load i64, ptr %l158, !tbaa !24
  %t370 = load i64, ptr %l159, !tbaa !24
  %t371 = icmp sgt i64 %t369, %t370
  store i1 %t371, ptr %l160, !tbaa !21
  %t372 = load i1, ptr %l160, !tbaa !21
  br i1 %t372, label %bb64, label %bb65
bb64:
  %t373 = load i64, ptr %l24, !tbaa !24
  store i64 %t373, ptr %l162, !tbaa !24
  %t374 = load i64, ptr %l162, !tbaa !24
  %t375 = icmp sgt i64 %t374, 0
  store i1 %t375, ptr %l163, !tbaa !21
  %t376 = load i1, ptr %l163, !tbaa !21
  br i1 %t376, label %bb66, label %bb67
bb65:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb69
bb66:
  %t377 = load i64, ptr %l23, !tbaa !24
  store i64 %t377, ptr %l165, !tbaa !24
  %t378 = load i64, ptr %l22, !tbaa !24
  store i64 %t378, ptr %l166, !tbaa !24
  %t379 = load i64, ptr %l165, !tbaa !24
  %t380 = load i64, ptr %l166, !tbaa !24
  %t381 = sub i64 %t379, %t380
  store i64 %t381, ptr %l167, !tbaa !24
  %t382 = load i64, ptr %l24, !tbaa !24
  store i64 %t382, ptr %l168, !tbaa !24
  %t383 = load i64, ptr %l167, !tbaa !24
  %t384 = load i64, ptr %l168, !tbaa !24
  %t385 = add i64 %t383, %t384
  store i64 %t385, ptr %l169, !tbaa !24
  %t386 = load i64, ptr %l169, !tbaa !24
  %t387 = sub i64 %t386, 1
  store i64 %t387, ptr %l170, !tbaa !24
  %t388 = load i64, ptr %l24, !tbaa !24
  store i64 %t388, ptr %l171, !tbaa !24
  %t389 = load i64, ptr %l170, !tbaa !24
  %t390 = load i64, ptr %l171, !tbaa !24
  %t391 = sdiv i64 %t389, %t390
  store i64 %t391, ptr %l172, !tbaa !24
  %t392 = load i64, ptr %l172, !tbaa !24
  store i64 %t392, ptr %l164, !tbaa !24
  br label %bb68
bb67:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb68
bb68:
  %t393 = load i64, ptr %l164, !tbaa !24
  store i64 %t393, ptr %l161, !tbaa !24
  br label %bb69
bb69:
  %t394 = load i64, ptr %l161, !tbaa !24
  store i64 %t394, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s12
  %t395 = load i64, ptr %l26, !tbaa !24
  store i64 %t395, ptr %l173, !tbaa !24
  %t396 = load i64, ptr %l25, !tbaa !24
  store i64 %t396, ptr %l174, !tbaa !24
  %t397 = load i64, ptr %l173, !tbaa !24
  %t398 = load i64, ptr %l174, !tbaa !24
  %t399 = icmp slt i64 %t397, %t398
  store i1 %t399, ptr %l175, !tbaa !21
  %t400 = load i1, ptr %l175, !tbaa !21
  %t401 = xor i1 %t400, true
  store i1 %t401, ptr %l176, !tbaa !21
  %t402 = load i1, ptr %l176, !tbaa !21
  br i1 %t402, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s12)
  br label %bb111
bb72:
  br label %bb73
bb73:
  %t403 = load i64, ptr %l22, !tbaa !24
  store i64 %t403, ptr %l177, !tbaa !24
  %t404 = load i64, ptr %l26, !tbaa !24
  store i64 %t404, ptr %l178, !tbaa !24
  %t405 = load i64, ptr %l24, !tbaa !24
  store i64 %t405, ptr %l179, !tbaa !24
  %t406 = load i64, ptr %l178, !tbaa !24
  %t407 = load i64, ptr %l179, !tbaa !24
  %t408 = mul i64 %t406, %t407
  store i64 %t408, ptr %l180, !tbaa !24
  %t409 = load i64, ptr %l177, !tbaa !24
  %t410 = load i64, ptr %l180, !tbaa !24
  %t411 = add i64 %t409, %t410
  store i64 %t411, ptr %l181, !tbaa !24
  %t412 = load i64, ptr %l181, !tbaa !24
  store i64 %t412, ptr %l27, !tbaa !24
  %t413 = load i64, ptr %l27, !tbaa !24
  store i64 %t413, ptr %l182, !tbaa !24
  %t414 = load i64, ptr %l182, !tbaa !24
  %t415 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t416 = load ptr, ptr %t415, !tbaa !27
  %t417 = getelementptr i32, ptr %t416, i64 %t414
  %t418 = load i32, ptr %t417, !tbaa !33
  store i32 %t418, ptr %l183, !tbaa !23
  %t419 = load i32, ptr %l183, !tbaa !23
  %t420 = icmp ne i32 %t419, 0
  store i1 %t420, ptr %l184, !tbaa !21
  %t421 = load i1, ptr %l184, !tbaa !21
  br i1 %t421, label %bb74, label %bb75
bb74:
  store %olang.scope zeroinitializer, ptr %s13
  %t422 = load i64, ptr %l27, !tbaa !24
  store i64 %t422, ptr %l185, !tbaa !24
  %t423 = load i64, ptr %l185, !tbaa !24
  %t424 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr { i64, ptr }, ptr %t425, i64 %t423
  %t427 = load { i64, ptr }, ptr %t426, !tbaa !37
  store { i64, ptr } %t427, ptr %l186, !tbaa !27
  %t428 = load { i64, ptr }, ptr %l186, !tbaa !27
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t428)
  br label %bb76
bb75:
  br label %bb90
bb76:
  %t429 = load i1, ptr %l21, !tbaa !21
  store i1 %t429, ptr %l187, !tbaa !21
  %t430 = load i1, ptr %l187, !tbaa !21
  %t431 = xor i1 %t430, true
  store i1 %t431, ptr %l188, !tbaa !21
  %t432 = load i1, ptr %l188, !tbaa !21
  br i1 %t432, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s14
  %t433 = load ptr, ptr %l2, !tbaa !29
  store ptr %t433, ptr %l189, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t434
  %t435 = getelementptr { i64, [3 x i64] }, ptr %t434, i32 0, i32 0
  store i64 0, ptr %t435
  %t436 = load { i64, [3 x i64] }, ptr %t434
  store { i64, [3 x i64] } %t436, ptr %l190
  %t437 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 3
  store ptr %t437, ptr %l191, !tbaa !29
  %t438 = load i64, ptr %l27, !tbaa !24
  store i64 %t438, ptr %l192, !tbaa !24
  %t439 = load ptr, ptr %l191, !tbaa !29
  %t440 = load i64, ptr %l192, !tbaa !24
  %t441 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t439, i64 %t440)
  store { i64, ptr } %t441, ptr %l193
  br label %bb79
bb78:
  br label %bb82
bb79:
  %t442 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t443 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %s0, ptr %s14, { i64, ptr } %t442)
  store %"compiler/msgs:Msg" %t443, ptr %l194
  br label %bb80
bb80:
  %t444 = load ptr, ptr %l189, !tbaa !29
  %t445 = load { i64, [3 x i64] }, ptr %l190
  %t446 = load %"compiler/msgs:Msg", ptr %l194
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %s14, ptr %t444, { i64, [3 x i64] } %t445, %"compiler/msgs:Msg" %t446)
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s14)
  br label %bb82
bb82:
  store i1 true, ptr %l21, !tbaa !21
  %t447 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 1
  store ptr %t447, ptr %l195, !tbaa !29
  %t448 = load i64, ptr %l27, !tbaa !24
  store i64 %t448, ptr %l196, !tbaa !24
  %t449 = load ptr, ptr %l195, !tbaa !29
  %t450 = load i64, ptr %l196, !tbaa !24
  %t451 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t449, i64 %t450)
  store { i64, ptr } %t451, ptr %l197
  br label %bb83
bb83:
  %t452 = load { i64, ptr }, ptr %l197, !tbaa !27
  %t453 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t452)
  store i32 %t453, ptr %l198
  %t454 = icmp ne i32 %t453, 0
  br i1 %t454, label %bb85, label %ok.455
ok.455:
  br label %bb84
bb84:
  br label %bb89
bb85:
  %t456 = load i32, ptr %l198, !tbaa !23
  %t457 = ashr i32 %t456, 16
  store i32 %t457, ptr %l199, !tbaa !23
  %t458 = load i32, ptr %l199, !tbaa !23
  %t459 = icmp eq i32 %t458, 1
  store i1 %t459, ptr %l200, !tbaa !21
  %t460 = load i1, ptr %l200, !tbaa !21
  br i1 %t460, label %bb86, label %bb87
bb86:
  br label %bb88
bb87:
  %t461 = load i32, ptr %l198, !tbaa !23
  %t462 = lshr i32 %t461, 16
  %t463 = and i32 %t461, 65535
  %t464 = icmp eq i32 %t462, 1
  %t465 = select i1 %t464, i32 0, i32 0
  %t466 = icmp eq i32 %t461, 0
  %t467 = shl i32 %t465, 16
  %t468 = or i32 %t467, %t463
  %t469 = select i1 %t466, i32 0, i32 %t468
  store i32 %t469, ptr %l201, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t470 = load i32, ptr %l201, !tbaa !23
  %t471 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t470, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t471, ptr %rv
  br label %ret
bb88:
  store %olang.scope zeroinitializer, ptr %s15
  call void @__olang_scope_close(ptr %s15)
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  br label %bb110
bb90:
  %t472 = load i64, ptr %l27, !tbaa !24
  store i64 %t472, ptr %l202, !tbaa !24
  %t473 = load i64, ptr %l202, !tbaa !24
  %t474 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t475 = load ptr, ptr %t474, !tbaa !27
  %t476 = getelementptr { i64, ptr }, ptr %t475, i64 %t473
  %t477 = load { i64, ptr }, ptr %t476, !tbaa !37
  store { i64, ptr } %t477, ptr %l203, !tbaa !27
  %t478 = load { i64, ptr }, ptr %l203, !tbaa !27
  %t479 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s12, { i64, ptr } %t478, { i64, ptr } { i64 0, ptr @.d68 })
  store i1 %t479, ptr %l204
  br label %bb91
bb91:
  %t480 = load i1, ptr %l204, !tbaa !21
  %t481 = xor i1 %t480, true
  store i1 %t481, ptr %l205, !tbaa !21
  %t482 = load i1, ptr %l205, !tbaa !21
  br i1 %t482, label %bb92, label %bb93
bb92:
  store %olang.scope zeroinitializer, ptr %s16
  %t483 = load i64, ptr %l27, !tbaa !24
  store i64 %t483, ptr %l206, !tbaa !24
  %t484 = load i64, ptr %l206, !tbaa !24
  %t485 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t486 = load ptr, ptr %t485, !tbaa !27
  %t487 = getelementptr { i64, ptr }, ptr %t486, i64 %t484
  %t488 = load { i64, ptr }, ptr %t487, !tbaa !37
  store { i64, ptr } %t488, ptr %l207, !tbaa !27
  %t489 = load { i64, ptr }, ptr %l207, !tbaa !27
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t489)
  br label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_scope_close(ptr %s16)
  br label %bb95
bb95:
  %t490 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 1
  store ptr %t490, ptr %l208, !tbaa !29
  %t491 = load i64, ptr %l27, !tbaa !24
  store i64 %t491, ptr %l209, !tbaa !24
  %t492 = load ptr, ptr %l208, !tbaa !29
  %t493 = load i64, ptr %l209, !tbaa !24
  %t494 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t492, i64 %t493)
  store { i64, ptr } %t494, ptr %l210
  br label %bb96
bb96:
  %t495 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 2
  store ptr %t495, ptr %l211, !tbaa !29
  %t496 = load i64, ptr %l27, !tbaa !24
  store i64 %t496, ptr %l212, !tbaa !24
  %t497 = load ptr, ptr %l211, !tbaa !29
  %t498 = load i64, ptr %l212, !tbaa !24
  %t499 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t497, i64 %t498)
  store { i64, ptr } %t499, ptr %l213
  br label %bb97
bb97:
  %t500 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t501 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t502 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t500, { i64, ptr } %t501)
  store i32 %t502, ptr %l214
  %t503 = icmp ne i32 %t502, 0
  br i1 %t503, label %bb99, label %ok.504
ok.504:
  br label %bb98
bb98:
  br label %bb109
bb99:
  %t505 = load i32, ptr %l214, !tbaa !23
  %t506 = ashr i32 %t505, 16
  store i32 %t506, ptr %l215, !tbaa !23
  %t507 = load i32, ptr %l215, !tbaa !23
  %t508 = icmp eq i32 %t507, 1
  store i1 %t508, ptr %l216, !tbaa !21
  %t509 = load i1, ptr %l216, !tbaa !21
  br i1 %t509, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  %t510 = load i32, ptr %l214, !tbaa !23
  %t511 = lshr i32 %t510, 16
  %t512 = and i32 %t510, 65535
  %t513 = icmp eq i32 %t511, 1
  %t514 = select i1 %t513, i32 0, i32 0
  %t515 = icmp eq i32 %t510, 0
  %t516 = shl i32 %t514, 16
  %t517 = or i32 %t516, %t512
  %t518 = select i1 %t515, i32 0, i32 %t517
  store i32 %t518, ptr %l217, !tbaa !23
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t519 = load i32, ptr %l217, !tbaa !23
  %t520 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t519, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t520, ptr %rv
  br label %ret
bb102:
  store %olang.scope zeroinitializer, ptr %s17
  %t521 = load i1, ptr %l21, !tbaa !21
  store i1 %t521, ptr %l218, !tbaa !21
  %t522 = load i1, ptr %l218, !tbaa !21
  %t523 = xor i1 %t522, true
  store i1 %t523, ptr %l219, !tbaa !21
  %t524 = load i1, ptr %l219, !tbaa !21
  br i1 %t524, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s18
  %t525 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 2
  store ptr %t525, ptr %l220, !tbaa !29
  %t526 = load i64, ptr %l27, !tbaa !24
  store i64 %t526, ptr %l221, !tbaa !24
  %t527 = load ptr, ptr %l220, !tbaa !29
  %t528 = load i64, ptr %l221, !tbaa !24
  %t529 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t527, i64 %t528)
  store { i64, ptr } %t529, ptr %l222
  br label %bb105
bb104:
  br label %bb108
bb105:
  %t530 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s18)
  store %"compiler/msgs:Msg" %t530, ptr %l223
  br label %bb106
bb106:
  %t531 = load ptr, ptr %l2, !tbaa !29
  store ptr %t531, ptr %l224, !tbaa !29
  %t532 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t533 = load %"compiler/msgs:Msg", ptr %l223
  %t534 = load ptr, ptr %l224, !tbaa !29
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s18, ptr %v2, { i64, ptr } %t532, %"compiler/msgs:Msg" %t533, ptr %t534)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s18)
  br label %bb108
bb108:
  store i1 true, ptr %l21, !tbaa !21
  call void @__olang_scope_close(ptr %s17)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s12)
  br label %bb110
bb110:
  store %olang.scope zeroinitializer, ptr %s19
  %t535 = load i64, ptr %l26, !tbaa !24
  store i64 %t535, ptr %l225, !tbaa !24
  %t536 = load i64, ptr %l225, !tbaa !24
  %t537 = add i64 %t536, 1
  store i64 %t537, ptr %l226, !tbaa !24
  %t538 = load i64, ptr %l226, !tbaa !24
  store i64 %t538, ptr %l26, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb70
bb111:
  call void @__olang_scope_close(ptr %s11)
  %t539 = load i1, ptr %l21, !tbaa !21
  store i1 %t539, ptr %l227, !tbaa !21
  %t540 = load i1, ptr %l227, !tbaa !21
  br i1 %t540, label %bb112, label %bb113
bb112:
  store %olang.scope zeroinitializer, ptr %s20
  store i32 65536, ptr %l228, !tbaa !23
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s0)
  %t541 = load i32, ptr %l228, !tbaa !23
  %t542 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t541, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t542, ptr %rv
  br label %ret
bb113:
  br label %bb114
bb114:
  %t543 = load ptr, ptr %lp11
  %t544 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t543
  store %"std/prelude/list:List<std/prelude/text:String&>" %t544, ptr %l229
  call void @__olang_scope_close(ptr %s0)
  %t545 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l229
  %t546 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, %"std/prelude/list:List<std/prelude/text:String&>" %t545, 1
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t546, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/list:List<std/prelude/text:String&>" }, ptr %rv
  ret { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/os:Output"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca %"std/os:Output"
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/os:Output"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 17
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr @.d69 })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l6, !tbaa !29
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s2, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s2
  %t16 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t29 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t28, 0
  %t30 = insertvalue [2 x { i64, ptr }] %t29, { i64, ptr } { i64 9, ptr @.d70 }, 1
  store [2 x { i64, ptr }] %t30, ptr %l10
  %t31 = load [2 x { i64, ptr }], ptr %l10
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call ptr @__olang_scope_alloc(ptr %t32, i64 32)
  store [2 x { i64, ptr }] %t31, ptr %t33
  %t34 = insertvalue { i64, ptr } undef, i64 2, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l11, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 16
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d71 }, ptr %l13, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t45 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t43, { i64, ptr } %t44, i1 true, { i64, ptr } { i64 0, ptr @.d72 })
  %t46 = extractvalue { i32, %"std/os:Output" } %t45, 1
  %t47 = extractvalue { i32, %"std/os:Output" } %t45, 0
  store i32 %t47, ptr %l15
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb5, label %ok.49
ok.49:
  store %"std/os:Output" %t46, ptr %l14
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t50 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t50, ptr %l5
  br label %bb9
bb5:
  %t51 = load i32, ptr %l15, !tbaa !23
  %t52 = ashr i32 %t51, 16
  store i32 %t52, ptr %l16, !tbaa !23
  %t53 = load i32, ptr %l16, !tbaa !23
  %t54 = icmp eq i32 %t53, 1
  store i1 %t54, ptr %l17, !tbaa !21
  %t55 = load i1, ptr %l17, !tbaa !21
  br i1 %t55, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c73)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 0, ptr @.d74 }, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  %t57 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t57, ptr %l1
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l19, !tbaa !29
  %t59 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59, !tbaa !27
  store { i64, ptr } %t60, ptr %l20, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t61 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  call void @__olang_sb_put(ptr %s4, ptr %t62, i64 %t63)
  %t64 = load ptr, ptr %s4
  %t65 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t66 = load i64, ptr %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t64, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l21, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  %t70 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l22, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t78 = load ptr, ptr %l19, !tbaa !29
  %t79 = getelementptr %"compiler/build:Config", ptr %t78, i32 0, i32 17
  store { i64, ptr } %t77, ptr %t79, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t80 = load ptr, ptr %l0, !tbaa !29
  store ptr %t80, ptr %l23, !tbaa !29
  %t81 = load ptr, ptr %l23, !tbaa !29
  %t82 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 17
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l24, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %l11 = alloca ptr
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t6 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t5)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  br label %bb1
bb1:
  br label %bb8
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  store i32 %t10, ptr %l5, !tbaa !23
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = icmp eq i32 %t11, 1
  store i1 %t12, ptr %l6, !tbaa !21
  %t13 = load i1, ptr %l6, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 0, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  store i32 %t22, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l7, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l8, !tbaa !29
  %t25 = load ptr, ptr %l8, !tbaa !29
  %t26 = getelementptr %"compiler/build:Config", ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t28, ptr %l10
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l1, !tbaa !29
  store ptr %t29, ptr %l11, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t31 = load %"compiler/msgs:Msg", ptr %l10
  %t32 = load ptr, ptr %l11, !tbaa !29
  call void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %s1, ptr %v1, { i64, ptr } %t30, %"compiler/msgs:Msg" %t31, ptr %t32)
  br label %bb7
bb7:
  store i32 65536, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i32, ptr %l12, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l2, !tbaa !21
  %t5 = load i1, ptr %l2, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 5, ptr @.d75 }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d76 }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 6, ptr @.d77 }, ptr %l6, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr @.d78 }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l7, !tbaa !29
  %t12 = load ptr, ptr %l7, !tbaa !29
  %t13 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 6
  %t14 = load i1, ptr %t13, !tbaa !21
  store i1 %t14, ptr %l8, !tbaa !21
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 4, ptr @.d79 }, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr @.d80 }, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l10, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 10
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l5, !tbaa !21
  %t5 = load i1, ptr %l5, !tbaa !21
  %t6 = xor i1 %t5, true
  store i1 %t6, ptr %l6, !tbaa !21
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s2, ptr %t10, i64 %t11)
  %t12 = load ptr, ptr %s2
  %t13 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t14 = load i64, ptr %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t12, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l8, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t19 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t20, ptr %l3
  store ptr %l3, ptr %l10, !tbaa !29
  %t21 = load ptr, ptr %l10, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t21, i8 27)
  br label %bb5
bb5:
  store ptr %l3, ptr %l11, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t22, ptr %l12, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d81 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t23, i64 %t24)
  %t25 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  call void @__olang_sb_put(ptr %s3, ptr %t26, i64 %t27)
  %t28 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 1
  %t29 = extractvalue { i64, ptr } { i64 1, ptr @.d82 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t28, i64 %t29)
  %t30 = load ptr, ptr %s3
  %t31 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t32 = load i64, ptr %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t30, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l13, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t36 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l14, !tbaa !27
  %t43 = load ptr, ptr %l11, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t43, { i64, ptr } %t44)
  br label %bb6
bb6:
  store ptr %l3, ptr %l15, !tbaa !29
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t45, ptr %l16, !tbaa !27
  %t46 = load ptr, ptr %l15, !tbaa !29
  %t47 = load { i64, ptr }, ptr %l16, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v2, ptr %t46, { i64, ptr } %t47)
  br label %bb7
bb7:
  store ptr %l3, ptr %l17, !tbaa !29
  %t48 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t48, i8 27)
  br label %bb8
bb8:
  store ptr %l3, ptr %l18, !tbaa !29
  %t49 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t49, { i64, ptr } { i64 3, ptr @.d83 })
  br label %bb9
bb9:
  store ptr %l3, ptr %l19, !tbaa !29
  %t50 = load ptr, ptr %l19, !tbaa !29
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %t50)
  store { i64, ptr } %t51, ptr %l20
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t52, ptr %l21, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l22, !tbaa !24
  %t55 = load i64, ptr %l22, !tbaa !24
  %t56 = mul i64 %t55, 1
  %t57 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l23, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l22, !tbaa !24
  %t65 = mul i64 %t64, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t66, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t67 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v2, ptr %s0, ptr %t2)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t11)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l6, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t14 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 27, ptr @.d84 }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr @.d84 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  %t32 = load ptr, ptr %l6, !tbaa !29
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t34 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t32, { i64, ptr } { i64 2, ptr @.d85 }, { i64, ptr } %t33)
  store { i64, ptr } %t34, ptr %l10
  br label %bb3
bb3:
  %t35 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l11, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t42)
  br label %bb4
bb4:
  store i32 1, ptr %l12, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l12, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  %t2 = load %"compiler/msgs:Msg", ptr %l2
  store %"compiler/msgs:Msg" %t2, ptr %l5
  %t3 = load ptr, ptr %l3, !tbaa !29
  store ptr %t3, ptr %l6, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = load %"compiler/msgs:Msg", ptr %l5
  %t6 = load ptr, ptr %l6, !tbaa !29
  call void @compiler_2fbuild_2efileError(ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t4, %"compiler/msgs:Msg" %t5, ptr %t6)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s0, ptr %t8)
  store { i64, ptr } %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l9, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t17)
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l10, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s1, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 27, ptr @.d86 }, 1
  %t24 = extractvalue { i64, ptr } { i64 27, ptr @.d86 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l12, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l13, !tbaa !27
  %t38 = load ptr, ptr %l10, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t40 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t38, { i64, ptr } { i64 2, ptr @.d87 }, { i64, ptr } %t39)
  store { i64, ptr } %t40, ptr %l14
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l15, !tbaa !27
  %t48 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t48)
  br label %bb5
bb5:
  store i32 1, ptr %l16, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i32, ptr %l16, !tbaa !23
  store i32 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %lp7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca { i64, [3 x i64] }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  %t132 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l18, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t2, ptr %l19, !tbaa !27
  %t3 = load ptr, ptr %l18, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t5 = call %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v3, ptr %s0, ptr %t3, { i64, ptr } %t4)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l20
  store %"std/prelude/list:List<std/prelude/text:String&>" %t6, ptr %l6
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l21, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l22, !tbaa !27
  %t9 = load i32, ptr %l3
  store i32 %t9, ptr %l23
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t10, ptr %l24, !tbaa !27
  store ptr %l6, ptr %l25, !tbaa !29
  %t11 = load ptr, ptr %l21, !tbaa !29
  %t12 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t13 = load i32, ptr %l23
  %t14 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t15 = load ptr, ptr %l25, !tbaa !29
  %t16 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v2, ptr %v3, ptr %s0, ptr %v5, ptr %t11, { i64, ptr } %t12, i32 %t13, { i64, ptr } %t14, ptr %t15)
  store { i64, ptr } %t16, ptr %l26
  br label %bb2
bb2:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 16, i64 8)
  store ptr %t17, ptr %lp7
  %t18 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t19 = load ptr, ptr %lp7
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load ptr, ptr %lp7
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l27, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t23 = call i1 @std_2fos_2eExists(ptr %v5, { i64, ptr } %t22)
  store i1 %t23, ptr %l28
  br label %bb3
bb3:
  %t24 = load i1, ptr %l28, !tbaa !21
  br i1 %t24, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l29, !tbaa !21
  br label %bb7
bb5:
  %t25 = load ptr, ptr %lp7
  %t26 = load { i64, ptr }, ptr %t25, !tbaa !27
  store { i64, ptr } %t26, ptr %l30, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l31, !tbaa !24
  %t29 = load i64, ptr %l31, !tbaa !24
  %t30 = mul i64 %t29, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l32, !tbaa !27
  %t34 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = load i64, ptr %l31, !tbaa !24
  %t39 = mul i64 %t38, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t35, ptr %t37, i64 %t39, i1 false)
  %t40 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t40, ptr %l8, !tbaa !27
  %t41 = load ptr, ptr %l1, !tbaa !29
  store ptr %t41, ptr %l33, !tbaa !29
  %t42 = load ptr, ptr %l33, !tbaa !29
  %t43 = getelementptr %"compiler/build:compiles", ptr %t42, i32 0, i32 2
  store ptr %t43, ptr %l34, !tbaa !29
  %t44 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t44, ptr %l35, !tbaa !27
  %t45 = load ptr, ptr %l34, !tbaa !29
  %t46 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t47 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v1, ptr %s0, ptr %t45, { i64, ptr } %t46)
  store i1 %t47, ptr %l36
  br label %bb6
bb6:
  %t48 = load i1, ptr %l36, !tbaa !21
  store i1 %t48, ptr %l29, !tbaa !21
  br label %bb7
bb7:
  %t49 = load i1, ptr %l29, !tbaa !21
  br i1 %t49, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t50 = load ptr, ptr %lp7
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  store { i64, ptr } %t51, ptr %l37, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t53 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t52, 1
  store { i32, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t54 = load ptr, ptr %lp7
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l38, !tbaa !27
  %t56 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l39, !tbaa !24
  %t58 = load i64, ptr %l39, !tbaa !24
  %t59 = sub i64 %t58, 2
  store i64 %t59, ptr %l40, !tbaa !24
  %t60 = load ptr, ptr %lp7
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l41, !tbaa !24
  %t63 = icmp sge i64 0, 0
  store i1 %t63, ptr %l42, !tbaa !21
  %t64 = load i1, ptr %l42, !tbaa !21
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t65 = load i64, ptr %l40, !tbaa !24
  %t66 = icmp sle i64 0, %t65
  store i1 %t66, ptr %l43, !tbaa !21
  %t67 = load i1, ptr %l43, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb13:
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = load i64, ptr %l41, !tbaa !24
  %t70 = icmp sle i64 %t68, %t69
  store i1 %t70, ptr %l44, !tbaa !21
  %t71 = load i1, ptr %l44, !tbaa !21
  br i1 %t71, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb15:
  %t72 = load ptr, ptr %lp7
  %t73 = getelementptr { i64, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73, !tbaa !27
  %t75 = load i64, ptr %l40, !tbaa !24
  %t76 = getelementptr i8, ptr %t74, i64 0
  %t77 = sub i64 %t75, 0
  %t78 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  store { i64, ptr } %t79, ptr %l45, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t80 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  call void @__olang_sb_put(ptr %s2, ptr %t81, i64 %t82)
  %t83 = extractvalue { i64, ptr } { i64 3, ptr @.d89 }, 1
  %t84 = extractvalue { i64, ptr } { i64 3, ptr @.d89 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t83, i64 %t84)
  %t85 = load ptr, ptr %s2
  %t86 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t87 = load i64, ptr %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t85, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l46, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t91 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t91, ptr %l9, !tbaa !27
  %t92 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t92, ptr %l47, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t93, ptr %l48, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t94, ptr %l49, !tbaa !27
  %t95 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t96 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t97 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v3, { i64, ptr } %t95, { i64, ptr } %t96)
  store i32 %t97, ptr %l50
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb18, label %ok.99
ok.99:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c88)
  unreachable
bb17:
  br label %bb24
bb18:
  %t100 = load i32, ptr %l50, !tbaa !23
  %t101 = ashr i32 %t100, 16
  store i32 %t101, ptr %l51, !tbaa !23
  %t102 = load i32, ptr %l51, !tbaa !23
  %t103 = icmp eq i32 %t102, 1
  store i1 %t103, ptr %l52, !tbaa !21
  %t104 = load i1, ptr %l52, !tbaa !21
  br i1 %t104, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  %t105 = load i32, ptr %l50, !tbaa !23
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 0, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  store i32 %t113, ptr %l53, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t114 = load i32, ptr %l53, !tbaa !23
  %t115 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t114, 0
  store { i32, { i64, ptr } } %t115, ptr %rv
  br label %ret
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t116 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t116, ptr %l54, !tbaa !27
  %t117 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s3)
  store %"compiler/msgs:Msg" %t117, ptr %l55
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l5, !tbaa !29
  store ptr %t118, ptr %l56, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t120 = load %"compiler/msgs:Msg", ptr %l55
  %t121 = load ptr, ptr %l56, !tbaa !29
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s3, ptr %v4, { i64, ptr } %t119, %"compiler/msgs:Msg" %t120, ptr %t121)
  br label %bb23
bb23:
  store i32 65536, ptr %l57, !tbaa !23
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t122 = load i32, ptr %l57, !tbaa !23
  %t123 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t122, 0
  store { i32, { i64, ptr } } %t123, ptr %rv
  br label %ret
bb24:
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l58, !tbaa !29
  %t125 = load ptr, ptr %l58, !tbaa !29
  %t126 = getelementptr %"compiler/build:Config", ptr %t125, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !27
  store { i64, ptr } %t127, ptr %l59, !tbaa !27
  %t128 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr @.d90 })
  store i1 %t129, ptr %l60
  br label %bb25
bb25:
  %t130 = load i1, ptr %l60, !tbaa !21
  br i1 %t130, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load ptr, ptr %l5, !tbaa !29
  store ptr %t131, ptr %l61, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 0
  store i64 0, ptr %t133
  %t134 = load { i64, [3 x i64] }, ptr %t132
  store { i64, [3 x i64] } %t134, ptr %l62
  %t135 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t135, ptr %l63, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t137 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %s0, ptr %s4, { i64, ptr } %t136)
  store %"compiler/msgs:Msg" %t137, ptr %l64
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t138 = load ptr, ptr %l61, !tbaa !29
  %t139 = load { i64, [3 x i64] }, ptr %l62
  %t140 = load %"compiler/msgs:Msg", ptr %l64
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s4, ptr %t138, { i64, [3 x i64] } %t139, %"compiler/msgs:Msg" %t140)
  br label %bb29
bb29:
  store i32 65536, ptr %l65, !tbaa !23
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l65, !tbaa !23
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t141, 0
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb30:
  %t143 = load ptr, ptr %lp7
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l66, !tbaa !27
  %t145 = call i32 @getpid()
  store i32 %t145, ptr %l67
  br label %bb31
bb31:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t146 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  call void @__olang_sb_put(ptr %s5, ptr %t147, i64 %t148)
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr @.d91 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t149, i64 %t150)
  %t151 = load i32, ptr %l67, !tbaa !23
  %t152 = sext i32 %t151 to i64
  %t153 = call ptr @__olang_sb_room(ptr %s5, i64 24)
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t152)
  call void @__olang_sb_add(ptr %s5, i64 %t154)
  %t155 = extractvalue { i64, ptr } { i64 4, ptr @.d92 }, 1
  %t156 = extractvalue { i64, ptr } { i64 4, ptr @.d92 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t155, i64 %t156)
  %t157 = load ptr, ptr %s5
  %t158 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t159 = load i64, ptr %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t157, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l68, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t163 = load { i64, ptr }, ptr %l68, !tbaa !27
  store { i64, ptr } %t163, ptr %l10, !tbaa !27
  %t164 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t164, ptr %l69
  br label %bb32
bb32:
  %t165 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l69
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t165, ptr %t166
  store ptr %t166, ptr %l70, !tbaa !29
  %t167 = load ptr, ptr %l70, !tbaa !29
  store ptr %t167, ptr %l11, !tbaa !29
  %t168 = load ptr, ptr %l11, !tbaa !29
  store ptr %t168, ptr %l71, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  store ptr %t169, ptr %l72, !tbaa !29
  %t170 = load ptr, ptr %l72, !tbaa !29
  %t171 = getelementptr %"compiler/build:Config", ptr %t170, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171, !tbaa !27
  store { i64, ptr } %t172, ptr %l73, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t173 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  call void @__olang_sb_put(ptr %s6, ptr %t174, i64 %t175)
  %t176 = load ptr, ptr %s6
  %t177 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t178 = load i64, ptr %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t176, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  store { i64, ptr } %t181, ptr %l74, !tbaa !27
  call void @__olang_sb_done(ptr %s6)
  %t182 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l75, !tbaa !27
  %t189 = load ptr, ptr %l71, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l75, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t189, { i64, ptr } %t190)
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l6, ptr %l76, !tbaa !29
  %t191 = load ptr, ptr %l76, !tbaa !29
  store ptr %t191, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t192 = load ptr, ptr %l12, !tbaa !29
  store ptr %t192, ptr %l78, !tbaa !29
  %t193 = load i64, ptr %l13, !tbaa !24
  store i64 %t193, ptr %l79, !tbaa !24
  %t194 = load ptr, ptr %l78, !tbaa !29
  %t195 = load i64, ptr %l79, !tbaa !24
  %t196 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t194, i64 %t195)
  %t197 = extractvalue { i32, { i64, ptr } } %t196, 1
  %t198 = extractvalue { i32, { i64, ptr } } %t196, 0
  store i32 %t198, ptr %l81
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb36, label %ok.200
ok.200:
  store { i64, ptr } %t197, ptr %l80
  br label %bb35
bb35:
  %t201 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t201, ptr %l77, !tbaa !27
  br label %bb40
bb36:
  %t202 = load i32, ptr %l81, !tbaa !23
  %t203 = ashr i32 %t202, 16
  store i32 %t203, ptr %l82, !tbaa !23
  %t204 = load i32, ptr %l82, !tbaa !23
  %t205 = icmp eq i32 %t204, 1
  store i1 %t205, ptr %l83, !tbaa !21
  %t206 = load i1, ptr %l83, !tbaa !21
  br i1 %t206, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  %t207 = load i32, ptr %l81, !tbaa !23
  %t208 = lshr i32 %t207, 16
  %t209 = and i32 %t207, 65535
  %t210 = icmp eq i32 %t208, 1
  %t211 = select i1 %t210, i32 0, i32 0
  %t212 = icmp eq i32 %t207, 0
  %t213 = shl i32 %t211, 16
  %t214 = or i32 %t213, %t209
  %t215 = select i1 %t212, i32 0, i32 %t214
  store i32 %t215, ptr %l84, !tbaa !23
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t216 = load i32, ptr %l84, !tbaa !23
  %t217 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t216, 0
  store { i32, { i64, ptr } } %t217, ptr %rv
  br label %ret
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb40:
  %t218 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t218, ptr %l14, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t219, ptr %l85, !tbaa !27
  %t220 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l86, !tbaa !24
  %t222 = load i64, ptr %l86, !tbaa !24
  store i64 %t222, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t223 = load i64, ptr %l16, !tbaa !24
  store i64 %t223, ptr %l87, !tbaa !24
  %t224 = load i64, ptr %l15, !tbaa !24
  store i64 %t224, ptr %l88, !tbaa !24
  %t225 = load i64, ptr %l87, !tbaa !24
  %t226 = load i64, ptr %l88, !tbaa !24
  %t227 = icmp slt i64 %t225, %t226
  store i1 %t227, ptr %l89, !tbaa !21
  %t228 = load i1, ptr %l89, !tbaa !21
  %t229 = xor i1 %t228, true
  store i1 %t229, ptr %l90, !tbaa !21
  %t230 = load i1, ptr %l90, !tbaa !21
  br i1 %t230, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb43:
  br label %bb44
bb44:
  %t231 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t231, ptr %l91, !tbaa !27
  %t232 = load i64, ptr %l16, !tbaa !24
  store i64 %t232, ptr %l92, !tbaa !24
  %t233 = load i64, ptr %l92, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr { i64, ptr }, ptr %t235, i64 %t233
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !37
  store { i64, ptr } %t237, ptr %l93, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t238, ptr %l17, !tbaa !27
  %t239 = load ptr, ptr %l11, !tbaa !29
  store ptr %t239, ptr %l94, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t240, ptr %l95, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t241 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t242 = extractvalue { i64, ptr } %t241, 1
  %t243 = extractvalue { i64, ptr } %t241, 0
  call void @__olang_sb_put(ptr %s10, ptr %t242, i64 %t243)
  %t244 = load ptr, ptr %s10
  %t245 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t246 = load i64, ptr %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t244, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  store { i64, ptr } %t249, ptr %l96, !tbaa !27
  call void @__olang_sb_done(ptr %s10)
  %t250 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l97, !tbaa !27
  %t257 = load ptr, ptr %l94, !tbaa !29
  %t258 = load { i64, ptr }, ptr %l97, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t257, { i64, ptr } %t258)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t259 = load i64, ptr %l16, !tbaa !24
  store i64 %t259, ptr %l98, !tbaa !24
  %t260 = load i64, ptr %l98, !tbaa !24
  %t261 = add i64 %t260, 1
  store i64 %t261, ptr %l99, !tbaa !24
  %t262 = load i64, ptr %l99, !tbaa !24
  store i64 %t262, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb41
bb47:
  %t263 = load i64, ptr %l13, !tbaa !24
  store i64 %t263, ptr %l100, !tbaa !24
  %t264 = load i64, ptr %l15, !tbaa !24
  store i64 %t264, ptr %l101, !tbaa !24
  %t265 = load i64, ptr %l100, !tbaa !24
  %t266 = load i64, ptr %l101, !tbaa !24
  %t267 = add i64 %t265, %t266
  store i64 %t267, ptr %l102, !tbaa !24
  %t268 = load i64, ptr %l102, !tbaa !24
  store i64 %t268, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  br label %bb34
bb49:
  call void @__olang_scope_close(ptr %s7)
  %t269 = load ptr, ptr %l11, !tbaa !29
  store ptr %t269, ptr %l103, !tbaa !29
  %t270 = load ptr, ptr %l103, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t270, { i64, ptr } { i64 2, ptr @.d93 })
  br label %bb50
bb50:
  %t271 = load ptr, ptr %l11, !tbaa !29
  store ptr %t271, ptr %l104, !tbaa !29
  %t272 = load ptr, ptr %l104, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t272, { i64, ptr } { i64 2, ptr @.d94 })
  br label %bb51
bb51:
  %t273 = load ptr, ptr %l11, !tbaa !29
  store ptr %t273, ptr %l105, !tbaa !29
  %t274 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t274, ptr %l106, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t275 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  call void @__olang_sb_put(ptr %s12, ptr %t276, i64 %t277)
  %t278 = load ptr, ptr %s12
  %t279 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t280 = load i64, ptr %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t278, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l107, !tbaa !27
  call void @__olang_sb_done(ptr %s12)
  %t284 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l108, !tbaa !27
  %t291 = load ptr, ptr %l105, !tbaa !29
  %t292 = load { i64, ptr }, ptr %l108, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t291, { i64, ptr } %t292)
  br label %bb52
bb52:
  %t293 = load ptr, ptr %l11, !tbaa !29
  store ptr %t293, ptr %l109, !tbaa !29
  %t294 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t294, ptr %l110, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t295 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  call void @__olang_sb_put(ptr %s13, ptr %t296, i64 %t297)
  %t298 = load ptr, ptr %s13
  %t299 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t300 = load i64, ptr %t299
  %t301 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t298, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  store { i64, ptr } %t303, ptr %l111, !tbaa !27
  call void @__olang_sb_done(ptr %s13)
  %t304 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t304, 0
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l112, !tbaa !27
  %t311 = load ptr, ptr %l109, !tbaa !29
  %t312 = load { i64, ptr }, ptr %l112, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t311, { i64, ptr } %t312)
  br label %bb53
bb53:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l113, !tbaa !29
  %t314 = load ptr, ptr %l113, !tbaa !29
  %t315 = getelementptr %"compiler/build:compiles", ptr %t314, i32 0, i32 0
  store ptr %t315, ptr %l114, !tbaa !29
  %t316 = load ptr, ptr %l11, !tbaa !29
  store ptr %t316, ptr %l115, !tbaa !29
  %t317 = load ptr, ptr %l115, !tbaa !29
  %t318 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v1, ptr %v1, ptr %t317)
  store { i64, ptr } %t318, ptr %l116
  br label %bb54
bb54:
  %t319 = load ptr, ptr %l114, !tbaa !29
  %t320 = load { i64, ptr }, ptr %l116, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v1, ptr %v1, ptr %t319, { i64, ptr } %t320)
  br label %bb55
bb55:
  %t321 = load ptr, ptr %l1, !tbaa !29
  store ptr %t321, ptr %l117, !tbaa !29
  %t322 = load ptr, ptr %l117, !tbaa !29
  %t323 = getelementptr %"compiler/build:compiles", ptr %t322, i32 0, i32 1
  store ptr %t323, ptr %l118, !tbaa !29
  %t324 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t324, ptr %l119, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t325 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  call void @__olang_sb_put(ptr %s14, ptr %t326, i64 %t327)
  %t328 = load ptr, ptr %s14
  %t329 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t330 = load i64, ptr %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t328, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  store { i64, ptr } %t333, ptr %l120, !tbaa !27
  call void @__olang_sb_done(ptr %s14)
  %t334 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = extractvalue { i64, ptr } %t334, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  store { i64, ptr } %t340, ptr %l121, !tbaa !27
  %t341 = load ptr, ptr %l118, !tbaa !29
  %t342 = load { i64, ptr }, ptr %l121, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t341, { i64, ptr } %t342)
  br label %bb56
bb56:
  %t343 = load ptr, ptr %l1, !tbaa !29
  store ptr %t343, ptr %l122, !tbaa !29
  %t344 = load ptr, ptr %l122, !tbaa !29
  %t345 = getelementptr %"compiler/build:compiles", ptr %t344, i32 0, i32 2
  store ptr %t345, ptr %l123, !tbaa !29
  %t346 = load ptr, ptr %lp7
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !27
  store { i64, ptr } %t347, ptr %l124, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t348 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 1
  %t350 = extractvalue { i64, ptr } %t348, 0
  call void @__olang_sb_put(ptr %s15, ptr %t349, i64 %t350)
  %t351 = load ptr, ptr %s15
  %t352 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t353 = load i64, ptr %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t353)
  call void @llvm.memcpy.p0.p0.i64(ptr %t354, ptr %t351, i64 %t353, i1 false)
  %t355 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l125, !tbaa !27
  call void @__olang_sb_done(ptr %s15)
  %t357 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t358 = extractvalue { i64, ptr } %t357, 0
  %t359 = extractvalue { i64, ptr } %t357, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  store { i64, ptr } %t363, ptr %l126, !tbaa !27
  %t364 = load ptr, ptr %l123, !tbaa !29
  %t365 = load { i64, ptr }, ptr %l126, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t364, { i64, ptr } %t365)
  br label %bb57
bb57:
  %t366 = load ptr, ptr %l1, !tbaa !29
  store ptr %t366, ptr %l127, !tbaa !29
  %t367 = load ptr, ptr %l127, !tbaa !29
  %t368 = getelementptr %"compiler/build:compiles", ptr %t367, i32 0, i32 3
  store ptr %t368, ptr %l128, !tbaa !29
  %t369 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t369, ptr %l129, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t370 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  call void @__olang_sb_put(ptr %s16, ptr %t371, i64 %t372)
  %t373 = load ptr, ptr %s16
  %t374 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t375 = load i64, ptr %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t375)
  call void @llvm.memcpy.p0.p0.i64(ptr %t376, ptr %t373, i64 %t375, i1 false)
  %t377 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  store { i64, ptr } %t378, ptr %l130, !tbaa !27
  call void @__olang_sb_done(ptr %s16)
  %t379 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t380 = extractvalue { i64, ptr } %t379, 0
  %t381 = extractvalue { i64, ptr } %t379, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  store { i64, ptr } %t385, ptr %l131, !tbaa !27
  %t386 = load ptr, ptr %l128, !tbaa !29
  %t387 = load { i64, ptr }, ptr %l131, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t386, { i64, ptr } %t387)
  br label %bb58
bb58:
  %t388 = load ptr, ptr %lp7
  %t389 = load { i64, ptr }, ptr %t388, !tbaa !27
  store { i64, ptr } %t389, ptr %l132, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t390 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t391 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t390, 1
  store { i32, { i64, ptr } } %t391, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 9
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  %t6 = icmp sgt i64 %t5, 0
  store i1 %t6, ptr %l4, !tbaa !21
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  store ptr %t8, ptr %l5, !tbaa !29
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 9
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i64, ptr %l6, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call i64 @sysconf(i32 84)
  store i64 %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  store i64 %t15, ptr %l8, !tbaa !24
  %t16 = load i64, ptr %l8, !tbaa !24
  %t17 = icmp sgt i64 %t16, 0
  store i1 %t17, ptr %l9, !tbaa !21
  %t18 = load i1, ptr %l9, !tbaa !21
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l11, !tbaa !24
  store i64 %t20, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  store i64 1, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l10, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/build:Unit"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca %"compiler/build:Unit"
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca %"compiler/build:Unit"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l8, !tbaa !29
  %t4 = load ptr, ptr %l8, !tbaa !29
  store ptr %t4, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l1, !tbaa !29
  store ptr %t5, ptr %l10, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  store i64 %t6, ptr %l11, !tbaa !24
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = load i64, ptr %l11, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l13
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l13, !tbaa !23
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l14, !tbaa !23
  %t17 = load i32, ptr %l14, !tbaa !23
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l15, !tbaa !21
  %t19 = load i1, ptr %l15, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c95)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb7:
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t21, ptr %l16, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17, !tbaa !24
  %t24 = load i64, ptr %l17, !tbaa !24
  store i64 %t24, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5, !tbaa !24
  store i64 %t25, ptr %l18, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  store i64 %t26, ptr %l19, !tbaa !24
  %t27 = load i64, ptr %l18, !tbaa !24
  %t28 = load i64, ptr %l19, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l20, !tbaa !21
  %t30 = load i1, ptr %l20, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l21, !tbaa !21
  %t32 = load i1, ptr %l21, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  store i64 %t34, ptr %l23, !tbaa !24
  %t35 = load i64, ptr %l23, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/build:Unit", ptr %t37, i64 %t35
  %t39 = load %"compiler/build:Unit", ptr %t38
  store %"compiler/build:Unit" %t39, ptr %l24
  %t40 = load %"compiler/build:Unit", ptr %l24
  store %"compiler/build:Unit" %t40, ptr %l6
  %t41 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l25
  store ptr %l25, ptr %l26, !tbaa !29
  store i32 1, ptr %l27
  store ptr %l27, ptr %l28, !tbaa !29
  %t43 = load ptr, ptr %l26, !tbaa !29
  %t44 = load ptr, ptr %l28, !tbaa !29
  %t45 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %t43, ptr %t44)
  store i1 %t45, ptr %l29
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb16
bb14:
  %t47 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l31
  store ptr %l31, ptr %l32, !tbaa !29
  store i32 2, ptr %l33
  store ptr %l33, ptr %l34, !tbaa !29
  %t49 = load ptr, ptr %l32, !tbaa !29
  %t50 = load ptr, ptr %l34, !tbaa !29
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %t49, ptr %t50)
  store i1 %t51, ptr %l35
  br label %bb15
bb15:
  %t52 = load i1, ptr %l35, !tbaa !21
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t54 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  store { i64, ptr } %t55, ptr %l36, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t56 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  call void @__olang_sb_put(ptr %s5, ptr %t57, i64 %t58)
  %t59 = load ptr, ptr %s5
  %t60 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t59, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l37, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load i64, ptr %l5, !tbaa !24
  store i64 %t66, ptr %l38, !tbaa !24
  %t67 = load i64, ptr %l38, !tbaa !24
  %t68 = add i64 %t67, 1
  store i64 %t68, ptr %l39, !tbaa !24
  %t69 = load i64, ptr %l39, !tbaa !24
  store i64 %t69, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb8
bb21:
  %t70 = load i64, ptr %l2, !tbaa !24
  store i64 %t70, ptr %l40, !tbaa !24
  %t71 = load i64, ptr %l4, !tbaa !24
  store i64 %t71, ptr %l41, !tbaa !24
  %t72 = load i64, ptr %l40, !tbaa !24
  %t73 = load i64, ptr %l41, !tbaa !24
  %t74 = add i64 %t72, %t73
  store i64 %t74, ptr %l42, !tbaa !24
  %t75 = load i64, ptr %l42, !tbaa !24
  store i64 %t75, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb1
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l43, !tbaa !29
  %t77 = load ptr, ptr %l43, !tbaa !29
  %t78 = getelementptr %"compiler/build:Program", ptr %t77, i32 0, i32 0
  store ptr %t78, ptr %l44, !tbaa !29
  %t79 = load ptr, ptr %l44, !tbaa !29
  %t80 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t79)
  store i64 %t80, ptr %l45
  br label %bb24
bb24:
  %t81 = load i64, ptr %l45, !tbaa !24
  %t82 = icmp sgt i64 %t81, 0
  store i1 %t82, ptr %l46, !tbaa !21
  %t83 = load i1, ptr %l46, !tbaa !21
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t84 = load ptr, ptr %l0, !tbaa !29
  store ptr %t84, ptr %l48, !tbaa !29
  %t85 = load ptr, ptr %l48, !tbaa !29
  %t86 = getelementptr %"compiler/build:Program", ptr %t85, i32 0, i32 0
  store ptr %t86, ptr %l49, !tbaa !29
  %t87 = load ptr, ptr %l49, !tbaa !29
  %t88 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t87, i64 0)
  store %"compiler/build:Unit" %t88, ptr %l50
  br label %bb27
bb26:
  store { i64, ptr } { i64 1, ptr @.d96 }, ptr %l53, !tbaa !27
  %t89 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t89, ptr %l54, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l54, !tbaa !27
  store { i64, ptr } %t90, ptr %l47, !tbaa !27
  br label %bb28
bb27:
  %t91 = getelementptr %"compiler/build:Unit", ptr %l50, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  store { i64, ptr } %t92, ptr %l51, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t93 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  call void @__olang_sb_put(ptr %s7, ptr %t94, i64 %t95)
  %t96 = load ptr, ptr %s7
  %t97 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t98 = load i64, ptr %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t96, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l52, !tbaa !27
  call void @__olang_sb_done(ptr %s7)
  %t102 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t102, ptr %l47, !tbaa !27
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [8 x i8]
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca [1 x i8]
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca [1 x i8]
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i8
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/text:StringBuilder"
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l14, !tbaa !29
  %t2 = load ptr, ptr %l14, !tbaa !29
  %t3 = getelementptr %"compiler/build:Sha256", ptr %t2, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l15, !tbaa !24
  %t5 = load i64, ptr %l15, !tbaa !24
  store i64 %t5, ptr %l16, !tbaa !65
  %t6 = load i64, ptr %l16, !tbaa !65
  %t7 = mul i64 %t6, 8
  store i64 %t7, ptr %l17, !tbaa !65
  %t8 = load i64, ptr %l17, !tbaa !65
  store i64 %t8, ptr %l1, !tbaa !65
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l18, !tbaa !29
  %t10 = insertvalue [1 x i8] undef, i8 -128, 0
  store [1 x i8] %t10, ptr %l19
  %t11 = load [1 x i8], ptr %l19
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call ptr @__olang_scope_alloc(ptr %t12, i64 1)
  store [1 x i8] %t11, ptr %t13
  %t14 = insertvalue { i64, ptr } undef, i64 1, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l20, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l21, !tbaa !27
  %t23 = load ptr, ptr %l18, !tbaa !29
  %t24 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t23, { i64, ptr } %t24)
  br label %bb1
bb1:
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0, !tbaa !29
  store ptr %t25, ptr %l22, !tbaa !29
  %t26 = load ptr, ptr %l22, !tbaa !29
  %t27 = getelementptr %"compiler/build:Sha256", ptr %t26, i32 0, i32 2
  %t28 = load i64, ptr %t27, !tbaa !24
  store i64 %t28, ptr %l23, !tbaa !24
  %t29 = load i64, ptr %l23, !tbaa !24
  %t30 = icmp ne i64 %t29, 56
  store i1 %t30, ptr %l24, !tbaa !21
  %t31 = load i1, ptr %l24, !tbaa !21
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l25, !tbaa !21
  %t33 = load i1, ptr %l25, !tbaa !21
  br i1 %t33, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  %t35 = insertvalue [1 x i8] undef, i8 0, 0
  store [1 x i8] %t35, ptr %l27
  %t36 = load [1 x i8], ptr %l27
  %t37 = load ptr, ptr @__olang_prog_scope
  %t38 = call ptr @__olang_scope_alloc(ptr %t37, i64 1)
  store [1 x i8] %t36, ptr %t38
  %t39 = insertvalue { i64, ptr } undef, i64 1, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l29, !tbaa !27
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l29, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s1, ptr %t48, { i64, ptr } %t49)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb2
bb8:
  store [8 x i8] zeroinitializer, ptr %l2
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t50 = load i64, ptr %l4, !tbaa !24
  store i64 %t50, ptr %l30, !tbaa !24
  %t51 = load i64, ptr %l3, !tbaa !24
  store i64 %t51, ptr %l31, !tbaa !24
  %t52 = load i64, ptr %l30, !tbaa !24
  %t53 = load i64, ptr %l31, !tbaa !24
  %t54 = icmp sgt i64 %t52, %t53
  store i1 %t54, ptr %l32, !tbaa !21
  %t55 = load i1, ptr %l32, !tbaa !21
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t56 = load i64, ptr %l5, !tbaa !24
  store i64 %t56, ptr %l34, !tbaa !24
  %t57 = load i64, ptr %l34, !tbaa !24
  %t58 = icmp sgt i64 %t57, 0
  store i1 %t58, ptr %l35, !tbaa !21
  %t59 = load i1, ptr %l35, !tbaa !21
  br i1 %t59, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l33, !tbaa !24
  br label %bb14
bb11:
  %t60 = load i64, ptr %l4, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = load i64, ptr %l3, !tbaa !24
  store i64 %t61, ptr %l38, !tbaa !24
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = load i64, ptr %l38, !tbaa !24
  %t64 = sub i64 %t62, %t63
  store i64 %t64, ptr %l39, !tbaa !24
  %t65 = load i64, ptr %l5, !tbaa !24
  store i64 %t65, ptr %l40, !tbaa !24
  %t66 = load i64, ptr %l39, !tbaa !24
  %t67 = load i64, ptr %l40, !tbaa !24
  %t68 = add i64 %t66, %t67
  store i64 %t68, ptr %l41, !tbaa !24
  %t69 = load i64, ptr %l41, !tbaa !24
  %t70 = sub i64 %t69, 1
  store i64 %t70, ptr %l42, !tbaa !24
  %t71 = load i64, ptr %l5, !tbaa !24
  store i64 %t71, ptr %l43, !tbaa !24
  %t72 = load i64, ptr %l42, !tbaa !24
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = sdiv i64 %t72, %t73
  store i64 %t74, ptr %l44, !tbaa !24
  %t75 = load i64, ptr %l44, !tbaa !24
  store i64 %t75, ptr %l36, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l36, !tbaa !24
  br label %bb13
bb13:
  %t76 = load i64, ptr %l36, !tbaa !24
  store i64 %t76, ptr %l33, !tbaa !24
  br label %bb14
bb14:
  %t77 = load i64, ptr %l33, !tbaa !24
  store i64 %t77, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load i64, ptr %l7, !tbaa !24
  store i64 %t78, ptr %l45, !tbaa !24
  %t79 = load i64, ptr %l6, !tbaa !24
  store i64 %t79, ptr %l46, !tbaa !24
  %t80 = load i64, ptr %l45, !tbaa !24
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = icmp slt i64 %t80, %t81
  store i1 %t82, ptr %l47, !tbaa !21
  %t83 = load i1, ptr %l47, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l48, !tbaa !21
  %t85 = load i1, ptr %l48, !tbaa !21
  br i1 %t85, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %l49, !tbaa !24
  %t87 = load i64, ptr %l7, !tbaa !24
  store i64 %t87, ptr %l50, !tbaa !24
  %t88 = load i64, ptr %l5, !tbaa !24
  store i64 %t88, ptr %l51, !tbaa !24
  %t89 = load i64, ptr %l50, !tbaa !24
  %t90 = load i64, ptr %l51, !tbaa !24
  %t91 = mul i64 %t89, %t90
  store i64 %t91, ptr %l52, !tbaa !24
  %t92 = load i64, ptr %l49, !tbaa !24
  %t93 = load i64, ptr %l52, !tbaa !24
  %t94 = add i64 %t92, %t93
  store i64 %t94, ptr %l53, !tbaa !24
  %t95 = load i64, ptr %l53, !tbaa !24
  store i64 %t95, ptr %l8, !tbaa !24
  %t96 = load i64, ptr %l8, !tbaa !24
  store i64 %t96, ptr %l54, !tbaa !24
  %t97 = load i64, ptr %l1, !tbaa !65
  store i64 %t97, ptr %l55, !tbaa !65
  %t98 = load i64, ptr %l8, !tbaa !24
  store i64 %t98, ptr %l56, !tbaa !24
  %t99 = load i64, ptr %l56, !tbaa !24
  %t100 = mul i64 8, %t99
  store i64 %t100, ptr %l57, !tbaa !24
  %t101 = load i64, ptr %l57, !tbaa !24
  %t102 = sub i64 56, %t101
  store i64 %t102, ptr %l58, !tbaa !24
  %t103 = load i64, ptr %l58, !tbaa !24
  store i64 %t103, ptr %l59, !tbaa !65
  %t104 = load i64, ptr %l55, !tbaa !65
  %t105 = load i64, ptr %l59, !tbaa !65
  %t106 = load i64, ptr %l59, !tbaa !65
  %t107 = lshr i64 %t104, %t106
  store i64 %t107, ptr %l60, !tbaa !65
  %t108 = load i64, ptr %l60, !tbaa !65
  %t109 = trunc i64 %t108 to i8
  store i8 %t109, ptr %l61, !tbaa !22
  %t110 = load i8, ptr %l61, !tbaa !22
  %t111 = load i64, ptr %l54, !tbaa !24
  %t112 = getelementptr [8 x i8], ptr %l2, i64 0, i64 %t111
  store i8 %t110, ptr %t112, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load i64, ptr %l7, !tbaa !24
  store i64 %t113, ptr %l62, !tbaa !24
  %t114 = load i64, ptr %l62, !tbaa !24
  %t115 = add i64 %t114, 1
  store i64 %t115, ptr %l63, !tbaa !24
  %t116 = load i64, ptr %l63, !tbaa !24
  store i64 %t116, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb20:
  call void @__olang_scope_close(ptr %s2)
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l64, !tbaa !29
  store ptr %l2, ptr %l65
  %t118 = load ptr, ptr %l65
  %t119 = insertvalue { i64, ptr } undef, i64 8, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l66, !tbaa !27
  %t121 = load ptr, ptr %l64, !tbaa !29
  %t122 = load { i64, ptr }, ptr %l66, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t121, { i64, ptr } %t122)
  br label %bb21
bb21:
  %t123 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t123, ptr %l67
  br label %bb22
bb22:
  %t124 = load %"std/prelude/text:StringBuilder", ptr %l67
  store %"std/prelude/text:StringBuilder" %t124, ptr %l9
  store %olang.scope zeroinitializer, ptr %s5
  %t125 = load ptr, ptr %l0, !tbaa !29
  store ptr %t125, ptr %l68, !tbaa !29
  %t126 = load ptr, ptr %l68, !tbaa !29
  %t127 = getelementptr %"compiler/build:Sha256", ptr %t126, i32 0, i32 0
  store ptr %t127, ptr %l69
  %t128 = load ptr, ptr %l69
  store ptr %t128, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t129 = load ptr, ptr %l10
  store ptr %t129, ptr %l70
  %t130 = load ptr, ptr %l70
  store i64 8, ptr %l71, !tbaa !24
  %t131 = load i64, ptr %l71, !tbaa !24
  store i64 %t131, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t132 = load i64, ptr %l11, !tbaa !24
  store i64 %t132, ptr %l72, !tbaa !24
  %t133 = load i64, ptr %l12, !tbaa !24
  store i64 %t133, ptr %l73, !tbaa !24
  %t134 = load i64, ptr %l72, !tbaa !24
  %t135 = load i64, ptr %l73, !tbaa !24
  %t136 = icmp slt i64 %t134, %t135
  store i1 %t136, ptr %l74, !tbaa !21
  %t137 = load i1, ptr %l74, !tbaa !21
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l75, !tbaa !21
  %t139 = load i1, ptr %l75, !tbaa !21
  br i1 %t139, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t140 = load ptr, ptr %l10
  store ptr %t140, ptr %l76
  %t141 = load i64, ptr %l11, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  %t142 = load ptr, ptr %l76
  %t143 = load i64, ptr %l77, !tbaa !24
  %t144 = getelementptr [8 x i32], ptr %t142, i64 0, i64 %t143
  %t145 = load i32, ptr %t144, !tbaa !84
  store i32 %t145, ptr %l78, !tbaa !64
  %t146 = load i32, ptr %l78, !tbaa !64
  store i32 %t146, ptr %l13, !tbaa !64
  store ptr %l9, ptr %l79, !tbaa !29
  %t147 = load i32, ptr %l13, !tbaa !64
  store i32 %t147, ptr %l80, !tbaa !64
  %t148 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 16)
  %t149 = extractvalue { i32, i64 } %t148, 1
  %t150 = extractvalue { i32, i64 } %t148, 0
  store i32 %t150, ptr %l82
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb28, label %ok.152
ok.152:
  store i64 %t149, ptr %l81
  br label %bb27
bb27:
  %t153 = load i32, ptr %l80, !tbaa !64
  %t154 = load i64, ptr %l81, !tbaa !24
  %t155 = call { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %s6, i32 %t153, i64 %t154)
  store { i64, ptr } %t155, ptr %l83
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c97)
  unreachable
bb29:
  %t156 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l84, !tbaa !27
  %t163 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t164 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t163, i64 8, i8 48)
  store { i64, ptr } %t164, ptr %l85
  br label %bb30
bb30:
  %t165 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l86, !tbaa !27
  %t172 = load ptr, ptr %l79, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l86, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t172, { i64, ptr } %t173)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t174 = load i64, ptr %l11, !tbaa !24
  store i64 %t174, ptr %l87, !tbaa !24
  %t175 = load i64, ptr %l87, !tbaa !24
  %t176 = add i64 %t175, 1
  store i64 %t176, ptr %l88, !tbaa !24
  %t177 = load i64, ptr %l88, !tbaa !24
  store i64 %t177, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb33:
  call void @__olang_scope_close(ptr %s5)
  store ptr %l9, ptr %l89, !tbaa !29
  %t178 = load ptr, ptr %l89, !tbaa !29
  %t179 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t178)
  store { i64, ptr } %t179, ptr %l90
  br label %bb34
bb34:
  %t180 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t180, ptr %l91, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l92, !tbaa !24
  %t183 = load i64, ptr %l92, !tbaa !24
  %t184 = mul i64 %t183, 1
  %t185 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l93, !tbaa !27
  %t188 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t189 = load ptr, ptr %t188, !tbaa !27
  %t190 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t191 = load ptr, ptr %t190, !tbaa !27
  %t192 = load i64, ptr %l92, !tbaa !24
  %t193 = mul i64 %t192, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t189, ptr %t191, i64 %t193, i1 false)
  %t194 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t194, ptr %l91, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t195 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t195, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i8
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i8
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l4, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l5, !tbaa !24
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = getelementptr %"compiler/build:Sha256", ptr %t6, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  store i64 %t9, ptr %l8, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = add i64 %t10, %t11
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load i64, ptr %l9, !tbaa !24
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = getelementptr %"compiler/build:Sha256", ptr %t14, i32 0, i32 3
  store i64 %t13, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l10, !tbaa !29
  %t17 = load ptr, ptr %l10, !tbaa !29
  %t18 = getelementptr %"compiler/build:Sha256", ptr %t17, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  store i64 %t19, ptr %l11, !tbaa !24
  %t20 = load i64, ptr %l11, !tbaa !24
  %t21 = icmp sgt i64 %t20, 0
  store i1 %t21, ptr %l12, !tbaa !21
  %t22 = load i1, ptr %l12, !tbaa !21
  br i1 %t22, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l13, !tbaa !29
  %t24 = load ptr, ptr %l13, !tbaa !29
  %t25 = getelementptr %"compiler/build:Sha256", ptr %t24, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l14, !tbaa !24
  %t27 = load i64, ptr %l14, !tbaa !24
  %t28 = icmp slt i64 %t27, 64
  store i1 %t28, ptr %l15, !tbaa !21
  %t29 = load i1, ptr %l15, !tbaa !21
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l2, !tbaa !24
  store i64 %t30, ptr %l17, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load i64, ptr %l17, !tbaa !24
  %t33 = load i64, ptr %l18, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  store i1 %t34, ptr %l19, !tbaa !21
  %t35 = load i1, ptr %l19, !tbaa !21
  store i1 %t35, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l16, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  %t38 = load i1, ptr %l20, !tbaa !21
  br i1 %t38, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l21, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l22, !tbaa !29
  %t41 = load ptr, ptr %l22, !tbaa !29
  %t42 = getelementptr %"compiler/build:Sha256", ptr %t41, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  store i64 %t43, ptr %l23, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  store i64 %t45, ptr %l25, !tbaa !24
  %t46 = load i64, ptr %l25, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t46
  %t50 = load i8, ptr %t49, !tbaa !32
  store i8 %t50, ptr %l26, !tbaa !22
  %t51 = load i8, ptr %l26, !tbaa !22
  %t52 = load ptr, ptr %l21, !tbaa !29
  %t53 = getelementptr %"compiler/build:Sha256", ptr %t52, i32 0, i32 1
  %t54 = load i64, ptr %l23, !tbaa !24
  %t55 = getelementptr [64 x i8], ptr %t53, i64 0, i64 %t54
  store i8 %t51, ptr %t55, !tbaa !32
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l27, !tbaa !29
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = getelementptr %"compiler/build:Sha256", ptr %t57, i32 0, i32 2
  %t59 = load i64, ptr %t58, !tbaa !24
  store i64 %t59, ptr %l28, !tbaa !24
  %t60 = load i64, ptr %l28, !tbaa !24
  %t61 = add i64 %t60, 1
  store i64 %t61, ptr %l29, !tbaa !24
  %t62 = load i64, ptr %l29, !tbaa !24
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t64 = getelementptr %"compiler/build:Sha256", ptr %t63, i32 0, i32 2
  store i64 %t62, ptr %t64, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  store i64 %t65, ptr %l30, !tbaa !24
  %t66 = load i64, ptr %l30, !tbaa !24
  %t67 = add i64 %t66, 1
  store i64 %t67, ptr %l31, !tbaa !24
  %t68 = load i64, ptr %l31, !tbaa !24
  store i64 %t68, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l32, !tbaa !29
  %t70 = load ptr, ptr %l32, !tbaa !29
  %t71 = getelementptr %"compiler/build:Sha256", ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  store i64 %t72, ptr %l33, !tbaa !24
  %t73 = load i64, ptr %l33, !tbaa !24
  %t74 = icmp slt i64 %t73, 64
  store i1 %t74, ptr %l34, !tbaa !21
  %t75 = load i1, ptr %l34, !tbaa !21
  br i1 %t75, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  store ptr %t76, ptr %l35, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l36, !tbaa !29
  %t78 = load ptr, ptr %l36, !tbaa !29
  %t79 = getelementptr %"compiler/build:Sha256", ptr %t78, i32 0, i32 1
  store ptr %t79, ptr %l37
  %t80 = load ptr, ptr %l37
  %t81 = insertvalue { i64, ptr } undef, i64 64, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l38, !tbaa !27
  %t83 = load ptr, ptr %l35, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l38, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v0, ptr %t83, { i64, ptr } %t84, i64 0)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l39, !tbaa !29
  %t86 = load ptr, ptr %l39, !tbaa !29
  %t87 = getelementptr %"compiler/build:Sha256", ptr %t86, i32 0, i32 2
  store i64 0, ptr %t87, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load i64, ptr %l2, !tbaa !24
  store i64 %t88, ptr %l40, !tbaa !24
  %t89 = load i64, ptr %l40, !tbaa !24
  %t90 = add i64 %t89, 64
  store i64 %t90, ptr %l41, !tbaa !24
  %t91 = load i64, ptr %l3, !tbaa !24
  store i64 %t91, ptr %l42, !tbaa !24
  %t92 = load i64, ptr %l41, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  store i1 %t94, ptr %l43, !tbaa !21
  %t95 = load i1, ptr %l43, !tbaa !21
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l44, !tbaa !21
  %t97 = load i1, ptr %l44, !tbaa !21
  br i1 %t97, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l45, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t99, ptr %l46, !tbaa !27
  %t100 = load i64, ptr %l2, !tbaa !24
  store i64 %t100, ptr %l47, !tbaa !24
  %t101 = load ptr, ptr %l45, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t103 = load i64, ptr %l47, !tbaa !24
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %t102, i64 %t103)
  br label %bb21
bb21:
  %t104 = load i64, ptr %l2, !tbaa !24
  store i64 %t104, ptr %l48, !tbaa !24
  %t105 = load i64, ptr %l48, !tbaa !24
  %t106 = add i64 %t105, 64
  store i64 %t106, ptr %l49, !tbaa !24
  %t107 = load i64, ptr %l49, !tbaa !24
  store i64 %t107, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  br label %bb17
bb23:
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load i64, ptr %l2, !tbaa !24
  store i64 %t108, ptr %l50, !tbaa !24
  %t109 = load i64, ptr %l3, !tbaa !24
  store i64 %t109, ptr %l51, !tbaa !24
  %t110 = load i64, ptr %l50, !tbaa !24
  %t111 = load i64, ptr %l51, !tbaa !24
  %t112 = icmp slt i64 %t110, %t111
  store i1 %t112, ptr %l52, !tbaa !21
  %t113 = load i1, ptr %l52, !tbaa !21
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l53, !tbaa !21
  %t115 = load i1, ptr %l53, !tbaa !21
  br i1 %t115, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  store ptr %t116, ptr %l54, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  store ptr %t117, ptr %l55, !tbaa !29
  %t118 = load ptr, ptr %l55, !tbaa !29
  %t119 = getelementptr %"compiler/build:Sha256", ptr %t118, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  store i64 %t120, ptr %l56, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t121, ptr %l57, !tbaa !27
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %l58, !tbaa !24
  %t123 = load i64, ptr %l58, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t123
  %t127 = load i8, ptr %t126, !tbaa !32
  store i8 %t127, ptr %l59, !tbaa !22
  %t128 = load i8, ptr %l59, !tbaa !22
  %t129 = load ptr, ptr %l54, !tbaa !29
  %t130 = getelementptr %"compiler/build:Sha256", ptr %t129, i32 0, i32 1
  %t131 = load i64, ptr %l56, !tbaa !24
  %t132 = getelementptr [64 x i8], ptr %t130, i64 0, i64 %t131
  store i8 %t128, ptr %t132, !tbaa !32
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l60, !tbaa !29
  %t134 = load ptr, ptr %l60, !tbaa !29
  %t135 = getelementptr %"compiler/build:Sha256", ptr %t134, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  store i64 %t136, ptr %l61, !tbaa !24
  %t137 = load i64, ptr %l61, !tbaa !24
  %t138 = add i64 %t137, 1
  store i64 %t138, ptr %l62, !tbaa !24
  %t139 = load i64, ptr %l62, !tbaa !24
  %t140 = load ptr, ptr %l60, !tbaa !29
  %t141 = getelementptr %"compiler/build:Sha256", ptr %t140, i32 0, i32 2
  store i64 %t139, ptr %t141, !tbaa !24
  %t142 = load i64, ptr %l2, !tbaa !24
  store i64 %t142, ptr %l63, !tbaa !24
  %t143 = load i64, ptr %l63, !tbaa !24
  %t144 = add i64 %t143, 1
  store i64 %t144, ptr %l64, !tbaa !24
  %t145 = load i64, ptr %l64, !tbaa !24
  store i64 %t145, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  br label %bb24
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i8
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i8
  %l76 = alloca i32
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i8
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i8
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i32
  %l121 = alloca i32
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i32
  %l125 = alloca i32
  %l126 = alloca i32
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i32
  %l130 = alloca i32
  %l131 = alloca i32
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i32
  %l135 = alloca i32
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca i32
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i32
  %l144 = alloca i32
  %l145 = alloca i32
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i32
  %l150 = alloca i32
  %l151 = alloca i32
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i32
  %l157 = alloca i32
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca ptr
  %l169 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca ptr
  %l173 = alloca i32
  %l174 = alloca ptr
  %l175 = alloca i32
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i1
  %l179 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i1
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i64
  %l187 = alloca i64
  %l188 = alloca i64
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i64
  %l192 = alloca i64
  %l193 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i32
  %l201 = alloca i32
  %l202 = alloca i32
  %l203 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i32
  %l208 = alloca i32
  %l209 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i32
  %l212 = alloca i32
  %l213 = alloca i32
  %l214 = alloca i32
  %l215 = alloca i32
  %l216 = alloca i32
  %l217 = alloca i32
  %l218 = alloca i32
  %l219 = alloca i32
  %l220 = alloca i32
  %l221 = alloca i64
  %l222 = alloca i32
  %l223 = alloca i32
  %l224 = alloca i64
  %l225 = alloca i32
  %l226 = alloca i32
  %l227 = alloca i32
  %l228 = alloca i32
  %l229 = alloca i32
  %l230 = alloca i32
  %l231 = alloca i32
  %l232 = alloca i32
  %l233 = alloca i32
  %l234 = alloca i32
  %l235 = alloca i32
  %l236 = alloca i32
  %l237 = alloca i32
  %l238 = alloca i32
  %l239 = alloca i32
  %l240 = alloca i32
  %l241 = alloca i32
  %l242 = alloca i32
  %l243 = alloca i32
  %l244 = alloca i32
  %l245 = alloca i32
  %l246 = alloca i32
  %l247 = alloca i32
  %l248 = alloca i32
  %l249 = alloca i32
  %l250 = alloca i32
  %l251 = alloca i32
  %l252 = alloca i32
  %l253 = alloca i32
  %l254 = alloca i32
  %l255 = alloca i32
  %l256 = alloca i32
  %l257 = alloca i32
  %l258 = alloca i32
  %l259 = alloca i32
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca ptr
  %l263 = alloca i32
  %l264 = alloca i32
  %l265 = alloca i32
  %l266 = alloca ptr
  %l267 = alloca i32
  %l268 = alloca i32
  %l269 = alloca i32
  %l270 = alloca ptr
  %l271 = alloca i32
  %l272 = alloca i32
  %l273 = alloca i32
  %l274 = alloca ptr
  %l275 = alloca i32
  %l276 = alloca i32
  %l277 = alloca i32
  %l278 = alloca ptr
  %l279 = alloca i32
  %l280 = alloca i32
  %l281 = alloca i32
  %l282 = alloca ptr
  %l283 = alloca i32
  %l284 = alloca i32
  %l285 = alloca i32
  %l286 = alloca ptr
  %l287 = alloca i32
  %l288 = alloca i32
  %l289 = alloca i32
  %l290 = alloca ptr
  %l291 = alloca i32
  %l292 = alloca i32
  %l293 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [64 x i32] zeroinitializer, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t1 = load i64, ptr %l5, !tbaa !24
  store i64 %t1, ptr %l38, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  store i64 %t2, ptr %l39, !tbaa !24
  %t3 = load i64, ptr %l38, !tbaa !24
  %t4 = load i64, ptr %l39, !tbaa !24
  %t5 = icmp sgt i64 %t3, %t4
  store i1 %t5, ptr %l40, !tbaa !21
  %t6 = load i1, ptr %l40, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  store i64 %t7, ptr %l42, !tbaa !24
  %t8 = load i64, ptr %l42, !tbaa !24
  %t9 = icmp sgt i64 %t8, 0
  store i1 %t9, ptr %l43, !tbaa !21
  %t10 = load i1, ptr %l43, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  store i64 %t11, ptr %l45, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  store i64 %t12, ptr %l46, !tbaa !24
  %t13 = load i64, ptr %l45, !tbaa !24
  %t14 = load i64, ptr %l46, !tbaa !24
  %t15 = sub i64 %t13, %t14
  store i64 %t15, ptr %l47, !tbaa !24
  %t16 = load i64, ptr %l6, !tbaa !24
  store i64 %t16, ptr %l48, !tbaa !24
  %t17 = load i64, ptr %l47, !tbaa !24
  %t18 = load i64, ptr %l48, !tbaa !24
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %l49, !tbaa !24
  %t20 = load i64, ptr %l49, !tbaa !24
  %t21 = sub i64 %t20, 1
  store i64 %t21, ptr %l50, !tbaa !24
  %t22 = load i64, ptr %l6, !tbaa !24
  store i64 %t22, ptr %l51, !tbaa !24
  %t23 = load i64, ptr %l50, !tbaa !24
  %t24 = load i64, ptr %l51, !tbaa !24
  %t25 = sdiv i64 %t23, %t24
  store i64 %t25, ptr %l52, !tbaa !24
  %t26 = load i64, ptr %l52, !tbaa !24
  store i64 %t26, ptr %l44, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l44, !tbaa !24
  store i64 %t27, ptr %l41, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l41, !tbaa !24
  store i64 %t28, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l8, !tbaa !24
  store i64 %t29, ptr %l53, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  store i64 %t30, ptr %l54, !tbaa !24
  %t31 = load i64, ptr %l53, !tbaa !24
  %t32 = load i64, ptr %l54, !tbaa !24
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l55, !tbaa !21
  %t34 = load i1, ptr %l55, !tbaa !21
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l56, !tbaa !21
  %t36 = load i1, ptr %l56, !tbaa !21
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l4, !tbaa !24
  store i64 %t37, ptr %l57, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  store i64 %t38, ptr %l58, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  store i64 %t39, ptr %l59, !tbaa !24
  %t40 = load i64, ptr %l58, !tbaa !24
  %t41 = load i64, ptr %l59, !tbaa !24
  %t42 = mul i64 %t40, %t41
  store i64 %t42, ptr %l60, !tbaa !24
  %t43 = load i64, ptr %l57, !tbaa !24
  %t44 = load i64, ptr %l60, !tbaa !24
  %t45 = add i64 %t43, %t44
  store i64 %t45, ptr %l61, !tbaa !24
  %t46 = load i64, ptr %l61, !tbaa !24
  store i64 %t46, ptr %l9, !tbaa !24
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l62, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  store i64 %t48, ptr %l63, !tbaa !24
  %t49 = load i64, ptr %l63, !tbaa !24
  %t50 = mul i64 %t49, 4
  store i64 %t50, ptr %l64, !tbaa !24
  %t51 = load i64, ptr %l62, !tbaa !24
  %t52 = load i64, ptr %l64, !tbaa !24
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l65, !tbaa !24
  %t54 = load i64, ptr %l65, !tbaa !24
  store i64 %t54, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  store i64 %t55, ptr %l66, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t56, ptr %l67, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  store i64 %t57, ptr %l68, !tbaa !24
  %t58 = load i64, ptr %l68, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t58
  %t62 = load i8, ptr %t61, !tbaa !32
  store i8 %t62, ptr %l69, !tbaa !22
  %t63 = load i8, ptr %l69, !tbaa !22
  %t64 = zext i8 %t63 to i32
  store i32 %t64, ptr %l70, !tbaa !64
  %t65 = load i32, ptr %l70, !tbaa !64
  %t66 = shl i32 %t65, 24
  store i32 %t66, ptr %l71, !tbaa !64
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t67, ptr %l72, !tbaa !27
  %t68 = load i64, ptr %l10, !tbaa !24
  store i64 %t68, ptr %l73, !tbaa !24
  %t69 = load i64, ptr %l73, !tbaa !24
  %t70 = add i64 %t69, 1
  store i64 %t70, ptr %l74, !tbaa !24
  %t71 = load i64, ptr %l74, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t71
  %t75 = load i8, ptr %t74, !tbaa !32
  store i8 %t75, ptr %l75, !tbaa !22
  %t76 = load i8, ptr %l75, !tbaa !22
  %t77 = zext i8 %t76 to i32
  store i32 %t77, ptr %l76, !tbaa !64
  %t78 = load i32, ptr %l76, !tbaa !64
  %t79 = shl i32 %t78, 16
  store i32 %t79, ptr %l77, !tbaa !64
  %t80 = load i32, ptr %l71, !tbaa !64
  %t81 = load i32, ptr %l77, !tbaa !64
  %t82 = or i32 %t80, %t81
  store i32 %t82, ptr %l78, !tbaa !64
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t83, ptr %l79, !tbaa !27
  %t84 = load i64, ptr %l10, !tbaa !24
  store i64 %t84, ptr %l80, !tbaa !24
  %t85 = load i64, ptr %l80, !tbaa !24
  %t86 = add i64 %t85, 2
  store i64 %t86, ptr %l81, !tbaa !24
  %t87 = load i64, ptr %l81, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t87
  %t91 = load i8, ptr %t90, !tbaa !32
  store i8 %t91, ptr %l82, !tbaa !22
  %t92 = load i8, ptr %l82, !tbaa !22
  %t93 = zext i8 %t92 to i32
  store i32 %t93, ptr %l83, !tbaa !64
  %t94 = load i32, ptr %l83, !tbaa !64
  %t95 = shl i32 %t94, 8
  store i32 %t95, ptr %l84, !tbaa !64
  %t96 = load i32, ptr %l78, !tbaa !64
  %t97 = load i32, ptr %l84, !tbaa !64
  %t98 = or i32 %t96, %t97
  store i32 %t98, ptr %l85, !tbaa !64
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t99, ptr %l86, !tbaa !27
  %t100 = load i64, ptr %l10, !tbaa !24
  store i64 %t100, ptr %l87, !tbaa !24
  %t101 = load i64, ptr %l87, !tbaa !24
  %t102 = add i64 %t101, 3
  store i64 %t102, ptr %l88, !tbaa !24
  %t103 = load i64, ptr %l88, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i8, ptr %t105, i64 %t103
  %t107 = load i8, ptr %t106, !tbaa !32
  store i8 %t107, ptr %l89, !tbaa !22
  %t108 = load i8, ptr %l89, !tbaa !22
  %t109 = zext i8 %t108 to i32
  store i32 %t109, ptr %l90, !tbaa !64
  %t110 = load i32, ptr %l85, !tbaa !64
  %t111 = load i32, ptr %l90, !tbaa !64
  %t112 = or i32 %t110, %t111
  store i32 %t112, ptr %l91, !tbaa !64
  %t113 = load i32, ptr %l91, !tbaa !64
  %t114 = load i64, ptr %l66, !tbaa !24
  %t115 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t114
  store i32 %t113, ptr %t115, !tbaa !84
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t116 = load i64, ptr %l8, !tbaa !24
  store i64 %t116, ptr %l92, !tbaa !24
  %t117 = load i64, ptr %l92, !tbaa !24
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l93, !tbaa !24
  %t119 = load i64, ptr %l93, !tbaa !24
  store i64 %t119, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb7
bb12:
  call void @__olang_scope_close(ptr %s1)
  store %olang.scope zeroinitializer, ptr %s4
  store i64 16, ptr %l11, !tbaa !24
  store i64 64, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  store i64 %t120, ptr %l94, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  store i64 %t121, ptr %l95, !tbaa !24
  %t122 = load i64, ptr %l94, !tbaa !24
  %t123 = load i64, ptr %l95, !tbaa !24
  %t124 = icmp sgt i64 %t122, %t123
  store i1 %t124, ptr %l96, !tbaa !21
  %t125 = load i1, ptr %l96, !tbaa !21
  br i1 %t125, label %bb13, label %bb14
bb13:
  %t126 = load i64, ptr %l13, !tbaa !24
  store i64 %t126, ptr %l98, !tbaa !24
  %t127 = load i64, ptr %l98, !tbaa !24
  %t128 = icmp sgt i64 %t127, 0
  store i1 %t128, ptr %l99, !tbaa !21
  %t129 = load i1, ptr %l99, !tbaa !21
  br i1 %t129, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb18
bb15:
  %t130 = load i64, ptr %l12, !tbaa !24
  store i64 %t130, ptr %l101, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  store i64 %t131, ptr %l102, !tbaa !24
  %t132 = load i64, ptr %l101, !tbaa !24
  %t133 = load i64, ptr %l102, !tbaa !24
  %t134 = sub i64 %t132, %t133
  store i64 %t134, ptr %l103, !tbaa !24
  %t135 = load i64, ptr %l13, !tbaa !24
  store i64 %t135, ptr %l104, !tbaa !24
  %t136 = load i64, ptr %l103, !tbaa !24
  %t137 = load i64, ptr %l104, !tbaa !24
  %t138 = add i64 %t136, %t137
  store i64 %t138, ptr %l105, !tbaa !24
  %t139 = load i64, ptr %l105, !tbaa !24
  %t140 = sub i64 %t139, 1
  store i64 %t140, ptr %l106, !tbaa !24
  %t141 = load i64, ptr %l13, !tbaa !24
  store i64 %t141, ptr %l107, !tbaa !24
  %t142 = load i64, ptr %l106, !tbaa !24
  %t143 = load i64, ptr %l107, !tbaa !24
  %t144 = sdiv i64 %t142, %t143
  store i64 %t144, ptr %l108, !tbaa !24
  %t145 = load i64, ptr %l108, !tbaa !24
  store i64 %t145, ptr %l100, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb17
bb17:
  %t146 = load i64, ptr %l100, !tbaa !24
  store i64 %t146, ptr %l97, !tbaa !24
  br label %bb18
bb18:
  %t147 = load i64, ptr %l97, !tbaa !24
  store i64 %t147, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load i64, ptr %l15, !tbaa !24
  store i64 %t148, ptr %l109, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  store i64 %t149, ptr %l110, !tbaa !24
  %t150 = load i64, ptr %l109, !tbaa !24
  %t151 = load i64, ptr %l110, !tbaa !24
  %t152 = icmp slt i64 %t150, %t151
  store i1 %t152, ptr %l111, !tbaa !21
  %t153 = load i1, ptr %l111, !tbaa !21
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l112, !tbaa !21
  %t155 = load i1, ptr %l112, !tbaa !21
  br i1 %t155, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t156 = load i64, ptr %l11, !tbaa !24
  store i64 %t156, ptr %l113, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  store i64 %t157, ptr %l114, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  store i64 %t158, ptr %l115, !tbaa !24
  %t159 = load i64, ptr %l114, !tbaa !24
  %t160 = load i64, ptr %l115, !tbaa !24
  %t161 = mul i64 %t159, %t160
  store i64 %t161, ptr %l116, !tbaa !24
  %t162 = load i64, ptr %l113, !tbaa !24
  %t163 = load i64, ptr %l116, !tbaa !24
  %t164 = add i64 %t162, %t163
  store i64 %t164, ptr %l117, !tbaa !24
  %t165 = load i64, ptr %l117, !tbaa !24
  store i64 %t165, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  store i64 %t166, ptr %l118, !tbaa !24
  %t167 = load i64, ptr %l118, !tbaa !24
  %t168 = sub i64 %t167, 15
  store i64 %t168, ptr %l119, !tbaa !24
  %t169 = load i64, ptr %l119, !tbaa !24
  %t170 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t169
  %t171 = load i32, ptr %t170, !tbaa !84
  store i32 %t171, ptr %l120, !tbaa !64
  %t172 = load i32, ptr %l120, !tbaa !64
  %t173 = call i32 @compiler_2fbuild_2erotr(i32 %t172, i32 7)
  store i32 %t173, ptr %l121
  br label %bb23
bb23:
  %t174 = load i64, ptr %l16, !tbaa !24
  store i64 %t174, ptr %l122, !tbaa !24
  %t175 = load i64, ptr %l122, !tbaa !24
  %t176 = sub i64 %t175, 15
  store i64 %t176, ptr %l123, !tbaa !24
  %t177 = load i64, ptr %l123, !tbaa !24
  %t178 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t177
  %t179 = load i32, ptr %t178, !tbaa !84
  store i32 %t179, ptr %l124, !tbaa !64
  %t180 = load i32, ptr %l124, !tbaa !64
  %t181 = call i32 @compiler_2fbuild_2erotr(i32 %t180, i32 18)
  store i32 %t181, ptr %l125
  br label %bb24
bb24:
  %t182 = load i32, ptr %l121, !tbaa !64
  %t183 = load i32, ptr %l125, !tbaa !64
  %t184 = xor i32 %t182, %t183
  store i32 %t184, ptr %l126, !tbaa !64
  %t185 = load i64, ptr %l16, !tbaa !24
  store i64 %t185, ptr %l127, !tbaa !24
  %t186 = load i64, ptr %l127, !tbaa !24
  %t187 = sub i64 %t186, 15
  store i64 %t187, ptr %l128, !tbaa !24
  %t188 = load i64, ptr %l128, !tbaa !24
  %t189 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t188
  %t190 = load i32, ptr %t189, !tbaa !84
  store i32 %t190, ptr %l129, !tbaa !64
  %t191 = load i32, ptr %l129, !tbaa !64
  %t192 = lshr i32 %t191, 3
  store i32 %t192, ptr %l130, !tbaa !64
  %t193 = load i32, ptr %l126, !tbaa !64
  %t194 = load i32, ptr %l130, !tbaa !64
  %t195 = xor i32 %t193, %t194
  store i32 %t195, ptr %l131, !tbaa !64
  %t196 = load i32, ptr %l131, !tbaa !64
  store i32 %t196, ptr %l17, !tbaa !64
  %t197 = load i64, ptr %l16, !tbaa !24
  store i64 %t197, ptr %l132, !tbaa !24
  %t198 = load i64, ptr %l132, !tbaa !24
  %t199 = sub i64 %t198, 2
  store i64 %t199, ptr %l133, !tbaa !24
  %t200 = load i64, ptr %l133, !tbaa !24
  %t201 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t200
  %t202 = load i32, ptr %t201, !tbaa !84
  store i32 %t202, ptr %l134, !tbaa !64
  %t203 = load i32, ptr %l134, !tbaa !64
  %t204 = call i32 @compiler_2fbuild_2erotr(i32 %t203, i32 17)
  store i32 %t204, ptr %l135
  br label %bb25
bb25:
  %t205 = load i64, ptr %l16, !tbaa !24
  store i64 %t205, ptr %l136, !tbaa !24
  %t206 = load i64, ptr %l136, !tbaa !24
  %t207 = sub i64 %t206, 2
  store i64 %t207, ptr %l137, !tbaa !24
  %t208 = load i64, ptr %l137, !tbaa !24
  %t209 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t208
  %t210 = load i32, ptr %t209, !tbaa !84
  store i32 %t210, ptr %l138, !tbaa !64
  %t211 = load i32, ptr %l138, !tbaa !64
  %t212 = call i32 @compiler_2fbuild_2erotr(i32 %t211, i32 19)
  store i32 %t212, ptr %l139
  br label %bb26
bb26:
  %t213 = load i32, ptr %l135, !tbaa !64
  %t214 = load i32, ptr %l139, !tbaa !64
  %t215 = xor i32 %t213, %t214
  store i32 %t215, ptr %l140, !tbaa !64
  %t216 = load i64, ptr %l16, !tbaa !24
  store i64 %t216, ptr %l141, !tbaa !24
  %t217 = load i64, ptr %l141, !tbaa !24
  %t218 = sub i64 %t217, 2
  store i64 %t218, ptr %l142, !tbaa !24
  %t219 = load i64, ptr %l142, !tbaa !24
  %t220 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t219
  %t221 = load i32, ptr %t220, !tbaa !84
  store i32 %t221, ptr %l143, !tbaa !64
  %t222 = load i32, ptr %l143, !tbaa !64
  %t223 = lshr i32 %t222, 10
  store i32 %t223, ptr %l144, !tbaa !64
  %t224 = load i32, ptr %l140, !tbaa !64
  %t225 = load i32, ptr %l144, !tbaa !64
  %t226 = xor i32 %t224, %t225
  store i32 %t226, ptr %l145, !tbaa !64
  %t227 = load i32, ptr %l145, !tbaa !64
  store i32 %t227, ptr %l18, !tbaa !64
  %t228 = load i64, ptr %l16, !tbaa !24
  store i64 %t228, ptr %l146, !tbaa !24
  %t229 = load i64, ptr %l16, !tbaa !24
  store i64 %t229, ptr %l147, !tbaa !24
  %t230 = load i64, ptr %l147, !tbaa !24
  %t231 = sub i64 %t230, 16
  store i64 %t231, ptr %l148, !tbaa !24
  %t232 = load i64, ptr %l148, !tbaa !24
  %t233 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t232
  %t234 = load i32, ptr %t233, !tbaa !84
  store i32 %t234, ptr %l149, !tbaa !64
  %t235 = load i32, ptr %l17, !tbaa !64
  store i32 %t235, ptr %l150, !tbaa !64
  %t236 = load i32, ptr %l149, !tbaa !64
  %t237 = load i32, ptr %l150, !tbaa !64
  %t238 = add i32 %t236, %t237
  store i32 %t238, ptr %l151, !tbaa !64
  %t239 = load i64, ptr %l16, !tbaa !24
  store i64 %t239, ptr %l152, !tbaa !24
  %t240 = load i64, ptr %l152, !tbaa !24
  %t241 = sub i64 %t240, 7
  store i64 %t241, ptr %l153, !tbaa !24
  %t242 = load i64, ptr %l153, !tbaa !24
  %t243 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t242
  %t244 = load i32, ptr %t243, !tbaa !84
  store i32 %t244, ptr %l154, !tbaa !64
  %t245 = load i32, ptr %l151, !tbaa !64
  %t246 = load i32, ptr %l154, !tbaa !64
  %t247 = add i32 %t245, %t246
  store i32 %t247, ptr %l155, !tbaa !64
  %t248 = load i32, ptr %l18, !tbaa !64
  store i32 %t248, ptr %l156, !tbaa !64
  %t249 = load i32, ptr %l155, !tbaa !64
  %t250 = load i32, ptr %l156, !tbaa !64
  %t251 = add i32 %t249, %t250
  store i32 %t251, ptr %l157, !tbaa !64
  %t252 = load i32, ptr %l157, !tbaa !64
  %t253 = load i64, ptr %l146, !tbaa !24
  %t254 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t253
  store i32 %t252, ptr %t254, !tbaa !84
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t255 = load i64, ptr %l15, !tbaa !24
  store i64 %t255, ptr %l158, !tbaa !24
  %t256 = load i64, ptr %l158, !tbaa !24
  %t257 = add i64 %t256, 1
  store i64 %t257, ptr %l159, !tbaa !24
  %t258 = load i64, ptr %l159, !tbaa !24
  store i64 %t258, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb19
bb28:
  call void @__olang_scope_close(ptr %s4)
  %t259 = load ptr, ptr %l0, !tbaa !29
  store ptr %t259, ptr %l160, !tbaa !29
  %t260 = load ptr, ptr %l160, !tbaa !29
  %t261 = getelementptr %"compiler/build:Sha256", ptr %t260, i32 0, i32 0
  %t262 = getelementptr [8 x i32], ptr %t261, i64 0, i64 0
  %t263 = load i32, ptr %t262, !tbaa !84
  store i32 %t263, ptr %l161, !tbaa !64
  %t264 = load i32, ptr %l161, !tbaa !64
  store i32 %t264, ptr %l19, !tbaa !64
  %t265 = load ptr, ptr %l0, !tbaa !29
  store ptr %t265, ptr %l162, !tbaa !29
  %t266 = load ptr, ptr %l162, !tbaa !29
  %t267 = getelementptr %"compiler/build:Sha256", ptr %t266, i32 0, i32 0
  %t268 = getelementptr [8 x i32], ptr %t267, i64 0, i64 1
  %t269 = load i32, ptr %t268, !tbaa !84
  store i32 %t269, ptr %l163, !tbaa !64
  %t270 = load i32, ptr %l163, !tbaa !64
  store i32 %t270, ptr %l20, !tbaa !64
  %t271 = load ptr, ptr %l0, !tbaa !29
  store ptr %t271, ptr %l164, !tbaa !29
  %t272 = load ptr, ptr %l164, !tbaa !29
  %t273 = getelementptr %"compiler/build:Sha256", ptr %t272, i32 0, i32 0
  %t274 = getelementptr [8 x i32], ptr %t273, i64 0, i64 2
  %t275 = load i32, ptr %t274, !tbaa !84
  store i32 %t275, ptr %l165, !tbaa !64
  %t276 = load i32, ptr %l165, !tbaa !64
  store i32 %t276, ptr %l21, !tbaa !64
  %t277 = load ptr, ptr %l0, !tbaa !29
  store ptr %t277, ptr %l166, !tbaa !29
  %t278 = load ptr, ptr %l166, !tbaa !29
  %t279 = getelementptr %"compiler/build:Sha256", ptr %t278, i32 0, i32 0
  %t280 = getelementptr [8 x i32], ptr %t279, i64 0, i64 3
  %t281 = load i32, ptr %t280, !tbaa !84
  store i32 %t281, ptr %l167, !tbaa !64
  %t282 = load i32, ptr %l167, !tbaa !64
  store i32 %t282, ptr %l22, !tbaa !64
  %t283 = load ptr, ptr %l0, !tbaa !29
  store ptr %t283, ptr %l168, !tbaa !29
  %t284 = load ptr, ptr %l168, !tbaa !29
  %t285 = getelementptr %"compiler/build:Sha256", ptr %t284, i32 0, i32 0
  %t286 = getelementptr [8 x i32], ptr %t285, i64 0, i64 4
  %t287 = load i32, ptr %t286, !tbaa !84
  store i32 %t287, ptr %l169, !tbaa !64
  %t288 = load i32, ptr %l169, !tbaa !64
  store i32 %t288, ptr %l23, !tbaa !64
  %t289 = load ptr, ptr %l0, !tbaa !29
  store ptr %t289, ptr %l170, !tbaa !29
  %t290 = load ptr, ptr %l170, !tbaa !29
  %t291 = getelementptr %"compiler/build:Sha256", ptr %t290, i32 0, i32 0
  %t292 = getelementptr [8 x i32], ptr %t291, i64 0, i64 5
  %t293 = load i32, ptr %t292, !tbaa !84
  store i32 %t293, ptr %l171, !tbaa !64
  %t294 = load i32, ptr %l171, !tbaa !64
  store i32 %t294, ptr %l24, !tbaa !64
  %t295 = load ptr, ptr %l0, !tbaa !29
  store ptr %t295, ptr %l172, !tbaa !29
  %t296 = load ptr, ptr %l172, !tbaa !29
  %t297 = getelementptr %"compiler/build:Sha256", ptr %t296, i32 0, i32 0
  %t298 = getelementptr [8 x i32], ptr %t297, i64 0, i64 6
  %t299 = load i32, ptr %t298, !tbaa !84
  store i32 %t299, ptr %l173, !tbaa !64
  %t300 = load i32, ptr %l173, !tbaa !64
  store i32 %t300, ptr %l25, !tbaa !64
  %t301 = load ptr, ptr %l0, !tbaa !29
  store ptr %t301, ptr %l174, !tbaa !29
  %t302 = load ptr, ptr %l174, !tbaa !29
  %t303 = getelementptr %"compiler/build:Sha256", ptr %t302, i32 0, i32 0
  %t304 = getelementptr [8 x i32], ptr %t303, i64 0, i64 7
  %t305 = load i32, ptr %t304, !tbaa !84
  store i32 %t305, ptr %l175, !tbaa !64
  %t306 = load i32, ptr %l175, !tbaa !64
  store i32 %t306, ptr %l26, !tbaa !64
  store %olang.scope zeroinitializer, ptr %s7
  store i64 0, ptr %l27, !tbaa !24
  store i64 64, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t307 = load i64, ptr %l28, !tbaa !24
  store i64 %t307, ptr %l176, !tbaa !24
  %t308 = load i64, ptr %l27, !tbaa !24
  store i64 %t308, ptr %l177, !tbaa !24
  %t309 = load i64, ptr %l176, !tbaa !24
  %t310 = load i64, ptr %l177, !tbaa !24
  %t311 = icmp sgt i64 %t309, %t310
  store i1 %t311, ptr %l178, !tbaa !21
  %t312 = load i1, ptr %l178, !tbaa !21
  br i1 %t312, label %bb29, label %bb30
bb29:
  %t313 = load i64, ptr %l29, !tbaa !24
  store i64 %t313, ptr %l180, !tbaa !24
  %t314 = load i64, ptr %l180, !tbaa !24
  %t315 = icmp sgt i64 %t314, 0
  store i1 %t315, ptr %l181, !tbaa !21
  %t316 = load i1, ptr %l181, !tbaa !21
  br i1 %t316, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb34
bb31:
  %t317 = load i64, ptr %l28, !tbaa !24
  store i64 %t317, ptr %l183, !tbaa !24
  %t318 = load i64, ptr %l27, !tbaa !24
  store i64 %t318, ptr %l184, !tbaa !24
  %t319 = load i64, ptr %l183, !tbaa !24
  %t320 = load i64, ptr %l184, !tbaa !24
  %t321 = sub i64 %t319, %t320
  store i64 %t321, ptr %l185, !tbaa !24
  %t322 = load i64, ptr %l29, !tbaa !24
  store i64 %t322, ptr %l186, !tbaa !24
  %t323 = load i64, ptr %l185, !tbaa !24
  %t324 = load i64, ptr %l186, !tbaa !24
  %t325 = add i64 %t323, %t324
  store i64 %t325, ptr %l187, !tbaa !24
  %t326 = load i64, ptr %l187, !tbaa !24
  %t327 = sub i64 %t326, 1
  store i64 %t327, ptr %l188, !tbaa !24
  %t328 = load i64, ptr %l29, !tbaa !24
  store i64 %t328, ptr %l189, !tbaa !24
  %t329 = load i64, ptr %l188, !tbaa !24
  %t330 = load i64, ptr %l189, !tbaa !24
  %t331 = sdiv i64 %t329, %t330
  store i64 %t331, ptr %l190, !tbaa !24
  %t332 = load i64, ptr %l190, !tbaa !24
  store i64 %t332, ptr %l182, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb33
bb33:
  %t333 = load i64, ptr %l182, !tbaa !24
  store i64 %t333, ptr %l179, !tbaa !24
  br label %bb34
bb34:
  %t334 = load i64, ptr %l179, !tbaa !24
  store i64 %t334, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t335 = load i64, ptr %l31, !tbaa !24
  store i64 %t335, ptr %l191, !tbaa !24
  %t336 = load i64, ptr %l30, !tbaa !24
  store i64 %t336, ptr %l192, !tbaa !24
  %t337 = load i64, ptr %l191, !tbaa !24
  %t338 = load i64, ptr %l192, !tbaa !24
  %t339 = icmp slt i64 %t337, %t338
  store i1 %t339, ptr %l193, !tbaa !21
  %t340 = load i1, ptr %l193, !tbaa !21
  %t341 = xor i1 %t340, true
  store i1 %t341, ptr %l194, !tbaa !21
  %t342 = load i1, ptr %l194, !tbaa !21
  br i1 %t342, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t343 = load i64, ptr %l27, !tbaa !24
  store i64 %t343, ptr %l195, !tbaa !24
  %t344 = load i64, ptr %l31, !tbaa !24
  store i64 %t344, ptr %l196, !tbaa !24
  %t345 = load i64, ptr %l29, !tbaa !24
  store i64 %t345, ptr %l197, !tbaa !24
  %t346 = load i64, ptr %l196, !tbaa !24
  %t347 = load i64, ptr %l197, !tbaa !24
  %t348 = mul i64 %t346, %t347
  store i64 %t348, ptr %l198, !tbaa !24
  %t349 = load i64, ptr %l195, !tbaa !24
  %t350 = load i64, ptr %l198, !tbaa !24
  %t351 = add i64 %t349, %t350
  store i64 %t351, ptr %l199, !tbaa !24
  %t352 = load i64, ptr %l199, !tbaa !24
  store i64 %t352, ptr %l32, !tbaa !24
  %t353 = load i32, ptr %l23, !tbaa !64
  store i32 %t353, ptr %l200, !tbaa !64
  %t354 = load i32, ptr %l200, !tbaa !64
  %t355 = call i32 @compiler_2fbuild_2erotr(i32 %t354, i32 6)
  store i32 %t355, ptr %l201
  br label %bb39
bb39:
  %t356 = load i32, ptr %l23, !tbaa !64
  store i32 %t356, ptr %l202, !tbaa !64
  %t357 = load i32, ptr %l202, !tbaa !64
  %t358 = call i32 @compiler_2fbuild_2erotr(i32 %t357, i32 11)
  store i32 %t358, ptr %l203
  br label %bb40
bb40:
  %t359 = load i32, ptr %l201, !tbaa !64
  %t360 = load i32, ptr %l203, !tbaa !64
  %t361 = xor i32 %t359, %t360
  store i32 %t361, ptr %l204, !tbaa !64
  %t362 = load i32, ptr %l23, !tbaa !64
  store i32 %t362, ptr %l205, !tbaa !64
  %t363 = load i32, ptr %l205, !tbaa !64
  %t364 = call i32 @compiler_2fbuild_2erotr(i32 %t363, i32 25)
  store i32 %t364, ptr %l206
  br label %bb41
bb41:
  %t365 = load i32, ptr %l204, !tbaa !64
  %t366 = load i32, ptr %l206, !tbaa !64
  %t367 = xor i32 %t365, %t366
  store i32 %t367, ptr %l207, !tbaa !64
  %t368 = load i32, ptr %l207, !tbaa !64
  store i32 %t368, ptr %l33, !tbaa !64
  %t369 = load i32, ptr %l23, !tbaa !64
  store i32 %t369, ptr %l208, !tbaa !64
  %t370 = load i32, ptr %l24, !tbaa !64
  store i32 %t370, ptr %l209, !tbaa !64
  %t371 = load i32, ptr %l208, !tbaa !64
  %t372 = load i32, ptr %l209, !tbaa !64
  %t373 = and i32 %t371, %t372
  store i32 %t373, ptr %l210, !tbaa !64
  %t374 = load i32, ptr %l23, !tbaa !64
  store i32 %t374, ptr %l211, !tbaa !64
  %t375 = load i32, ptr %l211, !tbaa !64
  %t376 = xor i32 %t375, -1
  store i32 %t376, ptr %l212, !tbaa !64
  %t377 = load i32, ptr %l25, !tbaa !64
  store i32 %t377, ptr %l213, !tbaa !64
  %t378 = load i32, ptr %l212, !tbaa !64
  %t379 = load i32, ptr %l213, !tbaa !64
  %t380 = and i32 %t378, %t379
  store i32 %t380, ptr %l214, !tbaa !64
  %t381 = load i32, ptr %l210, !tbaa !64
  %t382 = load i32, ptr %l214, !tbaa !64
  %t383 = xor i32 %t381, %t382
  store i32 %t383, ptr %l215, !tbaa !64
  %t384 = load i32, ptr %l215, !tbaa !64
  store i32 %t384, ptr %l34, !tbaa !64
  %t385 = load i32, ptr %l26, !tbaa !64
  store i32 %t385, ptr %l216, !tbaa !64
  %t386 = load i32, ptr %l33, !tbaa !64
  store i32 %t386, ptr %l217, !tbaa !64
  %t387 = load i32, ptr %l216, !tbaa !64
  %t388 = load i32, ptr %l217, !tbaa !64
  %t389 = add i32 %t387, %t388
  store i32 %t389, ptr %l218, !tbaa !64
  %t390 = load i32, ptr %l34, !tbaa !64
  store i32 %t390, ptr %l219, !tbaa !64
  %t391 = load i32, ptr %l218, !tbaa !64
  %t392 = load i32, ptr %l219, !tbaa !64
  %t393 = add i32 %t391, %t392
  store i32 %t393, ptr %l220, !tbaa !64
  %t394 = load i64, ptr %l32, !tbaa !24
  store i64 %t394, ptr %l221, !tbaa !24
  %t395 = load i64, ptr %l221, !tbaa !24
  %t396 = getelementptr [64 x i32], ptr @G_2ecompiler_2fbuild_2eShaK, i64 0, i64 %t395
  %t397 = load i32, ptr %t396, !tbaa !84
  store i32 %t397, ptr %l222, !tbaa !64
  %t398 = load i32, ptr %l220, !tbaa !64
  %t399 = load i32, ptr %l222, !tbaa !64
  %t400 = add i32 %t398, %t399
  store i32 %t400, ptr %l223, !tbaa !64
  %t401 = load i64, ptr %l32, !tbaa !24
  store i64 %t401, ptr %l224, !tbaa !24
  %t402 = load i64, ptr %l224, !tbaa !24
  %t403 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t402
  %t404 = load i32, ptr %t403, !tbaa !84
  store i32 %t404, ptr %l225, !tbaa !64
  %t405 = load i32, ptr %l223, !tbaa !64
  %t406 = load i32, ptr %l225, !tbaa !64
  %t407 = add i32 %t405, %t406
  store i32 %t407, ptr %l226, !tbaa !64
  %t408 = load i32, ptr %l226, !tbaa !64
  store i32 %t408, ptr %l35, !tbaa !64
  %t409 = load i32, ptr %l19, !tbaa !64
  store i32 %t409, ptr %l227, !tbaa !64
  %t410 = load i32, ptr %l227, !tbaa !64
  %t411 = call i32 @compiler_2fbuild_2erotr(i32 %t410, i32 2)
  store i32 %t411, ptr %l228
  br label %bb42
bb42:
  %t412 = load i32, ptr %l19, !tbaa !64
  store i32 %t412, ptr %l229, !tbaa !64
  %t413 = load i32, ptr %l229, !tbaa !64
  %t414 = call i32 @compiler_2fbuild_2erotr(i32 %t413, i32 13)
  store i32 %t414, ptr %l230
  br label %bb43
bb43:
  %t415 = load i32, ptr %l228, !tbaa !64
  %t416 = load i32, ptr %l230, !tbaa !64
  %t417 = xor i32 %t415, %t416
  store i32 %t417, ptr %l231, !tbaa !64
  %t418 = load i32, ptr %l19, !tbaa !64
  store i32 %t418, ptr %l232, !tbaa !64
  %t419 = load i32, ptr %l232, !tbaa !64
  %t420 = call i32 @compiler_2fbuild_2erotr(i32 %t419, i32 22)
  store i32 %t420, ptr %l233
  br label %bb44
bb44:
  %t421 = load i32, ptr %l231, !tbaa !64
  %t422 = load i32, ptr %l233, !tbaa !64
  %t423 = xor i32 %t421, %t422
  store i32 %t423, ptr %l234, !tbaa !64
  %t424 = load i32, ptr %l234, !tbaa !64
  store i32 %t424, ptr %l36, !tbaa !64
  %t425 = load i32, ptr %l19, !tbaa !64
  store i32 %t425, ptr %l235, !tbaa !64
  %t426 = load i32, ptr %l20, !tbaa !64
  store i32 %t426, ptr %l236, !tbaa !64
  %t427 = load i32, ptr %l235, !tbaa !64
  %t428 = load i32, ptr %l236, !tbaa !64
  %t429 = and i32 %t427, %t428
  store i32 %t429, ptr %l237, !tbaa !64
  %t430 = load i32, ptr %l19, !tbaa !64
  store i32 %t430, ptr %l238, !tbaa !64
  %t431 = load i32, ptr %l21, !tbaa !64
  store i32 %t431, ptr %l239, !tbaa !64
  %t432 = load i32, ptr %l238, !tbaa !64
  %t433 = load i32, ptr %l239, !tbaa !64
  %t434 = and i32 %t432, %t433
  store i32 %t434, ptr %l240, !tbaa !64
  %t435 = load i32, ptr %l237, !tbaa !64
  %t436 = load i32, ptr %l240, !tbaa !64
  %t437 = xor i32 %t435, %t436
  store i32 %t437, ptr %l241, !tbaa !64
  %t438 = load i32, ptr %l20, !tbaa !64
  store i32 %t438, ptr %l242, !tbaa !64
  %t439 = load i32, ptr %l21, !tbaa !64
  store i32 %t439, ptr %l243, !tbaa !64
  %t440 = load i32, ptr %l242, !tbaa !64
  %t441 = load i32, ptr %l243, !tbaa !64
  %t442 = and i32 %t440, %t441
  store i32 %t442, ptr %l244, !tbaa !64
  %t443 = load i32, ptr %l241, !tbaa !64
  %t444 = load i32, ptr %l244, !tbaa !64
  %t445 = xor i32 %t443, %t444
  store i32 %t445, ptr %l245, !tbaa !64
  %t446 = load i32, ptr %l245, !tbaa !64
  store i32 %t446, ptr %l37, !tbaa !64
  %t447 = load i32, ptr %l25, !tbaa !64
  store i32 %t447, ptr %l246, !tbaa !64
  %t448 = load i32, ptr %l246, !tbaa !64
  store i32 %t448, ptr %l26, !tbaa !64
  %t449 = load i32, ptr %l24, !tbaa !64
  store i32 %t449, ptr %l247, !tbaa !64
  %t450 = load i32, ptr %l247, !tbaa !64
  store i32 %t450, ptr %l25, !tbaa !64
  %t451 = load i32, ptr %l23, !tbaa !64
  store i32 %t451, ptr %l248, !tbaa !64
  %t452 = load i32, ptr %l248, !tbaa !64
  store i32 %t452, ptr %l24, !tbaa !64
  %t453 = load i32, ptr %l22, !tbaa !64
  store i32 %t453, ptr %l249, !tbaa !64
  %t454 = load i32, ptr %l35, !tbaa !64
  store i32 %t454, ptr %l250, !tbaa !64
  %t455 = load i32, ptr %l249, !tbaa !64
  %t456 = load i32, ptr %l250, !tbaa !64
  %t457 = add i32 %t455, %t456
  store i32 %t457, ptr %l251, !tbaa !64
  %t458 = load i32, ptr %l251, !tbaa !64
  store i32 %t458, ptr %l23, !tbaa !64
  %t459 = load i32, ptr %l21, !tbaa !64
  store i32 %t459, ptr %l252, !tbaa !64
  %t460 = load i32, ptr %l252, !tbaa !64
  store i32 %t460, ptr %l22, !tbaa !64
  %t461 = load i32, ptr %l20, !tbaa !64
  store i32 %t461, ptr %l253, !tbaa !64
  %t462 = load i32, ptr %l253, !tbaa !64
  store i32 %t462, ptr %l21, !tbaa !64
  %t463 = load i32, ptr %l19, !tbaa !64
  store i32 %t463, ptr %l254, !tbaa !64
  %t464 = load i32, ptr %l254, !tbaa !64
  store i32 %t464, ptr %l20, !tbaa !64
  %t465 = load i32, ptr %l35, !tbaa !64
  store i32 %t465, ptr %l255, !tbaa !64
  %t466 = load i32, ptr %l36, !tbaa !64
  store i32 %t466, ptr %l256, !tbaa !64
  %t467 = load i32, ptr %l255, !tbaa !64
  %t468 = load i32, ptr %l256, !tbaa !64
  %t469 = add i32 %t467, %t468
  store i32 %t469, ptr %l257, !tbaa !64
  %t470 = load i32, ptr %l37, !tbaa !64
  store i32 %t470, ptr %l258, !tbaa !64
  %t471 = load i32, ptr %l257, !tbaa !64
  %t472 = load i32, ptr %l258, !tbaa !64
  %t473 = add i32 %t471, %t472
  store i32 %t473, ptr %l259, !tbaa !64
  %t474 = load i32, ptr %l259, !tbaa !64
  store i32 %t474, ptr %l19, !tbaa !64
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t475 = load i64, ptr %l31, !tbaa !24
  store i64 %t475, ptr %l260, !tbaa !24
  %t476 = load i64, ptr %l260, !tbaa !24
  %t477 = add i64 %t476, 1
  store i64 %t477, ptr %l261, !tbaa !24
  %t478 = load i64, ptr %l261, !tbaa !24
  store i64 %t478, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb35
bb46:
  call void @__olang_scope_close(ptr %s7)
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l262, !tbaa !29
  %t480 = load ptr, ptr %l262, !tbaa !29
  %t481 = getelementptr %"compiler/build:Sha256", ptr %t480, i32 0, i32 0
  %t482 = getelementptr [8 x i32], ptr %t481, i64 0, i64 0
  %t483 = load i32, ptr %t482, !tbaa !84
  store i32 %t483, ptr %l263, !tbaa !64
  %t484 = load i32, ptr %l19, !tbaa !64
  store i32 %t484, ptr %l264, !tbaa !64
  %t485 = load i32, ptr %l263, !tbaa !64
  %t486 = load i32, ptr %l264, !tbaa !64
  %t487 = add i32 %t485, %t486
  store i32 %t487, ptr %l265, !tbaa !64
  %t488 = load i32, ptr %l265, !tbaa !64
  %t489 = load ptr, ptr %l262, !tbaa !29
  %t490 = getelementptr %"compiler/build:Sha256", ptr %t489, i32 0, i32 0
  %t491 = getelementptr [8 x i32], ptr %t490, i64 0, i64 0
  store i32 %t488, ptr %t491, !tbaa !84
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l266, !tbaa !29
  %t493 = load ptr, ptr %l266, !tbaa !29
  %t494 = getelementptr %"compiler/build:Sha256", ptr %t493, i32 0, i32 0
  %t495 = getelementptr [8 x i32], ptr %t494, i64 0, i64 1
  %t496 = load i32, ptr %t495, !tbaa !84
  store i32 %t496, ptr %l267, !tbaa !64
  %t497 = load i32, ptr %l20, !tbaa !64
  store i32 %t497, ptr %l268, !tbaa !64
  %t498 = load i32, ptr %l267, !tbaa !64
  %t499 = load i32, ptr %l268, !tbaa !64
  %t500 = add i32 %t498, %t499
  store i32 %t500, ptr %l269, !tbaa !64
  %t501 = load i32, ptr %l269, !tbaa !64
  %t502 = load ptr, ptr %l266, !tbaa !29
  %t503 = getelementptr %"compiler/build:Sha256", ptr %t502, i32 0, i32 0
  %t504 = getelementptr [8 x i32], ptr %t503, i64 0, i64 1
  store i32 %t501, ptr %t504, !tbaa !84
  %t505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t505, ptr %l270, !tbaa !29
  %t506 = load ptr, ptr %l270, !tbaa !29
  %t507 = getelementptr %"compiler/build:Sha256", ptr %t506, i32 0, i32 0
  %t508 = getelementptr [8 x i32], ptr %t507, i64 0, i64 2
  %t509 = load i32, ptr %t508, !tbaa !84
  store i32 %t509, ptr %l271, !tbaa !64
  %t510 = load i32, ptr %l21, !tbaa !64
  store i32 %t510, ptr %l272, !tbaa !64
  %t511 = load i32, ptr %l271, !tbaa !64
  %t512 = load i32, ptr %l272, !tbaa !64
  %t513 = add i32 %t511, %t512
  store i32 %t513, ptr %l273, !tbaa !64
  %t514 = load i32, ptr %l273, !tbaa !64
  %t515 = load ptr, ptr %l270, !tbaa !29
  %t516 = getelementptr %"compiler/build:Sha256", ptr %t515, i32 0, i32 0
  %t517 = getelementptr [8 x i32], ptr %t516, i64 0, i64 2
  store i32 %t514, ptr %t517, !tbaa !84
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l274, !tbaa !29
  %t519 = load ptr, ptr %l274, !tbaa !29
  %t520 = getelementptr %"compiler/build:Sha256", ptr %t519, i32 0, i32 0
  %t521 = getelementptr [8 x i32], ptr %t520, i64 0, i64 3
  %t522 = load i32, ptr %t521, !tbaa !84
  store i32 %t522, ptr %l275, !tbaa !64
  %t523 = load i32, ptr %l22, !tbaa !64
  store i32 %t523, ptr %l276, !tbaa !64
  %t524 = load i32, ptr %l275, !tbaa !64
  %t525 = load i32, ptr %l276, !tbaa !64
  %t526 = add i32 %t524, %t525
  store i32 %t526, ptr %l277, !tbaa !64
  %t527 = load i32, ptr %l277, !tbaa !64
  %t528 = load ptr, ptr %l274, !tbaa !29
  %t529 = getelementptr %"compiler/build:Sha256", ptr %t528, i32 0, i32 0
  %t530 = getelementptr [8 x i32], ptr %t529, i64 0, i64 3
  store i32 %t527, ptr %t530, !tbaa !84
  %t531 = load ptr, ptr %l0, !tbaa !29
  store ptr %t531, ptr %l278, !tbaa !29
  %t532 = load ptr, ptr %l278, !tbaa !29
  %t533 = getelementptr %"compiler/build:Sha256", ptr %t532, i32 0, i32 0
  %t534 = getelementptr [8 x i32], ptr %t533, i64 0, i64 4
  %t535 = load i32, ptr %t534, !tbaa !84
  store i32 %t535, ptr %l279, !tbaa !64
  %t536 = load i32, ptr %l23, !tbaa !64
  store i32 %t536, ptr %l280, !tbaa !64
  %t537 = load i32, ptr %l279, !tbaa !64
  %t538 = load i32, ptr %l280, !tbaa !64
  %t539 = add i32 %t537, %t538
  store i32 %t539, ptr %l281, !tbaa !64
  %t540 = load i32, ptr %l281, !tbaa !64
  %t541 = load ptr, ptr %l278, !tbaa !29
  %t542 = getelementptr %"compiler/build:Sha256", ptr %t541, i32 0, i32 0
  %t543 = getelementptr [8 x i32], ptr %t542, i64 0, i64 4
  store i32 %t540, ptr %t543, !tbaa !84
  %t544 = load ptr, ptr %l0, !tbaa !29
  store ptr %t544, ptr %l282, !tbaa !29
  %t545 = load ptr, ptr %l282, !tbaa !29
  %t546 = getelementptr %"compiler/build:Sha256", ptr %t545, i32 0, i32 0
  %t547 = getelementptr [8 x i32], ptr %t546, i64 0, i64 5
  %t548 = load i32, ptr %t547, !tbaa !84
  store i32 %t548, ptr %l283, !tbaa !64
  %t549 = load i32, ptr %l24, !tbaa !64
  store i32 %t549, ptr %l284, !tbaa !64
  %t550 = load i32, ptr %l283, !tbaa !64
  %t551 = load i32, ptr %l284, !tbaa !64
  %t552 = add i32 %t550, %t551
  store i32 %t552, ptr %l285, !tbaa !64
  %t553 = load i32, ptr %l285, !tbaa !64
  %t554 = load ptr, ptr %l282, !tbaa !29
  %t555 = getelementptr %"compiler/build:Sha256", ptr %t554, i32 0, i32 0
  %t556 = getelementptr [8 x i32], ptr %t555, i64 0, i64 5
  store i32 %t553, ptr %t556, !tbaa !84
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l286, !tbaa !29
  %t558 = load ptr, ptr %l286, !tbaa !29
  %t559 = getelementptr %"compiler/build:Sha256", ptr %t558, i32 0, i32 0
  %t560 = getelementptr [8 x i32], ptr %t559, i64 0, i64 6
  %t561 = load i32, ptr %t560, !tbaa !84
  store i32 %t561, ptr %l287, !tbaa !64
  %t562 = load i32, ptr %l25, !tbaa !64
  store i32 %t562, ptr %l288, !tbaa !64
  %t563 = load i32, ptr %l287, !tbaa !64
  %t564 = load i32, ptr %l288, !tbaa !64
  %t565 = add i32 %t563, %t564
  store i32 %t565, ptr %l289, !tbaa !64
  %t566 = load i32, ptr %l289, !tbaa !64
  %t567 = load ptr, ptr %l286, !tbaa !29
  %t568 = getelementptr %"compiler/build:Sha256", ptr %t567, i32 0, i32 0
  %t569 = getelementptr [8 x i32], ptr %t568, i64 0, i64 6
  store i32 %t566, ptr %t569, !tbaa !84
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l290, !tbaa !29
  %t571 = load ptr, ptr %l290, !tbaa !29
  %t572 = getelementptr %"compiler/build:Sha256", ptr %t571, i32 0, i32 0
  %t573 = getelementptr [8 x i32], ptr %t572, i64 0, i64 7
  %t574 = load i32, ptr %t573, !tbaa !84
  store i32 %t574, ptr %l291, !tbaa !64
  %t575 = load i32, ptr %l26, !tbaa !64
  store i32 %t575, ptr %l292, !tbaa !64
  %t576 = load i32, ptr %l291, !tbaa !64
  %t577 = load i32, ptr %l292, !tbaa !64
  %t578 = add i32 %t576, %t577
  store i32 %t578, ptr %l293, !tbaa !64
  %t579 = load i32, ptr %l293, !tbaa !64
  %t580 = load ptr, ptr %l290, !tbaa !29
  %t581 = getelementptr %"compiler/build:Sha256", ptr %t580, i32 0, i32 0
  %t582 = getelementptr [8 x i32], ptr %t581, i64 0, i64 7
  store i32 %t579, ptr %t582, !tbaa !84
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/msgs:Msg"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca %"compiler/msgs:Msg"
  %l11 = alloca i64
  %s0 = alloca %olang.scope
  %t9 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/msgs:Msg" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %l5, !tbaa !27
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t3, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr @.d98 }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = insertvalue { i64 } undef, i64 %t11, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  store { i64, [3 x i64] } %t14, ptr %l9
  %t15 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t15, ptr %l10
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t17 = load { i64, [3 x i64] }, ptr %l9
  %t18 = load %"compiler/msgs:Msg", ptr %l10
  %t19 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %v1, ptr %t16, { i64, [3 x i64] } %t17, %"compiler/msgs:Msg" %t18)
  store i64 %t19, ptr %l11
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/msgs:Msg"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %t9 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/msgs:Msg" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t2, ptr %l5, !tbaa !27
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t3, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr @.d99 }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load i64, ptr %l3, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = insertvalue { i64 } undef, i64 %t11, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  store { i64, [3 x i64] } %t14, ptr %l9
  %t15 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t15, ptr %l10
  %t16 = load ptr, ptr %l7, !tbaa !29
  %t17 = load { i64, [3 x i64] }, ptr %l9
  %t18 = load %"compiler/msgs:Msg", ptr %l10
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v1, ptr %t16, { i64, [3 x i64] } %t17, %"compiler/msgs:Msg" %t18)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %t2)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l3, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t11)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l4, !tbaa !29
  %t13 = load ptr, ptr %l4, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %s0, ptr %t13)
  store { i64, ptr } %t14, ptr %l5
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t22)
  br label %bb4
bb4:
  store i32 1, ptr %l7, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l7, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l3, !tbaa !21
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d100 }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb4:
  %t8 = load i32, ptr %l0
  store i32 %t8, ptr %l6
  %t9 = load i32, ptr %l6
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t9, %t10
  store i1 %t11, ptr %l7, !tbaa !21
  %t12 = load i1, ptr %l7, !tbaa !21
  br i1 %t12, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 5, ptr @.d101 }, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l9, !tbaa !27
  %t14 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t14, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t15 = load i32, ptr %l0
  store i32 %t15, ptr %l10
  %t16 = load i32, ptr %l10
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t16, %t17
  store i1 %t18, ptr %l11, !tbaa !21
  %t19 = load i1, ptr %l11, !tbaa !21
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 5, ptr @.d102 }, ptr %l12, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l13, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t21, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb12:
  %t22 = load i32, ptr %l0
  store i32 %t22, ptr %l14
  %t23 = load i32, ptr %l14
  %t24 = trunc i64 3 to i32
  %t25 = icmp eq i32 %t23, %t24
  store i1 %t25, ptr %l15, !tbaa !21
  %t26 = load i1, ptr %l15, !tbaa !21
  br i1 %t26, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 5, ptr @.d103 }, ptr %l16, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l17, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t28, ptr %l1, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c104)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2elinkCurrent(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca %"std/os:FileInfo"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %t2)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = ashr i32 %t9, 16
  store i32 %t10, ptr %l9, !tbaa !23
  %t11 = load i32, ptr %l9, !tbaa !23
  %t12 = icmp eq i32 %t11, 1
  store i1 %t12, ptr %l10, !tbaa !21
  %t13 = load i1, ptr %l10, !tbaa !21
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c105)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l11, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l11, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
bb6:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l13, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t18 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %t17)
  %t19 = extractvalue { i32, %"std/os:FileInfo" } %t18, 1
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t18, 0
  store i32 %t20, ptr %l15
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22
ok.22:
  store %"std/os:FileInfo" %t19, ptr %l14
  br label %bb7
bb7:
  %t23 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t23, ptr %l12
  br label %bb12
bb8:
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = ashr i32 %t24, 16
  store i32 %t25, ptr %l16, !tbaa !23
  %t26 = load i32, ptr %l16, !tbaa !23
  %t27 = icmp eq i32 %t26, 1
  store i1 %t27, ptr %l17, !tbaa !21
  %t28 = load i1, ptr %l17, !tbaa !21
  br i1 %t28, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c106)
  unreachable
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 false, ptr %l18, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i1, ptr %l18, !tbaa !21
  store i1 %t29, ptr %rv
  br label %ret
bb12:
  %t30 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t30, ptr %l4
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t31, ptr %l19, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l20, !tbaa !27
  %t33 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  store i64 %t34, ptr %l21, !tbaa !24
  %t35 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  store i64 %t36, ptr %l22, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t37 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  call void @__olang_sb_put(ptr %s3, ptr %t38, i64 %t39)
  %t40 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr @.d107 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t40, i64 %t41)
  %t42 = load i64, ptr %l21, !tbaa !24
  %t43 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t44 = call i64 @__olang_fmt_i64(ptr %t43, i64 %t42)
  call void @__olang_sb_add(ptr %s3, i64 %t44)
  %t45 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t45, i64 %t46)
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t49 = call i64 @__olang_fmt_i64(ptr %t48, i64 %t47)
  call void @__olang_sb_add(ptr %s3, i64 %t49)
  %t50 = extractvalue { i64, ptr } { i64 1, ptr @.d109 }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr @.d109 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t50, i64 %t51)
  %t52 = load ptr, ptr %s3
  %t53 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t54 = load i64, ptr %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t52, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l23, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t58 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 0
  %t60 = extractvalue { i64, ptr } %t58, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l24, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t65, { i64, ptr } %t66)
  store i1 %t67, ptr %l25
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i1, ptr %l25, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fbuild_2erotr(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0, !tbaa !64
  store i32 %t1, ptr %l2, !tbaa !64
  %t2 = load i32, ptr %l1, !tbaa !64
  store i32 %t2, ptr %l3, !tbaa !64
  %t3 = load i32, ptr %l2, !tbaa !64
  %t4 = load i32, ptr %l3, !tbaa !64
  %t5 = load i32, ptr %l3, !tbaa !64
  %t6 = lshr i32 %t3, %t5
  store i32 %t6, ptr %l4, !tbaa !64
  %t7 = load i32, ptr %l0, !tbaa !64
  store i32 %t7, ptr %l5, !tbaa !64
  %t8 = load i32, ptr %l1, !tbaa !64
  store i32 %t8, ptr %l6, !tbaa !64
  %t9 = load i32, ptr %l6, !tbaa !64
  %t10 = sub i32 32, %t9
  store i32 %t10, ptr %l7, !tbaa !64
  %t11 = load i32, ptr %l5, !tbaa !64
  %t12 = load i32, ptr %l7, !tbaa !64
  %t13 = load i32, ptr %l7, !tbaa !64
  %t14 = shl i32 %t11, %t13
  store i32 %t14, ptr %l8, !tbaa !64
  %t15 = load i32, ptr %l4, !tbaa !64
  %t16 = load i32, ptr %l8, !tbaa !64
  %t17 = or i32 %t15, %t16
  store i32 %t17, ptr %l9, !tbaa !64
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l9, !tbaa !64
  store i32 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/os:Output"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l7, !tbaa !29
  %t2 = load ptr, ptr %l7, !tbaa !29
  store ptr %t2, ptr %l4, !tbaa !29
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4, !tbaa !29
  store ptr %t3, ptr %l9, !tbaa !29
  %t4 = load ptr, ptr %l9, !tbaa !29
  %t5 = call { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l11
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb7
bb3:
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = ashr i32 %t11, 16
  store i32 %t12, ptr %l12, !tbaa !23
  %t13 = load i32, ptr %l12, !tbaa !23
  %t14 = icmp eq i32 %t13, 1
  store i1 %t14, ptr %l13, !tbaa !21
  %t15 = load i1, ptr %l13, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb7:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t19
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d111 }, ptr %l18, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t26 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t24, { i64, ptr } %t25, i1 true, { i64, ptr } { i64 0, ptr @.d112 })
  %t27 = extractvalue { i32, %"std/os:Output" } %t26, 1
  %t28 = extractvalue { i32, %"std/os:Output" } %t26, 0
  store i32 %t28, ptr %l20
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb9, label %ok.30
ok.30:
  store %"std/os:Output" %t27, ptr %l19
  br label %bb8
bb8:
  %t31 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t31, ptr %l14
  br label %bb13
bb9:
  %t32 = load i32, ptr %l20, !tbaa !23
  %t33 = ashr i32 %t32, 16
  store i32 %t33, ptr %l21, !tbaa !23
  %t34 = load i32, ptr %l21, !tbaa !23
  %t35 = icmp eq i32 %t34, 1
  store i1 %t35, ptr %l22, !tbaa !21
  %t36 = load i1, ptr %l22, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c113)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l5, !tbaa !24
  store i64 %t38, ptr %l24, !tbaa !24
  %t39 = load i64, ptr %l24, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t39
  store i32 127, ptr %t42, !tbaa !33
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l25, !tbaa !27
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l26, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  store i64 %t46, ptr %l28, !tbaa !24
  %t47 = load i64, ptr %l28, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %t49, i64 %t47
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !37
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %t53, i64 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !37
  store { i64, ptr } %t55, ptr %l30, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t56 = extractvalue { i64, ptr } { i64 11, ptr @.d114 }, 1
  %t57 = extractvalue { i64, ptr } { i64 11, ptr @.d114 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t56, i64 %t57)
  %t58 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  call void @__olang_sb_put(ptr %s4, ptr %t59, i64 %t60)
  %t61 = extractvalue { i64, ptr } { i64 1, ptr @.d115 }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr @.d115 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t61, i64 %t62)
  %t63 = load ptr, ptr %s4
  %t64 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t63, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l31, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  %t69 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t77 = load i64, ptr %l26, !tbaa !24
  %t78 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %t79, i64 %t77
  store { i64, ptr } %t76, ptr %t80, !tbaa !37
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb13:
  %t81 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t81, ptr %l6
  %t82 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t82, ptr %l33, !tbaa !27
  %t83 = load i64, ptr %l5, !tbaa !24
  store i64 %t83, ptr %l34, !tbaa !24
  %t84 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t85 = load i32, ptr %t84, !tbaa !23
  store i32 %t85, ptr %l35, !tbaa !23
  %t86 = load i32, ptr %l35, !tbaa !23
  %t87 = load i64, ptr %l34, !tbaa !24
  %t88 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i32, ptr %t89, i64 %t87
  store i32 %t86, ptr %t90, !tbaa !33
  %t91 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t91, ptr %l36, !tbaa !27
  %t92 = load i64, ptr %l5, !tbaa !24
  store i64 %t92, ptr %l37, !tbaa !24
  %t93 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l38, !tbaa !27
  %t95 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  store { i64, ptr } %t96, ptr %l39, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t97 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  call void @__olang_sb_put(ptr %s5, ptr %t98, i64 %t99)
  %t100 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  call void @__olang_sb_put(ptr %s5, ptr %t101, i64 %t102)
  %t103 = load ptr, ptr %s5
  %t104 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t105 = load i64, ptr %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t103, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l40, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t109 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l41, !tbaa !27
  %t116 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t117 = load i64, ptr %l37, !tbaa !24
  %t118 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t117
  store { i64, ptr } %t116, ptr %t120, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb1
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c117)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = call i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3, !tbaa !23
  %t8 = load i32, ptr %l3, !tbaa !23
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i1, ptr %l4, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c118)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2eunbuilt() #0 {
entry:
  %l0 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr %l0, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  %t1 = load i32, ptr %l0, !tbaa !23
  store i32 %t1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/target:Target"
  %l3 = alloca %"compiler/cond:Consts"
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/target:Target"
  %l19 = alloca %"compiler/cond:Consts"
  %l20 = alloca %"compiler/build:Config"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 5, ptr @.d119 }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d120 }, ptr %l1, !tbaa !27
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
  store %"compiler/target:Target" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"compiler/target:Target", ptr %l18
  store %"compiler/target:Target" %t2, ptr %l2
  %t3 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
  store %"compiler/cond:Consts" %t3, ptr %l19
  br label %bb2
bb2:
  %t4 = load %"compiler/cond:Consts", ptr %l19
  store %"compiler/cond:Consts" %t4, ptr %l3
  store i1 false, ptr %l4, !tbaa !21
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  store i1 false, ptr %l7, !tbaa !21
  store i1 false, ptr %l8, !tbaa !21
  store i64 0, ptr %l9, !tbaa !24
  store i1 false, ptr %l10, !tbaa !21
  store i1 false, ptr %l11, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d121 }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d122 }, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  store i1 false, ptr %l16, !tbaa !21
  store { i64, ptr } { i64 0, ptr @.d123 }, ptr %l17, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t6 = insertvalue %"compiler/build:Config" undef, { i64, ptr } %t5, 0
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = insertvalue %"compiler/build:Config" %t6, { i64, ptr } %t7, 1
  %t9 = load %"compiler/target:Target", ptr %l2
  %t10 = insertvalue %"compiler/build:Config" %t8, %"compiler/target:Target" %t9, 2
  %t11 = load %"compiler/cond:Consts", ptr %l3
  %t12 = insertvalue %"compiler/build:Config" %t10, %"compiler/cond:Consts" %t11, 3
  %t13 = load i1, ptr %l4, !tbaa !21
  %t14 = insertvalue %"compiler/build:Config" %t12, i1 %t13, 4
  %t15 = load i1, ptr %l5, !tbaa !21
  %t16 = insertvalue %"compiler/build:Config" %t14, i1 %t15, 5
  %t17 = load i1, ptr %l6, !tbaa !21
  %t18 = insertvalue %"compiler/build:Config" %t16, i1 %t17, 6
  %t19 = load i1, ptr %l7, !tbaa !21
  %t20 = insertvalue %"compiler/build:Config" %t18, i1 %t19, 7
  %t21 = load i1, ptr %l8, !tbaa !21
  %t22 = insertvalue %"compiler/build:Config" %t20, i1 %t21, 8
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = insertvalue %"compiler/build:Config" %t22, i64 %t23, 9
  %t25 = load i1, ptr %l10, !tbaa !21
  %t26 = insertvalue %"compiler/build:Config" %t24, i1 %t25, 10
  %t27 = load i1, ptr %l11, !tbaa !21
  %t28 = insertvalue %"compiler/build:Config" %t26, i1 %t27, 11
  %t29 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t30 = insertvalue %"compiler/build:Config" %t28, { i64, ptr } %t29, 12
  %t31 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t32 = insertvalue %"compiler/build:Config" %t30, { i64, ptr } %t31, 13
  %t33 = load i64, ptr %l14, !tbaa !24
  %t34 = insertvalue %"compiler/build:Config" %t32, i64 %t33, 14
  %t35 = load i64, ptr %l15, !tbaa !24
  %t36 = insertvalue %"compiler/build:Config" %t34, i64 %t35, 15
  %t37 = load i1, ptr %l16, !tbaa !21
  %t38 = insertvalue %"compiler/build:Config" %t36, i1 %t37, 16
  %t39 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t40 = insertvalue %"compiler/build:Config" %t38, { i64, ptr } %t39, 17
  store %"compiler/build:Config" %t40, ptr %l20
  call void @__olang_scope_close(ptr %s0)
  %t41 = load %"compiler/build:Config", ptr %l20
  store %"compiler/build:Config" %t41, ptr %out
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/build:Unit>"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List<compiler/build:Unit>"
  %l4 = alloca %"compiler/build:Program"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:Program"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/build:Unit>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %t1)
  store %"std/prelude/list:List<compiler/build:Unit>" %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<compiler/build:Unit>", ptr %l3
  store %"std/prelude/list:List<compiler/build:Unit>" %t3, ptr %l0
  store { i64, ptr } { i64 0, ptr @.d124 }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d125 }, ptr %l2, !tbaa !27
  %t4 = load %"std/prelude/list:List<compiler/build:Unit>", ptr %l0
  %t5 = insertvalue %"compiler/build:Program" undef, %"std/prelude/list:List<compiler/build:Unit>" %t4, 0
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = insertvalue %"compiler/build:Program" %t5, { i64, ptr } %t6, 1
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = insertvalue %"compiler/build:Program" %t7, { i64, ptr } %t8, 2
  store %"compiler/build:Program" %t9, ptr %l4
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"compiler/build:Program", ptr %l4
  store %"compiler/build:Program" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Program", ptr %rv
  ret %"compiler/build:Program" %rr
}

define dso_local %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca [8 x i32]
  %l1 = alloca [64 x i8]
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca [8 x i32]
  %l5 = alloca %"compiler/build:Sha256"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:Sha256"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x i32] undef, i32 1779033703, 0
  %t2 = insertvalue [8 x i32] %t1, i32 -1150833019, 1
  %t3 = insertvalue [8 x i32] %t2, i32 1013904242, 2
  %t4 = insertvalue [8 x i32] %t3, i32 -1521486534, 3
  %t5 = insertvalue [8 x i32] %t4, i32 1359893119, 4
  %t6 = insertvalue [8 x i32] %t5, i32 -1694144372, 5
  %t7 = insertvalue [8 x i32] %t6, i32 528734635, 6
  %t8 = insertvalue [8 x i32] %t7, i32 1541459225, 7
  store [8 x i32] %t8, ptr %l4
  %t9 = load [8 x i32], ptr %l4
  store [8 x i32] %t9, ptr %l0
  store [64 x i8] zeroinitializer, ptr %l1
  store i64 0, ptr %l2, !tbaa !24
  store i64 0, ptr %l3, !tbaa !24
  %t10 = load [8 x i32], ptr %l0
  %t11 = insertvalue %"compiler/build:Sha256" undef, [8 x i32] %t10, 0
  %t12 = load [64 x i8], ptr %l1
  %t13 = insertvalue %"compiler/build:Sha256" %t11, [64 x i8] %t12, 1
  %t14 = load i64, ptr %l2, !tbaa !24
  %t15 = insertvalue %"compiler/build:Sha256" %t13, i64 %t14, 2
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = insertvalue %"compiler/build:Sha256" %t15, i64 %t16, 3
  store %"compiler/build:Sha256" %t17, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/build:Sha256", ptr %l5
  store %"compiler/build:Sha256" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Sha256", ptr %rv
  ret %"compiler/build:Sha256" %rr
}

define dso_local %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/build:Unit"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:Unit"
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l6, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t2, ptr %l3, !tbaa !27
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l7
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = insertvalue %"compiler/build:Unit" undef, { i64, ptr } %t7, 0
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/build:Unit" %t8, i32 %t9, 1
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = insertvalue %"compiler/build:Unit" %t10, { i64, ptr } %t11, 2
  store %"compiler/build:Unit" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/build:Unit", ptr %l9
  store %"compiler/build:Unit" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Unit", ptr %rv
  ret %"compiler/build:Unit" %rr
}

define dso_local %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  %l1 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l2 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l3 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l4 = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  %l5 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l6 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l7 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l8 = alloca %"compiler/build:compiles"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:compiles"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %t1)
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %l4
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t4)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l5
  store %"std/prelude/list:List<std/prelude/text:String&>" %t6, ptr %l1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t8, ptr %l6
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l6
  store %"std/prelude/list:List<std/prelude/text:String&>" %t9, ptr %l2
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t10)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t11, ptr %l7
  br label %bb4
bb4:
  %t12 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l7
  store %"std/prelude/list:List<std/prelude/text:String&>" %t12, ptr %l3
  %t13 = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %l0
  %t14 = insertvalue %"compiler/build:compiles" undef, %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t13, 0
  %t15 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l1
  %t16 = insertvalue %"compiler/build:compiles" %t14, %"std/prelude/list:List<std/prelude/text:String&>" %t15, 1
  %t17 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l2
  %t18 = insertvalue %"compiler/build:compiles" %t16, %"std/prelude/list:List<std/prelude/text:String&>" %t17, 2
  %t19 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l3
  %t20 = insertvalue %"compiler/build:compiles" %t18, %"std/prelude/list:List<std/prelude/text:String&>" %t19, 3
  store %"compiler/build:compiles" %t20, ptr %l8
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/build:compiles", ptr %l8
  store %"compiler/build:compiles" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:compiles", ptr %rv
  ret %"compiler/build:compiles" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fbuild() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_2eThinFrom_2einit()
  br label %bb1
bb1:
  call void @compiler_2fbuild_2eShaK_2einit()
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:267: reached unreachable code\0A\00"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.c1 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:310: array length out of range\0A\00"
@.c2 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:311: array length out of range\0A\00"
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.c3 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:315: reached unreachable code\0A\00"
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task4(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load ptr, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2fbuild_2erunner(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

declare i64 @__olang_join_tasks(ptr)
@.d5 = private constant [1 x i8] c"/"
declare void @__olang_sb_put(ptr, ptr, i64)
declare void @__olang_sb_done(ptr)
@.d6 = private constant [2 x i8] c"./"
@.d7 = private constant [6 x i8] c"Hangup"
@.d8 = private constant [9 x i8] c"Interrupt"
@.d9 = private constant [4 x i8] c"Quit"
@.d10 = private constant [19 x i8] c"Illegal instruction"
@.d11 = private constant [21 x i8] c"Trace/breakpoint trap"
@.d12 = private constant [7 x i8] c"Aborted"
@.d13 = private constant [9 x i8] c"Bus error"
@.d14 = private constant [24 x i8] c"Floating point exception"
@.d15 = private constant [6 x i8] c"Killed"
@.d16 = private constant [18 x i8] c"Segmentation fault"
@.d17 = private constant [11 x i8] c"Broken pipe"
@.d18 = private constant [11 x i8] c"Alarm clock"
@.d19 = private constant [10 x i8] c"Terminated"
@.d20 = private constant [15 x i8] c"Unknown signal "
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.c21 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:625: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

@.d22 = private constant [4 x i8] c"test"
@.d23 = private constant [0 x i8] c""
@.d24 = private constant [0 x i8] c""
@.c25 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:605: reached unreachable code\0A\00"
@.d26 = private constant [35 x i8] c": lost track of its build, skipping"
@.d27 = private constant [2 x i8] c"31"
@.d28 = private constant [22 x i8] c": the compiler ended ("
@.d29 = private constant [11 x i8] c"), skipping"
@.d30 = private constant [2 x i8] c"31"
@.d31 = private constant [62 x i8] c"olang: error: the self-hosted compiler cannot build this yet: "
@.d32 = private constant [6 x i8] c"bfloat"
@.d33 = private constant [6 x i8] c"-mllvm"
@.d34 = private constant [16 x i8] c"-fast-isel=false"
@.d35 = private constant [26 x i8] c"-Wl,-plugin-opt,cache-dir="
@.d36 = private constant [8 x i8] c"/thinlto"
@.d37 = private constant [2 x i8] c"-o"
@.d38 = private constant [3 x i8] c"-lm"
@.d39 = private constant [9 x i8] c"-lpthread"
@.d40 = private constant [4 x i8] c"-ldl"
@.d41 = private constant [5 x i8] c"-lffi"
@.d42 = private constant [5 x i8] c".link"
@.d43 = private constant [0 x i8] c""
@.d44 = private constant [0 x i8] c""
@.d45 = private constant [0 x i8] c""
@.d46 = private constant [1 x i8] c" "
@.d47 = private constant [1 x i8] c" "
@.d48 = private constant [1 x i8] c"\0A"
@.d49 = private constant [9 x i8] c"--target="
@.d50 = private constant [0 x i8] c""
@.d51 = private constant [3 x i8] c"-O0"
@.d52 = private constant [2 x i8] c"-g"
@.d53 = private constant [17 x i8] c"-fsanitize=thread"
@.d54 = private constant [3 x i8] c"-O1"
@.d55 = private constant [17 x i8] c"-fsanitize=thread"
@.d56 = private constant [3 x i8] c"-O3"
@.d57 = private constant [10 x i8] c"-flto=thin"
@.d58 = private constant [5 x i8] c"-flto"
@.c59 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:298: reached unreachable code\0A\00"
@.c60 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:301: slice bounds out of range\0A\00"
@.d61 = private constant [1 x i8] c"/"
@.d62 = private constant [1 x i8] c"."
@.d63 = private constant [2 x i8] c".o"
@.d64 = private constant [0 x i8] c""
@.d65 = private constant [13 x i8] c"olang_runtime"
@.d66 = private constant [0 x i8] c""
@.d67 = private constant [13 x i8] c"olang_dyncall"
@.d68 = private constant [0 x i8] c""
@.d69 = private constant [0 x i8] c""
@.d70 = private constant [9 x i8] c"--version"
@.d71 = private constant [0 x i8] c""
@.d72 = private constant [0 x i8] c""
@.c73 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:154: reached unreachable code\0A\00"
@.d74 = private constant [0 x i8] c""
@.d75 = private constant [5 x i8] c".race"
@.d76 = private constant [0 x i8] c""
@.d77 = private constant [6 x i8] c".debug"
@.d78 = private constant [0 x i8] c""
@.d79 = private constant [4 x i8] c".san"
@.d80 = private constant [0 x i8] c""
@.d81 = private constant [1 x i8] c"["
@.d82 = private constant [1 x i8] c"m"
@.d83 = private constant [3 x i8] c"[0m"
@.d84 = private constant [27 x i8] c": semantic errors, skipping"
@.d85 = private constant [2 x i8] c"31"
@.d86 = private constant [27 x i8] c": cannot be built, skipping"
@.d87 = private constant [2 x i8] c"31"
@.c88 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:351: slice bounds out of range\0A\00"
@.d89 = private constant [3 x i8] c".ll"
@.d90 = private constant [0 x i8] c""
declare i32 @getpid()
@.d91 = private constant [1 x i8] c"."
@.d92 = private constant [4 x i8] c".tmp"
@.d93 = private constant [2 x i8] c"-c"
@.d94 = private constant [2 x i8] c"-o"
declare i64 @sysconf(i32)
@.c95 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:490: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d96 = private constant [1 x i8] c"a"
@.c97 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:260: reached unreachable code\0A\00"
@.d98 = private constant [0 x i8] c""
@.d99 = private constant [0 x i8] c""
@.d100 = private constant [0 x i8] c""
@.d101 = private constant [5 x i8] c".main"
@.d102 = private constant [5 x i8] c".test"
@.d103 = private constant [5 x i8] c".inst"
@.c104 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:285: reached unreachable code\0A\00"
@.c105 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:449: reached unreachable code\0A\00"
@.c106 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:450: reached unreachable code\0A\00"
@.d107 = private constant [1 x i8] c" "
@.d108 = private constant [1 x i8] c" "
@.d109 = private constant [1 x i8] c"\0A"
@.c110 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:325: reached unreachable code\0A\00"
@.d111 = private constant [0 x i8] c""
@.d112 = private constant [0 x i8] c""
@.c113 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:326: reached unreachable code\0A\00"
@.d114 = private constant [11 x i8] c"cannot run "
@.d115 = private constant [1 x i8] c"\0A"
@.c116 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:460: reached unreachable code\0A\00"
@.c117 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:462: reached unreachable code\0A\00"
@.c118 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:461: reached unreachable code\0A\00"
@.d119 = private constant [5 x i8] c"build"
@.d120 = private constant [0 x i8] c""
@.d121 = private constant [0 x i8] c""
@.d122 = private constant [0 x i8] c""
@.d123 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<compiler/build:Unit>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/build:Unit>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/build:Unit>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/build:Unit>" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/build:Unit>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/build:Unit>", ptr %l0
  store %"std/prelude/list:List<compiler/build:Unit>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/build:Unit>", ptr %rv
  ret %"std/prelude/list:List<compiler/build:Unit>" %rr
}

@.d124 = private constant [0 x i8] c""
@.d125 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %l0
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %rv
  ret %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @std_2fchan_2eInit_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
declare %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/build:Unit>" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
