; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Sha256" = type { [8 x i32], [64 x i8], i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/chan:Chan.2cbf9f1a83f145a06a7c468d5d4e63f8" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, %"<pthread.h>:pthread_mutex_t", %"<pthread.h>:pthread_cond_t", %"<pthread.h>:pthread_cond_t" }
%"<pthread.h>:pthread_mutex_t" = type { [5 x i64] }
%"<pthread.h>:pthread_cond_t" = type { [6 x i64] }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:compiles" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:stubFrontend" = type { i64, i64 }
@G_2ecompiler_2fbuild_2eImportLimit = constant <{ [8 x i8] }> <{ [8 x i8] c"\46\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbuild_2ePhaseAt = global i64 zeroinitializer
@G_2ecompiler_2fbuild_2eShaK = constant <{ [256 x i8] }> <{ [256 x i8] c"\98\2F\8A\42\91\44\37\71\CF\FB\C0\B5\A5\DB\B5\E9\5B\C2\56\39\F1\11\F1\59\A4\82\3F\92\D5\5E\1C\AB\98\AA\07\D8\01\5B\83\12\BE\85\31\24\C3\7D\0C\55\74\5D\BE\72\FE\B1\DE\80\A7\06\DC\9B\74\F1\9B\C1\C1\69\9B\E4\86\47\BE\EF\C6\9D\C1\0F\CC\A1\0C\24\6F\2C\E9\2D\AA\84\74\4A\DC\A9\B0\5C\DA\88\F9\76\52\51\3E\98\6D\C6\31\A8\C8\27\03\B0\C7\7F\59\BF\F3\0B\E0\C6\47\91\A7\D5\51\63\CA\06\67\29\29\14\85\0A\B7\27\38\21\1B\2E\FC\6D\2C\4D\13\0D\38\53\54\73\0A\65\BB\0A\6A\76\2E\C9\C2\81\85\2C\72\92\A1\E8\BF\A2\4B\66\1A\A8\70\8B\4B\C2\A3\51\6C\C7\19\E8\92\D1\24\06\99\D6\85\35\0E\F4\70\A0\6A\10\16\C1\A4\19\08\6C\37\1E\4C\77\48\27\B5\BC\B0\34\B3\0C\1C\39\4A\AA\D8\4E\4F\CA\9C\5B\F3\6F\2E\68\EE\82\8F\74\6F\63\A5\78\14\78\C8\84\08\02\C7\8C\FA\FF\BE\90\EB\6C\50\A4\F7\A3\F9\BE\F2\78\71\C6" }>, align 64
@G_2ecompiler_2fbuild_2eThinFrom = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"compiler/build:Sha256"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l5
  store %"compiler/build:Sha256" %t2, ptr %l1
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb3
bb3:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t20)
  br label %bb8
bb8:
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %s2, ptr %l1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  %t31 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t31, ptr %l22
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2eImportLimit_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 70, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i8
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load i1, ptr %l10, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l11, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 6
  store i64 %t14, ptr %l14, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = icmp sge i64 0, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  br label %bb11
bb5:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = icmp sle i64 0, %t19
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb7:
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb9:
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = getelementptr i8, ptr %t27, i64 0
  %t30 = sub i64 %t28, 0
  %t31 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb11:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l20
  br label %bb12
bb12:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t35, ptr %l2
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l5, !tbaa !24
  br label %bb13
bb13:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  br label %bb16
bb16:
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l28, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t51
  %t56 = load i8, ptr %t55, !tbaa !32
  store i8 %t56, ptr %l6, !tbaa !22
  store ptr %l2, ptr %l31, !tbaa !29
  %t58 = load i8, ptr %l6, !tbaa !22
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t58)
  store i1 %t60, ptr %l33
  br label %bb17
bb17:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t62 = load i8, ptr %l6, !tbaa !22
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t62)
  store i1 %t64, ptr %l36
  br label %bb20
bb20:
  %t65 = load i1, ptr %l36, !tbaa !21
  store i1 %t65, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb23:
  %t67 = load i8, ptr %l6, !tbaa !22
  %t69 = icmp eq i8 %t67, 95
  store i1 %t69, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t71 = load i1, ptr %l37, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  %t72 = load i8, ptr %l6, !tbaa !22
  store i8 %t72, ptr %l40, !tbaa !22
  br label %bb27
bb26:
  store i8 95, ptr %l40, !tbaa !22
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i8, ptr %l40, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t74, i8 %t75)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l4, !tbaa !24
  br label %bb13
bb30:
  %t81 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t81, ptr %l45
  br label %bb31
bb31:
  %t82 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t82, ptr %l46, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l47, !tbaa !24
  %t85 = load i64, ptr %l47, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l48, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l47, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t96, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l8 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d2, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb4
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l7, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb4:
  %t11 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  %t12 = call i64 @std_2ftime_2eNow()
  store i64 %t12, ptr %l8
  br label %bb5
bb5:
  %t13 = load i64, ptr %l8, !tbaa !24
  store i64 %t13, ptr %l2, !tbaa !24
  %t14 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t16 = icmp ne i64 %t14, 0
  br i1 %t16, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t19 = load i64, ptr %l2, !tbaa !24
  %t20 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t25 = sdiv i64 %t23, 1000000
  %t26 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t29 = extractvalue { i64, ptr } %t18, 1
  %t30 = extractvalue { i64, ptr } %t18, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t36 = call i64 @__olang_fmt_i64(ptr null, i64 %t25)
  %t37 = add i64 %t34, %t36
  %t38 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t41 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t40)
  call void @olang_textcopy(ptr %t41, ptr %t26, i64 %t27)
  %t42 = getelementptr i8, ptr %t41, i64 %t27
  call void @olang_textcopy(ptr %t42, ptr %t29, i64 %t30)
  %t43 = getelementptr i8, ptr %t42, i64 %t30
  call void @olang_textcopy(ptr %t43, ptr %t32, i64 %t33)
  %t44 = getelementptr i8, ptr %t43, i64 %t33
  %t45 = call i64 @__olang_fmt_i64(ptr %t44, i64 %t25)
  %t46 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t46, ptr %t38, i64 %t39)
  %t47 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t41, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = extractvalue { i64, ptr } %t48, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  call void @compiler_2fbuild_2esayErr(ptr %s2, { i64, ptr } %t55)
  br label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  %t57 = load i64, ptr %l2, !tbaa !24
  store i64 %t57, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t59 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t61 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t59, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t61, ptr %l20
  br label %bb10
bb10:
  %t62 = load i1, ptr %l20, !tbaa !21
  br i1 %t62, label %bb11, label %bb12
bb11:
  %t63 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t65, ptr %l23
  br label %bb13
bb12:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb14
bb13:
  %t66 = load i1, ptr %l23, !tbaa !21
  store i1 %t66, ptr %l21, !tbaa !21
  br label %bb14
bb14:
  %t67 = load i1, ptr %l21, !tbaa !21
  br i1 %t67, label %bb15, label %bb16
bb15:
  call void @std_2fos_2eExit(i32 0)
  unreachable
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_1a0af222d89a1264_6ae848cde6020298)
  unreachable
bb18:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ePhaseAt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ePid() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @getpid()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i8
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t25)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t29 = load i8, ptr %l5, !tbaa !22
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t29)
  store i1 %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load i1, ptr %l22, !tbaa !21
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i8, ptr %l5, !tbaa !22
  %t36 = icmp eq i8 %t34, 95
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t39 = load i8, ptr %l5, !tbaa !22
  %t41 = icmp eq i8 %t39, 45
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t44 = load i8, ptr %l5, !tbaa !22
  store i8 %t44, ptr %l29, !tbaa !22
  br label %bb19
bb18:
  store i8 95, ptr %l29, !tbaa !22
  br label %bb19
bb19:
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t47 = load i8, ptr %l29, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t46, i8 %t47)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb22:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l41 = alloca { { i64, ptr }, { i64, ptr } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l88 = alloca %"std/chan:Chan.2cbf9f1a83f145a06a7c468d5d4e63f8"
  %l98 = alloca { i64, ptr }
  %l103 = alloca i32
  %l105 = alloca i1
  %l111 = alloca i64
  %l118 = alloca i64
  %l121 = alloca i64
  %l150 = alloca { { i64, ptr }, { i64, ptr } }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %jh10 = alloca ptr
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t28 = alloca i64
  %t168 = alloca { { i64, ptr }, ptr }, align 8
  %t179 = alloca %"std/chan:Chan.2cbf9f1a83f145a06a7c468d5d4e63f8", align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l27, !tbaa !24
  %t6 = load i64, ptr %l27, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l27, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb3:
  %t12 = load i64, ptr %l27, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = load i64, ptr %l31, !tbaa !24
  %t20 = icmp sge i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb5:
  %t22 = load i64, ptr %l31, !tbaa !24
  %t23 = icmp sle i64 %t22, 576460752303423487
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb7:
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = mul i64 %t25, 16
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t25
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, ptr }, ptr %t27, i64 %t32
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t27, 1
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb9:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t43, 0
  %t50 = insertvalue { { i64, ptr }, { i64, ptr } } %t48, { i64, ptr } %t45, 1
  store { { i64, ptr }, { i64, ptr } } %t50, ptr %l41
  %t51 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l42, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l43, !tbaa !24
  %t55 = load i64, ptr %l43, !tbaa !24
  %t56 = mul i64 %t55, 4
  %t57 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l44, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = mul i64 %t64, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  %t68 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l45, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l46, !tbaa !24
  %t72 = load i64, ptr %l46, !tbaa !24
  %t73 = mul i64 %t72, 16
  %t74 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = mul i64 %t81, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t84 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  store { i64, ptr } %t83, ptr %t84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { { i64, ptr }, { i64, ptr } }, ptr %l41
  store { { i64, ptr }, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb12, label %bb13
bb12:
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = icmp sle i64 %t90, 1152921504606846975
  br i1 %t91, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb14:
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = mul i64 %t93, 8
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l3, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb16:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb18:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l59, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t127 = load i64, ptr %l59, !tbaa !24
  store i64 %t127, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  %t129 = load i64, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t137 = load i64, ptr %l7, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i64, ptr %t152, i64 %t147
  store i64 %t148, ptr %t153, !tbaa !34
  br label %bb26
bb26:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l11, !tbaa !24
  br label %bb22
bb27:
  %t158 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t162 = icmp sgt i64 %t160, 0
  br i1 %t162, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t164 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t166 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t167 = ptrtoint ptr %t166 to i64
  %t169 = getelementptr { { i64, ptr }, ptr }, ptr %t168, i32 0, i32 0
  store { i64, ptr } %t165, ptr %t169, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t171 = getelementptr { { i64, ptr }, ptr }, ptr %t168, i32 0, i32 1
  store ptr %v1, ptr %t171, !tbaa !28
  %t172 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_9, 0
  %t173 = insertvalue { ptr, ptr } %t172, ptr %t168, 1
  %t176 = extractvalue { ptr, ptr } %t173, 0
  %t177 = extractvalue { ptr, ptr } %t173, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s5, { i64, ptr } %t164, ptr %t176, ptr %t177)
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t178 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %t179, ptr %s0, i64 %t178)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t179, i64 216, i1 false)
  br label %bb32
bb32:
  %t181 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 216, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %l88, i64 216, i1 false)
  store ptr %t181, ptr %l13, !tbaa !29
  %t183 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eInit_3cI64_3e(ptr %s0, ptr %t183)
  br label %bb33
bb33:
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t185, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t199, ptr %l98, !tbaa !27
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i64, ptr %t203, i64 %t200
  %t205 = load i64, ptr %t204, !tbaa !34
  %t207 = load ptr, ptr %l13, !tbaa !29
  %t211 = call i32 @std_2fchan_2eSend_3cI64_3e(ptr %s0, ptr %t207, i64 %t205)
  store i32 %t211, ptr %l103
  %t212 = icmp ne i32 %t211, 0
  br i1 %t212, label %bb39, label %ok.213
ok.213:
  br label %bb38
bb38:
  br label %bb41
bb39:
  %t214 = load i32, ptr %l103, !tbaa !23
  %t215 = ashr i32 %t214, 16
  %t217 = icmp eq i32 %t215, 1
  store i1 %t217, ptr %l105, !tbaa !21
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_1359a9f97975288c_a8d4abcb606172b0)
  unreachable
bb41:
  br label %bb42
bb42:
  %t218 = load i64, ptr %l15, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l15, !tbaa !24
  br label %bb34
bb43:
  %t222 = load i64, ptr %l1, !tbaa !24
  %t223 = load i64, ptr %l3, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  br i1 %t226, label %bb44, label %bb45
bb44:
  %t228 = load i64, ptr %l1, !tbaa !24
  store i64 %t228, ptr %l111, !tbaa !24
  br label %bb46
bb45:
  %t230 = load i64, ptr %l3, !tbaa !24
  store i64 %t230, ptr %l111, !tbaa !24
  br label %bb46
bb46:
  %t232 = load i64, ptr %l111, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s10
  store ptr null, ptr %jh10
  store i64 0, ptr %l19, !tbaa !24
  store i64 %t232, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t235 = load i64, ptr %l20, !tbaa !24
  %t236 = load i64, ptr %l19, !tbaa !24
  %t239 = icmp sgt i64 %t235, %t236
  br i1 %t239, label %bb47, label %bb48
bb47:
  %t241 = load i64, ptr %l21, !tbaa !24
  %t243 = icmp sgt i64 %t241, 0
  br i1 %t243, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb52
bb49:
  %t245 = load i64, ptr %l20, !tbaa !24
  %t246 = load i64, ptr %l19, !tbaa !24
  %t249 = sub i64 %t245, %t246
  %t250 = load i64, ptr %l21, !tbaa !24
  %t253 = add i64 %t249, %t250
  %t255 = sub i64 %t253, 1
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = sdiv i64 %t255, %t256
  store i64 %t259, ptr %l121, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb51
bb51:
  %t261 = load i64, ptr %l121, !tbaa !24
  store i64 %t261, ptr %l118, !tbaa !24
  br label %bb52
bb52:
  %t262 = load i64, ptr %l118, !tbaa !24
  store i64 %t262, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb53
bb53:
  %t263 = load i64, ptr %l23, !tbaa !24
  %t264 = load i64, ptr %l22, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  br label %bb56
bb56:
  %t271 = load i64, ptr %l19, !tbaa !24
  %t272 = load i64, ptr %l23, !tbaa !24
  %t273 = load i64, ptr %l21, !tbaa !24
  %t276 = mul i64 %t272, %t273
  %t279 = add i64 %t271, %t276
  store i64 %t279, ptr %l24, !tbaa !24
  %t281 = load ptr, ptr %l13, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t289 = call ptr @__olang_standin(ptr %s0)
  %t290 = call ptr @__olang_standin(ptr %v0)
  %t291 = call ptr @__olang_standin(ptr %v2)
  %t292 = call ptr @__olang_standin(ptr %v2)
  %t293 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t294 = ptrtoint ptr %t293 to i64
  %t295 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 %t294, i64 8)
  %t296 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 0
  store ptr %t281, ptr %t296
  %t297 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 1
  store { i64, ptr } %t282, ptr %t297
  %t298 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 2
  store { i64, ptr } %t283, ptr %t298
  %t299 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 3
  store { i64, ptr } %t284, ptr %t299
  %t300 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 4
  store ptr %t289, ptr %t300
  %t301 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 5
  store ptr %t290, ptr %t301
  %t302 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 6
  store ptr %t291, ptr %t302
  %t303 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 7
  store ptr %t292, ptr %t303
  %t304 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  %t305 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr null, ptr %t305
  %t306 = getelementptr { ptr, ptr }, ptr %t305, i32 0, i32 1
  store ptr %t289, ptr %t306
  %t307 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t305, ptr %t307
  %t308 = getelementptr { ptr, ptr }, ptr %t307, i32 0, i32 1
  store ptr %t290, ptr %t308
  %t309 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t307, ptr %t309
  %t310 = getelementptr { ptr, ptr }, ptr %t309, i32 0, i32 1
  store ptr %t291, ptr %t310
  %t311 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t309, ptr %t311
  %t312 = getelementptr { ptr, ptr }, ptr %t311, i32 0, i32 1
  store ptr %t292, ptr %t312
  %t313 = getelementptr { ptr, i64, ptr, i64 }, ptr %t304, i32 0, i32 2
  store ptr %t311, ptr %t313
  %t314 = getelementptr { ptr, i64, ptr, i64 }, ptr %t304, i32 0, i32 1
  store i64 0, ptr %t314
  %t315 = getelementptr { ptr, i64, ptr, i64 }, ptr %t304, i32 0, i32 3
  store i64 0, ptr %t315
  %t316 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t316, ptr @olang_task10, ptr %t295, ptr %t304)
  %t317 = load ptr, ptr %jh10
  store ptr %t317, ptr %t304
  store ptr %t304, ptr %jh10
  br label %bb57
bb57:
  %t318 = load i64, ptr %l23, !tbaa !24
  %t320 = add i64 %t318, 1
  store i64 %t320, ptr %l23, !tbaa !24
  br label %bb53
bb58:
  %t322 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eClose_3cI64_3e(ptr %s0, ptr %t322)
  br label %bb59
bb59:
  %t324 = call i64 @__olang_join_tasks(ptr %jh10)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb61:
  %t325 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t330 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t325, 0
  %t332 = insertvalue { { i64, ptr }, { i64, ptr } } %t330, { i64, ptr } %t327, 1
  store { { i64, ptr }, { i64, ptr } } %t332, ptr %l150
  %t333 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 0
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  store { i64, ptr } %t334, ptr %l151, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  store i64 %t336, ptr %l152, !tbaa !24
  %t337 = load i64, ptr %l152, !tbaa !24
  %t338 = mul i64 %t337, 4
  %t339 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t338)
  %t340 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  store { i64, ptr } %t341, ptr %l153, !tbaa !27
  %t342 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = load i64, ptr %l152, !tbaa !24
  %t347 = mul i64 %t346, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t343, ptr %t345, i64 %t347, i1 false)
  %t348 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t349 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 0
  store { i64, ptr } %t348, ptr %t349, !tbaa !27
  %t350 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 1
  %t351 = load { i64, ptr }, ptr %t350, !tbaa !27
  store { i64, ptr } %t351, ptr %l154, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t352, 0
  store i64 %t353, ptr %l155, !tbaa !24
  %t354 = load i64, ptr %l155, !tbaa !24
  %t355 = mul i64 %t354, 16
  %t356 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t355)
  %t357 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t356, 1
  store { i64, ptr } %t358, ptr %l156, !tbaa !27
  %t359 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t362 = load ptr, ptr %t361, !tbaa !27
  %t363 = load i64, ptr %l155, !tbaa !24
  %t364 = mul i64 %t363, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t360, ptr %t362, i64 %t364, i1 false)
  %t365 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t366 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 1
  store { i64, ptr } %t365, ptr %t366, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t367 = load { { i64, ptr }, { i64, ptr } }, ptr %l150
  store { { i64, ptr }, { i64, ptr } } %t367, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbuild_2eShaK_2einit() #0 {
entry:
  %l0 = alloca [64 x i32]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [64 x i32], ptr %l0, i64 0, i64 0
  store i32 1116352408, ptr %t1
  %t2 = getelementptr [64 x i32], ptr %l0, i64 0, i64 1
  store i32 1899447441, ptr %t2
  %t3 = getelementptr [64 x i32], ptr %l0, i64 0, i64 2
  store i32 -1245643825, ptr %t3
  %t4 = getelementptr [64 x i32], ptr %l0, i64 0, i64 3
  store i32 -373957723, ptr %t4
  %t5 = getelementptr [64 x i32], ptr %l0, i64 0, i64 4
  store i32 961987163, ptr %t5
  %t6 = getelementptr [64 x i32], ptr %l0, i64 0, i64 5
  store i32 1508970993, ptr %t6
  %t7 = getelementptr [64 x i32], ptr %l0, i64 0, i64 6
  store i32 -1841331548, ptr %t7
  %t8 = getelementptr [64 x i32], ptr %l0, i64 0, i64 7
  store i32 -1424204075, ptr %t8
  %t9 = getelementptr [64 x i32], ptr %l0, i64 0, i64 8
  store i32 -670586216, ptr %t9
  %t10 = getelementptr [64 x i32], ptr %l0, i64 0, i64 9
  store i32 310598401, ptr %t10
  %t11 = getelementptr [64 x i32], ptr %l0, i64 0, i64 10
  store i32 607225278, ptr %t11
  %t12 = getelementptr [64 x i32], ptr %l0, i64 0, i64 11
  store i32 1426881987, ptr %t12
  %t13 = getelementptr [64 x i32], ptr %l0, i64 0, i64 12
  store i32 1925078388, ptr %t13
  %t14 = getelementptr [64 x i32], ptr %l0, i64 0, i64 13
  store i32 -2132889090, ptr %t14
  %t15 = getelementptr [64 x i32], ptr %l0, i64 0, i64 14
  store i32 -1680079193, ptr %t15
  %t16 = getelementptr [64 x i32], ptr %l0, i64 0, i64 15
  store i32 -1046744716, ptr %t16
  %t17 = getelementptr [64 x i32], ptr %l0, i64 0, i64 16
  store i32 -459576895, ptr %t17
  %t18 = getelementptr [64 x i32], ptr %l0, i64 0, i64 17
  store i32 -272742522, ptr %t18
  %t19 = getelementptr [64 x i32], ptr %l0, i64 0, i64 18
  store i32 264347078, ptr %t19
  %t20 = getelementptr [64 x i32], ptr %l0, i64 0, i64 19
  store i32 604807628, ptr %t20
  %t21 = getelementptr [64 x i32], ptr %l0, i64 0, i64 20
  store i32 770255983, ptr %t21
  %t22 = getelementptr [64 x i32], ptr %l0, i64 0, i64 21
  store i32 1249150122, ptr %t22
  %t23 = getelementptr [64 x i32], ptr %l0, i64 0, i64 22
  store i32 1555081692, ptr %t23
  %t24 = getelementptr [64 x i32], ptr %l0, i64 0, i64 23
  store i32 1996064986, ptr %t24
  %t25 = getelementptr [64 x i32], ptr %l0, i64 0, i64 24
  store i32 -1740746414, ptr %t25
  %t26 = getelementptr [64 x i32], ptr %l0, i64 0, i64 25
  store i32 -1473132947, ptr %t26
  %t27 = getelementptr [64 x i32], ptr %l0, i64 0, i64 26
  store i32 -1341970488, ptr %t27
  %t28 = getelementptr [64 x i32], ptr %l0, i64 0, i64 27
  store i32 -1084653625, ptr %t28
  %t29 = getelementptr [64 x i32], ptr %l0, i64 0, i64 28
  store i32 -958395405, ptr %t29
  %t30 = getelementptr [64 x i32], ptr %l0, i64 0, i64 29
  store i32 -710438585, ptr %t30
  %t31 = getelementptr [64 x i32], ptr %l0, i64 0, i64 30
  store i32 113926993, ptr %t31
  %t32 = getelementptr [64 x i32], ptr %l0, i64 0, i64 31
  store i32 338241895, ptr %t32
  %t33 = getelementptr [64 x i32], ptr %l0, i64 0, i64 32
  store i32 666307205, ptr %t33
  %t34 = getelementptr [64 x i32], ptr %l0, i64 0, i64 33
  store i32 773529912, ptr %t34
  %t35 = getelementptr [64 x i32], ptr %l0, i64 0, i64 34
  store i32 1294757372, ptr %t35
  %t36 = getelementptr [64 x i32], ptr %l0, i64 0, i64 35
  store i32 1396182291, ptr %t36
  %t37 = getelementptr [64 x i32], ptr %l0, i64 0, i64 36
  store i32 1695183700, ptr %t37
  %t38 = getelementptr [64 x i32], ptr %l0, i64 0, i64 37
  store i32 1986661051, ptr %t38
  %t39 = getelementptr [64 x i32], ptr %l0, i64 0, i64 38
  store i32 -2117940946, ptr %t39
  %t40 = getelementptr [64 x i32], ptr %l0, i64 0, i64 39
  store i32 -1838011259, ptr %t40
  %t41 = getelementptr [64 x i32], ptr %l0, i64 0, i64 40
  store i32 -1564481375, ptr %t41
  %t42 = getelementptr [64 x i32], ptr %l0, i64 0, i64 41
  store i32 -1474664885, ptr %t42
  %t43 = getelementptr [64 x i32], ptr %l0, i64 0, i64 42
  store i32 -1035236496, ptr %t43
  %t44 = getelementptr [64 x i32], ptr %l0, i64 0, i64 43
  store i32 -949202525, ptr %t44
  %t45 = getelementptr [64 x i32], ptr %l0, i64 0, i64 44
  store i32 -778901479, ptr %t45
  %t46 = getelementptr [64 x i32], ptr %l0, i64 0, i64 45
  store i32 -694614492, ptr %t46
  %t47 = getelementptr [64 x i32], ptr %l0, i64 0, i64 46
  store i32 -200395387, ptr %t47
  %t48 = getelementptr [64 x i32], ptr %l0, i64 0, i64 47
  store i32 275423344, ptr %t48
  %t49 = getelementptr [64 x i32], ptr %l0, i64 0, i64 48
  store i32 430227734, ptr %t49
  %t50 = getelementptr [64 x i32], ptr %l0, i64 0, i64 49
  store i32 506948616, ptr %t50
  %t51 = getelementptr [64 x i32], ptr %l0, i64 0, i64 50
  store i32 659060556, ptr %t51
  %t52 = getelementptr [64 x i32], ptr %l0, i64 0, i64 51
  store i32 883997877, ptr %t52
  %t53 = getelementptr [64 x i32], ptr %l0, i64 0, i64 52
  store i32 958139571, ptr %t53
  %t54 = getelementptr [64 x i32], ptr %l0, i64 0, i64 53
  store i32 1322822218, ptr %t54
  %t55 = getelementptr [64 x i32], ptr %l0, i64 0, i64 54
  store i32 1537002063, ptr %t55
  %t56 = getelementptr [64 x i32], ptr %l0, i64 0, i64 55
  store i32 1747873779, ptr %t56
  %t57 = getelementptr [64 x i32], ptr %l0, i64 0, i64 56
  store i32 1955562222, ptr %t57
  %t58 = getelementptr [64 x i32], ptr %l0, i64 0, i64 57
  store i32 2024104815, ptr %t58
  %t59 = getelementptr [64 x i32], ptr %l0, i64 0, i64 58
  store i32 -2067236844, ptr %t59
  %t60 = getelementptr [64 x i32], ptr %l0, i64 0, i64 59
  store i32 -1933114872, ptr %t60
  %t61 = getelementptr [64 x i32], ptr %l0, i64 0, i64 60
  store i32 -1866530822, ptr %t61
  %t62 = getelementptr [64 x i32], ptr %l0, i64 0, i64 61
  store i32 -1538233109, ptr %t62
  %t63 = getelementptr [64 x i32], ptr %l0, i64 0, i64 62
  store i32 -1090935817, ptr %t63
  %t64 = getelementptr [64 x i32], ptr %l0, i64 0, i64 63
  store i32 -965641998, ptr %t64
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fbuild_2eShaK, ptr %l0, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  br label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } %t13, 0
  %t19 = add i64 %t15, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = getelementptr i8, ptr %t20, i64 %t15
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l1, !tbaa !27
  br label %bb57
bb4:
  %t7 = load i32, ptr %l0, !tbaa !23
  %t9 = icmp eq i32 %t7, 2
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  br label %bb57
bb8:
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 3
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  br label %bb57
bb12:
  %t19 = load i32, ptr %l0, !tbaa !23
  %t21 = icmp eq i32 %t19, 4
  br i1 %t21, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l1, !tbaa !27
  br label %bb57
bb16:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = icmp eq i32 %t25, 5
  br i1 %t27, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  br label %bb57
bb20:
  %t31 = load i32, ptr %l0, !tbaa !23
  %t33 = icmp eq i32 %t31, 6
  br i1 %t33, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t35, ptr %l1, !tbaa !27
  br label %bb57
bb24:
  %t37 = load i32, ptr %l0, !tbaa !23
  %t39 = icmp eq i32 %t37, 7
  br i1 %t39, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l1, !tbaa !27
  br label %bb57
bb28:
  %t43 = load i32, ptr %l0, !tbaa !23
  %t45 = icmp eq i32 %t43, 8
  br i1 %t45, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t47, ptr %l1, !tbaa !27
  br label %bb57
bb32:
  %t49 = load i32, ptr %l0, !tbaa !23
  %t51 = icmp eq i32 %t49, 9
  br i1 %t51, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  br label %bb57
bb36:
  %t55 = load i32, ptr %l0, !tbaa !23
  %t57 = icmp eq i32 %t55, 11
  br i1 %t57, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t59, ptr %l1, !tbaa !27
  br label %bb57
bb40:
  %t61 = load i32, ptr %l0, !tbaa !23
  %t63 = icmp eq i32 %t61, 13
  br i1 %t63, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t65, ptr %l1, !tbaa !27
  br label %bb57
bb44:
  %t67 = load i32, ptr %l0, !tbaa !23
  %t69 = icmp eq i32 %t67, 14
  br i1 %t69, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t71, ptr %l1, !tbaa !27
  br label %bb57
bb48:
  %t73 = load i32, ptr %l0, !tbaa !23
  %t75 = icmp eq i32 %t73, 15
  br i1 %t75, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t77, ptr %l1, !tbaa !27
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t79 = load i32, ptr %l0, !tbaa !23
  %t80 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t83 = sext i32 %t79 to i64
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = getelementptr i8, ptr %t86, i64 %t81
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t83)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  store { i64, ptr } %t90, ptr %l1, !tbaa !27
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_84eba90bdad5d702_427cd4b75eaf1c36)
  unreachable
bb57:
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l56, !tbaa !24
  %t94 = load i64, ptr %l56, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l57, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t105, ptr %l1, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/os:Output"
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l49 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l78 = alloca %"std/os:Output"
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca %"std/os:Output"
  %l83 = alloca i32
  %l85 = alloca i1
  %l90 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l107 = alloca i1
  %l114 = alloca i1
  %l118 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l126 = alloca { i64, ptr }
  %l135 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l144 = alloca i32
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  store { i64, ptr } %a3, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l9, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %l33, !tbaa !27
  %t16 = load i64, ptr %l8, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t16
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t23 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l36
  br label %bb5
bb5:
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l11
  %t27 = extractvalue { i64, ptr } %a1, 1
  %t28 = extractvalue { i64, ptr } %a1, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t38)
  br label %bb6
bb6:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb7
bb7:
  store { i64, ptr } %a2, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l14, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l13, !tbaa !24
  %t49 = load i64, ptr %l14, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t56, ptr %l49, !tbaa !27
  %t57 = load i64, ptr %l13, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %t60, i64 %t57
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !37
  %t66 = extractvalue { i64, ptr } %t62, 1
  %t67 = extractvalue { i64, ptr } %t62, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t77)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t80 = load i64, ptr %l13, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l13, !tbaa !24
  br label %bb8
bb14:
  %t84 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t86, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t97)
  br label %bb15
bb15:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l18, !tbaa !24
  br label %bb16
bb16:
  %t106 = load i64, ptr %l17, !tbaa !24
  %t107 = load i64, ptr %l18, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t114 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t114, ptr %l69, !tbaa !27
  %t115 = load i64, ptr %l17, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %t118, i64 %t115
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !37
  %t124 = extractvalue { i64, ptr } %t120, 1
  %t125 = extractvalue { i64, ptr } %t120, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t135)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t138 = load i64, ptr %l17, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l17, !tbaa !24
  br label %bb16
bb22:
  %t143 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s2, ptr %s2, ptr %l11)
  store { i64, ptr } %t143, ptr %l80
  br label %bb23
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l81, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t146 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t144, { i64, ptr } %t145, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t147 = extractvalue { i32, %"std/os:Output" } %t146, 1
  %t148 = extractvalue { i32, %"std/os:Output" } %t146, 0
  store i32 %t148, ptr %l83
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb25, label %ok.150
ok.150:
  store %"std/os:Output" %t147, ptr %l82
  br label %bb24
bb24:
  %t151 = load %"std/os:Output", ptr %l82
  store %"std/os:Output" %t151, ptr %l78
  br label %bb29
bb25:
  %t152 = load i32, ptr %l83, !tbaa !23
  %t153 = ashr i32 %t152, 16
  %t155 = icmp eq i32 %t153, 1
  store i1 %t155, ptr %l85, !tbaa !21
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t156 = load ptr, ptr %l0, !tbaa !29
  %t157 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t157, 1
  %t160 = extractvalue { i64, ptr } %t157, 0
  %t161 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t164 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t163)
  call void @olang_textcopy(ptr %t164, ptr %t159, i64 %t160)
  %t165 = getelementptr i8, ptr %t164, i64 %t160
  call void @olang_textcopy(ptr %t165, ptr %t161, i64 %t162)
  %t166 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t164, 1
  %t169 = extractvalue { i64, ptr } %t167, 0
  %t170 = extractvalue { i64, ptr } %t167, 1
  %t171 = mul i64 %t169, 1
  %t172 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t171)
  call void @llvm.memcpy.p0.p0.i64(ptr %t172, ptr %t170, i64 %t171, i1 false)
  %t173 = insertvalue { i64, ptr } undef, i64 %t169, 0
  %t174 = insertvalue { i64, ptr } %t173, ptr %t172, 1
  %t177 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s13, ptr %s13, ptr %s13, ptr %t156, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } %t174)
  store { i64, ptr } %t177, ptr %l90
  br label %bb27
bb27:
  %t178 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t178, 0
  %t180 = extractvalue { i64, ptr } %t178, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  call void @compiler_2fbuild_2esayln(ptr %s13, { i64, ptr } %t184)
  br label %bb28
bb28:
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb29:
  %t186 = load %"std/os:Output", ptr %l78
  store %"std/os:Output" %t186, ptr %l20
  %t187 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t188 = load i32, ptr %t187, !tbaa !23
  %t190 = icmp sgt i32 %t188, 128
  br i1 %t190, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s15
  %t192 = load ptr, ptr %l0, !tbaa !29
  store ptr %t192, ptr %l94, !tbaa !29
  %t193 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t193, ptr %l95, !tbaa !27
  %t194 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t195 = load i32, ptr %t194, !tbaa !23
  %t197 = sub i32 %t195, 128
  %t199 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s15, i32 %t197)
  store { i64, ptr } %t199, ptr %l98
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t200 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t204 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t205 = add i64 %t202, %t204
  %t206 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 1
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t209 = add i64 %t205, %t208
  %t210 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t212 = add i64 %t209, %t211
  %t213 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t212)
  call void @olang_textcopy(ptr %t213, ptr %t201, i64 %t202)
  %t214 = getelementptr i8, ptr %t213, i64 %t202
  call void @olang_textcopy(ptr %t214, ptr %t203, i64 %t204)
  %t215 = getelementptr i8, ptr %t214, i64 %t204
  call void @olang_textcopy(ptr %t215, ptr %t207, i64 %t208)
  %t216 = getelementptr i8, ptr %t215, i64 %t208
  call void @olang_textcopy(ptr %t216, ptr %t210, i64 %t211)
  %t217 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t213, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t226 = load ptr, ptr %l94, !tbaa !29
  %t228 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s15, ptr %s15, ptr %s15, ptr %t226, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } %t225)
  store { i64, ptr } %t228, ptr %l101
  br label %bb33
bb33:
  %t229 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  call void @compiler_2fbuild_2esayln(ptr %s15, { i64, ptr } %t235)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s15)
  br label %bb35
bb35:
  %t237 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t238 = load i32, ptr %t237, !tbaa !23
  %t240 = icmp ne i32 %t238, 3
  br i1 %t240, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb38
bb37:
  br label %bb38
bb38:
  %t242 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t243 = load i32, ptr %t242, !tbaa !23
  %t245 = icmp ne i32 %t243, 0
  br i1 %t245, label %bb39, label %bb40
bb39:
  %t247 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t248 = load i32, ptr %t247, !tbaa !23
  %t250 = icmp ne i32 %t248, 3
  store i1 %t250, ptr %l107, !tbaa !21
  br label %bb41
bb40:
  store i1 false, ptr %l107, !tbaa !21
  br label %bb41
bb41:
  %t252 = load i1, ptr %l107, !tbaa !21
  br i1 %t252, label %bb42, label %bb43
bb42:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb44
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s2)
  br label %bb45
bb45:
  %t253 = load i64, ptr %l8, !tbaa !24
  %t255 = add i64 %t253, 1
  store i64 %t255, ptr %l8, !tbaa !24
  br label %bb1
bb46:
  %t257 = load i1, ptr %l6, !tbaa !21
  %t259 = xor i1 %t257, true
  br i1 %t259, label %bb47, label %bb48
bb47:
  %t261 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t265 = icmp sgt i64 %t263, 0
  store i1 %t265, ptr %l114, !tbaa !21
  br label %bb49
bb48:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb49
bb49:
  %t267 = load i1, ptr %l114, !tbaa !21
  br i1 %t267, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s20
  %t268 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s20, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t268, ptr %l118
  br label %bb52
bb51:
  br label %bb63
bb52:
  %t269 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l118
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t269, ptr %l21
  %t270 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t270, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t272 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t272, 0
  store i64 %t274, ptr %l24, !tbaa !24
  br label %bb53
bb53:
  %t276 = load i64, ptr %l23, !tbaa !24
  %t277 = load i64, ptr %l24, !tbaa !24
  %t280 = icmp slt i64 %t276, %t277
  %t282 = xor i1 %t280, true
  br i1 %t282, label %bb54, label %bb55
bb54:
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t284 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t284, ptr %l126, !tbaa !27
  %t285 = load i64, ptr %l23, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr { i64, ptr }, ptr %t288, i64 %t285
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !37
  %t293 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t294 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t296 = extractvalue { i64, ptr } %t290, 1
  %t297 = extractvalue { i64, ptr } %t290, 0
  %t298 = add i64 %t294, %t297
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t300 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t301 = add i64 %t298, %t300
  %t302 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t301)
  call void @olang_textcopy(ptr %t302, ptr %t293, i64 %t294)
  %t303 = getelementptr i8, ptr %t302, i64 %t294
  call void @olang_textcopy(ptr %t303, ptr %t296, i64 %t297)
  %t304 = getelementptr i8, ptr %t303, i64 %t297
  call void @olang_textcopy(ptr %t304, ptr %t299, i64 %t300)
  %t305 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t302, 1
  %t308 = extractvalue { i64, ptr } %t306, 0
  %t309 = extractvalue { i64, ptr } %t306, 1
  %t310 = mul i64 %t308, 1
  %t311 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t310)
  call void @llvm.memcpy.p0.p0.i64(ptr %t311, ptr %t309, i64 %t310, i1 false)
  %t312 = insertvalue { i64, ptr } undef, i64 %t308, 0
  %t313 = insertvalue { i64, ptr } %t312, ptr %t311, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s20, ptr %s20, ptr %l21, { i64, ptr } %t313)
  br label %bb57
bb57:
  br label %bb58
bb58:
  %t316 = load i64, ptr %l23, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l23, !tbaa !24
  br label %bb53
bb59:
  %t320 = load ptr, ptr %l0, !tbaa !29
  store ptr %t320, ptr %l135, !tbaa !29
  %t322 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s20, ptr %s20, ptr %s20, ptr %l21, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) })
  store { i64, ptr } %t322, ptr %l137
  br label %bb60
bb60:
  %t323 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d38, i32 0, i32 1) }, 1
  %t324 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d38, i32 0, i32 1) }, 0
  %t325 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t328 = add i64 %t324, %t327
  %t329 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t323, i64 %t324)
  %t330 = getelementptr i8, ptr %t329, i64 %t324
  call void @olang_textcopy(ptr %t330, ptr %t326, i64 %t327)
  %t331 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t329, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = extractvalue { i64, ptr } %t332, 1
  %t336 = mul i64 %t334, 1
  %t337 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t336)
  call void @llvm.memcpy.p0.p0.i64(ptr %t337, ptr %t335, i64 %t336, i1 false)
  %t338 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  %t340 = load ptr, ptr %l135, !tbaa !29
  %t342 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s20, ptr %s20, ptr %s20, ptr %t340, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d39, i32 0, i32 1) }, { i64, ptr } %t339)
  store { i64, ptr } %t342, ptr %l140
  br label %bb61
bb61:
  %t343 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  %t345 = extractvalue { i64, ptr } %t343, 1
  %t346 = mul i64 %t344, 1
  %t347 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t346)
  call void @llvm.memcpy.p0.p0.i64(ptr %t347, ptr %t345, i64 %t346, i1 false)
  %t348 = insertvalue { i64, ptr } undef, i64 %t344, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  call void @compiler_2fbuild_2esayln(ptr %s20, { i64, ptr } %t349)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s20)
  store i32 1, ptr %rv
  br label %ret
bb63:
  %t352 = load i1, ptr %l5, !tbaa !21
  br i1 %t352, label %bb64, label %bb65
bb64:
  store i32 1, ptr %l144, !tbaa !23
  br label %bb66
bb65:
  store i32 0, ptr %l144, !tbaa !23
  br label %bb66
bb66:
  %t354 = load i32, ptr %l144, !tbaa !23
  store i32 %t354, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2eThinFrom_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8388608, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t18)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fbuild_2eclaim(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca i32
  %l40 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l50 = alloca i32
  %l52 = alloca i1
  %l60 = alloca i1
  %l63 = alloca i32
  %l65 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l15, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  br label %bb36
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = call i32 @std_2fos_2eMkDir(ptr %s0, { i64, ptr } %t59)
  store i32 %t61, ptr %l37
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb12, label %ok.63
ok.63:
  br label %bb11
bb11:
  br label %bb17
bb12:
  %t64 = load i32, ptr %l37, !tbaa !23
  %t65 = icmp eq i32 %t64, 65537
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  store i1 %t70, ptr %l40, !tbaa !21
  br label %bb16
bb15:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l9, !tbaa !21
  br label %bb17
bb16:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb17:
  %t72 = load i1, ptr %l9, !tbaa !21
  br i1 %t72, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s6
  %t74 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = extractvalue { i64, ptr } %t74, 0
  %t78 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t79 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t80 = add i64 %t77, %t79
  %t81 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t80)
  call void @olang_textcopy(ptr %t81, ptr %t76, i64 %t77)
  %t82 = getelementptr i8, ptr %t81, i64 %t77
  call void @olang_textcopy(ptr %t82, ptr %t78, i64 %t79)
  %t83 = insertvalue { i64, ptr } undef, i64 %t80, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l45, !tbaa !27
  %t92 = call i32 @getpid()
  store i32 %t92, ptr %l46
  br label %bb20
bb19:
  br label %bb26
bb20:
  %t93 = load i32, ptr %l46, !tbaa !23
  %t94 = sext i32 %t93 to i64
  %t95 = call i64 @__olang_fmt_i64(ptr null, i64 %t94)
  %t96 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t95)
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t94)
  %t98 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t96, 1
  %t102 = extractvalue { i64, ptr } %t99, 0
  %t103 = extractvalue { i64, ptr } %t99, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t110 = call i32 @std_2fos_2eWriteFile(ptr %s6, ptr %s6, { i64, ptr } %t108, { i64, ptr } %t107)
  store i32 %t110, ptr %l50
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb22, label %ok.112
ok.112:
  br label %bb21
bb21:
  br label %bb24
bb22:
  %t113 = load i32, ptr %l50, !tbaa !23
  %t114 = ashr i32 %t113, 16
  %t116 = icmp eq i32 %t114, 1
  store i1 %t116, ptr %l52, !tbaa !21
  br label %bb23
bb23:
  call void @__olang_ert_req_clear()
  br label %bb24
bb24:
  %t119 = getelementptr %"compiler/build:compiles", ptr %a1, i32 0, i32 6
  %t120 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = extractvalue { i64, ptr } %t120, 0
  %t124 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t122, i64 %t123)
  %t125 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t119, { i64, ptr } %t133)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb26:
  %t137 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t139 = call i1 @compiler_2fbuild_2eholderAlive(ptr %s0, { i64, ptr } %t137)
  store i1 %t139, ptr %l60
  br label %bb27
bb27:
  %t140 = load i1, ptr %l60, !tbaa !21
  br i1 %t140, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t142 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t144 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t142)
  store i32 %t144, ptr %l63
  %t145 = icmp ne i32 %t144, 0
  br i1 %t145, label %bb32, label %ok.146
ok.146:
  br label %bb31
bb31:
  br label %bb34
bb32:
  %t147 = load i32, ptr %l63, !tbaa !23
  %t148 = ashr i32 %t147, 16
  %t150 = icmp eq i32 %t148, 1
  store i1 %t150, ptr %l65, !tbaa !21
  br label %bb33
bb33:
  call void @__olang_ert_req_clear()
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t151 = load i64, ptr %l7, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l7, !tbaa !24
  br label %bb7
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fbuild_2ecloseness(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp sgt i64 %t9, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = sub i64 %t19, %t22
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb3:
  br label %bb26
bb4:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb6:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l30, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l30, !tbaa !24
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l27, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l48, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l49, !tbaa !27
  %t77 = load i64, ptr %l8, !tbaa !24
  store i64 %t77, ptr %l50, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = add i64 %t78, %t81
  store i64 %t84, ptr %l54, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l50, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t90 = load i64, ptr %l50, !tbaa !24
  %t91 = load i64, ptr %l54, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb16:
  %t94 = load i64, ptr %l54, !tbaa !24
  %t95 = load i64, ptr %l55, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb18:
  %t98 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l54, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t106 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t108 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %t106, { i64, ptr } %t105)
  store i64 %t108, ptr %l60
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb20:
  %t109 = load i64, ptr %l60, !tbaa !24
  store i64 %t109, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l2, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  br i1 %t114, label %bb21, label %bb22
bb21:
  %t116 = load i64, ptr %l9, !tbaa !24
  store i64 %t116, ptr %l2, !tbaa !24
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l7, !tbaa !24
  br label %bb10
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l21 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 2
  %t8 = getelementptr %"compiler/target:Target", ptr %t7, i32 0, i32 9
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %lp1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 2
  %t15 = getelementptr %"compiler/target:Target", ptr %t14, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t20, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t11, { i64, ptr } %t33)
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t36 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s1)
  store { i64, ptr } %t36, ptr %l11
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t40, ptr %l13
  br label %bb6
bb6:
  %t41 = load i1, ptr %l13, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %lp1
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t49 = extractvalue { i64, ptr } %t45, 1
  %t50 = extractvalue { i64, ptr } %t45, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t44, { i64, ptr } %t62)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 2
  %t68 = getelementptr %"compiler/target:Target", ptr %t67, i32 0, i32 6
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d46, i32 0, i32 1) })
  store i1 %t71, ptr %l21
  br label %bb12
bb12:
  %t72 = load i1, ptr %l21, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %lp1
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/build:Config", ptr %t76, i32 0, i32 2
  %t79 = getelementptr %"compiler/target:Target", ptr %t78, i32 0, i32 6
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t75, { i64, ptr } %t93)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t96 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t96, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb17
bb17:
  %t98 = load ptr, ptr %lp1
  %t99 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t98
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v2, ptr %t1)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t6 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t15)
  store i1 %t16, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t19, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) })
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t21, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %lp2
  %t24 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t23
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s1, ptr %a0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s1, ptr %t12)
  store i64 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s1, ptr %s1, ptr %t21, i64 %t22)
  store { i64, ptr } %t25, ptr %l16
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s2, { i64, ptr } %t27, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d51, i32 0, i32 1) })
  store i1 %t29, ptr %l18
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d52, i32 0, i32 1) })
  store i1 %t35, ptr %l22
  br label %bb12
bb11:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  %t36 = load i1, ptr %l22, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %lp1
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t40, { i64, ptr } %t54)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l3, !tbaa !24
  br label %bb3
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t61 = load ptr, ptr %lp1
  %t62 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t61
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/os:Output"
  %l28 = alloca %"std/os:FileInfo"
  %l29 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l69 = alloca %"std/prelude/text:StringBuilder"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca i1
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l110 = alloca i64
  %l112 = alloca i64
  %l117 = alloca { i64, ptr }
  %l125 = alloca i64
  %l127 = alloca i64
  %l132 = alloca { i64, ptr }
  %l144 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l146 = alloca i64
  %l148 = alloca i64
  %l153 = alloca { i64, ptr }
  %l158 = alloca ptr
  %l160 = alloca { i64, ptr }
  %l162 = alloca { i64, ptr }
  %l168 = alloca i1
  %l170 = alloca i32
  %l172 = alloca i1
  %l175 = alloca i1
  %l177 = alloca %"std/os:Output"
  %l179 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca %"std/os:Output"
  %l182 = alloca i32
  %l184 = alloca i1
  %l189 = alloca ptr
  %l192 = alloca %"std/os:FileInfo"
  %l194 = alloca %"std/os:FileInfo"
  %l195 = alloca i32
  %l197 = alloca i1
  %l205 = alloca i32
  %l207 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l29
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l29
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l6
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t19)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s2, ptr %t22)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l36
  br label %bb3
bb3:
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %t26
  store ptr %t26, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l8, !tbaa !24
  store i64 %t28, ptr %l38, !tbaa !24
  %t29 = load ptr, ptr %l7, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t29)
  store i64 %t31, ptr %l40
  br label %bb5
bb5:
  %t32 = load i64, ptr %l38, !tbaa !24
  %t33 = load i64, ptr %l40, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l7, !tbaa !29
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %t38, i64 %t39)
  store { i64, ptr } %t42, ptr %l45
  br label %bb9
bb9:
  %t43 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = extractvalue { i64, ptr } %t43, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t57)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l8, !tbaa !24
  br label %bb4
bb12:
  call void @__olang_scope_close(ptr %s2)
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 21
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Config", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t73 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t76 = extractvalue { i64, ptr } %t72, 1
  %t77 = extractvalue { i64, ptr } %t72, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t93)
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t96 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t97 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t100 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t101 = add i64 %t98, %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t97, i64 %t98)
  %t103 = getelementptr i8, ptr %t102, i64 %t98
  %t104 = call i64 @__olang_fmt_i64(ptr %t103, i64 %t96)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t102, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = extractvalue { i64, ptr } %t106, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t113)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t116 = load ptr, ptr %l5, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb41
bb20:
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = extractvalue { i64, ptr } %t123, 0
  %t127 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t125, i64 %t126)
  %t131 = getelementptr i8, ptr %t130, i64 %t126
  call void @olang_textcopy(ptr %t131, ptr %t127, i64 %t128)
  %t132 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t130, 1
  store { i64, ptr } %t133, ptr %l10, !tbaa !27
  %t135 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t135, ptr %l69
  br label %bb21
bb21:
  %t136 = load %"std/prelude/text:StringBuilder", ptr %l69
  store %"std/prelude/text:StringBuilder" %t136, ptr %l11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l11, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb22
bb22:
  %t138 = load ptr, ptr %l5, !tbaa !29
  store ptr %t138, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s12
  %t140 = load i64, ptr %l13, !tbaa !24
  store i64 %t140, ptr %l72, !tbaa !24
  %t141 = load ptr, ptr %l12, !tbaa !29
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t141)
  store i64 %t143, ptr %l74
  br label %bb24
bb24:
  %t144 = load i64, ptr %l72, !tbaa !24
  %t145 = load i64, ptr %l74, !tbaa !24
  %t146 = icmp slt i64 %t144, %t145
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s12)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t150 = load ptr, ptr %l12, !tbaa !29
  %t151 = load i64, ptr %l13, !tbaa !24
  %t154 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t150, i64 %t151)
  store { i64, ptr } %t154, ptr %l79
  br label %bb28
bb28:
  %t155 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t160 = extractvalue { i64, ptr } %t155, 1
  %t161 = extractvalue { i64, ptr } %t155, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t165)
  call void @olang_textcopy(ptr %t166, ptr %t157, i64 %t158)
  %t167 = getelementptr i8, ptr %t166, i64 %t158
  call void @olang_textcopy(ptr %t167, ptr %t160, i64 %t161)
  %t168 = getelementptr i8, ptr %t167, i64 %t161
  call void @olang_textcopy(ptr %t168, ptr %t163, i64 %t164)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t166, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } %t170, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s12, ptr %l11, { i64, ptr } %t177)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s12)
  br label %bb30
bb30:
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l13, !tbaa !24
  br label %bb23
bb31:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l11, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb32
bb32:
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t185, ptr %l87, !tbaa !27
  %t187 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %s9, ptr %l11)
  store { i64, ptr } %t187, ptr %l89
  br label %bb33
bb33:
  %t188 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t191 = call i32 @std_2fos_2eWriteFile(ptr %s9, ptr %s9, { i64, ptr } %t189, { i64, ptr } %t188)
  store i32 %t191, ptr %l91
  %t192 = icmp ne i32 %t191, 0
  br i1 %t192, label %bb35, label %ok.193
ok.193:
  br label %bb34
bb34:
  br label %bb37
bb35:
  %t194 = load i32, ptr %l91, !tbaa !23
  %t195 = ashr i32 %t194, 16
  %t197 = icmp eq i32 %t195, 1
  store i1 %t197, ptr %l93, !tbaa !21
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb37:
  %t199 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t200 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t203 = extractvalue { i64, ptr } %t199, 1
  %t204 = extractvalue { i64, ptr } %t199, 0
  %t205 = add i64 %t201, %t204
  %t206 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t205)
  call void @olang_textcopy(ptr %t206, ptr %t200, i64 %t201)
  %t207 = getelementptr i8, ptr %t206, i64 %t201
  call void @olang_textcopy(ptr %t207, ptr %t203, i64 %t204)
  %t208 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t209 = insertvalue { i64, ptr } %t208, ptr %t206, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = extractvalue { i64, ptr } %t209, 1
  %t213 = mul i64 %t211, 1
  %t214 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t213)
  call void @llvm.memcpy.p0.p0.i64(ptr %t214, ptr %t212, i64 %t213, i1 false)
  %t215 = insertvalue { i64, ptr } undef, i64 %t211, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t214, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t216)
  br label %bb38
bb38:
  store ptr %l6, ptr %l99, !tbaa !29
  %t219 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t221 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v2, { i64, ptr } %t219)
  store { i64, ptr } %t221, ptr %l101
  br label %bb39
bb39:
  %t222 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t223 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t224 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = add i64 %t223, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t222, i64 %t223)
  %t229 = getelementptr i8, ptr %t228, i64 %t223
  call void @olang_textcopy(ptr %t229, ptr %t225, i64 %t226)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  %t233 = extractvalue { i64, ptr } %t231, 0
  %t234 = extractvalue { i64, ptr } %t231, 1
  %t235 = mul i64 %t233, 1
  %t236 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t235)
  call void @llvm.memcpy.p0.p0.i64(ptr %t236, ptr %t234, i64 %t235, i1 false)
  %t237 = insertvalue { i64, ptr } undef, i64 %t233, 0
  %t238 = insertvalue { i64, ptr } %t237, ptr %t236, 1
  %t239 = load ptr, ptr %l99, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t239, { i64, ptr } %t238)
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb41:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d64, i32 0, i32 1) })
  br label %bb42
bb42:
  %t242 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t242, 1
  %t245 = extractvalue { i64, ptr } %t242, 0
  %t246 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t245)
  call void @olang_textcopy(ptr %t246, ptr %t244, i64 %t245)
  %t247 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t248 = insertvalue { i64, ptr } %t247, ptr %t246, 1
  %t250 = extractvalue { i64, ptr } %t248, 0
  %t251 = extractvalue { i64, ptr } %t248, 1
  %t252 = mul i64 %t250, 1
  %t253 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t252)
  call void @llvm.memcpy.p0.p0.i64(ptr %t253, ptr %t251, i64 %t252, i1 false)
  %t254 = insertvalue { i64, ptr } undef, i64 %t250, 0
  %t255 = insertvalue { i64, ptr } %t254, ptr %t253, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t255)
  br label %bb43
bb43:
  store ptr %a1, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb44
bb44:
  %t260 = load i64, ptr %l16, !tbaa !24
  store i64 %t260, ptr %l110, !tbaa !24
  %t261 = load ptr, ptr %l15, !tbaa !29
  %t263 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t261)
  store i64 %t263, ptr %l112
  br label %bb45
bb45:
  %t264 = load i64, ptr %l110, !tbaa !24
  %t265 = load i64, ptr %l112, !tbaa !24
  %t266 = icmp slt i64 %t264, %t265
  %t268 = xor i1 %t266, true
  br i1 %t268, label %bb46, label %bb47
bb46:
  br label %bb52
bb47:
  br label %bb48
bb48:
  %t270 = load ptr, ptr %l15, !tbaa !29
  %t271 = load i64, ptr %l16, !tbaa !24
  %t274 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t270, i64 %t271)
  store { i64, ptr } %t274, ptr %l117
  br label %bb49
bb49:
  %t275 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t275, 1
  %t279 = extractvalue { i64, ptr } %t275, 0
  %t280 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t279)
  call void @olang_textcopy(ptr %t280, ptr %t278, i64 %t279)
  %t281 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t282 = insertvalue { i64, ptr } %t281, ptr %t280, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  %t285 = extractvalue { i64, ptr } %t282, 1
  %t286 = mul i64 %t284, 1
  %t287 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t286)
  call void @llvm.memcpy.p0.p0.i64(ptr %t287, ptr %t285, i64 %t286, i1 false)
  %t288 = insertvalue { i64, ptr } undef, i64 %t284, 0
  %t289 = insertvalue { i64, ptr } %t288, ptr %t287, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t289)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t292 = load i64, ptr %l16, !tbaa !24
  %t294 = add i64 %t292, 1
  store i64 %t294, ptr %l16, !tbaa !24
  br label %bb44
bb52:
  store ptr %a4, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb53
bb53:
  %t298 = load i64, ptr %l19, !tbaa !24
  store i64 %t298, ptr %l125, !tbaa !24
  %t299 = load ptr, ptr %l18, !tbaa !29
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t299)
  store i64 %t301, ptr %l127
  br label %bb54
bb54:
  %t302 = load i64, ptr %l125, !tbaa !24
  %t303 = load i64, ptr %l127, !tbaa !24
  %t304 = icmp slt i64 %t302, %t303
  %t306 = xor i1 %t304, true
  br i1 %t306, label %bb55, label %bb56
bb55:
  br label %bb61
bb56:
  br label %bb57
bb57:
  %t308 = load ptr, ptr %l18, !tbaa !29
  %t309 = load i64, ptr %l19, !tbaa !24
  %t312 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t308, i64 %t309)
  store { i64, ptr } %t312, ptr %l132
  br label %bb58
bb58:
  %t313 = load { i64, ptr }, ptr %l132, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t313, 1
  %t317 = extractvalue { i64, ptr } %t313, 0
  %t318 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t317)
  call void @olang_textcopy(ptr %t318, ptr %t316, i64 %t317)
  %t319 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t318, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t327)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t330 = load i64, ptr %l19, !tbaa !24
  %t332 = add i64 %t330, 1
  store i64 %t332, ptr %l19, !tbaa !24
  br label %bb53
bb61:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb62
bb62:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb63
bb63:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb64
bb64:
  br i1 %a3, label %bb65, label %bb66
bb65:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb67
bb66:
  br label %bb68
bb67:
  br label %bb68
bb68:
  %t340 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t340, ptr %l144
  br label %bb69
bb69:
  %t341 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l144
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t341, ptr %l21
  store ptr %l6, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb70
bb70:
  %t343 = load i64, ptr %l23, !tbaa !24
  store i64 %t343, ptr %l146, !tbaa !24
  %t344 = load ptr, ptr %l22, !tbaa !29
  %t346 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t344)
  store i64 %t346, ptr %l148
  br label %bb71
bb71:
  %t347 = load i64, ptr %l146, !tbaa !24
  %t348 = load i64, ptr %l148, !tbaa !24
  %t349 = icmp slt i64 %t347, %t348
  %t351 = xor i1 %t349, true
  br i1 %t351, label %bb72, label %bb73
bb72:
  br label %bb78
bb73:
  br label %bb74
bb74:
  %t353 = load ptr, ptr %l22, !tbaa !29
  %t354 = load i64, ptr %l23, !tbaa !24
  %t357 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t353, i64 %t354)
  store { i64, ptr } %t357, ptr %l153
  br label %bb75
bb75:
  %t358 = load { i64, ptr }, ptr %l153, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } %t358)
  br label %bb76
bb76:
  br label %bb77
bb77:
  %t362 = load i64, ptr %l23, !tbaa !24
  %t364 = add i64 %t362, 1
  store i64 %t364, ptr %l23, !tbaa !24
  br label %bb70
bb78:
  store ptr %l21, ptr %l158, !tbaa !29
  %t366 = load ptr, ptr %l0, !tbaa !29
  %t368 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t366)
  store { i64, ptr } %t368, ptr %l160
  br label %bb79
bb79:
  %t369 = load ptr, ptr %l158, !tbaa !29
  %t370 = load { i64, ptr }, ptr %l160, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t369, { i64, ptr } %t370)
  br label %bb80
bb80:
  %t372 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l21)
  store { i64, ptr } %t372, ptr %l162
  br label %bb81
bb81:
  %t373 = load { i64, ptr }, ptr %l162, !tbaa !27
  store { i64, ptr } %t373, ptr %l25, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t376 = extractvalue { i64, ptr } %t374, 1
  %t377 = extractvalue { i64, ptr } %t374, 0
  %t378 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t379 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t380 = add i64 %t377, %t379
  %t381 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t380)
  call void @olang_textcopy(ptr %t381, ptr %t376, i64 %t377)
  %t382 = getelementptr i8, ptr %t381, i64 %t377
  call void @olang_textcopy(ptr %t382, ptr %t378, i64 %t379)
  %t383 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t384 = insertvalue { i64, ptr } %t383, ptr %t381, 1
  store { i64, ptr } %t384, ptr %l26, !tbaa !27
  %t386 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t387 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t388 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t392 = call i1 @compiler_2fbuild_2elinkCurrent(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t386, { i64, ptr } %t387, { i64, ptr } %t388)
  store i1 %t392, ptr %l168
  br label %bb82
bb82:
  %t393 = load i1, ptr %l168, !tbaa !21
  br i1 %t393, label %bb83, label %bb84
bb83:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb84:
  br label %bb85
bb85:
  %t394 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t396 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t394)
  store i32 %t396, ptr %l170
  %t397 = icmp ne i32 %t396, 0
  br i1 %t397, label %bb87, label %ok.398
ok.398:
  br label %bb86
bb86:
  br label %bb89
bb87:
  %t399 = load i32, ptr %l170, !tbaa !23
  %t400 = ashr i32 %t399, 16
  %t402 = icmp eq i32 %t400, 1
  store i1 %t402, ptr %l172, !tbaa !21
  br label %bb88
bb88:
  call void @__olang_ert_req_clear()
  br label %bb89
bb89:
  %t403 = load ptr, ptr %l0, !tbaa !29
  %t405 = getelementptr %"compiler/build:Config", ptr %t403, i32 0, i32 1
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t408 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t406, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d70, i32 0, i32 1) })
  store i1 %t408, ptr %l175
  br label %bb90
bb90:
  %t409 = load i1, ptr %l175, !tbaa !21
  br i1 %t409, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t412 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t412, ptr %l179
  br label %bb94
bb94:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d71, i32 0, i32 1) }, ptr %l180, !tbaa !27
  %t413 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t415 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t413, { i64, ptr } %t414, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t416 = extractvalue { i32, %"std/os:Output" } %t415, 1
  %t417 = extractvalue { i32, %"std/os:Output" } %t415, 0
  store i32 %t417, ptr %l182
  %t418 = icmp ne i32 %t417, 0
  br i1 %t418, label %bb96, label %ok.419
ok.419:
  store %"std/os:Output" %t416, ptr %l181
  br label %bb95
bb95:
  %t420 = load %"std/os:Output", ptr %l181
  store %"std/os:Output" %t420, ptr %l177
  br label %bb98
bb96:
  %t421 = load i32, ptr %l182, !tbaa !23
  %t422 = ashr i32 %t421, 16
  %t424 = icmp eq i32 %t422, 1
  store i1 %t424, ptr %l184, !tbaa !21
  br label %bb97
bb97:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb98:
  %t426 = load %"std/os:Output", ptr %l177
  store %"std/os:Output" %t426, ptr %l27
  %t427 = getelementptr %"std/os:Output", ptr %l27, i32 0, i32 0
  %t428 = load i32, ptr %t427, !tbaa !23
  %t430 = icmp ne i32 %t428, 0
  br i1 %t430, label %bb99, label %bb100
bb99:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb100:
  br label %bb101
bb101:
  %t433 = load ptr, ptr %l0, !tbaa !29
  store ptr %t433, ptr %l189, !tbaa !29
  %t434 = load ptr, ptr %l189, !tbaa !29
  %t435 = getelementptr %"compiler/build:Config", ptr %t434, i32 0, i32 20
  %t436 = load i64, ptr %t435, !tbaa !24
  %t438 = add i64 %t436, 1
  %t440 = load ptr, ptr %l189, !tbaa !29
  %t441 = getelementptr %"compiler/build:Config", ptr %t440, i32 0, i32 20
  store i64 %t438, ptr %t441, !tbaa !24
  %t442 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t444 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t442)
  %t445 = extractvalue { i32, %"std/os:FileInfo" } %t444, 1
  %t446 = extractvalue { i32, %"std/os:FileInfo" } %t444, 0
  store i32 %t446, ptr %l195
  %t447 = icmp ne i32 %t446, 0
  br i1 %t447, label %bb103, label %ok.448
ok.448:
  store %"std/os:FileInfo" %t445, ptr %l194
  br label %bb102
bb102:
  %t449 = load %"std/os:FileInfo", ptr %l194
  store %"std/os:FileInfo" %t449, ptr %l192
  br label %bb105
bb103:
  %t450 = load i32, ptr %l195, !tbaa !23
  %t451 = ashr i32 %t450, 16
  %t453 = icmp eq i32 %t451, 1
  store i1 %t453, ptr %l197, !tbaa !21
  br label %bb104
bb104:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb105:
  %t454 = load %"std/os:FileInfo", ptr %l192
  store %"std/os:FileInfo" %t454, ptr %l28
  %t455 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t456 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t457 = getelementptr %"std/os:FileInfo", ptr %l28, i32 0, i32 1
  %t458 = load i64, ptr %t457, !tbaa !24
  %t459 = getelementptr %"std/os:FileInfo", ptr %l28, i32 0, i32 2
  %t460 = load i64, ptr %t459, !tbaa !24
  %t462 = extractvalue { i64, ptr } %t456, 1
  %t463 = extractvalue { i64, ptr } %t456, 0
  %t464 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t465 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t466 = add i64 %t463, %t465
  %t468 = call i64 @__olang_fmt_i64(ptr null, i64 %t458)
  %t469 = add i64 %t466, %t468
  %t470 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t471 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t472 = add i64 %t469, %t471
  %t474 = call i64 @__olang_fmt_i64(ptr null, i64 %t460)
  %t475 = add i64 %t472, %t474
  %t476 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 1
  %t477 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d73, i32 0, i32 1) }, 0
  %t478 = add i64 %t475, %t477
  %t479 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t478)
  call void @olang_textcopy(ptr %t479, ptr %t462, i64 %t463)
  %t480 = getelementptr i8, ptr %t479, i64 %t463
  call void @olang_textcopy(ptr %t480, ptr %t464, i64 %t465)
  %t481 = getelementptr i8, ptr %t480, i64 %t465
  %t482 = call i64 @__olang_fmt_i64(ptr %t481, i64 %t458)
  %t483 = getelementptr i8, ptr %t481, i64 %t468
  call void @olang_textcopy(ptr %t483, ptr %t470, i64 %t471)
  %t484 = getelementptr i8, ptr %t483, i64 %t471
  %t485 = call i64 @__olang_fmt_i64(ptr %t484, i64 %t460)
  %t486 = getelementptr i8, ptr %t484, i64 %t474
  call void @olang_textcopy(ptr %t486, ptr %t476, i64 %t477)
  %t487 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t479, 1
  %t491 = extractvalue { i64, ptr } %t488, 0
  %t492 = extractvalue { i64, ptr } %t488, 1
  %t493 = mul i64 %t491, 1
  %t494 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t493)
  call void @llvm.memcpy.p0.p0.i64(ptr %t494, ptr %t492, i64 %t493, i1 false)
  %t495 = insertvalue { i64, ptr } undef, i64 %t491, 0
  %t496 = insertvalue { i64, ptr } %t495, ptr %t494, 1
  %t499 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t455, { i64, ptr } %t496)
  store i32 %t499, ptr %l205
  %t500 = icmp ne i32 %t499, 0
  br i1 %t500, label %bb107, label %ok.501
ok.501:
  br label %bb106
bb106:
  br label %bb109
bb107:
  %t502 = load i32, ptr %l205, !tbaa !23
  %t503 = ashr i32 %t502, 16
  %t505 = icmp eq i32 %t503, 1
  store i1 %t505, ptr %l207, !tbaa !21
  br label %bb108
bb108:
  call void @__olang_ert_req_clear()
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l21 = alloca i1
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 2
  %t8 = getelementptr %"compiler/target:Target", ptr %t7, i32 0, i32 9
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %lp1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 2
  %t15 = getelementptr %"compiler/target:Target", ptr %t14, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d74, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d74, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t20, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t11, { i64, ptr } %t33)
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t36 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s1)
  store { i64, ptr } %t36, ptr %l11
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d75, i32 0, i32 1) })
  store i1 %t40, ptr %l13
  br label %bb6
bb6:
  %t41 = load i1, ptr %l13, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %lp1
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t49 = extractvalue { i64, ptr } %t45, 1
  %t50 = extractvalue { i64, ptr } %t45, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t44, { i64, ptr } %t62)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 2
  %t68 = getelementptr %"compiler/target:Target", ptr %t67, i32 0, i32 6
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t71, ptr %l21
  br label %bb12
bb12:
  %t72 = load i1, ptr %l21, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %lp1
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/build:Config", ptr %t76, i32 0, i32 2
  %t79 = getelementptr %"compiler/target:Target", ptr %t78, i32 0, i32 6
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t75, { i64, ptr } %t93)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 9
  %t99 = load i1, ptr %t98, !tbaa !21
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t101 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t101, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d78, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/build:Config", ptr %t103, i32 0, i32 10
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t106, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d79, i32 0, i32 1) })
  store i1 %t108, ptr %l33
  br label %bb21
bb21:
  %t109 = load i1, ptr %l33, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t112 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t112, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d80, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 4
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb26, label %bb27
bb26:
  %t119 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t119, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d81, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t121 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t121, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d82, i32 0, i32 1) })
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/build:Config", ptr %t123, i32 0, i32 6
  %t126 = load i1, ptr %t125, !tbaa !21
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t128 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t128, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d83, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t130 = load ptr, ptr %lp1
  %t131 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t130
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %rv
  br label %ret
bb34:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/build:Config", ptr %t133, i32 0, i32 6
  %t136 = load i1, ptr %t135, !tbaa !21
  br i1 %t136, label %bb35, label %bb36
bb35:
  %t138 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t138, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t140 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t140, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d85, i32 0, i32 1) })
  br label %bb38
bb38:
  %t142 = load ptr, ptr %lp1
  %t143 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t142
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t143, ptr %rv
  br label %ret
bb39:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/build:Config", ptr %t145, i32 0, i32 5
  %t148 = load i1, ptr %t147, !tbaa !21
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t150, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t152 = load ptr, ptr %lp1
  %t153 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t152
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t153, ptr %rv
  br label %ret
bb43:
  %t155 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t155, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb44
bb44:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/build:Config", ptr %t157, i32 0, i32 21
  %t160 = load i1, ptr %t159, !tbaa !21
  br i1 %t160, label %bb45, label %bb46
bb45:
  %t162 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t162, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb47
bb46:
  %t164 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t164, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t166 = load ptr, ptr %lp1
  %t167 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t166
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t167, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  store ptr %a4, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb4
bb4:
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = load i64, ptr %l16, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load i64, ptr %l7, !tbaa !24
  %t22 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t18, i64 %t19)
  store { i64, ptr } %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %t23)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t27 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l7, !tbaa !24
  br label %bb3
bb11:
  store ptr %l5, ptr %l26, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t31)
  store { i64, ptr } %t33, ptr %l28
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t34, { i64, ptr } %t35)
  br label %bb13
bb13:
  %t37 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t37, ptr %l30
  br label %bb14
bb14:
  %t38 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t38, ptr %l9, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/build:Config", ptr %t39, i32 0, i32 0
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l32, !tbaa !27
  store { i64, ptr } %a1, ptr %l33, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l34, !tbaa !24
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = icmp sle i64 0, 16
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb17:
  %t50 = load i64, ptr %l34, !tbaa !24
  %t51 = icmp sle i64 16, %t50
  br i1 %t51, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb19:
  %t53 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 0
  %t56 = sub i64 16, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l38, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %a2)
  store { i64, ptr } %t61, ptr %l40
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb21:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t62)
  store { i64, ptr } %t64, ptr %l42
  br label %bb22
bb22:
  %t65 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d90, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d91, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d92, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t66, i64 %t67)
  %t94 = getelementptr i8, ptr %t93, i64 %t67
  call void @olang_textcopy(ptr %t94, ptr %t68, i64 %t69)
  %t95 = getelementptr i8, ptr %t94, i64 %t69
  call void @olang_textcopy(ptr %t95, ptr %t72, i64 %t73)
  %t96 = getelementptr i8, ptr %t95, i64 %t73
  call void @olang_textcopy(ptr %t96, ptr %t75, i64 %t76)
  %t97 = getelementptr i8, ptr %t96, i64 %t76
  call void @olang_textcopy(ptr %t97, ptr %t79, i64 %t80)
  %t98 = getelementptr i8, ptr %t97, i64 %t80
  call void @olang_textcopy(ptr %t98, ptr %t83, i64 %t84)
  %t99 = getelementptr i8, ptr %t98, i64 %t84
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t90, i64 %t91)
  %t101 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t93, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/build:Unit"
  %l7 = alloca %"compiler/build:compiles"
  %lp8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/build:Unit"
  %l13 = alloca i64
  %l14 = alloca %"compiler/build:compiles"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"compiler/build:Unit"
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca %"compiler/build:Unit"
  %l36 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l52 = alloca %"compiler/build:compiles"
  %l53 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l56 = alloca i64
  %l58 = alloca i64
  %l64 = alloca %"compiler/build:Unit"
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l85 = alloca i64
  %l88 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l105 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i32
  %l124 = alloca i32
  %l127 = alloca i64
  %l129 = alloca %"compiler/build:compiles"
  %l131 = alloca i64
  %l133 = alloca i64
  %l138 = alloca i64
  %l143 = alloca i1
  %l146 = alloca i1
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l156 = alloca i1
  %l158 = alloca i1
  %l162 = alloca i1
  %l164 = alloca i32
  %l166 = alloca i1
  %l173 = alloca %"compiler/build:Unit"
  %l174 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca i32
  %l190 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca i32
  %l200 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca i32
  %l215 = alloca i32
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l22, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l22, !tbaa !24
  %t10 = load i64, ptr %l24, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/build:Unit" %t19, ptr %l29
  br label %bb6
bb6:
  %t20 = load %"compiler/build:Unit", ptr %l29
  store %"compiler/build:Unit" %t20, ptr %l6
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = add i64 %t21, %t25
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb1
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l36, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 4
  %t38 = load i1, ptr %t37, !tbaa !21
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/build:Config", ptr %t42, i32 0, i32 6
  %t45 = load i1, ptr %t44, !tbaa !21
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l40, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l40, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 5
  %t53 = load i1, ptr %t52, !tbaa !21
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l44, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l44, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t62 = icmp sge i64 %t58, %t59
  store i1 %t62, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t64 = load i1, ptr %l48, !tbaa !21
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 21
  store i1 %t64, ptr %t66, !tbaa !21
  %t67 = call %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %s0)
  store %"compiler/build:compiles" %t67, ptr %l52
  br label %bb18
bb18:
  %t68 = load %"compiler/build:compiles", ptr %l52
  store %"compiler/build:compiles" %t68, ptr %l7
  %t69 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t69, ptr %l53
  br label %bb19
bb19:
  %t70 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t70, ptr %lp8
  %t71 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l53
  %t72 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %t72
  %t73 = load ptr, ptr %l1, !tbaa !29
  %t75 = getelementptr %"compiler/build:Program", ptr %t73, i32 0, i32 0
  store ptr %t75, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  %t77 = load i64, ptr %l10, !tbaa !24
  store i64 %t77, ptr %l56, !tbaa !24
  %t78 = load ptr, ptr %l9, !tbaa !29
  %t80 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t78)
  store i64 %t80, ptr %l58
  br label %bb21
bb21:
  %t81 = load i64, ptr %l56, !tbaa !24
  %t82 = load i64, ptr %l58, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  %t85 = xor i1 %t83, true
  br i1 %t85, label %bb22, label %bb23
bb22:
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t87 = load i64, ptr %l10, !tbaa !24
  store i64 %t87, ptr %l11, !tbaa !24
  %t89 = load ptr, ptr %l9, !tbaa !29
  %t90 = load i64, ptr %l10, !tbaa !24
  %t93 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t89, i64 %t90)
  store %"compiler/build:Unit" %t93, ptr %l64
  br label %bb25
bb25:
  %t94 = load %"compiler/build:Unit", ptr %l64
  store %"compiler/build:Unit" %t94, ptr %l12
  %t95 = load ptr, ptr %lp8
  store ptr %t95, ptr %l65, !tbaa !29
  %t96 = load ptr, ptr %l0, !tbaa !29
  store ptr %t96, ptr %l67, !tbaa !29
  store ptr %l7, ptr %l68, !tbaa !29
  %t97 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %v3, { i64, ptr } %t98)
  store { i64, ptr } %t100, ptr %l70
  br label %bb26
bb26:
  %t101 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t108 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 1
  %t109 = load i32, ptr %t108
  %t110 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 2
  %t111 = load { i64, ptr }, ptr %t110, !tbaa !27
  %t112 = load ptr, ptr %l2, !tbaa !29
  %t113 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 3
  %t114 = load { i64, ptr }, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l11, !tbaa !24
  %t116 = load ptr, ptr %l67, !tbaa !29
  %t117 = load ptr, ptr %l68, !tbaa !29
  %t124 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v1, ptr %v3, ptr %t116, ptr %t117, { i64, ptr } %t107, i32 %t109, { i64, ptr } %t111, ptr %t112, { i64, ptr } %t114, i64 %t115)
  %t125 = extractvalue { i32, { i64, ptr } } %t124, 1
  %t126 = extractvalue { i32, { i64, ptr } } %t124, 0
  store i32 %t126, ptr %l78
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb28, label %ok.128
ok.128:
  store { i64, ptr } %t125, ptr %l77
  br label %bb27
bb27:
  %t129 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t129, ptr %l66, !tbaa !27
  br label %bb29
bb28:
  %t130 = load i32, ptr %l78, !tbaa !23
  %t131 = lshr i32 %t130, 16
  %t132 = and i32 %t130, 65535
  %t133 = icmp eq i32 %t131, 1
  %t134 = select i1 %t133, i32 1, i32 0
  %t135 = icmp eq i32 %t130, 0
  %t136 = shl i32 %t134, 16
  %t137 = or i32 %t136, %t132
  %t138 = select i1 %t135, i32 0, i32 %t137
  call void @__olang_scope_close(ptr %s0)
  %t140 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t138, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t140, ptr %rv
  br label %ret
bb29:
  %t141 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 0
  %t143 = extractvalue { i64, ptr } %t141, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t148, { i64, ptr } %t147)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t150 = load i64, ptr %l10, !tbaa !24
  %t152 = add i64 %t150, 1
  store i64 %t152, ptr %l10, !tbaa !24
  br label %bb20
bb32:
  %t154 = load ptr, ptr %l1, !tbaa !29
  %t156 = getelementptr %"compiler/build:Program", ptr %t154, i32 0, i32 0
  %t158 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t156)
  store i64 %t158, ptr %l85
  br label %bb33
bb33:
  %t159 = load i64, ptr %l85, !tbaa !24
  store i64 %t159, ptr %l13, !tbaa !24
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/build:Program", ptr %t160, i32 0, i32 1
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  %t165 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t163, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d93, i32 0, i32 1) })
  store i1 %t165, ptr %l88
  br label %bb34
bb34:
  %t166 = load i1, ptr %l88, !tbaa !21
  %t167 = xor i1 %t166, true
  br i1 %t167, label %bb35, label %bb36
bb35:
  %t169 = load ptr, ptr %lp8
  store ptr %t169, ptr %l90, !tbaa !29
  %t170 = load ptr, ptr %l0, !tbaa !29
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/build:Program", ptr %t171, i32 0, i32 1
  %t174 = load { i64, ptr }, ptr %t173, !tbaa !27
  %t175 = load ptr, ptr %l2, !tbaa !29
  %t176 = load i64, ptr %l13, !tbaa !24
  %t183 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t170, ptr %l7, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d94, i32 0, i32 1) }, i32 0, { i64, ptr } %t174, ptr %t175, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, i64 %t176)
  %t184 = extractvalue { i32, { i64, ptr } } %t183, 1
  %t185 = extractvalue { i32, { i64, ptr } } %t183, 0
  store i32 %t185, ptr %l100
  %t186 = icmp ne i32 %t185, 0
  br i1 %t186, label %bb38, label %ok.187
ok.187:
  store { i64, ptr } %t184, ptr %l99
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t188 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t188, ptr %l91, !tbaa !27
  br label %bb39
bb38:
  %t189 = load i32, ptr %l100, !tbaa !23
  %t190 = lshr i32 %t189, 16
  %t191 = and i32 %t189, 65535
  %t192 = icmp eq i32 %t190, 1
  %t193 = select i1 %t192, i32 1, i32 0
  %t194 = icmp eq i32 %t189, 0
  %t195 = shl i32 %t193, 16
  %t196 = or i32 %t195, %t191
  %t197 = select i1 %t194, i32 0, i32 %t196
  call void @__olang_scope_close(ptr %s0)
  %t199 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t197, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t199, ptr %rv
  br label %ret
bb39:
  %t200 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  %t207 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t207, { i64, ptr } %t206)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t211 = getelementptr %"compiler/build:Program", ptr %t209, i32 0, i32 2
  %t212 = load { i64, ptr }, ptr %t211, !tbaa !27
  %t214 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t212, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t214, ptr %l105
  br label %bb42
bb42:
  %t215 = load i1, ptr %l105, !tbaa !21
  %t216 = xor i1 %t215, true
  br i1 %t216, label %bb43, label %bb44
bb43:
  %t218 = load ptr, ptr %lp8
  store ptr %t218, ptr %l107, !tbaa !29
  %t219 = load ptr, ptr %l0, !tbaa !29
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = getelementptr %"compiler/build:Program", ptr %t220, i32 0, i32 2
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  %t224 = load ptr, ptr %l2, !tbaa !29
  %t225 = load i64, ptr %l13, !tbaa !24
  %t227 = add i64 %t225, 1
  %t234 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t219, ptr %l7, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d97, i32 0, i32 1) }, i32 0, { i64, ptr } %t223, ptr %t224, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d98, i32 0, i32 1) }, i64 %t227)
  %t235 = extractvalue { i32, { i64, ptr } } %t234, 1
  %t236 = extractvalue { i32, { i64, ptr } } %t234, 0
  store i32 %t236, ptr %l118
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb46, label %ok.238
ok.238:
  store { i64, ptr } %t235, ptr %l117
  br label %bb45
bb44:
  br label %bb49
bb45:
  %t239 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t239, ptr %l108, !tbaa !27
  br label %bb47
bb46:
  %t240 = load i32, ptr %l118, !tbaa !23
  %t241 = lshr i32 %t240, 16
  %t242 = and i32 %t240, 65535
  %t243 = icmp eq i32 %t241, 1
  %t244 = select i1 %t243, i32 1, i32 0
  %t245 = icmp eq i32 %t240, 0
  %t246 = shl i32 %t244, 16
  %t247 = or i32 %t246, %t242
  %t248 = select i1 %t245, i32 0, i32 %t247
  call void @__olang_scope_close(ptr %s0)
  %t250 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t248, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t250, ptr %rv
  br label %ret
bb47:
  %t251 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  %t258 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t258, { i64, ptr } %t257)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t260 = load ptr, ptr %l0, !tbaa !29
  %t261 = load ptr, ptr %l2, !tbaa !29
  %t265 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %s0, ptr %v2, ptr %t260, ptr %l7, ptr %t261)
  store i32 %t265, ptr %l124
  %t266 = icmp ne i32 %t265, 0
  br i1 %t266, label %bb51, label %ok.267
ok.267:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t268 = load i32, ptr %l124, !tbaa !23
  %t269 = lshr i32 %t268, 16
  %t270 = and i32 %t268, 65535
  %t271 = icmp eq i32 %t269, 1
  %t272 = select i1 %t271, i32 1, i32 0
  %t273 = icmp eq i32 %t268, 0
  %t274 = shl i32 %t272, 16
  %t275 = or i32 %t274, %t270
  %t276 = select i1 %t273, i32 0, i32 %t275
  call void @__olang_scope_close(ptr %s0)
  %t278 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t276, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t278, ptr %rv
  br label %ret
bb52:
  %t279 = getelementptr %"compiler/build:compiles", ptr %l7, i32 0, i32 7
  %t281 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t279)
  store i64 %t281, ptr %l127
  br label %bb53
bb53:
  %t282 = load i64, ptr %l127, !tbaa !24
  %t283 = icmp sgt i64 %t282, 0
  br i1 %t283, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  %t285 = call %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %s9)
  store %"compiler/build:compiles" %t285, ptr %l129
  br label %bb56
bb55:
  br label %bb110
bb56:
  %t286 = load %"compiler/build:compiles", ptr %l129
  store %"compiler/build:compiles" %t286, ptr %l14
  %t287 = getelementptr %"compiler/build:compiles", ptr %l7, i32 0, i32 7
  store ptr %t287, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t289 = load i64, ptr %l16, !tbaa !24
  store i64 %t289, ptr %l131, !tbaa !24
  %t290 = load ptr, ptr %l15, !tbaa !29
  %t292 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t290)
  store i64 %t292, ptr %l133
  br label %bb58
bb58:
  %t293 = load i64, ptr %l131, !tbaa !24
  %t294 = load i64, ptr %l133, !tbaa !24
  %t295 = icmp slt i64 %t293, %t294
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb106
bb60:
  br label %bb61
bb61:
  %t299 = load ptr, ptr %l15, !tbaa !29
  %t300 = load i64, ptr %l16, !tbaa !24
  %t303 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t299, i64 %t300)
  store i64 %t303, ptr %l138
  br label %bb62
bb62:
  %t304 = load i64, ptr %l138, !tbaa !24
  store i64 %t304, ptr %l17, !tbaa !24
  %t305 = load i64, ptr %l17, !tbaa !24
  %t306 = load i64, ptr %l13, !tbaa !24
  %t308 = add i64 %t306, 1
  %t311 = icmp slt i64 %t305, %t308
  br i1 %t311, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb66
bb64:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t315 = getelementptr %"compiler/build:Program", ptr %t313, i32 0, i32 1
  %t316 = load { i64, ptr }, ptr %t315, !tbaa !27
  %t318 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s11, { i64, ptr } %t316, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t318, ptr %l146
  br label %bb65
bb65:
  %t319 = load i1, ptr %l146, !tbaa !21
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l143, !tbaa !21
  br label %bb66
bb66:
  %t322 = load i1, ptr %l143, !tbaa !21
  br i1 %t322, label %bb67, label %bb68
bb67:
  %t323 = load ptr, ptr %lp8
  %t324 = load i64, ptr %l17, !tbaa !24
  %t327 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s11, ptr %t323, i64 %t324)
  store { i64, ptr } %t327, ptr %l151
  br label %bb69
bb68:
  %t328 = load ptr, ptr %lp8
  %t329 = load i64, ptr %l13, !tbaa !24
  %t332 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s11, ptr %t328, i64 %t329)
  store { i64, ptr } %t332, ptr %l154
  br label %bb70
bb69:
  %t333 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t333, ptr %l148, !tbaa !27
  br label %bb71
bb70:
  %t334 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t334, ptr %l148, !tbaa !27
  br label %bb71
bb71:
  %t335 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t335, ptr %l18, !tbaa !27
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t336 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t338 = call i1 @std_2fos_2eExists(ptr %s11, { i64, ptr } %t336)
  store i1 %t338, ptr %l156
  br label %bb73
bb73:
  %t339 = load i1, ptr %l156, !tbaa !21
  %t340 = xor i1 %t339, true
  br i1 %t340, label %bb74, label %bb75
bb74:
  %t342 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t342, 1
  %t345 = extractvalue { i64, ptr } %t342, 0
  %t346 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t347 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t348 = add i64 %t345, %t347
  %t349 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t348)
  call void @olang_textcopy(ptr %t349, ptr %t344, i64 %t345)
  %t350 = getelementptr i8, ptr %t349, i64 %t345
  call void @olang_textcopy(ptr %t350, ptr %t346, i64 %t347)
  %t351 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t349, 1
  %t354 = extractvalue { i64, ptr } %t352, 0
  %t355 = extractvalue { i64, ptr } %t352, 1
  %t356 = mul i64 %t354, 1
  %t357 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t356)
  call void @llvm.memcpy.p0.p0.i64(ptr %t357, ptr %t355, i64 %t356, i1 false)
  %t358 = insertvalue { i64, ptr } undef, i64 %t354, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  %t361 = call i1 @compiler_2fbuild_2eholderAlive(ptr %s12, { i64, ptr } %t359)
  store i1 %t361, ptr %l162
  br label %bb76
bb75:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb77
bb76:
  %t362 = load i1, ptr %l162, !tbaa !21
  store i1 %t362, ptr %l158, !tbaa !21
  br label %bb77
bb77:
  %t363 = load i1, ptr %l158, !tbaa !21
  %t364 = xor i1 %t363, true
  br i1 %t364, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb79:
  br label %bb80
bb80:
  %t366 = call i32 @usleep(i32 20000)
  store i32 %t366, ptr %l164
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb82
bb82:
  br label %bb72
bb83:
  %t367 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t369 = call i1 @std_2fos_2eExists(ptr %s11, { i64, ptr } %t367)
  store i1 %t369, ptr %l166
  br label %bb84
bb84:
  %t370 = load i1, ptr %l166, !tbaa !21
  br i1 %t370, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb105
bb86:
  br label %bb87
bb87:
  %t371 = load i64, ptr %l17, !tbaa !24
  %t372 = load i64, ptr %l13, !tbaa !24
  %t375 = icmp slt i64 %t371, %t372
  br i1 %t375, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s15
  %t377 = load ptr, ptr %l1, !tbaa !29
  %t379 = getelementptr %"compiler/build:Program", ptr %t377, i32 0, i32 0
  %t380 = load i64, ptr %l17, !tbaa !24
  %t383 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t379, i64 %t380)
  store %"compiler/build:Unit" %t383, ptr %l173
  br label %bb90
bb89:
  %t384 = load i64, ptr %l17, !tbaa !24
  %t385 = load i64, ptr %l13, !tbaa !24
  %t388 = icmp eq i64 %t384, %t385
  br i1 %t388, label %bb95, label %bb96
bb90:
  %t390 = load %"compiler/build:Unit", ptr %l173
  store %"compiler/build:Unit" %t390, ptr %l19
  %t391 = load ptr, ptr %l0, !tbaa !29
  store ptr %t391, ptr %l175, !tbaa !29
  store ptr %l14, ptr %l176, !tbaa !29
  %t392 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 0
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !27
  %t395 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s15, { i64, ptr } %t393)
  store { i64, ptr } %t395, ptr %l178
  br label %bb91
bb91:
  %t396 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t397 = extractvalue { i64, ptr } %t396, 0
  %t398 = extractvalue { i64, ptr } %t396, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  %t403 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 1
  %t404 = load i32, ptr %t403
  %t405 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 2
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !27
  %t407 = load ptr, ptr %l2, !tbaa !29
  %t408 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 3
  %t409 = load { i64, ptr }, ptr %t408, !tbaa !27
  %t410 = load ptr, ptr %l175, !tbaa !29
  %t411 = load ptr, ptr %l176, !tbaa !29
  %t417 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s9, ptr %s15, ptr %v1, ptr %v2, ptr %v1, ptr %s15, ptr %t410, ptr %t411, { i64, ptr } %t402, i32 %t404, { i64, ptr } %t406, ptr %t407, { i64, ptr } %t409, i64 -1)
  %t418 = extractvalue { i32, { i64, ptr } } %t417, 1
  %t419 = extractvalue { i32, { i64, ptr } } %t417, 0
  store i32 %t419, ptr %l185
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb93, label %ok.421
ok.421:
  store { i64, ptr } %t418, ptr %l184
  br label %bb92
bb92:
  %t422 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t422, ptr %l174, !tbaa !27
  br label %bb94
bb93:
  %t423 = load i32, ptr %l185, !tbaa !23
  %t424 = lshr i32 %t423, 16
  %t425 = and i32 %t423, 65535
  %t426 = icmp eq i32 %t424, 1
  %t427 = select i1 %t426, i32 1, i32 0
  %t428 = icmp eq i32 %t423, 0
  %t429 = shl i32 %t427, 16
  %t430 = or i32 %t429, %t425
  %t431 = select i1 %t428, i32 0, i32 %t430
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t433 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t431, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t433, ptr %rv
  br label %ret
bb94:
  call void @__olang_scope_close(ptr %s15)
  br label %bb104
bb95:
  store %olang.scope zeroinitializer, ptr %s17
  %t434 = load ptr, ptr %l0, !tbaa !29
  %t435 = load ptr, ptr %l1, !tbaa !29
  %t437 = getelementptr %"compiler/build:Program", ptr %t435, i32 0, i32 1
  %t438 = load { i64, ptr }, ptr %t437, !tbaa !27
  %t439 = load ptr, ptr %l2, !tbaa !29
  %t445 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s9, ptr %s17, ptr %v1, ptr %v2, ptr %s17, ptr %s17, ptr %t434, ptr %l14, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d101, i32 0, i32 1) }, i32 0, { i64, ptr } %t438, ptr %t439, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) }, i64 -1)
  %t446 = extractvalue { i32, { i64, ptr } } %t445, 1
  %t447 = extractvalue { i32, { i64, ptr } } %t445, 0
  store i32 %t447, ptr %l198
  %t448 = icmp ne i32 %t447, 0
  br i1 %t448, label %bb98, label %ok.449
ok.449:
  store { i64, ptr } %t446, ptr %l197
  br label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s18
  %t450 = load ptr, ptr %l0, !tbaa !29
  %t451 = load ptr, ptr %l1, !tbaa !29
  %t453 = getelementptr %"compiler/build:Program", ptr %t451, i32 0, i32 2
  %t454 = load { i64, ptr }, ptr %t453, !tbaa !27
  %t455 = load ptr, ptr %l2, !tbaa !29
  %t461 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s9, ptr %s18, ptr %v1, ptr %v2, ptr %s18, ptr %s18, ptr %t450, ptr %l14, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d103, i32 0, i32 1) }, i32 0, { i64, ptr } %t454, ptr %t455, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) }, i64 -1)
  %t462 = extractvalue { i32, { i64, ptr } } %t461, 1
  %t463 = extractvalue { i32, { i64, ptr } } %t461, 0
  store i32 %t463, ptr %l208
  %t464 = icmp ne i32 %t463, 0
  br i1 %t464, label %bb101, label %ok.465
ok.465:
  store { i64, ptr } %t462, ptr %l207
  br label %bb100
bb97:
  %t466 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t466, ptr %l190, !tbaa !27
  br label %bb99
bb98:
  %t467 = load i32, ptr %l198, !tbaa !23
  %t468 = lshr i32 %t467, 16
  %t469 = and i32 %t467, 65535
  %t470 = icmp eq i32 %t468, 1
  %t471 = select i1 %t470, i32 1, i32 0
  %t472 = icmp eq i32 %t467, 0
  %t473 = shl i32 %t471, 16
  %t474 = or i32 %t473, %t469
  %t475 = select i1 %t472, i32 0, i32 %t474
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t477 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t475, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t477, ptr %rv
  br label %ret
bb99:
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb100:
  %t478 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t478, ptr %l200, !tbaa !27
  br label %bb102
bb101:
  %t479 = load i32, ptr %l208, !tbaa !23
  %t480 = lshr i32 %t479, 16
  %t481 = and i32 %t479, 65535
  %t482 = icmp eq i32 %t480, 1
  %t483 = select i1 %t482, i32 1, i32 0
  %t484 = icmp eq i32 %t479, 0
  %t485 = shl i32 %t483, 16
  %t486 = or i32 %t485, %t481
  %t487 = select i1 %t484, i32 0, i32 %t486
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t489 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t487, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t489, ptr %rv
  br label %ret
bb102:
  call void @__olang_scope_close(ptr %s18)
  br label %bb103
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s11)
  br label %bb105
bb105:
  %t490 = load i64, ptr %l16, !tbaa !24
  %t492 = add i64 %t490, 1
  store i64 %t492, ptr %l16, !tbaa !24
  br label %bb57
bb106:
  %t494 = load ptr, ptr %l0, !tbaa !29
  %t495 = load ptr, ptr %l2, !tbaa !29
  %t499 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %s9, ptr %v2, ptr %t494, ptr %l14, ptr %t495)
  store i32 %t499, ptr %l215
  %t500 = icmp ne i32 %t499, 0
  br i1 %t500, label %bb108, label %ok.501
ok.501:
  br label %bb107
bb107:
  br label %bb109
bb108:
  %t502 = load i32, ptr %l215, !tbaa !23
  %t503 = lshr i32 %t502, 16
  %t504 = and i32 %t502, 65535
  %t505 = icmp eq i32 %t503, 1
  %t506 = select i1 %t505, i32 1, i32 0
  %t507 = icmp eq i32 %t502, 0
  %t508 = shl i32 %t506, 16
  %t509 = or i32 %t508, %t504
  %t510 = select i1 %t507, i32 0, i32 %t509
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t512 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t510, 0
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t512, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s9)
  br label %bb110
bb110:
  %t513 = load ptr, ptr %lp8
  %t514 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t513
  call void @__olang_scope_close(ptr %s0)
  %t516 = insertvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t514, 1
  store { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t516, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/os:Output"
  %l4 = alloca i1
  %l5 = alloca %"std/os:Output"
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/os:Output"
  %l12 = alloca i32
  %l14 = alloca i1
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 23
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d104, i32 0, i32 1) })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = mul i64 2, 16
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 2, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 0
  store { i64, ptr } %t24, ptr %t32, !tbaa !37
  %t33 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %t34, i64 1
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d105, i32 0, i32 1) }, ptr %t35, !tbaa !37
  %t36 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t37 = call { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d106, i32 0, i32 1) }, i1 true)
  %t38 = extractvalue { i32, %"std/os:Output" } %t37, 1
  %t39 = extractvalue { i32, %"std/os:Output" } %t37, 0
  store i32 %t39, ptr %l12
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb5, label %ok.41
ok.41:
  store %"std/os:Output" %t38, ptr %l11
  br label %bb4
bb3:
  br label %bb8
bb4:
  %t42 = load %"std/os:Output", ptr %l11
  store %"std/os:Output" %t42, ptr %l5
  br label %bb7
bb5:
  %t43 = load i32, ptr %l12, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  store i1 %t46, ptr %l14, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) }, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t47 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t47, ptr %rv
  br label %ret
bb7:
  %t48 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t48, ptr %l1
  %t49 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = extractvalue { i64, ptr } %t51, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  %t67 = getelementptr %"compiler/build:Config", ptr %t49, i32 0, i32 23
  store { i64, ptr } %t64, ptr %t67, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb8:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/build:Config", ptr %t68, i32 0, i32 23
  %t71 = load { i64, ptr }, ptr %t70, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t71, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { { i64, ptr }, { i64, ptr } }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { { i64, ptr }, { i64, ptr } }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i64
  %l35 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l86 = alloca { i64, ptr }
  %l87 = alloca %"compiler/msgs:Msg"
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca i1
  %l97 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l117 = alloca { i64, ptr }
  %l118 = alloca %"compiler/msgs:Msg"
  %l120 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l129 = alloca i64
  %l131 = alloca i64
  %l136 = alloca { i64, ptr }
  %l138 = alloca i32
  %l140 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t160 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:compiles", ptr %t1, i32 0, i32 0
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v1, ptr %v1, ptr %t3)
  store { i64, ptr } %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l20
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/build:compiles", ptr %t9, i32 0, i32 5
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s0, ptr %t11)
  store { i64, ptr } %t13, ptr %l23
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t15 = load i64, ptr %l20, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t17 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t14, i64 %t15, { i64, ptr } %t16)
  store { { i64, ptr }, { i64, ptr } } %t17, ptr %l24
  br label %bb4
bb4:
  %t18 = load { { i64, ptr }, { i64, ptr } }, ptr %l24
  store { { i64, ptr }, { i64, ptr } } %t18, ptr %l3
  %t19 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l25, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l26, !tbaa !24
  %t23 = load i64, ptr %l26, !tbaa !24
  %t24 = mul i64 %t23, 4
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l27, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = mul i64 %t32, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l28, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = mul i64 %t39, 16
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = mul i64 %t48, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t52, i32 0, i32 19
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/build:compiles", ptr %t55, i32 0, i32 0
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %v1, ptr %t57)
  store i64 %t59, ptr %l35
  br label %bb5
bb5:
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = load i64, ptr %l35, !tbaa !24
  %t62 = add i64 %t60, %t61
  %t64 = load ptr, ptr %l31, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 19
  store i64 %t62, ptr %t65, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb6, label %bb7
bb6:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb11
bb8:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l45, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb10
bb10:
  %t96 = load i64, ptr %l45, !tbaa !24
  store i64 %t96, ptr %l42, !tbaa !24
  br label %bb11
bb11:
  %t97 = load i64, ptr %l42, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb57
bb14:
  br label %bb15
bb15:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l12, !tbaa !24
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/build:compiles", ptr %t116, i32 0, i32 4
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t118, i64 %t119)
  store { i64, ptr } %t122, ptr %l66
  br label %bb16
bb16:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/build:compiles", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t125, i64 %t126)
  store { i64, ptr } %t129, ptr %l70
  br label %bb17
bb17:
  %t130 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t132 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t130, { i64, ptr } %t131)
  store i32 %t132, ptr %l71
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb19, label %ok.134
ok.134:
  br label %bb18
bb18:
  br label %bb21
bb19:
  %t135 = load i32, ptr %l71, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l73, !tbaa !21
  br label %bb20
bb20:
  call void @__olang_ert_req_clear()
  br label %bb21
bb21:
  %t139 = load i64, ptr %l12, !tbaa !24
  %t141 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t142 = load ptr, ptr %t141, !tbaa !27
  %t143 = getelementptr i32, ptr %t142, i64 %t139
  %t144 = load i32, ptr %t143, !tbaa !33
  %t146 = icmp ne i32 %t144, 0
  br i1 %t146, label %bb22, label %bb23
bb22:
  %t148 = load i64, ptr %l12, !tbaa !24
  %t150 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t151 = load ptr, ptr %t150, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %t151, i64 %t148
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t153)
  br label %bb24
bb23:
  br label %bb36
bb24:
  %t155 = load i1, ptr %l6, !tbaa !21
  %t157 = xor i1 %t155, true
  br i1 %t157, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  %t159 = load ptr, ptr %l2, !tbaa !29
  store ptr %t159, ptr %l81, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t160
  %t161 = getelementptr { i64, [3 x i64] }, ptr %t160, i32 0, i32 0
  store i64 0, ptr %t161
  %t162 = load { i64, [3 x i64] }, ptr %t160
  store { i64, [3 x i64] } %t162, ptr %l82
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = getelementptr %"compiler/build:compiles", ptr %t163, i32 0, i32 3
  %t166 = load i64, ptr %l12, !tbaa !24
  %t169 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t165, i64 %t166)
  store { i64, ptr } %t169, ptr %l86
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t170 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t171 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v1, ptr %s5, { i64, ptr } %t170)
  store %"compiler/msgs:Msg" %t171, ptr %l87
  br label %bb28
bb28:
  %t172 = load ptr, ptr %l81, !tbaa !29
  %t173 = load { i64, [3 x i64] }, ptr %l82
  %t174 = load %"compiler/msgs:Msg", ptr %l87
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %s5, ptr %t172, { i64, [3 x i64] } %t173, %"compiler/msgs:Msg" %t174)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  store i1 true, ptr %l6, !tbaa !21
  %t175 = load ptr, ptr %l1, !tbaa !29
  %t177 = getelementptr %"compiler/build:compiles", ptr %t175, i32 0, i32 1
  %t178 = load i64, ptr %l12, !tbaa !24
  %t181 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t177, i64 %t178)
  store { i64, ptr } %t181, ptr %l91
  br label %bb31
bb31:
  %t182 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t183 = call i32 @std_2fos_2eRemove(ptr %v1, { i64, ptr } %t182)
  store i32 %t183, ptr %l92
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb33, label %ok.185
ok.185:
  br label %bb32
bb32:
  br label %bb35
bb33:
  %t186 = load i32, ptr %l92, !tbaa !23
  %t187 = ashr i32 %t186, 16
  %t189 = icmp eq i32 %t187, 1
  store i1 %t189, ptr %l94, !tbaa !21
  br label %bb34
bb34:
  call void @__olang_ert_req_clear()
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s2)
  br label %bb56
bb36:
  %t190 = load i64, ptr %l12, !tbaa !24
  %t192 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %t193, i64 %t190
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !37
  %t197 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t195, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) })
  store i1 %t197, ptr %l97
  br label %bb37
bb37:
  %t198 = load i1, ptr %l97, !tbaa !21
  %t199 = xor i1 %t198, true
  br i1 %t199, label %bb38, label %bb39
bb38:
  %t201 = load i64, ptr %l12, !tbaa !24
  %t203 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t204 = load ptr, ptr %t203, !tbaa !27
  %t205 = getelementptr { i64, ptr }, ptr %t204, i64 %t201
  %t206 = load { i64, ptr }, ptr %t205, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t206)
  br label %bb40
bb39:
  br label %bb41
bb40:
  br label %bb41
bb41:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/build:compiles", ptr %t208, i32 0, i32 1
  %t211 = load i64, ptr %l12, !tbaa !24
  %t214 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t210, i64 %t211)
  store { i64, ptr } %t214, ptr %l104
  br label %bb42
bb42:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/build:compiles", ptr %t215, i32 0, i32 2
  %t218 = load i64, ptr %l12, !tbaa !24
  %t221 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t217, i64 %t218)
  store { i64, ptr } %t221, ptr %l108
  br label %bb43
bb43:
  %t222 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t224 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t222, { i64, ptr } %t223)
  store i32 %t224, ptr %l109
  %t225 = icmp ne i32 %t224, 0
  br i1 %t225, label %bb45, label %ok.226
ok.226:
  br label %bb44
bb44:
  br label %bb53
bb45:
  %t227 = load i32, ptr %l109, !tbaa !23
  %t228 = ashr i32 %t227, 16
  %t230 = icmp eq i32 %t228, 1
  store i1 %t230, ptr %l111, !tbaa !21
  br label %bb46
bb46:
  call void @__olang_ert_req_clear()
  %t231 = load i1, ptr %l6, !tbaa !21
  %t233 = xor i1 %t231, true
  br i1 %t233, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s9
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/build:compiles", ptr %t235, i32 0, i32 2
  %t238 = load i64, ptr %l12, !tbaa !24
  %t241 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t237, i64 %t238)
  store { i64, ptr } %t241, ptr %l117
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t242 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s9)
  store %"compiler/msgs:Msg" %t242, ptr %l118
  br label %bb50
bb50:
  %t243 = load ptr, ptr %l2, !tbaa !29
  %t244 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t245 = load %"compiler/msgs:Msg", ptr %l118
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s9, ptr %v2, { i64, ptr } %t244, %"compiler/msgs:Msg" %t245, ptr %t243)
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s9)
  br label %bb52
bb52:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb56
bb53:
  %t247 = load ptr, ptr %l0, !tbaa !29
  store ptr %t247, ptr %l120, !tbaa !29
  %t248 = load ptr, ptr %l1, !tbaa !29
  %t250 = getelementptr %"compiler/build:compiles", ptr %t248, i32 0, i32 2
  %t251 = load i64, ptr %l12, !tbaa !24
  %t254 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t250, i64 %t251)
  store { i64, ptr } %t254, ptr %l124
  br label %bb54
bb54:
  %t255 = load ptr, ptr %l120, !tbaa !29
  %t256 = load { i64, ptr }, ptr %l124, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %t255, { i64, ptr } %t256)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s2)
  br label %bb56
bb56:
  %t257 = load i64, ptr %l11, !tbaa !24
  %t259 = add i64 %t257, 1
  store i64 %t259, ptr %l11, !tbaa !24
  br label %bb12
bb57:
  %t261 = load ptr, ptr %l1, !tbaa !29
  %t263 = getelementptr %"compiler/build:compiles", ptr %t261, i32 0, i32 6
  store ptr %t263, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb58
bb58:
  %t265 = load i64, ptr %l14, !tbaa !24
  store i64 %t265, ptr %l129, !tbaa !24
  %t266 = load ptr, ptr %l13, !tbaa !29
  %t268 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t266)
  store i64 %t268, ptr %l131
  br label %bb59
bb59:
  %t269 = load i64, ptr %l129, !tbaa !24
  %t270 = load i64, ptr %l131, !tbaa !24
  %t271 = icmp slt i64 %t269, %t270
  %t273 = xor i1 %t271, true
  br i1 %t273, label %bb60, label %bb61
bb60:
  br label %bb69
bb61:
  br label %bb62
bb62:
  %t275 = load ptr, ptr %l13, !tbaa !29
  %t276 = load i64, ptr %l14, !tbaa !24
  %t279 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t275, i64 %t276)
  store { i64, ptr } %t279, ptr %l136
  br label %bb63
bb63:
  %t280 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t283 = call i32 @std_2fos_2eRemoveAll(ptr %v1, { i64, ptr } %t280)
  store i32 %t283, ptr %l138
  %t284 = icmp ne i32 %t283, 0
  br i1 %t284, label %bb65, label %ok.285
ok.285:
  br label %bb64
bb64:
  br label %bb67
bb65:
  %t286 = load i32, ptr %l138, !tbaa !23
  %t287 = ashr i32 %t286, 16
  %t289 = icmp eq i32 %t287, 1
  store i1 %t289, ptr %l140, !tbaa !21
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  br label %bb67
bb67:
  br label %bb68
bb68:
  %t290 = load i64, ptr %l14, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l14, !tbaa !24
  br label %bb58
bb69:
  %t294 = load i1, ptr %l6, !tbaa !21
  br i1 %t294, label %bb70, label %bb71
bb70:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb71:
  br label %bb72
bb72:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t4)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l6, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/build:Config", ptr %t13, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  store { i64, ptr } %t16, ptr %l8, !tbaa !27
  %t17 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t17, ptr %l9
  br label %bb4
bb4:
  %t19 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t20 = load %"compiler/msgs:Msg", ptr %l9
  call void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %s1, ptr %v1, { i64, ptr } %t19, %"compiler/msgs:Msg" %t20, ptr %a1)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %rv
  br label %ret
bb6:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/os:Output"
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"std/os:Output"
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"std/os:Output"
  %l26 = alloca i32
  %l28 = alloca i1
  %l37 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 11
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 11
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d109, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d109, i32 0, i32 1) }, 0
  %t16 = call i64 @__olang_fmt_i64(ptr null, i64 %t12)
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = getelementptr i8, ptr %t18, i64 %t14
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t12)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t8, { i64, ptr } %t29)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/build:Config", ptr %t33, i32 0, i32 10
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/build:Program", ptr %t37, i32 0, i32 6
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t44 = extractvalue { i64, ptr } %t36, 1
  %t45 = extractvalue { i64, ptr } %t36, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t40, 1
  %t52 = extractvalue { i64, ptr } %t40, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d112, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t41, i64 %t42)
  %t58 = getelementptr i8, ptr %t57, i64 %t42
  call void @olang_textcopy(ptr %t58, ptr %t44, i64 %t45)
  %t59 = getelementptr i8, ptr %t58, i64 %t45
  call void @olang_textcopy(ptr %t59, ptr %t47, i64 %t48)
  %t60 = getelementptr i8, ptr %t59, i64 %t48
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t73 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t32, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d113, i32 0, i32 1) }, { i64, ptr } %t70)
  store { i64, ptr } %t73, ptr %l19
  br label %bb5
bb5:
  %t74 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t80)
  br label %bb6
bb6:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t82)
  store { i64, ptr } %t84, ptr %l23
  br label %bb7
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d114, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t87 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t85, { i64, ptr } %t86, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t88 = extractvalue { i32, %"std/os:Output" } %t87, 1
  %t89 = extractvalue { i32, %"std/os:Output" } %t87, 0
  store i32 %t89, ptr %l26
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb9, label %ok.91
ok.91:
  store %"std/os:Output" %t88, ptr %l25
  br label %bb8
bb8:
  %t92 = load %"std/os:Output", ptr %l25
  store %"std/os:Output" %t92, ptr %l21
  br label %bb11
bb9:
  %t93 = load i32, ptr %l26, !tbaa !23
  %t94 = ashr i32 %t93, 16
  %t96 = icmp eq i32 %t94, 1
  store i1 %t96, ptr %l28, !tbaa !21
  br label %bb10
bb10:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb11:
  %t98 = load %"std/os:Output", ptr %l21
  store %"std/os:Output" %t98, ptr %l3
  %t99 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 0
  %t100 = load i32, ptr %t99, !tbaa !23
  %t102 = icmp eq i32 %t100, 0
  br i1 %t102, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s5
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/build:Config", ptr %t105, i32 0, i32 10
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t112 = extractvalue { i64, ptr } %t108, 1
  %t113 = extractvalue { i64, ptr } %t108, 0
  %t114 = add i64 %t110, %t113
  %t115 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t109, i64 %t110)
  %t119 = getelementptr i8, ptr %t118, i64 %t110
  call void @olang_textcopy(ptr %t119, ptr %t112, i64 %t113)
  %t120 = getelementptr i8, ptr %t119, i64 %t113
  call void @olang_textcopy(ptr %t120, ptr %t115, i64 %t116)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t132 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s5, ptr %s5, ptr %s5, ptr %t104, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d117, i32 0, i32 1) }, { i64, ptr } %t129)
  store { i64, ptr } %t132, ptr %l37
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t133 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = mul i64 %t134, 1
  %t137 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t136)
  call void @llvm.memcpy.p0.p0.i64(ptr %t137, ptr %t135, i64 %t136, i1 false)
  %t138 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  call void @compiler_2fbuild_2esayln(ptr %s5, { i64, ptr } %t139)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb16:
  %t142 = load ptr, ptr %l0, !tbaa !29
  %t143 = load ptr, ptr %l0, !tbaa !29
  %t145 = getelementptr %"compiler/build:Config", ptr %t143, i32 0, i32 10
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t147 = load ptr, ptr %l2, !tbaa !29
  %t149 = getelementptr %"compiler/build:Program", ptr %t147, i32 0, i32 6
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t151 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 1
  %t152 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d118, i32 0, i32 1) }, 0
  %t154 = extractvalue { i64, ptr } %t146, 1
  %t155 = extractvalue { i64, ptr } %t146, 0
  %t156 = add i64 %t152, %t155
  %t157 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d119, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d119, i32 0, i32 1) }, 0
  %t159 = add i64 %t156, %t158
  %t161 = extractvalue { i64, ptr } %t150, 1
  %t162 = extractvalue { i64, ptr } %t150, 0
  %t163 = add i64 %t159, %t162
  %t164 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d120, i32 0, i32 1) }, 1
  %t165 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d120, i32 0, i32 1) }, 0
  %t166 = add i64 %t163, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t151, i64 %t152)
  %t168 = getelementptr i8, ptr %t167, i64 %t152
  call void @olang_textcopy(ptr %t168, ptr %t154, i64 %t155)
  %t169 = getelementptr i8, ptr %t168, i64 %t155
  call void @olang_textcopy(ptr %t169, ptr %t157, i64 %t158)
  %t170 = getelementptr i8, ptr %t169, i64 %t158
  call void @olang_textcopy(ptr %t170, ptr %t161, i64 %t162)
  %t171 = getelementptr i8, ptr %t170, i64 %t162
  call void @olang_textcopy(ptr %t171, ptr %t164, i64 %t165)
  %t172 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t167, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  %t183 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t142, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d121, i32 0, i32 1) }, { i64, ptr } %t180)
  store { i64, ptr } %t183, ptr %l47
  br label %bb17
bb17:
  %t184 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = extractvalue { i64, ptr } %t184, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t190)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l24 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l35 = alloca i32
  %l37 = alloca i1
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i32
  %l46 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 22
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d122, i32 0, i32 1) })
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 22
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/build:Config", ptr %t13, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = add i64 %t18, 1
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t21, 0
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp sge i64 %t27, 0
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = icmp sle i64 %t30, %t31
  br i1 %t32, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb9:
  %t38 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = getelementptr i8, ptr %t39, i64 %t40
  %t43 = sub i64 %t41, %t40
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t46 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d123, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t45, 1
  %t54 = extractvalue { i64, ptr } %t45, 0
  %t55 = add i64 %t51, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t56, 1
  store { i64, ptr } %t60, ptr %l2, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t62)
  store i1 %t64, ptr %l24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb11:
  %t65 = load i1, ptr %l24, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t66, i32 0, i32 22
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t69)
  store i32 %t71, ptr %l27
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb16, label %ok.73
ok.73:
  br label %bb15
bb15:
  br label %bb18
bb16:
  %t74 = load i32, ptr %l27, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  store i1 %t77, ptr %l29, !tbaa !21
  br label %bb17
bb17:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb18:
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t78, ptr %l30, !tbaa !27
  %t79 = call i32 @getpid()
  store i32 %t79, ptr %l31
  br label %bb19
bb19:
  %t80 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 1
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d124, i32 0, i32 1) }, 0
  %t85 = add i64 %t82, %t84
  %t86 = load i32, ptr %l31, !tbaa !23
  %t87 = sext i32 %t86 to i64
  %t88 = call i64 @__olang_fmt_i64(ptr null, i64 %t87)
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d125, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d125, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t81, i64 %t82)
  %t94 = getelementptr i8, ptr %t93, i64 %t82
  call void @olang_textcopy(ptr %t94, ptr %t83, i64 %t84)
  %t95 = getelementptr i8, ptr %t94, i64 %t84
  %t96 = call i64 @__olang_fmt_i64(ptr %t95, i64 %t87)
  %t97 = getelementptr i8, ptr %t95, i64 %t88
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t93, 1
  store { i64, ptr } %t99, ptr %l3, !tbaa !27
  %t101 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = call i32 @std_2fos_2eLink(ptr %v1, ptr %s0, { i64, ptr } %t101, { i64, ptr } %t102)
  store i32 %t105, ptr %l35
  %t106 = icmp ne i32 %t105, 0
  br i1 %t106, label %bb21, label %ok.107
ok.107:
  br label %bb20
bb20:
  br label %bb23
bb21:
  %t108 = load i32, ptr %l35, !tbaa !23
  %t109 = ashr i32 %t108, 16
  %t111 = icmp eq i32 %t109, 1
  store i1 %t111, ptr %l37, !tbaa !21
  br label %bb22
bb22:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb23:
  %t112 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t116 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t112, { i64, ptr } %t113)
  store i32 %t116, ptr %l40
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb25, label %ok.118
ok.118:
  br label %bb24
bb24:
  br label %bb31
bb25:
  %t119 = load i32, ptr %l40, !tbaa !23
  %t120 = ashr i32 %t119, 16
  %t122 = icmp eq i32 %t120, 1
  store i1 %t122, ptr %l42, !tbaa !21
  br label %bb26
bb26:
  call void @__olang_ert_req_clear()
  %t123 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t125 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t123)
  store i32 %t125, ptr %l44
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb28, label %ok.127
ok.127:
  br label %bb27
bb27:
  br label %bb30
bb28:
  %t128 = load i32, ptr %l44, !tbaa !23
  %t129 = ashr i32 %t128, 16
  %t131 = icmp eq i32 %t129, 1
  store i1 %t131, ptr %l46, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  br label %bb30
bb30:
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca i1
  %l47 = alloca i32
  %l49 = alloca i1
  %l50 = alloca ptr
  %l51 = alloca { i64, [3 x i64] }
  %l53 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i1
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i32
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t128 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v3, ptr %s0, { i64, ptr } %a3)
  store { i64, ptr } %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 17
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) })
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/build:Config", ptr %t14, i32 0, i32 17
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = extractvalue { i64, ptr } %t17, 0
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t19, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l14, !tbaa !27
  br label %bb7
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/build:Config", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t30)
  store { i64, ptr } %t32, ptr %l22
  br label %bb5
bb5:
  %t33 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l25, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t44 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t40, { i64, ptr } %t42, { i64, ptr } %t43)
  store { i64, ptr } %t44, ptr %l27
  br label %bb6
bb6:
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t57 = extractvalue { i64, ptr } %t45, 1
  %t58 = extractvalue { i64, ptr } %t45, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d130, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d130, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t47, i64 %t48)
  %t64 = getelementptr i8, ptr %t63, i64 %t48
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t63, 1
  store { i64, ptr } %t69, ptr %l14, !tbaa !27
  br label %bb7
bb7:
  %t71 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, { i64, ptr } %t72)
  store { i64, ptr } %t74, ptr %l31
  br label %bb8
bb8:
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = getelementptr i8, ptr %t82, i64 %t78
  call void @olang_textcopy(ptr %t83, ptr %t79, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t95 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t93, { i64, ptr } %t92, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d132, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d134, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d135, i32 0, i32 1) })
  store { i64, ptr } %t95, ptr %l35
  br label %bb9
bb9:
  %t96 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t96, ptr %l7, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l36, !tbaa !29
  store ptr %a2, ptr %l37, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t99, ptr %l38, !tbaa !27
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/build:Program", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d136, i32 0, i32 1) })
  store i1 %t105, ptr %l41
  br label %bb10
bb10:
  %t106 = load i1, ptr %l41, !tbaa !21
  %t107 = xor i1 %t106, true
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/build:Program", ptr %t108, i32 0, i32 3
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/build:Program", ptr %t111, i32 0, i32 4
  %t114 = load ptr, ptr %l36, !tbaa !29
  %t115 = load ptr, ptr %l37, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t120 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v2, ptr %s0, ptr %v1, ptr %v1, ptr %t114, ptr %t115, { i64, ptr } %t116, i1 %t107, ptr %t110, ptr %t113)
  store i32 %t120, ptr %l47
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb12, label %ok.122
ok.122:
  br label %bb11
bb11:
  br label %bb17
bb12:
  %t123 = load i32, ptr %l47, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  store i1 %t126, ptr %l49, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t127 = load ptr, ptr %l4, !tbaa !29
  store ptr %t127, ptr %l50, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t128
  %t129 = getelementptr { i64, [3 x i64] }, ptr %t128, i32 0, i32 0
  store i64 0, ptr %t129
  %t130 = load { i64, [3 x i64] }, ptr %t128
  store { i64, [3 x i64] } %t130, ptr %l51
  %t131 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s4, { i64, ptr } %t131)
  store %"compiler/msgs:Msg" %t133, ptr %l53
  br label %bb14
bb14:
  %t134 = load ptr, ptr %l50, !tbaa !29
  %t135 = load { i64, [3 x i64] }, ptr %l51
  %t136 = load %"compiler/msgs:Msg", ptr %l53
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s4, ptr %t134, { i64, [3 x i64] } %t135, %"compiler/msgs:Msg" %t136)
  br label %bb15
bb15:
  %t137 = load ptr, ptr %l4, !tbaa !29
  %t139 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t137)
  store i32 %t139, ptr %l55
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t140 = load i32, ptr %l55, !tbaa !23
  store i32 %t140, ptr %rv
  br label %ret
bb17:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d137, i32 0, i32 1) })
  br label %bb18
bb18:
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/build:Program", ptr %t142, i32 0, i32 5
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t149 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t141, { i64, ptr } %t145)
  store i32 %t149, ptr %l60
  %t150 = icmp ne i32 %t149, 0
  br i1 %t150, label %bb20, label %ok.151
ok.151:
  br label %bb19
bb19:
  br label %bb25
bb20:
  %t152 = load i32, ptr %l60, !tbaa !23
  %t153 = ashr i32 %t152, 16
  %t155 = icmp eq i32 %t153, 1
  store i1 %t155, ptr %l62, !tbaa !21
  br label %bb21
bb21:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s5
  %t156 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t156, ptr %l63, !tbaa !27
  %t157 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s5)
  store %"compiler/msgs:Msg" %t157, ptr %l64
  br label %bb22
bb22:
  %t158 = load ptr, ptr %l4, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t160 = load %"compiler/msgs:Msg", ptr %l64
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s5, ptr %v4, { i64, ptr } %t159, %"compiler/msgs:Msg" %t160, ptr %t158)
  br label %bb23
bb23:
  %t162 = load ptr, ptr %l4, !tbaa !29
  %t164 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t162)
  store i32 %t164, ptr %l67
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t165 = load i32, ptr %l67, !tbaa !23
  store i32 %t165, ptr %rv
  br label %ret
bb25:
  %t166 = load ptr, ptr %l0, !tbaa !29
  %t167 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = extractvalue { i64, ptr } %t167, 0
  %t171 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t169, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  %t183 = getelementptr %"compiler/build:Config", ptr %t166, i32 0, i32 18
  store { i64, ptr } %t180, ptr %t183, !tbaa !27
  %t184 = load ptr, ptr %l0, !tbaa !29
  %t186 = getelementptr %"compiler/build:Config", ptr %t184, i32 0, i32 16
  %t187 = load i1, ptr %t186, !tbaa !21
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s7
  %t191 = load ptr, ptr %l0, !tbaa !29
  store ptr %t191, ptr %l75, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t194 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s7, { i64, ptr } %t192)
  store { i64, ptr } %t194, ptr %l77
  br label %bb28
bb27:
  br label %bb32
bb28:
  %t195 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t197 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s7, { i64, ptr } %t195)
  store { i64, ptr } %t197, ptr %l79
  br label %bb29
bb29:
  %t198 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t199 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t200 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = add i64 %t199, %t202
  %t204 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t205 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t206 = add i64 %t203, %t205
  %t207 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 1
  %t209 = extractvalue { i64, ptr } %t207, 0
  %t210 = add i64 %t206, %t209
  %t211 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t210)
  call void @olang_textcopy(ptr %t211, ptr %t198, i64 %t199)
  %t212 = getelementptr i8, ptr %t211, i64 %t199
  call void @olang_textcopy(ptr %t212, ptr %t201, i64 %t202)
  %t213 = getelementptr i8, ptr %t212, i64 %t202
  call void @olang_textcopy(ptr %t213, ptr %t204, i64 %t205)
  %t214 = getelementptr i8, ptr %t213, i64 %t205
  call void @olang_textcopy(ptr %t214, ptr %t208, i64 %t209)
  %t215 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t216 = insertvalue { i64, ptr } %t215, ptr %t211, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  %t219 = extractvalue { i64, ptr } %t216, 1
  %t220 = mul i64 %t218, 1
  %t221 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t220)
  call void @llvm.memcpy.p0.p0.i64(ptr %t221, ptr %t219, i64 %t220, i1 false)
  %t222 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t221, 1
  %t224 = load ptr, ptr %l75, !tbaa !29
  %t226 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t224, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d140, i32 0, i32 1) }, { i64, ptr } %t223)
  store { i64, ptr } %t226, ptr %l82
  br label %bb30
bb30:
  %t227 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  call void @compiler_2fbuild_2esayln(ptr %s7, { i64, ptr } %t233)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s7)
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d141, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d143, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d144, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Config", ptr %t11, i32 0, i32 5
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d145, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d146, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 7
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d147, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d148, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb12:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/build:Config", ptr %t21, i32 0, i32 9
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d150, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb15:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/build:Config", ptr %t26, i32 0, i32 10
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb16
bb16:
  %t32 = load i1, ptr %l18, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d153, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb19
bb19:
  %t35 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 1
  %t37 = extractvalue { i64, ptr } %t35, 0
  %t38 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = add i64 %t37, %t40
  %t42 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = add i64 %t41, %t44
  %t46 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = add i64 %t45, %t48
  %t50 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = add i64 %t49, %t52
  %t54 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t57 = add i64 %t53, %t56
  %t58 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t57)
  call void @olang_textcopy(ptr %t58, ptr %t36, i64 %t37)
  %t59 = getelementptr i8, ptr %t58, i64 %t37
  call void @olang_textcopy(ptr %t59, ptr %t39, i64 %t40)
  %t60 = getelementptr i8, ptr %t59, i64 %t40
  call void @olang_textcopy(ptr %t60, ptr %t43, i64 %t44)
  %t61 = getelementptr i8, ptr %t60, i64 %t44
  call void @olang_textcopy(ptr %t61, ptr %t47, i64 %t48)
  %t62 = getelementptr i8, ptr %t61, i64 %t48
  call void @olang_textcopy(ptr %t62, ptr %t51, i64 %t52)
  %t63 = getelementptr i8, ptr %t62, i64 %t52
  call void @olang_textcopy(ptr %t63, ptr %t55, i64 %t56)
  %t64 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t58, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 15
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = extractvalue { i64, ptr } %t8, 0
  %t12 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t10, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t17, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb5
bb5:
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %a1, 1
  %t24 = extractvalue { i64, ptr } %a1, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t40)
  br label %bb6
bb6:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v2, ptr %l3, { i64, ptr } %t43)
  br label %bb7
bb7:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb8
bb8:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d156, i32 0, i32 1) })
  br label %bb9
bb9:
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t49, ptr %l20
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t50, ptr %l21, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l22, !tbaa !24
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l23, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l22, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t64, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t65 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, [3 x i64] }
  %l13 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 2
  %t5 = call { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v2, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %a1, ptr %l9, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [3 x i64] }, ptr %t16
  store { i64, [3 x i64] } %t18, ptr %l10
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/build:Config", ptr %t19, i32 0, i32 2
  %t22 = getelementptr %"compiler/target:Target", ptr %t21, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %s1, { i64, ptr } %t23)
  store %"compiler/msgs:Msg" %t25, ptr %l13
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l9, !tbaa !29
  %t27 = load { i64, [3 x i64] }, ptr %l10
  %t28 = load %"compiler/msgs:Msg", ptr %l13
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s1, ptr %t26, { i64, [3 x i64] } %t27, %"compiler/msgs:Msg" %t28)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t30 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t30, ptr %rv
  br label %ret
bb6:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t31, 1
  store { i32, { i64, ptr } } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v2, ptr %s0, ptr %a2)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t33 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d158, i32 0, i32 1) }, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l10
  br label %bb3
bb3:
  %t34 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t40)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fbuild_2efileError(ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t1, %"compiler/msgs:Msg" %a2, ptr %t3)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t16)
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d159, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d159, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t39 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d160, i32 0, i32 1) }, { i64, ptr } %t36)
  store { i64, ptr } %t39, ptr %l14
  br label %bb4
bb4:
  %t40 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t46)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, { i64, ptr } %a6, i64 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l22 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l32 = alloca i1
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca { i64, ptr }
  %l50 = alloca i1
  %l54 = alloca i1
  %l57 = alloca { i64, ptr }
  %l61 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l72 = alloca i32
  %l74 = alloca i1
  %l76 = alloca i1
  %l80 = alloca i1
  %l83 = alloca i1
  %l91 = alloca i64
  %l92 = alloca i64
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l107 = alloca i1
  %l109 = alloca i1
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca { i64, ptr }
  %l116 = alloca i1
  %l118 = alloca { i64, ptr }
  %l120 = alloca i64
  %l122 = alloca i64
  %l123 = alloca { i64, ptr }
  %l126 = alloca i64
  %l127 = alloca i64
  %l131 = alloca { i64, ptr }
  %l132 = alloca i32
  %l137 = alloca i32
  %l139 = alloca i1
  %l140 = alloca { i64, ptr }
  %l141 = alloca %"compiler/msgs:Msg"
  %l146 = alloca i1
  %l149 = alloca i32
  %l151 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca { i64, [3 x i64] }
  %l155 = alloca %"compiler/msgs:Msg"
  %l157 = alloca { i64, ptr }
  %l158 = alloca i32
  %l160 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l168 = alloca i64
  %l170 = alloca i64
  %l175 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l195 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t419 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  store i64 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l3
  %t3 = trunc i64 4 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %s0, ptr %t6)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l24
  br label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v3, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l27
  br label %bb4
bb3:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l24
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l22
  br label %bb5
bb4:
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l22
  br label %bb5
bb5:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l22
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l8
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l28, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l29, !tbaa !27
  %t19 = load i32, ptr %l3
  store i32 %t19, ptr %l30
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d161, i32 0, i32 1) })
  store i1 %t22, ptr %l32
  br label %bb6
bb6:
  %t23 = load i1, ptr %l32, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t26, ptr %l34, !tbaa !27
  br label %bb10
bb8:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v5, { i64, ptr } %t28)
  store { i64, ptr } %t30, ptr %l37
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l34, !tbaa !27
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l28, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t41 = load i32, ptr %l30
  %t42 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t44 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v2, ptr %v5, ptr %s0, ptr %v6, ptr %t39, { i64, ptr } %t40, i32 %t41, { i64, ptr } %t42, ptr %l8)
  store { i64, ptr } %t44, ptr %l40
  br label %bb11
bb11:
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 16, i64 8)
  store ptr %t45, ptr %lp9
  %t46 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t47 = load ptr, ptr %lp9
  store { i64, ptr } %t46, ptr %t47, !tbaa !27
  %t48 = load ptr, ptr %lp9
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t49)
  store i1 %t51, ptr %l42
  br label %bb12
bb12:
  %t52 = load i1, ptr %l42, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l43, !tbaa !21
  br label %bb16
bb14:
  %t53 = load ptr, ptr %lp9
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l44, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l45, !tbaa !24
  %t57 = load i64, ptr %l45, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l46, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l45, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/build:compiles", ptr %t69, i32 0, i32 2
  %t75 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v1, ptr %s0, ptr %t71, { i64, ptr } %t68)
  store i1 %t75, ptr %l50
  br label %bb15
bb15:
  %t76 = load i1, ptr %l50, !tbaa !21
  store i1 %t76, ptr %l43, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l43, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %lp9
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t81 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t79, 1
  store { i32, { i64, ptr } } %t81, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 22
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d162, i32 0, i32 1) })
  store i1 %t87, ptr %l54
  br label %bb20
bb20:
  %t88 = load i1, ptr %l54, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/build:Config", ptr %t91, i32 0, i32 22
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l57, !tbaa !27
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/build:Config", ptr %t95, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l61, !tbaa !24
  %t103 = load ptr, ptr %lp9
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l63, !tbaa !24
  %t107 = load ptr, ptr %lp9
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l64, !tbaa !24
  %t110 = load i64, ptr %l61, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb23, label %bb24
bb22:
  br label %bb37
bb23:
  %t113 = load i64, ptr %l61, !tbaa !24
  %t114 = load i64, ptr %l63, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb25:
  %t117 = load i64, ptr %l63, !tbaa !24
  %t118 = load i64, ptr %l64, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  br i1 %t119, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb27:
  %t121 = load ptr, ptr %lp9
  %t122 = getelementptr { i64, ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l61, !tbaa !24
  %t125 = load i64, ptr %l63, !tbaa !24
  %t126 = getelementptr i8, ptr %t123, i64 %t124
  %t127 = sub i64 %t125, %t124
  %t128 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  %t130 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t137 = extractvalue { i64, ptr } %t129, 1
  %t138 = extractvalue { i64, ptr } %t129, 0
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t152 = load ptr, ptr %lp9
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t156 = call i32 @std_2fos_2eLink(ptr %s2, ptr %v6, { i64, ptr } %t151, { i64, ptr } %t153)
  store i32 %t156, ptr %l72
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb30, label %ok.158
ok.158:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb29:
  br label %bb32
bb30:
  %t159 = load i32, ptr %l72, !tbaa !23
  %t160 = ashr i32 %t159, 16
  %t162 = icmp eq i32 %t160, 1
  store i1 %t162, ptr %l74, !tbaa !21
  br label %bb31
bb31:
  call void @__olang_ert_req_clear()
  br label %bb32
bb32:
  %t163 = load ptr, ptr %lp9
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t164)
  store i1 %t166, ptr %l76
  br label %bb33
bb33:
  %t167 = load i1, ptr %l76, !tbaa !21
  br i1 %t167, label %bb34, label %bb35
bb34:
  %t168 = load ptr, ptr %lp9
  %t169 = load { i64, ptr }, ptr %t168, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t171 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t169, 1
  store { i32, { i64, ptr } } %t171, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s2)
  br label %bb37
bb37:
  %t172 = load i64, ptr %l7, !tbaa !24
  %t174 = icmp sge i64 %t172, 0
  br i1 %t174, label %bb38, label %bb39
bb38:
  %t176 = load ptr, ptr %lp9
  %t177 = load { i64, ptr }, ptr %t176, !tbaa !27
  %t178 = load ptr, ptr %l1, !tbaa !29
  %t181 = call i1 @compiler_2fbuild_2eclaim(ptr %v6, ptr %v1, { i64, ptr } %t177, ptr %t178)
  store i1 %t181, ptr %l83
  br label %bb40
bb39:
  store i1 false, ptr %l80, !tbaa !21
  br label %bb41
bb40:
  %t182 = load i1, ptr %l83, !tbaa !21
  %t183 = xor i1 %t182, true
  store i1 %t183, ptr %l80, !tbaa !21
  br label %bb41
bb41:
  %t185 = load i1, ptr %l80, !tbaa !21
  br i1 %t185, label %bb42, label %bb43
bb42:
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/build:compiles", ptr %t186, i32 0, i32 7
  %t189 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t188, i64 %t189)
  br label %bb44
bb43:
  br label %bb45
bb44:
  %t192 = load ptr, ptr %lp9
  %t193 = load { i64, ptr }, ptr %t192, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t195 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t193, 1
  store { i32, { i64, ptr } } %t195, ptr %rv
  br label %ret
bb45:
  %t196 = load ptr, ptr %lp9
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t201 = sub i64 %t199, 2
  store i64 %t201, ptr %l91, !tbaa !24
  %t202 = load ptr, ptr %lp9
  %t203 = load { i64, ptr }, ptr %t202, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t203, 0
  store i64 %t204, ptr %l92, !tbaa !24
  %t205 = icmp sge i64 0, 0
  br i1 %t205, label %bb46, label %bb47
bb46:
  %t207 = load i64, ptr %l91, !tbaa !24
  %t208 = icmp sle i64 0, %t207
  br i1 %t208, label %bb48, label %bb49
bb47:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb48:
  %t210 = load i64, ptr %l91, !tbaa !24
  %t211 = load i64, ptr %l92, !tbaa !24
  %t212 = icmp sle i64 %t210, %t211
  br i1 %t212, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb50:
  %t214 = load ptr, ptr %lp9
  %t215 = getelementptr { i64, ptr }, ptr %t214, i32 0, i32 1
  %t216 = load ptr, ptr %t215, !tbaa !27
  %t217 = load i64, ptr %l91, !tbaa !24
  %t218 = getelementptr i8, ptr %t216, i64 0
  %t219 = sub i64 %t217, 0
  %t220 = insertvalue { i64, ptr } undef, i64 %t219, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t218, 1
  %t223 = extractvalue { i64, ptr } %t221, 1
  %t224 = extractvalue { i64, ptr } %t221, 0
  %t225 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t226 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t227 = add i64 %t224, %t226
  %t228 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t227)
  call void @olang_textcopy(ptr %t228, ptr %t223, i64 %t224)
  %t229 = getelementptr i8, ptr %t228, i64 %t224
  call void @olang_textcopy(ptr %t229, ptr %t225, i64 %t226)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t228, 1
  store { i64, ptr } %t231, ptr %l11, !tbaa !27
  %t233 = load ptr, ptr %l0, !tbaa !29
  %t235 = getelementptr %"compiler/build:Config", ptr %t233, i32 0, i32 0
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  store { i64, ptr } %t236, ptr %l99, !tbaa !27
  %t237 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t237, ptr %l100, !tbaa !27
  %t238 = load i32, ptr %l3
  %t240 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %t238)
  store { i64, ptr } %t240, ptr %l102
  br label %bb52
bb51:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb52:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t241)
  store { i64, ptr } %t243, ptr %l104
  br label %bb53
bb53:
  %t244 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 1
  %t246 = extractvalue { i64, ptr } %t244, 0
  %t247 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t248 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t249 = add i64 %t246, %t248
  %t250 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = add i64 %t249, %t252
  %t254 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 1
  %t256 = extractvalue { i64, ptr } %t254, 0
  %t257 = add i64 %t253, %t256
  %t258 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t264)
  call void @olang_textcopy(ptr %t265, ptr %t245, i64 %t246)
  %t266 = getelementptr i8, ptr %t265, i64 %t246
  call void @olang_textcopy(ptr %t266, ptr %t247, i64 %t248)
  %t267 = getelementptr i8, ptr %t266, i64 %t248
  call void @olang_textcopy(ptr %t267, ptr %t251, i64 %t252)
  %t268 = getelementptr i8, ptr %t267, i64 %t252
  call void @olang_textcopy(ptr %t268, ptr %t255, i64 %t256)
  %t269 = getelementptr i8, ptr %t268, i64 %t256
  call void @olang_textcopy(ptr %t269, ptr %t259, i64 %t260)
  %t270 = getelementptr i8, ptr %t269, i64 %t260
  call void @olang_textcopy(ptr %t270, ptr %t262, i64 %t263)
  %t271 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t272 = insertvalue { i64, ptr } %t271, ptr %t265, 1
  store { i64, ptr } %t272, ptr %l12, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t276 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t274, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d167, i32 0, i32 1) })
  store i1 %t276, ptr %l107
  br label %bb54
bb54:
  %t277 = load i1, ptr %l107, !tbaa !21
  %t278 = xor i1 %t277, true
  br i1 %t278, label %bb55, label %bb56
bb55:
  %t280 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t280, ptr %l110, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t281, 0
  store i64 %t282, ptr %l111, !tbaa !24
  %t283 = load i64, ptr %l111, !tbaa !24
  %t284 = mul i64 %t283, 1
  %t285 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t284)
  %t286 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t287 = insertvalue { i64, ptr } %t286, ptr %t285, 1
  store { i64, ptr } %t287, ptr %l112, !tbaa !27
  %t288 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t289 = load ptr, ptr %t288, !tbaa !27
  %t290 = getelementptr { i64, ptr }, ptr %l110, i32 0, i32 1
  %t291 = load ptr, ptr %t290, !tbaa !27
  %t292 = load i64, ptr %l111, !tbaa !24
  %t293 = mul i64 %t292, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t289, ptr %t291, i64 %t293, i1 false)
  %t294 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t295 = load ptr, ptr %l1, !tbaa !29
  %t297 = getelementptr %"compiler/build:compiles", ptr %t295, i32 0, i32 3
  %t301 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v1, ptr %s0, ptr %t297, { i64, ptr } %t294)
  store i1 %t301, ptr %l116
  br label %bb57
bb56:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb58
bb57:
  %t302 = load i1, ptr %l116, !tbaa !21
  %t303 = xor i1 %t302, true
  store i1 %t303, ptr %l109, !tbaa !21
  br label %bb58
bb58:
  %t305 = load i1, ptr %l109, !tbaa !21
  br i1 %t305, label %bb59, label %bb60
bb59:
  %t306 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t306, ptr %l118, !tbaa !27
  %t307 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 0
  %t309 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  store i64 %t310, ptr %l120, !tbaa !24
  %t312 = load i64, ptr %l120, !tbaa !24
  %t313 = icmp eq i64 %t308, %t312
  br i1 %t313, label %bb61, label %bb62
bb60:
  br label %bb64
bb61:
  %t315 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t318 = load ptr, ptr %t317, !tbaa !27
  %t319 = load i64, ptr %l120, !tbaa !24
  %t320 = mul i64 %t319, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t316, ptr %t318, i64 %t320, i1 false)
  br label %bb63
bb62:
  %t321 = load { i64, ptr }, ptr %l118, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 0
  store i64 %t322, ptr %l122, !tbaa !24
  %t323 = load i64, ptr %l122, !tbaa !24
  %t324 = mul i64 %t323, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  %t326 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  store { i64, ptr } %t327, ptr %l123, !tbaa !27
  %t328 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t329 = load ptr, ptr %t328, !tbaa !27
  %t330 = getelementptr { i64, ptr }, ptr %l118, i32 0, i32 1
  %t331 = load ptr, ptr %t330, !tbaa !27
  %t332 = load i64, ptr %l122, !tbaa !24
  %t333 = mul i64 %t332, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t329, ptr %t331, i64 %t333, i1 false)
  %t334 = load { i64, ptr }, ptr %l123, !tbaa !27
  store { i64, ptr } %t334, ptr %l11, !tbaa !27
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t335 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t339 = sub i64 %t337, 3
  store i64 %t339, ptr %l126, !tbaa !24
  %t340 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  store i64 %t341, ptr %l127, !tbaa !24
  %t342 = icmp sge i64 0, 0
  br i1 %t342, label %bb65, label %bb66
bb65:
  %t344 = load i64, ptr %l126, !tbaa !24
  %t345 = icmp sle i64 0, %t344
  br i1 %t345, label %bb67, label %bb68
bb66:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb67:
  %t347 = load i64, ptr %l126, !tbaa !24
  %t348 = load i64, ptr %l127, !tbaa !24
  %t349 = icmp sle i64 %t347, %t348
  br i1 %t349, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb69:
  %t351 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t352 = load ptr, ptr %t351, !tbaa !27
  %t353 = load i64, ptr %l126, !tbaa !24
  %t354 = getelementptr i8, ptr %t352, i64 0
  %t355 = sub i64 %t353, 0
  %t356 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t354, 1
  store { i64, ptr } %t357, ptr %l131, !tbaa !27
  %t358 = call i32 @getpid()
  store i32 %t358, ptr %l132
  br label %bb71
bb70:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb71:
  %t359 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t359, 1
  %t361 = extractvalue { i64, ptr } %t359, 0
  %t362 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t365 = load i32, ptr %l132, !tbaa !23
  %t366 = sext i32 %t365 to i64
  %t367 = call i64 @__olang_fmt_i64(ptr null, i64 %t366)
  %t368 = add i64 %t364, %t367
  %t369 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d169, i32 0, i32 1) }, 1
  %t370 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d169, i32 0, i32 1) }, 0
  %t371 = add i64 %t368, %t370
  %t372 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t371)
  call void @olang_textcopy(ptr %t372, ptr %t360, i64 %t361)
  %t373 = getelementptr i8, ptr %t372, i64 %t361
  call void @olang_textcopy(ptr %t373, ptr %t362, i64 %t363)
  %t374 = getelementptr i8, ptr %t373, i64 %t363
  %t375 = call i64 @__olang_fmt_i64(ptr %t374, i64 %t366)
  %t376 = getelementptr i8, ptr %t374, i64 %t367
  call void @olang_textcopy(ptr %t376, ptr %t369, i64 %t370)
  %t377 = insertvalue { i64, ptr } undef, i64 %t371, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t372, 1
  store { i64, ptr } %t378, ptr %l14, !tbaa !27
  %t380 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t381 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t385 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v3, { i64, ptr } %t380, { i64, ptr } %t381)
  store i32 %t385, ptr %l137
  %t386 = icmp ne i32 %t385, 0
  br i1 %t386, label %bb73, label %ok.387
ok.387:
  br label %bb72
bb72:
  br label %bb77
bb73:
  %t388 = load i32, ptr %l137, !tbaa !23
  %t389 = ashr i32 %t388, 16
  %t391 = icmp eq i32 %t389, 1
  store i1 %t391, ptr %l139, !tbaa !21
  br label %bb74
bb74:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t392 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t392, ptr %l140, !tbaa !27
  %t393 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s11)
  store %"compiler/msgs:Msg" %t393, ptr %l141
  br label %bb75
bb75:
  %t394 = load ptr, ptr %l5, !tbaa !29
  %t395 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t396 = load %"compiler/msgs:Msg", ptr %l141
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s11, ptr %v4, { i64, ptr } %t395, %"compiler/msgs:Msg" %t396, ptr %t394)
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t399 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t399, ptr %rv
  br label %ret
bb77:
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = getelementptr %"compiler/build:Config", ptr %t400, i32 0, i32 1
  %t403 = load { i64, ptr }, ptr %t402, !tbaa !27
  %t405 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t403, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d170, i32 0, i32 1) })
  store i1 %t405, ptr %l146
  br label %bb78
bb78:
  %t406 = load i1, ptr %l146, !tbaa !21
  br i1 %t406, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s12
  %t407 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t411 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t407, { i64, ptr } %t408)
  store i32 %t411, ptr %l149
  %t412 = icmp ne i32 %t411, 0
  br i1 %t412, label %bb82, label %ok.413
ok.413:
  br label %bb81
bb80:
  br label %bb87
bb81:
  br label %bb84
bb82:
  %t414 = load i32, ptr %l149, !tbaa !23
  %t415 = ashr i32 %t414, 16
  %t417 = icmp eq i32 %t415, 1
  store i1 %t417, ptr %l151, !tbaa !21
  br label %bb83
bb83:
  call void @__olang_ert_req_clear()
  br label %bb84
bb84:
  %t418 = load ptr, ptr %l5, !tbaa !29
  store ptr %t418, ptr %l152, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t419
  %t420 = getelementptr { i64, [3 x i64] }, ptr %t419, i32 0, i32 0
  store i64 0, ptr %t420
  %t421 = load { i64, [3 x i64] }, ptr %t419
  store { i64, [3 x i64] } %t421, ptr %l153
  %t422 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t424 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %s0, ptr %s12, { i64, ptr } %t422)
  store %"compiler/msgs:Msg" %t424, ptr %l155
  br label %bb85
bb85:
  %t425 = load ptr, ptr %l152, !tbaa !29
  %t426 = load { i64, [3 x i64] }, ptr %l153
  %t427 = load %"compiler/msgs:Msg", ptr %l155
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s12, ptr %t425, { i64, [3 x i64] } %t426, %"compiler/msgs:Msg" %t427)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t429 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t429, ptr %rv
  br label %ret
bb87:
  %t430 = load ptr, ptr %lp9
  %t431 = load { i64, ptr }, ptr %t430, !tbaa !27
  store { i64, ptr } %t431, ptr %l157, !tbaa !27
  %t432 = call i32 @getpid()
  store i32 %t432, ptr %l158
  br label %bb88
bb88:
  %t433 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 1
  %t435 = extractvalue { i64, ptr } %t433, 0
  %t436 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t437 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t438 = add i64 %t435, %t437
  %t439 = load i32, ptr %l158, !tbaa !23
  %t440 = sext i32 %t439 to i64
  %t441 = call i64 @__olang_fmt_i64(ptr null, i64 %t440)
  %t442 = add i64 %t438, %t441
  %t443 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t444 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t445 = add i64 %t442, %t444
  %t446 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t445)
  call void @olang_textcopy(ptr %t446, ptr %t434, i64 %t435)
  %t447 = getelementptr i8, ptr %t446, i64 %t435
  call void @olang_textcopy(ptr %t447, ptr %t436, i64 %t437)
  %t448 = getelementptr i8, ptr %t447, i64 %t437
  %t449 = call i64 @__olang_fmt_i64(ptr %t448, i64 %t440)
  %t450 = getelementptr i8, ptr %t448, i64 %t441
  call void @olang_textcopy(ptr %t450, ptr %t443, i64 %t444)
  %t451 = insertvalue { i64, ptr } undef, i64 %t445, 0
  %t452 = insertvalue { i64, ptr } %t451, ptr %t446, 1
  store { i64, ptr } %t452, ptr %l15, !tbaa !27
  %t454 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t454, ptr %l160
  br label %bb89
bb89:
  %t455 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l160
  %t456 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t455, ptr %t456
  store ptr %t456, ptr %l16, !tbaa !29
  %t458 = load ptr, ptr %l16, !tbaa !29
  %t459 = load ptr, ptr %l0, !tbaa !29
  %t461 = getelementptr %"compiler/build:Config", ptr %t459, i32 0, i32 1
  %t462 = load { i64, ptr }, ptr %t461, !tbaa !27
  %t464 = extractvalue { i64, ptr } %t462, 1
  %t465 = extractvalue { i64, ptr } %t462, 0
  %t466 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t465)
  call void @olang_textcopy(ptr %t466, ptr %t464, i64 %t465)
  %t467 = insertvalue { i64, ptr } undef, i64 %t465, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t466, 1
  %t470 = extractvalue { i64, ptr } %t468, 0
  %t471 = extractvalue { i64, ptr } %t468, 1
  %t472 = mul i64 %t470, 1
  %t473 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t472)
  call void @llvm.memcpy.p0.p0.i64(ptr %t473, ptr %t471, i64 %t472, i1 false)
  %t474 = insertvalue { i64, ptr } undef, i64 %t470, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t473, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t458, { i64, ptr } %t475)
  br label %bb90
bb90:
  store ptr %l8, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb91
bb91:
  %t479 = load i64, ptr %l18, !tbaa !24
  store i64 %t479, ptr %l168, !tbaa !24
  %t480 = load ptr, ptr %l17, !tbaa !29
  %t482 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t480)
  store i64 %t482, ptr %l170
  br label %bb92
bb92:
  %t483 = load i64, ptr %l168, !tbaa !24
  %t484 = load i64, ptr %l170, !tbaa !24
  %t485 = icmp slt i64 %t483, %t484
  %t487 = xor i1 %t485, true
  br i1 %t487, label %bb93, label %bb94
bb93:
  br label %bb99
bb94:
  br label %bb95
bb95:
  %t489 = load ptr, ptr %l17, !tbaa !29
  %t490 = load i64, ptr %l18, !tbaa !24
  %t493 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t489, i64 %t490)
  store { i64, ptr } %t493, ptr %l175
  br label %bb96
bb96:
  %t494 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t495 = load ptr, ptr %l16, !tbaa !29
  %t498 = extractvalue { i64, ptr } %t494, 1
  %t499 = extractvalue { i64, ptr } %t494, 0
  %t500 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t499)
  call void @olang_textcopy(ptr %t500, ptr %t498, i64 %t499)
  %t501 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t500, 1
  %t504 = extractvalue { i64, ptr } %t502, 0
  %t505 = extractvalue { i64, ptr } %t502, 1
  %t506 = mul i64 %t504, 1
  %t507 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t506)
  call void @llvm.memcpy.p0.p0.i64(ptr %t507, ptr %t505, i64 %t506, i1 false)
  %t508 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t509 = insertvalue { i64, ptr } %t508, ptr %t507, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t495, { i64, ptr } %t509)
  br label %bb97
bb97:
  br label %bb98
bb98:
  %t512 = load i64, ptr %l18, !tbaa !24
  %t514 = add i64 %t512, 1
  store i64 %t514, ptr %l18, !tbaa !24
  br label %bb91
bb99:
  %t516 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t516, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d173, i32 0, i32 1) })
  br label %bb100
bb100:
  %t518 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t518, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d174, i32 0, i32 1) })
  br label %bb101
bb101:
  %t520 = load ptr, ptr %l16, !tbaa !29
  %t521 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t523 = extractvalue { i64, ptr } %t521, 1
  %t524 = extractvalue { i64, ptr } %t521, 0
  %t525 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t524)
  call void @olang_textcopy(ptr %t525, ptr %t523, i64 %t524)
  %t526 = insertvalue { i64, ptr } undef, i64 %t524, 0
  %t527 = insertvalue { i64, ptr } %t526, ptr %t525, 1
  %t529 = extractvalue { i64, ptr } %t527, 0
  %t530 = extractvalue { i64, ptr } %t527, 1
  %t531 = mul i64 %t529, 1
  %t532 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t531)
  call void @llvm.memcpy.p0.p0.i64(ptr %t532, ptr %t530, i64 %t531, i1 false)
  %t533 = insertvalue { i64, ptr } undef, i64 %t529, 0
  %t534 = insertvalue { i64, ptr } %t533, ptr %t532, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t520, { i64, ptr } %t534)
  br label %bb102
bb102:
  %t537 = load ptr, ptr %l16, !tbaa !29
  %t538 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t540 = extractvalue { i64, ptr } %t538, 1
  %t541 = extractvalue { i64, ptr } %t538, 0
  %t542 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t541)
  call void @olang_textcopy(ptr %t542, ptr %t540, i64 %t541)
  %t543 = insertvalue { i64, ptr } undef, i64 %t541, 0
  %t544 = insertvalue { i64, ptr } %t543, ptr %t542, 1
  %t546 = extractvalue { i64, ptr } %t544, 0
  %t547 = extractvalue { i64, ptr } %t544, 1
  %t548 = mul i64 %t546, 1
  %t549 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t548)
  call void @llvm.memcpy.p0.p0.i64(ptr %t549, ptr %t547, i64 %t548, i1 false)
  %t550 = insertvalue { i64, ptr } undef, i64 %t546, 0
  %t551 = insertvalue { i64, ptr } %t550, ptr %t549, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t537, { i64, ptr } %t551)
  br label %bb103
bb103:
  %t554 = load ptr, ptr %l1, !tbaa !29
  %t556 = getelementptr %"compiler/build:compiles", ptr %t554, i32 0, i32 0
  store ptr %t556, ptr %l193, !tbaa !29
  %t557 = load ptr, ptr %l16, !tbaa !29
  %t559 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t557)
  store { i64, ptr } %t559, ptr %l195
  br label %bb104
bb104:
  %t560 = load ptr, ptr %l193, !tbaa !29
  %t561 = load { i64, ptr }, ptr %l195, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v1, ptr %v1, ptr %t560, { i64, ptr } %t561)
  br label %bb105
bb105:
  %t562 = load ptr, ptr %l1, !tbaa !29
  %t564 = getelementptr %"compiler/build:compiles", ptr %t562, i32 0, i32 1
  %t565 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t565, 1
  %t568 = extractvalue { i64, ptr } %t565, 0
  %t569 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t568)
  call void @olang_textcopy(ptr %t569, ptr %t567, i64 %t568)
  %t570 = insertvalue { i64, ptr } undef, i64 %t568, 0
  %t571 = insertvalue { i64, ptr } %t570, ptr %t569, 1
  %t573 = extractvalue { i64, ptr } %t571, 0
  %t574 = extractvalue { i64, ptr } %t571, 1
  %t575 = mul i64 %t573, 1
  %t576 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t575)
  call void @llvm.memcpy.p0.p0.i64(ptr %t576, ptr %t574, i64 %t575, i1 false)
  %t577 = insertvalue { i64, ptr } undef, i64 %t573, 0
  %t578 = insertvalue { i64, ptr } %t577, ptr %t576, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t564, { i64, ptr } %t578)
  br label %bb106
bb106:
  %t581 = load ptr, ptr %l1, !tbaa !29
  %t583 = getelementptr %"compiler/build:compiles", ptr %t581, i32 0, i32 2
  %t584 = load ptr, ptr %lp9
  %t585 = load { i64, ptr }, ptr %t584, !tbaa !27
  %t587 = extractvalue { i64, ptr } %t585, 1
  %t588 = extractvalue { i64, ptr } %t585, 0
  %t589 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t588)
  call void @olang_textcopy(ptr %t589, ptr %t587, i64 %t588)
  %t590 = insertvalue { i64, ptr } undef, i64 %t588, 0
  %t591 = insertvalue { i64, ptr } %t590, ptr %t589, 1
  %t593 = extractvalue { i64, ptr } %t591, 0
  %t594 = extractvalue { i64, ptr } %t591, 1
  %t595 = mul i64 %t593, 1
  %t596 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t595)
  call void @llvm.memcpy.p0.p0.i64(ptr %t596, ptr %t594, i64 %t595, i1 false)
  %t597 = insertvalue { i64, ptr } undef, i64 %t593, 0
  %t598 = insertvalue { i64, ptr } %t597, ptr %t596, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t583, { i64, ptr } %t598)
  br label %bb107
bb107:
  %t601 = load ptr, ptr %l1, !tbaa !29
  %t603 = getelementptr %"compiler/build:compiles", ptr %t601, i32 0, i32 3
  %t604 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t606 = extractvalue { i64, ptr } %t604, 1
  %t607 = extractvalue { i64, ptr } %t604, 0
  %t608 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t607)
  call void @olang_textcopy(ptr %t608, ptr %t606, i64 %t607)
  %t609 = insertvalue { i64, ptr } undef, i64 %t607, 0
  %t610 = insertvalue { i64, ptr } %t609, ptr %t608, 1
  %t612 = extractvalue { i64, ptr } %t610, 0
  %t613 = extractvalue { i64, ptr } %t610, 1
  %t614 = mul i64 %t612, 1
  %t615 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t614)
  call void @llvm.memcpy.p0.p0.i64(ptr %t615, ptr %t613, i64 %t614, i1 false)
  %t616 = insertvalue { i64, ptr } undef, i64 %t612, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t603, { i64, ptr } %t617)
  br label %bb108
bb108:
  %t620 = load ptr, ptr %l1, !tbaa !29
  %t622 = getelementptr %"compiler/build:compiles", ptr %t620, i32 0, i32 4
  %t623 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t625 = extractvalue { i64, ptr } %t623, 1
  %t626 = extractvalue { i64, ptr } %t623, 0
  %t627 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t626)
  call void @olang_textcopy(ptr %t627, ptr %t625, i64 %t626)
  %t628 = insertvalue { i64, ptr } undef, i64 %t626, 0
  %t629 = insertvalue { i64, ptr } %t628, ptr %t627, 1
  %t631 = extractvalue { i64, ptr } %t629, 0
  %t632 = extractvalue { i64, ptr } %t629, 1
  %t633 = mul i64 %t631, 1
  %t634 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t633)
  call void @llvm.memcpy.p0.p0.i64(ptr %t634, ptr %t632, i64 %t633, i1 false)
  %t635 = insertvalue { i64, ptr } undef, i64 %t631, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t634, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t622, { i64, ptr } %t636)
  br label %bb109
bb109:
  %t639 = load ptr, ptr %l1, !tbaa !29
  %t641 = getelementptr %"compiler/build:compiles", ptr %t639, i32 0, i32 5
  %t642 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t644 = extractvalue { i64, ptr } %t642, 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t641, i64 %t644)
  br label %bb110
bb110:
  %t647 = load ptr, ptr %lp9
  %t648 = load { i64, ptr }, ptr %t647, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t650 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t648, 1
  store { i32, { i64, ptr } } %t650, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 14
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 14
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call i64 @sysconf(i32 84)
  store i64 %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  store i64 1, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l10, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/build:Unit"
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/build:Unit"
  %l16 = alloca i1
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"compiler/build:Unit"
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/build:Unit" %t19, ptr %l13
  br label %bb6
bb6:
  %t20 = load %"compiler/build:Unit", ptr %l13
  store %"compiler/build:Unit" %t20, ptr %l3
  %t21 = getelementptr %"compiler/build:Unit", ptr %l3, i32 0, i32 1
  %t22 = load i32, ptr %t21
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t27 = getelementptr %"compiler/build:Unit", ptr %l3, i32 0, i32 1
  %t28 = load i32, ptr %t27
  %t30 = trunc i64 2 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = getelementptr %"compiler/build:Unit", ptr %l3, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t37, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb1
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/build:Program", ptr %t47, i32 0, i32 0
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l25
  br label %bb15
bb15:
  %t52 = load i64, ptr %l25, !tbaa !24
  %t53 = icmp sgt i64 %t52, 0
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/build:Program", ptr %t55, i32 0, i32 0
  %t59 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t57, i64 0)
  store %"compiler/build:Unit" %t59, ptr %l30
  br label %bb18
bb17:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d175, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t60, ptr %l27, !tbaa !27
  br label %bb19
bb18:
  %t62 = getelementptr %"compiler/build:Unit", ptr %l30, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l27, !tbaa !27
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l35, !tbaa !24
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l35, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t84, ptr %l27, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [8 x i8]
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l53 = alloca i64
  %l61 = alloca %"std/prelude/text:StringBuilder"
  %l73 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Sha256", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = mul i64 %t4, 8
  store i64 %t7, ptr %l1, !tbaa !65
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d176, i32 0, i32 1) })
  br label %bb1
bb1:
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Sha256", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = icmp ne i64 %t14, 56
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s1, ptr %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb2
bb8:
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l30, !tbaa !24
  store i64 %t48, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t49 = load i64, ptr %l27, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l1, !tbaa !65
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = mul i64 8, %t70
  %t74 = sub i64 56, %t72
  store i64 %t74, ptr %l53, !tbaa !65
  %t77 = load i64, ptr %l53, !tbaa !65
  %t78 = load i64, ptr %l53, !tbaa !65
  %t79 = lshr i64 %t69, %t78
  %t81 = trunc i64 %t79 to i8
  %t84 = getelementptr [8 x i8], ptr %l2, i64 0, i64 %t68
  store i8 %t81, ptr %t84, !tbaa !32
  br label %bb19
bb19:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb15
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = insertvalue { i64, ptr } undef, i64 8, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %l2, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t89, { i64, ptr } %t92)
  br label %bb21
bb21:
  %t95 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t95, ptr %l61
  br label %bb22
bb22:
  %t96 = load %"std/prelude/text:StringBuilder", ptr %l61
  store %"std/prelude/text:StringBuilder" %t96, ptr %l9
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/build:Sha256", ptr %t97, i32 0, i32 0
  store ptr %t99, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t101 = load ptr, ptr %l10
  store i64 8, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l12, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t112 = load ptr, ptr %l10
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = getelementptr [8 x i32], ptr %t112, i64 0, i64 %t113
  %t117 = load i32, ptr %t116, !tbaa !84
  store ptr %l9, ptr %l73, !tbaa !29
  store i32 %t117, ptr %l74, !tbaa !64
  %t120 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 16)
  %t121 = extractvalue { i32, i64 } %t120, 1
  %t122 = extractvalue { i32, i64 } %t120, 0
  store i32 %t122, ptr %l76
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb28, label %ok.124
ok.124:
  store i64 %t121, ptr %l75
  br label %bb27
bb27:
  %t125 = load i32, ptr %l74, !tbaa !64
  %t126 = load i64, ptr %l75, !tbaa !24
  %t127 = call { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %s6, i32 %t125, i64 %t126)
  store { i64, ptr } %t127, ptr %l77
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58)
  unreachable
bb29:
  %t128 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t134, i64 8, i8 48)
  store { i64, ptr } %t136, ptr %l79
  br label %bb30
bb30:
  %t137 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t144, { i64, ptr } %t143)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb23
bb33:
  %t151 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l9)
  store { i64, ptr } %t151, ptr %l84
  br label %bb34
bb34:
  %t152 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t152, ptr %l85, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l86, !tbaa !24
  %t155 = load i64, ptr %l86, !tbaa !24
  %t156 = mul i64 %t155, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l87, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l86, !tbaa !24
  %t165 = mul i64 %t164, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %t163, i64 %t165, i1 false)
  %t166 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t166, ptr %l85, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t167 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t167, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = getelementptr %"compiler/build:Sha256", ptr %t6, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = add i64 %t8, %t9
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = getelementptr %"compiler/build:Sha256", ptr %t14, i32 0, i32 3
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Sha256", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb16
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/build:Sha256", ptr %t23, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp slt i64 %t26, 64
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l16, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/build:Sha256", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t53 = getelementptr %"compiler/build:Sha256", ptr %t39, i32 0, i32 1
  %t55 = getelementptr [64 x i8], ptr %t53, i64 0, i64 %t43
  store i8 %t50, ptr %t55, !tbaa !32
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l27, !tbaa !29
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = getelementptr %"compiler/build:Sha256", ptr %t57, i32 0, i32 2
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = add i64 %t59, 1
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t64 = getelementptr %"compiler/build:Sha256", ptr %t63, i32 0, i32 2
  store i64 %t61, ptr %t64, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Sha256", ptr %t69, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp slt i64 %t72, 64
  br i1 %t74, label %bb12, label %bb13
bb12:
  br label %ret
bb13:
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Sha256", ptr %t77, i32 0, i32 1
  %t81 = insertvalue { i64, ptr } undef, i64 64, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v0, ptr %t76, { i64, ptr } %t82, i64 0)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Sha256", ptr %t85, i32 0, i32 2
  store i64 0, ptr %t87, !tbaa !24
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t90 = add i64 %t88, 64
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sle i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %t98, { i64, ptr } %t99, i64 %t100)
  br label %bb21
bb21:
  %t104 = load i64, ptr %l2, !tbaa !24
  %t106 = add i64 %t104, 64
  store i64 %t106, ptr %l2, !tbaa !24
  br label %bb22
bb22:
  br label %bb17
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l2, !tbaa !24
  %t109 = load i64, ptr %l3, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/build:Sha256", ptr %t117, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t121, ptr %l57, !tbaa !27
  %t122 = load i64, ptr %l2, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t122
  %t127 = load i8, ptr %t126, !tbaa !32
  %t130 = getelementptr %"compiler/build:Sha256", ptr %t116, i32 0, i32 1
  %t132 = getelementptr [64 x i8], ptr %t130, i64 0, i64 %t120
  store i8 %t127, ptr %t132, !tbaa !32
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l60, !tbaa !29
  %t134 = load ptr, ptr %l60, !tbaa !29
  %t135 = getelementptr %"compiler/build:Sha256", ptr %t134, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t138 = add i64 %t136, 1
  %t140 = load ptr, ptr %l60, !tbaa !29
  %t141 = getelementptr %"compiler/build:Sha256", ptr %t140, i32 0, i32 2
  store i64 %t138, ptr %t141, !tbaa !24
  %t142 = load i64, ptr %l2, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l2, !tbaa !24
  br label %bb28
bb28:
  br label %bb24
bb29:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i32
  %l38 = alloca [64 x i32]
  %l42 = alloca i64
  %l45 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l98 = alloca i64
  %l101 = alloca i64
  %l122 = alloca i32
  %l126 = alloca i32
  %l136 = alloca i32
  %l140 = alloca i32
  %l180 = alloca i64
  %l183 = alloca i64
  %l202 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i32
  %l207 = alloca i32
  %l229 = alloca i32
  %l231 = alloca i32
  %l232 = alloca i32
  %l234 = alloca i32
  %l263 = alloca ptr
  %l267 = alloca ptr
  %l271 = alloca ptr
  %l275 = alloca ptr
  %l279 = alloca ptr
  %l283 = alloca ptr
  %l287 = alloca ptr
  %l291 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 64
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [64 x i32], ptr %l38, i64 0, i64 %t5
  store i32 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l38, i64 256, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l45, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l45, !tbaa !24
  store i64 %t35, ptr %l42, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l42, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = mul i64 %t56, 4
  %t61 = add i64 %a2, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %l68, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = zext i8 %t70 to i32
  %t74 = shl i32 %t72, 24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l73, !tbaa !27
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = add i64 %t76, 1
  %t80 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 %t78
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = zext i8 %t83 to i32
  %t87 = shl i32 %t85, 16
  %t90 = or i32 %t74, %t87
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l80, !tbaa !27
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = add i64 %t92, 2
  %t96 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = zext i8 %t99 to i32
  %t103 = shl i32 %t101, 8
  %t106 = or i32 %t90, %t103
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l87, !tbaa !27
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = add i64 %t108, 3
  %t112 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = zext i8 %t115 to i32
  %t120 = or i32 %t106, %t117
  %t123 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t63
  store i32 %t120, ptr %t123, !tbaa !84
  br label %bb11
bb11:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  store i64 16, ptr %l11, !tbaa !24
  store i64 64, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb13, label %bb14
bb13:
  %t134 = load i64, ptr %l13, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb18
bb15:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l13, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb17
bb17:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb18
bb18:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  %t156 = load i64, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb20, label %bb21
bb20:
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t164 = load i64, ptr %l11, !tbaa !24
  %t165 = load i64, ptr %l15, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l16, !tbaa !24
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = sub i64 %t174, 15
  %t178 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t176
  %t179 = load i32, ptr %t178, !tbaa !84
  %t181 = call i32 @compiler_2fbuild_2erotr(i32 %t179, i32 7)
  store i32 %t181, ptr %l122
  br label %bb23
bb23:
  %t182 = load i64, ptr %l16, !tbaa !24
  %t184 = sub i64 %t182, 15
  %t186 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t184
  %t187 = load i32, ptr %t186, !tbaa !84
  %t189 = call i32 @compiler_2fbuild_2erotr(i32 %t187, i32 18)
  store i32 %t189, ptr %l126
  br label %bb24
bb24:
  %t190 = load i32, ptr %l122, !tbaa !64
  %t191 = load i32, ptr %l126, !tbaa !64
  %t192 = xor i32 %t190, %t191
  %t193 = load i64, ptr %l16, !tbaa !24
  %t195 = sub i64 %t193, 15
  %t197 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t195
  %t198 = load i32, ptr %t197, !tbaa !84
  %t200 = lshr i32 %t198, 3
  %t203 = xor i32 %t192, %t200
  store i32 %t203, ptr %l17, !tbaa !64
  %t205 = load i64, ptr %l16, !tbaa !24
  %t207 = sub i64 %t205, 2
  %t209 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t207
  %t210 = load i32, ptr %t209, !tbaa !84
  %t212 = call i32 @compiler_2fbuild_2erotr(i32 %t210, i32 17)
  store i32 %t212, ptr %l136
  br label %bb25
bb25:
  %t213 = load i64, ptr %l16, !tbaa !24
  %t215 = sub i64 %t213, 2
  %t217 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t215
  %t218 = load i32, ptr %t217, !tbaa !84
  %t220 = call i32 @compiler_2fbuild_2erotr(i32 %t218, i32 19)
  store i32 %t220, ptr %l140
  br label %bb26
bb26:
  %t221 = load i32, ptr %l136, !tbaa !64
  %t222 = load i32, ptr %l140, !tbaa !64
  %t223 = xor i32 %t221, %t222
  %t224 = load i64, ptr %l16, !tbaa !24
  %t226 = sub i64 %t224, 2
  %t228 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t226
  %t229 = load i32, ptr %t228, !tbaa !84
  %t231 = lshr i32 %t229, 10
  %t234 = xor i32 %t223, %t231
  %t236 = load i64, ptr %l16, !tbaa !24
  %t237 = load i64, ptr %l16, !tbaa !24
  %t239 = sub i64 %t237, 16
  %t241 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t239
  %t242 = load i32, ptr %t241, !tbaa !84
  %t243 = load i32, ptr %l17, !tbaa !64
  %t246 = add i32 %t242, %t243
  %t247 = load i64, ptr %l16, !tbaa !24
  %t249 = sub i64 %t247, 7
  %t251 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t249
  %t252 = load i32, ptr %t251, !tbaa !84
  %t255 = add i32 %t246, %t252
  %t259 = add i32 %t255, %t234
  %t262 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t236
  store i32 %t259, ptr %t262, !tbaa !84
  br label %bb27
bb27:
  %t263 = load i64, ptr %l15, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l15, !tbaa !24
  br label %bb19
bb28:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/build:Sha256", ptr %t267, i32 0, i32 0
  %t270 = getelementptr [8 x i32], ptr %t269, i64 0, i64 0
  %t271 = load i32, ptr %t270, !tbaa !84
  store i32 %t271, ptr %l19, !tbaa !64
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/build:Sha256", ptr %t273, i32 0, i32 0
  %t276 = getelementptr [8 x i32], ptr %t275, i64 0, i64 1
  %t277 = load i32, ptr %t276, !tbaa !84
  store i32 %t277, ptr %l20, !tbaa !64
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/build:Sha256", ptr %t279, i32 0, i32 0
  %t282 = getelementptr [8 x i32], ptr %t281, i64 0, i64 2
  %t283 = load i32, ptr %t282, !tbaa !84
  store i32 %t283, ptr %l21, !tbaa !64
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/build:Sha256", ptr %t285, i32 0, i32 0
  %t288 = getelementptr [8 x i32], ptr %t287, i64 0, i64 3
  %t289 = load i32, ptr %t288, !tbaa !84
  store i32 %t289, ptr %l22, !tbaa !64
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/build:Sha256", ptr %t291, i32 0, i32 0
  %t294 = getelementptr [8 x i32], ptr %t293, i64 0, i64 4
  %t295 = load i32, ptr %t294, !tbaa !84
  store i32 %t295, ptr %l23, !tbaa !64
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/build:Sha256", ptr %t297, i32 0, i32 0
  %t300 = getelementptr [8 x i32], ptr %t299, i64 0, i64 5
  %t301 = load i32, ptr %t300, !tbaa !84
  store i32 %t301, ptr %l24, !tbaa !64
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/build:Sha256", ptr %t303, i32 0, i32 0
  %t306 = getelementptr [8 x i32], ptr %t305, i64 0, i64 6
  %t307 = load i32, ptr %t306, !tbaa !84
  store i32 %t307, ptr %l25, !tbaa !64
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/build:Sha256", ptr %t309, i32 0, i32 0
  %t312 = getelementptr [8 x i32], ptr %t311, i64 0, i64 7
  %t313 = load i32, ptr %t312, !tbaa !84
  store i32 %t313, ptr %l26, !tbaa !64
  store i64 0, ptr %l27, !tbaa !24
  store i64 64, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t315 = load i64, ptr %l28, !tbaa !24
  %t316 = load i64, ptr %l27, !tbaa !24
  %t319 = icmp sgt i64 %t315, %t316
  br i1 %t319, label %bb29, label %bb30
bb29:
  %t321 = load i64, ptr %l29, !tbaa !24
  %t323 = icmp sgt i64 %t321, 0
  br i1 %t323, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb34
bb31:
  %t325 = load i64, ptr %l28, !tbaa !24
  %t326 = load i64, ptr %l27, !tbaa !24
  %t329 = sub i64 %t325, %t326
  %t330 = load i64, ptr %l29, !tbaa !24
  %t333 = add i64 %t329, %t330
  %t335 = sub i64 %t333, 1
  %t336 = load i64, ptr %l29, !tbaa !24
  %t339 = sdiv i64 %t335, %t336
  store i64 %t339, ptr %l183, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb33
bb33:
  %t341 = load i64, ptr %l183, !tbaa !24
  store i64 %t341, ptr %l180, !tbaa !24
  br label %bb34
bb34:
  %t342 = load i64, ptr %l180, !tbaa !24
  store i64 %t342, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb35
bb35:
  %t343 = load i64, ptr %l31, !tbaa !24
  %t344 = load i64, ptr %l30, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb36, label %bb37
bb36:
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t351 = load i64, ptr %l27, !tbaa !24
  %t352 = load i64, ptr %l31, !tbaa !24
  %t353 = load i64, ptr %l29, !tbaa !24
  %t356 = mul i64 %t352, %t353
  %t359 = add i64 %t351, %t356
  store i64 %t359, ptr %l32, !tbaa !24
  %t361 = load i32, ptr %l23, !tbaa !64
  %t363 = call i32 @compiler_2fbuild_2erotr(i32 %t361, i32 6)
  store i32 %t363, ptr %l202
  br label %bb39
bb39:
  %t364 = load i32, ptr %l23, !tbaa !64
  %t366 = call i32 @compiler_2fbuild_2erotr(i32 %t364, i32 11)
  store i32 %t366, ptr %l204
  br label %bb40
bb40:
  %t367 = load i32, ptr %l202, !tbaa !64
  %t368 = load i32, ptr %l204, !tbaa !64
  %t369 = xor i32 %t367, %t368
  store i32 %t369, ptr %l205, !tbaa !64
  %t370 = load i32, ptr %l23, !tbaa !64
  %t372 = call i32 @compiler_2fbuild_2erotr(i32 %t370, i32 25)
  store i32 %t372, ptr %l207
  br label %bb41
bb41:
  %t373 = load i32, ptr %l205, !tbaa !64
  %t374 = load i32, ptr %l207, !tbaa !64
  %t375 = xor i32 %t373, %t374
  %t377 = load i32, ptr %l23, !tbaa !64
  %t378 = load i32, ptr %l24, !tbaa !64
  %t381 = and i32 %t377, %t378
  %t382 = load i32, ptr %l23, !tbaa !64
  %t384 = xor i32 %t382, -1
  %t385 = load i32, ptr %l25, !tbaa !64
  %t388 = and i32 %t384, %t385
  %t391 = xor i32 %t381, %t388
  %t393 = load i32, ptr %l26, !tbaa !64
  %t397 = add i32 %t393, %t375
  %t401 = add i32 %t397, %t391
  %t402 = load i64, ptr %l32, !tbaa !24
  %t404 = getelementptr [64 x i32], ptr @G_2ecompiler_2fbuild_2eShaK, i64 0, i64 %t402
  %t405 = load i32, ptr %t404, !tbaa !84
  %t408 = add i32 %t401, %t405
  %t409 = load i64, ptr %l32, !tbaa !24
  %t411 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t409
  %t412 = load i32, ptr %t411, !tbaa !84
  %t415 = add i32 %t408, %t412
  store i32 %t415, ptr %l35, !tbaa !64
  %t417 = load i32, ptr %l19, !tbaa !64
  %t419 = call i32 @compiler_2fbuild_2erotr(i32 %t417, i32 2)
  store i32 %t419, ptr %l229
  br label %bb42
bb42:
  %t420 = load i32, ptr %l19, !tbaa !64
  %t422 = call i32 @compiler_2fbuild_2erotr(i32 %t420, i32 13)
  store i32 %t422, ptr %l231
  br label %bb43
bb43:
  %t423 = load i32, ptr %l229, !tbaa !64
  %t424 = load i32, ptr %l231, !tbaa !64
  %t425 = xor i32 %t423, %t424
  store i32 %t425, ptr %l232, !tbaa !64
  %t426 = load i32, ptr %l19, !tbaa !64
  %t428 = call i32 @compiler_2fbuild_2erotr(i32 %t426, i32 22)
  store i32 %t428, ptr %l234
  br label %bb44
bb44:
  %t429 = load i32, ptr %l232, !tbaa !64
  %t430 = load i32, ptr %l234, !tbaa !64
  %t431 = xor i32 %t429, %t430
  %t433 = load i32, ptr %l19, !tbaa !64
  %t434 = load i32, ptr %l20, !tbaa !64
  %t437 = and i32 %t433, %t434
  %t438 = load i32, ptr %l19, !tbaa !64
  %t439 = load i32, ptr %l21, !tbaa !64
  %t442 = and i32 %t438, %t439
  %t445 = xor i32 %t437, %t442
  %t446 = load i32, ptr %l20, !tbaa !64
  %t447 = load i32, ptr %l21, !tbaa !64
  %t450 = and i32 %t446, %t447
  %t453 = xor i32 %t445, %t450
  %t455 = load i32, ptr %l25, !tbaa !64
  store i32 %t455, ptr %l26, !tbaa !64
  %t457 = load i32, ptr %l24, !tbaa !64
  store i32 %t457, ptr %l25, !tbaa !64
  %t459 = load i32, ptr %l23, !tbaa !64
  store i32 %t459, ptr %l24, !tbaa !64
  %t461 = load i32, ptr %l22, !tbaa !64
  %t462 = load i32, ptr %l35, !tbaa !64
  %t465 = add i32 %t461, %t462
  store i32 %t465, ptr %l23, !tbaa !64
  %t467 = load i32, ptr %l21, !tbaa !64
  store i32 %t467, ptr %l22, !tbaa !64
  %t469 = load i32, ptr %l20, !tbaa !64
  store i32 %t469, ptr %l21, !tbaa !64
  %t471 = load i32, ptr %l19, !tbaa !64
  store i32 %t471, ptr %l20, !tbaa !64
  %t473 = load i32, ptr %l35, !tbaa !64
  %t477 = add i32 %t473, %t431
  %t481 = add i32 %t477, %t453
  store i32 %t481, ptr %l19, !tbaa !64
  br label %bb45
bb45:
  %t483 = load i64, ptr %l31, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l31, !tbaa !24
  br label %bb35
bb46:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l263, !tbaa !29
  %t488 = load ptr, ptr %l263, !tbaa !29
  %t489 = getelementptr %"compiler/build:Sha256", ptr %t488, i32 0, i32 0
  %t490 = getelementptr [8 x i32], ptr %t489, i64 0, i64 0
  %t491 = load i32, ptr %t490, !tbaa !84
  %t492 = load i32, ptr %l19, !tbaa !64
  %t495 = add i32 %t491, %t492
  %t497 = load ptr, ptr %l263, !tbaa !29
  %t498 = getelementptr %"compiler/build:Sha256", ptr %t497, i32 0, i32 0
  %t499 = getelementptr [8 x i32], ptr %t498, i64 0, i64 0
  store i32 %t495, ptr %t499, !tbaa !84
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l267, !tbaa !29
  %t501 = load ptr, ptr %l267, !tbaa !29
  %t502 = getelementptr %"compiler/build:Sha256", ptr %t501, i32 0, i32 0
  %t503 = getelementptr [8 x i32], ptr %t502, i64 0, i64 1
  %t504 = load i32, ptr %t503, !tbaa !84
  %t505 = load i32, ptr %l20, !tbaa !64
  %t508 = add i32 %t504, %t505
  %t510 = load ptr, ptr %l267, !tbaa !29
  %t511 = getelementptr %"compiler/build:Sha256", ptr %t510, i32 0, i32 0
  %t512 = getelementptr [8 x i32], ptr %t511, i64 0, i64 1
  store i32 %t508, ptr %t512, !tbaa !84
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l271, !tbaa !29
  %t514 = load ptr, ptr %l271, !tbaa !29
  %t515 = getelementptr %"compiler/build:Sha256", ptr %t514, i32 0, i32 0
  %t516 = getelementptr [8 x i32], ptr %t515, i64 0, i64 2
  %t517 = load i32, ptr %t516, !tbaa !84
  %t518 = load i32, ptr %l21, !tbaa !64
  %t521 = add i32 %t517, %t518
  %t523 = load ptr, ptr %l271, !tbaa !29
  %t524 = getelementptr %"compiler/build:Sha256", ptr %t523, i32 0, i32 0
  %t525 = getelementptr [8 x i32], ptr %t524, i64 0, i64 2
  store i32 %t521, ptr %t525, !tbaa !84
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l275, !tbaa !29
  %t527 = load ptr, ptr %l275, !tbaa !29
  %t528 = getelementptr %"compiler/build:Sha256", ptr %t527, i32 0, i32 0
  %t529 = getelementptr [8 x i32], ptr %t528, i64 0, i64 3
  %t530 = load i32, ptr %t529, !tbaa !84
  %t531 = load i32, ptr %l22, !tbaa !64
  %t534 = add i32 %t530, %t531
  %t536 = load ptr, ptr %l275, !tbaa !29
  %t537 = getelementptr %"compiler/build:Sha256", ptr %t536, i32 0, i32 0
  %t538 = getelementptr [8 x i32], ptr %t537, i64 0, i64 3
  store i32 %t534, ptr %t538, !tbaa !84
  %t539 = load ptr, ptr %l0, !tbaa !29
  store ptr %t539, ptr %l279, !tbaa !29
  %t540 = load ptr, ptr %l279, !tbaa !29
  %t541 = getelementptr %"compiler/build:Sha256", ptr %t540, i32 0, i32 0
  %t542 = getelementptr [8 x i32], ptr %t541, i64 0, i64 4
  %t543 = load i32, ptr %t542, !tbaa !84
  %t544 = load i32, ptr %l23, !tbaa !64
  %t547 = add i32 %t543, %t544
  %t549 = load ptr, ptr %l279, !tbaa !29
  %t550 = getelementptr %"compiler/build:Sha256", ptr %t549, i32 0, i32 0
  %t551 = getelementptr [8 x i32], ptr %t550, i64 0, i64 4
  store i32 %t547, ptr %t551, !tbaa !84
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l283, !tbaa !29
  %t553 = load ptr, ptr %l283, !tbaa !29
  %t554 = getelementptr %"compiler/build:Sha256", ptr %t553, i32 0, i32 0
  %t555 = getelementptr [8 x i32], ptr %t554, i64 0, i64 5
  %t556 = load i32, ptr %t555, !tbaa !84
  %t557 = load i32, ptr %l24, !tbaa !64
  %t560 = add i32 %t556, %t557
  %t562 = load ptr, ptr %l283, !tbaa !29
  %t563 = getelementptr %"compiler/build:Sha256", ptr %t562, i32 0, i32 0
  %t564 = getelementptr [8 x i32], ptr %t563, i64 0, i64 5
  store i32 %t560, ptr %t564, !tbaa !84
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l287, !tbaa !29
  %t566 = load ptr, ptr %l287, !tbaa !29
  %t567 = getelementptr %"compiler/build:Sha256", ptr %t566, i32 0, i32 0
  %t568 = getelementptr [8 x i32], ptr %t567, i64 0, i64 6
  %t569 = load i32, ptr %t568, !tbaa !84
  %t570 = load i32, ptr %l25, !tbaa !64
  %t573 = add i32 %t569, %t570
  %t575 = load ptr, ptr %l287, !tbaa !29
  %t576 = getelementptr %"compiler/build:Sha256", ptr %t575, i32 0, i32 0
  %t577 = getelementptr [8 x i32], ptr %t576, i64 0, i64 6
  store i32 %t573, ptr %t577, !tbaa !84
  %t578 = load ptr, ptr %l0, !tbaa !29
  store ptr %t578, ptr %l291, !tbaa !29
  %t579 = load ptr, ptr %l291, !tbaa !29
  %t580 = getelementptr %"compiler/build:Sha256", ptr %t579, i32 0, i32 0
  %t581 = getelementptr [8 x i32], ptr %t580, i64 0, i64 7
  %t582 = load i32, ptr %t581, !tbaa !84
  %t583 = load i32, ptr %l26, !tbaa !64
  %t586 = add i32 %t582, %t583
  %t588 = load ptr, ptr %l291, !tbaa !29
  %t589 = getelementptr %"compiler/build:Sha256", ptr %t588, i32 0, i32 0
  %t590 = getelementptr [8 x i32], ptr %t589, i64 0, i64 7
  store i32 %t586, ptr %t590, !tbaa !84
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l35 = alloca %"compiler/build:Unit"
  %l37 = alloca ptr
  %l45 = alloca %"compiler/build:Unit"
  %l51 = alloca ptr
  %l54 = alloca i32
  %l58 = alloca %"compiler/build:Unit"
  %l60 = alloca ptr
  %l66 = alloca %"compiler/build:Unit"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/build:stubFrontend", ptr %t2, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = getelementptr %"compiler/build:stubFrontend", ptr %t8, i32 0, i32 1
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/build:Config", ptr %t10, i32 0, i32 3
  %t14 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v2, ptr %s0, ptr %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d178, i32 0, i32 1) })
  store i1 %t14, ptr %l15
  br label %bb1
bb1:
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 3
  %t20 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v2, ptr %s0, ptr %s0, ptr %t18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store { i64, ptr } %t20, ptr %l19
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d180, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb5
bb4:
  %t21 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 2
  %t33 = getelementptr %"compiler/target:Target", ptr %t32, i32 0, i32 5
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d181, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d181, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %t34, 1
  %t39 = extractvalue { i64, ptr } %t34, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d182, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d182, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = getelementptr i8, ptr %t45, i64 %t39
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t44, 1
  store { i64, ptr } %t48, ptr %l7, !tbaa !27
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 2
  %t53 = getelementptr %"compiler/target:Target", ptr %t52, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t58 = extractvalue { i64, ptr } %t54, 1
  %t59 = extractvalue { i64, ptr } %t54, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = getelementptr i8, ptr %t65, i64 %t59
  call void @olang_textcopy(ptr %t66, ptr %t61, i64 %t62)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  store { i64, ptr } %t68, ptr %l8, !tbaa !27
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/build:Program", ptr %t70, i32 0, i32 0
  store ptr %t72, ptr %l28, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d185, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d185, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t83 = extractvalue { i64, ptr } %t29, 1
  %t84 = extractvalue { i64, ptr } %t29, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t90 = extractvalue { i64, ptr } %t75, 1
  %t91 = extractvalue { i64, ptr } %t75, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t77, i64 %t78)
  %t94 = getelementptr i8, ptr %t93, i64 %t78
  call void @olang_textcopy(ptr %t94, ptr %t79, i64 %t80)
  %t95 = getelementptr i8, ptr %t94, i64 %t80
  call void @olang_textcopy(ptr %t95, ptr %t83, i64 %t84)
  %t96 = getelementptr i8, ptr %t95, i64 %t84
  call void @olang_textcopy(ptr %t96, ptr %t86, i64 %t87)
  %t97 = getelementptr i8, ptr %t96, i64 %t87
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t93, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t109 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, i32 0, { i64, ptr } %t106)
  store %"compiler/build:Unit" %t109, ptr %l35
  br label %bb6
bb6:
  %t110 = load ptr, ptr %l28, !tbaa !29
  %t111 = load %"compiler/build:Unit", ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t110, %"compiler/build:Unit" %t111)
  br label %bb7
bb7:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/build:Program", ptr %t112, i32 0, i32 0
  store ptr %t114, ptr %l37, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/build:stubFrontend", ptr %t116, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t115, 1
  %t123 = extractvalue { i64, ptr } %t115, 0
  %t124 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d188, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d188, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t134 = extractvalue { i64, ptr } %t120, 1
  %t135 = extractvalue { i64, ptr } %t120, 0
  %t136 = add i64 %t132, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t122, i64 %t123)
  %t138 = getelementptr i8, ptr %t137, i64 %t123
  call void @olang_textcopy(ptr %t138, ptr %t124, i64 %t125)
  %t139 = getelementptr i8, ptr %t138, i64 %t125
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t119)
  %t141 = getelementptr i8, ptr %t139, i64 %t128
  call void @olang_textcopy(ptr %t141, ptr %t130, i64 %t131)
  %t142 = getelementptr i8, ptr %t141, i64 %t131
  call void @olang_textcopy(ptr %t142, ptr %t134, i64 %t135)
  %t143 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t137, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t154 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d190, i32 0, i32 1) }, i32 0, { i64, ptr } %t151)
  store %"compiler/build:Unit" %t154, ptr %l45
  br label %bb8
bb8:
  %t155 = load ptr, ptr %l37, !tbaa !29
  %t156 = load %"compiler/build:Unit", ptr %l45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t155, %"compiler/build:Unit" %t156)
  br label %bb9
bb9:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = extractvalue { i64, ptr } %t157, 0
  %t162 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d193, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t175 = extractvalue { i64, ptr } %t158, 1
  %t176 = extractvalue { i64, ptr } %t158, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t160, i64 %t161)
  %t179 = getelementptr i8, ptr %t178, i64 %t161
  call void @olang_textcopy(ptr %t179, ptr %t162, i64 %t163)
  %t180 = getelementptr i8, ptr %t179, i64 %t163
  call void @olang_textcopy(ptr %t180, ptr %t165, i64 %t166)
  %t181 = getelementptr i8, ptr %t180, i64 %t166
  call void @olang_textcopy(ptr %t181, ptr %t168, i64 %t169)
  %t182 = getelementptr i8, ptr %t181, i64 %t169
  call void @olang_textcopy(ptr %t182, ptr %t171, i64 %t172)
  %t183 = getelementptr i8, ptr %t182, i64 %t172
  call void @olang_textcopy(ptr %t183, ptr %t175, i64 %t176)
  %t184 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t178, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l9, !tbaa !27
  %t194 = load ptr, ptr %l4, !tbaa !29
  %t196 = getelementptr %"compiler/build:Program", ptr %t194, i32 0, i32 0
  store ptr %t196, ptr %l51, !tbaa !29
  %t199 = trunc i64 1 to i32
  %t200 = icmp eq i32 %a2, %t199
  br i1 %t200, label %bb10, label %bb11
bb10:
  store i32 1, ptr %l54
  br label %bb12
bb11:
  store i32 2, ptr %l54
  br label %bb12
bb12:
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t205 = load i32, ptr %l54
  %t207 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d195, i32 0, i32 1) }, i32 %t205, { i64, ptr } %t204)
  store %"compiler/build:Unit" %t207, ptr %l58
  br label %bb13
bb13:
  %t208 = load ptr, ptr %l51, !tbaa !29
  %t209 = load %"compiler/build:Unit", ptr %l58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t208, %"compiler/build:Unit" %t209)
  br label %bb14
bb14:
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = getelementptr %"compiler/build:Program", ptr %t210, i32 0, i32 0
  store ptr %t212, ptr %l60, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = extractvalue { i64, ptr } %t213, 0
  %t218 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t222 = extractvalue { i64, ptr } %t214, 1
  %t223 = extractvalue { i64, ptr } %t214, 0
  %t224 = add i64 %t220, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t216, i64 %t217)
  %t226 = getelementptr i8, ptr %t225, i64 %t217
  call void @olang_textcopy(ptr %t226, ptr %t218, i64 %t219)
  %t227 = getelementptr i8, ptr %t226, i64 %t219
  call void @olang_textcopy(ptr %t227, ptr %t222, i64 %t223)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t225, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = extractvalue { i64, ptr } %t229, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t239 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d197, i32 0, i32 1) }, i32 3, { i64, ptr } %t236)
  store %"compiler/build:Unit" %t239, ptr %l66
  br label %bb15
bb15:
  %t240 = load ptr, ptr %l60, !tbaa !29
  %t241 = load %"compiler/build:Unit", ptr %l66
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t240, %"compiler/build:Unit" %t241)
  br label %bb16
bb16:
  %t242 = load ptr, ptr %l4, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = extractvalue { i64, ptr } %t243, 0
  %t248 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t252 = extractvalue { i64, ptr } %t244, 1
  %t253 = extractvalue { i64, ptr } %t244, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t246, i64 %t247)
  %t256 = getelementptr i8, ptr %t255, i64 %t247
  call void @olang_textcopy(ptr %t256, ptr %t248, i64 %t249)
  %t257 = getelementptr i8, ptr %t256, i64 %t249
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t255, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = extractvalue { i64, ptr } %t259, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t269 = getelementptr %"compiler/build:Program", ptr %t242, i32 0, i32 1
  store { i64, ptr } %t266, ptr %t269, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a2, 1
  %t6 = extractvalue { i64, ptr } %a2, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d200, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d200, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t15, 1
  store { i32, { i64, ptr } } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a2, 0
  %t5 = trunc i64 %t3 to i32
  %t7 = insertvalue { i32, i32 } zeroinitializer, i32 %t5, 1
  store { i32, i32 } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @compiler_2fbuild_2efileError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %l11 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d201, i32 0, i32 1) }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  %t19 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/msgs:Msg" %a1)
  store i64 %t19, ptr %l11
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d202, i32 0, i32 1) }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/msgs:Msg" %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %t1)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %s0, ptr %t12)
  store { i64, ptr } %t14, ptr %l5
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t21)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ehexOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2eholderAlive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l6 = alloca %"std/os:FileInfo"
  %l7 = alloca i32
  %l9 = alloca i1
  %l11 = alloca i64
  %l17 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l24 = alloca i1
  %l28 = alloca i1
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l6
  store %"std/os:FileInfo" %t8, ptr %l4
  br label %bb4
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t14 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t14, ptr %l1
  %t15 = call i64 @std_2ftime_2eWall()
  store i64 %t15, ptr %l11
  br label %bb5
bb5:
  %t16 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t17 = load i64, ptr %t16, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t20 = sub i64 %t18, %t17
  store i64 %t20, ptr %l2, !tbaa !24
  %t22 = load i64, ptr %l2, !tbaa !24
  %t24 = icmp sgt i64 %t22, 1800000000000
  br i1 %t24, label %bb6, label %bb7
bb6:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t27 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 1
  %t30 = extractvalue { i64, ptr } %t27, 0
  %t31 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d203, i32 0, i32 1) }, 0
  %t33 = add i64 %t30, %t32
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @olang_textcopy(ptr %t34, ptr %t29, i64 %t30)
  %t35 = getelementptr i8, ptr %t34, i64 %t30
  call void @olang_textcopy(ptr %t35, ptr %t31, i64 %t32)
  %t36 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t34, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = extractvalue { i64, ptr } %t37, 1
  %t41 = mul i64 %t39, 1
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @llvm.memcpy.p0.p0.i64(ptr %t42, ptr %t40, i64 %t41, i1 false)
  %t43 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  %t46 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t44)
  %t47 = extractvalue { i32, { i64, ptr } } %t46, 1
  %t48 = extractvalue { i32, { i64, ptr } } %t46, 0
  store i32 %t48, ptr %l22
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb10, label %ok.50
ok.50:
  store { i64, ptr } %t47, ptr %l21
  br label %bb9
bb9:
  %t51 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t51, ptr %l17, !tbaa !27
  br label %bb12
bb10:
  %t52 = load i32, ptr %l22, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  store i1 %t55, ptr %l24, !tbaa !21
  br label %bb11
bb11:
  call void @__olang_ert_req_clear()
  %t56 = load i64, ptr %l2, !tbaa !24
  %t58 = icmp slt i64 %t56, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t58, ptr %rv
  br label %ret
bb12:
  %t60 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t60, ptr %l3, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t63 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d204, i32 0, i32 1) })
  store i1 %t63, ptr %l28
  br label %bb13
bb13:
  %t64 = load i1, ptr %l28, !tbaa !21
  br i1 %t64, label %bb14, label %bb15
bb14:
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = icmp slt i64 %t65, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t67, ptr %rv
  br label %ret
bb15:
  br label %bb16
bb16:
  %t69 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t70 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d205, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d205, i32 0, i32 1) }, 0
  %t73 = extractvalue { i64, ptr } %t69, 1
  %t74 = extractvalue { i64, ptr } %t69, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t70, i64 %t71)
  %t77 = getelementptr i8, ptr %t76, i64 %t71
  call void @olang_textcopy(ptr %t77, ptr %t73, i64 %t74)
  %t78 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t86)
  store i1 %t88, ptr %l34
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load i1, ptr %l34, !tbaa !21
  store i1 %t89, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d206, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb21
bb4:
  %t8 = load i32, ptr %l0
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d207, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  br label %bb21
bb8:
  %t15 = load i32, ptr %l0
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d208, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  br label %bb21
bb12:
  %t22 = load i32, ptr %l0
  %t24 = trunc i64 3 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d209, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l1, !tbaa !27
  br label %bb21
bb16:
  %t29 = load i32, ptr %l0
  %t31 = trunc i64 4 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d210, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t34, ptr %l1, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7cb1cbeb873878be_a9deaf72b78184ba)
  unreachable
bb21:
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t49, ptr %l1, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2elinkCurrent(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l10 = alloca i1
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l17 = alloca i1
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  br label %bb4
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l10, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb4:
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t14, ptr %l3, !tbaa !27
  %t17 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
  %t18 = extractvalue { i32, %"std/os:FileInfo" } %t17, 1
  %t19 = extractvalue { i32, %"std/os:FileInfo" } %t17, 0
  store i32 %t19, ptr %l15
  %t20 = icmp ne i32 %t19, 0
  br i1 %t20, label %bb6, label %ok.21
ok.21:
  store %"std/os:FileInfo" %t18, ptr %l14
  br label %bb5
bb5:
  %t22 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t22, ptr %l12
  br label %bb8
bb6:
  %t23 = load i32, ptr %l15, !tbaa !23
  %t24 = ashr i32 %t23, 16
  %t26 = icmp eq i32 %t24, 1
  store i1 %t26, ptr %l17, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb8:
  %t28 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t28, ptr %l4
  %t29 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t31 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t34 = load i64, ptr %t33, !tbaa !24
  %t36 = extractvalue { i64, ptr } %a2, 1
  %t37 = extractvalue { i64, ptr } %a2, 0
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t40 = add i64 %t37, %t39
  %t42 = call i64 @__olang_fmt_i64(ptr null, i64 %t32)
  %t43 = add i64 %t40, %t42
  %t44 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d211, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t48 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t49 = add i64 %t46, %t48
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d212, i32 0, i32 1) }, 0
  %t52 = add i64 %t49, %t51
  %t53 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t52)
  call void @olang_textcopy(ptr %t53, ptr %t36, i64 %t37)
  %t54 = getelementptr i8, ptr %t53, i64 %t37
  call void @olang_textcopy(ptr %t54, ptr %t38, i64 %t39)
  %t55 = getelementptr i8, ptr %t54, i64 %t39
  %t56 = call i64 @__olang_fmt_i64(ptr %t55, i64 %t32)
  %t57 = getelementptr i8, ptr %t55, i64 %t42
  call void @olang_textcopy(ptr %t57, ptr %t44, i64 %t45)
  %t58 = getelementptr i8, ptr %t57, i64 %t45
  %t59 = call i64 @__olang_fmt_i64(ptr %t58, i64 %t34)
  %t60 = getelementptr i8, ptr %t58, i64 %t48
  call void @olang_textcopy(ptr %t60, ptr %t50, i64 %t51)
  %t61 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t53, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t72 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t29, { i64, ptr } %t69)
  store i1 %t72, ptr %l25
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t73 = load i1, ptr %l25, !tbaa !21
  store i1 %t73, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l19
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t17, ptr %l27, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d213, i32 0, i32 1) }, 0
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d214, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d214, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = getelementptr i8, ptr %t36, i64 %t30
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t35, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } %t39, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t46)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l5, !tbaa !24
  br label %bb2
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l38, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l39, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l38, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t67, ptr %l8, !tbaa !27
  store i64 1073741824, ptr %l9, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb10, label %bb11
bb10:
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t82, ptr %l47, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %t86, i64 %t83
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !37
  store { i64, ptr } %t88, ptr %l13, !tbaa !27
  store ptr %a2, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb13
bb13:
  %t92 = load i64, ptr %l15, !tbaa !24
  store i64 %t92, ptr %l51, !tbaa !24
  %t93 = load ptr, ptr %l14, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t93)
  store i64 %t95, ptr %l53
  br label %bb14
bb14:
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = load i64, ptr %l53, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb15, label %bb16
bb15:
  br label %bb31
bb16:
  br label %bb17
bb17:
  %t102 = load ptr, ptr %l14, !tbaa !29
  %t103 = load i64, ptr %l15, !tbaa !24
  %t106 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l58
  br label %bb18
bb18:
  %t107 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t107, ptr %l16, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t112 = call i64 @compiler_2fbuild_2ecloseness(ptr %v1, ptr %v2, { i64, ptr } %t108, { i64, ptr } %t109)
  store i64 %t112, ptr %l61
  br label %bb19
bb19:
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l17, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t115 = load i64, ptr %l17, !tbaa !24
  %t118 = call i1 @compiler_2fmsgs_2eNear(ptr %v1, { i64, ptr } %t114, i64 %t115)
  store i1 %t118, ptr %l64
  br label %bb20
bb20:
  %t119 = load i1, ptr %l64, !tbaa !21
  br i1 %t119, label %bb21, label %bb22
bb21:
  %t120 = load i64, ptr %l17, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  store i1 %t124, ptr %l65, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb23
bb23:
  %t126 = load i1, ptr %l65, !tbaa !21
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t127 = load i64, ptr %l17, !tbaa !24
  store i64 %t127, ptr %l9, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 1
  %t132 = extractvalue { i64, ptr } %t129, 0
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t131, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l71, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l73, !tbaa !24
  %t141 = load i64, ptr %l73, !tbaa !24
  %t142 = icmp eq i64 %t137, %t141
  br i1 %t142, label %bb26, label %bb27
bb25:
  br label %bb29
bb26:
  %t144 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l73, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  br label %bb28
bb27:
  %t150 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t150, ptr %l8, !tbaa !27
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t151 = load i64, ptr %l15, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l15, !tbaa !24
  br label %bb13
bb31:
  br label %bb32
bb32:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l11, !tbaa !24
  br label %bb9
bb33:
  %t159 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t159, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d216, i32 0, i32 1) })
  store i1 %t161, ptr %l80
  br label %bb34
bb34:
  %t162 = load i1, ptr %l80, !tbaa !21
  %t163 = xor i1 %t162, true
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t165 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t166 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t169 = extractvalue { i64, ptr } %t165, 1
  %t170 = extractvalue { i64, ptr } %t165, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t166, i64 %t167)
  %t176 = getelementptr i8, ptr %t175, i64 %t167
  call void @olang_textcopy(ptr %t176, ptr %t169, i64 %t170)
  %t177 = getelementptr i8, ptr %t176, i64 %t170
  call void @olang_textcopy(ptr %t177, ptr %t172, i64 %t173)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t175, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } %t179, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  store { i64, ptr } %t186, ptr %l82, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d219, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb37
bb37:
  %t188 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t188, ptr %l18, !tbaa !27
  store { i64, ptr } %a0, ptr %l86, !tbaa !27
  %t191 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d220, i32 0, i32 1) })
  store { i64, ptr } %t191, ptr %l88
  br label %bb38
bb38:
  %t192 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d221, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d221, i32 0, i32 1) }, 0
  %t198 = add i64 %t195, %t197
  %t199 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = add i64 %t198, %t201
  %t204 = extractvalue { i64, ptr } %t192, 1
  %t205 = extractvalue { i64, ptr } %t192, 0
  %t206 = add i64 %t202, %t205
  %t207 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t194, i64 %t195)
  %t208 = getelementptr i8, ptr %t207, i64 %t195
  call void @olang_textcopy(ptr %t208, ptr %t196, i64 %t197)
  %t209 = getelementptr i8, ptr %t208, i64 %t197
  call void @olang_textcopy(ptr %t209, ptr %t200, i64 %t201)
  %t210 = getelementptr i8, ptr %t209, i64 %t201
  call void @olang_textcopy(ptr %t210, ptr %t204, i64 %t205)
  %t211 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t207, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2erotr(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !64
  %t2 = load i32, ptr %l1, !tbaa !64
  store i32 %t2, ptr %l3, !tbaa !64
  %t4 = load i32, ptr %l3, !tbaa !64
  %t5 = load i32, ptr %l3, !tbaa !64
  %t6 = lshr i32 %t1, %t5
  %t7 = load i32, ptr %l0, !tbaa !64
  %t8 = load i32, ptr %l1, !tbaa !64
  %t10 = sub i32 32, %t8
  store i32 %t10, ptr %l7, !tbaa !64
  %t12 = load i32, ptr %l7, !tbaa !64
  %t13 = load i32, ptr %l7, !tbaa !64
  %t14 = shl i32 %t7, %t13
  %t17 = or i32 %t6, %t14
  store i32 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/os:Output"
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i1
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t5 = call { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l11
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb5:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %t20, i64 %t17
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d222, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t25 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t22, { i64, ptr } %t24, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t26 = extractvalue { i32, %"std/os:Output" } %t25, 1
  %t27 = extractvalue { i32, %"std/os:Output" } %t25, 0
  store i32 %t27, ptr %l20
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29
ok.29:
  store %"std/os:Output" %t26, ptr %l19
  br label %bb6
bb6:
  %t30 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t30, ptr %l14
  br label %bb9
bb7:
  %t31 = load i32, ptr %l20, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  store i1 %t34, ptr %l22, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_ert_req_clear()
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l23, !tbaa !27
  %t36 = load i64, ptr %l5, !tbaa !24
  %t38 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = getelementptr i32, ptr %t39, i64 %t36
  store i32 127, ptr %t40, !tbaa !33
  %t41 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t41, ptr %l25, !tbaa !27
  %t42 = load i64, ptr %l5, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %l27, !tbaa !27
  %t44 = load i64, ptr %l5, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %t47, i64 %t44
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !37
  store { i64, ptr } %t49, ptr %l29, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %t51, i64 0
  %t53 = load { i64, ptr }, ptr %t52, !tbaa !37
  %t54 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d223, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d223, i32 0, i32 1) }, 0
  %t57 = extractvalue { i64, ptr } %t53, 1
  %t58 = extractvalue { i64, ptr } %t53, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d224, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d224, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t54, i64 %t55)
  %t64 = getelementptr i8, ptr %t63, i64 %t55
  call void @olang_textcopy(ptr %t64, ptr %t57, i64 %t58)
  %t65 = getelementptr i8, ptr %t64, i64 %t58
  call void @olang_textcopy(ptr %t65, ptr %t60, i64 %t61)
  %t66 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t63, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t77 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %t78, i64 %t42
  store { i64, ptr } %t74, ptr %t79, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb9:
  %t80 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t80, ptr %l6
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t81, ptr %l33, !tbaa !27
  %t82 = load i64, ptr %l5, !tbaa !24
  %t83 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t84 = load i32, ptr %t83, !tbaa !23
  %t87 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t88 = load ptr, ptr %t87, !tbaa !27
  %t89 = getelementptr i32, ptr %t88, i64 %t82
  store i32 %t84, ptr %t89, !tbaa !33
  %t90 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t90, ptr %l36, !tbaa !27
  %t91 = load i64, ptr %l5, !tbaa !24
  %t92 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  %t94 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t93, 1
  %t98 = extractvalue { i64, ptr } %t93, 0
  %t100 = extractvalue { i64, ptr } %t95, 1
  %t101 = extractvalue { i64, ptr } %t95, 0
  %t102 = add i64 %t98, %t101
  %t103 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t102)
  call void @olang_textcopy(ptr %t103, ptr %t97, i64 %t98)
  %t104 = getelementptr i8, ptr %t103, i64 %t98
  call void @olang_textcopy(ptr %t104, ptr %t100, i64 %t101)
  %t105 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t103, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = extractvalue { i64, ptr } %t106, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  %t116 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t117 = load ptr, ptr %t116, !tbaa !27
  %t118 = getelementptr { i64, ptr }, ptr %t117, i64 %t91
  store { i64, ptr } %t113, ptr %t118, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb1
bb11:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb4
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2estatusOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/os:Output"
  %l9 = alloca i32
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = mul i64 1, 16
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 0
  store { i64, ptr } %t14, ptr %t22, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d222, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } %t24, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t26 = extractvalue { i32, %"std/os:Output" } %t25, 1
  %t27 = extractvalue { i32, %"std/os:Output" } %t25, 0
  store i32 %t27, ptr %l9
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb2, label %ok.29
ok.29:
  store %"std/os:Output" %t26, ptr %l8
  br label %bb1
bb1:
  %t30 = load %"std/os:Output", ptr %l8
  store %"std/os:Output" %t30, ptr %l2
  br label %bb4
bb2:
  %t31 = load i32, ptr %l9, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  store i1 %t34, ptr %l11, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb4:
  %t36 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t36, ptr %l1
  %t37 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t38 = load i32, ptr %t37, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t38, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eunbuilt() #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/target:Target"
  %l10 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/target:Target"
  %l25 = alloca %"compiler/cond:Consts"
  %l26 = alloca %"compiler/build:Config"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d225, i32 0, i32 1) }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d226, i32 0, i32 1) }, ptr %l1, !tbaa !27
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
  store %"compiler/target:Target" %t1, ptr %l24
  br label %bb1
bb1:
  %t2 = load %"compiler/target:Target", ptr %l24
  store %"compiler/target:Target" %t2, ptr %l2
  %t3 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
  store %"compiler/cond:Consts" %t3, ptr %l25
  br label %bb2
bb2:
  %t4 = load %"compiler/cond:Consts", ptr %l25
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d227, i32 0, i32 1) }, ptr %l10, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d228, i32 0, i32 1) }, ptr %l17, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d229, i32 0, i32 1) }, ptr %l18, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d230, i32 0, i32 1) }, ptr %l22, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d231, i32 0, i32 1) }, ptr %l23, !tbaa !27
  %t5 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 2
  %t10 = load %"compiler/target:Target", ptr %l2
  store %"compiler/target:Target" %t10, ptr %t9
  %t11 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 3
  store %"compiler/cond:Consts" %t4, ptr %t11
  %t13 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 4
  store i1 false, ptr %t13, !tbaa !21
  %t15 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 5
  store i1 false, ptr %t15, !tbaa !21
  %t17 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 6
  store i1 false, ptr %t17, !tbaa !21
  %t19 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 7
  store i1 false, ptr %t19, !tbaa !21
  %t21 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 8
  store i1 false, ptr %t21, !tbaa !21
  %t23 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 9
  store i1 false, ptr %t23, !tbaa !21
  %t25 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 10
  %t26 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t26, ptr %t25, !tbaa !27
  %t27 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 11
  store i64 0, ptr %t27, !tbaa !24
  %t29 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 12
  store i1 false, ptr %t29, !tbaa !21
  %t31 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 13
  store i1 false, ptr %t31, !tbaa !21
  %t33 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 14
  store i64 0, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 15
  store i1 false, ptr %t35, !tbaa !21
  %t37 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 16
  store i1 false, ptr %t37, !tbaa !21
  %t39 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 17
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t40, ptr %t39, !tbaa !27
  %t41 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 18
  %t42 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t42, ptr %t41, !tbaa !27
  %t43 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 19
  store i64 0, ptr %t43, !tbaa !24
  %t45 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 20
  store i64 0, ptr %t45, !tbaa !24
  %t47 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 21
  store i1 false, ptr %t47, !tbaa !21
  %t49 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 22
  %t50 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t50, ptr %t49, !tbaa !27
  %t51 = getelementptr %"compiler/build:Config", ptr %l26, i32 0, i32 23
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %t51, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l26, i64 360, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/build:Program"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d232, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d233, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l9
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l3
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l10
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l4
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d234, i32 0, i32 1) }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d235, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l11
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  %t9 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t10 = insertvalue %"compiler/build:Program" undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, 0
  %t11 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = insertvalue %"compiler/build:Program" %t10, { i64, ptr } %t11, 1
  %t13 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t14 = insertvalue %"compiler/build:Program" %t12, { i64, ptr } %t13, 2
  %t15 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t16 = insertvalue %"compiler/build:Program" %t14, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 3
  %t17 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t18 = insertvalue %"compiler/build:Program" %t16, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 4
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t20 = insertvalue %"compiler/build:Program" %t18, { i64, ptr } %t19, 5
  %t21 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = insertvalue %"compiler/build:Program" %t20, { i64, ptr } %t21, 6
  %t24 = insertvalue %"compiler/build:Program" %t22, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, 7
  store %"compiler/build:Program" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Program", ptr %rv
  ret %"compiler/build:Program" %rr
}

define dso_local %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca [8 x i32]
  %l5 = alloca [64 x i8]
  %rv = alloca %"compiler/build:Sha256"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x i32] undef, i32 1779033703, 0
  %t2 = insertvalue [8 x i32] %t1, i32 -1150833019, 1
  %t3 = insertvalue [8 x i32] %t2, i32 1013904242, 2
  %t4 = insertvalue [8 x i32] %t3, i32 -1521486534, 3
  %t5 = insertvalue [8 x i32] %t4, i32 1359893119, 4
  %t6 = insertvalue [8 x i32] %t5, i32 -1694144372, 5
  %t7 = insertvalue [8 x i32] %t6, i32 528734635, 6
  %t8 = insertvalue [8 x i32] %t7, i32 1541459225, 7
  store [8 x i32] %t8, ptr %l0
  br label %fill.13
fill.13:
  br label %fill.10
fill.10:
  %t14 = phi i64 [ 0, %fill.13 ], [ %t15, %fill.11 ]
  %t16 = icmp slt i64 %t14, 64
  br i1 %t16, label %fill.11, label %fill.12
fill.11:
  %t17 = getelementptr [64 x i8], ptr %l5, i64 0, i64 %t14
  store i8 0, ptr %t17
  %t15 = add i64 %t14, 1
  br label %fill.10
fill.12:
  %t18 = load [64 x i8], ptr %l5
  %t19 = load [8 x i32], ptr %l0
  %t20 = insertvalue %"compiler/build:Sha256" undef, [8 x i32] %t19, 0
  %t22 = insertvalue %"compiler/build:Sha256" %t20, [64 x i8] %t18, 1
  %t24 = insertvalue %"compiler/build:Sha256" %t22, i64 0, 2
  %t26 = insertvalue %"compiler/build:Sha256" %t24, i64 0, 3
  store %"compiler/build:Sha256" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Sha256", ptr %rv
  ret %"compiler/build:Sha256" %rr
}

define dso_local %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca %"compiler/build:Unit"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d236, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t8 = insertvalue %"compiler/build:Unit" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/build:Unit" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/build:Unit" %t10, { i64, ptr } %a2, 2
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/build:Unit" %t12, { i64, ptr } %t13, 3
  store %"compiler/build:Unit" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Unit", ptr %rv
  ret %"compiler/build:Unit" %rr
}

define dso_local %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/build:compiles"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l9
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l10
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l11
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l12
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l4
  %t11 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l13
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l14
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l6
  %t15 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l15
  br label %bb8
bb8:
  %t16 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t17 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t18 = insertvalue %"compiler/build:compiles" undef, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 0
  %t19 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t20 = insertvalue %"compiler/build:compiles" %t18, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 1
  %t21 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t22 = insertvalue %"compiler/build:compiles" %t20, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 2
  %t23 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t24 = insertvalue %"compiler/build:compiles" %t22, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, 3
  %t25 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t26 = insertvalue %"compiler/build:compiles" %t24, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, 4
  %t27 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t28 = insertvalue %"compiler/build:compiles" %t26, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, 5
  %t29 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t30 = insertvalue %"compiler/build:compiles" %t28, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, 6
  %t32 = insertvalue %"compiler/build:compiles" %t30, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, 7
  store %"compiler/build:compiles" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:compiles", ptr %rv
  ret %"compiler/build:compiles" %rr
}

define dso_local %"compiler/build:stubFrontend" @compiler_2fbuild_3astubFrontend_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/build:stubFrontend"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/build:stubFrontend" undef, i64 0, 0
  %t4 = insertvalue %"compiler/build:stubFrontend" %t2, i64 0, 1
  store %"compiler/build:stubFrontend" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:stubFrontend", ptr %rv
  ret %"compiler/build:stubFrontend" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fbuild() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fbuild_2eThinFrom_2einit()
  br label %bb1
bb1:
  call void @compiler_2fbuild_2eImportLimit_2einit()
  br label %bb2
bb2:
  call void @compiler_2fbuild_2ePhaseAt_2einit()
  br label %bb3
bb3:
  call void @compiler_2fbuild_2eShaK_2einit()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 0] }>, align 8
@.d1 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare void @__olang_check_failed(ptr)
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TIMES" }>, align 8
declare void @__olang_ert_req_clear()
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"front" }>, align 8
@.d7 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lower+emit" }>, align 8
declare i32 @getpid()
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_9(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l2
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %a0
  %t7 = load i64, ptr %t6, !tbaa !34
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i64, ptr %t12, i64 %a1
  %t14 = load i64, ptr %t13, !tbaa !34
  %t17 = icmp sgt i64 %t7, %t14
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task10(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load ptr, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2fbuild_2erunner(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

declare i64 @__olang_join_tasks(ptr)
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Hangup" }>, align 8
@.d14 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Interrupt" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Quit" }>, align 8
@.d16 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"Illegal instruction" }>, align 8
@.d17 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"Trace/breakpoint trap" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Aborted" }>, align 8
@.d19 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Bus error" }>, align 8
@.d20 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"Floating point exception" }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Killed" }>, align 8
@.d22 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"Segmentation fault" }>, align 8
@.d23 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Broken pipe" }>, align 8
@.d24 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Alarm clock" }>, align 8
@.d25 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Terminated" }>, align 8
@.d26 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"Unknown signal " }>, align 8
@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c": lost track of its build, skipping" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d32 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c": the compiler ended (" }>, align 8
@.d33 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"), skipping" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d38 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"no listed file has a test named by " }>, align 8
@.d39 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d40 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"olang: error: the self-hosted compiler cannot build this yet: " }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
@.d42 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d43 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--sysroot=" }>, align 8
@.d46 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d47 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"-D_GNU_SOURCE" }>, align 8
@.d48 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-mllvm" }>, align 8
@.d50 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"-fast-isel=false" }>, align 8
@.d51 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d52 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d53 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"-Wl,-plugin-opt,cache-dir=" }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/thinlto" }>, align 8
@.d55 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"-Wl,-plugin-opt,-import-instr-limit=" }>, align 8
@.d56 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-shared" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".map" }>, align 8
@.d58 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{\0A  global:\0A" }>, align 8
@.d59 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d60 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c";\0A" }>, align 8
@.d61 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  local: *;\0A};\0A" }>, align 8
@.d62 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"-Wl,--version-script=" }>, align 8
@.d63 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"-Wl,-soname," }>, align 8
@.d64 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d65 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-lm" }>, align 8
@.d66 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-lpthread" }>, align 8
@.d67 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-ldl" }>, align 8
@.d68 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d69 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".link" }>, align 8
@.d70 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d71 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d73 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d74 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d75 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d76 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--sysroot=" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-fPIC" }>, align 8
@.d79 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d80 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=fuzzer" }>, align 8
@.d81 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O0" }>, align 8
@.d82 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-g" }>, align 8
@.d83 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d84 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O1" }>, align 8
@.d85 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d86 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O2" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O3" }>, align 8
@.d88 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d89 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d90 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d91 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d92 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".o" }>, align 8
@.d93 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d94 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d98 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
declare i32 @usleep(i32)
@.d101 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d104 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d105 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--version" }>, align 8
@.d106 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"-max_total_time=" }>, align 8
@.d110 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d111 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c": failing inputs go to " }>, align 8
@.d112 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d113 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"36" }>, align 8
@.d114 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d115 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d116 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c": nothing failed" }>, align 8
@.d117 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d118 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d119 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c": an input failed, saved in " }>, align 8
@.d120 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"/ - 'olang test' replays it" }>, align 8
@.d121 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d122 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d123 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d124 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d125 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/lib" }>, align 8
@.d130 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d131 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d132 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d134 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d135 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d136 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d137 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d138 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d139 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d140 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d141 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".race" }>, align 8
@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d143 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".debug" }>, align 8
@.d144 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d145 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".quick" }>, align 8
@.d146 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d147 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".san" }>, align 8
@.d148 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d149 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d150 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d151 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d152 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".fuzz" }>, align 8
@.d153 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d154 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d155 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d156 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"[0m" }>, align 8
@.d157 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": semantic errors, skipping" }>, align 8
@.d158 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d159 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": cannot be built, skipping" }>, align 8
@.d160 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d161 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d162 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d163 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d164 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d165 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d166 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d167 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang_" }>, align 8
@.d168 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d169 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".tmp.ll" }>, align 8
@.d170 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d171 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d172 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d173 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d174 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
declare i64 @sysconf(i32)
@.d175 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d176 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 -128] }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 0] }>, align 8
@.d178 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d179 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d180 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"41" }>, align 8
@.d181 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"attributes #0 = { nounwind " }>, align 8
@.d182 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" }\0A" }>, align 8
@.d183 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d184 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d185 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"define i32 @lib_n() #0 {\0A  ret i32 " }>, align 8
@.d186 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d187 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lib" }>, align 8
@.d188 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"define i32 @util_k() #0 {\0A  ret i32 " }>, align 8
@.d189 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d190 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"util" }>, align 8
@.d191 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"declare i32 @lib_n()\0Adeclare i32 @util_k()\0Adeclare i32 @inst_z()\0Adeclare void @olang_rt()\0A" }>, align 8
@.d192 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"define i32 @main() #0 {\0A  call void @olang_rt()\0A  %a = call i32 @lib_n()\0A" }>, align 8
@.d193 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %b = call i32 @util_k()\0A  %c = call i32 @inst_z()\0A  %s = add i32 %a, %b\0A  %t = add i32 %s, %c\0A" }>, align 8
@.d194 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  ret i32 %t\0A}\0A" }>, align 8
@.d195 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@.d196 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"define i32 @inst_z() #0 {\0A  ret i32 0\0A}\0A" }>, align 8
@.d197 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@.d198 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"define void @olang_rt() #0 {\0A  ret void\0A}\0A" }>, align 8
@.d199 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d200 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()\0A" }>, align 8
@.d201 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d202 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d203 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d204 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d205 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d206 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d207 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".main" }>, align 8
@.d208 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".test" }>, align 8
@.d209 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".inst" }>, align 8
@.d210 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".loc" }>, align 8
@.d211 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d212 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d213 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d214 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d215 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d216 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d217 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d218 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d219 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d220 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d221 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c": no test is named by " }>, align 8
@.d222 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d223 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"cannot run " }>, align 8
@.d224 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d225 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d226 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d227 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d228 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d229 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d230 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d231 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d232 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d233 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d234 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d235 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d236 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_807a392292b9ae5a_fba630df00719f06 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2ftime_2eNow()
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_1a0af222d89a1264_6ae848cde6020298 = external constant [0 x i8]
@olang_loc_2b4b55182e30c5b8_1dd1254afca8c384 = external constant [0 x i8]
@olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491 = external constant [0 x i8]
@olang_loc_bc625dc042a99e06_c0b5fdead4ea6272 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @std_2fchan_2eInit_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1359a9f97975288c_a8d4abcb606172b0 = external constant [0 x i8]
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_84eba90bdad5d702_427cd4b75eaf1c36 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eMkDir(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d17f382592ac8ef_3cd22268ed245003 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %v0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_4cf283899a273ea5_54dbe84ebef87a69 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2 = external constant [0 x i8]
declare i32 @std_2fos_2eLink(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_81dfa638548de3d7_ab0731b6a5acba3 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_64cef890f5e30dfa_ab05d47f854753c6 = external constant [0 x i8]
@olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2ftime_2eWall()
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_7cb1cbeb873878be_a9deaf72b78184ba = external constant [0 x i8]
declare i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
declare %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
