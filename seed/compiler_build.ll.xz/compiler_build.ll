; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%"compiler/build:Sha256" = type { [8 x i32], [64 x i8], i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"std/chan:Chan<I64>" = type { { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, [8 x i64], [8 x i64], [8 x i64] }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<compiler/cond:Value>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"std/prelude/list:List<compiler/cond:Value>" = type { ptr }
%"std/prelude/list:List<Bool>" = type { ptr }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:compiles" = type { %"std/prelude/list:List<Array<std/prelude/text:String&>&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>" }
%"std/prelude/list:List<Array<std/prelude/text:String&>&>" = type { ptr }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Program" = type { %"std/prelude/list:List<compiler/build:Unit>", { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List<compiler/build:Unit>" = type { ptr }
@G_2ecompiler_2fbuild_2eShaK = global [64 x i32] zeroinitializer
define dso_local { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Sha256"
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i32
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca ptr
  %l30 = alloca [1 x i8]
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l8
  store %"compiler/build:Sha256" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0
  store ptr %t3, ptr %l9
  %t4 = load ptr, ptr %l9
  store ptr %t4, ptr %l2
  store i64 0, ptr %l3
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2
  store ptr %t5, ptr %l11
  %t6 = load i64, ptr %l3
  store i64 %t6, ptr %l12
  %t7 = load ptr, ptr %l11
  %t8 = load i64, ptr %l12
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t14, ptr %l10
  br label %bb8
bb4:
  %t15 = load i32, ptr %l14
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l15
  %t17 = load i32, ptr %l15
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l16
  %t19 = load i1, ptr %l16
  br i1 %t19, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb8:
  %t20 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t20, ptr %l4
  %t21 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t21, ptr %l17
  %t22 = load { i64, ptr }, ptr %l17
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l18
  %t24 = load i64, ptr %l18
  store i64 %t24, ptr %l5
  store i64 0, ptr %l6
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6
  store i64 %t25, ptr %l19
  %t26 = load i64, ptr %l5
  store i64 %t26, ptr %l20
  %t27 = load i64, ptr %l19
  %t28 = load i64, ptr %l20
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l21
  %t30 = load i1, ptr %l21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l22
  %t32 = load i1, ptr %l22
  br i1 %t32, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t33, ptr %l23
  %t34 = load i64, ptr %l6
  store i64 %t34, ptr %l24
  %t35 = load i64, ptr %l24
  %t36 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t35
  %t39 = load { i64, ptr }, ptr %t38
  store { i64, ptr } %t39, ptr %l25
  %t40 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t40, ptr %l7
  store ptr %l1, ptr %l26
  %t41 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t41, ptr %l27
  %t42 = load { i64, ptr }, ptr %l27
  store { i64, ptr } %t42, ptr %l28
  %t43 = load ptr, ptr %l26
  %t44 = load { i64, ptr }, ptr %l28
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %t43, { i64, ptr } %t44)
  br label %bb13
bb13:
  store ptr %l1, ptr %l29
  %t45 = insertvalue [1 x i8] undef, i8 0, 0
  store [1 x i8] %t45, ptr %l30
  %t46 = load [1 x i8], ptr %l30
  %t47 = load ptr, ptr @__olang_prog_scope
  %t48 = call ptr @__olang_scope_alloc(ptr %t47, i64 1)
  store [1 x i8] %t46, ptr %t48
  %t49 = insertvalue { i64, ptr } undef, i64 1, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  store { i64, ptr } %t50, ptr %l31
  %t51 = load { i64, ptr }, ptr %l31
  %t52 = extractvalue { i64, ptr } %t51, 0
  %t53 = extractvalue { i64, ptr } %t51, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l32
  %t58 = load ptr, ptr %l29
  %t59 = load { i64, ptr }, ptr %l32
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %s3, ptr %t58, { i64, ptr } %t59)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t60 = load i64, ptr %l6
  store i64 %t60, ptr %l33
  %t61 = load i64, ptr %l33
  %t62 = add i64 %t61, 1
  store i64 %t62, ptr %l34
  %t63 = load i64, ptr %l34
  store i64 %t63, ptr %l6
  call void @__olang_scope_close(ptr %s4)
  br label %bb9
bb16:
  %t64 = load i64, ptr %l3
  store i64 %t64, ptr %l35
  %t65 = load i64, ptr %l5
  store i64 %t65, ptr %l36
  %t66 = load i64, ptr %l35
  %t67 = load i64, ptr %l36
  %t68 = add i64 %t66, %t67
  store i64 %t68, ptr %l37
  %t69 = load i64, ptr %l37
  store i64 %t69, ptr %l3
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb2
bb18:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l38
  %t70 = load ptr, ptr %l38
  %t71 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %t70)
  store { i64, ptr } %t71, ptr %l39
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t72 = load { i64, ptr }, ptr %l39
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i8
  %l17 = alloca ptr
  %l18 = alloca i8
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca i8
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca i8
  %l25 = alloca i1
  %l26 = alloca i1
  %l27 = alloca i8
  %l28 = alloca i1
  %l29 = alloca i8
  %l30 = alloca i8
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t3, ptr %l7
  %t4 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t4, ptr %l2
  store i64 0, ptr %l3
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l9
  %t8 = load i64, ptr %l9
  store i64 %t8, ptr %l4
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3
  store i64 %t9, ptr %l10
  %t10 = load i64, ptr %l4
  store i64 %t10, ptr %l11
  %t11 = load i64, ptr %l10
  %t12 = load i64, ptr %l11
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l12
  %t14 = load i1, ptr %l12
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l13
  %t16 = load i1, ptr %l13
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t17, ptr %l14
  %t18 = load i64, ptr %l3
  store i64 %t18, ptr %l15
  %t19 = load i64, ptr %l15
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = getelementptr i8, ptr %t21, i64 %t19
  %t23 = load i8, ptr %t22
  store i8 %t23, ptr %l16
  %t24 = load i8, ptr %l16
  store i8 %t24, ptr %l5
  store ptr %l1, ptr %l17
  %t25 = load i8, ptr %l5
  store i8 %t25, ptr %l18
  %t26 = load i8, ptr %l18
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t26)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20
  br label %bb10
bb8:
  %t29 = load i8, ptr %l5
  store i8 %t29, ptr %l21
  %t30 = load i8, ptr %l21
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t30)
  store i1 %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load i1, ptr %l22
  store i1 %t32, ptr %l20
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23
  br label %bb13
bb12:
  %t34 = load i8, ptr %l5
  store i8 %t34, ptr %l24
  %t35 = load i8, ptr %l24
  %t36 = icmp eq i8 %t35, 95
  store i1 %t36, ptr %l25
  %t37 = load i1, ptr %l25
  store i1 %t37, ptr %l23
  br label %bb13
bb13:
  %t38 = load i1, ptr %l23
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26
  br label %bb16
bb15:
  %t39 = load i8, ptr %l5
  store i8 %t39, ptr %l27
  %t40 = load i8, ptr %l27
  %t41 = icmp eq i8 %t40, 45
  store i1 %t41, ptr %l28
  %t42 = load i1, ptr %l28
  store i1 %t42, ptr %l26
  br label %bb16
bb16:
  %t43 = load i1, ptr %l26
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t44 = load i8, ptr %l5
  store i8 %t44, ptr %l30
  %t45 = load i8, ptr %l30
  store i8 %t45, ptr %l29
  br label %bb19
bb18:
  store i8 95, ptr %l29
  br label %bb19
bb19:
  %t46 = load ptr, ptr %l17
  %t47 = load i8, ptr %l29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t46, i8 %t47)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l3
  store i64 %t48, ptr %l31
  %t49 = load i64, ptr %l31
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l32
  %t51 = load i64, ptr %l32
  store i64 %t51, ptr %l3
  call void @__olang_scope_close(ptr %s3)
  br label %bb2
bb22:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l1, ptr %l33
  %t52 = load ptr, ptr %l33
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t52)
  store { i64, ptr } %t53, ptr %l34
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l34
  store { i64, ptr } %t54, ptr %l35
  %t55 = load { i64, ptr }, ptr %l35
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36
  %t57 = load i64, ptr %l36
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64
  %t66 = load i64, ptr %l36
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37
  store { i64, ptr } %t68, ptr %l35
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i1
  %l28 = alloca i1
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { { i64, ptr }, { i64, ptr } }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca i64
  %l45 = alloca %"std/chan:Chan<I64>"
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i1
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca i64
  %l75 = alloca i32
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i1
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca ptr
  %l112 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca ptr
  %l118 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca { { i64, ptr }, { i64, ptr } }
  %l123 = alloca { i64, ptr }
  %l124 = alloca i64
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca i64
  %l128 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %jh6 = alloca ptr
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t93 = alloca %"std/chan:Chan<I64>", align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l19
  %t2 = load { i64, ptr }, ptr %l19
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l20
  %t4 = load i64, ptr %l20
  store i64 %t4, ptr %l2
  %t5 = load i64, ptr %l2
  store i64 %t5, ptr %l21
  %t6 = load i64, ptr %l21
  %t7 = icmp sge i64 %t6, 0
  store i1 %t7, ptr %l22
  %t8 = load i1, ptr %l22
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l21
  %t10 = icmp sle i64 %t9, 2305843009213693951
  store i1 %t10, ptr %l23
  %t11 = load i1, ptr %l23
  br i1 %t11, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb3:
  %t12 = load i64, ptr %l21
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l24
  %t17 = load { i64, ptr }, ptr %l24
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 4
  %t21 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l25
  %t24 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t24, ptr %l3
  %t25 = load i64, ptr %l2
  store i64 %t25, ptr %l26
  %t26 = load i64, ptr %l26
  %t27 = icmp sge i64 %t26, 0
  store i1 %t27, ptr %l27
  %t28 = load i1, ptr %l27
  br i1 %t28, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb5:
  %t29 = load i64, ptr %l26
  %t30 = icmp sle i64 %t29, 576460752303423487
  store i1 %t30, ptr %l28
  %t31 = load i1, ptr %l28
  br i1 %t31, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb7:
  %t32 = load i64, ptr %l26
  %t33 = mul i64 %t32, 16
  %t34 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t33)
  %t35 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  store { i64, ptr } %t36, ptr %l29
  %t37 = load { i64, ptr }, ptr %l29
  %t38 = extractvalue { i64, ptr } %t37, 0
  %t39 = extractvalue { i64, ptr } %t37, 1
  %t40 = mul i64 %t38, 16
  %t41 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t40)
  call void @llvm.memcpy.p0.p0.i64(ptr %t41, ptr %t39, i64 %t40, i1 false)
  %t42 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l30
  %t44 = load { i64, ptr }, ptr %l30
  store { i64, ptr } %t44, ptr %l4
  %t45 = load i64, ptr %l2
  store i64 %t45, ptr %l31
  %t46 = load i64, ptr %l31
  %t47 = icmp eq i64 %t46, 0
  store i1 %t47, ptr %l32
  %t48 = load i1, ptr %l32
  br i1 %t48, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb9:
  store %olang.scope zeroinitializer, ptr %s1
  %t49 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t49, ptr %l33
  %t50 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t50, ptr %l34
  %t51 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t51, ptr %l35
  %t52 = load { i64, ptr }, ptr %l35
  store { i64, ptr } %t52, ptr %l36
  %t53 = load { i64, ptr }, ptr %l34
  %t54 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t53, 0
  %t55 = load { i64, ptr }, ptr %l36
  %t56 = insertvalue { { i64, ptr }, { i64, ptr } } %t54, { i64, ptr } %t55, 1
  store { { i64, ptr }, { i64, ptr } } %t56, ptr %l37
  %t57 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 0
  %t58 = load { i64, ptr }, ptr %t57
  store { i64, ptr } %t58, ptr %l38
  %t59 = load { i64, ptr }, ptr %l38
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l39
  %t61 = load i64, ptr %l39
  %t62 = mul i64 %t61, 4
  %t63 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l40
  %t66 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t67 = load ptr, ptr %t66
  %t68 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t69 = load ptr, ptr %t68
  %t70 = load i64, ptr %l39
  %t71 = mul i64 %t70, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l40
  %t73 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 0
  store { i64, ptr } %t72, ptr %t73
  %t74 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 1
  %t75 = load { i64, ptr }, ptr %t74
  store { i64, ptr } %t75, ptr %l41
  %t76 = load { i64, ptr }, ptr %l41
  %t77 = extractvalue { i64, ptr } %t76, 0
  store i64 %t77, ptr %l42
  %t78 = load i64, ptr %l42
  %t79 = mul i64 %t78, 16
  %t80 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t79)
  %t81 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l43
  %t83 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t84 = load ptr, ptr %t83
  %t85 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t86 = load ptr, ptr %t85
  %t87 = load i64, ptr %l42
  %t88 = mul i64 %t87, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t84, ptr %t86, i64 %t88, i1 false)
  %t89 = load { i64, ptr }, ptr %l43
  %t90 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l37, i32 0, i32 1
  store { i64, ptr } %t89, ptr %t90
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t91 = load { { i64, ptr }, { i64, ptr } }, ptr %l37
  store { { i64, ptr }, { i64, ptr } } %t91, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t92 = load i64, ptr %l2
  store i64 %t92, ptr %l44
  %t94 = load i64, ptr %l44
  call void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %t93, ptr %s0, i64 %t94)
  %t95 = load %"std/chan:Chan<I64>", ptr %t93
  store %"std/chan:Chan<I64>" %t95, ptr %l45
  br label %bb12
bb12:
  %t96 = load %"std/chan:Chan<I64>", ptr %l45
  %t97 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 264, i64 8)
  store %"std/chan:Chan<I64>" %t96, ptr %t97
  store ptr %t97, ptr %l46
  %t98 = load ptr, ptr %l46
  store ptr %t98, ptr %l5
  %t99 = load ptr, ptr %l5
  store ptr %t99, ptr %l47
  %t100 = load ptr, ptr %l47
  call void @std_2fchan_2eInit_3cI64_3e(ptr %s0, ptr %t100)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l6
  %t101 = load i64, ptr %l2
  store i64 %t101, ptr %l48
  %t102 = load i64, ptr %l48
  store i64 %t102, ptr %l7
  store i64 1, ptr %l8
  %t103 = load i64, ptr %l7
  store i64 %t103, ptr %l49
  %t104 = load i64, ptr %l6
  store i64 %t104, ptr %l50
  %t105 = load i64, ptr %l49
  %t106 = load i64, ptr %l50
  %t107 = icmp sgt i64 %t105, %t106
  store i1 %t107, ptr %l51
  %t108 = load i1, ptr %l51
  br i1 %t108, label %bb14, label %bb15
bb14:
  %t109 = load i64, ptr %l8
  store i64 %t109, ptr %l53
  %t110 = load i64, ptr %l53
  %t111 = icmp sgt i64 %t110, 0
  store i1 %t111, ptr %l54
  %t112 = load i1, ptr %l54
  br i1 %t112, label %bb16, label %bb17
bb15:
  store i64 0, ptr %l52
  br label %bb19
bb16:
  %t113 = load i64, ptr %l7
  store i64 %t113, ptr %l56
  %t114 = load i64, ptr %l6
  store i64 %t114, ptr %l57
  %t115 = load i64, ptr %l56
  %t116 = load i64, ptr %l57
  %t117 = sub i64 %t115, %t116
  store i64 %t117, ptr %l58
  %t118 = load i64, ptr %l8
  store i64 %t118, ptr %l59
  %t119 = load i64, ptr %l58
  %t120 = load i64, ptr %l59
  %t121 = add i64 %t119, %t120
  store i64 %t121, ptr %l60
  %t122 = load i64, ptr %l60
  %t123 = sub i64 %t122, 1
  store i64 %t123, ptr %l61
  %t124 = load i64, ptr %l8
  store i64 %t124, ptr %l62
  %t125 = load i64, ptr %l61
  %t126 = load i64, ptr %l62
  %t127 = sdiv i64 %t125, %t126
  store i64 %t127, ptr %l63
  %t128 = load i64, ptr %l63
  store i64 %t128, ptr %l55
  br label %bb18
bb17:
  store i64 0, ptr %l55
  br label %bb18
bb18:
  %t129 = load i64, ptr %l55
  store i64 %t129, ptr %l52
  br label %bb19
bb19:
  %t130 = load i64, ptr %l52
  store i64 %t130, ptr %l9
  store i64 0, ptr %l10
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s3
  %t131 = load i64, ptr %l10
  store i64 %t131, ptr %l64
  %t132 = load i64, ptr %l9
  store i64 %t132, ptr %l65
  %t133 = load i64, ptr %l64
  %t134 = load i64, ptr %l65
  %t135 = icmp slt i64 %t133, %t134
  store i1 %t135, ptr %l66
  %t136 = load i1, ptr %l66
  %t137 = xor i1 %t136, true
  store i1 %t137, ptr %l67
  %t138 = load i1, ptr %l67
  br i1 %t138, label %bb21, label %bb22
bb21:
  call void @__olang_scope_close(ptr %s3)
  br label %bb31
bb22:
  br label %bb23
bb23:
  %t139 = load i64, ptr %l6
  store i64 %t139, ptr %l68
  %t140 = load i64, ptr %l10
  store i64 %t140, ptr %l69
  %t141 = load i64, ptr %l8
  store i64 %t141, ptr %l70
  %t142 = load i64, ptr %l69
  %t143 = load i64, ptr %l70
  %t144 = mul i64 %t142, %t143
  store i64 %t144, ptr %l71
  %t145 = load i64, ptr %l68
  %t146 = load i64, ptr %l71
  %t147 = add i64 %t145, %t146
  store i64 %t147, ptr %l72
  %t148 = load i64, ptr %l72
  store i64 %t148, ptr %l11
  %t149 = load ptr, ptr %l5
  store ptr %t149, ptr %l73
  %t150 = load i64, ptr %l11
  store i64 %t150, ptr %l74
  %t151 = load ptr, ptr %l73
  %t152 = load i64, ptr %l74
  %t153 = call i32 @std_2fchan_2eSend_3cI64_3e(ptr %s0, ptr %t151, i64 %t152)
  store i32 %t153, ptr %l75
  %t154 = icmp ne i32 %t153, 0
  br i1 %t154, label %bb25, label %ok.155
ok.155:
  br label %bb24
bb24:
  br label %bb29
bb25:
  %t156 = load i32, ptr %l75
  %t157 = ashr i32 %t156, 16
  store i32 %t157, ptr %l76
  %t158 = load i32, ptr %l76
  %t159 = icmp eq i32 %t158, 1
  store i1 %t159, ptr %l77
  %t160 = load i1, ptr %l77
  br i1 %t160, label %bb26, label %bb27
bb26:
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb28:
  store %olang.scope zeroinitializer, ptr %s4
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb29:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t161 = load i64, ptr %l10
  store i64 %t161, ptr %l78
  %t162 = load i64, ptr %l78
  %t163 = add i64 %t162, 1
  store i64 %t163, ptr %l79
  %t164 = load i64, ptr %l79
  store i64 %t164, ptr %l10
  call void @__olang_scope_close(ptr %s5)
  br label %bb20
bb31:
  call void @__olang_scope_close(ptr %s2)
  %t165 = load i64, ptr %l1
  store i64 %t165, ptr %l80
  %t166 = load i64, ptr %l2
  store i64 %t166, ptr %l81
  %t167 = load i64, ptr %l80
  %t168 = load i64, ptr %l81
  %t169 = icmp slt i64 %t167, %t168
  store i1 %t169, ptr %l82
  %t170 = load i1, ptr %l82
  br i1 %t170, label %bb32, label %bb33
bb32:
  %t171 = load i64, ptr %l1
  store i64 %t171, ptr %l84
  %t172 = load i64, ptr %l84
  store i64 %t172, ptr %l83
  br label %bb34
bb33:
  %t173 = load i64, ptr %l2
  store i64 %t173, ptr %l85
  %t174 = load i64, ptr %l85
  store i64 %t174, ptr %l83
  br label %bb34
bb34:
  %t175 = load i64, ptr %l83
  store i64 %t175, ptr %l12
  store %olang.scope zeroinitializer, ptr %s6
  store ptr null, ptr %jh6
  store %olang.scope zeroinitializer, ptr %s7
  store i64 0, ptr %l13
  %t176 = load i64, ptr %l12
  store i64 %t176, ptr %l86
  %t177 = load i64, ptr %l86
  store i64 %t177, ptr %l14
  store i64 1, ptr %l15
  %t178 = load i64, ptr %l14
  store i64 %t178, ptr %l87
  %t179 = load i64, ptr %l13
  store i64 %t179, ptr %l88
  %t180 = load i64, ptr %l87
  %t181 = load i64, ptr %l88
  %t182 = icmp sgt i64 %t180, %t181
  store i1 %t182, ptr %l89
  %t183 = load i1, ptr %l89
  br i1 %t183, label %bb35, label %bb36
bb35:
  %t184 = load i64, ptr %l15
  store i64 %t184, ptr %l91
  %t185 = load i64, ptr %l91
  %t186 = icmp sgt i64 %t185, 0
  store i1 %t186, ptr %l92
  %t187 = load i1, ptr %l92
  br i1 %t187, label %bb37, label %bb38
bb36:
  store i64 0, ptr %l90
  br label %bb40
bb37:
  %t188 = load i64, ptr %l14
  store i64 %t188, ptr %l94
  %t189 = load i64, ptr %l13
  store i64 %t189, ptr %l95
  %t190 = load i64, ptr %l94
  %t191 = load i64, ptr %l95
  %t192 = sub i64 %t190, %t191
  store i64 %t192, ptr %l96
  %t193 = load i64, ptr %l15
  store i64 %t193, ptr %l97
  %t194 = load i64, ptr %l96
  %t195 = load i64, ptr %l97
  %t196 = add i64 %t194, %t195
  store i64 %t196, ptr %l98
  %t197 = load i64, ptr %l98
  %t198 = sub i64 %t197, 1
  store i64 %t198, ptr %l99
  %t199 = load i64, ptr %l15
  store i64 %t199, ptr %l100
  %t200 = load i64, ptr %l99
  %t201 = load i64, ptr %l100
  %t202 = sdiv i64 %t200, %t201
  store i64 %t202, ptr %l101
  %t203 = load i64, ptr %l101
  store i64 %t203, ptr %l93
  br label %bb39
bb38:
  store i64 0, ptr %l93
  br label %bb39
bb39:
  %t204 = load i64, ptr %l93
  store i64 %t204, ptr %l90
  br label %bb40
bb40:
  %t205 = load i64, ptr %l90
  store i64 %t205, ptr %l16
  store i64 0, ptr %l17
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s8
  %t206 = load i64, ptr %l17
  store i64 %t206, ptr %l102
  %t207 = load i64, ptr %l16
  store i64 %t207, ptr %l103
  %t208 = load i64, ptr %l102
  %t209 = load i64, ptr %l103
  %t210 = icmp slt i64 %t208, %t209
  store i1 %t210, ptr %l104
  %t211 = load i1, ptr %l104
  %t212 = xor i1 %t211, true
  store i1 %t212, ptr %l105
  %t213 = load i1, ptr %l105
  br i1 %t213, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb43:
  br label %bb44
bb44:
  %t214 = load i64, ptr %l13
  store i64 %t214, ptr %l106
  %t215 = load i64, ptr %l17
  store i64 %t215, ptr %l107
  %t216 = load i64, ptr %l15
  store i64 %t216, ptr %l108
  %t217 = load i64, ptr %l107
  %t218 = load i64, ptr %l108
  %t219 = mul i64 %t217, %t218
  store i64 %t219, ptr %l109
  %t220 = load i64, ptr %l106
  %t221 = load i64, ptr %l109
  %t222 = add i64 %t220, %t221
  store i64 %t222, ptr %l110
  %t223 = load i64, ptr %l110
  store i64 %t223, ptr %l18
  %t224 = load ptr, ptr %l5
  store ptr %t224, ptr %l111
  %t225 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t225, ptr %l112
  %t226 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t226, ptr %l113
  %t227 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t227, ptr %l114
  %t228 = load ptr, ptr %l111
  %t229 = load { i64, ptr }, ptr %l112
  %t230 = load { i64, ptr }, ptr %l113
  %t231 = load { i64, ptr }, ptr %l114
  %t232 = call ptr @__olang_standin(ptr %s0)
  %t233 = call ptr @__olang_standin(ptr %v0)
  %t234 = call ptr @__olang_standin(ptr %v1)
  %t235 = call ptr @__olang_standin(ptr %v1)
  %t236 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t237 = ptrtoint ptr %t236 to i64
  %t238 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 %t237, i64 8)
  %t239 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 0
  store ptr %t228, ptr %t239
  %t240 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 1
  store { i64, ptr } %t229, ptr %t240
  %t241 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 2
  store { i64, ptr } %t230, ptr %t241
  %t242 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 3
  store { i64, ptr } %t231, ptr %t242
  %t243 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 4
  store ptr %t232, ptr %t243
  %t244 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 5
  store ptr %t233, ptr %t244
  %t245 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 6
  store ptr %t234, ptr %t245
  %t246 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t238, i32 0, i32 7
  store ptr %t235, ptr %t246
  %t247 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  %t248 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr null, ptr %t248
  %t249 = getelementptr { ptr, ptr }, ptr %t248, i32 0, i32 1
  store ptr %t232, ptr %t249
  %t250 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr %t248, ptr %t250
  %t251 = getelementptr { ptr, ptr }, ptr %t250, i32 0, i32 1
  store ptr %t233, ptr %t251
  %t252 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr %t250, ptr %t252
  %t253 = getelementptr { ptr, ptr }, ptr %t252, i32 0, i32 1
  store ptr %t234, ptr %t253
  %t254 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 16, i64 8)
  store ptr %t252, ptr %t254
  %t255 = getelementptr { ptr, ptr }, ptr %t254, i32 0, i32 1
  store ptr %t235, ptr %t255
  %t256 = getelementptr { ptr, i64, ptr, i64 }, ptr %t247, i32 0, i32 2
  store ptr %t254, ptr %t256
  %t257 = getelementptr { ptr, i64, ptr, i64 }, ptr %t247, i32 0, i32 1
  store i64 0, ptr %t257
  %t258 = getelementptr { ptr, i64, ptr, i64 }, ptr %t247, i32 0, i32 3
  store i64 0, ptr %t258
  %t259 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t259, ptr @olang_task4, ptr %t238, ptr %t247)
  %t260 = load ptr, ptr %jh6
  store ptr %t260, ptr %t247
  store ptr %t247, ptr %jh6
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t261 = load i64, ptr %l17
  store i64 %t261, ptr %l115
  %t262 = load i64, ptr %l115
  %t263 = add i64 %t262, 1
  store i64 %t263, ptr %l116
  %t264 = load i64, ptr %l116
  store i64 %t264, ptr %l17
  call void @__olang_scope_close(ptr %s9)
  br label %bb41
bb46:
  call void @__olang_scope_close(ptr %s7)
  %t265 = load ptr, ptr %l5
  store ptr %t265, ptr %l117
  %t266 = load ptr, ptr %l117
  call void @std_2fchan_2eClose_3cI64_3e(ptr %s0, ptr %t266)
  br label %bb47
bb47:
  %t267 = call i64 @__olang_join_tasks(ptr %jh6)
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb49:
  %t268 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t268, ptr %l118
  %t269 = load { i64, ptr }, ptr %l118
  store { i64, ptr } %t269, ptr %l119
  %t270 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t270, ptr %l120
  %t271 = load { i64, ptr }, ptr %l120
  store { i64, ptr } %t271, ptr %l121
  %t272 = load { i64, ptr }, ptr %l119
  %t273 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t272, 0
  %t274 = load { i64, ptr }, ptr %l121
  %t275 = insertvalue { { i64, ptr }, { i64, ptr } } %t273, { i64, ptr } %t274, 1
  store { { i64, ptr }, { i64, ptr } } %t275, ptr %l122
  %t276 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 0
  %t277 = load { i64, ptr }, ptr %t276
  store { i64, ptr } %t277, ptr %l123
  %t278 = load { i64, ptr }, ptr %l123
  %t279 = extractvalue { i64, ptr } %t278, 0
  store i64 %t279, ptr %l124
  %t280 = load i64, ptr %l124
  %t281 = mul i64 %t280, 4
  %t282 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t281)
  %t283 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  store { i64, ptr } %t284, ptr %l125
  %t285 = getelementptr { i64, ptr }, ptr %l125, i32 0, i32 1
  %t286 = load ptr, ptr %t285
  %t287 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t288 = load ptr, ptr %t287
  %t289 = load i64, ptr %l124
  %t290 = mul i64 %t289, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t286, ptr %t288, i64 %t290, i1 false)
  %t291 = load { i64, ptr }, ptr %l125
  %t292 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 0
  store { i64, ptr } %t291, ptr %t292
  %t293 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 1
  %t294 = load { i64, ptr }, ptr %t293
  store { i64, ptr } %t294, ptr %l126
  %t295 = load { i64, ptr }, ptr %l126
  %t296 = extractvalue { i64, ptr } %t295, 0
  store i64 %t296, ptr %l127
  %t297 = load i64, ptr %l127
  %t298 = mul i64 %t297, 16
  %t299 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t298)
  %t300 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, ptr } %t301, ptr %l128
  %t302 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t303 = load ptr, ptr %t302
  %t304 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t305 = load ptr, ptr %t304
  %t306 = load i64, ptr %l127
  %t307 = mul i64 %t306, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t303, ptr %t305, i64 %t307, i1 false)
  %t308 = load { i64, ptr }, ptr %l128
  %t309 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l122, i32 0, i32 1
  store { i64, ptr } %t308, ptr %t309
  call void @__olang_scope_close(ptr %s0)
  %t310 = load { { i64, ptr }, { i64, ptr } }, ptr %l122
  store { { i64, ptr }, { i64, ptr } } %t310, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbuild_2eShaK_2einit() #0 {
entry:
  %l0 = alloca [64 x i32]
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = getelementptr [64 x i32], ptr %l0, i64 0, i64 0
  store i32 1116352408, ptr %t1
  %t2 = getelementptr [64 x i32], ptr %l0, i64 0, i64 1
  store i32 1899447441, ptr %t2
  %t3 = getelementptr [64 x i32], ptr %l0, i64 0, i64 2
  store i32 -1245643825, ptr %t3
  %t4 = getelementptr [64 x i32], ptr %l0, i64 0, i64 3
  store i32 -373957723, ptr %t4
  %t5 = getelementptr [64 x i32], ptr %l0, i64 0, i64 4
  store i32 961987163, ptr %t5
  %t6 = getelementptr [64 x i32], ptr %l0, i64 0, i64 5
  store i32 1508970993, ptr %t6
  %t7 = getelementptr [64 x i32], ptr %l0, i64 0, i64 6
  store i32 -1841331548, ptr %t7
  %t8 = getelementptr [64 x i32], ptr %l0, i64 0, i64 7
  store i32 -1424204075, ptr %t8
  %t9 = getelementptr [64 x i32], ptr %l0, i64 0, i64 8
  store i32 -670586216, ptr %t9
  %t10 = getelementptr [64 x i32], ptr %l0, i64 0, i64 9
  store i32 310598401, ptr %t10
  %t11 = getelementptr [64 x i32], ptr %l0, i64 0, i64 10
  store i32 607225278, ptr %t11
  %t12 = getelementptr [64 x i32], ptr %l0, i64 0, i64 11
  store i32 1426881987, ptr %t12
  %t13 = getelementptr [64 x i32], ptr %l0, i64 0, i64 12
  store i32 1925078388, ptr %t13
  %t14 = getelementptr [64 x i32], ptr %l0, i64 0, i64 13
  store i32 -2132889090, ptr %t14
  %t15 = getelementptr [64 x i32], ptr %l0, i64 0, i64 14
  store i32 -1680079193, ptr %t15
  %t16 = getelementptr [64 x i32], ptr %l0, i64 0, i64 15
  store i32 -1046744716, ptr %t16
  %t17 = getelementptr [64 x i32], ptr %l0, i64 0, i64 16
  store i32 -459576895, ptr %t17
  %t18 = getelementptr [64 x i32], ptr %l0, i64 0, i64 17
  store i32 -272742522, ptr %t18
  %t19 = getelementptr [64 x i32], ptr %l0, i64 0, i64 18
  store i32 264347078, ptr %t19
  %t20 = getelementptr [64 x i32], ptr %l0, i64 0, i64 19
  store i32 604807628, ptr %t20
  %t21 = getelementptr [64 x i32], ptr %l0, i64 0, i64 20
  store i32 770255983, ptr %t21
  %t22 = getelementptr [64 x i32], ptr %l0, i64 0, i64 21
  store i32 1249150122, ptr %t22
  %t23 = getelementptr [64 x i32], ptr %l0, i64 0, i64 22
  store i32 1555081692, ptr %t23
  %t24 = getelementptr [64 x i32], ptr %l0, i64 0, i64 23
  store i32 1996064986, ptr %t24
  %t25 = getelementptr [64 x i32], ptr %l0, i64 0, i64 24
  store i32 -1740746414, ptr %t25
  %t26 = getelementptr [64 x i32], ptr %l0, i64 0, i64 25
  store i32 -1473132947, ptr %t26
  %t27 = getelementptr [64 x i32], ptr %l0, i64 0, i64 26
  store i32 -1341970488, ptr %t27
  %t28 = getelementptr [64 x i32], ptr %l0, i64 0, i64 27
  store i32 -1084653625, ptr %t28
  %t29 = getelementptr [64 x i32], ptr %l0, i64 0, i64 28
  store i32 -958395405, ptr %t29
  %t30 = getelementptr [64 x i32], ptr %l0, i64 0, i64 29
  store i32 -710438585, ptr %t30
  %t31 = getelementptr [64 x i32], ptr %l0, i64 0, i64 30
  store i32 113926993, ptr %t31
  %t32 = getelementptr [64 x i32], ptr %l0, i64 0, i64 31
  store i32 338241895, ptr %t32
  %t33 = getelementptr [64 x i32], ptr %l0, i64 0, i64 32
  store i32 666307205, ptr %t33
  %t34 = getelementptr [64 x i32], ptr %l0, i64 0, i64 33
  store i32 773529912, ptr %t34
  %t35 = getelementptr [64 x i32], ptr %l0, i64 0, i64 34
  store i32 1294757372, ptr %t35
  %t36 = getelementptr [64 x i32], ptr %l0, i64 0, i64 35
  store i32 1396182291, ptr %t36
  %t37 = getelementptr [64 x i32], ptr %l0, i64 0, i64 36
  store i32 1695183700, ptr %t37
  %t38 = getelementptr [64 x i32], ptr %l0, i64 0, i64 37
  store i32 1986661051, ptr %t38
  %t39 = getelementptr [64 x i32], ptr %l0, i64 0, i64 38
  store i32 -2117940946, ptr %t39
  %t40 = getelementptr [64 x i32], ptr %l0, i64 0, i64 39
  store i32 -1838011259, ptr %t40
  %t41 = getelementptr [64 x i32], ptr %l0, i64 0, i64 40
  store i32 -1564481375, ptr %t41
  %t42 = getelementptr [64 x i32], ptr %l0, i64 0, i64 41
  store i32 -1474664885, ptr %t42
  %t43 = getelementptr [64 x i32], ptr %l0, i64 0, i64 42
  store i32 -1035236496, ptr %t43
  %t44 = getelementptr [64 x i32], ptr %l0, i64 0, i64 43
  store i32 -949202525, ptr %t44
  %t45 = getelementptr [64 x i32], ptr %l0, i64 0, i64 44
  store i32 -778901479, ptr %t45
  %t46 = getelementptr [64 x i32], ptr %l0, i64 0, i64 45
  store i32 -694614492, ptr %t46
  %t47 = getelementptr [64 x i32], ptr %l0, i64 0, i64 46
  store i32 -200395387, ptr %t47
  %t48 = getelementptr [64 x i32], ptr %l0, i64 0, i64 47
  store i32 275423344, ptr %t48
  %t49 = getelementptr [64 x i32], ptr %l0, i64 0, i64 48
  store i32 430227734, ptr %t49
  %t50 = getelementptr [64 x i32], ptr %l0, i64 0, i64 49
  store i32 506948616, ptr %t50
  %t51 = getelementptr [64 x i32], ptr %l0, i64 0, i64 50
  store i32 659060556, ptr %t51
  %t52 = getelementptr [64 x i32], ptr %l0, i64 0, i64 51
  store i32 883997877, ptr %t52
  %t53 = getelementptr [64 x i32], ptr %l0, i64 0, i64 52
  store i32 958139571, ptr %t53
  %t54 = getelementptr [64 x i32], ptr %l0, i64 0, i64 53
  store i32 1322822218, ptr %t54
  %t55 = getelementptr [64 x i32], ptr %l0, i64 0, i64 54
  store i32 1537002063, ptr %t55
  %t56 = getelementptr [64 x i32], ptr %l0, i64 0, i64 55
  store i32 1747873779, ptr %t56
  %t57 = getelementptr [64 x i32], ptr %l0, i64 0, i64 56
  store i32 1955562222, ptr %t57
  %t58 = getelementptr [64 x i32], ptr %l0, i64 0, i64 57
  store i32 2024104815, ptr %t58
  %t59 = getelementptr [64 x i32], ptr %l0, i64 0, i64 58
  store i32 -2067236844, ptr %t59
  %t60 = getelementptr [64 x i32], ptr %l0, i64 0, i64 59
  store i32 -1933114872, ptr %t60
  %t61 = getelementptr [64 x i32], ptr %l0, i64 0, i64 60
  store i32 -1866530822, ptr %t61
  %t62 = getelementptr [64 x i32], ptr %l0, i64 0, i64 61
  store i32 -1538233109, ptr %t62
  %t63 = getelementptr [64 x i32], ptr %l0, i64 0, i64 62
  store i32 -1090935817, ptr %t63
  %t64 = getelementptr [64 x i32], ptr %l0, i64 0, i64 63
  store i32 -965641998, ptr %t64
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fbuild_2eShaK, ptr %l0, i64 256, i1 false)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 1, ptr @.d5 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t5, ptr %l4
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t6 = load { i64, ptr }, ptr %l4
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l5
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t15, ptr %l3
  br label %bb4
bb3:
  %t16 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t16, ptr %l6
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t17 = extractvalue { i64, ptr } { i64 2, ptr @.d6 }, 1
  %t18 = extractvalue { i64, ptr } { i64 2, ptr @.d6 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t17, i64 %t18)
  %t19 = load { i64, ptr }, ptr %l6
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  call void @__olang_sb_put(ptr %s2, ptr %t20, i64 %t21)
  %t22 = load ptr, ptr %s2
  %t23 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t24 = load i64, ptr %t23
  %t25 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t22, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l7
  call void @__olang_sb_done(ptr %s2)
  %t28 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t28, ptr %l3
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i32
  %l19 = alloca i1
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i32
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l47 = alloca i1
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = icmp eq i32 %t2, 1
  store i1 %t3, ptr %l3
  %t4 = load i1, ptr %l3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 6, ptr @.d7 }, ptr %l4
  %t5 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t5, ptr %l5
  %t6 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t6, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb57
bb4:
  %t7 = load i32, ptr %l0
  store i32 %t7, ptr %l6
  %t8 = load i32, ptr %l6
  %t9 = icmp eq i32 %t8, 2
  store i1 %t9, ptr %l7
  %t10 = load i1, ptr %l7
  br i1 %t10, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 9, ptr @.d8 }, ptr %l8
  %t11 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t11, ptr %l9
  %t12 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t12, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb57
bb8:
  %t13 = load i32, ptr %l0
  store i32 %t13, ptr %l10
  %t14 = load i32, ptr %l10
  %t15 = icmp eq i32 %t14, 3
  store i1 %t15, ptr %l11
  %t16 = load i1, ptr %l11
  br i1 %t16, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 4, ptr @.d9 }, ptr %l12
  %t17 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t17, ptr %l13
  %t18 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t18, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb12:
  %t19 = load i32, ptr %l0
  store i32 %t19, ptr %l14
  %t20 = load i32, ptr %l14
  %t21 = icmp eq i32 %t20, 4
  store i1 %t21, ptr %l15
  %t22 = load i1, ptr %l15
  br i1 %t22, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 19, ptr @.d10 }, ptr %l16
  %t23 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t23, ptr %l17
  %t24 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t24, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb57
bb16:
  %t25 = load i32, ptr %l0
  store i32 %t25, ptr %l18
  %t26 = load i32, ptr %l18
  %t27 = icmp eq i32 %t26, 5
  store i1 %t27, ptr %l19
  %t28 = load i1, ptr %l19
  br i1 %t28, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  store { i64, ptr } { i64 21, ptr @.d11 }, ptr %l20
  %t29 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t29, ptr %l21
  %t30 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t30, ptr %l1
  call void @__olang_scope_close(ptr %s5)
  br label %bb57
bb20:
  %t31 = load i32, ptr %l0
  store i32 %t31, ptr %l22
  %t32 = load i32, ptr %l22
  %t33 = icmp eq i32 %t32, 6
  store i1 %t33, ptr %l23
  %t34 = load i1, ptr %l23
  br i1 %t34, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  store { i64, ptr } { i64 7, ptr @.d12 }, ptr %l24
  %t35 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t35, ptr %l25
  %t36 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t36, ptr %l1
  call void @__olang_scope_close(ptr %s6)
  br label %bb57
bb24:
  %t37 = load i32, ptr %l0
  store i32 %t37, ptr %l26
  %t38 = load i32, ptr %l26
  %t39 = icmp eq i32 %t38, 7
  store i1 %t39, ptr %l27
  %t40 = load i1, ptr %l27
  br i1 %t40, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s7
  store { i64, ptr } { i64 9, ptr @.d13 }, ptr %l28
  %t41 = load { i64, ptr }, ptr %l28
  store { i64, ptr } %t41, ptr %l29
  %t42 = load { i64, ptr }, ptr %l29
  store { i64, ptr } %t42, ptr %l1
  call void @__olang_scope_close(ptr %s7)
  br label %bb57
bb28:
  %t43 = load i32, ptr %l0
  store i32 %t43, ptr %l30
  %t44 = load i32, ptr %l30
  %t45 = icmp eq i32 %t44, 8
  store i1 %t45, ptr %l31
  %t46 = load i1, ptr %l31
  br i1 %t46, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s8
  store { i64, ptr } { i64 24, ptr @.d14 }, ptr %l32
  %t47 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t47, ptr %l33
  %t48 = load { i64, ptr }, ptr %l33
  store { i64, ptr } %t48, ptr %l1
  call void @__olang_scope_close(ptr %s8)
  br label %bb57
bb32:
  %t49 = load i32, ptr %l0
  store i32 %t49, ptr %l34
  %t50 = load i32, ptr %l34
  %t51 = icmp eq i32 %t50, 9
  store i1 %t51, ptr %l35
  %t52 = load i1, ptr %l35
  br i1 %t52, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s9
  store { i64, ptr } { i64 6, ptr @.d15 }, ptr %l36
  %t53 = load { i64, ptr }, ptr %l36
  store { i64, ptr } %t53, ptr %l37
  %t54 = load { i64, ptr }, ptr %l37
  store { i64, ptr } %t54, ptr %l1
  call void @__olang_scope_close(ptr %s9)
  br label %bb57
bb36:
  %t55 = load i32, ptr %l0
  store i32 %t55, ptr %l38
  %t56 = load i32, ptr %l38
  %t57 = icmp eq i32 %t56, 11
  store i1 %t57, ptr %l39
  %t58 = load i1, ptr %l39
  br i1 %t58, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store %olang.scope zeroinitializer, ptr %s10
  store { i64, ptr } { i64 18, ptr @.d16 }, ptr %l40
  %t59 = load { i64, ptr }, ptr %l40
  store { i64, ptr } %t59, ptr %l41
  %t60 = load { i64, ptr }, ptr %l41
  store { i64, ptr } %t60, ptr %l1
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb40:
  %t61 = load i32, ptr %l0
  store i32 %t61, ptr %l42
  %t62 = load i32, ptr %l42
  %t63 = icmp eq i32 %t62, 13
  store i1 %t63, ptr %l43
  %t64 = load i1, ptr %l43
  br i1 %t64, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s11
  store { i64, ptr } { i64 11, ptr @.d17 }, ptr %l44
  %t65 = load { i64, ptr }, ptr %l44
  store { i64, ptr } %t65, ptr %l45
  %t66 = load { i64, ptr }, ptr %l45
  store { i64, ptr } %t66, ptr %l1
  call void @__olang_scope_close(ptr %s11)
  br label %bb57
bb44:
  %t67 = load i32, ptr %l0
  store i32 %t67, ptr %l46
  %t68 = load i32, ptr %l46
  %t69 = icmp eq i32 %t68, 14
  store i1 %t69, ptr %l47
  %t70 = load i1, ptr %l47
  br i1 %t70, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s12
  store { i64, ptr } { i64 11, ptr @.d18 }, ptr %l48
  %t71 = load { i64, ptr }, ptr %l48
  store { i64, ptr } %t71, ptr %l49
  %t72 = load { i64, ptr }, ptr %l49
  store { i64, ptr } %t72, ptr %l1
  call void @__olang_scope_close(ptr %s12)
  br label %bb57
bb48:
  %t73 = load i32, ptr %l0
  store i32 %t73, ptr %l50
  %t74 = load i32, ptr %l50
  %t75 = icmp eq i32 %t74, 15
  store i1 %t75, ptr %l51
  %t76 = load i1, ptr %l51
  br i1 %t76, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s13
  store { i64, ptr } { i64 10, ptr @.d19 }, ptr %l52
  %t77 = load { i64, ptr }, ptr %l52
  store { i64, ptr } %t77, ptr %l53
  %t78 = load { i64, ptr }, ptr %l53
  store { i64, ptr } %t78, ptr %l1
  call void @__olang_scope_close(ptr %s13)
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s14
  %t79 = load i32, ptr %l0
  store i32 %t79, ptr %l54
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t80 = extractvalue { i64, ptr } { i64 15, ptr @.d20 }, 1
  %t81 = extractvalue { i64, ptr } { i64 15, ptr @.d20 }, 0
  call void @__olang_sb_put(ptr %s15, ptr %t80, i64 %t81)
  %t82 = load i32, ptr %l54
  %t83 = sext i32 %t82 to i64
  %t84 = call ptr @__olang_sb_room(ptr %s15, i64 24)
  %t85 = call i64 @__olang_fmt_i64(ptr %t84, i64 %t83)
  call void @__olang_sb_add(ptr %s15, i64 %t85)
  %t86 = load ptr, ptr %s15
  %t87 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t88 = load i64, ptr %t87
  %t89 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t86, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  store { i64, ptr } %t91, ptr %l55
  call void @__olang_sb_done(ptr %s15)
  %t92 = load { i64, ptr }, ptr %l55
  store { i64, ptr } %t92, ptr %l1
  call void @__olang_scope_close(ptr %s14)
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c21)
  unreachable
bb57:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t93, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i1
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca %"std/os:Output"
  %l52 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"std/os:Output"
  %l56 = alloca i32
  %l57 = alloca i32
  %l58 = alloca i1
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %l65 = alloca i32
  %l66 = alloca i1
  %l67 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l69 = alloca i32
  %l70 = alloca i32
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l77 = alloca i1
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i1
  %l81 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 false, ptr %l4
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t1, ptr %l15
  %t2 = load { i64, ptr }, ptr %l15
  store { i64, ptr } %t2, ptr %l5
  store i64 0, ptr %l6
  %t3 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t3, ptr %l16
  %t4 = load { i64, ptr }, ptr %l16
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l17
  %t6 = load i64, ptr %l17
  store i64 %t6, ptr %l7
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l6
  store i64 %t7, ptr %l18
  %t8 = load i64, ptr %l7
  store i64 %t8, ptr %l19
  %t9 = load i64, ptr %l18
  %t10 = load i64, ptr %l19
  %t11 = icmp slt i64 %t9, %t10
  store i1 %t11, ptr %l20
  %t12 = load i1, ptr %l20
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l21
  %t14 = load i1, ptr %l21
  br i1 %t14, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t15, ptr %l22
  %t16 = load i64, ptr %l6
  store i64 %t16, ptr %l23
  %t17 = load i64, ptr %l23
  %t18 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t19 = load ptr, ptr %t18
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t17
  %t21 = load { i64, ptr }, ptr %t20
  store { i64, ptr } %t21, ptr %l24
  %t22 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t22, ptr %l8
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t23)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t24, ptr %l25
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l25
  store %"std/prelude/list:List<std/prelude/text:String&>" %t25, ptr %l9
  store ptr %l9, ptr %l26
  %t26 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t26, ptr %l27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t27 = load { i64, ptr }, ptr %l27
  %t28 = extractvalue { i64, ptr } %t27, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  call void @__olang_sb_put(ptr %s3, ptr %t28, i64 %t29)
  %t30 = load ptr, ptr %s3
  %t31 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t32 = load i64, ptr %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t30, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l28
  call void @__olang_sb_done(ptr %s3)
  %t36 = load { i64, ptr }, ptr %l28
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l29
  %t43 = load ptr, ptr %l26
  %t44 = load { i64, ptr }, ptr %l29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t43, { i64, ptr } %t44)
  br label %bb6
bb6:
  store ptr %l9, ptr %l30
  %t45 = load ptr, ptr %l30
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t45, { i64, ptr } { i64 4, ptr @.d22 })
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t46 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t46, ptr %l31
  %t47 = load { i64, ptr }, ptr %l31
  store { i64, ptr } %t47, ptr %l10
  store i64 0, ptr %l11
  %t48 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t48, ptr %l32
  %t49 = load { i64, ptr }, ptr %l32
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l33
  %t51 = load i64, ptr %l33
  store i64 %t51, ptr %l12
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s5
  %t52 = load i64, ptr %l11
  store i64 %t52, ptr %l34
  %t53 = load i64, ptr %l12
  store i64 %t53, ptr %l35
  %t54 = load i64, ptr %l34
  %t55 = load i64, ptr %l35
  %t56 = icmp slt i64 %t54, %t55
  store i1 %t56, ptr %l36
  %t57 = load i1, ptr %l36
  %t58 = xor i1 %t57, true
  store i1 %t58, ptr %l37
  %t59 = load i1, ptr %l37
  br i1 %t59, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t60 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t60, ptr %l38
  %t61 = load i64, ptr %l11
  store i64 %t61, ptr %l39
  %t62 = load i64, ptr %l39
  %t63 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t64 = load ptr, ptr %t63
  %t65 = getelementptr { i64, ptr }, ptr %t64, i64 %t62
  %t66 = load { i64, ptr }, ptr %t65
  store { i64, ptr } %t66, ptr %l40
  %t67 = load { i64, ptr }, ptr %l40
  store { i64, ptr } %t67, ptr %l13
  store ptr %l9, ptr %l41
  %t68 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t68, ptr %l42
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t69 = load { i64, ptr }, ptr %l42
  %t70 = extractvalue { i64, ptr } %t69, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  call void @__olang_sb_put(ptr %s6, ptr %t70, i64 %t71)
  %t72 = load ptr, ptr %s6
  %t73 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t74 = load i64, ptr %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t72, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l43
  call void @__olang_sb_done(ptr %s6)
  %t78 = load { i64, ptr }, ptr %l43
  %t79 = extractvalue { i64, ptr } %t78, 0
  %t80 = extractvalue { i64, ptr } %t78, 1
  %t81 = mul i64 %t79, 1
  %t82 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t81)
  call void @llvm.memcpy.p0.p0.i64(ptr %t82, ptr %t80, i64 %t81, i1 false)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t82, 1
  store { i64, ptr } %t84, ptr %l44
  %t85 = load ptr, ptr %l41
  %t86 = load { i64, ptr }, ptr %l44
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t85, { i64, ptr } %t86)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s7
  %t87 = load i64, ptr %l11
  store i64 %t87, ptr %l45
  %t88 = load i64, ptr %l45
  %t89 = add i64 %t88, 1
  store i64 %t89, ptr %l46
  %t90 = load i64, ptr %l46
  store i64 %t90, ptr %l11
  call void @__olang_scope_close(ptr %s7)
  br label %bb8
bb14:
  call void @__olang_scope_close(ptr %s4)
  store ptr %l9, ptr %l47
  %t91 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t91, ptr %l48
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t92 = load { i64, ptr }, ptr %l48
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  call void @__olang_sb_put(ptr %s8, ptr %t93, i64 %t94)
  %t95 = load ptr, ptr %s8
  %t96 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t97 = load i64, ptr %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t97)
  call void @llvm.memcpy.p0.p0.i64(ptr %t98, ptr %t95, i64 %t97, i1 false)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l49
  call void @__olang_sb_done(ptr %s8)
  %t101 = load { i64, ptr }, ptr %l49
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  store { i64, ptr } %t107, ptr %l50
  %t108 = load ptr, ptr %l47
  %t109 = load { i64, ptr }, ptr %l50
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %t108, { i64, ptr } %t109)
  br label %bb15
bb15:
  store ptr %l9, ptr %l52
  %t110 = load ptr, ptr %l52
  %t111 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s2, ptr %s2, ptr %t110)
  store { i64, ptr } %t111, ptr %l53
  br label %bb16
bb16:
  store { i64, ptr } { i64 0, ptr @.d23 }, ptr %l54
  %t112 = load { i64, ptr }, ptr %l53
  %t113 = load { i64, ptr }, ptr %l54
  %t114 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t112, { i64, ptr } %t113, i1 false, { i64, ptr } { i64 0, ptr @.d24 })
  %t115 = extractvalue { i32, %"std/os:Output" } %t114, 1
  %t116 = extractvalue { i32, %"std/os:Output" } %t114, 0
  store i32 %t116, ptr %l56
  %t117 = icmp ne i32 %t116, 0
  br i1 %t117, label %bb18, label %ok.118
ok.118:
  store %"std/os:Output" %t115, ptr %l55
  br label %bb17
bb17:
  %t119 = load %"std/os:Output", ptr %l55
  store %"std/os:Output" %t119, ptr %l51
  br label %bb24
bb18:
  %t120 = load i32, ptr %l56
  %t121 = ashr i32 %t120, 16
  store i32 %t121, ptr %l57
  %t122 = load i32, ptr %l57
  %t123 = icmp eq i32 %t122, 1
  store i1 %t123, ptr %l58
  %t124 = load i1, ptr %l58
  br i1 %t124, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c25)
  unreachable
bb21:
  store %olang.scope zeroinitializer, ptr %s9
  %t125 = load ptr, ptr %l0
  store ptr %t125, ptr %l59
  %t126 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t126, ptr %l60
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t127 = load { i64, ptr }, ptr %l60
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  call void @__olang_sb_put(ptr %s10, ptr %t128, i64 %t129)
  %t130 = extractvalue { i64, ptr } { i64 35, ptr @.d26 }, 1
  %t131 = extractvalue { i64, ptr } { i64 35, ptr @.d26 }, 0
  call void @__olang_sb_put(ptr %s10, ptr %t130, i64 %t131)
  %t132 = load ptr, ptr %s10
  %t133 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t134 = load i64, ptr %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t134)
  call void @llvm.memcpy.p0.p0.i64(ptr %t135, ptr %t132, i64 %t134, i1 false)
  %t136 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l61
  call void @__olang_sb_done(ptr %s10)
  %t138 = load { i64, ptr }, ptr %l61
  %t139 = extractvalue { i64, ptr } %t138, 0
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  store { i64, ptr } %t144, ptr %l62
  %t145 = load ptr, ptr %l59
  %t146 = load { i64, ptr }, ptr %l62
  %t147 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %t145, { i64, ptr } { i64 2, ptr @.d27 }, { i64, ptr } %t146)
  store { i64, ptr } %t147, ptr %l63
  br label %bb22
bb22:
  %t148 = load { i64, ptr }, ptr %l63
  %t149 = extractvalue { i64, ptr } %t148, 0
  %t150 = extractvalue { i64, ptr } %t148, 1
  %t151 = mul i64 %t149, 1
  %t152 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t150, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l64
  %t155 = load { i64, ptr }, ptr %l64
  call void @compiler_2fbuild_2esayln(ptr %s9, { i64, ptr } %t155)
  br label %bb23
bb23:
  store i1 true, ptr %l4
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb24:
  %t156 = load %"std/os:Output", ptr %l51
  store %"std/os:Output" %t156, ptr %l14
  %t157 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t158 = load i32, ptr %t157
  store i32 %t158, ptr %l65
  %t159 = load i32, ptr %l65
  %t160 = icmp sgt i32 %t159, 128
  store i1 %t160, ptr %l66
  %t161 = load i1, ptr %l66
  br i1 %t161, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s11
  %t162 = load ptr, ptr %l0
  store ptr %t162, ptr %l67
  %t163 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t163, ptr %l68
  %t164 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t165 = load i32, ptr %t164
  store i32 %t165, ptr %l69
  %t166 = load i32, ptr %l69
  %t167 = sub i32 %t166, 128
  store i32 %t167, ptr %l70
  %t168 = load i32, ptr %l70
  %t169 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t168)
  store { i64, ptr } %t169, ptr %l71
  br label %bb27
bb26:
  br label %bb30
bb27:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t170 = load { i64, ptr }, ptr %l68
  %t171 = extractvalue { i64, ptr } %t170, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  call void @__olang_sb_put(ptr %s12, ptr %t171, i64 %t172)
  %t173 = extractvalue { i64, ptr } { i64 22, ptr @.d28 }, 1
  %t174 = extractvalue { i64, ptr } { i64 22, ptr @.d28 }, 0
  call void @__olang_sb_put(ptr %s12, ptr %t173, i64 %t174)
  %t175 = load { i64, ptr }, ptr %l71
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  call void @__olang_sb_put(ptr %s12, ptr %t176, i64 %t177)
  %t178 = extractvalue { i64, ptr } { i64 11, ptr @.d29 }, 1
  %t179 = extractvalue { i64, ptr } { i64 11, ptr @.d29 }, 0
  call void @__olang_sb_put(ptr %s12, ptr %t178, i64 %t179)
  %t180 = load ptr, ptr %s12
  %t181 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t182 = load i64, ptr %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t180, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  store { i64, ptr } %t185, ptr %l72
  call void @__olang_sb_done(ptr %s12)
  %t186 = load { i64, ptr }, ptr %l72
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l73
  %t193 = load ptr, ptr %l67
  %t194 = load { i64, ptr }, ptr %l73
  %t195 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %t193, { i64, ptr } { i64 2, ptr @.d30 }, { i64, ptr } %t194)
  store { i64, ptr } %t195, ptr %l74
  br label %bb28
bb28:
  %t196 = load { i64, ptr }, ptr %l74
  %t197 = extractvalue { i64, ptr } %t196, 0
  %t198 = extractvalue { i64, ptr } %t196, 1
  %t199 = mul i64 %t197, 1
  %t200 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t199)
  call void @llvm.memcpy.p0.p0.i64(ptr %t200, ptr %t198, i64 %t199, i1 false)
  %t201 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t202 = insertvalue { i64, ptr } %t201, ptr %t200, 1
  store { i64, ptr } %t202, ptr %l75
  %t203 = load { i64, ptr }, ptr %l75
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t203)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s11)
  br label %bb30
bb30:
  %t204 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t205 = load i32, ptr %t204
  store i32 %t205, ptr %l76
  %t206 = load i32, ptr %l76
  %t207 = icmp ne i32 %t206, 0
  store i1 %t207, ptr %l77
  %t208 = load i1, ptr %l77
  br i1 %t208, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s13
  store i1 true, ptr %l4
  call void @__olang_scope_close(ptr %s13)
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s14
  %t209 = load i64, ptr %l6
  store i64 %t209, ptr %l78
  %t210 = load i64, ptr %l78
  %t211 = add i64 %t210, 1
  store i64 %t211, ptr %l79
  %t212 = load i64, ptr %l79
  store i64 %t212, ptr %l6
  call void @__olang_scope_close(ptr %s14)
  br label %bb1
bb35:
  call void @__olang_scope_close(ptr %s1)
  %t213 = load i1, ptr %l4
  store i1 %t213, ptr %l80
  %t214 = load i1, ptr %l80
  br i1 %t214, label %bb36, label %bb37
bb36:
  store i32 1, ptr %l81
  br label %bb38
bb37:
  store i32 0, ptr %l81
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t215 = load i32, ptr %l81
  store i32 %t215, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t2 = extractvalue { i64, ptr } { i64 62, ptr @.d31 }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr @.d31 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t2, i64 %t3)
  %t4 = load { i64, ptr }, ptr %l1
  %t5 = extractvalue { i64, ptr } %t4, 1
  %t6 = extractvalue { i64, ptr } %t4, 0
  call void @__olang_sb_put(ptr %s1, ptr %t5, i64 %t6)
  %t7 = load ptr, ptr %s1
  %t8 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t9 = load i64, ptr %t8
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t7, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l2
  call void @__olang_sb_done(ptr %s1)
  %t13 = load { i64, ptr }, ptr %l2
  %t14 = extractvalue { i64, ptr } %t13, 0
  %t15 = extractvalue { i64, ptr } %t13, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  store { i64, ptr } %t19, ptr %l3
  %t20 = load { i64, ptr }, ptr %l3
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t20)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %lp2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l5 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = call %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v2, ptr %t2)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l4
  %t6 = load ptr, ptr %lp2
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %t6
  %t7 = load ptr, ptr %l0
  store ptr %t7, ptr %l5
  %t8 = load ptr, ptr %l5
  %t9 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 4
  %t10 = load i1, ptr %t9
  store i1 %t10, ptr %l6
  %t11 = load i1, ptr %l6
  br i1 %t11, label %bb2, label %bb3
bb2:
  %t12 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t12, ptr %l8
  %t13 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t13, ptr %l9
  store { i64, ptr } { i64 6, ptr @.d32 }, ptr %l10
  %t14 = load { i64, ptr }, ptr %l9
  %t15 = load { i64, ptr }, ptr %l10
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %t14, { i64, ptr } %t15)
  store i1 %t16, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7
  br label %bb5
bb4:
  %t17 = load i1, ptr %l11
  store i1 %t17, ptr %l7
  br label %bb5
bb5:
  %t18 = load i1, ptr %l7
  br i1 %t18, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %lp2
  store ptr %t19, ptr %l12
  %t20 = load ptr, ptr %l12
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t20, { i64, ptr } { i64 6, ptr @.d33 })
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %lp2
  store ptr %t21, ptr %l13
  %t22 = load ptr, ptr %l13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t22, { i64, ptr } { i64 16, ptr @.d34 })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t23 = load ptr, ptr %lp2
  %t24 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t23
  store %"std/prelude/list:List<std/prelude/text:String&>" %t24, ptr %l14
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l14
  store %"std/prelude/list:List<std/prelude/text:String&>" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/os:Output"
  %l27 = alloca %"std/os:FileInfo"
  %l28 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca { i64, ptr }
  %l52 = alloca i64
  %l53 = alloca { i64, ptr }
  %l54 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca { i64, ptr }
  %l73 = alloca i32
  %l74 = alloca i32
  %l75 = alloca i1
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca { i64, ptr }
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca ptr
  %l96 = alloca ptr
  %l97 = alloca ptr
  %l98 = alloca i1
  %l99 = alloca ptr
  %l100 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l101 = alloca ptr
  %l102 = alloca { i64, ptr }
  %l103 = alloca ptr
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %l106 = alloca i32
  %l107 = alloca i32
  %l108 = alloca i1
  %l109 = alloca i32
  %l110 = alloca { i64, ptr }
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i1
  %l115 = alloca i1
  %l116 = alloca { i64, ptr }
  %l117 = alloca i64
  %l118 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca ptr
  %l127 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca i1
  %l141 = alloca i32
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l144 = alloca i1
  %l145 = alloca i32
  %l146 = alloca %"std/os:Output"
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca %"std/os:Output"
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i1
  %l154 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i32
  %l157 = alloca i1
  %l158 = alloca i32
  %l159 = alloca ptr
  %l160 = alloca i64
  %l161 = alloca i64
  %l162 = alloca %"std/os:FileInfo"
  %l163 = alloca { i64, ptr }
  %l164 = alloca %"std/os:FileInfo"
  %l165 = alloca i32
  %l166 = alloca i32
  %l167 = alloca i1
  %l168 = alloca i32
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i64
  %l172 = alloca i64
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l176 = alloca i32
  %l177 = alloca i32
  %l178 = alloca i1
  %l179 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.builder
  %s18room = alloca [64 x i8], align 8
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %s25 = alloca %olang.builder
  %s25room = alloca [64 x i8], align 8
  %s26 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l28
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l28
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l4
  store ptr %l4, ptr %l29
  %t4 = load ptr, ptr %l0
  store ptr %t4, ptr %l30
  %t5 = load ptr, ptr %l30
  %t6 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6
  store { i64, ptr } %t7, ptr %l31
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t8 = load { i64, ptr }, ptr %l31
  %t9 = extractvalue { i64, ptr } %t8, 1
  %t10 = extractvalue { i64, ptr } %t8, 0
  call void @__olang_sb_put(ptr %s1, ptr %t9, i64 %t10)
  %t11 = load ptr, ptr %s1
  %t12 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t13 = load i64, ptr %t12
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t11, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l32
  call void @__olang_sb_done(ptr %s1)
  %t17 = load { i64, ptr }, ptr %l32
  %t18 = extractvalue { i64, ptr } %t17, 0
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = mul i64 %t18, 1
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @llvm.memcpy.p0.p0.i64(ptr %t21, ptr %t19, i64 %t20, i1 false)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l33
  %t24 = load ptr, ptr %l29
  %t25 = load { i64, ptr }, ptr %l33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t24, { i64, ptr } %t25)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t26 = load ptr, ptr %l0
  store ptr %t26, ptr %l34
  %t27 = load ptr, ptr %l34
  %t28 = call %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s2, ptr %t27)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t28, ptr %l35
  br label %bb3
bb3:
  %t29 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l35
  %t30 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t29, ptr %t30
  store ptr %t30, ptr %l36
  %t31 = load ptr, ptr %l36
  store ptr %t31, ptr %l5
  store i64 0, ptr %l6
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t32 = load ptr, ptr %l5
  store ptr %t32, ptr %l38
  %t33 = load i64, ptr %l6
  store i64 %t33, ptr %l39
  %t34 = load ptr, ptr %l38
  %t35 = load i64, ptr %l39
  %t36 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s2, ptr %t34, i64 %t35)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l41
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb6, label %ok.40
ok.40:
  store { i64, ptr } %t37, ptr %l40
  br label %bb5
bb5:
  %t41 = load { i64, ptr }, ptr %l40
  store { i64, ptr } %t41, ptr %l37
  br label %bb10
bb6:
  %t42 = load i32, ptr %l41
  %t43 = ashr i32 %t42, 16
  store i32 %t43, ptr %l42
  %t44 = load i32, ptr %l42
  %t45 = icmp eq i32 %t44, 1
  store i1 %t45, ptr %l43
  %t46 = load i1, ptr %l43
  br i1 %t46, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  %t47 = load i32, ptr %l41
  %t48 = lshr i32 %t47, 16
  %t49 = and i32 %t47, 65535
  %t50 = icmp eq i32 %t48, 1
  %t51 = select i1 %t50, i32 0, i32 0
  %t52 = icmp eq i32 %t47, 0
  %t53 = shl i32 %t51, 16
  %t54 = or i32 %t53, %t49
  %t55 = select i1 %t52, i32 0, i32 %t54
  store i32 %t55, ptr %l44
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t56 = load i32, ptr %l44
  store i32 %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb10:
  %t57 = load { i64, ptr }, ptr %l37
  store { i64, ptr } %t57, ptr %l7
  %t58 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t58, ptr %l45
  %t59 = load { i64, ptr }, ptr %l45
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l46
  %t61 = load i64, ptr %l46
  store i64 %t61, ptr %l8
  store i64 0, ptr %l9
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t62 = load i64, ptr %l9
  store i64 %t62, ptr %l47
  %t63 = load i64, ptr %l8
  store i64 %t63, ptr %l48
  %t64 = load i64, ptr %l47
  %t65 = load i64, ptr %l48
  %t66 = icmp slt i64 %t64, %t65
  store i1 %t66, ptr %l49
  %t67 = load i1, ptr %l49
  %t68 = xor i1 %t67, true
  store i1 %t68, ptr %l50
  %t69 = load i1, ptr %l50
  br i1 %t69, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t70 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t70, ptr %l51
  %t71 = load i64, ptr %l9
  store i64 %t71, ptr %l52
  %t72 = load i64, ptr %l52
  %t73 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  %t75 = getelementptr { i64, ptr }, ptr %t74, i64 %t72
  %t76 = load { i64, ptr }, ptr %t75
  store { i64, ptr } %t76, ptr %l53
  %t77 = load { i64, ptr }, ptr %l53
  store { i64, ptr } %t77, ptr %l10
  store ptr %l4, ptr %l54
  %t78 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t78, ptr %l55
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t79 = load { i64, ptr }, ptr %l55
  %t80 = extractvalue { i64, ptr } %t79, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  call void @__olang_sb_put(ptr %s5, ptr %t80, i64 %t81)
  %t82 = load ptr, ptr %s5
  %t83 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t84 = load i64, ptr %t83
  %t85 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t82, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  store { i64, ptr } %t87, ptr %l56
  call void @__olang_sb_done(ptr %s5)
  %t88 = load { i64, ptr }, ptr %l56
  %t89 = extractvalue { i64, ptr } %t88, 0
  %t90 = extractvalue { i64, ptr } %t88, 1
  %t91 = mul i64 %t89, 1
  %t92 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t91)
  call void @llvm.memcpy.p0.p0.i64(ptr %t92, ptr %t90, i64 %t91, i1 false)
  %t93 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t92, 1
  store { i64, ptr } %t94, ptr %l57
  %t95 = load ptr, ptr %l54
  %t96 = load { i64, ptr }, ptr %l57
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t95, { i64, ptr } %t96)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t97 = load i64, ptr %l9
  store i64 %t97, ptr %l58
  %t98 = load i64, ptr %l58
  %t99 = add i64 %t98, 1
  store i64 %t99, ptr %l59
  %t100 = load i64, ptr %l59
  store i64 %t100, ptr %l9
  call void @__olang_scope_close(ptr %s6)
  br label %bb11
bb17:
  %t101 = load i64, ptr %l6
  store i64 %t101, ptr %l60
  %t102 = load i64, ptr %l8
  store i64 %t102, ptr %l61
  %t103 = load i64, ptr %l60
  %t104 = load i64, ptr %l61
  %t105 = add i64 %t103, %t104
  store i64 %t105, ptr %l62
  %t106 = load i64, ptr %l62
  store i64 %t106, ptr %l6
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb4
bb19:
  call void @__olang_scope_close(ptr %s2)
  store ptr %l4, ptr %l63
  %t107 = load ptr, ptr %l63
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t107, { i64, ptr } { i64 2, ptr @.d35 })
  br label %bb20
bb20:
  store ptr %l4, ptr %l64
  %t108 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t108, ptr %l65
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t109 = load { i64, ptr }, ptr %l65
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  call void @__olang_sb_put(ptr %s7, ptr %t110, i64 %t111)
  %t112 = load ptr, ptr %s7
  %t113 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t114 = load i64, ptr %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t112, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  store { i64, ptr } %t117, ptr %l66
  call void @__olang_sb_done(ptr %s7)
  %t118 = load { i64, ptr }, ptr %l66
  %t119 = extractvalue { i64, ptr } %t118, 0
  %t120 = extractvalue { i64, ptr } %t118, 1
  %t121 = mul i64 %t119, 1
  %t122 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t121)
  call void @llvm.memcpy.p0.p0.i64(ptr %t122, ptr %t120, i64 %t121, i1 false)
  %t123 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t124 = insertvalue { i64, ptr } %t123, ptr %t122, 1
  store { i64, ptr } %t124, ptr %l67
  %t125 = load ptr, ptr %l64
  %t126 = load { i64, ptr }, ptr %l67
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t125, { i64, ptr } %t126)
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s8
  %t127 = load ptr, ptr %l1
  store ptr %t127, ptr %l68
  %t128 = load ptr, ptr %l68
  store ptr %t128, ptr %l11
  store i64 0, ptr %l12
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s9
  %t129 = load ptr, ptr %l11
  store ptr %t129, ptr %l70
  %t130 = load i64, ptr %l12
  store i64 %t130, ptr %l71
  %t131 = load ptr, ptr %l70
  %t132 = load i64, ptr %l71
  %t133 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t131, i64 %t132)
  %t134 = extractvalue { i32, { i64, ptr } } %t133, 1
  %t135 = extractvalue { i32, { i64, ptr } } %t133, 0
  store i32 %t135, ptr %l73
  %t136 = icmp ne i32 %t135, 0
  br i1 %t136, label %bb24, label %ok.137
ok.137:
  store { i64, ptr } %t134, ptr %l72
  br label %bb23
bb23:
  %t138 = load { i64, ptr }, ptr %l72
  store { i64, ptr } %t138, ptr %l69
  br label %bb28
bb24:
  %t139 = load i32, ptr %l73
  %t140 = ashr i32 %t139, 16
  store i32 %t140, ptr %l74
  %t141 = load i32, ptr %l74
  %t142 = icmp eq i32 %t141, 1
  store i1 %t142, ptr %l75
  %t143 = load i1, ptr %l75
  br i1 %t143, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  %t144 = load i32, ptr %l73
  %t145 = lshr i32 %t144, 16
  %t146 = and i32 %t144, 65535
  %t147 = icmp eq i32 %t145, 1
  %t148 = select i1 %t147, i32 0, i32 0
  %t149 = icmp eq i32 %t144, 0
  %t150 = shl i32 %t148, 16
  %t151 = or i32 %t150, %t146
  %t152 = select i1 %t149, i32 0, i32 %t151
  store i32 %t152, ptr %l76
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t153 = load i32, ptr %l76
  store i32 %t153, ptr %rv
  br label %ret
bb27:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb28:
  %t154 = load { i64, ptr }, ptr %l69
  store { i64, ptr } %t154, ptr %l13
  %t155 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t155, ptr %l77
  %t156 = load { i64, ptr }, ptr %l77
  %t157 = extractvalue { i64, ptr } %t156, 0
  store i64 %t157, ptr %l78
  %t158 = load i64, ptr %l78
  store i64 %t158, ptr %l14
  store i64 0, ptr %l15
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s10
  %t159 = load i64, ptr %l15
  store i64 %t159, ptr %l79
  %t160 = load i64, ptr %l14
  store i64 %t160, ptr %l80
  %t161 = load i64, ptr %l79
  %t162 = load i64, ptr %l80
  %t163 = icmp slt i64 %t161, %t162
  store i1 %t163, ptr %l81
  %t164 = load i1, ptr %l81
  %t165 = xor i1 %t164, true
  store i1 %t165, ptr %l82
  %t166 = load i1, ptr %l82
  br i1 %t166, label %bb30, label %bb31
bb30:
  call void @__olang_scope_close(ptr %s10)
  br label %bb35
bb31:
  br label %bb32
bb32:
  %t167 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t167, ptr %l83
  %t168 = load i64, ptr %l15
  store i64 %t168, ptr %l84
  %t169 = load i64, ptr %l84
  %t170 = getelementptr { i64, ptr }, ptr %l83, i32 0, i32 1
  %t171 = load ptr, ptr %t170
  %t172 = getelementptr { i64, ptr }, ptr %t171, i64 %t169
  %t173 = load { i64, ptr }, ptr %t172
  store { i64, ptr } %t173, ptr %l85
  %t174 = load { i64, ptr }, ptr %l85
  store { i64, ptr } %t174, ptr %l16
  store ptr %l4, ptr %l86
  %t175 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t175, ptr %l87
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  %t176 = load { i64, ptr }, ptr %l87
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  call void @__olang_sb_put(ptr %s11, ptr %t177, i64 %t178)
  %t179 = load ptr, ptr %s11
  %t180 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t181 = load i64, ptr %t180
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t179, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l88
  call void @__olang_sb_done(ptr %s11)
  %t185 = load { i64, ptr }, ptr %l88
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l89
  %t192 = load ptr, ptr %l86
  %t193 = load { i64, ptr }, ptr %l89
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t192, { i64, ptr } %t193)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s10)
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s12
  %t194 = load i64, ptr %l15
  store i64 %t194, ptr %l90
  %t195 = load i64, ptr %l90
  %t196 = add i64 %t195, 1
  store i64 %t196, ptr %l91
  %t197 = load i64, ptr %l91
  store i64 %t197, ptr %l15
  call void @__olang_scope_close(ptr %s12)
  br label %bb29
bb35:
  %t198 = load i64, ptr %l12
  store i64 %t198, ptr %l92
  %t199 = load i64, ptr %l14
  store i64 %t199, ptr %l93
  %t200 = load i64, ptr %l92
  %t201 = load i64, ptr %l93
  %t202 = add i64 %t200, %t201
  store i64 %t202, ptr %l94
  %t203 = load i64, ptr %l94
  store i64 %t203, ptr %l12
  call void @__olang_scope_close(ptr %s9)
  br label %bb36
bb36:
  br label %bb22
bb37:
  call void @__olang_scope_close(ptr %s8)
  store ptr %l4, ptr %l95
  %t204 = load ptr, ptr %l95
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t204, { i64, ptr } { i64 3, ptr @.d36 })
  br label %bb38
bb38:
  store ptr %l4, ptr %l96
  %t205 = load ptr, ptr %l96
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t205, { i64, ptr } { i64 9, ptr @.d37 })
  br label %bb39
bb39:
  store ptr %l4, ptr %l97
  %t206 = load ptr, ptr %l97
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t206, { i64, ptr } { i64 4, ptr @.d38 })
  br label %bb40
bb40:
  %t207 = load i1, ptr %l3
  store i1 %t207, ptr %l98
  %t208 = load i1, ptr %l98
  br i1 %t208, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l4, ptr %l99
  %t209 = load ptr, ptr %l99
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t209, { i64, ptr } { i64 5, ptr @.d39 })
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s13)
  br label %bb44
bb44:
  %t210 = load ptr, ptr @__olang_prog_scope
  %t211 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t210)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t211, ptr %l100
  br label %bb45
bb45:
  %t212 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l100
  store %"std/prelude/list:List<std/prelude/text:String&>" %t212, ptr %l17
  store %olang.scope zeroinitializer, ptr %s14
  store ptr %l4, ptr %l101
  %t213 = load ptr, ptr %l101
  store ptr %t213, ptr %l18
  store i64 0, ptr %l19
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s15
  %t214 = load ptr, ptr %l18
  store ptr %t214, ptr %l103
  %t215 = load i64, ptr %l19
  store i64 %t215, ptr %l104
  %t216 = load ptr, ptr %l103
  %t217 = load i64, ptr %l104
  %t218 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t216, i64 %t217)
  %t219 = extractvalue { i32, { i64, ptr } } %t218, 1
  %t220 = extractvalue { i32, { i64, ptr } } %t218, 0
  store i32 %t220, ptr %l106
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb48, label %ok.222
ok.222:
  store { i64, ptr } %t219, ptr %l105
  br label %bb47
bb47:
  %t223 = load { i64, ptr }, ptr %l105
  store { i64, ptr } %t223, ptr %l102
  br label %bb52
bb48:
  %t224 = load i32, ptr %l106
  %t225 = ashr i32 %t224, 16
  store i32 %t225, ptr %l107
  %t226 = load i32, ptr %l107
  %t227 = icmp eq i32 %t226, 1
  store i1 %t227, ptr %l108
  %t228 = load i1, ptr %l108
  br i1 %t228, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  %t229 = load i32, ptr %l106
  %t230 = lshr i32 %t229, 16
  %t231 = and i32 %t229, 65535
  %t232 = icmp eq i32 %t230, 1
  %t233 = select i1 %t232, i32 0, i32 0
  %t234 = icmp eq i32 %t229, 0
  %t235 = shl i32 %t233, 16
  %t236 = or i32 %t235, %t231
  %t237 = select i1 %t234, i32 0, i32 %t236
  store i32 %t237, ptr %l109
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t238 = load i32, ptr %l109
  store i32 %t238, ptr %rv
  br label %ret
bb51:
  call void @__olang_scope_close(ptr %s15)
  br label %bb61
bb52:
  %t239 = load { i64, ptr }, ptr %l102
  store { i64, ptr } %t239, ptr %l20
  %t240 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t240, ptr %l110
  %t241 = load { i64, ptr }, ptr %l110
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l111
  %t243 = load i64, ptr %l111
  store i64 %t243, ptr %l21
  store i64 0, ptr %l22
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s16
  %t244 = load i64, ptr %l22
  store i64 %t244, ptr %l112
  %t245 = load i64, ptr %l21
  store i64 %t245, ptr %l113
  %t246 = load i64, ptr %l112
  %t247 = load i64, ptr %l113
  %t248 = icmp slt i64 %t246, %t247
  store i1 %t248, ptr %l114
  %t249 = load i1, ptr %l114
  %t250 = xor i1 %t249, true
  store i1 %t250, ptr %l115
  %t251 = load i1, ptr %l115
  br i1 %t251, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s16)
  br label %bb59
bb55:
  br label %bb56
bb56:
  %t252 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t252, ptr %l116
  %t253 = load i64, ptr %l22
  store i64 %t253, ptr %l117
  %t254 = load i64, ptr %l117
  %t255 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t256 = load ptr, ptr %t255
  %t257 = getelementptr { i64, ptr }, ptr %t256, i64 %t254
  %t258 = load { i64, ptr }, ptr %t257
  store { i64, ptr } %t258, ptr %l118
  %t259 = load { i64, ptr }, ptr %l118
  store { i64, ptr } %t259, ptr %l23
  store ptr %l17, ptr %l119
  %t260 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t260, ptr %l120
  %t261 = load ptr, ptr %l119
  %t262 = load { i64, ptr }, ptr %l120
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t261, { i64, ptr } %t262)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s16)
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s17
  %t263 = load i64, ptr %l22
  store i64 %t263, ptr %l121
  %t264 = load i64, ptr %l121
  %t265 = add i64 %t264, 1
  store i64 %t265, ptr %l122
  %t266 = load i64, ptr %l122
  store i64 %t266, ptr %l22
  call void @__olang_scope_close(ptr %s17)
  br label %bb53
bb59:
  %t267 = load i64, ptr %l19
  store i64 %t267, ptr %l123
  %t268 = load i64, ptr %l21
  store i64 %t268, ptr %l124
  %t269 = load i64, ptr %l123
  %t270 = load i64, ptr %l124
  %t271 = add i64 %t269, %t270
  store i64 %t271, ptr %l125
  %t272 = load i64, ptr %l125
  store i64 %t272, ptr %l19
  call void @__olang_scope_close(ptr %s15)
  br label %bb60
bb60:
  br label %bb46
bb61:
  call void @__olang_scope_close(ptr %s14)
  store ptr %l17, ptr %l126
  %t273 = load ptr, ptr %l0
  store ptr %t273, ptr %l127
  %t274 = load ptr, ptr %l127
  %t275 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t274)
  store { i64, ptr } %t275, ptr %l128
  br label %bb62
bb62:
  %t276 = load ptr, ptr %l126
  %t277 = load { i64, ptr }, ptr %l128
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t276, { i64, ptr } %t277)
  br label %bb63
bb63:
  store ptr %l17, ptr %l129
  %t278 = load ptr, ptr %l129
  %t279 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %t278)
  store { i64, ptr } %t279, ptr %l130
  br label %bb64
bb64:
  %t280 = load { i64, ptr }, ptr %l130
  store { i64, ptr } %t280, ptr %l24
  %t281 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t281, ptr %l131
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s18
  store ptr %s18room, ptr %s18
  %t282 = load { i64, ptr }, ptr %l131
  %t283 = extractvalue { i64, ptr } %t282, 1
  %t284 = extractvalue { i64, ptr } %t282, 0
  call void @__olang_sb_put(ptr %s18, ptr %t283, i64 %t284)
  %t285 = extractvalue { i64, ptr } { i64 5, ptr @.d40 }, 1
  %t286 = extractvalue { i64, ptr } { i64 5, ptr @.d40 }, 0
  call void @__olang_sb_put(ptr %s18, ptr %t285, i64 %t286)
  %t287 = load ptr, ptr %s18
  %t288 = getelementptr %olang.builder, ptr %s18, i32 0, i32 1
  %t289 = load i64, ptr %t288
  %t290 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t287, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  store { i64, ptr } %t292, ptr %l132
  call void @__olang_sb_done(ptr %s18)
  %t293 = load { i64, ptr }, ptr %l132
  store { i64, ptr } %t293, ptr %l25
  %t294 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t294, ptr %l133
  %t295 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t295, ptr %l134
  %t296 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t296, ptr %l135
  %t297 = load { i64, ptr }, ptr %l133
  %t298 = load { i64, ptr }, ptr %l134
  %t299 = load { i64, ptr }, ptr %l135
  %t300 = call i1 @compiler_2fbuild_2elinkCurrent(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t297, { i64, ptr } %t298, { i64, ptr } %t299)
  store i1 %t300, ptr %l136
  br label %bb65
bb65:
  %t301 = load i1, ptr %l136
  br i1 %t301, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s19
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb67:
  br label %bb68
bb68:
  %t302 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t302, ptr %l137
  %t303 = load { i64, ptr }, ptr %l137
  %t304 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t303)
  store i32 %t304, ptr %l138
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb70, label %ok.306
ok.306:
  br label %bb69
bb69:
  br label %bb74
bb70:
  %t307 = load i32, ptr %l138
  %t308 = ashr i32 %t307, 16
  store i32 %t308, ptr %l139
  %t309 = load i32, ptr %l139
  %t310 = icmp eq i32 %t309, 1
  store i1 %t310, ptr %l140
  %t311 = load i1, ptr %l140
  br i1 %t311, label %bb71, label %bb72
bb71:
  br label %bb73
bb72:
  %t312 = load i32, ptr %l138
  %t313 = lshr i32 %t312, 16
  %t314 = and i32 %t312, 65535
  %t315 = icmp eq i32 %t313, 1
  %t316 = select i1 %t315, i32 0, i32 0
  %t317 = icmp eq i32 %t312, 0
  %t318 = shl i32 %t316, 16
  %t319 = or i32 %t318, %t314
  %t320 = select i1 %t317, i32 0, i32 %t319
  store i32 %t320, ptr %l141
  call void @__olang_scope_close(ptr %s0)
  %t321 = load i32, ptr %l141
  store i32 %t321, ptr %rv
  br label %ret
bb73:
  store %olang.scope zeroinitializer, ptr %s20
  call void @__olang_scope_close(ptr %s20)
  br label %bb74
bb74:
  %t322 = load ptr, ptr %l0
  store ptr %t322, ptr %l142
  %t323 = load ptr, ptr %l142
  %t324 = getelementptr %"compiler/build:Config", ptr %t323, i32 0, i32 1
  %t325 = load { i64, ptr }, ptr %t324
  store { i64, ptr } %t325, ptr %l143
  %t326 = load { i64, ptr }, ptr %l143
  %t327 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t326, { i64, ptr } { i64 0, ptr @.d41 })
  store i1 %t327, ptr %l144
  br label %bb75
bb75:
  %t328 = load i1, ptr %l144
  br i1 %t328, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s21
  store i32 65537, ptr %l145
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t329 = load i32, ptr %l145
  store i32 %t329, ptr %rv
  br label %ret
bb77:
  br label %bb78
bb78:
  store ptr %l4, ptr %l147
  %t330 = load ptr, ptr %l147
  %t331 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s0, ptr %s0, ptr %t330)
  store { i64, ptr } %t331, ptr %l148
  br label %bb79
bb79:
  store { i64, ptr } { i64 0, ptr @.d42 }, ptr %l149
  %t332 = load { i64, ptr }, ptr %l148
  %t333 = load { i64, ptr }, ptr %l149
  %t334 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t332, { i64, ptr } %t333, i1 false, { i64, ptr } { i64 0, ptr @.d43 })
  %t335 = extractvalue { i32, %"std/os:Output" } %t334, 1
  %t336 = extractvalue { i32, %"std/os:Output" } %t334, 0
  store i32 %t336, ptr %l151
  %t337 = icmp ne i32 %t336, 0
  br i1 %t337, label %bb81, label %ok.338
ok.338:
  store %"std/os:Output" %t335, ptr %l150
  br label %bb80
bb80:
  %t339 = load %"std/os:Output", ptr %l150
  store %"std/os:Output" %t339, ptr %l146
  br label %bb85
bb81:
  %t340 = load i32, ptr %l151
  %t341 = ashr i32 %t340, 16
  store i32 %t341, ptr %l152
  %t342 = load i32, ptr %l152
  %t343 = icmp eq i32 %t342, 1
  store i1 %t343, ptr %l153
  %t344 = load i1, ptr %l153
  br i1 %t344, label %bb82, label %bb83
bb82:
  br label %bb84
bb83:
  %t345 = load i32, ptr %l151
  %t346 = lshr i32 %t345, 16
  %t347 = and i32 %t345, 65535
  %t348 = icmp eq i32 %t346, 1
  %t349 = select i1 %t348, i32 0, i32 0
  %t350 = icmp eq i32 %t345, 0
  %t351 = shl i32 %t349, 16
  %t352 = or i32 %t351, %t347
  %t353 = select i1 %t350, i32 0, i32 %t352
  store i32 %t353, ptr %l154
  call void @__olang_scope_close(ptr %s0)
  %t354 = load i32, ptr %l154
  store i32 %t354, ptr %rv
  br label %ret
bb84:
  store %olang.scope zeroinitializer, ptr %s22
  store i32 65536, ptr %l155
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t355 = load i32, ptr %l155
  store i32 %t355, ptr %rv
  br label %ret
bb85:
  %t356 = load %"std/os:Output", ptr %l146
  store %"std/os:Output" %t356, ptr %l26
  %t357 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 0
  %t358 = load i32, ptr %t357
  store i32 %t358, ptr %l156
  %t359 = load i32, ptr %l156
  %t360 = icmp ne i32 %t359, 0
  store i1 %t360, ptr %l157
  %t361 = load i1, ptr %l157
  br i1 %t361, label %bb86, label %bb87
bb86:
  store %olang.scope zeroinitializer, ptr %s23
  store i32 65536, ptr %l158
  call void @__olang_scope_close(ptr %s23)
  call void @__olang_scope_close(ptr %s0)
  %t362 = load i32, ptr %l158
  store i32 %t362, ptr %rv
  br label %ret
bb87:
  br label %bb88
bb88:
  %t363 = load ptr, ptr %l0
  store ptr %t363, ptr %l159
  %t364 = load ptr, ptr %l159
  %t365 = getelementptr %"compiler/build:Config", ptr %t364, i32 0, i32 15
  %t366 = load i64, ptr %t365
  store i64 %t366, ptr %l160
  %t367 = load i64, ptr %l160
  %t368 = add i64 %t367, 1
  store i64 %t368, ptr %l161
  %t369 = load i64, ptr %l161
  %t370 = load ptr, ptr %l159
  %t371 = getelementptr %"compiler/build:Config", ptr %t370, i32 0, i32 15
  store i64 %t369, ptr %t371
  %t372 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t372, ptr %l163
  %t373 = load { i64, ptr }, ptr %l163
  %t374 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t373)
  %t375 = extractvalue { i32, %"std/os:FileInfo" } %t374, 1
  %t376 = extractvalue { i32, %"std/os:FileInfo" } %t374, 0
  store i32 %t376, ptr %l165
  %t377 = icmp ne i32 %t376, 0
  br i1 %t377, label %bb90, label %ok.378
ok.378:
  store %"std/os:FileInfo" %t375, ptr %l164
  br label %bb89
bb89:
  %t379 = load %"std/os:FileInfo", ptr %l164
  store %"std/os:FileInfo" %t379, ptr %l162
  br label %bb94
bb90:
  %t380 = load i32, ptr %l165
  %t381 = ashr i32 %t380, 16
  store i32 %t381, ptr %l166
  %t382 = load i32, ptr %l166
  %t383 = icmp eq i32 %t382, 1
  store i1 %t383, ptr %l167
  %t384 = load i1, ptr %l167
  br i1 %t384, label %bb91, label %bb92
bb91:
  br label %bb93
bb92:
  %t385 = load i32, ptr %l165
  %t386 = lshr i32 %t385, 16
  %t387 = and i32 %t385, 65535
  %t388 = icmp eq i32 %t386, 1
  %t389 = select i1 %t388, i32 0, i32 0
  %t390 = icmp eq i32 %t385, 0
  %t391 = shl i32 %t389, 16
  %t392 = or i32 %t391, %t387
  %t393 = select i1 %t390, i32 0, i32 %t392
  store i32 %t393, ptr %l168
  call void @__olang_scope_close(ptr %s0)
  %t394 = load i32, ptr %l168
  store i32 %t394, ptr %rv
  br label %ret
bb93:
  store %olang.scope zeroinitializer, ptr %s24
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb94:
  %t395 = load %"std/os:FileInfo", ptr %l162
  store %"std/os:FileInfo" %t395, ptr %l27
  %t396 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t396, ptr %l169
  %t397 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t397, ptr %l170
  %t398 = getelementptr %"std/os:FileInfo", ptr %l27, i32 0, i32 1
  %t399 = load i64, ptr %t398
  store i64 %t399, ptr %l171
  %t400 = getelementptr %"std/os:FileInfo", ptr %l27, i32 0, i32 2
  %t401 = load i64, ptr %t400
  store i64 %t401, ptr %l172
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s25
  store ptr %s25room, ptr %s25
  %t402 = load { i64, ptr }, ptr %l170
  %t403 = extractvalue { i64, ptr } %t402, 1
  %t404 = extractvalue { i64, ptr } %t402, 0
  call void @__olang_sb_put(ptr %s25, ptr %t403, i64 %t404)
  %t405 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 1
  %t406 = extractvalue { i64, ptr } { i64 1, ptr @.d44 }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t405, i64 %t406)
  %t407 = load i64, ptr %l171
  %t408 = call ptr @__olang_sb_room(ptr %s25, i64 24)
  %t409 = call i64 @__olang_fmt_i64(ptr %t408, i64 %t407)
  call void @__olang_sb_add(ptr %s25, i64 %t409)
  %t410 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 1
  %t411 = extractvalue { i64, ptr } { i64 1, ptr @.d45 }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t410, i64 %t411)
  %t412 = load i64, ptr %l172
  %t413 = call ptr @__olang_sb_room(ptr %s25, i64 24)
  %t414 = call i64 @__olang_fmt_i64(ptr %t413, i64 %t412)
  call void @__olang_sb_add(ptr %s25, i64 %t414)
  %t415 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 1
  %t416 = extractvalue { i64, ptr } { i64 1, ptr @.d46 }, 0
  call void @__olang_sb_put(ptr %s25, ptr %t415, i64 %t416)
  %t417 = load ptr, ptr %s25
  %t418 = getelementptr %olang.builder, ptr %s25, i32 0, i32 1
  %t419 = load i64, ptr %t418
  %t420 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t417, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t419, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  store { i64, ptr } %t422, ptr %l173
  call void @__olang_sb_done(ptr %s25)
  %t423 = load { i64, ptr }, ptr %l173
  store { i64, ptr } %t423, ptr %l174
  %t424 = load { i64, ptr }, ptr %l174
  %t425 = extractvalue { i64, ptr } %t424, 0
  %t426 = extractvalue { i64, ptr } %t424, 1
  %t427 = mul i64 %t425, 1
  %t428 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t427)
  call void @llvm.memcpy.p0.p0.i64(ptr %t428, ptr %t426, i64 %t427, i1 false)
  %t429 = insertvalue { i64, ptr } undef, i64 %t425, 0
  %t430 = insertvalue { i64, ptr } %t429, ptr %t428, 1
  store { i64, ptr } %t430, ptr %l175
  %t431 = load { i64, ptr }, ptr %l169
  %t432 = load { i64, ptr }, ptr %l175
  %t433 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t431, { i64, ptr } %t432)
  store i32 %t433, ptr %l176
  %t434 = icmp ne i32 %t433, 0
  br i1 %t434, label %bb96, label %ok.435
ok.435:
  br label %bb95
bb95:
  br label %bb100
bb96:
  %t436 = load i32, ptr %l176
  %t437 = ashr i32 %t436, 16
  store i32 %t437, ptr %l177
  %t438 = load i32, ptr %l177
  %t439 = icmp eq i32 %t438, 1
  store i1 %t439, ptr %l178
  %t440 = load i1, ptr %l178
  br i1 %t440, label %bb97, label %bb98
bb97:
  br label %bb99
bb98:
  %t441 = load i32, ptr %l176
  %t442 = lshr i32 %t441, 16
  %t443 = and i32 %t441, 65535
  %t444 = icmp eq i32 %t442, 1
  %t445 = select i1 %t444, i32 0, i32 0
  %t446 = icmp eq i32 %t441, 0
  %t447 = shl i32 %t445, 16
  %t448 = or i32 %t447, %t443
  %t449 = select i1 %t446, i32 0, i32 %t448
  store i32 %t449, ptr %l179
  call void @__olang_scope_close(ptr %s0)
  %t450 = load i32, ptr %l179
  store i32 %t450, ptr %rv
  br label %ret
bb99:
  store %olang.scope zeroinitializer, ptr %s26
  call void @__olang_scope_close(ptr %s26)
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l27 = alloca ptr
  %l28 = alloca i1
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l31 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l32 = alloca ptr
  %l33 = alloca ptr
  %l34 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l2
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List<std/prelude/text:String&>" %t4, ptr %t5
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l3
  %t7 = load ptr, ptr %l3
  %t8 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 2
  %t9 = getelementptr %"compiler/target:Target", ptr %t8, i32 0, i32 9
  %t10 = load i1, ptr %t9
  store i1 %t10, ptr %l4
  %t11 = load i1, ptr %l4
  br i1 %t11, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %lp1
  store ptr %t12, ptr %l5
  %t13 = load ptr, ptr %l0
  store ptr %t13, ptr %l6
  %t14 = load ptr, ptr %l6
  %t15 = getelementptr %"compiler/build:Config", ptr %t14, i32 0, i32 2
  %t16 = getelementptr %"compiler/target:Target", ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16
  store { i64, ptr } %t17, ptr %l7
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t18 = extractvalue { i64, ptr } { i64 9, ptr @.d47 }, 1
  %t19 = extractvalue { i64, ptr } { i64 9, ptr @.d47 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l7
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s2, ptr %t21, i64 %t22)
  %t23 = load ptr, ptr %s2
  %t24 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t25 = load i64, ptr %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t23, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l8
  call void @__olang_sb_done(ptr %s2)
  %t29 = load { i64, ptr }, ptr %l8
  %t30 = extractvalue { i64, ptr } %t29, 0
  %t31 = extractvalue { i64, ptr } %t29, 1
  %t32 = mul i64 %t30, 1
  %t33 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t31, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l9
  %t36 = load ptr, ptr %l5
  %t37 = load { i64, ptr }, ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t36, { i64, ptr } %t37)
  br label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  %t38 = load ptr, ptr %l0
  store ptr %t38, ptr %l10
  %t39 = load ptr, ptr %l10
  %t40 = getelementptr %"compiler/build:Config", ptr %t39, i32 0, i32 2
  %t41 = getelementptr %"compiler/target:Target", ptr %t40, i32 0, i32 6
  %t42 = load { i64, ptr }, ptr %t41
  store { i64, ptr } %t42, ptr %l11
  %t43 = load { i64, ptr }, ptr %l11
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t43, { i64, ptr } { i64 0, ptr @.d48 })
  store i1 %t44, ptr %l12
  br label %bb6
bb6:
  %t45 = load i1, ptr %l12
  %t46 = xor i1 %t45, true
  store i1 %t46, ptr %l13
  %t47 = load i1, ptr %l13
  br i1 %t47, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %lp1
  store ptr %t48, ptr %l14
  %t49 = load ptr, ptr %l0
  store ptr %t49, ptr %l15
  %t50 = load ptr, ptr %l15
  %t51 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 2
  %t52 = getelementptr %"compiler/target:Target", ptr %t51, i32 0, i32 6
  %t53 = load { i64, ptr }, ptr %t52
  store { i64, ptr } %t53, ptr %l16
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t54 = load { i64, ptr }, ptr %l16
  %t55 = extractvalue { i64, ptr } %t54, 1
  %t56 = extractvalue { i64, ptr } %t54, 0
  call void @__olang_sb_put(ptr %s4, ptr %t55, i64 %t56)
  %t57 = load ptr, ptr %s4
  %t58 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t59 = load i64, ptr %t58
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t57, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  store { i64, ptr } %t62, ptr %l17
  call void @__olang_sb_done(ptr %s4)
  %t63 = load { i64, ptr }, ptr %l17
  %t64 = extractvalue { i64, ptr } %t63, 0
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l18
  %t70 = load ptr, ptr %l14
  %t71 = load { i64, ptr }, ptr %l18
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t70, { i64, ptr } %t71)
  br label %bb9
bb8:
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb10
bb10:
  %t72 = load ptr, ptr %l0
  store ptr %t72, ptr %l19
  %t73 = load ptr, ptr %l19
  %t74 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 4
  %t75 = load i1, ptr %t74
  store i1 %t75, ptr %l20
  %t76 = load i1, ptr %l20
  br i1 %t76, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s5
  %t77 = load ptr, ptr %lp1
  store ptr %t77, ptr %l21
  %t78 = load ptr, ptr %l21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t78, { i64, ptr } { i64 3, ptr @.d49 })
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t79 = load ptr, ptr %lp1
  store ptr %t79, ptr %l22
  %t80 = load ptr, ptr %l22
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t80, { i64, ptr } { i64 2, ptr @.d50 })
  br label %bb14
bb14:
  %t81 = load ptr, ptr %l0
  store ptr %t81, ptr %l23
  %t82 = load ptr, ptr %l23
  %t83 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 5
  %t84 = load i1, ptr %t83
  store i1 %t84, ptr %l24
  %t85 = load i1, ptr %l24
  br i1 %t85, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s6
  %t86 = load ptr, ptr %lp1
  store ptr %t86, ptr %l25
  %t87 = load ptr, ptr %l25
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t87, { i64, ptr } { i64 17, ptr @.d51 })
  br label %bb17
bb16:
  br label %bb18
bb17:
  call void @__olang_scope_close(ptr %s6)
  br label %bb18
bb18:
  %t88 = load ptr, ptr %lp1
  %t89 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t88
  store %"std/prelude/list:List<std/prelude/text:String&>" %t89, ptr %l26
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t90 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l26
  store %"std/prelude/list:List<std/prelude/text:String&>" %t90, ptr %rv
  br label %ret
bb19:
  %t91 = load ptr, ptr %l0
  store ptr %t91, ptr %l27
  %t92 = load ptr, ptr %l27
  %t93 = getelementptr %"compiler/build:Config", ptr %t92, i32 0, i32 5
  %t94 = load i1, ptr %t93
  store i1 %t94, ptr %l28
  %t95 = load i1, ptr %l28
  br i1 %t95, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  %t96 = load ptr, ptr %lp1
  store ptr %t96, ptr %l29
  %t97 = load ptr, ptr %l29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t97, { i64, ptr } { i64 3, ptr @.d52 })
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t98 = load ptr, ptr %lp1
  store ptr %t98, ptr %l30
  %t99 = load ptr, ptr %l30
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t99, { i64, ptr } { i64 17, ptr @.d53 })
  br label %bb23
bb23:
  %t100 = load ptr, ptr %lp1
  %t101 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t100
  store %"std/prelude/list:List<std/prelude/text:String&>" %t101, ptr %l31
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t102 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l31
  store %"std/prelude/list:List<std/prelude/text:String&>" %t102, ptr %rv
  br label %ret
bb24:
  %t103 = load ptr, ptr %lp1
  store ptr %t103, ptr %l32
  %t104 = load ptr, ptr %l32
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t104, { i64, ptr } { i64 3, ptr @.d54 })
  br label %bb25
bb25:
  %t105 = load ptr, ptr %lp1
  store ptr %t105, ptr %l33
  %t106 = load ptr, ptr %l33
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t106, { i64, ptr } { i64 5, ptr @.d55 })
  br label %bb26
bb26:
  %t107 = load ptr, ptr %lp1
  %t108 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t107
  store %"std/prelude/list:List<std/prelude/text:String&>" %t108, ptr %l34
  call void @__olang_scope_close(ptr %s0)
  %t109 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l34
  store %"std/prelude/list:List<std/prelude/text:String&>" %t109, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca ptr
  %l44 = alloca { i64, ptr }
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca i1
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca ptr
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i32 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l13
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l13
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l5
  store ptr %l5, ptr %l14
  %t4 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t4, ptr %l15
  %t5 = load ptr, ptr %l14
  %t6 = load { i64, ptr }, ptr %l15
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v2, ptr %t5, { i64, ptr } %t6)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l4
  store ptr %t7, ptr %l16
  %t8 = load ptr, ptr %l16
  store ptr %t8, ptr %l6
  store i64 0, ptr %l7
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load ptr, ptr %l6
  store ptr %t9, ptr %l18
  %t10 = load i64, ptr %l7
  store i64 %t10, ptr %l19
  %t11 = load ptr, ptr %l18
  %t12 = load i64, ptr %l19
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t11, i64 %t12)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l21
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l20
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t18, ptr %l17
  br label %bb9
bb5:
  %t19 = load i32, ptr %l21
  %t20 = ashr i32 %t19, 16
  store i32 %t20, ptr %l22
  %t21 = load i32, ptr %l22
  %t22 = icmp eq i32 %t21, 1
  store i1 %t22, ptr %l23
  %t23 = load i1, ptr %l23
  br i1 %t23, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c56)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb9:
  %t24 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t24, ptr %l8
  %t25 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t25, ptr %l24
  %t26 = load { i64, ptr }, ptr %l24
  %t27 = extractvalue { i64, ptr } %t26, 0
  store i64 %t27, ptr %l25
  %t28 = load i64, ptr %l25
  store i64 %t28, ptr %l9
  store i64 0, ptr %l10
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l10
  store i64 %t29, ptr %l26
  %t30 = load i64, ptr %l9
  store i64 %t30, ptr %l27
  %t31 = load i64, ptr %l26
  %t32 = load i64, ptr %l27
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l28
  %t34 = load i1, ptr %l28
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l29
  %t36 = load i1, ptr %l29
  br i1 %t36, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t37 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t37, ptr %l30
  %t38 = load i64, ptr %l10
  store i64 %t38, ptr %l31
  %t39 = load i64, ptr %l31
  %t40 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t39
  %t43 = load { i64, ptr }, ptr %t42
  store { i64, ptr } %t43, ptr %l32
  %t44 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t44, ptr %l11
  store ptr %l5, ptr %l33
  %t45 = load { i64, ptr }, ptr %l11
  store { i64, ptr } %t45, ptr %l34
  %t46 = load ptr, ptr %l33
  %t47 = load { i64, ptr }, ptr %l34
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v3, ptr %t46, { i64, ptr } %t47)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  %t48 = load i64, ptr %l10
  store i64 %t48, ptr %l35
  %t49 = load i64, ptr %l35
  %t50 = add i64 %t49, 1
  store i64 %t50, ptr %l36
  %t51 = load i64, ptr %l36
  store i64 %t51, ptr %l10
  call void @__olang_scope_close(ptr %s4)
  br label %bb10
bb16:
  %t52 = load i64, ptr %l7
  store i64 %t52, ptr %l37
  %t53 = load i64, ptr %l9
  store i64 %t53, ptr %l38
  %t54 = load i64, ptr %l37
  %t55 = load i64, ptr %l38
  %t56 = add i64 %t54, %t55
  store i64 %t56, ptr %l39
  %t57 = load i64, ptr %l39
  store i64 %t57, ptr %l7
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb3
bb18:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l5, ptr %l40
  %t58 = load ptr, ptr %l0
  store ptr %t58, ptr %l41
  %t59 = load ptr, ptr %l41
  %t60 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t59)
  store { i64, ptr } %t60, ptr %l42
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l40
  %t62 = load { i64, ptr }, ptr %l42
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t61, { i64, ptr } %t62)
  br label %bb20
bb20:
  store ptr %l5, ptr %l43
  %t63 = load ptr, ptr %l43
  %t64 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %t63)
  store { i64, ptr } %t64, ptr %l44
  br label %bb21
bb21:
  %t65 = load { i64, ptr }, ptr %l44
  store { i64, ptr } %t65, ptr %l12
  %t66 = load ptr, ptr %l0
  store ptr %t66, ptr %l45
  %t67 = load ptr, ptr %l45
  %t68 = getelementptr %"compiler/build:Config", ptr %t67, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68
  store { i64, ptr } %t69, ptr %l46
  %t70 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t70, ptr %l47
  %t71 = load { i64, ptr }, ptr %l12
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l48
  %t73 = icmp sge i64 0, 0
  store i1 %t73, ptr %l49
  %t74 = load i1, ptr %l49
  br i1 %t74, label %bb22, label %bb23
bb22:
  %t75 = icmp sle i64 0, 16
  store i1 %t75, ptr %l50
  %t76 = load i1, ptr %l50
  br i1 %t76, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb24:
  %t77 = load i64, ptr %l48
  %t78 = icmp sle i64 16, %t77
  store i1 %t78, ptr %l51
  %t79 = load i1, ptr %l51
  br i1 %t79, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb26:
  %t80 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t81 = load ptr, ptr %t80
  %t82 = getelementptr i8, ptr %t81, i64 0
  %t83 = sub i64 16, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l52
  %t86 = load i32, ptr %l2
  store i32 %t86, ptr %l53
  %t87 = load i32, ptr %l53
  %t88 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %t87)
  store { i64, ptr } %t88, ptr %l54
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c57)
  unreachable
bb28:
  %t89 = load ptr, ptr %l0
  store ptr %t89, ptr %l55
  %t90 = load ptr, ptr %l55
  %t91 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t90)
  store { i64, ptr } %t91, ptr %l56
  br label %bb29
bb29:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t92 = load { i64, ptr }, ptr %l46
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  call void @__olang_sb_put(ptr %s5, ptr %t93, i64 %t94)
  %t95 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 1
  %t96 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t95, i64 %t96)
  %t97 = load { i64, ptr }, ptr %l47
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  call void @__olang_sb_put(ptr %s5, ptr %t98, i64 %t99)
  %t100 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t101 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t100, i64 %t101)
  %t102 = load { i64, ptr }, ptr %l52
  %t103 = extractvalue { i64, ptr } %t102, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  call void @__olang_sb_put(ptr %s5, ptr %t103, i64 %t104)
  %t105 = load { i64, ptr }, ptr %l54
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  call void @__olang_sb_put(ptr %s5, ptr %t106, i64 %t107)
  %t108 = load { i64, ptr }, ptr %l56
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  call void @__olang_sb_put(ptr %s5, ptr %t109, i64 %t110)
  %t111 = extractvalue { i64, ptr } { i64 2, ptr @.d60 }, 1
  %t112 = extractvalue { i64, ptr } { i64 2, ptr @.d60 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t111, i64 %t112)
  %t113 = load ptr, ptr %s5
  %t114 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t115 = load i64, ptr %t114
  %t116 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t113, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t115, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  store { i64, ptr } %t118, ptr %l57
  call void @__olang_sb_done(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i64, ptr }, ptr %l57
  store { i64, ptr } %t119, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/list:List<std/prelude/text:String&>" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"compiler/build:compiles"
  %lp4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca %"compiler/build:Unit"
  %l11 = alloca { { i64, ptr }, { i64, ptr } }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca %"compiler/build:compiles"
  %l22 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l30 = alloca i32
  %l31 = alloca i1
  %l32 = alloca i32
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca { i64, ptr }
  %l40 = alloca i64
  %l41 = alloca %"compiler/build:Unit"
  %l42 = alloca ptr
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca i32
  %l50 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l52 = alloca { i64, ptr }
  %l53 = alloca i32
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca ptr
  %l62 = alloca { i64, ptr }
  %l63 = alloca i1
  %l64 = alloca i1
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i32
  %l70 = alloca ptr
  %l71 = alloca { i64, ptr }
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l75 = alloca i32
  %l76 = alloca { i64, ptr }
  %l77 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca i1
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, ptr }
  %l83 = alloca ptr
  %l84 = alloca ptr
  %l85 = alloca i32
  %l86 = alloca ptr
  %l87 = alloca { i64, ptr }
  %l88 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l95 = alloca ptr
  %l96 = alloca i64
  %l97 = alloca { { i64, ptr }, { i64, ptr } }
  %l98 = alloca { i64, ptr }
  %l99 = alloca i64
  %l100 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l102 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca ptr
  %l105 = alloca i64
  %l106 = alloca ptr
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca { i64, ptr }
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i1
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i1
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i1
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i32
  %l137 = alloca i1
  %l138 = alloca i64
  %l139 = alloca { i64, ptr }
  %l140 = alloca i1
  %l141 = alloca i1
  %l142 = alloca ptr
  %l143 = alloca { i64, [3 x i64] }
  %l144 = alloca ptr
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l147 = alloca %"compiler/msgs:Msg"
  %l148 = alloca ptr
  %l149 = alloca i64
  %l150 = alloca { i64, ptr }
  %l151 = alloca i32
  %l152 = alloca i32
  %l153 = alloca i1
  %l154 = alloca i32
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %l157 = alloca i1
  %l158 = alloca i1
  %l159 = alloca i64
  %l160 = alloca { i64, ptr }
  %l161 = alloca ptr
  %l162 = alloca i64
  %l163 = alloca { i64, ptr }
  %l164 = alloca ptr
  %l165 = alloca i64
  %l166 = alloca { i64, ptr }
  %l167 = alloca i32
  %l168 = alloca i32
  %l169 = alloca i1
  %l170 = alloca i32
  %l171 = alloca i1
  %l172 = alloca i1
  %l173 = alloca ptr
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %l176 = alloca %"compiler/msgs:Msg"
  %l177 = alloca ptr
  %l178 = alloca i64
  %l179 = alloca i64
  %l180 = alloca i1
  %l181 = alloca i32
  %l182 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/list:List<std/prelude/text:String&>" }
  %t339 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %s0)
  store %"compiler/build:compiles" %t1, ptr %l21
  br label %bb1
bb1:
  %t2 = load %"compiler/build:compiles", ptr %l21
  store %"compiler/build:compiles" %t2, ptr %l3
  %t3 = load ptr, ptr @__olang_prog_scope
  %t4 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t3)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t4, ptr %l22
  br label %bb2
bb2:
  %t5 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t5, ptr %lp4
  %t6 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l22
  %t7 = load ptr, ptr %lp4
  store %"std/prelude/list:List<std/prelude/text:String&>" %t6, ptr %t7
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l1
  store ptr %t8, ptr %l23
  %t9 = load ptr, ptr %l23
  %t10 = getelementptr %"compiler/build:Program", ptr %t9, i32 0, i32 0
  store ptr %t10, ptr %l24
  %t11 = load ptr, ptr %l24
  store ptr %t11, ptr %l5
  store i64 0, ptr %l6
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = load ptr, ptr %l5
  store ptr %t12, ptr %l26
  %t13 = load i64, ptr %l6
  store i64 %t13, ptr %l27
  %t14 = load ptr, ptr %l26
  %t15 = load i64, ptr %l27
  %t16 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t14, i64 %t15)
  %t17 = extractvalue { i32, { i64, ptr } } %t16, 1
  %t18 = extractvalue { i32, { i64, ptr } } %t16, 0
  store i32 %t18, ptr %l29
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb5, label %ok.20
ok.20:
  store { i64, ptr } %t17, ptr %l28
  br label %bb4
bb4:
  %t21 = load { i64, ptr }, ptr %l28
  store { i64, ptr } %t21, ptr %l25
  br label %bb9
bb5:
  %t22 = load i32, ptr %l29
  %t23 = ashr i32 %t22, 16
  store i32 %t23, ptr %l30
  %t24 = load i32, ptr %l30
  %t25 = icmp eq i32 %t24, 1
  store i1 %t25, ptr %l31
  %t26 = load i1, ptr %l31
  br i1 %t26, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  %t27 = load i32, ptr %l29
  %t28 = lshr i32 %t27, 16
  %t29 = and i32 %t27, 65535
  %t30 = icmp eq i32 %t28, 1
  %t31 = select i1 %t30, i32 0, i32 0
  %t32 = icmp eq i32 %t27, 0
  %t33 = shl i32 %t31, 16
  %t34 = or i32 %t33, %t29
  %t35 = select i1 %t32, i32 0, i32 %t34
  store i32 %t35, ptr %l32
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t36 = load i32, ptr %l32
  %t37 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t36, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t37, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb9:
  %t38 = load { i64, ptr }, ptr %l25
  store { i64, ptr } %t38, ptr %l7
  %t39 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t39, ptr %l33
  %t40 = load { i64, ptr }, ptr %l33
  %t41 = extractvalue { i64, ptr } %t40, 0
  store i64 %t41, ptr %l34
  %t42 = load i64, ptr %l34
  store i64 %t42, ptr %l8
  store i64 0, ptr %l9
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t43 = load i64, ptr %l9
  store i64 %t43, ptr %l35
  %t44 = load i64, ptr %l8
  store i64 %t44, ptr %l36
  %t45 = load i64, ptr %l35
  %t46 = load i64, ptr %l36
  %t47 = icmp slt i64 %t45, %t46
  store i1 %t47, ptr %l37
  %t48 = load i1, ptr %l37
  %t49 = xor i1 %t48, true
  store i1 %t49, ptr %l38
  %t50 = load i1, ptr %l38
  br i1 %t50, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb12:
  br label %bb13
bb13:
  %t51 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t51, ptr %l39
  %t52 = load i64, ptr %l9
  store i64 %t52, ptr %l40
  %t53 = load i64, ptr %l40
  %t54 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t55 = load ptr, ptr %t54
  %t56 = getelementptr %"compiler/build:Unit", ptr %t55, i64 %t53
  %t57 = load %"compiler/build:Unit", ptr %t56
  store %"compiler/build:Unit" %t57, ptr %l41
  %t58 = load %"compiler/build:Unit", ptr %l41
  store %"compiler/build:Unit" %t58, ptr %l10
  %t59 = load ptr, ptr %lp4
  store ptr %t59, ptr %l42
  %t60 = load ptr, ptr %l0
  store ptr %t60, ptr %l44
  store ptr %l3, ptr %l45
  %t61 = getelementptr %"compiler/build:Unit", ptr %l10, i32 0, i32 0
  %t62 = load { i64, ptr }, ptr %t61
  store { i64, ptr } %t62, ptr %l46
  %t63 = load { i64, ptr }, ptr %l46
  %t64 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %v3, { i64, ptr } %t63)
  store { i64, ptr } %t64, ptr %l47
  br label %bb14
bb14:
  %t65 = load { i64, ptr }, ptr %l47
  %t66 = extractvalue { i64, ptr } %t65, 0
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  store { i64, ptr } %t71, ptr %l48
  %t72 = getelementptr %"compiler/build:Unit", ptr %l10, i32 0, i32 1
  %t73 = load i32, ptr %t72
  store i32 %t73, ptr %l49
  %t74 = getelementptr %"compiler/build:Unit", ptr %l10, i32 0, i32 2
  %t75 = load { i64, ptr }, ptr %t74
  store { i64, ptr } %t75, ptr %l50
  %t76 = load ptr, ptr %l2
  store ptr %t76, ptr %l51
  %t77 = load ptr, ptr %l44
  %t78 = load ptr, ptr %l45
  %t79 = load { i64, ptr }, ptr %l48
  %t80 = load i32, ptr %l49
  %t81 = load { i64, ptr }, ptr %l50
  %t82 = load ptr, ptr %l51
  %t83 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t77, ptr %t78, { i64, ptr } %t79, i32 %t80, { i64, ptr } %t81, ptr %t82)
  %t84 = extractvalue { i32, { i64, ptr } } %t83, 1
  %t85 = extractvalue { i32, { i64, ptr } } %t83, 0
  store i32 %t85, ptr %l53
  %t86 = icmp ne i32 %t85, 0
  br i1 %t86, label %bb16, label %ok.87
ok.87:
  store { i64, ptr } %t84, ptr %l52
  br label %bb15
bb15:
  %t88 = load { i64, ptr }, ptr %l52
  store { i64, ptr } %t88, ptr %l43
  br label %bb17
bb16:
  %t89 = load i32, ptr %l53
  %t90 = lshr i32 %t89, 16
  %t91 = and i32 %t89, 65535
  %t92 = icmp eq i32 %t90, 1
  %t93 = select i1 %t92, i32 1, i32 0
  %t94 = icmp eq i32 %t89, 0
  %t95 = shl i32 %t93, 16
  %t96 = or i32 %t95, %t91
  %t97 = select i1 %t94, i32 0, i32 %t96
  store i32 %t97, ptr %l54
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t98 = load i32, ptr %l54
  %t99 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t98, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t99, ptr %rv
  br label %ret
bb17:
  %t100 = load { i64, ptr }, ptr %l43
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l55
  %t107 = load ptr, ptr %l42
  %t108 = load { i64, ptr }, ptr %l55
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t107, { i64, ptr } %t108)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t109 = load i64, ptr %l9
  store i64 %t109, ptr %l56
  %t110 = load i64, ptr %l56
  %t111 = add i64 %t110, 1
  store i64 %t111, ptr %l57
  %t112 = load i64, ptr %l57
  store i64 %t112, ptr %l9
  call void @__olang_scope_close(ptr %s4)
  br label %bb10
bb20:
  %t113 = load i64, ptr %l6
  store i64 %t113, ptr %l58
  %t114 = load i64, ptr %l8
  store i64 %t114, ptr %l59
  %t115 = load i64, ptr %l58
  %t116 = load i64, ptr %l59
  %t117 = add i64 %t115, %t116
  store i64 %t117, ptr %l60
  %t118 = load i64, ptr %l60
  store i64 %t118, ptr %l6
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  br label %bb3
bb22:
  call void @__olang_scope_close(ptr %s1)
  %t119 = load ptr, ptr %l1
  store ptr %t119, ptr %l61
  %t120 = load ptr, ptr %l61
  %t121 = getelementptr %"compiler/build:Program", ptr %t120, i32 0, i32 1
  %t122 = load { i64, ptr }, ptr %t121
  store { i64, ptr } %t122, ptr %l62
  %t123 = load { i64, ptr }, ptr %l62
  %t124 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t123, { i64, ptr } { i64 0, ptr @.d61 })
  store i1 %t124, ptr %l63
  br label %bb23
bb23:
  %t125 = load i1, ptr %l63
  %t126 = xor i1 %t125, true
  store i1 %t126, ptr %l64
  %t127 = load i1, ptr %l64
  br i1 %t127, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t128 = load ptr, ptr %lp4
  store ptr %t128, ptr %l65
  %t129 = load ptr, ptr %l0
  store ptr %t129, ptr %l67
  store ptr %l3, ptr %l68
  store i32 0, ptr %l69
  %t130 = load ptr, ptr %l1
  store ptr %t130, ptr %l70
  %t131 = load ptr, ptr %l70
  %t132 = getelementptr %"compiler/build:Program", ptr %t131, i32 0, i32 1
  %t133 = load { i64, ptr }, ptr %t132
  store { i64, ptr } %t133, ptr %l71
  %t134 = load ptr, ptr %l2
  store ptr %t134, ptr %l72
  %t135 = load ptr, ptr %l67
  %t136 = load ptr, ptr %l68
  %t137 = load i32, ptr %l69
  %t138 = load { i64, ptr }, ptr %l71
  %t139 = load ptr, ptr %l72
  %t140 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t135, ptr %t136, { i64, ptr } { i64 13, ptr @.d62 }, i32 %t137, { i64, ptr } %t138, ptr %t139)
  %t141 = extractvalue { i32, { i64, ptr } } %t140, 1
  %t142 = extractvalue { i32, { i64, ptr } } %t140, 0
  store i32 %t142, ptr %l74
  %t143 = icmp ne i32 %t142, 0
  br i1 %t143, label %bb27, label %ok.144
ok.144:
  store { i64, ptr } %t141, ptr %l73
  br label %bb26
bb25:
  br label %bb30
bb26:
  %t145 = load { i64, ptr }, ptr %l73
  store { i64, ptr } %t145, ptr %l66
  br label %bb28
bb27:
  %t146 = load i32, ptr %l74
  %t147 = lshr i32 %t146, 16
  %t148 = and i32 %t146, 65535
  %t149 = icmp eq i32 %t147, 1
  %t150 = select i1 %t149, i32 1, i32 0
  %t151 = icmp eq i32 %t146, 0
  %t152 = shl i32 %t150, 16
  %t153 = or i32 %t152, %t148
  %t154 = select i1 %t151, i32 0, i32 %t153
  store i32 %t154, ptr %l75
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t155 = load i32, ptr %l75
  %t156 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t155, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t156, ptr %rv
  br label %ret
bb28:
  %t157 = load { i64, ptr }, ptr %l66
  %t158 = extractvalue { i64, ptr } %t157, 0
  %t159 = extractvalue { i64, ptr } %t157, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l76
  %t164 = load ptr, ptr %l65
  %t165 = load { i64, ptr }, ptr %l76
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t164, { i64, ptr } %t165)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s5)
  br label %bb30
bb30:
  %t166 = load ptr, ptr %l1
  store ptr %t166, ptr %l77
  %t167 = load ptr, ptr %l77
  %t168 = getelementptr %"compiler/build:Program", ptr %t167, i32 0, i32 2
  %t169 = load { i64, ptr }, ptr %t168
  store { i64, ptr } %t169, ptr %l78
  %t170 = load { i64, ptr }, ptr %l78
  %t171 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t170, { i64, ptr } { i64 0, ptr @.d63 })
  store i1 %t171, ptr %l79
  br label %bb31
bb31:
  %t172 = load i1, ptr %l79
  %t173 = xor i1 %t172, true
  store i1 %t173, ptr %l80
  %t174 = load i1, ptr %l80
  br i1 %t174, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s6
  %t175 = load ptr, ptr %lp4
  store ptr %t175, ptr %l81
  %t176 = load ptr, ptr %l0
  store ptr %t176, ptr %l83
  store ptr %l3, ptr %l84
  store i32 0, ptr %l85
  %t177 = load ptr, ptr %l1
  store ptr %t177, ptr %l86
  %t178 = load ptr, ptr %l86
  %t179 = getelementptr %"compiler/build:Program", ptr %t178, i32 0, i32 2
  %t180 = load { i64, ptr }, ptr %t179
  store { i64, ptr } %t180, ptr %l87
  %t181 = load ptr, ptr %l2
  store ptr %t181, ptr %l88
  %t182 = load ptr, ptr %l83
  %t183 = load ptr, ptr %l84
  %t184 = load i32, ptr %l85
  %t185 = load { i64, ptr }, ptr %l87
  %t186 = load ptr, ptr %l88
  %t187 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %t182, ptr %t183, { i64, ptr } { i64 13, ptr @.d64 }, i32 %t184, { i64, ptr } %t185, ptr %t186)
  %t188 = extractvalue { i32, { i64, ptr } } %t187, 1
  %t189 = extractvalue { i32, { i64, ptr } } %t187, 0
  store i32 %t189, ptr %l90
  %t190 = icmp ne i32 %t189, 0
  br i1 %t190, label %bb35, label %ok.191
ok.191:
  store { i64, ptr } %t188, ptr %l89
  br label %bb34
bb33:
  br label %bb38
bb34:
  %t192 = load { i64, ptr }, ptr %l89
  store { i64, ptr } %t192, ptr %l82
  br label %bb36
bb35:
  %t193 = load i32, ptr %l90
  %t194 = lshr i32 %t193, 16
  %t195 = and i32 %t193, 65535
  %t196 = icmp eq i32 %t194, 1
  %t197 = select i1 %t196, i32 1, i32 0
  %t198 = icmp eq i32 %t193, 0
  %t199 = shl i32 %t197, 16
  %t200 = or i32 %t199, %t195
  %t201 = select i1 %t198, i32 0, i32 %t200
  store i32 %t201, ptr %l91
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t202 = load i32, ptr %l91
  %t203 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t202, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t203, ptr %rv
  br label %ret
bb36:
  %t204 = load { i64, ptr }, ptr %l82
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = mul i64 %t205, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t208, ptr %t206, i64 %t207, i1 false)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  store { i64, ptr } %t210, ptr %l92
  %t211 = load ptr, ptr %l81
  %t212 = load { i64, ptr }, ptr %l92
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t211, { i64, ptr } %t212)
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s6)
  br label %bb38
bb38:
  %t213 = getelementptr %"compiler/build:compiles", ptr %l3, i32 0, i32 0
  store ptr %t213, ptr %l93
  %t214 = load ptr, ptr %l93
  %t215 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %t214)
  store { i64, ptr } %t215, ptr %l94
  br label %bb39
bb39:
  %t216 = load ptr, ptr %l0
  store ptr %t216, ptr %l95
  %t217 = load ptr, ptr %l95
  %t218 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t217)
  store i64 %t218, ptr %l96
  br label %bb40
bb40:
  %t219 = load { i64, ptr }, ptr %l94
  %t220 = load i64, ptr %l96
  %t221 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %s0, ptr %s0, { i64, ptr } %t219, i64 %t220)
  store { { i64, ptr }, { i64, ptr } } %t221, ptr %l97
  br label %bb41
bb41:
  %t222 = load { { i64, ptr }, { i64, ptr } }, ptr %l97
  store { { i64, ptr }, { i64, ptr } } %t222, ptr %l11
  %t223 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l11, i32 0, i32 0
  %t224 = load { i64, ptr }, ptr %t223
  store { i64, ptr } %t224, ptr %l98
  %t225 = load { i64, ptr }, ptr %l98
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l99
  %t227 = load i64, ptr %l99
  %t228 = mul i64 %t227, 4
  %t229 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t228)
  %t230 = insertvalue { i64, ptr } undef, i64 %t227, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l100
  %t232 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t233 = load ptr, ptr %t232
  %t234 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  %t236 = load i64, ptr %l99
  %t237 = mul i64 %t236, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t233, ptr %t235, i64 %t237, i1 false)
  %t238 = load { i64, ptr }, ptr %l100
  store { i64, ptr } %t238, ptr %l12
  %t239 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l11, i32 0, i32 1
  %t240 = load { i64, ptr }, ptr %t239
  store { i64, ptr } %t240, ptr %l101
  %t241 = load { i64, ptr }, ptr %l101
  %t242 = extractvalue { i64, ptr } %t241, 0
  store i64 %t242, ptr %l102
  %t243 = load i64, ptr %l102
  %t244 = mul i64 %t243, 16
  %t245 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t244)
  %t246 = insertvalue { i64, ptr } undef, i64 %t243, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  store { i64, ptr } %t247, ptr %l103
  %t248 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t249 = load ptr, ptr %t248
  %t250 = getelementptr { i64, ptr }, ptr %l101, i32 0, i32 1
  %t251 = load ptr, ptr %t250
  %t252 = load i64, ptr %l102
  %t253 = mul i64 %t252, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t249, ptr %t251, i64 %t253, i1 false)
  %t254 = load { i64, ptr }, ptr %l103
  store { i64, ptr } %t254, ptr %l13
  %t255 = load ptr, ptr %l0
  store ptr %t255, ptr %l104
  %t256 = load ptr, ptr %l104
  %t257 = getelementptr %"compiler/build:Config", ptr %t256, i32 0, i32 14
  %t258 = load i64, ptr %t257
  store i64 %t258, ptr %l105
  %t259 = getelementptr %"compiler/build:compiles", ptr %l3, i32 0, i32 0
  store ptr %t259, ptr %l106
  %t260 = load ptr, ptr %l106
  %t261 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %s0, ptr %t260)
  store i64 %t261, ptr %l107
  br label %bb42
bb42:
  %t262 = load i64, ptr %l105
  %t263 = load i64, ptr %l107
  %t264 = add i64 %t262, %t263
  store i64 %t264, ptr %l108
  %t265 = load i64, ptr %l108
  %t266 = load ptr, ptr %l104
  %t267 = getelementptr %"compiler/build:Config", ptr %t266, i32 0, i32 14
  store i64 %t265, ptr %t267
  store i1 false, ptr %l14
  store %olang.scope zeroinitializer, ptr %s7
  store i64 0, ptr %l15
  %t268 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t268, ptr %l109
  %t269 = load { i64, ptr }, ptr %l109
  %t270 = extractvalue { i64, ptr } %t269, 0
  store i64 %t270, ptr %l110
  %t271 = load i64, ptr %l110
  store i64 %t271, ptr %l16
  store i64 1, ptr %l17
  %t272 = load i64, ptr %l16
  store i64 %t272, ptr %l111
  %t273 = load i64, ptr %l15
  store i64 %t273, ptr %l112
  %t274 = load i64, ptr %l111
  %t275 = load i64, ptr %l112
  %t276 = icmp sgt i64 %t274, %t275
  store i1 %t276, ptr %l113
  %t277 = load i1, ptr %l113
  br i1 %t277, label %bb43, label %bb44
bb43:
  %t278 = load i64, ptr %l17
  store i64 %t278, ptr %l115
  %t279 = load i64, ptr %l115
  %t280 = icmp sgt i64 %t279, 0
  store i1 %t280, ptr %l116
  %t281 = load i1, ptr %l116
  br i1 %t281, label %bb45, label %bb46
bb44:
  store i64 0, ptr %l114
  br label %bb48
bb45:
  %t282 = load i64, ptr %l16
  store i64 %t282, ptr %l118
  %t283 = load i64, ptr %l15
  store i64 %t283, ptr %l119
  %t284 = load i64, ptr %l118
  %t285 = load i64, ptr %l119
  %t286 = sub i64 %t284, %t285
  store i64 %t286, ptr %l120
  %t287 = load i64, ptr %l17
  store i64 %t287, ptr %l121
  %t288 = load i64, ptr %l120
  %t289 = load i64, ptr %l121
  %t290 = add i64 %t288, %t289
  store i64 %t290, ptr %l122
  %t291 = load i64, ptr %l122
  %t292 = sub i64 %t291, 1
  store i64 %t292, ptr %l123
  %t293 = load i64, ptr %l17
  store i64 %t293, ptr %l124
  %t294 = load i64, ptr %l123
  %t295 = load i64, ptr %l124
  %t296 = sdiv i64 %t294, %t295
  store i64 %t296, ptr %l125
  %t297 = load i64, ptr %l125
  store i64 %t297, ptr %l117
  br label %bb47
bb46:
  store i64 0, ptr %l117
  br label %bb47
bb47:
  %t298 = load i64, ptr %l117
  store i64 %t298, ptr %l114
  br label %bb48
bb48:
  %t299 = load i64, ptr %l114
  store i64 %t299, ptr %l18
  store i64 0, ptr %l19
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t300 = load i64, ptr %l19
  store i64 %t300, ptr %l126
  %t301 = load i64, ptr %l18
  store i64 %t301, ptr %l127
  %t302 = load i64, ptr %l126
  %t303 = load i64, ptr %l127
  %t304 = icmp slt i64 %t302, %t303
  store i1 %t304, ptr %l128
  %t305 = load i1, ptr %l128
  %t306 = xor i1 %t305, true
  store i1 %t306, ptr %l129
  %t307 = load i1, ptr %l129
  br i1 %t307, label %bb50, label %bb51
bb50:
  call void @__olang_scope_close(ptr %s8)
  br label %bb90
bb51:
  br label %bb52
bb52:
  %t308 = load i64, ptr %l15
  store i64 %t308, ptr %l130
  %t309 = load i64, ptr %l19
  store i64 %t309, ptr %l131
  %t310 = load i64, ptr %l17
  store i64 %t310, ptr %l132
  %t311 = load i64, ptr %l131
  %t312 = load i64, ptr %l132
  %t313 = mul i64 %t311, %t312
  store i64 %t313, ptr %l133
  %t314 = load i64, ptr %l130
  %t315 = load i64, ptr %l133
  %t316 = add i64 %t314, %t315
  store i64 %t316, ptr %l134
  %t317 = load i64, ptr %l134
  store i64 %t317, ptr %l20
  %t318 = load i64, ptr %l20
  store i64 %t318, ptr %l135
  %t319 = load i64, ptr %l135
  %t320 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t321 = load ptr, ptr %t320
  %t322 = getelementptr i32, ptr %t321, i64 %t319
  %t323 = load i32, ptr %t322
  store i32 %t323, ptr %l136
  %t324 = load i32, ptr %l136
  %t325 = icmp ne i32 %t324, 0
  store i1 %t325, ptr %l137
  %t326 = load i1, ptr %l137
  br i1 %t326, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t327 = load i64, ptr %l20
  store i64 %t327, ptr %l138
  %t328 = load i64, ptr %l138
  %t329 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t330 = load ptr, ptr %t329
  %t331 = getelementptr { i64, ptr }, ptr %t330, i64 %t328
  %t332 = load { i64, ptr }, ptr %t331
  store { i64, ptr } %t332, ptr %l139
  %t333 = load { i64, ptr }, ptr %l139
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t333)
  br label %bb55
bb54:
  br label %bb69
bb55:
  %t334 = load i1, ptr %l14
  store i1 %t334, ptr %l140
  %t335 = load i1, ptr %l140
  %t336 = xor i1 %t335, true
  store i1 %t336, ptr %l141
  %t337 = load i1, ptr %l141
  br i1 %t337, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s10
  %t338 = load ptr, ptr %l2
  store ptr %t338, ptr %l142
  store { i64, [3 x i64] } zeroinitializer, ptr %t339
  %t340 = getelementptr { i64, [3 x i64] }, ptr %t339, i32 0, i32 0
  store i64 0, ptr %t340
  %t341 = load { i64, [3 x i64] }, ptr %t339
  store { i64, [3 x i64] } %t341, ptr %l143
  %t342 = getelementptr %"compiler/build:compiles", ptr %l3, i32 0, i32 3
  store ptr %t342, ptr %l144
  %t343 = load i64, ptr %l20
  store i64 %t343, ptr %l145
  %t344 = load ptr, ptr %l144
  %t345 = load i64, ptr %l145
  %t346 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t344, i64 %t345)
  store { i64, ptr } %t346, ptr %l146
  br label %bb58
bb57:
  br label %bb61
bb58:
  %t347 = load { i64, ptr }, ptr %l146
  %t348 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %s0, ptr %s10, { i64, ptr } %t347)
  store %"compiler/msgs:Msg" %t348, ptr %l147
  br label %bb59
bb59:
  %t349 = load ptr, ptr %l142
  %t350 = load { i64, [3 x i64] }, ptr %l143
  %t351 = load %"compiler/msgs:Msg", ptr %l147
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %s10, ptr %t349, { i64, [3 x i64] } %t350, %"compiler/msgs:Msg" %t351)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb61:
  store i1 true, ptr %l14
  %t352 = getelementptr %"compiler/build:compiles", ptr %l3, i32 0, i32 1
  store ptr %t352, ptr %l148
  %t353 = load i64, ptr %l20
  store i64 %t353, ptr %l149
  %t354 = load ptr, ptr %l148
  %t355 = load i64, ptr %l149
  %t356 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t354, i64 %t355)
  store { i64, ptr } %t356, ptr %l150
  br label %bb62
bb62:
  %t357 = load { i64, ptr }, ptr %l150
  %t358 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t357)
  store i32 %t358, ptr %l151
  %t359 = icmp ne i32 %t358, 0
  br i1 %t359, label %bb64, label %ok.360
ok.360:
  br label %bb63
bb63:
  br label %bb68
bb64:
  %t361 = load i32, ptr %l151
  %t362 = ashr i32 %t361, 16
  store i32 %t362, ptr %l152
  %t363 = load i32, ptr %l152
  %t364 = icmp eq i32 %t363, 1
  store i1 %t364, ptr %l153
  %t365 = load i1, ptr %l153
  br i1 %t365, label %bb65, label %bb66
bb65:
  br label %bb67
bb66:
  %t366 = load i32, ptr %l151
  %t367 = lshr i32 %t366, 16
  %t368 = and i32 %t366, 65535
  %t369 = icmp eq i32 %t367, 1
  %t370 = select i1 %t369, i32 0, i32 0
  %t371 = icmp eq i32 %t366, 0
  %t372 = shl i32 %t370, 16
  %t373 = or i32 %t372, %t368
  %t374 = select i1 %t371, i32 0, i32 %t373
  store i32 %t374, ptr %l154
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t375 = load i32, ptr %l154
  %t376 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t375, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t376, ptr %rv
  br label %ret
bb67:
  store %olang.scope zeroinitializer, ptr %s11
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb69:
  %t377 = load i64, ptr %l20
  store i64 %t377, ptr %l155
  %t378 = load i64, ptr %l155
  %t379 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t380 = load ptr, ptr %t379
  %t381 = getelementptr { i64, ptr }, ptr %t380, i64 %t378
  %t382 = load { i64, ptr }, ptr %t381
  store { i64, ptr } %t382, ptr %l156
  %t383 = load { i64, ptr }, ptr %l156
  %t384 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s8, { i64, ptr } %t383, { i64, ptr } { i64 0, ptr @.d65 })
  store i1 %t384, ptr %l157
  br label %bb70
bb70:
  %t385 = load i1, ptr %l157
  %t386 = xor i1 %t385, true
  store i1 %t386, ptr %l158
  %t387 = load i1, ptr %l158
  br i1 %t387, label %bb71, label %bb72
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t388 = load i64, ptr %l20
  store i64 %t388, ptr %l159
  %t389 = load i64, ptr %l159
  %t390 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t391 = load ptr, ptr %t390
  %t392 = getelementptr { i64, ptr }, ptr %t391, i64 %t389
  %t393 = load { i64, ptr }, ptr %t392
  store { i64, ptr } %t393, ptr %l160
  %t394 = load { i64, ptr }, ptr %l160
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t394)
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_scope_close(ptr %s12)
  br label %bb74
bb74:
  %t395 = getelementptr %"compiler/build:compiles", ptr %l3, i32 0, i32 1
  store ptr %t395, ptr %l161
  %t396 = load i64, ptr %l20
  store i64 %t396, ptr %l162
  %t397 = load ptr, ptr %l161
  %t398 = load i64, ptr %l162
  %t399 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t397, i64 %t398)
  store { i64, ptr } %t399, ptr %l163
  br label %bb75
bb75:
  %t400 = getelementptr %"compiler/build:compiles", ptr %l3, i32 0, i32 2
  store ptr %t400, ptr %l164
  %t401 = load i64, ptr %l20
  store i64 %t401, ptr %l165
  %t402 = load ptr, ptr %l164
  %t403 = load i64, ptr %l165
  %t404 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t402, i64 %t403)
  store { i64, ptr } %t404, ptr %l166
  br label %bb76
bb76:
  %t405 = load { i64, ptr }, ptr %l163
  %t406 = load { i64, ptr }, ptr %l166
  %t407 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t405, { i64, ptr } %t406)
  store i32 %t407, ptr %l167
  %t408 = icmp ne i32 %t407, 0
  br i1 %t408, label %bb78, label %ok.409
ok.409:
  br label %bb77
bb77:
  br label %bb88
bb78:
  %t410 = load i32, ptr %l167
  %t411 = ashr i32 %t410, 16
  store i32 %t411, ptr %l168
  %t412 = load i32, ptr %l168
  %t413 = icmp eq i32 %t412, 1
  store i1 %t413, ptr %l169
  %t414 = load i1, ptr %l169
  br i1 %t414, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  %t415 = load i32, ptr %l167
  %t416 = lshr i32 %t415, 16
  %t417 = and i32 %t415, 65535
  %t418 = icmp eq i32 %t416, 1
  %t419 = select i1 %t418, i32 0, i32 0
  %t420 = icmp eq i32 %t415, 0
  %t421 = shl i32 %t419, 16
  %t422 = or i32 %t421, %t417
  %t423 = select i1 %t420, i32 0, i32 %t422
  store i32 %t423, ptr %l170
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t424 = load i32, ptr %l170
  %t425 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t424, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t425, ptr %rv
  br label %ret
bb81:
  store %olang.scope zeroinitializer, ptr %s13
  %t426 = load i1, ptr %l14
  store i1 %t426, ptr %l171
  %t427 = load i1, ptr %l171
  %t428 = xor i1 %t427, true
  store i1 %t428, ptr %l172
  %t429 = load i1, ptr %l172
  br i1 %t429, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s14
  %t430 = getelementptr %"compiler/build:compiles", ptr %l3, i32 0, i32 2
  store ptr %t430, ptr %l173
  %t431 = load i64, ptr %l20
  store i64 %t431, ptr %l174
  %t432 = load ptr, ptr %l173
  %t433 = load i64, ptr %l174
  %t434 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t432, i64 %t433)
  store { i64, ptr } %t434, ptr %l175
  br label %bb84
bb83:
  br label %bb87
bb84:
  %t435 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s14)
  store %"compiler/msgs:Msg" %t435, ptr %l176
  br label %bb85
bb85:
  %t436 = load ptr, ptr %l2
  store ptr %t436, ptr %l177
  %t437 = load { i64, ptr }, ptr %l175
  %t438 = load %"compiler/msgs:Msg", ptr %l176
  %t439 = load ptr, ptr %l177
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s14, ptr %v2, { i64, ptr } %t437, %"compiler/msgs:Msg" %t438, ptr %t439)
  br label %bb86
bb86:
  call void @__olang_scope_close(ptr %s14)
  br label %bb87
bb87:
  store i1 true, ptr %l14
  call void @__olang_scope_close(ptr %s13)
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s8)
  br label %bb89
bb89:
  store %olang.scope zeroinitializer, ptr %s15
  %t440 = load i64, ptr %l19
  store i64 %t440, ptr %l178
  %t441 = load i64, ptr %l178
  %t442 = add i64 %t441, 1
  store i64 %t442, ptr %l179
  %t443 = load i64, ptr %l179
  store i64 %t443, ptr %l19
  call void @__olang_scope_close(ptr %s15)
  br label %bb49
bb90:
  call void @__olang_scope_close(ptr %s7)
  %t444 = load i1, ptr %l14
  store i1 %t444, ptr %l180
  %t445 = load i1, ptr %l180
  br i1 %t445, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s16
  store i32 65536, ptr %l181
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t446 = load i32, ptr %l181
  %t447 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, i32 %t446, 0
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t447, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t448 = load ptr, ptr %lp4
  %t449 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %t448
  store %"std/prelude/list:List<std/prelude/text:String&>" %t449, ptr %l182
  call void @__olang_scope_close(ptr %s0)
  %t450 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l182
  %t451 = insertvalue { i32, %"std/prelude/list:List<std/prelude/text:String&>" } zeroinitializer, %"std/prelude/list:List<std/prelude/text:String&>" %t450, 1
  store { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %t451, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/list:List<std/prelude/text:String&>" }, ptr %rv
  ret { i32, %"std/prelude/list:List<std/prelude/text:String&>" } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/os:Output"
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca %"std/os:Output"
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca [2 x { i64, ptr }]
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/os:Output"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 16
  %t4 = load { i64, ptr }, ptr %t3
  store { i64, ptr } %t4, ptr %l3
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 0, ptr @.d66 })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0
  store ptr %t8, ptr %l6
  %t9 = load ptr, ptr %l6
  %t10 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10
  store { i64, ptr } %t11, ptr %l7
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t12 = load { i64, ptr }, ptr %l7
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s2, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s2
  %t16 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l8
  call void @__olang_sb_done(ptr %s2)
  %t21 = load { i64, ptr }, ptr %l8
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l9
  %t28 = load { i64, ptr }, ptr %l9
  %t29 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t28, 0
  %t30 = insertvalue [2 x { i64, ptr }] %t29, { i64, ptr } { i64 9, ptr @.d67 }, 1
  store [2 x { i64, ptr }] %t30, ptr %l10
  %t31 = load [2 x { i64, ptr }], ptr %l10
  %t32 = load ptr, ptr @__olang_prog_scope
  %t33 = call ptr @__olang_scope_alloc(ptr %t32, i64 32)
  store [2 x { i64, ptr }] %t31, ptr %t33
  %t34 = insertvalue { i64, ptr } undef, i64 2, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l11
  %t36 = load { i64, ptr }, ptr %l11
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 16
  %t40 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l12
  store { i64, ptr } { i64 0, ptr @.d68 }, ptr %l13
  %t43 = load { i64, ptr }, ptr %l12
  %t44 = load { i64, ptr }, ptr %l13
  %t45 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s1, ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t43, { i64, ptr } %t44, i1 true, { i64, ptr } { i64 0, ptr @.d69 })
  %t46 = extractvalue { i32, %"std/os:Output" } %t45, 1
  %t47 = extractvalue { i32, %"std/os:Output" } %t45, 0
  store i32 %t47, ptr %l15
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb5, label %ok.49
ok.49:
  store %"std/os:Output" %t46, ptr %l14
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t50 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t50, ptr %l5
  br label %bb9
bb5:
  %t51 = load i32, ptr %l15
  %t52 = ashr i32 %t51, 16
  store i32 %t52, ptr %l16
  %t53 = load i32, ptr %l16
  %t54 = icmp eq i32 %t53, 1
  store i1 %t54, ptr %l17
  %t55 = load i1, ptr %l17
  br i1 %t55, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 0, ptr @.d71 }, ptr %l18
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t56 = load { i64, ptr }, ptr %l18
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  %t57 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t57, ptr %l1
  %t58 = load ptr, ptr %l0
  store ptr %t58, ptr %l19
  %t59 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 1
  %t60 = load { i64, ptr }, ptr %t59
  store { i64, ptr } %t60, ptr %l20
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t61 = load { i64, ptr }, ptr %l20
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  call void @__olang_sb_put(ptr %s4, ptr %t62, i64 %t63)
  %t64 = load ptr, ptr %s4
  %t65 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t66 = load i64, ptr %t65
  %t67 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t64, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l21
  call void @__olang_sb_done(ptr %s4)
  %t70 = load { i64, ptr }, ptr %l21
  %t71 = extractvalue { i64, ptr } %t70, 0
  %t72 = extractvalue { i64, ptr } %t70, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l22
  %t77 = load { i64, ptr }, ptr %l22
  %t78 = load ptr, ptr %l19
  %t79 = getelementptr %"compiler/build:Config", ptr %t78, i32 0, i32 16
  store { i64, ptr } %t77, ptr %t79
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t80 = load ptr, ptr %l0
  store ptr %t80, ptr %l23
  %t81 = load ptr, ptr %l23
  %t82 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 16
  %t83 = load { i64, ptr }, ptr %t82
  store { i64, ptr } %t83, ptr %l24
  call void @__olang_scope_close(ptr %s0)
  %t84 = load { i64, ptr }, ptr %l24
  store { i64, ptr } %t84, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i32
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %l11 = alloca ptr
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3
  store { i64, ptr } %t4, ptr %l3
  %t5 = load { i64, ptr }, ptr %l3
  %t6 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t5)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  br label %bb1
bb1:
  br label %bb8
bb2:
  %t9 = load i32, ptr %l4
  %t10 = ashr i32 %t9, 16
  store i32 %t10, ptr %l5
  %t11 = load i32, ptr %l5
  %t12 = icmp eq i32 %t11, 1
  store i1 %t12, ptr %l6
  %t13 = load i1, ptr %l6
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l4
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 0, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  store i32 %t22, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l7
  store i32 %t23, ptr %rv
  br label %ret
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0
  store ptr %t24, ptr %l8
  %t25 = load ptr, ptr %l8
  %t26 = getelementptr %"compiler/build:Config", ptr %t25, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26
  store { i64, ptr } %t27, ptr %l9
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t28, ptr %l10
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l1
  store ptr %t29, ptr %l11
  %t30 = load { i64, ptr }, ptr %l9
  %t31 = load %"compiler/msgs:Msg", ptr %l10
  %t32 = load ptr, ptr %l11
  call void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %s1, ptr %v1, { i64, ptr } %t30, %"compiler/msgs:Msg" %t31, ptr %t32)
  br label %bb7
bb7:
  store i32 65536, ptr %l12
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i32, ptr %l12
  store i32 %t33, ptr %rv
  br label %ret
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l1
  %t2 = load ptr, ptr %l1
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 5
  %t4 = load i1, ptr %t3
  store i1 %t4, ptr %l2
  %t5 = load i1, ptr %l2
  br i1 %t5, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 5, ptr @.d72 }, ptr %l3
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d73 }, ptr %l3
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0
  store ptr %t6, ptr %l4
  %t7 = load ptr, ptr %l4
  %t8 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 4
  %t9 = load i1, ptr %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 6, ptr @.d74 }, ptr %l6
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr @.d75 }, ptr %l6
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0
  store ptr %t11, ptr %l7
  %t12 = load ptr, ptr %l7
  %t13 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 6
  %t14 = load i1, ptr %t13
  store i1 %t14, ptr %l8
  %t15 = load i1, ptr %l8
  br i1 %t15, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 4, ptr @.d76 }, ptr %l9
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr @.d77 }, ptr %l9
  br label %bb9
bb9:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t16 = load { i64, ptr }, ptr %l3
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load { i64, ptr }, ptr %l6
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  call void @__olang_sb_put(ptr %s1, ptr %t20, i64 %t21)
  %t22 = load { i64, ptr }, ptr %l9
  %t23 = extractvalue { i64, ptr } %t22, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l10
  call void @__olang_sb_done(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l4
  %t2 = load ptr, ptr %l4
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 10
  %t4 = load i1, ptr %t3
  store i1 %t4, ptr %l5
  %t5 = load i1, ptr %l5
  %t6 = xor i1 %t5, true
  store i1 %t6, ptr %l6
  %t7 = load i1, ptr %l6
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t8, ptr %l7
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t9 = load { i64, ptr }, ptr %l7
  %t10 = extractvalue { i64, ptr } %t9, 1
  %t11 = extractvalue { i64, ptr } %t9, 0
  call void @__olang_sb_put(ptr %s2, ptr %t10, i64 %t11)
  %t12 = load ptr, ptr %s2
  %t13 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t14 = load i64, ptr %t13
  %t15 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t14)
  call void @llvm.memcpy.p0.p0.i64(ptr %t15, ptr %t12, i64 %t14, i1 false)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  store { i64, ptr } %t17, ptr %l8
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t18, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t19 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t19, ptr %l9
  br label %bb4
bb4:
  %t20 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t20, ptr %l3
  store ptr %l3, ptr %l10
  %t21 = load ptr, ptr %l10
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t21, i8 27)
  br label %bb5
bb5:
  store ptr %l3, ptr %l11
  %t22 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t22, ptr %l12
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d78 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t23, i64 %t24)
  %t25 = load { i64, ptr }, ptr %l12
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  call void @__olang_sb_put(ptr %s3, ptr %t26, i64 %t27)
  %t28 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 1
  %t29 = extractvalue { i64, ptr } { i64 1, ptr @.d79 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t28, i64 %t29)
  %t30 = load ptr, ptr %s3
  %t31 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t32 = load i64, ptr %t31
  %t33 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t32)
  call void @llvm.memcpy.p0.p0.i64(ptr %t33, ptr %t30, i64 %t32, i1 false)
  %t34 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l13
  call void @__olang_sb_done(ptr %s3)
  %t36 = load { i64, ptr }, ptr %l13
  %t37 = extractvalue { i64, ptr } %t36, 0
  %t38 = extractvalue { i64, ptr } %t36, 1
  %t39 = mul i64 %t37, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t38, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l14
  %t43 = load ptr, ptr %l11
  %t44 = load { i64, ptr }, ptr %l14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t43, { i64, ptr } %t44)
  br label %bb6
bb6:
  store ptr %l3, ptr %l15
  %t45 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t45, ptr %l16
  %t46 = load ptr, ptr %l15
  %t47 = load { i64, ptr }, ptr %l16
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v2, ptr %t46, { i64, ptr } %t47)
  br label %bb7
bb7:
  store ptr %l3, ptr %l17
  %t48 = load ptr, ptr %l17
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t48, i8 27)
  br label %bb8
bb8:
  store ptr %l3, ptr %l18
  %t49 = load ptr, ptr %l18
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t49, { i64, ptr } { i64 3, ptr @.d80 })
  br label %bb9
bb9:
  store ptr %l3, ptr %l19
  %t50 = load ptr, ptr %l19
  %t51 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %t50)
  store { i64, ptr } %t51, ptr %l20
  br label %bb10
bb10:
  %t52 = load { i64, ptr }, ptr %l20
  store { i64, ptr } %t52, ptr %l21
  %t53 = load { i64, ptr }, ptr %l21
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l22
  %t55 = load i64, ptr %l22
  %t56 = mul i64 %t55, 1
  %t57 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l23
  %t60 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t61 = load ptr, ptr %t60
  %t62 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t63 = load ptr, ptr %t62
  %t64 = load i64, ptr %l22
  %t65 = mul i64 %t64, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l23
  store { i64, ptr } %t66, ptr %l21
  call void @__olang_scope_close(ptr %s0)
  %t67 = load { i64, ptr }, ptr %l21
  store { i64, ptr } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l3
  %t2 = load ptr, ptr %l3
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v2, ptr %s0, ptr %t2)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5
  %t11 = load { i64, ptr }, ptr %l5
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t11)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0
  store ptr %t12, ptr %l6
  %t13 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t13, ptr %l7
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t14 = load { i64, ptr }, ptr %l7
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  call void @__olang_sb_put(ptr %s1, ptr %t15, i64 %t16)
  %t17 = extractvalue { i64, ptr } { i64 27, ptr @.d81 }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr @.d81 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t17, i64 %t18)
  %t19 = load ptr, ptr %s1
  %t20 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t21 = load i64, ptr %t20
  %t22 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t19, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t21, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  store { i64, ptr } %t24, ptr %l8
  call void @__olang_sb_done(ptr %s1)
  %t25 = load { i64, ptr }, ptr %l8
  %t26 = extractvalue { i64, ptr } %t25, 0
  %t27 = extractvalue { i64, ptr } %t25, 1
  %t28 = mul i64 %t26, 1
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @llvm.memcpy.p0.p0.i64(ptr %t29, ptr %t27, i64 %t28, i1 false)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l9
  %t32 = load ptr, ptr %l6
  %t33 = load { i64, ptr }, ptr %l9
  %t34 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t32, { i64, ptr } { i64 2, ptr @.d82 }, { i64, ptr } %t33)
  store { i64, ptr } %t34, ptr %l10
  br label %bb3
bb3:
  %t35 = load { i64, ptr }, ptr %l10
  %t36 = extractvalue { i64, ptr } %t35, 0
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = mul i64 %t36, 1
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @llvm.memcpy.p0.p0.i64(ptr %t39, ptr %t37, i64 %t38, i1 false)
  %t40 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l11
  %t42 = load { i64, ptr }, ptr %l11
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t42)
  br label %bb4
bb4:
  store i32 1, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l12
  store i32 %t43, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"compiler/msgs:Msg"
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l4
  %t2 = load %"compiler/msgs:Msg", ptr %l2
  store %"compiler/msgs:Msg" %t2, ptr %l5
  %t3 = load ptr, ptr %l3
  store ptr %t3, ptr %l6
  %t4 = load { i64, ptr }, ptr %l4
  %t5 = load %"compiler/msgs:Msg", ptr %l5
  %t6 = load ptr, ptr %l6
  call void @compiler_2fbuild_2efileError(ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t4, %"compiler/msgs:Msg" %t5, ptr %t6)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3
  store ptr %t7, ptr %l7
  %t8 = load ptr, ptr %l7
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s0, ptr %t8)
  store { i64, ptr } %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l9
  %t17 = load { i64, ptr }, ptr %l9
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t17)
  br label %bb3
bb3:
  %t18 = load ptr, ptr %l0
  store ptr %t18, ptr %l10
  %t19 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t19, ptr %l11
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t20 = load { i64, ptr }, ptr %l11
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s1, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 27, ptr @.d83 }, 1
  %t24 = extractvalue { i64, ptr } { i64 27, ptr @.d83 }, 0
  call void @__olang_sb_put(ptr %s1, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s1
  %t26 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l12
  call void @__olang_sb_done(ptr %s1)
  %t31 = load { i64, ptr }, ptr %l12
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l13
  %t38 = load ptr, ptr %l10
  %t39 = load { i64, ptr }, ptr %l13
  %t40 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t38, { i64, ptr } { i64 2, ptr @.d84 }, { i64, ptr } %t39)
  store { i64, ptr } %t40, ptr %l14
  br label %bb4
bb4:
  %t41 = load { i64, ptr }, ptr %l14
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l15
  %t48 = load { i64, ptr }, ptr %l15
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t48)
  br label %bb5
bb5:
  store i32 1, ptr %l16
  call void @__olang_scope_close(ptr %s0)
  %t49 = load i32, ptr %l16
  store i32 %t49, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %lp7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca { i64, ptr }
  %l20 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca i32
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i1
  %l29 = alloca i1
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca { i64, ptr }
  %l33 = alloca ptr
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i1
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l51 = alloca i32
  %l52 = alloca i1
  %l53 = alloca i32
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"compiler/msgs:Msg"
  %l56 = alloca ptr
  %l57 = alloca i32
  %l58 = alloca ptr
  %l59 = alloca { i64, ptr }
  %l60 = alloca i1
  %l61 = alloca ptr
  %l62 = alloca { i64, [3 x i64] }
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l65 = alloca i32
  %l66 = alloca { i64, ptr }
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l78 = alloca ptr
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca i32
  %l82 = alloca i32
  %l83 = alloca i1
  %l84 = alloca i32
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i1
  %l90 = alloca i1
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca ptr
  %l104 = alloca ptr
  %l105 = alloca ptr
  %l106 = alloca { i64, ptr }
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca ptr
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca ptr
  %l116 = alloca { i64, ptr }
  %l117 = alloca ptr
  %l118 = alloca ptr
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca ptr
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l127 = alloca ptr
  %l128 = alloca ptr
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l132 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %s16 = alloca %olang.builder
  %s16room = alloca [64 x i8], align 8
  %rv = alloca { i32, { i64, ptr } }
  %t132 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l18
  %t2 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t2, ptr %l19
  %t3 = load ptr, ptr %l18
  %t4 = load { i64, ptr }, ptr %l19
  %t5 = call %"std/prelude/list:List<std/prelude/text:String&>" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v3, ptr %s0, ptr %t3, { i64, ptr } %t4)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %l20
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l20
  store %"std/prelude/list:List<std/prelude/text:String&>" %t6, ptr %l6
  %t7 = load ptr, ptr %l0
  store ptr %t7, ptr %l21
  %t8 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t8, ptr %l22
  %t9 = load i32, ptr %l3
  store i32 %t9, ptr %l23
  %t10 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t10, ptr %l24
  store ptr %l6, ptr %l25
  %t11 = load ptr, ptr %l21
  %t12 = load { i64, ptr }, ptr %l22
  %t13 = load i32, ptr %l23
  %t14 = load { i64, ptr }, ptr %l24
  %t15 = load ptr, ptr %l25
  %t16 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v2, ptr %v3, ptr %s0, ptr %v5, ptr %t11, { i64, ptr } %t12, i32 %t13, { i64, ptr } %t14, ptr %t15)
  store { i64, ptr } %t16, ptr %l26
  br label %bb2
bb2:
  %t17 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 16, i64 8)
  store ptr %t17, ptr %lp7
  %t18 = load { i64, ptr }, ptr %l26
  %t19 = load ptr, ptr %lp7
  store { i64, ptr } %t18, ptr %t19
  %t20 = load ptr, ptr %lp7
  %t21 = load { i64, ptr }, ptr %t20
  store { i64, ptr } %t21, ptr %l27
  %t22 = load { i64, ptr }, ptr %l27
  %t23 = call i1 @std_2fos_2eExists(ptr %v5, { i64, ptr } %t22)
  store i1 %t23, ptr %l28
  br label %bb3
bb3:
  %t24 = load i1, ptr %l28
  br i1 %t24, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l29
  br label %bb7
bb5:
  %t25 = load ptr, ptr %lp7
  %t26 = load { i64, ptr }, ptr %t25
  store { i64, ptr } %t26, ptr %l30
  %t27 = load { i64, ptr }, ptr %l30
  %t28 = extractvalue { i64, ptr } %t27, 0
  store i64 %t28, ptr %l31
  %t29 = load i64, ptr %l31
  %t30 = mul i64 %t29, 1
  %t31 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t30)
  %t32 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l32
  %t34 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t35 = load ptr, ptr %t34
  %t36 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  %t38 = load i64, ptr %l31
  %t39 = mul i64 %t38, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t35, ptr %t37, i64 %t39, i1 false)
  %t40 = load { i64, ptr }, ptr %l32
  store { i64, ptr } %t40, ptr %l8
  %t41 = load ptr, ptr %l1
  store ptr %t41, ptr %l33
  %t42 = load ptr, ptr %l33
  %t43 = getelementptr %"compiler/build:compiles", ptr %t42, i32 0, i32 2
  store ptr %t43, ptr %l34
  %t44 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t44, ptr %l35
  %t45 = load ptr, ptr %l34
  %t46 = load { i64, ptr }, ptr %l35
  %t47 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v1, ptr %s0, ptr %t45, { i64, ptr } %t46)
  store i1 %t47, ptr %l36
  br label %bb6
bb6:
  %t48 = load i1, ptr %l36
  store i1 %t48, ptr %l29
  br label %bb7
bb7:
  %t49 = load i1, ptr %l29
  br i1 %t49, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  %t50 = load ptr, ptr %lp7
  %t51 = load { i64, ptr }, ptr %t50
  store { i64, ptr } %t51, ptr %l37
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l37
  %t53 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t52, 1
  store { i32, { i64, ptr } } %t53, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t54 = load ptr, ptr %lp7
  %t55 = load { i64, ptr }, ptr %t54
  store { i64, ptr } %t55, ptr %l38
  %t56 = load { i64, ptr }, ptr %l38
  %t57 = extractvalue { i64, ptr } %t56, 0
  store i64 %t57, ptr %l39
  %t58 = load i64, ptr %l39
  %t59 = sub i64 %t58, 2
  store i64 %t59, ptr %l40
  %t60 = load ptr, ptr %lp7
  %t61 = load { i64, ptr }, ptr %t60
  %t62 = extractvalue { i64, ptr } %t61, 0
  store i64 %t62, ptr %l41
  %t63 = icmp sge i64 0, 0
  store i1 %t63, ptr %l42
  %t64 = load i1, ptr %l42
  br i1 %t64, label %bb11, label %bb12
bb11:
  %t65 = load i64, ptr %l40
  %t66 = icmp sle i64 0, %t65
  store i1 %t66, ptr %l43
  %t67 = load i1, ptr %l43
  br i1 %t67, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c85)
  unreachable
bb13:
  %t68 = load i64, ptr %l40
  %t69 = load i64, ptr %l41
  %t70 = icmp sle i64 %t68, %t69
  store i1 %t70, ptr %l44
  %t71 = load i1, ptr %l44
  br i1 %t71, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @.c85)
  unreachable
bb15:
  %t72 = load ptr, ptr %lp7
  %t73 = getelementptr { i64, ptr }, ptr %t72, i32 0, i32 1
  %t74 = load ptr, ptr %t73
  %t75 = load i64, ptr %l40
  %t76 = getelementptr i8, ptr %t74, i64 0
  %t77 = sub i64 %t75, 0
  %t78 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t76, 1
  store { i64, ptr } %t79, ptr %l45
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t80 = load { i64, ptr }, ptr %l45
  %t81 = extractvalue { i64, ptr } %t80, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  call void @__olang_sb_put(ptr %s2, ptr %t81, i64 %t82)
  %t83 = extractvalue { i64, ptr } { i64 3, ptr @.d86 }, 1
  %t84 = extractvalue { i64, ptr } { i64 3, ptr @.d86 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t83, i64 %t84)
  %t85 = load ptr, ptr %s2
  %t86 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t87 = load i64, ptr %t86
  %t88 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t87)
  call void @llvm.memcpy.p0.p0.i64(ptr %t88, ptr %t85, i64 %t87, i1 false)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l46
  call void @__olang_sb_done(ptr %s2)
  %t91 = load { i64, ptr }, ptr %l46
  store { i64, ptr } %t91, ptr %l9
  %t92 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t92, ptr %l47
  %t93 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t93, ptr %l48
  %t94 = load { i64, ptr }, ptr %l48
  store { i64, ptr } %t94, ptr %l49
  %t95 = load { i64, ptr }, ptr %l47
  %t96 = load { i64, ptr }, ptr %l49
  %t97 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v3, { i64, ptr } %t95, { i64, ptr } %t96)
  store i32 %t97, ptr %l50
  %t98 = icmp ne i32 %t97, 0
  br i1 %t98, label %bb18, label %ok.99
ok.99:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c85)
  unreachable
bb17:
  br label %bb24
bb18:
  %t100 = load i32, ptr %l50
  %t101 = ashr i32 %t100, 16
  store i32 %t101, ptr %l51
  %t102 = load i32, ptr %l51
  %t103 = icmp eq i32 %t102, 1
  store i1 %t103, ptr %l52
  %t104 = load i1, ptr %l52
  br i1 %t104, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  %t105 = load i32, ptr %l50
  %t106 = lshr i32 %t105, 16
  %t107 = and i32 %t105, 65535
  %t108 = icmp eq i32 %t106, 1
  %t109 = select i1 %t108, i32 0, i32 0
  %t110 = icmp eq i32 %t105, 0
  %t111 = shl i32 %t109, 16
  %t112 = or i32 %t111, %t107
  %t113 = select i1 %t110, i32 0, i32 %t112
  store i32 %t113, ptr %l53
  call void @__olang_scope_close(ptr %s0)
  %t114 = load i32, ptr %l53
  %t115 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t114, 0
  store { i32, { i64, ptr } } %t115, ptr %rv
  br label %ret
bb21:
  store %olang.scope zeroinitializer, ptr %s3
  %t116 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t116, ptr %l54
  %t117 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s3)
  store %"compiler/msgs:Msg" %t117, ptr %l55
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l5
  store ptr %t118, ptr %l56
  %t119 = load { i64, ptr }, ptr %l54
  %t120 = load %"compiler/msgs:Msg", ptr %l55
  %t121 = load ptr, ptr %l56
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s3, ptr %v4, { i64, ptr } %t119, %"compiler/msgs:Msg" %t120, ptr %t121)
  br label %bb23
bb23:
  store i32 65536, ptr %l57
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t122 = load i32, ptr %l57
  %t123 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t122, 0
  store { i32, { i64, ptr } } %t123, ptr %rv
  br label %ret
bb24:
  %t124 = load ptr, ptr %l0
  store ptr %t124, ptr %l58
  %t125 = load ptr, ptr %l58
  %t126 = getelementptr %"compiler/build:Config", ptr %t125, i32 0, i32 1
  %t127 = load { i64, ptr }, ptr %t126
  store { i64, ptr } %t127, ptr %l59
  %t128 = load { i64, ptr }, ptr %l59
  %t129 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t128, { i64, ptr } { i64 0, ptr @.d87 })
  store i1 %t129, ptr %l60
  br label %bb25
bb25:
  %t130 = load i1, ptr %l60
  br i1 %t130, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s4
  %t131 = load ptr, ptr %l5
  store ptr %t131, ptr %l61
  store { i64, [3 x i64] } zeroinitializer, ptr %t132
  %t133 = getelementptr { i64, [3 x i64] }, ptr %t132, i32 0, i32 0
  store i64 0, ptr %t133
  %t134 = load { i64, [3 x i64] }, ptr %t132
  store { i64, [3 x i64] } %t134, ptr %l62
  %t135 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t135, ptr %l63
  %t136 = load { i64, ptr }, ptr %l63
  %t137 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %s0, ptr %s4, { i64, ptr } %t136)
  store %"compiler/msgs:Msg" %t137, ptr %l64
  br label %bb28
bb27:
  br label %bb30
bb28:
  %t138 = load ptr, ptr %l61
  %t139 = load { i64, [3 x i64] }, ptr %l62
  %t140 = load %"compiler/msgs:Msg", ptr %l64
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s4, ptr %t138, { i64, [3 x i64] } %t139, %"compiler/msgs:Msg" %t140)
  br label %bb29
bb29:
  store i32 65536, ptr %l65
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l65
  %t142 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t141, 0
  store { i32, { i64, ptr } } %t142, ptr %rv
  br label %ret
bb30:
  %t143 = load ptr, ptr %lp7
  %t144 = load { i64, ptr }, ptr %t143
  store { i64, ptr } %t144, ptr %l66
  %t145 = call i32 @getpid()
  store i32 %t145, ptr %l67
  br label %bb31
bb31:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t146 = load { i64, ptr }, ptr %l66
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  call void @__olang_sb_put(ptr %s5, ptr %t147, i64 %t148)
  %t149 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 1
  %t150 = extractvalue { i64, ptr } { i64 1, ptr @.d88 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t149, i64 %t150)
  %t151 = load i32, ptr %l67
  %t152 = sext i32 %t151 to i64
  %t153 = call ptr @__olang_sb_room(ptr %s5, i64 24)
  %t154 = call i64 @__olang_fmt_i64(ptr %t153, i64 %t152)
  call void @__olang_sb_add(ptr %s5, i64 %t154)
  %t155 = extractvalue { i64, ptr } { i64 4, ptr @.d89 }, 1
  %t156 = extractvalue { i64, ptr } { i64 4, ptr @.d89 }, 0
  call void @__olang_sb_put(ptr %s5, ptr %t155, i64 %t156)
  %t157 = load ptr, ptr %s5
  %t158 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t159 = load i64, ptr %t158
  %t160 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t157, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l68
  call void @__olang_sb_done(ptr %s5)
  %t163 = load { i64, ptr }, ptr %l68
  store { i64, ptr } %t163, ptr %l10
  %t164 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t164, ptr %l69
  br label %bb32
bb32:
  %t165 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l69
  %t166 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t165, ptr %t166
  store ptr %t166, ptr %l70
  %t167 = load ptr, ptr %l70
  store ptr %t167, ptr %l11
  %t168 = load ptr, ptr %l11
  store ptr %t168, ptr %l71
  %t169 = load ptr, ptr %l0
  store ptr %t169, ptr %l72
  %t170 = load ptr, ptr %l72
  %t171 = getelementptr %"compiler/build:Config", ptr %t170, i32 0, i32 1
  %t172 = load { i64, ptr }, ptr %t171
  store { i64, ptr } %t172, ptr %l73
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t173 = load { i64, ptr }, ptr %l73
  %t174 = extractvalue { i64, ptr } %t173, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  call void @__olang_sb_put(ptr %s6, ptr %t174, i64 %t175)
  %t176 = load ptr, ptr %s6
  %t177 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t178 = load i64, ptr %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t178)
  call void @llvm.memcpy.p0.p0.i64(ptr %t179, ptr %t176, i64 %t178, i1 false)
  %t180 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t181 = insertvalue { i64, ptr } %t180, ptr %t179, 1
  store { i64, ptr } %t181, ptr %l74
  call void @__olang_sb_done(ptr %s6)
  %t182 = load { i64, ptr }, ptr %l74
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l75
  %t189 = load ptr, ptr %l71
  %t190 = load { i64, ptr }, ptr %l75
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t189, { i64, ptr } %t190)
  br label %bb33
bb33:
  store %olang.scope zeroinitializer, ptr %s7
  store ptr %l6, ptr %l76
  %t191 = load ptr, ptr %l76
  store ptr %t191, ptr %l12
  store i64 0, ptr %l13
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s8
  %t192 = load ptr, ptr %l12
  store ptr %t192, ptr %l78
  %t193 = load i64, ptr %l13
  store i64 %t193, ptr %l79
  %t194 = load ptr, ptr %l78
  %t195 = load i64, ptr %l79
  %t196 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t194, i64 %t195)
  %t197 = extractvalue { i32, { i64, ptr } } %t196, 1
  %t198 = extractvalue { i32, { i64, ptr } } %t196, 0
  store i32 %t198, ptr %l81
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb36, label %ok.200
ok.200:
  store { i64, ptr } %t197, ptr %l80
  br label %bb35
bb35:
  %t201 = load { i64, ptr }, ptr %l80
  store { i64, ptr } %t201, ptr %l77
  br label %bb40
bb36:
  %t202 = load i32, ptr %l81
  %t203 = ashr i32 %t202, 16
  store i32 %t203, ptr %l82
  %t204 = load i32, ptr %l82
  %t205 = icmp eq i32 %t204, 1
  store i1 %t205, ptr %l83
  %t206 = load i1, ptr %l83
  br i1 %t206, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  %t207 = load i32, ptr %l81
  %t208 = lshr i32 %t207, 16
  %t209 = and i32 %t207, 65535
  %t210 = icmp eq i32 %t208, 1
  %t211 = select i1 %t210, i32 0, i32 0
  %t212 = icmp eq i32 %t207, 0
  %t213 = shl i32 %t211, 16
  %t214 = or i32 %t213, %t209
  %t215 = select i1 %t212, i32 0, i32 %t214
  store i32 %t215, ptr %l84
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t216 = load i32, ptr %l84
  %t217 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t216, 0
  store { i32, { i64, ptr } } %t217, ptr %rv
  br label %ret
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb40:
  %t218 = load { i64, ptr }, ptr %l77
  store { i64, ptr } %t218, ptr %l14
  %t219 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t219, ptr %l85
  %t220 = load { i64, ptr }, ptr %l85
  %t221 = extractvalue { i64, ptr } %t220, 0
  store i64 %t221, ptr %l86
  %t222 = load i64, ptr %l86
  store i64 %t222, ptr %l15
  store i64 0, ptr %l16
  br label %bb41
bb41:
  store %olang.scope zeroinitializer, ptr %s9
  %t223 = load i64, ptr %l16
  store i64 %t223, ptr %l87
  %t224 = load i64, ptr %l15
  store i64 %t224, ptr %l88
  %t225 = load i64, ptr %l87
  %t226 = load i64, ptr %l88
  %t227 = icmp slt i64 %t225, %t226
  store i1 %t227, ptr %l89
  %t228 = load i1, ptr %l89
  %t229 = xor i1 %t228, true
  store i1 %t229, ptr %l90
  %t230 = load i1, ptr %l90
  br i1 %t230, label %bb42, label %bb43
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb47
bb43:
  br label %bb44
bb44:
  %t231 = load { i64, ptr }, ptr %l14
  store { i64, ptr } %t231, ptr %l91
  %t232 = load i64, ptr %l16
  store i64 %t232, ptr %l92
  %t233 = load i64, ptr %l92
  %t234 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t235 = load ptr, ptr %t234
  %t236 = getelementptr { i64, ptr }, ptr %t235, i64 %t233
  %t237 = load { i64, ptr }, ptr %t236
  store { i64, ptr } %t237, ptr %l93
  %t238 = load { i64, ptr }, ptr %l93
  store { i64, ptr } %t238, ptr %l17
  %t239 = load ptr, ptr %l11
  store ptr %t239, ptr %l94
  %t240 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t240, ptr %l95
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t241 = load { i64, ptr }, ptr %l95
  %t242 = extractvalue { i64, ptr } %t241, 1
  %t243 = extractvalue { i64, ptr } %t241, 0
  call void @__olang_sb_put(ptr %s10, ptr %t242, i64 %t243)
  %t244 = load ptr, ptr %s10
  %t245 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t246 = load i64, ptr %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t244, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  store { i64, ptr } %t249, ptr %l96
  call void @__olang_sb_done(ptr %s10)
  %t250 = load { i64, ptr }, ptr %l96
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l97
  %t257 = load ptr, ptr %l94
  %t258 = load { i64, ptr }, ptr %l97
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t257, { i64, ptr } %t258)
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s9)
  br label %bb46
bb46:
  store %olang.scope zeroinitializer, ptr %s11
  %t259 = load i64, ptr %l16
  store i64 %t259, ptr %l98
  %t260 = load i64, ptr %l98
  %t261 = add i64 %t260, 1
  store i64 %t261, ptr %l99
  %t262 = load i64, ptr %l99
  store i64 %t262, ptr %l16
  call void @__olang_scope_close(ptr %s11)
  br label %bb41
bb47:
  %t263 = load i64, ptr %l13
  store i64 %t263, ptr %l100
  %t264 = load i64, ptr %l15
  store i64 %t264, ptr %l101
  %t265 = load i64, ptr %l100
  %t266 = load i64, ptr %l101
  %t267 = add i64 %t265, %t266
  store i64 %t267, ptr %l102
  %t268 = load i64, ptr %l102
  store i64 %t268, ptr %l13
  call void @__olang_scope_close(ptr %s8)
  br label %bb48
bb48:
  br label %bb34
bb49:
  call void @__olang_scope_close(ptr %s7)
  %t269 = load ptr, ptr %l11
  store ptr %t269, ptr %l103
  %t270 = load ptr, ptr %l103
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t270, { i64, ptr } { i64 2, ptr @.d90 })
  br label %bb50
bb50:
  %t271 = load ptr, ptr %l11
  store ptr %t271, ptr %l104
  %t272 = load ptr, ptr %l104
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t272, { i64, ptr } { i64 2, ptr @.d91 })
  br label %bb51
bb51:
  %t273 = load ptr, ptr %l11
  store ptr %t273, ptr %l105
  %t274 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t274, ptr %l106
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t275 = load { i64, ptr }, ptr %l106
  %t276 = extractvalue { i64, ptr } %t275, 1
  %t277 = extractvalue { i64, ptr } %t275, 0
  call void @__olang_sb_put(ptr %s12, ptr %t276, i64 %t277)
  %t278 = load ptr, ptr %s12
  %t279 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t280 = load i64, ptr %t279
  %t281 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t278, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  store { i64, ptr } %t283, ptr %l107
  call void @__olang_sb_done(ptr %s12)
  %t284 = load { i64, ptr }, ptr %l107
  %t285 = extractvalue { i64, ptr } %t284, 0
  %t286 = extractvalue { i64, ptr } %t284, 1
  %t287 = mul i64 %t285, 1
  %t288 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t287)
  call void @llvm.memcpy.p0.p0.i64(ptr %t288, ptr %t286, i64 %t287, i1 false)
  %t289 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t290 = insertvalue { i64, ptr } %t289, ptr %t288, 1
  store { i64, ptr } %t290, ptr %l108
  %t291 = load ptr, ptr %l105
  %t292 = load { i64, ptr }, ptr %l108
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t291, { i64, ptr } %t292)
  br label %bb52
bb52:
  %t293 = load ptr, ptr %l11
  store ptr %t293, ptr %l109
  %t294 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t294, ptr %l110
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t295 = load { i64, ptr }, ptr %l110
  %t296 = extractvalue { i64, ptr } %t295, 1
  %t297 = extractvalue { i64, ptr } %t295, 0
  call void @__olang_sb_put(ptr %s13, ptr %t296, i64 %t297)
  %t298 = load ptr, ptr %s13
  %t299 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t300 = load i64, ptr %t299
  %t301 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t300)
  call void @llvm.memcpy.p0.p0.i64(ptr %t301, ptr %t298, i64 %t300, i1 false)
  %t302 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t303 = insertvalue { i64, ptr } %t302, ptr %t301, 1
  store { i64, ptr } %t303, ptr %l111
  call void @__olang_sb_done(ptr %s13)
  %t304 = load { i64, ptr }, ptr %l111
  %t305 = extractvalue { i64, ptr } %t304, 0
  %t306 = extractvalue { i64, ptr } %t304, 1
  %t307 = mul i64 %t305, 1
  %t308 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t307)
  call void @llvm.memcpy.p0.p0.i64(ptr %t308, ptr %t306, i64 %t307, i1 false)
  %t309 = insertvalue { i64, ptr } undef, i64 %t305, 0
  %t310 = insertvalue { i64, ptr } %t309, ptr %t308, 1
  store { i64, ptr } %t310, ptr %l112
  %t311 = load ptr, ptr %l109
  %t312 = load { i64, ptr }, ptr %l112
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t311, { i64, ptr } %t312)
  br label %bb53
bb53:
  %t313 = load ptr, ptr %l1
  store ptr %t313, ptr %l113
  %t314 = load ptr, ptr %l113
  %t315 = getelementptr %"compiler/build:compiles", ptr %t314, i32 0, i32 0
  store ptr %t315, ptr %l114
  %t316 = load ptr, ptr %l11
  store ptr %t316, ptr %l115
  %t317 = load ptr, ptr %l115
  %t318 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v1, ptr %v1, ptr %t317)
  store { i64, ptr } %t318, ptr %l116
  br label %bb54
bb54:
  %t319 = load ptr, ptr %l114
  %t320 = load { i64, ptr }, ptr %l116
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v1, ptr %v1, ptr %t319, { i64, ptr } %t320)
  br label %bb55
bb55:
  %t321 = load ptr, ptr %l1
  store ptr %t321, ptr %l117
  %t322 = load ptr, ptr %l117
  %t323 = getelementptr %"compiler/build:compiles", ptr %t322, i32 0, i32 1
  store ptr %t323, ptr %l118
  %t324 = load { i64, ptr }, ptr %l10
  store { i64, ptr } %t324, ptr %l119
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t325 = load { i64, ptr }, ptr %l119
  %t326 = extractvalue { i64, ptr } %t325, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  call void @__olang_sb_put(ptr %s14, ptr %t326, i64 %t327)
  %t328 = load ptr, ptr %s14
  %t329 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t330 = load i64, ptr %t329
  %t331 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t330)
  call void @llvm.memcpy.p0.p0.i64(ptr %t331, ptr %t328, i64 %t330, i1 false)
  %t332 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  store { i64, ptr } %t333, ptr %l120
  call void @__olang_sb_done(ptr %s14)
  %t334 = load { i64, ptr }, ptr %l120
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = extractvalue { i64, ptr } %t334, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  store { i64, ptr } %t340, ptr %l121
  %t341 = load ptr, ptr %l118
  %t342 = load { i64, ptr }, ptr %l121
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t341, { i64, ptr } %t342)
  br label %bb56
bb56:
  %t343 = load ptr, ptr %l1
  store ptr %t343, ptr %l122
  %t344 = load ptr, ptr %l122
  %t345 = getelementptr %"compiler/build:compiles", ptr %t344, i32 0, i32 2
  store ptr %t345, ptr %l123
  %t346 = load ptr, ptr %lp7
  %t347 = load { i64, ptr }, ptr %t346
  store { i64, ptr } %t347, ptr %l124
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t348 = load { i64, ptr }, ptr %l124
  %t349 = extractvalue { i64, ptr } %t348, 1
  %t350 = extractvalue { i64, ptr } %t348, 0
  call void @__olang_sb_put(ptr %s15, ptr %t349, i64 %t350)
  %t351 = load ptr, ptr %s15
  %t352 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t353 = load i64, ptr %t352
  %t354 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t353)
  call void @llvm.memcpy.p0.p0.i64(ptr %t354, ptr %t351, i64 %t353, i1 false)
  %t355 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l125
  call void @__olang_sb_done(ptr %s15)
  %t357 = load { i64, ptr }, ptr %l125
  %t358 = extractvalue { i64, ptr } %t357, 0
  %t359 = extractvalue { i64, ptr } %t357, 1
  %t360 = mul i64 %t358, 1
  %t361 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t360)
  call void @llvm.memcpy.p0.p0.i64(ptr %t361, ptr %t359, i64 %t360, i1 false)
  %t362 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t361, 1
  store { i64, ptr } %t363, ptr %l126
  %t364 = load ptr, ptr %l123
  %t365 = load { i64, ptr }, ptr %l126
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t364, { i64, ptr } %t365)
  br label %bb57
bb57:
  %t366 = load ptr, ptr %l1
  store ptr %t366, ptr %l127
  %t367 = load ptr, ptr %l127
  %t368 = getelementptr %"compiler/build:compiles", ptr %t367, i32 0, i32 3
  store ptr %t368, ptr %l128
  %t369 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t369, ptr %l129
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s16
  store ptr %s16room, ptr %s16
  %t370 = load { i64, ptr }, ptr %l129
  %t371 = extractvalue { i64, ptr } %t370, 1
  %t372 = extractvalue { i64, ptr } %t370, 0
  call void @__olang_sb_put(ptr %s16, ptr %t371, i64 %t372)
  %t373 = load ptr, ptr %s16
  %t374 = getelementptr %olang.builder, ptr %s16, i32 0, i32 1
  %t375 = load i64, ptr %t374
  %t376 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t375)
  call void @llvm.memcpy.p0.p0.i64(ptr %t376, ptr %t373, i64 %t375, i1 false)
  %t377 = insertvalue { i64, ptr } undef, i64 %t375, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  store { i64, ptr } %t378, ptr %l130
  call void @__olang_sb_done(ptr %s16)
  %t379 = load { i64, ptr }, ptr %l130
  %t380 = extractvalue { i64, ptr } %t379, 0
  %t381 = extractvalue { i64, ptr } %t379, 1
  %t382 = mul i64 %t380, 1
  %t383 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t382)
  call void @llvm.memcpy.p0.p0.i64(ptr %t383, ptr %t381, i64 %t382, i1 false)
  %t384 = insertvalue { i64, ptr } undef, i64 %t380, 0
  %t385 = insertvalue { i64, ptr } %t384, ptr %t383, 1
  store { i64, ptr } %t385, ptr %l131
  %t386 = load ptr, ptr %l128
  %t387 = load { i64, ptr }, ptr %l131
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t386, { i64, ptr } %t387)
  br label %bb58
bb58:
  %t388 = load ptr, ptr %lp7
  %t389 = load { i64, ptr }, ptr %t388
  store { i64, ptr } %t389, ptr %l132
  call void @__olang_scope_close(ptr %s0)
  %t390 = load { i64, ptr }, ptr %l132
  %t391 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t390, 1
  store { i32, { i64, ptr } } %t391, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i64
  %l11 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l2
  %t2 = load ptr, ptr %l2
  %t3 = getelementptr %"compiler/build:Config", ptr %t2, i32 0, i32 9
  %t4 = load i64, ptr %t3
  store i64 %t4, ptr %l3
  %t5 = load i64, ptr %l3
  %t6 = icmp sgt i64 %t5, 0
  store i1 %t6, ptr %l4
  %t7 = load i1, ptr %l4
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0
  store ptr %t8, ptr %l5
  %t9 = load ptr, ptr %l5
  %t10 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 9
  %t11 = load i64, ptr %t10
  store i64 %t11, ptr %l6
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i64, ptr %l6
  store i64 %t12, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call i64 @sysconf(i32 84)
  store i64 %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load i64, ptr %l7
  store i64 %t14, ptr %l1
  %t15 = load i64, ptr %l1
  store i64 %t15, ptr %l8
  %t16 = load i64, ptr %l8
  %t17 = icmp sgt i64 %t16, 0
  store i1 %t17, ptr %l9
  %t18 = load i1, ptr %l9
  br i1 %t18, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l1
  store i64 %t19, ptr %l11
  %t20 = load i64, ptr %l11
  store i64 %t20, ptr %l10
  br label %bb7
bb6:
  store i64 1, ptr %l10
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i64, ptr %l10
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/build:Unit"
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca %"compiler/build:Unit"
  %l25 = alloca i32
  %l26 = alloca ptr
  %l27 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i32
  %l32 = alloca ptr
  %l33 = alloca i32
  %l34 = alloca ptr
  %l35 = alloca i1
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca ptr
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca %"compiler/build:Unit"
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l7
  %t2 = load ptr, ptr %l7
  %t3 = getelementptr %"compiler/build:Program", ptr %t2, i32 0, i32 0
  store ptr %t3, ptr %l8
  %t4 = load ptr, ptr %l8
  store ptr %t4, ptr %l1
  store i64 0, ptr %l2
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l1
  store ptr %t5, ptr %l10
  %t6 = load i64, ptr %l2
  store i64 %t6, ptr %l11
  %t7 = load ptr, ptr %l10
  %t8 = load i64, ptr %l11
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l13
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t14, ptr %l9
  br label %bb7
bb3:
  %t15 = load i32, ptr %l13
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l14
  %t17 = load i32, ptr %l14
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l15
  %t19 = load i1, ptr %l15
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c92)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb7:
  %t20 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t20, ptr %l3
  %t21 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t21, ptr %l16
  %t22 = load { i64, ptr }, ptr %l16
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l17
  %t24 = load i64, ptr %l17
  store i64 %t24, ptr %l4
  store i64 0, ptr %l5
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5
  store i64 %t25, ptr %l18
  %t26 = load i64, ptr %l4
  store i64 %t26, ptr %l19
  %t27 = load i64, ptr %l18
  %t28 = load i64, ptr %l19
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l20
  %t30 = load i1, ptr %l20
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l21
  %t32 = load i1, ptr %l21
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t33, ptr %l22
  %t34 = load i64, ptr %l5
  store i64 %t34, ptr %l23
  %t35 = load i64, ptr %l23
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36
  %t38 = getelementptr %"compiler/build:Unit", ptr %t37, i64 %t35
  %t39 = load %"compiler/build:Unit", ptr %t38
  store %"compiler/build:Unit" %t39, ptr %l24
  %t40 = load %"compiler/build:Unit", ptr %l24
  store %"compiler/build:Unit" %t40, ptr %l6
  %t41 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l25
  store ptr %l25, ptr %l26
  store i32 1, ptr %l27
  store ptr %l27, ptr %l28
  %t43 = load ptr, ptr %l26
  %t44 = load ptr, ptr %l28
  %t45 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %t43, ptr %t44)
  store i1 %t45, ptr %l29
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30
  br label %bb16
bb14:
  %t47 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l31
  store ptr %l31, ptr %l32
  store i32 2, ptr %l33
  store ptr %l33, ptr %l34
  %t49 = load ptr, ptr %l32
  %t50 = load ptr, ptr %l34
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %t49, ptr %t50)
  store i1 %t51, ptr %l35
  br label %bb15
bb15:
  %t52 = load i1, ptr %l35
  store i1 %t52, ptr %l30
  br label %bb16
bb16:
  %t53 = load i1, ptr %l30
  br i1 %t53, label %bb17, label %bb18
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t54 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54
  store { i64, ptr } %t55, ptr %l36
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t56 = load { i64, ptr }, ptr %l36
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  call void @__olang_sb_put(ptr %s5, ptr %t57, i64 %t58)
  %t59 = load ptr, ptr %s5
  %t60 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t61 = load i64, ptr %t60
  %t62 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t59, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l37
  call void @__olang_sb_done(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t65 = load { i64, ptr }, ptr %l37
  store { i64, ptr } %t65, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t66 = load i64, ptr %l5
  store i64 %t66, ptr %l38
  %t67 = load i64, ptr %l38
  %t68 = add i64 %t67, 1
  store i64 %t68, ptr %l39
  %t69 = load i64, ptr %l39
  store i64 %t69, ptr %l5
  call void @__olang_scope_close(ptr %s6)
  br label %bb8
bb21:
  %t70 = load i64, ptr %l2
  store i64 %t70, ptr %l40
  %t71 = load i64, ptr %l4
  store i64 %t71, ptr %l41
  %t72 = load i64, ptr %l40
  %t73 = load i64, ptr %l41
  %t74 = add i64 %t72, %t73
  store i64 %t74, ptr %l42
  %t75 = load i64, ptr %l42
  store i64 %t75, ptr %l2
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb1
bb23:
  call void @__olang_scope_close(ptr %s1)
  %t76 = load ptr, ptr %l0
  store ptr %t76, ptr %l43
  %t77 = load ptr, ptr %l43
  %t78 = getelementptr %"compiler/build:Program", ptr %t77, i32 0, i32 0
  store ptr %t78, ptr %l44
  %t79 = load ptr, ptr %l44
  %t80 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t79)
  store i64 %t80, ptr %l45
  br label %bb24
bb24:
  %t81 = load i64, ptr %l45
  %t82 = icmp sgt i64 %t81, 0
  store i1 %t82, ptr %l46
  %t83 = load i1, ptr %l46
  br i1 %t83, label %bb25, label %bb26
bb25:
  %t84 = load ptr, ptr %l0
  store ptr %t84, ptr %l48
  %t85 = load ptr, ptr %l48
  %t86 = getelementptr %"compiler/build:Program", ptr %t85, i32 0, i32 0
  store ptr %t86, ptr %l49
  %t87 = load ptr, ptr %l49
  %t88 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t87, i64 0)
  store %"compiler/build:Unit" %t88, ptr %l50
  br label %bb27
bb26:
  store { i64, ptr } { i64 1, ptr @.d93 }, ptr %l53
  %t89 = load { i64, ptr }, ptr %l53
  store { i64, ptr } %t89, ptr %l54
  %t90 = load { i64, ptr }, ptr %l54
  store { i64, ptr } %t90, ptr %l47
  br label %bb28
bb27:
  %t91 = getelementptr %"compiler/build:Unit", ptr %l50, i32 0, i32 0
  %t92 = load { i64, ptr }, ptr %t91
  store { i64, ptr } %t92, ptr %l51
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t93 = load { i64, ptr }, ptr %l51
  %t94 = extractvalue { i64, ptr } %t93, 1
  %t95 = extractvalue { i64, ptr } %t93, 0
  call void @__olang_sb_put(ptr %s7, ptr %t94, i64 %t95)
  %t96 = load ptr, ptr %s7
  %t97 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t98 = load i64, ptr %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t96, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l52
  call void @__olang_sb_done(ptr %s7)
  %t102 = load { i64, ptr }, ptr %l52
  store { i64, ptr } %t102, ptr %l47
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t103 = load { i64, ptr }, ptr %l47
  store { i64, ptr } %t103, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [8 x i8]
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i32
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca [1 x i8]
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i1
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca [1 x i8]
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i1
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i8
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca ptr
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"std/prelude/text:StringBuilder"
  %l68 = alloca ptr
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i1
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca i32
  %l79 = alloca ptr
  %l80 = alloca i32
  %l81 = alloca i64
  %l82 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i64
  %l93 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l14
  %t2 = load ptr, ptr %l14
  %t3 = getelementptr %"compiler/build:Sha256", ptr %t2, i32 0, i32 3
  %t4 = load i64, ptr %t3
  store i64 %t4, ptr %l15
  %t5 = load i64, ptr %l15
  store i64 %t5, ptr %l16
  %t6 = load i64, ptr %l16
  %t7 = mul i64 %t6, 8
  store i64 %t7, ptr %l17
  %t8 = load i64, ptr %l17
  store i64 %t8, ptr %l1
  %t9 = load ptr, ptr %l0
  store ptr %t9, ptr %l18
  %t10 = insertvalue [1 x i8] undef, i8 -128, 0
  store [1 x i8] %t10, ptr %l19
  %t11 = load [1 x i8], ptr %l19
  %t12 = load ptr, ptr @__olang_prog_scope
  %t13 = call ptr @__olang_scope_alloc(ptr %t12, i64 1)
  store [1 x i8] %t11, ptr %t13
  %t14 = insertvalue { i64, ptr } undef, i64 1, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l20
  %t16 = load { i64, ptr }, ptr %l20
  %t17 = extractvalue { i64, ptr } %t16, 0
  %t18 = extractvalue { i64, ptr } %t16, 1
  %t19 = mul i64 %t17, 1
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @llvm.memcpy.p0.p0.i64(ptr %t20, ptr %t18, i64 %t19, i1 false)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t20, 1
  store { i64, ptr } %t22, ptr %l21
  %t23 = load ptr, ptr %l18
  %t24 = load { i64, ptr }, ptr %l21
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t23, { i64, ptr } %t24)
  br label %bb1
bb1:
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t25 = load ptr, ptr %l0
  store ptr %t25, ptr %l22
  %t26 = load ptr, ptr %l22
  %t27 = getelementptr %"compiler/build:Sha256", ptr %t26, i32 0, i32 2
  %t28 = load i64, ptr %t27
  store i64 %t28, ptr %l23
  %t29 = load i64, ptr %l23
  %t30 = icmp ne i64 %t29, 56
  store i1 %t30, ptr %l24
  %t31 = load i1, ptr %l24
  %t32 = xor i1 %t31, true
  store i1 %t32, ptr %l25
  %t33 = load i1, ptr %l25
  br i1 %t33, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t34 = load ptr, ptr %l0
  store ptr %t34, ptr %l26
  %t35 = insertvalue [1 x i8] undef, i8 0, 0
  store [1 x i8] %t35, ptr %l27
  %t36 = load [1 x i8], ptr %l27
  %t37 = load ptr, ptr @__olang_prog_scope
  %t38 = call ptr @__olang_scope_alloc(ptr %t37, i64 1)
  store [1 x i8] %t36, ptr %t38
  %t39 = insertvalue { i64, ptr } undef, i64 1, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } %t40, ptr %l28
  %t41 = load { i64, ptr }, ptr %l28
  %t42 = extractvalue { i64, ptr } %t41, 0
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = mul i64 %t42, 1
  %t45 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t44)
  call void @llvm.memcpy.p0.p0.i64(ptr %t45, ptr %t43, i64 %t44, i1 false)
  %t46 = insertvalue { i64, ptr } undef, i64 %t42, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  store { i64, ptr } %t47, ptr %l29
  %t48 = load ptr, ptr %l26
  %t49 = load { i64, ptr }, ptr %l29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s1, ptr %t48, { i64, ptr } %t49)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb2
bb8:
  store [8 x i8] zeroinitializer, ptr %l2
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l3
  store i64 8, ptr %l4
  store i64 1, ptr %l5
  %t50 = load i64, ptr %l4
  store i64 %t50, ptr %l30
  %t51 = load i64, ptr %l3
  store i64 %t51, ptr %l31
  %t52 = load i64, ptr %l30
  %t53 = load i64, ptr %l31
  %t54 = icmp sgt i64 %t52, %t53
  store i1 %t54, ptr %l32
  %t55 = load i1, ptr %l32
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t56 = load i64, ptr %l5
  store i64 %t56, ptr %l34
  %t57 = load i64, ptr %l34
  %t58 = icmp sgt i64 %t57, 0
  store i1 %t58, ptr %l35
  %t59 = load i1, ptr %l35
  br i1 %t59, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l33
  br label %bb14
bb11:
  %t60 = load i64, ptr %l4
  store i64 %t60, ptr %l37
  %t61 = load i64, ptr %l3
  store i64 %t61, ptr %l38
  %t62 = load i64, ptr %l37
  %t63 = load i64, ptr %l38
  %t64 = sub i64 %t62, %t63
  store i64 %t64, ptr %l39
  %t65 = load i64, ptr %l5
  store i64 %t65, ptr %l40
  %t66 = load i64, ptr %l39
  %t67 = load i64, ptr %l40
  %t68 = add i64 %t66, %t67
  store i64 %t68, ptr %l41
  %t69 = load i64, ptr %l41
  %t70 = sub i64 %t69, 1
  store i64 %t70, ptr %l42
  %t71 = load i64, ptr %l5
  store i64 %t71, ptr %l43
  %t72 = load i64, ptr %l42
  %t73 = load i64, ptr %l43
  %t74 = sdiv i64 %t72, %t73
  store i64 %t74, ptr %l44
  %t75 = load i64, ptr %l44
  store i64 %t75, ptr %l36
  br label %bb13
bb12:
  store i64 0, ptr %l36
  br label %bb13
bb13:
  %t76 = load i64, ptr %l36
  store i64 %t76, ptr %l33
  br label %bb14
bb14:
  %t77 = load i64, ptr %l33
  store i64 %t77, ptr %l6
  store i64 0, ptr %l7
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t78 = load i64, ptr %l7
  store i64 %t78, ptr %l45
  %t79 = load i64, ptr %l6
  store i64 %t79, ptr %l46
  %t80 = load i64, ptr %l45
  %t81 = load i64, ptr %l46
  %t82 = icmp slt i64 %t80, %t81
  store i1 %t82, ptr %l47
  %t83 = load i1, ptr %l47
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l48
  %t85 = load i1, ptr %l48
  br i1 %t85, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t86 = load i64, ptr %l3
  store i64 %t86, ptr %l49
  %t87 = load i64, ptr %l7
  store i64 %t87, ptr %l50
  %t88 = load i64, ptr %l5
  store i64 %t88, ptr %l51
  %t89 = load i64, ptr %l50
  %t90 = load i64, ptr %l51
  %t91 = mul i64 %t89, %t90
  store i64 %t91, ptr %l52
  %t92 = load i64, ptr %l49
  %t93 = load i64, ptr %l52
  %t94 = add i64 %t92, %t93
  store i64 %t94, ptr %l53
  %t95 = load i64, ptr %l53
  store i64 %t95, ptr %l8
  %t96 = load i64, ptr %l8
  store i64 %t96, ptr %l54
  %t97 = load i64, ptr %l1
  store i64 %t97, ptr %l55
  %t98 = load i64, ptr %l8
  store i64 %t98, ptr %l56
  %t99 = load i64, ptr %l56
  %t100 = mul i64 8, %t99
  store i64 %t100, ptr %l57
  %t101 = load i64, ptr %l57
  %t102 = sub i64 56, %t101
  store i64 %t102, ptr %l58
  %t103 = load i64, ptr %l58
  store i64 %t103, ptr %l59
  %t104 = load i64, ptr %l55
  %t105 = load i64, ptr %l59
  %t106 = load i64, ptr %l59
  %t107 = lshr i64 %t104, %t106
  store i64 %t107, ptr %l60
  %t108 = load i64, ptr %l60
  %t109 = trunc i64 %t108 to i8
  store i8 %t109, ptr %l61
  %t110 = load i8, ptr %l61
  %t111 = load i64, ptr %l54
  %t112 = getelementptr [8 x i8], ptr %l2, i64 0, i64 %t111
  store i8 %t110, ptr %t112
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s4
  %t113 = load i64, ptr %l7
  store i64 %t113, ptr %l62
  %t114 = load i64, ptr %l62
  %t115 = add i64 %t114, 1
  store i64 %t115, ptr %l63
  %t116 = load i64, ptr %l63
  store i64 %t116, ptr %l7
  call void @__olang_scope_close(ptr %s4)
  br label %bb15
bb20:
  call void @__olang_scope_close(ptr %s2)
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l64
  store ptr %l2, ptr %l65
  %t118 = load ptr, ptr %l65
  %t119 = insertvalue { i64, ptr } undef, i64 8, 0
  %t120 = insertvalue { i64, ptr } %t119, ptr %t118, 1
  store { i64, ptr } %t120, ptr %l66
  %t121 = load ptr, ptr %l64
  %t122 = load { i64, ptr }, ptr %l66
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t121, { i64, ptr } %t122)
  br label %bb21
bb21:
  %t123 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t123, ptr %l67
  br label %bb22
bb22:
  %t124 = load %"std/prelude/text:StringBuilder", ptr %l67
  store %"std/prelude/text:StringBuilder" %t124, ptr %l9
  store %olang.scope zeroinitializer, ptr %s5
  %t125 = load ptr, ptr %l0
  store ptr %t125, ptr %l68
  %t126 = load ptr, ptr %l68
  %t127 = getelementptr %"compiler/build:Sha256", ptr %t126, i32 0, i32 0
  store ptr %t127, ptr %l69
  %t128 = load ptr, ptr %l69
  store ptr %t128, ptr %l10
  store i64 0, ptr %l11
  %t129 = load ptr, ptr %l10
  store ptr %t129, ptr %l70
  %t130 = load ptr, ptr %l70
  store i64 8, ptr %l71
  %t131 = load i64, ptr %l71
  store i64 %t131, ptr %l12
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t132 = load i64, ptr %l11
  store i64 %t132, ptr %l72
  %t133 = load i64, ptr %l12
  store i64 %t133, ptr %l73
  %t134 = load i64, ptr %l72
  %t135 = load i64, ptr %l73
  %t136 = icmp slt i64 %t134, %t135
  store i1 %t136, ptr %l74
  %t137 = load i1, ptr %l74
  %t138 = xor i1 %t137, true
  store i1 %t138, ptr %l75
  %t139 = load i1, ptr %l75
  br i1 %t139, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t140 = load ptr, ptr %l10
  store ptr %t140, ptr %l76
  %t141 = load i64, ptr %l11
  store i64 %t141, ptr %l77
  %t142 = load ptr, ptr %l76
  %t143 = load i64, ptr %l77
  %t144 = getelementptr [8 x i32], ptr %t142, i64 0, i64 %t143
  %t145 = load i32, ptr %t144
  store i32 %t145, ptr %l78
  %t146 = load i32, ptr %l78
  store i32 %t146, ptr %l13
  store ptr %l9, ptr %l79
  %t147 = load i32, ptr %l13
  store i32 %t147, ptr %l80
  %t148 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 16)
  %t149 = extractvalue { i32, i64 } %t148, 1
  %t150 = extractvalue { i32, i64 } %t148, 0
  store i32 %t150, ptr %l82
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb28, label %ok.152
ok.152:
  store i64 %t149, ptr %l81
  br label %bb27
bb27:
  %t153 = load i32, ptr %l80
  %t154 = load i64, ptr %l81
  %t155 = call { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %s6, i32 %t153, i64 %t154)
  store { i64, ptr } %t155, ptr %l83
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c94)
  unreachable
bb29:
  %t156 = load { i64, ptr }, ptr %l83
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  store { i64, ptr } %t162, ptr %l84
  %t163 = load { i64, ptr }, ptr %l84
  %t164 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t163, i64 8, i8 48)
  store { i64, ptr } %t164, ptr %l85
  br label %bb30
bb30:
  %t165 = load { i64, ptr }, ptr %l85
  %t166 = extractvalue { i64, ptr } %t165, 0
  %t167 = extractvalue { i64, ptr } %t165, 1
  %t168 = mul i64 %t166, 1
  %t169 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t168)
  call void @llvm.memcpy.p0.p0.i64(ptr %t169, ptr %t167, i64 %t168, i1 false)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t169, 1
  store { i64, ptr } %t171, ptr %l86
  %t172 = load ptr, ptr %l79
  %t173 = load { i64, ptr }, ptr %l86
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t172, { i64, ptr } %t173)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s7
  %t174 = load i64, ptr %l11
  store i64 %t174, ptr %l87
  %t175 = load i64, ptr %l87
  %t176 = add i64 %t175, 1
  store i64 %t176, ptr %l88
  %t177 = load i64, ptr %l88
  store i64 %t177, ptr %l11
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb33:
  call void @__olang_scope_close(ptr %s5)
  store ptr %l9, ptr %l89
  %t178 = load ptr, ptr %l89
  %t179 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t178)
  store { i64, ptr } %t179, ptr %l90
  br label %bb34
bb34:
  %t180 = load { i64, ptr }, ptr %l90
  store { i64, ptr } %t180, ptr %l91
  %t181 = load { i64, ptr }, ptr %l91
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l92
  %t183 = load i64, ptr %l92
  %t184 = mul i64 %t183, 1
  %t185 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l93
  %t188 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t189 = load ptr, ptr %t188
  %t190 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t191 = load ptr, ptr %t190
  %t192 = load i64, ptr %l92
  %t193 = mul i64 %t192, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t189, ptr %t191, i64 %t193, i1 false)
  %t194 = load { i64, ptr }, ptr %l93
  store { i64, ptr } %t194, ptr %l91
  call void @__olang_scope_close(ptr %s0)
  %t195 = load { i64, ptr }, ptr %l91
  store { i64, ptr } %t195, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i1
  %l20 = alloca i1
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i8
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i1
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %l58 = alloca i64
  %l59 = alloca i8
  %l60 = alloca ptr
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l2
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l4
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l5
  %t4 = load i64, ptr %l5
  store i64 %t4, ptr %l3
  %t5 = load ptr, ptr %l0
  store ptr %t5, ptr %l6
  %t6 = load ptr, ptr %l6
  %t7 = getelementptr %"compiler/build:Sha256", ptr %t6, i32 0, i32 3
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l7
  %t9 = load i64, ptr %l3
  store i64 %t9, ptr %l8
  %t10 = load i64, ptr %l7
  %t11 = load i64, ptr %l8
  %t12 = add i64 %t10, %t11
  store i64 %t12, ptr %l9
  %t13 = load i64, ptr %l9
  %t14 = load ptr, ptr %l6
  %t15 = getelementptr %"compiler/build:Sha256", ptr %t14, i32 0, i32 3
  store i64 %t13, ptr %t15
  %t16 = load ptr, ptr %l0
  store ptr %t16, ptr %l10
  %t17 = load ptr, ptr %l10
  %t18 = getelementptr %"compiler/build:Sha256", ptr %t17, i32 0, i32 2
  %t19 = load i64, ptr %t18
  store i64 %t19, ptr %l11
  %t20 = load i64, ptr %l11
  %t21 = icmp sgt i64 %t20, 0
  store i1 %t21, ptr %l12
  %t22 = load i1, ptr %l12
  br i1 %t22, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0
  store ptr %t23, ptr %l13
  %t24 = load ptr, ptr %l13
  %t25 = getelementptr %"compiler/build:Sha256", ptr %t24, i32 0, i32 2
  %t26 = load i64, ptr %t25
  store i64 %t26, ptr %l14
  %t27 = load i64, ptr %l14
  %t28 = icmp slt i64 %t27, 64
  store i1 %t28, ptr %l15
  %t29 = load i1, ptr %l15
  br i1 %t29, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l2
  store i64 %t30, ptr %l17
  %t31 = load i64, ptr %l3
  store i64 %t31, ptr %l18
  %t32 = load i64, ptr %l17
  %t33 = load i64, ptr %l18
  %t34 = icmp slt i64 %t32, %t33
  store i1 %t34, ptr %l19
  %t35 = load i1, ptr %l19
  store i1 %t35, ptr %l16
  br label %bb6
bb5:
  store i1 false, ptr %l16
  br label %bb6
bb6:
  %t36 = load i1, ptr %l16
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20
  %t38 = load i1, ptr %l20
  br i1 %t38, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0
  store ptr %t39, ptr %l21
  %t40 = load ptr, ptr %l0
  store ptr %t40, ptr %l22
  %t41 = load ptr, ptr %l22
  %t42 = getelementptr %"compiler/build:Sha256", ptr %t41, i32 0, i32 2
  %t43 = load i64, ptr %t42
  store i64 %t43, ptr %l23
  %t44 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t44, ptr %l24
  %t45 = load i64, ptr %l2
  store i64 %t45, ptr %l25
  %t46 = load i64, ptr %l25
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47
  %t49 = getelementptr i8, ptr %t48, i64 %t46
  %t50 = load i8, ptr %t49
  store i8 %t50, ptr %l26
  %t51 = load i8, ptr %l26
  %t52 = load ptr, ptr %l21
  %t53 = getelementptr %"compiler/build:Sha256", ptr %t52, i32 0, i32 1
  %t54 = load i64, ptr %l23
  %t55 = getelementptr [64 x i8], ptr %t53, i64 0, i64 %t54
  store i8 %t51, ptr %t55
  %t56 = load ptr, ptr %l0
  store ptr %t56, ptr %l27
  %t57 = load ptr, ptr %l27
  %t58 = getelementptr %"compiler/build:Sha256", ptr %t57, i32 0, i32 2
  %t59 = load i64, ptr %t58
  store i64 %t59, ptr %l28
  %t60 = load i64, ptr %l28
  %t61 = add i64 %t60, 1
  store i64 %t61, ptr %l29
  %t62 = load i64, ptr %l29
  %t63 = load ptr, ptr %l27
  %t64 = getelementptr %"compiler/build:Sha256", ptr %t63, i32 0, i32 2
  store i64 %t62, ptr %t64
  %t65 = load i64, ptr %l2
  store i64 %t65, ptr %l30
  %t66 = load i64, ptr %l30
  %t67 = add i64 %t66, 1
  store i64 %t67, ptr %l31
  %t68 = load i64, ptr %l31
  store i64 %t68, ptr %l2
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t69 = load ptr, ptr %l0
  store ptr %t69, ptr %l32
  %t70 = load ptr, ptr %l32
  %t71 = getelementptr %"compiler/build:Sha256", ptr %t70, i32 0, i32 2
  %t72 = load i64, ptr %t71
  store i64 %t72, ptr %l33
  %t73 = load i64, ptr %l33
  %t74 = icmp slt i64 %t73, 64
  store i1 %t74, ptr %l34
  %t75 = load i1, ptr %l34
  br i1 %t75, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0
  store ptr %t76, ptr %l35
  %t77 = load ptr, ptr %l0
  store ptr %t77, ptr %l36
  %t78 = load ptr, ptr %l36
  %t79 = getelementptr %"compiler/build:Sha256", ptr %t78, i32 0, i32 1
  store ptr %t79, ptr %l37
  %t80 = load ptr, ptr %l37
  %t81 = insertvalue { i64, ptr } undef, i64 64, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l38
  %t83 = load ptr, ptr %l35
  %t84 = load { i64, ptr }, ptr %l38
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v0, ptr %t83, { i64, ptr } %t84, i64 0)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0
  store ptr %t85, ptr %l39
  %t86 = load ptr, ptr %l39
  %t87 = getelementptr %"compiler/build:Sha256", ptr %t86, i32 0, i32 2
  store i64 0, ptr %t87
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load i64, ptr %l2
  store i64 %t88, ptr %l40
  %t89 = load i64, ptr %l40
  %t90 = add i64 %t89, 64
  store i64 %t90, ptr %l41
  %t91 = load i64, ptr %l3
  store i64 %t91, ptr %l42
  %t92 = load i64, ptr %l41
  %t93 = load i64, ptr %l42
  %t94 = icmp sle i64 %t92, %t93
  store i1 %t94, ptr %l43
  %t95 = load i1, ptr %l43
  %t96 = xor i1 %t95, true
  store i1 %t96, ptr %l44
  %t97 = load i1, ptr %l44
  br i1 %t97, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0
  store ptr %t98, ptr %l45
  %t99 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t99, ptr %l46
  %t100 = load i64, ptr %l2
  store i64 %t100, ptr %l47
  %t101 = load ptr, ptr %l45
  %t102 = load { i64, ptr }, ptr %l46
  %t103 = load i64, ptr %l47
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %t101, { i64, ptr } %t102, i64 %t103)
  br label %bb21
bb21:
  %t104 = load i64, ptr %l2
  store i64 %t104, ptr %l48
  %t105 = load i64, ptr %l48
  %t106 = add i64 %t105, 64
  store i64 %t106, ptr %l49
  %t107 = load i64, ptr %l49
  store i64 %t107, ptr %l2
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  br label %bb17
bb23:
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load i64, ptr %l2
  store i64 %t108, ptr %l50
  %t109 = load i64, ptr %l3
  store i64 %t109, ptr %l51
  %t110 = load i64, ptr %l50
  %t111 = load i64, ptr %l51
  %t112 = icmp slt i64 %t110, %t111
  store i1 %t112, ptr %l52
  %t113 = load i1, ptr %l52
  %t114 = xor i1 %t113, true
  store i1 %t114, ptr %l53
  %t115 = load i1, ptr %l53
  br i1 %t115, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0
  store ptr %t116, ptr %l54
  %t117 = load ptr, ptr %l0
  store ptr %t117, ptr %l55
  %t118 = load ptr, ptr %l55
  %t119 = getelementptr %"compiler/build:Sha256", ptr %t118, i32 0, i32 2
  %t120 = load i64, ptr %t119
  store i64 %t120, ptr %l56
  %t121 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t121, ptr %l57
  %t122 = load i64, ptr %l2
  store i64 %t122, ptr %l58
  %t123 = load i64, ptr %l58
  %t124 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t125 = load ptr, ptr %t124
  %t126 = getelementptr i8, ptr %t125, i64 %t123
  %t127 = load i8, ptr %t126
  store i8 %t127, ptr %l59
  %t128 = load i8, ptr %l59
  %t129 = load ptr, ptr %l54
  %t130 = getelementptr %"compiler/build:Sha256", ptr %t129, i32 0, i32 1
  %t131 = load i64, ptr %l56
  %t132 = getelementptr [64 x i8], ptr %t130, i64 0, i64 %t131
  store i8 %t128, ptr %t132
  %t133 = load ptr, ptr %l0
  store ptr %t133, ptr %l60
  %t134 = load ptr, ptr %l60
  %t135 = getelementptr %"compiler/build:Sha256", ptr %t134, i32 0, i32 2
  %t136 = load i64, ptr %t135
  store i64 %t136, ptr %l61
  %t137 = load i64, ptr %l61
  %t138 = add i64 %t137, 1
  store i64 %t138, ptr %l62
  %t139 = load i64, ptr %l62
  %t140 = load ptr, ptr %l60
  %t141 = getelementptr %"compiler/build:Sha256", ptr %t140, i32 0, i32 2
  store i64 %t139, ptr %t141
  %t142 = load i64, ptr %l2
  store i64 %t142, ptr %l63
  %t143 = load i64, ptr %l63
  %t144 = add i64 %t143, 1
  store i64 %t144, ptr %l64
  %t145 = load i64, ptr %l64
  store i64 %t145, ptr %l2
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  br label %bb24
bb29:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i32
  %l34 = alloca i32
  %l35 = alloca i32
  %l36 = alloca i32
  %l37 = alloca i32
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i1
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l68 = alloca i64
  %l69 = alloca i8
  %l70 = alloca i32
  %l71 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i8
  %l76 = alloca i32
  %l77 = alloca i32
  %l78 = alloca i32
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i8
  %l83 = alloca i32
  %l84 = alloca i32
  %l85 = alloca i32
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i8
  %l90 = alloca i32
  %l91 = alloca i32
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca i1
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i1
  %l112 = alloca i1
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i64
  %l120 = alloca i32
  %l121 = alloca i32
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i32
  %l125 = alloca i32
  %l126 = alloca i32
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i32
  %l130 = alloca i32
  %l131 = alloca i32
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i32
  %l135 = alloca i32
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i32
  %l139 = alloca i32
  %l140 = alloca i32
  %l141 = alloca i64
  %l142 = alloca i64
  %l143 = alloca i32
  %l144 = alloca i32
  %l145 = alloca i32
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i32
  %l150 = alloca i32
  %l151 = alloca i32
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i32
  %l155 = alloca i32
  %l156 = alloca i32
  %l157 = alloca i32
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca ptr
  %l161 = alloca i32
  %l162 = alloca ptr
  %l163 = alloca i32
  %l164 = alloca ptr
  %l165 = alloca i32
  %l166 = alloca ptr
  %l167 = alloca i32
  %l168 = alloca ptr
  %l169 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca ptr
  %l173 = alloca i32
  %l174 = alloca ptr
  %l175 = alloca i32
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i1
  %l179 = alloca i64
  %l180 = alloca i64
  %l181 = alloca i1
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i64
  %l187 = alloca i64
  %l188 = alloca i64
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i64
  %l192 = alloca i64
  %l193 = alloca i1
  %l194 = alloca i1
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i64
  %l199 = alloca i64
  %l200 = alloca i32
  %l201 = alloca i32
  %l202 = alloca i32
  %l203 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i32
  %l206 = alloca i32
  %l207 = alloca i32
  %l208 = alloca i32
  %l209 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i32
  %l212 = alloca i32
  %l213 = alloca i32
  %l214 = alloca i32
  %l215 = alloca i32
  %l216 = alloca i32
  %l217 = alloca i32
  %l218 = alloca i32
  %l219 = alloca i32
  %l220 = alloca i32
  %l221 = alloca i64
  %l222 = alloca i32
  %l223 = alloca i32
  %l224 = alloca i64
  %l225 = alloca i32
  %l226 = alloca i32
  %l227 = alloca i32
  %l228 = alloca i32
  %l229 = alloca i32
  %l230 = alloca i32
  %l231 = alloca i32
  %l232 = alloca i32
  %l233 = alloca i32
  %l234 = alloca i32
  %l235 = alloca i32
  %l236 = alloca i32
  %l237 = alloca i32
  %l238 = alloca i32
  %l239 = alloca i32
  %l240 = alloca i32
  %l241 = alloca i32
  %l242 = alloca i32
  %l243 = alloca i32
  %l244 = alloca i32
  %l245 = alloca i32
  %l246 = alloca i32
  %l247 = alloca i32
  %l248 = alloca i32
  %l249 = alloca i32
  %l250 = alloca i32
  %l251 = alloca i32
  %l252 = alloca i32
  %l253 = alloca i32
  %l254 = alloca i32
  %l255 = alloca i32
  %l256 = alloca i32
  %l257 = alloca i32
  %l258 = alloca i32
  %l259 = alloca i32
  %l260 = alloca i64
  %l261 = alloca i64
  %l262 = alloca ptr
  %l263 = alloca i32
  %l264 = alloca i32
  %l265 = alloca i32
  %l266 = alloca ptr
  %l267 = alloca i32
  %l268 = alloca i32
  %l269 = alloca i32
  %l270 = alloca ptr
  %l271 = alloca i32
  %l272 = alloca i32
  %l273 = alloca i32
  %l274 = alloca ptr
  %l275 = alloca i32
  %l276 = alloca i32
  %l277 = alloca i32
  %l278 = alloca ptr
  %l279 = alloca i32
  %l280 = alloca i32
  %l281 = alloca i32
  %l282 = alloca ptr
  %l283 = alloca i32
  %l284 = alloca i32
  %l285 = alloca i32
  %l286 = alloca ptr
  %l287 = alloca i32
  %l288 = alloca i32
  %l289 = alloca i32
  %l290 = alloca ptr
  %l291 = alloca i32
  %l292 = alloca i32
  %l293 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store [64 x i32] zeroinitializer, ptr %l3
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l4
  store i64 16, ptr %l5
  store i64 1, ptr %l6
  %t1 = load i64, ptr %l5
  store i64 %t1, ptr %l38
  %t2 = load i64, ptr %l4
  store i64 %t2, ptr %l39
  %t3 = load i64, ptr %l38
  %t4 = load i64, ptr %l39
  %t5 = icmp sgt i64 %t3, %t4
  store i1 %t5, ptr %l40
  %t6 = load i1, ptr %l40
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l6
  store i64 %t7, ptr %l42
  %t8 = load i64, ptr %l42
  %t9 = icmp sgt i64 %t8, 0
  store i1 %t9, ptr %l43
  %t10 = load i1, ptr %l43
  br i1 %t10, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l41
  br label %bb6
bb3:
  %t11 = load i64, ptr %l5
  store i64 %t11, ptr %l45
  %t12 = load i64, ptr %l4
  store i64 %t12, ptr %l46
  %t13 = load i64, ptr %l45
  %t14 = load i64, ptr %l46
  %t15 = sub i64 %t13, %t14
  store i64 %t15, ptr %l47
  %t16 = load i64, ptr %l6
  store i64 %t16, ptr %l48
  %t17 = load i64, ptr %l47
  %t18 = load i64, ptr %l48
  %t19 = add i64 %t17, %t18
  store i64 %t19, ptr %l49
  %t20 = load i64, ptr %l49
  %t21 = sub i64 %t20, 1
  store i64 %t21, ptr %l50
  %t22 = load i64, ptr %l6
  store i64 %t22, ptr %l51
  %t23 = load i64, ptr %l50
  %t24 = load i64, ptr %l51
  %t25 = sdiv i64 %t23, %t24
  store i64 %t25, ptr %l52
  %t26 = load i64, ptr %l52
  store i64 %t26, ptr %l44
  br label %bb5
bb4:
  store i64 0, ptr %l44
  br label %bb5
bb5:
  %t27 = load i64, ptr %l44
  store i64 %t27, ptr %l41
  br label %bb6
bb6:
  %t28 = load i64, ptr %l41
  store i64 %t28, ptr %l7
  store i64 0, ptr %l8
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l8
  store i64 %t29, ptr %l53
  %t30 = load i64, ptr %l7
  store i64 %t30, ptr %l54
  %t31 = load i64, ptr %l53
  %t32 = load i64, ptr %l54
  %t33 = icmp slt i64 %t31, %t32
  store i1 %t33, ptr %l55
  %t34 = load i1, ptr %l55
  %t35 = xor i1 %t34, true
  store i1 %t35, ptr %l56
  %t36 = load i1, ptr %l56
  br i1 %t36, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l4
  store i64 %t37, ptr %l57
  %t38 = load i64, ptr %l8
  store i64 %t38, ptr %l58
  %t39 = load i64, ptr %l6
  store i64 %t39, ptr %l59
  %t40 = load i64, ptr %l58
  %t41 = load i64, ptr %l59
  %t42 = mul i64 %t40, %t41
  store i64 %t42, ptr %l60
  %t43 = load i64, ptr %l57
  %t44 = load i64, ptr %l60
  %t45 = add i64 %t43, %t44
  store i64 %t45, ptr %l61
  %t46 = load i64, ptr %l61
  store i64 %t46, ptr %l9
  %t47 = load i64, ptr %l2
  store i64 %t47, ptr %l62
  %t48 = load i64, ptr %l9
  store i64 %t48, ptr %l63
  %t49 = load i64, ptr %l63
  %t50 = mul i64 %t49, 4
  store i64 %t50, ptr %l64
  %t51 = load i64, ptr %l62
  %t52 = load i64, ptr %l64
  %t53 = add i64 %t51, %t52
  store i64 %t53, ptr %l65
  %t54 = load i64, ptr %l65
  store i64 %t54, ptr %l10
  %t55 = load i64, ptr %l9
  store i64 %t55, ptr %l66
  %t56 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t56, ptr %l67
  %t57 = load i64, ptr %l10
  store i64 %t57, ptr %l68
  %t58 = load i64, ptr %l68
  %t59 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t60 = load ptr, ptr %t59
  %t61 = getelementptr i8, ptr %t60, i64 %t58
  %t62 = load i8, ptr %t61
  store i8 %t62, ptr %l69
  %t63 = load i8, ptr %l69
  %t64 = zext i8 %t63 to i32
  store i32 %t64, ptr %l70
  %t65 = load i32, ptr %l70
  %t66 = shl i32 %t65, 24
  store i32 %t66, ptr %l71
  %t67 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t67, ptr %l72
  %t68 = load i64, ptr %l10
  store i64 %t68, ptr %l73
  %t69 = load i64, ptr %l73
  %t70 = add i64 %t69, 1
  store i64 %t70, ptr %l74
  %t71 = load i64, ptr %l74
  %t72 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t73 = load ptr, ptr %t72
  %t74 = getelementptr i8, ptr %t73, i64 %t71
  %t75 = load i8, ptr %t74
  store i8 %t75, ptr %l75
  %t76 = load i8, ptr %l75
  %t77 = zext i8 %t76 to i32
  store i32 %t77, ptr %l76
  %t78 = load i32, ptr %l76
  %t79 = shl i32 %t78, 16
  store i32 %t79, ptr %l77
  %t80 = load i32, ptr %l71
  %t81 = load i32, ptr %l77
  %t82 = or i32 %t80, %t81
  store i32 %t82, ptr %l78
  %t83 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t83, ptr %l79
  %t84 = load i64, ptr %l10
  store i64 %t84, ptr %l80
  %t85 = load i64, ptr %l80
  %t86 = add i64 %t85, 2
  store i64 %t86, ptr %l81
  %t87 = load i64, ptr %l81
  %t88 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  %t90 = getelementptr i8, ptr %t89, i64 %t87
  %t91 = load i8, ptr %t90
  store i8 %t91, ptr %l82
  %t92 = load i8, ptr %l82
  %t93 = zext i8 %t92 to i32
  store i32 %t93, ptr %l83
  %t94 = load i32, ptr %l83
  %t95 = shl i32 %t94, 8
  store i32 %t95, ptr %l84
  %t96 = load i32, ptr %l78
  %t97 = load i32, ptr %l84
  %t98 = or i32 %t96, %t97
  store i32 %t98, ptr %l85
  %t99 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t99, ptr %l86
  %t100 = load i64, ptr %l10
  store i64 %t100, ptr %l87
  %t101 = load i64, ptr %l87
  %t102 = add i64 %t101, 3
  store i64 %t102, ptr %l88
  %t103 = load i64, ptr %l88
  %t104 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t105 = load ptr, ptr %t104
  %t106 = getelementptr i8, ptr %t105, i64 %t103
  %t107 = load i8, ptr %t106
  store i8 %t107, ptr %l89
  %t108 = load i8, ptr %l89
  %t109 = zext i8 %t108 to i32
  store i32 %t109, ptr %l90
  %t110 = load i32, ptr %l85
  %t111 = load i32, ptr %l90
  %t112 = or i32 %t110, %t111
  store i32 %t112, ptr %l91
  %t113 = load i32, ptr %l91
  %t114 = load i64, ptr %l66
  %t115 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t114
  store i32 %t113, ptr %t115
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t116 = load i64, ptr %l8
  store i64 %t116, ptr %l92
  %t117 = load i64, ptr %l92
  %t118 = add i64 %t117, 1
  store i64 %t118, ptr %l93
  %t119 = load i64, ptr %l93
  store i64 %t119, ptr %l8
  call void @__olang_scope_close(ptr %s3)
  br label %bb7
bb12:
  call void @__olang_scope_close(ptr %s1)
  store %olang.scope zeroinitializer, ptr %s4
  store i64 16, ptr %l11
  store i64 64, ptr %l12
  store i64 1, ptr %l13
  %t120 = load i64, ptr %l12
  store i64 %t120, ptr %l94
  %t121 = load i64, ptr %l11
  store i64 %t121, ptr %l95
  %t122 = load i64, ptr %l94
  %t123 = load i64, ptr %l95
  %t124 = icmp sgt i64 %t122, %t123
  store i1 %t124, ptr %l96
  %t125 = load i1, ptr %l96
  br i1 %t125, label %bb13, label %bb14
bb13:
  %t126 = load i64, ptr %l13
  store i64 %t126, ptr %l98
  %t127 = load i64, ptr %l98
  %t128 = icmp sgt i64 %t127, 0
  store i1 %t128, ptr %l99
  %t129 = load i1, ptr %l99
  br i1 %t129, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l97
  br label %bb18
bb15:
  %t130 = load i64, ptr %l12
  store i64 %t130, ptr %l101
  %t131 = load i64, ptr %l11
  store i64 %t131, ptr %l102
  %t132 = load i64, ptr %l101
  %t133 = load i64, ptr %l102
  %t134 = sub i64 %t132, %t133
  store i64 %t134, ptr %l103
  %t135 = load i64, ptr %l13
  store i64 %t135, ptr %l104
  %t136 = load i64, ptr %l103
  %t137 = load i64, ptr %l104
  %t138 = add i64 %t136, %t137
  store i64 %t138, ptr %l105
  %t139 = load i64, ptr %l105
  %t140 = sub i64 %t139, 1
  store i64 %t140, ptr %l106
  %t141 = load i64, ptr %l13
  store i64 %t141, ptr %l107
  %t142 = load i64, ptr %l106
  %t143 = load i64, ptr %l107
  %t144 = sdiv i64 %t142, %t143
  store i64 %t144, ptr %l108
  %t145 = load i64, ptr %l108
  store i64 %t145, ptr %l100
  br label %bb17
bb16:
  store i64 0, ptr %l100
  br label %bb17
bb17:
  %t146 = load i64, ptr %l100
  store i64 %t146, ptr %l97
  br label %bb18
bb18:
  %t147 = load i64, ptr %l97
  store i64 %t147, ptr %l14
  store i64 0, ptr %l15
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load i64, ptr %l15
  store i64 %t148, ptr %l109
  %t149 = load i64, ptr %l14
  store i64 %t149, ptr %l110
  %t150 = load i64, ptr %l109
  %t151 = load i64, ptr %l110
  %t152 = icmp slt i64 %t150, %t151
  store i1 %t152, ptr %l111
  %t153 = load i1, ptr %l111
  %t154 = xor i1 %t153, true
  store i1 %t154, ptr %l112
  %t155 = load i1, ptr %l112
  br i1 %t155, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t156 = load i64, ptr %l11
  store i64 %t156, ptr %l113
  %t157 = load i64, ptr %l15
  store i64 %t157, ptr %l114
  %t158 = load i64, ptr %l13
  store i64 %t158, ptr %l115
  %t159 = load i64, ptr %l114
  %t160 = load i64, ptr %l115
  %t161 = mul i64 %t159, %t160
  store i64 %t161, ptr %l116
  %t162 = load i64, ptr %l113
  %t163 = load i64, ptr %l116
  %t164 = add i64 %t162, %t163
  store i64 %t164, ptr %l117
  %t165 = load i64, ptr %l117
  store i64 %t165, ptr %l16
  %t166 = load i64, ptr %l16
  store i64 %t166, ptr %l118
  %t167 = load i64, ptr %l118
  %t168 = sub i64 %t167, 15
  store i64 %t168, ptr %l119
  %t169 = load i64, ptr %l119
  %t170 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t169
  %t171 = load i32, ptr %t170
  store i32 %t171, ptr %l120
  %t172 = load i32, ptr %l120
  %t173 = call i32 @compiler_2fbuild_2erotr(i32 %t172, i32 7)
  store i32 %t173, ptr %l121
  br label %bb23
bb23:
  %t174 = load i64, ptr %l16
  store i64 %t174, ptr %l122
  %t175 = load i64, ptr %l122
  %t176 = sub i64 %t175, 15
  store i64 %t176, ptr %l123
  %t177 = load i64, ptr %l123
  %t178 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t177
  %t179 = load i32, ptr %t178
  store i32 %t179, ptr %l124
  %t180 = load i32, ptr %l124
  %t181 = call i32 @compiler_2fbuild_2erotr(i32 %t180, i32 18)
  store i32 %t181, ptr %l125
  br label %bb24
bb24:
  %t182 = load i32, ptr %l121
  %t183 = load i32, ptr %l125
  %t184 = xor i32 %t182, %t183
  store i32 %t184, ptr %l126
  %t185 = load i64, ptr %l16
  store i64 %t185, ptr %l127
  %t186 = load i64, ptr %l127
  %t187 = sub i64 %t186, 15
  store i64 %t187, ptr %l128
  %t188 = load i64, ptr %l128
  %t189 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t188
  %t190 = load i32, ptr %t189
  store i32 %t190, ptr %l129
  %t191 = load i32, ptr %l129
  %t192 = lshr i32 %t191, 3
  store i32 %t192, ptr %l130
  %t193 = load i32, ptr %l126
  %t194 = load i32, ptr %l130
  %t195 = xor i32 %t193, %t194
  store i32 %t195, ptr %l131
  %t196 = load i32, ptr %l131
  store i32 %t196, ptr %l17
  %t197 = load i64, ptr %l16
  store i64 %t197, ptr %l132
  %t198 = load i64, ptr %l132
  %t199 = sub i64 %t198, 2
  store i64 %t199, ptr %l133
  %t200 = load i64, ptr %l133
  %t201 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t200
  %t202 = load i32, ptr %t201
  store i32 %t202, ptr %l134
  %t203 = load i32, ptr %l134
  %t204 = call i32 @compiler_2fbuild_2erotr(i32 %t203, i32 17)
  store i32 %t204, ptr %l135
  br label %bb25
bb25:
  %t205 = load i64, ptr %l16
  store i64 %t205, ptr %l136
  %t206 = load i64, ptr %l136
  %t207 = sub i64 %t206, 2
  store i64 %t207, ptr %l137
  %t208 = load i64, ptr %l137
  %t209 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t208
  %t210 = load i32, ptr %t209
  store i32 %t210, ptr %l138
  %t211 = load i32, ptr %l138
  %t212 = call i32 @compiler_2fbuild_2erotr(i32 %t211, i32 19)
  store i32 %t212, ptr %l139
  br label %bb26
bb26:
  %t213 = load i32, ptr %l135
  %t214 = load i32, ptr %l139
  %t215 = xor i32 %t213, %t214
  store i32 %t215, ptr %l140
  %t216 = load i64, ptr %l16
  store i64 %t216, ptr %l141
  %t217 = load i64, ptr %l141
  %t218 = sub i64 %t217, 2
  store i64 %t218, ptr %l142
  %t219 = load i64, ptr %l142
  %t220 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t219
  %t221 = load i32, ptr %t220
  store i32 %t221, ptr %l143
  %t222 = load i32, ptr %l143
  %t223 = lshr i32 %t222, 10
  store i32 %t223, ptr %l144
  %t224 = load i32, ptr %l140
  %t225 = load i32, ptr %l144
  %t226 = xor i32 %t224, %t225
  store i32 %t226, ptr %l145
  %t227 = load i32, ptr %l145
  store i32 %t227, ptr %l18
  %t228 = load i64, ptr %l16
  store i64 %t228, ptr %l146
  %t229 = load i64, ptr %l16
  store i64 %t229, ptr %l147
  %t230 = load i64, ptr %l147
  %t231 = sub i64 %t230, 16
  store i64 %t231, ptr %l148
  %t232 = load i64, ptr %l148
  %t233 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t232
  %t234 = load i32, ptr %t233
  store i32 %t234, ptr %l149
  %t235 = load i32, ptr %l17
  store i32 %t235, ptr %l150
  %t236 = load i32, ptr %l149
  %t237 = load i32, ptr %l150
  %t238 = add i32 %t236, %t237
  store i32 %t238, ptr %l151
  %t239 = load i64, ptr %l16
  store i64 %t239, ptr %l152
  %t240 = load i64, ptr %l152
  %t241 = sub i64 %t240, 7
  store i64 %t241, ptr %l153
  %t242 = load i64, ptr %l153
  %t243 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t242
  %t244 = load i32, ptr %t243
  store i32 %t244, ptr %l154
  %t245 = load i32, ptr %l151
  %t246 = load i32, ptr %l154
  %t247 = add i32 %t245, %t246
  store i32 %t247, ptr %l155
  %t248 = load i32, ptr %l18
  store i32 %t248, ptr %l156
  %t249 = load i32, ptr %l155
  %t250 = load i32, ptr %l156
  %t251 = add i32 %t249, %t250
  store i32 %t251, ptr %l157
  %t252 = load i32, ptr %l157
  %t253 = load i64, ptr %l146
  %t254 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t253
  store i32 %t252, ptr %t254
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t255 = load i64, ptr %l15
  store i64 %t255, ptr %l158
  %t256 = load i64, ptr %l158
  %t257 = add i64 %t256, 1
  store i64 %t257, ptr %l159
  %t258 = load i64, ptr %l159
  store i64 %t258, ptr %l15
  call void @__olang_scope_close(ptr %s6)
  br label %bb19
bb28:
  call void @__olang_scope_close(ptr %s4)
  %t259 = load ptr, ptr %l0
  store ptr %t259, ptr %l160
  %t260 = load ptr, ptr %l160
  %t261 = getelementptr %"compiler/build:Sha256", ptr %t260, i32 0, i32 0
  %t262 = getelementptr [8 x i32], ptr %t261, i64 0, i64 0
  %t263 = load i32, ptr %t262
  store i32 %t263, ptr %l161
  %t264 = load i32, ptr %l161
  store i32 %t264, ptr %l19
  %t265 = load ptr, ptr %l0
  store ptr %t265, ptr %l162
  %t266 = load ptr, ptr %l162
  %t267 = getelementptr %"compiler/build:Sha256", ptr %t266, i32 0, i32 0
  %t268 = getelementptr [8 x i32], ptr %t267, i64 0, i64 1
  %t269 = load i32, ptr %t268
  store i32 %t269, ptr %l163
  %t270 = load i32, ptr %l163
  store i32 %t270, ptr %l20
  %t271 = load ptr, ptr %l0
  store ptr %t271, ptr %l164
  %t272 = load ptr, ptr %l164
  %t273 = getelementptr %"compiler/build:Sha256", ptr %t272, i32 0, i32 0
  %t274 = getelementptr [8 x i32], ptr %t273, i64 0, i64 2
  %t275 = load i32, ptr %t274
  store i32 %t275, ptr %l165
  %t276 = load i32, ptr %l165
  store i32 %t276, ptr %l21
  %t277 = load ptr, ptr %l0
  store ptr %t277, ptr %l166
  %t278 = load ptr, ptr %l166
  %t279 = getelementptr %"compiler/build:Sha256", ptr %t278, i32 0, i32 0
  %t280 = getelementptr [8 x i32], ptr %t279, i64 0, i64 3
  %t281 = load i32, ptr %t280
  store i32 %t281, ptr %l167
  %t282 = load i32, ptr %l167
  store i32 %t282, ptr %l22
  %t283 = load ptr, ptr %l0
  store ptr %t283, ptr %l168
  %t284 = load ptr, ptr %l168
  %t285 = getelementptr %"compiler/build:Sha256", ptr %t284, i32 0, i32 0
  %t286 = getelementptr [8 x i32], ptr %t285, i64 0, i64 4
  %t287 = load i32, ptr %t286
  store i32 %t287, ptr %l169
  %t288 = load i32, ptr %l169
  store i32 %t288, ptr %l23
  %t289 = load ptr, ptr %l0
  store ptr %t289, ptr %l170
  %t290 = load ptr, ptr %l170
  %t291 = getelementptr %"compiler/build:Sha256", ptr %t290, i32 0, i32 0
  %t292 = getelementptr [8 x i32], ptr %t291, i64 0, i64 5
  %t293 = load i32, ptr %t292
  store i32 %t293, ptr %l171
  %t294 = load i32, ptr %l171
  store i32 %t294, ptr %l24
  %t295 = load ptr, ptr %l0
  store ptr %t295, ptr %l172
  %t296 = load ptr, ptr %l172
  %t297 = getelementptr %"compiler/build:Sha256", ptr %t296, i32 0, i32 0
  %t298 = getelementptr [8 x i32], ptr %t297, i64 0, i64 6
  %t299 = load i32, ptr %t298
  store i32 %t299, ptr %l173
  %t300 = load i32, ptr %l173
  store i32 %t300, ptr %l25
  %t301 = load ptr, ptr %l0
  store ptr %t301, ptr %l174
  %t302 = load ptr, ptr %l174
  %t303 = getelementptr %"compiler/build:Sha256", ptr %t302, i32 0, i32 0
  %t304 = getelementptr [8 x i32], ptr %t303, i64 0, i64 7
  %t305 = load i32, ptr %t304
  store i32 %t305, ptr %l175
  %t306 = load i32, ptr %l175
  store i32 %t306, ptr %l26
  store %olang.scope zeroinitializer, ptr %s7
  store i64 0, ptr %l27
  store i64 64, ptr %l28
  store i64 1, ptr %l29
  %t307 = load i64, ptr %l28
  store i64 %t307, ptr %l176
  %t308 = load i64, ptr %l27
  store i64 %t308, ptr %l177
  %t309 = load i64, ptr %l176
  %t310 = load i64, ptr %l177
  %t311 = icmp sgt i64 %t309, %t310
  store i1 %t311, ptr %l178
  %t312 = load i1, ptr %l178
  br i1 %t312, label %bb29, label %bb30
bb29:
  %t313 = load i64, ptr %l29
  store i64 %t313, ptr %l180
  %t314 = load i64, ptr %l180
  %t315 = icmp sgt i64 %t314, 0
  store i1 %t315, ptr %l181
  %t316 = load i1, ptr %l181
  br i1 %t316, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l179
  br label %bb34
bb31:
  %t317 = load i64, ptr %l28
  store i64 %t317, ptr %l183
  %t318 = load i64, ptr %l27
  store i64 %t318, ptr %l184
  %t319 = load i64, ptr %l183
  %t320 = load i64, ptr %l184
  %t321 = sub i64 %t319, %t320
  store i64 %t321, ptr %l185
  %t322 = load i64, ptr %l29
  store i64 %t322, ptr %l186
  %t323 = load i64, ptr %l185
  %t324 = load i64, ptr %l186
  %t325 = add i64 %t323, %t324
  store i64 %t325, ptr %l187
  %t326 = load i64, ptr %l187
  %t327 = sub i64 %t326, 1
  store i64 %t327, ptr %l188
  %t328 = load i64, ptr %l29
  store i64 %t328, ptr %l189
  %t329 = load i64, ptr %l188
  %t330 = load i64, ptr %l189
  %t331 = sdiv i64 %t329, %t330
  store i64 %t331, ptr %l190
  %t332 = load i64, ptr %l190
  store i64 %t332, ptr %l182
  br label %bb33
bb32:
  store i64 0, ptr %l182
  br label %bb33
bb33:
  %t333 = load i64, ptr %l182
  store i64 %t333, ptr %l179
  br label %bb34
bb34:
  %t334 = load i64, ptr %l179
  store i64 %t334, ptr %l30
  store i64 0, ptr %l31
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t335 = load i64, ptr %l31
  store i64 %t335, ptr %l191
  %t336 = load i64, ptr %l30
  store i64 %t336, ptr %l192
  %t337 = load i64, ptr %l191
  %t338 = load i64, ptr %l192
  %t339 = icmp slt i64 %t337, %t338
  store i1 %t339, ptr %l193
  %t340 = load i1, ptr %l193
  %t341 = xor i1 %t340, true
  store i1 %t341, ptr %l194
  %t342 = load i1, ptr %l194
  br i1 %t342, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t343 = load i64, ptr %l27
  store i64 %t343, ptr %l195
  %t344 = load i64, ptr %l31
  store i64 %t344, ptr %l196
  %t345 = load i64, ptr %l29
  store i64 %t345, ptr %l197
  %t346 = load i64, ptr %l196
  %t347 = load i64, ptr %l197
  %t348 = mul i64 %t346, %t347
  store i64 %t348, ptr %l198
  %t349 = load i64, ptr %l195
  %t350 = load i64, ptr %l198
  %t351 = add i64 %t349, %t350
  store i64 %t351, ptr %l199
  %t352 = load i64, ptr %l199
  store i64 %t352, ptr %l32
  %t353 = load i32, ptr %l23
  store i32 %t353, ptr %l200
  %t354 = load i32, ptr %l200
  %t355 = call i32 @compiler_2fbuild_2erotr(i32 %t354, i32 6)
  store i32 %t355, ptr %l201
  br label %bb39
bb39:
  %t356 = load i32, ptr %l23
  store i32 %t356, ptr %l202
  %t357 = load i32, ptr %l202
  %t358 = call i32 @compiler_2fbuild_2erotr(i32 %t357, i32 11)
  store i32 %t358, ptr %l203
  br label %bb40
bb40:
  %t359 = load i32, ptr %l201
  %t360 = load i32, ptr %l203
  %t361 = xor i32 %t359, %t360
  store i32 %t361, ptr %l204
  %t362 = load i32, ptr %l23
  store i32 %t362, ptr %l205
  %t363 = load i32, ptr %l205
  %t364 = call i32 @compiler_2fbuild_2erotr(i32 %t363, i32 25)
  store i32 %t364, ptr %l206
  br label %bb41
bb41:
  %t365 = load i32, ptr %l204
  %t366 = load i32, ptr %l206
  %t367 = xor i32 %t365, %t366
  store i32 %t367, ptr %l207
  %t368 = load i32, ptr %l207
  store i32 %t368, ptr %l33
  %t369 = load i32, ptr %l23
  store i32 %t369, ptr %l208
  %t370 = load i32, ptr %l24
  store i32 %t370, ptr %l209
  %t371 = load i32, ptr %l208
  %t372 = load i32, ptr %l209
  %t373 = and i32 %t371, %t372
  store i32 %t373, ptr %l210
  %t374 = load i32, ptr %l23
  store i32 %t374, ptr %l211
  %t375 = load i32, ptr %l211
  %t376 = xor i32 %t375, -1
  store i32 %t376, ptr %l212
  %t377 = load i32, ptr %l25
  store i32 %t377, ptr %l213
  %t378 = load i32, ptr %l212
  %t379 = load i32, ptr %l213
  %t380 = and i32 %t378, %t379
  store i32 %t380, ptr %l214
  %t381 = load i32, ptr %l210
  %t382 = load i32, ptr %l214
  %t383 = xor i32 %t381, %t382
  store i32 %t383, ptr %l215
  %t384 = load i32, ptr %l215
  store i32 %t384, ptr %l34
  %t385 = load i32, ptr %l26
  store i32 %t385, ptr %l216
  %t386 = load i32, ptr %l33
  store i32 %t386, ptr %l217
  %t387 = load i32, ptr %l216
  %t388 = load i32, ptr %l217
  %t389 = add i32 %t387, %t388
  store i32 %t389, ptr %l218
  %t390 = load i32, ptr %l34
  store i32 %t390, ptr %l219
  %t391 = load i32, ptr %l218
  %t392 = load i32, ptr %l219
  %t393 = add i32 %t391, %t392
  store i32 %t393, ptr %l220
  %t394 = load i64, ptr %l32
  store i64 %t394, ptr %l221
  %t395 = load i64, ptr %l221
  %t396 = getelementptr [64 x i32], ptr @G_2ecompiler_2fbuild_2eShaK, i64 0, i64 %t395
  %t397 = load i32, ptr %t396
  store i32 %t397, ptr %l222
  %t398 = load i32, ptr %l220
  %t399 = load i32, ptr %l222
  %t400 = add i32 %t398, %t399
  store i32 %t400, ptr %l223
  %t401 = load i64, ptr %l32
  store i64 %t401, ptr %l224
  %t402 = load i64, ptr %l224
  %t403 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t402
  %t404 = load i32, ptr %t403
  store i32 %t404, ptr %l225
  %t405 = load i32, ptr %l223
  %t406 = load i32, ptr %l225
  %t407 = add i32 %t405, %t406
  store i32 %t407, ptr %l226
  %t408 = load i32, ptr %l226
  store i32 %t408, ptr %l35
  %t409 = load i32, ptr %l19
  store i32 %t409, ptr %l227
  %t410 = load i32, ptr %l227
  %t411 = call i32 @compiler_2fbuild_2erotr(i32 %t410, i32 2)
  store i32 %t411, ptr %l228
  br label %bb42
bb42:
  %t412 = load i32, ptr %l19
  store i32 %t412, ptr %l229
  %t413 = load i32, ptr %l229
  %t414 = call i32 @compiler_2fbuild_2erotr(i32 %t413, i32 13)
  store i32 %t414, ptr %l230
  br label %bb43
bb43:
  %t415 = load i32, ptr %l228
  %t416 = load i32, ptr %l230
  %t417 = xor i32 %t415, %t416
  store i32 %t417, ptr %l231
  %t418 = load i32, ptr %l19
  store i32 %t418, ptr %l232
  %t419 = load i32, ptr %l232
  %t420 = call i32 @compiler_2fbuild_2erotr(i32 %t419, i32 22)
  store i32 %t420, ptr %l233
  br label %bb44
bb44:
  %t421 = load i32, ptr %l231
  %t422 = load i32, ptr %l233
  %t423 = xor i32 %t421, %t422
  store i32 %t423, ptr %l234
  %t424 = load i32, ptr %l234
  store i32 %t424, ptr %l36
  %t425 = load i32, ptr %l19
  store i32 %t425, ptr %l235
  %t426 = load i32, ptr %l20
  store i32 %t426, ptr %l236
  %t427 = load i32, ptr %l235
  %t428 = load i32, ptr %l236
  %t429 = and i32 %t427, %t428
  store i32 %t429, ptr %l237
  %t430 = load i32, ptr %l19
  store i32 %t430, ptr %l238
  %t431 = load i32, ptr %l21
  store i32 %t431, ptr %l239
  %t432 = load i32, ptr %l238
  %t433 = load i32, ptr %l239
  %t434 = and i32 %t432, %t433
  store i32 %t434, ptr %l240
  %t435 = load i32, ptr %l237
  %t436 = load i32, ptr %l240
  %t437 = xor i32 %t435, %t436
  store i32 %t437, ptr %l241
  %t438 = load i32, ptr %l20
  store i32 %t438, ptr %l242
  %t439 = load i32, ptr %l21
  store i32 %t439, ptr %l243
  %t440 = load i32, ptr %l242
  %t441 = load i32, ptr %l243
  %t442 = and i32 %t440, %t441
  store i32 %t442, ptr %l244
  %t443 = load i32, ptr %l241
  %t444 = load i32, ptr %l244
  %t445 = xor i32 %t443, %t444
  store i32 %t445, ptr %l245
  %t446 = load i32, ptr %l245
  store i32 %t446, ptr %l37
  %t447 = load i32, ptr %l25
  store i32 %t447, ptr %l246
  %t448 = load i32, ptr %l246
  store i32 %t448, ptr %l26
  %t449 = load i32, ptr %l24
  store i32 %t449, ptr %l247
  %t450 = load i32, ptr %l247
  store i32 %t450, ptr %l25
  %t451 = load i32, ptr %l23
  store i32 %t451, ptr %l248
  %t452 = load i32, ptr %l248
  store i32 %t452, ptr %l24
  %t453 = load i32, ptr %l22
  store i32 %t453, ptr %l249
  %t454 = load i32, ptr %l35
  store i32 %t454, ptr %l250
  %t455 = load i32, ptr %l249
  %t456 = load i32, ptr %l250
  %t457 = add i32 %t455, %t456
  store i32 %t457, ptr %l251
  %t458 = load i32, ptr %l251
  store i32 %t458, ptr %l23
  %t459 = load i32, ptr %l21
  store i32 %t459, ptr %l252
  %t460 = load i32, ptr %l252
  store i32 %t460, ptr %l22
  %t461 = load i32, ptr %l20
  store i32 %t461, ptr %l253
  %t462 = load i32, ptr %l253
  store i32 %t462, ptr %l21
  %t463 = load i32, ptr %l19
  store i32 %t463, ptr %l254
  %t464 = load i32, ptr %l254
  store i32 %t464, ptr %l20
  %t465 = load i32, ptr %l35
  store i32 %t465, ptr %l255
  %t466 = load i32, ptr %l36
  store i32 %t466, ptr %l256
  %t467 = load i32, ptr %l255
  %t468 = load i32, ptr %l256
  %t469 = add i32 %t467, %t468
  store i32 %t469, ptr %l257
  %t470 = load i32, ptr %l37
  store i32 %t470, ptr %l258
  %t471 = load i32, ptr %l257
  %t472 = load i32, ptr %l258
  %t473 = add i32 %t471, %t472
  store i32 %t473, ptr %l259
  %t474 = load i32, ptr %l259
  store i32 %t474, ptr %l19
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t475 = load i64, ptr %l31
  store i64 %t475, ptr %l260
  %t476 = load i64, ptr %l260
  %t477 = add i64 %t476, 1
  store i64 %t477, ptr %l261
  %t478 = load i64, ptr %l261
  store i64 %t478, ptr %l31
  call void @__olang_scope_close(ptr %s9)
  br label %bb35
bb46:
  call void @__olang_scope_close(ptr %s7)
  %t479 = load ptr, ptr %l0
  store ptr %t479, ptr %l262
  %t480 = load ptr, ptr %l262
  %t481 = getelementptr %"compiler/build:Sha256", ptr %t480, i32 0, i32 0
  %t482 = getelementptr [8 x i32], ptr %t481, i64 0, i64 0
  %t483 = load i32, ptr %t482
  store i32 %t483, ptr %l263
  %t484 = load i32, ptr %l19
  store i32 %t484, ptr %l264
  %t485 = load i32, ptr %l263
  %t486 = load i32, ptr %l264
  %t487 = add i32 %t485, %t486
  store i32 %t487, ptr %l265
  %t488 = load i32, ptr %l265
  %t489 = load ptr, ptr %l262
  %t490 = getelementptr %"compiler/build:Sha256", ptr %t489, i32 0, i32 0
  %t491 = getelementptr [8 x i32], ptr %t490, i64 0, i64 0
  store i32 %t488, ptr %t491
  %t492 = load ptr, ptr %l0
  store ptr %t492, ptr %l266
  %t493 = load ptr, ptr %l266
  %t494 = getelementptr %"compiler/build:Sha256", ptr %t493, i32 0, i32 0
  %t495 = getelementptr [8 x i32], ptr %t494, i64 0, i64 1
  %t496 = load i32, ptr %t495
  store i32 %t496, ptr %l267
  %t497 = load i32, ptr %l20
  store i32 %t497, ptr %l268
  %t498 = load i32, ptr %l267
  %t499 = load i32, ptr %l268
  %t500 = add i32 %t498, %t499
  store i32 %t500, ptr %l269
  %t501 = load i32, ptr %l269
  %t502 = load ptr, ptr %l266
  %t503 = getelementptr %"compiler/build:Sha256", ptr %t502, i32 0, i32 0
  %t504 = getelementptr [8 x i32], ptr %t503, i64 0, i64 1
  store i32 %t501, ptr %t504
  %t505 = load ptr, ptr %l0
  store ptr %t505, ptr %l270
  %t506 = load ptr, ptr %l270
  %t507 = getelementptr %"compiler/build:Sha256", ptr %t506, i32 0, i32 0
  %t508 = getelementptr [8 x i32], ptr %t507, i64 0, i64 2
  %t509 = load i32, ptr %t508
  store i32 %t509, ptr %l271
  %t510 = load i32, ptr %l21
  store i32 %t510, ptr %l272
  %t511 = load i32, ptr %l271
  %t512 = load i32, ptr %l272
  %t513 = add i32 %t511, %t512
  store i32 %t513, ptr %l273
  %t514 = load i32, ptr %l273
  %t515 = load ptr, ptr %l270
  %t516 = getelementptr %"compiler/build:Sha256", ptr %t515, i32 0, i32 0
  %t517 = getelementptr [8 x i32], ptr %t516, i64 0, i64 2
  store i32 %t514, ptr %t517
  %t518 = load ptr, ptr %l0
  store ptr %t518, ptr %l274
  %t519 = load ptr, ptr %l274
  %t520 = getelementptr %"compiler/build:Sha256", ptr %t519, i32 0, i32 0
  %t521 = getelementptr [8 x i32], ptr %t520, i64 0, i64 3
  %t522 = load i32, ptr %t521
  store i32 %t522, ptr %l275
  %t523 = load i32, ptr %l22
  store i32 %t523, ptr %l276
  %t524 = load i32, ptr %l275
  %t525 = load i32, ptr %l276
  %t526 = add i32 %t524, %t525
  store i32 %t526, ptr %l277
  %t527 = load i32, ptr %l277
  %t528 = load ptr, ptr %l274
  %t529 = getelementptr %"compiler/build:Sha256", ptr %t528, i32 0, i32 0
  %t530 = getelementptr [8 x i32], ptr %t529, i64 0, i64 3
  store i32 %t527, ptr %t530
  %t531 = load ptr, ptr %l0
  store ptr %t531, ptr %l278
  %t532 = load ptr, ptr %l278
  %t533 = getelementptr %"compiler/build:Sha256", ptr %t532, i32 0, i32 0
  %t534 = getelementptr [8 x i32], ptr %t533, i64 0, i64 4
  %t535 = load i32, ptr %t534
  store i32 %t535, ptr %l279
  %t536 = load i32, ptr %l23
  store i32 %t536, ptr %l280
  %t537 = load i32, ptr %l279
  %t538 = load i32, ptr %l280
  %t539 = add i32 %t537, %t538
  store i32 %t539, ptr %l281
  %t540 = load i32, ptr %l281
  %t541 = load ptr, ptr %l278
  %t542 = getelementptr %"compiler/build:Sha256", ptr %t541, i32 0, i32 0
  %t543 = getelementptr [8 x i32], ptr %t542, i64 0, i64 4
  store i32 %t540, ptr %t543
  %t544 = load ptr, ptr %l0
  store ptr %t544, ptr %l282
  %t545 = load ptr, ptr %l282
  %t546 = getelementptr %"compiler/build:Sha256", ptr %t545, i32 0, i32 0
  %t547 = getelementptr [8 x i32], ptr %t546, i64 0, i64 5
  %t548 = load i32, ptr %t547
  store i32 %t548, ptr %l283
  %t549 = load i32, ptr %l24
  store i32 %t549, ptr %l284
  %t550 = load i32, ptr %l283
  %t551 = load i32, ptr %l284
  %t552 = add i32 %t550, %t551
  store i32 %t552, ptr %l285
  %t553 = load i32, ptr %l285
  %t554 = load ptr, ptr %l282
  %t555 = getelementptr %"compiler/build:Sha256", ptr %t554, i32 0, i32 0
  %t556 = getelementptr [8 x i32], ptr %t555, i64 0, i64 5
  store i32 %t553, ptr %t556
  %t557 = load ptr, ptr %l0
  store ptr %t557, ptr %l286
  %t558 = load ptr, ptr %l286
  %t559 = getelementptr %"compiler/build:Sha256", ptr %t558, i32 0, i32 0
  %t560 = getelementptr [8 x i32], ptr %t559, i64 0, i64 6
  %t561 = load i32, ptr %t560
  store i32 %t561, ptr %l287
  %t562 = load i32, ptr %l25
  store i32 %t562, ptr %l288
  %t563 = load i32, ptr %l287
  %t564 = load i32, ptr %l288
  %t565 = add i32 %t563, %t564
  store i32 %t565, ptr %l289
  %t566 = load i32, ptr %l289
  %t567 = load ptr, ptr %l286
  %t568 = getelementptr %"compiler/build:Sha256", ptr %t567, i32 0, i32 0
  %t569 = getelementptr [8 x i32], ptr %t568, i64 0, i64 6
  store i32 %t566, ptr %t569
  %t570 = load ptr, ptr %l0
  store ptr %t570, ptr %l290
  %t571 = load ptr, ptr %l290
  %t572 = getelementptr %"compiler/build:Sha256", ptr %t571, i32 0, i32 0
  %t573 = getelementptr [8 x i32], ptr %t572, i64 0, i64 7
  %t574 = load i32, ptr %t573
  store i32 %t574, ptr %l291
  %t575 = load i32, ptr %l26
  store i32 %t575, ptr %l292
  %t576 = load i32, ptr %l291
  %t577 = load i32, ptr %l292
  %t578 = add i32 %t576, %t577
  store i32 %t578, ptr %l293
  %t579 = load i32, ptr %l293
  %t580 = load ptr, ptr %l290
  %t581 = getelementptr %"compiler/build:Sha256", ptr %t580, i32 0, i32 0
  %t582 = getelementptr [8 x i32], ptr %t581, i64 0, i64 7
  store i32 %t579, ptr %t582
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/msgs:Msg"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca %"compiler/msgs:Msg"
  %l11 = alloca i64
  %s0 = alloca %olang.scope
  %t9 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/msgs:Msg" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t2, ptr %l5
  %t3 = load ptr, ptr %l4
  %t4 = load { i64, ptr }, ptr %l5
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t3, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr @.d95 }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6
  store i64 %t6, ptr %l3
  %t7 = load ptr, ptr %l2
  store ptr %t7, ptr %l7
  %t8 = load i64, ptr %l3
  store i64 %t8, ptr %l8
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t11 = load i64, ptr %l8
  %t12 = insertvalue { i64 } undef, i64 %t11, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  store { i64, [3 x i64] } %t14, ptr %l9
  %t15 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t15, ptr %l10
  %t16 = load ptr, ptr %l7
  %t17 = load { i64, [3 x i64] }, ptr %l9
  %t18 = load %"compiler/msgs:Msg", ptr %l10
  %t19 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %v1, ptr %t16, { i64, [3 x i64] } %t17, %"compiler/msgs:Msg" %t18)
  store i64 %t19, ptr %l11
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"compiler/msgs:Msg"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %t9 = alloca { i64, [3 x i64] }, align 8
  store { i64, ptr } %a0, ptr %l0
  store %"compiler/msgs:Msg" %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l2
  store ptr %t1, ptr %l4
  %t2 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t2, ptr %l5
  %t3 = load ptr, ptr %l4
  %t4 = load { i64, ptr }, ptr %l5
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t3, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr @.d96 }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6
  store i64 %t6, ptr %l3
  %t7 = load ptr, ptr %l2
  store ptr %t7, ptr %l7
  %t8 = load i64, ptr %l3
  store i64 %t8, ptr %l8
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t11 = load i64, ptr %l8
  %t12 = insertvalue { i64 } undef, i64 %t11, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  store { i64, [3 x i64] } %t14, ptr %l9
  %t15 = load %"compiler/msgs:Msg", ptr %l1
  store %"compiler/msgs:Msg" %t15, ptr %l10
  %t16 = load ptr, ptr %l7
  %t17 = load { i64, [3 x i64] }, ptr %l9
  %t18 = load %"compiler/msgs:Msg", ptr %l10
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v1, ptr %t16, { i64, [3 x i64] } %t17, %"compiler/msgs:Msg" %t18)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l1
  %t2 = load ptr, ptr %l1
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %t2)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l3
  %t11 = load { i64, ptr }, ptr %l3
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t11)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0
  store ptr %t12, ptr %l4
  %t13 = load ptr, ptr %l4
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %s0, ptr %t13)
  store { i64, ptr } %t14, ptr %l5
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l5
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l6
  %t22 = load { i64, ptr }, ptr %l6
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t22)
  br label %bb4
bb4:
  store i32 1, ptr %l7
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l7
  store i32 %t23, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i1
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i32
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l2
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t2, %t3
  store i1 %t4, ptr %l3
  %t5 = load i1, ptr %l3
  br i1 %t5, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d97 }, ptr %l4
  %t6 = load { i64, ptr }, ptr %l4
  store { i64, ptr } %t6, ptr %l5
  %t7 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t7, ptr %l1
  call void @__olang_scope_close(ptr %s1)
  br label %bb17
bb4:
  %t8 = load i32, ptr %l0
  store i32 %t8, ptr %l6
  %t9 = load i32, ptr %l6
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t9, %t10
  store i1 %t11, ptr %l7
  %t12 = load i1, ptr %l7
  br i1 %t12, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 5, ptr @.d98 }, ptr %l8
  %t13 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t13, ptr %l9
  %t14 = load { i64, ptr }, ptr %l9
  store { i64, ptr } %t14, ptr %l1
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb8:
  %t15 = load i32, ptr %l0
  store i32 %t15, ptr %l10
  %t16 = load i32, ptr %l10
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t16, %t17
  store i1 %t18, ptr %l11
  %t19 = load i1, ptr %l11
  br i1 %t19, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  store { i64, ptr } { i64 5, ptr @.d99 }, ptr %l12
  %t20 = load { i64, ptr }, ptr %l12
  store { i64, ptr } %t20, ptr %l13
  %t21 = load { i64, ptr }, ptr %l13
  store { i64, ptr } %t21, ptr %l1
  call void @__olang_scope_close(ptr %s3)
  br label %bb17
bb12:
  %t22 = load i32, ptr %l0
  store i32 %t22, ptr %l14
  %t23 = load i32, ptr %l14
  %t24 = trunc i64 3 to i32
  %t25 = icmp eq i32 %t23, %t24
  store i1 %t25, ptr %l15
  %t26 = load i1, ptr %l15
  br i1 %t26, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s4
  store { i64, ptr } { i64 5, ptr @.d100 }, ptr %l16
  %t27 = load { i64, ptr }, ptr %l16
  store { i64, ptr } %t27, ptr %l17
  %t28 = load { i64, ptr }, ptr %l17
  store { i64, ptr } %t28, ptr %l1
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c101)
  unreachable
bb17:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t29, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2elinkCurrent(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l9 = alloca i32
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca %"std/os:FileInfo"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca i1
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l6
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %t2)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7
  store { i64, ptr } %t8, ptr %l5
  br label %bb6
bb2:
  %t9 = load i32, ptr %l8
  %t10 = ashr i32 %t9, 16
  store i32 %t10, ptr %l9
  %t11 = load i32, ptr %l9
  %t12 = icmp eq i32 %t11, 1
  store i1 %t12, ptr %l10
  %t13 = load i1, ptr %l10
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c102)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l11
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l11
  store i1 %t14, ptr %rv
  br label %ret
bb6:
  %t15 = load { i64, ptr }, ptr %l5
  store { i64, ptr } %t15, ptr %l3
  %t16 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t16, ptr %l13
  %t17 = load { i64, ptr }, ptr %l13
  %t18 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %t17)
  %t19 = extractvalue { i32, %"std/os:FileInfo" } %t18, 1
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t18, 0
  store i32 %t20, ptr %l15
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22
ok.22:
  store %"std/os:FileInfo" %t19, ptr %l14
  br label %bb7
bb7:
  %t23 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t23, ptr %l12
  br label %bb12
bb8:
  %t24 = load i32, ptr %l15
  %t25 = ashr i32 %t24, 16
  store i32 %t25, ptr %l16
  %t26 = load i32, ptr %l16
  %t27 = icmp eq i32 %t26, 1
  store i1 %t27, ptr %l17
  %t28 = load i1, ptr %l17
  br i1 %t28, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c103)
  unreachable
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 false, ptr %l18
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i1, ptr %l18
  store i1 %t29, ptr %rv
  br label %ret
bb12:
  %t30 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t30, ptr %l4
  %t31 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t31, ptr %l19
  %t32 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t32, ptr %l20
  %t33 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t34 = load i64, ptr %t33
  store i64 %t34, ptr %l21
  %t35 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t36 = load i64, ptr %t35
  store i64 %t36, ptr %l22
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t37 = load { i64, ptr }, ptr %l20
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  call void @__olang_sb_put(ptr %s3, ptr %t38, i64 %t39)
  %t40 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t40, i64 %t41)
  %t42 = load i64, ptr %l21
  %t43 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t44 = call i64 @__olang_fmt_i64(ptr %t43, i64 %t42)
  call void @__olang_sb_add(ptr %s3, i64 %t44)
  %t45 = extractvalue { i64, ptr } { i64 1, ptr @.d105 }, 1
  %t46 = extractvalue { i64, ptr } { i64 1, ptr @.d105 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t45, i64 %t46)
  %t47 = load i64, ptr %l22
  %t48 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t49 = call i64 @__olang_fmt_i64(ptr %t48, i64 %t47)
  call void @__olang_sb_add(ptr %s3, i64 %t49)
  %t50 = extractvalue { i64, ptr } { i64 1, ptr @.d106 }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr @.d106 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t50, i64 %t51)
  %t52 = load ptr, ptr %s3
  %t53 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t54 = load i64, ptr %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t52, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l23
  call void @__olang_sb_done(ptr %s3)
  %t58 = load { i64, ptr }, ptr %l23
  %t59 = extractvalue { i64, ptr } %t58, 0
  %t60 = extractvalue { i64, ptr } %t58, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  store { i64, ptr } %t64, ptr %l24
  %t65 = load { i64, ptr }, ptr %l19
  %t66 = load { i64, ptr }, ptr %l24
  %t67 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t65, { i64, ptr } %t66)
  store i1 %t67, ptr %l25
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i1, ptr %l25
  store i1 %t68, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fbuild_2erotr(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i32
  %l5 = alloca i32
  %l6 = alloca i32
  %l7 = alloca i32
  %l8 = alloca i32
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %l2
  %t2 = load i32, ptr %l1
  store i32 %t2, ptr %l3
  %t3 = load i32, ptr %l2
  %t4 = load i32, ptr %l3
  %t5 = load i32, ptr %l3
  %t6 = lshr i32 %t3, %t5
  store i32 %t6, ptr %l4
  %t7 = load i32, ptr %l0
  store i32 %t7, ptr %l5
  %t8 = load i32, ptr %l1
  store i32 %t8, ptr %l6
  %t9 = load i32, ptr %l6
  %t10 = sub i32 32, %t9
  store i32 %t10, ptr %l7
  %t11 = load i32, ptr %l5
  %t12 = load i32, ptr %l7
  %t13 = load i32, ptr %l7
  %t14 = shl i32 %t11, %t13
  store i32 %t14, ptr %l8
  %t15 = load i32, ptr %l4
  %t16 = load i32, ptr %l8
  %t17 = or i32 %t15, %t16
  store i32 %t17, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i32, ptr %l9
  store i32 %t18, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/os:Output"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i32
  %l12 = alloca i32
  %l13 = alloca i1
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l35 = alloca i32
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0
  store ptr %t1, ptr %l7
  %t2 = load ptr, ptr %l7
  store ptr %t2, ptr %l4
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4
  store ptr %t3, ptr %l9
  %t4 = load ptr, ptr %l9
  %t5 = call { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l11
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10
  store i64 %t10, ptr %l8
  br label %bb7
bb3:
  %t11 = load i32, ptr %l11
  %t12 = ashr i32 %t11, 16
  store i32 %t12, ptr %l12
  %t13 = load i32, ptr %l12
  %t14 = icmp eq i32 %t13, 1
  store i1 %t14, ptr %l13
  %t15 = load i1, ptr %l13
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c107)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb7:
  %t16 = load i64, ptr %l8
  store i64 %t16, ptr %l5
  %t17 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t17, ptr %l15
  %t18 = load i64, ptr %l5
  store i64 %t18, ptr %l16
  %t19 = load i64, ptr %l16
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t19
  %t23 = load { i64, ptr }, ptr %t22
  store { i64, ptr } %t23, ptr %l17
  store { i64, ptr } { i64 0, ptr @.d108 }, ptr %l18
  %t24 = load { i64, ptr }, ptr %l17
  %t25 = load { i64, ptr }, ptr %l18
  %t26 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t24, { i64, ptr } %t25, i1 true, { i64, ptr } { i64 0, ptr @.d109 })
  %t27 = extractvalue { i32, %"std/os:Output" } %t26, 1
  %t28 = extractvalue { i32, %"std/os:Output" } %t26, 0
  store i32 %t28, ptr %l20
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb9, label %ok.30
ok.30:
  store %"std/os:Output" %t27, ptr %l19
  br label %bb8
bb8:
  %t31 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t31, ptr %l14
  br label %bb13
bb9:
  %t32 = load i32, ptr %l20
  %t33 = ashr i32 %t32, 16
  store i32 %t33, ptr %l21
  %t34 = load i32, ptr %l21
  %t35 = icmp eq i32 %t34, 1
  store i1 %t35, ptr %l22
  %t36 = load i1, ptr %l22
  br i1 %t36, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c110)
  unreachable
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t37 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t37, ptr %l23
  %t38 = load i64, ptr %l5
  store i64 %t38, ptr %l24
  %t39 = load i64, ptr %l24
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40
  %t42 = getelementptr i32, ptr %t41, i64 %t39
  store i32 127, ptr %t42
  %t43 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t43, ptr %l25
  %t44 = load i64, ptr %l5
  store i64 %t44, ptr %l26
  %t45 = load { i64, ptr }, ptr %l1
  store { i64, ptr } %t45, ptr %l27
  %t46 = load i64, ptr %l5
  store i64 %t46, ptr %l28
  %t47 = load i64, ptr %l28
  %t48 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t49 = load ptr, ptr %t48
  %t50 = getelementptr { i64, ptr }, ptr %t49, i64 %t47
  %t51 = load { i64, ptr }, ptr %t50
  store { i64, ptr } %t51, ptr %l29
  %t52 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t53 = load ptr, ptr %t52
  %t54 = getelementptr { i64, ptr }, ptr %t53, i64 0
  %t55 = load { i64, ptr }, ptr %t54
  store { i64, ptr } %t55, ptr %l30
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t56 = extractvalue { i64, ptr } { i64 11, ptr @.d111 }, 1
  %t57 = extractvalue { i64, ptr } { i64 11, ptr @.d111 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t56, i64 %t57)
  %t58 = load { i64, ptr }, ptr %l30
  %t59 = extractvalue { i64, ptr } %t58, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  call void @__olang_sb_put(ptr %s4, ptr %t59, i64 %t60)
  %t61 = extractvalue { i64, ptr } { i64 1, ptr @.d112 }, 1
  %t62 = extractvalue { i64, ptr } { i64 1, ptr @.d112 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t61, i64 %t62)
  %t63 = load ptr, ptr %s4
  %t64 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t65 = load i64, ptr %t64
  %t66 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t65)
  call void @llvm.memcpy.p0.p0.i64(ptr %t66, ptr %t63, i64 %t65, i1 false)
  %t67 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l31
  call void @__olang_sb_done(ptr %s4)
  %t69 = load { i64, ptr }, ptr %l31
  %t70 = extractvalue { i64, ptr } %t69, 0
  %t71 = extractvalue { i64, ptr } %t69, 1
  %t72 = mul i64 %t70, 1
  %t73 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t71, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t70, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l32
  %t76 = load { i64, ptr }, ptr %l32
  %t77 = load i64, ptr %l26
  %t78 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t79 = load ptr, ptr %t78
  %t80 = getelementptr { i64, ptr }, ptr %t79, i64 %t77
  store { i64, ptr } %t76, ptr %t80
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb13:
  %t81 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t81, ptr %l6
  %t82 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t82, ptr %l33
  %t83 = load i64, ptr %l5
  store i64 %t83, ptr %l34
  %t84 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t85 = load i32, ptr %t84
  store i32 %t85, ptr %l35
  %t86 = load i32, ptr %l35
  %t87 = load i64, ptr %l34
  %t88 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t89 = load ptr, ptr %t88
  %t90 = getelementptr i32, ptr %t89, i64 %t87
  store i32 %t86, ptr %t90
  %t91 = load { i64, ptr }, ptr %l3
  store { i64, ptr } %t91, ptr %l36
  %t92 = load i64, ptr %l5
  store i64 %t92, ptr %l37
  %t93 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t94 = load { i64, ptr }, ptr %t93
  store { i64, ptr } %t94, ptr %l38
  %t95 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t96 = load { i64, ptr }, ptr %t95
  store { i64, ptr } %t96, ptr %l39
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t97 = load { i64, ptr }, ptr %l38
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  call void @__olang_sb_put(ptr %s5, ptr %t98, i64 %t99)
  %t100 = load { i64, ptr }, ptr %l39
  %t101 = extractvalue { i64, ptr } %t100, 1
  %t102 = extractvalue { i64, ptr } %t100, 0
  call void @__olang_sb_put(ptr %s5, ptr %t101, i64 %t102)
  %t103 = load ptr, ptr %s5
  %t104 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t105 = load i64, ptr %t104
  %t106 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t103, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  store { i64, ptr } %t108, ptr %l40
  call void @__olang_sb_done(ptr %s5)
  %t109 = load { i64, ptr }, ptr %l40
  %t110 = extractvalue { i64, ptr } %t109, 0
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l41
  %t116 = load { i64, ptr }, ptr %l41
  %t117 = load i64, ptr %l37
  %t118 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t119 = load ptr, ptr %t118
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t117
  store { i64, ptr } %t116, ptr %t120
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb1
bb15:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3
  %t8 = load i32, ptr %l3
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4
  %t10 = load i1, ptr %l4
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c113)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3
  %t8 = load i32, ptr %l3
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4
  %t10 = load i1, ptr %l4
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c114)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i32
  %l3 = alloca i32
  %l4 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l1
  %t2 = load { i64, ptr }, ptr %l1
  %t3 = call i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %t2)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2
  %t7 = ashr i32 %t6, 16
  store i32 %t7, ptr %l3
  %t8 = load i32, ptr %l3
  %t9 = icmp eq i32 %t8, 1
  store i1 %t9, ptr %l4
  %t10 = load i1, ptr %l4
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c115)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2eunbuilt() #0 {
entry:
  %l0 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i32 1, ptr %l0
  call void @__olang_scope_close(ptr %s0)
  %t1 = load i32, ptr %l0
  store i32 %t1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/target:Target"
  %l3 = alloca %"compiler/cond:Consts"
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca i1
  %l11 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/target:Target"
  %l18 = alloca %"compiler/cond:Consts"
  %l19 = alloca %"compiler/build:Config"
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store { i64, ptr } { i64 5, ptr @.d116 }, ptr %l0
  store { i64, ptr } { i64 0, ptr @.d117 }, ptr %l1
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
  store %"compiler/target:Target" %t1, ptr %l17
  br label %bb1
bb1:
  %t2 = load %"compiler/target:Target", ptr %l17
  store %"compiler/target:Target" %t2, ptr %l2
  %t3 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
  store %"compiler/cond:Consts" %t3, ptr %l18
  br label %bb2
bb2:
  %t4 = load %"compiler/cond:Consts", ptr %l18
  store %"compiler/cond:Consts" %t4, ptr %l3
  store i1 false, ptr %l4
  store i1 false, ptr %l5
  store i1 false, ptr %l6
  store i1 false, ptr %l7
  store i1 false, ptr %l8
  store i64 0, ptr %l9
  store i1 false, ptr %l10
  store i1 false, ptr %l11
  store { i64, ptr } { i64 0, ptr @.d118 }, ptr %l12
  store { i64, ptr } { i64 0, ptr @.d119 }, ptr %l13
  store i64 0, ptr %l14
  store i64 0, ptr %l15
  store { i64, ptr } { i64 0, ptr @.d120 }, ptr %l16
  %t5 = load { i64, ptr }, ptr %l0
  %t6 = insertvalue %"compiler/build:Config" undef, { i64, ptr } %t5, 0
  %t7 = load { i64, ptr }, ptr %l1
  %t8 = insertvalue %"compiler/build:Config" %t6, { i64, ptr } %t7, 1
  %t9 = load %"compiler/target:Target", ptr %l2
  %t10 = insertvalue %"compiler/build:Config" %t8, %"compiler/target:Target" %t9, 2
  %t11 = load %"compiler/cond:Consts", ptr %l3
  %t12 = insertvalue %"compiler/build:Config" %t10, %"compiler/cond:Consts" %t11, 3
  %t13 = load i1, ptr %l4
  %t14 = insertvalue %"compiler/build:Config" %t12, i1 %t13, 4
  %t15 = load i1, ptr %l5
  %t16 = insertvalue %"compiler/build:Config" %t14, i1 %t15, 5
  %t17 = load i1, ptr %l6
  %t18 = insertvalue %"compiler/build:Config" %t16, i1 %t17, 6
  %t19 = load i1, ptr %l7
  %t20 = insertvalue %"compiler/build:Config" %t18, i1 %t19, 7
  %t21 = load i1, ptr %l8
  %t22 = insertvalue %"compiler/build:Config" %t20, i1 %t21, 8
  %t23 = load i64, ptr %l9
  %t24 = insertvalue %"compiler/build:Config" %t22, i64 %t23, 9
  %t25 = load i1, ptr %l10
  %t26 = insertvalue %"compiler/build:Config" %t24, i1 %t25, 10
  %t27 = load i1, ptr %l11
  %t28 = insertvalue %"compiler/build:Config" %t26, i1 %t27, 11
  %t29 = load { i64, ptr }, ptr %l12
  %t30 = insertvalue %"compiler/build:Config" %t28, { i64, ptr } %t29, 12
  %t31 = load { i64, ptr }, ptr %l13
  %t32 = insertvalue %"compiler/build:Config" %t30, { i64, ptr } %t31, 13
  %t33 = load i64, ptr %l14
  %t34 = insertvalue %"compiler/build:Config" %t32, i64 %t33, 14
  %t35 = load i64, ptr %l15
  %t36 = insertvalue %"compiler/build:Config" %t34, i64 %t35, 15
  %t37 = load { i64, ptr }, ptr %l16
  %t38 = insertvalue %"compiler/build:Config" %t36, { i64, ptr } %t37, 16
  store %"compiler/build:Config" %t38, ptr %l19
  call void @__olang_scope_close(ptr %s0)
  %t39 = load %"compiler/build:Config", ptr %l19
  store %"compiler/build:Config" %t39, ptr %out
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/build:Unit>"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List<compiler/build:Unit>"
  %l4 = alloca %"compiler/build:Program"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:Program"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/build:Unit>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %t1)
  store %"std/prelude/list:List<compiler/build:Unit>" %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<compiler/build:Unit>", ptr %l3
  store %"std/prelude/list:List<compiler/build:Unit>" %t3, ptr %l0
  store { i64, ptr } { i64 0, ptr @.d121 }, ptr %l1
  store { i64, ptr } { i64 0, ptr @.d122 }, ptr %l2
  %t4 = load %"std/prelude/list:List<compiler/build:Unit>", ptr %l0
  %t5 = insertvalue %"compiler/build:Program" undef, %"std/prelude/list:List<compiler/build:Unit>" %t4, 0
  %t6 = load { i64, ptr }, ptr %l1
  %t7 = insertvalue %"compiler/build:Program" %t5, { i64, ptr } %t6, 1
  %t8 = load { i64, ptr }, ptr %l2
  %t9 = insertvalue %"compiler/build:Program" %t7, { i64, ptr } %t8, 2
  store %"compiler/build:Program" %t9, ptr %l4
  call void @__olang_scope_close(ptr %s0)
  %t10 = load %"compiler/build:Program", ptr %l4
  store %"compiler/build:Program" %t10, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Program", ptr %rv
  ret %"compiler/build:Program" %rr
}

define dso_local %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca [8 x i32]
  %l1 = alloca [64 x i8]
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca [8 x i32]
  %l5 = alloca %"compiler/build:Sha256"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:Sha256"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = insertvalue [8 x i32] undef, i32 1779033703, 0
  %t2 = insertvalue [8 x i32] %t1, i32 -1150833019, 1
  %t3 = insertvalue [8 x i32] %t2, i32 1013904242, 2
  %t4 = insertvalue [8 x i32] %t3, i32 -1521486534, 3
  %t5 = insertvalue [8 x i32] %t4, i32 1359893119, 4
  %t6 = insertvalue [8 x i32] %t5, i32 -1694144372, 5
  %t7 = insertvalue [8 x i32] %t6, i32 528734635, 6
  %t8 = insertvalue [8 x i32] %t7, i32 1541459225, 7
  store [8 x i32] %t8, ptr %l4
  %t9 = load [8 x i32], ptr %l4
  store [8 x i32] %t9, ptr %l0
  store [64 x i8] zeroinitializer, ptr %l1
  store i64 0, ptr %l2
  store i64 0, ptr %l3
  %t10 = load [8 x i32], ptr %l0
  %t11 = insertvalue %"compiler/build:Sha256" undef, [8 x i32] %t10, 0
  %t12 = load [64 x i8], ptr %l1
  %t13 = insertvalue %"compiler/build:Sha256" %t11, [64 x i8] %t12, 1
  %t14 = load i64, ptr %l2
  %t15 = insertvalue %"compiler/build:Sha256" %t13, i64 %t14, 2
  %t16 = load i64, ptr %l3
  %t17 = insertvalue %"compiler/build:Sha256" %t15, i64 %t16, 3
  store %"compiler/build:Sha256" %t17, ptr %l5
  call void @__olang_scope_close(ptr %s0)
  %t18 = load %"compiler/build:Sha256", ptr %l5
  store %"compiler/build:Sha256" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Sha256", ptr %rv
  ret %"compiler/build:Sha256" %rr
}

define dso_local %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i32
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/build:Unit"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:Unit"
  store { i64, ptr } %a0, ptr %l0
  store i32 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0
  store { i64, ptr } %t1, ptr %l6
  %t2 = load { i64, ptr }, ptr %l6
  store { i64, ptr } %t2, ptr %l3
  %t3 = load i32, ptr %l1
  store i32 %t3, ptr %l7
  %t4 = load i32, ptr %l7
  store i32 %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2
  store { i64, ptr } %t5, ptr %l8
  %t6 = load { i64, ptr }, ptr %l8
  store { i64, ptr } %t6, ptr %l5
  %t7 = load { i64, ptr }, ptr %l3
  %t8 = insertvalue %"compiler/build:Unit" undef, { i64, ptr } %t7, 0
  %t9 = load i32, ptr %l4
  %t10 = insertvalue %"compiler/build:Unit" %t8, i32 %t9, 1
  %t11 = load { i64, ptr }, ptr %l5
  %t12 = insertvalue %"compiler/build:Unit" %t10, { i64, ptr } %t11, 2
  store %"compiler/build:Unit" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/build:Unit", ptr %l9
  store %"compiler/build:Unit" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Unit", ptr %rv
  ret %"compiler/build:Unit" %rr
}

define dso_local %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  %l1 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l2 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l3 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l4 = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  %l5 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l6 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l7 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l8 = alloca %"compiler/build:compiles"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/build:compiles"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %t1)
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t2, ptr %l4
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %l4
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t4)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %l5
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l5
  store %"std/prelude/list:List<std/prelude/text:String&>" %t6, ptr %l1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t8, ptr %l6
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l6
  store %"std/prelude/list:List<std/prelude/text:String&>" %t9, ptr %l2
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t10)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t11, ptr %l7
  br label %bb4
bb4:
  %t12 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l7
  store %"std/prelude/list:List<std/prelude/text:String&>" %t12, ptr %l3
  %t13 = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %l0
  %t14 = insertvalue %"compiler/build:compiles" undef, %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t13, 0
  %t15 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l1
  %t16 = insertvalue %"compiler/build:compiles" %t14, %"std/prelude/list:List<std/prelude/text:String&>" %t15, 1
  %t17 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l2
  %t18 = insertvalue %"compiler/build:compiles" %t16, %"std/prelude/list:List<std/prelude/text:String&>" %t17, 2
  %t19 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l3
  %t20 = insertvalue %"compiler/build:compiles" %t18, %"std/prelude/list:List<std/prelude/text:String&>" %t19, 3
  store %"compiler/build:compiles" %t20, ptr %l8
  call void @__olang_scope_close(ptr %s0)
  %t21 = load %"compiler/build:compiles", ptr %l8
  store %"compiler/build:compiles" %t21, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:compiles", ptr %rv
  ret %"compiler/build:compiles" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fbuild() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_2eShaK_2einit()
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:261: reached unreachable code\0A\00"
declare void @__olang_scope_close(ptr)
@__olang_prog_scope = external thread_local(initialexec) global ptr
declare ptr @__olang_scope_alloc(ptr, i64)
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
declare ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.c1 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:304: array length out of range\0A\00"
@.c2 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:305: array length out of range\0A\00"
declare ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.c3 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:309: reached unreachable code\0A\00"
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task4(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load ptr, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2fbuild_2erunner(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

declare i64 @__olang_join_tasks(ptr)
@.d5 = private constant [1 x i8] c"/"
declare void @__olang_sb_put(ptr, ptr, i64)
declare void @__olang_sb_done(ptr)
@.d6 = private constant [2 x i8] c"./"
@.d7 = private constant [6 x i8] c"Hangup"
@.d8 = private constant [9 x i8] c"Interrupt"
@.d9 = private constant [4 x i8] c"Quit"
@.d10 = private constant [19 x i8] c"Illegal instruction"
@.d11 = private constant [21 x i8] c"Trace/breakpoint trap"
@.d12 = private constant [7 x i8] c"Aborted"
@.d13 = private constant [9 x i8] c"Bus error"
@.d14 = private constant [24 x i8] c"Floating point exception"
@.d15 = private constant [6 x i8] c"Killed"
@.d16 = private constant [18 x i8] c"Segmentation fault"
@.d17 = private constant [11 x i8] c"Broken pipe"
@.d18 = private constant [11 x i8] c"Alarm clock"
@.d19 = private constant [10 x i8] c"Terminated"
@.d20 = private constant [15 x i8] c"Unknown signal "
declare ptr @__olang_sb_room(ptr, i64)
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.c21 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:613: reached unreachable code\0A\00"
define linkonce_odr %"std/prelude/list:List<std/prelude/text:String&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l0
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %rv
  ret %"std/prelude/list:List<std/prelude/text:String&>" %rr
}

@.d22 = private constant [4 x i8] c"test"
@.d23 = private constant [0 x i8] c""
@.d24 = private constant [0 x i8] c""
@.c25 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:593: reached unreachable code\0A\00"
@.d26 = private constant [35 x i8] c": lost track of its build, skipping"
@.d27 = private constant [2 x i8] c"31"
@.d28 = private constant [22 x i8] c": the compiler ended ("
@.d29 = private constant [11 x i8] c"), skipping"
@.d30 = private constant [2 x i8] c"31"
@.d31 = private constant [62 x i8] c"olang: error: the self-hosted compiler cannot build this yet: "
@.d32 = private constant [6 x i8] c"bfloat"
@.d33 = private constant [6 x i8] c"-mllvm"
@.d34 = private constant [16 x i8] c"-fast-isel=false"
@.d35 = private constant [2 x i8] c"-o"
@.d36 = private constant [3 x i8] c"-lm"
@.d37 = private constant [9 x i8] c"-lpthread"
@.d38 = private constant [4 x i8] c"-ldl"
@.d39 = private constant [5 x i8] c"-lffi"
@.d40 = private constant [5 x i8] c".link"
@.d41 = private constant [0 x i8] c""
@.d42 = private constant [0 x i8] c""
@.d43 = private constant [0 x i8] c""
@.d44 = private constant [1 x i8] c" "
@.d45 = private constant [1 x i8] c" "
@.d46 = private constant [1 x i8] c"\0A"
@.d47 = private constant [9 x i8] c"--target="
@.d48 = private constant [0 x i8] c""
@.d49 = private constant [3 x i8] c"-O0"
@.d50 = private constant [2 x i8] c"-g"
@.d51 = private constant [17 x i8] c"-fsanitize=thread"
@.d52 = private constant [3 x i8] c"-O1"
@.d53 = private constant [17 x i8] c"-fsanitize=thread"
@.d54 = private constant [3 x i8] c"-O3"
@.d55 = private constant [5 x i8] c"-flto"
@.c56 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:292: reached unreachable code\0A\00"
@.c57 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:295: slice bounds out of range\0A\00"
@.d58 = private constant [1 x i8] c"/"
@.d59 = private constant [1 x i8] c"."
@.d60 = private constant [2 x i8] c".o"
@.d61 = private constant [0 x i8] c""
@.d62 = private constant [13 x i8] c"olang_runtime"
@.d63 = private constant [0 x i8] c""
@.d64 = private constant [13 x i8] c"olang_dyncall"
@.d65 = private constant [0 x i8] c""
@.d66 = private constant [0 x i8] c""
@.d67 = private constant [9 x i8] c"--version"
@.d68 = private constant [0 x i8] c""
@.d69 = private constant [0 x i8] c""
@.c70 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:148: reached unreachable code\0A\00"
@.d71 = private constant [0 x i8] c""
@.d72 = private constant [5 x i8] c".race"
@.d73 = private constant [0 x i8] c""
@.d74 = private constant [6 x i8] c".debug"
@.d75 = private constant [0 x i8] c""
@.d76 = private constant [4 x i8] c".san"
@.d77 = private constant [0 x i8] c""
@.d78 = private constant [1 x i8] c"["
@.d79 = private constant [1 x i8] c"m"
@.d80 = private constant [3 x i8] c"[0m"
@.d81 = private constant [27 x i8] c": semantic errors, skipping"
@.d82 = private constant [2 x i8] c"31"
@.d83 = private constant [27 x i8] c": cannot be built, skipping"
@.d84 = private constant [2 x i8] c"31"
@.c85 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:345: slice bounds out of range\0A\00"
@.d86 = private constant [3 x i8] c".ll"
@.d87 = private constant [0 x i8] c""
declare i32 @getpid()
@.d88 = private constant [1 x i8] c"."
@.d89 = private constant [4 x i8] c".tmp"
@.d90 = private constant [2 x i8] c"-c"
@.d91 = private constant [2 x i8] c"-o"
declare i64 @sysconf(i32)
@.c92 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:478: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2
  %t1 = load ptr, ptr %l0
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3
  %t4 = load ptr, ptr %l1
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4
  %t7 = load i64, ptr %l3
  %t8 = load i64, ptr %l4
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5
  %t10 = load i1, ptr %l5
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d93 = private constant [1 x i8] c"a"
@.c94 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:254: reached unreachable code\0A\00"
@.d95 = private constant [0 x i8] c""
@.d96 = private constant [0 x i8] c""
@.d97 = private constant [0 x i8] c""
@.d98 = private constant [5 x i8] c".main"
@.d99 = private constant [5 x i8] c".test"
@.d100 = private constant [5 x i8] c".inst"
@.c101 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:279: reached unreachable code\0A\00"
@.c102 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:437: reached unreachable code\0A\00"
@.c103 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:438: reached unreachable code\0A\00"
@.d104 = private constant [1 x i8] c" "
@.d105 = private constant [1 x i8] c" "
@.d106 = private constant [1 x i8] c"\0A"
@.c107 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:319: reached unreachable code\0A\00"
@.d108 = private constant [0 x i8] c""
@.d109 = private constant [0 x i8] c""
@.c110 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:320: reached unreachable code\0A\00"
@.d111 = private constant [11 x i8] c"cannot run "
@.d112 = private constant [1 x i8] c"\0A"
@.c113 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:448: reached unreachable code\0A\00"
@.c114 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:450: reached unreachable code\0A\00"
@.c115 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:449: reached unreachable code\0A\00"
@.d116 = private constant [5 x i8] c"build"
@.d117 = private constant [0 x i8] c""
@.d118 = private constant [0 x i8] c""
@.d119 = private constant [0 x i8] c""
@.d120 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<compiler/build:Unit>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/build:Unit>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/build:Unit>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/build:Unit>" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/build:Unit>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/build:Unit>", ptr %l0
  store %"std/prelude/list:List<compiler/build:Unit>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/build:Unit>", ptr %rv
  ret %"std/prelude/list:List<compiler/build:Unit>" %rr
}

@.d121 = private constant [0 x i8] c""
@.d122 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<Array<std/prelude/text:String&>&>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %l0
  store %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<Array<std/prelude/text:String&>&>", ptr %rv
  ret %"std/prelude/list:List<Array<std/prelude/text:String&>&>" %rr
}

declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @std_2fchan_2eInit_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
declare %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/build:Unit>" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Array<std/prelude/text:String&>&>" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
