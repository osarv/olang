; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Sha256" = type { [8 x i32], [64 x i8], i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, [8 x i64], [8 x i64], [8 x i64] }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:compiles" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Program" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:stubFrontend" = type { i64, i64 }
@G_2ecompiler_2fbuild_2eImportLimit = constant <{ [8 x i8] }> <{ [8 x i8] c"\46\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbuild_2ePhaseAt = global i64 zeroinitializer
@G_2ecompiler_2fbuild_2eShaK = constant <{ [256 x i8] }> <{ [256 x i8] c"\98\2F\8A\42\91\44\37\71\CF\FB\C0\B5\A5\DB\B5\E9\5B\C2\56\39\F1\11\F1\59\A4\82\3F\92\D5\5E\1C\AB\98\AA\07\D8\01\5B\83\12\BE\85\31\24\C3\7D\0C\55\74\5D\BE\72\FE\B1\DE\80\A7\06\DC\9B\74\F1\9B\C1\C1\69\9B\E4\86\47\BE\EF\C6\9D\C1\0F\CC\A1\0C\24\6F\2C\E9\2D\AA\84\74\4A\DC\A9\B0\5C\DA\88\F9\76\52\51\3E\98\6D\C6\31\A8\C8\27\03\B0\C7\7F\59\BF\F3\0B\E0\C6\47\91\A7\D5\51\63\CA\06\67\29\29\14\85\0A\B7\27\38\21\1B\2E\FC\6D\2C\4D\13\0D\38\53\54\73\0A\65\BB\0A\6A\76\2E\C9\C2\81\85\2C\72\92\A1\E8\BF\A2\4B\66\1A\A8\70\8B\4B\C2\A3\51\6C\C7\19\E8\92\D1\24\06\99\D6\85\35\0E\F4\70\A0\6A\10\16\C1\A4\19\08\6C\37\1E\4C\77\48\27\B5\BC\B0\34\B3\0C\1C\39\4A\AA\D8\4E\4F\CA\9C\5B\F3\6F\2E\68\EE\82\8F\74\6F\63\A5\78\14\78\C8\84\08\02\C7\8C\FA\FF\BE\90\EB\6C\50\A4\F7\A3\F9\BE\F2\78\71\C6" }>, align 64
@G_2ecompiler_2fbuild_2eThinFrom = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/build:Sha256"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l23 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l8
  store %"compiler/build:Sha256" %t2, ptr %l1
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  br label %bb8
bb4:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @olang_loc_425ee9903c92bc28_2d21c05ef6c078ec)
  unreachable
bb7:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb8:
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t39)
  br label %bb13
bb13:
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb9
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  store i64 %t54, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t57 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t57, ptr %l36
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2eImportLimit_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 70, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i8
  %l45 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load i1, ptr %l10, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l11, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 6
  store i64 %t14, ptr %l14, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = icmp sge i64 0, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  br label %bb11
bb5:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = icmp sle i64 0, %t19
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb7:
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb9:
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = getelementptr i8, ptr %t27, i64 0
  %t30 = sub i64 %t28, 0
  %t31 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb11:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l20
  br label %bb12
bb12:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t35, ptr %l2
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l5, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb30
bb15:
  br label %bb16
bb16:
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l28, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t51
  %t56 = load i8, ptr %t55, !tbaa !32
  store i8 %t56, ptr %l6, !tbaa !22
  store ptr %l2, ptr %l31, !tbaa !29
  %t58 = load i8, ptr %l6, !tbaa !22
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t58)
  store i1 %t60, ptr %l33
  br label %bb17
bb17:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t62 = load i8, ptr %l6, !tbaa !22
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t62)
  store i1 %t64, ptr %l36
  br label %bb20
bb20:
  %t65 = load i1, ptr %l36, !tbaa !21
  store i1 %t65, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb23:
  %t67 = load i8, ptr %l6, !tbaa !22
  %t69 = icmp eq i8 %t67, 95
  store i1 %t69, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t71 = load i1, ptr %l37, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  %t72 = load i8, ptr %l6, !tbaa !22
  store i8 %t72, ptr %l40, !tbaa !22
  br label %bb27
bb26:
  store i8 95, ptr %l40, !tbaa !22
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i8, ptr %l40, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t74, i8 %t75)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s3)
  br label %bb29
bb29:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l4, !tbaa !24
  br label %bb13
bb30:
  %t81 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t81, ptr %l45
  br label %bb31
bb31:
  %t82 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t82, ptr %l46, !tbaa !27
  %t83 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  store i64 %t84, ptr %l47, !tbaa !24
  %t85 = load i64, ptr %l47, !tbaa !24
  %t86 = mul i64 %t85, 1
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l48, !tbaa !27
  %t90 = getelementptr { i64, ptr }, ptr %l48, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = load i64, ptr %l47, !tbaa !24
  %t95 = mul i64 %t94, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t91, ptr %t93, i64 %t95, i1 false)
  %t96 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t96, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t97 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t97, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d2, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_1a0af222d89a1264_6ae848cde6020298)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t12, ptr %l1, !tbaa !27
  %t13 = call i64 @std_2ftime_2eNow()
  store i64 %t13, ptr %l8
  br label %bb7
bb7:
  %t14 = load i64, ptr %l8, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t17 = icmp ne i64 %t15, 0
  br i1 %t17, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t26 = sdiv i64 %t24, 1000000
  %t27 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t28 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t30 = extractvalue { i64, ptr } %t19, 1
  %t31 = extractvalue { i64, ptr } %t19, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t35 = add i64 %t32, %t34
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t27, i64 %t28)
  %t43 = getelementptr i8, ptr %t42, i64 %t28
  call void @olang_textcopy(ptr %t43, ptr %t30, i64 %t31)
  %t44 = getelementptr i8, ptr %t43, i64 %t31
  call void @olang_textcopy(ptr %t44, ptr %t33, i64 %t34)
  %t45 = getelementptr i8, ptr %t44, i64 %t34
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t26)
  %t47 = getelementptr i8, ptr %t45, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t42, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  call void @compiler_2fbuild_2esayErr(ptr %s2, { i64, ptr } %t56)
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t58 = load i64, ptr %l2, !tbaa !24
  store i64 %t58, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t62, ptr %l20
  br label %bb12
bb12:
  %t63 = load i1, ptr %l20, !tbaa !21
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t64, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t66, ptr %l23
  br label %bb15
bb14:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb16
bb15:
  %t67 = load i1, ptr %l23, !tbaa !21
  store i1 %t67, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l21, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  call void @std_2fos_2eExit(i32 0)
  unreachable
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_5ecb9fdb04842c55_e03f98123a4ef969)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ePhaseAt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ePid() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @getpid()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i8
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t25)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t29 = load i8, ptr %l5, !tbaa !22
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t29)
  store i1 %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load i1, ptr %l22, !tbaa !21
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i8, ptr %l5, !tbaa !22
  %t36 = icmp eq i8 %t34, 95
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t39 = load i8, ptr %l5, !tbaa !22
  %t41 = icmp eq i8 %t39, 45
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t44 = load i8, ptr %l5, !tbaa !22
  store i8 %t44, ptr %l29, !tbaa !22
  br label %bb19
bb18:
  store i8 95, ptr %l29, !tbaa !22
  br label %bb19
bb19:
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t47 = load i8, ptr %l29, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t46, i8 %t47)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb22:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l41 = alloca { { i64, ptr }, { i64, ptr } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l88 = alloca %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc"
  %l98 = alloca { i64, ptr }
  %l103 = alloca i32
  %l111 = alloca i64
  %l118 = alloca i64
  %l121 = alloca i64
  %l150 = alloca { { i64, ptr }, { i64, ptr } }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %jh10 = alloca ptr
  %s12 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t28 = alloca i64
  %t168 = alloca { { i64, ptr }, ptr }, align 8
  %t179 = alloca %"std/chan:Chan.352927c3413fc4ddcbe8e6329f7841cc", align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l27, !tbaa !24
  %t6 = load i64, ptr %l27, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l27, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb3:
  %t12 = load i64, ptr %l27, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = load i64, ptr %l31, !tbaa !24
  %t20 = icmp sge i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb5:
  %t22 = load i64, ptr %l31, !tbaa !24
  %t23 = icmp sle i64 %t22, 576460752303423487
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb7:
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = mul i64 %t25, 16
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t25
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, ptr }, ptr %t27, i64 %t32
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) }, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t27, 1
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb9:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t43, 0
  %t50 = insertvalue { { i64, ptr }, { i64, ptr } } %t48, { i64, ptr } %t45, 1
  store { { i64, ptr }, { i64, ptr } } %t50, ptr %l41
  %t51 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l42, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l43, !tbaa !24
  %t55 = load i64, ptr %l43, !tbaa !24
  %t56 = mul i64 %t55, 4
  %t57 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l44, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = mul i64 %t64, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  %t68 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l45, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l46, !tbaa !24
  %t72 = load i64, ptr %l46, !tbaa !24
  %t73 = mul i64 %t72, 16
  %t74 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = mul i64 %t81, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t84 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  store { i64, ptr } %t83, ptr %t84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { { i64, ptr }, { i64, ptr } }, ptr %l41
  store { { i64, ptr }, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb12, label %bb13
bb12:
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = icmp sle i64 %t90, 1152921504606846975
  br i1 %t91, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb14:
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = mul i64 %t93, 8
  %t95 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l3, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb16:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb18:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l59, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t127 = load i64, ptr %l59, !tbaa !24
  store i64 %t127, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t129 = load i64, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t137 = load i64, ptr %l7, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i64, ptr %t152, i64 %t147
  store i64 %t148, ptr %t153, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l11, !tbaa !24
  br label %bb22
bb27:
  %t158 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t162 = icmp sgt i64 %t160, 0
  br i1 %t162, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t164 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t166 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t167 = ptrtoint ptr %t166 to i64
  %t169 = getelementptr { { i64, ptr }, ptr }, ptr %t168, i32 0, i32 0
  store { i64, ptr } %t165, ptr %t169, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t171 = getelementptr { { i64, ptr }, ptr }, ptr %t168, i32 0, i32 1
  store ptr %v1, ptr %t171, !tbaa !28
  %t172 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_9, 0
  %t173 = insertvalue { ptr, ptr } %t172, ptr %t168, 1
  %t176 = extractvalue { ptr, ptr } %t173, 0
  %t177 = extractvalue { ptr, ptr } %t173, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s5, { i64, ptr } %t164, ptr %t176, ptr %t177)
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t178 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %t179, ptr %s0, i64 %t178)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t179, i64 272, i1 false)
  br label %bb32
bb32:
  %t181 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 272, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %l88, i64 272, i1 false)
  store ptr %t181, ptr %l13, !tbaa !29
  %t183 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eInit_3cI64_3e(ptr %s0, ptr %t183)
  br label %bb33
bb33:
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t185, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb36:
  br label %bb37
bb37:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t199, ptr %l98, !tbaa !27
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i64, ptr %t203, i64 %t200
  %t205 = load i64, ptr %t204, !tbaa !34
  %t207 = load ptr, ptr %l13, !tbaa !29
  %t211 = call i32 @std_2fchan_2eSend_3cI64_3e(ptr %s0, ptr %t207, i64 %t205)
  store i32 %t211, ptr %l103
  %t212 = icmp ne i32 %t211, 0
  br i1 %t212, label %bb39, label %ok.213
ok.213:
  br label %bb38
bb38:
  br label %bb43
bb39:
  %t214 = load i32, ptr %l103, !tbaa !23
  %t215 = ashr i32 %t214, 16
  %t217 = icmp eq i32 %t215, 1
  br i1 %t217, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @olang_loc_1359a9f97975288c_a8d4abcb606172b0)
  unreachable
bb42:
  call void @__olang_ert_req_clear()
  call void @__olang_check_failed(ptr @olang_loc_1359a9f97975288c_a8d4abcb606172b0)
  unreachable
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t219 = load i64, ptr %l15, !tbaa !24
  %t221 = add i64 %t219, 1
  store i64 %t221, ptr %l15, !tbaa !24
  br label %bb34
bb45:
  %t223 = load i64, ptr %l1, !tbaa !24
  %t224 = load i64, ptr %l3, !tbaa !24
  %t227 = icmp slt i64 %t223, %t224
  br i1 %t227, label %bb46, label %bb47
bb46:
  %t229 = load i64, ptr %l1, !tbaa !24
  store i64 %t229, ptr %l111, !tbaa !24
  br label %bb48
bb47:
  %t231 = load i64, ptr %l3, !tbaa !24
  store i64 %t231, ptr %l111, !tbaa !24
  br label %bb48
bb48:
  %t233 = load i64, ptr %l111, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s10
  store ptr null, ptr %jh10
  store i64 0, ptr %l19, !tbaa !24
  store i64 %t233, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t236 = load i64, ptr %l20, !tbaa !24
  %t237 = load i64, ptr %l19, !tbaa !24
  %t240 = icmp sgt i64 %t236, %t237
  br i1 %t240, label %bb49, label %bb50
bb49:
  %t242 = load i64, ptr %l21, !tbaa !24
  %t244 = icmp sgt i64 %t242, 0
  br i1 %t244, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb54
bb51:
  %t246 = load i64, ptr %l20, !tbaa !24
  %t247 = load i64, ptr %l19, !tbaa !24
  %t250 = sub i64 %t246, %t247
  %t251 = load i64, ptr %l21, !tbaa !24
  %t254 = add i64 %t250, %t251
  %t256 = sub i64 %t254, 1
  %t257 = load i64, ptr %l21, !tbaa !24
  %t260 = sdiv i64 %t256, %t257
  store i64 %t260, ptr %l121, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb53
bb53:
  %t262 = load i64, ptr %l121, !tbaa !24
  store i64 %t262, ptr %l118, !tbaa !24
  br label %bb54
bb54:
  %t263 = load i64, ptr %l118, !tbaa !24
  store i64 %t263, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t264 = load i64, ptr %l23, !tbaa !24
  %t265 = load i64, ptr %l22, !tbaa !24
  %t268 = icmp slt i64 %t264, %t265
  %t270 = xor i1 %t268, true
  br i1 %t270, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t272 = load i64, ptr %l19, !tbaa !24
  %t273 = load i64, ptr %l23, !tbaa !24
  %t274 = load i64, ptr %l21, !tbaa !24
  %t277 = mul i64 %t273, %t274
  %t280 = add i64 %t272, %t277
  store i64 %t280, ptr %l24, !tbaa !24
  %t282 = load ptr, ptr %l13, !tbaa !29
  %t283 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t285 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t290 = call ptr @__olang_standin(ptr %s0)
  %t291 = call ptr @__olang_standin(ptr %v0)
  %t292 = call ptr @__olang_standin(ptr %v2)
  %t293 = call ptr @__olang_standin(ptr %v2)
  %t294 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t295 = ptrtoint ptr %t294 to i64
  %t296 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 %t295, i64 8)
  %t297 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 0
  store ptr %t282, ptr %t297
  %t298 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 1
  store { i64, ptr } %t283, ptr %t298
  %t299 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 2
  store { i64, ptr } %t284, ptr %t299
  %t300 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 3
  store { i64, ptr } %t285, ptr %t300
  %t301 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 4
  store ptr %t290, ptr %t301
  %t302 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 5
  store ptr %t291, ptr %t302
  %t303 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 6
  store ptr %t292, ptr %t303
  %t304 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t296, i32 0, i32 7
  store ptr %t293, ptr %t304
  %t305 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  %t306 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr null, ptr %t306
  %t307 = getelementptr { ptr, ptr }, ptr %t306, i32 0, i32 1
  store ptr %t290, ptr %t307
  %t308 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t306, ptr %t308
  %t309 = getelementptr { ptr, ptr }, ptr %t308, i32 0, i32 1
  store ptr %t291, ptr %t309
  %t310 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t308, ptr %t310
  %t311 = getelementptr { ptr, ptr }, ptr %t310, i32 0, i32 1
  store ptr %t292, ptr %t311
  %t312 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t310, ptr %t312
  %t313 = getelementptr { ptr, ptr }, ptr %t312, i32 0, i32 1
  store ptr %t293, ptr %t313
  %t314 = getelementptr { ptr, i64, ptr, i64 }, ptr %t305, i32 0, i32 2
  store ptr %t312, ptr %t314
  %t315 = getelementptr { ptr, i64, ptr, i64 }, ptr %t305, i32 0, i32 1
  store i64 0, ptr %t315
  %t316 = getelementptr { ptr, i64, ptr, i64 }, ptr %t305, i32 0, i32 3
  store i64 0, ptr %t316
  %t317 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t317, ptr @olang_task10, ptr %t296, ptr %t305)
  %t318 = load ptr, ptr %jh10
  store ptr %t318, ptr %t305
  store ptr %t305, ptr %jh10
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb59:
  %t319 = load i64, ptr %l23, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l23, !tbaa !24
  br label %bb55
bb60:
  %t323 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eClose_3cI64_3e(ptr %s0, ptr %t323)
  br label %bb61
bb61:
  %t325 = call i64 @__olang_join_tasks(ptr %jh10)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  %t326 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t331 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t326, 0
  %t333 = insertvalue { { i64, ptr }, { i64, ptr } } %t331, { i64, ptr } %t328, 1
  store { { i64, ptr }, { i64, ptr } } %t333, ptr %l150
  %t334 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l151, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  store i64 %t337, ptr %l152, !tbaa !24
  %t338 = load i64, ptr %l152, !tbaa !24
  %t339 = mul i64 %t338, 4
  %t340 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t339)
  %t341 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  store { i64, ptr } %t342, ptr %l153, !tbaa !27
  %t343 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = load i64, ptr %l152, !tbaa !24
  %t348 = mul i64 %t347, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t344, ptr %t346, i64 %t348, i1 false)
  %t349 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t350 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 0
  store { i64, ptr } %t349, ptr %t350, !tbaa !27
  %t351 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 1
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  store { i64, ptr } %t352, ptr %l154, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 0
  store i64 %t354, ptr %l155, !tbaa !24
  %t355 = load i64, ptr %l155, !tbaa !24
  %t356 = mul i64 %t355, 16
  %t357 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t356)
  %t358 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l156, !tbaa !27
  %t360 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = load i64, ptr %l155, !tbaa !24
  %t365 = mul i64 %t364, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t361, ptr %t363, i64 %t365, i1 false)
  %t366 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t367 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 1
  store { i64, ptr } %t366, ptr %t367, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t368 = load { { i64, ptr }, { i64, ptr } }, ptr %l150
  store { { i64, ptr }, { i64, ptr } } %t368, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbuild_2eShaK_2einit() #0 {
entry:
  %l0 = alloca [64 x i32]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [64 x i32], ptr %l0, i64 0, i64 0
  store i32 1116352408, ptr %t1
  %t2 = getelementptr [64 x i32], ptr %l0, i64 0, i64 1
  store i32 1899447441, ptr %t2
  %t3 = getelementptr [64 x i32], ptr %l0, i64 0, i64 2
  store i32 -1245643825, ptr %t3
  %t4 = getelementptr [64 x i32], ptr %l0, i64 0, i64 3
  store i32 -373957723, ptr %t4
  %t5 = getelementptr [64 x i32], ptr %l0, i64 0, i64 4
  store i32 961987163, ptr %t5
  %t6 = getelementptr [64 x i32], ptr %l0, i64 0, i64 5
  store i32 1508970993, ptr %t6
  %t7 = getelementptr [64 x i32], ptr %l0, i64 0, i64 6
  store i32 -1841331548, ptr %t7
  %t8 = getelementptr [64 x i32], ptr %l0, i64 0, i64 7
  store i32 -1424204075, ptr %t8
  %t9 = getelementptr [64 x i32], ptr %l0, i64 0, i64 8
  store i32 -670586216, ptr %t9
  %t10 = getelementptr [64 x i32], ptr %l0, i64 0, i64 9
  store i32 310598401, ptr %t10
  %t11 = getelementptr [64 x i32], ptr %l0, i64 0, i64 10
  store i32 607225278, ptr %t11
  %t12 = getelementptr [64 x i32], ptr %l0, i64 0, i64 11
  store i32 1426881987, ptr %t12
  %t13 = getelementptr [64 x i32], ptr %l0, i64 0, i64 12
  store i32 1925078388, ptr %t13
  %t14 = getelementptr [64 x i32], ptr %l0, i64 0, i64 13
  store i32 -2132889090, ptr %t14
  %t15 = getelementptr [64 x i32], ptr %l0, i64 0, i64 14
  store i32 -1680079193, ptr %t15
  %t16 = getelementptr [64 x i32], ptr %l0, i64 0, i64 15
  store i32 -1046744716, ptr %t16
  %t17 = getelementptr [64 x i32], ptr %l0, i64 0, i64 16
  store i32 -459576895, ptr %t17
  %t18 = getelementptr [64 x i32], ptr %l0, i64 0, i64 17
  store i32 -272742522, ptr %t18
  %t19 = getelementptr [64 x i32], ptr %l0, i64 0, i64 18
  store i32 264347078, ptr %t19
  %t20 = getelementptr [64 x i32], ptr %l0, i64 0, i64 19
  store i32 604807628, ptr %t20
  %t21 = getelementptr [64 x i32], ptr %l0, i64 0, i64 20
  store i32 770255983, ptr %t21
  %t22 = getelementptr [64 x i32], ptr %l0, i64 0, i64 21
  store i32 1249150122, ptr %t22
  %t23 = getelementptr [64 x i32], ptr %l0, i64 0, i64 22
  store i32 1555081692, ptr %t23
  %t24 = getelementptr [64 x i32], ptr %l0, i64 0, i64 23
  store i32 1996064986, ptr %t24
  %t25 = getelementptr [64 x i32], ptr %l0, i64 0, i64 24
  store i32 -1740746414, ptr %t25
  %t26 = getelementptr [64 x i32], ptr %l0, i64 0, i64 25
  store i32 -1473132947, ptr %t26
  %t27 = getelementptr [64 x i32], ptr %l0, i64 0, i64 26
  store i32 -1341970488, ptr %t27
  %t28 = getelementptr [64 x i32], ptr %l0, i64 0, i64 27
  store i32 -1084653625, ptr %t28
  %t29 = getelementptr [64 x i32], ptr %l0, i64 0, i64 28
  store i32 -958395405, ptr %t29
  %t30 = getelementptr [64 x i32], ptr %l0, i64 0, i64 29
  store i32 -710438585, ptr %t30
  %t31 = getelementptr [64 x i32], ptr %l0, i64 0, i64 30
  store i32 113926993, ptr %t31
  %t32 = getelementptr [64 x i32], ptr %l0, i64 0, i64 31
  store i32 338241895, ptr %t32
  %t33 = getelementptr [64 x i32], ptr %l0, i64 0, i64 32
  store i32 666307205, ptr %t33
  %t34 = getelementptr [64 x i32], ptr %l0, i64 0, i64 33
  store i32 773529912, ptr %t34
  %t35 = getelementptr [64 x i32], ptr %l0, i64 0, i64 34
  store i32 1294757372, ptr %t35
  %t36 = getelementptr [64 x i32], ptr %l0, i64 0, i64 35
  store i32 1396182291, ptr %t36
  %t37 = getelementptr [64 x i32], ptr %l0, i64 0, i64 36
  store i32 1695183700, ptr %t37
  %t38 = getelementptr [64 x i32], ptr %l0, i64 0, i64 37
  store i32 1986661051, ptr %t38
  %t39 = getelementptr [64 x i32], ptr %l0, i64 0, i64 38
  store i32 -2117940946, ptr %t39
  %t40 = getelementptr [64 x i32], ptr %l0, i64 0, i64 39
  store i32 -1838011259, ptr %t40
  %t41 = getelementptr [64 x i32], ptr %l0, i64 0, i64 40
  store i32 -1564481375, ptr %t41
  %t42 = getelementptr [64 x i32], ptr %l0, i64 0, i64 41
  store i32 -1474664885, ptr %t42
  %t43 = getelementptr [64 x i32], ptr %l0, i64 0, i64 42
  store i32 -1035236496, ptr %t43
  %t44 = getelementptr [64 x i32], ptr %l0, i64 0, i64 43
  store i32 -949202525, ptr %t44
  %t45 = getelementptr [64 x i32], ptr %l0, i64 0, i64 44
  store i32 -778901479, ptr %t45
  %t46 = getelementptr [64 x i32], ptr %l0, i64 0, i64 45
  store i32 -694614492, ptr %t46
  %t47 = getelementptr [64 x i32], ptr %l0, i64 0, i64 46
  store i32 -200395387, ptr %t47
  %t48 = getelementptr [64 x i32], ptr %l0, i64 0, i64 47
  store i32 275423344, ptr %t48
  %t49 = getelementptr [64 x i32], ptr %l0, i64 0, i64 48
  store i32 430227734, ptr %t49
  %t50 = getelementptr [64 x i32], ptr %l0, i64 0, i64 49
  store i32 506948616, ptr %t50
  %t51 = getelementptr [64 x i32], ptr %l0, i64 0, i64 50
  store i32 659060556, ptr %t51
  %t52 = getelementptr [64 x i32], ptr %l0, i64 0, i64 51
  store i32 883997877, ptr %t52
  %t53 = getelementptr [64 x i32], ptr %l0, i64 0, i64 52
  store i32 958139571, ptr %t53
  %t54 = getelementptr [64 x i32], ptr %l0, i64 0, i64 53
  store i32 1322822218, ptr %t54
  %t55 = getelementptr [64 x i32], ptr %l0, i64 0, i64 54
  store i32 1537002063, ptr %t55
  %t56 = getelementptr [64 x i32], ptr %l0, i64 0, i64 55
  store i32 1747873779, ptr %t56
  %t57 = getelementptr [64 x i32], ptr %l0, i64 0, i64 56
  store i32 1955562222, ptr %t57
  %t58 = getelementptr [64 x i32], ptr %l0, i64 0, i64 57
  store i32 2024104815, ptr %t58
  %t59 = getelementptr [64 x i32], ptr %l0, i64 0, i64 58
  store i32 -2067236844, ptr %t59
  %t60 = getelementptr [64 x i32], ptr %l0, i64 0, i64 59
  store i32 -1933114872, ptr %t60
  %t61 = getelementptr [64 x i32], ptr %l0, i64 0, i64 60
  store i32 -1866530822, ptr %t61
  %t62 = getelementptr [64 x i32], ptr %l0, i64 0, i64 61
  store i32 -1538233109, ptr %t62
  %t63 = getelementptr [64 x i32], ptr %l0, i64 0, i64 62
  store i32 -1090935817, ptr %t63
  %t64 = getelementptr [64 x i32], ptr %l0, i64 0, i64 63
  store i32 -965641998, ptr %t64
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fbuild_2eShaK, ptr %l0, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  br label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d12, i32 0, i32 1) }, 0
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } %t13, 0
  %t19 = add i64 %t15, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = getelementptr i8, ptr %t20, i64 %t15
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d13, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l1, !tbaa !27
  br label %bb57
bb4:
  %t7 = load i32, ptr %l0, !tbaa !23
  %t9 = icmp eq i32 %t7, 2
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  br label %bb57
bb8:
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 3
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  br label %bb57
bb12:
  %t19 = load i32, ptr %l0, !tbaa !23
  %t21 = icmp eq i32 %t19, 4
  br i1 %t21, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l1, !tbaa !27
  br label %bb57
bb16:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = icmp eq i32 %t25, 5
  br i1 %t27, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  br label %bb57
bb20:
  %t31 = load i32, ptr %l0, !tbaa !23
  %t33 = icmp eq i32 %t31, 6
  br i1 %t33, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t35, ptr %l1, !tbaa !27
  br label %bb57
bb24:
  %t37 = load i32, ptr %l0, !tbaa !23
  %t39 = icmp eq i32 %t37, 7
  br i1 %t39, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l1, !tbaa !27
  br label %bb57
bb28:
  %t43 = load i32, ptr %l0, !tbaa !23
  %t45 = icmp eq i32 %t43, 8
  br i1 %t45, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t47, ptr %l1, !tbaa !27
  br label %bb57
bb32:
  %t49 = load i32, ptr %l0, !tbaa !23
  %t51 = icmp eq i32 %t49, 9
  br i1 %t51, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  br label %bb57
bb36:
  %t55 = load i32, ptr %l0, !tbaa !23
  %t57 = icmp eq i32 %t55, 11
  br i1 %t57, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t59, ptr %l1, !tbaa !27
  br label %bb57
bb40:
  %t61 = load i32, ptr %l0, !tbaa !23
  %t63 = icmp eq i32 %t61, 13
  br i1 %t63, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t65, ptr %l1, !tbaa !27
  br label %bb57
bb44:
  %t67 = load i32, ptr %l0, !tbaa !23
  %t69 = icmp eq i32 %t67, 14
  br i1 %t69, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t71, ptr %l1, !tbaa !27
  br label %bb57
bb48:
  %t73 = load i32, ptr %l0, !tbaa !23
  %t75 = icmp eq i32 %t73, 15
  br i1 %t75, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t77, ptr %l1, !tbaa !27
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t79 = load i32, ptr %l0, !tbaa !23
  %t80 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t83 = sext i32 %t79 to i64
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = getelementptr i8, ptr %t86, i64 %t81
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t83)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  store { i64, ptr } %t90, ptr %l1, !tbaa !27
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_84eba90bdad5d702_427cd4b75eaf1c36)
  unreachable
bb57:
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l56, !tbaa !24
  %t94 = load i64, ptr %l56, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l57, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t105, ptr %l1, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"std/os:Output"
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca { i64, ptr }
  %l51 = alloca %"std/os:Output"
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"std/os:Output"
  %l56 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l81 = alloca i32
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l4, !tbaa !21
  store { i64, ptr } %a3, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l22, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t16
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  %t23 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, ptr %l25
  br label %bb5
bb5:
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l9
  %t27 = extractvalue { i64, ptr } %a1, 1
  %t28 = extractvalue { i64, ptr } %a1, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } %t38)
  br label %bb6
bb6:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d27, i32 0, i32 1) })
  br label %bb7
bb7:
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s5
  %t48 = load i64, ptr %l11, !tbaa !24
  %t49 = load i64, ptr %l12, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t56, ptr %l38, !tbaa !27
  %t57 = load i64, ptr %l11, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %t60, i64 %t57
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !37
  %t66 = extractvalue { i64, ptr } %t62, 1
  %t67 = extractvalue { i64, ptr } %t62, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } %t77)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb13
bb13:
  %t80 = load i64, ptr %l11, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l11, !tbaa !24
  br label %bb8
bb14:
  %t84 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t86, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } %t97)
  br label %bb15
bb15:
  %t101 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s2, ptr %s2, ptr %l9)
  store { i64, ptr } %t101, ptr %l53
  br label %bb16
bb16:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l54, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t104 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t102, { i64, ptr } %t103, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t105 = extractvalue { i32, %"std/os:Output" } %t104, 1
  %t106 = extractvalue { i32, %"std/os:Output" } %t104, 0
  store i32 %t106, ptr %l56
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb18, label %ok.108
ok.108:
  store %"std/os:Output" %t105, ptr %l55
  br label %bb17
bb17:
  %t109 = load %"std/os:Output", ptr %l55
  store %"std/os:Output" %t109, ptr %l51
  br label %bb24
bb18:
  %t110 = load i32, ptr %l56, !tbaa !23
  %t111 = ashr i32 %t110, 16
  %t113 = icmp eq i32 %t111, 1
  br i1 %t113, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_c094ff343a4c193c_f5cfbac5a7fd7498)
  unreachable
bb21:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s9
  %t115 = load ptr, ptr %l0, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = extractvalue { i64, ptr } %t116, 0
  %t120 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d30, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d30, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t118, i64 %t119)
  %t124 = getelementptr i8, ptr %t123, i64 %t119
  call void @olang_textcopy(ptr %t124, ptr %t120, i64 %t121)
  %t125 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t123, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = extractvalue { i64, ptr } %t126, 1
  %t130 = mul i64 %t128, 1
  %t131 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t130)
  call void @llvm.memcpy.p0.p0.i64(ptr %t131, ptr %t129, i64 %t130, i1 false)
  %t132 = insertvalue { i64, ptr } undef, i64 %t128, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t131, 1
  %t136 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %t115, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d31, i32 0, i32 1) }, { i64, ptr } %t133)
  store { i64, ptr } %t136, ptr %l63
  br label %bb22
bb22:
  %t137 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  call void @compiler_2fbuild_2esayln(ptr %s9, { i64, ptr } %t143)
  br label %bb23
bb23:
  store i1 true, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb24:
  %t145 = load %"std/os:Output", ptr %l51
  store %"std/os:Output" %t145, ptr %l14
  %t146 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t147 = load i32, ptr %t146, !tbaa !23
  %t149 = icmp sgt i32 %t147, 128
  br i1 %t149, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s11
  %t151 = load ptr, ptr %l0, !tbaa !29
  store ptr %t151, ptr %l67, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t152, ptr %l68, !tbaa !27
  %t153 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t154 = load i32, ptr %t153, !tbaa !23
  %t156 = sub i32 %t154, 128
  %t158 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t156)
  store { i64, ptr } %t158, ptr %l71
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t159 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t159, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t165 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t165, 1
  %t167 = extractvalue { i64, ptr } %t165, 0
  %t168 = add i64 %t164, %t167
  %t169 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t160, i64 %t161)
  %t173 = getelementptr i8, ptr %t172, i64 %t161
  call void @olang_textcopy(ptr %t173, ptr %t162, i64 %t163)
  %t174 = getelementptr i8, ptr %t173, i64 %t163
  call void @olang_textcopy(ptr %t174, ptr %t166, i64 %t167)
  %t175 = getelementptr i8, ptr %t174, i64 %t167
  call void @olang_textcopy(ptr %t175, ptr %t169, i64 %t170)
  %t176 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t172, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  %t185 = load ptr, ptr %l67, !tbaa !29
  %t187 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %t185, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d34, i32 0, i32 1) }, { i64, ptr } %t184)
  store { i64, ptr } %t187, ptr %l74
  br label %bb28
bb28:
  %t188 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t188, 0
  %t190 = extractvalue { i64, ptr } %t188, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t194)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s11)
  br label %bb30
bb30:
  %t196 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t197 = load i32, ptr %t196, !tbaa !23
  %t199 = icmp ne i32 %t197, 0
  br i1 %t199, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t201 = load i64, ptr %l6, !tbaa !24
  %t203 = add i64 %t201, 1
  store i64 %t203, ptr %l6, !tbaa !24
  br label %bb1
bb35:
  %t205 = load i1, ptr %l4, !tbaa !21
  br i1 %t205, label %bb36, label %bb37
bb36:
  store i32 1, ptr %l81, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l81, !tbaa !23
  br label %bb38
bb38:
  %t207 = load i32, ptr %l81, !tbaa !23
  store i32 %t207, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2eThinFrom_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8388608, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t18)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fbuild_2eclaim(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca i32
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l50 = alloca i32
  %l60 = alloca i1
  %l63 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l15, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s3
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s3)
  br label %bb42
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = call i32 @std_2fos_2eMkDir(ptr %s0, { i64, ptr } %t59)
  store i32 %t61, ptr %l37
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb12, label %ok.63
ok.63:
  br label %bb11
bb11:
  br label %bb19
bb12:
  %t64 = load i32, ptr %l37, !tbaa !23
  %t65 = icmp eq i32 %t64, 65537
  br i1 %t65, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb16, label %bb17
bb15:
  call void @__olang_ert_req_clear()
  store i1 false, ptr %l9, !tbaa !21
  br label %bb19
bb16:
  br label %bb18
bb17:
  call void @__olang_check_failed(ptr @olang_loc_3577cefc2355b499_7d6905d22965c065)
  unreachable
bb18:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb19:
  %t73 = load i1, ptr %l9, !tbaa !21
  br i1 %t73, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t75 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = getelementptr i8, ptr %t82, i64 %t78
  call void @olang_textcopy(ptr %t83, ptr %t79, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l45, !tbaa !27
  %t93 = call i32 @getpid()
  store i32 %t93, ptr %l46
  br label %bb22
bb21:
  br label %bb30
bb22:
  %t94 = load i32, ptr %l46, !tbaa !23
  %t95 = sext i32 %t94 to i64
  %t96 = call i64 @__olang_fmt_i64(ptr null, i64 %t95)
  %t97 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t96)
  %t98 = call i64 @__olang_fmt_i64(ptr %t97, i64 %t95)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t97, 1
  %t103 = extractvalue { i64, ptr } %t100, 0
  %t104 = extractvalue { i64, ptr } %t100, 1
  %t105 = mul i64 %t103, 1
  %t106 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t105)
  call void @llvm.memcpy.p0.p0.i64(ptr %t106, ptr %t104, i64 %t105, i1 false)
  %t107 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t106, 1
  %t109 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t111 = call i32 @std_2fos_2eWriteFile(ptr %s6, ptr %s6, { i64, ptr } %t109, { i64, ptr } %t108)
  store i32 %t111, ptr %l50
  %t112 = icmp ne i32 %t111, 0
  br i1 %t112, label %bb24, label %ok.113
ok.113:
  br label %bb23
bb23:
  br label %bb28
bb24:
  %t114 = load i32, ptr %l50, !tbaa !23
  %t115 = ashr i32 %t114, 16
  %t117 = icmp eq i32 %t115, 1
  br i1 %t117, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_5f770347e29e5fc8_2866945fa632b934)
  unreachable
bb27:
  call void @__olang_ert_req_clear()
  br label %bb28
bb28:
  %t121 = getelementptr %"compiler/build:compiles", ptr %a1, i32 0, i32 6
  %t122 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t122, 1
  %t125 = extractvalue { i64, ptr } %t122, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t121, { i64, ptr } %t135)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb30:
  %t139 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t141 = call i1 @compiler_2fbuild_2eholderAlive(ptr %s0, { i64, ptr } %t139)
  store i1 %t141, ptr %l60
  br label %bb31
bb31:
  %t142 = load i1, ptr %l60, !tbaa !21
  br i1 %t142, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb33:
  br label %bb34
bb34:
  %t144 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t146 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t144)
  store i32 %t146, ptr %l63
  %t147 = icmp ne i32 %t146, 0
  br i1 %t147, label %bb36, label %ok.148
ok.148:
  br label %bb35
bb35:
  br label %bb40
bb36:
  %t149 = load i32, ptr %l63, !tbaa !23
  %t150 = ashr i32 %t149, 16
  %t152 = icmp eq i32 %t150, 1
  br i1 %t152, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_check_failed(ptr @olang_loc_51ea3fb94a0f14a3_79d3779c97249b6f)
  unreachable
bb39:
  call void @__olang_ert_req_clear()
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s3)
  br label %bb41
bb41:
  %t154 = load i64, ptr %l7, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l7, !tbaa !24
  br label %bb7
bb42:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v2, ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t6 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t15)
  store i1 %t16, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t19, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t21, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %lp2
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t23
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l25 = alloca { i64, ptr }
  %l29 = alloca i1
  %l31 = alloca i1
  %l33 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s1, ptr %a0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %t9
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load ptr, ptr %l2, !tbaa !29
  %t12 = load i64, ptr %l3, !tbaa !24
  %t15 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s1, ptr %t11, i64 %t12)
  %t16 = extractvalue { i32, { i64, ptr } } %t15, 1
  %t17 = extractvalue { i32, { i64, ptr } } %t15, 0
  store i32 %t17, ptr %l16
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb5, label %ok.19
ok.19:
  store { i64, ptr } %t16, ptr %l15
  br label %bb4
bb4:
  %t20 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t20, ptr %l12, !tbaa !27
  br label %bb9
bb5:
  %t21 = load i32, ptr %l16, !tbaa !23
  %t22 = ashr i32 %t21, 16
  %t24 = icmp eq i32 %t22, 1
  br i1 %t24, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d9f2db171606c9bf_4bc78b18f11f6703)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb26
bb9:
  %t26 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = extractvalue { i64, ptr } %t27, 0
  store i64 %t29, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t31 = load i64, ptr %l6, !tbaa !24
  %t32 = load i64, ptr %l5, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  %t37 = xor i1 %t35, true
  br i1 %t37, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb12:
  br label %bb13
bb13:
  %t39 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t39, ptr %l25, !tbaa !27
  %t40 = load i64, ptr %l6, !tbaa !24
  %t42 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %t43, i64 %t40
  %t45 = load { i64, ptr }, ptr %t44, !tbaa !37
  store { i64, ptr } %t45, ptr %l7, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t49 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t47, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t49, ptr %l29
  br label %bb14
bb14:
  %t50 = load i1, ptr %l29, !tbaa !21
  %t51 = xor i1 %t50, true
  br i1 %t51, label %bb15, label %bb16
bb15:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s3, { i64, ptr } %t53, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t55, ptr %l33
  br label %bb17
bb16:
  store i1 false, ptr %l31, !tbaa !21
  br label %bb18
bb17:
  %t56 = load i1, ptr %l33, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l31, !tbaa !21
  br label %bb18
bb18:
  %t59 = load i1, ptr %l31, !tbaa !21
  br i1 %t59, label %bb19, label %bb20
bb19:
  %t60 = load ptr, ptr %lp1
  %t61 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t61, 1
  %t64 = extractvalue { i64, ptr } %t61, 0
  %t65 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t63, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t60, { i64, ptr } %t74)
  br label %bb21
bb20:
  br label %bb22
bb21:
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  %t77 = load i64, ptr %l6, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l6, !tbaa !24
  br label %bb10
bb24:
  %t81 = load i64, ptr %l3, !tbaa !24
  %t82 = load i64, ptr %l5, !tbaa !24
  %t85 = add i64 %t81, %t82
  store i64 %t85, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb25
bb25:
  br label %bb3
bb26:
  call void @__olang_scope_close(ptr %s1)
  %t87 = load ptr, ptr %lp1
  %t88 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t87
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t88, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"std/prelude/text:StringBuilder"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l34 = alloca ptr
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca i64
  %l38 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca %"std/os:Output"
  %l43 = alloca %"std/os:FileInfo"
  %l44 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l51 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l53 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l57 = alloca i32
  %l67 = alloca { i64, ptr }
  %l96 = alloca %"std/prelude/text:StringBuilder"
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l113 = alloca { i64, ptr }
  %l126 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l130 = alloca i32
  %l139 = alloca ptr
  %l141 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i32
  %l164 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l180 = alloca { i64, ptr }
  %l181 = alloca i32
  %l191 = alloca { i64, ptr }
  %l208 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l210 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i32
  %l224 = alloca { i64, ptr }
  %l234 = alloca ptr
  %l236 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l244 = alloca i1
  %l246 = alloca i32
  %l252 = alloca i1
  %l254 = alloca %"std/os:Output"
  %l256 = alloca { i64, ptr }
  %l257 = alloca { i64, ptr }
  %l258 = alloca %"std/os:Output"
  %l259 = alloca i32
  %l267 = alloca ptr
  %l270 = alloca %"std/os:FileInfo"
  %l272 = alloca %"std/os:FileInfo"
  %l273 = alloca i32
  %l284 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %s28 = alloca %olang.scope
  %s33 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l44
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l44
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l6
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t19)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s2, ptr %t22)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l51
  br label %bb3
bb3:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l51
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %t26
  store ptr %t26, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load ptr, ptr %l7, !tbaa !29
  %t29 = load i64, ptr %l8, !tbaa !24
  %t32 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s2, ptr %t28, i64 %t29)
  %t33 = extractvalue { i32, { i64, ptr } } %t32, 1
  %t34 = extractvalue { i32, { i64, ptr } } %t32, 0
  store i32 %t34, ptr %l57
  %t35 = icmp ne i32 %t34, 0
  br i1 %t35, label %bb6, label %ok.36
ok.36:
  store { i64, ptr } %t33, ptr %l56
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t37, ptr %l53, !tbaa !27
  br label %bb10
bb6:
  %t38 = load i32, ptr %l57, !tbaa !23
  %t39 = ashr i32 %t38, 16
  %t41 = icmp eq i32 %t39, 1
  br i1 %t41, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  %t43 = load i32, ptr %l57, !tbaa !23
  %t44 = lshr i32 %t43, 16
  %t45 = and i32 %t43, 65535
  %t46 = icmp eq i32 %t44, 1
  %t47 = select i1 %t46, i32 0, i32 0
  %t48 = icmp eq i32 %t43, 0
  %t49 = shl i32 %t47, 16
  %t50 = or i32 %t49, %t45
  %t51 = select i1 %t48, i32 0, i32 %t50
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t51, ptr %rv
  br label %ret
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb10:
  %t53 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t53, ptr %l9, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  store i64 %t56, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load i64, ptr %l11, !tbaa !24
  %t59 = load i64, ptr %l10, !tbaa !24
  %t62 = icmp slt i64 %t58, %t59
  %t64 = xor i1 %t62, true
  br i1 %t64, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t66 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t66, ptr %l67, !tbaa !27
  %t67 = load i64, ptr %l11, !tbaa !24
  %t69 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %t70, i64 %t67
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !37
  %t76 = extractvalue { i64, ptr } %t72, 1
  %t77 = extractvalue { i64, ptr } %t72, 0
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t76, i64 %t77)
  %t79 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  %t82 = extractvalue { i64, ptr } %t80, 0
  %t83 = extractvalue { i64, ptr } %t80, 1
  %t84 = mul i64 %t82, 1
  %t85 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t84)
  call void @llvm.memcpy.p0.p0.i64(ptr %t85, ptr %t83, i64 %t84, i1 false)
  %t86 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t85, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t87)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  %t90 = load i64, ptr %l11, !tbaa !24
  %t92 = add i64 %t90, 1
  store i64 %t92, ptr %l11, !tbaa !24
  br label %bb11
bb17:
  %t94 = load i64, ptr %l8, !tbaa !24
  %t95 = load i64, ptr %l10, !tbaa !24
  %t98 = add i64 %t94, %t95
  store i64 %t98, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb4
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t100 = load ptr, ptr %l0, !tbaa !29
  %t102 = getelementptr %"compiler/build:Config", ptr %t100, i32 0, i32 19
  %t103 = load i1, ptr %t102, !tbaa !21
  br i1 %t103, label %bb20, label %bb21
bb20:
  %t105 = load ptr, ptr %l0, !tbaa !29
  %t107 = getelementptr %"compiler/build:Config", ptr %t105, i32 0, i32 0
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t110 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t112 = extractvalue { i64, ptr } %t108, 1
  %t113 = extractvalue { i64, ptr } %t108, 0
  %t114 = add i64 %t110, %t113
  %t115 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t116 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t117 = add i64 %t114, %t116
  %t118 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t117)
  call void @olang_textcopy(ptr %t118, ptr %t109, i64 %t110)
  %t119 = getelementptr i8, ptr %t118, i64 %t110
  call void @olang_textcopy(ptr %t119, ptr %t112, i64 %t113)
  %t120 = getelementptr i8, ptr %t119, i64 %t113
  call void @olang_textcopy(ptr %t120, ptr %t115, i64 %t116)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t118, 1
  %t124 = extractvalue { i64, ptr } %t122, 0
  %t125 = extractvalue { i64, ptr } %t122, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t129)
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t132 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t133 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t136 = call i64 @__olang_fmt_i64(ptr null, i64 %t132)
  %t137 = add i64 %t134, %t136
  %t138 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t137)
  call void @olang_textcopy(ptr %t138, ptr %t133, i64 %t134)
  %t139 = getelementptr i8, ptr %t138, i64 %t134
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t132)
  %t141 = insertvalue { i64, ptr } undef, i64 %t137, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t138, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t149)
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t152 = load ptr, ptr %l5, !tbaa !29
  %t154 = icmp eq ptr %t152, null
  %t156 = xor i1 %t154, true
  br i1 %t156, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s10
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb27
bb26:
  br label %bb57
bb27:
  %t159 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t159, 1
  %t162 = extractvalue { i64, ptr } %t159, 0
  %t163 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t165)
  call void @olang_textcopy(ptr %t166, ptr %t161, i64 %t162)
  %t167 = getelementptr i8, ptr %t166, i64 %t162
  call void @olang_textcopy(ptr %t167, ptr %t163, i64 %t164)
  %t168 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t169 = insertvalue { i64, ptr } %t168, ptr %t166, 1
  store { i64, ptr } %t169, ptr %l13, !tbaa !27
  %t171 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s10)
  store %"std/prelude/text:StringBuilder" %t171, ptr %l96
  br label %bb28
bb28:
  %t172 = load %"std/prelude/text:StringBuilder", ptr %l96
  store %"std/prelude/text:StringBuilder" %t172, ptr %l14
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s10, ptr %l14, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb29
bb29:
  %t174 = load ptr, ptr %l5, !tbaa !29
  store ptr %t174, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s13
  %t176 = load ptr, ptr %l15, !tbaa !29
  %t177 = load i64, ptr %l16, !tbaa !24
  %t180 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v4, ptr %t176, i64 %t177)
  %t181 = extractvalue { i32, { i64, ptr } } %t180, 1
  %t182 = extractvalue { i32, { i64, ptr } } %t180, 0
  store i32 %t182, ptr %l103
  %t183 = icmp ne i32 %t182, 0
  br i1 %t183, label %bb32, label %ok.184
ok.184:
  store { i64, ptr } %t181, ptr %l102
  br label %bb31
bb31:
  %t185 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t185, ptr %l99, !tbaa !27
  br label %bb36
bb32:
  %t186 = load i32, ptr %l103, !tbaa !23
  %t187 = ashr i32 %t186, 16
  %t189 = icmp eq i32 %t187, 1
  br i1 %t189, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  %t191 = load i32, ptr %l103, !tbaa !23
  %t192 = lshr i32 %t191, 16
  %t193 = and i32 %t191, 65535
  %t194 = icmp eq i32 %t192, 1
  %t195 = select i1 %t194, i32 0, i32 0
  %t196 = icmp eq i32 %t191, 0
  %t197 = shl i32 %t195, 16
  %t198 = or i32 %t197, %t193
  %t199 = select i1 %t196, i32 0, i32 %t198
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t199, ptr %rv
  br label %ret
bb35:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb45
bb36:
  %t201 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t201, ptr %l17, !tbaa !27
  %t202 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  store i64 %t204, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb37
bb37:
  store %olang.scope zeroinitializer, ptr %s14
  %t206 = load i64, ptr %l19, !tbaa !24
  %t207 = load i64, ptr %l18, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb38, label %bb39
bb38:
  call void @__olang_scope_close(ptr %s14)
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t214 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t214, ptr %l113, !tbaa !27
  %t215 = load i64, ptr %l19, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l113, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %t218, i64 %t215
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !37
  %t223 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t224 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t226 = extractvalue { i64, ptr } %t220, 1
  %t227 = extractvalue { i64, ptr } %t220, 0
  %t228 = add i64 %t224, %t227
  %t229 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t230 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t231 = add i64 %t228, %t230
  %t232 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t231)
  call void @olang_textcopy(ptr %t232, ptr %t223, i64 %t224)
  %t233 = getelementptr i8, ptr %t232, i64 %t224
  call void @olang_textcopy(ptr %t233, ptr %t226, i64 %t227)
  %t234 = getelementptr i8, ptr %t233, i64 %t227
  call void @olang_textcopy(ptr %t234, ptr %t229, i64 %t230)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t232, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = extractvalue { i64, ptr } %t236, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s14, ptr %l14, { i64, ptr } %t243)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s14)
  br label %bb42
bb42:
  %t246 = load i64, ptr %l19, !tbaa !24
  %t248 = add i64 %t246, 1
  store i64 %t248, ptr %l19, !tbaa !24
  br label %bb37
bb43:
  %t250 = load i64, ptr %l16, !tbaa !24
  %t251 = load i64, ptr %l18, !tbaa !24
  %t254 = add i64 %t250, %t251
  store i64 %t254, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb44
bb44:
  br label %bb30
bb45:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s10, ptr %s10, ptr %l14, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb46
bb46:
  %t257 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t257, ptr %l126, !tbaa !27
  %t259 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s10, ptr %s10, ptr %l14)
  store { i64, ptr } %t259, ptr %l128
  br label %bb47
bb47:
  %t260 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t261 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t263 = call i32 @std_2fos_2eWriteFile(ptr %s10, ptr %s10, { i64, ptr } %t261, { i64, ptr } %t260)
  store i32 %t263, ptr %l130
  %t264 = icmp ne i32 %t263, 0
  br i1 %t264, label %bb49, label %ok.265
ok.265:
  br label %bb48
bb48:
  br label %bb53
bb49:
  %t266 = load i32, ptr %l130, !tbaa !23
  %t267 = ashr i32 %t266, 16
  %t269 = icmp eq i32 %t267, 1
  br i1 %t269, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  %t271 = load i32, ptr %l130, !tbaa !23
  %t272 = lshr i32 %t271, 16
  %t273 = and i32 %t271, 65535
  %t274 = icmp eq i32 %t272, 1
  %t275 = select i1 %t274, i32 0, i32 0
  %t276 = icmp eq i32 %t271, 0
  %t277 = shl i32 %t275, 16
  %t278 = or i32 %t277, %t273
  %t279 = select i1 %t276, i32 0, i32 %t278
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t279, ptr %rv
  br label %ret
bb52:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb53:
  %t282 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t283 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t286 = extractvalue { i64, ptr } %t282, 1
  %t287 = extractvalue { i64, ptr } %t282, 0
  %t288 = add i64 %t284, %t287
  %t289 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t288)
  call void @olang_textcopy(ptr %t289, ptr %t283, i64 %t284)
  %t290 = getelementptr i8, ptr %t289, i64 %t284
  call void @olang_textcopy(ptr %t290, ptr %t286, i64 %t287)
  %t291 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t289, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t299)
  br label %bb54
bb54:
  store ptr %l6, ptr %l139, !tbaa !29
  %t302 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t304 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v2, { i64, ptr } %t302)
  store { i64, ptr } %t304, ptr %l141
  br label %bb55
bb55:
  %t305 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t306 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t307 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t308 = extractvalue { i64, ptr } %t307, 1
  %t309 = extractvalue { i64, ptr } %t307, 0
  %t310 = add i64 %t306, %t309
  %t311 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t310)
  call void @olang_textcopy(ptr %t311, ptr %t305, i64 %t306)
  %t312 = getelementptr i8, ptr %t311, i64 %t306
  call void @olang_textcopy(ptr %t312, ptr %t308, i64 %t309)
  %t313 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t314 = insertvalue { i64, ptr } %t313, ptr %t311, 1
  %t316 = extractvalue { i64, ptr } %t314, 0
  %t317 = extractvalue { i64, ptr } %t314, 1
  %t318 = mul i64 %t316, 1
  %t319 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t318)
  call void @llvm.memcpy.p0.p0.i64(ptr %t319, ptr %t317, i64 %t318, i1 false)
  %t320 = insertvalue { i64, ptr } undef, i64 %t316, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  %t322 = load ptr, ptr %l139, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %t322, { i64, ptr } %t321)
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s10)
  br label %bb57
bb57:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d54, i32 0, i32 1) })
  br label %bb58
bb58:
  %t325 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t327 = extractvalue { i64, ptr } %t325, 1
  %t328 = extractvalue { i64, ptr } %t325, 0
  %t329 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t328)
  call void @olang_textcopy(ptr %t329, ptr %t327, i64 %t328)
  %t330 = insertvalue { i64, ptr } undef, i64 %t328, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t334 = extractvalue { i64, ptr } %t331, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t338)
  br label %bb59
bb59:
  store ptr %a1, ptr %l21, !tbaa !29
  store i64 0, ptr %l22, !tbaa !24
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s22
  %t343 = load ptr, ptr %l21, !tbaa !29
  %t344 = load i64, ptr %l22, !tbaa !24
  %t347 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t343, i64 %t344)
  %t348 = extractvalue { i32, { i64, ptr } } %t347, 1
  %t349 = extractvalue { i32, { i64, ptr } } %t347, 0
  store i32 %t349, ptr %l154
  %t350 = icmp ne i32 %t349, 0
  br i1 %t350, label %bb62, label %ok.351
ok.351:
  store { i64, ptr } %t348, ptr %l153
  br label %bb61
bb61:
  %t352 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t352, ptr %l150, !tbaa !27
  br label %bb66
bb62:
  %t353 = load i32, ptr %l154, !tbaa !23
  %t354 = ashr i32 %t353, 16
  %t356 = icmp eq i32 %t354, 1
  br i1 %t356, label %bb63, label %bb64
bb63:
  br label %bb65
bb64:
  %t358 = load i32, ptr %l154, !tbaa !23
  %t359 = lshr i32 %t358, 16
  %t360 = and i32 %t358, 65535
  %t361 = icmp eq i32 %t359, 1
  %t362 = select i1 %t361, i32 0, i32 0
  %t363 = icmp eq i32 %t358, 0
  %t364 = shl i32 %t362, 16
  %t365 = or i32 %t364, %t360
  %t366 = select i1 %t363, i32 0, i32 %t365
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t366, ptr %rv
  br label %ret
bb65:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s22)
  br label %bb75
bb66:
  %t368 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t368, ptr %l23, !tbaa !27
  %t369 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t371 = extractvalue { i64, ptr } %t369, 0
  store i64 %t371, ptr %l24, !tbaa !24
  store i64 0, ptr %l25, !tbaa !24
  br label %bb67
bb67:
  store %olang.scope zeroinitializer, ptr %s23
  %t373 = load i64, ptr %l25, !tbaa !24
  %t374 = load i64, ptr %l24, !tbaa !24
  %t377 = icmp slt i64 %t373, %t374
  %t379 = xor i1 %t377, true
  br i1 %t379, label %bb68, label %bb69
bb68:
  call void @__olang_scope_close(ptr %s23)
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t381 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t381, ptr %l164, !tbaa !27
  %t382 = load i64, ptr %l25, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l164, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr { i64, ptr }, ptr %t385, i64 %t382
  %t387 = load { i64, ptr }, ptr %t386, !tbaa !37
  %t391 = extractvalue { i64, ptr } %t387, 1
  %t392 = extractvalue { i64, ptr } %t387, 0
  %t393 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t392)
  call void @olang_textcopy(ptr %t393, ptr %t391, i64 %t392)
  %t394 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = extractvalue { i64, ptr } %t395, 1
  %t399 = mul i64 %t397, 1
  %t400 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t399)
  call void @llvm.memcpy.p0.p0.i64(ptr %t400, ptr %t398, i64 %t399, i1 false)
  %t401 = insertvalue { i64, ptr } undef, i64 %t397, 0
  %t402 = insertvalue { i64, ptr } %t401, ptr %t400, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t402)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s23)
  br label %bb72
bb72:
  %t405 = load i64, ptr %l25, !tbaa !24
  %t407 = add i64 %t405, 1
  store i64 %t407, ptr %l25, !tbaa !24
  br label %bb67
bb73:
  %t409 = load i64, ptr %l22, !tbaa !24
  %t410 = load i64, ptr %l24, !tbaa !24
  %t413 = add i64 %t409, %t410
  store i64 %t413, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s22)
  br label %bb74
bb74:
  br label %bb60
bb75:
  store ptr %a4, ptr %l27, !tbaa !29
  store i64 0, ptr %l28, !tbaa !24
  br label %bb76
bb76:
  store %olang.scope zeroinitializer, ptr %s27
  %t417 = load ptr, ptr %l27, !tbaa !29
  %t418 = load i64, ptr %l28, !tbaa !24
  %t421 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t417, i64 %t418)
  %t422 = extractvalue { i32, { i64, ptr } } %t421, 1
  %t423 = extractvalue { i32, { i64, ptr } } %t421, 0
  store i32 %t423, ptr %l181
  %t424 = icmp ne i32 %t423, 0
  br i1 %t424, label %bb78, label %ok.425
ok.425:
  store { i64, ptr } %t422, ptr %l180
  br label %bb77
bb77:
  %t426 = load { i64, ptr }, ptr %l180, !tbaa !27
  store { i64, ptr } %t426, ptr %l177, !tbaa !27
  br label %bb82
bb78:
  %t427 = load i32, ptr %l181, !tbaa !23
  %t428 = ashr i32 %t427, 16
  %t430 = icmp eq i32 %t428, 1
  br i1 %t430, label %bb79, label %bb80
bb79:
  br label %bb81
bb80:
  %t432 = load i32, ptr %l181, !tbaa !23
  %t433 = lshr i32 %t432, 16
  %t434 = and i32 %t432, 65535
  %t435 = icmp eq i32 %t433, 1
  %t436 = select i1 %t435, i32 0, i32 0
  %t437 = icmp eq i32 %t432, 0
  %t438 = shl i32 %t436, 16
  %t439 = or i32 %t438, %t434
  %t440 = select i1 %t437, i32 0, i32 %t439
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t440, ptr %rv
  br label %ret
bb81:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s27)
  br label %bb91
bb82:
  %t442 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t442, ptr %l29, !tbaa !27
  %t443 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t443, 0
  store i64 %t445, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb83
bb83:
  store %olang.scope zeroinitializer, ptr %s28
  %t447 = load i64, ptr %l31, !tbaa !24
  %t448 = load i64, ptr %l30, !tbaa !24
  %t451 = icmp slt i64 %t447, %t448
  %t453 = xor i1 %t451, true
  br i1 %t453, label %bb84, label %bb85
bb84:
  call void @__olang_scope_close(ptr %s28)
  br label %bb89
bb85:
  br label %bb86
bb86:
  %t455 = load { i64, ptr }, ptr %l29, !tbaa !27
  store { i64, ptr } %t455, ptr %l191, !tbaa !27
  %t456 = load i64, ptr %l31, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr { i64, ptr }, ptr %t459, i64 %t456
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !37
  %t465 = extractvalue { i64, ptr } %t461, 1
  %t466 = extractvalue { i64, ptr } %t461, 0
  %t467 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t466)
  call void @olang_textcopy(ptr %t467, ptr %t465, i64 %t466)
  %t468 = insertvalue { i64, ptr } undef, i64 %t466, 0
  %t469 = insertvalue { i64, ptr } %t468, ptr %t467, 1
  %t471 = extractvalue { i64, ptr } %t469, 0
  %t472 = extractvalue { i64, ptr } %t469, 1
  %t473 = mul i64 %t471, 1
  %t474 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t473)
  call void @llvm.memcpy.p0.p0.i64(ptr %t474, ptr %t472, i64 %t473, i1 false)
  %t475 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t474, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t476)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s28)
  br label %bb88
bb88:
  %t479 = load i64, ptr %l31, !tbaa !24
  %t481 = add i64 %t479, 1
  store i64 %t481, ptr %l31, !tbaa !24
  br label %bb83
bb89:
  %t483 = load i64, ptr %l28, !tbaa !24
  %t484 = load i64, ptr %l30, !tbaa !24
  %t487 = add i64 %t483, %t484
  store i64 %t487, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s27)
  br label %bb90
bb90:
  br label %bb76
bb91:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d55, i32 0, i32 1) })
  br label %bb92
bb92:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d56, i32 0, i32 1) })
  br label %bb93
bb93:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d57, i32 0, i32 1) })
  br label %bb94
bb94:
  br i1 %a3, label %bb95, label %bb96
bb95:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d58, i32 0, i32 1) })
  br label %bb97
bb96:
  br label %bb98
bb97:
  br label %bb98
bb98:
  %t495 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t495, ptr %l208
  br label %bb99
bb99:
  %t496 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l208
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t496, ptr %l33
  store ptr %l6, ptr %l34, !tbaa !29
  store i64 0, ptr %l35, !tbaa !24
  br label %bb100
bb100:
  store %olang.scope zeroinitializer, ptr %s33
  %t498 = load ptr, ptr %l34, !tbaa !29
  %t499 = load i64, ptr %l35, !tbaa !24
  %t502 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t498, i64 %t499)
  %t503 = extractvalue { i32, { i64, ptr } } %t502, 1
  %t504 = extractvalue { i32, { i64, ptr } } %t502, 0
  store i32 %t504, ptr %l214
  %t505 = icmp ne i32 %t504, 0
  br i1 %t505, label %bb102, label %ok.506
ok.506:
  store { i64, ptr } %t503, ptr %l213
  br label %bb101
bb101:
  %t507 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t507, ptr %l210, !tbaa !27
  br label %bb106
bb102:
  %t508 = load i32, ptr %l214, !tbaa !23
  %t509 = ashr i32 %t508, 16
  %t511 = icmp eq i32 %t509, 1
  br i1 %t511, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  %t513 = load i32, ptr %l214, !tbaa !23
  %t514 = lshr i32 %t513, 16
  %t515 = and i32 %t513, 65535
  %t516 = icmp eq i32 %t514, 1
  %t517 = select i1 %t516, i32 0, i32 0
  %t518 = icmp eq i32 %t513, 0
  %t519 = shl i32 %t517, 16
  %t520 = or i32 %t519, %t515
  %t521 = select i1 %t518, i32 0, i32 %t520
  call void @__olang_scope_close(ptr %s33)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t521, ptr %rv
  br label %ret
bb105:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s33)
  br label %bb115
bb106:
  %t523 = load { i64, ptr }, ptr %l210, !tbaa !27
  store { i64, ptr } %t523, ptr %l36, !tbaa !27
  %t524 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t526 = extractvalue { i64, ptr } %t524, 0
  store i64 %t526, ptr %l37, !tbaa !24
  store i64 0, ptr %l38, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s34
  %t528 = load i64, ptr %l38, !tbaa !24
  %t529 = load i64, ptr %l37, !tbaa !24
  %t532 = icmp slt i64 %t528, %t529
  %t534 = xor i1 %t532, true
  br i1 %t534, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s34)
  br label %bb113
bb109:
  br label %bb110
bb110:
  %t536 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t536, ptr %l224, !tbaa !27
  %t537 = load i64, ptr %l38, !tbaa !24
  %t539 = getelementptr { i64, ptr }, ptr %l224, i32 0, i32 1
  %t540 = load ptr, ptr %t539, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %t540, i64 %t537
  %t542 = load { i64, ptr }, ptr %t541, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l33, { i64, ptr } %t542)
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s34)
  br label %bb112
bb112:
  %t547 = load i64, ptr %l38, !tbaa !24
  %t549 = add i64 %t547, 1
  store i64 %t549, ptr %l38, !tbaa !24
  br label %bb107
bb113:
  %t551 = load i64, ptr %l35, !tbaa !24
  %t552 = load i64, ptr %l37, !tbaa !24
  %t555 = add i64 %t551, %t552
  store i64 %t555, ptr %l35, !tbaa !24
  call void @__olang_scope_close(ptr %s33)
  br label %bb114
bb114:
  br label %bb100
bb115:
  store ptr %l33, ptr %l234, !tbaa !29
  %t557 = load ptr, ptr %l0, !tbaa !29
  %t559 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t557)
  store { i64, ptr } %t559, ptr %l236
  br label %bb116
bb116:
  %t560 = load ptr, ptr %l234, !tbaa !29
  %t561 = load { i64, ptr }, ptr %l236, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t560, { i64, ptr } %t561)
  br label %bb117
bb117:
  %t563 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l33)
  store { i64, ptr } %t563, ptr %l238
  br label %bb118
bb118:
  %t564 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t564, ptr %l40, !tbaa !27
  %t565 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t567 = extractvalue { i64, ptr } %t565, 1
  %t568 = extractvalue { i64, ptr } %t565, 0
  %t569 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t570 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t571 = add i64 %t568, %t570
  %t572 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t571)
  call void @olang_textcopy(ptr %t572, ptr %t567, i64 %t568)
  %t573 = getelementptr i8, ptr %t572, i64 %t568
  call void @olang_textcopy(ptr %t573, ptr %t569, i64 %t570)
  %t574 = insertvalue { i64, ptr } undef, i64 %t571, 0
  %t575 = insertvalue { i64, ptr } %t574, ptr %t572, 1
  store { i64, ptr } %t575, ptr %l41, !tbaa !27
  %t577 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t578 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t579 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t583 = call i1 @compiler_2fbuild_2elinkCurrent(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t577, { i64, ptr } %t578, { i64, ptr } %t579)
  store i1 %t583, ptr %l244
  br label %bb119
bb119:
  %t584 = load i1, ptr %l244, !tbaa !21
  br i1 %t584, label %bb120, label %bb121
bb120:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb121:
  br label %bb122
bb122:
  %t585 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t587 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t585)
  store i32 %t587, ptr %l246
  %t588 = icmp ne i32 %t587, 0
  br i1 %t588, label %bb124, label %ok.589
ok.589:
  br label %bb123
bb123:
  br label %bb128
bb124:
  %t590 = load i32, ptr %l246, !tbaa !23
  %t591 = ashr i32 %t590, 16
  %t593 = icmp eq i32 %t591, 1
  br i1 %t593, label %bb125, label %bb126
bb125:
  br label %bb127
bb126:
  %t595 = load i32, ptr %l246, !tbaa !23
  %t596 = lshr i32 %t595, 16
  %t597 = and i32 %t595, 65535
  %t598 = icmp eq i32 %t596, 1
  %t599 = select i1 %t598, i32 0, i32 0
  %t600 = icmp eq i32 %t595, 0
  %t601 = shl i32 %t599, 16
  %t602 = or i32 %t601, %t597
  %t603 = select i1 %t600, i32 0, i32 %t602
  call void @__olang_scope_close(ptr %s0)
  store i32 %t603, ptr %rv
  br label %ret
bb127:
  call void @__olang_ert_req_clear()
  br label %bb128
bb128:
  %t605 = load ptr, ptr %l0, !tbaa !29
  %t607 = getelementptr %"compiler/build:Config", ptr %t605, i32 0, i32 1
  %t608 = load { i64, ptr }, ptr %t607, !tbaa !27
  %t610 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t608, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store i1 %t610, ptr %l252
  br label %bb129
bb129:
  %t611 = load i1, ptr %l252, !tbaa !21
  br i1 %t611, label %bb130, label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb131:
  br label %bb132
bb132:
  %t614 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t614, ptr %l256
  br label %bb133
bb133:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d61, i32 0, i32 1) }, ptr %l257, !tbaa !27
  %t615 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t616 = load { i64, ptr }, ptr %l257, !tbaa !27
  %t617 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t615, { i64, ptr } %t616, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t618 = extractvalue { i32, %"std/os:Output" } %t617, 1
  %t619 = extractvalue { i32, %"std/os:Output" } %t617, 0
  store i32 %t619, ptr %l259
  %t620 = icmp ne i32 %t619, 0
  br i1 %t620, label %bb135, label %ok.621
ok.621:
  store %"std/os:Output" %t618, ptr %l258
  br label %bb134
bb134:
  %t622 = load %"std/os:Output", ptr %l258
  store %"std/os:Output" %t622, ptr %l254
  br label %bb139
bb135:
  %t623 = load i32, ptr %l259, !tbaa !23
  %t624 = ashr i32 %t623, 16
  %t626 = icmp eq i32 %t624, 1
  br i1 %t626, label %bb136, label %bb137
bb136:
  br label %bb138
bb137:
  %t628 = load i32, ptr %l259, !tbaa !23
  %t629 = lshr i32 %t628, 16
  %t630 = and i32 %t628, 65535
  %t631 = icmp eq i32 %t629, 1
  %t632 = select i1 %t631, i32 0, i32 0
  %t633 = icmp eq i32 %t628, 0
  %t634 = shl i32 %t632, 16
  %t635 = or i32 %t634, %t630
  %t636 = select i1 %t633, i32 0, i32 %t635
  call void @__olang_scope_close(ptr %s0)
  store i32 %t636, ptr %rv
  br label %ret
bb138:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb139:
  %t639 = load %"std/os:Output", ptr %l254
  store %"std/os:Output" %t639, ptr %l42
  %t640 = getelementptr %"std/os:Output", ptr %l42, i32 0, i32 0
  %t641 = load i32, ptr %t640, !tbaa !23
  %t643 = icmp ne i32 %t641, 0
  br i1 %t643, label %bb140, label %bb141
bb140:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb141:
  br label %bb142
bb142:
  %t646 = load ptr, ptr %l0, !tbaa !29
  store ptr %t646, ptr %l267, !tbaa !29
  %t647 = load ptr, ptr %l267, !tbaa !29
  %t648 = getelementptr %"compiler/build:Config", ptr %t647, i32 0, i32 18
  %t649 = load i64, ptr %t648, !tbaa !24
  %t651 = add i64 %t649, 1
  %t653 = load ptr, ptr %l267, !tbaa !29
  %t654 = getelementptr %"compiler/build:Config", ptr %t653, i32 0, i32 18
  store i64 %t651, ptr %t654, !tbaa !24
  %t655 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t657 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t655)
  %t658 = extractvalue { i32, %"std/os:FileInfo" } %t657, 1
  %t659 = extractvalue { i32, %"std/os:FileInfo" } %t657, 0
  store i32 %t659, ptr %l273
  %t660 = icmp ne i32 %t659, 0
  br i1 %t660, label %bb144, label %ok.661
ok.661:
  store %"std/os:FileInfo" %t658, ptr %l272
  br label %bb143
bb143:
  %t662 = load %"std/os:FileInfo", ptr %l272
  store %"std/os:FileInfo" %t662, ptr %l270
  br label %bb148
bb144:
  %t663 = load i32, ptr %l273, !tbaa !23
  %t664 = ashr i32 %t663, 16
  %t666 = icmp eq i32 %t664, 1
  br i1 %t666, label %bb145, label %bb146
bb145:
  br label %bb147
bb146:
  %t668 = load i32, ptr %l273, !tbaa !23
  %t669 = lshr i32 %t668, 16
  %t670 = and i32 %t668, 65535
  %t671 = icmp eq i32 %t669, 1
  %t672 = select i1 %t671, i32 0, i32 0
  %t673 = icmp eq i32 %t668, 0
  %t674 = shl i32 %t672, 16
  %t675 = or i32 %t674, %t670
  %t676 = select i1 %t673, i32 0, i32 %t675
  call void @__olang_scope_close(ptr %s0)
  store i32 %t676, ptr %rv
  br label %ret
bb147:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb148:
  %t678 = load %"std/os:FileInfo", ptr %l270
  store %"std/os:FileInfo" %t678, ptr %l43
  %t679 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t680 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t681 = getelementptr %"std/os:FileInfo", ptr %l43, i32 0, i32 1
  %t682 = load i64, ptr %t681, !tbaa !24
  %t683 = getelementptr %"std/os:FileInfo", ptr %l43, i32 0, i32 2
  %t684 = load i64, ptr %t683, !tbaa !24
  %t686 = extractvalue { i64, ptr } %t680, 1
  %t687 = extractvalue { i64, ptr } %t680, 0
  %t688 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t689 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t690 = add i64 %t687, %t689
  %t692 = call i64 @__olang_fmt_i64(ptr null, i64 %t682)
  %t693 = add i64 %t690, %t692
  %t694 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t695 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t696 = add i64 %t693, %t695
  %t698 = call i64 @__olang_fmt_i64(ptr null, i64 %t684)
  %t699 = add i64 %t696, %t698
  %t700 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t701 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t702 = add i64 %t699, %t701
  %t703 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t702)
  call void @olang_textcopy(ptr %t703, ptr %t686, i64 %t687)
  %t704 = getelementptr i8, ptr %t703, i64 %t687
  call void @olang_textcopy(ptr %t704, ptr %t688, i64 %t689)
  %t705 = getelementptr i8, ptr %t704, i64 %t689
  %t706 = call i64 @__olang_fmt_i64(ptr %t705, i64 %t682)
  %t707 = getelementptr i8, ptr %t705, i64 %t692
  call void @olang_textcopy(ptr %t707, ptr %t694, i64 %t695)
  %t708 = getelementptr i8, ptr %t707, i64 %t695
  %t709 = call i64 @__olang_fmt_i64(ptr %t708, i64 %t684)
  %t710 = getelementptr i8, ptr %t708, i64 %t698
  call void @olang_textcopy(ptr %t710, ptr %t700, i64 %t701)
  %t711 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t703, 1
  %t715 = extractvalue { i64, ptr } %t712, 0
  %t716 = extractvalue { i64, ptr } %t712, 1
  %t717 = mul i64 %t715, 1
  %t718 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t717)
  call void @llvm.memcpy.p0.p0.i64(ptr %t718, ptr %t716, i64 %t717, i1 false)
  %t719 = insertvalue { i64, ptr } undef, i64 %t715, 0
  %t720 = insertvalue { i64, ptr } %t719, ptr %t718, 1
  %t723 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t679, { i64, ptr } %t720)
  store i32 %t723, ptr %l284
  %t724 = icmp ne i32 %t723, 0
  br i1 %t724, label %bb150, label %ok.725
ok.725:
  br label %bb149
bb149:
  br label %bb154
bb150:
  %t726 = load i32, ptr %l284, !tbaa !23
  %t727 = ashr i32 %t726, 16
  %t729 = icmp eq i32 %t727, 1
  br i1 %t729, label %bb151, label %bb152
bb151:
  br label %bb153
bb152:
  %t731 = load i32, ptr %l284, !tbaa !23
  %t732 = lshr i32 %t731, 16
  %t733 = and i32 %t731, 65535
  %t734 = icmp eq i32 %t732, 1
  %t735 = select i1 %t734, i32 0, i32 0
  %t736 = icmp eq i32 %t731, 0
  %t737 = shl i32 %t735, 16
  %t738 = or i32 %t737, %t733
  %t739 = select i1 %t736, i32 0, i32 %t738
  call void @__olang_scope_close(ptr %s0)
  store i32 %t739, ptr %rv
  br label %ret
bb153:
  call void @__olang_ert_req_clear()
  br label %bb154
bb154:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l21 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 2
  %t8 = getelementptr %"compiler/target:Target", ptr %t7, i32 0, i32 9
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %lp1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 2
  %t15 = getelementptr %"compiler/target:Target", ptr %t14, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t20, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t11, { i64, ptr } %t33)
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t36 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s1)
  store { i64, ptr } %t36, ptr %l11
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d65, i32 0, i32 1) })
  store i1 %t40, ptr %l13
  br label %bb6
bb6:
  %t41 = load i1, ptr %l13, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %lp1
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t49 = extractvalue { i64, ptr } %t45, 1
  %t50 = extractvalue { i64, ptr } %t45, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t44, { i64, ptr } %t62)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 2
  %t68 = getelementptr %"compiler/target:Target", ptr %t67, i32 0, i32 6
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d67, i32 0, i32 1) })
  store i1 %t71, ptr %l21
  br label %bb12
bb12:
  %t72 = load i1, ptr %l21, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %lp1
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/build:Config", ptr %t76, i32 0, i32 2
  %t79 = getelementptr %"compiler/target:Target", ptr %t78, i32 0, i32 6
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t75, { i64, ptr } %t93)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 9
  %t99 = load i1, ptr %t98, !tbaa !21
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t101 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t101, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d68, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/build:Config", ptr %t103, i32 0, i32 4
  %t106 = load i1, ptr %t105, !tbaa !21
  br i1 %t106, label %bb21, label %bb22
bb21:
  %t108 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t108, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb23
bb22:
  br label %bb29
bb23:
  %t110 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t110, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb24
bb24:
  %t112 = load ptr, ptr %l0, !tbaa !29
  %t114 = getelementptr %"compiler/build:Config", ptr %t112, i32 0, i32 6
  %t115 = load i1, ptr %t114, !tbaa !21
  br i1 %t115, label %bb25, label %bb26
bb25:
  %t117 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t117, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb27
bb26:
  br label %bb28
bb27:
  br label %bb28
bb28:
  %t119 = load ptr, ptr %lp1
  %t120 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t119
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t120, ptr %rv
  br label %ret
bb29:
  %t122 = load ptr, ptr %l0, !tbaa !29
  %t124 = getelementptr %"compiler/build:Config", ptr %t122, i32 0, i32 6
  %t125 = load i1, ptr %t124, !tbaa !21
  br i1 %t125, label %bb30, label %bb31
bb30:
  %t127 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t127, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb34
bb32:
  %t129 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t129, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb33
bb33:
  %t131 = load ptr, ptr %lp1
  %t132 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t131
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t132, ptr %rv
  br label %ret
bb34:
  %t134 = load ptr, ptr %l0, !tbaa !29
  %t136 = getelementptr %"compiler/build:Config", ptr %t134, i32 0, i32 5
  %t137 = load i1, ptr %t136, !tbaa !21
  br i1 %t137, label %bb35, label %bb36
bb35:
  %t139 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t139, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d74, i32 0, i32 1) })
  br label %bb37
bb36:
  br label %bb38
bb37:
  %t141 = load ptr, ptr %lp1
  %t142 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t141
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t142, ptr %rv
  br label %ret
bb38:
  %t144 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t144, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb39
bb39:
  %t146 = load ptr, ptr %l0, !tbaa !29
  %t148 = getelementptr %"compiler/build:Config", ptr %t146, i32 0, i32 19
  %t149 = load i1, ptr %t148, !tbaa !21
  br i1 %t149, label %bb40, label %bb41
bb40:
  %t151 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t151, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d76, i32 0, i32 1) })
  br label %bb42
bb41:
  %t153 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t153, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d77, i32 0, i32 1) })
  br label %bb43
bb42:
  br label %bb44
bb43:
  br label %bb44
bb44:
  %t155 = load ptr, ptr %lp1
  %t156 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t155
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t156, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v2, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  store ptr %a4, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t8 = load ptr, ptr %l6, !tbaa !29
  %t9 = load i64, ptr %l7, !tbaa !24
  %t12 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t8, i64 %t9)
  %t13 = extractvalue { i32, { i64, ptr } } %t12, 1
  %t14 = extractvalue { i32, { i64, ptr } } %t12, 0
  store i32 %t14, ptr %l21
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16
ok.16:
  store { i64, ptr } %t13, ptr %l20
  br label %bb4
bb4:
  %t17 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t17, ptr %l17, !tbaa !27
  br label %bb9
bb5:
  %t18 = load i32, ptr %l21, !tbaa !23
  %t19 = ashr i32 %t18, 16
  %t21 = icmp eq i32 %t19, 1
  br i1 %t21, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_bfc49e763ae34426_1cf738faff557a0a)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb9:
  %t23 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t23, ptr %l8, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  store i64 %t26, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t28 = load i64, ptr %l10, !tbaa !24
  %t29 = load i64, ptr %l9, !tbaa !24
  %t32 = icmp slt i64 %t28, %t29
  %t34 = xor i1 %t32, true
  br i1 %t34, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t36 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t36, ptr %l30, !tbaa !27
  %t37 = load i64, ptr %l10, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr { i64, ptr }, ptr %t40, i64 %t37
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %t42)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t47 = load i64, ptr %l10, !tbaa !24
  %t49 = add i64 %t47, 1
  store i64 %t49, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  %t51 = load i64, ptr %l7, !tbaa !24
  %t52 = load i64, ptr %l9, !tbaa !24
  %t55 = add i64 %t51, %t52
  store i64 %t55, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb3
bb18:
  store ptr %l5, ptr %l40, !tbaa !29
  %t57 = load ptr, ptr %l0, !tbaa !29
  %t59 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t57)
  store { i64, ptr } %t59, ptr %l42
  br label %bb19
bb19:
  %t60 = load ptr, ptr %l40, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t60, { i64, ptr } %t61)
  br label %bb20
bb20:
  %t63 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t63, ptr %l44
  br label %bb21
bb21:
  %t64 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t64, ptr %l12, !tbaa !27
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 0
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !27
  store { i64, ptr } %t68, ptr %l46, !tbaa !27
  store { i64, ptr } %a1, ptr %l47, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l48, !tbaa !24
  %t72 = icmp sge i64 0, 0
  br i1 %t72, label %bb22, label %bb23
bb22:
  %t74 = icmp sle i64 0, 16
  br i1 %t74, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_9440ba48b5f00e48_8accfe015a3e4c7c)
  unreachable
bb24:
  %t76 = load i64, ptr %l48, !tbaa !24
  %t77 = icmp sle i64 16, %t76
  br i1 %t77, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @olang_loc_9440ba48b5f00e48_8accfe015a3e4c7c)
  unreachable
bb26:
  %t79 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 0
  %t82 = sub i64 16, 0
  %t83 = insertvalue { i64, ptr } undef, i64 %t82, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t81, 1
  store { i64, ptr } %t84, ptr %l52, !tbaa !27
  %t87 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %a2)
  store { i64, ptr } %t87, ptr %l54
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @olang_loc_9440ba48b5f00e48_8accfe015a3e4c7c)
  unreachable
bb28:
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t88)
  store { i64, ptr } %t90, ptr %l56
  br label %bb29
bb29:
  %t91 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t95 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t96 = add i64 %t93, %t95
  %t97 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 1
  %t99 = extractvalue { i64, ptr } %t97, 0
  %t100 = add i64 %t96, %t99
  %t101 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t102 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t103 = add i64 %t100, %t102
  %t104 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 1
  %t106 = extractvalue { i64, ptr } %t104, 0
  %t107 = add i64 %t103, %t106
  %t108 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = add i64 %t107, %t110
  %t112 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t112, 1
  %t114 = extractvalue { i64, ptr } %t112, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t117 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t92, i64 %t93)
  %t120 = getelementptr i8, ptr %t119, i64 %t93
  call void @olang_textcopy(ptr %t120, ptr %t94, i64 %t95)
  %t121 = getelementptr i8, ptr %t120, i64 %t95
  call void @olang_textcopy(ptr %t121, ptr %t98, i64 %t99)
  %t122 = getelementptr i8, ptr %t121, i64 %t99
  call void @olang_textcopy(ptr %t122, ptr %t101, i64 %t102)
  %t123 = getelementptr i8, ptr %t122, i64 %t102
  call void @olang_textcopy(ptr %t123, ptr %t105, i64 %t106)
  %t124 = getelementptr i8, ptr %t123, i64 %t106
  call void @olang_textcopy(ptr %t124, ptr %t109, i64 %t110)
  %t125 = getelementptr i8, ptr %t124, i64 %t110
  call void @olang_textcopy(ptr %t125, ptr %t113, i64 %t114)
  %t126 = getelementptr i8, ptr %t125, i64 %t114
  call void @olang_textcopy(ptr %t126, ptr %t116, i64 %t117)
  %t127 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t119, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t128, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/build:Unit"
  %l10 = alloca %"compiler/build:compiles"
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca %"compiler/build:Unit"
  %l20 = alloca i64
  %l21 = alloca %"compiler/build:compiles"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca %"compiler/build:Unit"
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l46 = alloca { i64, ptr }
  %l58 = alloca ptr
  %l62 = alloca i1
  %l66 = alloca i1
  %l70 = alloca i1
  %l74 = alloca %"compiler/build:compiles"
  %l75 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca i32
  %l93 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l101 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l121 = alloca i64
  %l124 = alloca i1
  %l126 = alloca ptr
  %l127 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l136 = alloca i32
  %l141 = alloca i1
  %l143 = alloca ptr
  %l144 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i32
  %l160 = alloca i32
  %l163 = alloca i64
  %l165 = alloca %"compiler/build:compiles"
  %l167 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l171 = alloca i32
  %l181 = alloca { i64, ptr }
  %l188 = alloca i1
  %l191 = alloca i1
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l199 = alloca { i64, ptr }
  %l201 = alloca i1
  %l203 = alloca i1
  %l207 = alloca i1
  %l209 = alloca i32
  %l211 = alloca i1
  %l218 = alloca %"compiler/build:Unit"
  %l219 = alloca { i64, ptr }
  %l220 = alloca ptr
  %l221 = alloca ptr
  %l223 = alloca { i64, ptr }
  %l229 = alloca { i64, ptr }
  %l230 = alloca i32
  %l235 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l243 = alloca i32
  %l245 = alloca { i64, ptr }
  %l252 = alloca { i64, ptr }
  %l253 = alloca i32
  %l263 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l36
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l35
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t14, ptr %l32, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l36, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load i32, ptr %l36, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 0, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t30 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t28, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t30, ptr %rv
  br label %ret
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb7:
  %t31 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l46, !tbaa !27
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l46, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/build:Unit", ptr %t48, i64 %t45
  %t50 = load %"compiler/build:Unit", ptr %t49
  store %"compiler/build:Unit" %t50, ptr %l9
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = getelementptr %"compiler/build:Unit", ptr %l9, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = add i64 %t52, %t56
  store i64 %t59, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l8, !tbaa !24
  br label %bb8
bb13:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t65, %t66
  store i64 %t69, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb1
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l58, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t72, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t79, i32 0, i32 6
  %t82 = load i1, ptr %t81, !tbaa !21
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l62, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l62, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 5
  %t90 = load i1, ptr %t89, !tbaa !21
  %t92 = xor i1 %t90, true
  store i1 %t92, ptr %l66, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l66, !tbaa !21
  br label %bb21
bb21:
  %t94 = load i1, ptr %l66, !tbaa !21
  br i1 %t94, label %bb22, label %bb23
bb22:
  %t95 = load i64, ptr %l3, !tbaa !24
  %t96 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t99 = icmp sge i64 %t95, %t96
  store i1 %t99, ptr %l70, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l70, !tbaa !21
  br label %bb24
bb24:
  %t101 = load i1, ptr %l70, !tbaa !21
  %t102 = load ptr, ptr %l58, !tbaa !29
  %t103 = getelementptr %"compiler/build:Config", ptr %t102, i32 0, i32 19
  store i1 %t101, ptr %t103, !tbaa !21
  %t104 = call %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %s0)
  store %"compiler/build:compiles" %t104, ptr %l74
  br label %bb25
bb25:
  %t105 = load %"compiler/build:compiles", ptr %l74
  store %"compiler/build:compiles" %t105, ptr %l10
  %t106 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v3)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t106, ptr %l75
  br label %bb26
bb26:
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t107, ptr %lp11
  %t108 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l75
  %t109 = load ptr, ptr %lp11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t108, ptr %t109
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t112 = getelementptr %"compiler/build:Program", ptr %t110, i32 0, i32 0
  store ptr %t112, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  store i64 0, ptr %l14, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s6
  %t114 = load ptr, ptr %l12, !tbaa !29
  %t115 = load i64, ptr %l13, !tbaa !24
  %t118 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t114, i64 %t115)
  %t119 = extractvalue { i32, { i64, ptr } } %t118, 1
  %t120 = extractvalue { i32, { i64, ptr } } %t118, 0
  store i32 %t120, ptr %l82
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb29, label %ok.122
ok.122:
  store { i64, ptr } %t119, ptr %l81
  br label %bb28
bb28:
  %t123 = load { i64, ptr }, ptr %l81, !tbaa !27
  store { i64, ptr } %t123, ptr %l78, !tbaa !27
  br label %bb33
bb29:
  %t124 = load i32, ptr %l82, !tbaa !23
  %t125 = ashr i32 %t124, 16
  %t127 = icmp eq i32 %t125, 1
  br i1 %t127, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  %t129 = load i32, ptr %l82, !tbaa !23
  %t130 = lshr i32 %t129, 16
  %t131 = and i32 %t129, 65535
  %t132 = icmp eq i32 %t130, 1
  %t133 = select i1 %t132, i32 0, i32 0
  %t134 = icmp eq i32 %t129, 0
  %t135 = shl i32 %t133, 16
  %t136 = or i32 %t135, %t131
  %t137 = select i1 %t134, i32 0, i32 %t136
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t139 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t137, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t139, ptr %rv
  br label %ret
bb32:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s6)
  br label %bb46
bb33:
  %t140 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t140, ptr %l15, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t141, 0
  store i64 %t143, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t145 = load i64, ptr %l17, !tbaa !24
  %t146 = load i64, ptr %l16, !tbaa !24
  %t149 = icmp slt i64 %t145, %t146
  %t151 = xor i1 %t149, true
  br i1 %t151, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb36:
  br label %bb37
bb37:
  %t153 = load i64, ptr %l14, !tbaa !24
  store i64 %t153, ptr %l18, !tbaa !24
  %t155 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t155, ptr %l93, !tbaa !27
  %t156 = load i64, ptr %l17, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l93, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr %"compiler/build:Unit", ptr %t159, i64 %t156
  %t161 = load %"compiler/build:Unit", ptr %t160
  store %"compiler/build:Unit" %t161, ptr %l19
  %t163 = load ptr, ptr %lp11
  store ptr %t163, ptr %l96, !tbaa !29
  %t164 = load ptr, ptr %l0, !tbaa !29
  store ptr %t164, ptr %l98, !tbaa !29
  store ptr %l10, ptr %l99, !tbaa !29
  %t165 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 0
  %t166 = load { i64, ptr }, ptr %t165, !tbaa !27
  %t168 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %v3, { i64, ptr } %t166)
  store { i64, ptr } %t168, ptr %l101
  br label %bb38
bb38:
  %t169 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 0
  %t171 = extractvalue { i64, ptr } %t169, 1
  %t172 = mul i64 %t170, 1
  %t173 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t172)
  call void @llvm.memcpy.p0.p0.i64(ptr %t173, ptr %t171, i64 %t172, i1 false)
  %t174 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  %t176 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 1
  %t177 = load i32, ptr %t176
  %t178 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 2
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t180 = load ptr, ptr %l2, !tbaa !29
  %t181 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 3
  %t182 = load { i64, ptr }, ptr %t181, !tbaa !27
  %t183 = load i64, ptr %l18, !tbaa !24
  %t184 = load ptr, ptr %l98, !tbaa !29
  %t185 = load ptr, ptr %l99, !tbaa !29
  %t192 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v1, ptr %v3, ptr %t184, ptr %t185, { i64, ptr } %t175, i32 %t177, { i64, ptr } %t179, ptr %t180, { i64, ptr } %t182, i64 %t183)
  %t193 = extractvalue { i32, { i64, ptr } } %t192, 1
  %t194 = extractvalue { i32, { i64, ptr } } %t192, 0
  store i32 %t194, ptr %l109
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb40, label %ok.196
ok.196:
  store { i64, ptr } %t193, ptr %l108
  br label %bb39
bb39:
  %t197 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t197, ptr %l97, !tbaa !27
  br label %bb41
bb40:
  %t198 = load i32, ptr %l109, !tbaa !23
  %t199 = lshr i32 %t198, 16
  %t200 = and i32 %t198, 65535
  %t201 = icmp eq i32 %t199, 1
  %t202 = select i1 %t201, i32 1, i32 0
  %t203 = icmp eq i32 %t198, 0
  %t204 = shl i32 %t202, 16
  %t205 = or i32 %t204, %t200
  %t206 = select i1 %t203, i32 0, i32 %t205
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t208 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t206, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t208, ptr %rv
  br label %ret
bb41:
  %t209 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t216 = load ptr, ptr %l96, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t216, { i64, ptr } %t215)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s7)
  br label %bb43
bb43:
  %t218 = load i64, ptr %l17, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l17, !tbaa !24
  %t222 = load i64, ptr %l14, !tbaa !24
  %t224 = add i64 %t222, 1
  store i64 %t224, ptr %l14, !tbaa !24
  br label %bb34
bb44:
  %t226 = load i64, ptr %l13, !tbaa !24
  %t227 = load i64, ptr %l16, !tbaa !24
  %t230 = add i64 %t226, %t227
  store i64 %t230, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb45
bb45:
  br label %bb27
bb46:
  %t232 = load ptr, ptr %l1, !tbaa !29
  %t234 = getelementptr %"compiler/build:Program", ptr %t232, i32 0, i32 0
  %t236 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t234)
  store i64 %t236, ptr %l121
  br label %bb47
bb47:
  %t237 = load i64, ptr %l121, !tbaa !24
  store i64 %t237, ptr %l20, !tbaa !24
  %t238 = load ptr, ptr %l1, !tbaa !29
  %t240 = getelementptr %"compiler/build:Program", ptr %t238, i32 0, i32 1
  %t241 = load { i64, ptr }, ptr %t240, !tbaa !27
  %t243 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t241, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t243, ptr %l124
  br label %bb48
bb48:
  %t244 = load i1, ptr %l124, !tbaa !21
  %t245 = xor i1 %t244, true
  br i1 %t245, label %bb49, label %bb50
bb49:
  %t247 = load ptr, ptr %lp11
  store ptr %t247, ptr %l126, !tbaa !29
  %t248 = load ptr, ptr %l0, !tbaa !29
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t251 = getelementptr %"compiler/build:Program", ptr %t249, i32 0, i32 1
  %t252 = load { i64, ptr }, ptr %t251, !tbaa !27
  %t253 = load ptr, ptr %l2, !tbaa !29
  %t254 = load i64, ptr %l20, !tbaa !24
  %t261 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t248, ptr %l10, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d82, i32 0, i32 1) }, i32 0, { i64, ptr } %t252, ptr %t253, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) }, i64 %t254)
  %t262 = extractvalue { i32, { i64, ptr } } %t261, 1
  %t263 = extractvalue { i32, { i64, ptr } } %t261, 0
  store i32 %t263, ptr %l136
  %t264 = icmp ne i32 %t263, 0
  br i1 %t264, label %bb52, label %ok.265
ok.265:
  store { i64, ptr } %t262, ptr %l135
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t266 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t266, ptr %l127, !tbaa !27
  br label %bb53
bb52:
  %t267 = load i32, ptr %l136, !tbaa !23
  %t268 = lshr i32 %t267, 16
  %t269 = and i32 %t267, 65535
  %t270 = icmp eq i32 %t268, 1
  %t271 = select i1 %t270, i32 1, i32 0
  %t272 = icmp eq i32 %t267, 0
  %t273 = shl i32 %t271, 16
  %t274 = or i32 %t273, %t269
  %t275 = select i1 %t272, i32 0, i32 %t274
  call void @__olang_scope_close(ptr %s0)
  %t277 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t275, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t277, ptr %rv
  br label %ret
bb53:
  %t278 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load ptr, ptr %l126, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t285, { i64, ptr } %t284)
  br label %bb54
bb54:
  br label %bb55
bb55:
  %t287 = load ptr, ptr %l1, !tbaa !29
  %t289 = getelementptr %"compiler/build:Program", ptr %t287, i32 0, i32 2
  %t290 = load { i64, ptr }, ptr %t289, !tbaa !27
  %t292 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t290, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d84, i32 0, i32 1) })
  store i1 %t292, ptr %l141
  br label %bb56
bb56:
  %t293 = load i1, ptr %l141, !tbaa !21
  %t294 = xor i1 %t293, true
  br i1 %t294, label %bb57, label %bb58
bb57:
  %t296 = load ptr, ptr %lp11
  store ptr %t296, ptr %l143, !tbaa !29
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t298 = load ptr, ptr %l1, !tbaa !29
  %t300 = getelementptr %"compiler/build:Program", ptr %t298, i32 0, i32 2
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  %t302 = load ptr, ptr %l2, !tbaa !29
  %t303 = load i64, ptr %l20, !tbaa !24
  %t305 = add i64 %t303, 1
  %t312 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t297, ptr %l10, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d85, i32 0, i32 1) }, i32 0, { i64, ptr } %t301, ptr %t302, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d86, i32 0, i32 1) }, i64 %t305)
  %t313 = extractvalue { i32, { i64, ptr } } %t312, 1
  %t314 = extractvalue { i32, { i64, ptr } } %t312, 0
  store i32 %t314, ptr %l154
  %t315 = icmp ne i32 %t314, 0
  br i1 %t315, label %bb60, label %ok.316
ok.316:
  store { i64, ptr } %t313, ptr %l153
  br label %bb59
bb58:
  br label %bb63
bb59:
  %t317 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t317, ptr %l144, !tbaa !27
  br label %bb61
bb60:
  %t318 = load i32, ptr %l154, !tbaa !23
  %t319 = lshr i32 %t318, 16
  %t320 = and i32 %t318, 65535
  %t321 = icmp eq i32 %t319, 1
  %t322 = select i1 %t321, i32 1, i32 0
  %t323 = icmp eq i32 %t318, 0
  %t324 = shl i32 %t322, 16
  %t325 = or i32 %t324, %t320
  %t326 = select i1 %t323, i32 0, i32 %t325
  call void @__olang_scope_close(ptr %s0)
  %t328 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t326, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t328, ptr %rv
  br label %ret
bb61:
  %t329 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t330 = extractvalue { i64, ptr } %t329, 0
  %t331 = extractvalue { i64, ptr } %t329, 1
  %t332 = mul i64 %t330, 1
  %t333 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t331, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t330, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t336 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t336, { i64, ptr } %t335)
  br label %bb62
bb62:
  br label %bb63
bb63:
  %t338 = load ptr, ptr %l0, !tbaa !29
  %t339 = load ptr, ptr %l2, !tbaa !29
  %t343 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %s0, ptr %v2, ptr %t338, ptr %l10, ptr %t339)
  store i32 %t343, ptr %l160
  %t344 = icmp ne i32 %t343, 0
  br i1 %t344, label %bb65, label %ok.345
ok.345:
  br label %bb64
bb64:
  br label %bb66
bb65:
  %t346 = load i32, ptr %l160, !tbaa !23
  %t347 = lshr i32 %t346, 16
  %t348 = and i32 %t346, 65535
  %t349 = icmp eq i32 %t347, 1
  %t350 = select i1 %t349, i32 1, i32 0
  %t351 = icmp eq i32 %t346, 0
  %t352 = shl i32 %t350, 16
  %t353 = or i32 %t352, %t348
  %t354 = select i1 %t351, i32 0, i32 %t353
  call void @__olang_scope_close(ptr %s0)
  %t356 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t354, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t356, ptr %rv
  br label %ret
bb66:
  %t357 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 7
  %t359 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t357)
  store i64 %t359, ptr %l163
  br label %bb67
bb67:
  %t360 = load i64, ptr %l163, !tbaa !24
  %t361 = icmp sgt i64 %t360, 0
  br i1 %t361, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s11
  %t363 = call %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %s11)
  store %"compiler/build:compiles" %t363, ptr %l165
  br label %bb70
bb69:
  br label %bb131
bb70:
  %t364 = load %"compiler/build:compiles", ptr %l165
  store %"compiler/build:compiles" %t364, ptr %l21
  %t365 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 7
  store ptr %t365, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t367 = load ptr, ptr %l22, !tbaa !29
  %t368 = load i64, ptr %l23, !tbaa !24
  %t371 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t367, i64 %t368)
  %t372 = extractvalue { i32, { i64, ptr } } %t371, 1
  %t373 = extractvalue { i32, { i64, ptr } } %t371, 0
  store i32 %t373, ptr %l171
  %t374 = icmp ne i32 %t373, 0
  br i1 %t374, label %bb73, label %ok.375
ok.375:
  store { i64, ptr } %t372, ptr %l170
  br label %bb72
bb72:
  %t376 = load { i64, ptr }, ptr %l170, !tbaa !27
  store { i64, ptr } %t376, ptr %l167, !tbaa !27
  br label %bb77
bb73:
  %t377 = load i32, ptr %l171, !tbaa !23
  %t378 = ashr i32 %t377, 16
  %t380 = icmp eq i32 %t378, 1
  br i1 %t380, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  %t382 = load i32, ptr %l171, !tbaa !23
  %t383 = lshr i32 %t382, 16
  %t384 = and i32 %t382, 65535
  %t385 = icmp eq i32 %t383, 1
  %t386 = select i1 %t385, i32 0, i32 0
  %t387 = icmp eq i32 %t382, 0
  %t388 = shl i32 %t386, 16
  %t389 = or i32 %t388, %t384
  %t390 = select i1 %t387, i32 0, i32 %t389
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t392 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t390, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t392, ptr %rv
  br label %ret
bb76:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s13)
  br label %bb127
bb77:
  %t393 = load { i64, ptr }, ptr %l167, !tbaa !27
  store { i64, ptr } %t393, ptr %l24, !tbaa !27
  %t394 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t394, 0
  store i64 %t396, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t398 = load i64, ptr %l26, !tbaa !24
  %t399 = load i64, ptr %l25, !tbaa !24
  %t402 = icmp slt i64 %t398, %t399
  %t404 = xor i1 %t402, true
  br i1 %t404, label %bb79, label %bb80
bb79:
  call void @__olang_scope_close(ptr %s14)
  br label %bb125
bb80:
  br label %bb81
bb81:
  %t406 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t406, ptr %l181, !tbaa !27
  %t407 = load i64, ptr %l26, !tbaa !24
  %t409 = getelementptr { i64, ptr }, ptr %l181, i32 0, i32 1
  %t410 = load ptr, ptr %t409, !tbaa !27
  %t411 = getelementptr i64, ptr %t410, i64 %t407
  %t412 = load i64, ptr %t411, !tbaa !34
  store i64 %t412, ptr %l27, !tbaa !24
  %t414 = load i64, ptr %l27, !tbaa !24
  %t415 = load i64, ptr %l20, !tbaa !24
  %t417 = add i64 %t415, 1
  %t420 = icmp slt i64 %t414, %t417
  br i1 %t420, label %bb82, label %bb83
bb82:
  store i1 true, ptr %l188, !tbaa !21
  br label %bb85
bb83:
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t424 = getelementptr %"compiler/build:Program", ptr %t422, i32 0, i32 1
  %t425 = load { i64, ptr }, ptr %t424, !tbaa !27
  %t427 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s14, { i64, ptr } %t425, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d87, i32 0, i32 1) })
  store i1 %t427, ptr %l191
  br label %bb84
bb84:
  %t428 = load i1, ptr %l191, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l188, !tbaa !21
  br label %bb85
bb85:
  %t431 = load i1, ptr %l188, !tbaa !21
  br i1 %t431, label %bb86, label %bb87
bb86:
  %t432 = load ptr, ptr %lp11
  %t433 = load i64, ptr %l27, !tbaa !24
  %t436 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v3, ptr %s14, ptr %t432, i64 %t433)
  store { i64, ptr } %t436, ptr %l196
  br label %bb88
bb87:
  %t437 = load ptr, ptr %lp11
  %t438 = load i64, ptr %l20, !tbaa !24
  %t441 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v3, ptr %s14, ptr %t437, i64 %t438)
  store { i64, ptr } %t441, ptr %l199
  br label %bb89
bb88:
  %t442 = load { i64, ptr }, ptr %l196, !tbaa !27
  store { i64, ptr } %t442, ptr %l193, !tbaa !27
  br label %bb90
bb89:
  %t443 = load { i64, ptr }, ptr %l199, !tbaa !27
  store { i64, ptr } %t443, ptr %l193, !tbaa !27
  br label %bb90
bb90:
  %t444 = load { i64, ptr }, ptr %l193, !tbaa !27
  store { i64, ptr } %t444, ptr %l28, !tbaa !27
  br label %bb91
bb91:
  store %olang.scope zeroinitializer, ptr %s15
  %t445 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t447 = call i1 @std_2fos_2eExists(ptr %s14, { i64, ptr } %t445)
  store i1 %t447, ptr %l201
  br label %bb92
bb92:
  %t448 = load i1, ptr %l201, !tbaa !21
  %t449 = xor i1 %t448, true
  br i1 %t449, label %bb93, label %bb94
bb93:
  %t451 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t453 = extractvalue { i64, ptr } %t451, 1
  %t454 = extractvalue { i64, ptr } %t451, 0
  %t455 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d88, i32 0, i32 1) }, 1
  %t456 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d88, i32 0, i32 1) }, 0
  %t457 = add i64 %t454, %t456
  %t458 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t457)
  call void @olang_textcopy(ptr %t458, ptr %t453, i64 %t454)
  %t459 = getelementptr i8, ptr %t458, i64 %t454
  call void @olang_textcopy(ptr %t459, ptr %t455, i64 %t456)
  %t460 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t461 = insertvalue { i64, ptr } %t460, ptr %t458, 1
  %t463 = extractvalue { i64, ptr } %t461, 0
  %t464 = extractvalue { i64, ptr } %t461, 1
  %t465 = mul i64 %t463, 1
  %t466 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t465)
  call void @llvm.memcpy.p0.p0.i64(ptr %t466, ptr %t464, i64 %t465, i1 false)
  %t467 = insertvalue { i64, ptr } undef, i64 %t463, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t466, 1
  %t470 = call i1 @compiler_2fbuild_2eholderAlive(ptr %s15, { i64, ptr } %t468)
  store i1 %t470, ptr %l207
  br label %bb95
bb94:
  store i1 false, ptr %l203, !tbaa !21
  br label %bb96
bb95:
  %t471 = load i1, ptr %l207, !tbaa !21
  store i1 %t471, ptr %l203, !tbaa !21
  br label %bb96
bb96:
  %t472 = load i1, ptr %l203, !tbaa !21
  %t473 = xor i1 %t472, true
  br i1 %t473, label %bb97, label %bb98
bb97:
  call void @__olang_scope_close(ptr %s15)
  br label %bb102
bb98:
  br label %bb99
bb99:
  %t475 = call i32 @usleep(i32 20000)
  store i32 %t475, ptr %l209
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s15)
  br label %bb101
bb101:
  br label %bb91
bb102:
  %t476 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t478 = call i1 @std_2fos_2eExists(ptr %s14, { i64, ptr } %t476)
  store i1 %t478, ptr %l211
  br label %bb103
bb103:
  %t479 = load i1, ptr %l211, !tbaa !21
  br i1 %t479, label %bb104, label %bb105
bb104:
  call void @__olang_scope_close(ptr %s14)
  br label %bb124
bb105:
  br label %bb106
bb106:
  %t480 = load i64, ptr %l27, !tbaa !24
  %t481 = load i64, ptr %l20, !tbaa !24
  %t484 = icmp slt i64 %t480, %t481
  br i1 %t484, label %bb107, label %bb108
bb107:
  store %olang.scope zeroinitializer, ptr %s18
  %t486 = load ptr, ptr %l1, !tbaa !29
  %t488 = getelementptr %"compiler/build:Program", ptr %t486, i32 0, i32 0
  %t489 = load i64, ptr %l27, !tbaa !24
  %t492 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t488, i64 %t489)
  store %"compiler/build:Unit" %t492, ptr %l218
  br label %bb109
bb108:
  %t493 = load i64, ptr %l27, !tbaa !24
  %t494 = load i64, ptr %l20, !tbaa !24
  %t497 = icmp eq i64 %t493, %t494
  br i1 %t497, label %bb114, label %bb115
bb109:
  %t499 = load %"compiler/build:Unit", ptr %l218
  store %"compiler/build:Unit" %t499, ptr %l29
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l220, !tbaa !29
  store ptr %l21, ptr %l221, !tbaa !29
  %t501 = getelementptr %"compiler/build:Unit", ptr %l29, i32 0, i32 0
  %t502 = load { i64, ptr }, ptr %t501, !tbaa !27
  %t504 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s18, { i64, ptr } %t502)
  store { i64, ptr } %t504, ptr %l223
  br label %bb110
bb110:
  %t505 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t505, 0
  %t507 = extractvalue { i64, ptr } %t505, 1
  %t508 = mul i64 %t506, 1
  %t509 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t508)
  call void @llvm.memcpy.p0.p0.i64(ptr %t509, ptr %t507, i64 %t508, i1 false)
  %t510 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  %t512 = getelementptr %"compiler/build:Unit", ptr %l29, i32 0, i32 1
  %t513 = load i32, ptr %t512
  %t514 = getelementptr %"compiler/build:Unit", ptr %l29, i32 0, i32 2
  %t515 = load { i64, ptr }, ptr %t514, !tbaa !27
  %t516 = load ptr, ptr %l2, !tbaa !29
  %t517 = getelementptr %"compiler/build:Unit", ptr %l29, i32 0, i32 3
  %t518 = load { i64, ptr }, ptr %t517, !tbaa !27
  %t519 = load ptr, ptr %l220, !tbaa !29
  %t520 = load ptr, ptr %l221, !tbaa !29
  %t526 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s11, ptr %s18, ptr %v1, ptr %v2, ptr %v1, ptr %s18, ptr %t519, ptr %t520, { i64, ptr } %t511, i32 %t513, { i64, ptr } %t515, ptr %t516, { i64, ptr } %t518, i64 -1)
  %t527 = extractvalue { i32, { i64, ptr } } %t526, 1
  %t528 = extractvalue { i32, { i64, ptr } } %t526, 0
  store i32 %t528, ptr %l230
  %t529 = icmp ne i32 %t528, 0
  br i1 %t529, label %bb112, label %ok.530
ok.530:
  store { i64, ptr } %t527, ptr %l229
  br label %bb111
bb111:
  %t531 = load { i64, ptr }, ptr %l229, !tbaa !27
  store { i64, ptr } %t531, ptr %l219, !tbaa !27
  br label %bb113
bb112:
  %t532 = load i32, ptr %l230, !tbaa !23
  %t533 = lshr i32 %t532, 16
  %t534 = and i32 %t532, 65535
  %t535 = icmp eq i32 %t533, 1
  %t536 = select i1 %t535, i32 1, i32 0
  %t537 = icmp eq i32 %t532, 0
  %t538 = shl i32 %t536, 16
  %t539 = or i32 %t538, %t534
  %t540 = select i1 %t537, i32 0, i32 %t539
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t542 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t540, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t542, ptr %rv
  br label %ret
bb113:
  call void @__olang_scope_close(ptr %s18)
  br label %bb123
bb114:
  store %olang.scope zeroinitializer, ptr %s20
  %t543 = load ptr, ptr %l0, !tbaa !29
  %t544 = load ptr, ptr %l1, !tbaa !29
  %t546 = getelementptr %"compiler/build:Program", ptr %t544, i32 0, i32 1
  %t547 = load { i64, ptr }, ptr %t546, !tbaa !27
  %t548 = load ptr, ptr %l2, !tbaa !29
  %t554 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s11, ptr %s20, ptr %v1, ptr %v2, ptr %s20, ptr %s20, ptr %t543, ptr %l21, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d89, i32 0, i32 1) }, i32 0, { i64, ptr } %t547, ptr %t548, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, i64 -1)
  %t555 = extractvalue { i32, { i64, ptr } } %t554, 1
  %t556 = extractvalue { i32, { i64, ptr } } %t554, 0
  store i32 %t556, ptr %l243
  %t557 = icmp ne i32 %t556, 0
  br i1 %t557, label %bb117, label %ok.558
ok.558:
  store { i64, ptr } %t555, ptr %l242
  br label %bb116
bb115:
  store %olang.scope zeroinitializer, ptr %s21
  %t559 = load ptr, ptr %l0, !tbaa !29
  %t560 = load ptr, ptr %l1, !tbaa !29
  %t562 = getelementptr %"compiler/build:Program", ptr %t560, i32 0, i32 2
  %t563 = load { i64, ptr }, ptr %t562, !tbaa !27
  %t564 = load ptr, ptr %l2, !tbaa !29
  %t570 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s11, ptr %s21, ptr %v1, ptr %v2, ptr %s21, ptr %s21, ptr %t559, ptr %l21, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d91, i32 0, i32 1) }, i32 0, { i64, ptr } %t563, ptr %t564, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d90, i32 0, i32 1) }, i64 -1)
  %t571 = extractvalue { i32, { i64, ptr } } %t570, 1
  %t572 = extractvalue { i32, { i64, ptr } } %t570, 0
  store i32 %t572, ptr %l253
  %t573 = icmp ne i32 %t572, 0
  br i1 %t573, label %bb120, label %ok.574
ok.574:
  store { i64, ptr } %t571, ptr %l252
  br label %bb119
bb116:
  %t575 = load { i64, ptr }, ptr %l242, !tbaa !27
  store { i64, ptr } %t575, ptr %l235, !tbaa !27
  br label %bb118
bb117:
  %t576 = load i32, ptr %l243, !tbaa !23
  %t577 = lshr i32 %t576, 16
  %t578 = and i32 %t576, 65535
  %t579 = icmp eq i32 %t577, 1
  %t580 = select i1 %t579, i32 1, i32 0
  %t581 = icmp eq i32 %t576, 0
  %t582 = shl i32 %t580, 16
  %t583 = or i32 %t582, %t578
  %t584 = select i1 %t581, i32 0, i32 %t583
  call void @__olang_scope_close(ptr %s20)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t586 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t584, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t586, ptr %rv
  br label %ret
bb118:
  call void @__olang_scope_close(ptr %s20)
  br label %bb122
bb119:
  %t587 = load { i64, ptr }, ptr %l252, !tbaa !27
  store { i64, ptr } %t587, ptr %l245, !tbaa !27
  br label %bb121
bb120:
  %t588 = load i32, ptr %l253, !tbaa !23
  %t589 = lshr i32 %t588, 16
  %t590 = and i32 %t588, 65535
  %t591 = icmp eq i32 %t589, 1
  %t592 = select i1 %t591, i32 1, i32 0
  %t593 = icmp eq i32 %t588, 0
  %t594 = shl i32 %t592, 16
  %t595 = or i32 %t594, %t590
  %t596 = select i1 %t593, i32 0, i32 %t595
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t598 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t596, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t598, ptr %rv
  br label %ret
bb121:
  call void @__olang_scope_close(ptr %s21)
  br label %bb122
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s14)
  br label %bb124
bb124:
  %t599 = load i64, ptr %l26, !tbaa !24
  %t601 = add i64 %t599, 1
  store i64 %t601, ptr %l26, !tbaa !24
  br label %bb78
bb125:
  %t603 = load i64, ptr %l23, !tbaa !24
  %t604 = load i64, ptr %l25, !tbaa !24
  %t607 = add i64 %t603, %t604
  store i64 %t607, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb126
bb126:
  br label %bb71
bb127:
  %t609 = load ptr, ptr %l0, !tbaa !29
  %t610 = load ptr, ptr %l2, !tbaa !29
  %t614 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %s11, ptr %v2, ptr %t609, ptr %l21, ptr %t610)
  store i32 %t614, ptr %l263
  %t615 = icmp ne i32 %t614, 0
  br i1 %t615, label %bb129, label %ok.616
ok.616:
  br label %bb128
bb128:
  br label %bb130
bb129:
  %t617 = load i32, ptr %l263, !tbaa !23
  %t618 = lshr i32 %t617, 16
  %t619 = and i32 %t617, 65535
  %t620 = icmp eq i32 %t618, 1
  %t621 = select i1 %t620, i32 1, i32 0
  %t622 = icmp eq i32 %t617, 0
  %t623 = shl i32 %t621, 16
  %t624 = or i32 %t623, %t619
  %t625 = select i1 %t622, i32 0, i32 %t624
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t627 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t625, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t627, ptr %rv
  br label %ret
bb130:
  call void @__olang_scope_close(ptr %s11)
  br label %bb131
bb131:
  %t628 = load ptr, ptr %lp11
  %t629 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t628
  call void @__olang_scope_close(ptr %s0)
  %t631 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t629, 1
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t631, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }, ptr %rv
  ret { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/os:Output"
  %l4 = alloca i1
  %l5 = alloca %"std/os:Output"
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/os:Output"
  %l12 = alloca i32
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 21
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d92, i32 0, i32 1) })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = mul i64 2, 16
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 2, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 0
  store { i64, ptr } %t24, ptr %t32, !tbaa !37
  %t33 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %t34, i64 1
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d93, i32 0, i32 1) }, ptr %t35, !tbaa !37
  %t36 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t37 = call { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d94, i32 0, i32 1) }, i1 true)
  %t38 = extractvalue { i32, %"std/os:Output" } %t37, 1
  %t39 = extractvalue { i32, %"std/os:Output" } %t37, 0
  store i32 %t39, ptr %l12
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb5, label %ok.41
ok.41:
  store %"std/os:Output" %t38, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t42 = load %"std/os:Output", ptr %l11
  store %"std/os:Output" %t42, ptr %l5
  br label %bb9
bb5:
  %t43 = load i32, ptr %l12, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  br i1 %t46, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_fb1993af6f92a97f_575d454bf14ba47b)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d95, i32 0, i32 1) }, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t48 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t48, ptr %rv
  br label %ret
bb9:
  %t49 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t49, ptr %l1
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t51 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 1
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = extractvalue { i64, ptr } %t52, 0
  %t56 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t54, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t68 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 21
  store { i64, ptr } %t65, ptr %t68, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Config", ptr %t69, i32 0, i32 21
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t72, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { { i64, ptr }, { i64, ptr } }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l21 = alloca { i64, ptr }
  %l23 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { { i64, ptr }, { i64, ptr } }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l34 = alloca ptr
  %l35 = alloca i64
  %l38 = alloca i64
  %l45 = alloca i64
  %l48 = alloca i64
  %l69 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca i32
  %l85 = alloca ptr
  %l86 = alloca { i64, [3 x i64] }
  %l90 = alloca { i64, ptr }
  %l91 = alloca %"compiler/msgs:Msg"
  %l95 = alloca { i64, ptr }
  %l96 = alloca i32
  %l102 = alloca i1
  %l109 = alloca { i64, ptr }
  %l113 = alloca { i64, ptr }
  %l114 = alloca i32
  %l123 = alloca { i64, ptr }
  %l124 = alloca %"compiler/msgs:Msg"
  %l126 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l135 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca i32
  %l149 = alloca { i64, ptr }
  %l153 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t171 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:compiles", ptr %t1, i32 0, i32 0
  %t5 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %v1, ptr %v1, ptr %t3)
  store { i64, ptr } %t5, ptr %l21
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l23
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/build:compiles", ptr %t9, i32 0, i32 5
  %t13 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s0, ptr %t11)
  store { i64, ptr } %t13, ptr %l26
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t15 = load i64, ptr %l23, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t17 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t14, i64 %t15, { i64, ptr } %t16)
  store { { i64, ptr }, { i64, ptr } } %t17, ptr %l27
  br label %bb4
bb4:
  %t18 = load { { i64, ptr }, { i64, ptr } }, ptr %l27
  store { { i64, ptr }, { i64, ptr } } %t18, ptr %l3
  %t19 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l28, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l29, !tbaa !24
  %t23 = load i64, ptr %l29, !tbaa !24
  %t24 = mul i64 %t23, 4
  %t25 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l30, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l29, !tbaa !24
  %t33 = mul i64 %t32, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l31, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l32, !tbaa !24
  %t39 = load i64, ptr %l32, !tbaa !24
  %t40 = mul i64 %t39, 16
  %t41 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l33, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l32, !tbaa !24
  %t49 = mul i64 %t48, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l34, !tbaa !29
  %t52 = load ptr, ptr %l34, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t52, i32 0, i32 17
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l35, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/build:compiles", ptr %t55, i32 0, i32 0
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %v1, ptr %t57)
  store i64 %t59, ptr %l38
  br label %bb5
bb5:
  %t60 = load i64, ptr %l35, !tbaa !24
  %t61 = load i64, ptr %l38, !tbaa !24
  %t62 = add i64 %t60, %t61
  %t64 = load ptr, ptr %l34, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 17
  store i64 %t62, ptr %t65, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb6, label %bb7
bb6:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb11
bb8:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l48, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l48, !tbaa !24
  br label %bb10
bb10:
  %t96 = load i64, ptr %l48, !tbaa !24
  store i64 %t96, ptr %l45, !tbaa !24
  br label %bb11
bb11:
  %t97 = load i64, ptr %l45, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb63
bb14:
  br label %bb15
bb15:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l12, !tbaa !24
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/build:compiles", ptr %t116, i32 0, i32 4
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t118, i64 %t119)
  store { i64, ptr } %t122, ptr %l69
  br label %bb16
bb16:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/build:compiles", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t125, i64 %t126)
  store { i64, ptr } %t129, ptr %l73
  br label %bb17
bb17:
  %t130 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t132 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t130, { i64, ptr } %t131)
  store i32 %t132, ptr %l74
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb19, label %ok.134
ok.134:
  br label %bb18
bb18:
  br label %bb23
bb19:
  %t135 = load i32, ptr %l74, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  br i1 %t138, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  %t140 = load i32, ptr %l74, !tbaa !23
  %t141 = lshr i32 %t140, 16
  %t142 = and i32 %t140, 65535
  %t143 = icmp eq i32 %t141, 1
  %t144 = select i1 %t143, i32 0, i32 0
  %t145 = icmp eq i32 %t140, 0
  %t146 = shl i32 %t144, 16
  %t147 = or i32 %t146, %t142
  %t148 = select i1 %t145, i32 0, i32 %t147
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t148, ptr %rv
  br label %ret
bb22:
  call void @__olang_ert_req_clear()
  br label %bb23
bb23:
  %t150 = load i64, ptr %l12, !tbaa !24
  %t152 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr i32, ptr %t153, i64 %t150
  %t155 = load i32, ptr %t154, !tbaa !33
  %t157 = icmp ne i32 %t155, 0
  br i1 %t157, label %bb24, label %bb25
bb24:
  %t159 = load i64, ptr %l12, !tbaa !24
  %t161 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t162 = load ptr, ptr %t161, !tbaa !27
  %t163 = getelementptr { i64, ptr }, ptr %t162, i64 %t159
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t164)
  br label %bb26
bb25:
  br label %bb40
bb26:
  %t166 = load i1, ptr %l6, !tbaa !21
  %t168 = xor i1 %t166, true
  br i1 %t168, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t170 = load ptr, ptr %l2, !tbaa !29
  store ptr %t170, ptr %l85, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t171
  %t172 = getelementptr { i64, [3 x i64] }, ptr %t171, i32 0, i32 0
  store i64 0, ptr %t172
  %t173 = load { i64, [3 x i64] }, ptr %t171
  store { i64, [3 x i64] } %t173, ptr %l86
  %t174 = load ptr, ptr %l1, !tbaa !29
  %t176 = getelementptr %"compiler/build:compiles", ptr %t174, i32 0, i32 3
  %t177 = load i64, ptr %l12, !tbaa !24
  %t180 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t176, i64 %t177)
  store { i64, ptr } %t180, ptr %l90
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t181 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t182 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v1, ptr %s5, { i64, ptr } %t181)
  store %"compiler/msgs:Msg" %t182, ptr %l91
  br label %bb30
bb30:
  %t183 = load ptr, ptr %l85, !tbaa !29
  %t184 = load { i64, [3 x i64] }, ptr %l86
  %t185 = load %"compiler/msgs:Msg", ptr %l91
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %s5, ptr %t183, { i64, [3 x i64] } %t184, %"compiler/msgs:Msg" %t185)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  store i1 true, ptr %l6, !tbaa !21
  %t186 = load ptr, ptr %l1, !tbaa !29
  %t188 = getelementptr %"compiler/build:compiles", ptr %t186, i32 0, i32 1
  %t189 = load i64, ptr %l12, !tbaa !24
  %t192 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t188, i64 %t189)
  store { i64, ptr } %t192, ptr %l95
  br label %bb33
bb33:
  %t193 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t194 = call i32 @std_2fos_2eRemove(ptr %v1, { i64, ptr } %t193)
  store i32 %t194, ptr %l96
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb35, label %ok.196
ok.196:
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t197 = load i32, ptr %l96, !tbaa !23
  %t198 = ashr i32 %t197, 16
  %t200 = icmp eq i32 %t198, 1
  br i1 %t200, label %bb36, label %bb37
bb36:
  br label %bb38
bb37:
  %t202 = load i32, ptr %l96, !tbaa !23
  %t203 = lshr i32 %t202, 16
  %t204 = and i32 %t202, 65535
  %t205 = icmp eq i32 %t203, 1
  %t206 = select i1 %t205, i32 0, i32 0
  %t207 = icmp eq i32 %t202, 0
  %t208 = shl i32 %t206, 16
  %t209 = or i32 %t208, %t204
  %t210 = select i1 %t207, i32 0, i32 %t209
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t210, ptr %rv
  br label %ret
bb38:
  call void @__olang_ert_req_clear()
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb40:
  %t212 = load i64, ptr %l12, !tbaa !24
  %t214 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t215 = load ptr, ptr %t214, !tbaa !27
  %t216 = getelementptr { i64, ptr }, ptr %t215, i64 %t212
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !37
  %t219 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t217, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d96, i32 0, i32 1) })
  store i1 %t219, ptr %l102
  br label %bb41
bb41:
  %t220 = load i1, ptr %l102, !tbaa !21
  %t221 = xor i1 %t220, true
  br i1 %t221, label %bb42, label %bb43
bb42:
  %t223 = load i64, ptr %l12, !tbaa !24
  %t225 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t226 = load ptr, ptr %t225, !tbaa !27
  %t227 = getelementptr { i64, ptr }, ptr %t226, i64 %t223
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t228)
  br label %bb44
bb43:
  br label %bb45
bb44:
  br label %bb45
bb45:
  %t230 = load ptr, ptr %l1, !tbaa !29
  %t232 = getelementptr %"compiler/build:compiles", ptr %t230, i32 0, i32 1
  %t233 = load i64, ptr %l12, !tbaa !24
  %t236 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t232, i64 %t233)
  store { i64, ptr } %t236, ptr %l109
  br label %bb46
bb46:
  %t237 = load ptr, ptr %l1, !tbaa !29
  %t239 = getelementptr %"compiler/build:compiles", ptr %t237, i32 0, i32 2
  %t240 = load i64, ptr %l12, !tbaa !24
  %t243 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t239, i64 %t240)
  store { i64, ptr } %t243, ptr %l113
  br label %bb47
bb47:
  %t244 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l113, !tbaa !27
  %t246 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t244, { i64, ptr } %t245)
  store i32 %t246, ptr %l114
  %t247 = icmp ne i32 %t246, 0
  br i1 %t247, label %bb49, label %ok.248
ok.248:
  br label %bb48
bb48:
  br label %bb59
bb49:
  %t249 = load i32, ptr %l114, !tbaa !23
  %t250 = ashr i32 %t249, 16
  %t252 = icmp eq i32 %t250, 1
  br i1 %t252, label %bb50, label %bb51
bb50:
  br label %bb52
bb51:
  %t254 = load i32, ptr %l114, !tbaa !23
  %t255 = lshr i32 %t254, 16
  %t256 = and i32 %t254, 65535
  %t257 = icmp eq i32 %t255, 1
  %t258 = select i1 %t257, i32 0, i32 0
  %t259 = icmp eq i32 %t254, 0
  %t260 = shl i32 %t258, 16
  %t261 = or i32 %t260, %t256
  %t262 = select i1 %t259, i32 0, i32 %t261
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t262, ptr %rv
  br label %ret
bb52:
  call void @__olang_ert_req_clear()
  %t264 = load i1, ptr %l6, !tbaa !21
  %t266 = xor i1 %t264, true
  br i1 %t266, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t268 = load ptr, ptr %l1, !tbaa !29
  %t270 = getelementptr %"compiler/build:compiles", ptr %t268, i32 0, i32 2
  %t271 = load i64, ptr %l12, !tbaa !24
  %t274 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t270, i64 %t271)
  store { i64, ptr } %t274, ptr %l123
  br label %bb55
bb54:
  br label %bb58
bb55:
  %t275 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s9)
  store %"compiler/msgs:Msg" %t275, ptr %l124
  br label %bb56
bb56:
  %t276 = load ptr, ptr %l2, !tbaa !29
  %t277 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t278 = load %"compiler/msgs:Msg", ptr %l124
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s9, ptr %v2, { i64, ptr } %t277, %"compiler/msgs:Msg" %t278, ptr %t276)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s9)
  br label %bb58
bb58:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb59:
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l126, !tbaa !29
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t283 = getelementptr %"compiler/build:compiles", ptr %t281, i32 0, i32 2
  %t284 = load i64, ptr %l12, !tbaa !24
  %t287 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v1, ptr %v1, ptr %t283, i64 %t284)
  store { i64, ptr } %t287, ptr %l130
  br label %bb60
bb60:
  %t288 = load ptr, ptr %l126, !tbaa !29
  %t289 = load { i64, ptr }, ptr %l130, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %t288, { i64, ptr } %t289)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s2)
  br label %bb62
bb62:
  %t290 = load i64, ptr %l11, !tbaa !24
  %t292 = add i64 %t290, 1
  store i64 %t292, ptr %l11, !tbaa !24
  br label %bb12
bb63:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t296 = getelementptr %"compiler/build:compiles", ptr %t294, i32 0, i32 6
  store ptr %t296, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb64
bb64:
  store %olang.scope zeroinitializer, ptr %s12
  %t298 = load ptr, ptr %l13, !tbaa !29
  %t299 = load i64, ptr %l14, !tbaa !24
  %t302 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t298, i64 %t299)
  %t303 = extractvalue { i32, { i64, ptr } } %t302, 1
  %t304 = extractvalue { i32, { i64, ptr } } %t302, 0
  store i32 %t304, ptr %l139
  %t305 = icmp ne i32 %t304, 0
  br i1 %t305, label %bb66, label %ok.306
ok.306:
  store { i64, ptr } %t303, ptr %l138
  br label %bb65
bb65:
  %t307 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t307, ptr %l135, !tbaa !27
  br label %bb70
bb66:
  %t308 = load i32, ptr %l139, !tbaa !23
  %t309 = ashr i32 %t308, 16
  %t311 = icmp eq i32 %t309, 1
  br i1 %t311, label %bb67, label %bb68
bb67:
  br label %bb69
bb68:
  %t313 = load i32, ptr %l139, !tbaa !23
  %t314 = lshr i32 %t313, 16
  %t315 = and i32 %t313, 65535
  %t316 = icmp eq i32 %t314, 1
  %t317 = select i1 %t316, i32 0, i32 0
  %t318 = icmp eq i32 %t313, 0
  %t319 = shl i32 %t317, 16
  %t320 = or i32 %t319, %t315
  %t321 = select i1 %t318, i32 0, i32 %t320
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t321, ptr %rv
  br label %ret
bb69:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb70:
  %t323 = load { i64, ptr }, ptr %l135, !tbaa !27
  store { i64, ptr } %t323, ptr %l15, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t326 = extractvalue { i64, ptr } %t324, 0
  store i64 %t326, ptr %l16, !tbaa !24
  store i64 0, ptr %l17, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s13
  %t328 = load i64, ptr %l17, !tbaa !24
  %t329 = load i64, ptr %l16, !tbaa !24
  %t332 = icmp slt i64 %t328, %t329
  %t334 = xor i1 %t332, true
  br i1 %t334, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s13)
  br label %bb82
bb73:
  br label %bb74
bb74:
  %t336 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t336, ptr %l149, !tbaa !27
  %t337 = load i64, ptr %l17, !tbaa !24
  %t339 = getelementptr { i64, ptr }, ptr %l149, i32 0, i32 1
  %t340 = load ptr, ptr %t339, !tbaa !27
  %t341 = getelementptr { i64, ptr }, ptr %t340, i64 %t337
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !37
  %t346 = call i32 @std_2fos_2eRemoveAll(ptr %v1, { i64, ptr } %t342)
  store i32 %t346, ptr %l153
  %t347 = icmp ne i32 %t346, 0
  br i1 %t347, label %bb76, label %ok.348
ok.348:
  br label %bb75
bb75:
  br label %bb80
bb76:
  %t349 = load i32, ptr %l153, !tbaa !23
  %t350 = ashr i32 %t349, 16
  %t352 = icmp eq i32 %t350, 1
  br i1 %t352, label %bb77, label %bb78
bb77:
  br label %bb79
bb78:
  %t354 = load i32, ptr %l153, !tbaa !23
  %t355 = lshr i32 %t354, 16
  %t356 = and i32 %t354, 65535
  %t357 = icmp eq i32 %t355, 1
  %t358 = select i1 %t357, i32 0, i32 0
  %t359 = icmp eq i32 %t354, 0
  %t360 = shl i32 %t358, 16
  %t361 = or i32 %t360, %t356
  %t362 = select i1 %t359, i32 0, i32 %t361
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t362, ptr %rv
  br label %ret
bb79:
  call void @__olang_ert_req_clear()
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s13)
  br label %bb81
bb81:
  %t364 = load i64, ptr %l17, !tbaa !24
  %t366 = add i64 %t364, 1
  store i64 %t366, ptr %l17, !tbaa !24
  br label %bb71
bb82:
  %t368 = load i64, ptr %l14, !tbaa !24
  %t369 = load i64, ptr %l16, !tbaa !24
  %t372 = add i64 %t368, %t369
  store i64 %t372, ptr %l14, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb83:
  br label %bb64
bb84:
  %t374 = load i1, ptr %l6, !tbaa !21
  br i1 %t374, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb86:
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t4)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  br label %bb1
bb1:
  br label %bb8
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 0, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  store i32 %t22, ptr %rv
  br label %ret
bb5:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/build:Config", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t28, ptr %l10
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t31 = load %"compiler/msgs:Msg", ptr %l10
  call void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %s1, ptr %v1, { i64, ptr } %t30, %"compiler/msgs:Msg" %t31, ptr %a1)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %rv
  br label %ret
bb8:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l24 = alloca i1
  %l27 = alloca i32
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l35 = alloca i32
  %l40 = alloca i32
  %l44 = alloca i32
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 20
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d97, i32 0, i32 1) })
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 20
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/build:Config", ptr %t13, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = add i64 %t18, 1
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t21, 0
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp sge i64 %t27, 0
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = icmp sle i64 %t30, %t31
  br i1 %t32, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb9:
  %t38 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = getelementptr i8, ptr %t39, i64 %t40
  %t43 = sub i64 %t41, %t40
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t46 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t45, 1
  %t54 = extractvalue { i64, ptr } %t45, 0
  %t55 = add i64 %t51, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t56, 1
  store { i64, ptr } %t60, ptr %l2, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t62)
  store i1 %t64, ptr %l24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb11:
  %t65 = load i1, ptr %l24, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t66, i32 0, i32 20
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t69)
  store i32 %t71, ptr %l27
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb16, label %ok.73
ok.73:
  br label %bb15
bb15:
  br label %bb20
bb16:
  %t74 = load i32, ptr %l27, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  br i1 %t77, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_90cf0970d2913dc4_9bcdb60805de20f8)
  unreachable
bb19:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t79, ptr %l30, !tbaa !27
  %t80 = call i32 @getpid()
  store i32 %t80, ptr %l31
  br label %bb21
bb21:
  %t81 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t81, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 1
  %t85 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d99, i32 0, i32 1) }, 0
  %t86 = add i64 %t83, %t85
  %t87 = load i32, ptr %l31, !tbaa !23
  %t88 = sext i32 %t87 to i64
  %t89 = call i64 @__olang_fmt_i64(ptr null, i64 %t88)
  %t90 = add i64 %t86, %t89
  %t91 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, 1
  %t92 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d100, i32 0, i32 1) }, 0
  %t93 = add i64 %t90, %t92
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t82, i64 %t83)
  %t95 = getelementptr i8, ptr %t94, i64 %t83
  call void @olang_textcopy(ptr %t95, ptr %t84, i64 %t85)
  %t96 = getelementptr i8, ptr %t95, i64 %t85
  %t97 = call i64 @__olang_fmt_i64(ptr %t96, i64 %t88)
  %t98 = getelementptr i8, ptr %t96, i64 %t89
  call void @olang_textcopy(ptr %t98, ptr %t91, i64 %t92)
  %t99 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t94, 1
  store { i64, ptr } %t100, ptr %l3, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t106 = call i32 @std_2fos_2eLink(ptr %v1, ptr %s0, { i64, ptr } %t102, { i64, ptr } %t103)
  store i32 %t106, ptr %l35
  %t107 = icmp ne i32 %t106, 0
  br i1 %t107, label %bb23, label %ok.108
ok.108:
  br label %bb22
bb22:
  br label %bb27
bb23:
  %t109 = load i32, ptr %l35, !tbaa !23
  %t110 = ashr i32 %t109, 16
  %t112 = icmp eq i32 %t110, 1
  br i1 %t112, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_8b1e12aab65e64ff_84504a06af2aa513)
  unreachable
bb26:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t114 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t115 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t118 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t114, { i64, ptr } %t115)
  store i32 %t118, ptr %l40
  %t119 = icmp ne i32 %t118, 0
  br i1 %t119, label %bb29, label %ok.120
ok.120:
  br label %bb28
bb28:
  br label %bb39
bb29:
  %t121 = load i32, ptr %l40, !tbaa !23
  %t122 = ashr i32 %t121, 16
  %t124 = icmp eq i32 %t122, 1
  br i1 %t124, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  call void @__olang_check_failed(ptr @olang_loc_92faa2cdf30c2efe_47110dc1ef627b12)
  unreachable
bb32:
  call void @__olang_ert_req_clear()
  %t126 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t128 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t126)
  store i32 %t128, ptr %l44
  %t129 = icmp ne i32 %t128, 0
  br i1 %t129, label %bb34, label %ok.130
ok.130:
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t131 = load i32, ptr %l44, !tbaa !23
  %t132 = ashr i32 %t131, 16
  %t134 = icmp eq i32 %t132, 1
  br i1 %t134, label %bb35, label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_check_failed(ptr @olang_loc_92faa2cdf30c2efe_47110dc1ef627b12)
  unreachable
bb37:
  call void @__olang_ert_req_clear()
  br label %bb38
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca i1
  %l14 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca { i64, ptr }
  %l41 = alloca i1
  %l47 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca { i64, [3 x i64] }
  %l53 = alloca %"compiler/msgs:Msg"
  %l55 = alloca i32
  %l60 = alloca i32
  %l63 = alloca { i64, ptr }
  %l64 = alloca %"compiler/msgs:Msg"
  %l67 = alloca i32
  %l75 = alloca ptr
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t129 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v3, ptr %s0, { i64, ptr } %a3)
  store { i64, ptr } %t3, ptr %l9
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 15
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) })
  store i1 %t10, ptr %l12
  br label %bb2
bb2:
  %t11 = load i1, ptr %l12, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/build:Config", ptr %t14, i32 0, i32 15
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = extractvalue { i64, ptr } %t17, 0
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t19, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l14, !tbaa !27
  br label %bb7
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/build:Config", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l19, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t29, ptr %l20, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t30)
  store { i64, ptr } %t32, ptr %l22
  br label %bb5
bb5:
  %t33 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d102, i32 0, i32 1) }, ptr %l25, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d103, i32 0, i32 1) }, ptr %l26, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t44 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t40, { i64, ptr } %t42, { i64, ptr } %t43)
  store { i64, ptr } %t44, ptr %l27
  br label %bb6
bb6:
  %t45 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d104, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d104, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t57 = extractvalue { i64, ptr } %t45, 1
  %t58 = extractvalue { i64, ptr } %t45, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d105, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t47, i64 %t48)
  %t64 = getelementptr i8, ptr %t63, i64 %t48
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t63, 1
  store { i64, ptr } %t69, ptr %l14, !tbaa !27
  br label %bb7
bb7:
  %t71 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, { i64, ptr } %t72)
  store { i64, ptr } %t74, ptr %l31
  br label %bb8
bb8:
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = getelementptr i8, ptr %t82, i64 %t78
  call void @olang_textcopy(ptr %t83, ptr %t79, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t95 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t93, { i64, ptr } %t92, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d107, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d109, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d110, i32 0, i32 1) })
  store { i64, ptr } %t95, ptr %l35
  br label %bb9
bb9:
  %t96 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t96, ptr %l7, !tbaa !27
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l36, !tbaa !29
  store ptr %a2, ptr %l37, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t99, ptr %l38, !tbaa !27
  %t100 = load ptr, ptr %l1, !tbaa !29
  %t102 = getelementptr %"compiler/build:Program", ptr %t100, i32 0, i32 2
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  %t105 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t103, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d111, i32 0, i32 1) })
  store i1 %t105, ptr %l41
  br label %bb10
bb10:
  %t106 = load i1, ptr %l41, !tbaa !21
  %t107 = xor i1 %t106, true
  %t108 = load ptr, ptr %l1, !tbaa !29
  %t110 = getelementptr %"compiler/build:Program", ptr %t108, i32 0, i32 3
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t113 = getelementptr %"compiler/build:Program", ptr %t111, i32 0, i32 4
  %t114 = load ptr, ptr %l36, !tbaa !29
  %t115 = load ptr, ptr %l37, !tbaa !29
  %t116 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t120 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v2, ptr %s0, ptr %v1, ptr %v1, ptr %t114, ptr %t115, { i64, ptr } %t116, i1 %t107, ptr %t110, ptr %t113)
  store i32 %t120, ptr %l47
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb12, label %ok.122
ok.122:
  br label %bb11
bb11:
  br label %bb19
bb12:
  %t123 = load i32, ptr %l47, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  br i1 %t126, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_4094133386311447_ea4f4ad8e8116e4b)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t128 = load ptr, ptr %l4, !tbaa !29
  store ptr %t128, ptr %l50, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t129
  %t130 = getelementptr { i64, [3 x i64] }, ptr %t129, i32 0, i32 0
  store i64 0, ptr %t130
  %t131 = load { i64, [3 x i64] }, ptr %t129
  store { i64, [3 x i64] } %t131, ptr %l51
  %t132 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t134 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s4, { i64, ptr } %t132)
  store %"compiler/msgs:Msg" %t134, ptr %l53
  br label %bb16
bb16:
  %t135 = load ptr, ptr %l50, !tbaa !29
  %t136 = load { i64, [3 x i64] }, ptr %l51
  %t137 = load %"compiler/msgs:Msg", ptr %l53
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s4, ptr %t135, { i64, [3 x i64] } %t136, %"compiler/msgs:Msg" %t137)
  br label %bb17
bb17:
  %t138 = load ptr, ptr %l4, !tbaa !29
  %t140 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t138)
  store i32 %t140, ptr %l55
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l55, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
bb19:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d112, i32 0, i32 1) })
  br label %bb20
bb20:
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/build:Program", ptr %t143, i32 0, i32 5
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t150 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t142, { i64, ptr } %t146)
  store i32 %t150, ptr %l60
  %t151 = icmp ne i32 %t150, 0
  br i1 %t151, label %bb22, label %ok.152
ok.152:
  br label %bb21
bb21:
  br label %bb29
bb22:
  %t153 = load i32, ptr %l60, !tbaa !23
  %t154 = ashr i32 %t153, 16
  %t156 = icmp eq i32 %t154, 1
  br i1 %t156, label %bb23, label %bb24
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_5506b8e1d4511fe6_ac8ddf3d542b2a0a)
  unreachable
bb25:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s5
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t158, ptr %l63, !tbaa !27
  %t159 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s5)
  store %"compiler/msgs:Msg" %t159, ptr %l64
  br label %bb26
bb26:
  %t160 = load ptr, ptr %l4, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t162 = load %"compiler/msgs:Msg", ptr %l64
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s5, ptr %v4, { i64, ptr } %t161, %"compiler/msgs:Msg" %t162, ptr %t160)
  br label %bb27
bb27:
  %t164 = load ptr, ptr %l4, !tbaa !29
  %t166 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t164)
  store i32 %t166, ptr %l67
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t167 = load i32, ptr %l67, !tbaa !23
  store i32 %t167, ptr %rv
  br label %ret
bb29:
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t169, 1
  %t172 = extractvalue { i64, ptr } %t169, 0
  %t173 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t171, i64 %t172)
  %t174 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t173, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t185 = getelementptr %"compiler/build:Config", ptr %t168, i32 0, i32 16
  store { i64, ptr } %t182, ptr %t185, !tbaa !27
  %t186 = load ptr, ptr %l0, !tbaa !29
  %t188 = getelementptr %"compiler/build:Config", ptr %t186, i32 0, i32 14
  %t189 = load i1, ptr %t188, !tbaa !21
  %t191 = xor i1 %t189, true
  br i1 %t191, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t193 = load ptr, ptr %l0, !tbaa !29
  store ptr %t193, ptr %l75, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t196 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s7, { i64, ptr } %t194)
  store { i64, ptr } %t196, ptr %l77
  br label %bb32
bb31:
  br label %bb36
bb32:
  %t197 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t199 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s7, { i64, ptr } %t197)
  store { i64, ptr } %t199, ptr %l79
  br label %bb33
bb33:
  %t200 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d113, i32 0, i32 1) }, 1
  %t201 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d113, i32 0, i32 1) }, 0
  %t202 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t203 = extractvalue { i64, ptr } %t202, 1
  %t204 = extractvalue { i64, ptr } %t202, 0
  %t205 = add i64 %t201, %t204
  %t206 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t207 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t208 = add i64 %t205, %t207
  %t209 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 1
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t212 = add i64 %t208, %t211
  %t213 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t212)
  call void @olang_textcopy(ptr %t213, ptr %t200, i64 %t201)
  %t214 = getelementptr i8, ptr %t213, i64 %t201
  call void @olang_textcopy(ptr %t214, ptr %t203, i64 %t204)
  %t215 = getelementptr i8, ptr %t214, i64 %t204
  call void @olang_textcopy(ptr %t215, ptr %t206, i64 %t207)
  %t216 = getelementptr i8, ptr %t215, i64 %t207
  call void @olang_textcopy(ptr %t216, ptr %t210, i64 %t211)
  %t217 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t213, 1
  %t220 = extractvalue { i64, ptr } %t218, 0
  %t221 = extractvalue { i64, ptr } %t218, 1
  %t222 = mul i64 %t220, 1
  %t223 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t222)
  call void @llvm.memcpy.p0.p0.i64(ptr %t223, ptr %t221, i64 %t222, i1 false)
  %t224 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t225 = insertvalue { i64, ptr } %t224, ptr %t223, 1
  %t226 = load ptr, ptr %l75, !tbaa !29
  %t228 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t226, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d115, i32 0, i32 1) }, { i64, ptr } %t225)
  store { i64, ptr } %t228, ptr %l82
  br label %bb34
bb34:
  %t229 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  %t231 = extractvalue { i64, ptr } %t229, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  call void @compiler_2fbuild_2esayln(ptr %s7, { i64, ptr } %t235)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d116, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d119, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Config", ptr %t11, i32 0, i32 5
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d121, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 7
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d122, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb12:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/build:Config", ptr %t21, i32 0, i32 9
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d124, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d125, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb15:
  %t26 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t26, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = add i64 %t28, %t31
  %t33 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = add i64 %t32, %t35
  %t37 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  %t40 = add i64 %t36, %t39
  %t41 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t41, 1
  %t43 = extractvalue { i64, ptr } %t41, 0
  %t44 = add i64 %t40, %t43
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t27, i64 %t28)
  %t46 = getelementptr i8, ptr %t45, i64 %t28
  call void @olang_textcopy(ptr %t46, ptr %t30, i64 %t31)
  %t47 = getelementptr i8, ptr %t46, i64 %t31
  call void @olang_textcopy(ptr %t47, ptr %t34, i64 %t35)
  %t48 = getelementptr i8, ptr %t47, i64 %t35
  call void @olang_textcopy(ptr %t48, ptr %t38, i64 %t39)
  %t49 = getelementptr i8, ptr %t48, i64 %t39
  call void @olang_textcopy(ptr %t49, ptr %t42, i64 %t43)
  %t50 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t45, 1
  store { i64, ptr } %t51, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 13
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = extractvalue { i64, ptr } %t8, 0
  %t12 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t10, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t17, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb5
bb5:
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d126, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %a1, 1
  %t24 = extractvalue { i64, ptr } %a1, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d127, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t40)
  br label %bb6
bb6:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v2, ptr %l3, { i64, ptr } %t43)
  br label %bb7
bb7:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb8
bb8:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d128, i32 0, i32 1) })
  br label %bb9
bb9:
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t49, ptr %l20
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t50, ptr %l21, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l22, !tbaa !24
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l23, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l22, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t64, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t65 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l10 = alloca ptr
  %l11 = alloca { i64, [3 x i64] }
  %l14 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t28 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 2
  %t5 = call { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v2, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb8
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t17 = lshr i32 %t16, 16
  %t18 = and i32 %t16, 65535
  %t19 = icmp eq i32 %t17, 1
  %t20 = select i1 %t19, i32 0, i32 0
  %t21 = icmp eq i32 %t16, 0
  %t22 = shl i32 %t20, 16
  %t23 = or i32 %t22, %t18
  %t24 = select i1 %t21, i32 0, i32 %t23
  %t26 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t24, 0
  store { i32, { i64, ptr } } %t26, ptr %rv
  br label %ret
bb5:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %a1, ptr %l10, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t28
  %t29 = getelementptr { i64, [3 x i64] }, ptr %t28, i32 0, i32 0
  store i64 0, ptr %t29
  %t30 = load { i64, [3 x i64] }, ptr %t28
  store { i64, [3 x i64] } %t30, ptr %l11
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = getelementptr %"compiler/build:Config", ptr %t31, i32 0, i32 2
  %t34 = getelementptr %"compiler/target:Target", ptr %t33, i32 0, i32 2
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %s1, { i64, ptr } %t35)
  store %"compiler/msgs:Msg" %t37, ptr %l14
  br label %bb6
bb6:
  %t38 = load ptr, ptr %l10, !tbaa !29
  %t39 = load { i64, [3 x i64] }, ptr %l11
  %t40 = load %"compiler/msgs:Msg", ptr %l14
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s1, ptr %t38, { i64, [3 x i64] } %t39, %"compiler/msgs:Msg" %t40)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  %t42 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t42, ptr %rv
  br label %ret
bb8:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t44 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t43, 1
  store { i32, { i64, ptr } } %t44, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v2, ptr %s0, ptr %a2)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d129, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d129, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t33 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d130, i32 0, i32 1) }, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l10
  br label %bb3
bb3:
  %t34 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t40)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fbuild_2efileError(ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t1, %"compiler/msgs:Msg" %a2, ptr %t3)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t16)
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t39 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d132, i32 0, i32 1) }, { i64, ptr } %t36)
  store { i64, ptr } %t39, ptr %l14
  br label %bb4
bb4:
  %t40 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t46)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, { i64, ptr } %a6, i64 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp9 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l27 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l30 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l35 = alloca i1
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l45 = alloca i1
  %l46 = alloca i1
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca { i64, ptr }
  %l53 = alloca i1
  %l57 = alloca i1
  %l60 = alloca { i64, ptr }
  %l64 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l75 = alloca i32
  %l80 = alloca i1
  %l84 = alloca i1
  %l87 = alloca i1
  %l95 = alloca i64
  %l96 = alloca i64
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca i1
  %l113 = alloca i1
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l116 = alloca { i64, ptr }
  %l120 = alloca i1
  %l122 = alloca { i64, ptr }
  %l124 = alloca i64
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l130 = alloca i64
  %l131 = alloca i64
  %l135 = alloca { i64, ptr }
  %l136 = alloca i32
  %l141 = alloca i32
  %l145 = alloca { i64, ptr }
  %l146 = alloca %"compiler/msgs:Msg"
  %l151 = alloca i1
  %l154 = alloca i32
  %l158 = alloca ptr
  %l159 = alloca { i64, [3 x i64] }
  %l161 = alloca %"compiler/msgs:Msg"
  %l163 = alloca { i64, ptr }
  %l164 = alloca i32
  %l166 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l174 = alloca { i64, ptr }
  %l177 = alloca { i64, ptr }
  %l178 = alloca i32
  %l188 = alloca { i64, ptr }
  %l211 = alloca ptr
  %l213 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t455 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  store i64 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l3
  %t3 = trunc i64 4 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %s0, ptr %t6)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l27
  br label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v3, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l30
  br label %bb4
bb3:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l27
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l25
  br label %bb5
bb4:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l30
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l25
  br label %bb5
bb5:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, ptr %l8
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l31, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l32, !tbaa !27
  %t19 = load i32, ptr %l3
  store i32 %t19, ptr %l33
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d133, i32 0, i32 1) })
  store i1 %t22, ptr %l35
  br label %bb6
bb6:
  %t23 = load i1, ptr %l35, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t26, ptr %l37, !tbaa !27
  br label %bb10
bb8:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v5, { i64, ptr } %t28)
  store { i64, ptr } %t30, ptr %l40
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l37, !tbaa !27
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l31, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t41 = load i32, ptr %l33
  %t42 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t44 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v2, ptr %v5, ptr %s0, ptr %v6, ptr %t39, { i64, ptr } %t40, i32 %t41, { i64, ptr } %t42, ptr %l8)
  store { i64, ptr } %t44, ptr %l43
  br label %bb11
bb11:
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 16, i64 8)
  store ptr %t45, ptr %lp9
  %t46 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t47 = load ptr, ptr %lp9
  store { i64, ptr } %t46, ptr %t47, !tbaa !27
  %t48 = load ptr, ptr %lp9
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !27
  %t51 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t49)
  store i1 %t51, ptr %l45
  br label %bb12
bb12:
  %t52 = load i1, ptr %l45, !tbaa !21
  br i1 %t52, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l46, !tbaa !21
  br label %bb16
bb14:
  %t53 = load ptr, ptr %lp9
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  store { i64, ptr } %t54, ptr %l47, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l48, !tbaa !24
  %t57 = load i64, ptr %l48, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l49, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l48, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t69 = load ptr, ptr %l1, !tbaa !29
  %t71 = getelementptr %"compiler/build:compiles", ptr %t69, i32 0, i32 2
  %t75 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v1, ptr %s0, ptr %t71, { i64, ptr } %t68)
  store i1 %t75, ptr %l53
  br label %bb15
bb15:
  %t76 = load i1, ptr %l53, !tbaa !21
  store i1 %t76, ptr %l46, !tbaa !21
  br label %bb16
bb16:
  %t77 = load i1, ptr %l46, !tbaa !21
  br i1 %t77, label %bb17, label %bb18
bb17:
  %t78 = load ptr, ptr %lp9
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t81 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t79, 1
  store { i32, { i64, ptr } } %t81, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  %t82 = load ptr, ptr %l0, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 20
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d134, i32 0, i32 1) })
  store i1 %t87, ptr %l57
  br label %bb20
bb20:
  %t88 = load i1, ptr %l57, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb21, label %bb22
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t91 = load ptr, ptr %l0, !tbaa !29
  %t93 = getelementptr %"compiler/build:Config", ptr %t91, i32 0, i32 20
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  store { i64, ptr } %t94, ptr %l60, !tbaa !27
  %t95 = load ptr, ptr %l0, !tbaa !29
  %t97 = getelementptr %"compiler/build:Config", ptr %t95, i32 0, i32 0
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t102 = add i64 %t100, 1
  store i64 %t102, ptr %l64, !tbaa !24
  %t103 = load ptr, ptr %lp9
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t104, 0
  store i64 %t106, ptr %l66, !tbaa !24
  %t107 = load ptr, ptr %lp9
  %t108 = load { i64, ptr }, ptr %t107, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l67, !tbaa !24
  %t110 = load i64, ptr %l64, !tbaa !24
  %t111 = icmp sge i64 %t110, 0
  br i1 %t111, label %bb23, label %bb24
bb22:
  br label %bb39
bb23:
  %t113 = load i64, ptr %l64, !tbaa !24
  %t114 = load i64, ptr %l66, !tbaa !24
  %t115 = icmp sle i64 %t113, %t114
  br i1 %t115, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb25:
  %t117 = load i64, ptr %l66, !tbaa !24
  %t118 = load i64, ptr %l67, !tbaa !24
  %t119 = icmp sle i64 %t117, %t118
  br i1 %t119, label %bb27, label %bb28
bb26:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb27:
  %t121 = load ptr, ptr %lp9
  %t122 = getelementptr { i64, ptr }, ptr %t121, i32 0, i32 1
  %t123 = load ptr, ptr %t122, !tbaa !27
  %t124 = load i64, ptr %l64, !tbaa !24
  %t125 = load i64, ptr %l66, !tbaa !24
  %t126 = getelementptr i8, ptr %t123, i64 %t124
  %t127 = sub i64 %t125, %t124
  %t128 = insertvalue { i64, ptr } undef, i64 %t127, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t126, 1
  %t130 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 1
  %t134 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d135, i32 0, i32 1) }, 0
  %t135 = add i64 %t132, %t134
  %t137 = extractvalue { i64, ptr } %t129, 1
  %t138 = extractvalue { i64, ptr } %t129, 0
  %t139 = add i64 %t135, %t138
  %t140 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t131, i64 %t132)
  %t141 = getelementptr i8, ptr %t140, i64 %t132
  call void @olang_textcopy(ptr %t141, ptr %t133, i64 %t134)
  %t142 = getelementptr i8, ptr %t141, i64 %t134
  call void @olang_textcopy(ptr %t142, ptr %t137, i64 %t138)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t140, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t152 = load ptr, ptr %lp9
  %t153 = load { i64, ptr }, ptr %t152, !tbaa !27
  %t156 = call i32 @std_2fos_2eLink(ptr %s2, ptr %v6, { i64, ptr } %t151, { i64, ptr } %t153)
  store i32 %t156, ptr %l75
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb30, label %ok.158
ok.158:
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb29:
  br label %bb34
bb30:
  %t159 = load i32, ptr %l75, !tbaa !23
  %t160 = ashr i32 %t159, 16
  %t162 = icmp eq i32 %t160, 1
  br i1 %t162, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  %t164 = load i32, ptr %l75, !tbaa !23
  %t165 = lshr i32 %t164, 16
  %t166 = and i32 %t164, 65535
  %t167 = icmp eq i32 %t165, 1
  %t168 = select i1 %t167, i32 0, i32 0
  %t169 = icmp eq i32 %t164, 0
  %t170 = shl i32 %t168, 16
  %t171 = or i32 %t170, %t166
  %t172 = select i1 %t169, i32 0, i32 %t171
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t174 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t172, 0
  store { i32, { i64, ptr } } %t174, ptr %rv
  br label %ret
bb33:
  call void @__olang_ert_req_clear()
  br label %bb34
bb34:
  %t175 = load ptr, ptr %lp9
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  %t178 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t176)
  store i1 %t178, ptr %l80
  br label %bb35
bb35:
  %t179 = load i1, ptr %l80, !tbaa !21
  br i1 %t179, label %bb36, label %bb37
bb36:
  %t180 = load ptr, ptr %lp9
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t183 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t181, 1
  store { i32, { i64, ptr } } %t183, ptr %rv
  br label %ret
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s2)
  br label %bb39
bb39:
  %t184 = load i64, ptr %l7, !tbaa !24
  %t186 = icmp sge i64 %t184, 0
  br i1 %t186, label %bb40, label %bb41
bb40:
  %t188 = load ptr, ptr %lp9
  %t189 = load { i64, ptr }, ptr %t188, !tbaa !27
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t193 = call i1 @compiler_2fbuild_2eclaim(ptr %v6, ptr %v1, { i64, ptr } %t189, ptr %t190)
  store i1 %t193, ptr %l87
  br label %bb42
bb41:
  store i1 false, ptr %l84, !tbaa !21
  br label %bb43
bb42:
  %t194 = load i1, ptr %l87, !tbaa !21
  %t195 = xor i1 %t194, true
  store i1 %t195, ptr %l84, !tbaa !21
  br label %bb43
bb43:
  %t197 = load i1, ptr %l84, !tbaa !21
  br i1 %t197, label %bb44, label %bb45
bb44:
  %t198 = load ptr, ptr %l1, !tbaa !29
  %t200 = getelementptr %"compiler/build:compiles", ptr %t198, i32 0, i32 7
  %t201 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t200, i64 %t201)
  br label %bb46
bb45:
  br label %bb47
bb46:
  %t204 = load ptr, ptr %lp9
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t207 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t205, 1
  store { i32, { i64, ptr } } %t207, ptr %rv
  br label %ret
bb47:
  %t208 = load ptr, ptr %lp9
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 0
  %t213 = sub i64 %t211, 2
  store i64 %t213, ptr %l95, !tbaa !24
  %t214 = load ptr, ptr %lp9
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t215, 0
  store i64 %t216, ptr %l96, !tbaa !24
  %t217 = icmp sge i64 0, 0
  br i1 %t217, label %bb48, label %bb49
bb48:
  %t219 = load i64, ptr %l95, !tbaa !24
  %t220 = icmp sle i64 0, %t219
  br i1 %t220, label %bb50, label %bb51
bb49:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb50:
  %t222 = load i64, ptr %l95, !tbaa !24
  %t223 = load i64, ptr %l96, !tbaa !24
  %t224 = icmp sle i64 %t222, %t223
  br i1 %t224, label %bb52, label %bb53
bb51:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb52:
  %t226 = load ptr, ptr %lp9
  %t227 = getelementptr { i64, ptr }, ptr %t226, i32 0, i32 1
  %t228 = load ptr, ptr %t227, !tbaa !27
  %t229 = load i64, ptr %l95, !tbaa !24
  %t230 = getelementptr i8, ptr %t228, i64 0
  %t231 = sub i64 %t229, 0
  %t232 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t230, 1
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = extractvalue { i64, ptr } %t233, 0
  %t237 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t238 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t239 = add i64 %t236, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t235, i64 %t236)
  %t241 = getelementptr i8, ptr %t240, i64 %t236
  call void @olang_textcopy(ptr %t241, ptr %t237, i64 %t238)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  store { i64, ptr } %t243, ptr %l11, !tbaa !27
  %t245 = load ptr, ptr %l0, !tbaa !29
  %t247 = getelementptr %"compiler/build:Config", ptr %t245, i32 0, i32 0
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !27
  store { i64, ptr } %t248, ptr %l103, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t249, ptr %l104, !tbaa !27
  %t250 = load i32, ptr %l3
  %t252 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %t250)
  store { i64, ptr } %t252, ptr %l106
  br label %bb54
bb53:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb54:
  %t253 = load ptr, ptr %l0, !tbaa !29
  %t255 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t253)
  store { i64, ptr } %t255, ptr %l108
  br label %bb55
bb55:
  %t256 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t257 = extractvalue { i64, ptr } %t256, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t262 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = add i64 %t261, %t264
  %t266 = load { i64, ptr }, ptr %l106, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 1
  %t272 = extractvalue { i64, ptr } %t270, 0
  %t273 = add i64 %t269, %t272
  %t274 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d138, i32 0, i32 1) }, 1
  %t275 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d138, i32 0, i32 1) }, 0
  %t276 = add i64 %t273, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t257, i64 %t258)
  %t278 = getelementptr i8, ptr %t277, i64 %t258
  call void @olang_textcopy(ptr %t278, ptr %t259, i64 %t260)
  %t279 = getelementptr i8, ptr %t278, i64 %t260
  call void @olang_textcopy(ptr %t279, ptr %t263, i64 %t264)
  %t280 = getelementptr i8, ptr %t279, i64 %t264
  call void @olang_textcopy(ptr %t280, ptr %t267, i64 %t268)
  %t281 = getelementptr i8, ptr %t280, i64 %t268
  call void @olang_textcopy(ptr %t281, ptr %t271, i64 %t272)
  %t282 = getelementptr i8, ptr %t281, i64 %t272
  call void @olang_textcopy(ptr %t282, ptr %t274, i64 %t275)
  %t283 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t277, 1
  store { i64, ptr } %t284, ptr %l12, !tbaa !27
  %t286 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t288 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t286, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d139, i32 0, i32 1) })
  store i1 %t288, ptr %l111
  br label %bb56
bb56:
  %t289 = load i1, ptr %l111, !tbaa !21
  %t290 = xor i1 %t289, true
  br i1 %t290, label %bb57, label %bb58
bb57:
  %t292 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t292, ptr %l114, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t294 = extractvalue { i64, ptr } %t293, 0
  store i64 %t294, ptr %l115, !tbaa !24
  %t295 = load i64, ptr %l115, !tbaa !24
  %t296 = mul i64 %t295, 1
  %t297 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t296)
  %t298 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  store { i64, ptr } %t299, ptr %l116, !tbaa !27
  %t300 = getelementptr { i64, ptr }, ptr %l116, i32 0, i32 1
  %t301 = load ptr, ptr %t300, !tbaa !27
  %t302 = getelementptr { i64, ptr }, ptr %l114, i32 0, i32 1
  %t303 = load ptr, ptr %t302, !tbaa !27
  %t304 = load i64, ptr %l115, !tbaa !24
  %t305 = mul i64 %t304, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t301, ptr %t303, i64 %t305, i1 false)
  %t306 = load { i64, ptr }, ptr %l116, !tbaa !27
  %t307 = load ptr, ptr %l1, !tbaa !29
  %t309 = getelementptr %"compiler/build:compiles", ptr %t307, i32 0, i32 3
  %t313 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v1, ptr %s0, ptr %t309, { i64, ptr } %t306)
  store i1 %t313, ptr %l120
  br label %bb59
bb58:
  store i1 false, ptr %l113, !tbaa !21
  br label %bb60
bb59:
  %t314 = load i1, ptr %l120, !tbaa !21
  %t315 = xor i1 %t314, true
  store i1 %t315, ptr %l113, !tbaa !21
  br label %bb60
bb60:
  %t317 = load i1, ptr %l113, !tbaa !21
  br i1 %t317, label %bb61, label %bb62
bb61:
  %t318 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t318, ptr %l122, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t320 = extractvalue { i64, ptr } %t319, 0
  %t321 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t322 = extractvalue { i64, ptr } %t321, 0
  store i64 %t322, ptr %l124, !tbaa !24
  %t324 = load i64, ptr %l124, !tbaa !24
  %t325 = icmp eq i64 %t320, %t324
  br i1 %t325, label %bb63, label %bb64
bb62:
  br label %bb66
bb63:
  %t327 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t328 = load ptr, ptr %t327, !tbaa !27
  %t329 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t330 = load ptr, ptr %t329, !tbaa !27
  %t331 = load i64, ptr %l124, !tbaa !24
  %t332 = mul i64 %t331, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t328, ptr %t330, i64 %t332, i1 false)
  br label %bb65
bb64:
  %t333 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  store i64 %t334, ptr %l126, !tbaa !24
  %t335 = load i64, ptr %l126, !tbaa !24
  %t336 = mul i64 %t335, 1
  %t337 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t336)
  %t338 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  store { i64, ptr } %t339, ptr %l127, !tbaa !27
  %t340 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = load i64, ptr %l126, !tbaa !24
  %t345 = mul i64 %t344, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t341, ptr %t343, i64 %t345, i1 false)
  %t346 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t346, ptr %l11, !tbaa !27
  br label %bb65
bb65:
  br label %bb66
bb66:
  %t347 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t347, 0
  %t351 = sub i64 %t349, 3
  store i64 %t351, ptr %l130, !tbaa !24
  %t352 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t352, 0
  store i64 %t353, ptr %l131, !tbaa !24
  %t354 = icmp sge i64 0, 0
  br i1 %t354, label %bb67, label %bb68
bb67:
  %t356 = load i64, ptr %l130, !tbaa !24
  %t357 = icmp sle i64 0, %t356
  br i1 %t357, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb69:
  %t359 = load i64, ptr %l130, !tbaa !24
  %t360 = load i64, ptr %l131, !tbaa !24
  %t361 = icmp sle i64 %t359, %t360
  br i1 %t361, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb71:
  %t363 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = load i64, ptr %l130, !tbaa !24
  %t366 = getelementptr i8, ptr %t364, i64 0
  %t367 = sub i64 %t365, 0
  %t368 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t369 = insertvalue { i64, ptr } %t368, ptr %t366, 1
  store { i64, ptr } %t369, ptr %l135, !tbaa !27
  %t370 = call i32 @getpid()
  store i32 %t370, ptr %l136
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb73:
  %t371 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t371, 1
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t374 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t376 = add i64 %t373, %t375
  %t377 = load i32, ptr %l136, !tbaa !23
  %t378 = sext i32 %t377 to i64
  %t379 = call i64 @__olang_fmt_i64(ptr null, i64 %t378)
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t384 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t383)
  call void @olang_textcopy(ptr %t384, ptr %t372, i64 %t373)
  %t385 = getelementptr i8, ptr %t384, i64 %t373
  call void @olang_textcopy(ptr %t385, ptr %t374, i64 %t375)
  %t386 = getelementptr i8, ptr %t385, i64 %t375
  %t387 = call i64 @__olang_fmt_i64(ptr %t386, i64 %t378)
  %t388 = getelementptr i8, ptr %t386, i64 %t379
  call void @olang_textcopy(ptr %t388, ptr %t381, i64 %t382)
  %t389 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t384, 1
  store { i64, ptr } %t390, ptr %l14, !tbaa !27
  %t392 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t393 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t397 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v3, { i64, ptr } %t392, { i64, ptr } %t393)
  store i32 %t397, ptr %l141
  %t398 = icmp ne i32 %t397, 0
  br i1 %t398, label %bb75, label %ok.399
ok.399:
  br label %bb74
bb74:
  br label %bb81
bb75:
  %t400 = load i32, ptr %l141, !tbaa !23
  %t401 = ashr i32 %t400, 16
  %t403 = icmp eq i32 %t401, 1
  br i1 %t403, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  %t405 = load i32, ptr %l141, !tbaa !23
  %t406 = lshr i32 %t405, 16
  %t407 = and i32 %t405, 65535
  %t408 = icmp eq i32 %t406, 1
  %t409 = select i1 %t408, i32 0, i32 0
  %t410 = icmp eq i32 %t405, 0
  %t411 = shl i32 %t409, 16
  %t412 = or i32 %t411, %t407
  %t413 = select i1 %t410, i32 0, i32 %t412
  call void @__olang_scope_close(ptr %s0)
  %t415 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t413, 0
  store { i32, { i64, ptr } } %t415, ptr %rv
  br label %ret
bb78:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t416 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t416, ptr %l145, !tbaa !27
  %t417 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s11)
  store %"compiler/msgs:Msg" %t417, ptr %l146
  br label %bb79
bb79:
  %t418 = load ptr, ptr %l5, !tbaa !29
  %t419 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t420 = load %"compiler/msgs:Msg", ptr %l146
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s11, ptr %v4, { i64, ptr } %t419, %"compiler/msgs:Msg" %t420, ptr %t418)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t423 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t423, ptr %rv
  br label %ret
bb81:
  %t424 = load ptr, ptr %l0, !tbaa !29
  %t426 = getelementptr %"compiler/build:Config", ptr %t424, i32 0, i32 1
  %t427 = load { i64, ptr }, ptr %t426, !tbaa !27
  %t429 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t427, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d142, i32 0, i32 1) })
  store i1 %t429, ptr %l151
  br label %bb82
bb82:
  %t430 = load i1, ptr %l151, !tbaa !21
  br i1 %t430, label %bb83, label %bb84
bb83:
  store %olang.scope zeroinitializer, ptr %s12
  %t431 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t432 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t435 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t431, { i64, ptr } %t432)
  store i32 %t435, ptr %l154
  %t436 = icmp ne i32 %t435, 0
  br i1 %t436, label %bb86, label %ok.437
ok.437:
  br label %bb85
bb84:
  br label %bb93
bb85:
  br label %bb90
bb86:
  %t438 = load i32, ptr %l154, !tbaa !23
  %t439 = ashr i32 %t438, 16
  %t441 = icmp eq i32 %t439, 1
  br i1 %t441, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  %t443 = load i32, ptr %l154, !tbaa !23
  %t444 = lshr i32 %t443, 16
  %t445 = and i32 %t443, 65535
  %t446 = icmp eq i32 %t444, 1
  %t447 = select i1 %t446, i32 0, i32 0
  %t448 = icmp eq i32 %t443, 0
  %t449 = shl i32 %t447, 16
  %t450 = or i32 %t449, %t445
  %t451 = select i1 %t448, i32 0, i32 %t450
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t453 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t451, 0
  store { i32, { i64, ptr } } %t453, ptr %rv
  br label %ret
bb89:
  call void @__olang_ert_req_clear()
  br label %bb90
bb90:
  %t454 = load ptr, ptr %l5, !tbaa !29
  store ptr %t454, ptr %l158, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t455
  %t456 = getelementptr { i64, [3 x i64] }, ptr %t455, i32 0, i32 0
  store i64 0, ptr %t456
  %t457 = load { i64, [3 x i64] }, ptr %t455
  store { i64, [3 x i64] } %t457, ptr %l159
  %t458 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t460 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %s0, ptr %s12, { i64, ptr } %t458)
  store %"compiler/msgs:Msg" %t460, ptr %l161
  br label %bb91
bb91:
  %t461 = load ptr, ptr %l158, !tbaa !29
  %t462 = load { i64, [3 x i64] }, ptr %l159
  %t463 = load %"compiler/msgs:Msg", ptr %l161
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s12, ptr %t461, { i64, [3 x i64] } %t462, %"compiler/msgs:Msg" %t463)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t465 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t465, ptr %rv
  br label %ret
bb93:
  %t466 = load ptr, ptr %lp9
  %t467 = load { i64, ptr }, ptr %t466, !tbaa !27
  store { i64, ptr } %t467, ptr %l163, !tbaa !27
  %t468 = call i32 @getpid()
  store i32 %t468, ptr %l164
  br label %bb94
bb94:
  %t469 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t470 = extractvalue { i64, ptr } %t469, 1
  %t471 = extractvalue { i64, ptr } %t469, 0
  %t472 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 1
  %t473 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d143, i32 0, i32 1) }, 0
  %t474 = add i64 %t471, %t473
  %t475 = load i32, ptr %l164, !tbaa !23
  %t476 = sext i32 %t475 to i64
  %t477 = call i64 @__olang_fmt_i64(ptr null, i64 %t476)
  %t478 = add i64 %t474, %t477
  %t479 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t480 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t481 = add i64 %t478, %t480
  %t482 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t481)
  call void @olang_textcopy(ptr %t482, ptr %t470, i64 %t471)
  %t483 = getelementptr i8, ptr %t482, i64 %t471
  call void @olang_textcopy(ptr %t483, ptr %t472, i64 %t473)
  %t484 = getelementptr i8, ptr %t483, i64 %t473
  %t485 = call i64 @__olang_fmt_i64(ptr %t484, i64 %t476)
  %t486 = getelementptr i8, ptr %t484, i64 %t477
  call void @olang_textcopy(ptr %t486, ptr %t479, i64 %t480)
  %t487 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t488 = insertvalue { i64, ptr } %t487, ptr %t482, 1
  store { i64, ptr } %t488, ptr %l15, !tbaa !27
  %t490 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t490, ptr %l166
  br label %bb95
bb95:
  %t491 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l166
  %t492 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t491, ptr %t492
  store ptr %t492, ptr %l16, !tbaa !29
  %t494 = load ptr, ptr %l16, !tbaa !29
  %t495 = load ptr, ptr %l0, !tbaa !29
  %t497 = getelementptr %"compiler/build:Config", ptr %t495, i32 0, i32 1
  %t498 = load { i64, ptr }, ptr %t497, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t498, 1
  %t501 = extractvalue { i64, ptr } %t498, 0
  %t502 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t501)
  call void @olang_textcopy(ptr %t502, ptr %t500, i64 %t501)
  %t503 = insertvalue { i64, ptr } undef, i64 %t501, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t502, 1
  %t506 = extractvalue { i64, ptr } %t504, 0
  %t507 = extractvalue { i64, ptr } %t504, 1
  %t508 = mul i64 %t506, 1
  %t509 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t508)
  call void @llvm.memcpy.p0.p0.i64(ptr %t509, ptr %t507, i64 %t508, i1 false)
  %t510 = insertvalue { i64, ptr } undef, i64 %t506, 0
  %t511 = insertvalue { i64, ptr } %t510, ptr %t509, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t494, { i64, ptr } %t511)
  br label %bb96
bb96:
  store ptr %l8, ptr %l17, !tbaa !29
  store i64 0, ptr %l18, !tbaa !24
  br label %bb97
bb97:
  store %olang.scope zeroinitializer, ptr %s17
  %t515 = load ptr, ptr %l17, !tbaa !29
  %t516 = load i64, ptr %l18, !tbaa !24
  %t519 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t515, i64 %t516)
  %t520 = extractvalue { i32, { i64, ptr } } %t519, 1
  %t521 = extractvalue { i32, { i64, ptr } } %t519, 0
  store i32 %t521, ptr %l178
  %t522 = icmp ne i32 %t521, 0
  br i1 %t522, label %bb99, label %ok.523
ok.523:
  store { i64, ptr } %t520, ptr %l177
  br label %bb98
bb98:
  %t524 = load { i64, ptr }, ptr %l177, !tbaa !27
  store { i64, ptr } %t524, ptr %l174, !tbaa !27
  br label %bb103
bb99:
  %t525 = load i32, ptr %l178, !tbaa !23
  %t526 = ashr i32 %t525, 16
  %t528 = icmp eq i32 %t526, 1
  br i1 %t528, label %bb100, label %bb101
bb100:
  br label %bb102
bb101:
  %t530 = load i32, ptr %l178, !tbaa !23
  %t531 = lshr i32 %t530, 16
  %t532 = and i32 %t530, 65535
  %t533 = icmp eq i32 %t531, 1
  %t534 = select i1 %t533, i32 0, i32 0
  %t535 = icmp eq i32 %t530, 0
  %t536 = shl i32 %t534, 16
  %t537 = or i32 %t536, %t532
  %t538 = select i1 %t535, i32 0, i32 %t537
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t540 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t538, 0
  store { i32, { i64, ptr } } %t540, ptr %rv
  br label %ret
bb102:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s17)
  br label %bb112
bb103:
  %t541 = load { i64, ptr }, ptr %l174, !tbaa !27
  store { i64, ptr } %t541, ptr %l19, !tbaa !27
  %t542 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t544 = extractvalue { i64, ptr } %t542, 0
  store i64 %t544, ptr %l20, !tbaa !24
  store i64 0, ptr %l21, !tbaa !24
  br label %bb104
bb104:
  store %olang.scope zeroinitializer, ptr %s18
  %t546 = load i64, ptr %l21, !tbaa !24
  %t547 = load i64, ptr %l20, !tbaa !24
  %t550 = icmp slt i64 %t546, %t547
  %t552 = xor i1 %t550, true
  br i1 %t552, label %bb105, label %bb106
bb105:
  call void @__olang_scope_close(ptr %s18)
  br label %bb110
bb106:
  br label %bb107
bb107:
  %t554 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t554, ptr %l188, !tbaa !27
  %t555 = load i64, ptr %l21, !tbaa !24
  %t557 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t558 = load ptr, ptr %t557, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %t558, i64 %t555
  %t560 = load { i64, ptr }, ptr %t559, !tbaa !37
  %t562 = load ptr, ptr %l16, !tbaa !29
  %t565 = extractvalue { i64, ptr } %t560, 1
  %t566 = extractvalue { i64, ptr } %t560, 0
  %t567 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t566)
  call void @olang_textcopy(ptr %t567, ptr %t565, i64 %t566)
  %t568 = insertvalue { i64, ptr } undef, i64 %t566, 0
  %t569 = insertvalue { i64, ptr } %t568, ptr %t567, 1
  %t571 = extractvalue { i64, ptr } %t569, 0
  %t572 = extractvalue { i64, ptr } %t569, 1
  %t573 = mul i64 %t571, 1
  %t574 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t573)
  call void @llvm.memcpy.p0.p0.i64(ptr %t574, ptr %t572, i64 %t573, i1 false)
  %t575 = insertvalue { i64, ptr } undef, i64 %t571, 0
  %t576 = insertvalue { i64, ptr } %t575, ptr %t574, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t562, { i64, ptr } %t576)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s18)
  br label %bb109
bb109:
  %t579 = load i64, ptr %l21, !tbaa !24
  %t581 = add i64 %t579, 1
  store i64 %t581, ptr %l21, !tbaa !24
  br label %bb104
bb110:
  %t583 = load i64, ptr %l18, !tbaa !24
  %t584 = load i64, ptr %l20, !tbaa !24
  %t587 = add i64 %t583, %t584
  store i64 %t587, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb111
bb111:
  br label %bb97
bb112:
  %t589 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t589, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d145, i32 0, i32 1) })
  br label %bb113
bb113:
  %t591 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t591, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d146, i32 0, i32 1) })
  br label %bb114
bb114:
  %t593 = load ptr, ptr %l16, !tbaa !29
  %t594 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t596 = extractvalue { i64, ptr } %t594, 1
  %t597 = extractvalue { i64, ptr } %t594, 0
  %t598 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t597)
  call void @olang_textcopy(ptr %t598, ptr %t596, i64 %t597)
  %t599 = insertvalue { i64, ptr } undef, i64 %t597, 0
  %t600 = insertvalue { i64, ptr } %t599, ptr %t598, 1
  %t602 = extractvalue { i64, ptr } %t600, 0
  %t603 = extractvalue { i64, ptr } %t600, 1
  %t604 = mul i64 %t602, 1
  %t605 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t604)
  call void @llvm.memcpy.p0.p0.i64(ptr %t605, ptr %t603, i64 %t604, i1 false)
  %t606 = insertvalue { i64, ptr } undef, i64 %t602, 0
  %t607 = insertvalue { i64, ptr } %t606, ptr %t605, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t593, { i64, ptr } %t607)
  br label %bb115
bb115:
  %t610 = load ptr, ptr %l16, !tbaa !29
  %t611 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t613 = extractvalue { i64, ptr } %t611, 1
  %t614 = extractvalue { i64, ptr } %t611, 0
  %t615 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t614)
  call void @olang_textcopy(ptr %t615, ptr %t613, i64 %t614)
  %t616 = insertvalue { i64, ptr } undef, i64 %t614, 0
  %t617 = insertvalue { i64, ptr } %t616, ptr %t615, 1
  %t619 = extractvalue { i64, ptr } %t617, 0
  %t620 = extractvalue { i64, ptr } %t617, 1
  %t621 = mul i64 %t619, 1
  %t622 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t621)
  call void @llvm.memcpy.p0.p0.i64(ptr %t622, ptr %t620, i64 %t621, i1 false)
  %t623 = insertvalue { i64, ptr } undef, i64 %t619, 0
  %t624 = insertvalue { i64, ptr } %t623, ptr %t622, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t610, { i64, ptr } %t624)
  br label %bb116
bb116:
  %t627 = load ptr, ptr %l1, !tbaa !29
  %t629 = getelementptr %"compiler/build:compiles", ptr %t627, i32 0, i32 0
  store ptr %t629, ptr %l211, !tbaa !29
  %t630 = load ptr, ptr %l16, !tbaa !29
  %t632 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v1, ptr %v1, ptr %t630)
  store { i64, ptr } %t632, ptr %l213
  br label %bb117
bb117:
  %t633 = load ptr, ptr %l211, !tbaa !29
  %t634 = load { i64, ptr }, ptr %l213, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v1, ptr %v1, ptr %t633, { i64, ptr } %t634)
  br label %bb118
bb118:
  %t635 = load ptr, ptr %l1, !tbaa !29
  %t637 = getelementptr %"compiler/build:compiles", ptr %t635, i32 0, i32 1
  %t638 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t640 = extractvalue { i64, ptr } %t638, 1
  %t641 = extractvalue { i64, ptr } %t638, 0
  %t642 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t641)
  call void @olang_textcopy(ptr %t642, ptr %t640, i64 %t641)
  %t643 = insertvalue { i64, ptr } undef, i64 %t641, 0
  %t644 = insertvalue { i64, ptr } %t643, ptr %t642, 1
  %t646 = extractvalue { i64, ptr } %t644, 0
  %t647 = extractvalue { i64, ptr } %t644, 1
  %t648 = mul i64 %t646, 1
  %t649 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t648)
  call void @llvm.memcpy.p0.p0.i64(ptr %t649, ptr %t647, i64 %t648, i1 false)
  %t650 = insertvalue { i64, ptr } undef, i64 %t646, 0
  %t651 = insertvalue { i64, ptr } %t650, ptr %t649, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t637, { i64, ptr } %t651)
  br label %bb119
bb119:
  %t654 = load ptr, ptr %l1, !tbaa !29
  %t656 = getelementptr %"compiler/build:compiles", ptr %t654, i32 0, i32 2
  %t657 = load ptr, ptr %lp9
  %t658 = load { i64, ptr }, ptr %t657, !tbaa !27
  %t660 = extractvalue { i64, ptr } %t658, 1
  %t661 = extractvalue { i64, ptr } %t658, 0
  %t662 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t661)
  call void @olang_textcopy(ptr %t662, ptr %t660, i64 %t661)
  %t663 = insertvalue { i64, ptr } undef, i64 %t661, 0
  %t664 = insertvalue { i64, ptr } %t663, ptr %t662, 1
  %t666 = extractvalue { i64, ptr } %t664, 0
  %t667 = extractvalue { i64, ptr } %t664, 1
  %t668 = mul i64 %t666, 1
  %t669 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t668)
  call void @llvm.memcpy.p0.p0.i64(ptr %t669, ptr %t667, i64 %t668, i1 false)
  %t670 = insertvalue { i64, ptr } undef, i64 %t666, 0
  %t671 = insertvalue { i64, ptr } %t670, ptr %t669, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t656, { i64, ptr } %t671)
  br label %bb120
bb120:
  %t674 = load ptr, ptr %l1, !tbaa !29
  %t676 = getelementptr %"compiler/build:compiles", ptr %t674, i32 0, i32 3
  %t677 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t679 = extractvalue { i64, ptr } %t677, 1
  %t680 = extractvalue { i64, ptr } %t677, 0
  %t681 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t680)
  call void @olang_textcopy(ptr %t681, ptr %t679, i64 %t680)
  %t682 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t683 = insertvalue { i64, ptr } %t682, ptr %t681, 1
  %t685 = extractvalue { i64, ptr } %t683, 0
  %t686 = extractvalue { i64, ptr } %t683, 1
  %t687 = mul i64 %t685, 1
  %t688 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t687)
  call void @llvm.memcpy.p0.p0.i64(ptr %t688, ptr %t686, i64 %t687, i1 false)
  %t689 = insertvalue { i64, ptr } undef, i64 %t685, 0
  %t690 = insertvalue { i64, ptr } %t689, ptr %t688, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t676, { i64, ptr } %t690)
  br label %bb121
bb121:
  %t693 = load ptr, ptr %l1, !tbaa !29
  %t695 = getelementptr %"compiler/build:compiles", ptr %t693, i32 0, i32 4
  %t696 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t698 = extractvalue { i64, ptr } %t696, 1
  %t699 = extractvalue { i64, ptr } %t696, 0
  %t700 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t699)
  call void @olang_textcopy(ptr %t700, ptr %t698, i64 %t699)
  %t701 = insertvalue { i64, ptr } undef, i64 %t699, 0
  %t702 = insertvalue { i64, ptr } %t701, ptr %t700, 1
  %t704 = extractvalue { i64, ptr } %t702, 0
  %t705 = extractvalue { i64, ptr } %t702, 1
  %t706 = mul i64 %t704, 1
  %t707 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t706)
  call void @llvm.memcpy.p0.p0.i64(ptr %t707, ptr %t705, i64 %t706, i1 false)
  %t708 = insertvalue { i64, ptr } undef, i64 %t704, 0
  %t709 = insertvalue { i64, ptr } %t708, ptr %t707, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t695, { i64, ptr } %t709)
  br label %bb122
bb122:
  %t712 = load ptr, ptr %l1, !tbaa !29
  %t714 = getelementptr %"compiler/build:compiles", ptr %t712, i32 0, i32 5
  %t715 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t717 = extractvalue { i64, ptr } %t715, 0
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t714, i64 %t717)
  br label %bb123
bb123:
  %t720 = load ptr, ptr %lp9
  %t721 = load { i64, ptr }, ptr %t720, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t723 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t721, 1
  store { i32, { i64, ptr } } %t723, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 12
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 12
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call i64 @sysconf(i32 84)
  store i64 %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  store i64 1, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l10, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/build:Unit"
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %l27 = alloca i1
  %l39 = alloca i64
  %l41 = alloca { i64, ptr }
  %l44 = alloca %"compiler/build:Unit"
  %l47 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l13
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l13, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_93685d01cca04f82_bac91b93b7acf8e6)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb7:
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/build:Unit", ptr %t37, i64 %t34
  %t39 = load %"compiler/build:Unit", ptr %t38
  store %"compiler/build:Unit" %t39, ptr %l6
  %t41 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t42 = load i32, ptr %t41
  %t44 = trunc i64 1 to i32
  %t45 = icmp eq i32 %t42, %t44
  br i1 %t45, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb14
bb13:
  %t47 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t48 = load i32, ptr %t47
  %t50 = trunc i64 2 to i32
  %t51 = icmp eq i32 %t48, %t50
  store i1 %t51, ptr %l27, !tbaa !21
  br label %bb14
bb14:
  %t53 = load i1, ptr %l27, !tbaa !21
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t54 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t57, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l5, !tbaa !24
  br label %bb8
bb19:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t67, %t68
  store i64 %t71, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb20:
  br label %bb1
bb21:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Program", ptr %t73, i32 0, i32 0
  %t77 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t75)
  store i64 %t77, ptr %l39
  br label %bb22
bb22:
  %t78 = load i64, ptr %l39, !tbaa !24
  %t79 = icmp sgt i64 %t78, 0
  br i1 %t79, label %bb23, label %bb24
bb23:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/build:Program", ptr %t81, i32 0, i32 0
  %t85 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t83, i64 0)
  store %"compiler/build:Unit" %t85, ptr %l44
  br label %bb25
bb24:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d147, i32 0, i32 1) }, ptr %l47, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t86, ptr %l41, !tbaa !27
  br label %bb26
bb25:
  %t88 = getelementptr %"compiler/build:Unit", ptr %l44, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l41, !tbaa !27
  br label %bb26
bb26:
  %t97 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l49, !tbaa !24
  %t99 = load i64, ptr %l49, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l50, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l49, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t110, ptr %l41, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l41, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [8 x i8]
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l28 = alloca i64
  %l31 = alloca i64
  %l54 = alloca i64
  %l62 = alloca %"std/prelude/text:StringBuilder"
  %l74 = alloca ptr
  %l75 = alloca i32
  %l76 = alloca i64
  %l77 = alloca i32
  %l78 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca i64
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Sha256", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = mul i64 %t4, 8
  store i64 %t7, ptr %l1, !tbaa !65
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d148, i32 0, i32 1) })
  br label %bb1
bb1:
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Sha256", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = icmp ne i64 %t14, 56
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s1, ptr %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d149, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb2
bb8:
  %t22 = insertvalue [8 x i8] undef, i8 0, 0
  %t23 = insertvalue [8 x i8] %t22, i8 0, 1
  %t24 = insertvalue [8 x i8] %t23, i8 0, 2
  %t25 = insertvalue [8 x i8] %t24, i8 0, 3
  %t26 = insertvalue [8 x i8] %t25, i8 0, 4
  %t27 = insertvalue [8 x i8] %t26, i8 0, 5
  %t28 = insertvalue [8 x i8] %t27, i8 0, 6
  %t29 = insertvalue [8 x i8] %t28, i8 0, 7
  store [8 x i8] %t29, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t31 = load i64, ptr %l4, !tbaa !24
  %t32 = load i64, ptr %l3, !tbaa !24
  %t35 = icmp sgt i64 %t31, %t32
  br i1 %t35, label %bb9, label %bb10
bb9:
  %t37 = load i64, ptr %l5, !tbaa !24
  %t39 = icmp sgt i64 %t37, 0
  br i1 %t39, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb14
bb11:
  %t41 = load i64, ptr %l4, !tbaa !24
  %t42 = load i64, ptr %l3, !tbaa !24
  %t45 = sub i64 %t41, %t42
  %t46 = load i64, ptr %l5, !tbaa !24
  %t49 = add i64 %t45, %t46
  %t51 = sub i64 %t49, 1
  %t52 = load i64, ptr %l5, !tbaa !24
  %t55 = sdiv i64 %t51, %t52
  store i64 %t55, ptr %l31, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb13
bb13:
  %t57 = load i64, ptr %l31, !tbaa !24
  store i64 %t57, ptr %l28, !tbaa !24
  br label %bb14
bb14:
  %t58 = load i64, ptr %l28, !tbaa !24
  store i64 %t58, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l6, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t67 = load i64, ptr %l3, !tbaa !24
  %t68 = load i64, ptr %l7, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = mul i64 %t68, %t69
  %t75 = add i64 %t67, %t72
  store i64 %t75, ptr %l8, !tbaa !24
  %t77 = load i64, ptr %l8, !tbaa !24
  %t78 = load i64, ptr %l1, !tbaa !65
  %t79 = load i64, ptr %l8, !tbaa !24
  %t81 = mul i64 8, %t79
  %t83 = sub i64 56, %t81
  store i64 %t83, ptr %l54, !tbaa !65
  %t86 = load i64, ptr %l54, !tbaa !65
  %t87 = load i64, ptr %l54, !tbaa !65
  %t88 = lshr i64 %t78, %t87
  %t90 = trunc i64 %t88 to i8
  %t93 = getelementptr [8 x i8], ptr %l2, i64 0, i64 %t77
  store i8 %t90, ptr %t93, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t94 = load i64, ptr %l7, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l7, !tbaa !24
  br label %bb15
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = insertvalue { i64, ptr } undef, i64 8, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %l2, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t98, { i64, ptr } %t101)
  br label %bb21
bb21:
  %t104 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t104, ptr %l62
  br label %bb22
bb22:
  %t105 = load %"std/prelude/text:StringBuilder", ptr %l62
  store %"std/prelude/text:StringBuilder" %t105, ptr %l9
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/build:Sha256", ptr %t106, i32 0, i32 0
  store ptr %t108, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t110 = load ptr, ptr %l10
  store i64 8, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t113 = load i64, ptr %l11, !tbaa !24
  %t114 = load i64, ptr %l12, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t121 = load ptr, ptr %l10
  %t122 = load i64, ptr %l11, !tbaa !24
  %t125 = getelementptr [8 x i32], ptr %t121, i64 0, i64 %t122
  %t126 = load i32, ptr %t125, !tbaa !84
  store ptr %l9, ptr %l74, !tbaa !29
  store i32 %t126, ptr %l75, !tbaa !64
  %t129 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 16)
  %t130 = extractvalue { i32, i64 } %t129, 1
  %t131 = extractvalue { i32, i64 } %t129, 0
  store i32 %t131, ptr %l77
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb28, label %ok.133
ok.133:
  store i64 %t130, ptr %l76
  br label %bb27
bb27:
  %t134 = load i32, ptr %l75, !tbaa !64
  %t135 = load i64, ptr %l76, !tbaa !24
  %t136 = call { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %s6, i32 %t134, i64 %t135)
  store { i64, ptr } %t136, ptr %l78
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58)
  unreachable
bb29:
  %t137 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t143, i64 8, i8 48)
  store { i64, ptr } %t145, ptr %l80
  br label %bb30
bb30:
  %t146 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 0
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = mul i64 %t147, 1
  %t150 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t149)
  call void @llvm.memcpy.p0.p0.i64(ptr %t150, ptr %t148, i64 %t149, i1 false)
  %t151 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t153 = load ptr, ptr %l74, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t153, { i64, ptr } %t152)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l11, !tbaa !24
  br label %bb23
bb33:
  %t160 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l9)
  store { i64, ptr } %t160, ptr %l85
  br label %bb34
bb34:
  %t161 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t161, ptr %l86, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l87, !tbaa !24
  %t164 = load i64, ptr %l87, !tbaa !24
  %t165 = mul i64 %t164, 1
  %t166 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t165)
  %t167 = insertvalue { i64, ptr } undef, i64 %t164, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l88, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = load i64, ptr %l87, !tbaa !24
  %t174 = mul i64 %t173, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t170, ptr %t172, i64 %t174, i1 false)
  %t175 = load { i64, ptr }, ptr %l88, !tbaa !27
  store { i64, ptr } %t175, ptr %l86, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t176 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t176, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = getelementptr %"compiler/build:Sha256", ptr %t6, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = add i64 %t8, %t9
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = getelementptr %"compiler/build:Sha256", ptr %t14, i32 0, i32 3
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Sha256", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/build:Sha256", ptr %t23, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp slt i64 %t26, 64
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l16, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/build:Sha256", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t53 = getelementptr %"compiler/build:Sha256", ptr %t39, i32 0, i32 1
  %t55 = getelementptr [64 x i8], ptr %t53, i64 0, i64 %t43
  store i8 %t50, ptr %t55, !tbaa !32
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l27, !tbaa !29
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = getelementptr %"compiler/build:Sha256", ptr %t57, i32 0, i32 2
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = add i64 %t59, 1
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t64 = getelementptr %"compiler/build:Sha256", ptr %t63, i32 0, i32 2
  store i64 %t61, ptr %t64, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Sha256", ptr %t69, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp slt i64 %t72, 64
  br i1 %t74, label %bb12, label %bb13
bb12:
  br label %ret
bb13:
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Sha256", ptr %t77, i32 0, i32 1
  %t81 = insertvalue { i64, ptr } undef, i64 64, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v0, ptr %t76, { i64, ptr } %t82, i64 0)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Sha256", ptr %t85, i32 0, i32 2
  store i64 0, ptr %t87, !tbaa !24
  br label %bb16
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load i64, ptr %l2, !tbaa !24
  %t90 = add i64 %t88, 64
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sle i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %t98, { i64, ptr } %t99, i64 %t100)
  br label %bb21
bb21:
  %t104 = load i64, ptr %l2, !tbaa !24
  %t106 = add i64 %t104, 64
  store i64 %t106, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  br label %bb17
bb23:
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load i64, ptr %l2, !tbaa !24
  %t109 = load i64, ptr %l3, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/build:Sha256", ptr %t117, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t121, ptr %l57, !tbaa !27
  %t122 = load i64, ptr %l2, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t122
  %t127 = load i8, ptr %t126, !tbaa !32
  %t130 = getelementptr %"compiler/build:Sha256", ptr %t116, i32 0, i32 1
  %t132 = getelementptr [64 x i8], ptr %t130, i64 0, i64 %t120
  store i8 %t127, ptr %t132, !tbaa !32
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l60, !tbaa !29
  %t134 = load ptr, ptr %l60, !tbaa !29
  %t135 = getelementptr %"compiler/build:Sha256", ptr %t134, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t138 = add i64 %t136, 1
  %t140 = load ptr, ptr %l60, !tbaa !29
  %t141 = getelementptr %"compiler/build:Sha256", ptr %t140, i32 0, i32 2
  store i64 %t138, ptr %t141, !tbaa !24
  %t142 = load i64, ptr %l2, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  br label %bb24
bb29:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i32
  %l38 = alloca [64 x i32]
  %l42 = alloca i64
  %l45 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l98 = alloca i64
  %l101 = alloca i64
  %l122 = alloca i32
  %l126 = alloca i32
  %l136 = alloca i32
  %l140 = alloca i32
  %l180 = alloca i64
  %l183 = alloca i64
  %l202 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i32
  %l207 = alloca i32
  %l229 = alloca i32
  %l231 = alloca i32
  %l232 = alloca i32
  %l234 = alloca i32
  %l263 = alloca ptr
  %l267 = alloca ptr
  %l271 = alloca ptr
  %l275 = alloca ptr
  %l279 = alloca ptr
  %l283 = alloca ptr
  %l287 = alloca ptr
  %l291 = alloca ptr
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 64
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [64 x i32], ptr %l38, i64 0, i64 %t5
  store i32 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l38, i64 256, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l45, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l45, !tbaa !24
  store i64 %t35, ptr %l42, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l42, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = mul i64 %t56, 4
  %t61 = add i64 %a2, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %l68, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = zext i8 %t70 to i32
  %t74 = shl i32 %t72, 24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l73, !tbaa !27
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = add i64 %t76, 1
  %t80 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 %t78
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = zext i8 %t83 to i32
  %t87 = shl i32 %t85, 16
  %t90 = or i32 %t74, %t87
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l80, !tbaa !27
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = add i64 %t92, 2
  %t96 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = zext i8 %t99 to i32
  %t103 = shl i32 %t101, 8
  %t106 = or i32 %t90, %t103
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l87, !tbaa !27
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = add i64 %t108, 3
  %t112 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = zext i8 %t115 to i32
  %t120 = or i32 %t106, %t117
  %t123 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t63
  store i32 %t120, ptr %t123, !tbaa !84
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  store i64 16, ptr %l11, !tbaa !24
  store i64 64, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb13, label %bb14
bb13:
  %t134 = load i64, ptr %l13, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb18
bb15:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l13, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb17
bb17:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb18
bb18:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t156 = load i64, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t164 = load i64, ptr %l11, !tbaa !24
  %t165 = load i64, ptr %l15, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l16, !tbaa !24
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = sub i64 %t174, 15
  %t178 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t176
  %t179 = load i32, ptr %t178, !tbaa !84
  %t181 = call i32 @compiler_2fbuild_2erotr(i32 %t179, i32 7)
  store i32 %t181, ptr %l122
  br label %bb23
bb23:
  %t182 = load i64, ptr %l16, !tbaa !24
  %t184 = sub i64 %t182, 15
  %t186 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t184
  %t187 = load i32, ptr %t186, !tbaa !84
  %t189 = call i32 @compiler_2fbuild_2erotr(i32 %t187, i32 18)
  store i32 %t189, ptr %l126
  br label %bb24
bb24:
  %t190 = load i32, ptr %l122, !tbaa !64
  %t191 = load i32, ptr %l126, !tbaa !64
  %t192 = xor i32 %t190, %t191
  %t193 = load i64, ptr %l16, !tbaa !24
  %t195 = sub i64 %t193, 15
  %t197 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t195
  %t198 = load i32, ptr %t197, !tbaa !84
  %t200 = lshr i32 %t198, 3
  %t203 = xor i32 %t192, %t200
  store i32 %t203, ptr %l17, !tbaa !64
  %t205 = load i64, ptr %l16, !tbaa !24
  %t207 = sub i64 %t205, 2
  %t209 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t207
  %t210 = load i32, ptr %t209, !tbaa !84
  %t212 = call i32 @compiler_2fbuild_2erotr(i32 %t210, i32 17)
  store i32 %t212, ptr %l136
  br label %bb25
bb25:
  %t213 = load i64, ptr %l16, !tbaa !24
  %t215 = sub i64 %t213, 2
  %t217 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t215
  %t218 = load i32, ptr %t217, !tbaa !84
  %t220 = call i32 @compiler_2fbuild_2erotr(i32 %t218, i32 19)
  store i32 %t220, ptr %l140
  br label %bb26
bb26:
  %t221 = load i32, ptr %l136, !tbaa !64
  %t222 = load i32, ptr %l140, !tbaa !64
  %t223 = xor i32 %t221, %t222
  %t224 = load i64, ptr %l16, !tbaa !24
  %t226 = sub i64 %t224, 2
  %t228 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t226
  %t229 = load i32, ptr %t228, !tbaa !84
  %t231 = lshr i32 %t229, 10
  %t234 = xor i32 %t223, %t231
  %t236 = load i64, ptr %l16, !tbaa !24
  %t237 = load i64, ptr %l16, !tbaa !24
  %t239 = sub i64 %t237, 16
  %t241 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t239
  %t242 = load i32, ptr %t241, !tbaa !84
  %t243 = load i32, ptr %l17, !tbaa !64
  %t246 = add i32 %t242, %t243
  %t247 = load i64, ptr %l16, !tbaa !24
  %t249 = sub i64 %t247, 7
  %t251 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t249
  %t252 = load i32, ptr %t251, !tbaa !84
  %t255 = add i32 %t246, %t252
  %t259 = add i32 %t255, %t234
  %t262 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t236
  store i32 %t259, ptr %t262, !tbaa !84
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t263 = load i64, ptr %l15, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l15, !tbaa !24
  br label %bb19
bb28:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/build:Sha256", ptr %t267, i32 0, i32 0
  %t270 = getelementptr [8 x i32], ptr %t269, i64 0, i64 0
  %t271 = load i32, ptr %t270, !tbaa !84
  store i32 %t271, ptr %l19, !tbaa !64
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/build:Sha256", ptr %t273, i32 0, i32 0
  %t276 = getelementptr [8 x i32], ptr %t275, i64 0, i64 1
  %t277 = load i32, ptr %t276, !tbaa !84
  store i32 %t277, ptr %l20, !tbaa !64
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/build:Sha256", ptr %t279, i32 0, i32 0
  %t282 = getelementptr [8 x i32], ptr %t281, i64 0, i64 2
  %t283 = load i32, ptr %t282, !tbaa !84
  store i32 %t283, ptr %l21, !tbaa !64
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/build:Sha256", ptr %t285, i32 0, i32 0
  %t288 = getelementptr [8 x i32], ptr %t287, i64 0, i64 3
  %t289 = load i32, ptr %t288, !tbaa !84
  store i32 %t289, ptr %l22, !tbaa !64
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/build:Sha256", ptr %t291, i32 0, i32 0
  %t294 = getelementptr [8 x i32], ptr %t293, i64 0, i64 4
  %t295 = load i32, ptr %t294, !tbaa !84
  store i32 %t295, ptr %l23, !tbaa !64
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/build:Sha256", ptr %t297, i32 0, i32 0
  %t300 = getelementptr [8 x i32], ptr %t299, i64 0, i64 5
  %t301 = load i32, ptr %t300, !tbaa !84
  store i32 %t301, ptr %l24, !tbaa !64
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/build:Sha256", ptr %t303, i32 0, i32 0
  %t306 = getelementptr [8 x i32], ptr %t305, i64 0, i64 6
  %t307 = load i32, ptr %t306, !tbaa !84
  store i32 %t307, ptr %l25, !tbaa !64
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/build:Sha256", ptr %t309, i32 0, i32 0
  %t312 = getelementptr [8 x i32], ptr %t311, i64 0, i64 7
  %t313 = load i32, ptr %t312, !tbaa !84
  store i32 %t313, ptr %l26, !tbaa !64
  store i64 0, ptr %l27, !tbaa !24
  store i64 64, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t315 = load i64, ptr %l28, !tbaa !24
  %t316 = load i64, ptr %l27, !tbaa !24
  %t319 = icmp sgt i64 %t315, %t316
  br i1 %t319, label %bb29, label %bb30
bb29:
  %t321 = load i64, ptr %l29, !tbaa !24
  %t323 = icmp sgt i64 %t321, 0
  br i1 %t323, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb34
bb31:
  %t325 = load i64, ptr %l28, !tbaa !24
  %t326 = load i64, ptr %l27, !tbaa !24
  %t329 = sub i64 %t325, %t326
  %t330 = load i64, ptr %l29, !tbaa !24
  %t333 = add i64 %t329, %t330
  %t335 = sub i64 %t333, 1
  %t336 = load i64, ptr %l29, !tbaa !24
  %t339 = sdiv i64 %t335, %t336
  store i64 %t339, ptr %l183, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb33
bb33:
  %t341 = load i64, ptr %l183, !tbaa !24
  store i64 %t341, ptr %l180, !tbaa !24
  br label %bb34
bb34:
  %t342 = load i64, ptr %l180, !tbaa !24
  store i64 %t342, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t343 = load i64, ptr %l31, !tbaa !24
  %t344 = load i64, ptr %l30, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t351 = load i64, ptr %l27, !tbaa !24
  %t352 = load i64, ptr %l31, !tbaa !24
  %t353 = load i64, ptr %l29, !tbaa !24
  %t356 = mul i64 %t352, %t353
  %t359 = add i64 %t351, %t356
  store i64 %t359, ptr %l32, !tbaa !24
  %t361 = load i32, ptr %l23, !tbaa !64
  %t363 = call i32 @compiler_2fbuild_2erotr(i32 %t361, i32 6)
  store i32 %t363, ptr %l202
  br label %bb39
bb39:
  %t364 = load i32, ptr %l23, !tbaa !64
  %t366 = call i32 @compiler_2fbuild_2erotr(i32 %t364, i32 11)
  store i32 %t366, ptr %l204
  br label %bb40
bb40:
  %t367 = load i32, ptr %l202, !tbaa !64
  %t368 = load i32, ptr %l204, !tbaa !64
  %t369 = xor i32 %t367, %t368
  store i32 %t369, ptr %l205, !tbaa !64
  %t370 = load i32, ptr %l23, !tbaa !64
  %t372 = call i32 @compiler_2fbuild_2erotr(i32 %t370, i32 25)
  store i32 %t372, ptr %l207
  br label %bb41
bb41:
  %t373 = load i32, ptr %l205, !tbaa !64
  %t374 = load i32, ptr %l207, !tbaa !64
  %t375 = xor i32 %t373, %t374
  %t377 = load i32, ptr %l23, !tbaa !64
  %t378 = load i32, ptr %l24, !tbaa !64
  %t381 = and i32 %t377, %t378
  %t382 = load i32, ptr %l23, !tbaa !64
  %t384 = xor i32 %t382, -1
  %t385 = load i32, ptr %l25, !tbaa !64
  %t388 = and i32 %t384, %t385
  %t391 = xor i32 %t381, %t388
  %t393 = load i32, ptr %l26, !tbaa !64
  %t397 = add i32 %t393, %t375
  %t401 = add i32 %t397, %t391
  %t402 = load i64, ptr %l32, !tbaa !24
  %t404 = getelementptr [64 x i32], ptr @G_2ecompiler_2fbuild_2eShaK, i64 0, i64 %t402
  %t405 = load i32, ptr %t404, !tbaa !84
  %t408 = add i32 %t401, %t405
  %t409 = load i64, ptr %l32, !tbaa !24
  %t411 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t409
  %t412 = load i32, ptr %t411, !tbaa !84
  %t415 = add i32 %t408, %t412
  store i32 %t415, ptr %l35, !tbaa !64
  %t417 = load i32, ptr %l19, !tbaa !64
  %t419 = call i32 @compiler_2fbuild_2erotr(i32 %t417, i32 2)
  store i32 %t419, ptr %l229
  br label %bb42
bb42:
  %t420 = load i32, ptr %l19, !tbaa !64
  %t422 = call i32 @compiler_2fbuild_2erotr(i32 %t420, i32 13)
  store i32 %t422, ptr %l231
  br label %bb43
bb43:
  %t423 = load i32, ptr %l229, !tbaa !64
  %t424 = load i32, ptr %l231, !tbaa !64
  %t425 = xor i32 %t423, %t424
  store i32 %t425, ptr %l232, !tbaa !64
  %t426 = load i32, ptr %l19, !tbaa !64
  %t428 = call i32 @compiler_2fbuild_2erotr(i32 %t426, i32 22)
  store i32 %t428, ptr %l234
  br label %bb44
bb44:
  %t429 = load i32, ptr %l232, !tbaa !64
  %t430 = load i32, ptr %l234, !tbaa !64
  %t431 = xor i32 %t429, %t430
  %t433 = load i32, ptr %l19, !tbaa !64
  %t434 = load i32, ptr %l20, !tbaa !64
  %t437 = and i32 %t433, %t434
  %t438 = load i32, ptr %l19, !tbaa !64
  %t439 = load i32, ptr %l21, !tbaa !64
  %t442 = and i32 %t438, %t439
  %t445 = xor i32 %t437, %t442
  %t446 = load i32, ptr %l20, !tbaa !64
  %t447 = load i32, ptr %l21, !tbaa !64
  %t450 = and i32 %t446, %t447
  %t453 = xor i32 %t445, %t450
  %t455 = load i32, ptr %l25, !tbaa !64
  store i32 %t455, ptr %l26, !tbaa !64
  %t457 = load i32, ptr %l24, !tbaa !64
  store i32 %t457, ptr %l25, !tbaa !64
  %t459 = load i32, ptr %l23, !tbaa !64
  store i32 %t459, ptr %l24, !tbaa !64
  %t461 = load i32, ptr %l22, !tbaa !64
  %t462 = load i32, ptr %l35, !tbaa !64
  %t465 = add i32 %t461, %t462
  store i32 %t465, ptr %l23, !tbaa !64
  %t467 = load i32, ptr %l21, !tbaa !64
  store i32 %t467, ptr %l22, !tbaa !64
  %t469 = load i32, ptr %l20, !tbaa !64
  store i32 %t469, ptr %l21, !tbaa !64
  %t471 = load i32, ptr %l19, !tbaa !64
  store i32 %t471, ptr %l20, !tbaa !64
  %t473 = load i32, ptr %l35, !tbaa !64
  %t477 = add i32 %t473, %t431
  %t481 = add i32 %t477, %t453
  store i32 %t481, ptr %l19, !tbaa !64
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  %t483 = load i64, ptr %l31, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l31, !tbaa !24
  br label %bb35
bb46:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l263, !tbaa !29
  %t488 = load ptr, ptr %l263, !tbaa !29
  %t489 = getelementptr %"compiler/build:Sha256", ptr %t488, i32 0, i32 0
  %t490 = getelementptr [8 x i32], ptr %t489, i64 0, i64 0
  %t491 = load i32, ptr %t490, !tbaa !84
  %t492 = load i32, ptr %l19, !tbaa !64
  %t495 = add i32 %t491, %t492
  %t497 = load ptr, ptr %l263, !tbaa !29
  %t498 = getelementptr %"compiler/build:Sha256", ptr %t497, i32 0, i32 0
  %t499 = getelementptr [8 x i32], ptr %t498, i64 0, i64 0
  store i32 %t495, ptr %t499, !tbaa !84
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l267, !tbaa !29
  %t501 = load ptr, ptr %l267, !tbaa !29
  %t502 = getelementptr %"compiler/build:Sha256", ptr %t501, i32 0, i32 0
  %t503 = getelementptr [8 x i32], ptr %t502, i64 0, i64 1
  %t504 = load i32, ptr %t503, !tbaa !84
  %t505 = load i32, ptr %l20, !tbaa !64
  %t508 = add i32 %t504, %t505
  %t510 = load ptr, ptr %l267, !tbaa !29
  %t511 = getelementptr %"compiler/build:Sha256", ptr %t510, i32 0, i32 0
  %t512 = getelementptr [8 x i32], ptr %t511, i64 0, i64 1
  store i32 %t508, ptr %t512, !tbaa !84
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l271, !tbaa !29
  %t514 = load ptr, ptr %l271, !tbaa !29
  %t515 = getelementptr %"compiler/build:Sha256", ptr %t514, i32 0, i32 0
  %t516 = getelementptr [8 x i32], ptr %t515, i64 0, i64 2
  %t517 = load i32, ptr %t516, !tbaa !84
  %t518 = load i32, ptr %l21, !tbaa !64
  %t521 = add i32 %t517, %t518
  %t523 = load ptr, ptr %l271, !tbaa !29
  %t524 = getelementptr %"compiler/build:Sha256", ptr %t523, i32 0, i32 0
  %t525 = getelementptr [8 x i32], ptr %t524, i64 0, i64 2
  store i32 %t521, ptr %t525, !tbaa !84
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l275, !tbaa !29
  %t527 = load ptr, ptr %l275, !tbaa !29
  %t528 = getelementptr %"compiler/build:Sha256", ptr %t527, i32 0, i32 0
  %t529 = getelementptr [8 x i32], ptr %t528, i64 0, i64 3
  %t530 = load i32, ptr %t529, !tbaa !84
  %t531 = load i32, ptr %l22, !tbaa !64
  %t534 = add i32 %t530, %t531
  %t536 = load ptr, ptr %l275, !tbaa !29
  %t537 = getelementptr %"compiler/build:Sha256", ptr %t536, i32 0, i32 0
  %t538 = getelementptr [8 x i32], ptr %t537, i64 0, i64 3
  store i32 %t534, ptr %t538, !tbaa !84
  %t539 = load ptr, ptr %l0, !tbaa !29
  store ptr %t539, ptr %l279, !tbaa !29
  %t540 = load ptr, ptr %l279, !tbaa !29
  %t541 = getelementptr %"compiler/build:Sha256", ptr %t540, i32 0, i32 0
  %t542 = getelementptr [8 x i32], ptr %t541, i64 0, i64 4
  %t543 = load i32, ptr %t542, !tbaa !84
  %t544 = load i32, ptr %l23, !tbaa !64
  %t547 = add i32 %t543, %t544
  %t549 = load ptr, ptr %l279, !tbaa !29
  %t550 = getelementptr %"compiler/build:Sha256", ptr %t549, i32 0, i32 0
  %t551 = getelementptr [8 x i32], ptr %t550, i64 0, i64 4
  store i32 %t547, ptr %t551, !tbaa !84
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l283, !tbaa !29
  %t553 = load ptr, ptr %l283, !tbaa !29
  %t554 = getelementptr %"compiler/build:Sha256", ptr %t553, i32 0, i32 0
  %t555 = getelementptr [8 x i32], ptr %t554, i64 0, i64 5
  %t556 = load i32, ptr %t555, !tbaa !84
  %t557 = load i32, ptr %l24, !tbaa !64
  %t560 = add i32 %t556, %t557
  %t562 = load ptr, ptr %l283, !tbaa !29
  %t563 = getelementptr %"compiler/build:Sha256", ptr %t562, i32 0, i32 0
  %t564 = getelementptr [8 x i32], ptr %t563, i64 0, i64 5
  store i32 %t560, ptr %t564, !tbaa !84
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l287, !tbaa !29
  %t566 = load ptr, ptr %l287, !tbaa !29
  %t567 = getelementptr %"compiler/build:Sha256", ptr %t566, i32 0, i32 0
  %t568 = getelementptr [8 x i32], ptr %t567, i64 0, i64 6
  %t569 = load i32, ptr %t568, !tbaa !84
  %t570 = load i32, ptr %l25, !tbaa !64
  %t573 = add i32 %t569, %t570
  %t575 = load ptr, ptr %l287, !tbaa !29
  %t576 = getelementptr %"compiler/build:Sha256", ptr %t575, i32 0, i32 0
  %t577 = getelementptr [8 x i32], ptr %t576, i64 0, i64 6
  store i32 %t573, ptr %t577, !tbaa !84
  %t578 = load ptr, ptr %l0, !tbaa !29
  store ptr %t578, ptr %l291, !tbaa !29
  %t579 = load ptr, ptr %l291, !tbaa !29
  %t580 = getelementptr %"compiler/build:Sha256", ptr %t579, i32 0, i32 0
  %t581 = getelementptr [8 x i32], ptr %t580, i64 0, i64 7
  %t582 = load i32, ptr %t581, !tbaa !84
  %t583 = load i32, ptr %l26, !tbaa !64
  %t586 = add i32 %t582, %t583
  %t588 = load ptr, ptr %l291, !tbaa !29
  %t589 = getelementptr %"compiler/build:Sha256", ptr %t588, i32 0, i32 0
  %t590 = getelementptr [8 x i32], ptr %t589, i64 0, i64 7
  store i32 %t586, ptr %t590, !tbaa !84
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l35 = alloca %"compiler/build:Unit"
  %l37 = alloca ptr
  %l45 = alloca %"compiler/build:Unit"
  %l51 = alloca ptr
  %l54 = alloca i32
  %l58 = alloca %"compiler/build:Unit"
  %l60 = alloca ptr
  %l66 = alloca %"compiler/build:Unit"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/build:stubFrontend", ptr %t2, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = getelementptr %"compiler/build:stubFrontend", ptr %t8, i32 0, i32 1
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/build:Config", ptr %t10, i32 0, i32 3
  %t14 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v2, ptr %s0, ptr %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d150, i32 0, i32 1) })
  store i1 %t14, ptr %l15
  br label %bb1
bb1:
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 3
  %t20 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v2, ptr %s0, ptr %s0, ptr %t18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d151, i32 0, i32 1) })
  store { i64, ptr } %t20, ptr %l19
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb5
bb4:
  %t21 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 2
  %t33 = getelementptr %"compiler/target:Target", ptr %t32, i32 0, i32 5
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d153, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d153, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %t34, 1
  %t39 = extractvalue { i64, ptr } %t34, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d154, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d154, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = getelementptr i8, ptr %t45, i64 %t39
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t44, 1
  store { i64, ptr } %t48, ptr %l7, !tbaa !27
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 2
  %t53 = getelementptr %"compiler/target:Target", ptr %t52, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t58 = extractvalue { i64, ptr } %t54, 1
  %t59 = extractvalue { i64, ptr } %t54, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = getelementptr i8, ptr %t65, i64 %t59
  call void @olang_textcopy(ptr %t66, ptr %t61, i64 %t62)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  store { i64, ptr } %t68, ptr %l8, !tbaa !27
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/build:Program", ptr %t70, i32 0, i32 0
  store ptr %t72, ptr %l28, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d157, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d157, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t83 = extractvalue { i64, ptr } %t29, 1
  %t84 = extractvalue { i64, ptr } %t29, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t90 = extractvalue { i64, ptr } %t75, 1
  %t91 = extractvalue { i64, ptr } %t75, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t77, i64 %t78)
  %t94 = getelementptr i8, ptr %t93, i64 %t78
  call void @olang_textcopy(ptr %t94, ptr %t79, i64 %t80)
  %t95 = getelementptr i8, ptr %t94, i64 %t80
  call void @olang_textcopy(ptr %t95, ptr %t83, i64 %t84)
  %t96 = getelementptr i8, ptr %t95, i64 %t84
  call void @olang_textcopy(ptr %t96, ptr %t86, i64 %t87)
  %t97 = getelementptr i8, ptr %t96, i64 %t87
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t93, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t109 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d159, i32 0, i32 1) }, i32 0, { i64, ptr } %t106)
  store %"compiler/build:Unit" %t109, ptr %l35
  br label %bb6
bb6:
  %t110 = load ptr, ptr %l28, !tbaa !29
  %t111 = load %"compiler/build:Unit", ptr %l35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t110, %"compiler/build:Unit" %t111)
  br label %bb7
bb7:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/build:Program", ptr %t112, i32 0, i32 0
  store ptr %t114, ptr %l37, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/build:stubFrontend", ptr %t116, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t115, 1
  %t123 = extractvalue { i64, ptr } %t115, 0
  %t124 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d160, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d160, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t134 = extractvalue { i64, ptr } %t120, 1
  %t135 = extractvalue { i64, ptr } %t120, 0
  %t136 = add i64 %t132, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t122, i64 %t123)
  %t138 = getelementptr i8, ptr %t137, i64 %t123
  call void @olang_textcopy(ptr %t138, ptr %t124, i64 %t125)
  %t139 = getelementptr i8, ptr %t138, i64 %t125
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t119)
  %t141 = getelementptr i8, ptr %t139, i64 %t128
  call void @olang_textcopy(ptr %t141, ptr %t130, i64 %t131)
  %t142 = getelementptr i8, ptr %t141, i64 %t131
  call void @olang_textcopy(ptr %t142, ptr %t134, i64 %t135)
  %t143 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t137, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t154 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d162, i32 0, i32 1) }, i32 0, { i64, ptr } %t151)
  store %"compiler/build:Unit" %t154, ptr %l45
  br label %bb8
bb8:
  %t155 = load ptr, ptr %l37, !tbaa !29
  %t156 = load %"compiler/build:Unit", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t155, %"compiler/build:Unit" %t156)
  br label %bb9
bb9:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = extractvalue { i64, ptr } %t157, 0
  %t162 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d164, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d164, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d166, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t175 = extractvalue { i64, ptr } %t158, 1
  %t176 = extractvalue { i64, ptr } %t158, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t160, i64 %t161)
  %t179 = getelementptr i8, ptr %t178, i64 %t161
  call void @olang_textcopy(ptr %t179, ptr %t162, i64 %t163)
  %t180 = getelementptr i8, ptr %t179, i64 %t163
  call void @olang_textcopy(ptr %t180, ptr %t165, i64 %t166)
  %t181 = getelementptr i8, ptr %t180, i64 %t166
  call void @olang_textcopy(ptr %t181, ptr %t168, i64 %t169)
  %t182 = getelementptr i8, ptr %t181, i64 %t169
  call void @olang_textcopy(ptr %t182, ptr %t171, i64 %t172)
  %t183 = getelementptr i8, ptr %t182, i64 %t172
  call void @olang_textcopy(ptr %t183, ptr %t175, i64 %t176)
  %t184 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t178, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l9, !tbaa !27
  %t194 = load ptr, ptr %l4, !tbaa !29
  %t196 = getelementptr %"compiler/build:Program", ptr %t194, i32 0, i32 0
  store ptr %t196, ptr %l51, !tbaa !29
  %t199 = trunc i64 1 to i32
  %t200 = icmp eq i32 %a2, %t199
  br i1 %t200, label %bb10, label %bb11
bb10:
  store i32 1, ptr %l54
  br label %bb12
bb11:
  store i32 2, ptr %l54
  br label %bb12
bb12:
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t205 = load i32, ptr %l54
  %t207 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d167, i32 0, i32 1) }, i32 %t205, { i64, ptr } %t204)
  store %"compiler/build:Unit" %t207, ptr %l58
  br label %bb13
bb13:
  %t208 = load ptr, ptr %l51, !tbaa !29
  %t209 = load %"compiler/build:Unit", ptr %l58
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t208, %"compiler/build:Unit" %t209)
  br label %bb14
bb14:
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = getelementptr %"compiler/build:Program", ptr %t210, i32 0, i32 0
  store ptr %t212, ptr %l60, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = extractvalue { i64, ptr } %t213, 0
  %t218 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d168, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d168, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t222 = extractvalue { i64, ptr } %t214, 1
  %t223 = extractvalue { i64, ptr } %t214, 0
  %t224 = add i64 %t220, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t216, i64 %t217)
  %t226 = getelementptr i8, ptr %t225, i64 %t217
  call void @olang_textcopy(ptr %t226, ptr %t218, i64 %t219)
  %t227 = getelementptr i8, ptr %t226, i64 %t219
  call void @olang_textcopy(ptr %t227, ptr %t222, i64 %t223)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t225, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = extractvalue { i64, ptr } %t229, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t239 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d169, i32 0, i32 1) }, i32 3, { i64, ptr } %t236)
  store %"compiler/build:Unit" %t239, ptr %l66
  br label %bb15
bb15:
  %t240 = load ptr, ptr %l60, !tbaa !29
  %t241 = load %"compiler/build:Unit", ptr %l66
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t240, %"compiler/build:Unit" %t241)
  br label %bb16
bb16:
  %t242 = load ptr, ptr %l4, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = extractvalue { i64, ptr } %t243, 0
  %t248 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d170, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d170, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t252 = extractvalue { i64, ptr } %t244, 1
  %t253 = extractvalue { i64, ptr } %t244, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t246, i64 %t247)
  %t256 = getelementptr i8, ptr %t255, i64 %t247
  call void @olang_textcopy(ptr %t256, ptr %t248, i64 %t249)
  %t257 = getelementptr i8, ptr %t256, i64 %t249
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t255, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = extractvalue { i64, ptr } %t259, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t269 = getelementptr %"compiler/build:Program", ptr %t242, i32 0, i32 1
  store { i64, ptr } %t266, ptr %t269, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d171, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d171, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a2, 1
  %t6 = extractvalue { i64, ptr } %a2, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d172, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d172, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t15, 1
  store { i32, { i64, ptr } } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a2, 0
  %t5 = trunc i64 %t3 to i32
  %t7 = insertvalue { i32, i32 } zeroinitializer, i32 %t5, 1
  store { i32, i32 } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @compiler_2fbuild_2efileError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %l11 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  %t19 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/msgs:Msg" %a1)
  store i64 %t19, ptr %l11
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d174, i32 0, i32 1) }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/msgs:Msg" %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %t1)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %s0, ptr %t12)
  store { i64, ptr } %t14, ptr %l5
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t21)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ehexOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2eholderAlive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l6 = alloca %"std/os:FileInfo"
  %l7 = alloca i32
  %l11 = alloca i64
  %l17 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i32
  %l28 = alloca i1
  %l34 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l6
  store %"std/os:FileInfo" %t8, ptr %l4
  br label %bb6
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_602a27eba9c0e30c_cb26c57d6ff1f850)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t15 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t15, ptr %l1
  %t16 = call i64 @std_2ftime_2eWall()
  store i64 %t16, ptr %l11
  br label %bb7
bb7:
  %t17 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t18 = load i64, ptr %t17, !tbaa !24
  %t19 = load i64, ptr %l11, !tbaa !24
  %t21 = sub i64 %t19, %t18
  store i64 %t21, ptr %l2, !tbaa !24
  %t23 = load i64, ptr %l2, !tbaa !24
  %t25 = icmp sgt i64 %t23, 1800000000000
  br i1 %t25, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t28 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t28, 1
  %t31 = extractvalue { i64, ptr } %t28, 0
  %t32 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t30, i64 %t31)
  %t36 = getelementptr i8, ptr %t35, i64 %t31
  call void @olang_textcopy(ptr %t36, ptr %t32, i64 %t33)
  %t37 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t35, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  %t41 = extractvalue { i64, ptr } %t38, 1
  %t42 = mul i64 %t40, 1
  %t43 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t42)
  call void @llvm.memcpy.p0.p0.i64(ptr %t43, ptr %t41, i64 %t42, i1 false)
  %t44 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t43, 1
  %t47 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t45)
  %t48 = extractvalue { i32, { i64, ptr } } %t47, 1
  %t49 = extractvalue { i32, { i64, ptr } } %t47, 0
  store i32 %t49, ptr %l22
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb12, label %ok.51
ok.51:
  store { i64, ptr } %t48, ptr %l21
  br label %bb11
bb11:
  %t52 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t52, ptr %l17, !tbaa !27
  br label %bb16
bb12:
  %t53 = load i32, ptr %l22, !tbaa !23
  %t54 = ashr i32 %t53, 16
  %t56 = icmp eq i32 %t54, 1
  br i1 %t56, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  call void @__olang_check_failed(ptr @olang_loc_15dd64069ce39a3d_80bf0827a15c8de1)
  unreachable
bb15:
  call void @__olang_ert_req_clear()
  %t58 = load i64, ptr %l2, !tbaa !24
  %t60 = icmp slt i64 %t58, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t60, ptr %rv
  br label %ret
bb16:
  %t62 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t62, ptr %l3, !tbaa !27
  %t63 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t65 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t63, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d176, i32 0, i32 1) })
  store i1 %t65, ptr %l28
  br label %bb17
bb17:
  %t66 = load i1, ptr %l28, !tbaa !21
  br i1 %t66, label %bb18, label %bb19
bb18:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t69 = icmp slt i64 %t67, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t69, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t72 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t75 = extractvalue { i64, ptr } %t71, 1
  %t76 = extractvalue { i64, ptr } %t71, 0
  %t77 = add i64 %t73, %t76
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @olang_textcopy(ptr %t78, ptr %t72, i64 %t73)
  %t79 = getelementptr i8, ptr %t78, i64 %t73
  call void @olang_textcopy(ptr %t79, ptr %t75, i64 %t76)
  %t80 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  %t90 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t88)
  store i1 %t90, ptr %l34
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t91 = load i1, ptr %l34, !tbaa !21
  store i1 %t91, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb21
bb4:
  %t8 = load i32, ptr %l0
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d179, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  br label %bb21
bb8:
  %t15 = load i32, ptr %l0
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d180, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  br label %bb21
bb12:
  %t22 = load i32, ptr %l0
  %t24 = trunc i64 3 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d181, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l1, !tbaa !27
  br label %bb21
bb16:
  %t29 = load i32, ptr %l0
  %t31 = trunc i64 4 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d182, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t34, ptr %l1, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7cb1cbeb873878be_a9deaf72b78184ba)
  unreachable
bb21:
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t49, ptr %l1, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2elinkCurrent(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_7df71b5a4631055e_60e51d006fa4a4aa)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  %t18 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
  %t19 = extractvalue { i32, %"std/os:FileInfo" } %t18, 1
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t18, 0
  store i32 %t20, ptr %l15
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22
ok.22:
  store %"std/os:FileInfo" %t19, ptr %l14
  br label %bb7
bb7:
  %t23 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t23, ptr %l12
  br label %bb12
bb8:
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_9a7734a3326ed1df_c69e249acd38d36b)
  unreachable
bb11:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t30 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t30, ptr %l4
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = extractvalue { i64, ptr } %a2, 1
  %t39 = extractvalue { i64, ptr } %a2, 0
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t42 = add i64 %t39, %t41
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t45 = add i64 %t42, %t44
  %t46 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t48 = add i64 %t45, %t47
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t51 = add i64 %t48, %t50
  %t52 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t38, i64 %t39)
  %t56 = getelementptr i8, ptr %t55, i64 %t39
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t34)
  %t59 = getelementptr i8, ptr %t57, i64 %t44
  call void @olang_textcopy(ptr %t59, ptr %t46, i64 %t47)
  %t60 = getelementptr i8, ptr %t59, i64 %t47
  %t61 = call i64 @__olang_fmt_i64(ptr %t60, i64 %t36)
  %t62 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t55, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = extractvalue { i64, ptr } %t64, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } %t71)
  store i1 %t74, ptr %l25
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i1, ptr %l25, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fbuild_2erotr(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !64
  %t2 = load i32, ptr %l1, !tbaa !64
  store i32 %t2, ptr %l3, !tbaa !64
  %t4 = load i32, ptr %l3, !tbaa !64
  %t5 = load i32, ptr %l3, !tbaa !64
  %t6 = lshr i32 %t1, %t5
  %t7 = load i32, ptr %l0, !tbaa !64
  %t8 = load i32, ptr %l1, !tbaa !64
  %t10 = sub i32 32, %t8
  store i32 %t10, ptr %l7, !tbaa !64
  %t12 = load i32, ptr %l7, !tbaa !64
  %t13 = load i32, ptr %l7, !tbaa !64
  %t14 = shl i32 %t7, %t13
  %t17 = or i32 %t6, %t14
  store i32 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/os:Output"
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t5 = call { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l11
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb7
bb3:
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @olang_loc_76fcee83141467d_6681b68f7241f131)
  unreachable
bb6:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb7:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d185, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t26 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t23, { i64, ptr } %t25, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t27 = extractvalue { i32, %"std/os:Output" } %t26, 1
  %t28 = extractvalue { i32, %"std/os:Output" } %t26, 0
  store i32 %t28, ptr %l20
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb9, label %ok.30
ok.30:
  store %"std/os:Output" %t27, ptr %l19
  br label %bb8
bb8:
  %t31 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t31, ptr %l14
  br label %bb13
bb9:
  %t32 = load i32, ptr %l20, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @olang_loc_59822f8cc43c6c4c_c533a14ad3826d20)
  unreachable
bb12:
  call void @__olang_ert_req_clear()
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t38
  store i32 127, ptr %t42, !tbaa !33
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l25, !tbaa !27
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %t49, i64 %t46
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !37
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %t53, i64 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !37
  %t56 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d186, i32 0, i32 1) }, 1
  %t57 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d186, i32 0, i32 1) }, 0
  %t59 = extractvalue { i64, ptr } %t55, 1
  %t60 = extractvalue { i64, ptr } %t55, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d187, i32 0, i32 1) }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = getelementptr i8, ptr %t66, i64 %t60
  call void @olang_textcopy(ptr %t67, ptr %t62, i64 %t63)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t79 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %t80, i64 %t44
  store { i64, ptr } %t76, ptr %t81, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb13:
  %t82 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t82, ptr %l6
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l33, !tbaa !27
  %t84 = load i64, ptr %l5, !tbaa !24
  %t85 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t89 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i32, ptr %t90, i64 %t84
  store i32 %t86, ptr %t91, !tbaa !33
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l36, !tbaa !27
  %t93 = load i64, ptr %l5, !tbaa !24
  %t94 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t96 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t95, 1
  %t100 = extractvalue { i64, ptr } %t95, 0
  %t102 = extractvalue { i64, ptr } %t97, 1
  %t103 = extractvalue { i64, ptr } %t97, 0
  %t104 = add i64 %t100, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t99, i64 %t100)
  %t106 = getelementptr i8, ptr %t105, i64 %t100
  call void @olang_textcopy(ptr %t106, ptr %t102, i64 %t103)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t118 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t93
  store { i64, ptr } %t115, ptr %t120, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb1
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_3ec5d72509c932fc_abe0ecabdd43ffc8)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_bf59f6e6492ea7f9_e2d907cc6a3aac55)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2458f2dc1922626_b765309b90803e52)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2estatusOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/os:Output"
  %l9 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t15 = mul i64 1, 16
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 1, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l6, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 0
  store { i64, ptr } %t14, ptr %t22, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d185, i32 0, i32 1) }, ptr %l7, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t25 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t23, { i64, ptr } %t24, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t26 = extractvalue { i32, %"std/os:Output" } %t25, 1
  %t27 = extractvalue { i32, %"std/os:Output" } %t25, 0
  store i32 %t27, ptr %l9
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb2, label %ok.29
ok.29:
  store %"std/os:Output" %t26, ptr %l8
  br label %bb1
bb1:
  %t30 = load %"std/os:Output", ptr %l8
  store %"std/os:Output" %t30, ptr %l2
  br label %bb6
bb2:
  %t31 = load i32, ptr %l9, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  br i1 %t34, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_bee12b45472bc532_5a2625924af16ce)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb6:
  %t37 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t37, ptr %l1
  %t38 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t39 = load i32, ptr %t38, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t39, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eunbuilt() #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/target:Target"
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/target:Target"
  %l23 = alloca %"compiler/cond:Consts"
  %l24 = alloca %"compiler/build:Config"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d188, i32 0, i32 1) }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d189, i32 0, i32 1) }, ptr %l1, !tbaa !27
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
  store %"compiler/target:Target" %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = load %"compiler/target:Target", ptr %l22
  store %"compiler/target:Target" %t2, ptr %l2
  %t3 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
  store %"compiler/cond:Consts" %t3, ptr %l23
  br label %bb2
bb2:
  %t4 = load %"compiler/cond:Consts", ptr %l23
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d190, i32 0, i32 1) }, ptr %l15, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d191, i32 0, i32 1) }, ptr %l16, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d192, i32 0, i32 1) }, ptr %l20, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d193, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t5 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 2
  %t10 = load %"compiler/target:Target", ptr %l2
  store %"compiler/target:Target" %t10, ptr %t9
  %t11 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 3
  store %"compiler/cond:Consts" %t4, ptr %t11
  %t13 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 4
  store i1 false, ptr %t13, !tbaa !21
  %t15 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 5
  store i1 false, ptr %t15, !tbaa !21
  %t17 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 6
  store i1 false, ptr %t17, !tbaa !21
  %t19 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 7
  store i1 false, ptr %t19, !tbaa !21
  %t21 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 8
  store i1 false, ptr %t21, !tbaa !21
  %t23 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 9
  store i1 false, ptr %t23, !tbaa !21
  %t25 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 10
  store i1 false, ptr %t25, !tbaa !21
  %t27 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 11
  store i1 false, ptr %t27, !tbaa !21
  %t29 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 12
  store i64 0, ptr %t29, !tbaa !24
  %t31 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 13
  store i1 false, ptr %t31, !tbaa !21
  %t33 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 14
  store i1 false, ptr %t33, !tbaa !21
  %t35 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 15
  %t36 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t36, ptr %t35, !tbaa !27
  %t37 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 16
  %t38 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t38, ptr %t37, !tbaa !27
  %t39 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 17
  store i64 0, ptr %t39, !tbaa !24
  %t41 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 18
  store i64 0, ptr %t41, !tbaa !24
  %t43 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 19
  store i1 false, ptr %t43, !tbaa !21
  %t45 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 20
  %t46 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t46, ptr %t45, !tbaa !27
  %t47 = getelementptr %"compiler/build:Config", ptr %l24, i32 0, i32 21
  %t48 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t48, ptr %t47, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l24, i64 328, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/build:Program"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d194, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d195, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l7
  br label %bb2
bb2:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l3
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l8
  br label %bb3
bb3:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d196, i32 0, i32 1) }, ptr %l5, !tbaa !27
  %t7 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t8 = insertvalue %"compiler/build:Program" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, 0
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t10 = insertvalue %"compiler/build:Program" %t8, { i64, ptr } %t9, 1
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = insertvalue %"compiler/build:Program" %t10, { i64, ptr } %t11, 2
  %t13 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t14 = insertvalue %"compiler/build:Program" %t12, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, 3
  %t16 = insertvalue %"compiler/build:Program" %t14, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, 4
  %t17 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t18 = insertvalue %"compiler/build:Program" %t16, { i64, ptr } %t17, 5
  store %"compiler/build:Program" %t18, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Program", ptr %rv
  ret %"compiler/build:Program" %rr
}

define dso_local %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca [8 x i32]
  %l5 = alloca [64 x i8]
  %rv = alloca %"compiler/build:Sha256"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x i32] undef, i32 1779033703, 0
  %t2 = insertvalue [8 x i32] %t1, i32 -1150833019, 1
  %t3 = insertvalue [8 x i32] %t2, i32 1013904242, 2
  %t4 = insertvalue [8 x i32] %t3, i32 -1521486534, 3
  %t5 = insertvalue [8 x i32] %t4, i32 1359893119, 4
  %t6 = insertvalue [8 x i32] %t5, i32 -1694144372, 5
  %t7 = insertvalue [8 x i32] %t6, i32 528734635, 6
  %t8 = insertvalue [8 x i32] %t7, i32 1541459225, 7
  store [8 x i32] %t8, ptr %l0
  br label %fill.13
fill.13:
  br label %fill.10
fill.10:
  %t14 = phi i64 [ 0, %fill.13 ], [ %t15, %fill.11 ]
  %t16 = icmp slt i64 %t14, 64
  br i1 %t16, label %fill.11, label %fill.12
fill.11:
  %t17 = getelementptr [64 x i8], ptr %l5, i64 0, i64 %t14
  store i8 0, ptr %t17
  %t15 = add i64 %t14, 1
  br label %fill.10
fill.12:
  %t18 = load [64 x i8], ptr %l5
  %t19 = load [8 x i32], ptr %l0
  %t20 = insertvalue %"compiler/build:Sha256" undef, [8 x i32] %t19, 0
  %t22 = insertvalue %"compiler/build:Sha256" %t20, [64 x i8] %t18, 1
  %t24 = insertvalue %"compiler/build:Sha256" %t22, i64 0, 2
  %t26 = insertvalue %"compiler/build:Sha256" %t24, i64 0, 3
  store %"compiler/build:Sha256" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Sha256", ptr %rv
  ret %"compiler/build:Sha256" %rr
}

define dso_local %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca %"compiler/build:Unit"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d197, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t8 = insertvalue %"compiler/build:Unit" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/build:Unit" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/build:Unit" %t10, { i64, ptr } %a2, 2
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/build:Unit" %t12, { i64, ptr } %t13, 3
  store %"compiler/build:Unit" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Unit", ptr %rv
  ret %"compiler/build:Unit" %rr
}

define dso_local %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l14 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l15 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/build:compiles"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l9
  br label %bb2
bb2:
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %l1
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l10
  br label %bb3
bb3:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l10
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l2
  %t7 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t7, ptr %l11
  br label %bb4
bb4:
  %t8 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l3
  %t9 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l12
  br label %bb5
bb5:
  %t10 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l12
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t10, ptr %l4
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l13
  br label %bb6
bb6:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l5
  %t13 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t13, ptr %l14
  br label %bb7
bb7:
  %t14 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l14
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l6
  %t15 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, ptr %l15
  br label %bb8
bb8:
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l15
  %t17 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t18 = insertvalue %"compiler/build:compiles" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t17, 0
  %t19 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t20 = insertvalue %"compiler/build:compiles" %t18, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t19, 1
  %t21 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t22 = insertvalue %"compiler/build:compiles" %t20, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, 2
  %t23 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t24 = insertvalue %"compiler/build:compiles" %t22, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t23, 3
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t26 = insertvalue %"compiler/build:compiles" %t24, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, 4
  %t27 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  %t28 = insertvalue %"compiler/build:compiles" %t26, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t27, 5
  %t29 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  %t30 = insertvalue %"compiler/build:compiles" %t28, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t29, 6
  %t32 = insertvalue %"compiler/build:compiles" %t30, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, 7
  store %"compiler/build:compiles" %t32, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:compiles", ptr %rv
  ret %"compiler/build:compiles" %rr
}

define dso_local %"compiler/build:stubFrontend" @compiler_2fbuild_3astubFrontend_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/build:stubFrontend"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/build:stubFrontend" undef, i64 0, 0
  %t4 = insertvalue %"compiler/build:stubFrontend" %t2, i64 0, 1
  store %"compiler/build:stubFrontend" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:stubFrontend", ptr %rv
  ret %"compiler/build:stubFrontend" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fbuild() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fbuild_2eThinFrom_2einit()
  br label %bb1
bb1:
  call void @compiler_2fbuild_2eImportLimit_2einit()
  br label %bb2
bb2:
  call void @compiler_2fbuild_2ePhaseAt_2einit()
  br label %bb3
bb3:
  call void @compiler_2fbuild_2eShaK_2einit()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr)
declare void @__olang_ert_req_clear()
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 0] }>, align 8
@.d1 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TIMES" }>, align 8
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"front" }>, align 8
@.d7 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lower+emit" }>, align 8
declare i32 @getpid()
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_9(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l2
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %a0
  %t7 = load i64, ptr %t6, !tbaa !34
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i64, ptr %t12, i64 %a1
  %t14 = load i64, ptr %t13, !tbaa !34
  %t17 = icmp sgt i64 %t7, %t14
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task10(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load ptr, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2fbuild_2erunner(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

declare i64 @__olang_join_tasks(ptr)
@.d11 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d12 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d13 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Hangup" }>, align 8
@.d14 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Interrupt" }>, align 8
@.d15 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Quit" }>, align 8
@.d16 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"Illegal instruction" }>, align 8
@.d17 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"Trace/breakpoint trap" }>, align 8
@.d18 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Aborted" }>, align 8
@.d19 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Bus error" }>, align 8
@.d20 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"Floating point exception" }>, align 8
@.d21 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Killed" }>, align 8
@.d22 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"Segmentation fault" }>, align 8
@.d23 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Broken pipe" }>, align 8
@.d24 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Alarm clock" }>, align 8
@.d25 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Terminated" }>, align 8
@.d26 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"Unknown signal " }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d27 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c": lost track of its build, skipping" }>, align 8
@.d31 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d32 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c": the compiler ended (" }>, align 8
@.d33 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"), skipping" }>, align 8
@.d34 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d35 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"olang: error: the self-hosted compiler cannot build this yet: " }>, align 8
@.d36 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
@.d37 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d38 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d39 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-mllvm" }>, align 8
@.d40 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"-fast-isel=false" }>, align 8
@.d41 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d42 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d43 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"-Wl,-plugin-opt,cache-dir=" }>, align 8
@.d44 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/thinlto" }>, align 8
@.d45 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"-Wl,-plugin-opt,-import-instr-limit=" }>, align 8
@.d46 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-shared" }>, align 8
@.d47 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".map" }>, align 8
@.d48 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{\0A  global:\0A" }>, align 8
@.d49 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d50 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c";\0A" }>, align 8
@.d51 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  local: *;\0A};\0A" }>, align 8
@.d52 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"-Wl,--version-script=" }>, align 8
@.d53 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"-Wl,-soname," }>, align 8
@.d54 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d55 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-lm" }>, align 8
@.d56 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-lpthread" }>, align 8
@.d57 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-ldl" }>, align 8
@.d58 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d59 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".link" }>, align 8
@.d60 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d61 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d62 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d63 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d64 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d65 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d66 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--sysroot=" }>, align 8
@.d67 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d68 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-fPIC" }>, align 8
@.d69 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O0" }>, align 8
@.d70 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-g" }>, align 8
@.d71 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d72 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O1" }>, align 8
@.d73 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d74 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O2" }>, align 8
@.d75 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O3" }>, align 8
@.d76 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d77 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d80 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".o" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d85 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d86 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d87 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d88 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
declare i32 @usleep(i32)
@.d89 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d90 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d91 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d92 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d93 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--version" }>, align 8
@.d94 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d95 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d96 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d97 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d98 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d99 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d100 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d102 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d103 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d104 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/lib" }>, align 8
@.d105 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d106 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d107 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d110 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d111 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d112 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d113 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d114 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d115 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d116 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".race" }>, align 8
@.d117 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d118 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".debug" }>, align 8
@.d119 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d120 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".quick" }>, align 8
@.d121 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d122 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".san" }>, align 8
@.d123 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d124 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d125 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d126 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d127 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d128 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"[0m" }>, align 8
@.d129 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": semantic errors, skipping" }>, align 8
@.d130 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d131 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": cannot be built, skipping" }>, align 8
@.d132 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d133 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d134 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d135 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d136 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d137 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d138 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d139 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang_" }>, align 8
@.d140 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d141 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".tmp.ll" }>, align 8
@.d142 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d143 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d144 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d145 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d146 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
declare i64 @sysconf(i32)
@.d147 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d148 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 -128] }>, align 8
@.d149 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 0] }>, align 8
@.d150 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d151 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d152 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"41" }>, align 8
@.d153 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"attributes #0 = { nounwind " }>, align 8
@.d154 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" }\0A" }>, align 8
@.d155 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d156 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d157 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"define i32 @lib_n() #0 {\0A  ret i32 " }>, align 8
@.d158 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d159 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lib" }>, align 8
@.d160 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"define i32 @util_k() #0 {\0A  ret i32 " }>, align 8
@.d161 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d162 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"util" }>, align 8
@.d163 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"declare i32 @lib_n()\0Adeclare i32 @util_k()\0Adeclare i32 @inst_z()\0Adeclare void @olang_rt()\0A" }>, align 8
@.d164 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"define i32 @main() #0 {\0A  call void @olang_rt()\0A  %a = call i32 @lib_n()\0A" }>, align 8
@.d165 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %b = call i32 @util_k()\0A  %c = call i32 @inst_z()\0A  %s = add i32 %a, %b\0A  %t = add i32 %s, %c\0A" }>, align 8
@.d166 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  ret i32 %t\0A}\0A" }>, align 8
@.d167 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@.d168 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"define i32 @inst_z() #0 {\0A  ret i32 0\0A}\0A" }>, align 8
@.d169 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@.d170 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"define void @olang_rt() #0 {\0A  ret void\0A}\0A" }>, align 8
@.d171 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d172 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()\0A" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d175 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d176 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d177 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d179 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".main" }>, align 8
@.d180 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".test" }>, align 8
@.d181 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".inst" }>, align 8
@.d182 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".loc" }>, align 8
@.d183 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d184 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d185 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d186 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"cannot run " }>, align 8
@.d187 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d188 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d189 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d190 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d191 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d192 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d193 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d194 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d195 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d196 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d197 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_425ee9903c92bc28_2d21c05ef6c078ec = external constant [0 x i8]
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_807a392292b9ae5a_fba630df00719f06 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_1a0af222d89a1264_6ae848cde6020298 = external constant [0 x i8]
declare i64 @std_2ftime_2eNow()
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_5ecb9fdb04842c55_e03f98123a4ef969 = external constant [0 x i8]
@olang_loc_2b4b55182e30c5b8_1dd1254afca8c384 = external constant [0 x i8]
@olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491 = external constant [0 x i8]
@olang_loc_bc625dc042a99e06_c0b5fdead4ea6272 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @std_2fchan_2eInit_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1359a9f97975288c_a8d4abcb606172b0 = external constant [0 x i8]
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_84eba90bdad5d702_427cd4b75eaf1c36 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_c094ff343a4c193c_f5cfbac5a7fd7498 = external constant [0 x i8]
declare i32 @std_2fos_2eMkDir(ptr %v0, { i64, ptr } %a0)
@olang_loc_3577cefc2355b499_7d6905d22965c065 = external constant [0 x i8]
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_5f770347e29e5fc8_2866945fa632b934 = external constant [0 x i8]
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_51ea3fb94a0f14a3_79d3779c97249b6f = external constant [0 x i8]
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d9f2db171606c9bf_4bc78b18f11f6703 = external constant [0 x i8]
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %v0)
@olang_loc_bfc49e763ae34426_1cf738faff557a0a = external constant [0 x i8]
@olang_loc_9440ba48b5f00e48_8accfe015a3e4c7c = external constant [0 x i8]
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_fb1993af6f92a97f_575d454bf14ba47b = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
@olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2 = external constant [0 x i8]
@olang_loc_90cf0970d2913dc4_9bcdb60805de20f8 = external constant [0 x i8]
declare i32 @std_2fos_2eLink(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_8b1e12aab65e64ff_84504a06af2aa513 = external constant [0 x i8]
@olang_loc_92faa2cdf30c2efe_47110dc1ef627b12 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5)
@olang_loc_4094133386311447_ea4f4ad8e8116e4b = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_5506b8e1d4511fe6_ac8ddf3d542b2a0a = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_81dfa638548de3d7_ab0731b6a5acba3 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_64cef890f5e30dfa_ab05d47f854753c6 = external constant [0 x i8]
@olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_93685d01cca04f82_bac91b93b7acf8e6 = external constant [0 x i8]
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_602a27eba9c0e30c_cb26c57d6ff1f850 = external constant [0 x i8]
declare i64 @std_2ftime_2eWall()
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_15dd64069ce39a3d_80bf0827a15c8de1 = external constant [0 x i8]
@olang_loc_7cb1cbeb873878be_a9deaf72b78184ba = external constant [0 x i8]
@olang_loc_7df71b5a4631055e_60e51d006fa4a4aa = external constant [0 x i8]
@olang_loc_9a7734a3326ed1df_c69e249acd38d36b = external constant [0 x i8]
declare { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0)
@olang_loc_76fcee83141467d_6681b68f7241f131 = external constant [0 x i8]
@olang_loc_59822f8cc43c6c4c_c533a14ad3826d20 = external constant [0 x i8]
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
@olang_loc_3ec5d72509c932fc_abe0ecabdd43ffc8 = external constant [0 x i8]
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
@olang_loc_bf59f6e6492ea7f9_e2d907cc6a3aac55 = external constant [0 x i8]
declare i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
@olang_loc_2458f2dc1922626_b765309b90803e52 = external constant [0 x i8]
@olang_loc_bee12b45472bc532_5a2625924af16ce = external constant [0 x i8]
declare %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
