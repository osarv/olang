; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Sha256" = type { [8 x i32], [64 x i8], i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"std/chan:Chan.11ca74d91bf46e08896eb88ea5508941" = type { { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, [8 x i64], [8 x i64], [8 x i64] }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:compiles" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Program" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"compiler/build:stubFrontend" = type { i64, i64 }
@G_2ecompiler_2fbuild_2eImportLimit = constant <{ [8 x i8] }> <{ [8 x i8] c"\46\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbuild_2ePhaseAt = global i64 zeroinitializer
@G_2ecompiler_2fbuild_2eShaK = constant <{ [256 x i8] }> <{ [256 x i8] c"\98\2F\8A\42\91\44\37\71\CF\FB\C0\B5\A5\DB\B5\E9\5B\C2\56\39\F1\11\F1\59\A4\82\3F\92\D5\5E\1C\AB\98\AA\07\D8\01\5B\83\12\BE\85\31\24\C3\7D\0C\55\74\5D\BE\72\FE\B1\DE\80\A7\06\DC\9B\74\F1\9B\C1\C1\69\9B\E4\86\47\BE\EF\C6\9D\C1\0F\CC\A1\0C\24\6F\2C\E9\2D\AA\84\74\4A\DC\A9\B0\5C\DA\88\F9\76\52\51\3E\98\6D\C6\31\A8\C8\27\03\B0\C7\7F\59\BF\F3\0B\E0\C6\47\91\A7\D5\51\63\CA\06\67\29\29\14\85\0A\B7\27\38\21\1B\2E\FC\6D\2C\4D\13\0D\38\53\54\73\0A\65\BB\0A\6A\76\2E\C9\C2\81\85\2C\72\92\A1\E8\BF\A2\4B\66\1A\A8\70\8B\4B\C2\A3\51\6C\C7\19\E8\92\D1\24\06\99\D6\85\35\0E\F4\70\A0\6A\10\16\C1\A4\19\08\6C\37\1E\4C\77\48\27\B5\BC\B0\34\B3\0C\1C\39\4A\AA\D8\4E\4F\CA\9C\5B\F3\6F\2E\68\EE\82\8F\74\6F\63\A5\78\14\78\C8\84\08\02\C7\8C\FA\FF\BE\90\EB\6C\50\A4\F7\A3\F9\BE\F2\78\71\C6" }>, align 64
@G_2ecompiler_2fbuild_2eThinFrom = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
define dso_local { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca %"compiler/build:Sha256"
  %l10 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca i32
  %l23 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l8
  store %"compiler/build:Sha256" %t2, ptr %l1
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l14
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb4, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l13
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t14, ptr %l10, !tbaa !27
  br label %bb8
bb4:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  call void @__olang_check_failed(ptr @.c0)
  unreachable
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb8:
  %t20 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb11:
  br label %bb12
bb12:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l23, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %t37, i64 %t34
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !37
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t39)
  br label %bb13
bb13:
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %s3, ptr %l1, { i64, ptr } { i64 1, ptr @.d1 })
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t46 = load i64, ptr %l6, !tbaa !24
  %t48 = add i64 %t46, 1
  store i64 %t48, ptr %l6, !tbaa !24
  br label %bb9
bb16:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = add i64 %t50, %t51
  store i64 %t54, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb2
bb18:
  %t57 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t57, ptr %l36
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2eImportLimit_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 70, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l8 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr @.d2 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  br i1 %t10, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t12 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t12, ptr %l1, !tbaa !27
  %t13 = call i64 @std_2ftime_2eNow()
  store i64 %t13, ptr %l8
  br label %bb7
bb7:
  %t14 = load i64, ptr %l8, !tbaa !24
  store i64 %t14, ptr %l2, !tbaa !24
  %t15 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t17 = icmp ne i64 %t15, 0
  br i1 %t17, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t20 = load i64, ptr %l2, !tbaa !24
  %t21 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t24 = sub i64 %t20, %t21
  %t26 = sdiv i64 %t24, 1000000
  %t27 = extractvalue { i64, ptr } { i64 7, ptr @.d4 }, 1
  %t28 = extractvalue { i64, ptr } { i64 7, ptr @.d4 }, 0
  %t30 = extractvalue { i64, ptr } %t19, 1
  %t31 = extractvalue { i64, ptr } %t19, 0
  %t32 = add i64 %t28, %t31
  %t33 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 1
  %t34 = extractvalue { i64, ptr } { i64 1, ptr @.d5 }, 0
  %t35 = add i64 %t32, %t34
  %t37 = call i64 @__olang_fmt_i64(ptr null, i64 %t26)
  %t38 = add i64 %t35, %t37
  %t39 = extractvalue { i64, ptr } { i64 4, ptr @.d6 }, 1
  %t40 = extractvalue { i64, ptr } { i64 4, ptr @.d6 }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t27, i64 %t28)
  %t43 = getelementptr i8, ptr %t42, i64 %t28
  call void @olang_textcopy(ptr %t43, ptr %t30, i64 %t31)
  %t44 = getelementptr i8, ptr %t43, i64 %t31
  call void @olang_textcopy(ptr %t44, ptr %t33, i64 %t34)
  %t45 = getelementptr i8, ptr %t44, i64 %t34
  %t46 = call i64 @__olang_fmt_i64(ptr %t45, i64 %t26)
  %t47 = getelementptr i8, ptr %t45, i64 %t37
  call void @olang_textcopy(ptr %t47, ptr %t39, i64 %t40)
  %t48 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t42, 1
  %t51 = extractvalue { i64, ptr } %t49, 0
  %t52 = extractvalue { i64, ptr } %t49, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  call void @compiler_2fbuild_2esayErr(ptr %s2, { i64, ptr } %t56)
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t58 = load i64, ptr %l2, !tbaa !24
  store i64 %t58, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t60, { i64, ptr } { i64 5, ptr @.d7 })
  store i1 %t62, ptr %l20
  br label %bb12
bb12:
  %t63 = load i1, ptr %l20, !tbaa !21
  br i1 %t63, label %bb13, label %bb14
bb13:
  %t64 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t64, { i64, ptr } { i64 10, ptr @.d8 })
  store i1 %t66, ptr %l23
  br label %bb15
bb14:
  store i1 false, ptr %l21, !tbaa !21
  br label %bb16
bb15:
  %t67 = load i1, ptr %l23, !tbaa !21
  store i1 %t67, ptr %l21, !tbaa !21
  br label %bb16
bb16:
  %t68 = load i1, ptr %l21, !tbaa !21
  br i1 %t68, label %bb17, label %bb18
bb17:
  call void @std_2fos_2eExit(i32 0)
  unreachable
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @.c9)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ePhaseAt_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ePid() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @getpid()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i8
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t25)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t29 = load i8, ptr %l5, !tbaa !22
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t29)
  store i1 %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load i1, ptr %l22, !tbaa !21
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i8, ptr %l5, !tbaa !22
  %t36 = icmp eq i8 %t34, 95
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t39 = load i8, ptr %l5, !tbaa !22
  %t41 = icmp eq i8 %t39, 45
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t44 = load i8, ptr %l5, !tbaa !22
  store i8 %t44, ptr %l29, !tbaa !22
  br label %bb19
bb18:
  store i8 95, ptr %l29, !tbaa !22
  br label %bb19
bb19:
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t47 = load i8, ptr %l29, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t46, i8 %t47)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  br label %bb21
bb21:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb22:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb23
bb23:
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %l35, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l36, !tbaa !24
  %t57 = load i64, ptr %l36, !tbaa !24
  %t58 = mul i64 %t57, 1
  %t59 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  store { i64, ptr } %t61, ptr %l37, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t65 = load ptr, ptr %t64, !tbaa !27
  %t66 = load i64, ptr %l36, !tbaa !24
  %t67 = mul i64 %t66, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t63, ptr %t65, i64 %t67, i1 false)
  %t68 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t68, ptr %l35, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t69 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t69, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l41 = alloca { { i64, ptr }, { i64, ptr } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l87 = alloca %"std/chan:Chan.11ca74d91bf46e08896eb88ea5508941"
  %l97 = alloca { i64, ptr }
  %l102 = alloca i32
  %l110 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l149 = alloca { { i64, ptr }, { i64, ptr } }
  %l150 = alloca { i64, ptr }
  %l151 = alloca i64
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l154 = alloca i64
  %l155 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %jh10 = alloca ptr
  %s12 = alloca %olang.scope
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t165 = alloca { { i64, ptr }, ptr }, align 8
  %t176 = alloca %"std/chan:Chan.11ca74d91bf46e08896eb88ea5508941", align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l27, !tbaa !24
  %t6 = load i64, ptr %l27, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l27, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb3:
  %t12 = load i64, ptr %l27, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = load i64, ptr %l31, !tbaa !24
  %t20 = icmp sge i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @.c10)
  unreachable
bb5:
  %t22 = load i64, ptr %l31, !tbaa !24
  %t23 = icmp sle i64 %t22, 576460752303423487
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb7:
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = mul i64 %t25, 16
  %t27 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  store { i64, ptr } %t29, ptr %l5, !tbaa !27
  %t31 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp eq i64 %t31, 0
  br i1 %t33, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb9:
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t40 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t35, 0
  %t42 = insertvalue { { i64, ptr }, { i64, ptr } } %t40, { i64, ptr } %t37, 1
  store { { i64, ptr }, { i64, ptr } } %t42, ptr %l41
  %t43 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l42, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l43, !tbaa !24
  %t47 = load i64, ptr %l43, !tbaa !24
  %t48 = mul i64 %t47, 4
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l44, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l43, !tbaa !24
  %t57 = mul i64 %t56, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t59 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  store { i64, ptr } %t58, ptr %t59, !tbaa !27
  %t60 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !27
  store { i64, ptr } %t61, ptr %l45, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 0
  store i64 %t63, ptr %l46, !tbaa !24
  %t64 = load i64, ptr %l46, !tbaa !24
  %t65 = mul i64 %t64, 16
  %t66 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t65)
  %t67 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t66, 1
  store { i64, ptr } %t68, ptr %l47, !tbaa !27
  %t69 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t70 = load ptr, ptr %t69, !tbaa !27
  %t71 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t72 = load ptr, ptr %t71, !tbaa !27
  %t73 = load i64, ptr %l46, !tbaa !24
  %t74 = mul i64 %t73, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t70, ptr %t72, i64 %t74, i1 false)
  %t75 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t76 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  store { i64, ptr } %t75, ptr %t76, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t77 = load { { i64, ptr }, { i64, ptr } }, ptr %l41
  store { { i64, ptr }, { i64, ptr } } %t77, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t78 = load i64, ptr %l3, !tbaa !24
  store i64 %t78, ptr %l48, !tbaa !24
  %t79 = load i64, ptr %l48, !tbaa !24
  %t80 = icmp sge i64 %t79, 0
  br i1 %t80, label %bb12, label %bb13
bb12:
  %t82 = load i64, ptr %l48, !tbaa !24
  %t83 = icmp sle i64 %t82, 1152921504606846975
  br i1 %t83, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb14:
  %t85 = load i64, ptr %l48, !tbaa !24
  %t86 = mul i64 %t85, 8
  %t87 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t91 = load i64, ptr %l3, !tbaa !24
  store i64 %t91, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t93 = load i64, ptr %l8, !tbaa !24
  %t94 = load i64, ptr %l7, !tbaa !24
  %t97 = icmp sgt i64 %t93, %t94
  br i1 %t97, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @.c12)
  unreachable
bb16:
  %t99 = load i64, ptr %l9, !tbaa !24
  %t101 = icmp sgt i64 %t99, 0
  br i1 %t101, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb18:
  %t103 = load i64, ptr %l8, !tbaa !24
  %t104 = load i64, ptr %l7, !tbaa !24
  %t107 = sub i64 %t103, %t104
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = add i64 %t107, %t108
  %t113 = sub i64 %t111, 1
  %t114 = load i64, ptr %l9, !tbaa !24
  %t117 = sdiv i64 %t113, %t114
  store i64 %t117, ptr %l59, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t119 = load i64, ptr %l59, !tbaa !24
  store i64 %t119, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t120 = load i64, ptr %l56, !tbaa !24
  store i64 %t120, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  store %olang.scope zeroinitializer, ptr %s3
  %t121 = load i64, ptr %l11, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  %t125 = icmp slt i64 %t121, %t122
  %t127 = xor i1 %t125, true
  br i1 %t127, label %bb23, label %bb24
bb23:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t129 = load i64, ptr %l7, !tbaa !24
  %t130 = load i64, ptr %l11, !tbaa !24
  %t131 = load i64, ptr %l9, !tbaa !24
  %t134 = mul i64 %t130, %t131
  %t137 = add i64 %t129, %t134
  store i64 %t137, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l12, !tbaa !24
  %t140 = load i64, ptr %l12, !tbaa !24
  %t143 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t144 = load ptr, ptr %t143, !tbaa !27
  %t145 = getelementptr i64, ptr %t144, i64 %t139
  store i64 %t140, ptr %t145, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb26:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb22
bb27:
  %t150 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 0
  %t153 = extractvalue { i64, ptr } zeroinitializer, 0
  %t154 = icmp eq i64 %t152, %t153
  %t155 = extractvalue { i64, ptr } %t150, 1
  %t156 = extractvalue { i64, ptr } zeroinitializer, 1
  %t157 = icmp eq ptr %t155, %t156
  %t158 = and i1 %t154, %t157
  %t159 = xor i1 %t158, true
  br i1 %t159, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t161 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t162 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t163 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t164 = ptrtoint ptr %t163 to i64
  %t166 = getelementptr { { i64, ptr }, ptr }, ptr %t165, i32 0, i32 0
  store { i64, ptr } %t162, ptr %t166, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t168 = getelementptr { { i64, ptr }, ptr }, ptr %t165, i32 0, i32 1
  store ptr %v1, ptr %t168, !tbaa !28
  %t169 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_13, 0
  %t170 = insertvalue { ptr, ptr } %t169, ptr %t165, 1
  %t173 = extractvalue { ptr, ptr } %t170, 0
  %t174 = extractvalue { ptr, ptr } %t170, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %s0, ptr %s5, { i64, ptr } %t161, ptr %t173, ptr %t174)
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t175 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %t176, ptr %s0, i64 %t175)
  call void @llvm.memmove.p0.p0.i64(ptr %l87, ptr %t176, i64 264, i1 false)
  br label %bb32
bb32:
  %t178 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 264, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t178, ptr %l87, i64 264, i1 false)
  store ptr %t178, ptr %l13, !tbaa !29
  %t180 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eInit_3cI64_3e(ptr %s0, ptr %t180)
  br label %bb33
bb33:
  %t182 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t182, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t184 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t184, 0
  store i64 %t186, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s7
  %t188 = load i64, ptr %l15, !tbaa !24
  %t189 = load i64, ptr %l16, !tbaa !24
  %t192 = icmp slt i64 %t188, %t189
  %t194 = xor i1 %t192, true
  br i1 %t194, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s7)
  br label %bb45
bb36:
  br label %bb37
bb37:
  %t196 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t196, ptr %l97, !tbaa !27
  %t197 = load i64, ptr %l15, !tbaa !24
  %t199 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr i64, ptr %t200, i64 %t197
  %t202 = load i64, ptr %t201, !tbaa !34
  %t204 = load ptr, ptr %l13, !tbaa !29
  %t208 = call i32 @std_2fchan_2eSend_3cI64_3e(ptr %s0, ptr %t204, i64 %t202)
  store i32 %t208, ptr %l102
  %t209 = icmp ne i32 %t208, 0
  br i1 %t209, label %bb39, label %ok.210
ok.210:
  br label %bb38
bb38:
  br label %bb43
bb39:
  %t211 = load i32, ptr %l102, !tbaa !23
  %t212 = ashr i32 %t211, 16
  %t214 = icmp eq i32 %t212, 1
  br i1 %t214, label %bb40, label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb42:
  call void @__olang_check_failed(ptr @.c14)
  unreachable
bb43:
  call void @__olang_scope_close(ptr %s7)
  br label %bb44
bb44:
  %t216 = load i64, ptr %l15, !tbaa !24
  %t218 = add i64 %t216, 1
  store i64 %t218, ptr %l15, !tbaa !24
  br label %bb34
bb45:
  %t220 = load i64, ptr %l1, !tbaa !24
  %t221 = load i64, ptr %l3, !tbaa !24
  %t224 = icmp slt i64 %t220, %t221
  br i1 %t224, label %bb46, label %bb47
bb46:
  %t226 = load i64, ptr %l1, !tbaa !24
  store i64 %t226, ptr %l110, !tbaa !24
  br label %bb48
bb47:
  %t228 = load i64, ptr %l3, !tbaa !24
  store i64 %t228, ptr %l110, !tbaa !24
  br label %bb48
bb48:
  %t230 = load i64, ptr %l110, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s10
  store ptr null, ptr %jh10
  store i64 0, ptr %l19, !tbaa !24
  store i64 %t230, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t233 = load i64, ptr %l20, !tbaa !24
  %t234 = load i64, ptr %l19, !tbaa !24
  %t237 = icmp sgt i64 %t233, %t234
  br i1 %t237, label %bb49, label %bb50
bb49:
  %t239 = load i64, ptr %l21, !tbaa !24
  %t241 = icmp sgt i64 %t239, 0
  br i1 %t241, label %bb51, label %bb52
bb50:
  store i64 0, ptr %l117, !tbaa !24
  br label %bb54
bb51:
  %t243 = load i64, ptr %l20, !tbaa !24
  %t244 = load i64, ptr %l19, !tbaa !24
  %t247 = sub i64 %t243, %t244
  %t248 = load i64, ptr %l21, !tbaa !24
  %t251 = add i64 %t247, %t248
  %t253 = sub i64 %t251, 1
  %t254 = load i64, ptr %l21, !tbaa !24
  %t257 = sdiv i64 %t253, %t254
  store i64 %t257, ptr %l120, !tbaa !24
  br label %bb53
bb52:
  store i64 0, ptr %l120, !tbaa !24
  br label %bb53
bb53:
  %t259 = load i64, ptr %l120, !tbaa !24
  store i64 %t259, ptr %l117, !tbaa !24
  br label %bb54
bb54:
  %t260 = load i64, ptr %l117, !tbaa !24
  store i64 %t260, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb55
bb55:
  store %olang.scope zeroinitializer, ptr %s12
  %t261 = load i64, ptr %l23, !tbaa !24
  %t262 = load i64, ptr %l22, !tbaa !24
  %t265 = icmp slt i64 %t261, %t262
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s12)
  br label %bb60
bb57:
  br label %bb58
bb58:
  %t269 = load i64, ptr %l19, !tbaa !24
  %t270 = load i64, ptr %l23, !tbaa !24
  %t271 = load i64, ptr %l21, !tbaa !24
  %t274 = mul i64 %t270, %t271
  %t277 = add i64 %t269, %t274
  store i64 %t277, ptr %l24, !tbaa !24
  %t279 = load ptr, ptr %l13, !tbaa !29
  %t280 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t281 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t287 = call ptr @__olang_standin(ptr %s0)
  %t288 = call ptr @__olang_standin(ptr %v0)
  %t289 = call ptr @__olang_standin(ptr %v2)
  %t290 = call ptr @__olang_standin(ptr %v2)
  %t291 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t292 = ptrtoint ptr %t291 to i64
  %t293 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 %t292, i64 8)
  %t294 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 0
  store ptr %t279, ptr %t294
  %t295 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 1
  store { i64, ptr } %t280, ptr %t295
  %t296 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 2
  store { i64, ptr } %t281, ptr %t296
  %t297 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 3
  store { i64, ptr } %t282, ptr %t297
  %t298 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 4
  store ptr %t287, ptr %t298
  %t299 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 5
  store ptr %t288, ptr %t299
  %t300 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 6
  store ptr %t289, ptr %t300
  %t301 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t293, i32 0, i32 7
  store ptr %t290, ptr %t301
  %t302 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 32, i64 8)
  %t303 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr null, ptr %t303
  %t304 = getelementptr { ptr, ptr }, ptr %t303, i32 0, i32 1
  store ptr %t287, ptr %t304
  %t305 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t303, ptr %t305
  %t306 = getelementptr { ptr, ptr }, ptr %t305, i32 0, i32 1
  store ptr %t288, ptr %t306
  %t307 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t305, ptr %t307
  %t308 = getelementptr { ptr, ptr }, ptr %t307, i32 0, i32 1
  store ptr %t289, ptr %t308
  %t309 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t307, ptr %t309
  %t310 = getelementptr { ptr, ptr }, ptr %t309, i32 0, i32 1
  store ptr %t290, ptr %t310
  %t311 = getelementptr { ptr, i64, ptr, i64 }, ptr %t302, i32 0, i32 2
  store ptr %t309, ptr %t311
  %t312 = getelementptr { ptr, i64, ptr, i64 }, ptr %t302, i32 0, i32 1
  store i64 0, ptr %t312
  %t313 = getelementptr { ptr, i64, ptr, i64 }, ptr %t302, i32 0, i32 3
  store i64 0, ptr %t313
  %t314 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t314, ptr @olang_task15, ptr %t293, ptr %t302)
  %t315 = load ptr, ptr %jh10
  store ptr %t315, ptr %t302
  store ptr %t302, ptr %jh10
  call void @__olang_scope_close(ptr %s12)
  br label %bb59
bb59:
  %t316 = load i64, ptr %l23, !tbaa !24
  %t318 = add i64 %t316, 1
  store i64 %t318, ptr %l23, !tbaa !24
  br label %bb55
bb60:
  %t320 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eClose_3cI64_3e(ptr %s0, ptr %t320)
  br label %bb61
bb61:
  %t322 = call i64 @__olang_join_tasks(ptr %jh10)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  %t323 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t328 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t323, 0
  %t330 = insertvalue { { i64, ptr }, { i64, ptr } } %t328, { i64, ptr } %t325, 1
  store { { i64, ptr }, { i64, ptr } } %t330, ptr %l149
  %t331 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l149, i32 0, i32 0
  %t332 = load { i64, ptr }, ptr %t331, !tbaa !27
  store { i64, ptr } %t332, ptr %l150, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t334 = extractvalue { i64, ptr } %t333, 0
  store i64 %t334, ptr %l151, !tbaa !24
  %t335 = load i64, ptr %l151, !tbaa !24
  %t336 = mul i64 %t335, 4
  %t337 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t336)
  %t338 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  store { i64, ptr } %t339, ptr %l152, !tbaa !27
  %t340 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t341 = load ptr, ptr %t340, !tbaa !27
  %t342 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t343 = load ptr, ptr %t342, !tbaa !27
  %t344 = load i64, ptr %l151, !tbaa !24
  %t345 = mul i64 %t344, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t341, ptr %t343, i64 %t345, i1 false)
  %t346 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t347 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l149, i32 0, i32 0
  store { i64, ptr } %t346, ptr %t347, !tbaa !27
  %t348 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l149, i32 0, i32 1
  %t349 = load { i64, ptr }, ptr %t348, !tbaa !27
  store { i64, ptr } %t349, ptr %l153, !tbaa !27
  %t350 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t351 = extractvalue { i64, ptr } %t350, 0
  store i64 %t351, ptr %l154, !tbaa !24
  %t352 = load i64, ptr %l154, !tbaa !24
  %t353 = mul i64 %t352, 16
  %t354 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t353)
  %t355 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t356 = insertvalue { i64, ptr } %t355, ptr %t354, 1
  store { i64, ptr } %t356, ptr %l155, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t360 = load ptr, ptr %t359, !tbaa !27
  %t361 = load i64, ptr %l154, !tbaa !24
  %t362 = mul i64 %t361, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t358, ptr %t360, i64 %t362, i1 false)
  %t363 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t364 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l149, i32 0, i32 1
  store { i64, ptr } %t363, ptr %t364, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t365 = load { { i64, ptr }, { i64, ptr } }, ptr %l149
  store { { i64, ptr }, { i64, ptr } } %t365, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local void @compiler_2fbuild_2eShaK_2einit() #0 {
entry:
  %l0 = alloca [64 x i32]
  br label %start
start:
  br label %bb0
bb0:
  %t1 = getelementptr [64 x i32], ptr %l0, i64 0, i64 0
  store i32 1116352408, ptr %t1
  %t2 = getelementptr [64 x i32], ptr %l0, i64 0, i64 1
  store i32 1899447441, ptr %t2
  %t3 = getelementptr [64 x i32], ptr %l0, i64 0, i64 2
  store i32 -1245643825, ptr %t3
  %t4 = getelementptr [64 x i32], ptr %l0, i64 0, i64 3
  store i32 -373957723, ptr %t4
  %t5 = getelementptr [64 x i32], ptr %l0, i64 0, i64 4
  store i32 961987163, ptr %t5
  %t6 = getelementptr [64 x i32], ptr %l0, i64 0, i64 5
  store i32 1508970993, ptr %t6
  %t7 = getelementptr [64 x i32], ptr %l0, i64 0, i64 6
  store i32 -1841331548, ptr %t7
  %t8 = getelementptr [64 x i32], ptr %l0, i64 0, i64 7
  store i32 -1424204075, ptr %t8
  %t9 = getelementptr [64 x i32], ptr %l0, i64 0, i64 8
  store i32 -670586216, ptr %t9
  %t10 = getelementptr [64 x i32], ptr %l0, i64 0, i64 9
  store i32 310598401, ptr %t10
  %t11 = getelementptr [64 x i32], ptr %l0, i64 0, i64 10
  store i32 607225278, ptr %t11
  %t12 = getelementptr [64 x i32], ptr %l0, i64 0, i64 11
  store i32 1426881987, ptr %t12
  %t13 = getelementptr [64 x i32], ptr %l0, i64 0, i64 12
  store i32 1925078388, ptr %t13
  %t14 = getelementptr [64 x i32], ptr %l0, i64 0, i64 13
  store i32 -2132889090, ptr %t14
  %t15 = getelementptr [64 x i32], ptr %l0, i64 0, i64 14
  store i32 -1680079193, ptr %t15
  %t16 = getelementptr [64 x i32], ptr %l0, i64 0, i64 15
  store i32 -1046744716, ptr %t16
  %t17 = getelementptr [64 x i32], ptr %l0, i64 0, i64 16
  store i32 -459576895, ptr %t17
  %t18 = getelementptr [64 x i32], ptr %l0, i64 0, i64 17
  store i32 -272742522, ptr %t18
  %t19 = getelementptr [64 x i32], ptr %l0, i64 0, i64 18
  store i32 264347078, ptr %t19
  %t20 = getelementptr [64 x i32], ptr %l0, i64 0, i64 19
  store i32 604807628, ptr %t20
  %t21 = getelementptr [64 x i32], ptr %l0, i64 0, i64 20
  store i32 770255983, ptr %t21
  %t22 = getelementptr [64 x i32], ptr %l0, i64 0, i64 21
  store i32 1249150122, ptr %t22
  %t23 = getelementptr [64 x i32], ptr %l0, i64 0, i64 22
  store i32 1555081692, ptr %t23
  %t24 = getelementptr [64 x i32], ptr %l0, i64 0, i64 23
  store i32 1996064986, ptr %t24
  %t25 = getelementptr [64 x i32], ptr %l0, i64 0, i64 24
  store i32 -1740746414, ptr %t25
  %t26 = getelementptr [64 x i32], ptr %l0, i64 0, i64 25
  store i32 -1473132947, ptr %t26
  %t27 = getelementptr [64 x i32], ptr %l0, i64 0, i64 26
  store i32 -1341970488, ptr %t27
  %t28 = getelementptr [64 x i32], ptr %l0, i64 0, i64 27
  store i32 -1084653625, ptr %t28
  %t29 = getelementptr [64 x i32], ptr %l0, i64 0, i64 28
  store i32 -958395405, ptr %t29
  %t30 = getelementptr [64 x i32], ptr %l0, i64 0, i64 29
  store i32 -710438585, ptr %t30
  %t31 = getelementptr [64 x i32], ptr %l0, i64 0, i64 30
  store i32 113926993, ptr %t31
  %t32 = getelementptr [64 x i32], ptr %l0, i64 0, i64 31
  store i32 338241895, ptr %t32
  %t33 = getelementptr [64 x i32], ptr %l0, i64 0, i64 32
  store i32 666307205, ptr %t33
  %t34 = getelementptr [64 x i32], ptr %l0, i64 0, i64 33
  store i32 773529912, ptr %t34
  %t35 = getelementptr [64 x i32], ptr %l0, i64 0, i64 34
  store i32 1294757372, ptr %t35
  %t36 = getelementptr [64 x i32], ptr %l0, i64 0, i64 35
  store i32 1396182291, ptr %t36
  %t37 = getelementptr [64 x i32], ptr %l0, i64 0, i64 36
  store i32 1695183700, ptr %t37
  %t38 = getelementptr [64 x i32], ptr %l0, i64 0, i64 37
  store i32 1986661051, ptr %t38
  %t39 = getelementptr [64 x i32], ptr %l0, i64 0, i64 38
  store i32 -2117940946, ptr %t39
  %t40 = getelementptr [64 x i32], ptr %l0, i64 0, i64 39
  store i32 -1838011259, ptr %t40
  %t41 = getelementptr [64 x i32], ptr %l0, i64 0, i64 40
  store i32 -1564481375, ptr %t41
  %t42 = getelementptr [64 x i32], ptr %l0, i64 0, i64 41
  store i32 -1474664885, ptr %t42
  %t43 = getelementptr [64 x i32], ptr %l0, i64 0, i64 42
  store i32 -1035236496, ptr %t43
  %t44 = getelementptr [64 x i32], ptr %l0, i64 0, i64 43
  store i32 -949202525, ptr %t44
  %t45 = getelementptr [64 x i32], ptr %l0, i64 0, i64 44
  store i32 -778901479, ptr %t45
  %t46 = getelementptr [64 x i32], ptr %l0, i64 0, i64 45
  store i32 -694614492, ptr %t46
  %t47 = getelementptr [64 x i32], ptr %l0, i64 0, i64 46
  store i32 -200395387, ptr %t47
  %t48 = getelementptr [64 x i32], ptr %l0, i64 0, i64 47
  store i32 275423344, ptr %t48
  %t49 = getelementptr [64 x i32], ptr %l0, i64 0, i64 48
  store i32 430227734, ptr %t49
  %t50 = getelementptr [64 x i32], ptr %l0, i64 0, i64 49
  store i32 506948616, ptr %t50
  %t51 = getelementptr [64 x i32], ptr %l0, i64 0, i64 50
  store i32 659060556, ptr %t51
  %t52 = getelementptr [64 x i32], ptr %l0, i64 0, i64 51
  store i32 883997877, ptr %t52
  %t53 = getelementptr [64 x i32], ptr %l0, i64 0, i64 52
  store i32 958139571, ptr %t53
  %t54 = getelementptr [64 x i32], ptr %l0, i64 0, i64 53
  store i32 1322822218, ptr %t54
  %t55 = getelementptr [64 x i32], ptr %l0, i64 0, i64 54
  store i32 1537002063, ptr %t55
  %t56 = getelementptr [64 x i32], ptr %l0, i64 0, i64 55
  store i32 1747873779, ptr %t56
  %t57 = getelementptr [64 x i32], ptr %l0, i64 0, i64 56
  store i32 1955562222, ptr %t57
  %t58 = getelementptr [64 x i32], ptr %l0, i64 0, i64 57
  store i32 2024104815, ptr %t58
  %t59 = getelementptr [64 x i32], ptr %l0, i64 0, i64 58
  store i32 -2067236844, ptr %t59
  %t60 = getelementptr [64 x i32], ptr %l0, i64 0, i64 59
  store i32 -1933114872, ptr %t60
  %t61 = getelementptr [64 x i32], ptr %l0, i64 0, i64 60
  store i32 -1866530822, ptr %t61
  %t62 = getelementptr [64 x i32], ptr %l0, i64 0, i64 61
  store i32 -1538233109, ptr %t62
  %t63 = getelementptr [64 x i32], ptr %l0, i64 0, i64 62
  store i32 -1090935817, ptr %t63
  %t64 = getelementptr [64 x i32], ptr %l0, i64 0, i64 63
  store i32 -965641998, ptr %t64
  call void @llvm.memmove.p0.p0.i64(ptr @G_2ecompiler_2fbuild_2eShaK, ptr %l0, i64 256, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr @.d16 })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  br label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr @.d17 }, 0
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } %t13, 0
  %t19 = add i64 %t15, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = getelementptr i8, ptr %t20, i64 %t15
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr @.d18 }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l1, !tbaa !27
  br label %bb57
bb4:
  %t7 = load i32, ptr %l0, !tbaa !23
  %t9 = icmp eq i32 %t7, 2
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 9, ptr @.d19 }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  br label %bb57
bb8:
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 3
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr @.d20 }, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  br label %bb57
bb12:
  %t19 = load i32, ptr %l0, !tbaa !23
  %t21 = icmp eq i32 %t19, 4
  br i1 %t21, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 19, ptr @.d21 }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l1, !tbaa !27
  br label %bb57
bb16:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = icmp eq i32 %t25, 5
  br i1 %t27, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 21, ptr @.d22 }, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  br label %bb57
bb20:
  %t31 = load i32, ptr %l0, !tbaa !23
  %t33 = icmp eq i32 %t31, 6
  br i1 %t33, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 7, ptr @.d23 }, ptr %l24, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t35, ptr %l1, !tbaa !27
  br label %bb57
bb24:
  %t37 = load i32, ptr %l0, !tbaa !23
  %t39 = icmp eq i32 %t37, 7
  br i1 %t39, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 9, ptr @.d24 }, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l1, !tbaa !27
  br label %bb57
bb28:
  %t43 = load i32, ptr %l0, !tbaa !23
  %t45 = icmp eq i32 %t43, 8
  br i1 %t45, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 24, ptr @.d25 }, ptr %l32, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t47, ptr %l1, !tbaa !27
  br label %bb57
bb32:
  %t49 = load i32, ptr %l0, !tbaa !23
  %t51 = icmp eq i32 %t49, 9
  br i1 %t51, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 6, ptr @.d26 }, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  br label %bb57
bb36:
  %t55 = load i32, ptr %l0, !tbaa !23
  %t57 = icmp eq i32 %t55, 11
  br i1 %t57, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 18, ptr @.d27 }, ptr %l40, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t59, ptr %l1, !tbaa !27
  br label %bb57
bb40:
  %t61 = load i32, ptr %l0, !tbaa !23
  %t63 = icmp eq i32 %t61, 13
  br i1 %t63, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 11, ptr @.d28 }, ptr %l44, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t65, ptr %l1, !tbaa !27
  br label %bb57
bb44:
  %t67 = load i32, ptr %l0, !tbaa !23
  %t69 = icmp eq i32 %t67, 14
  br i1 %t69, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 11, ptr @.d29 }, ptr %l48, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t71, ptr %l1, !tbaa !27
  br label %bb57
bb48:
  %t73 = load i32, ptr %l0, !tbaa !23
  %t75 = icmp eq i32 %t73, 15
  br i1 %t75, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 10, ptr @.d30 }, ptr %l52, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t77, ptr %l1, !tbaa !27
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t79 = load i32, ptr %l0, !tbaa !23
  %t80 = extractvalue { i64, ptr } { i64 15, ptr @.d31 }, 1
  %t81 = extractvalue { i64, ptr } { i64 15, ptr @.d31 }, 0
  %t83 = sext i32 %t79 to i64
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = getelementptr i8, ptr %t86, i64 %t81
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t83)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  store { i64, ptr } %t90, ptr %l1, !tbaa !27
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @.c32)
  unreachable
bb57:
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l56, !tbaa !24
  %t94 = load i64, ptr %l56, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l57, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t105, ptr %l1, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"std/os:Output"
  %l22 = alloca { i64, ptr }
  %l25 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l38 = alloca { i64, ptr }
  %l51 = alloca %"std/os:Output"
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"std/os:Output"
  %l56 = alloca i32
  %l63 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l68 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l81 = alloca i32
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l4, !tbaa !21
  store { i64, ptr } %a3, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l7, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l7, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l22, !tbaa !27
  %t16 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t16
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  %t23 = load ptr, ptr @__olang_prog_scope
  %t24 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %l25
  br label %bb5
bb5:
  %t25 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l25
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l9
  %t28 = extractvalue { i64, ptr } %a1, 1
  %t29 = extractvalue { i64, ptr } %a1, 0
  %t30 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t29)
  call void @olang_textcopy(ptr %t30, ptr %t28, i64 %t29)
  %t31 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 1
  %t37 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } %t39)
  br label %bb6
bb6:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } { i64 4, ptr @.d33 })
  br label %bb7
bb7:
  store { i64, ptr } %a2, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t45, 0
  store i64 %t47, ptr %l12, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s5
  %t49 = load i64, ptr %l11, !tbaa !24
  %t50 = load i64, ptr %l12, !tbaa !24
  %t53 = icmp slt i64 %t49, %t50
  %t55 = xor i1 %t53, true
  br i1 %t55, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s5)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t57 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t57, ptr %l38, !tbaa !27
  %t58 = load i64, ptr %l11, !tbaa !24
  %t60 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %t61, i64 %t58
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !37
  %t67 = extractvalue { i64, ptr } %t63, 1
  %t68 = extractvalue { i64, ptr } %t63, 0
  %t69 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t67, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } %t78)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s5)
  br label %bb13
bb13:
  %t81 = load i64, ptr %l11, !tbaa !24
  %t83 = add i64 %t81, 1
  store i64 %t83, ptr %l11, !tbaa !24
  br label %bb8
bb14:
  %t85 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = extractvalue { i64, ptr } %t85, 0
  %t89 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t88)
  call void @olang_textcopy(ptr %t89, ptr %t87, i64 %t88)
  %t90 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  %t94 = extractvalue { i64, ptr } %t91, 1
  %t95 = mul i64 %t93, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t95)
  call void @llvm.memcpy.p0.p0.i64(ptr %t96, ptr %t94, i64 %t95, i1 false)
  %t97 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s2, ptr %s2, ptr %l9, { i64, ptr } %t98)
  br label %bb15
bb15:
  %t102 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s2, ptr %s2, ptr %l9)
  store { i64, ptr } %t102, ptr %l53
  br label %bb16
bb16:
  store { i64, ptr } { i64 0, ptr @.d34 }, ptr %l54, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t105 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t103, { i64, ptr } %t104, i1 false, { i64, ptr } { i64 0, ptr @.d35 })
  %t106 = extractvalue { i32, %"std/os:Output" } %t105, 1
  %t107 = extractvalue { i32, %"std/os:Output" } %t105, 0
  store i32 %t107, ptr %l56
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb18, label %ok.109
ok.109:
  store %"std/os:Output" %t106, ptr %l55
  br label %bb17
bb17:
  %t110 = load %"std/os:Output", ptr %l55
  store %"std/os:Output" %t110, ptr %l51
  br label %bb24
bb18:
  %t111 = load i32, ptr %l56, !tbaa !23
  %t112 = ashr i32 %t111, 16
  %t114 = icmp eq i32 %t112, 1
  br i1 %t114, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @.c36)
  unreachable
bb21:
  store %olang.scope zeroinitializer, ptr %s9
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t117, 1
  %t120 = extractvalue { i64, ptr } %t117, 0
  %t121 = extractvalue { i64, ptr } { i64 35, ptr @.d37 }, 1
  %t122 = extractvalue { i64, ptr } { i64 35, ptr @.d37 }, 0
  %t123 = add i64 %t120, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t119, i64 %t120)
  %t125 = getelementptr i8, ptr %t124, i64 %t120
  call void @olang_textcopy(ptr %t125, ptr %t121, i64 %t122)
  %t126 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t124, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t137 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s9, ptr %s9, ptr %s9, ptr %t116, { i64, ptr } { i64 2, ptr @.d38 }, { i64, ptr } %t134)
  store { i64, ptr } %t137, ptr %l63
  br label %bb22
bb22:
  %t138 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  call void @compiler_2fbuild_2esayln(ptr %s9, { i64, ptr } %t144)
  br label %bb23
bb23:
  store i1 true, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb24:
  %t146 = load %"std/os:Output", ptr %l51
  store %"std/os:Output" %t146, ptr %l14
  %t147 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t148 = load i32, ptr %t147, !tbaa !23
  %t150 = icmp sgt i32 %t148, 128
  br i1 %t150, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s11
  %t152 = load ptr, ptr %l0, !tbaa !29
  store ptr %t152, ptr %l67, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t153, ptr %l68, !tbaa !27
  %t154 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t155 = load i32, ptr %t154, !tbaa !23
  %t157 = sub i32 %t155, 128
  %t159 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t157)
  store { i64, ptr } %t159, ptr %l71
  br label %bb27
bb26:
  br label %bb30
bb27:
  %t160 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } { i64 22, ptr @.d39 }, 1
  %t164 = extractvalue { i64, ptr } { i64 22, ptr @.d39 }, 0
  %t165 = add i64 %t162, %t164
  %t166 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = add i64 %t165, %t168
  %t170 = extractvalue { i64, ptr } { i64 11, ptr @.d40 }, 1
  %t171 = extractvalue { i64, ptr } { i64 11, ptr @.d40 }, 0
  %t172 = add i64 %t169, %t171
  %t173 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t172)
  call void @olang_textcopy(ptr %t173, ptr %t161, i64 %t162)
  %t174 = getelementptr i8, ptr %t173, i64 %t162
  call void @olang_textcopy(ptr %t174, ptr %t163, i64 %t164)
  %t175 = getelementptr i8, ptr %t174, i64 %t164
  call void @olang_textcopy(ptr %t175, ptr %t167, i64 %t168)
  %t176 = getelementptr i8, ptr %t175, i64 %t168
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t173, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t186 = load ptr, ptr %l67, !tbaa !29
  %t188 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s11, ptr %s11, ptr %s11, ptr %t186, { i64, ptr } { i64 2, ptr @.d41 }, { i64, ptr } %t185)
  store { i64, ptr } %t188, ptr %l74
  br label %bb28
bb28:
  %t189 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = extractvalue { i64, ptr } %t189, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t195)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s11)
  br label %bb30
bb30:
  %t197 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t198 = load i32, ptr %t197, !tbaa !23
  %t200 = icmp ne i32 %t198, 0
  br i1 %t200, label %bb31, label %bb32
bb31:
  store i1 true, ptr %l4, !tbaa !21
  br label %bb33
bb32:
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s2)
  br label %bb34
bb34:
  %t202 = load i64, ptr %l6, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l6, !tbaa !24
  br label %bb1
bb35:
  %t206 = load i1, ptr %l4, !tbaa !21
  br i1 %t206, label %bb36, label %bb37
bb36:
  store i32 1, ptr %l81, !tbaa !23
  br label %bb38
bb37:
  store i32 0, ptr %l81, !tbaa !23
  br label %bb38
bb38:
  %t208 = load i32, ptr %l81, !tbaa !23
  store i32 %t208, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2eThinFrom_2einit() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  store i64 8388608, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = extractvalue { i64, ptr } { i64 62, ptr @.d42 }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr @.d42 }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t18)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v2, ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 8, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l4
  %t6 = load ptr, ptr %lp2
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 4
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store { i64, ptr } { i64 6, ptr @.d43 }, ptr %l10, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t16 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t15)
  store i1 %t16, ptr %l11
  br label %bb4
bb3:
  store i1 false, ptr %l7, !tbaa !21
  br label %bb5
bb4:
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %l7, !tbaa !21
  br label %bb5
bb5:
  %t18 = load i1, ptr %l7, !tbaa !21
  br i1 %t18, label %bb6, label %bb7
bb6:
  %t19 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t19, { i64, ptr } { i64 6, ptr @.d44 })
  br label %bb8
bb7:
  br label %bb10
bb8:
  %t21 = load ptr, ptr %lp2
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v2, ptr %v2, ptr %t21, { i64, ptr } { i64 16, ptr @.d45 })
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t23 = load ptr, ptr %lp2
  %t24 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t23
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t24, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %l21 = alloca i64
  %l22 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/os:Output"
  %l27 = alloca %"std/os:FileInfo"
  %l28 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l35 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l37 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l51 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i32
  %l94 = alloca { i64, ptr }
  %l111 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l127 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l147 = alloca i1
  %l149 = alloca i32
  %l155 = alloca i1
  %l157 = alloca %"std/os:Output"
  %l159 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l161 = alloca %"std/os:Output"
  %l162 = alloca i32
  %l170 = alloca ptr
  %l173 = alloca %"std/os:FileInfo"
  %l175 = alloca %"std/os:FileInfo"
  %l176 = alloca i32
  %l187 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l28
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l28
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l4
  %t4 = load ptr, ptr %l0, !tbaa !29
  %t6 = getelementptr %"compiler/build:Config", ptr %t4, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 1
  %t10 = extractvalue { i64, ptr } %t7, 0
  %t11 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t9, i64 %t10)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  %t16 = extractvalue { i64, ptr } %t13, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t20)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s2, ptr %t23)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t25, ptr %l35
  br label %bb3
bb3:
  %t26 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l35
  %t27 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t26, ptr %t27
  store ptr %t27, ptr %l5, !tbaa !29
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load ptr, ptr %l5, !tbaa !29
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s2, ptr %t29, i64 %t30)
  %t34 = extractvalue { i32, { i64, ptr } } %t33, 1
  %t35 = extractvalue { i32, { i64, ptr } } %t33, 0
  store i32 %t35, ptr %l41
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb6, label %ok.37
ok.37:
  store { i64, ptr } %t34, ptr %l40
  br label %bb5
bb5:
  %t38 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t38, ptr %l37, !tbaa !27
  br label %bb10
bb6:
  %t39 = load i32, ptr %l41, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  br i1 %t42, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  %t44 = load i32, ptr %l41, !tbaa !23
  %t45 = lshr i32 %t44, 16
  %t46 = and i32 %t44, 65535
  %t47 = icmp eq i32 %t45, 1
  %t48 = select i1 %t47, i32 0, i32 0
  %t49 = icmp eq i32 %t44, 0
  %t50 = shl i32 %t48, 16
  %t51 = or i32 %t50, %t46
  %t52 = select i1 %t49, i32 0, i32 %t51
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t52, ptr %rv
  br label %ret
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb10:
  %t54 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t54, ptr %l7, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 0
  store i64 %t57, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s4
  %t59 = load i64, ptr %l9, !tbaa !24
  %t60 = load i64, ptr %l8, !tbaa !24
  %t63 = icmp slt i64 %t59, %t60
  %t65 = xor i1 %t63, true
  br i1 %t65, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s4)
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t67 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t67, ptr %l51, !tbaa !27
  %t68 = load i64, ptr %l9, !tbaa !24
  %t70 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t71 = load ptr, ptr %t70, !tbaa !27
  %t72 = getelementptr { i64, ptr }, ptr %t71, i64 %t68
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !37
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @olang_textcopy(ptr %t79, ptr %t77, i64 %t78)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  %t83 = extractvalue { i64, ptr } %t81, 0
  %t84 = extractvalue { i64, ptr } %t81, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t88)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s4)
  br label %bb16
bb16:
  %t91 = load i64, ptr %l9, !tbaa !24
  %t93 = add i64 %t91, 1
  store i64 %t93, ptr %l9, !tbaa !24
  br label %bb11
bb17:
  %t95 = load i64, ptr %l6, !tbaa !24
  %t96 = load i64, ptr %l8, !tbaa !24
  %t99 = add i64 %t95, %t96
  store i64 %t99, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb18
bb18:
  br label %bb4
bb19:
  call void @__olang_scope_close(ptr %s2)
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/build:Config", ptr %t101, i32 0, i32 16
  %t104 = load i1, ptr %t103, !tbaa !21
  br i1 %t104, label %bb20, label %bb21
bb20:
  %t106 = load ptr, ptr %l0, !tbaa !29
  %t108 = getelementptr %"compiler/build:Config", ptr %t106, i32 0, i32 0
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t110 = extractvalue { i64, ptr } { i64 26, ptr @.d46 }, 1
  %t111 = extractvalue { i64, ptr } { i64 26, ptr @.d46 }, 0
  %t113 = extractvalue { i64, ptr } %t109, 1
  %t114 = extractvalue { i64, ptr } %t109, 0
  %t115 = add i64 %t111, %t114
  %t116 = extractvalue { i64, ptr } { i64 8, ptr @.d47 }, 1
  %t117 = extractvalue { i64, ptr } { i64 8, ptr @.d47 }, 0
  %t118 = add i64 %t115, %t117
  %t119 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t118)
  call void @olang_textcopy(ptr %t119, ptr %t110, i64 %t111)
  %t120 = getelementptr i8, ptr %t119, i64 %t111
  call void @olang_textcopy(ptr %t120, ptr %t113, i64 %t114)
  %t121 = getelementptr i8, ptr %t120, i64 %t114
  call void @olang_textcopy(ptr %t121, ptr %t116, i64 %t117)
  %t122 = insertvalue { i64, ptr } undef, i64 %t118, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t119, 1
  %t125 = extractvalue { i64, ptr } %t123, 0
  %t126 = extractvalue { i64, ptr } %t123, 1
  %t127 = mul i64 %t125, 1
  %t128 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t127)
  call void @llvm.memcpy.p0.p0.i64(ptr %t128, ptr %t126, i64 %t127, i1 false)
  %t129 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t130 = insertvalue { i64, ptr } %t129, ptr %t128, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t130)
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t133 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t134 = extractvalue { i64, ptr } { i64 36, ptr @.d48 }, 1
  %t135 = extractvalue { i64, ptr } { i64 36, ptr @.d48 }, 0
  %t137 = call i64 @__olang_fmt_i64(ptr null, i64 %t133)
  %t138 = add i64 %t135, %t137
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t134, i64 %t135)
  %t140 = getelementptr i8, ptr %t139, i64 %t135
  %t141 = call i64 @__olang_fmt_i64(ptr %t140, i64 %t133)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t139, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t150)
  br label %bb23
bb23:
  br label %bb24
bb24:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 2, ptr @.d49 })
  br label %bb25
bb25:
  %t154 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = extractvalue { i64, ptr } %t154, 0
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @olang_textcopy(ptr %t158, ptr %t156, i64 %t157)
  %t159 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = extractvalue { i64, ptr } %t160, 0
  %t163 = extractvalue { i64, ptr } %t160, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t167)
  br label %bb26
bb26:
  store ptr %a1, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb27
bb27:
  store %olang.scope zeroinitializer, ptr %s12
  %t172 = load ptr, ptr %l11, !tbaa !29
  %t173 = load i64, ptr %l12, !tbaa !24
  %t176 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v1, ptr %t172, i64 %t173)
  %t177 = extractvalue { i32, { i64, ptr } } %t176, 1
  %t178 = extractvalue { i32, { i64, ptr } } %t176, 0
  store i32 %t178, ptr %l84
  %t179 = icmp ne i32 %t178, 0
  br i1 %t179, label %bb29, label %ok.180
ok.180:
  store { i64, ptr } %t177, ptr %l83
  br label %bb28
bb28:
  %t181 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t181, ptr %l80, !tbaa !27
  br label %bb33
bb29:
  %t182 = load i32, ptr %l84, !tbaa !23
  %t183 = ashr i32 %t182, 16
  %t185 = icmp eq i32 %t183, 1
  br i1 %t185, label %bb30, label %bb31
bb30:
  br label %bb32
bb31:
  %t187 = load i32, ptr %l84, !tbaa !23
  %t188 = lshr i32 %t187, 16
  %t189 = and i32 %t187, 65535
  %t190 = icmp eq i32 %t188, 1
  %t191 = select i1 %t190, i32 0, i32 0
  %t192 = icmp eq i32 %t187, 0
  %t193 = shl i32 %t191, 16
  %t194 = or i32 %t193, %t189
  %t195 = select i1 %t192, i32 0, i32 %t194
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t195, ptr %rv
  br label %ret
bb32:
  call void @__olang_scope_close(ptr %s12)
  br label %bb42
bb33:
  %t197 = load { i64, ptr }, ptr %l80, !tbaa !27
  store { i64, ptr } %t197, ptr %l13, !tbaa !27
  %t198 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t198, 0
  store i64 %t200, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb34
bb34:
  store %olang.scope zeroinitializer, ptr %s13
  %t202 = load i64, ptr %l15, !tbaa !24
  %t203 = load i64, ptr %l14, !tbaa !24
  %t206 = icmp slt i64 %t202, %t203
  %t208 = xor i1 %t206, true
  br i1 %t208, label %bb35, label %bb36
bb35:
  call void @__olang_scope_close(ptr %s13)
  br label %bb40
bb36:
  br label %bb37
bb37:
  %t210 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t210, ptr %l94, !tbaa !27
  %t211 = load i64, ptr %l15, !tbaa !24
  %t213 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t214 = load ptr, ptr %t213, !tbaa !27
  %t215 = getelementptr { i64, ptr }, ptr %t214, i64 %t211
  %t216 = load { i64, ptr }, ptr %t215, !tbaa !37
  %t220 = extractvalue { i64, ptr } %t216, 1
  %t221 = extractvalue { i64, ptr } %t216, 0
  %t222 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t221)
  call void @olang_textcopy(ptr %t222, ptr %t220, i64 %t221)
  %t223 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = extractvalue { i64, ptr } %t224, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } %t231)
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s13)
  br label %bb39
bb39:
  %t234 = load i64, ptr %l15, !tbaa !24
  %t236 = add i64 %t234, 1
  store i64 %t236, ptr %l15, !tbaa !24
  br label %bb34
bb40:
  %t238 = load i64, ptr %l12, !tbaa !24
  %t239 = load i64, ptr %l14, !tbaa !24
  %t242 = add i64 %t238, %t239
  store i64 %t242, ptr %l12, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb41
bb41:
  br label %bb27
bb42:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 3, ptr @.d50 })
  br label %bb43
bb43:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 9, ptr @.d51 })
  br label %bb44
bb44:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 4, ptr @.d52 })
  br label %bb45
bb45:
  br i1 %a3, label %bb46, label %bb47
bb46:
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l4, { i64, ptr } { i64 5, ptr @.d53 })
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t250 = load ptr, ptr @__olang_prog_scope
  %t251 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t250)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t251, ptr %l111
  br label %bb50
bb50:
  %t252 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l111
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t252, ptr %l17
  store ptr %l4, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s18
  %t254 = load ptr, ptr %l18, !tbaa !29
  %t255 = load i64, ptr %l19, !tbaa !24
  %t258 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t254, i64 %t255)
  %t259 = extractvalue { i32, { i64, ptr } } %t258, 1
  %t260 = extractvalue { i32, { i64, ptr } } %t258, 0
  store i32 %t260, ptr %l117
  %t261 = icmp ne i32 %t260, 0
  br i1 %t261, label %bb53, label %ok.262
ok.262:
  store { i64, ptr } %t259, ptr %l116
  br label %bb52
bb52:
  %t263 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t263, ptr %l113, !tbaa !27
  br label %bb57
bb53:
  %t264 = load i32, ptr %l117, !tbaa !23
  %t265 = ashr i32 %t264, 16
  %t267 = icmp eq i32 %t265, 1
  br i1 %t267, label %bb54, label %bb55
bb54:
  br label %bb56
bb55:
  %t269 = load i32, ptr %l117, !tbaa !23
  %t270 = lshr i32 %t269, 16
  %t271 = and i32 %t269, 65535
  %t272 = icmp eq i32 %t270, 1
  %t273 = select i1 %t272, i32 0, i32 0
  %t274 = icmp eq i32 %t269, 0
  %t275 = shl i32 %t273, 16
  %t276 = or i32 %t275, %t271
  %t277 = select i1 %t274, i32 0, i32 %t276
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t277, ptr %rv
  br label %ret
bb56:
  call void @__olang_scope_close(ptr %s18)
  br label %bb66
bb57:
  %t279 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t279, ptr %l20, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t282 = extractvalue { i64, ptr } %t280, 0
  store i64 %t282, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb58
bb58:
  store %olang.scope zeroinitializer, ptr %s19
  %t284 = load i64, ptr %l22, !tbaa !24
  %t285 = load i64, ptr %l21, !tbaa !24
  %t288 = icmp slt i64 %t284, %t285
  %t290 = xor i1 %t288, true
  br i1 %t290, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s19)
  br label %bb64
bb60:
  br label %bb61
bb61:
  %t292 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t292, ptr %l127, !tbaa !27
  %t293 = load i64, ptr %l22, !tbaa !24
  %t295 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = getelementptr { i64, ptr }, ptr %t296, i64 %t293
  %t298 = load { i64, ptr }, ptr %t297, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t298)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s19)
  br label %bb63
bb63:
  %t303 = load i64, ptr %l22, !tbaa !24
  %t305 = add i64 %t303, 1
  store i64 %t305, ptr %l22, !tbaa !24
  br label %bb58
bb64:
  %t307 = load i64, ptr %l19, !tbaa !24
  %t308 = load i64, ptr %l21, !tbaa !24
  %t311 = add i64 %t307, %t308
  store i64 %t311, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb65
bb65:
  br label %bb51
bb66:
  store ptr %l17, ptr %l137, !tbaa !29
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t315 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t313)
  store { i64, ptr } %t315, ptr %l139
  br label %bb67
bb67:
  %t316 = load ptr, ptr %l137, !tbaa !29
  %t317 = load { i64, ptr }, ptr %l139, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t316, { i64, ptr } %t317)
  br label %bb68
bb68:
  %t319 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t319, ptr %l141
  br label %bb69
bb69:
  %t320 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t320, ptr %l24, !tbaa !27
  %t321 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t323 = extractvalue { i64, ptr } %t321, 1
  %t324 = extractvalue { i64, ptr } %t321, 0
  %t325 = extractvalue { i64, ptr } { i64 5, ptr @.d54 }, 1
  %t326 = extractvalue { i64, ptr } { i64 5, ptr @.d54 }, 0
  %t327 = add i64 %t324, %t326
  %t328 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t323, i64 %t324)
  %t329 = getelementptr i8, ptr %t328, i64 %t324
  call void @olang_textcopy(ptr %t329, ptr %t325, i64 %t326)
  %t330 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t328, 1
  store { i64, ptr } %t331, ptr %l25, !tbaa !27
  %t333 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t334 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t335 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t339 = call i1 @compiler_2fbuild_2elinkCurrent(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t333, { i64, ptr } %t334, { i64, ptr } %t335)
  store i1 %t339, ptr %l147
  br label %bb70
bb70:
  %t340 = load i1, ptr %l147, !tbaa !21
  br i1 %t340, label %bb71, label %bb72
bb71:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb72:
  br label %bb73
bb73:
  %t341 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t343 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t341)
  store i32 %t343, ptr %l149
  %t344 = icmp ne i32 %t343, 0
  br i1 %t344, label %bb75, label %ok.345
ok.345:
  br label %bb74
bb74:
  br label %bb79
bb75:
  %t346 = load i32, ptr %l149, !tbaa !23
  %t347 = ashr i32 %t346, 16
  %t349 = icmp eq i32 %t347, 1
  br i1 %t349, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  %t351 = load i32, ptr %l149, !tbaa !23
  %t352 = lshr i32 %t351, 16
  %t353 = and i32 %t351, 65535
  %t354 = icmp eq i32 %t352, 1
  %t355 = select i1 %t354, i32 0, i32 0
  %t356 = icmp eq i32 %t351, 0
  %t357 = shl i32 %t355, 16
  %t358 = or i32 %t357, %t353
  %t359 = select i1 %t356, i32 0, i32 %t358
  call void @__olang_scope_close(ptr %s0)
  store i32 %t359, ptr %rv
  br label %ret
bb78:
  br label %bb79
bb79:
  %t361 = load ptr, ptr %l0, !tbaa !29
  %t363 = getelementptr %"compiler/build:Config", ptr %t361, i32 0, i32 1
  %t364 = load { i64, ptr }, ptr %t363, !tbaa !27
  %t366 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t364, { i64, ptr } { i64 0, ptr @.d55 })
  store i1 %t366, ptr %l155
  br label %bb80
bb80:
  %t367 = load i1, ptr %l155, !tbaa !21
  br i1 %t367, label %bb81, label %bb82
bb81:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb82:
  br label %bb83
bb83:
  %t370 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t370, ptr %l159
  br label %bb84
bb84:
  store { i64, ptr } { i64 0, ptr @.d56 }, ptr %l160, !tbaa !27
  %t371 = load { i64, ptr }, ptr %l159, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t373 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t371, { i64, ptr } %t372, i1 false, { i64, ptr } { i64 0, ptr @.d57 })
  %t374 = extractvalue { i32, %"std/os:Output" } %t373, 1
  %t375 = extractvalue { i32, %"std/os:Output" } %t373, 0
  store i32 %t375, ptr %l162
  %t376 = icmp ne i32 %t375, 0
  br i1 %t376, label %bb86, label %ok.377
ok.377:
  store %"std/os:Output" %t374, ptr %l161
  br label %bb85
bb85:
  %t378 = load %"std/os:Output", ptr %l161
  store %"std/os:Output" %t378, ptr %l157
  br label %bb90
bb86:
  %t379 = load i32, ptr %l162, !tbaa !23
  %t380 = ashr i32 %t379, 16
  %t382 = icmp eq i32 %t380, 1
  br i1 %t382, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  %t384 = load i32, ptr %l162, !tbaa !23
  %t385 = lshr i32 %t384, 16
  %t386 = and i32 %t384, 65535
  %t387 = icmp eq i32 %t385, 1
  %t388 = select i1 %t387, i32 0, i32 0
  %t389 = icmp eq i32 %t384, 0
  %t390 = shl i32 %t388, 16
  %t391 = or i32 %t390, %t386
  %t392 = select i1 %t389, i32 0, i32 %t391
  call void @__olang_scope_close(ptr %s0)
  store i32 %t392, ptr %rv
  br label %ret
bb89:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb90:
  %t395 = load %"std/os:Output", ptr %l157
  store %"std/os:Output" %t395, ptr %l26
  %t396 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 0
  %t397 = load i32, ptr %t396, !tbaa !23
  %t399 = icmp ne i32 %t397, 0
  br i1 %t399, label %bb91, label %bb92
bb91:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb92:
  br label %bb93
bb93:
  %t402 = load ptr, ptr %l0, !tbaa !29
  store ptr %t402, ptr %l170, !tbaa !29
  %t403 = load ptr, ptr %l170, !tbaa !29
  %t404 = getelementptr %"compiler/build:Config", ptr %t403, i32 0, i32 15
  %t405 = load i64, ptr %t404, !tbaa !24
  %t407 = add i64 %t405, 1
  %t409 = load ptr, ptr %l170, !tbaa !29
  %t410 = getelementptr %"compiler/build:Config", ptr %t409, i32 0, i32 15
  store i64 %t407, ptr %t410, !tbaa !24
  %t411 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t413 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t411)
  %t414 = extractvalue { i32, %"std/os:FileInfo" } %t413, 1
  %t415 = extractvalue { i32, %"std/os:FileInfo" } %t413, 0
  store i32 %t415, ptr %l176
  %t416 = icmp ne i32 %t415, 0
  br i1 %t416, label %bb95, label %ok.417
ok.417:
  store %"std/os:FileInfo" %t414, ptr %l175
  br label %bb94
bb94:
  %t418 = load %"std/os:FileInfo", ptr %l175
  store %"std/os:FileInfo" %t418, ptr %l173
  br label %bb99
bb95:
  %t419 = load i32, ptr %l176, !tbaa !23
  %t420 = ashr i32 %t419, 16
  %t422 = icmp eq i32 %t420, 1
  br i1 %t422, label %bb96, label %bb97
bb96:
  br label %bb98
bb97:
  %t424 = load i32, ptr %l176, !tbaa !23
  %t425 = lshr i32 %t424, 16
  %t426 = and i32 %t424, 65535
  %t427 = icmp eq i32 %t425, 1
  %t428 = select i1 %t427, i32 0, i32 0
  %t429 = icmp eq i32 %t424, 0
  %t430 = shl i32 %t428, 16
  %t431 = or i32 %t430, %t426
  %t432 = select i1 %t429, i32 0, i32 %t431
  call void @__olang_scope_close(ptr %s0)
  store i32 %t432, ptr %rv
  br label %ret
bb98:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb99:
  %t434 = load %"std/os:FileInfo", ptr %l173
  store %"std/os:FileInfo" %t434, ptr %l27
  %t435 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t436 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t437 = getelementptr %"std/os:FileInfo", ptr %l27, i32 0, i32 1
  %t438 = load i64, ptr %t437, !tbaa !24
  %t439 = getelementptr %"std/os:FileInfo", ptr %l27, i32 0, i32 2
  %t440 = load i64, ptr %t439, !tbaa !24
  %t442 = extractvalue { i64, ptr } %t436, 1
  %t443 = extractvalue { i64, ptr } %t436, 0
  %t444 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 1
  %t445 = extractvalue { i64, ptr } { i64 1, ptr @.d58 }, 0
  %t446 = add i64 %t443, %t445
  %t448 = call i64 @__olang_fmt_i64(ptr null, i64 %t438)
  %t449 = add i64 %t446, %t448
  %t450 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 1
  %t451 = extractvalue { i64, ptr } { i64 1, ptr @.d59 }, 0
  %t452 = add i64 %t449, %t451
  %t454 = call i64 @__olang_fmt_i64(ptr null, i64 %t440)
  %t455 = add i64 %t452, %t454
  %t456 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 1
  %t457 = extractvalue { i64, ptr } { i64 1, ptr @.d60 }, 0
  %t458 = add i64 %t455, %t457
  %t459 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t458)
  call void @olang_textcopy(ptr %t459, ptr %t442, i64 %t443)
  %t460 = getelementptr i8, ptr %t459, i64 %t443
  call void @olang_textcopy(ptr %t460, ptr %t444, i64 %t445)
  %t461 = getelementptr i8, ptr %t460, i64 %t445
  %t462 = call i64 @__olang_fmt_i64(ptr %t461, i64 %t438)
  %t463 = getelementptr i8, ptr %t461, i64 %t448
  call void @olang_textcopy(ptr %t463, ptr %t450, i64 %t451)
  %t464 = getelementptr i8, ptr %t463, i64 %t451
  %t465 = call i64 @__olang_fmt_i64(ptr %t464, i64 %t440)
  %t466 = getelementptr i8, ptr %t464, i64 %t454
  call void @olang_textcopy(ptr %t466, ptr %t456, i64 %t457)
  %t467 = insertvalue { i64, ptr } undef, i64 %t458, 0
  %t468 = insertvalue { i64, ptr } %t467, ptr %t459, 1
  %t471 = extractvalue { i64, ptr } %t468, 0
  %t472 = extractvalue { i64, ptr } %t468, 1
  %t473 = mul i64 %t471, 1
  %t474 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t473)
  call void @llvm.memcpy.p0.p0.i64(ptr %t474, ptr %t472, i64 %t473, i1 false)
  %t475 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t474, 1
  %t479 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t435, { i64, ptr } %t476)
  store i32 %t479, ptr %l187
  %t480 = icmp ne i32 %t479, 0
  br i1 %t480, label %bb101, label %ok.481
ok.481:
  br label %bb100
bb100:
  br label %bb105
bb101:
  %t482 = load i32, ptr %l187, !tbaa !23
  %t483 = ashr i32 %t482, 16
  %t485 = icmp eq i32 %t483, 1
  br i1 %t485, label %bb102, label %bb103
bb102:
  br label %bb104
bb103:
  %t487 = load i32, ptr %l187, !tbaa !23
  %t488 = lshr i32 %t487, 16
  %t489 = and i32 %t487, 65535
  %t490 = icmp eq i32 %t488, 1
  %t491 = select i1 %t490, i32 0, i32 0
  %t492 = icmp eq i32 %t487, 0
  %t493 = shl i32 %t491, 16
  %t494 = or i32 %t493, %t489
  %t495 = select i1 %t492, i32 0, i32 %t494
  call void @__olang_scope_close(ptr %s0)
  store i32 %t495, ptr %rv
  br label %ret
bb104:
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l12 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l2
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t4, ptr %t5
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 2
  %t9 = getelementptr %"compiler/target:Target", ptr %t8, i32 0, i32 9
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp1
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/build:Config", ptr %t13, i32 0, i32 2
  %t16 = getelementptr %"compiler/target:Target", ptr %t15, i32 0, i32 1
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t18 = extractvalue { i64, ptr } { i64 9, ptr @.d61 }, 1
  %t19 = extractvalue { i64, ptr } { i64 9, ptr @.d61 }, 0
  %t21 = extractvalue { i64, ptr } %t17, 1
  %t22 = extractvalue { i64, ptr } %t17, 0
  %t23 = add i64 %t19, %t22
  %t24 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t23)
  call void @olang_textcopy(ptr %t24, ptr %t18, i64 %t19)
  %t25 = getelementptr i8, ptr %t24, i64 %t19
  call void @olang_textcopy(ptr %t25, ptr %t21, i64 %t22)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  %t29 = extractvalue { i64, ptr } %t27, 0
  %t30 = extractvalue { i64, ptr } %t27, 1
  %t31 = mul i64 %t29, 1
  %t32 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t31)
  call void @llvm.memcpy.p0.p0.i64(ptr %t32, ptr %t30, i64 %t31, i1 false)
  %t33 = insertvalue { i64, ptr } undef, i64 %t29, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t32, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t12, { i64, ptr } %t34)
  br label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l0, !tbaa !29
  %t39 = getelementptr %"compiler/build:Config", ptr %t37, i32 0, i32 2
  %t40 = getelementptr %"compiler/target:Target", ptr %t39, i32 0, i32 6
  %t41 = load { i64, ptr }, ptr %t40, !tbaa !27
  %t43 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t41, { i64, ptr } { i64 0, ptr @.d62 })
  store i1 %t43, ptr %l12
  br label %bb6
bb6:
  %t44 = load i1, ptr %l12, !tbaa !21
  %t45 = xor i1 %t44, true
  br i1 %t45, label %bb7, label %bb8
bb7:
  %t47 = load ptr, ptr %lp1
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/build:Config", ptr %t48, i32 0, i32 2
  %t51 = getelementptr %"compiler/target:Target", ptr %t50, i32 0, i32 6
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t52, 1
  %t55 = extractvalue { i64, ptr } %t52, 0
  %t56 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t54, i64 %t55)
  %t57 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t56, 1
  %t60 = extractvalue { i64, ptr } %t58, 0
  %t61 = extractvalue { i64, ptr } %t58, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t47, { i64, ptr } %t65)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  %t68 = load ptr, ptr %l0, !tbaa !29
  %t70 = getelementptr %"compiler/build:Config", ptr %t68, i32 0, i32 4
  %t71 = load i1, ptr %t70, !tbaa !21
  br i1 %t71, label %bb11, label %bb12
bb11:
  %t73 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t73, { i64, ptr } { i64 3, ptr @.d63 })
  br label %bb13
bb12:
  br label %bb19
bb13:
  %t75 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t75, { i64, ptr } { i64 2, ptr @.d64 })
  br label %bb14
bb14:
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Config", ptr %t77, i32 0, i32 5
  %t80 = load i1, ptr %t79, !tbaa !21
  br i1 %t80, label %bb15, label %bb16
bb15:
  %t82 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t82, { i64, ptr } { i64 17, ptr @.d65 })
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t84 = load ptr, ptr %lp1
  %t85 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t84
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t85, ptr %rv
  br label %ret
bb19:
  %t87 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"compiler/build:Config", ptr %t87, i32 0, i32 5
  %t90 = load i1, ptr %t89, !tbaa !21
  br i1 %t90, label %bb20, label %bb21
bb20:
  %t92 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t92, { i64, ptr } { i64 3, ptr @.d66 })
  br label %bb22
bb21:
  br label %bb24
bb22:
  %t94 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t94, { i64, ptr } { i64 17, ptr @.d67 })
  br label %bb23
bb23:
  %t96 = load ptr, ptr %lp1
  %t97 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t96
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t97, ptr %rv
  br label %ret
bb24:
  %t99 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t99, { i64, ptr } { i64 3, ptr @.d68 })
  br label %bb25
bb25:
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"compiler/build:Config", ptr %t101, i32 0, i32 16
  %t104 = load i1, ptr %t103, !tbaa !21
  br i1 %t104, label %bb26, label %bb27
bb26:
  %t106 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t106, { i64, ptr } { i64 10, ptr @.d69 })
  br label %bb28
bb27:
  %t108 = load ptr, ptr %lp1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t108, { i64, ptr } { i64 5, ptr @.d70 })
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t110 = load ptr, ptr %lp1
  %t111 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t110
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t111, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l17 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i32
  %l30 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l52 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l13
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l13
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l5
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v2, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  store ptr %a4, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t10 = load i64, ptr %l7, !tbaa !24
  %t13 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v3, ptr %t9, i64 %t10)
  %t14 = extractvalue { i32, { i64, ptr } } %t13, 1
  %t15 = extractvalue { i32, { i64, ptr } } %t13, 0
  store i32 %t15, ptr %l21
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17
ok.17:
  store { i64, ptr } %t14, ptr %l20
  br label %bb4
bb4:
  %t18 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t18, ptr %l17, !tbaa !27
  br label %bb9
bb5:
  %t19 = load i32, ptr %l21, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb9:
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l8, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t27 = extractvalue { i64, ptr } %t25, 0
  store i64 %t27, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t29 = load i64, ptr %l10, !tbaa !24
  %t30 = load i64, ptr %l9, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb11, label %bb12
bb11:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb12:
  br label %bb13
bb13:
  %t37 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t37, ptr %l30, !tbaa !27
  %t38 = load i64, ptr %l10, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %t41, i64 %t38
  %t43 = load { i64, ptr }, ptr %t42, !tbaa !37
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %t43)
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  %t48 = load i64, ptr %l10, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l10, !tbaa !24
  br label %bb10
bb16:
  %t52 = load i64, ptr %l7, !tbaa !24
  %t53 = load i64, ptr %l9, !tbaa !24
  %t56 = add i64 %t52, %t53
  store i64 %t56, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb17
bb17:
  br label %bb3
bb18:
  store ptr %l5, ptr %l40, !tbaa !29
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t60 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %t58)
  store { i64, ptr } %t60, ptr %l42
  br label %bb19
bb19:
  %t61 = load ptr, ptr %l40, !tbaa !29
  %t62 = load { i64, ptr }, ptr %l42, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %s0, ptr %v0, ptr %t61, { i64, ptr } %t62)
  br label %bb20
bb20:
  %t64 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t64, ptr %l44
  br label %bb21
bb21:
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t65, ptr %l12, !tbaa !27
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t66, i32 0, i32 0
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l46, !tbaa !27
  store { i64, ptr } %a1, ptr %l47, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l48, !tbaa !24
  %t73 = icmp sge i64 0, 0
  br i1 %t73, label %bb22, label %bb23
bb22:
  %t75 = icmp sle i64 0, 16
  br i1 %t75, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb24:
  %t77 = load i64, ptr %l48, !tbaa !24
  %t78 = icmp sle i64 16, %t77
  br i1 %t78, label %bb26, label %bb27
bb25:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb26:
  %t80 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 0
  %t83 = sub i64 16, 0
  %t84 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  store { i64, ptr } %t85, ptr %l52, !tbaa !27
  %t88 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %a2)
  store { i64, ptr } %t88, ptr %l54
  br label %bb28
bb27:
  call void @__olang_check_failed(ptr @.c72)
  unreachable
bb28:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t89)
  store { i64, ptr } %t91, ptr %l56
  br label %bb29
bb29:
  %t92 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 1
  %t96 = extractvalue { i64, ptr } { i64 1, ptr @.d73 }, 0
  %t97 = add i64 %t94, %t96
  %t98 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 1
  %t100 = extractvalue { i64, ptr } %t98, 0
  %t101 = add i64 %t97, %t100
  %t102 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 1
  %t103 = extractvalue { i64, ptr } { i64 1, ptr @.d74 }, 0
  %t104 = add i64 %t101, %t103
  %t105 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 1
  %t107 = extractvalue { i64, ptr } %t105, 0
  %t108 = add i64 %t104, %t107
  %t109 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 1
  %t111 = extractvalue { i64, ptr } %t109, 0
  %t112 = add i64 %t108, %t111
  %t113 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t114 = extractvalue { i64, ptr } %t113, 1
  %t115 = extractvalue { i64, ptr } %t113, 0
  %t116 = add i64 %t112, %t115
  %t117 = extractvalue { i64, ptr } { i64 2, ptr @.d75 }, 1
  %t118 = extractvalue { i64, ptr } { i64 2, ptr @.d75 }, 0
  %t119 = add i64 %t116, %t118
  %t120 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t119)
  call void @olang_textcopy(ptr %t120, ptr %t93, i64 %t94)
  %t121 = getelementptr i8, ptr %t120, i64 %t94
  call void @olang_textcopy(ptr %t121, ptr %t95, i64 %t96)
  %t122 = getelementptr i8, ptr %t121, i64 %t96
  call void @olang_textcopy(ptr %t122, ptr %t99, i64 %t100)
  %t123 = getelementptr i8, ptr %t122, i64 %t100
  call void @olang_textcopy(ptr %t123, ptr %t102, i64 %t103)
  %t124 = getelementptr i8, ptr %t123, i64 %t103
  call void @olang_textcopy(ptr %t124, ptr %t106, i64 %t107)
  %t125 = getelementptr i8, ptr %t124, i64 %t107
  call void @olang_textcopy(ptr %t125, ptr %t110, i64 %t111)
  %t126 = getelementptr i8, ptr %t125, i64 %t111
  call void @olang_textcopy(ptr %t126, ptr %t114, i64 %t115)
  %t127 = getelementptr i8, ptr %t126, i64 %t115
  call void @olang_textcopy(ptr %t127, ptr %t117, i64 %t118)
  %t128 = insertvalue { i64, ptr } undef, i64 %t119, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t120, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t129, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"compiler/build:Unit"
  %l10 = alloca %"compiler/build:compiles"
  %lp11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca %"compiler/build:Unit"
  %l18 = alloca { { i64, ptr }, { i64, ptr } }
  %l19 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i32
  %l44 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l60 = alloca i1
  %l64 = alloca i1
  %l68 = alloca %"compiler/build:compiles"
  %l69 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l86 = alloca { i64, ptr }
  %l89 = alloca ptr
  %l90 = alloca { i64, ptr }
  %l91 = alloca ptr
  %l92 = alloca ptr
  %l94 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i32
  %l111 = alloca i1
  %l113 = alloca ptr
  %l114 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l122 = alloca i32
  %l127 = alloca i1
  %l129 = alloca ptr
  %l130 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l138 = alloca i32
  %l142 = alloca { i64, ptr }
  %l144 = alloca i64
  %l146 = alloca { i64, ptr }
  %l147 = alloca { { i64, ptr }, { i64, ptr } }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca ptr
  %l155 = alloca i64
  %l157 = alloca i64
  %l164 = alloca i64
  %l167 = alloca i64
  %l192 = alloca ptr
  %l193 = alloca { i64, [3 x i64] }
  %l196 = alloca { i64, ptr }
  %l197 = alloca %"compiler/msgs:Msg"
  %l200 = alloca { i64, ptr }
  %l201 = alloca i32
  %l207 = alloca i1
  %l213 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l217 = alloca i32
  %l225 = alloca { i64, ptr }
  %l226 = alloca %"compiler/msgs:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
  %t441 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = load i64, ptr %l5, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l34
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l33
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t14, ptr %l30, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l34, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t20 = load i32, ptr %l34, !tbaa !23
  %t21 = lshr i32 %t20, 16
  %t22 = and i32 %t20, 65535
  %t23 = icmp eq i32 %t21, 1
  %t24 = select i1 %t23, i32 0, i32 0
  %t25 = icmp eq i32 %t20, 0
  %t26 = shl i32 %t24, 16
  %t27 = or i32 %t26, %t22
  %t28 = select i1 %t25, i32 0, i32 %t27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t30 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t28, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t30, ptr %rv
  br label %ret
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb7:
  %t31 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t31, ptr %l6, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 0
  store i64 %t34, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t36 = load i64, ptr %l8, !tbaa !24
  %t37 = load i64, ptr %l7, !tbaa !24
  %t40 = icmp slt i64 %t36, %t37
  %t42 = xor i1 %t40, true
  br i1 %t42, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb10:
  br label %bb11
bb11:
  %t44 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t44, ptr %l44, !tbaa !27
  %t45 = load i64, ptr %l8, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/build:Unit", ptr %t48, i64 %t45
  %t50 = load %"compiler/build:Unit", ptr %t49
  store %"compiler/build:Unit" %t50, ptr %l9
  %t52 = load i64, ptr %l3, !tbaa !24
  %t53 = getelementptr %"compiler/build:Unit", ptr %l9, i32 0, i32 2
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t54, 0
  %t59 = add i64 %t52, %t56
  store i64 %t59, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb12
bb12:
  %t61 = load i64, ptr %l8, !tbaa !24
  %t63 = add i64 %t61, 1
  store i64 %t63, ptr %l8, !tbaa !24
  br label %bb8
bb13:
  %t65 = load i64, ptr %l5, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t69 = add i64 %t65, %t66
  store i64 %t69, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb1
bb15:
  %t71 = load ptr, ptr %l0, !tbaa !29
  store ptr %t71, ptr %l56, !tbaa !29
  %t72 = load ptr, ptr %l0, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t72, i32 0, i32 4
  %t75 = load i1, ptr %t74, !tbaa !21
  %t77 = xor i1 %t75, true
  br i1 %t77, label %bb16, label %bb17
bb16:
  %t79 = load ptr, ptr %l0, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t79, i32 0, i32 5
  %t82 = load i1, ptr %t81, !tbaa !21
  %t84 = xor i1 %t82, true
  store i1 %t84, ptr %l60, !tbaa !21
  br label %bb18
bb17:
  store i1 false, ptr %l60, !tbaa !21
  br label %bb18
bb18:
  %t86 = load i1, ptr %l60, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb19:
  %t87 = load i64, ptr %l3, !tbaa !24
  %t88 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t91 = icmp sge i64 %t87, %t88
  store i1 %t91, ptr %l64, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l64, !tbaa !21
  br label %bb21
bb21:
  %t93 = load i1, ptr %l64, !tbaa !21
  %t94 = load ptr, ptr %l56, !tbaa !29
  %t95 = getelementptr %"compiler/build:Config", ptr %t94, i32 0, i32 16
  store i1 %t93, ptr %t95, !tbaa !21
  %t96 = call %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %s0)
  store %"compiler/build:compiles" %t96, ptr %l68
  br label %bb22
bb22:
  %t97 = load %"compiler/build:compiles", ptr %l68
  store %"compiler/build:compiles" %t97, ptr %l10
  %t98 = load ptr, ptr @__olang_prog_scope
  %t99 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t98)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t99, ptr %l69
  br label %bb23
bb23:
  %t100 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 8, i64 8)
  store ptr %t100, ptr %lp11
  %t101 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l69
  %t102 = load ptr, ptr %lp11
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t101, ptr %t102
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/build:Program", ptr %t103, i32 0, i32 0
  store ptr %t105, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load ptr, ptr %l12, !tbaa !29
  %t108 = load i64, ptr %l13, !tbaa !24
  %t111 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t107, i64 %t108)
  %t112 = extractvalue { i32, { i64, ptr } } %t111, 1
  %t113 = extractvalue { i32, { i64, ptr } } %t111, 0
  store i32 %t113, ptr %l76
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb26, label %ok.115
ok.115:
  store { i64, ptr } %t112, ptr %l75
  br label %bb25
bb25:
  %t116 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t116, ptr %l72, !tbaa !27
  br label %bb30
bb26:
  %t117 = load i32, ptr %l76, !tbaa !23
  %t118 = ashr i32 %t117, 16
  %t120 = icmp eq i32 %t118, 1
  br i1 %t120, label %bb27, label %bb28
bb27:
  br label %bb29
bb28:
  %t122 = load i32, ptr %l76, !tbaa !23
  %t123 = lshr i32 %t122, 16
  %t124 = and i32 %t122, 65535
  %t125 = icmp eq i32 %t123, 1
  %t126 = select i1 %t125, i32 0, i32 0
  %t127 = icmp eq i32 %t122, 0
  %t128 = shl i32 %t126, 16
  %t129 = or i32 %t128, %t124
  %t130 = select i1 %t127, i32 0, i32 %t129
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t132 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t130, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t132, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s6)
  br label %bb43
bb30:
  %t133 = load { i64, ptr }, ptr %l72, !tbaa !27
  store { i64, ptr } %t133, ptr %l14, !tbaa !27
  %t134 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t134, 0
  store i64 %t136, ptr %l15, !tbaa !24
  store i64 0, ptr %l16, !tbaa !24
  br label %bb31
bb31:
  store %olang.scope zeroinitializer, ptr %s7
  %t138 = load i64, ptr %l16, !tbaa !24
  %t139 = load i64, ptr %l15, !tbaa !24
  %t142 = icmp slt i64 %t138, %t139
  %t144 = xor i1 %t142, true
  br i1 %t144, label %bb32, label %bb33
bb32:
  call void @__olang_scope_close(ptr %s7)
  br label %bb41
bb33:
  br label %bb34
bb34:
  %t146 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t146, ptr %l86, !tbaa !27
  %t147 = load i64, ptr %l16, !tbaa !24
  %t149 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = getelementptr %"compiler/build:Unit", ptr %t150, i64 %t147
  %t152 = load %"compiler/build:Unit", ptr %t151
  store %"compiler/build:Unit" %t152, ptr %l17
  %t154 = load ptr, ptr %lp11
  store ptr %t154, ptr %l89, !tbaa !29
  %t155 = load ptr, ptr %l0, !tbaa !29
  store ptr %t155, ptr %l91, !tbaa !29
  store ptr %l10, ptr %l92, !tbaa !29
  %t156 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 0
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t159 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %v3, { i64, ptr } %t157)
  store { i64, ptr } %t159, ptr %l94
  br label %bb35
bb35:
  %t160 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t167 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 1
  %t168 = load i32, ptr %t167
  %t169 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 2
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !27
  %t171 = load ptr, ptr %l2, !tbaa !29
  %t172 = getelementptr %"compiler/build:Unit", ptr %l17, i32 0, i32 3
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t174 = load ptr, ptr %l91, !tbaa !29
  %t175 = load ptr, ptr %l92, !tbaa !29
  %t181 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v1, ptr %v3, ptr %t174, ptr %t175, { i64, ptr } %t166, i32 %t168, { i64, ptr } %t170, ptr %t171, { i64, ptr } %t173)
  %t182 = extractvalue { i32, { i64, ptr } } %t181, 1
  %t183 = extractvalue { i32, { i64, ptr } } %t181, 0
  store i32 %t183, ptr %l101
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb37, label %ok.185
ok.185:
  store { i64, ptr } %t182, ptr %l100
  br label %bb36
bb36:
  %t186 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t186, ptr %l90, !tbaa !27
  br label %bb38
bb37:
  %t187 = load i32, ptr %l101, !tbaa !23
  %t188 = lshr i32 %t187, 16
  %t189 = and i32 %t187, 65535
  %t190 = icmp eq i32 %t188, 1
  %t191 = select i1 %t190, i32 1, i32 0
  %t192 = icmp eq i32 %t187, 0
  %t193 = shl i32 %t191, 16
  %t194 = or i32 %t193, %t189
  %t195 = select i1 %t192, i32 0, i32 %t194
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t197 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t195, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t197, ptr %rv
  br label %ret
bb38:
  %t198 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t199 = extractvalue { i64, ptr } %t198, 0
  %t200 = extractvalue { i64, ptr } %t198, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t205 = load ptr, ptr %l89, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t205, { i64, ptr } %t204)
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s7)
  br label %bb40
bb40:
  %t207 = load i64, ptr %l16, !tbaa !24
  %t209 = add i64 %t207, 1
  store i64 %t209, ptr %l16, !tbaa !24
  br label %bb31
bb41:
  %t211 = load i64, ptr %l13, !tbaa !24
  %t212 = load i64, ptr %l15, !tbaa !24
  %t215 = add i64 %t211, %t212
  store i64 %t215, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb42
bb42:
  br label %bb24
bb43:
  %t217 = load ptr, ptr %l1, !tbaa !29
  %t219 = getelementptr %"compiler/build:Program", ptr %t217, i32 0, i32 1
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t222 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t220, { i64, ptr } { i64 0, ptr @.d76 })
  store i1 %t222, ptr %l111
  br label %bb44
bb44:
  %t223 = load i1, ptr %l111, !tbaa !21
  %t224 = xor i1 %t223, true
  br i1 %t224, label %bb45, label %bb46
bb45:
  %t226 = load ptr, ptr %lp11
  store ptr %t226, ptr %l113, !tbaa !29
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t228 = load ptr, ptr %l1, !tbaa !29
  %t230 = getelementptr %"compiler/build:Program", ptr %t228, i32 0, i32 1
  %t231 = load { i64, ptr }, ptr %t230, !tbaa !27
  %t232 = load ptr, ptr %l2, !tbaa !29
  %t238 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t227, ptr %l10, { i64, ptr } { i64 13, ptr @.d77 }, i32 0, { i64, ptr } %t231, ptr %t232, { i64, ptr } { i64 0, ptr @.d78 })
  %t239 = extractvalue { i32, { i64, ptr } } %t238, 1
  %t240 = extractvalue { i32, { i64, ptr } } %t238, 0
  store i32 %t240, ptr %l122
  %t241 = icmp ne i32 %t240, 0
  br i1 %t241, label %bb48, label %ok.242
ok.242:
  store { i64, ptr } %t239, ptr %l121
  br label %bb47
bb46:
  br label %bb51
bb47:
  %t243 = load { i64, ptr }, ptr %l121, !tbaa !27
  store { i64, ptr } %t243, ptr %l114, !tbaa !27
  br label %bb49
bb48:
  %t244 = load i32, ptr %l122, !tbaa !23
  %t245 = lshr i32 %t244, 16
  %t246 = and i32 %t244, 65535
  %t247 = icmp eq i32 %t245, 1
  %t248 = select i1 %t247, i32 1, i32 0
  %t249 = icmp eq i32 %t244, 0
  %t250 = shl i32 %t248, 16
  %t251 = or i32 %t250, %t246
  %t252 = select i1 %t249, i32 0, i32 %t251
  call void @__olang_scope_close(ptr %s0)
  %t254 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t252, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t254, ptr %rv
  br label %ret
bb49:
  %t255 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t255, 0
  %t257 = extractvalue { i64, ptr } %t255, 1
  %t258 = mul i64 %t256, 1
  %t259 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t258)
  call void @llvm.memcpy.p0.p0.i64(ptr %t259, ptr %t257, i64 %t258, i1 false)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t259, 1
  %t262 = load ptr, ptr %l113, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t262, { i64, ptr } %t261)
  br label %bb50
bb50:
  br label %bb51
bb51:
  %t264 = load ptr, ptr %l1, !tbaa !29
  %t266 = getelementptr %"compiler/build:Program", ptr %t264, i32 0, i32 2
  %t267 = load { i64, ptr }, ptr %t266, !tbaa !27
  %t269 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t267, { i64, ptr } { i64 0, ptr @.d79 })
  store i1 %t269, ptr %l127
  br label %bb52
bb52:
  %t270 = load i1, ptr %l127, !tbaa !21
  %t271 = xor i1 %t270, true
  br i1 %t271, label %bb53, label %bb54
bb53:
  %t273 = load ptr, ptr %lp11
  store ptr %t273, ptr %l129, !tbaa !29
  %t274 = load ptr, ptr %l0, !tbaa !29
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t277 = getelementptr %"compiler/build:Program", ptr %t275, i32 0, i32 2
  %t278 = load { i64, ptr }, ptr %t277, !tbaa !27
  %t279 = load ptr, ptr %l2, !tbaa !29
  %t285 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t274, ptr %l10, { i64, ptr } { i64 13, ptr @.d80 }, i32 0, { i64, ptr } %t278, ptr %t279, { i64, ptr } { i64 0, ptr @.d81 })
  %t286 = extractvalue { i32, { i64, ptr } } %t285, 1
  %t287 = extractvalue { i32, { i64, ptr } } %t285, 0
  store i32 %t287, ptr %l138
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb56, label %ok.289
ok.289:
  store { i64, ptr } %t286, ptr %l137
  br label %bb55
bb54:
  br label %bb59
bb55:
  %t290 = load { i64, ptr }, ptr %l137, !tbaa !27
  store { i64, ptr } %t290, ptr %l130, !tbaa !27
  br label %bb57
bb56:
  %t291 = load i32, ptr %l138, !tbaa !23
  %t292 = lshr i32 %t291, 16
  %t293 = and i32 %t291, 65535
  %t294 = icmp eq i32 %t292, 1
  %t295 = select i1 %t294, i32 1, i32 0
  %t296 = icmp eq i32 %t291, 0
  %t297 = shl i32 %t295, 16
  %t298 = or i32 %t297, %t293
  %t299 = select i1 %t296, i32 0, i32 %t298
  call void @__olang_scope_close(ptr %s0)
  %t301 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t299, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t301, ptr %rv
  br label %ret
bb57:
  %t302 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t303 = extractvalue { i64, ptr } %t302, 0
  %t304 = extractvalue { i64, ptr } %t302, 1
  %t305 = mul i64 %t303, 1
  %t306 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t305)
  call void @llvm.memcpy.p0.p0.i64(ptr %t306, ptr %t304, i64 %t305, i1 false)
  %t307 = insertvalue { i64, ptr } undef, i64 %t303, 0
  %t308 = insertvalue { i64, ptr } %t307, ptr %t306, 1
  %t309 = load ptr, ptr %l129, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v3, ptr %v3, ptr %t309, { i64, ptr } %t308)
  br label %bb58
bb58:
  br label %bb59
bb59:
  %t311 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 0
  %t313 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %t311)
  store { i64, ptr } %t313, ptr %l142
  br label %bb60
bb60:
  %t314 = load ptr, ptr %l0, !tbaa !29
  %t316 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t314)
  store i64 %t316, ptr %l144
  br label %bb61
bb61:
  %t317 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 4
  %t319 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %t317)
  store { i64, ptr } %t319, ptr %l146
  br label %bb62
bb62:
  %t320 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t321 = load i64, ptr %l144, !tbaa !24
  %t322 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t323 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t320, i64 %t321, { i64, ptr } %t322)
  store { { i64, ptr }, { i64, ptr } } %t323, ptr %l147
  br label %bb63
bb63:
  %t324 = load { { i64, ptr }, { i64, ptr } }, ptr %l147
  store { { i64, ptr }, { i64, ptr } } %t324, ptr %l18
  %t325 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l18, i32 0, i32 0
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l148, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t327, 0
  store i64 %t328, ptr %l149, !tbaa !24
  %t329 = load i64, ptr %l149, !tbaa !24
  %t330 = mul i64 %t329, 4
  %t331 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t330)
  %t332 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t333 = insertvalue { i64, ptr } %t332, ptr %t331, 1
  store { i64, ptr } %t333, ptr %l150, !tbaa !27
  %t334 = getelementptr { i64, ptr }, ptr %l150, i32 0, i32 1
  %t335 = load ptr, ptr %t334, !tbaa !27
  %t336 = getelementptr { i64, ptr }, ptr %l148, i32 0, i32 1
  %t337 = load ptr, ptr %t336, !tbaa !27
  %t338 = load i64, ptr %l149, !tbaa !24
  %t339 = mul i64 %t338, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t335, ptr %t337, i64 %t339, i1 false)
  %t340 = load { i64, ptr }, ptr %l150, !tbaa !27
  store { i64, ptr } %t340, ptr %l19, !tbaa !27
  %t341 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l18, i32 0, i32 1
  %t342 = load { i64, ptr }, ptr %t341, !tbaa !27
  store { i64, ptr } %t342, ptr %l151, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t344 = extractvalue { i64, ptr } %t343, 0
  store i64 %t344, ptr %l152, !tbaa !24
  %t345 = load i64, ptr %l152, !tbaa !24
  %t346 = mul i64 %t345, 16
  %t347 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t346)
  %t348 = insertvalue { i64, ptr } undef, i64 %t345, 0
  %t349 = insertvalue { i64, ptr } %t348, ptr %t347, 1
  store { i64, ptr } %t349, ptr %l153, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = load i64, ptr %l152, !tbaa !24
  %t355 = mul i64 %t354, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t351, ptr %t353, i64 %t355, i1 false)
  %t356 = load { i64, ptr }, ptr %l153, !tbaa !27
  store { i64, ptr } %t356, ptr %l20, !tbaa !27
  %t357 = load ptr, ptr %l0, !tbaa !29
  store ptr %t357, ptr %l154, !tbaa !29
  %t358 = load ptr, ptr %l154, !tbaa !29
  %t359 = getelementptr %"compiler/build:Config", ptr %t358, i32 0, i32 14
  %t360 = load i64, ptr %t359, !tbaa !24
  store i64 %t360, ptr %l155, !tbaa !24
  %t361 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 0
  %t363 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %s0, ptr %t361)
  store i64 %t363, ptr %l157
  br label %bb64
bb64:
  %t364 = load i64, ptr %l155, !tbaa !24
  %t365 = load i64, ptr %l157, !tbaa !24
  %t366 = add i64 %t364, %t365
  %t368 = load ptr, ptr %l154, !tbaa !29
  %t369 = getelementptr %"compiler/build:Config", ptr %t368, i32 0, i32 14
  store i64 %t366, ptr %t369, !tbaa !24
  store i1 false, ptr %l21, !tbaa !21
  store i64 0, ptr %l22, !tbaa !24
  %t370 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t372 = extractvalue { i64, ptr } %t370, 0
  store i64 %t372, ptr %l23, !tbaa !24
  store i64 1, ptr %l24, !tbaa !24
  %t374 = load i64, ptr %l23, !tbaa !24
  %t375 = load i64, ptr %l22, !tbaa !24
  %t378 = icmp sgt i64 %t374, %t375
  br i1 %t378, label %bb65, label %bb66
bb65:
  %t380 = load i64, ptr %l24, !tbaa !24
  %t382 = icmp sgt i64 %t380, 0
  br i1 %t382, label %bb67, label %bb68
bb66:
  store i64 0, ptr %l164, !tbaa !24
  br label %bb70
bb67:
  %t384 = load i64, ptr %l23, !tbaa !24
  %t385 = load i64, ptr %l22, !tbaa !24
  %t388 = sub i64 %t384, %t385
  %t389 = load i64, ptr %l24, !tbaa !24
  %t392 = add i64 %t388, %t389
  %t394 = sub i64 %t392, 1
  %t395 = load i64, ptr %l24, !tbaa !24
  %t398 = sdiv i64 %t394, %t395
  store i64 %t398, ptr %l167, !tbaa !24
  br label %bb69
bb68:
  store i64 0, ptr %l167, !tbaa !24
  br label %bb69
bb69:
  %t400 = load i64, ptr %l167, !tbaa !24
  store i64 %t400, ptr %l164, !tbaa !24
  br label %bb70
bb70:
  %t401 = load i64, ptr %l164, !tbaa !24
  store i64 %t401, ptr %l25, !tbaa !24
  store i64 0, ptr %l26, !tbaa !24
  br label %bb71
bb71:
  store %olang.scope zeroinitializer, ptr %s12
  %t402 = load i64, ptr %l26, !tbaa !24
  %t403 = load i64, ptr %l25, !tbaa !24
  %t406 = icmp slt i64 %t402, %t403
  %t408 = xor i1 %t406, true
  br i1 %t408, label %bb72, label %bb73
bb72:
  call void @__olang_scope_close(ptr %s12)
  br label %bb112
bb73:
  br label %bb74
bb74:
  %t410 = load i64, ptr %l22, !tbaa !24
  %t411 = load i64, ptr %l26, !tbaa !24
  %t412 = load i64, ptr %l24, !tbaa !24
  %t415 = mul i64 %t411, %t412
  %t418 = add i64 %t410, %t415
  store i64 %t418, ptr %l27, !tbaa !24
  %t420 = load i64, ptr %l27, !tbaa !24
  %t422 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t423 = load ptr, ptr %t422, !tbaa !27
  %t424 = getelementptr i32, ptr %t423, i64 %t420
  %t425 = load i32, ptr %t424, !tbaa !33
  %t427 = icmp ne i32 %t425, 0
  br i1 %t427, label %bb75, label %bb76
bb75:
  %t429 = load i64, ptr %l27, !tbaa !24
  %t431 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t432 = load ptr, ptr %t431, !tbaa !27
  %t433 = getelementptr { i64, ptr }, ptr %t432, i64 %t429
  %t434 = load { i64, ptr }, ptr %t433, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t434)
  br label %bb77
bb76:
  br label %bb91
bb77:
  %t436 = load i1, ptr %l21, !tbaa !21
  %t438 = xor i1 %t436, true
  br i1 %t438, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s14
  %t440 = load ptr, ptr %l2, !tbaa !29
  store ptr %t440, ptr %l192, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t441
  %t442 = getelementptr { i64, [3 x i64] }, ptr %t441, i32 0, i32 0
  store i64 0, ptr %t442
  %t443 = load { i64, [3 x i64] }, ptr %t441
  store { i64, [3 x i64] } %t443, ptr %l193
  %t444 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 3
  %t445 = load i64, ptr %l27, !tbaa !24
  %t448 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t444, i64 %t445)
  store { i64, ptr } %t448, ptr %l196
  br label %bb80
bb79:
  br label %bb83
bb80:
  %t449 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t450 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %s0, ptr %s14, { i64, ptr } %t449)
  store %"compiler/msgs:Msg" %t450, ptr %l197
  br label %bb81
bb81:
  %t451 = load ptr, ptr %l192, !tbaa !29
  %t452 = load { i64, [3 x i64] }, ptr %l193
  %t453 = load %"compiler/msgs:Msg", ptr %l197
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %s14, ptr %t451, { i64, [3 x i64] } %t452, %"compiler/msgs:Msg" %t453)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s14)
  br label %bb83
bb83:
  store i1 true, ptr %l21, !tbaa !21
  %t454 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 1
  %t455 = load i64, ptr %l27, !tbaa !24
  %t458 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t454, i64 %t455)
  store { i64, ptr } %t458, ptr %l200
  br label %bb84
bb84:
  %t459 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t460 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t459)
  store i32 %t460, ptr %l201
  %t461 = icmp ne i32 %t460, 0
  br i1 %t461, label %bb86, label %ok.462
ok.462:
  br label %bb85
bb85:
  br label %bb90
bb86:
  %t463 = load i32, ptr %l201, !tbaa !23
  %t464 = ashr i32 %t463, 16
  %t466 = icmp eq i32 %t464, 1
  br i1 %t466, label %bb87, label %bb88
bb87:
  br label %bb89
bb88:
  %t468 = load i32, ptr %l201, !tbaa !23
  %t469 = lshr i32 %t468, 16
  %t470 = and i32 %t468, 65535
  %t471 = icmp eq i32 %t469, 1
  %t472 = select i1 %t471, i32 0, i32 0
  %t473 = icmp eq i32 %t468, 0
  %t474 = shl i32 %t472, 16
  %t475 = or i32 %t474, %t470
  %t476 = select i1 %t473, i32 0, i32 %t475
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t478 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t476, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t478, ptr %rv
  br label %ret
bb89:
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s12)
  br label %bb111
bb91:
  %t479 = load i64, ptr %l27, !tbaa !24
  %t481 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = getelementptr { i64, ptr }, ptr %t482, i64 %t479
  %t484 = load { i64, ptr }, ptr %t483, !tbaa !37
  %t486 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s12, { i64, ptr } %t484, { i64, ptr } { i64 0, ptr @.d82 })
  store i1 %t486, ptr %l207
  br label %bb92
bb92:
  %t487 = load i1, ptr %l207, !tbaa !21
  %t488 = xor i1 %t487, true
  br i1 %t488, label %bb93, label %bb94
bb93:
  %t490 = load i64, ptr %l27, !tbaa !24
  %t492 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t493 = load ptr, ptr %t492, !tbaa !27
  %t494 = getelementptr { i64, ptr }, ptr %t493, i64 %t490
  %t495 = load { i64, ptr }, ptr %t494, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t495)
  br label %bb95
bb94:
  br label %bb96
bb95:
  br label %bb96
bb96:
  %t497 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 1
  %t498 = load i64, ptr %l27, !tbaa !24
  %t501 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t497, i64 %t498)
  store { i64, ptr } %t501, ptr %l213
  br label %bb97
bb97:
  %t502 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 2
  %t503 = load i64, ptr %l27, !tbaa !24
  %t506 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t502, i64 %t503)
  store { i64, ptr } %t506, ptr %l216
  br label %bb98
bb98:
  %t507 = load { i64, ptr }, ptr %l213, !tbaa !27
  %t508 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t509 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t507, { i64, ptr } %t508)
  store i32 %t509, ptr %l217
  %t510 = icmp ne i32 %t509, 0
  br i1 %t510, label %bb100, label %ok.511
ok.511:
  br label %bb99
bb99:
  br label %bb110
bb100:
  %t512 = load i32, ptr %l217, !tbaa !23
  %t513 = ashr i32 %t512, 16
  %t515 = icmp eq i32 %t513, 1
  br i1 %t515, label %bb101, label %bb102
bb101:
  br label %bb103
bb102:
  %t517 = load i32, ptr %l217, !tbaa !23
  %t518 = lshr i32 %t517, 16
  %t519 = and i32 %t517, 65535
  %t520 = icmp eq i32 %t518, 1
  %t521 = select i1 %t520, i32 0, i32 0
  %t522 = icmp eq i32 %t517, 0
  %t523 = shl i32 %t521, 16
  %t524 = or i32 %t523, %t519
  %t525 = select i1 %t522, i32 0, i32 %t524
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t527 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 %t525, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t527, ptr %rv
  br label %ret
bb103:
  %t528 = load i1, ptr %l21, !tbaa !21
  %t530 = xor i1 %t528, true
  br i1 %t530, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s18
  %t532 = getelementptr %"compiler/build:compiles", ptr %l10, i32 0, i32 2
  %t533 = load i64, ptr %l27, !tbaa !24
  %t536 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t532, i64 %t533)
  store { i64, ptr } %t536, ptr %l225
  br label %bb106
bb105:
  br label %bb109
bb106:
  %t537 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s18)
  store %"compiler/msgs:Msg" %t537, ptr %l226
  br label %bb107
bb107:
  %t538 = load ptr, ptr %l2, !tbaa !29
  %t539 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t540 = load %"compiler/msgs:Msg", ptr %l226
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s18, ptr %v2, { i64, ptr } %t539, %"compiler/msgs:Msg" %t540, ptr %t538)
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s18)
  br label %bb109
bb109:
  store i1 true, ptr %l21, !tbaa !21
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s12)
  br label %bb111
bb111:
  %t542 = load i64, ptr %l26, !tbaa !24
  %t544 = add i64 %t542, 1
  store i64 %t544, ptr %l26, !tbaa !24
  br label %bb71
bb112:
  %t546 = load i1, ptr %l21, !tbaa !21
  br i1 %t546, label %bb113, label %bb114
bb113:
  call void @__olang_scope_close(ptr %s0)
  %t549 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, i32 65536, 0
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t549, ptr %rv
  br label %ret
bb114:
  br label %bb115
bb115:
  %t550 = load ptr, ptr %lp11
  %t551 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %t550
  call void @__olang_scope_close(ptr %s0)
  %t553 = insertvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } zeroinitializer, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t551, 1
  store { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t553, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }, ptr %rv
  ret { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/os:Output"
  %l4 = alloca i1
  %l5 = alloca %"std/os:Output"
  %l13 = alloca %"std/os:Output"
  %l14 = alloca i32
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 17
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr @.d83 })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t26 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t24, 0
  %t27 = insertvalue [2 x { i64, ptr }] %t26, { i64, ptr } { i64 9, ptr @.d84 }, 1
  %t29 = load ptr, ptr @__olang_prog_scope
  %t30 = call ptr @__olang_scope_alloc(ptr %t29, i64 32)
  store [2 x { i64, ptr }] %t27, ptr %t30
  %t31 = insertvalue { i64, ptr } undef, i64 2, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t30, 1
  %t34 = extractvalue { i64, ptr } %t32, 0
  %t35 = extractvalue { i64, ptr } %t32, 1
  %t36 = mul i64 %t34, 16
  %t37 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t36)
  call void @llvm.memcpy.p0.p0.i64(ptr %t37, ptr %t35, i64 %t36, i1 false)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t37, 1
  %t41 = call { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t39, { i64, ptr } { i64 0, ptr @.d85 }, i1 true)
  %t42 = extractvalue { i32, %"std/os:Output" } %t41, 1
  %t43 = extractvalue { i32, %"std/os:Output" } %t41, 0
  store i32 %t43, ptr %l14
  %t44 = icmp ne i32 %t43, 0
  br i1 %t44, label %bb5, label %ok.45
ok.45:
  store %"std/os:Output" %t42, ptr %l13
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t46 = load %"std/os:Output", ptr %l13
  store %"std/os:Output" %t46, ptr %l5
  br label %bb9
bb5:
  %t47 = load i32, ptr %l14, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  br i1 %t50, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @.c86)
  unreachable
bb8:
  store { i64, ptr } { i64 0, ptr @.d87 }, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb9:
  %t53 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t53, ptr %l1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = extractvalue { i64, ptr } %t56, 0
  %t60 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t58, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t72 = getelementptr %"compiler/build:Config", ptr %t54, i32 0, i32 17
  store { i64, ptr } %t69, ptr %t72, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 17
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"compiler/msgs:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t4)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8
ok.8:
  br label %bb1
bb1:
  br label %bb8
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t14 = load i32, ptr %l4, !tbaa !23
  %t15 = lshr i32 %t14, 16
  %t16 = and i32 %t14, 65535
  %t17 = icmp eq i32 %t15, 1
  %t18 = select i1 %t17, i32 0, i32 0
  %t19 = icmp eq i32 %t14, 0
  %t20 = shl i32 %t18, 16
  %t21 = or i32 %t20, %t16
  %t22 = select i1 %t19, i32 0, i32 %t21
  store i32 %t22, ptr %rv
  br label %ret
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/build:Config", ptr %t24, i32 0, i32 0
  %t27 = load { i64, ptr }, ptr %t26, !tbaa !27
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  %t28 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t28, ptr %l10
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t31 = load %"compiler/msgs:Msg", ptr %l10
  call void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %s1, ptr %v1, { i64, ptr } %t30, %"compiler/msgs:Msg" %t31, ptr %a1)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %rv
  br label %ret
bb8:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 5, ptr @.d88 }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr @.d89 }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 6, ptr @.d90 }, ptr %l6, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr @.d91 }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Config", ptr %t11, i32 0, i32 6
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 4, ptr @.d92 }, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr @.d93 }, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t16, 1
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t19 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 1
  %t21 = extractvalue { i64, ptr } %t19, 0
  %t22 = add i64 %t18, %t21
  %t23 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t23, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = add i64 %t22, %t25
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t17, i64 %t18)
  %t28 = getelementptr i8, ptr %t27, i64 %t18
  call void @olang_textcopy(ptr %t28, ptr %t20, i64 %t21)
  %t29 = getelementptr i8, ptr %t28, i64 %t21
  call void @olang_textcopy(ptr %t29, ptr %t24, i64 %t25)
  %t30 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t27, 1
  store { i64, ptr } %t31, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 10
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = extractvalue { i64, ptr } %t8, 0
  %t12 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t10, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t17, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb5
bb5:
  %t20 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr @.d94 }, 0
  %t23 = extractvalue { i64, ptr } %a1, 1
  %t24 = extractvalue { i64, ptr } %a1, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr @.d95 }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr @.d95 }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t40)
  br label %bb6
bb6:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v2, ptr %l3, { i64, ptr } %t43)
  br label %bb7
bb7:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb8
bb8:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 3, ptr @.d96 })
  br label %bb9
bb9:
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t49, ptr %l20
  br label %bb10
bb10:
  %t50 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t50, ptr %l21, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t51, 0
  store i64 %t52, ptr %l22, !tbaa !24
  %t53 = load i64, ptr %l22, !tbaa !24
  %t54 = mul i64 %t53, 1
  %t55 = call ptr @__olang_scope_alloc_zeroed(ptr %v3, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t53, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l23, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l21, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = load i64, ptr %l22, !tbaa !24
  %t63 = mul i64 %t62, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t59, ptr %t61, i64 %t63, i1 false)
  %t64 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t64, ptr %l21, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t65 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t65, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v2, ptr %s0, ptr %a2)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 27, ptr @.d97 }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr @.d97 }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t33 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr @.d98 }, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l10
  br label %bb3
bb3:
  %t34 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t40)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fbuild_2efileError(ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t1, %"compiler/msgs:Msg" %a2, ptr %t3)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t16)
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 27, ptr @.d99 }, 1
  %t24 = extractvalue { i64, ptr } { i64 27, ptr @.d99 }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t39 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr @.d100 }, { i64, ptr } %t36)
  store { i64, ptr } %t39, ptr %l14
  br label %bb4
bb4:
  %t40 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t46)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, { i64, ptr } %a6) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %lp8 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l23 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l24 = alloca ptr
  %l25 = alloca { i64, ptr }
  %l26 = alloca i32
  %l28 = alloca i1
  %l30 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca i1
  %l39 = alloca i1
  %l40 = alloca { i64, ptr }
  %l41 = alloca i64
  %l42 = alloca { i64, ptr }
  %l46 = alloca i1
  %l50 = alloca i64
  %l51 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l66 = alloca i1
  %l68 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l75 = alloca i1
  %l77 = alloca { i64, ptr }
  %l79 = alloca i64
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l86 = alloca i32
  %l90 = alloca { i64, ptr }
  %l91 = alloca %"compiler/msgs:Msg"
  %l96 = alloca i1
  %l97 = alloca ptr
  %l98 = alloca { i64, [3 x i64] }
  %l100 = alloca %"compiler/msgs:Msg"
  %l102 = alloca { i64, ptr }
  %l103 = alloca i32
  %l105 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l113 = alloca { i64, ptr }
  %l116 = alloca { i64, ptr }
  %l117 = alloca i32
  %l127 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t251 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v3, ptr %s0, ptr %t1, { i64, ptr } %t2)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l23
  br label %bb1
bb1:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l23
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l7
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l24, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l25, !tbaa !27
  %t9 = load i32, ptr %l3
  store i32 %t9, ptr %l26
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t12 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 0, ptr @.d101 })
  store i1 %t12, ptr %l28
  br label %bb2
bb2:
  %t13 = load i1, ptr %l28, !tbaa !21
  %t14 = xor i1 %t13, true
  br i1 %t14, label %bb3, label %bb4
bb3:
  %t16 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t16, ptr %l30, !tbaa !27
  br label %bb6
bb4:
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t20 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v5, { i64, ptr } %t18)
  store { i64, ptr } %t20, ptr %l33
  br label %bb5
bb5:
  %t21 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l30, !tbaa !27
  br label %bb6
bb6:
  %t29 = load ptr, ptr %l24, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t31 = load i32, ptr %l26
  %t32 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t34 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v2, ptr %v5, ptr %s0, ptr %v6, ptr %t29, { i64, ptr } %t30, i32 %t31, { i64, ptr } %t32, ptr %l7)
  store { i64, ptr } %t34, ptr %l36
  br label %bb7
bb7:
  %t35 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 16, i64 8)
  store ptr %t35, ptr %lp8
  %t36 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t37 = load ptr, ptr %lp8
  store { i64, ptr } %t36, ptr %t37, !tbaa !27
  %t38 = load ptr, ptr %lp8
  %t39 = load { i64, ptr }, ptr %t38, !tbaa !27
  %t41 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t39)
  store i1 %t41, ptr %l38
  br label %bb8
bb8:
  %t42 = load i1, ptr %l38, !tbaa !21
  br i1 %t42, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l39, !tbaa !21
  br label %bb12
bb10:
  %t43 = load ptr, ptr %lp8
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l40, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l41, !tbaa !24
  %t47 = load i64, ptr %l41, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l42, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l40, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l41, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t61 = getelementptr %"compiler/build:compiles", ptr %t59, i32 0, i32 2
  %t65 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v1, ptr %s0, ptr %t61, { i64, ptr } %t58)
  store i1 %t65, ptr %l46
  br label %bb11
bb11:
  %t66 = load i1, ptr %l46, !tbaa !21
  store i1 %t66, ptr %l39, !tbaa !21
  br label %bb12
bb12:
  %t67 = load i1, ptr %l39, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t68 = load ptr, ptr %lp8
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t71 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t69, 1
  store { i32, { i64, ptr } } %t71, ptr %rv
  br label %ret
bb14:
  br label %bb15
bb15:
  %t72 = load ptr, ptr %lp8
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t73, 0
  %t77 = sub i64 %t75, 2
  store i64 %t77, ptr %l50, !tbaa !24
  %t78 = load ptr, ptr %lp8
  %t79 = load { i64, ptr }, ptr %t78, !tbaa !27
  %t80 = extractvalue { i64, ptr } %t79, 0
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = icmp sge i64 0, 0
  br i1 %t81, label %bb16, label %bb17
bb16:
  %t83 = load i64, ptr %l50, !tbaa !24
  %t84 = icmp sle i64 0, %t83
  br i1 %t84, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @.c102)
  unreachable
bb18:
  %t86 = load i64, ptr %l50, !tbaa !24
  %t87 = load i64, ptr %l51, !tbaa !24
  %t88 = icmp sle i64 %t86, %t87
  br i1 %t88, label %bb20, label %bb21
bb19:
  call void @__olang_check_failed(ptr @.c102)
  unreachable
bb20:
  %t90 = load ptr, ptr %lp8
  %t91 = getelementptr { i64, ptr }, ptr %t90, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = load i64, ptr %l50, !tbaa !24
  %t94 = getelementptr i8, ptr %t92, i64 0
  %t95 = sub i64 %t93, 0
  %t96 = insertvalue { i64, ptr } undef, i64 %t95, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t94, 1
  %t99 = extractvalue { i64, ptr } %t97, 1
  %t100 = extractvalue { i64, ptr } %t97, 0
  %t101 = extractvalue { i64, ptr } { i64 3, ptr @.d103 }, 1
  %t102 = extractvalue { i64, ptr } { i64 3, ptr @.d103 }, 0
  %t103 = add i64 %t100, %t102
  %t104 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t103)
  call void @olang_textcopy(ptr %t104, ptr %t99, i64 %t100)
  %t105 = getelementptr i8, ptr %t104, i64 %t100
  call void @olang_textcopy(ptr %t105, ptr %t101, i64 %t102)
  %t106 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %l10, !tbaa !27
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t111 = getelementptr %"compiler/build:Config", ptr %t109, i32 0, i32 0
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t113, ptr %l59, !tbaa !27
  %t114 = load i32, ptr %l3
  %t116 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %t114)
  store { i64, ptr } %t116, ptr %l61
  br label %bb22
bb21:
  call void @__olang_check_failed(ptr @.c102)
  unreachable
bb22:
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t117)
  store { i64, ptr } %t119, ptr %l63
  br label %bb23
bb23:
  %t120 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr @.d104 }, 0
  %t125 = add i64 %t122, %t124
  %t126 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = add i64 %t125, %t128
  %t130 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t134, 1
  %t136 = extractvalue { i64, ptr } %t134, 0
  %t137 = add i64 %t133, %t136
  %t138 = extractvalue { i64, ptr } { i64 3, ptr @.d105 }, 1
  %t139 = extractvalue { i64, ptr } { i64 3, ptr @.d105 }, 0
  %t140 = add i64 %t137, %t139
  %t141 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t121, i64 %t122)
  %t142 = getelementptr i8, ptr %t141, i64 %t122
  call void @olang_textcopy(ptr %t142, ptr %t123, i64 %t124)
  %t143 = getelementptr i8, ptr %t142, i64 %t124
  call void @olang_textcopy(ptr %t143, ptr %t127, i64 %t128)
  %t144 = getelementptr i8, ptr %t143, i64 %t128
  call void @olang_textcopy(ptr %t144, ptr %t131, i64 %t132)
  %t145 = getelementptr i8, ptr %t144, i64 %t132
  call void @olang_textcopy(ptr %t145, ptr %t135, i64 %t136)
  %t146 = getelementptr i8, ptr %t145, i64 %t136
  call void @olang_textcopy(ptr %t146, ptr %t138, i64 %t139)
  %t147 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t141, 1
  store { i64, ptr } %t148, ptr %l11, !tbaa !27
  %t150 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t150, { i64, ptr } { i64 6, ptr @.d106 })
  store i1 %t152, ptr %l66
  br label %bb24
bb24:
  %t153 = load i1, ptr %l66, !tbaa !21
  %t154 = xor i1 %t153, true
  br i1 %t154, label %bb25, label %bb26
bb25:
  %t156 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t156, ptr %l69, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 0
  store i64 %t158, ptr %l70, !tbaa !24
  %t159 = load i64, ptr %l70, !tbaa !24
  %t160 = mul i64 %t159, 1
  %t161 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t160)
  %t162 = insertvalue { i64, ptr } undef, i64 %t159, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l71, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t167 = load ptr, ptr %t166, !tbaa !27
  %t168 = load i64, ptr %l70, !tbaa !24
  %t169 = mul i64 %t168, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t165, ptr %t167, i64 %t169, i1 false)
  %t170 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t171 = load ptr, ptr %l1, !tbaa !29
  %t173 = getelementptr %"compiler/build:compiles", ptr %t171, i32 0, i32 3
  %t177 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v1, ptr %s0, ptr %t173, { i64, ptr } %t170)
  store i1 %t177, ptr %l75
  br label %bb27
bb26:
  store i1 false, ptr %l68, !tbaa !21
  br label %bb28
bb27:
  %t178 = load i1, ptr %l75, !tbaa !21
  %t179 = xor i1 %t178, true
  store i1 %t179, ptr %l68, !tbaa !21
  br label %bb28
bb28:
  %t181 = load i1, ptr %l68, !tbaa !21
  br i1 %t181, label %bb29, label %bb30
bb29:
  %t182 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t182, ptr %l77, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  %t185 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  store i64 %t186, ptr %l79, !tbaa !24
  %t188 = load i64, ptr %l79, !tbaa !24
  %t189 = icmp eq i64 %t184, %t188
  br i1 %t189, label %bb31, label %bb32
bb30:
  br label %bb34
bb31:
  %t191 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t194 = load ptr, ptr %t193, !tbaa !27
  %t195 = load i64, ptr %l79, !tbaa !24
  %t196 = mul i64 %t195, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t192, ptr %t194, i64 %t196, i1 false)
  br label %bb33
bb32:
  %t197 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  store i64 %t198, ptr %l81, !tbaa !24
  %t199 = load i64, ptr %l81, !tbaa !24
  %t200 = mul i64 %t199, 1
  %t201 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t200)
  %t202 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  store { i64, ptr } %t203, ptr %l82, !tbaa !27
  %t204 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t205 = load ptr, ptr %t204, !tbaa !27
  %t206 = getelementptr { i64, ptr }, ptr %l77, i32 0, i32 1
  %t207 = load ptr, ptr %t206, !tbaa !27
  %t208 = load i64, ptr %l81, !tbaa !24
  %t209 = mul i64 %t208, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t205, ptr %t207, i64 %t209, i1 false)
  %t210 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t210, ptr %l10, !tbaa !27
  br label %bb33
bb33:
  br label %bb34
bb34:
  %t211 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t216 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v3, { i64, ptr } %t211, { i64, ptr } %t212)
  store i32 %t216, ptr %l86
  %t217 = icmp ne i32 %t216, 0
  br i1 %t217, label %bb36, label %ok.218
ok.218:
  br label %bb35
bb35:
  br label %bb42
bb36:
  %t219 = load i32, ptr %l86, !tbaa !23
  %t220 = ashr i32 %t219, 16
  %t222 = icmp eq i32 %t220, 1
  br i1 %t222, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  %t224 = load i32, ptr %l86, !tbaa !23
  %t225 = lshr i32 %t224, 16
  %t226 = and i32 %t224, 65535
  %t227 = icmp eq i32 %t225, 1
  %t228 = select i1 %t227, i32 0, i32 0
  %t229 = icmp eq i32 %t224, 0
  %t230 = shl i32 %t228, 16
  %t231 = or i32 %t230, %t226
  %t232 = select i1 %t229, i32 0, i32 %t231
  call void @__olang_scope_close(ptr %s0)
  %t234 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t232, 0
  store { i32, { i64, ptr } } %t234, ptr %rv
  br label %ret
bb39:
  store %olang.scope zeroinitializer, ptr %s5
  %t235 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t235, ptr %l90, !tbaa !27
  %t236 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s5)
  store %"compiler/msgs:Msg" %t236, ptr %l91
  br label %bb40
bb40:
  %t237 = load ptr, ptr %l5, !tbaa !29
  %t238 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t239 = load %"compiler/msgs:Msg", ptr %l91
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s5, ptr %v4, { i64, ptr } %t238, %"compiler/msgs:Msg" %t239, ptr %t237)
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t242 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t242, ptr %rv
  br label %ret
bb42:
  %t243 = load ptr, ptr %l0, !tbaa !29
  %t245 = getelementptr %"compiler/build:Config", ptr %t243, i32 0, i32 1
  %t246 = load { i64, ptr }, ptr %t245, !tbaa !27
  %t248 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t246, { i64, ptr } { i64 0, ptr @.d107 })
  store i1 %t248, ptr %l96
  br label %bb43
bb43:
  %t249 = load i1, ptr %l96, !tbaa !21
  br i1 %t249, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t250 = load ptr, ptr %l5, !tbaa !29
  store ptr %t250, ptr %l97, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t251
  %t252 = getelementptr { i64, [3 x i64] }, ptr %t251, i32 0, i32 0
  store i64 0, ptr %t252
  %t253 = load { i64, [3 x i64] }, ptr %t251
  store { i64, [3 x i64] } %t253, ptr %l98
  %t254 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t256 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %s0, ptr %s6, { i64, ptr } %t254)
  store %"compiler/msgs:Msg" %t256, ptr %l100
  br label %bb46
bb45:
  br label %bb48
bb46:
  %t257 = load ptr, ptr %l97, !tbaa !29
  %t258 = load { i64, [3 x i64] }, ptr %l98
  %t259 = load %"compiler/msgs:Msg", ptr %l100
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s6, ptr %t257, { i64, [3 x i64] } %t258, %"compiler/msgs:Msg" %t259)
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t261 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t261, ptr %rv
  br label %ret
bb48:
  %t262 = load ptr, ptr %lp8
  %t263 = load { i64, ptr }, ptr %t262, !tbaa !27
  store { i64, ptr } %t263, ptr %l102, !tbaa !27
  %t264 = call i32 @getpid()
  store i32 %t264, ptr %l103
  br label %bb49
bb49:
  %t265 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 1
  %t269 = extractvalue { i64, ptr } { i64 1, ptr @.d108 }, 0
  %t270 = add i64 %t267, %t269
  %t271 = load i32, ptr %l103, !tbaa !23
  %t272 = sext i32 %t271 to i64
  %t273 = call i64 @__olang_fmt_i64(ptr null, i64 %t272)
  %t274 = add i64 %t270, %t273
  %t275 = extractvalue { i64, ptr } { i64 4, ptr @.d109 }, 1
  %t276 = extractvalue { i64, ptr } { i64 4, ptr @.d109 }, 0
  %t277 = add i64 %t274, %t276
  %t278 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t277)
  call void @olang_textcopy(ptr %t278, ptr %t266, i64 %t267)
  %t279 = getelementptr i8, ptr %t278, i64 %t267
  call void @olang_textcopy(ptr %t279, ptr %t268, i64 %t269)
  %t280 = getelementptr i8, ptr %t279, i64 %t269
  %t281 = call i64 @__olang_fmt_i64(ptr %t280, i64 %t272)
  %t282 = getelementptr i8, ptr %t280, i64 %t273
  call void @olang_textcopy(ptr %t282, ptr %t275, i64 %t276)
  %t283 = insertvalue { i64, ptr } undef, i64 %t277, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t278, 1
  store { i64, ptr } %t284, ptr %l13, !tbaa !27
  %t286 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t286, ptr %l105
  br label %bb50
bb50:
  %t287 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l105
  %t288 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t287, ptr %t288
  store ptr %t288, ptr %l14, !tbaa !29
  %t290 = load ptr, ptr %l14, !tbaa !29
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/build:Config", ptr %t291, i32 0, i32 1
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t294, 1
  %t297 = extractvalue { i64, ptr } %t294, 0
  %t298 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t297)
  call void @olang_textcopy(ptr %t298, ptr %t296, i64 %t297)
  %t299 = insertvalue { i64, ptr } undef, i64 %t297, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t302 = extractvalue { i64, ptr } %t300, 0
  %t303 = extractvalue { i64, ptr } %t300, 1
  %t304 = mul i64 %t302, 1
  %t305 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t304)
  call void @llvm.memcpy.p0.p0.i64(ptr %t305, ptr %t303, i64 %t304, i1 false)
  %t306 = insertvalue { i64, ptr } undef, i64 %t302, 0
  %t307 = insertvalue { i64, ptr } %t306, ptr %t305, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t290, { i64, ptr } %t307)
  br label %bb51
bb51:
  store ptr %l7, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb52
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  %t311 = load ptr, ptr %l15, !tbaa !29
  %t312 = load i64, ptr %l16, !tbaa !24
  %t315 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t311, i64 %t312)
  %t316 = extractvalue { i32, { i64, ptr } } %t315, 1
  %t317 = extractvalue { i32, { i64, ptr } } %t315, 0
  store i32 %t317, ptr %l117
  %t318 = icmp ne i32 %t317, 0
  br i1 %t318, label %bb54, label %ok.319
ok.319:
  store { i64, ptr } %t316, ptr %l116
  br label %bb53
bb53:
  %t320 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t320, ptr %l113, !tbaa !27
  br label %bb58
bb54:
  %t321 = load i32, ptr %l117, !tbaa !23
  %t322 = ashr i32 %t321, 16
  %t324 = icmp eq i32 %t322, 1
  br i1 %t324, label %bb55, label %bb56
bb55:
  br label %bb57
bb56:
  %t326 = load i32, ptr %l117, !tbaa !23
  %t327 = lshr i32 %t326, 16
  %t328 = and i32 %t326, 65535
  %t329 = icmp eq i32 %t327, 1
  %t330 = select i1 %t329, i32 0, i32 0
  %t331 = icmp eq i32 %t326, 0
  %t332 = shl i32 %t330, 16
  %t333 = or i32 %t332, %t328
  %t334 = select i1 %t331, i32 0, i32 %t333
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t336 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t334, 0
  store { i32, { i64, ptr } } %t336, ptr %rv
  br label %ret
bb57:
  call void @__olang_scope_close(ptr %s10)
  br label %bb67
bb58:
  %t337 = load { i64, ptr }, ptr %l113, !tbaa !27
  store { i64, ptr } %t337, ptr %l17, !tbaa !27
  %t338 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t338, 0
  store i64 %t340, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb59
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t342 = load i64, ptr %l19, !tbaa !24
  %t343 = load i64, ptr %l18, !tbaa !24
  %t346 = icmp slt i64 %t342, %t343
  %t348 = xor i1 %t346, true
  br i1 %t348, label %bb60, label %bb61
bb60:
  call void @__olang_scope_close(ptr %s11)
  br label %bb65
bb61:
  br label %bb62
bb62:
  %t350 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t350, ptr %l127, !tbaa !27
  %t351 = load i64, ptr %l19, !tbaa !24
  %t353 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t354 = load ptr, ptr %t353, !tbaa !27
  %t355 = getelementptr { i64, ptr }, ptr %t354, i64 %t351
  %t356 = load { i64, ptr }, ptr %t355, !tbaa !37
  %t358 = load ptr, ptr %l14, !tbaa !29
  %t361 = extractvalue { i64, ptr } %t356, 1
  %t362 = extractvalue { i64, ptr } %t356, 0
  %t363 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t362)
  call void @olang_textcopy(ptr %t363, ptr %t361, i64 %t362)
  %t364 = insertvalue { i64, ptr } undef, i64 %t362, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  %t367 = extractvalue { i64, ptr } %t365, 0
  %t368 = extractvalue { i64, ptr } %t365, 1
  %t369 = mul i64 %t367, 1
  %t370 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t369)
  call void @llvm.memcpy.p0.p0.i64(ptr %t370, ptr %t368, i64 %t369, i1 false)
  %t371 = insertvalue { i64, ptr } undef, i64 %t367, 0
  %t372 = insertvalue { i64, ptr } %t371, ptr %t370, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t358, { i64, ptr } %t372)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s11)
  br label %bb64
bb64:
  %t375 = load i64, ptr %l19, !tbaa !24
  %t377 = add i64 %t375, 1
  store i64 %t377, ptr %l19, !tbaa !24
  br label %bb59
bb65:
  %t379 = load i64, ptr %l16, !tbaa !24
  %t380 = load i64, ptr %l18, !tbaa !24
  %t383 = add i64 %t379, %t380
  store i64 %t383, ptr %l16, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb66
bb66:
  br label %bb52
bb67:
  %t385 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t385, { i64, ptr } { i64 2, ptr @.d110 })
  br label %bb68
bb68:
  %t387 = load ptr, ptr %l14, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t387, { i64, ptr } { i64 2, ptr @.d111 })
  br label %bb69
bb69:
  %t389 = load ptr, ptr %l14, !tbaa !29
  %t390 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t390, 1
  %t393 = extractvalue { i64, ptr } %t390, 0
  %t394 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t393)
  call void @olang_textcopy(ptr %t394, ptr %t392, i64 %t393)
  %t395 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = extractvalue { i64, ptr } %t396, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t389, { i64, ptr } %t403)
  br label %bb70
bb70:
  %t406 = load ptr, ptr %l14, !tbaa !29
  %t407 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t409 = extractvalue { i64, ptr } %t407, 1
  %t410 = extractvalue { i64, ptr } %t407, 0
  %t411 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t410)
  call void @olang_textcopy(ptr %t411, ptr %t409, i64 %t410)
  %t412 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t411, 1
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = extractvalue { i64, ptr } %t413, 1
  %t417 = mul i64 %t415, 1
  %t418 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t417)
  call void @llvm.memcpy.p0.p0.i64(ptr %t418, ptr %t416, i64 %t417, i1 false)
  %t419 = insertvalue { i64, ptr } undef, i64 %t415, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t418, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t406, { i64, ptr } %t420)
  br label %bb71
bb71:
  %t423 = load ptr, ptr %l1, !tbaa !29
  %t425 = getelementptr %"compiler/build:compiles", ptr %t423, i32 0, i32 0
  store ptr %t425, ptr %l150, !tbaa !29
  %t426 = load ptr, ptr %l14, !tbaa !29
  %t428 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v1, ptr %v1, ptr %t426)
  store { i64, ptr } %t428, ptr %l152
  br label %bb72
bb72:
  %t429 = load ptr, ptr %l150, !tbaa !29
  %t430 = load { i64, ptr }, ptr %l152, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v1, ptr %v1, ptr %t429, { i64, ptr } %t430)
  br label %bb73
bb73:
  %t431 = load ptr, ptr %l1, !tbaa !29
  %t433 = getelementptr %"compiler/build:compiles", ptr %t431, i32 0, i32 1
  %t434 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t434, 1
  %t437 = extractvalue { i64, ptr } %t434, 0
  %t438 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t437)
  call void @olang_textcopy(ptr %t438, ptr %t436, i64 %t437)
  %t439 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t440 = insertvalue { i64, ptr } %t439, ptr %t438, 1
  %t442 = extractvalue { i64, ptr } %t440, 0
  %t443 = extractvalue { i64, ptr } %t440, 1
  %t444 = mul i64 %t442, 1
  %t445 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t444)
  call void @llvm.memcpy.p0.p0.i64(ptr %t445, ptr %t443, i64 %t444, i1 false)
  %t446 = insertvalue { i64, ptr } undef, i64 %t442, 0
  %t447 = insertvalue { i64, ptr } %t446, ptr %t445, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t433, { i64, ptr } %t447)
  br label %bb74
bb74:
  %t450 = load ptr, ptr %l1, !tbaa !29
  %t452 = getelementptr %"compiler/build:compiles", ptr %t450, i32 0, i32 2
  %t453 = load ptr, ptr %lp8
  %t454 = load { i64, ptr }, ptr %t453, !tbaa !27
  %t456 = extractvalue { i64, ptr } %t454, 1
  %t457 = extractvalue { i64, ptr } %t454, 0
  %t458 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t457)
  call void @olang_textcopy(ptr %t458, ptr %t456, i64 %t457)
  %t459 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t458, 1
  %t462 = extractvalue { i64, ptr } %t460, 0
  %t463 = extractvalue { i64, ptr } %t460, 1
  %t464 = mul i64 %t462, 1
  %t465 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t464)
  call void @llvm.memcpy.p0.p0.i64(ptr %t465, ptr %t463, i64 %t464, i1 false)
  %t466 = insertvalue { i64, ptr } undef, i64 %t462, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t452, { i64, ptr } %t467)
  br label %bb75
bb75:
  %t470 = load ptr, ptr %l1, !tbaa !29
  %t472 = getelementptr %"compiler/build:compiles", ptr %t470, i32 0, i32 3
  %t473 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t475 = extractvalue { i64, ptr } %t473, 1
  %t476 = extractvalue { i64, ptr } %t473, 0
  %t477 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t476)
  call void @olang_textcopy(ptr %t477, ptr %t475, i64 %t476)
  %t478 = insertvalue { i64, ptr } undef, i64 %t476, 0
  %t479 = insertvalue { i64, ptr } %t478, ptr %t477, 1
  %t481 = extractvalue { i64, ptr } %t479, 0
  %t482 = extractvalue { i64, ptr } %t479, 1
  %t483 = mul i64 %t481, 1
  %t484 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t483)
  call void @llvm.memcpy.p0.p0.i64(ptr %t484, ptr %t482, i64 %t483, i1 false)
  %t485 = insertvalue { i64, ptr } undef, i64 %t481, 0
  %t486 = insertvalue { i64, ptr } %t485, ptr %t484, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v1, ptr %v1, ptr %t472, { i64, ptr } %t486)
  br label %bb76
bb76:
  %t489 = load ptr, ptr %l1, !tbaa !29
  %t491 = getelementptr %"compiler/build:compiles", ptr %t489, i32 0, i32 4
  %t492 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t494 = extractvalue { i64, ptr } %t492, 0
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t491, i64 %t494)
  br label %bb77
bb77:
  %t497 = load ptr, ptr %lp8
  %t498 = load { i64, ptr }, ptr %t497, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t500 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t498, 1
  store { i32, { i64, ptr } } %t500, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 9
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 9
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call i64 @sysconf(i32 84)
  store i64 %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  store i64 1, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l10, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/build:Unit"
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l22 = alloca { i64, ptr }
  %l25 = alloca i32
  %l27 = alloca i32
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i1
  %l45 = alloca i64
  %l47 = alloca { i64, ptr }
  %l50 = alloca %"compiler/build:Unit"
  %l53 = alloca { i64, ptr }
  %l55 = alloca i64
  %l56 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load i64, ptr %l2, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t5, i64 %t6)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l13
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l12
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t14, ptr %l9, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l13, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c112)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb23
bb7:
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t20, ptr %l3, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t21, 0
  store i64 %t23, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l5, !tbaa !24
  %t26 = load i64, ptr %l4, !tbaa !24
  %t29 = icmp slt i64 %t25, %t26
  %t31 = xor i1 %t29, true
  br i1 %t31, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb21
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l22, !tbaa !27
  %t34 = load i64, ptr %l5, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/build:Unit", ptr %t37, i64 %t34
  %t39 = load %"compiler/build:Unit", ptr %t38
  store %"compiler/build:Unit" %t39, ptr %l6
  %t41 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t42 = load i32, ptr %t41
  store i32 %t42, ptr %l25
  store i32 1, ptr %l27
  %t45 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %l25, ptr %l27)
  store i1 %t45, ptr %l29
  br label %bb12
bb12:
  %t46 = load i1, ptr %l29, !tbaa !21
  br i1 %t46, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l30, !tbaa !21
  br label %bb16
bb14:
  %t47 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 1
  %t48 = load i32, ptr %t47
  store i32 %t48, ptr %l31
  store i32 2, ptr %l33
  %t51 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %l31, ptr %l33)
  store i1 %t51, ptr %l35
  br label %bb15
bb15:
  %t52 = load i1, ptr %l35, !tbaa !21
  store i1 %t52, ptr %l30, !tbaa !21
  br label %bb16
bb16:
  %t53 = load i1, ptr %l30, !tbaa !21
  br i1 %t53, label %bb17, label %bb18
bb17:
  %t54 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t55, 1
  %t58 = extractvalue { i64, ptr } %t55, 0
  %t59 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t58)
  call void @olang_textcopy(ptr %t59, ptr %t57, i64 %t58)
  %t60 = insertvalue { i64, ptr } undef, i64 %t58, 0
  %t61 = insertvalue { i64, ptr } %t60, ptr %t59, 1
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  store { i64, ptr } %t61, ptr %rv
  br label %ret
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb20:
  %t63 = load i64, ptr %l5, !tbaa !24
  %t65 = add i64 %t63, 1
  store i64 %t65, ptr %l5, !tbaa !24
  br label %bb8
bb21:
  %t67 = load i64, ptr %l2, !tbaa !24
  %t68 = load i64, ptr %l4, !tbaa !24
  %t71 = add i64 %t67, %t68
  store i64 %t71, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb22
bb22:
  br label %bb1
bb23:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Program", ptr %t73, i32 0, i32 0
  %t77 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t75)
  store i64 %t77, ptr %l45
  br label %bb24
bb24:
  %t78 = load i64, ptr %l45, !tbaa !24
  %t79 = icmp sgt i64 %t78, 0
  br i1 %t79, label %bb25, label %bb26
bb25:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/build:Program", ptr %t81, i32 0, i32 0
  %t85 = call %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t83, i64 0)
  store %"compiler/build:Unit" %t85, ptr %l50
  br label %bb27
bb26:
  store { i64, ptr } { i64 1, ptr @.d113 }, ptr %l53, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t86, ptr %l47, !tbaa !27
  br label %bb28
bb27:
  %t88 = getelementptr %"compiler/build:Unit", ptr %l50, i32 0, i32 0
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l47, !tbaa !27
  br label %bb28
bb28:
  %t97 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t98 = extractvalue { i64, ptr } %t97, 0
  store i64 %t98, ptr %l55, !tbaa !24
  %t99 = load i64, ptr %l55, !tbaa !24
  %t100 = mul i64 %t99, 1
  %t101 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t100)
  %t102 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t103 = insertvalue { i64, ptr } %t102, ptr %t101, 1
  store { i64, ptr } %t103, ptr %l56, !tbaa !27
  %t104 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t107 = load ptr, ptr %t106, !tbaa !27
  %t108 = load i64, ptr %l55, !tbaa !24
  %t109 = mul i64 %t108, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t105, ptr %t107, i64 %t109, i1 false)
  %t110 = load { i64, ptr }, ptr %l56, !tbaa !27
  store { i64, ptr } %t110, ptr %l47, !tbaa !27
  %t111 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t111, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [8 x i8]
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l53 = alloca i64
  %l61 = alloca %"std/prelude/text:StringBuilder"
  %l73 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Sha256", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = mul i64 %t4, 8
  store i64 %t7, ptr %l1, !tbaa !65
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr @.d114 })
  br label %bb1
bb1:
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Sha256", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = icmp ne i64 %t14, 56
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s1, ptr %t20, { i64, ptr } { i64 1, ptr @.d115 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb2
bb8:
  store [8 x i8] zeroinitializer, ptr %l2
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l30, !tbaa !24
  store i64 %t48, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t49 = load i64, ptr %l27, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  store %olang.scope zeroinitializer, ptr %s3
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s3)
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l1, !tbaa !65
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = mul i64 8, %t70
  %t74 = sub i64 56, %t72
  store i64 %t74, ptr %l53, !tbaa !65
  %t77 = load i64, ptr %l53, !tbaa !65
  %t78 = load i64, ptr %l53, !tbaa !65
  %t79 = lshr i64 %t69, %t78
  %t81 = trunc i64 %t79 to i8
  %t84 = getelementptr [8 x i8], ptr %l2, i64 0, i64 %t68
  store i8 %t81, ptr %t84, !tbaa !32
  call void @__olang_scope_close(ptr %s3)
  br label %bb19
bb19:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb15
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = insertvalue { i64, ptr } undef, i64 8, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %l2, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t89, { i64, ptr } %t92)
  br label %bb21
bb21:
  %t95 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t95, ptr %l61
  br label %bb22
bb22:
  %t96 = load %"std/prelude/text:StringBuilder", ptr %l61
  store %"std/prelude/text:StringBuilder" %t96, ptr %l9
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/build:Sha256", ptr %t97, i32 0, i32 0
  store ptr %t99, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t101 = load ptr, ptr %l10
  store i64 8, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l12, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t112 = load ptr, ptr %l10
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = getelementptr [8 x i32], ptr %t112, i64 0, i64 %t113
  %t117 = load i32, ptr %t116, !tbaa !84
  store ptr %l9, ptr %l73, !tbaa !29
  store i32 %t117, ptr %l74, !tbaa !64
  %t120 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 16)
  %t121 = extractvalue { i32, i64 } %t120, 1
  %t122 = extractvalue { i32, i64 } %t120, 0
  store i32 %t122, ptr %l76
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb28, label %ok.124
ok.124:
  store i64 %t121, ptr %l75
  br label %bb27
bb27:
  %t125 = load i32, ptr %l74, !tbaa !64
  %t126 = load i64, ptr %l75, !tbaa !24
  %t127 = call { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %s6, i32 %t125, i64 %t126)
  store { i64, ptr } %t127, ptr %l77
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @.c116)
  unreachable
bb29:
  %t128 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t134, i64 8, i8 48)
  store { i64, ptr } %t136, ptr %l79
  br label %bb30
bb30:
  %t137 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t144, { i64, ptr } %t143)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb23
bb33:
  %t151 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l9)
  store { i64, ptr } %t151, ptr %l84
  br label %bb34
bb34:
  %t152 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t152, ptr %l85, !tbaa !27
  %t153 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t154 = extractvalue { i64, ptr } %t153, 0
  store i64 %t154, ptr %l86, !tbaa !24
  %t155 = load i64, ptr %l86, !tbaa !24
  %t156 = mul i64 %t155, 1
  %t157 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t156)
  %t158 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l87, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t161 = load ptr, ptr %t160, !tbaa !27
  %t162 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t163 = load ptr, ptr %t162, !tbaa !27
  %t164 = load i64, ptr %l86, !tbaa !24
  %t165 = mul i64 %t164, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t161, ptr %t163, i64 %t165, i1 false)
  %t166 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t166, ptr %l85, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t167 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t167, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca ptr
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = getelementptr %"compiler/build:Sha256", ptr %t6, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = add i64 %t8, %t9
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = getelementptr %"compiler/build:Sha256", ptr %t14, i32 0, i32 3
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Sha256", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb16
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/build:Sha256", ptr %t23, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp slt i64 %t26, 64
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l16, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/build:Sha256", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t53 = getelementptr %"compiler/build:Sha256", ptr %t39, i32 0, i32 1
  %t55 = getelementptr [64 x i8], ptr %t53, i64 0, i64 %t43
  store i8 %t50, ptr %t55, !tbaa !32
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l27, !tbaa !29
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = getelementptr %"compiler/build:Sha256", ptr %t57, i32 0, i32 2
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = add i64 %t59, 1
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t64 = getelementptr %"compiler/build:Sha256", ptr %t63, i32 0, i32 2
  store i64 %t61, ptr %t64, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Sha256", ptr %t69, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp slt i64 %t72, 64
  br i1 %t74, label %bb12, label %bb13
bb12:
  br label %ret
bb13:
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Sha256", ptr %t77, i32 0, i32 1
  %t81 = insertvalue { i64, ptr } undef, i64 64, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v0, ptr %t76, { i64, ptr } %t82, i64 0)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Sha256", ptr %t85, i32 0, i32 2
  store i64 0, ptr %t87, !tbaa !24
  br label %bb16
bb16:
  br label %bb17
bb17:
  store %olang.scope zeroinitializer, ptr %s4
  %t88 = load i64, ptr %l2, !tbaa !24
  %t90 = add i64 %t88, 64
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sle i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  call void @__olang_scope_close(ptr %s4)
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %t98, { i64, ptr } %t99, i64 %t100)
  br label %bb21
bb21:
  %t104 = load i64, ptr %l2, !tbaa !24
  %t106 = add i64 %t104, 64
  store i64 %t106, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  br label %bb17
bb23:
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s5
  %t108 = load i64, ptr %l2, !tbaa !24
  %t109 = load i64, ptr %l3, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/build:Sha256", ptr %t117, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t121, ptr %l57, !tbaa !27
  %t122 = load i64, ptr %l2, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t122
  %t127 = load i8, ptr %t126, !tbaa !32
  %t130 = getelementptr %"compiler/build:Sha256", ptr %t116, i32 0, i32 1
  %t132 = getelementptr [64 x i8], ptr %t130, i64 0, i64 %t120
  store i8 %t127, ptr %t132, !tbaa !32
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l60, !tbaa !29
  %t134 = load ptr, ptr %l60, !tbaa !29
  %t135 = getelementptr %"compiler/build:Sha256", ptr %t134, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t138 = add i64 %t136, 1
  %t140 = load ptr, ptr %l60, !tbaa !29
  %t141 = getelementptr %"compiler/build:Sha256", ptr %t140, i32 0, i32 2
  store i64 %t138, ptr %t141, !tbaa !24
  %t142 = load i64, ptr %l2, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb28:
  br label %bb24
bb29:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i32
  %l41 = alloca i64
  %l44 = alloca i64
  %l67 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l97 = alloca i64
  %l100 = alloca i64
  %l121 = alloca i32
  %l125 = alloca i32
  %l135 = alloca i32
  %l139 = alloca i32
  %l179 = alloca i64
  %l182 = alloca i64
  %l201 = alloca i32
  %l203 = alloca i32
  %l204 = alloca i32
  %l206 = alloca i32
  %l228 = alloca i32
  %l230 = alloca i32
  %l231 = alloca i32
  %l233 = alloca i32
  %l262 = alloca ptr
  %l266 = alloca ptr
  %l270 = alloca ptr
  %l274 = alloca ptr
  %l278 = alloca ptr
  %l282 = alloca ptr
  %l286 = alloca ptr
  %l290 = alloca ptr
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s8 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  call void @llvm.memset.p0.i64(ptr %l3, i8 0, i64 256, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t1 = load i64, ptr %l5, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp sgt i64 %t1, %t2
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t7 = load i64, ptr %l6, !tbaa !24
  %t9 = icmp sgt i64 %t7, 0
  br i1 %t9, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l41, !tbaa !24
  br label %bb6
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l4, !tbaa !24
  %t15 = sub i64 %t11, %t12
  %t16 = load i64, ptr %l6, !tbaa !24
  %t19 = add i64 %t15, %t16
  %t21 = sub i64 %t19, 1
  %t22 = load i64, ptr %l6, !tbaa !24
  %t25 = sdiv i64 %t21, %t22
  store i64 %t25, ptr %l44, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l44, !tbaa !24
  br label %bb5
bb5:
  %t27 = load i64, ptr %l44, !tbaa !24
  store i64 %t27, ptr %l41, !tbaa !24
  br label %bb6
bb6:
  %t28 = load i64, ptr %l41, !tbaa !24
  store i64 %t28, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load i64, ptr %l8, !tbaa !24
  %t30 = load i64, ptr %l7, !tbaa !24
  %t33 = icmp slt i64 %t29, %t30
  %t35 = xor i1 %t33, true
  br i1 %t35, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t37 = load i64, ptr %l4, !tbaa !24
  %t38 = load i64, ptr %l8, !tbaa !24
  %t39 = load i64, ptr %l6, !tbaa !24
  %t42 = mul i64 %t38, %t39
  %t45 = add i64 %t37, %t42
  store i64 %t45, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l9, !tbaa !24
  %t50 = mul i64 %t48, 4
  %t53 = add i64 %a2, %t50
  store i64 %t53, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l9, !tbaa !24
  %t56 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t56, ptr %l67, !tbaa !27
  %t57 = load i64, ptr %l10, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t57
  %t62 = load i8, ptr %t61, !tbaa !32
  %t64 = zext i8 %t62 to i32
  %t66 = shl i32 %t64, 24
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t67, ptr %l72, !tbaa !27
  %t68 = load i64, ptr %l10, !tbaa !24
  %t70 = add i64 %t68, 1
  %t72 = getelementptr { i64, ptr }, ptr %l72, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i8, ptr %t73, i64 %t70
  %t75 = load i8, ptr %t74, !tbaa !32
  %t77 = zext i8 %t75 to i32
  %t79 = shl i32 %t77, 16
  %t82 = or i32 %t66, %t79
  %t83 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t83, ptr %l79, !tbaa !27
  %t84 = load i64, ptr %l10, !tbaa !24
  %t86 = add i64 %t84, 2
  %t88 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t89 = load ptr, ptr %t88, !tbaa !27
  %t90 = getelementptr i8, ptr %t89, i64 %t86
  %t91 = load i8, ptr %t90, !tbaa !32
  %t93 = zext i8 %t91 to i32
  %t95 = shl i32 %t93, 8
  %t98 = or i32 %t82, %t95
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t99, ptr %l86, !tbaa !27
  %t100 = load i64, ptr %l10, !tbaa !24
  %t102 = add i64 %t100, 3
  %t104 = getelementptr { i64, ptr }, ptr %l86, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr i8, ptr %t105, i64 %t102
  %t107 = load i8, ptr %t106, !tbaa !32
  %t109 = zext i8 %t107 to i32
  %t112 = or i32 %t98, %t109
  %t115 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t55
  store i32 %t112, ptr %t115, !tbaa !84
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t116 = load i64, ptr %l8, !tbaa !24
  %t118 = add i64 %t116, 1
  store i64 %t118, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  store i64 16, ptr %l11, !tbaa !24
  store i64 64, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l12, !tbaa !24
  %t121 = load i64, ptr %l11, !tbaa !24
  %t124 = icmp sgt i64 %t120, %t121
  br i1 %t124, label %bb13, label %bb14
bb13:
  %t126 = load i64, ptr %l13, !tbaa !24
  %t128 = icmp sgt i64 %t126, 0
  br i1 %t128, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l97, !tbaa !24
  br label %bb18
bb15:
  %t130 = load i64, ptr %l12, !tbaa !24
  %t131 = load i64, ptr %l11, !tbaa !24
  %t134 = sub i64 %t130, %t131
  %t135 = load i64, ptr %l13, !tbaa !24
  %t138 = add i64 %t134, %t135
  %t140 = sub i64 %t138, 1
  %t141 = load i64, ptr %l13, !tbaa !24
  %t144 = sdiv i64 %t140, %t141
  store i64 %t144, ptr %l100, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l100, !tbaa !24
  br label %bb17
bb17:
  %t146 = load i64, ptr %l100, !tbaa !24
  store i64 %t146, ptr %l97, !tbaa !24
  br label %bb18
bb18:
  %t147 = load i64, ptr %l97, !tbaa !24
  store i64 %t147, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t148 = load i64, ptr %l15, !tbaa !24
  %t149 = load i64, ptr %l14, !tbaa !24
  %t152 = icmp slt i64 %t148, %t149
  %t154 = xor i1 %t152, true
  br i1 %t154, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t156 = load i64, ptr %l11, !tbaa !24
  %t157 = load i64, ptr %l15, !tbaa !24
  %t158 = load i64, ptr %l13, !tbaa !24
  %t161 = mul i64 %t157, %t158
  %t164 = add i64 %t156, %t161
  store i64 %t164, ptr %l16, !tbaa !24
  %t166 = load i64, ptr %l16, !tbaa !24
  %t168 = sub i64 %t166, 15
  %t170 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t168
  %t171 = load i32, ptr %t170, !tbaa !84
  %t173 = call i32 @compiler_2fbuild_2erotr(i32 %t171, i32 7)
  store i32 %t173, ptr %l121
  br label %bb23
bb23:
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = sub i64 %t174, 15
  %t178 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t176
  %t179 = load i32, ptr %t178, !tbaa !84
  %t181 = call i32 @compiler_2fbuild_2erotr(i32 %t179, i32 18)
  store i32 %t181, ptr %l125
  br label %bb24
bb24:
  %t182 = load i32, ptr %l121, !tbaa !64
  %t183 = load i32, ptr %l125, !tbaa !64
  %t184 = xor i32 %t182, %t183
  %t185 = load i64, ptr %l16, !tbaa !24
  %t187 = sub i64 %t185, 15
  %t189 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t187
  %t190 = load i32, ptr %t189, !tbaa !84
  %t192 = lshr i32 %t190, 3
  %t195 = xor i32 %t184, %t192
  store i32 %t195, ptr %l17, !tbaa !64
  %t197 = load i64, ptr %l16, !tbaa !24
  %t199 = sub i64 %t197, 2
  %t201 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t199
  %t202 = load i32, ptr %t201, !tbaa !84
  %t204 = call i32 @compiler_2fbuild_2erotr(i32 %t202, i32 17)
  store i32 %t204, ptr %l135
  br label %bb25
bb25:
  %t205 = load i64, ptr %l16, !tbaa !24
  %t207 = sub i64 %t205, 2
  %t209 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t207
  %t210 = load i32, ptr %t209, !tbaa !84
  %t212 = call i32 @compiler_2fbuild_2erotr(i32 %t210, i32 19)
  store i32 %t212, ptr %l139
  br label %bb26
bb26:
  %t213 = load i32, ptr %l135, !tbaa !64
  %t214 = load i32, ptr %l139, !tbaa !64
  %t215 = xor i32 %t213, %t214
  %t216 = load i64, ptr %l16, !tbaa !24
  %t218 = sub i64 %t216, 2
  %t220 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t218
  %t221 = load i32, ptr %t220, !tbaa !84
  %t223 = lshr i32 %t221, 10
  %t226 = xor i32 %t215, %t223
  %t228 = load i64, ptr %l16, !tbaa !24
  %t229 = load i64, ptr %l16, !tbaa !24
  %t231 = sub i64 %t229, 16
  %t233 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t231
  %t234 = load i32, ptr %t233, !tbaa !84
  %t235 = load i32, ptr %l17, !tbaa !64
  %t238 = add i32 %t234, %t235
  %t239 = load i64, ptr %l16, !tbaa !24
  %t241 = sub i64 %t239, 7
  %t243 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t241
  %t244 = load i32, ptr %t243, !tbaa !84
  %t247 = add i32 %t238, %t244
  %t251 = add i32 %t247, %t226
  %t254 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t228
  store i32 %t251, ptr %t254, !tbaa !84
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  %t255 = load i64, ptr %l15, !tbaa !24
  %t257 = add i64 %t255, 1
  store i64 %t257, ptr %l15, !tbaa !24
  br label %bb19
bb28:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t261 = getelementptr %"compiler/build:Sha256", ptr %t259, i32 0, i32 0
  %t262 = getelementptr [8 x i32], ptr %t261, i64 0, i64 0
  %t263 = load i32, ptr %t262, !tbaa !84
  store i32 %t263, ptr %l19, !tbaa !64
  %t265 = load ptr, ptr %l0, !tbaa !29
  %t267 = getelementptr %"compiler/build:Sha256", ptr %t265, i32 0, i32 0
  %t268 = getelementptr [8 x i32], ptr %t267, i64 0, i64 1
  %t269 = load i32, ptr %t268, !tbaa !84
  store i32 %t269, ptr %l20, !tbaa !64
  %t271 = load ptr, ptr %l0, !tbaa !29
  %t273 = getelementptr %"compiler/build:Sha256", ptr %t271, i32 0, i32 0
  %t274 = getelementptr [8 x i32], ptr %t273, i64 0, i64 2
  %t275 = load i32, ptr %t274, !tbaa !84
  store i32 %t275, ptr %l21, !tbaa !64
  %t277 = load ptr, ptr %l0, !tbaa !29
  %t279 = getelementptr %"compiler/build:Sha256", ptr %t277, i32 0, i32 0
  %t280 = getelementptr [8 x i32], ptr %t279, i64 0, i64 3
  %t281 = load i32, ptr %t280, !tbaa !84
  store i32 %t281, ptr %l22, !tbaa !64
  %t283 = load ptr, ptr %l0, !tbaa !29
  %t285 = getelementptr %"compiler/build:Sha256", ptr %t283, i32 0, i32 0
  %t286 = getelementptr [8 x i32], ptr %t285, i64 0, i64 4
  %t287 = load i32, ptr %t286, !tbaa !84
  store i32 %t287, ptr %l23, !tbaa !64
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t291 = getelementptr %"compiler/build:Sha256", ptr %t289, i32 0, i32 0
  %t292 = getelementptr [8 x i32], ptr %t291, i64 0, i64 5
  %t293 = load i32, ptr %t292, !tbaa !84
  store i32 %t293, ptr %l24, !tbaa !64
  %t295 = load ptr, ptr %l0, !tbaa !29
  %t297 = getelementptr %"compiler/build:Sha256", ptr %t295, i32 0, i32 0
  %t298 = getelementptr [8 x i32], ptr %t297, i64 0, i64 6
  %t299 = load i32, ptr %t298, !tbaa !84
  store i32 %t299, ptr %l25, !tbaa !64
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/build:Sha256", ptr %t301, i32 0, i32 0
  %t304 = getelementptr [8 x i32], ptr %t303, i64 0, i64 7
  %t305 = load i32, ptr %t304, !tbaa !84
  store i32 %t305, ptr %l26, !tbaa !64
  store i64 0, ptr %l27, !tbaa !24
  store i64 64, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t307 = load i64, ptr %l28, !tbaa !24
  %t308 = load i64, ptr %l27, !tbaa !24
  %t311 = icmp sgt i64 %t307, %t308
  br i1 %t311, label %bb29, label %bb30
bb29:
  %t313 = load i64, ptr %l29, !tbaa !24
  %t315 = icmp sgt i64 %t313, 0
  br i1 %t315, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l179, !tbaa !24
  br label %bb34
bb31:
  %t317 = load i64, ptr %l28, !tbaa !24
  %t318 = load i64, ptr %l27, !tbaa !24
  %t321 = sub i64 %t317, %t318
  %t322 = load i64, ptr %l29, !tbaa !24
  %t325 = add i64 %t321, %t322
  %t327 = sub i64 %t325, 1
  %t328 = load i64, ptr %l29, !tbaa !24
  %t331 = sdiv i64 %t327, %t328
  store i64 %t331, ptr %l182, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l182, !tbaa !24
  br label %bb33
bb33:
  %t333 = load i64, ptr %l182, !tbaa !24
  store i64 %t333, ptr %l179, !tbaa !24
  br label %bb34
bb34:
  %t334 = load i64, ptr %l179, !tbaa !24
  store i64 %t334, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb35
bb35:
  store %olang.scope zeroinitializer, ptr %s8
  %t335 = load i64, ptr %l31, !tbaa !24
  %t336 = load i64, ptr %l30, !tbaa !24
  %t339 = icmp slt i64 %t335, %t336
  %t341 = xor i1 %t339, true
  br i1 %t341, label %bb36, label %bb37
bb36:
  call void @__olang_scope_close(ptr %s8)
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t343 = load i64, ptr %l27, !tbaa !24
  %t344 = load i64, ptr %l31, !tbaa !24
  %t345 = load i64, ptr %l29, !tbaa !24
  %t348 = mul i64 %t344, %t345
  %t351 = add i64 %t343, %t348
  store i64 %t351, ptr %l32, !tbaa !24
  %t353 = load i32, ptr %l23, !tbaa !64
  %t355 = call i32 @compiler_2fbuild_2erotr(i32 %t353, i32 6)
  store i32 %t355, ptr %l201
  br label %bb39
bb39:
  %t356 = load i32, ptr %l23, !tbaa !64
  %t358 = call i32 @compiler_2fbuild_2erotr(i32 %t356, i32 11)
  store i32 %t358, ptr %l203
  br label %bb40
bb40:
  %t359 = load i32, ptr %l201, !tbaa !64
  %t360 = load i32, ptr %l203, !tbaa !64
  %t361 = xor i32 %t359, %t360
  store i32 %t361, ptr %l204, !tbaa !64
  %t362 = load i32, ptr %l23, !tbaa !64
  %t364 = call i32 @compiler_2fbuild_2erotr(i32 %t362, i32 25)
  store i32 %t364, ptr %l206
  br label %bb41
bb41:
  %t365 = load i32, ptr %l204, !tbaa !64
  %t366 = load i32, ptr %l206, !tbaa !64
  %t367 = xor i32 %t365, %t366
  %t369 = load i32, ptr %l23, !tbaa !64
  %t370 = load i32, ptr %l24, !tbaa !64
  %t373 = and i32 %t369, %t370
  %t374 = load i32, ptr %l23, !tbaa !64
  %t376 = xor i32 %t374, -1
  %t377 = load i32, ptr %l25, !tbaa !64
  %t380 = and i32 %t376, %t377
  %t383 = xor i32 %t373, %t380
  %t385 = load i32, ptr %l26, !tbaa !64
  %t389 = add i32 %t385, %t367
  %t393 = add i32 %t389, %t383
  %t394 = load i64, ptr %l32, !tbaa !24
  %t396 = getelementptr [64 x i32], ptr @G_2ecompiler_2fbuild_2eShaK, i64 0, i64 %t394
  %t397 = load i32, ptr %t396, !tbaa !84
  %t400 = add i32 %t393, %t397
  %t401 = load i64, ptr %l32, !tbaa !24
  %t403 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t401
  %t404 = load i32, ptr %t403, !tbaa !84
  %t407 = add i32 %t400, %t404
  store i32 %t407, ptr %l35, !tbaa !64
  %t409 = load i32, ptr %l19, !tbaa !64
  %t411 = call i32 @compiler_2fbuild_2erotr(i32 %t409, i32 2)
  store i32 %t411, ptr %l228
  br label %bb42
bb42:
  %t412 = load i32, ptr %l19, !tbaa !64
  %t414 = call i32 @compiler_2fbuild_2erotr(i32 %t412, i32 13)
  store i32 %t414, ptr %l230
  br label %bb43
bb43:
  %t415 = load i32, ptr %l228, !tbaa !64
  %t416 = load i32, ptr %l230, !tbaa !64
  %t417 = xor i32 %t415, %t416
  store i32 %t417, ptr %l231, !tbaa !64
  %t418 = load i32, ptr %l19, !tbaa !64
  %t420 = call i32 @compiler_2fbuild_2erotr(i32 %t418, i32 22)
  store i32 %t420, ptr %l233
  br label %bb44
bb44:
  %t421 = load i32, ptr %l231, !tbaa !64
  %t422 = load i32, ptr %l233, !tbaa !64
  %t423 = xor i32 %t421, %t422
  %t425 = load i32, ptr %l19, !tbaa !64
  %t426 = load i32, ptr %l20, !tbaa !64
  %t429 = and i32 %t425, %t426
  %t430 = load i32, ptr %l19, !tbaa !64
  %t431 = load i32, ptr %l21, !tbaa !64
  %t434 = and i32 %t430, %t431
  %t437 = xor i32 %t429, %t434
  %t438 = load i32, ptr %l20, !tbaa !64
  %t439 = load i32, ptr %l21, !tbaa !64
  %t442 = and i32 %t438, %t439
  %t445 = xor i32 %t437, %t442
  %t447 = load i32, ptr %l25, !tbaa !64
  store i32 %t447, ptr %l26, !tbaa !64
  %t449 = load i32, ptr %l24, !tbaa !64
  store i32 %t449, ptr %l25, !tbaa !64
  %t451 = load i32, ptr %l23, !tbaa !64
  store i32 %t451, ptr %l24, !tbaa !64
  %t453 = load i32, ptr %l22, !tbaa !64
  %t454 = load i32, ptr %l35, !tbaa !64
  %t457 = add i32 %t453, %t454
  store i32 %t457, ptr %l23, !tbaa !64
  %t459 = load i32, ptr %l21, !tbaa !64
  store i32 %t459, ptr %l22, !tbaa !64
  %t461 = load i32, ptr %l20, !tbaa !64
  store i32 %t461, ptr %l21, !tbaa !64
  %t463 = load i32, ptr %l19, !tbaa !64
  store i32 %t463, ptr %l20, !tbaa !64
  %t465 = load i32, ptr %l35, !tbaa !64
  %t469 = add i32 %t465, %t423
  %t473 = add i32 %t469, %t445
  store i32 %t473, ptr %l19, !tbaa !64
  call void @__olang_scope_close(ptr %s8)
  br label %bb45
bb45:
  %t475 = load i64, ptr %l31, !tbaa !24
  %t477 = add i64 %t475, 1
  store i64 %t477, ptr %l31, !tbaa !24
  br label %bb35
bb46:
  %t479 = load ptr, ptr %l0, !tbaa !29
  store ptr %t479, ptr %l262, !tbaa !29
  %t480 = load ptr, ptr %l262, !tbaa !29
  %t481 = getelementptr %"compiler/build:Sha256", ptr %t480, i32 0, i32 0
  %t482 = getelementptr [8 x i32], ptr %t481, i64 0, i64 0
  %t483 = load i32, ptr %t482, !tbaa !84
  %t484 = load i32, ptr %l19, !tbaa !64
  %t487 = add i32 %t483, %t484
  %t489 = load ptr, ptr %l262, !tbaa !29
  %t490 = getelementptr %"compiler/build:Sha256", ptr %t489, i32 0, i32 0
  %t491 = getelementptr [8 x i32], ptr %t490, i64 0, i64 0
  store i32 %t487, ptr %t491, !tbaa !84
  %t492 = load ptr, ptr %l0, !tbaa !29
  store ptr %t492, ptr %l266, !tbaa !29
  %t493 = load ptr, ptr %l266, !tbaa !29
  %t494 = getelementptr %"compiler/build:Sha256", ptr %t493, i32 0, i32 0
  %t495 = getelementptr [8 x i32], ptr %t494, i64 0, i64 1
  %t496 = load i32, ptr %t495, !tbaa !84
  %t497 = load i32, ptr %l20, !tbaa !64
  %t500 = add i32 %t496, %t497
  %t502 = load ptr, ptr %l266, !tbaa !29
  %t503 = getelementptr %"compiler/build:Sha256", ptr %t502, i32 0, i32 0
  %t504 = getelementptr [8 x i32], ptr %t503, i64 0, i64 1
  store i32 %t500, ptr %t504, !tbaa !84
  %t505 = load ptr, ptr %l0, !tbaa !29
  store ptr %t505, ptr %l270, !tbaa !29
  %t506 = load ptr, ptr %l270, !tbaa !29
  %t507 = getelementptr %"compiler/build:Sha256", ptr %t506, i32 0, i32 0
  %t508 = getelementptr [8 x i32], ptr %t507, i64 0, i64 2
  %t509 = load i32, ptr %t508, !tbaa !84
  %t510 = load i32, ptr %l21, !tbaa !64
  %t513 = add i32 %t509, %t510
  %t515 = load ptr, ptr %l270, !tbaa !29
  %t516 = getelementptr %"compiler/build:Sha256", ptr %t515, i32 0, i32 0
  %t517 = getelementptr [8 x i32], ptr %t516, i64 0, i64 2
  store i32 %t513, ptr %t517, !tbaa !84
  %t518 = load ptr, ptr %l0, !tbaa !29
  store ptr %t518, ptr %l274, !tbaa !29
  %t519 = load ptr, ptr %l274, !tbaa !29
  %t520 = getelementptr %"compiler/build:Sha256", ptr %t519, i32 0, i32 0
  %t521 = getelementptr [8 x i32], ptr %t520, i64 0, i64 3
  %t522 = load i32, ptr %t521, !tbaa !84
  %t523 = load i32, ptr %l22, !tbaa !64
  %t526 = add i32 %t522, %t523
  %t528 = load ptr, ptr %l274, !tbaa !29
  %t529 = getelementptr %"compiler/build:Sha256", ptr %t528, i32 0, i32 0
  %t530 = getelementptr [8 x i32], ptr %t529, i64 0, i64 3
  store i32 %t526, ptr %t530, !tbaa !84
  %t531 = load ptr, ptr %l0, !tbaa !29
  store ptr %t531, ptr %l278, !tbaa !29
  %t532 = load ptr, ptr %l278, !tbaa !29
  %t533 = getelementptr %"compiler/build:Sha256", ptr %t532, i32 0, i32 0
  %t534 = getelementptr [8 x i32], ptr %t533, i64 0, i64 4
  %t535 = load i32, ptr %t534, !tbaa !84
  %t536 = load i32, ptr %l23, !tbaa !64
  %t539 = add i32 %t535, %t536
  %t541 = load ptr, ptr %l278, !tbaa !29
  %t542 = getelementptr %"compiler/build:Sha256", ptr %t541, i32 0, i32 0
  %t543 = getelementptr [8 x i32], ptr %t542, i64 0, i64 4
  store i32 %t539, ptr %t543, !tbaa !84
  %t544 = load ptr, ptr %l0, !tbaa !29
  store ptr %t544, ptr %l282, !tbaa !29
  %t545 = load ptr, ptr %l282, !tbaa !29
  %t546 = getelementptr %"compiler/build:Sha256", ptr %t545, i32 0, i32 0
  %t547 = getelementptr [8 x i32], ptr %t546, i64 0, i64 5
  %t548 = load i32, ptr %t547, !tbaa !84
  %t549 = load i32, ptr %l24, !tbaa !64
  %t552 = add i32 %t548, %t549
  %t554 = load ptr, ptr %l282, !tbaa !29
  %t555 = getelementptr %"compiler/build:Sha256", ptr %t554, i32 0, i32 0
  %t556 = getelementptr [8 x i32], ptr %t555, i64 0, i64 5
  store i32 %t552, ptr %t556, !tbaa !84
  %t557 = load ptr, ptr %l0, !tbaa !29
  store ptr %t557, ptr %l286, !tbaa !29
  %t558 = load ptr, ptr %l286, !tbaa !29
  %t559 = getelementptr %"compiler/build:Sha256", ptr %t558, i32 0, i32 0
  %t560 = getelementptr [8 x i32], ptr %t559, i64 0, i64 6
  %t561 = load i32, ptr %t560, !tbaa !84
  %t562 = load i32, ptr %l25, !tbaa !64
  %t565 = add i32 %t561, %t562
  %t567 = load ptr, ptr %l286, !tbaa !29
  %t568 = getelementptr %"compiler/build:Sha256", ptr %t567, i32 0, i32 0
  %t569 = getelementptr [8 x i32], ptr %t568, i64 0, i64 6
  store i32 %t565, ptr %t569, !tbaa !84
  %t570 = load ptr, ptr %l0, !tbaa !29
  store ptr %t570, ptr %l290, !tbaa !29
  %t571 = load ptr, ptr %l290, !tbaa !29
  %t572 = getelementptr %"compiler/build:Sha256", ptr %t571, i32 0, i32 0
  %t573 = getelementptr [8 x i32], ptr %t572, i64 0, i64 7
  %t574 = load i32, ptr %t573, !tbaa !84
  %t575 = load i32, ptr %l26, !tbaa !64
  %t578 = add i32 %t574, %t575
  %t580 = load ptr, ptr %l290, !tbaa !29
  %t581 = getelementptr %"compiler/build:Sha256", ptr %t580, i32 0, i32 0
  %t582 = getelementptr [8 x i32], ptr %t581, i64 0, i64 7
  store i32 %t578, ptr %t582, !tbaa !84
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l35 = alloca %"compiler/build:Unit"
  %l37 = alloca ptr
  %l45 = alloca %"compiler/build:Unit"
  %l51 = alloca ptr
  %l52 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i1
  %l57 = alloca i32
  %l61 = alloca %"compiler/build:Unit"
  %l63 = alloca ptr
  %l69 = alloca %"compiler/build:Unit"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/build:stubFrontend", ptr %t2, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = getelementptr %"compiler/build:stubFrontend", ptr %t8, i32 0, i32 1
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/build:Config", ptr %t10, i32 0, i32 3
  %t14 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v2, ptr %s0, ptr %t12, { i64, ptr } { i64 1, ptr @.d117 })
  store i1 %t14, ptr %l15
  br label %bb1
bb1:
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 3
  %t20 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v2, ptr %s0, ptr %s0, ptr %t18, { i64, ptr } { i64 1, ptr @.d118 })
  store { i64, ptr } %t20, ptr %l19
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr @.d119 }, ptr %l16, !tbaa !27
  br label %bb5
bb4:
  %t21 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 2
  %t33 = getelementptr %"compiler/target:Target", ptr %t32, i32 0, i32 5
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 27, ptr @.d120 }, 1
  %t36 = extractvalue { i64, ptr } { i64 27, ptr @.d120 }, 0
  %t38 = extractvalue { i64, ptr } %t34, 1
  %t39 = extractvalue { i64, ptr } %t34, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 3, ptr @.d121 }, 1
  %t42 = extractvalue { i64, ptr } { i64 3, ptr @.d121 }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = getelementptr i8, ptr %t45, i64 %t39
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t44, 1
  store { i64, ptr } %t48, ptr %l7, !tbaa !27
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 2
  %t53 = getelementptr %"compiler/target:Target", ptr %t52, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = extractvalue { i64, ptr } { i64 17, ptr @.d122 }, 1
  %t56 = extractvalue { i64, ptr } { i64 17, ptr @.d122 }, 0
  %t58 = extractvalue { i64, ptr } %t54, 1
  %t59 = extractvalue { i64, ptr } %t54, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 2, ptr @.d123 }, 1
  %t62 = extractvalue { i64, ptr } { i64 2, ptr @.d123 }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = getelementptr i8, ptr %t65, i64 %t59
  call void @olang_textcopy(ptr %t66, ptr %t61, i64 %t62)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  store { i64, ptr } %t68, ptr %l8, !tbaa !27
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/build:Program", ptr %t70, i32 0, i32 0
  store ptr %t72, ptr %l28, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = extractvalue { i64, ptr } { i64 35, ptr @.d124 }, 1
  %t80 = extractvalue { i64, ptr } { i64 35, ptr @.d124 }, 0
  %t81 = add i64 %t78, %t80
  %t83 = extractvalue { i64, ptr } %t29, 1
  %t84 = extractvalue { i64, ptr } %t29, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 3, ptr @.d125 }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr @.d125 }, 0
  %t88 = add i64 %t85, %t87
  %t90 = extractvalue { i64, ptr } %t75, 1
  %t91 = extractvalue { i64, ptr } %t75, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t77, i64 %t78)
  %t94 = getelementptr i8, ptr %t93, i64 %t78
  call void @olang_textcopy(ptr %t94, ptr %t79, i64 %t80)
  %t95 = getelementptr i8, ptr %t94, i64 %t80
  call void @olang_textcopy(ptr %t95, ptr %t83, i64 %t84)
  %t96 = getelementptr i8, ptr %t95, i64 %t84
  call void @olang_textcopy(ptr %t96, ptr %t86, i64 %t87)
  %t97 = getelementptr i8, ptr %t96, i64 %t87
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t93, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t109 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr @.d126 }, i32 0, { i64, ptr } %t106)
  store %"compiler/build:Unit" %t109, ptr %l35
  br label %bb6
bb6:
  %t110 = load ptr, ptr %l28, !tbaa !29
  %t111 = load %"compiler/build:Unit", ptr %l35
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t110, %"compiler/build:Unit" %t111)
  br label %bb7
bb7:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/build:Program", ptr %t112, i32 0, i32 0
  store ptr %t114, ptr %l37, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/build:stubFrontend", ptr %t116, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t115, 1
  %t123 = extractvalue { i64, ptr } %t115, 0
  %t124 = extractvalue { i64, ptr } { i64 36, ptr @.d127 }, 1
  %t125 = extractvalue { i64, ptr } { i64 36, ptr @.d127 }, 0
  %t126 = add i64 %t123, %t125
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 3, ptr @.d128 }, 1
  %t131 = extractvalue { i64, ptr } { i64 3, ptr @.d128 }, 0
  %t132 = add i64 %t129, %t131
  %t134 = extractvalue { i64, ptr } %t120, 1
  %t135 = extractvalue { i64, ptr } %t120, 0
  %t136 = add i64 %t132, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t122, i64 %t123)
  %t138 = getelementptr i8, ptr %t137, i64 %t123
  call void @olang_textcopy(ptr %t138, ptr %t124, i64 %t125)
  %t139 = getelementptr i8, ptr %t138, i64 %t125
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t119)
  %t141 = getelementptr i8, ptr %t139, i64 %t128
  call void @olang_textcopy(ptr %t141, ptr %t130, i64 %t131)
  %t142 = getelementptr i8, ptr %t141, i64 %t131
  call void @olang_textcopy(ptr %t142, ptr %t134, i64 %t135)
  %t143 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t137, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t154 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 4, ptr @.d129 }, i32 0, { i64, ptr } %t151)
  store %"compiler/build:Unit" %t154, ptr %l45
  br label %bb8
bb8:
  %t155 = load ptr, ptr %l37, !tbaa !29
  %t156 = load %"compiler/build:Unit", ptr %l45
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t155, %"compiler/build:Unit" %t156)
  br label %bb9
bb9:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = extractvalue { i64, ptr } %t157, 0
  %t162 = extractvalue { i64, ptr } { i64 90, ptr @.d130 }, 1
  %t163 = extractvalue { i64, ptr } { i64 90, ptr @.d130 }, 0
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 73, ptr @.d131 }, 1
  %t166 = extractvalue { i64, ptr } { i64 73, ptr @.d131 }, 0
  %t167 = add i64 %t164, %t166
  %t168 = extractvalue { i64, ptr } { i64 96, ptr @.d132 }, 1
  %t169 = extractvalue { i64, ptr } { i64 96, ptr @.d132 }, 0
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 15, ptr @.d133 }, 1
  %t172 = extractvalue { i64, ptr } { i64 15, ptr @.d133 }, 0
  %t173 = add i64 %t170, %t172
  %t175 = extractvalue { i64, ptr } %t158, 1
  %t176 = extractvalue { i64, ptr } %t158, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t160, i64 %t161)
  %t179 = getelementptr i8, ptr %t178, i64 %t161
  call void @olang_textcopy(ptr %t179, ptr %t162, i64 %t163)
  %t180 = getelementptr i8, ptr %t179, i64 %t163
  call void @olang_textcopy(ptr %t180, ptr %t165, i64 %t166)
  %t181 = getelementptr i8, ptr %t180, i64 %t166
  call void @olang_textcopy(ptr %t181, ptr %t168, i64 %t169)
  %t182 = getelementptr i8, ptr %t181, i64 %t169
  call void @olang_textcopy(ptr %t182, ptr %t171, i64 %t172)
  %t183 = getelementptr i8, ptr %t182, i64 %t172
  call void @olang_textcopy(ptr %t183, ptr %t175, i64 %t176)
  %t184 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t178, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l9, !tbaa !27
  %t194 = load ptr, ptr %l4, !tbaa !29
  %t196 = getelementptr %"compiler/build:Program", ptr %t194, i32 0, i32 0
  store ptr %t196, ptr %l51, !tbaa !29
  store i32 %a2, ptr %l52
  store i32 1, ptr %l54
  %t200 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %l52, ptr %l54)
  store i1 %t200, ptr %l56
  br label %bb10
bb10:
  %t201 = load i1, ptr %l56, !tbaa !21
  br i1 %t201, label %bb11, label %bb12
bb11:
  store i32 1, ptr %l57
  br label %bb13
bb12:
  store i32 2, ptr %l57
  br label %bb13
bb13:
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t205 = load i32, ptr %l57
  %t207 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr @.d134 }, i32 %t205, { i64, ptr } %t204)
  store %"compiler/build:Unit" %t207, ptr %l61
  br label %bb14
bb14:
  %t208 = load ptr, ptr %l51, !tbaa !29
  %t209 = load %"compiler/build:Unit", ptr %l61
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t208, %"compiler/build:Unit" %t209)
  br label %bb15
bb15:
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = getelementptr %"compiler/build:Program", ptr %t210, i32 0, i32 0
  store ptr %t212, ptr %l63, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = extractvalue { i64, ptr } %t213, 0
  %t218 = extractvalue { i64, ptr } { i64 40, ptr @.d135 }, 1
  %t219 = extractvalue { i64, ptr } { i64 40, ptr @.d135 }, 0
  %t220 = add i64 %t217, %t219
  %t222 = extractvalue { i64, ptr } %t214, 1
  %t223 = extractvalue { i64, ptr } %t214, 0
  %t224 = add i64 %t220, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t216, i64 %t217)
  %t226 = getelementptr i8, ptr %t225, i64 %t217
  call void @olang_textcopy(ptr %t226, ptr %t218, i64 %t219)
  %t227 = getelementptr i8, ptr %t226, i64 %t219
  call void @olang_textcopy(ptr %t227, ptr %t222, i64 %t223)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t225, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = extractvalue { i64, ptr } %t229, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t239 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr @.d136 }, i32 3, { i64, ptr } %t236)
  store %"compiler/build:Unit" %t239, ptr %l69
  br label %bb16
bb16:
  %t240 = load ptr, ptr %l63, !tbaa !29
  %t241 = load %"compiler/build:Unit", ptr %l69
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t240, %"compiler/build:Unit" %t241)
  br label %bb17
bb17:
  %t242 = load ptr, ptr %l4, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = extractvalue { i64, ptr } %t243, 0
  %t248 = extractvalue { i64, ptr } { i64 42, ptr @.d137 }, 1
  %t249 = extractvalue { i64, ptr } { i64 42, ptr @.d137 }, 0
  %t250 = add i64 %t247, %t249
  %t252 = extractvalue { i64, ptr } %t244, 1
  %t253 = extractvalue { i64, ptr } %t244, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t246, i64 %t247)
  %t256 = getelementptr i8, ptr %t255, i64 %t247
  call void @olang_textcopy(ptr %t256, ptr %t248, i64 %t249)
  %t257 = getelementptr i8, ptr %t256, i64 %t249
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t255, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = extractvalue { i64, ptr } %t259, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t269 = getelementptr %"compiler/build:Program", ptr %t242, i32 0, i32 1
  store { i64, ptr } %t266, ptr %t269, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i32 } @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a2, 0
  %t5 = trunc i64 %t3 to i32
  %t7 = insertvalue { i32, i32 } zeroinitializer, i32 %t5, 1
  store { i32, i32 } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @compiler_2fbuild_2efileError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %l11 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr @.d138 }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  %t19 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/msgs:Msg" %a1)
  store i64 %t19, ptr %l11
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr @.d139 }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/msgs:Msg" %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %t1)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %s0, ptr %t12)
  store { i64, ptr } %t14, ptr %l5
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t21)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ehexOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr @.d140 }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb17
bb4:
  %t8 = load i32, ptr %l0
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr @.d141 }, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  br label %bb17
bb8:
  %t15 = load i32, ptr %l0
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 5, ptr @.d142 }, ptr %l12, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  br label %bb17
bb12:
  %t22 = load i32, ptr %l0
  %t24 = trunc i64 3 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr @.d143 }, ptr %l16, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l1, !tbaa !27
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @.c144)
  unreachable
bb17:
  %t29 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t30 = extractvalue { i64, ptr } %t29, 0
  store i64 %t30, ptr %l18, !tbaa !24
  %t31 = load i64, ptr %l18, !tbaa !24
  %t32 = mul i64 %t31, 1
  %t33 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t32)
  %t34 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t35 = insertvalue { i64, ptr } %t34, ptr %t33, 1
  store { i64, ptr } %t35, ptr %l19, !tbaa !27
  %t36 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = mul i64 %t40, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t37, ptr %t39, i64 %t41, i1 false)
  %t42 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t42, ptr %l1, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t43, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2elinkCurrent(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l12 = alloca %"std/os:FileInfo"
  %l14 = alloca %"std/os:FileInfo"
  %l15 = alloca i32
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c145)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t15, ptr %l3, !tbaa !27
  %t18 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
  %t19 = extractvalue { i32, %"std/os:FileInfo" } %t18, 1
  %t20 = extractvalue { i32, %"std/os:FileInfo" } %t18, 0
  store i32 %t20, ptr %l15
  %t21 = icmp ne i32 %t20, 0
  br i1 %t21, label %bb8, label %ok.22
ok.22:
  store %"std/os:FileInfo" %t19, ptr %l14
  br label %bb7
bb7:
  %t23 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t23, ptr %l12
  br label %bb12
bb8:
  %t24 = load i32, ptr %l15, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @.c146)
  unreachable
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t30 = load %"std/os:FileInfo", ptr %l12
  store %"std/os:FileInfo" %t30, ptr %l4
  %t31 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t33 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t34 = load i64, ptr %t33, !tbaa !24
  %t35 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t36 = load i64, ptr %t35, !tbaa !24
  %t38 = extractvalue { i64, ptr } %a2, 1
  %t39 = extractvalue { i64, ptr } %a2, 0
  %t40 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 1
  %t41 = extractvalue { i64, ptr } { i64 1, ptr @.d147 }, 0
  %t42 = add i64 %t39, %t41
  %t44 = call i64 @__olang_fmt_i64(ptr null, i64 %t34)
  %t45 = add i64 %t42, %t44
  %t46 = extractvalue { i64, ptr } { i64 1, ptr @.d148 }, 1
  %t47 = extractvalue { i64, ptr } { i64 1, ptr @.d148 }, 0
  %t48 = add i64 %t45, %t47
  %t50 = call i64 @__olang_fmt_i64(ptr null, i64 %t36)
  %t51 = add i64 %t48, %t50
  %t52 = extractvalue { i64, ptr } { i64 1, ptr @.d149 }, 1
  %t53 = extractvalue { i64, ptr } { i64 1, ptr @.d149 }, 0
  %t54 = add i64 %t51, %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t38, i64 %t39)
  %t56 = getelementptr i8, ptr %t55, i64 %t39
  call void @olang_textcopy(ptr %t56, ptr %t40, i64 %t41)
  %t57 = getelementptr i8, ptr %t56, i64 %t41
  %t58 = call i64 @__olang_fmt_i64(ptr %t57, i64 %t34)
  %t59 = getelementptr i8, ptr %t57, i64 %t44
  call void @olang_textcopy(ptr %t59, ptr %t46, i64 %t47)
  %t60 = getelementptr i8, ptr %t59, i64 %t47
  %t61 = call i64 @__olang_fmt_i64(ptr %t60, i64 %t36)
  %t62 = getelementptr i8, ptr %t60, i64 %t50
  call void @olang_textcopy(ptr %t62, ptr %t52, i64 %t53)
  %t63 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t55, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = extractvalue { i64, ptr } %t64, 1
  %t68 = mul i64 %t66, 1
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @llvm.memcpy.p0.p0.i64(ptr %t69, ptr %t67, i64 %t68, i1 false)
  %t70 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t31, { i64, ptr } %t71)
  store i1 %t74, ptr %l25
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t75 = load i1, ptr %l25, !tbaa !21
  store i1 %t75, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fbuild_2erotr(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !64
  %t2 = load i32, ptr %l1, !tbaa !64
  store i32 %t2, ptr %l3, !tbaa !64
  %t4 = load i32, ptr %l3, !tbaa !64
  %t5 = load i32, ptr %l3, !tbaa !64
  %t6 = lshr i32 %t1, %t5
  %t7 = load i32, ptr %l0, !tbaa !64
  %t8 = load i32, ptr %l1, !tbaa !64
  %t10 = sub i32 32, %t8
  store i32 %t10, ptr %l7, !tbaa !64
  %t12 = load i32, ptr %l7, !tbaa !64
  %t13 = load i32, ptr %l7, !tbaa !64
  %t14 = shl i32 %t7, %t13
  %t17 = or i32 %t6, %t14
  store i32 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/os:Output"
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l23 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t5 = call { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l11
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9
ok.9:
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb7
bb3:
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c150)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb15
bb7:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  store { i64, ptr } { i64 0, ptr @.d151 }, ptr %l18, !tbaa !27
  %t25 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t26 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v1, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t23, { i64, ptr } %t25, i1 true, { i64, ptr } { i64 0, ptr @.d152 })
  %t27 = extractvalue { i32, %"std/os:Output" } %t26, 1
  %t28 = extractvalue { i32, %"std/os:Output" } %t26, 0
  store i32 %t28, ptr %l20
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb9, label %ok.30
ok.30:
  store %"std/os:Output" %t27, ptr %l19
  br label %bb8
bb8:
  %t31 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t31, ptr %l14
  br label %bb13
bb9:
  %t32 = load i32, ptr %l20, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb10, label %bb11
bb10:
  br label %bb12
bb11:
  call void @__olang_check_failed(ptr @.c153)
  unreachable
bb12:
  %t37 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t37, ptr %l23, !tbaa !27
  %t38 = load i64, ptr %l5, !tbaa !24
  %t40 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t41 = load ptr, ptr %t40, !tbaa !27
  %t42 = getelementptr i32, ptr %t41, i64 %t38
  store i32 127, ptr %t42, !tbaa !33
  %t43 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t43, ptr %l25, !tbaa !27
  %t44 = load i64, ptr %l5, !tbaa !24
  %t45 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t45, ptr %l27, !tbaa !27
  %t46 = load i64, ptr %l5, !tbaa !24
  %t48 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = getelementptr { i64, ptr }, ptr %t49, i64 %t46
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !37
  store { i64, ptr } %t51, ptr %l29, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %t53, i64 0
  %t55 = load { i64, ptr }, ptr %t54, !tbaa !37
  %t56 = extractvalue { i64, ptr } { i64 11, ptr @.d154 }, 1
  %t57 = extractvalue { i64, ptr } { i64 11, ptr @.d154 }, 0
  %t59 = extractvalue { i64, ptr } %t55, 1
  %t60 = extractvalue { i64, ptr } %t55, 0
  %t61 = add i64 %t57, %t60
  %t62 = extractvalue { i64, ptr } { i64 1, ptr @.d155 }, 1
  %t63 = extractvalue { i64, ptr } { i64 1, ptr @.d155 }, 0
  %t64 = add i64 %t61, %t63
  %t65 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t56, i64 %t57)
  %t66 = getelementptr i8, ptr %t65, i64 %t57
  call void @olang_textcopy(ptr %t66, ptr %t59, i64 %t60)
  %t67 = getelementptr i8, ptr %t66, i64 %t60
  call void @olang_textcopy(ptr %t67, ptr %t62, i64 %t63)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t65, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  %t79 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr { i64, ptr }, ptr %t80, i64 %t44
  store { i64, ptr } %t76, ptr %t81, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb13:
  %t82 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t82, ptr %l6
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l33, !tbaa !27
  %t84 = load i64, ptr %l5, !tbaa !24
  %t85 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t86 = load i32, ptr %t85, !tbaa !23
  %t89 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr i32, ptr %t90, i64 %t84
  store i32 %t86, ptr %t91, !tbaa !33
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l36, !tbaa !27
  %t93 = load i64, ptr %l5, !tbaa !24
  %t94 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t95 = load { i64, ptr }, ptr %t94, !tbaa !27
  %t96 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t95, 1
  %t100 = extractvalue { i64, ptr } %t95, 0
  %t102 = extractvalue { i64, ptr } %t97, 1
  %t103 = extractvalue { i64, ptr } %t97, 0
  %t104 = add i64 %t100, %t103
  %t105 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t104)
  call void @olang_textcopy(ptr %t105, ptr %t99, i64 %t100)
  %t106 = getelementptr i8, ptr %t105, i64 %t100
  call void @olang_textcopy(ptr %t106, ptr %t102, i64 %t103)
  %t107 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t108 = insertvalue { i64, ptr } %t107, ptr %t105, 1
  %t110 = extractvalue { i64, ptr } %t108, 0
  %t111 = extractvalue { i64, ptr } %t108, 1
  %t112 = mul i64 %t110, 1
  %t113 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t112)
  call void @llvm.memcpy.p0.p0.i64(ptr %t113, ptr %t111, i64 %t112, i1 false)
  %t114 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  %t118 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr { i64, ptr }, ptr %t119, i64 %t93
  store { i64, ptr } %t115, ptr %t120, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb14
bb14:
  br label %bb1
bb15:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c156)
  unreachable
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c157)
  unreachable
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  br i1 %t9, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c158)
  unreachable
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2estatusOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/os:Output"
  %l2 = alloca %"std/os:Output"
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/os:Output"
  %l11 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t16 = insertvalue [1 x { i64, ptr }] undef, { i64, ptr } %t14, 0
  %t18 = load ptr, ptr @__olang_prog_scope
  %t19 = call ptr @__olang_scope_alloc(ptr %t18, i64 16)
  store [1 x { i64, ptr }] %t16, ptr %t19
  %t20 = insertvalue { i64, ptr } undef, i64 1, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  %t23 = extractvalue { i64, ptr } %t21, 0
  %t24 = extractvalue { i64, ptr } %t21, 1
  %t25 = mul i64 %t23, 16
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t24, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } { i64 0, ptr @.d151 }, ptr %l9, !tbaa !27
  %t30 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t31 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t28, { i64, ptr } %t30, i1 true, { i64, ptr } { i64 0, ptr @.d152 })
  %t32 = extractvalue { i32, %"std/os:Output" } %t31, 1
  %t33 = extractvalue { i32, %"std/os:Output" } %t31, 0
  store i32 %t33, ptr %l11
  %t34 = icmp ne i32 %t33, 0
  br i1 %t34, label %bb2, label %ok.35
ok.35:
  store %"std/os:Output" %t32, ptr %l10
  br label %bb1
bb1:
  %t36 = load %"std/os:Output", ptr %l10
  store %"std/os:Output" %t36, ptr %l2
  br label %bb6
bb2:
  %t37 = load i32, ptr %l11, !tbaa !23
  %t38 = ashr i32 %t37, 16
  %t40 = icmp eq i32 %t38, 1
  br i1 %t40, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @.c159)
  unreachable
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb6:
  %t43 = load %"std/os:Output", ptr %l2
  store %"std/os:Output" %t43, ptr %l1
  %t44 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 0
  %t45 = load i32, ptr %t44, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t45, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eunbuilt() #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/target:Target"
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"compiler/target:Target"
  %l19 = alloca %"compiler/cond:Consts"
  %l20 = alloca %"compiler/build:Config"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 5, ptr @.d160 }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d161 }, ptr %l1, !tbaa !27
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
  store %"compiler/target:Target" %t1, ptr %l18
  br label %bb1
bb1:
  %t2 = load %"compiler/target:Target", ptr %l18
  store %"compiler/target:Target" %t2, ptr %l2
  %t3 = call %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
  store %"compiler/cond:Consts" %t3, ptr %l19
  br label %bb2
bb2:
  %t4 = load %"compiler/cond:Consts", ptr %l19
  store { i64, ptr } { i64 0, ptr @.d162 }, ptr %l12, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d163 }, ptr %l13, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d164 }, ptr %l17, !tbaa !27
  %t5 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 0
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %t5, !tbaa !27
  %t7 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 1
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %t7, !tbaa !27
  %t9 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 2
  %t10 = load %"compiler/target:Target", ptr %l2
  store %"compiler/target:Target" %t10, ptr %t9
  %t11 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 3
  store %"compiler/cond:Consts" %t4, ptr %t11
  %t13 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 4
  store i1 false, ptr %t13, !tbaa !21
  %t15 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 5
  store i1 false, ptr %t15, !tbaa !21
  %t17 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 6
  store i1 false, ptr %t17, !tbaa !21
  %t19 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 7
  store i1 false, ptr %t19, !tbaa !21
  %t21 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 8
  store i1 false, ptr %t21, !tbaa !21
  %t23 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 9
  store i64 0, ptr %t23, !tbaa !24
  %t25 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 10
  store i1 false, ptr %t25, !tbaa !21
  %t27 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 11
  store i1 false, ptr %t27, !tbaa !21
  %t29 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 12
  %t30 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t30, ptr %t29, !tbaa !27
  %t31 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 13
  %t32 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t32, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 14
  store i64 0, ptr %t33, !tbaa !24
  %t35 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 15
  store i64 0, ptr %t35, !tbaa !24
  %t37 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 16
  store i1 false, ptr %t37, !tbaa !21
  %t39 = getelementptr %"compiler/build:Config", ptr %l20, i32 0, i32 17
  %t40 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t40, ptr %t39, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l20, i64 312, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/build:Program"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l3
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  store { i64, ptr } { i64 0, ptr @.d165 }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d166 }, ptr %l2, !tbaa !27
  %t5 = insertvalue %"compiler/build:Program" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, 0
  %t6 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = insertvalue %"compiler/build:Program" %t5, { i64, ptr } %t6, 1
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = insertvalue %"compiler/build:Program" %t7, { i64, ptr } %t8, 2
  store %"compiler/build:Program" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Program", ptr %rv
  ret %"compiler/build:Program" %rr
}

define dso_local %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/build:Sha256"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x i32] undef, i32 1779033703, 0
  %t2 = insertvalue [8 x i32] %t1, i32 -1150833019, 1
  %t3 = insertvalue [8 x i32] %t2, i32 1013904242, 2
  %t4 = insertvalue [8 x i32] %t3, i32 -1521486534, 3
  %t5 = insertvalue [8 x i32] %t4, i32 1359893119, 4
  %t6 = insertvalue [8 x i32] %t5, i32 -1694144372, 5
  %t7 = insertvalue [8 x i32] %t6, i32 528734635, 6
  %t8 = insertvalue [8 x i32] %t7, i32 1541459225, 7
  %t11 = insertvalue %"compiler/build:Sha256" undef, [8 x i32] %t8, 0
  %t13 = insertvalue %"compiler/build:Sha256" %t11, [64 x i8] zeroinitializer, 1
  %t15 = insertvalue %"compiler/build:Sha256" %t13, i64 0, 2
  %t17 = insertvalue %"compiler/build:Sha256" %t15, i64 0, 3
  store %"compiler/build:Sha256" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Sha256", ptr %rv
  ret %"compiler/build:Sha256" %rr
}

define dso_local %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca %"compiler/build:Unit"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr @.d167 }, ptr %l6, !tbaa !27
  %t8 = insertvalue %"compiler/build:Unit" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/build:Unit" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/build:Unit" %t10, { i64, ptr } %a2, 2
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/build:Unit" %t12, { i64, ptr } %t13, 3
  store %"compiler/build:Unit" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Unit", ptr %rv
  ret %"compiler/build:Unit" %rr
}

define dso_local %"compiler/build:compiles" @compiler_2fbuild_3acompiles_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l1 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l2 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l3 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"compiler/build:compiles"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l5
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l5
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %l0
  %t4 = load ptr, ptr @__olang_prog_scope
  %t5 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t4)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t5, ptr %l6
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l6
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t6, ptr %l1
  %t7 = load ptr, ptr @__olang_prog_scope
  %t8 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t7)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t8, ptr %l7
  br label %bb3
bb3:
  %t9 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l7
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t9, ptr %l2
  %t10 = load ptr, ptr @__olang_prog_scope
  %t11 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t10)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t11, ptr %l8
  br label %bb4
bb4:
  %t12 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l8
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t12, ptr %l3
  %t13 = load ptr, ptr @__olang_prog_scope
  %t14 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t13)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t14, ptr %l9
  br label %bb5
bb5:
  %t15 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l9
  %t16 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  %t17 = insertvalue %"compiler/build:compiles" undef, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t16, 0
  %t18 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l1
  %t19 = insertvalue %"compiler/build:compiles" %t17, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t18, 1
  %t20 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l2
  %t21 = insertvalue %"compiler/build:compiles" %t19, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t20, 2
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l3
  %t23 = insertvalue %"compiler/build:compiles" %t21, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, 3
  %t25 = insertvalue %"compiler/build:compiles" %t23, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t15, 4
  store %"compiler/build:compiles" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:compiles", ptr %rv
  ret %"compiler/build:compiles" %rr
}

define dso_local %"compiler/build:stubFrontend" @compiler_2fbuild_3astubFrontend_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/build:stubFrontend"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/build:stubFrontend" undef, i64 0, 0
  %t4 = insertvalue %"compiler/build:stubFrontend" %t2, i64 0, 1
  store %"compiler/build:stubFrontend" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:stubFrontend", ptr %rv
  ret %"compiler/build:stubFrontend" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fbuild() #0 {
entry:
  br label %start
start:
  br label %bb0
bb0:
  call void @compiler_2fbuild_2eThinFrom_2einit()
  br label %bb1
bb1:
  call void @compiler_2fbuild_2eImportLimit_2einit()
  br label %bb2
bb2:
  call void @compiler_2fbuild_2ePhaseAt_2einit()
  br label %bb3
bb3:
  call void @compiler_2fbuild_2eShaK_2einit()
  br label %bb4
bb4:
  br label %ret
ret:
  ret void
}

declare void @__olang_check_failed(ptr)
@.c0 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:294: reached unreachable code\0A\00"
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d1 = private constant [1 x i8] [i8 0]
@.d2 = private constant [11 x i8] c"OLANG_TIMES"
@.c3 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:120: reached unreachable code\0A\00"
@.d4 = private constant [7 x i8] c"olang: "
@.d5 = private constant [1 x i8] c" "
declare i64 @__olang_fmt_i64(ptr, i64)
@.d6 = private constant [4 x i8] c" ms\0A"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant [5 x i8] c"front"
@.d8 = private constant [10 x i8] c"lower+emit"
@.c9 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:124: reached unreachable code\0A\00"
declare i32 @getpid()
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.c10 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:340: array length out of range\0A\00"
@.c11 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:341: array length out of range\0A\00"
@.c12 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:343: array length out of range\0A\00"
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_13(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l2
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %a0
  %t7 = load i64, ptr %t6, !tbaa !34
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i64, ptr %t12, i64 %a1
  %t14 = load i64, ptr %t13, !tbaa !34
  %t17 = icmp sgt i64 %t7, %t14
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.c14 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:348: reached unreachable code\0A\00"
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task15(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load ptr, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2fbuild_2erunner(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

declare i64 @__olang_join_tasks(ptr)
@.d16 = private constant [1 x i8] c"/"
@.d17 = private constant [2 x i8] c"./"
@.d18 = private constant [6 x i8] c"Hangup"
@.d19 = private constant [9 x i8] c"Interrupt"
@.d20 = private constant [4 x i8] c"Quit"
@.d21 = private constant [19 x i8] c"Illegal instruction"
@.d22 = private constant [21 x i8] c"Trace/breakpoint trap"
@.d23 = private constant [7 x i8] c"Aborted"
@.d24 = private constant [9 x i8] c"Bus error"
@.d25 = private constant [24 x i8] c"Floating point exception"
@.d26 = private constant [6 x i8] c"Killed"
@.d27 = private constant [18 x i8] c"Segmentation fault"
@.d28 = private constant [11 x i8] c"Broken pipe"
@.d29 = private constant [11 x i8] c"Alarm clock"
@.d30 = private constant [10 x i8] c"Terminated"
@.d31 = private constant [15 x i8] c"Unknown signal "
@.c32 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:673: reached unreachable code\0A\00"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d33 = private constant [4 x i8] c"test"
@.d34 = private constant [0 x i8] c""
@.d35 = private constant [0 x i8] c""
@.c36 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:653: reached unreachable code\0A\00"
@.d37 = private constant [35 x i8] c": lost track of its build, skipping"
@.d38 = private constant [2 x i8] c"31"
@.d39 = private constant [22 x i8] c": the compiler ended ("
@.d40 = private constant [11 x i8] c"), skipping"
@.d41 = private constant [2 x i8] c"31"
@.d42 = private constant [62 x i8] c"olang: error: the self-hosted compiler cannot build this yet: "
@.d43 = private constant [6 x i8] c"bfloat"
@.d44 = private constant [6 x i8] c"-mllvm"
@.d45 = private constant [16 x i8] c"-fast-isel=false"
@.d46 = private constant [26 x i8] c"-Wl,-plugin-opt,cache-dir="
@.d47 = private constant [8 x i8] c"/thinlto"
@.d48 = private constant [36 x i8] c"-Wl,-plugin-opt,-import-instr-limit="
@.d49 = private constant [2 x i8] c"-o"
@.d50 = private constant [3 x i8] c"-lm"
@.d51 = private constant [9 x i8] c"-lpthread"
@.d52 = private constant [4 x i8] c"-ldl"
@.d53 = private constant [5 x i8] c"-lffi"
@.d54 = private constant [5 x i8] c".link"
@.d55 = private constant [0 x i8] c""
@.d56 = private constant [0 x i8] c""
@.d57 = private constant [0 x i8] c""
@.d58 = private constant [1 x i8] c" "
@.d59 = private constant [1 x i8] c" "
@.d60 = private constant [1 x i8] c"\0A"
@.d61 = private constant [9 x i8] c"--target="
@.d62 = private constant [0 x i8] c""
@.d63 = private constant [3 x i8] c"-O0"
@.d64 = private constant [2 x i8] c"-g"
@.d65 = private constant [17 x i8] c"-fsanitize=thread"
@.d66 = private constant [3 x i8] c"-O1"
@.d67 = private constant [17 x i8] c"-fsanitize=thread"
@.d68 = private constant [3 x i8] c"-O3"
@.d69 = private constant [10 x i8] c"-flto=thin"
@.d70 = private constant [5 x i8] c"-flto"
@.c71 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:326: reached unreachable code\0A\00"
@.c72 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:329: slice bounds out of range\0A\00"
@.d73 = private constant [1 x i8] c"/"
@.d74 = private constant [1 x i8] c"."
@.d75 = private constant [2 x i8] c".o"
@.d76 = private constant [0 x i8] c""
@.d77 = private constant [13 x i8] c"olang_runtime"
@.d78 = private constant [0 x i8] c""
@.d79 = private constant [0 x i8] c""
@.d80 = private constant [13 x i8] c"olang_dyncall"
@.d81 = private constant [0 x i8] c""
@.d82 = private constant [0 x i8] c""
@.d83 = private constant [0 x i8] c""
@.d84 = private constant [9 x i8] c"--version"
@.d85 = private constant [0 x i8] c""
@.c86 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:181: reached unreachable code\0A\00"
@.d87 = private constant [0 x i8] c""
@.d88 = private constant [5 x i8] c".race"
@.d89 = private constant [0 x i8] c""
@.d90 = private constant [6 x i8] c".debug"
@.d91 = private constant [0 x i8] c""
@.d92 = private constant [4 x i8] c".san"
@.d93 = private constant [0 x i8] c""
@.d94 = private constant [1 x i8] c"["
@.d95 = private constant [1 x i8] c"m"
@.d96 = private constant [3 x i8] c"[0m"
@.d97 = private constant [27 x i8] c": semantic errors, skipping"
@.d98 = private constant [2 x i8] c"31"
@.d99 = private constant [27 x i8] c": cannot be built, skipping"
@.d100 = private constant [2 x i8] c"31"
@.d101 = private constant [0 x i8] c""
@.c102 = private unnamed_addr constant [53 x i8] c"compiler/build.olang:389: slice bounds out of range\0A\00"
@.d103 = private constant [3 x i8] c".ll"
@.d104 = private constant [1 x i8] c"/"
@.d105 = private constant [3 x i8] c".ll"
@.d106 = private constant [6 x i8] c"olang_"
@.d107 = private constant [0 x i8] c""
@.d108 = private constant [1 x i8] c"."
@.d109 = private constant [4 x i8] c".tmp"
@.d110 = private constant [2 x i8] c"-c"
@.d111 = private constant [2 x i8] c"-o"
declare i64 @sysconf(i32)
@.c112 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:534: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aUnitKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d113 = private constant [1 x i8] c"a"
@.d114 = private constant [1 x i8] [i8 -128]
@.d115 = private constant [1 x i8] [i8 0]
@.c116 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:287: reached unreachable code\0A\00"
declare void @llvm.memset.p0.i64(ptr, i8, i64, i1)
@.d117 = private constant [1 x i8] c"N"
@.d118 = private constant [1 x i8] c"N"
@.d119 = private constant [2 x i8] c"41"
@.d120 = private constant [27 x i8] c"attributes #0 = { nounwind "
@.d121 = private constant [3 x i8] c" }\0A"
@.d122 = private constant [17 x i8] c"target triple = \22"
@.d123 = private constant [2 x i8] c"\22\0A"
@.d124 = private constant [35 x i8] c"define i32 @lib_n() #0 {\0A  ret i32 "
@.d125 = private constant [3 x i8] c"\0A}\0A"
@.d126 = private constant [3 x i8] c"lib"
@.d127 = private constant [36 x i8] c"define i32 @util_k() #0 {\0A  ret i32 "
@.d128 = private constant [3 x i8] c"\0A}\0A"
@.d129 = private constant [4 x i8] c"util"
@.d130 = private constant [90 x i8] c"declare i32 @lib_n()\0Adeclare i32 @util_k()\0Adeclare i32 @inst_z()\0Adeclare void @olang_rt()\0A"
@.d131 = private constant [73 x i8] c"define i32 @main() #0 {\0A  call void @olang_rt()\0A  %a = call i32 @lib_n()\0A"
@.d132 = private constant [96 x i8] c"  %b = call i32 @util_k()\0A  %c = call i32 @inst_z()\0A  %s = add i32 %a, %b\0A  %t = add i32 %s, %c\0A"
@.d133 = private constant [15 x i8] c"  ret i32 %t\0A}\0A"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fbuild_3aKind(ptr %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t2 = load i32, ptr %a0
  %t3 = sext i32 %t2 to i64
  %t5 = load i32, ptr %a1
  %t6 = sext i32 %t5 to i64
  %t9 = icmp eq i64 %t3, %t6
  br i1 %t9, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d134 = private constant [3 x i8] c"app"
@.d135 = private constant [40 x i8] c"define i32 @inst_z() #0 {\0A  ret i32 0\0A}\0A"
@.d136 = private constant [3 x i8] c"app"
@.d137 = private constant [42 x i8] c"define void @olang_rt() #0 {\0A  ret void\0A}\0A"
@.d138 = private constant [0 x i8] c""
@.d139 = private constant [0 x i8] c""
@.d140 = private constant [0 x i8] c""
@.d141 = private constant [5 x i8] c".main"
@.d142 = private constant [5 x i8] c".test"
@.d143 = private constant [5 x i8] c".inst"
@.c144 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:312: reached unreachable code\0A\00"
@.c145 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:493: reached unreachable code\0A\00"
@.c146 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:494: reached unreachable code\0A\00"
@.d147 = private constant [1 x i8] c" "
@.d148 = private constant [1 x i8] c" "
@.d149 = private constant [1 x i8] c"\0A"
@.c150 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:358: reached unreachable code\0A\00"
@.d151 = private constant [0 x i8] c""
@.d152 = private constant [0 x i8] c""
@.c153 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:359: reached unreachable code\0A\00"
@.d154 = private constant [11 x i8] c"cannot run "
@.d155 = private constant [1 x i8] c"\0A"
@.c156 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:504: reached unreachable code\0A\00"
@.c157 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:506: reached unreachable code\0A\00"
@.c158 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:505: reached unreachable code\0A\00"
@.c159 = private unnamed_addr constant [52 x i8] c"compiler/build.olang:798: reached unreachable code\0A\00"
@.d160 = private constant [5 x i8] c"build"
@.d161 = private constant [0 x i8] c""
@.d162 = private constant [0 x i8] c""
@.d163 = private constant [0 x i8] c""
@.d164 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d165 = private constant [0 x i8] c""
@.d166 = private constant [0 x i8] c""
@.d167 = private constant [0 x i8] c""
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2ftime_2eNow()
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fos_2eExit(i32 %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @std_2fchan_2eInit_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hd4bdf3befe2f7a35847f168802c5df68(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eRunFrom_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4dd2018b2860e81c323896fd3ca15193(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H8234c1c1c27ca4e3ae7fd7ce5493aa97(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
declare %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
declare %"compiler/cond:Consts" @compiler_2fcond_3aConsts_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
