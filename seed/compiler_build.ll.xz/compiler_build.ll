; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Sha256" = type { [8 x i32], [64 x i8], i64, i64 }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"std/chan:Chan.1f61752bf3a3e88b047d9d8b456b8f19" = type { i64, { i64, ptr }, i64, i64, i64, i1, i64, i64, i1, i64, %"<pthread.h>:pthread_mutex_t", %"<pthread.h>:pthread_cond_t", %"<pthread.h>:pthread_cond_t" }
%"<pthread.h>:pthread_mutex_t" = type { [5 x i64] }
%"<pthread.h>:pthread_cond_t" = type { [6 x i64] }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, { i64, ptr }, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Unit" = type { { i64, ptr }, i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:compiles" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:stubFrontend" = type { i64, i64 }
%"compiler/build:Listed" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/build:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
@G_2ecompiler_2fbuild_2eImportLimit = constant <{ [8 x i8] }> <{ [8 x i8] c"\46\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbuild_2ePhaseAt = global <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fbuild_2eRemarkPasses = constant <{ [8 x i8], ptr }> <{ [8 x i8] c"\BB\00\00\00\00\00\00\00", ptr @G_2ecompiler_2fbuild_2eRemarkPasses.k1 }>, align 8
@G_2ecompiler_2fbuild_2eRemarkPasses.k1 = internal constant <{ [187 x i8] }> <{ [187 x i8] c"\5E\28\69\6E\6C\69\6E\65\7C\6C\6F\6F\70\2D\76\65\63\74\6F\72\69\7A\65\7C\73\6C\70\2D\76\65\63\74\6F\72\69\7A\65\72\7C\6C\6F\6F\70\2D\75\6E\72\6F\6C\6C\7C\6C\6F\6F\70\2D\75\6E\72\6F\6C\6C\2D\61\6E\64\2D\6A\61\6D\7C\6C\69\63\6D\7C\67\76\6E\7C\6C\6F\6F\70\2D\69\64\69\6F\6D\7C\6C\6F\6F\70\2D\64\65\6C\65\74\65\7C\74\61\69\6C\63\61\6C\6C\65\6C\69\6D\7C\6C\6F\6F\70\2D\64\69\73\74\72\69\62\75\74\65\7C\6C\6F\6F\70\2D\69\6E\74\65\72\63\68\61\6E\67\65\7C\6C\6F\6F\70\2D\6C\6F\61\64\2D\65\6C\69\6D\7C\72\65\67\61\6C\6C\6F\63\7C\70\72\6F\6C\6F\67\65\70\69\6C\6F\67\29\24" }>, align 64
@G_2ecompiler_2fbuild_2eShaK = constant <{ [256 x i8] }> <{ [256 x i8] c"\98\2F\8A\42\91\44\37\71\CF\FB\C0\B5\A5\DB\B5\E9\5B\C2\56\39\F1\11\F1\59\A4\82\3F\92\D5\5E\1C\AB\98\AA\07\D8\01\5B\83\12\BE\85\31\24\C3\7D\0C\55\74\5D\BE\72\FE\B1\DE\80\A7\06\DC\9B\74\F1\9B\C1\C1\69\9B\E4\86\47\BE\EF\C6\9D\C1\0F\CC\A1\0C\24\6F\2C\E9\2D\AA\84\74\4A\DC\A9\B0\5C\DA\88\F9\76\52\51\3E\98\6D\C6\31\A8\C8\27\03\B0\C7\7F\59\BF\F3\0B\E0\C6\47\91\A7\D5\51\63\CA\06\67\29\29\14\85\0A\B7\27\38\21\1B\2E\FC\6D\2C\4D\13\0D\38\53\54\73\0A\65\BB\0A\6A\76\2E\C9\C2\81\85\2C\72\92\A1\E8\BF\A2\4B\66\1A\A8\70\8B\4B\C2\A3\51\6C\C7\19\E8\92\D1\24\06\99\D6\85\35\0E\F4\70\A0\6A\10\16\C1\A4\19\08\6C\37\1E\4C\77\48\27\B5\BC\B0\34\B3\0C\1C\39\4A\AA\D8\4E\4F\CA\9C\5B\F3\6F\2E\68\EE\82\8F\74\6F\63\A5\78\14\78\C8\84\08\02\C7\8C\FA\FF\BE\90\EB\6C\50\A4\F7\A3\F9\BE\F2\78\71\C6" }>, align 64
@G_2ecompiler_2fbuild_2eThinFrom = constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\80\00\00\00\00\00" }>, align 8
define dso_local i32 @compiler_2fbuild_2eFinish(ptr %v0, ptr %a0) #0 {
entry:
  %l2 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
  store i32 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i32, ptr %l2, !tbaa !23
  store i32 %t4, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca ptr
  %l3 = alloca i64
  %l5 = alloca %"compiler/build:Sha256"
  %l7 = alloca i64
  %l9 = alloca i64
  %l14 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l5
  store %"compiler/build:Sha256" %t2, ptr %l1
  store ptr %a0, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l7, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l9
  br label %bb3
bb3:
  %t9 = load i64, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb5:
  br label %bb6
bb6:
  %t15 = load ptr, ptr %l2, !tbaa !29
  %t16 = load i64, ptr %l3, !tbaa !24
  %t19 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store { i64, ptr } %t19, ptr %l14
  br label %bb7
bb7:
  %t20 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %t20)
  br label %bb8
bb8:
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %s2, ptr %l1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t26 = load i64, ptr %l3, !tbaa !24
  %t28 = add i64 %t26, 1
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb2
bb11:
  %t31 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t31, ptr %l22
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i8
  %l8 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l28 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l33 = alloca i1
  %l34 = alloca i1
  %l36 = alloca i1
  %l37 = alloca i1
  %l40 = alloca i8
  %l45 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v0, { i64, ptr } %a0)
  store { i64, ptr } %t3, ptr %l8
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t4, ptr %l1, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t7 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %s0, { i64, ptr } %t5, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t7, ptr %l10
  br label %bb2
bb2:
  %t8 = load i1, ptr %l10, !tbaa !21
  br i1 %t8, label %bb3, label %bb4
bb3:
  %t9 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t9, ptr %l11, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t14 = sub i64 %t12, 6
  store i64 %t14, ptr %l14, !tbaa !24
  %t15 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l15, !tbaa !24
  %t17 = icmp sge i64 0, 0
  br i1 %t17, label %bb5, label %bb6
bb4:
  br label %bb11
bb5:
  %t19 = load i64, ptr %l14, !tbaa !24
  %t20 = icmp sle i64 0, %t19
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb7:
  %t22 = load i64, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l15, !tbaa !24
  %t24 = icmp sle i64 %t22, %t23
  br i1 %t24, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb9:
  %t26 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l14, !tbaa !24
  %t29 = getelementptr i8, ptr %t27, i64 0
  %t30 = sub i64 %t28, 0
  %t31 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t32 = insertvalue { i64, ptr } %t31, ptr %t29, 1
  store { i64, ptr } %t32, ptr %l1, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_807a392292b9ae5a_fba630df00719f06)
  unreachable
bb11:
  %t34 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t34, ptr %l20
  br label %bb12
bb12:
  %t35 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t35, ptr %l2
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t36, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t38, 0
  store i64 %t40, ptr %l5, !tbaa !24
  br label %bb13
bb13:
  %t42 = load i64, ptr %l4, !tbaa !24
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = icmp slt i64 %t42, %t43
  %t48 = xor i1 %t46, true
  br i1 %t48, label %bb14, label %bb15
bb14:
  br label %bb30
bb15:
  br label %bb16
bb16:
  %t50 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t50, ptr %l28, !tbaa !27
  %t51 = load i64, ptr %l4, !tbaa !24
  %t53 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 %t51
  %t56 = load i8, ptr %t55, !tbaa !32
  store i8 %t56, ptr %l6, !tbaa !22
  store ptr %l2, ptr %l31, !tbaa !29
  %t58 = load i8, ptr %l6, !tbaa !22
  %t60 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t58)
  store i1 %t60, ptr %l33
  br label %bb17
bb17:
  %t61 = load i1, ptr %l33, !tbaa !21
  br i1 %t61, label %bb18, label %bb19
bb18:
  store i1 true, ptr %l34, !tbaa !21
  br label %bb21
bb19:
  %t62 = load i8, ptr %l6, !tbaa !22
  %t64 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t62)
  store i1 %t64, ptr %l36
  br label %bb20
bb20:
  %t65 = load i1, ptr %l36, !tbaa !21
  store i1 %t65, ptr %l34, !tbaa !21
  br label %bb21
bb21:
  %t66 = load i1, ptr %l34, !tbaa !21
  br i1 %t66, label %bb22, label %bb23
bb22:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb24
bb23:
  %t67 = load i8, ptr %l6, !tbaa !22
  %t69 = icmp eq i8 %t67, 95
  store i1 %t69, ptr %l37, !tbaa !21
  br label %bb24
bb24:
  %t71 = load i1, ptr %l37, !tbaa !21
  br i1 %t71, label %bb25, label %bb26
bb25:
  %t72 = load i8, ptr %l6, !tbaa !22
  store i8 %t72, ptr %l40, !tbaa !22
  br label %bb27
bb26:
  store i8 95, ptr %l40, !tbaa !22
  br label %bb27
bb27:
  %t74 = load ptr, ptr %l31, !tbaa !29
  %t75 = load i8, ptr %l40, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t74, i8 %t75)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t76 = load i64, ptr %l4, !tbaa !24
  %t78 = add i64 %t76, 1
  store i64 %t78, ptr %l4, !tbaa !24
  br label %bb13
bb30:
  %t81 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l2)
  store { i64, ptr } %t81, ptr %l45
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s0)
  %t82 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t82, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l7 = alloca i1
  %l10 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l25 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d2, i32 0, i32 1) })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l5
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  store { i64, ptr } %t2, ptr %l4
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  br label %bb6
bb2:
  %t7 = load i32, ptr %l5, !tbaa !23
  %t8 = ashr i32 %t7, 16
  %t10 = icmp eq i32 %t8, 1
  store i1 %t10, ptr %l7, !tbaa !21
  %t11 = load i32, ptr %l5, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  br i1 %t14, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb6:
  %t16 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t16, ptr %l1, !tbaa !27
  %t17 = call i64 @std_2ftime_2eNow()
  store i64 %t17, ptr %l10
  br label %bb7
bb7:
  %t18 = load i64, ptr %l10, !tbaa !24
  store i64 %t18, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t21 = icmp ne i64 %t19, 0
  br i1 %t21, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t23 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t24 = load i64, ptr %l2, !tbaa !24
  %t25 = load i64, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t28 = sub i64 %t24, %t25
  %t30 = sdiv i64 %t28, 1000000
  %t31 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 1
  %t32 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d3, i32 0, i32 1) }, 0
  %t34 = extractvalue { i64, ptr } %t23, 1
  %t35 = extractvalue { i64, ptr } %t23, 0
  %t36 = add i64 %t32, %t35
  %t37 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 1
  %t38 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d4, i32 0, i32 1) }, 0
  %t39 = add i64 %t36, %t38
  %t41 = call i64 @__olang_fmt_i64(ptr null, i64 %t30)
  %t42 = add i64 %t39, %t41
  %t43 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 1
  %t44 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d5, i32 0, i32 1) }, 0
  %t45 = add i64 %t42, %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t45)
  call void @olang_textcopy(ptr %t46, ptr %t31, i64 %t32)
  %t47 = getelementptr i8, ptr %t46, i64 %t32
  call void @olang_textcopy(ptr %t47, ptr %t34, i64 %t35)
  %t48 = getelementptr i8, ptr %t47, i64 %t35
  call void @olang_textcopy(ptr %t48, ptr %t37, i64 %t38)
  %t49 = getelementptr i8, ptr %t48, i64 %t38
  %t50 = call i64 @__olang_fmt_i64(ptr %t49, i64 %t30)
  %t51 = getelementptr i8, ptr %t49, i64 %t41
  call void @olang_textcopy(ptr %t51, ptr %t43, i64 %t44)
  %t52 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t46, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  %t56 = extractvalue { i64, ptr } %t53, 1
  %t57 = mul i64 %t55, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t57)
  call void @llvm.memcpy.p0.p0.i64(ptr %t58, ptr %t56, i64 %t57, i1 false)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  call void @compiler_2fbuild_2esayErr(ptr %s2, { i64, ptr } %t60)
  br label %bb10
bb9:
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  %t62 = load i64, ptr %l2, !tbaa !24
  store i64 %t62, ptr @G_2ecompiler_2fbuild_2ePhaseAt, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t66 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t64, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d6, i32 0, i32 1) })
  store i1 %t66, ptr %l22
  br label %bb12
bb12:
  %t67 = load i1, ptr %l22, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t68 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t70 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t68, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d7, i32 0, i32 1) })
  store i1 %t70, ptr %l25
  br label %bb15
bb14:
  store i1 false, ptr %l23, !tbaa !21
  br label %bb16
bb15:
  %t71 = load i1, ptr %l25, !tbaa !21
  store i1 %t71, ptr %l23, !tbaa !21
  br label %bb16
bb16:
  %t72 = load i1, ptr %l23, !tbaa !21
  br i1 %t72, label %bb17, label %bb18
bb17:
  call void @std_2fos_2eExit(i32 0)
  unreachable
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_1a0af222d89a1264_6ae848cde6020298)
  unreachable
bb20:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ePid() #0 {
entry:
  %l0 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call i32 @getpid()
  store i32 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i32, ptr %l0, !tbaa !23
  store i32 %t2, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i8
  %l6 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l19 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %l23 = alloca i1
  %l26 = alloca i1
  %l29 = alloca i8
  %l34 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l6
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l6
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l4, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb22
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l14, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l14, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i8, ptr %t21, i64 %t18
  %t23 = load i8, ptr %t22, !tbaa !32
  store i8 %t23, ptr %l5, !tbaa !22
  store ptr %l1, ptr %l17, !tbaa !29
  %t25 = load i8, ptr %l5, !tbaa !22
  %t27 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %t25)
  store i1 %t27, ptr %l19
  br label %bb6
bb6:
  %t28 = load i1, ptr %l19, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l20, !tbaa !21
  br label %bb10
bb8:
  %t29 = load i8, ptr %l5, !tbaa !22
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t29)
  store i1 %t31, ptr %l22
  br label %bb9
bb9:
  %t32 = load i1, ptr %l22, !tbaa !21
  store i1 %t32, ptr %l20, !tbaa !21
  br label %bb10
bb10:
  %t33 = load i1, ptr %l20, !tbaa !21
  br i1 %t33, label %bb11, label %bb12
bb11:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb13
bb12:
  %t34 = load i8, ptr %l5, !tbaa !22
  %t36 = icmp eq i8 %t34, 95
  store i1 %t36, ptr %l23, !tbaa !21
  br label %bb13
bb13:
  %t38 = load i1, ptr %l23, !tbaa !21
  br i1 %t38, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l26, !tbaa !21
  br label %bb16
bb15:
  %t39 = load i8, ptr %l5, !tbaa !22
  %t41 = icmp eq i8 %t39, 45
  store i1 %t41, ptr %l26, !tbaa !21
  br label %bb16
bb16:
  %t43 = load i1, ptr %l26, !tbaa !21
  br i1 %t43, label %bb17, label %bb18
bb17:
  %t44 = load i8, ptr %l5, !tbaa !22
  store i8 %t44, ptr %l29, !tbaa !22
  br label %bb19
bb18:
  store i8 95, ptr %l29, !tbaa !22
  br label %bb19
bb19:
  %t46 = load ptr, ptr %l17, !tbaa !29
  %t47 = load i8, ptr %l29, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t46, i8 %t47)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t48 = load i64, ptr %l3, !tbaa !24
  %t50 = add i64 %t48, 1
  store i64 %t50, ptr %l3, !tbaa !24
  br label %bb2
bb22:
  %t53 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t53, ptr %l34
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s0)
  %t54 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t54, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t2, 0
  %t6 = sub i64 %t4, 2
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t7, 0
  store i64 %t8, ptr %l5, !tbaa !24
  %t9 = icmp sge i64 0, 0
  br i1 %t9, label %bb1, label %bb2
bb1:
  %t11 = load i64, ptr %l4, !tbaa !24
  %t12 = icmp sle i64 0, %t11
  br i1 %t12, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_cca858d13f2cc89a_874b1ca570aaca06)
  unreachable
bb3:
  %t14 = load i64, ptr %l4, !tbaa !24
  %t15 = load i64, ptr %l5, !tbaa !24
  %t16 = icmp sle i64 %t14, %t15
  br i1 %t16, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_cca858d13f2cc89a_874b1ca570aaca06)
  unreachable
bb5:
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  %t21 = getelementptr i8, ptr %t19, i64 0
  %t22 = sub i64 %t20, 0
  %t23 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t21, 1
  %t26 = extractvalue { i64, ptr } %t24, 1
  %t27 = extractvalue { i64, ptr } %t24, 0
  %t28 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d8, i32 0, i32 1) }, 1
  %t29 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d8, i32 0, i32 1) }, 0
  %t30 = add i64 %t27, %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = getelementptr i8, ptr %t31, i64 %t27
  call void @olang_textcopy(ptr %t32, ptr %t28, i64 %t29)
  %t33 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t34 = insertvalue { i64, ptr } %t33, ptr %t31, 1
  store { i64, ptr } %t34, ptr %rv
  br label %ret
bb6:
  call void @__olang_check_failed(ptr @olang_loc_cca858d13f2cc89a_874b1ca570aaca06)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l31 = alloca i64
  %l41 = alloca { { i64, ptr }, { i64, ptr } }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l56 = alloca i64
  %l59 = alloca i64
  %l88 = alloca %"std/chan:Chan.1f61752bf3a3e88b047d9d8b456b8f19"
  %l98 = alloca { i64, ptr }
  %l103 = alloca i32
  %l105 = alloca i1
  %l111 = alloca i64
  %l118 = alloca i64
  %l121 = alloca i64
  %l150 = alloca { { i64, ptr }, { i64, ptr } }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l153 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i64
  %l156 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %jh10 = alloca ptr
  %rv = alloca { { i64, ptr }, { i64, ptr } }
  %t28 = alloca i64
  %t168 = alloca { { i64, ptr }, ptr }, align 8
  %t179 = alloca %"std/chan:Chan.1f61752bf3a3e88b047d9d8b456b8f19", align 8
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load i64, ptr %l3, !tbaa !24
  store i64 %t5, ptr %l27, !tbaa !24
  %t6 = load i64, ptr %l27, !tbaa !24
  %t7 = icmp sge i64 %t6, 0
  br i1 %t7, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l27, !tbaa !24
  %t10 = icmp sle i64 %t9, 2305843009213693951
  br i1 %t10, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb3:
  %t12 = load i64, ptr %l27, !tbaa !24
  %t13 = mul i64 %t12, 4
  %t14 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t13)
  %t15 = insertvalue { i64, ptr } undef, i64 %t12, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  store { i64, ptr } %t16, ptr %l4, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l31, !tbaa !24
  %t19 = load i64, ptr %l31, !tbaa !24
  %t20 = icmp sge i64 %t19, 0
  br i1 %t20, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_2b4b55182e30c5b8_1dd1254afca8c384)
  unreachable
bb5:
  %t22 = load i64, ptr %l31, !tbaa !24
  %t23 = icmp sle i64 %t22, 576460752303423487
  br i1 %t23, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb7:
  %t25 = load i64, ptr %l31, !tbaa !24
  %t26 = mul i64 %t25, 16
  %t27 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t26)
  store i64 0, ptr %t28
  br label %fill.29
fill.29:
  %t32 = load i64, ptr %t28
  %t33 = icmp slt i64 %t32, %t25
  br i1 %t33, label %fillb.30, label %filld.31
fillb.30:
  %t34 = getelementptr { i64, ptr }, ptr %t27, i64 %t32
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d9, i32 0, i32 1) }, ptr %t34
  %t35 = add i64 %t32, 1
  store i64 %t35, ptr %t28
  br label %fill.29
filld.31:
  %t36 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t27, 1
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  %t39 = load i64, ptr %l3, !tbaa !24
  %t41 = icmp eq i64 %t39, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491)
  unreachable
bb9:
  %t43 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t48 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t43, 0
  %t50 = insertvalue { { i64, ptr }, { i64, ptr } } %t48, { i64, ptr } %t45, 1
  store { { i64, ptr }, { i64, ptr } } %t50, ptr %l41
  %t51 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  %t52 = load { i64, ptr }, ptr %t51, !tbaa !27
  store { i64, ptr } %t52, ptr %l42, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 0
  store i64 %t54, ptr %l43, !tbaa !24
  %t55 = load i64, ptr %l43, !tbaa !24
  %t56 = mul i64 %t55, 4
  %t57 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t56)
  %t58 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t59 = insertvalue { i64, ptr } %t58, ptr %t57, 1
  store { i64, ptr } %t59, ptr %l44, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t61 = load ptr, ptr %t60, !tbaa !27
  %t62 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t63 = load ptr, ptr %t62, !tbaa !27
  %t64 = load i64, ptr %l43, !tbaa !24
  %t65 = mul i64 %t64, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t61, ptr %t63, i64 %t65, i1 false)
  %t66 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t67 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 0
  store { i64, ptr } %t66, ptr %t67, !tbaa !27
  %t68 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  store { i64, ptr } %t69, ptr %l45, !tbaa !27
  %t70 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l46, !tbaa !24
  %t72 = load i64, ptr %l46, !tbaa !24
  %t73 = mul i64 %t72, 16
  %t74 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t73)
  %t75 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l47, !tbaa !27
  %t77 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t78 = load ptr, ptr %t77, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l45, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = load i64, ptr %l46, !tbaa !24
  %t82 = mul i64 %t81, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t78, ptr %t80, i64 %t82, i1 false)
  %t83 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t84 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l41, i32 0, i32 1
  store { i64, ptr } %t83, ptr %t84, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t85 = load { { i64, ptr }, { i64, ptr } }, ptr %l41
  store { { i64, ptr }, { i64, ptr } } %t85, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t86 = load i64, ptr %l3, !tbaa !24
  store i64 %t86, ptr %l48, !tbaa !24
  %t87 = load i64, ptr %l48, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb12, label %bb13
bb12:
  %t90 = load i64, ptr %l48, !tbaa !24
  %t91 = icmp sle i64 %t90, 1152921504606846975
  br i1 %t91, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb14:
  %t93 = load i64, ptr %l48, !tbaa !24
  %t94 = mul i64 %t93, 8
  %t95 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t94)
  %t96 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  store { i64, ptr } %t97, ptr %l6, !tbaa !27
  store i64 0, ptr %l7, !tbaa !24
  %t99 = load i64, ptr %l3, !tbaa !24
  store i64 %t99, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t101 = load i64, ptr %l8, !tbaa !24
  %t102 = load i64, ptr %l7, !tbaa !24
  %t105 = icmp sgt i64 %t101, %t102
  br i1 %t105, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_bc625dc042a99e06_c0b5fdead4ea6272)
  unreachable
bb16:
  %t107 = load i64, ptr %l9, !tbaa !24
  %t109 = icmp sgt i64 %t107, 0
  br i1 %t109, label %bb18, label %bb19
bb17:
  store i64 0, ptr %l56, !tbaa !24
  br label %bb21
bb18:
  %t111 = load i64, ptr %l8, !tbaa !24
  %t112 = load i64, ptr %l7, !tbaa !24
  %t115 = sub i64 %t111, %t112
  %t116 = load i64, ptr %l9, !tbaa !24
  %t119 = add i64 %t115, %t116
  %t121 = sub i64 %t119, 1
  %t122 = load i64, ptr %l9, !tbaa !24
  %t125 = sdiv i64 %t121, %t122
  store i64 %t125, ptr %l59, !tbaa !24
  br label %bb20
bb19:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t127 = load i64, ptr %l59, !tbaa !24
  store i64 %t127, ptr %l56, !tbaa !24
  br label %bb21
bb21:
  %t128 = load i64, ptr %l56, !tbaa !24
  store i64 %t128, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb22
bb22:
  %t129 = load i64, ptr %l11, !tbaa !24
  %t130 = load i64, ptr %l10, !tbaa !24
  %t133 = icmp slt i64 %t129, %t130
  %t135 = xor i1 %t133, true
  br i1 %t135, label %bb23, label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb25
bb25:
  %t137 = load i64, ptr %l7, !tbaa !24
  %t138 = load i64, ptr %l11, !tbaa !24
  %t139 = load i64, ptr %l9, !tbaa !24
  %t142 = mul i64 %t138, %t139
  %t145 = add i64 %t137, %t142
  store i64 %t145, ptr %l12, !tbaa !24
  %t147 = load i64, ptr %l12, !tbaa !24
  %t148 = load i64, ptr %l12, !tbaa !24
  %t151 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t152 = load ptr, ptr %t151, !tbaa !27
  %t153 = getelementptr i64, ptr %t152, i64 %t147
  store i64 %t148, ptr %t153, !tbaa !34
  br label %bb26
bb26:
  %t154 = load i64, ptr %l11, !tbaa !24
  %t156 = add i64 %t154, 1
  store i64 %t156, ptr %l11, !tbaa !24
  br label %bb22
bb27:
  %t158 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t158, 0
  %t162 = icmp sgt i64 %t160, 0
  br i1 %t162, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s5
  %t164 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t166 = getelementptr { { i64, ptr }, ptr }, ptr null, i32 1
  %t167 = ptrtoint ptr %t166 to i64
  %t169 = getelementptr { { i64, ptr }, ptr }, ptr %t168, i32 0, i32 0
  store { i64, ptr } %t165, ptr %t169, !tbaa !28
  call void @__olang_scope_escape(ptr %v1)
  %t171 = getelementptr { { i64, ptr }, ptr }, ptr %t168, i32 0, i32 1
  store ptr %v1, ptr %t171, !tbaa !28
  %t172 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_10, 0
  %t173 = insertvalue { ptr, ptr } %t172, ptr %t168, 1
  %t176 = extractvalue { ptr, ptr } %t173, 0
  %t177 = extractvalue { ptr, ptr } %t173, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %s0, ptr %s5, { i64, ptr } %t164, ptr %t176, ptr %t177)
  br label %bb30
bb29:
  br label %bb31
bb30:
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  %t178 = load i64, ptr %l3, !tbaa !24
  call void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %t179, ptr %s0, i64 %t178)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t179, i64 224, i1 false)
  br label %bb32
bb32:
  %t181 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 224, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t181, ptr %l88, i64 224, i1 false)
  store ptr %t181, ptr %l13, !tbaa !29
  %t183 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eInit_3cI64_3e(ptr %s0, ptr %t183)
  br label %bb33
bb33:
  %t185 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t185, ptr %l14, !tbaa !27
  store i64 0, ptr %l15, !tbaa !24
  %t187 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t187, 0
  store i64 %t189, ptr %l16, !tbaa !24
  br label %bb34
bb34:
  %t191 = load i64, ptr %l15, !tbaa !24
  %t192 = load i64, ptr %l16, !tbaa !24
  %t195 = icmp slt i64 %t191, %t192
  %t197 = xor i1 %t195, true
  br i1 %t197, label %bb35, label %bb36
bb35:
  br label %bb43
bb36:
  br label %bb37
bb37:
  %t199 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t199, ptr %l98, !tbaa !27
  %t200 = load i64, ptr %l15, !tbaa !24
  %t202 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t203 = load ptr, ptr %t202, !tbaa !27
  %t204 = getelementptr i64, ptr %t203, i64 %t200
  %t205 = load i64, ptr %t204, !tbaa !34
  %t207 = load ptr, ptr %l13, !tbaa !29
  %t211 = call i32 @std_2fchan_2eSend_3cI64_3e(ptr %s0, ptr %t207, i64 %t205)
  store i32 %t211, ptr %l103
  %t212 = icmp ne i32 %t211, 0
  br i1 %t212, label %bb39, label %ok.213, !prof !99
ok.213:
  br label %bb38
bb38:
  br label %bb41
bb39:
  %t214 = load i32, ptr %l103, !tbaa !23
  %t215 = ashr i32 %t214, 16
  %t217 = icmp eq i32 %t215, 1
  store i1 %t217, ptr %l105, !tbaa !21
  br label %bb40
bb40:
  call void @__olang_check_failed(ptr @olang_loc_1359a9f97975288c_a8d4abcb606172b0)
  unreachable
bb41:
  br label %bb42
bb42:
  %t218 = load i64, ptr %l15, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l15, !tbaa !24
  br label %bb34
bb43:
  %t222 = load i64, ptr %l1, !tbaa !24
  %t223 = load i64, ptr %l3, !tbaa !24
  %t226 = icmp slt i64 %t222, %t223
  br i1 %t226, label %bb44, label %bb45
bb44:
  %t228 = load i64, ptr %l1, !tbaa !24
  store i64 %t228, ptr %l111, !tbaa !24
  br label %bb46
bb45:
  %t230 = load i64, ptr %l3, !tbaa !24
  store i64 %t230, ptr %l111, !tbaa !24
  br label %bb46
bb46:
  %t232 = load i64, ptr %l111, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s10
  store ptr null, ptr %jh10
  store i64 0, ptr %l19, !tbaa !24
  store i64 %t232, ptr %l20, !tbaa !24
  store i64 1, ptr %l21, !tbaa !24
  %t235 = load i64, ptr %l20, !tbaa !24
  %t236 = load i64, ptr %l19, !tbaa !24
  %t239 = icmp sgt i64 %t235, %t236
  br i1 %t239, label %bb47, label %bb48
bb47:
  %t241 = load i64, ptr %l21, !tbaa !24
  %t243 = icmp sgt i64 %t241, 0
  br i1 %t243, label %bb49, label %bb50
bb48:
  store i64 0, ptr %l118, !tbaa !24
  br label %bb52
bb49:
  %t245 = load i64, ptr %l20, !tbaa !24
  %t246 = load i64, ptr %l19, !tbaa !24
  %t249 = sub i64 %t245, %t246
  %t250 = load i64, ptr %l21, !tbaa !24
  %t253 = add i64 %t249, %t250
  %t255 = sub i64 %t253, 1
  %t256 = load i64, ptr %l21, !tbaa !24
  %t259 = sdiv i64 %t255, %t256
  store i64 %t259, ptr %l121, !tbaa !24
  br label %bb51
bb50:
  store i64 0, ptr %l121, !tbaa !24
  br label %bb51
bb51:
  %t261 = load i64, ptr %l121, !tbaa !24
  store i64 %t261, ptr %l118, !tbaa !24
  br label %bb52
bb52:
  %t262 = load i64, ptr %l118, !tbaa !24
  store i64 %t262, ptr %l22, !tbaa !24
  store i64 0, ptr %l23, !tbaa !24
  br label %bb53
bb53:
  %t263 = load i64, ptr %l23, !tbaa !24
  %t264 = load i64, ptr %l22, !tbaa !24
  %t267 = icmp slt i64 %t263, %t264
  %t269 = xor i1 %t267, true
  br i1 %t269, label %bb54, label %bb55
bb54:
  br label %bb58
bb55:
  br label %bb56
bb56:
  %t271 = load i64, ptr %l19, !tbaa !24
  %t272 = load i64, ptr %l23, !tbaa !24
  %t273 = load i64, ptr %l21, !tbaa !24
  %t276 = mul i64 %t272, %t273
  %t279 = add i64 %t271, %t276
  store i64 %t279, ptr %l24, !tbaa !24
  %t281 = load ptr, ptr %l13, !tbaa !29
  %t282 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t289 = call ptr @__olang_standin(ptr %s0)
  %t290 = call ptr @__olang_standin(ptr %v0)
  %t291 = call ptr @__olang_standin(ptr %s0)
  %t292 = call ptr @__olang_standin(ptr %v2)
  %t293 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr null, i32 1
  %t294 = ptrtoint ptr %t293 to i64
  %t295 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 %t294, i64 8)
  %t296 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 0
  store ptr %t281, ptr %t296
  %t297 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 1
  store { i64, ptr } %t282, ptr %t297
  %t298 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 2
  store { i64, ptr } %t283, ptr %t298
  %t299 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 3
  store { i64, ptr } %t284, ptr %t299
  %t300 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 4
  store ptr %t289, ptr %t300
  %t301 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 5
  store ptr %t290, ptr %t301
  %t302 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 6
  store ptr %t291, ptr %t302
  %t303 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %t295, i32 0, i32 7
  store ptr %t292, ptr %t303
  %t304 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 40, i64 8)
  %t305 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr null, ptr %t305
  %t306 = getelementptr { ptr, ptr }, ptr %t305, i32 0, i32 1
  store ptr %t289, ptr %t306
  %t307 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t305, ptr %t307
  %t308 = getelementptr { ptr, ptr }, ptr %t307, i32 0, i32 1
  store ptr %t290, ptr %t308
  %t309 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t307, ptr %t309
  %t310 = getelementptr { ptr, ptr }, ptr %t309, i32 0, i32 1
  store ptr %t291, ptr %t310
  %t311 = call ptr @__olang_scope_alloc_a(ptr %s10, i64 16, i64 8)
  store ptr %t309, ptr %t311
  %t312 = getelementptr { ptr, ptr }, ptr %t311, i32 0, i32 1
  store ptr %t292, ptr %t312
  %t313 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t304, i32 0, i32 2
  store ptr %t311, ptr %t313
  %t314 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t304, i32 0, i32 1
  store i64 0, ptr %t314
  %t315 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t304, i32 0, i32 3
  store i64 0, ptr %t315
  %t316 = getelementptr { ptr, i64, ptr, i64, ptr }, ptr %t304, i32 0, i32 4
  store ptr null, ptr %t316
  %t317 = call ptr @__olang_worker_get()
  call void @__olang_worker_start(ptr %t317, ptr @olang_task11, ptr %t295, ptr %t304)
  %t318 = load ptr, ptr %jh10
  store ptr %t318, ptr %t304
  store ptr %t304, ptr %jh10
  br label %bb57
bb57:
  %t319 = load i64, ptr %l23, !tbaa !24
  %t321 = add i64 %t319, 1
  store i64 %t321, ptr %l23, !tbaa !24
  br label %bb53
bb58:
  %t323 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fchan_2eClose_3cI64_3e(ptr %s0, ptr %t323)
  br label %bb59
bb59:
  %t325 = call i64 @__olang_join_tasks(ptr %jh10)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s10)
  br label %bb61
bb61:
  %t326 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t331 = insertvalue { { i64, ptr }, { i64, ptr } } undef, { i64, ptr } %t326, 0
  %t333 = insertvalue { { i64, ptr }, { i64, ptr } } %t331, { i64, ptr } %t328, 1
  store { { i64, ptr }, { i64, ptr } } %t333, ptr %l150
  %t334 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 0
  %t335 = load { i64, ptr }, ptr %t334, !tbaa !27
  store { i64, ptr } %t335, ptr %l151, !tbaa !27
  %t336 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  store i64 %t337, ptr %l152, !tbaa !24
  %t338 = load i64, ptr %l152, !tbaa !24
  %t339 = mul i64 %t338, 4
  %t340 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t339)
  %t341 = insertvalue { i64, ptr } undef, i64 %t338, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  store { i64, ptr } %t342, ptr %l153, !tbaa !27
  %t343 = getelementptr { i64, ptr }, ptr %l153, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr { i64, ptr }, ptr %l151, i32 0, i32 1
  %t346 = load ptr, ptr %t345, !tbaa !27
  %t347 = load i64, ptr %l152, !tbaa !24
  %t348 = mul i64 %t347, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t344, ptr %t346, i64 %t348, i1 false)
  %t349 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t350 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 0
  store { i64, ptr } %t349, ptr %t350, !tbaa !27
  %t351 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 1
  %t352 = load { i64, ptr }, ptr %t351, !tbaa !27
  store { i64, ptr } %t352, ptr %l154, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 0
  store i64 %t354, ptr %l155, !tbaa !24
  %t355 = load i64, ptr %l155, !tbaa !24
  %t356 = mul i64 %t355, 16
  %t357 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t356)
  %t358 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t359 = insertvalue { i64, ptr } %t358, ptr %t357, 1
  store { i64, ptr } %t359, ptr %l156, !tbaa !27
  %t360 = getelementptr { i64, ptr }, ptr %l156, i32 0, i32 1
  %t361 = load ptr, ptr %t360, !tbaa !27
  %t362 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = load i64, ptr %l155, !tbaa !24
  %t365 = mul i64 %t364, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t361, ptr %t363, i64 %t365, i1 false)
  %t366 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t367 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l150, i32 0, i32 1
  store { i64, ptr } %t366, ptr %t367, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t368 = load { { i64, ptr }, { i64, ptr } }, ptr %l150
  store { { i64, ptr }, { i64, ptr } } %t368, ptr %rv
  br label %ret
ret:
  %rr = load { { i64, ptr }, { i64, ptr } }, ptr %rv
  ret { { i64, ptr }, { i64, ptr } } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t1, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d12, i32 0, i32 1) })
  store i1 %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = extractvalue { i64, ptr } %t5, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  br label %bb4
bb3:
  %t13 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t15 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t17 = extractvalue { i64, ptr } %t13, 1
  %t18 = extractvalue { i64, ptr } %t13, 0
  %t19 = add i64 %t15, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t14, i64 %t15)
  %t21 = getelementptr i8, ptr %t20, i64 %t15
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  store { i64, ptr } %t23, ptr %l3, !tbaa !27
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t25, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l48 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !23
  %t3 = icmp eq i32 %t1, 1
  br i1 %t3, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d14, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t5, ptr %l1, !tbaa !27
  br label %bb57
bb4:
  %t7 = load i32, ptr %l0, !tbaa !23
  %t9 = icmp eq i32 %t7, 2
  br i1 %t9, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d15, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t11 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t11, ptr %l1, !tbaa !27
  br label %bb57
bb8:
  %t13 = load i32, ptr %l0, !tbaa !23
  %t15 = icmp eq i32 %t13, 3
  br i1 %t15, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t17, ptr %l1, !tbaa !27
  br label %bb57
bb12:
  %t19 = load i32, ptr %l0, !tbaa !23
  %t21 = icmp eq i32 %t19, 4
  br i1 %t21, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l1, !tbaa !27
  br label %bb57
bb16:
  %t25 = load i32, ptr %l0, !tbaa !23
  %t27 = icmp eq i32 %t25, 5
  br i1 %t27, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d18, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t29, ptr %l1, !tbaa !27
  br label %bb57
bb20:
  %t31 = load i32, ptr %l0, !tbaa !23
  %t33 = icmp eq i32 %t31, 6
  br i1 %t33, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb24
bb23:
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t35, ptr %l1, !tbaa !27
  br label %bb57
bb24:
  %t37 = load i32, ptr %l0, !tbaa !23
  %t39 = icmp eq i32 %t37, 7
  br i1 %t39, label %bb25, label %bb26
bb25:
  br label %bb27
bb26:
  br label %bb28
bb27:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t41 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t41, ptr %l1, !tbaa !27
  br label %bb57
bb28:
  %t43 = load i32, ptr %l0, !tbaa !23
  %t45 = icmp eq i32 %t43, 8
  br i1 %t45, label %bb29, label %bb30
bb29:
  br label %bb31
bb30:
  br label %bb32
bb31:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l32, !tbaa !27
  %t47 = load { i64, ptr }, ptr %l32, !tbaa !27
  store { i64, ptr } %t47, ptr %l1, !tbaa !27
  br label %bb57
bb32:
  %t49 = load i32, ptr %l0, !tbaa !23
  %t51 = icmp eq i32 %t49, 9
  br i1 %t51, label %bb33, label %bb34
bb33:
  br label %bb35
bb34:
  br label %bb36
bb35:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  br label %bb57
bb36:
  %t55 = load i32, ptr %l0, !tbaa !23
  %t57 = icmp eq i32 %t55, 11
  br i1 %t57, label %bb37, label %bb38
bb37:
  br label %bb39
bb38:
  br label %bb40
bb39:
  store { i64, ptr } { i64 18, ptr getelementptr inbounds (<{ i64, [18 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l40, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t59, ptr %l1, !tbaa !27
  br label %bb57
bb40:
  %t61 = load i32, ptr %l0, !tbaa !23
  %t63 = icmp eq i32 %t61, 13
  br i1 %t63, label %bb41, label %bb42
bb41:
  br label %bb43
bb42:
  br label %bb44
bb43:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l44, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l44, !tbaa !27
  store { i64, ptr } %t65, ptr %l1, !tbaa !27
  br label %bb57
bb44:
  %t67 = load i32, ptr %l0, !tbaa !23
  %t69 = icmp eq i32 %t67, 14
  br i1 %t69, label %bb45, label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb48
bb47:
  store { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d25, i32 0, i32 1) }, ptr %l48, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t71, ptr %l1, !tbaa !27
  br label %bb57
bb48:
  %t73 = load i32, ptr %l0, !tbaa !23
  %t75 = icmp eq i32 %t73, 15
  br i1 %t75, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  br label %bb52
bb51:
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l52, !tbaa !27
  %t77 = load { i64, ptr }, ptr %l52, !tbaa !27
  store { i64, ptr } %t77, ptr %l1, !tbaa !27
  br label %bb57
bb52:
  br i1 true, label %bb53, label %bb54
bb53:
  br label %bb55
bb54:
  br label %bb56
bb55:
  %t79 = load i32, ptr %l0, !tbaa !23
  %t80 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t83 = sext i32 %t79 to i64
  %t84 = call i64 @__olang_fmt_i64(ptr null, i64 %t83)
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = getelementptr i8, ptr %t86, i64 %t81
  %t88 = call i64 @__olang_fmt_i64(ptr %t87, i64 %t83)
  %t89 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t86, 1
  store { i64, ptr } %t90, ptr %l1, !tbaa !27
  br label %bb57
bb56:
  call void @__olang_check_failed(ptr @olang_loc_84eba90bdad5d702_427cd4b75eaf1c36)
  unreachable
bb57:
  %t92 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 0
  store i64 %t93, ptr %l56, !tbaa !24
  %t94 = load i64, ptr %l56, !tbaa !24
  %t95 = mul i64 %t94, 1
  %t96 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t95)
  %t97 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t98 = insertvalue { i64, ptr } %t97, ptr %t96, 1
  store { i64, ptr } %t98, ptr %l57, !tbaa !27
  %t99 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = load i64, ptr %l56, !tbaa !24
  %t104 = mul i64 %t103, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t100, ptr %t102, i64 %t104, i1 false)
  %t105 = load { i64, ptr }, ptr %l57, !tbaa !27
  store { i64, ptr } %t105, ptr %l1, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t106, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l20 = alloca %"std/os:Output"
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l33 = alloca { i64, ptr }
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l49 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l78 = alloca %"std/os:Output"
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca %"std/os:Output"
  %l83 = alloca i32
  %l85 = alloca i1
  %l92 = alloca { i64, ptr }
  %l96 = alloca ptr
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l109 = alloca i1
  %l116 = alloca i1
  %l120 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l128 = alloca { i64, ptr }
  %l137 = alloca ptr
  %l139 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l146 = alloca i32
  %s2 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store i1 false, ptr %l5, !tbaa !21
  store i1 false, ptr %l6, !tbaa !21
  store { i64, ptr } %a3, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l9, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t7 = load i64, ptr %l8, !tbaa !24
  %t8 = load i64, ptr %l9, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s2)
  br label %bb48
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t15, ptr %l33, !tbaa !27
  %t16 = load i64, ptr %l8, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t16
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t23 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s2, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t23, ptr %l36
  br label %bb5
bb5:
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l11
  %t27 = extractvalue { i64, ptr } %a1, 1
  %t28 = extractvalue { i64, ptr } %a1, 0
  %t29 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t27, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  %t33 = extractvalue { i64, ptr } %t31, 0
  %t34 = extractvalue { i64, ptr } %t31, 1
  %t35 = mul i64 %t33, 1
  %t36 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t35)
  call void @llvm.memcpy.p0.p0.i64(ptr %t36, ptr %t34, i64 %t35, i1 false)
  %t37 = insertvalue { i64, ptr } undef, i64 %t33, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t36, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t38)
  br label %bb6
bb6:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d28, i32 0, i32 1) })
  br label %bb7
bb7:
  store { i64, ptr } %a2, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l14, !tbaa !24
  br label %bb8
bb8:
  %t48 = load i64, ptr %l13, !tbaa !24
  %t49 = load i64, ptr %l14, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb9, label %bb10
bb9:
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t56, ptr %l49, !tbaa !27
  %t57 = load i64, ptr %l13, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %t60, i64 %t57
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !37
  %t66 = extractvalue { i64, ptr } %t62, 1
  %t67 = extractvalue { i64, ptr } %t62, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t77)
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t80 = load i64, ptr %l13, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l13, !tbaa !24
  br label %bb8
bb14:
  %t84 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t87)
  call void @olang_textcopy(ptr %t88, ptr %t86, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  %t92 = extractvalue { i64, ptr } %t90, 0
  %t93 = extractvalue { i64, ptr } %t90, 1
  %t94 = mul i64 %t92, 1
  %t95 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t94)
  call void @llvm.memcpy.p0.p0.i64(ptr %t95, ptr %t93, i64 %t94, i1 false)
  %t96 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t97 = insertvalue { i64, ptr } %t96, ptr %t95, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t97)
  br label %bb15
bb15:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t100, ptr %l16, !tbaa !27
  store i64 0, ptr %l17, !tbaa !24
  %t102 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t104 = extractvalue { i64, ptr } %t102, 0
  store i64 %t104, ptr %l18, !tbaa !24
  br label %bb16
bb16:
  %t106 = load i64, ptr %l17, !tbaa !24
  %t107 = load i64, ptr %l18, !tbaa !24
  %t110 = icmp slt i64 %t106, %t107
  %t112 = xor i1 %t110, true
  br i1 %t112, label %bb17, label %bb18
bb17:
  br label %bb22
bb18:
  br label %bb19
bb19:
  %t114 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t114, ptr %l69, !tbaa !27
  %t115 = load i64, ptr %l17, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr { i64, ptr }, ptr %t118, i64 %t115
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !37
  %t124 = extractvalue { i64, ptr } %t120, 1
  %t125 = extractvalue { i64, ptr } %t120, 0
  %t126 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t125)
  call void @olang_textcopy(ptr %t126, ptr %t124, i64 %t125)
  %t127 = insertvalue { i64, ptr } undef, i64 %t125, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t126, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  %t131 = extractvalue { i64, ptr } %t128, 1
  %t132 = mul i64 %t130, 1
  %t133 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t132)
  call void @llvm.memcpy.p0.p0.i64(ptr %t133, ptr %t131, i64 %t132, i1 false)
  %t134 = insertvalue { i64, ptr } undef, i64 %t130, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s2, ptr %s2, ptr %l11, { i64, ptr } %t135)
  br label %bb20
bb20:
  br label %bb21
bb21:
  %t138 = load i64, ptr %l17, !tbaa !24
  %t140 = add i64 %t138, 1
  store i64 %t140, ptr %l17, !tbaa !24
  br label %bb16
bb22:
  %t143 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s2, ptr %s2, ptr %l11)
  store { i64, ptr } %t143, ptr %l80
  br label %bb23
bb23:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l81, !tbaa !27
  %t144 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t146 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s2, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t144, { i64, ptr } %t145, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t147 = extractvalue { i32, %"std/os:Output" } %t146, 1
  %t148 = extractvalue { i32, %"std/os:Output" } %t146, 0
  store i32 %t148, ptr %l83
  %t149 = icmp ne i32 %t148, 0
  br i1 %t149, label %bb25, label %ok.150, !prof !99
ok.150:
  store %"std/os:Output" %t147, ptr %l82
  br label %bb24
bb24:
  %t151 = load %"std/os:Output", ptr %l82
  store %"std/os:Output" %t151, ptr %l78
  br label %bb31
bb25:
  %t152 = load i32, ptr %l83, !tbaa !23
  %t153 = ashr i32 %t152, 16
  %t155 = icmp eq i32 %t153, 1
  store i1 %t155, ptr %l85, !tbaa !21
  %t156 = load i32, ptr %l83, !tbaa !23
  %t157 = ashr i32 %t156, 16
  %t159 = icmp eq i32 %t157, 1
  br i1 %t159, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s13
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = extractvalue { i64, ptr } %t162, 0
  %t166 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d31, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d31, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t169 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t168)
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = getelementptr i8, ptr %t169, i64 %t165
  call void @olang_textcopy(ptr %t170, ptr %t166, i64 %t167)
  %t171 = insertvalue { i64, ptr } undef, i64 %t168, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t169, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = extractvalue { i64, ptr } %t172, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  %t182 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s13, ptr %s13, ptr %s13, ptr %t161, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d32, i32 0, i32 1) }, { i64, ptr } %t179)
  store { i64, ptr } %t182, ptr %l92
  br label %bb29
bb29:
  %t183 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  %t185 = extractvalue { i64, ptr } %t183, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  call void @compiler_2fbuild_2esayln(ptr %s13, { i64, ptr } %t189)
  br label %bb30
bb30:
  store i1 true, ptr %l5, !tbaa !21
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb31:
  %t191 = load %"std/os:Output", ptr %l78
  store %"std/os:Output" %t191, ptr %l20
  %t192 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t193 = load i32, ptr %t192, !tbaa !23
  %t195 = icmp sgt i32 %t193, 128
  br i1 %t195, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s15
  %t197 = load ptr, ptr %l0, !tbaa !29
  store ptr %t197, ptr %l96, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t198, ptr %l97, !tbaa !27
  %t199 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t200 = load i32, ptr %t199, !tbaa !23
  %t202 = sub i32 %t200, 128
  %t204 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s15, i32 %t202)
  store { i64, ptr } %t204, ptr %l100
  br label %bb34
bb33:
  br label %bb37
bb34:
  %t205 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t206 = extractvalue { i64, ptr } %t205, 1
  %t207 = extractvalue { i64, ptr } %t205, 0
  %t208 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t209 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t210 = add i64 %t207, %t209
  %t211 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t211, 1
  %t213 = extractvalue { i64, ptr } %t211, 0
  %t214 = add i64 %t210, %t213
  %t215 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t216 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t217 = add i64 %t214, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t206, i64 %t207)
  %t219 = getelementptr i8, ptr %t218, i64 %t207
  call void @olang_textcopy(ptr %t219, ptr %t208, i64 %t209)
  %t220 = getelementptr i8, ptr %t219, i64 %t209
  call void @olang_textcopy(ptr %t220, ptr %t212, i64 %t213)
  %t221 = getelementptr i8, ptr %t220, i64 %t213
  call void @olang_textcopy(ptr %t221, ptr %t215, i64 %t216)
  %t222 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t223 = insertvalue { i64, ptr } %t222, ptr %t218, 1
  %t225 = extractvalue { i64, ptr } %t223, 0
  %t226 = extractvalue { i64, ptr } %t223, 1
  %t227 = mul i64 %t225, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t227)
  call void @llvm.memcpy.p0.p0.i64(ptr %t228, ptr %t226, i64 %t227, i1 false)
  %t229 = insertvalue { i64, ptr } undef, i64 %t225, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  %t231 = load ptr, ptr %l96, !tbaa !29
  %t233 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s15, ptr %s15, ptr %s15, ptr %t231, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d35, i32 0, i32 1) }, { i64, ptr } %t230)
  store { i64, ptr } %t233, ptr %l103
  br label %bb35
bb35:
  %t234 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  %t236 = extractvalue { i64, ptr } %t234, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  call void @compiler_2fbuild_2esayln(ptr %s15, { i64, ptr } %t240)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s15)
  br label %bb37
bb37:
  %t242 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t243 = load i32, ptr %t242, !tbaa !23
  %t245 = icmp ne i32 %t243, 3
  br i1 %t245, label %bb38, label %bb39
bb38:
  store i1 true, ptr %l6, !tbaa !21
  br label %bb40
bb39:
  br label %bb40
bb40:
  %t247 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t248 = load i32, ptr %t247, !tbaa !23
  %t250 = icmp ne i32 %t248, 0
  br i1 %t250, label %bb41, label %bb42
bb41:
  %t252 = getelementptr %"std/os:Output", ptr %l20, i32 0, i32 0
  %t253 = load i32, ptr %t252, !tbaa !23
  %t255 = icmp ne i32 %t253, 3
  store i1 %t255, ptr %l109, !tbaa !21
  br label %bb43
bb42:
  store i1 false, ptr %l109, !tbaa !21
  br label %bb43
bb43:
  %t257 = load i1, ptr %l109, !tbaa !21
  br i1 %t257, label %bb44, label %bb45
bb44:
  store i1 true, ptr %l5, !tbaa !21
  br label %bb46
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb47:
  %t258 = load i64, ptr %l8, !tbaa !24
  %t260 = add i64 %t258, 1
  store i64 %t260, ptr %l8, !tbaa !24
  br label %bb1
bb48:
  %t262 = load i1, ptr %l6, !tbaa !21
  %t264 = xor i1 %t262, true
  br i1 %t264, label %bb49, label %bb50
bb49:
  %t266 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t270 = icmp sgt i64 %t268, 0
  store i1 %t270, ptr %l116, !tbaa !21
  br label %bb51
bb50:
  store i1 false, ptr %l116, !tbaa !21
  br label %bb51
bb51:
  %t272 = load i1, ptr %l116, !tbaa !21
  br i1 %t272, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s20
  %t273 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s20, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t273, ptr %l120
  br label %bb54
bb53:
  br label %bb65
bb54:
  %t274 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l120
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t274, ptr %l21
  %t275 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t275, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t277 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t277, 0
  store i64 %t279, ptr %l24, !tbaa !24
  br label %bb55
bb55:
  %t281 = load i64, ptr %l23, !tbaa !24
  %t282 = load i64, ptr %l24, !tbaa !24
  %t285 = icmp slt i64 %t281, %t282
  %t287 = xor i1 %t285, true
  br i1 %t287, label %bb56, label %bb57
bb56:
  br label %bb61
bb57:
  br label %bb58
bb58:
  %t289 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t289, ptr %l128, !tbaa !27
  %t290 = load i64, ptr %l23, !tbaa !24
  %t292 = getelementptr { i64, ptr }, ptr %l128, i32 0, i32 1
  %t293 = load ptr, ptr %t292, !tbaa !27
  %t294 = getelementptr { i64, ptr }, ptr %t293, i64 %t290
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !37
  %t298 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t299 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t301 = extractvalue { i64, ptr } %t295, 1
  %t302 = extractvalue { i64, ptr } %t295, 0
  %t303 = add i64 %t299, %t302
  %t304 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t306 = add i64 %t303, %t305
  %t307 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t306)
  call void @olang_textcopy(ptr %t307, ptr %t298, i64 %t299)
  %t308 = getelementptr i8, ptr %t307, i64 %t299
  call void @olang_textcopy(ptr %t308, ptr %t301, i64 %t302)
  %t309 = getelementptr i8, ptr %t308, i64 %t302
  call void @olang_textcopy(ptr %t309, ptr %t304, i64 %t305)
  %t310 = insertvalue { i64, ptr } undef, i64 %t306, 0
  %t311 = insertvalue { i64, ptr } %t310, ptr %t307, 1
  %t313 = extractvalue { i64, ptr } %t311, 0
  %t314 = extractvalue { i64, ptr } %t311, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s20, ptr %s20, ptr %l21, { i64, ptr } %t318)
  br label %bb59
bb59:
  br label %bb60
bb60:
  %t321 = load i64, ptr %l23, !tbaa !24
  %t323 = add i64 %t321, 1
  store i64 %t323, ptr %l23, !tbaa !24
  br label %bb55
bb61:
  %t325 = load ptr, ptr %l0, !tbaa !29
  store ptr %t325, ptr %l137, !tbaa !29
  %t327 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s20, ptr %s20, ptr %s20, ptr %l21, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store { i64, ptr } %t327, ptr %l139
  br label %bb62
bb62:
  %t328 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t329 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t330 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t331 = extractvalue { i64, ptr } %t330, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = add i64 %t329, %t332
  %t334 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t333)
  call void @olang_textcopy(ptr %t334, ptr %t328, i64 %t329)
  %t335 = getelementptr i8, ptr %t334, i64 %t329
  call void @olang_textcopy(ptr %t335, ptr %t331, i64 %t332)
  %t336 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t334, 1
  %t339 = extractvalue { i64, ptr } %t337, 0
  %t340 = extractvalue { i64, ptr } %t337, 1
  %t341 = mul i64 %t339, 1
  %t342 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t341)
  call void @llvm.memcpy.p0.p0.i64(ptr %t342, ptr %t340, i64 %t341, i1 false)
  %t343 = insertvalue { i64, ptr } undef, i64 %t339, 0
  %t344 = insertvalue { i64, ptr } %t343, ptr %t342, 1
  %t345 = load ptr, ptr %l137, !tbaa !29
  %t347 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s20, ptr %s20, ptr %s20, ptr %t345, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d40, i32 0, i32 1) }, { i64, ptr } %t344)
  store { i64, ptr } %t347, ptr %l142
  br label %bb63
bb63:
  %t348 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t349 = extractvalue { i64, ptr } %t348, 0
  %t350 = extractvalue { i64, ptr } %t348, 1
  %t351 = mul i64 %t349, 1
  %t352 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t351)
  call void @llvm.memcpy.p0.p0.i64(ptr %t352, ptr %t350, i64 %t351, i1 false)
  %t353 = insertvalue { i64, ptr } undef, i64 %t349, 0
  %t354 = insertvalue { i64, ptr } %t353, ptr %t352, 1
  call void @compiler_2fbuild_2esayln(ptr %s20, { i64, ptr } %t354)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s20)
  store i32 1, ptr %rv
  br label %ret
bb65:
  %t357 = load i1, ptr %l5, !tbaa !21
  br i1 %t357, label %bb66, label %bb67
bb66:
  store i32 1, ptr %l146, !tbaa !23
  br label %bb68
bb67:
  store i32 0, ptr %l146, !tbaa !23
  br label %bb68
bb68:
  %t359 = load i32, ptr %l146, !tbaa !23
  store i32 %t359, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2eUnbuildable(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d41, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 62, ptr getelementptr inbounds (<{ i64, [62 x i8] }>, ptr @.d41, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a0, 1
  %t6 = extractvalue { i64, ptr } %a0, 0
  %t7 = add i64 %t3, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t2, i64 %t3)
  %t9 = getelementptr i8, ptr %t8, i64 %t3
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t18)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2eafresh(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l3 = alloca i32
  %l5 = alloca i1
  %l9 = alloca i32
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/diagmsg:Msg"
  %s2 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %t1)
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l3, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i32, ptr %l3, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t17 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t15)
  store i32 %t17, ptr %l9
  %t18 = icmp ne i32 %t17, 0
  br i1 %t18, label %bb8, label %ok.19, !prof !99
ok.19:
  br label %bb7
bb7:
  br label %bb14
bb8:
  %t20 = load i32, ptr %l9, !tbaa !23
  %t21 = ashr i32 %t20, 16
  %t23 = icmp eq i32 %t21, 1
  store i1 %t23, ptr %l11, !tbaa !21
  %t24 = load i32, ptr %l9, !tbaa !23
  %t25 = ashr i32 %t24, 16
  %t27 = icmp eq i32 %t25, 1
  br i1 %t27, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t29 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t29, ptr %l14, !tbaa !27
  %t30 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s2)
  store %"compiler/diagmsg:Msg" %t30, ptr %l15
  br label %bb12
bb12:
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t33 = load %"compiler/diagmsg:Msg", ptr %l15
  call void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %s2, ptr %v1, { i64, ptr } %t32, %"compiler/diagmsg:Msg" %t33, ptr %a1)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s2)
  store i32 65536, ptr %rv
  br label %ret
bb14:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i64 @compiler_2fbuild_2ecloseness(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l12 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l60 = alloca i64
  %rv = alloca i64
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %t1, { i64, ptr } %t2)
  store i64 %t5, ptr %l12
  br label %bb1
bb1:
  %t6 = load i64, ptr %l12, !tbaa !24
  store i64 %t6, ptr %l2, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t10, 0
  %t15 = icmp sgt i64 %t9, %t12
  br i1 %t15, label %bb2, label %bb3
bb2:
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t20, 0
  %t25 = sub i64 %t19, %t22
  %t27 = add i64 %t25, 1
  store i64 %t27, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t29 = load i64, ptr %l4, !tbaa !24
  %t30 = load i64, ptr %l3, !tbaa !24
  %t33 = icmp sgt i64 %t29, %t30
  br i1 %t33, label %bb4, label %bb5
bb3:
  br label %bb26
bb4:
  %t35 = load i64, ptr %l5, !tbaa !24
  %t37 = icmp sgt i64 %t35, 0
  br i1 %t37, label %bb6, label %bb7
bb5:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb9
bb6:
  %t39 = load i64, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t43 = sub i64 %t39, %t40
  %t44 = load i64, ptr %l5, !tbaa !24
  %t47 = add i64 %t43, %t44
  %t49 = sub i64 %t47, 1
  %t50 = load i64, ptr %l5, !tbaa !24
  %t53 = sdiv i64 %t49, %t50
  store i64 %t53, ptr %l30, !tbaa !24
  br label %bb8
bb7:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb8
bb8:
  %t55 = load i64, ptr %l30, !tbaa !24
  store i64 %t55, ptr %l27, !tbaa !24
  br label %bb9
bb9:
  %t56 = load i64, ptr %l27, !tbaa !24
  store i64 %t56, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb10
bb10:
  %t57 = load i64, ptr %l7, !tbaa !24
  %t58 = load i64, ptr %l6, !tbaa !24
  %t61 = icmp slt i64 %t57, %t58
  %t63 = xor i1 %t61, true
  br i1 %t63, label %bb11, label %bb12
bb11:
  br label %bb25
bb12:
  br label %bb13
bb13:
  %t65 = load i64, ptr %l3, !tbaa !24
  %t66 = load i64, ptr %l7, !tbaa !24
  %t67 = load i64, ptr %l5, !tbaa !24
  %t70 = mul i64 %t66, %t67
  %t73 = add i64 %t65, %t70
  store i64 %t73, ptr %l8, !tbaa !24
  %t75 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t75, ptr %l48, !tbaa !27
  %t76 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t76, ptr %l49, !tbaa !27
  %t77 = load i64, ptr %l8, !tbaa !24
  store i64 %t77, ptr %l50, !tbaa !24
  %t78 = load i64, ptr %l8, !tbaa !24
  %t79 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t84 = add i64 %t78, %t81
  store i64 %t84, ptr %l54, !tbaa !24
  %t85 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  store i64 %t86, ptr %l55, !tbaa !24
  %t87 = load i64, ptr %l50, !tbaa !24
  %t88 = icmp sge i64 %t87, 0
  br i1 %t88, label %bb14, label %bb15
bb14:
  %t90 = load i64, ptr %l50, !tbaa !24
  %t91 = load i64, ptr %l54, !tbaa !24
  %t92 = icmp sle i64 %t90, %t91
  br i1 %t92, label %bb16, label %bb17
bb15:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb16:
  %t94 = load i64, ptr %l54, !tbaa !24
  %t95 = load i64, ptr %l55, !tbaa !24
  %t96 = icmp sle i64 %t94, %t95
  br i1 %t96, label %bb18, label %bb19
bb17:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb18:
  %t98 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t99 = load ptr, ptr %t98, !tbaa !27
  %t100 = load i64, ptr %l50, !tbaa !24
  %t101 = load i64, ptr %l54, !tbaa !24
  %t102 = getelementptr i8, ptr %t99, i64 %t100
  %t103 = sub i64 %t101, %t100
  %t104 = insertvalue { i64, ptr } undef, i64 %t103, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t102, 1
  %t106 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t108 = call i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %t106, { i64, ptr } %t105)
  store i64 %t108, ptr %l60
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_7d17f382592ac8ef_3cd22268ed245003)
  unreachable
bb20:
  %t109 = load i64, ptr %l60, !tbaa !24
  store i64 %t109, ptr %l9, !tbaa !24
  %t110 = load i64, ptr %l9, !tbaa !24
  %t111 = load i64, ptr %l2, !tbaa !24
  %t114 = icmp slt i64 %t110, %t111
  br i1 %t114, label %bb21, label %bb22
bb21:
  %t116 = load i64, ptr %l9, !tbaa !24
  store i64 %t116, ptr %l2, !tbaa !24
  br label %bb23
bb22:
  br label %bb23
bb23:
  br label %bb24
bb24:
  %t118 = load i64, ptr %l7, !tbaa !24
  %t120 = add i64 %t118, 1
  store i64 %t120, ptr %l7, !tbaa !24
  br label %bb10
bb25:
  br label %bb26
bb26:
  %t122 = load i64, ptr %l2, !tbaa !24
  store i64 %t122, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l21 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 2
  %t8 = getelementptr %"compiler/target:Target", ptr %t7, i32 0, i32 9
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %lp1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 2
  %t15 = getelementptr %"compiler/target:Target", ptr %t14, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t20, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t11, { i64, ptr } %t33)
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t36 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s1)
  store { i64, ptr } %t36, ptr %l11
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t40, ptr %l13
  br label %bb6
bb6:
  %t41 = load i1, ptr %l13, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %lp1
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t49 = extractvalue { i64, ptr } %t45, 1
  %t50 = extractvalue { i64, ptr } %t45, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t44, { i64, ptr } %t62)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 2
  %t68 = getelementptr %"compiler/target:Target", ptr %t67, i32 0, i32 6
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t71, ptr %l21
  br label %bb12
bb12:
  %t72 = load i1, ptr %l21, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %lp1
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/build:Config", ptr %t76, i32 0, i32 2
  %t79 = getelementptr %"compiler/target:Target", ptr %t78, i32 0, i32 6
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t75, { i64, ptr } %t93)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t96 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t96, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d46, i32 0, i32 1) })
  br label %bb17
bb17:
  %t98 = load ptr, ptr %lp1
  %t99 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t98
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t99, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %lp2 = alloca ptr
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v2, ptr %t1)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = call ptr @__olang_scope_alloc_a(ptr %v2, i64 32, i64 8)
  store ptr %t4, ptr %lp2
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  %t6 = load ptr, ptr %lp2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %t6
  %t7 = load ptr, ptr %l0, !tbaa !29
  %t9 = getelementptr %"compiler/build:Config", ptr %t7, i32 0, i32 12
  %t10 = load i1, ptr %t9, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t12 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t12, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d47, i32 0, i32 1) })
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t14 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t14, { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 4
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d49, i32 0, i32 1) }, ptr %l14, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t25 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v1, ptr %s0, { i64, ptr } %a1, { i64, ptr } %t24)
  store i1 %t25, ptr %l15
  br label %bb9
bb8:
  store i1 false, ptr %l11, !tbaa !21
  br label %bb10
bb9:
  %t26 = load i1, ptr %l15, !tbaa !21
  store i1 %t26, ptr %l11, !tbaa !21
  br label %bb10
bb10:
  %t27 = load i1, ptr %l11, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb11:
  %t28 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t28, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d50, i32 0, i32 1) })
  br label %bb13
bb12:
  br label %bb15
bb13:
  %t30 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t30, { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"compiler/build:Config", ptr %t32, i32 0, i32 13
  %t35 = load i1, ptr %t34, !tbaa !21
  br i1 %t35, label %bb16, label %bb17
bb16:
  %t37 = load ptr, ptr %lp2
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t37, { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d52, i32 0, i32 1) })
  br label %bb18
bb17:
  br label %bb20
bb18:
  %t39 = load ptr, ptr %lp2
  %t40 = load { i64, ptr }, ptr @G_2ecompiler_2fbuild_2eRemarkPasses, !tbaa !27
  %t41 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 29, ptr getelementptr inbounds (<{ i64, [29 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t44 = extractvalue { i64, ptr } %t40, 1
  %t45 = extractvalue { i64, ptr } %t40, 0
  %t46 = add i64 %t42, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t41, i64 %t42)
  %t48 = getelementptr i8, ptr %t47, i64 %t42
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v2, ptr %v2, ptr %t39, { i64, ptr } %t57)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t60 = load ptr, ptr %lp2
  %t61 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t61, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %lp1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca i64
  %l11 = alloca i64
  %l16 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca i1
  %l22 = alloca i1
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l5
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s1, ptr %a0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l7
  br label %bb2
bb2:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  %t9 = call ptr @__olang_scope_alloc_a(ptr %s1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %t9
  store ptr %t9, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t11 = load i64, ptr %l3, !tbaa !24
  store i64 %t11, ptr %l9, !tbaa !24
  %t12 = load ptr, ptr %l2, !tbaa !29
  %t14 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s1, ptr %t12)
  store i64 %t14, ptr %l11
  br label %bb4
bb4:
  %t15 = load i64, ptr %l9, !tbaa !24
  %t16 = load i64, ptr %l11, !tbaa !24
  %t17 = icmp slt i64 %t15, %t16
  %t19 = xor i1 %t17, true
  br i1 %t19, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb6:
  br label %bb7
bb7:
  %t21 = load ptr, ptr %l2, !tbaa !29
  %t22 = load i64, ptr %l3, !tbaa !24
  %t25 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s1, ptr %s1, ptr %t21, i64 %t22)
  store { i64, ptr } %t25, ptr %l16
  br label %bb8
bb8:
  %t26 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t26, ptr %l4, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t29 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s2, { i64, ptr } %t27, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d54, i32 0, i32 1) })
  store i1 %t29, ptr %l18
  br label %bb9
bb9:
  %t30 = load i1, ptr %l18, !tbaa !21
  %t31 = xor i1 %t30, true
  br i1 %t31, label %bb10, label %bb11
bb10:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t35 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s2, { i64, ptr } %t33, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t35, ptr %l22
  br label %bb12
bb11:
  store i1 false, ptr %l20, !tbaa !21
  br label %bb13
bb12:
  %t36 = load i1, ptr %l22, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l20, !tbaa !21
  br label %bb13
bb13:
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb14, label %bb15
bb14:
  %t40 = load ptr, ptr %lp1
  %t41 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 1
  %t44 = extractvalue { i64, ptr } %t41, 0
  %t45 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t44)
  call void @olang_textcopy(ptr %t45, ptr %t43, i64 %t44)
  %t46 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t47 = insertvalue { i64, ptr } %t46, ptr %t45, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  %t50 = extractvalue { i64, ptr } %t47, 1
  %t51 = mul i64 %t49, 1
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @llvm.memcpy.p0.p0.i64(ptr %t52, ptr %t50, i64 %t51, i1 false)
  %t53 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t52, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t40, { i64, ptr } %t54)
  br label %bb16
bb15:
  br label %bb17
bb16:
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb18
bb18:
  %t57 = load i64, ptr %l3, !tbaa !24
  %t59 = add i64 %t57, 1
  store i64 %t59, ptr %l3, !tbaa !24
  br label %bb3
bb19:
  call void @__olang_scope_close(ptr %s1)
  %t61 = load ptr, ptr %lp1
  %t62 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t61
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t62, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eFnAttrs(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 2
  %t4 = getelementptr %"compiler/target:Target", ptr %t3, i32 0, i32 5
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  store { i64, ptr } %t5, ptr %l2, !tbaa !27
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 12
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d56, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) }, ptr %l5, !tbaa !27
  br label %bb3
bb3:
  %t11 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t12 = extractvalue { i64, ptr } %t11, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 1
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t17 = add i64 %t13, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t12, i64 %t13)
  %t19 = getelementptr i8, ptr %t18, i64 %t13
  call void @olang_textcopy(ptr %t19, ptr %t15, i64 %t16)
  %t20 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t18, 1
  store { i64, ptr } %t21, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/prelude/text:StringBuilder"
  %l12 = alloca ptr
  %l13 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca %"std/os:Output"
  %l28 = alloca %"std/os:FileInfo"
  %l29 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l38 = alloca i64
  %l40 = alloca i64
  %l45 = alloca { i64, ptr }
  %l69 = alloca %"std/prelude/text:StringBuilder"
  %l72 = alloca i64
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca i1
  %l102 = alloca ptr
  %l104 = alloca { i64, ptr }
  %l113 = alloca i64
  %l115 = alloca i64
  %l120 = alloca { i64, ptr }
  %l128 = alloca i64
  %l130 = alloca i64
  %l135 = alloca { i64, ptr }
  %l151 = alloca i1
  %l158 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l160 = alloca i64
  %l162 = alloca i64
  %l167 = alloca { i64, ptr }
  %l172 = alloca ptr
  %l174 = alloca { i64, ptr }
  %l176 = alloca { i64, ptr }
  %l182 = alloca i1
  %l184 = alloca i32
  %l186 = alloca i1
  %l191 = alloca i1
  %l193 = alloca %"std/os:Output"
  %l195 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l197 = alloca %"std/os:Output"
  %l198 = alloca i32
  %l200 = alloca i1
  %l207 = alloca ptr
  %l210 = alloca %"std/os:FileInfo"
  %l212 = alloca %"std/os:FileInfo"
  %l213 = alloca i32
  %l215 = alloca i1
  %l225 = alloca i32
  %l227 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l29
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l29
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l6
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t19)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s2, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l36
  br label %bb3
bb3:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  store ptr %t26, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l8, !tbaa !24
  store i64 %t28, ptr %l38, !tbaa !24
  %t29 = load ptr, ptr %l7, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t29)
  store i64 %t31, ptr %l40
  br label %bb5
bb5:
  %t32 = load i64, ptr %l38, !tbaa !24
  %t33 = load i64, ptr %l40, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l7, !tbaa !29
  %t39 = load i64, ptr %l8, !tbaa !24
  %t42 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %t38, i64 %t39)
  store { i64, ptr } %t42, ptr %l45
  br label %bb9
bb9:
  %t43 = load { i64, ptr }, ptr %l45, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = extractvalue { i64, ptr } %t43, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t57)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t60 = load i64, ptr %l8, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l8, !tbaa !24
  br label %bb4
bb12:
  call void @__olang_scope_close(ptr %s2)
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 25
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Config", ptr %t69, i32 0, i32 0
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t73 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t74 = extractvalue { i64, ptr } { i64 26, ptr getelementptr inbounds (<{ i64, [26 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t76 = extractvalue { i64, ptr } %t72, 1
  %t77 = extractvalue { i64, ptr } %t72, 0
  %t78 = add i64 %t74, %t77
  %t79 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t73, i64 %t74)
  %t83 = getelementptr i8, ptr %t82, i64 %t74
  call void @olang_textcopy(ptr %t83, ptr %t76, i64 %t77)
  %t84 = getelementptr i8, ptr %t83, i64 %t77
  call void @olang_textcopy(ptr %t84, ptr %t79, i64 %t80)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t82, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t93)
  br label %bb15
bb14:
  br label %bb17
bb15:
  %t96 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t97 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t98 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t100 = call i64 @__olang_fmt_i64(ptr null, i64 %t96)
  %t101 = add i64 %t98, %t100
  %t102 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t101)
  call void @olang_textcopy(ptr %t102, ptr %t97, i64 %t98)
  %t103 = getelementptr i8, ptr %t102, i64 %t98
  %t104 = call i64 @__olang_fmt_i64(ptr %t103, i64 %t96)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t102, 1
  %t108 = extractvalue { i64, ptr } %t106, 0
  %t109 = extractvalue { i64, ptr } %t106, 1
  %t110 = mul i64 %t108, 1
  %t111 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t110)
  call void @llvm.memcpy.p0.p0.i64(ptr %t111, ptr %t109, i64 %t110, i1 false)
  %t112 = insertvalue { i64, ptr } undef, i64 %t108, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t113)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t116 = load ptr, ptr %l5, !tbaa !29
  %t118 = icmp eq ptr %t116, null
  %t120 = xor i1 %t118, true
  br i1 %t120, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d61, i32 0, i32 1) })
  br label %bb20
bb19:
  br label %bb43
bb20:
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = extractvalue { i64, ptr } %t123, 0
  %t127 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t128 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t129 = add i64 %t126, %t128
  %t130 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t129)
  call void @olang_textcopy(ptr %t130, ptr %t125, i64 %t126)
  %t131 = getelementptr i8, ptr %t130, i64 %t126
  call void @olang_textcopy(ptr %t131, ptr %t127, i64 %t128)
  %t132 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t133 = insertvalue { i64, ptr } %t132, ptr %t130, 1
  store { i64, ptr } %t133, ptr %l10, !tbaa !27
  %t135 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s9)
  store %"std/prelude/text:StringBuilder" %t135, ptr %l69
  br label %bb21
bb21:
  %t136 = load %"std/prelude/text:StringBuilder", ptr %l69
  store %"std/prelude/text:StringBuilder" %t136, ptr %l11
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l11, { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d63, i32 0, i32 1) })
  br label %bb22
bb22:
  %t138 = load ptr, ptr %l5, !tbaa !29
  store ptr %t138, ptr %l12, !tbaa !29
  store i64 0, ptr %l13, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s12
  %t140 = load i64, ptr %l13, !tbaa !24
  store i64 %t140, ptr %l72, !tbaa !24
  %t141 = load ptr, ptr %l12, !tbaa !29
  %t143 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v4, ptr %t141)
  store i64 %t143, ptr %l74
  br label %bb24
bb24:
  %t144 = load i64, ptr %l72, !tbaa !24
  %t145 = load i64, ptr %l74, !tbaa !24
  %t146 = icmp slt i64 %t144, %t145
  %t148 = xor i1 %t146, true
  br i1 %t148, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s12)
  br label %bb31
bb26:
  br label %bb27
bb27:
  %t150 = load ptr, ptr %l12, !tbaa !29
  %t151 = load i64, ptr %l13, !tbaa !24
  %t154 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v4, ptr %v4, ptr %t150, i64 %t151)
  store { i64, ptr } %t154, ptr %l79
  br label %bb28
bb28:
  %t155 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t157 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t158 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t160 = extractvalue { i64, ptr } %t155, 1
  %t161 = extractvalue { i64, ptr } %t155, 0
  %t162 = add i64 %t158, %t161
  %t163 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t164 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t165 = add i64 %t162, %t164
  %t166 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t165)
  call void @olang_textcopy(ptr %t166, ptr %t157, i64 %t158)
  %t167 = getelementptr i8, ptr %t166, i64 %t158
  call void @olang_textcopy(ptr %t167, ptr %t160, i64 %t161)
  %t168 = getelementptr i8, ptr %t167, i64 %t161
  call void @olang_textcopy(ptr %t168, ptr %t163, i64 %t164)
  %t169 = insertvalue { i64, ptr } undef, i64 %t165, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t166, 1
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t173 = extractvalue { i64, ptr } %t170, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s12, ptr %l11, { i64, ptr } %t177)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s12)
  br label %bb30
bb30:
  %t180 = load i64, ptr %l13, !tbaa !24
  %t182 = add i64 %t180, 1
  store i64 %t182, ptr %l13, !tbaa !24
  br label %bb23
bb31:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s9, ptr %s9, ptr %l11, { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d66, i32 0, i32 1) })
  br label %bb32
bb32:
  %t185 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t185, ptr %l87, !tbaa !27
  %t187 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s9, ptr %s9, ptr %l11)
  store { i64, ptr } %t187, ptr %l89
  br label %bb33
bb33:
  %t188 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t188, 0
  %t191 = extractvalue { i64, ptr } %t188, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  %t196 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t198 = call i32 @std_2fos_2eWriteFile(ptr %s9, ptr %s9, { i64, ptr } %t196, { i64, ptr } %t195)
  store i32 %t198, ptr %l92
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb35, label %ok.200, !prof !99
ok.200:
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t201 = load i32, ptr %l92, !tbaa !23
  %t202 = ashr i32 %t201, 16
  %t204 = icmp eq i32 %t202, 1
  store i1 %t204, ptr %l94, !tbaa !21
  %t205 = load i32, ptr %l92, !tbaa !23
  %t206 = ashr i32 %t205, 16
  %t208 = icmp eq i32 %t206, 1
  br i1 %t208, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb39:
  %t211 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t212 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t213 = extractvalue { i64, ptr } { i64 21, ptr getelementptr inbounds (<{ i64, [21 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t215 = extractvalue { i64, ptr } %t211, 1
  %t216 = extractvalue { i64, ptr } %t211, 0
  %t217 = add i64 %t213, %t216
  %t218 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t217)
  call void @olang_textcopy(ptr %t218, ptr %t212, i64 %t213)
  %t219 = getelementptr i8, ptr %t218, i64 %t213
  call void @olang_textcopy(ptr %t219, ptr %t215, i64 %t216)
  %t220 = insertvalue { i64, ptr } undef, i64 %t217, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr %t218, 1
  %t223 = extractvalue { i64, ptr } %t221, 0
  %t224 = extractvalue { i64, ptr } %t221, 1
  %t225 = mul i64 %t223, 1
  %t226 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t225)
  call void @llvm.memcpy.p0.p0.i64(ptr %t226, ptr %t224, i64 %t225, i1 false)
  %t227 = insertvalue { i64, ptr } undef, i64 %t223, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t226, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t228)
  br label %bb40
bb40:
  store ptr %l6, ptr %l102, !tbaa !29
  %t231 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t233 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v2, ptr %s9, { i64, ptr } %t231)
  store { i64, ptr } %t233, ptr %l104
  br label %bb41
bb41:
  %t234 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 12, ptr getelementptr inbounds (<{ i64, [12 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t236 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = add i64 %t235, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t234, i64 %t235)
  %t241 = getelementptr i8, ptr %t240, i64 %t235
  call void @olang_textcopy(ptr %t241, ptr %t237, i64 %t238)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load ptr, ptr %l102, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t251, { i64, ptr } %t250)
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s9)
  br label %bb43
bb43:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d69, i32 0, i32 1) })
  br label %bb44
bb44:
  %t254 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t256 = extractvalue { i64, ptr } %t254, 1
  %t257 = extractvalue { i64, ptr } %t254, 0
  %t258 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t256, i64 %t257)
  %t259 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } %t260, 1
  %t264 = mul i64 %t262, 1
  %t265 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t264)
  call void @llvm.memcpy.p0.p0.i64(ptr %t265, ptr %t263, i64 %t264, i1 false)
  %t266 = insertvalue { i64, ptr } undef, i64 %t262, 0
  %t267 = insertvalue { i64, ptr } %t266, ptr %t265, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t267)
  br label %bb45
bb45:
  store ptr %a1, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb46
bb46:
  %t272 = load i64, ptr %l16, !tbaa !24
  store i64 %t272, ptr %l113, !tbaa !24
  %t273 = load ptr, ptr %l15, !tbaa !29
  %t275 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t273)
  store i64 %t275, ptr %l115
  br label %bb47
bb47:
  %t276 = load i64, ptr %l113, !tbaa !24
  %t277 = load i64, ptr %l115, !tbaa !24
  %t278 = icmp slt i64 %t276, %t277
  %t280 = xor i1 %t278, true
  br i1 %t280, label %bb48, label %bb49
bb48:
  br label %bb54
bb49:
  br label %bb50
bb50:
  %t282 = load ptr, ptr %l15, !tbaa !29
  %t283 = load i64, ptr %l16, !tbaa !24
  %t286 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t282, i64 %t283)
  store { i64, ptr } %t286, ptr %l120
  br label %bb51
bb51:
  %t287 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t287, 1
  %t291 = extractvalue { i64, ptr } %t287, 0
  %t292 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t291)
  call void @olang_textcopy(ptr %t292, ptr %t290, i64 %t291)
  %t293 = insertvalue { i64, ptr } undef, i64 %t291, 0
  %t294 = insertvalue { i64, ptr } %t293, ptr %t292, 1
  %t296 = extractvalue { i64, ptr } %t294, 0
  %t297 = extractvalue { i64, ptr } %t294, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t301)
  br label %bb52
bb52:
  br label %bb53
bb53:
  %t304 = load i64, ptr %l16, !tbaa !24
  %t306 = add i64 %t304, 1
  store i64 %t306, ptr %l16, !tbaa !24
  br label %bb46
bb54:
  store ptr %a4, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb55
bb55:
  %t310 = load i64, ptr %l19, !tbaa !24
  store i64 %t310, ptr %l128, !tbaa !24
  %t311 = load ptr, ptr %l18, !tbaa !29
  %t313 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t311)
  store i64 %t313, ptr %l130
  br label %bb56
bb56:
  %t314 = load i64, ptr %l128, !tbaa !24
  %t315 = load i64, ptr %l130, !tbaa !24
  %t316 = icmp slt i64 %t314, %t315
  %t318 = xor i1 %t316, true
  br i1 %t318, label %bb57, label %bb58
bb57:
  br label %bb63
bb58:
  br label %bb59
bb59:
  %t320 = load ptr, ptr %l18, !tbaa !29
  %t321 = load i64, ptr %l19, !tbaa !24
  %t324 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t320, i64 %t321)
  store { i64, ptr } %t324, ptr %l135
  br label %bb60
bb60:
  %t325 = load { i64, ptr }, ptr %l135, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t325, 1
  %t329 = extractvalue { i64, ptr } %t325, 0
  %t330 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t329)
  call void @olang_textcopy(ptr %t330, ptr %t328, i64 %t329)
  %t331 = insertvalue { i64, ptr } undef, i64 %t329, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  %t334 = extractvalue { i64, ptr } %t332, 0
  %t335 = extractvalue { i64, ptr } %t332, 1
  %t336 = mul i64 %t334, 1
  %t337 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t336)
  call void @llvm.memcpy.p0.p0.i64(ptr %t337, ptr %t335, i64 %t336, i1 false)
  %t338 = insertvalue { i64, ptr } undef, i64 %t334, 0
  %t339 = insertvalue { i64, ptr } %t338, ptr %t337, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t339)
  br label %bb61
bb61:
  br label %bb62
bb62:
  %t342 = load i64, ptr %l19, !tbaa !24
  %t344 = add i64 %t342, 1
  store i64 %t344, ptr %l19, !tbaa !24
  br label %bb55
bb63:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d70, i32 0, i32 1) })
  br label %bb64
bb64:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d71, i32 0, i32 1) })
  br label %bb65
bb65:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d72, i32 0, i32 1) })
  br label %bb66
bb66:
  %t349 = load ptr, ptr %l0, !tbaa !29
  %t351 = getelementptr %"compiler/build:Config", ptr %t349, i32 0, i32 12
  %t352 = load i1, ptr %t351, !tbaa !21
  br i1 %t352, label %bb67, label %bb68
bb67:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d73, i32 0, i32 1) })
  br label %bb69
bb68:
  br label %bb77
bb69:
  %t355 = load ptr, ptr %l0, !tbaa !29
  %t357 = getelementptr %"compiler/build:Config", ptr %t355, i32 0, i32 5
  %t358 = load i1, ptr %t357, !tbaa !21
  %t360 = xor i1 %t358, true
  br i1 %t360, label %bb70, label %bb71
bb70:
  %t362 = load ptr, ptr %l0, !tbaa !29
  %t364 = getelementptr %"compiler/build:Config", ptr %t362, i32 0, i32 4
  %t365 = load i1, ptr %t364, !tbaa !21
  %t367 = xor i1 %t365, true
  store i1 %t367, ptr %l151, !tbaa !21
  br label %bb72
bb71:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb72
bb72:
  %t369 = load i1, ptr %l151, !tbaa !21
  br i1 %t369, label %bb73, label %bb74
bb73:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 41, ptr getelementptr inbounds (<{ i64, [41 x i8] }>, ptr @.d74, i32 0, i32 1) })
  br label %bb75
bb74:
  br label %bb76
bb75:
  br label %bb76
bb76:
  br label %bb77
bb77:
  br i1 %a3, label %bb78, label %bb79
bb78:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d75, i32 0, i32 1) })
  br label %bb80
bb79:
  br label %bb81
bb80:
  br label %bb81
bb81:
  %t374 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t374, ptr %l158
  br label %bb82
bb82:
  %t375 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l158
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t375, ptr %l21
  store ptr %l6, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb83
bb83:
  %t377 = load i64, ptr %l23, !tbaa !24
  store i64 %t377, ptr %l160, !tbaa !24
  %t378 = load ptr, ptr %l22, !tbaa !29
  %t380 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t378)
  store i64 %t380, ptr %l162
  br label %bb84
bb84:
  %t381 = load i64, ptr %l160, !tbaa !24
  %t382 = load i64, ptr %l162, !tbaa !24
  %t383 = icmp slt i64 %t381, %t382
  %t385 = xor i1 %t383, true
  br i1 %t385, label %bb85, label %bb86
bb85:
  br label %bb91
bb86:
  br label %bb87
bb87:
  %t387 = load ptr, ptr %l22, !tbaa !29
  %t388 = load i64, ptr %l23, !tbaa !24
  %t391 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t387, i64 %t388)
  store { i64, ptr } %t391, ptr %l167
  br label %bb88
bb88:
  %t392 = load { i64, ptr }, ptr %l167, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } %t392)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t396 = load i64, ptr %l23, !tbaa !24
  %t398 = add i64 %t396, 1
  store i64 %t398, ptr %l23, !tbaa !24
  br label %bb83
bb91:
  store ptr %l21, ptr %l172, !tbaa !29
  %t400 = load ptr, ptr %l0, !tbaa !29
  %t402 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t400)
  store { i64, ptr } %t402, ptr %l174
  br label %bb92
bb92:
  %t403 = load ptr, ptr %l172, !tbaa !29
  %t404 = load { i64, ptr }, ptr %l174, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t403, { i64, ptr } %t404)
  br label %bb93
bb93:
  %t406 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l21)
  store { i64, ptr } %t406, ptr %l176
  br label %bb94
bb94:
  %t407 = load { i64, ptr }, ptr %l176, !tbaa !27
  store { i64, ptr } %t407, ptr %l25, !tbaa !27
  %t408 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t410 = extractvalue { i64, ptr } %t408, 1
  %t411 = extractvalue { i64, ptr } %t408, 0
  %t412 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) }, 1
  %t413 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d76, i32 0, i32 1) }, 0
  %t414 = add i64 %t411, %t413
  %t415 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t414)
  call void @olang_textcopy(ptr %t415, ptr %t410, i64 %t411)
  %t416 = getelementptr i8, ptr %t415, i64 %t411
  call void @olang_textcopy(ptr %t416, ptr %t412, i64 %t413)
  %t417 = insertvalue { i64, ptr } undef, i64 %t414, 0
  %t418 = insertvalue { i64, ptr } %t417, ptr %t415, 1
  store { i64, ptr } %t418, ptr %l26, !tbaa !27
  %t420 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t421 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t422 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t426 = call i1 @compiler_2fbuild_2elinkCurrent(ptr %v2, ptr %s0, ptr %s0, { i64, ptr } %t420, { i64, ptr } %t421, { i64, ptr } %t422)
  store i1 %t426, ptr %l182
  br label %bb95
bb95:
  %t427 = load i1, ptr %l182, !tbaa !21
  br i1 %t427, label %bb96, label %bb97
bb96:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb97:
  br label %bb98
bb98:
  %t428 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t430 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t428)
  store i32 %t430, ptr %l184
  %t431 = icmp ne i32 %t430, 0
  br i1 %t431, label %bb100, label %ok.432, !prof !99
ok.432:
  br label %bb99
bb99:
  br label %bb104
bb100:
  %t433 = load i32, ptr %l184, !tbaa !23
  %t434 = ashr i32 %t433, 16
  %t436 = icmp eq i32 %t434, 1
  store i1 %t436, ptr %l186, !tbaa !21
  %t437 = load i32, ptr %l184, !tbaa !23
  %t438 = ashr i32 %t437, 16
  %t440 = icmp eq i32 %t438, 1
  br i1 %t440, label %bb101, label %bb102
bb101:
  call void @__olang_errpay_pop()
  br label %bb102
bb102:
  br label %bb103
bb103:
  br label %bb104
bb104:
  %t442 = load ptr, ptr %l0, !tbaa !29
  %t444 = getelementptr %"compiler/build:Config", ptr %t442, i32 0, i32 1
  %t445 = load { i64, ptr }, ptr %t444, !tbaa !27
  %t447 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t445, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d77, i32 0, i32 1) })
  store i1 %t447, ptr %l191
  br label %bb105
bb105:
  %t448 = load i1, ptr %l191, !tbaa !21
  br i1 %t448, label %bb106, label %bb107
bb106:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb107:
  br label %bb108
bb108:
  %t451 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t451, ptr %l195
  br label %bb109
bb109:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l196, !tbaa !27
  %t452 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t453 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t454 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t452, { i64, ptr } %t453, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t455 = extractvalue { i32, %"std/os:Output" } %t454, 1
  %t456 = extractvalue { i32, %"std/os:Output" } %t454, 0
  store i32 %t456, ptr %l198
  %t457 = icmp ne i32 %t456, 0
  br i1 %t457, label %bb111, label %ok.458, !prof !99
ok.458:
  store %"std/os:Output" %t455, ptr %l197
  br label %bb110
bb110:
  %t459 = load %"std/os:Output", ptr %l197
  store %"std/os:Output" %t459, ptr %l193
  br label %bb115
bb111:
  %t460 = load i32, ptr %l198, !tbaa !23
  %t461 = ashr i32 %t460, 16
  %t463 = icmp eq i32 %t461, 1
  store i1 %t463, ptr %l200, !tbaa !21
  %t464 = load i32, ptr %l198, !tbaa !23
  %t465 = ashr i32 %t464, 16
  %t467 = icmp eq i32 %t465, 1
  br i1 %t467, label %bb112, label %bb113
bb112:
  call void @__olang_errpay_pop()
  br label %bb113
bb113:
  br label %bb114
bb114:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb115:
  %t470 = load %"std/os:Output", ptr %l193
  store %"std/os:Output" %t470, ptr %l27
  %t471 = getelementptr %"std/os:Output", ptr %l27, i32 0, i32 0
  %t472 = load i32, ptr %t471, !tbaa !23
  %t474 = icmp ne i32 %t472, 0
  br i1 %t474, label %bb116, label %bb117
bb116:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb117:
  br label %bb118
bb118:
  %t477 = load ptr, ptr %l0, !tbaa !29
  store ptr %t477, ptr %l207, !tbaa !29
  %t478 = load ptr, ptr %l207, !tbaa !29
  %t479 = getelementptr %"compiler/build:Config", ptr %t478, i32 0, i32 24
  %t480 = load i64, ptr %t479, !tbaa !24
  %t482 = add i64 %t480, 1
  %t484 = load ptr, ptr %l207, !tbaa !29
  %t485 = getelementptr %"compiler/build:Config", ptr %t484, i32 0, i32 24
  store i64 %t482, ptr %t485, !tbaa !24
  %t486 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t488 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t486)
  %t489 = extractvalue { i32, %"std/os:FileInfo" } %t488, 1
  %t490 = extractvalue { i32, %"std/os:FileInfo" } %t488, 0
  store i32 %t490, ptr %l213
  %t491 = icmp ne i32 %t490, 0
  br i1 %t491, label %bb120, label %ok.492, !prof !99
ok.492:
  store %"std/os:FileInfo" %t489, ptr %l212
  br label %bb119
bb119:
  %t493 = load %"std/os:FileInfo", ptr %l212
  store %"std/os:FileInfo" %t493, ptr %l210
  br label %bb124
bb120:
  %t494 = load i32, ptr %l213, !tbaa !23
  %t495 = ashr i32 %t494, 16
  %t497 = icmp eq i32 %t495, 1
  store i1 %t497, ptr %l215, !tbaa !21
  %t498 = load i32, ptr %l213, !tbaa !23
  %t499 = ashr i32 %t498, 16
  %t501 = icmp eq i32 %t499, 1
  br i1 %t501, label %bb121, label %bb122
bb121:
  call void @__olang_errpay_pop()
  br label %bb122
bb122:
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb124:
  %t503 = load %"std/os:FileInfo", ptr %l210
  store %"std/os:FileInfo" %t503, ptr %l28
  %t504 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t505 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t506 = getelementptr %"std/os:FileInfo", ptr %l28, i32 0, i32 1
  %t507 = load i64, ptr %t506, !tbaa !24
  %t508 = getelementptr %"std/os:FileInfo", ptr %l28, i32 0, i32 2
  %t509 = load i64, ptr %t508, !tbaa !24
  %t511 = extractvalue { i64, ptr } %t505, 1
  %t512 = extractvalue { i64, ptr } %t505, 0
  %t513 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t514 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t515 = add i64 %t512, %t514
  %t517 = call i64 @__olang_fmt_i64(ptr null, i64 %t507)
  %t518 = add i64 %t515, %t517
  %t519 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 1
  %t520 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d78, i32 0, i32 1) }, 0
  %t521 = add i64 %t518, %t520
  %t523 = call i64 @__olang_fmt_i64(ptr null, i64 %t509)
  %t524 = add i64 %t521, %t523
  %t525 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 1
  %t526 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d79, i32 0, i32 1) }, 0
  %t527 = add i64 %t524, %t526
  %t528 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t527)
  call void @olang_textcopy(ptr %t528, ptr %t511, i64 %t512)
  %t529 = getelementptr i8, ptr %t528, i64 %t512
  call void @olang_textcopy(ptr %t529, ptr %t513, i64 %t514)
  %t530 = getelementptr i8, ptr %t529, i64 %t514
  %t531 = call i64 @__olang_fmt_i64(ptr %t530, i64 %t507)
  %t532 = getelementptr i8, ptr %t530, i64 %t517
  call void @olang_textcopy(ptr %t532, ptr %t519, i64 %t520)
  %t533 = getelementptr i8, ptr %t532, i64 %t520
  %t534 = call i64 @__olang_fmt_i64(ptr %t533, i64 %t509)
  %t535 = getelementptr i8, ptr %t533, i64 %t523
  call void @olang_textcopy(ptr %t535, ptr %t525, i64 %t526)
  %t536 = insertvalue { i64, ptr } undef, i64 %t527, 0
  %t537 = insertvalue { i64, ptr } %t536, ptr %t528, 1
  %t540 = extractvalue { i64, ptr } %t537, 0
  %t541 = extractvalue { i64, ptr } %t537, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  %t548 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t504, { i64, ptr } %t545)
  store i32 %t548, ptr %l225
  %t549 = icmp ne i32 %t548, 0
  br i1 %t549, label %bb126, label %ok.550, !prof !99
ok.550:
  br label %bb125
bb125:
  br label %bb130
bb126:
  %t551 = load i32, ptr %l225, !tbaa !23
  %t552 = ashr i32 %t551, 16
  %t554 = icmp eq i32 %t552, 1
  store i1 %t554, ptr %l227, !tbaa !21
  %t555 = load i32, ptr %l225, !tbaa !23
  %t556 = ashr i32 %t555, 16
  %t558 = icmp eq i32 %t556, 1
  br i1 %t558, label %bb127, label %bb128
bb127:
  call void @__olang_errpay_pop()
  br label %bb128
bb128:
  br label %bb129
bb129:
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l13 = alloca i1
  %l21 = alloca i1
  %l33 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l3
  br label %bb1
bb1:
  %t2 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store ptr %t2, ptr %lp1
  %t3 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t4 = load ptr, ptr %lp1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %t4
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 2
  %t8 = getelementptr %"compiler/target:Target", ptr %t7, i32 0, i32 9
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %lp1
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 2
  %t15 = getelementptr %"compiler/target:Target", ptr %t14, i32 0, i32 1
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t17 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d80, i32 0, i32 1) }, 0
  %t20 = extractvalue { i64, ptr } %t16, 1
  %t21 = extractvalue { i64, ptr } %t16, 0
  %t22 = add i64 %t18, %t21
  %t23 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t22)
  call void @olang_textcopy(ptr %t23, ptr %t17, i64 %t18)
  %t24 = getelementptr i8, ptr %t23, i64 %t18
  call void @olang_textcopy(ptr %t24, ptr %t20, i64 %t21)
  %t25 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr %t23, 1
  %t28 = extractvalue { i64, ptr } %t26, 0
  %t29 = extractvalue { i64, ptr } %t26, 1
  %t30 = mul i64 %t28, 1
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t29, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t11, { i64, ptr } %t33)
  br label %bb4
bb3:
  br label %bb11
bb4:
  %t36 = call { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %s1)
  store { i64, ptr } %t36, ptr %l11
  br label %bb5
bb5:
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t37, ptr %l2, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t40 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s1, ptr %s1, { i64, ptr } %t38, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d81, i32 0, i32 1) })
  store i1 %t40, ptr %l13
  br label %bb6
bb6:
  %t41 = load i1, ptr %l13, !tbaa !21
  %t42 = xor i1 %t41, true
  br i1 %t42, label %bb7, label %bb8
bb7:
  %t44 = load ptr, ptr %lp1
  %t45 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t46 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d82, i32 0, i32 1) }, 1
  %t47 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d82, i32 0, i32 1) }, 0
  %t49 = extractvalue { i64, ptr } %t45, 1
  %t50 = extractvalue { i64, ptr } %t45, 0
  %t51 = add i64 %t47, %t50
  %t52 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t51)
  call void @olang_textcopy(ptr %t52, ptr %t46, i64 %t47)
  %t53 = getelementptr i8, ptr %t52, i64 %t47
  call void @olang_textcopy(ptr %t53, ptr %t49, i64 %t50)
  %t54 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t52, 1
  %t57 = extractvalue { i64, ptr } %t55, 0
  %t58 = extractvalue { i64, ptr } %t55, 1
  %t59 = mul i64 %t57, 1
  %t60 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t59)
  call void @llvm.memcpy.p0.p0.i64(ptr %t60, ptr %t58, i64 %t59, i1 false)
  %t61 = insertvalue { i64, ptr } undef, i64 %t57, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t44, { i64, ptr } %t62)
  br label %bb9
bb8:
  br label %bb10
bb9:
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb11:
  %t65 = load ptr, ptr %l0, !tbaa !29
  %t67 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 2
  %t68 = getelementptr %"compiler/target:Target", ptr %t67, i32 0, i32 6
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t69, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d83, i32 0, i32 1) })
  store i1 %t71, ptr %l21
  br label %bb12
bb12:
  %t72 = load i1, ptr %l21, !tbaa !21
  %t73 = xor i1 %t72, true
  br i1 %t73, label %bb13, label %bb14
bb13:
  %t75 = load ptr, ptr %lp1
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t78 = getelementptr %"compiler/build:Config", ptr %t76, i32 0, i32 2
  %t79 = getelementptr %"compiler/target:Target", ptr %t78, i32 0, i32 6
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = extractvalue { i64, ptr } %t80, 1
  %t83 = extractvalue { i64, ptr } %t80, 0
  %t84 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t83)
  call void @olang_textcopy(ptr %t84, ptr %t82, i64 %t83)
  %t85 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = extractvalue { i64, ptr } %t86, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t75, { i64, ptr } %t93)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  %t96 = load ptr, ptr %l0, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 9
  %t99 = load i1, ptr %t98, !tbaa !21
  br i1 %t99, label %bb17, label %bb18
bb17:
  %t101 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t101, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d84, i32 0, i32 1) })
  br label %bb19
bb18:
  br label %bb20
bb19:
  br label %bb20
bb20:
  %t103 = load ptr, ptr %l0, !tbaa !29
  %t105 = getelementptr %"compiler/build:Config", ptr %t103, i32 0, i32 10
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t106, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d85, i32 0, i32 1) })
  store i1 %t108, ptr %l33
  br label %bb21
bb21:
  %t109 = load i1, ptr %l33, !tbaa !21
  %t110 = xor i1 %t109, true
  br i1 %t110, label %bb22, label %bb23
bb22:
  %t112 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t112, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d86, i32 0, i32 1) })
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t114 = load ptr, ptr %l0, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 4
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb26, label %bb27
bb26:
  %t119 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t119, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d87, i32 0, i32 1) })
  br label %bb28
bb27:
  br label %bb34
bb28:
  %t121 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t121, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d88, i32 0, i32 1) })
  br label %bb29
bb29:
  %t123 = load ptr, ptr %l0, !tbaa !29
  %t125 = getelementptr %"compiler/build:Config", ptr %t123, i32 0, i32 6
  %t126 = load i1, ptr %t125, !tbaa !21
  br i1 %t126, label %bb30, label %bb31
bb30:
  %t128 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t128, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d89, i32 0, i32 1) })
  br label %bb32
bb31:
  br label %bb33
bb32:
  br label %bb33
bb33:
  %t130 = load ptr, ptr %lp1
  %t131 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t130
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t131, ptr %rv
  br label %ret
bb34:
  %t133 = load ptr, ptr %l0, !tbaa !29
  %t135 = getelementptr %"compiler/build:Config", ptr %t133, i32 0, i32 6
  %t136 = load i1, ptr %t135, !tbaa !21
  br i1 %t136, label %bb35, label %bb36
bb35:
  %t138 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t138, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d90, i32 0, i32 1) })
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t140 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t140, { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d91, i32 0, i32 1) })
  br label %bb38
bb38:
  %t142 = load ptr, ptr %lp1
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t142
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %rv
  br label %ret
bb39:
  %t145 = load ptr, ptr %l0, !tbaa !29
  %t147 = getelementptr %"compiler/build:Config", ptr %t145, i32 0, i32 5
  %t148 = load i1, ptr %t147, !tbaa !21
  br i1 %t148, label %bb40, label %bb41
bb40:
  %t150 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t150, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d92, i32 0, i32 1) })
  br label %bb42
bb41:
  br label %bb43
bb42:
  %t152 = load ptr, ptr %lp1
  %t153 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t152
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t153, ptr %rv
  br label %ret
bb43:
  %t155 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t155, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d93, i32 0, i32 1) })
  br label %bb44
bb44:
  %t157 = load ptr, ptr %l0, !tbaa !29
  %t159 = getelementptr %"compiler/build:Config", ptr %t157, i32 0, i32 25
  %t160 = load i1, ptr %t159, !tbaa !21
  br i1 %t160, label %bb45, label %bb46
bb45:
  %t162 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t162, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d94, i32 0, i32 1) })
  br label %bb47
bb46:
  %t164 = load ptr, ptr %lp1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t164, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d95, i32 0, i32 1) })
  br label %bb48
bb47:
  br label %bb49
bb48:
  br label %bb49
bb49:
  %t166 = load ptr, ptr %lp1
  %t167 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t166
  call void @__olang_scope_close(ptr %s0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t167, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca ptr
  %l7 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca i64
  %l16 = alloca i64
  %l21 = alloca { i64, ptr }
  %l26 = alloca ptr
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l34 = alloca i64
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l10
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l5
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v2, ptr %l5, { i64, ptr } %a3)
  br label %bb2
bb2:
  store ptr %a4, ptr %l6, !tbaa !29
  store i64 0, ptr %l7, !tbaa !24
  br label %bb3
bb3:
  %t8 = load i64, ptr %l7, !tbaa !24
  store i64 %t8, ptr %l14, !tbaa !24
  %t9 = load ptr, ptr %l6, !tbaa !29
  %t11 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v3, ptr %t9)
  store i64 %t11, ptr %l16
  br label %bb4
bb4:
  %t12 = load i64, ptr %l14, !tbaa !24
  %t13 = load i64, ptr %l16, !tbaa !24
  %t14 = icmp slt i64 %t12, %t13
  %t16 = xor i1 %t14, true
  br i1 %t16, label %bb5, label %bb6
bb5:
  br label %bb11
bb6:
  br label %bb7
bb7:
  %t18 = load ptr, ptr %l6, !tbaa !29
  %t19 = load i64, ptr %l7, !tbaa !24
  %t22 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %v3, ptr %t18, i64 %t19)
  store { i64, ptr } %t22, ptr %l21
  br label %bb8
bb8:
  %t23 = load { i64, ptr }, ptr %l21, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v3, ptr %l5, { i64, ptr } %t23)
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t27 = load i64, ptr %l7, !tbaa !24
  %t29 = add i64 %t27, 1
  store i64 %t29, ptr %l7, !tbaa !24
  br label %bb3
bb11:
  store ptr %l5, ptr %l26, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  %t33 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t31)
  store { i64, ptr } %t33, ptr %l28
  br label %bb12
bb12:
  %t34 = load ptr, ptr %l26, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l28, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t34, { i64, ptr } %t35)
  br label %bb13
bb13:
  %t37 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t37, ptr %l30
  br label %bb14
bb14:
  %t38 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t38, ptr %l9, !tbaa !27
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t41 = getelementptr %"compiler/build:Config", ptr %t39, i32 0, i32 0
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  store { i64, ptr } %t42, ptr %l32, !tbaa !27
  store { i64, ptr } %a1, ptr %l33, !tbaa !27
  %t44 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t44, 0
  store i64 %t45, ptr %l34, !tbaa !24
  %t46 = icmp sge i64 0, 0
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = icmp sle i64 0, 16
  br i1 %t48, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb17:
  %t50 = load i64, ptr %l34, !tbaa !24
  %t51 = icmp sle i64 16, %t50
  br i1 %t51, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb19:
  %t53 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t54 = load ptr, ptr %t53, !tbaa !27
  %t55 = getelementptr i8, ptr %t54, i64 0
  %t56 = sub i64 16, 0
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  store { i64, ptr } %t58, ptr %l38, !tbaa !27
  %t61 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %a2)
  store { i64, ptr } %t61, ptr %l40
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_4cf283899a273ea5_54dbe84ebef87a69)
  unreachable
bb21:
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t62)
  store { i64, ptr } %t64, ptr %l42
  br label %bb22
bb22:
  %t65 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t66 = extractvalue { i64, ptr } %t65, 1
  %t67 = extractvalue { i64, ptr } %t65, 0
  %t68 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 1
  %t69 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d96, i32 0, i32 1) }, 0
  %t70 = add i64 %t67, %t69
  %t71 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = add i64 %t70, %t73
  %t75 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 1
  %t76 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d97, i32 0, i32 1) }, 0
  %t77 = add i64 %t74, %t76
  %t78 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t78, 1
  %t80 = extractvalue { i64, ptr } %t78, 0
  %t81 = add i64 %t77, %t80
  %t82 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = add i64 %t81, %t84
  %t86 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t87 = extractvalue { i64, ptr } %t86, 1
  %t88 = extractvalue { i64, ptr } %t86, 0
  %t89 = add i64 %t85, %t88
  %t90 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d98, i32 0, i32 1) }, 1
  %t91 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d98, i32 0, i32 1) }, 0
  %t92 = add i64 %t89, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t66, i64 %t67)
  %t94 = getelementptr i8, ptr %t93, i64 %t67
  call void @olang_textcopy(ptr %t94, ptr %t68, i64 %t69)
  %t95 = getelementptr i8, ptr %t94, i64 %t69
  call void @olang_textcopy(ptr %t95, ptr %t72, i64 %t73)
  %t96 = getelementptr i8, ptr %t95, i64 %t73
  call void @olang_textcopy(ptr %t96, ptr %t75, i64 %t76)
  %t97 = getelementptr i8, ptr %t96, i64 %t76
  call void @olang_textcopy(ptr %t97, ptr %t79, i64 %t80)
  %t98 = getelementptr i8, ptr %t97, i64 %t80
  call void @olang_textcopy(ptr %t98, ptr %t83, i64 %t84)
  %t99 = getelementptr i8, ptr %t98, i64 %t84
  call void @olang_textcopy(ptr %t99, ptr %t87, i64 %t88)
  %t100 = getelementptr i8, ptr %t99, i64 %t88
  call void @olang_textcopy(ptr %t100, ptr %t90, i64 %t91)
  %t101 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t93, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t102, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"compiler/build:Unit"
  %l7 = alloca %"compiler/build:compiles"
  %lp8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/build:Unit"
  %l13 = alloca i64
  %l14 = alloca %"compiler/build:compiles"
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"compiler/build:Unit"
  %l22 = alloca i64
  %l24 = alloca i64
  %l29 = alloca %"compiler/build:Unit"
  %l36 = alloca ptr
  %l40 = alloca i1
  %l44 = alloca i1
  %l48 = alloca i1
  %l52 = alloca %"compiler/build:compiles"
  %l53 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l56 = alloca i64
  %l58 = alloca i64
  %l64 = alloca %"compiler/build:Unit"
  %l65 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l70 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca i32
  %l85 = alloca i64
  %l88 = alloca i1
  %l90 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l99 = alloca { i64, ptr }
  %l100 = alloca i32
  %l105 = alloca i1
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i32
  %l124 = alloca i32
  %l127 = alloca i64
  %l129 = alloca %"compiler/build:compiles"
  %l131 = alloca i64
  %l133 = alloca i64
  %l138 = alloca i64
  %l143 = alloca i1
  %l146 = alloca i1
  %l148 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l156 = alloca i1
  %l158 = alloca i1
  %l162 = alloca i1
  %l164 = alloca i32
  %l166 = alloca i1
  %l173 = alloca %"compiler/build:Unit"
  %l174 = alloca { i64, ptr }
  %l175 = alloca ptr
  %l176 = alloca ptr
  %l178 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l185 = alloca i32
  %l190 = alloca { i64, ptr }
  %l197 = alloca { i64, ptr }
  %l198 = alloca i32
  %l200 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca i32
  %l215 = alloca i32
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
  %t67 = alloca %"compiler/build:compiles", align 8
  %t284 = alloca %"compiler/build:compiles", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l4, !tbaa !29
  store i64 0, ptr %l5, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l5, !tbaa !24
  store i64 %t5, ptr %l22, !tbaa !24
  %t6 = load ptr, ptr %l4, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t6)
  store i64 %t8, ptr %l24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l22, !tbaa !24
  %t10 = load i64, ptr %l24, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l4, !tbaa !29
  %t16 = load i64, ptr %l5, !tbaa !24
  %t19 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t15, i64 %t16)
  store %"compiler/build:Unit" %t19, ptr %l29
  br label %bb6
bb6:
  %t20 = load %"compiler/build:Unit", ptr %l29
  store %"compiler/build:Unit" %t20, ptr %l6
  %t21 = load i64, ptr %l3, !tbaa !24
  %t22 = getelementptr %"compiler/build:Unit", ptr %l6, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t28 = add i64 %t21, %t25
  store i64 %t28, ptr %l3, !tbaa !24
  br label %bb7
bb7:
  %t30 = load i64, ptr %l5, !tbaa !24
  %t32 = add i64 %t30, 1
  store i64 %t32, ptr %l5, !tbaa !24
  br label %bb1
bb8:
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l36, !tbaa !29
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 4
  %t38 = load i1, ptr %t37, !tbaa !21
  %t40 = xor i1 %t38, true
  br i1 %t40, label %bb9, label %bb10
bb9:
  %t42 = load ptr, ptr %l0, !tbaa !29
  %t44 = getelementptr %"compiler/build:Config", ptr %t42, i32 0, i32 6
  %t45 = load i1, ptr %t44, !tbaa !21
  %t47 = xor i1 %t45, true
  store i1 %t47, ptr %l40, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l40, !tbaa !21
  br label %bb11
bb11:
  %t49 = load i1, ptr %l40, !tbaa !21
  br i1 %t49, label %bb12, label %bb13
bb12:
  %t50 = load ptr, ptr %l0, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 5
  %t53 = load i1, ptr %t52, !tbaa !21
  %t55 = xor i1 %t53, true
  store i1 %t55, ptr %l44, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t57 = load i1, ptr %l44, !tbaa !21
  br i1 %t57, label %bb15, label %bb16
bb15:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr @G_2ecompiler_2fbuild_2eThinFrom, !tbaa !24
  %t62 = icmp sge i64 %t58, %t59
  store i1 %t62, ptr %l48, !tbaa !21
  br label %bb17
bb16:
  store i1 false, ptr %l48, !tbaa !21
  br label %bb17
bb17:
  %t64 = load i1, ptr %l48, !tbaa !21
  %t65 = load ptr, ptr %l36, !tbaa !29
  %t66 = getelementptr %"compiler/build:Config", ptr %t65, i32 0, i32 25
  store i1 %t64, ptr %t66, !tbaa !21
  call void @compiler_2fbuild_3acompiles_2ector(ptr %t67, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l52, ptr %t67, i64 288, i1 false)
  br label %bb18
bb18:
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %l52, i64 288, i1 false)
  %t68 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t68, ptr %l53
  br label %bb19
bb19:
  %t69 = call ptr @__olang_scope_alloc_a(ptr %v3, i64 32, i64 8)
  store ptr %t69, ptr %lp8
  %t70 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l53
  %t71 = load ptr, ptr %lp8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t70, ptr %t71
  %t72 = load ptr, ptr %l1, !tbaa !29
  %t74 = getelementptr %"compiler/build:Program", ptr %t72, i32 0, i32 0
  store ptr %t74, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  %t76 = load i64, ptr %l10, !tbaa !24
  store i64 %t76, ptr %l56, !tbaa !24
  %t77 = load ptr, ptr %l9, !tbaa !29
  %t79 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t77)
  store i64 %t79, ptr %l58
  br label %bb21
bb21:
  %t80 = load i64, ptr %l56, !tbaa !24
  %t81 = load i64, ptr %l58, !tbaa !24
  %t82 = icmp slt i64 %t80, %t81
  %t84 = xor i1 %t82, true
  br i1 %t84, label %bb22, label %bb23
bb22:
  br label %bb32
bb23:
  br label %bb24
bb24:
  %t86 = load i64, ptr %l10, !tbaa !24
  store i64 %t86, ptr %l11, !tbaa !24
  %t88 = load ptr, ptr %l9, !tbaa !29
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t88, i64 %t89)
  store %"compiler/build:Unit" %t92, ptr %l64
  br label %bb25
bb25:
  %t93 = load %"compiler/build:Unit", ptr %l64
  store %"compiler/build:Unit" %t93, ptr %l12
  %t94 = load ptr, ptr %lp8
  store ptr %t94, ptr %l65, !tbaa !29
  %t95 = load ptr, ptr %l0, !tbaa !29
  store ptr %t95, ptr %l67, !tbaa !29
  store ptr %l7, ptr %l68, !tbaa !29
  %t96 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 0
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %v3, { i64, ptr } %t97)
  store { i64, ptr } %t99, ptr %l70
  br label %bb26
bb26:
  %t100 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t107 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 1
  %t108 = load i32, ptr %t107, !range !{i32 0, i32 5}
  %t109 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t111 = load ptr, ptr %l2, !tbaa !29
  %t112 = getelementptr %"compiler/build:Unit", ptr %l12, i32 0, i32 3
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t114 = load i64, ptr %l11, !tbaa !24
  %t115 = load ptr, ptr %l67, !tbaa !29
  %t116 = load ptr, ptr %l68, !tbaa !29
  %t123 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v1, ptr %v3, ptr %t115, ptr %t116, { i64, ptr } %t106, i32 %t108, { i64, ptr } %t110, ptr %t111, { i64, ptr } %t113, i64 %t114)
  %t124 = extractvalue { i32, { i64, ptr } } %t123, 1
  %t125 = extractvalue { i32, { i64, ptr } } %t123, 0
  store i32 %t125, ptr %l78
  %t126 = icmp ne i32 %t125, 0
  br i1 %t126, label %bb28, label %ok.127, !prof !99
ok.127:
  store { i64, ptr } %t124, ptr %l77
  br label %bb27
bb27:
  %t128 = load { i64, ptr }, ptr %l77, !tbaa !27
  store { i64, ptr } %t128, ptr %l66, !tbaa !27
  br label %bb29
bb28:
  %t129 = load i32, ptr %l78, !tbaa !23
  %t130 = lshr i32 %t129, 16
  %t131 = and i32 %t129, 65535
  %t132 = icmp eq i32 %t130, 1
  %t133 = select i1 %t132, i32 1, i32 0
  %t134 = icmp eq i32 %t129, 0
  %t135 = shl i32 %t133, 16
  %t136 = or i32 %t135, %t131
  %t137 = select i1 %t134, i32 0, i32 %t136
  call void @__olang_scope_close(ptr %s0)
  %t139 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t137, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t139, ptr %rv
  br label %ret
bb29:
  %t140 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 0
  %t142 = extractvalue { i64, ptr } %t140, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  %t147 = load ptr, ptr %l65, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t147, { i64, ptr } %t146)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t149 = load i64, ptr %l10, !tbaa !24
  %t151 = add i64 %t149, 1
  store i64 %t151, ptr %l10, !tbaa !24
  br label %bb20
bb32:
  %t153 = load ptr, ptr %l1, !tbaa !29
  %t155 = getelementptr %"compiler/build:Program", ptr %t153, i32 0, i32 0
  %t157 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t155)
  store i64 %t157, ptr %l85
  br label %bb33
bb33:
  %t158 = load i64, ptr %l85, !tbaa !24
  store i64 %t158, ptr %l13, !tbaa !24
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = getelementptr %"compiler/build:Program", ptr %t159, i32 0, i32 1
  %t162 = load { i64, ptr }, ptr %t161, !tbaa !27
  %t164 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t162, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d99, i32 0, i32 1) })
  store i1 %t164, ptr %l88
  br label %bb34
bb34:
  %t165 = load i1, ptr %l88, !tbaa !21
  %t166 = xor i1 %t165, true
  br i1 %t166, label %bb35, label %bb36
bb35:
  %t168 = load ptr, ptr %lp8
  store ptr %t168, ptr %l90, !tbaa !29
  %t169 = load ptr, ptr %l0, !tbaa !29
  %t170 = load ptr, ptr %l1, !tbaa !29
  %t172 = getelementptr %"compiler/build:Program", ptr %t170, i32 0, i32 1
  %t173 = load { i64, ptr }, ptr %t172, !tbaa !27
  %t174 = load ptr, ptr %l2, !tbaa !29
  %t175 = load i64, ptr %l13, !tbaa !24
  %t182 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t169, ptr %l7, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d100, i32 0, i32 1) }, i32 0, { i64, ptr } %t173, ptr %t174, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d101, i32 0, i32 1) }, i64 %t175)
  %t183 = extractvalue { i32, { i64, ptr } } %t182, 1
  %t184 = extractvalue { i32, { i64, ptr } } %t182, 0
  store i32 %t184, ptr %l100
  %t185 = icmp ne i32 %t184, 0
  br i1 %t185, label %bb38, label %ok.186, !prof !99
ok.186:
  store { i64, ptr } %t183, ptr %l99
  br label %bb37
bb36:
  br label %bb41
bb37:
  %t187 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t187, ptr %l91, !tbaa !27
  br label %bb39
bb38:
  %t188 = load i32, ptr %l100, !tbaa !23
  %t189 = lshr i32 %t188, 16
  %t190 = and i32 %t188, 65535
  %t191 = icmp eq i32 %t189, 1
  %t192 = select i1 %t191, i32 1, i32 0
  %t193 = icmp eq i32 %t188, 0
  %t194 = shl i32 %t192, 16
  %t195 = or i32 %t194, %t190
  %t196 = select i1 %t193, i32 0, i32 %t195
  call void @__olang_scope_close(ptr %s0)
  %t198 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t196, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t198, ptr %rv
  br label %ret
bb39:
  %t199 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 0
  %t201 = extractvalue { i64, ptr } %t199, 1
  %t202 = mul i64 %t200, 1
  %t203 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t202)
  call void @llvm.memcpy.p0.p0.i64(ptr %t203, ptr %t201, i64 %t202, i1 false)
  %t204 = insertvalue { i64, ptr } undef, i64 %t200, 0
  %t205 = insertvalue { i64, ptr } %t204, ptr %t203, 1
  %t206 = load ptr, ptr %l90, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t206, { i64, ptr } %t205)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/build:Program", ptr %t208, i32 0, i32 2
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t213 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t211, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d102, i32 0, i32 1) })
  store i1 %t213, ptr %l105
  br label %bb42
bb42:
  %t214 = load i1, ptr %l105, !tbaa !21
  %t215 = xor i1 %t214, true
  br i1 %t215, label %bb43, label %bb44
bb43:
  %t217 = load ptr, ptr %lp8
  store ptr %t217, ptr %l107, !tbaa !29
  %t218 = load ptr, ptr %l0, !tbaa !29
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/build:Program", ptr %t219, i32 0, i32 2
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t223 = load ptr, ptr %l2, !tbaa !29
  %t224 = load i64, ptr %l13, !tbaa !24
  %t226 = add i64 %t224, 1
  %t233 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s0, ptr %v3, ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t218, ptr %l7, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d103, i32 0, i32 1) }, i32 0, { i64, ptr } %t222, ptr %t223, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d104, i32 0, i32 1) }, i64 %t226)
  %t234 = extractvalue { i32, { i64, ptr } } %t233, 1
  %t235 = extractvalue { i32, { i64, ptr } } %t233, 0
  store i32 %t235, ptr %l118
  %t236 = icmp ne i32 %t235, 0
  br i1 %t236, label %bb46, label %ok.237, !prof !99
ok.237:
  store { i64, ptr } %t234, ptr %l117
  br label %bb45
bb44:
  br label %bb49
bb45:
  %t238 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t238, ptr %l108, !tbaa !27
  br label %bb47
bb46:
  %t239 = load i32, ptr %l118, !tbaa !23
  %t240 = lshr i32 %t239, 16
  %t241 = and i32 %t239, 65535
  %t242 = icmp eq i32 %t240, 1
  %t243 = select i1 %t242, i32 1, i32 0
  %t244 = icmp eq i32 %t239, 0
  %t245 = shl i32 %t243, 16
  %t246 = or i32 %t245, %t241
  %t247 = select i1 %t244, i32 0, i32 %t246
  call void @__olang_scope_close(ptr %s0)
  %t249 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t247, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t249, ptr %rv
  br label %ret
bb47:
  %t250 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load ptr, ptr %l107, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v3, ptr %v3, ptr %t257, { i64, ptr } %t256)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t259 = load ptr, ptr %l0, !tbaa !29
  %t260 = load ptr, ptr %l2, !tbaa !29
  %t264 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %s0, ptr %v2, ptr %t259, ptr %l7, ptr %t260)
  store i32 %t264, ptr %l124
  %t265 = icmp ne i32 %t264, 0
  br i1 %t265, label %bb51, label %ok.266, !prof !99
ok.266:
  br label %bb50
bb50:
  br label %bb52
bb51:
  %t267 = load i32, ptr %l124, !tbaa !23
  %t268 = lshr i32 %t267, 16
  %t269 = and i32 %t267, 65535
  %t270 = icmp eq i32 %t268, 1
  %t271 = select i1 %t270, i32 1, i32 0
  %t272 = icmp eq i32 %t267, 0
  %t273 = shl i32 %t271, 16
  %t274 = or i32 %t273, %t269
  %t275 = select i1 %t272, i32 0, i32 %t274
  call void @__olang_scope_close(ptr %s0)
  %t277 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t275, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t277, ptr %rv
  br label %ret
bb52:
  %t278 = getelementptr %"compiler/build:compiles", ptr %l7, i32 0, i32 8
  %t280 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t278)
  store i64 %t280, ptr %l127
  br label %bb53
bb53:
  %t281 = load i64, ptr %l127, !tbaa !24
  %t282 = icmp sgt i64 %t281, 0
  br i1 %t282, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s9
  call void @compiler_2fbuild_3acompiles_2ector(ptr %t284, ptr %s9)
  call void @llvm.memmove.p0.p0.i64(ptr %l129, ptr %t284, i64 288, i1 false)
  br label %bb56
bb55:
  br label %bb110
bb56:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l129, i64 288, i1 false)
  %t285 = getelementptr %"compiler/build:compiles", ptr %l7, i32 0, i32 8
  store ptr %t285, ptr %l15, !tbaa !29
  store i64 0, ptr %l16, !tbaa !24
  br label %bb57
bb57:
  store %olang.scope zeroinitializer, ptr %s11
  %t287 = load i64, ptr %l16, !tbaa !24
  store i64 %t287, ptr %l131, !tbaa !24
  %t288 = load ptr, ptr %l15, !tbaa !29
  %t290 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %s0, ptr %t288)
  store i64 %t290, ptr %l133
  br label %bb58
bb58:
  %t291 = load i64, ptr %l131, !tbaa !24
  %t292 = load i64, ptr %l133, !tbaa !24
  %t293 = icmp slt i64 %t291, %t292
  %t295 = xor i1 %t293, true
  br i1 %t295, label %bb59, label %bb60
bb59:
  call void @__olang_scope_close(ptr %s11)
  br label %bb106
bb60:
  br label %bb61
bb61:
  %t297 = load ptr, ptr %l15, !tbaa !29
  %t298 = load i64, ptr %l16, !tbaa !24
  %t301 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %s0, ptr %t297, i64 %t298)
  store i64 %t301, ptr %l138
  br label %bb62
bb62:
  %t302 = load i64, ptr %l138, !tbaa !24
  store i64 %t302, ptr %l17, !tbaa !24
  %t303 = load i64, ptr %l17, !tbaa !24
  %t304 = load i64, ptr %l13, !tbaa !24
  %t306 = add i64 %t304, 1
  %t309 = icmp slt i64 %t303, %t306
  br i1 %t309, label %bb63, label %bb64
bb63:
  store i1 true, ptr %l143, !tbaa !21
  br label %bb66
bb64:
  %t311 = load ptr, ptr %l1, !tbaa !29
  %t313 = getelementptr %"compiler/build:Program", ptr %t311, i32 0, i32 1
  %t314 = load { i64, ptr }, ptr %t313, !tbaa !27
  %t316 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s11, { i64, ptr } %t314, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d105, i32 0, i32 1) })
  store i1 %t316, ptr %l146
  br label %bb65
bb65:
  %t317 = load i1, ptr %l146, !tbaa !21
  %t318 = xor i1 %t317, true
  store i1 %t318, ptr %l143, !tbaa !21
  br label %bb66
bb66:
  %t320 = load i1, ptr %l143, !tbaa !21
  br i1 %t320, label %bb67, label %bb68
bb67:
  %t321 = load ptr, ptr %lp8
  %t322 = load i64, ptr %l17, !tbaa !24
  %t325 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s11, ptr %t321, i64 %t322)
  store { i64, ptr } %t325, ptr %l151
  br label %bb69
bb68:
  %t326 = load ptr, ptr %lp8
  %t327 = load i64, ptr %l13, !tbaa !24
  %t330 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v3, ptr %s11, ptr %t326, i64 %t327)
  store { i64, ptr } %t330, ptr %l154
  br label %bb70
bb69:
  %t331 = load { i64, ptr }, ptr %l151, !tbaa !27
  store { i64, ptr } %t331, ptr %l148, !tbaa !27
  br label %bb71
bb70:
  %t332 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t332, ptr %l148, !tbaa !27
  br label %bb71
bb71:
  %t333 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t333, ptr %l18, !tbaa !27
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s12
  %t334 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t336 = call i1 @std_2fos_2eExists(ptr %s11, { i64, ptr } %t334)
  store i1 %t336, ptr %l156
  br label %bb73
bb73:
  %t337 = load i1, ptr %l156, !tbaa !21
  %t338 = xor i1 %t337, true
  br i1 %t338, label %bb74, label %bb75
bb74:
  %t340 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t340, 1
  %t343 = extractvalue { i64, ptr } %t340, 0
  %t344 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d106, i32 0, i32 1) }, 1
  %t345 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d106, i32 0, i32 1) }, 0
  %t346 = add i64 %t343, %t345
  %t347 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t346)
  call void @olang_textcopy(ptr %t347, ptr %t342, i64 %t343)
  %t348 = getelementptr i8, ptr %t347, i64 %t343
  call void @olang_textcopy(ptr %t348, ptr %t344, i64 %t345)
  %t349 = insertvalue { i64, ptr } undef, i64 %t346, 0
  %t350 = insertvalue { i64, ptr } %t349, ptr %t347, 1
  %t352 = extractvalue { i64, ptr } %t350, 0
  %t353 = extractvalue { i64, ptr } %t350, 1
  %t354 = mul i64 %t352, 1
  %t355 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t354)
  call void @llvm.memcpy.p0.p0.i64(ptr %t355, ptr %t353, i64 %t354, i1 false)
  %t356 = insertvalue { i64, ptr } undef, i64 %t352, 0
  %t357 = insertvalue { i64, ptr } %t356, ptr %t355, 1
  %t359 = call i1 @compiler_2fbuild_2eholderAlive(ptr %s12, { i64, ptr } %t357)
  store i1 %t359, ptr %l162
  br label %bb76
bb75:
  store i1 false, ptr %l158, !tbaa !21
  br label %bb77
bb76:
  %t360 = load i1, ptr %l162, !tbaa !21
  store i1 %t360, ptr %l158, !tbaa !21
  br label %bb77
bb77:
  %t361 = load i1, ptr %l158, !tbaa !21
  %t362 = xor i1 %t361, true
  br i1 %t362, label %bb78, label %bb79
bb78:
  call void @__olang_scope_close(ptr %s12)
  br label %bb83
bb79:
  br label %bb80
bb80:
  %t364 = call i32 @usleep(i32 20000)
  store i32 %t364, ptr %l164
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s12)
  br label %bb82
bb82:
  br label %bb72
bb83:
  %t365 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t367 = call i1 @std_2fos_2eExists(ptr %s11, { i64, ptr } %t365)
  store i1 %t367, ptr %l166
  br label %bb84
bb84:
  %t368 = load i1, ptr %l166, !tbaa !21
  br i1 %t368, label %bb85, label %bb86
bb85:
  call void @__olang_scope_close(ptr %s11)
  br label %bb105
bb86:
  br label %bb87
bb87:
  %t369 = load i64, ptr %l17, !tbaa !24
  %t370 = load i64, ptr %l13, !tbaa !24
  %t373 = icmp slt i64 %t369, %t370
  br i1 %t373, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s15
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr %"compiler/build:Program", ptr %t375, i32 0, i32 0
  %t378 = load i64, ptr %l17, !tbaa !24
  %t381 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t377, i64 %t378)
  store %"compiler/build:Unit" %t381, ptr %l173
  br label %bb90
bb89:
  %t382 = load i64, ptr %l17, !tbaa !24
  %t383 = load i64, ptr %l13, !tbaa !24
  %t386 = icmp eq i64 %t382, %t383
  br i1 %t386, label %bb95, label %bb96
bb90:
  %t388 = load %"compiler/build:Unit", ptr %l173
  store %"compiler/build:Unit" %t388, ptr %l19
  %t389 = load ptr, ptr %l0, !tbaa !29
  store ptr %t389, ptr %l175, !tbaa !29
  store ptr %l14, ptr %l176, !tbaa !29
  %t390 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 0
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !27
  %t393 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v1, ptr %s15, { i64, ptr } %t391)
  store { i64, ptr } %t393, ptr %l178
  br label %bb91
bb91:
  %t394 = load { i64, ptr }, ptr %l178, !tbaa !27
  %t395 = extractvalue { i64, ptr } %t394, 0
  %t396 = extractvalue { i64, ptr } %t394, 1
  %t397 = mul i64 %t395, 1
  %t398 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t397)
  call void @llvm.memcpy.p0.p0.i64(ptr %t398, ptr %t396, i64 %t397, i1 false)
  %t399 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t400 = insertvalue { i64, ptr } %t399, ptr %t398, 1
  %t401 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 1
  %t402 = load i32, ptr %t401, !range !{i32 0, i32 5}
  %t403 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 2
  %t404 = load { i64, ptr }, ptr %t403, !tbaa !27
  %t405 = load ptr, ptr %l2, !tbaa !29
  %t406 = getelementptr %"compiler/build:Unit", ptr %l19, i32 0, i32 3
  %t407 = load { i64, ptr }, ptr %t406, !tbaa !27
  %t408 = load ptr, ptr %l175, !tbaa !29
  %t409 = load ptr, ptr %l176, !tbaa !29
  %t415 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s9, ptr %s15, ptr %v1, ptr %v2, ptr %v1, ptr %s15, ptr %t408, ptr %t409, { i64, ptr } %t400, i32 %t402, { i64, ptr } %t404, ptr %t405, { i64, ptr } %t407, i64 -1)
  %t416 = extractvalue { i32, { i64, ptr } } %t415, 1
  %t417 = extractvalue { i32, { i64, ptr } } %t415, 0
  store i32 %t417, ptr %l185
  %t418 = icmp ne i32 %t417, 0
  br i1 %t418, label %bb93, label %ok.419, !prof !99
ok.419:
  store { i64, ptr } %t416, ptr %l184
  br label %bb92
bb92:
  %t420 = load { i64, ptr }, ptr %l184, !tbaa !27
  store { i64, ptr } %t420, ptr %l174, !tbaa !27
  br label %bb94
bb93:
  %t421 = load i32, ptr %l185, !tbaa !23
  %t422 = lshr i32 %t421, 16
  %t423 = and i32 %t421, 65535
  %t424 = icmp eq i32 %t422, 1
  %t425 = select i1 %t424, i32 1, i32 0
  %t426 = icmp eq i32 %t421, 0
  %t427 = shl i32 %t425, 16
  %t428 = or i32 %t427, %t423
  %t429 = select i1 %t426, i32 0, i32 %t428
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t431 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t429, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t431, ptr %rv
  br label %ret
bb94:
  call void @__olang_scope_close(ptr %s15)
  br label %bb104
bb95:
  store %olang.scope zeroinitializer, ptr %s17
  %t432 = load ptr, ptr %l0, !tbaa !29
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t435 = getelementptr %"compiler/build:Program", ptr %t433, i32 0, i32 1
  %t436 = load { i64, ptr }, ptr %t435, !tbaa !27
  %t437 = load ptr, ptr %l2, !tbaa !29
  %t443 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s9, ptr %s17, ptr %v1, ptr %v2, ptr %s17, ptr %s17, ptr %t432, ptr %l14, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d107, i32 0, i32 1) }, i32 0, { i64, ptr } %t436, ptr %t437, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) }, i64 -1)
  %t444 = extractvalue { i32, { i64, ptr } } %t443, 1
  %t445 = extractvalue { i32, { i64, ptr } } %t443, 0
  store i32 %t445, ptr %l198
  %t446 = icmp ne i32 %t445, 0
  br i1 %t446, label %bb98, label %ok.447, !prof !99
ok.447:
  store { i64, ptr } %t444, ptr %l197
  br label %bb97
bb96:
  store %olang.scope zeroinitializer, ptr %s18
  %t448 = load ptr, ptr %l0, !tbaa !29
  %t449 = load ptr, ptr %l1, !tbaa !29
  %t451 = getelementptr %"compiler/build:Program", ptr %t449, i32 0, i32 2
  %t452 = load { i64, ptr }, ptr %t451, !tbaa !27
  %t453 = load ptr, ptr %l2, !tbaa !29
  %t459 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %s9, ptr %s18, ptr %v1, ptr %v2, ptr %s18, ptr %s18, ptr %t448, ptr %l14, { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d109, i32 0, i32 1) }, i32 0, { i64, ptr } %t452, ptr %t453, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d108, i32 0, i32 1) }, i64 -1)
  %t460 = extractvalue { i32, { i64, ptr } } %t459, 1
  %t461 = extractvalue { i32, { i64, ptr } } %t459, 0
  store i32 %t461, ptr %l208
  %t462 = icmp ne i32 %t461, 0
  br i1 %t462, label %bb101, label %ok.463, !prof !99
ok.463:
  store { i64, ptr } %t460, ptr %l207
  br label %bb100
bb97:
  %t464 = load { i64, ptr }, ptr %l197, !tbaa !27
  store { i64, ptr } %t464, ptr %l190, !tbaa !27
  br label %bb99
bb98:
  %t465 = load i32, ptr %l198, !tbaa !23
  %t466 = lshr i32 %t465, 16
  %t467 = and i32 %t465, 65535
  %t468 = icmp eq i32 %t466, 1
  %t469 = select i1 %t468, i32 1, i32 0
  %t470 = icmp eq i32 %t465, 0
  %t471 = shl i32 %t469, 16
  %t472 = or i32 %t471, %t467
  %t473 = select i1 %t470, i32 0, i32 %t472
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t475 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t473, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t475, ptr %rv
  br label %ret
bb99:
  call void @__olang_scope_close(ptr %s17)
  br label %bb103
bb100:
  %t476 = load { i64, ptr }, ptr %l207, !tbaa !27
  store { i64, ptr } %t476, ptr %l200, !tbaa !27
  br label %bb102
bb101:
  %t477 = load i32, ptr %l208, !tbaa !23
  %t478 = lshr i32 %t477, 16
  %t479 = and i32 %t477, 65535
  %t480 = icmp eq i32 %t478, 1
  %t481 = select i1 %t480, i32 1, i32 0
  %t482 = icmp eq i32 %t477, 0
  %t483 = shl i32 %t481, 16
  %t484 = or i32 %t483, %t479
  %t485 = select i1 %t482, i32 0, i32 %t484
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t487 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t485, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t487, ptr %rv
  br label %ret
bb102:
  call void @__olang_scope_close(ptr %s18)
  br label %bb103
bb103:
  br label %bb104
bb104:
  call void @__olang_scope_close(ptr %s11)
  br label %bb105
bb105:
  %t488 = load i64, ptr %l16, !tbaa !24
  %t490 = add i64 %t488, 1
  store i64 %t490, ptr %l16, !tbaa !24
  br label %bb57
bb106:
  %t492 = load ptr, ptr %l0, !tbaa !29
  %t493 = load ptr, ptr %l2, !tbaa !29
  %t497 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %s9, ptr %v2, ptr %t492, ptr %l14, ptr %t493)
  store i32 %t497, ptr %l215
  %t498 = icmp ne i32 %t497, 0
  br i1 %t498, label %bb108, label %ok.499, !prof !99
ok.499:
  br label %bb107
bb107:
  br label %bb109
bb108:
  %t500 = load i32, ptr %l215, !tbaa !23
  %t501 = lshr i32 %t500, 16
  %t502 = and i32 %t500, 65535
  %t503 = icmp eq i32 %t501, 1
  %t504 = select i1 %t503, i32 1, i32 0
  %t505 = icmp eq i32 %t500, 0
  %t506 = shl i32 %t504, 16
  %t507 = or i32 %t506, %t502
  %t508 = select i1 %t505, i32 0, i32 %t507
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t510 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, i32 %t508, 0
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t510, ptr %rv
  br label %ret
bb109:
  call void @__olang_scope_close(ptr %s9)
  br label %bb110
bb110:
  %t511 = load ptr, ptr %lp8
  %t512 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t511
  call void @__olang_scope_close(ptr %s0)
  %t514 = insertvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } zeroinitializer, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t512, 1
  store { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t514, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }, ptr %rv
  ret { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l9 = alloca { i64, ptr }
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 20
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d110, i32 0, i32 1) }, 1
  %t11 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d110, i32 0, i32 1) }, 0
  %t13 = extractvalue { i64, ptr } %a1, 1
  %t14 = extractvalue { i64, ptr } %a1, 0
  %t15 = add i64 %t11, %t14
  %t16 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 1
  %t17 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d111, i32 0, i32 1) }, 0
  %t18 = add i64 %t15, %t17
  %t19 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t18)
  call void @olang_textcopy(ptr %t19, ptr %t10, i64 %t11)
  %t20 = getelementptr i8, ptr %t19, i64 %t11
  call void @olang_textcopy(ptr %t20, ptr %t13, i64 %t14)
  %t21 = getelementptr i8, ptr %t20, i64 %t14
  call void @olang_textcopy(ptr %t21, ptr %t16, i64 %t17)
  %t22 = insertvalue { i64, ptr } undef, i64 %t18, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t19, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t33 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s1, ptr %s1, ptr %s1, ptr %t8, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d112, i32 0, i32 1) }, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l9
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t34 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fbuild_2esayln(ptr %s1, { i64, ptr } %t40)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb5:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ebitcodeText(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { { i64, ptr }, { i64, ptr } }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca i32
  %l30 = alloca i1
  %l43 = alloca { i64, ptr }
  %l47 = alloca i1
  %l49 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l70 = alloca [9 x { i64, ptr }]
  %l87 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l95 = alloca i64
  %l99 = alloca { { i64, ptr }, { i64, ptr } }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l104 = alloca i64
  %l105 = alloca { i64, ptr }
  %l111 = alloca i64
  %l114 = alloca i64
  %l137 = alloca ptr
  %l138 = alloca { i64, [3 x i64] }
  %l141 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l149 = alloca %"compiler/diagmsg:Msg"
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  %t326 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l24
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l24
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v1, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l28
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l27
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t10, ptr %l25, !tbaa !27
  br label %bb11
bb3:
  %t11 = load i32, ptr %l28, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l30, !tbaa !21
  %t15 = load i32, ptr %l28, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = icmp sle i64 0, 576460752303423487
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_ed85b58552229ad2_db88a25435ad515e)
  unreachable
bb9:
  %t24 = mul i64 0, 16
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t26, ptr %l25, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_ed85b58552229ad2_db88a25435ad515e)
  unreachable
bb11:
  %t28 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb36
bb14:
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l43, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l43, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %t47, i64 %t44
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !37
  store { i64, ptr } %t49, ptr %l8, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t53 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %s0, ptr %s2, { i64, ptr } %t51, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d113, i32 0, i32 1) })
  store i1 %t53, ptr %l47
  br label %bb16
bb16:
  %t54 = load i1, ptr %l47, !tbaa !21
  %t55 = xor i1 %t54, true
  br i1 %t55, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb18:
  br label %bb19
bb19:
  %t57 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t57, ptr %l49
  br label %bb20
bb20:
  %t58 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l49
  %t59 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t58, ptr %t59
  store ptr %t59, ptr %l9, !tbaa !29
  %t61 = load ptr, ptr %l9, !tbaa !29
  %t62 = load ptr, ptr %l0, !tbaa !29
  %t64 = getelementptr %"compiler/build:Config", ptr %t62, i32 0, i32 1
  %t65 = load { i64, ptr }, ptr %t64, !tbaa !27
  %t67 = extractvalue { i64, ptr } %t65, 1
  %t68 = extractvalue { i64, ptr } %t65, 0
  %t69 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t68)
  call void @olang_textcopy(ptr %t69, ptr %t67, i64 %t68)
  %t70 = insertvalue { i64, ptr } undef, i64 %t68, 0
  %t71 = insertvalue { i64, ptr } %t70, ptr %t69, 1
  %t73 = extractvalue { i64, ptr } %t71, 0
  %t74 = extractvalue { i64, ptr } %t71, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t61, { i64, ptr } %t78)
  br label %bb21
bb21:
  %t81 = load ptr, ptr %l0, !tbaa !29
  %t83 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 2
  %t84 = getelementptr %"compiler/target:Target", ptr %t83, i32 0, i32 9
  %t85 = load i1, ptr %t84, !tbaa !21
  br i1 %t85, label %bb22, label %bb23
bb22:
  %t87 = load ptr, ptr %l9, !tbaa !29
  %t88 = load ptr, ptr %l0, !tbaa !29
  %t90 = getelementptr %"compiler/build:Config", ptr %t88, i32 0, i32 2
  %t91 = getelementptr %"compiler/target:Target", ptr %t90, i32 0, i32 1
  %t92 = load { i64, ptr }, ptr %t91, !tbaa !27
  %t93 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 1
  %t94 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d114, i32 0, i32 1) }, 0
  %t96 = extractvalue { i64, ptr } %t92, 1
  %t97 = extractvalue { i64, ptr } %t92, 0
  %t98 = add i64 %t94, %t97
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @olang_textcopy(ptr %t99, ptr %t93, i64 %t94)
  %t100 = getelementptr i8, ptr %t99, i64 %t94
  call void @olang_textcopy(ptr %t100, ptr %t96, i64 %t97)
  %t101 = insertvalue { i64, ptr } undef, i64 %t98, 0
  %t102 = insertvalue { i64, ptr } %t101, ptr %t99, 1
  %t104 = extractvalue { i64, ptr } %t102, 0
  %t105 = extractvalue { i64, ptr } %t102, 1
  %t106 = mul i64 %t104, 1
  %t107 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t106)
  call void @llvm.memcpy.p0.p0.i64(ptr %t107, ptr %t105, i64 %t106, i1 false)
  %t108 = insertvalue { i64, ptr } undef, i64 %t104, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t107, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t87, { i64, ptr } %t109)
  br label %bb24
bb23:
  br label %bb25
bb24:
  br label %bb25
bb25:
  %t112 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t115 = extractvalue { i64, ptr } %t112, 1
  %t116 = extractvalue { i64, ptr } %t112, 0
  %t117 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 1
  %t118 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d115, i32 0, i32 1) }, 0
  %t119 = add i64 %t116, %t118
  %t121 = extractvalue { i64, ptr } %t113, 1
  %t122 = extractvalue { i64, ptr } %t113, 0
  %t123 = add i64 %t119, %t122
  %t124 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t123)
  call void @olang_textcopy(ptr %t124, ptr %t115, i64 %t116)
  %t125 = getelementptr i8, ptr %t124, i64 %t116
  call void @olang_textcopy(ptr %t125, ptr %t117, i64 %t118)
  %t126 = getelementptr i8, ptr %t125, i64 %t118
  call void @olang_textcopy(ptr %t126, ptr %t121, i64 %t122)
  %t127 = insertvalue { i64, ptr } undef, i64 %t123, 0
  %t128 = insertvalue { i64, ptr } %t127, ptr %t124, 1
  store { i64, ptr } %t128, ptr %l10, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s8
  %t130 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t130, 1
  %t133 = extractvalue { i64, ptr } %t130, 0
  %t134 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d116, i32 0, i32 1) }, 1
  %t135 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d116, i32 0, i32 1) }, 0
  %t136 = add i64 %t133, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t132, i64 %t133)
  %t138 = getelementptr i8, ptr %t137, i64 %t133
  call void @olang_textcopy(ptr %t138, ptr %t134, i64 %t135)
  %t139 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = extractvalue { i64, ptr } %t140, 1
  %t144 = mul i64 %t142, 1
  %t145 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t144)
  call void @llvm.memcpy.p0.p0.i64(ptr %t145, ptr %t143, i64 %t144, i1 false)
  %t146 = insertvalue { i64, ptr } undef, i64 %t142, 0
  %t147 = insertvalue { i64, ptr } %t146, ptr %t145, 1
  %t148 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t149 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 0
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d117, i32 0, i32 1) }, ptr %t149, !tbaa !37
  %t150 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 1
  store { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d118, i32 0, i32 1) }, ptr %t150, !tbaa !37
  %t151 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 2
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d119, i32 0, i32 1) }, ptr %t151, !tbaa !37
  %t152 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 3
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d120, i32 0, i32 1) }, ptr %t152, !tbaa !37
  %t153 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 4
  store { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d121, i32 0, i32 1) }, ptr %t153, !tbaa !37
  %t154 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 5
  store { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d122, i32 0, i32 1) }, ptr %t154, !tbaa !37
  %t155 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 6
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d123, i32 0, i32 1) }, ptr %t155, !tbaa !37
  %t156 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 7
  store { i64, ptr } %t147, ptr %t156, !tbaa !37
  %t158 = getelementptr [9 x { i64, ptr }], ptr %l70, i64 0, i64 8
  store { i64, ptr } %t148, ptr %t158, !tbaa !37
  %t160 = call ptr @__olang_scope_alloc_a(ptr %s8, i64 144, i64 8)
  call void @llvm.memmove.p0.p0.i64(ptr %t160, ptr %l70, i64 144, i1 false)
  store ptr %t160, ptr %l11
  store i64 0, ptr %l12, !tbaa !24
  %t162 = load ptr, ptr %l11
  store i64 9, ptr %l13, !tbaa !24
  br label %bb26
bb26:
  %t165 = load i64, ptr %l12, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = icmp slt i64 %t165, %t166
  %t171 = xor i1 %t169, true
  br i1 %t171, label %bb27, label %bb28
bb27:
  br label %bb32
bb28:
  br label %bb29
bb29:
  %t173 = load ptr, ptr %l11
  %t174 = load i64, ptr %l12, !tbaa !24
  %t177 = getelementptr [9 x { i64, ptr }], ptr %t173, i64 0, i64 %t174
  %t178 = load { i64, ptr }, ptr %t177, !tbaa !37
  %t180 = load ptr, ptr %l9, !tbaa !29
  %t183 = extractvalue { i64, ptr } %t178, 1
  %t184 = extractvalue { i64, ptr } %t178, 0
  %t185 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t183, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } %t187, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t180, { i64, ptr } %t194)
  br label %bb30
bb30:
  br label %bb31
bb31:
  %t197 = load i64, ptr %l12, !tbaa !24
  %t199 = add i64 %t197, 1
  store i64 %t199, ptr %l12, !tbaa !24
  br label %bb26
bb32:
  call void @__olang_scope_close(ptr %s8)
  store ptr %l3, ptr %l87, !tbaa !29
  %t201 = load ptr, ptr %l9, !tbaa !29
  %t203 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %t201)
  store { i64, ptr } %t203, ptr %l89
  br label %bb33
bb33:
  %t204 = load ptr, ptr %l87, !tbaa !29
  %t205 = load { i64, ptr }, ptr %l89, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t204, { i64, ptr } %t205)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s2)
  br label %bb35
bb35:
  %t206 = load i64, ptr %l6, !tbaa !24
  %t208 = add i64 %t206, 1
  store i64 %t208, ptr %l6, !tbaa !24
  br label %bb12
bb36:
  %t211 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l3)
  store { i64, ptr } %t211, ptr %l93
  br label %bb37
bb37:
  %t212 = load ptr, ptr %l0, !tbaa !29
  %t214 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t212)
  store i64 %t214, ptr %l95
  br label %bb38
bb38:
  %t215 = icmp sge i64 0, 0
  br i1 %t215, label %bb39, label %bb40
bb39:
  %t217 = icmp sle i64 0, 1152921504606846975
  br i1 %t217, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @olang_loc_39c6cdce0ac4fdc7_621aa1b204fc2693)
  unreachable
bb41:
  %t219 = mul i64 0, 8
  %t220 = insertvalue { i64, ptr } undef, i64 0, 0
  %t221 = insertvalue { i64, ptr } %t220, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  %t222 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t223 = load i64, ptr %l95, !tbaa !24
  %t225 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t222, i64 %t223, { i64, ptr } %t221)
  store { { i64, ptr }, { i64, ptr } } %t225, ptr %l99
  br label %bb43
bb42:
  call void @__olang_check_failed(ptr @olang_loc_39c6cdce0ac4fdc7_621aa1b204fc2693)
  unreachable
bb43:
  %t226 = load { { i64, ptr }, { i64, ptr } }, ptr %l99
  store { { i64, ptr }, { i64, ptr } } %t226, ptr %l15
  %t227 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l100, !tbaa !27
  %t229 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t230 = extractvalue { i64, ptr } %t229, 0
  store i64 %t230, ptr %l101, !tbaa !24
  %t231 = load i64, ptr %l101, !tbaa !24
  %t232 = mul i64 %t231, 4
  %t233 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t232)
  %t234 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  store { i64, ptr } %t235, ptr %l102, !tbaa !27
  %t236 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = getelementptr { i64, ptr }, ptr %l100, i32 0, i32 1
  %t239 = load ptr, ptr %t238, !tbaa !27
  %t240 = load i64, ptr %l101, !tbaa !24
  %t241 = mul i64 %t240, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t237, ptr %t239, i64 %t241, i1 false)
  %t242 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t242, ptr %l16, !tbaa !27
  %t243 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l15, i32 0, i32 1
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  store { i64, ptr } %t244, ptr %l103, !tbaa !27
  %t245 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t245, 0
  store i64 %t246, ptr %l104, !tbaa !24
  %t247 = load i64, ptr %l104, !tbaa !24
  %t248 = mul i64 %t247, 16
  %t249 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t248)
  %t250 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  store { i64, ptr } %t251, ptr %l105, !tbaa !27
  %t252 = getelementptr { i64, ptr }, ptr %l105, i32 0, i32 1
  %t253 = load ptr, ptr %t252, !tbaa !27
  %t254 = getelementptr { i64, ptr }, ptr %l103, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = load i64, ptr %l104, !tbaa !24
  %t257 = mul i64 %t256, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t253, ptr %t255, i64 %t257, i1 false)
  %t258 = load { i64, ptr }, ptr %l105, !tbaa !27
  store { i64, ptr } %t258, ptr %l17, !tbaa !27
  store i64 0, ptr %l18, !tbaa !24
  %t259 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t259, 0
  store i64 %t261, ptr %l19, !tbaa !24
  store i64 1, ptr %l20, !tbaa !24
  %t263 = load i64, ptr %l19, !tbaa !24
  %t264 = load i64, ptr %l18, !tbaa !24
  %t267 = icmp sgt i64 %t263, %t264
  br i1 %t267, label %bb44, label %bb45
bb44:
  %t269 = load i64, ptr %l20, !tbaa !24
  %t271 = icmp sgt i64 %t269, 0
  br i1 %t271, label %bb46, label %bb47
bb45:
  store i64 0, ptr %l111, !tbaa !24
  br label %bb49
bb46:
  %t273 = load i64, ptr %l19, !tbaa !24
  %t274 = load i64, ptr %l18, !tbaa !24
  %t277 = sub i64 %t273, %t274
  %t278 = load i64, ptr %l20, !tbaa !24
  %t281 = add i64 %t277, %t278
  %t283 = sub i64 %t281, 1
  %t284 = load i64, ptr %l20, !tbaa !24
  %t287 = sdiv i64 %t283, %t284
  store i64 %t287, ptr %l114, !tbaa !24
  br label %bb48
bb47:
  store i64 0, ptr %l114, !tbaa !24
  br label %bb48
bb48:
  %t289 = load i64, ptr %l114, !tbaa !24
  store i64 %t289, ptr %l111, !tbaa !24
  br label %bb49
bb49:
  %t290 = load i64, ptr %l111, !tbaa !24
  store i64 %t290, ptr %l21, !tbaa !24
  store i64 0, ptr %l22, !tbaa !24
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s15
  %t291 = load i64, ptr %l22, !tbaa !24
  %t292 = load i64, ptr %l21, !tbaa !24
  %t295 = icmp slt i64 %t291, %t292
  %t297 = xor i1 %t295, true
  br i1 %t297, label %bb51, label %bb52
bb51:
  call void @__olang_scope_close(ptr %s15)
  br label %bb63
bb52:
  br label %bb53
bb53:
  %t299 = load i64, ptr %l18, !tbaa !24
  %t300 = load i64, ptr %l22, !tbaa !24
  %t301 = load i64, ptr %l20, !tbaa !24
  %t304 = mul i64 %t300, %t301
  %t307 = add i64 %t299, %t304
  store i64 %t307, ptr %l23, !tbaa !24
  %t309 = load i64, ptr %l23, !tbaa !24
  %t311 = getelementptr { i64, ptr }, ptr %l16, i32 0, i32 1
  %t312 = load ptr, ptr %t311, !tbaa !27
  %t313 = getelementptr i32, ptr %t312, i64 %t309
  %t314 = load i32, ptr %t313, !tbaa !33
  %t316 = icmp eq i32 %t314, 0
  br i1 %t316, label %bb54, label %bb55
bb54:
  call void @__olang_scope_close(ptr %s15)
  br label %bb62
bb55:
  br label %bb56
bb56:
  %t318 = load i64, ptr %l23, !tbaa !24
  %t320 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr { i64, ptr }, ptr %t321, i64 %t318
  %t323 = load { i64, ptr }, ptr %t322, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t323)
  br label %bb57
bb57:
  store ptr %a2, ptr %l137, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t326
  %t327 = getelementptr { i64, [3 x i64] }, ptr %t326, i32 0, i32 0
  store i64 0, ptr %t327
  %t328 = load { i64, [3 x i64] }, ptr %t326
  store { i64, [3 x i64] } %t328, ptr %l138
  %t329 = load i64, ptr %l23, !tbaa !24
  %t332 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %l3, i64 %t329)
  store { i64, ptr } %t332, ptr %l141
  br label %bb58
bb58:
  %t333 = load { i64, ptr }, ptr %l141, !tbaa !27
  store { i64, ptr } %t333, ptr %l142, !tbaa !27
  %t334 = load i64, ptr %l23, !tbaa !24
  %t337 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s15, ptr %l3, i64 %t334)
  store { i64, ptr } %t337, ptr %l145
  br label %bb59
bb59:
  %t338 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t339 = extractvalue { i64, ptr } %t338, 0
  %t341 = sub i64 %t339, 1
  %t343 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t344 = load ptr, ptr %t343, !tbaa !27
  %t345 = getelementptr { i64, ptr }, ptr %t344, i64 %t341
  %t346 = load { i64, ptr }, ptr %t345, !tbaa !37
  %t348 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %s0, ptr %s15, { i64, ptr } %t346)
  store %"compiler/diagmsg:Msg" %t348, ptr %l149
  br label %bb60
bb60:
  %t349 = load ptr, ptr %l137, !tbaa !29
  %t350 = load { i64, [3 x i64] }, ptr %l138
  %t351 = load %"compiler/diagmsg:Msg", ptr %l149
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %s15, ptr %t349, { i64, [3 x i64] } %t350, %"compiler/diagmsg:Msg" %t351)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb62:
  %t353 = load i64, ptr %l22, !tbaa !24
  %t355 = add i64 %t353, 1
  store i64 %t355, ptr %l22, !tbaa !24
  br label %bb50
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/os:Output"
  %l4 = alloca i1
  %l5 = alloca %"std/os:Output"
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/os:Output"
  %l12 = alloca i32
  %l14 = alloca i1
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 27
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d124, i32 0, i32 1) })
  store i1 %t6, ptr %l4
  br label %bb1
bb1:
  %t7 = load i1, ptr %l4, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 1
  %t14 = extractvalue { i64, ptr } %t11, 0
  %t15 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t14)
  call void @olang_textcopy(ptr %t15, ptr %t13, i64 %t14)
  %t16 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t17 = insertvalue { i64, ptr } %t16, ptr %t15, 1
  %t19 = extractvalue { i64, ptr } %t17, 0
  %t20 = extractvalue { i64, ptr } %t17, 1
  %t21 = mul i64 %t19, 1
  %t22 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t21)
  call void @llvm.memcpy.p0.p0.i64(ptr %t22, ptr %t20, i64 %t21, i1 false)
  %t23 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t24 = insertvalue { i64, ptr } %t23, ptr %t22, 1
  %t25 = mul i64 2, 16
  %t26 = call ptr @__olang_scope_alloc_zeroed(ptr %s1, i64 %t25)
  %t27 = insertvalue { i64, ptr } undef, i64 2, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l10, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = getelementptr { i64, ptr }, ptr %t31, i64 0
  store { i64, ptr } %t24, ptr %t32, !tbaa !37
  %t33 = getelementptr { i64, ptr }, ptr %l10, i32 0, i32 1
  %t34 = load ptr, ptr %t33, !tbaa !27
  %t35 = getelementptr { i64, ptr }, ptr %t34, i64 1
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d125, i32 0, i32 1) }, ptr %t35, !tbaa !37
  %t36 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t37 = call { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %s1, ptr %s1, ptr %s1, { i64, ptr } %t36, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d126, i32 0, i32 1) }, i1 true)
  %t38 = extractvalue { i32, %"std/os:Output" } %t37, 1
  %t39 = extractvalue { i32, %"std/os:Output" } %t37, 0
  store i32 %t39, ptr %l12
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb5, label %ok.41, !prof !99
ok.41:
  store %"std/os:Output" %t38, ptr %l11
  br label %bb4
bb3:
  br label %bb10
bb4:
  %t42 = load %"std/os:Output", ptr %l11
  store %"std/os:Output" %t42, ptr %l5
  br label %bb9
bb5:
  %t43 = load i32, ptr %l12, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  store i1 %t46, ptr %l14, !tbaa !21
  %t47 = load i32, ptr %l12, !tbaa !23
  %t48 = ashr i32 %t47, 16
  %t50 = icmp eq i32 %t48, 1
  br i1 %t50, label %bb6, label %bb7
bb6:
  call void @__olang_errpay_pop()
  br label %bb7
bb7:
  br label %bb8
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d127, i32 0, i32 1) }, ptr %l17, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t52 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t52, ptr %rv
  br label %ret
bb9:
  %t53 = load %"std/os:Output", ptr %l5
  store %"std/os:Output" %t53, ptr %l1
  %t54 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/os:Output", ptr %l1, i32 0, i32 1
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  %t58 = extractvalue { i64, ptr } %t56, 1
  %t59 = extractvalue { i64, ptr } %t56, 0
  %t60 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t59)
  call void @olang_textcopy(ptr %t60, ptr %t58, i64 %t59)
  %t61 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t62 = insertvalue { i64, ptr } %t61, ptr %t60, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  %t65 = extractvalue { i64, ptr } %t62, 1
  %t66 = mul i64 %t64, 1
  %t67 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t66)
  call void @llvm.memcpy.p0.p0.i64(ptr %t67, ptr %t65, i64 %t66, i1 false)
  %t68 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t72 = getelementptr %"compiler/build:Config", ptr %t54, i32 0, i32 27
  store { i64, ptr } %t69, ptr %t72, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t73 = load ptr, ptr %l0, !tbaa !29
  %t75 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 27
  %t76 = load { i64, ptr }, ptr %t75, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t76, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ecompile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { { i64, ptr }, { i64, ptr } }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { { i64, ptr }, { i64, ptr } }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i64
  %l30 = alloca { i64, ptr }
  %l31 = alloca ptr
  %l32 = alloca i64
  %l35 = alloca i64
  %l42 = alloca i64
  %l45 = alloca i64
  %l66 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca i32
  %l73 = alloca i1
  %l83 = alloca ptr
  %l84 = alloca { i64, [3 x i64] }
  %l88 = alloca { i64, ptr }
  %l89 = alloca %"compiler/diagmsg:Msg"
  %l93 = alloca { i64, ptr }
  %l94 = alloca i32
  %l96 = alloca i1
  %l102 = alloca { i64, ptr }
  %l103 = alloca i1
  %l108 = alloca { i64, ptr }
  %l109 = alloca i32
  %l111 = alloca i1
  %l116 = alloca i1
  %l123 = alloca { i64, ptr }
  %l124 = alloca i1
  %l129 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l136 = alloca i32
  %l138 = alloca i1
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca %"compiler/diagmsg:Msg"
  %l151 = alloca ptr
  %l155 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l161 = alloca { i64, ptr }
  %l165 = alloca { i64, ptr }
  %l166 = alloca i32
  %l168 = alloca i1
  %l176 = alloca { i64, ptr }
  %l177 = alloca %"compiler/diagmsg:Msg"
  %l179 = alloca ptr
  %l183 = alloca { i64, ptr }
  %l188 = alloca i64
  %l190 = alloca i64
  %l195 = alloca { i64, ptr }
  %l197 = alloca i32
  %l199 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca i32
  %t165 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:compiles", ptr %t1, i32 0, i32 0
  %t5 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v1, ptr %v1, ptr %t3)
  store { i64, ptr } %t5, ptr %l18
  br label %bb1
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l20
  br label %bb2
bb2:
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/build:compiles", ptr %t9, i32 0, i32 6
  %t13 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v1, ptr %s0, ptr %t11)
  store { i64, ptr } %t13, ptr %l23
  br label %bb3
bb3:
  %t14 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t15 = load i64, ptr %l20, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t17 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %v1, ptr %s0, ptr %s0, { i64, ptr } %t14, i64 %t15, { i64, ptr } %t16)
  store { { i64, ptr }, { i64, ptr } } %t17, ptr %l24
  br label %bb4
bb4:
  %t18 = load { { i64, ptr }, { i64, ptr } }, ptr %l24
  store { { i64, ptr }, { i64, ptr } } %t18, ptr %l3
  %t19 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 0
  %t20 = load { i64, ptr }, ptr %t19, !tbaa !27
  store { i64, ptr } %t20, ptr %l25, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l26, !tbaa !24
  %t23 = load i64, ptr %l26, !tbaa !24
  %t24 = mul i64 %t23, 4
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  %t26 = insertvalue { i64, ptr } undef, i64 %t23, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l27, !tbaa !27
  %t28 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t29 = load ptr, ptr %t28, !tbaa !27
  %t30 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l26, !tbaa !24
  %t33 = mul i64 %t32, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t29, ptr %t31, i64 %t33, i1 false)
  %t34 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  %t35 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l3, i32 0, i32 1
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  store { i64, ptr } %t36, ptr %l28, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 0
  store i64 %t38, ptr %l29, !tbaa !24
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = mul i64 %t39, 16
  %t41 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t40)
  %t42 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t43 = insertvalue { i64, ptr } %t42, ptr %t41, 1
  store { i64, ptr } %t43, ptr %l30, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = getelementptr { i64, ptr }, ptr %l28, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = load i64, ptr %l29, !tbaa !24
  %t49 = mul i64 %t48, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t45, ptr %t47, i64 %t49, i1 false)
  %t50 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t50, ptr %l5, !tbaa !27
  %t51 = load ptr, ptr %l0, !tbaa !29
  store ptr %t51, ptr %l31, !tbaa !29
  %t52 = load ptr, ptr %l31, !tbaa !29
  %t53 = getelementptr %"compiler/build:Config", ptr %t52, i32 0, i32 23
  %t54 = load i64, ptr %t53, !tbaa !24
  store i64 %t54, ptr %l32, !tbaa !24
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t57 = getelementptr %"compiler/build:compiles", ptr %t55, i32 0, i32 0
  %t59 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %v1, ptr %t57)
  store i64 %t59, ptr %l35
  br label %bb5
bb5:
  %t60 = load i64, ptr %l32, !tbaa !24
  %t61 = load i64, ptr %l35, !tbaa !24
  %t62 = add i64 %t60, %t61
  %t64 = load ptr, ptr %l31, !tbaa !29
  %t65 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 23
  store i64 %t62, ptr %t65, !tbaa !24
  store i1 false, ptr %l6, !tbaa !21
  store i64 0, ptr %l7, !tbaa !24
  %t66 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t68 = extractvalue { i64, ptr } %t66, 0
  store i64 %t68, ptr %l8, !tbaa !24
  store i64 1, ptr %l9, !tbaa !24
  %t70 = load i64, ptr %l8, !tbaa !24
  %t71 = load i64, ptr %l7, !tbaa !24
  %t74 = icmp sgt i64 %t70, %t71
  br i1 %t74, label %bb6, label %bb7
bb6:
  %t76 = load i64, ptr %l9, !tbaa !24
  %t78 = icmp sgt i64 %t76, 0
  br i1 %t78, label %bb8, label %bb9
bb7:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb11
bb8:
  %t80 = load i64, ptr %l8, !tbaa !24
  %t81 = load i64, ptr %l7, !tbaa !24
  %t84 = sub i64 %t80, %t81
  %t85 = load i64, ptr %l9, !tbaa !24
  %t88 = add i64 %t84, %t85
  %t90 = sub i64 %t88, 1
  %t91 = load i64, ptr %l9, !tbaa !24
  %t94 = sdiv i64 %t90, %t91
  store i64 %t94, ptr %l45, !tbaa !24
  br label %bb10
bb9:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb10
bb10:
  %t96 = load i64, ptr %l45, !tbaa !24
  store i64 %t96, ptr %l42, !tbaa !24
  br label %bb11
bb11:
  %t97 = load i64, ptr %l42, !tbaa !24
  store i64 %t97, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s2
  %t98 = load i64, ptr %l11, !tbaa !24
  %t99 = load i64, ptr %l10, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb13, label %bb14
bb13:
  call void @__olang_scope_close(ptr %s2)
  br label %bb99
bb14:
  br label %bb15
bb15:
  %t106 = load i64, ptr %l7, !tbaa !24
  %t107 = load i64, ptr %l11, !tbaa !24
  %t108 = load i64, ptr %l9, !tbaa !24
  %t111 = mul i64 %t107, %t108
  %t114 = add i64 %t106, %t111
  store i64 %t114, ptr %l12, !tbaa !24
  %t116 = load ptr, ptr %l1, !tbaa !29
  %t118 = getelementptr %"compiler/build:compiles", ptr %t116, i32 0, i32 4
  %t119 = load i64, ptr %l12, !tbaa !24
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t118, i64 %t119)
  store { i64, ptr } %t122, ptr %l66
  br label %bb16
bb16:
  %t123 = load ptr, ptr %l1, !tbaa !29
  %t125 = getelementptr %"compiler/build:compiles", ptr %t123, i32 0, i32 3
  %t126 = load i64, ptr %l12, !tbaa !24
  %t129 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t125, i64 %t126)
  store { i64, ptr } %t129, ptr %l70
  br label %bb17
bb17:
  %t130 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t132 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t130, { i64, ptr } %t131)
  store i32 %t132, ptr %l71
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb19, label %ok.134, !prof !99
ok.134:
  br label %bb18
bb18:
  br label %bb23
bb19:
  %t135 = load i32, ptr %l71, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l73, !tbaa !21
  %t139 = load i32, ptr %l71, !tbaa !23
  %t140 = ashr i32 %t139, 16
  %t142 = icmp eq i32 %t140, 1
  br i1 %t142, label %bb20, label %bb21
bb20:
  call void @__olang_errpay_pop()
  br label %bb21
bb21:
  br label %bb22
bb22:
  br label %bb23
bb23:
  %t144 = load i64, ptr %l12, !tbaa !24
  %t146 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = getelementptr i32, ptr %t147, i64 %t144
  %t149 = load i32, ptr %t148, !tbaa !33
  %t151 = icmp ne i32 %t149, 0
  br i1 %t151, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s4
  %t153 = load i64, ptr %l12, !tbaa !24
  %t155 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t156 = load ptr, ptr %t155, !tbaa !27
  %t157 = getelementptr { i64, ptr }, ptr %t156, i64 %t153
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t158)
  br label %bb26
bb25:
  br label %bb52
bb26:
  %t160 = load i1, ptr %l6, !tbaa !21
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb27, label %bb28
bb27:
  store %olang.scope zeroinitializer, ptr %s5
  %t164 = load ptr, ptr %l2, !tbaa !29
  store ptr %t164, ptr %l83, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t165
  %t166 = getelementptr { i64, [3 x i64] }, ptr %t165, i32 0, i32 0
  store i64 0, ptr %t166
  %t167 = load { i64, [3 x i64] }, ptr %t165
  store { i64, [3 x i64] } %t167, ptr %l84
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t170 = getelementptr %"compiler/build:compiles", ptr %t168, i32 0, i32 3
  %t171 = load i64, ptr %l12, !tbaa !24
  %t174 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t170, i64 %t171)
  store { i64, ptr } %t174, ptr %l88
  br label %bb29
bb28:
  br label %bb32
bb29:
  %t175 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t176 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v1, ptr %s5, { i64, ptr } %t175)
  store %"compiler/diagmsg:Msg" %t176, ptr %l89
  br label %bb30
bb30:
  %t177 = load ptr, ptr %l83, !tbaa !29
  %t178 = load { i64, [3 x i64] }, ptr %l84
  %t179 = load %"compiler/diagmsg:Msg", ptr %l89
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %s5, ptr %t177, { i64, [3 x i64] } %t178, %"compiler/diagmsg:Msg" %t179)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s5)
  br label %bb32
bb32:
  store i1 true, ptr %l6, !tbaa !21
  %t180 = load ptr, ptr %l1, !tbaa !29
  %t182 = getelementptr %"compiler/build:compiles", ptr %t180, i32 0, i32 1
  %t183 = load i64, ptr %l12, !tbaa !24
  %t186 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t182, i64 %t183)
  store { i64, ptr } %t186, ptr %l93
  br label %bb33
bb33:
  %t187 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t188 = call i32 @std_2fos_2eRemove(ptr %v1, { i64, ptr } %t187)
  store i32 %t188, ptr %l94
  %t189 = icmp ne i32 %t188, 0
  br i1 %t189, label %bb35, label %ok.190, !prof !99
ok.190:
  br label %bb34
bb34:
  br label %bb39
bb35:
  %t191 = load i32, ptr %l94, !tbaa !23
  %t192 = ashr i32 %t191, 16
  %t194 = icmp eq i32 %t192, 1
  store i1 %t194, ptr %l96, !tbaa !21
  %t195 = load i32, ptr %l94, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  br i1 %t198, label %bb36, label %bb37
bb36:
  call void @__olang_errpay_pop()
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  %t200 = load ptr, ptr %l1, !tbaa !29
  %t202 = getelementptr %"compiler/build:compiles", ptr %t200, i32 0, i32 5
  %t203 = load i64, ptr %l12, !tbaa !24
  %t206 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t202, i64 %t203)
  store { i64, ptr } %t206, ptr %l102
  br label %bb40
bb40:
  %t207 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t208 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s4, { i64, ptr } %t207, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d128, i32 0, i32 1) })
  store i1 %t208, ptr %l103
  br label %bb41
bb41:
  %t209 = load i1, ptr %l103, !tbaa !21
  %t210 = xor i1 %t209, true
  br i1 %t210, label %bb42, label %bb43
bb42:
  %t212 = load ptr, ptr %l1, !tbaa !29
  %t214 = getelementptr %"compiler/build:compiles", ptr %t212, i32 0, i32 5
  %t215 = load i64, ptr %l12, !tbaa !24
  %t218 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t214, i64 %t215)
  store { i64, ptr } %t218, ptr %l108
  br label %bb44
bb43:
  br label %bb51
bb44:
  %t219 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t220 = call i32 @std_2fos_2eRemove(ptr %v1, { i64, ptr } %t219)
  store i32 %t220, ptr %l109
  %t221 = icmp ne i32 %t220, 0
  br i1 %t221, label %bb46, label %ok.222, !prof !99
ok.222:
  br label %bb45
bb45:
  br label %bb50
bb46:
  %t223 = load i32, ptr %l109, !tbaa !23
  %t224 = ashr i32 %t223, 16
  %t226 = icmp eq i32 %t224, 1
  store i1 %t226, ptr %l111, !tbaa !21
  %t227 = load i32, ptr %l109, !tbaa !23
  %t228 = ashr i32 %t227, 16
  %t230 = icmp eq i32 %t228, 1
  br i1 %t230, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb52:
  %t232 = load i64, ptr %l12, !tbaa !24
  %t234 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t235 = load ptr, ptr %t234, !tbaa !27
  %t236 = getelementptr { i64, ptr }, ptr %t235, i64 %t232
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !37
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s2, { i64, ptr } %t237, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d129, i32 0, i32 1) })
  store i1 %t239, ptr %l116
  br label %bb53
bb53:
  %t240 = load i1, ptr %l116, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb54, label %bb55
bb54:
  %t243 = load i64, ptr %l12, !tbaa !24
  %t245 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t246 = load ptr, ptr %t245, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %t246, i64 %t243
  %t248 = load { i64, ptr }, ptr %t247, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t248)
  br label %bb56
bb55:
  br label %bb57
bb56:
  br label %bb57
bb57:
  %t250 = load ptr, ptr %l1, !tbaa !29
  %t252 = getelementptr %"compiler/build:compiles", ptr %t250, i32 0, i32 5
  %t253 = load i64, ptr %l12, !tbaa !24
  %t256 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t252, i64 %t253)
  store { i64, ptr } %t256, ptr %l123
  br label %bb58
bb58:
  %t257 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t258 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s2, { i64, ptr } %t257, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d130, i32 0, i32 1) })
  store i1 %t258, ptr %l124
  br label %bb59
bb59:
  %t259 = load i1, ptr %l124, !tbaa !21
  %t260 = xor i1 %t259, true
  br i1 %t260, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s10
  %t262 = load ptr, ptr %l1, !tbaa !29
  %t264 = getelementptr %"compiler/build:compiles", ptr %t262, i32 0, i32 5
  %t265 = load i64, ptr %l12, !tbaa !24
  %t268 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t264, i64 %t265)
  store { i64, ptr } %t268, ptr %l129
  br label %bb62
bb61:
  br label %bb81
bb62:
  %t269 = load ptr, ptr %l1, !tbaa !29
  %t271 = getelementptr %"compiler/build:compiles", ptr %t269, i32 0, i32 2
  %t272 = load i64, ptr %l12, !tbaa !24
  %t275 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t271, i64 %t272)
  store { i64, ptr } %t275, ptr %l133
  br label %bb63
bb63:
  %t276 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t277 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v1, ptr %s10, { i64, ptr } %t276)
  store { i64, ptr } %t277, ptr %l134
  br label %bb64
bb64:
  %t278 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t279 = extractvalue { i64, ptr } %t278, 0
  %t280 = extractvalue { i64, ptr } %t278, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  %t285 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t287 = call i32 @std_2fos_2eRename(ptr %v1, ptr %s10, { i64, ptr } %t285, { i64, ptr } %t284)
  store i32 %t287, ptr %l136
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb66, label %ok.289, !prof !99
ok.289:
  br label %bb65
bb65:
  br label %bb77
bb66:
  %t290 = load i32, ptr %l136, !tbaa !23
  %t291 = ashr i32 %t290, 16
  %t293 = icmp eq i32 %t291, 1
  store i1 %t293, ptr %l138, !tbaa !21
  %t294 = load i32, ptr %l136, !tbaa !23
  %t295 = ashr i32 %t294, 16
  %t297 = icmp eq i32 %t295, 1
  br i1 %t297, label %bb67, label %bb68
bb67:
  call void @__olang_errpay_pop()
  br label %bb68
bb68:
  br label %bb69
bb69:
  %t299 = load i1, ptr %l6, !tbaa !21
  %t301 = xor i1 %t299, true
  br i1 %t301, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s12
  %t303 = load ptr, ptr %l1, !tbaa !29
  %t305 = getelementptr %"compiler/build:compiles", ptr %t303, i32 0, i32 2
  %t306 = load i64, ptr %l12, !tbaa !24
  %t309 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t305, i64 %t306)
  store { i64, ptr } %t309, ptr %l146
  br label %bb72
bb71:
  br label %bb76
bb72:
  %t310 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t311 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v1, ptr %s12, { i64, ptr } %t310)
  store { i64, ptr } %t311, ptr %l147
  br label %bb73
bb73:
  %t312 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t313 = extractvalue { i64, ptr } %t312, 0
  %t314 = extractvalue { i64, ptr } %t312, 1
  %t315 = mul i64 %t313, 1
  %t316 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t315)
  call void @llvm.memcpy.p0.p0.i64(ptr %t316, ptr %t314, i64 %t315, i1 false)
  %t317 = insertvalue { i64, ptr } undef, i64 %t313, 0
  %t318 = insertvalue { i64, ptr } %t317, ptr %t316, 1
  store { i64, ptr } %t318, ptr %l148, !tbaa !27
  %t319 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s12)
  store %"compiler/diagmsg:Msg" %t319, ptr %l149
  br label %bb74
bb74:
  %t320 = load ptr, ptr %l2, !tbaa !29
  %t321 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t322 = load %"compiler/diagmsg:Msg", ptr %l149
  call void @compiler_2fbuild_2efileFatal(ptr %s12, ptr %s12, ptr %v2, { i64, ptr } %t321, %"compiler/diagmsg:Msg" %t322, ptr %t320)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s12)
  br label %bb76
bb76:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb77:
  %t324 = load ptr, ptr %l0, !tbaa !29
  store ptr %t324, ptr %l151, !tbaa !29
  %t325 = load ptr, ptr %l1, !tbaa !29
  %t327 = getelementptr %"compiler/build:compiles", ptr %t325, i32 0, i32 2
  %t328 = load i64, ptr %l12, !tbaa !24
  %t331 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t327, i64 %t328)
  store { i64, ptr } %t331, ptr %l155
  br label %bb78
bb78:
  %t332 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t333 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v1, ptr %s10, { i64, ptr } %t332)
  store { i64, ptr } %t333, ptr %l156
  br label %bb79
bb79:
  %t334 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t335 = extractvalue { i64, ptr } %t334, 0
  %t336 = extractvalue { i64, ptr } %t334, 1
  %t337 = mul i64 %t335, 1
  %t338 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t337)
  call void @llvm.memcpy.p0.p0.i64(ptr %t338, ptr %t336, i64 %t337, i1 false)
  %t339 = insertvalue { i64, ptr } undef, i64 %t335, 0
  %t340 = insertvalue { i64, ptr } %t339, ptr %t338, 1
  %t341 = load ptr, ptr %l151, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %s10, ptr %t341, { i64, ptr } %t340)
  br label %bb80
bb80:
  call void @__olang_scope_close(ptr %s10)
  br label %bb81
bb81:
  %t343 = load ptr, ptr %l1, !tbaa !29
  %t345 = getelementptr %"compiler/build:compiles", ptr %t343, i32 0, i32 1
  %t346 = load i64, ptr %l12, !tbaa !24
  %t349 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t345, i64 %t346)
  store { i64, ptr } %t349, ptr %l161
  br label %bb82
bb82:
  %t350 = load ptr, ptr %l1, !tbaa !29
  %t352 = getelementptr %"compiler/build:compiles", ptr %t350, i32 0, i32 2
  %t353 = load i64, ptr %l12, !tbaa !24
  %t356 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t352, i64 %t353)
  store { i64, ptr } %t356, ptr %l165
  br label %bb83
bb83:
  %t357 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t358 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t359 = call i32 @std_2fos_2eRename(ptr %v1, ptr %v1, { i64, ptr } %t357, { i64, ptr } %t358)
  store i32 %t359, ptr %l166
  %t360 = icmp ne i32 %t359, 0
  br i1 %t360, label %bb85, label %ok.361, !prof !99
ok.361:
  br label %bb84
bb84:
  br label %bb95
bb85:
  %t362 = load i32, ptr %l166, !tbaa !23
  %t363 = ashr i32 %t362, 16
  %t365 = icmp eq i32 %t363, 1
  store i1 %t365, ptr %l168, !tbaa !21
  %t366 = load i32, ptr %l166, !tbaa !23
  %t367 = ashr i32 %t366, 16
  %t369 = icmp eq i32 %t367, 1
  br i1 %t369, label %bb86, label %bb87
bb86:
  call void @__olang_errpay_pop()
  br label %bb87
bb87:
  br label %bb88
bb88:
  %t371 = load i1, ptr %l6, !tbaa !21
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s14
  %t375 = load ptr, ptr %l1, !tbaa !29
  %t377 = getelementptr %"compiler/build:compiles", ptr %t375, i32 0, i32 2
  %t378 = load i64, ptr %l12, !tbaa !24
  %t381 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t377, i64 %t378)
  store { i64, ptr } %t381, ptr %l176
  br label %bb91
bb90:
  br label %bb94
bb91:
  %t382 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s14)
  store %"compiler/diagmsg:Msg" %t382, ptr %l177
  br label %bb92
bb92:
  %t383 = load ptr, ptr %l2, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l176, !tbaa !27
  %t385 = load %"compiler/diagmsg:Msg", ptr %l177
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s14, ptr %v2, { i64, ptr } %t384, %"compiler/diagmsg:Msg" %t385, ptr %t383)
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s14)
  br label %bb94
bb94:
  store i1 true, ptr %l6, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb95:
  %t387 = load ptr, ptr %l0, !tbaa !29
  store ptr %t387, ptr %l179, !tbaa !29
  %t388 = load ptr, ptr %l1, !tbaa !29
  %t390 = getelementptr %"compiler/build:compiles", ptr %t388, i32 0, i32 2
  %t391 = load i64, ptr %l12, !tbaa !24
  %t394 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t390, i64 %t391)
  store { i64, ptr } %t394, ptr %l183
  br label %bb96
bb96:
  %t395 = load ptr, ptr %l179, !tbaa !29
  %t396 = load { i64, ptr }, ptr %l183, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %t395, { i64, ptr } %t396)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s2)
  br label %bb98
bb98:
  %t397 = load i64, ptr %l11, !tbaa !24
  %t399 = add i64 %t397, 1
  store i64 %t399, ptr %l11, !tbaa !24
  br label %bb12
bb99:
  %t401 = load ptr, ptr %l1, !tbaa !29
  %t403 = getelementptr %"compiler/build:compiles", ptr %t401, i32 0, i32 7
  store ptr %t403, ptr %l13, !tbaa !29
  store i64 0, ptr %l14, !tbaa !24
  br label %bb100
bb100:
  %t405 = load i64, ptr %l14, !tbaa !24
  store i64 %t405, ptr %l188, !tbaa !24
  %t406 = load ptr, ptr %l13, !tbaa !29
  %t408 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t406)
  store i64 %t408, ptr %l190
  br label %bb101
bb101:
  %t409 = load i64, ptr %l188, !tbaa !24
  %t410 = load i64, ptr %l190, !tbaa !24
  %t411 = icmp slt i64 %t409, %t410
  %t413 = xor i1 %t411, true
  br i1 %t413, label %bb102, label %bb103
bb102:
  br label %bb113
bb103:
  br label %bb104
bb104:
  %t415 = load ptr, ptr %l13, !tbaa !29
  %t416 = load i64, ptr %l14, !tbaa !24
  %t419 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t415, i64 %t416)
  store { i64, ptr } %t419, ptr %l195
  br label %bb105
bb105:
  %t420 = load { i64, ptr }, ptr %l195, !tbaa !27
  %t423 = call i32 @std_2fos_2eRemoveAll(ptr %v1, { i64, ptr } %t420)
  store i32 %t423, ptr %l197
  %t424 = icmp ne i32 %t423, 0
  br i1 %t424, label %bb107, label %ok.425, !prof !99
ok.425:
  br label %bb106
bb106:
  br label %bb111
bb107:
  %t426 = load i32, ptr %l197, !tbaa !23
  %t427 = ashr i32 %t426, 16
  %t429 = icmp eq i32 %t427, 1
  store i1 %t429, ptr %l199, !tbaa !21
  %t430 = load i32, ptr %l197, !tbaa !23
  %t431 = ashr i32 %t430, 16
  %t433 = icmp eq i32 %t431, 1
  br i1 %t433, label %bb108, label %bb109
bb108:
  call void @__olang_errpay_pop()
  br label %bb109
bb109:
  br label %bb110
bb110:
  br label %bb111
bb111:
  br label %bb112
bb112:
  %t435 = load i64, ptr %l14, !tbaa !24
  %t437 = add i64 %t435, 1
  store i64 %t437, ptr %l14, !tbaa !24
  br label %bb100
bb113:
  %t439 = load i1, ptr %l6, !tbaa !21
  br i1 %t439, label %bb114, label %bb115
bb114:
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb115:
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l4 = alloca i32
  %l6 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"compiler/diagmsg:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t4)
  store i32 %t6, ptr %l4
  %t7 = icmp ne i32 %t6, 0
  br i1 %t7, label %bb2, label %ok.8, !prof !99
ok.8:
  br label %bb1
bb1:
  br label %bb8
bb2:
  %t9 = load i32, ptr %l4, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l6, !tbaa !21
  %t13 = load i32, ptr %l4, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load ptr, ptr %l0, !tbaa !29
  %t20 = getelementptr %"compiler/build:Config", ptr %t18, i32 0, i32 0
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !27
  store { i64, ptr } %t21, ptr %l10, !tbaa !27
  %t22 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/diagmsg:Msg" %t22, ptr %l11
  br label %bb6
bb6:
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t25 = load %"compiler/diagmsg:Msg", ptr %l11
  call void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %s1, ptr %v1, { i64, ptr } %t24, %"compiler/diagmsg:Msg" %t25, ptr %a1)
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  store i32 65536, ptr %rv
  br label %ret
bb8:
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca %"std/os:Output"
  %l19 = alloca { i64, ptr }
  %l21 = alloca %"std/os:Output"
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca %"std/os:Output"
  %l26 = alloca i32
  %l28 = alloca i1
  %l39 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 11
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l1, !tbaa !29
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 11
  %t12 = load i64, ptr %t11, !tbaa !24
  %t13 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d131, i32 0, i32 1) }, 1
  %t14 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d131, i32 0, i32 1) }, 0
  %t16 = call i64 @__olang_fmt_i64(ptr null, i64 %t12)
  %t17 = add i64 %t14, %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t17)
  call void @olang_textcopy(ptr %t18, ptr %t13, i64 %t14)
  %t19 = getelementptr i8, ptr %t18, i64 %t14
  %t20 = call i64 @__olang_fmt_i64(ptr %t19, i64 %t12)
  %t21 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t22 = insertvalue { i64, ptr } %t21, ptr %t18, 1
  %t24 = extractvalue { i64, ptr } %t22, 0
  %t25 = extractvalue { i64, ptr } %t22, 1
  %t26 = mul i64 %t24, 1
  %t27 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t26)
  call void @llvm.memcpy.p0.p0.i64(ptr %t27, ptr %t25, i64 %t26, i1 false)
  %t28 = insertvalue { i64, ptr } undef, i64 %t24, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t8, { i64, ptr } %t29)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"compiler/build:Config", ptr %t33, i32 0, i32 10
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t37 = load ptr, ptr %l2, !tbaa !29
  %t39 = getelementptr %"compiler/build:Program", ptr %t37, i32 0, i32 6
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t41 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d132, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d132, i32 0, i32 1) }, 0
  %t44 = extractvalue { i64, ptr } %t36, 1
  %t45 = extractvalue { i64, ptr } %t36, 0
  %t46 = add i64 %t42, %t45
  %t47 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d133, i32 0, i32 1) }, 1
  %t48 = extractvalue { i64, ptr } { i64 23, ptr getelementptr inbounds (<{ i64, [23 x i8] }>, ptr @.d133, i32 0, i32 1) }, 0
  %t49 = add i64 %t46, %t48
  %t51 = extractvalue { i64, ptr } %t40, 1
  %t52 = extractvalue { i64, ptr } %t40, 0
  %t53 = add i64 %t49, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d134, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t57 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t56)
  call void @olang_textcopy(ptr %t57, ptr %t41, i64 %t42)
  %t58 = getelementptr i8, ptr %t57, i64 %t42
  call void @olang_textcopy(ptr %t58, ptr %t44, i64 %t45)
  %t59 = getelementptr i8, ptr %t58, i64 %t45
  call void @olang_textcopy(ptr %t59, ptr %t47, i64 %t48)
  %t60 = getelementptr i8, ptr %t59, i64 %t48
  call void @olang_textcopy(ptr %t60, ptr %t51, i64 %t52)
  %t61 = getelementptr i8, ptr %t60, i64 %t52
  call void @olang_textcopy(ptr %t61, ptr %t54, i64 %t55)
  %t62 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t57, 1
  %t65 = extractvalue { i64, ptr } %t63, 0
  %t66 = extractvalue { i64, ptr } %t63, 1
  %t67 = mul i64 %t65, 1
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @llvm.memcpy.p0.p0.i64(ptr %t68, ptr %t66, i64 %t67, i1 false)
  %t69 = insertvalue { i64, ptr } undef, i64 %t65, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t73 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t32, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d135, i32 0, i32 1) }, { i64, ptr } %t70)
  store { i64, ptr } %t73, ptr %l19
  br label %bb5
bb5:
  %t74 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t75 = extractvalue { i64, ptr } %t74, 0
  %t76 = extractvalue { i64, ptr } %t74, 1
  %t77 = mul i64 %t75, 1
  %t78 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t77)
  call void @llvm.memcpy.p0.p0.i64(ptr %t78, ptr %t76, i64 %t77, i1 false)
  %t79 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t80 = insertvalue { i64, ptr } %t79, ptr %t78, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t80)
  br label %bb6
bb6:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t82)
  store { i64, ptr } %t84, ptr %l23
  br label %bb7
bb7:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l24, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t86 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t87 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t85, { i64, ptr } %t86, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t88 = extractvalue { i32, %"std/os:Output" } %t87, 1
  %t89 = extractvalue { i32, %"std/os:Output" } %t87, 0
  store i32 %t89, ptr %l26
  %t90 = icmp ne i32 %t89, 0
  br i1 %t90, label %bb9, label %ok.91, !prof !99
ok.91:
  store %"std/os:Output" %t88, ptr %l25
  br label %bb8
bb8:
  %t92 = load %"std/os:Output", ptr %l25
  store %"std/os:Output" %t92, ptr %l21
  br label %bb13
bb9:
  %t93 = load i32, ptr %l26, !tbaa !23
  %t94 = ashr i32 %t93, 16
  %t96 = icmp eq i32 %t94, 1
  store i1 %t96, ptr %l28, !tbaa !21
  %t97 = load i32, ptr %l26, !tbaa !23
  %t98 = ashr i32 %t97, 16
  %t100 = icmp eq i32 %t98, 1
  br i1 %t100, label %bb10, label %bb11
bb10:
  call void @__olang_errpay_pop()
  br label %bb11
bb11:
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb13:
  %t103 = load %"std/os:Output", ptr %l21
  store %"std/os:Output" %t103, ptr %l3
  %t104 = getelementptr %"std/os:Output", ptr %l3, i32 0, i32 0
  %t105 = load i32, ptr %t104, !tbaa !23
  %t107 = icmp eq i32 %t105, 0
  br i1 %t107, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s5
  %t109 = load ptr, ptr %l0, !tbaa !29
  %t110 = load ptr, ptr %l0, !tbaa !29
  %t112 = getelementptr %"compiler/build:Config", ptr %t110, i32 0, i32 10
  %t113 = load { i64, ptr }, ptr %t112, !tbaa !27
  %t114 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d136, i32 0, i32 1) }, 1
  %t115 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d136, i32 0, i32 1) }, 0
  %t117 = extractvalue { i64, ptr } %t113, 1
  %t118 = extractvalue { i64, ptr } %t113, 0
  %t119 = add i64 %t115, %t118
  %t120 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d137, i32 0, i32 1) }, 1
  %t121 = extractvalue { i64, ptr } { i64 16, ptr getelementptr inbounds (<{ i64, [16 x i8] }>, ptr @.d137, i32 0, i32 1) }, 0
  %t122 = add i64 %t119, %t121
  %t123 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t122)
  call void @olang_textcopy(ptr %t123, ptr %t114, i64 %t115)
  %t124 = getelementptr i8, ptr %t123, i64 %t115
  call void @olang_textcopy(ptr %t124, ptr %t117, i64 %t118)
  %t125 = getelementptr i8, ptr %t124, i64 %t118
  call void @olang_textcopy(ptr %t125, ptr %t120, i64 %t121)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t123, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } %t127, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t137 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s5, ptr %s5, ptr %s5, ptr %t109, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d138, i32 0, i32 1) }, { i64, ptr } %t134)
  store { i64, ptr } %t137, ptr %l39
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t138 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  %t140 = extractvalue { i64, ptr } %t138, 1
  %t141 = mul i64 %t139, 1
  %t142 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t141)
  call void @llvm.memcpy.p0.p0.i64(ptr %t142, ptr %t140, i64 %t141, i1 false)
  %t143 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t142, 1
  call void @compiler_2fbuild_2esayln(ptr %s5, { i64, ptr } %t144)
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb18:
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load ptr, ptr %l0, !tbaa !29
  %t150 = getelementptr %"compiler/build:Config", ptr %t148, i32 0, i32 10
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  %t152 = load ptr, ptr %l2, !tbaa !29
  %t154 = getelementptr %"compiler/build:Program", ptr %t152, i32 0, i32 6
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t156 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d139, i32 0, i32 1) }, 1
  %t157 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d139, i32 0, i32 1) }, 0
  %t159 = extractvalue { i64, ptr } %t151, 1
  %t160 = extractvalue { i64, ptr } %t151, 0
  %t161 = add i64 %t157, %t160
  %t162 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d140, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 28, ptr getelementptr inbounds (<{ i64, [28 x i8] }>, ptr @.d140, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t166 = extractvalue { i64, ptr } %t155, 1
  %t167 = extractvalue { i64, ptr } %t155, 0
  %t168 = add i64 %t164, %t167
  %t169 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d141, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d141, i32 0, i32 1) }, 0
  %t171 = add i64 %t168, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t156, i64 %t157)
  %t173 = getelementptr i8, ptr %t172, i64 %t157
  call void @olang_textcopy(ptr %t173, ptr %t159, i64 %t160)
  %t174 = getelementptr i8, ptr %t173, i64 %t160
  call void @olang_textcopy(ptr %t174, ptr %t162, i64 %t163)
  %t175 = getelementptr i8, ptr %t174, i64 %t163
  call void @olang_textcopy(ptr %t175, ptr %t166, i64 %t167)
  %t176 = getelementptr i8, ptr %t175, i64 %t167
  call void @olang_textcopy(ptr %t176, ptr %t169, i64 %t170)
  %t177 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t172, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t188 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %t147, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d142, i32 0, i32 1) }, { i64, ptr } %t185)
  store { i64, ptr } %t188, ptr %l49
  br label %bb19
bb19:
  %t189 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = extractvalue { i64, ptr } %t189, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t195)
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ekeep(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca i1
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l13 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l24 = alloca i1
  %l27 = alloca i32
  %l29 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i32
  %l37 = alloca i32
  %l39 = alloca i1
  %l44 = alloca i32
  %l46 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i1
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 26
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t4, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d143, i32 0, i32 1) })
  store i1 %t6, ptr %l6
  br label %bb1
bb1:
  %t7 = load i1, ptr %l6, !tbaa !21
  br i1 %t7, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 26
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l8, !tbaa !27
  %t12 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t12, ptr %l9, !tbaa !27
  %t13 = load ptr, ptr %l0, !tbaa !29
  %t15 = getelementptr %"compiler/build:Config", ptr %t13, i32 0, i32 0
  %t16 = load { i64, ptr }, ptr %t15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t16, 0
  %t20 = add i64 %t18, 1
  store i64 %t20, ptr %l13, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t24 = extractvalue { i64, ptr } %t21, 0
  store i64 %t24, ptr %l16, !tbaa !24
  %t25 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 0
  store i64 %t26, ptr %l17, !tbaa !24
  %t27 = load i64, ptr %l13, !tbaa !24
  %t28 = icmp sge i64 %t27, 0
  br i1 %t28, label %bb5, label %bb6
bb5:
  %t30 = load i64, ptr %l13, !tbaa !24
  %t31 = load i64, ptr %l16, !tbaa !24
  %t32 = icmp sle i64 %t30, %t31
  br i1 %t32, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb7:
  %t34 = load i64, ptr %l16, !tbaa !24
  %t35 = load i64, ptr %l17, !tbaa !24
  %t36 = icmp sle i64 %t34, %t35
  br i1 %t36, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb9:
  %t38 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t39 = load ptr, ptr %t38, !tbaa !27
  %t40 = load i64, ptr %l13, !tbaa !24
  %t41 = load i64, ptr %l16, !tbaa !24
  %t42 = getelementptr i8, ptr %t39, i64 %t40
  %t43 = sub i64 %t41, %t40
  %t44 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t46 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d144, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t53 = extractvalue { i64, ptr } %t45, 1
  %t54 = extractvalue { i64, ptr } %t45, 0
  %t55 = add i64 %t51, %t54
  %t56 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t55)
  call void @olang_textcopy(ptr %t56, ptr %t47, i64 %t48)
  %t57 = getelementptr i8, ptr %t56, i64 %t48
  call void @olang_textcopy(ptr %t57, ptr %t49, i64 %t50)
  %t58 = getelementptr i8, ptr %t57, i64 %t50
  call void @olang_textcopy(ptr %t58, ptr %t53, i64 %t54)
  %t59 = insertvalue { i64, ptr } undef, i64 %t55, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t56, 1
  store { i64, ptr } %t60, ptr %l2, !tbaa !27
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t64 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t62)
  store i1 %t64, ptr %l24
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2)
  unreachable
bb11:
  %t65 = load i1, ptr %l24, !tbaa !21
  br i1 %t65, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb13:
  br label %bb14
bb14:
  %t66 = load ptr, ptr %l0, !tbaa !29
  %t68 = getelementptr %"compiler/build:Config", ptr %t66, i32 0, i32 26
  %t69 = load { i64, ptr }, ptr %t68, !tbaa !27
  %t71 = call i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %t69)
  store i32 %t71, ptr %l27
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb16, label %ok.73, !prof !99
ok.73:
  br label %bb15
bb15:
  br label %bb20
bb16:
  %t74 = load i32, ptr %l27, !tbaa !23
  %t75 = ashr i32 %t74, 16
  %t77 = icmp eq i32 %t75, 1
  store i1 %t77, ptr %l29, !tbaa !21
  %t78 = load i32, ptr %l27, !tbaa !23
  %t79 = ashr i32 %t78, 16
  %t81 = icmp eq i32 %t79, 1
  br i1 %t81, label %bb17, label %bb18
bb17:
  call void @__olang_errpay_pop()
  br label %bb18
bb18:
  br label %bb19
bb19:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb20:
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t83, ptr %l32, !tbaa !27
  %t84 = call i32 @getpid()
  store i32 %t84, ptr %l33
  br label %bb21
bb21:
  %t85 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d145, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = load i32, ptr %l33, !tbaa !23
  %t92 = sext i32 %t91 to i64
  %t93 = call i64 @__olang_fmt_i64(ptr null, i64 %t92)
  %t94 = add i64 %t90, %t93
  %t95 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) }, 1
  %t96 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d146, i32 0, i32 1) }, 0
  %t97 = add i64 %t94, %t96
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t86, i64 %t87)
  %t99 = getelementptr i8, ptr %t98, i64 %t87
  call void @olang_textcopy(ptr %t99, ptr %t88, i64 %t89)
  %t100 = getelementptr i8, ptr %t99, i64 %t89
  %t101 = call i64 @__olang_fmt_i64(ptr %t100, i64 %t92)
  %t102 = getelementptr i8, ptr %t100, i64 %t93
  call void @olang_textcopy(ptr %t102, ptr %t95, i64 %t96)
  %t103 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t98, 1
  store { i64, ptr } %t104, ptr %l3, !tbaa !27
  %t106 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t110 = call i32 @std_2fos_2eLink(ptr %v1, ptr %s0, { i64, ptr } %t106, { i64, ptr } %t107)
  store i32 %t110, ptr %l37
  %t111 = icmp ne i32 %t110, 0
  br i1 %t111, label %bb23, label %ok.112, !prof !99
ok.112:
  br label %bb22
bb22:
  br label %bb27
bb23:
  %t113 = load i32, ptr %l37, !tbaa !23
  %t114 = ashr i32 %t113, 16
  %t116 = icmp eq i32 %t114, 1
  store i1 %t116, ptr %l39, !tbaa !21
  %t117 = load i32, ptr %l37, !tbaa !23
  %t118 = ashr i32 %t117, 16
  %t120 = icmp eq i32 %t118, 1
  br i1 %t120, label %bb24, label %bb25
bb24:
  call void @__olang_errpay_pop()
  br label %bb25
bb25:
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb27:
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t123 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t126 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t122, { i64, ptr } %t123)
  store i32 %t126, ptr %l44
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb29, label %ok.128, !prof !99
ok.128:
  br label %bb28
bb28:
  br label %bb39
bb29:
  %t129 = load i32, ptr %l44, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  store i1 %t132, ptr %l46, !tbaa !21
  %t133 = load i32, ptr %l44, !tbaa !23
  %t134 = ashr i32 %t133, 16
  %t136 = icmp eq i32 %t134, 1
  br i1 %t136, label %bb30, label %bb31
bb30:
  call void @__olang_errpay_pop()
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t138 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t140 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t138)
  store i32 %t140, ptr %l50
  %t141 = icmp ne i32 %t140, 0
  br i1 %t141, label %bb34, label %ok.142, !prof !99
ok.142:
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t143 = load i32, ptr %l50, !tbaa !23
  %t144 = ashr i32 %t143, 16
  %t146 = icmp eq i32 %t144, 1
  store i1 %t146, ptr %l52, !tbaa !21
  %t147 = load i32, ptr %l50, !tbaa !23
  %t148 = ashr i32 %t147, 16
  %t150 = icmp eq i32 %t148, 1
  br i1 %t150, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca [2 x { i64, ptr }]
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l13 = alloca i1
  %l15 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l45 = alloca i1
  %l51 = alloca i32
  %l53 = alloca i1
  %l54 = alloca ptr
  %l55 = alloca { i64, [3 x i64] }
  %l57 = alloca %"compiler/diagmsg:Msg"
  %l59 = alloca i32
  %l64 = alloca i32
  %l66 = alloca i1
  %l69 = alloca { i64, ptr }
  %l70 = alloca %"compiler/diagmsg:Msg"
  %l73 = alloca i32
  %l81 = alloca ptr
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t135 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fbuild_2eLibName(ptr %v3, ptr %s0, { i64, ptr } %a3)
  store { i64, ptr } %t3, ptr %l10
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t4, ptr %l5, !tbaa !27
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"compiler/build:Config", ptr %t5, i32 0, i32 21
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d147, i32 0, i32 1) })
  store i1 %t10, ptr %l13
  br label %bb2
bb2:
  %t11 = load i1, ptr %l13, !tbaa !21
  %t12 = xor i1 %t11, true
  br i1 %t12, label %bb3, label %bb4
bb3:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t16 = getelementptr %"compiler/build:Config", ptr %t14, i32 0, i32 21
  %t17 = load { i64, ptr }, ptr %t16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t17, 1
  %t20 = extractvalue { i64, ptr } %t17, 0
  %t21 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t20)
  call void @olang_textcopy(ptr %t21, ptr %t19, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t20, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l15, !tbaa !27
  br label %bb7
bb4:
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"compiler/build:Config", ptr %t25, i32 0, i32 0
  %t28 = load { i64, ptr }, ptr %t27, !tbaa !27
  store { i64, ptr } %t28, ptr %l20, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t29, ptr %l21, !tbaa !27
  %t30 = load ptr, ptr %l0, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t30)
  store { i64, ptr } %t32, ptr %l23
  br label %bb5
bb5:
  %t33 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d148, i32 0, i32 1) }, ptr %l26, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d149, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t42 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t43 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t44 = call { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t40, { i64, ptr } %t42, { i64, ptr } %t43)
  store { i64, ptr } %t44, ptr %l28
  br label %bb6
bb6:
  %t45 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t46 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t47 = extractvalue { i64, ptr } %t46, 1
  %t48 = extractvalue { i64, ptr } %t46, 0
  %t49 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 1
  %t50 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d150, i32 0, i32 1) }, 0
  %t51 = add i64 %t48, %t50
  %t52 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t57 = extractvalue { i64, ptr } %t45, 1
  %t58 = extractvalue { i64, ptr } %t45, 0
  %t59 = add i64 %t55, %t58
  %t60 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d151, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d151, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t47, i64 %t48)
  %t64 = getelementptr i8, ptr %t63, i64 %t48
  call void @olang_textcopy(ptr %t64, ptr %t49, i64 %t50)
  %t65 = getelementptr i8, ptr %t64, i64 %t50
  call void @olang_textcopy(ptr %t65, ptr %t53, i64 %t54)
  %t66 = getelementptr i8, ptr %t65, i64 %t54
  call void @olang_textcopy(ptr %t66, ptr %t57, i64 %t58)
  %t67 = getelementptr i8, ptr %t66, i64 %t58
  call void @olang_textcopy(ptr %t67, ptr %t60, i64 %t61)
  %t68 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t63, 1
  store { i64, ptr } %t69, ptr %l15, !tbaa !27
  br label %bb7
bb7:
  %t71 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t71, ptr %l6, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t74 = call { i64, ptr } @std_2ffilepath_2eDir(ptr %s0, ptr %s0, { i64, ptr } %t72)
  store { i64, ptr } %t74, ptr %l32
  br label %bb8
bb8:
  %t75 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = extractvalue { i64, ptr } %t75, 0
  %t79 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d152, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t82 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t81)
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = getelementptr i8, ptr %t82, i64 %t78
  call void @olang_textcopy(ptr %t83, ptr %t79, i64 %t80)
  %t84 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t82, 1
  %t87 = extractvalue { i64, ptr } %t85, 0
  %t88 = extractvalue { i64, ptr } %t85, 1
  %t89 = mul i64 %t87, 1
  %t90 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t88, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t87, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  %t93 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t94 = insertvalue [2 x { i64, ptr }] undef, { i64, ptr } %t93, 0
  %t96 = insertvalue [2 x { i64, ptr }] %t94, { i64, ptr } %t92, 1
  store [2 x { i64, ptr }] %t96, ptr %l7
  %t99 = insertvalue { i64, ptr } undef, i64 2, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %l7, 1
  %t102 = call { i64, ptr } @std_2ffilepath_2eJoin(ptr %s0, ptr %s0, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l39
  br label %bb9
bb9:
  %t103 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t103, ptr %l8, !tbaa !27
  %t104 = load ptr, ptr %l0, !tbaa !29
  store ptr %t104, ptr %l40, !tbaa !29
  store ptr %a2, ptr %l41, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t106, ptr %l42, !tbaa !27
  %t107 = load ptr, ptr %l1, !tbaa !29
  %t109 = getelementptr %"compiler/build:Program", ptr %t107, i32 0, i32 2
  %t110 = load { i64, ptr }, ptr %t109, !tbaa !27
  %t112 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t110, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d153, i32 0, i32 1) })
  store i1 %t112, ptr %l45
  br label %bb10
bb10:
  %t113 = load i1, ptr %l45, !tbaa !21
  %t114 = xor i1 %t113, true
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/build:Program", ptr %t115, i32 0, i32 3
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/build:Program", ptr %t118, i32 0, i32 4
  %t121 = load ptr, ptr %l40, !tbaa !29
  %t122 = load ptr, ptr %l41, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t127 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v2, ptr %s0, ptr %v1, ptr %v1, ptr %t121, ptr %t122, { i64, ptr } %t123, i1 %t114, ptr %t117, ptr %t120)
  store i32 %t127, ptr %l51
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb12, label %ok.129, !prof !99
ok.129:
  br label %bb11
bb11:
  br label %bb17
bb12:
  %t130 = load i32, ptr %l51, !tbaa !23
  %t131 = ashr i32 %t130, 16
  %t133 = icmp eq i32 %t131, 1
  store i1 %t133, ptr %l53, !tbaa !21
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t134 = load ptr, ptr %l4, !tbaa !29
  store ptr %t134, ptr %l54, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t135
  %t136 = getelementptr { i64, [3 x i64] }, ptr %t135, i32 0, i32 0
  store i64 0, ptr %t136
  %t137 = load { i64, [3 x i64] }, ptr %t135
  store { i64, [3 x i64] } %t137, ptr %l55
  %t138 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t140 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s4, { i64, ptr } %t138)
  store %"compiler/diagmsg:Msg" %t140, ptr %l57
  br label %bb14
bb14:
  %t141 = load ptr, ptr %l54, !tbaa !29
  %t142 = load { i64, [3 x i64] }, ptr %l55
  %t143 = load %"compiler/diagmsg:Msg", ptr %l57
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s4, ptr %t141, { i64, [3 x i64] } %t142, %"compiler/diagmsg:Msg" %t143)
  br label %bb15
bb15:
  %t144 = load ptr, ptr %l4, !tbaa !29
  %t146 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t144)
  store i32 %t146, ptr %l59
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t147 = load i32, ptr %l59, !tbaa !23
  store i32 %t147, ptr %rv
  br label %ret
bb17:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d154, i32 0, i32 1) })
  br label %bb18
bb18:
  %t148 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t149 = load ptr, ptr %l1, !tbaa !29
  %t151 = getelementptr %"compiler/build:Program", ptr %t149, i32 0, i32 5
  %t152 = load { i64, ptr }, ptr %t151, !tbaa !27
  %t156 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v1, { i64, ptr } %t148, { i64, ptr } %t152)
  store i32 %t156, ptr %l64
  %t157 = icmp ne i32 %t156, 0
  br i1 %t157, label %bb20, label %ok.158, !prof !99
ok.158:
  br label %bb19
bb19:
  br label %bb27
bb20:
  %t159 = load i32, ptr %l64, !tbaa !23
  %t160 = ashr i32 %t159, 16
  %t162 = icmp eq i32 %t160, 1
  store i1 %t162, ptr %l66, !tbaa !21
  %t163 = load i32, ptr %l64, !tbaa !23
  %t164 = ashr i32 %t163, 16
  %t166 = icmp eq i32 %t164, 1
  br i1 %t166, label %bb21, label %bb22
bb21:
  call void @__olang_errpay_pop()
  br label %bb22
bb22:
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t168 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t168, ptr %l69, !tbaa !27
  %t169 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s5)
  store %"compiler/diagmsg:Msg" %t169, ptr %l70
  br label %bb24
bb24:
  %t170 = load ptr, ptr %l4, !tbaa !29
  %t171 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t172 = load %"compiler/diagmsg:Msg", ptr %l70
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s5, ptr %v4, { i64, ptr } %t171, %"compiler/diagmsg:Msg" %t172, ptr %t170)
  br label %bb25
bb25:
  %t174 = load ptr, ptr %l4, !tbaa !29
  %t176 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t174)
  store i32 %t176, ptr %l73
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t177 = load i32, ptr %l73, !tbaa !23
  store i32 %t177, ptr %rv
  br label %ret
bb27:
  %t178 = load ptr, ptr %l0, !tbaa !29
  %t179 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 1
  %t182 = extractvalue { i64, ptr } %t179, 0
  %t183 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t181, i64 %t182)
  %t184 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t195 = getelementptr %"compiler/build:Config", ptr %t178, i32 0, i32 22
  store { i64, ptr } %t192, ptr %t195, !tbaa !27
  %t196 = load ptr, ptr %l0, !tbaa !29
  %t198 = getelementptr %"compiler/build:Config", ptr %t196, i32 0, i32 20
  %t199 = load i1, ptr %t198, !tbaa !21
  %t201 = xor i1 %t199, true
  br i1 %t201, label %bb28, label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s7
  %t203 = load ptr, ptr %l0, !tbaa !29
  store ptr %t203, ptr %l81, !tbaa !29
  %t204 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t206 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s7, { i64, ptr } %t204)
  store { i64, ptr } %t206, ptr %l83
  br label %bb30
bb29:
  br label %bb34
bb30:
  %t207 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t209 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s7, { i64, ptr } %t207)
  store { i64, ptr } %t209, ptr %l85
  br label %bb31
bb31:
  %t210 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d155, i32 0, i32 1) }, 1
  %t211 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d155, i32 0, i32 1) }, 0
  %t212 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 1
  %t214 = extractvalue { i64, ptr } %t212, 0
  %t215 = add i64 %t211, %t214
  %t216 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d156, i32 0, i32 1) }, 1
  %t217 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d156, i32 0, i32 1) }, 0
  %t218 = add i64 %t215, %t217
  %t219 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = add i64 %t218, %t221
  %t223 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t222)
  call void @olang_textcopy(ptr %t223, ptr %t210, i64 %t211)
  %t224 = getelementptr i8, ptr %t223, i64 %t211
  call void @olang_textcopy(ptr %t224, ptr %t213, i64 %t214)
  %t225 = getelementptr i8, ptr %t224, i64 %t214
  call void @olang_textcopy(ptr %t225, ptr %t216, i64 %t217)
  %t226 = getelementptr i8, ptr %t225, i64 %t217
  call void @olang_textcopy(ptr %t226, ptr %t220, i64 %t221)
  %t227 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t228 = insertvalue { i64, ptr } %t227, ptr %t223, 1
  %t230 = extractvalue { i64, ptr } %t228, 0
  %t231 = extractvalue { i64, ptr } %t228, 1
  %t232 = mul i64 %t230, 1
  %t233 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t232)
  call void @llvm.memcpy.p0.p0.i64(ptr %t233, ptr %t231, i64 %t232, i1 false)
  %t234 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t235 = insertvalue { i64, ptr } %t234, ptr %t233, 1
  %t236 = load ptr, ptr %l81, !tbaa !29
  %t238 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s7, ptr %s7, ptr %s7, ptr %t236, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d157, i32 0, i32 1) }, { i64, ptr } %t235)
  store { i64, ptr } %t238, ptr %l88
  br label %bb32
bb32:
  %t239 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 0
  %t241 = extractvalue { i64, ptr } %t239, 1
  %t242 = mul i64 %t240, 1
  %t243 = call ptr @__olang_scope_alloc(ptr %s7, i64 %t242)
  call void @llvm.memcpy.p0.p0.i64(ptr %t243, ptr %t241, i64 %t242, i1 false)
  %t244 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t245 = insertvalue { i64, ptr } %t244, ptr %t243, 1
  call void @compiler_2fbuild_2esayln(ptr %s7, { i64, ptr } %t245)
  br label %bb33
bb33:
  call void @__olang_scope_close(ptr %s7)
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, ptr %a6) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca ptr
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca ptr
  %l9 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca i64
  %l19 = alloca i64
  %l21 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l22 = alloca ptr
  %l23 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca %"std/os:Output"
  %l27 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l36 = alloca i64
  %l38 = alloca i64
  %l43 = alloca { i64, ptr }
  %l56 = alloca ptr
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l78 = alloca i64
  %l80 = alloca i64
  %l85 = alloca { i64, ptr }
  %l94 = alloca i64
  %l96 = alloca i64
  %l101 = alloca { i64, ptr }
  %l127 = alloca i1
  %l132 = alloca i1
  %l134 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca i64
  %l138 = alloca i64
  %l143 = alloca { i64, ptr }
  %l148 = alloca ptr
  %l150 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l155 = alloca i1
  %l161 = alloca i32
  %l163 = alloca %"std/os:Output"
  %l165 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l167 = alloca %"std/os:Output"
  %l168 = alloca i32
  %l170 = alloca i1
  %l173 = alloca %"std/os:Output"
  %l180 = alloca ptr
  %l181 = alloca { i64, [3 x i64] }
  %l185 = alloca %"compiler/diagmsg:Msg"
  %l187 = alloca ptr
  %l194 = alloca i32
  %l203 = alloca i32
  %l205 = alloca i1
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s29 = alloca %olang.scope
  %rv = alloca i32
  %t423 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  store ptr %a6, ptr %l6
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l27
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l27
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l7
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t5 = getelementptr %"compiler/build:Config", ptr %t3, i32 0, i32 1
  %t6 = load { i64, ptr }, ptr %t5, !tbaa !27
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = extractvalue { i64, ptr } %t6, 0
  %t10 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t9)
  call void @olang_textcopy(ptr %t10, ptr %t8, i64 %t9)
  %t11 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  %t15 = extractvalue { i64, ptr } %t12, 1
  %t16 = mul i64 %t14, 1
  %t17 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t16)
  call void @llvm.memcpy.p0.p0.i64(ptr %t17, ptr %t15, i64 %t16, i1 false)
  %t18 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t19 = insertvalue { i64, ptr } %t18, ptr %t17, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t19)
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t22 = load ptr, ptr %l0, !tbaa !29
  %t24 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eModeFlags(ptr %v0, ptr %s2, ptr %t22)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %l34
  br label %bb3
bb3:
  %t25 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  %t26 = call ptr @__olang_scope_alloc_a(ptr %s2, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t25, ptr %t26
  store ptr %t26, ptr %l8, !tbaa !29
  store i64 0, ptr %l9, !tbaa !24
  br label %bb4
bb4:
  %t28 = load i64, ptr %l9, !tbaa !24
  store i64 %t28, ptr %l36, !tbaa !24
  %t29 = load ptr, ptr %l8, !tbaa !29
  %t31 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s2, ptr %t29)
  store i64 %t31, ptr %l38
  br label %bb5
bb5:
  %t32 = load i64, ptr %l36, !tbaa !24
  %t33 = load i64, ptr %l38, !tbaa !24
  %t34 = icmp slt i64 %t32, %t33
  %t36 = xor i1 %t34, true
  br i1 %t36, label %bb6, label %bb7
bb6:
  br label %bb12
bb7:
  br label %bb8
bb8:
  %t38 = load ptr, ptr %l8, !tbaa !29
  %t39 = load i64, ptr %l9, !tbaa !24
  %t42 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s2, ptr %s2, ptr %t38, i64 %t39)
  store { i64, ptr } %t42, ptr %l43
  br label %bb9
bb9:
  %t43 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t43, 1
  %t47 = extractvalue { i64, ptr } %t43, 0
  %t48 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t47)
  call void @olang_textcopy(ptr %t48, ptr %t46, i64 %t47)
  %t49 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t48, 1
  %t52 = extractvalue { i64, ptr } %t50, 0
  %t53 = extractvalue { i64, ptr } %t50, 1
  %t54 = mul i64 %t52, 1
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t53, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t57)
  br label %bb10
bb10:
  br label %bb11
bb11:
  %t60 = load i64, ptr %l9, !tbaa !24
  %t62 = add i64 %t60, 1
  store i64 %t62, ptr %l9, !tbaa !24
  br label %bb4
bb12:
  call void @__olang_scope_close(ptr %s2)
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t66 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 25
  %t67 = load i1, ptr %t66, !tbaa !21
  br i1 %t67, label %bb13, label %bb14
bb13:
  %t69 = load i64, ptr @G_2ecompiler_2fbuild_2eImportLimit, !tbaa !24
  %t70 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d158, i32 0, i32 1) }, 1
  %t71 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d158, i32 0, i32 1) }, 0
  %t73 = call i64 @__olang_fmt_i64(ptr null, i64 %t69)
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t70, i64 %t71)
  %t76 = getelementptr i8, ptr %t75, i64 %t71
  %t77 = call i64 @__olang_fmt_i64(ptr %t76, i64 %t69)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t75, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t86)
  br label %bb15
bb14:
  br label %bb16
bb15:
  br label %bb16
bb16:
  store ptr %l7, ptr %l56, !tbaa !29
  %t89 = load i1, ptr %l4, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 25, ptr getelementptr inbounds (<{ i64, [25 x i8] }>, ptr @.d159, i32 0, i32 1) }, ptr %l59, !tbaa !27
  %t91 = load { i64, ptr }, ptr %l59, !tbaa !27
  store { i64, ptr } %t91, ptr %l58, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d160, i32 0, i32 1) }, ptr %l61, !tbaa !27
  %t93 = load { i64, ptr }, ptr %l61, !tbaa !27
  store { i64, ptr } %t93, ptr %l58, !tbaa !27
  br label %bb19
bb19:
  %t95 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t95, 0
  %t97 = extractvalue { i64, ptr } %t95, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  %t102 = load ptr, ptr %l56, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t102, { i64, ptr } %t101)
  br label %bb20
bb20:
  %t104 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t105 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d161, i32 0, i32 1) }, 1
  %t106 = extractvalue { i64, ptr } { i64 37, ptr getelementptr inbounds (<{ i64, [37 x i8] }>, ptr @.d161, i32 0, i32 1) }, 0
  %t108 = extractvalue { i64, ptr } %t104, 1
  %t109 = extractvalue { i64, ptr } %t104, 0
  %t110 = add i64 %t106, %t109
  %t111 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d162, i32 0, i32 1) }, 1
  %t112 = extractvalue { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d162, i32 0, i32 1) }, 0
  %t113 = add i64 %t110, %t112
  %t114 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t113)
  call void @olang_textcopy(ptr %t114, ptr %t105, i64 %t106)
  %t115 = getelementptr i8, ptr %t114, i64 %t106
  call void @olang_textcopy(ptr %t115, ptr %t108, i64 %t109)
  %t116 = getelementptr i8, ptr %t115, i64 %t109
  call void @olang_textcopy(ptr %t116, ptr %t111, i64 %t112)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t114, 1
  %t120 = extractvalue { i64, ptr } %t118, 0
  %t121 = extractvalue { i64, ptr } %t118, 1
  %t122 = mul i64 %t120, 1
  %t123 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t122)
  call void @llvm.memcpy.p0.p0.i64(ptr %t123, ptr %t121, i64 %t122, i1 false)
  %t124 = insertvalue { i64, ptr } undef, i64 %t120, 0
  %t125 = insertvalue { i64, ptr } %t124, ptr %t123, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t125)
  br label %bb21
bb21:
  %t128 = load { i64, ptr }, ptr @G_2ecompiler_2fbuild_2eRemarkPasses, !tbaa !27
  %t129 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d163, i32 0, i32 1) }, 1
  %t130 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d163, i32 0, i32 1) }, 0
  %t132 = extractvalue { i64, ptr } %t128, 1
  %t133 = extractvalue { i64, ptr } %t128, 0
  %t134 = add i64 %t130, %t133
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  call void @olang_textcopy(ptr %t135, ptr %t129, i64 %t130)
  %t136 = getelementptr i8, ptr %t135, i64 %t130
  call void @olang_textcopy(ptr %t136, ptr %t132, i64 %t133)
  %t137 = insertvalue { i64, ptr } undef, i64 %t134, 0
  %t138 = insertvalue { i64, ptr } %t137, ptr %t135, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = extractvalue { i64, ptr } %t138, 1
  %t142 = mul i64 %t140, 1
  %t143 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t142)
  call void @llvm.memcpy.p0.p0.i64(ptr %t143, ptr %t141, i64 %t142, i1 false)
  %t144 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t145 = insertvalue { i64, ptr } %t144, ptr %t143, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t145)
  br label %bb22
bb22:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d164, i32 0, i32 1) })
  br label %bb23
bb23:
  %t149 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 1
  %t152 = extractvalue { i64, ptr } %t149, 0
  %t153 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d165, i32 0, i32 1) }, 1
  %t154 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d165, i32 0, i32 1) }, 0
  %t155 = add i64 %t152, %t154
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @olang_textcopy(ptr %t156, ptr %t151, i64 %t152)
  %t157 = getelementptr i8, ptr %t156, i64 %t152
  call void @olang_textcopy(ptr %t157, ptr %t153, i64 %t154)
  %t158 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t156, 1
  %t161 = extractvalue { i64, ptr } %t159, 0
  %t162 = extractvalue { i64, ptr } %t159, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t166)
  br label %bb24
bb24:
  store ptr %a1, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb25
bb25:
  %t171 = load i64, ptr %l12, !tbaa !24
  store i64 %t171, ptr %l78, !tbaa !24
  %t172 = load ptr, ptr %l11, !tbaa !29
  %t174 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v1, ptr %t172)
  store i64 %t174, ptr %l80
  br label %bb26
bb26:
  %t175 = load i64, ptr %l78, !tbaa !24
  %t176 = load i64, ptr %l80, !tbaa !24
  %t177 = icmp slt i64 %t175, %t176
  %t179 = xor i1 %t177, true
  br i1 %t179, label %bb27, label %bb28
bb27:
  br label %bb33
bb28:
  br label %bb29
bb29:
  %t181 = load ptr, ptr %l11, !tbaa !29
  %t182 = load i64, ptr %l12, !tbaa !24
  %t185 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v1, ptr %v1, ptr %t181, i64 %t182)
  store { i64, ptr } %t185, ptr %l85
  br label %bb30
bb30:
  %t186 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t189 = extractvalue { i64, ptr } %t186, 1
  %t190 = extractvalue { i64, ptr } %t186, 0
  %t191 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t190)
  call void @olang_textcopy(ptr %t191, ptr %t189, i64 %t190)
  %t192 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = extractvalue { i64, ptr } %t193, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t200)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t203 = load i64, ptr %l12, !tbaa !24
  %t205 = add i64 %t203, 1
  store i64 %t205, ptr %l12, !tbaa !24
  br label %bb25
bb33:
  %t207 = load ptr, ptr %l2, !tbaa !29
  %t209 = getelementptr %"compiler/build:Program", ptr %t207, i32 0, i32 3
  store ptr %t209, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb34
bb34:
  %t211 = load i64, ptr %l15, !tbaa !24
  store i64 %t211, ptr %l94, !tbaa !24
  %t212 = load ptr, ptr %l14, !tbaa !29
  %t214 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t212)
  store i64 %t214, ptr %l96
  br label %bb35
bb35:
  %t215 = load i64, ptr %l94, !tbaa !24
  %t216 = load i64, ptr %l96, !tbaa !24
  %t217 = icmp slt i64 %t215, %t216
  %t219 = xor i1 %t217, true
  br i1 %t219, label %bb36, label %bb37
bb36:
  br label %bb42
bb37:
  br label %bb38
bb38:
  %t221 = load ptr, ptr %l14, !tbaa !29
  %t222 = load i64, ptr %l15, !tbaa !24
  %t225 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t221, i64 %t222)
  store { i64, ptr } %t225, ptr %l101
  br label %bb39
bb39:
  %t226 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = extractvalue { i64, ptr } %t226, 0
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @olang_textcopy(ptr %t231, ptr %t229, i64 %t230)
  %t232 = insertvalue { i64, ptr } undef, i64 %t230, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = extractvalue { i64, ptr } %t233, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t240)
  br label %bb40
bb40:
  br label %bb41
bb41:
  %t243 = load i64, ptr %l15, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l15, !tbaa !24
  br label %bb34
bb42:
  store %olang.scope zeroinitializer, ptr %s19
  %t247 = insertvalue [3 x { i64, ptr }] undef, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d166, i32 0, i32 1) }, 0
  %t248 = insertvalue [3 x { i64, ptr }] %t247, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d167, i32 0, i32 1) }, 1
  %t249 = insertvalue [3 x { i64, ptr }] %t248, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d168, i32 0, i32 1) }, 2
  %t251 = call ptr @__olang_scope_alloc_a(ptr %s19, i64 48, i64 8)
  store [3 x { i64, ptr }] %t249, ptr %t251
  store ptr %t251, ptr %l17
  store i64 0, ptr %l18, !tbaa !24
  %t253 = load ptr, ptr %l17
  store i64 3, ptr %l19, !tbaa !24
  br label %bb43
bb43:
  %t256 = load i64, ptr %l18, !tbaa !24
  %t257 = load i64, ptr %l19, !tbaa !24
  %t260 = icmp slt i64 %t256, %t257
  %t262 = xor i1 %t260, true
  br i1 %t262, label %bb44, label %bb45
bb44:
  br label %bb49
bb45:
  br label %bb46
bb46:
  %t264 = load ptr, ptr %l17
  %t265 = load i64, ptr %l18, !tbaa !24
  %t268 = getelementptr [3 x { i64, ptr }], ptr %t264, i64 0, i64 %t265
  %t269 = load { i64, ptr }, ptr %t268, !tbaa !37
  %t273 = extractvalue { i64, ptr } %t269, 1
  %t274 = extractvalue { i64, ptr } %t269, 0
  %t275 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t274)
  call void @olang_textcopy(ptr %t275, ptr %t273, i64 %t274)
  %t276 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t275, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } %t277, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t284)
  br label %bb47
bb47:
  br label %bb48
bb48:
  %t287 = load i64, ptr %l18, !tbaa !24
  %t289 = add i64 %t287, 1
  store i64 %t289, ptr %l18, !tbaa !24
  br label %bb43
bb49:
  call void @__olang_scope_close(ptr %s19)
  %t291 = load ptr, ptr %l2, !tbaa !29
  %t293 = getelementptr %"compiler/build:Program", ptr %t291, i32 0, i32 2
  %t294 = load { i64, ptr }, ptr %t293, !tbaa !27
  %t296 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t294, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d169, i32 0, i32 1) })
  store i1 %t296, ptr %l127
  br label %bb50
bb50:
  %t297 = load i1, ptr %l127, !tbaa !21
  %t298 = xor i1 %t297, true
  br i1 %t298, label %bb51, label %bb52
bb51:
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d170, i32 0, i32 1) })
  br label %bb53
bb52:
  br label %bb54
bb53:
  br label %bb54
bb54:
  %t301 = load ptr, ptr %l0, !tbaa !29
  %t303 = getelementptr %"compiler/build:Config", ptr %t301, i32 0, i32 1
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !27
  %t306 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t304, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d171, i32 0, i32 1) })
  store i1 %t306, ptr %l132
  br label %bb55
bb55:
  %t307 = load i1, ptr %l132, !tbaa !21
  br i1 %t307, label %bb56, label %bb57
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb57:
  br label %bb58
bb58:
  %t309 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t309, ptr %l134
  br label %bb59
bb59:
  %t310 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l134
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t310, ptr %l21
  store ptr %l7, ptr %l22, !tbaa !29
  store i64 0, ptr %l23, !tbaa !24
  br label %bb60
bb60:
  %t312 = load i64, ptr %l23, !tbaa !24
  store i64 %t312, ptr %l136, !tbaa !24
  %t313 = load ptr, ptr %l22, !tbaa !29
  %t315 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t313)
  store i64 %t315, ptr %l138
  br label %bb61
bb61:
  %t316 = load i64, ptr %l136, !tbaa !24
  %t317 = load i64, ptr %l138, !tbaa !24
  %t318 = icmp slt i64 %t316, %t317
  %t320 = xor i1 %t318, true
  br i1 %t320, label %bb62, label %bb63
bb62:
  br label %bb68
bb63:
  br label %bb64
bb64:
  %t322 = load ptr, ptr %l22, !tbaa !29
  %t323 = load i64, ptr %l23, !tbaa !24
  %t326 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t322, i64 %t323)
  store { i64, ptr } %t326, ptr %l143
  br label %bb65
bb65:
  %t327 = load { i64, ptr }, ptr %l143, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l21, { i64, ptr } %t327)
  br label %bb66
bb66:
  br label %bb67
bb67:
  %t331 = load i64, ptr %l23, !tbaa !24
  %t333 = add i64 %t331, 1
  store i64 %t333, ptr %l23, !tbaa !24
  br label %bb60
bb68:
  store ptr %l21, ptr %l148, !tbaa !29
  %t335 = load ptr, ptr %l0, !tbaa !29
  %t337 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t335)
  store { i64, ptr } %t337, ptr %l150
  br label %bb69
bb69:
  %t338 = load ptr, ptr %l148, !tbaa !29
  %t339 = load { i64, ptr }, ptr %l150, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t338, { i64, ptr } %t339)
  br label %bb70
bb70:
  %t341 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l21)
  store { i64, ptr } %t341, ptr %l152
  br label %bb71
bb71:
  %t342 = load { i64, ptr }, ptr %l152, !tbaa !27
  store { i64, ptr } %t342, ptr %l25, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t347 = call i1 @compiler_2fbuild_2emadeBefore(ptr %v3, ptr %s0, { i64, ptr } %t343, { i64, ptr } %t344)
  store i1 %t347, ptr %l155
  br label %bb72
bb72:
  %t348 = load i1, ptr %l155, !tbaa !21
  br i1 %t348, label %bb73, label %bb74
bb73:
  %t349 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t350 = load i1, ptr %l4, !tbaa !21
  %t351 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v3, ptr %v4, { i64, ptr } %t349, i1 %t350, ptr %t351)
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb76:
  %t355 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t356 = load ptr, ptr %l6, !tbaa !29
  %t359 = call i32 @compiler_2fbuild_2eafresh(ptr %v3, ptr %v5, { i64, ptr } %t355, ptr %t356)
  store i32 %t359, ptr %l161
  %t360 = icmp ne i32 %t359, 0
  br i1 %t360, label %bb78, label %ok.361, !prof !99
ok.361:
  br label %bb77
bb77:
  br label %bb79
bb78:
  %t362 = load i32, ptr %l161, !tbaa !23
  %t363 = lshr i32 %t362, 16
  %t364 = and i32 %t362, 65535
  %t365 = icmp eq i32 %t363, 1
  %t366 = select i1 %t365, i32 1, i32 0
  %t367 = icmp eq i32 %t362, 0
  %t368 = shl i32 %t366, 16
  %t369 = or i32 %t368, %t364
  %t370 = select i1 %t367, i32 0, i32 %t369
  call void @__olang_scope_close(ptr %s0)
  store i32 %t370, ptr %rv
  br label %ret
bb79:
  %t373 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t373, ptr %l165
  br label %bb80
bb80:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l166, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l165, !tbaa !27
  %t375 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t376 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t374, { i64, ptr } %t375, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t377 = extractvalue { i32, %"std/os:Output" } %t376, 1
  %t378 = extractvalue { i32, %"std/os:Output" } %t376, 0
  store i32 %t378, ptr %l168
  %t379 = icmp ne i32 %t378, 0
  br i1 %t379, label %bb82, label %ok.380, !prof !99
ok.380:
  store %"std/os:Output" %t377, ptr %l167
  br label %bb81
bb81:
  %t381 = load %"std/os:Output", ptr %l167
  store %"std/os:Output" %t381, ptr %l163
  br label %bb87
bb82:
  %t382 = load i32, ptr %l168, !tbaa !23
  %t383 = ashr i32 %t382, 16
  %t385 = icmp eq i32 %t383, 1
  store i1 %t385, ptr %l170, !tbaa !21
  %t386 = load i32, ptr %l168, !tbaa !23
  %t387 = ashr i32 %t386, 16
  %t389 = icmp eq i32 %t387, 1
  br i1 %t389, label %bb83, label %bb84
bb83:
  call void @__olang_errpay_pop()
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t391 = call %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %s0, ptr %s0, ptr %s0, i32 127, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d172, i32 0, i32 1) }, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d173, i32 0, i32 1) })
  store %"std/os:Output" %t391, ptr %l173
  br label %bb86
bb86:
  %t392 = load %"std/os:Output", ptr %l173
  store %"std/os:Output" %t392, ptr %l163
  br label %bb87
bb87:
  %t393 = load %"std/os:Output", ptr %l163
  store %"std/os:Output" %t393, ptr %l26
  %t394 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 0
  %t395 = load i32, ptr %t394, !tbaa !23
  %t397 = icmp ne i32 %t395, 0
  br i1 %t397, label %bb88, label %bb89
bb88:
  store %olang.scope zeroinitializer, ptr %s29
  %t399 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 1
  %t400 = load { i64, ptr }, ptr %t399, !tbaa !27
  %t401 = getelementptr %"std/os:Output", ptr %l26, i32 0, i32 2
  %t402 = load { i64, ptr }, ptr %t401, !tbaa !27
  %t404 = extractvalue { i64, ptr } %t400, 1
  %t405 = extractvalue { i64, ptr } %t400, 0
  %t407 = extractvalue { i64, ptr } %t402, 1
  %t408 = extractvalue { i64, ptr } %t402, 0
  %t409 = add i64 %t405, %t408
  %t410 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t409)
  call void @olang_textcopy(ptr %t410, ptr %t404, i64 %t405)
  %t411 = getelementptr i8, ptr %t410, i64 %t405
  call void @olang_textcopy(ptr %t411, ptr %t407, i64 %t408)
  %t412 = insertvalue { i64, ptr } undef, i64 %t409, 0
  %t413 = insertvalue { i64, ptr } %t412, ptr %t410, 1
  %t415 = extractvalue { i64, ptr } %t413, 0
  %t416 = extractvalue { i64, ptr } %t413, 1
  %t417 = mul i64 %t415, 1
  %t418 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t417)
  call void @llvm.memcpy.p0.p0.i64(ptr %t418, ptr %t416, i64 %t417, i1 false)
  %t419 = insertvalue { i64, ptr } undef, i64 %t415, 0
  %t420 = insertvalue { i64, ptr } %t419, ptr %t418, 1
  call void @compiler_2fbuild_2esayErr(ptr %s29, { i64, ptr } %t420)
  br label %bb90
bb89:
  br label %bb93
bb90:
  %t422 = load ptr, ptr %l6, !tbaa !29
  store ptr %t422, ptr %l180, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t423
  %t424 = getelementptr { i64, [3 x i64] }, ptr %t423, i32 0, i32 0
  store i64 0, ptr %t424
  %t425 = load { i64, [3 x i64] }, ptr %t423
  store { i64, [3 x i64] } %t425, ptr %l181
  %t426 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t428 = extractvalue { i64, ptr } %t426, 1
  %t429 = extractvalue { i64, ptr } %t426, 0
  %t430 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d174, i32 0, i32 1) }, 1
  %t431 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d174, i32 0, i32 1) }, 0
  %t432 = add i64 %t429, %t431
  %t433 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t432)
  call void @olang_textcopy(ptr %t433, ptr %t428, i64 %t429)
  %t434 = getelementptr i8, ptr %t433, i64 %t429
  call void @olang_textcopy(ptr %t434, ptr %t430, i64 %t431)
  %t435 = insertvalue { i64, ptr } undef, i64 %t432, 0
  %t436 = insertvalue { i64, ptr } %t435, ptr %t433, 1
  %t438 = extractvalue { i64, ptr } %t436, 0
  %t439 = extractvalue { i64, ptr } %t436, 1
  %t440 = mul i64 %t438, 1
  %t441 = call ptr @__olang_scope_alloc(ptr %s29, i64 %t440)
  call void @llvm.memcpy.p0.p0.i64(ptr %t441, ptr %t439, i64 %t440, i1 false)
  %t442 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t443 = insertvalue { i64, ptr } %t442, ptr %t441, 1
  %t445 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s29, ptr %s29, { i64, ptr } %t443)
  store %"compiler/diagmsg:Msg" %t445, ptr %l185
  br label %bb91
bb91:
  %t446 = load ptr, ptr %l180, !tbaa !29
  %t447 = load { i64, [3 x i64] }, ptr %l181
  %t448 = load %"compiler/diagmsg:Msg", ptr %l185
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v5, ptr %s29, ptr %t446, { i64, [3 x i64] } %t447, %"compiler/diagmsg:Msg" %t448)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s29)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb93:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d175, i32 0, i32 1) })
  br label %bb94
bb94:
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l187, !tbaa !29
  %t451 = load ptr, ptr %l187, !tbaa !29
  %t452 = getelementptr %"compiler/build:Config", ptr %t451, i32 0, i32 24
  %t453 = load i64, ptr %t452, !tbaa !24
  %t455 = add i64 %t453, 1
  %t457 = load ptr, ptr %l187, !tbaa !29
  %t458 = getelementptr %"compiler/build:Config", ptr %t457, i32 0, i32 24
  store i64 %t455, ptr %t458, !tbaa !24
  %t459 = load i1, ptr %l4, !tbaa !21
  br i1 %t459, label %bb95, label %bb96
bb95:
  %t461 = load ptr, ptr %l0, !tbaa !29
  %t462 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t463 = load ptr, ptr %l6, !tbaa !29
  %t467 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ebitcodeText(ptr %v0, ptr %v3, ptr %v5, ptr %t461, { i64, ptr } %t462, ptr %t463)
  store i32 %t467, ptr %l194
  %t468 = icmp ne i32 %t467, 0
  br i1 %t468, label %bb98, label %ok.469, !prof !99
ok.469:
  br label %bb97
bb96:
  br label %bb100
bb97:
  br label %bb99
bb98:
  %t470 = load i32, ptr %l194, !tbaa !23
  %t471 = lshr i32 %t470, 16
  %t472 = and i32 %t470, 65535
  %t473 = icmp eq i32 %t471, 1
  %t474 = select i1 %t473, i32 1, i32 0
  %t475 = icmp eq i32 %t470, 0
  %t476 = shl i32 %t474, 16
  %t477 = or i32 %t476, %t472
  %t478 = select i1 %t475, i32 0, i32 %t477
  call void @__olang_scope_close(ptr %s0)
  store i32 %t478, ptr %rv
  br label %ret
bb99:
  br label %bb100
bb100:
  %t480 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t480, 1
  %t483 = extractvalue { i64, ptr } %t480, 0
  %t484 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d176, i32 0, i32 1) }, 1
  %t485 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d176, i32 0, i32 1) }, 0
  %t486 = add i64 %t483, %t485
  %t487 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t486)
  call void @olang_textcopy(ptr %t487, ptr %t482, i64 %t483)
  %t488 = getelementptr i8, ptr %t487, i64 %t483
  call void @olang_textcopy(ptr %t488, ptr %t484, i64 %t485)
  %t489 = insertvalue { i64, ptr } undef, i64 %t486, 0
  %t490 = insertvalue { i64, ptr } %t489, ptr %t487, 1
  %t492 = extractvalue { i64, ptr } %t490, 0
  %t493 = extractvalue { i64, ptr } %t490, 1
  %t494 = mul i64 %t492, 1
  %t495 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t494)
  call void @llvm.memcpy.p0.p0.i64(ptr %t495, ptr %t493, i64 %t494, i1 false)
  %t496 = insertvalue { i64, ptr } undef, i64 %t492, 0
  %t497 = insertvalue { i64, ptr } %t496, ptr %t495, 1
  %t498 = load { i64, ptr }, ptr %l25, !tbaa !27
  %t500 = extractvalue { i64, ptr } %t498, 1
  %t501 = extractvalue { i64, ptr } %t498, 0
  %t502 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, 1
  %t503 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d177, i32 0, i32 1) }, 0
  %t504 = add i64 %t501, %t503
  %t505 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t504)
  call void @olang_textcopy(ptr %t505, ptr %t500, i64 %t501)
  %t506 = getelementptr i8, ptr %t505, i64 %t501
  call void @olang_textcopy(ptr %t506, ptr %t502, i64 %t503)
  %t507 = insertvalue { i64, ptr } undef, i64 %t504, 0
  %t508 = insertvalue { i64, ptr } %t507, ptr %t505, 1
  %t511 = extractvalue { i64, ptr } %t508, 0
  %t512 = extractvalue { i64, ptr } %t508, 1
  %t513 = mul i64 %t511, 1
  %t514 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t513)
  call void @llvm.memcpy.p0.p0.i64(ptr %t514, ptr %t512, i64 %t513, i1 false)
  %t515 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t516 = insertvalue { i64, ptr } %t515, ptr %t514, 1
  %t519 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t497, { i64, ptr } %t516)
  store i32 %t519, ptr %l203
  %t520 = icmp ne i32 %t519, 0
  br i1 %t520, label %bb102, label %ok.521, !prof !99
ok.521:
  br label %bb101
bb101:
  br label %bb106
bb102:
  %t522 = load i32, ptr %l203, !tbaa !23
  %t523 = ashr i32 %t522, 16
  %t525 = icmp eq i32 %t523, 1
  store i1 %t525, ptr %l205, !tbaa !21
  %t526 = load i32, ptr %l203, !tbaa !23
  %t527 = ashr i32 %t526, 16
  %t529 = icmp eq i32 %t527, 1
  br i1 %t529, label %bb103, label %bb104
bb103:
  call void @__olang_errpay_pop()
  br label %bb104
bb104:
  br label %bb105
bb105:
  br label %bb106
bb106:
  %t531 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t532 = load i1, ptr %l4, !tbaa !21
  %t533 = load ptr, ptr %l5, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v3, ptr %v4, { i64, ptr } %t531, i1 %t532, ptr %t533)
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca %"compiler/build:Unit"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i64
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l33 = alloca { { i64, ptr }, { i64, ptr } }
  %l34 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l48 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca %"compiler/build:Unit"
  %l68 = alloca i1
  %l75 = alloca i1
  %l82 = alloca i1
  %l84 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i64
  %l88 = alloca i64
  %l93 = alloca { i64, ptr }
  %l94 = alloca ptr
  %l96 = alloca { i64, ptr }
  %l100 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l102 = alloca i64
  %l104 = alloca i64
  %l109 = alloca { i64, ptr }
  %l120 = alloca ptr
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca i1
  %l133 = alloca i32
  %l135 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l136 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l138 = alloca i64
  %l140 = alloca i64
  %l146 = alloca { i64, ptr }
  %l153 = alloca i32
  %l155 = alloca i1
  %l158 = alloca { i64, ptr }
  %l159 = alloca %"compiler/diagmsg:Msg"
  %l162 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l171 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l173 = alloca i64
  %l175 = alloca i64
  %l180 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca i64
  %l193 = alloca { i64, ptr }
  %l218 = alloca ptr
  %l220 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l229 = alloca i64
  %l231 = alloca { i64, ptr }
  %l232 = alloca { { i64, ptr }, { i64, ptr } }
  %l233 = alloca { i64, ptr }
  %l234 = alloca i64
  %l235 = alloca { i64, ptr }
  %l236 = alloca { i64, ptr }
  %l237 = alloca i64
  %l238 = alloca { i64, ptr }
  %l239 = alloca ptr
  %l240 = alloca i64
  %l242 = alloca i64
  %l249 = alloca i64
  %l252 = alloca i64
  %l275 = alloca ptr
  %l276 = alloca { i64, [3 x i64] }
  %l281 = alloca %"compiler/diagmsg:Msg"
  %l286 = alloca i64
  %l290 = alloca i64
  %l293 = alloca i64
  %l315 = alloca i32
  %l317 = alloca i1
  %l329 = alloca i32
  %l331 = alloca i1
  %s0 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s26 = alloca %olang.scope
  %s34 = alloca %olang.scope
  %s39 = alloca %olang.scope
  %rv = alloca i32
  %t590 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l48
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l48
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l6
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t5 = getelementptr %"compiler/build:Program", ptr %t3, i32 0, i32 0
  store ptr %t5, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb2
bb2:
  %t7 = load i64, ptr %l8, !tbaa !24
  store i64 %t7, ptr %l51, !tbaa !24
  %t8 = load ptr, ptr %l7, !tbaa !29
  %t10 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %t8)
  store i64 %t10, ptr %l53
  br label %bb3
bb3:
  %t11 = load i64, ptr %l51, !tbaa !24
  %t12 = load i64, ptr %l53, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb4, label %bb5
bb4:
  br label %bb13
bb5:
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l7, !tbaa !29
  %t18 = load i64, ptr %l8, !tbaa !24
  %t21 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v1, ptr %v1, ptr %t17, i64 %t18)
  store %"compiler/build:Unit" %t21, ptr %l58
  br label %bb7
bb7:
  %t22 = load %"compiler/build:Unit", ptr %l58
  store %"compiler/build:Unit" %t22, ptr %l9
  %t23 = getelementptr %"compiler/build:Unit", ptr %l9, i32 0, i32 1
  %t24 = load i32, ptr %t23, !range !{i32 0, i32 5}
  %t26 = trunc i64 4 to i32
  %t27 = icmp eq i32 %t24, %t26
  %t29 = xor i1 %t27, true
  br i1 %t29, label %bb8, label %bb9
bb8:
  %t31 = getelementptr %"compiler/build:Unit", ptr %l9, i32 0, i32 2
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l6, { i64, ptr } %t32)
  br label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb11
bb11:
  br label %bb12
bb12:
  %t35 = load i64, ptr %l8, !tbaa !24
  %t37 = add i64 %t35, 1
  store i64 %t37, ptr %l8, !tbaa !24
  br label %bb2
bb13:
  %t39 = load ptr, ptr %l1, !tbaa !29
  %t41 = getelementptr %"compiler/build:Program", ptr %t39, i32 0, i32 1
  %t42 = load { i64, ptr }, ptr %t41, !tbaa !27
  %t44 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t42, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d178, i32 0, i32 1) })
  store i1 %t44, ptr %l68
  br label %bb14
bb14:
  %t45 = load i1, ptr %l68, !tbaa !21
  %t46 = xor i1 %t45, true
  br i1 %t46, label %bb15, label %bb16
bb15:
  %t48 = load ptr, ptr %l1, !tbaa !29
  %t50 = getelementptr %"compiler/build:Program", ptr %t48, i32 0, i32 1
  %t51 = load { i64, ptr }, ptr %t50, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l6, { i64, ptr } %t51)
  br label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb18
bb18:
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t56 = getelementptr %"compiler/build:Program", ptr %t54, i32 0, i32 2
  %t57 = load { i64, ptr }, ptr %t56, !tbaa !27
  %t59 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t57, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d179, i32 0, i32 1) })
  store i1 %t59, ptr %l75
  br label %bb19
bb19:
  %t60 = load i1, ptr %l75, !tbaa !21
  %t61 = xor i1 %t60, true
  br i1 %t61, label %bb20, label %bb21
bb20:
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t65 = getelementptr %"compiler/build:Program", ptr %t63, i32 0, i32 2
  %t66 = load { i64, ptr }, ptr %t65, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v1, ptr %l6, { i64, ptr } %t66)
  br label %bb22
bb21:
  br label %bb23
bb22:
  br label %bb23
bb23:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Config", ptr %t69, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t74 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t72, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d180, i32 0, i32 1) })
  store i1 %t74, ptr %l82
  br label %bb24
bb24:
  %t75 = load i1, ptr %l82, !tbaa !21
  br i1 %t75, label %bb25, label %bb26
bb25:
  call void @__olang_scope_close(ptr %s0)
  store i32 65537, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  %t77 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t77, ptr %l84
  br label %bb28
bb28:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l84
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l10
  store ptr %l6, ptr %l11, !tbaa !29
  store i64 0, ptr %l12, !tbaa !24
  br label %bb29
bb29:
  %t80 = load i64, ptr %l12, !tbaa !24
  store i64 %t80, ptr %l86, !tbaa !24
  %t81 = load ptr, ptr %l11, !tbaa !29
  %t83 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t81)
  store i64 %t83, ptr %l88
  br label %bb30
bb30:
  %t84 = load i64, ptr %l86, !tbaa !24
  %t85 = load i64, ptr %l88, !tbaa !24
  %t86 = icmp slt i64 %t84, %t85
  %t88 = xor i1 %t86, true
  br i1 %t88, label %bb31, label %bb32
bb31:
  br label %bb48
bb32:
  br label %bb33
bb33:
  %t90 = load ptr, ptr %l11, !tbaa !29
  %t91 = load i64, ptr %l12, !tbaa !24
  %t94 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t90, i64 %t91)
  store { i64, ptr } %t94, ptr %l93
  br label %bb34
bb34:
  %t95 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t95, ptr %l13, !tbaa !27
  store ptr %l10, ptr %l94, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t98 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %s0, ptr %s0, { i64, ptr } %t96)
  store { i64, ptr } %t98, ptr %l96
  br label %bb35
bb35:
  %t99 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t100 = extractvalue { i64, ptr } %t99, 0
  %t101 = extractvalue { i64, ptr } %t99, 1
  %t102 = mul i64 %t100, 1
  %t103 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t102)
  call void @llvm.memcpy.p0.p0.i64(ptr %t103, ptr %t101, i64 %t102, i1 false)
  %t104 = insertvalue { i64, ptr } undef, i64 %t100, 0
  %t105 = insertvalue { i64, ptr } %t104, ptr %t103, 1
  %t106 = load ptr, ptr %l94, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t106, { i64, ptr } %t105)
  br label %bb36
bb36:
  %t108 = load ptr, ptr %l0, !tbaa !29
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t112 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %s0, ptr %s0, ptr %t108, { i64, ptr } %t109)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t112, ptr %l100
  br label %bb37
bb37:
  %t113 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l100
  %t114 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t113, ptr %t114
  store ptr %t114, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  %t116 = load i64, ptr %l15, !tbaa !24
  store i64 %t116, ptr %l102, !tbaa !24
  %t117 = load ptr, ptr %l14, !tbaa !29
  %t119 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t117)
  store i64 %t119, ptr %l104
  br label %bb39
bb39:
  %t120 = load i64, ptr %l102, !tbaa !24
  %t121 = load i64, ptr %l104, !tbaa !24
  %t122 = icmp slt i64 %t120, %t121
  %t124 = xor i1 %t122, true
  br i1 %t124, label %bb40, label %bb41
bb40:
  br label %bb46
bb41:
  br label %bb42
bb42:
  %t126 = load ptr, ptr %l14, !tbaa !29
  %t127 = load i64, ptr %l15, !tbaa !24
  %t130 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t126, i64 %t127)
  store { i64, ptr } %t130, ptr %l109
  br label %bb43
bb43:
  %t131 = load { i64, ptr }, ptr %l109, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t131)
  br label %bb44
bb44:
  br label %bb45
bb45:
  %t135 = load i64, ptr %l15, !tbaa !24
  %t137 = add i64 %t135, 1
  store i64 %t137, ptr %l15, !tbaa !24
  br label %bb38
bb46:
  br label %bb47
bb47:
  %t139 = load i64, ptr %l12, !tbaa !24
  %t141 = add i64 %t139, 1
  store i64 %t141, ptr %l12, !tbaa !24
  br label %bb29
bb48:
  %t143 = load i1, ptr %l3, !tbaa !21
  %t145 = select i1 %t143, ptr @.c181, ptr @.c182
  %t146 = select i1 %t143, i64 4, i64 5
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t145, i64 %t146)
  %t148 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t152 = extractvalue { i64, ptr } %t149, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t156)
  br label %bb49
bb49:
  store ptr %l10, ptr %l120, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eclangVersion(ptr %v0, ptr %v0, ptr %t159)
  store { i64, ptr } %t161, ptr %l122
  br label %bb50
bb50:
  %t162 = load ptr, ptr %l120, !tbaa !29
  %t163 = load { i64, ptr }, ptr %l122, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %v0, ptr %t162, { i64, ptr } %t163)
  br label %bb51
bb51:
  %t165 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t165, ptr %l124
  br label %bb52
bb52:
  %t166 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t166, ptr %l17, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t168 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t171 = call i1 @compiler_2fbuild_2emadeBefore(ptr %v2, ptr %s0, { i64, ptr } %t167, { i64, ptr } %t168)
  store i1 %t171, ptr %l127
  br label %bb53
bb53:
  %t172 = load i1, ptr %l127, !tbaa !21
  br i1 %t172, label %bb54, label %bb55
bb54:
  %t173 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t174 = load i1, ptr %l3, !tbaa !21
  %t175 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v2, ptr %v3, { i64, ptr } %t173, i1 %t174, ptr %t175)
  br label %bb56
bb55:
  br label %bb57
bb56:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
bb57:
  %t179 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t180 = load ptr, ptr %l5, !tbaa !29
  %t183 = call i32 @compiler_2fbuild_2eafresh(ptr %v2, ptr %v4, { i64, ptr } %t179, ptr %t180)
  store i32 %t183, ptr %l133
  %t184 = icmp ne i32 %t183, 0
  br i1 %t184, label %bb59, label %ok.185, !prof !99
ok.185:
  br label %bb58
bb58:
  br label %bb60
bb59:
  %t186 = load i32, ptr %l133, !tbaa !23
  %t187 = lshr i32 %t186, 16
  %t188 = and i32 %t186, 65535
  %t189 = icmp eq i32 %t187, 1
  %t190 = select i1 %t189, i32 1, i32 0
  %t191 = icmp eq i32 %t186, 0
  %t192 = shl i32 %t190, 16
  %t193 = or i32 %t192, %t188
  %t194 = select i1 %t191, i32 0, i32 %t193
  call void @__olang_scope_close(ptr %s0)
  store i32 %t194, ptr %rv
  br label %ret
bb60:
  %t196 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t196, ptr %l135
  br label %bb61
bb61:
  %t197 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l135
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t197, ptr %l18
  %t198 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t198, ptr %l136
  br label %bb62
bb62:
  %t199 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l136
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t199, ptr %l19
  store ptr %l6, ptr %l20, !tbaa !29
  store i64 0, ptr %l21, !tbaa !24
  br label %bb63
bb63:
  store %olang.scope zeroinitializer, ptr %s17
  %t201 = load i64, ptr %l21, !tbaa !24
  store i64 %t201, ptr %l138, !tbaa !24
  %t202 = load ptr, ptr %l20, !tbaa !29
  %t204 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t202)
  store i64 %t204, ptr %l140
  br label %bb64
bb64:
  %t205 = load i64, ptr %l138, !tbaa !24
  %t206 = load i64, ptr %l140, !tbaa !24
  %t207 = icmp slt i64 %t205, %t206
  %t209 = xor i1 %t207, true
  br i1 %t209, label %bb65, label %bb66
bb65:
  call void @__olang_scope_close(ptr %s17)
  br label %bb108
bb66:
  br label %bb67
bb67:
  %t211 = load i64, ptr %l21, !tbaa !24
  store i64 %t211, ptr %l22, !tbaa !24
  %t213 = load ptr, ptr %l20, !tbaa !29
  %t214 = load i64, ptr %l21, !tbaa !24
  %t217 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t213, i64 %t214)
  store { i64, ptr } %t217, ptr %l146
  br label %bb68
bb68:
  %t218 = load { i64, ptr }, ptr %l146, !tbaa !27
  store { i64, ptr } %t218, ptr %l23, !tbaa !27
  %t219 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t220 = load i64, ptr %l22, !tbaa !24
  %t222 = extractvalue { i64, ptr } %t219, 1
  %t223 = extractvalue { i64, ptr } %t219, 0
  %t224 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d183, i32 0, i32 1) }, 0
  %t226 = add i64 %t223, %t225
  %t228 = call i64 @__olang_fmt_i64(ptr null, i64 %t220)
  %t229 = add i64 %t226, %t228
  %t230 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d184, i32 0, i32 1) }, 0
  %t232 = add i64 %t229, %t231
  %t233 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t232)
  call void @olang_textcopy(ptr %t233, ptr %t222, i64 %t223)
  %t234 = getelementptr i8, ptr %t233, i64 %t223
  call void @olang_textcopy(ptr %t234, ptr %t224, i64 %t225)
  %t235 = getelementptr i8, ptr %t234, i64 %t225
  %t236 = call i64 @__olang_fmt_i64(ptr %t235, i64 %t220)
  %t237 = getelementptr i8, ptr %t235, i64 %t228
  call void @olang_textcopy(ptr %t237, ptr %t230, i64 %t231)
  %t238 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t233, 1
  store { i64, ptr } %t239, ptr %l24, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t246 = call i32 @std_2fos_2eWriteFile(ptr %s17, ptr %s0, { i64, ptr } %t241, { i64, ptr } %t242)
  store i32 %t246, ptr %l153
  %t247 = icmp ne i32 %t246, 0
  br i1 %t247, label %bb70, label %ok.248, !prof !99
ok.248:
  br label %bb69
bb69:
  br label %bb76
bb70:
  %t249 = load i32, ptr %l153, !tbaa !23
  %t250 = ashr i32 %t249, 16
  %t252 = icmp eq i32 %t250, 1
  store i1 %t252, ptr %l155, !tbaa !21
  %t253 = load i32, ptr %l153, !tbaa !23
  %t254 = ashr i32 %t253, 16
  %t256 = icmp eq i32 %t254, 1
  br i1 %t256, label %bb71, label %bb72
bb71:
  call void @__olang_errpay_pop()
  br label %bb72
bb72:
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s19
  %t258 = load { i64, ptr }, ptr %l24, !tbaa !27
  store { i64, ptr } %t258, ptr %l158, !tbaa !27
  %t259 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s19)
  store %"compiler/diagmsg:Msg" %t259, ptr %l159
  br label %bb74
bb74:
  %t260 = load ptr, ptr %l5, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t262 = load %"compiler/diagmsg:Msg", ptr %l159
  call void @compiler_2fbuild_2efileFatal(ptr %s17, ptr %s19, ptr %v4, { i64, ptr } %t261, %"compiler/diagmsg:Msg" %t262, ptr %t260)
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb76:
  %t265 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t265, ptr %l162
  br label %bb77
bb77:
  %t266 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l162
  %t267 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t266, ptr %t267
  store ptr %t267, ptr %l25, !tbaa !29
  %t269 = load ptr, ptr %l25, !tbaa !29
  %t270 = load ptr, ptr %l0, !tbaa !29
  %t272 = getelementptr %"compiler/build:Config", ptr %t270, i32 0, i32 1
  %t273 = load { i64, ptr }, ptr %t272, !tbaa !27
  %t275 = extractvalue { i64, ptr } %t273, 1
  %t276 = extractvalue { i64, ptr } %t273, 0
  %t277 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t275, i64 %t276)
  %t278 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = extractvalue { i64, ptr } %t279, 1
  %t283 = mul i64 %t281, 1
  %t284 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t283)
  call void @llvm.memcpy.p0.p0.i64(ptr %t284, ptr %t282, i64 %t283, i1 false)
  %t285 = insertvalue { i64, ptr } undef, i64 %t281, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t269, { i64, ptr } %t286)
  br label %bb78
bb78:
  store %olang.scope zeroinitializer, ptr %s21
  %t289 = load ptr, ptr %l0, !tbaa !29
  %t290 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t293 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %s0, ptr %s21, ptr %t289, { i64, ptr } %t290)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t293, ptr %l171
  br label %bb79
bb79:
  %t294 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l171
  %t295 = call ptr @__olang_scope_alloc_a(ptr %s21, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t294, ptr %t295
  store ptr %t295, ptr %l26, !tbaa !29
  store i64 0, ptr %l27, !tbaa !24
  br label %bb80
bb80:
  %t297 = load i64, ptr %l27, !tbaa !24
  store i64 %t297, ptr %l173, !tbaa !24
  %t298 = load ptr, ptr %l26, !tbaa !29
  %t300 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s21, ptr %t298)
  store i64 %t300, ptr %l175
  br label %bb81
bb81:
  %t301 = load i64, ptr %l173, !tbaa !24
  %t302 = load i64, ptr %l175, !tbaa !24
  %t303 = icmp slt i64 %t301, %t302
  %t305 = xor i1 %t303, true
  br i1 %t305, label %bb82, label %bb83
bb82:
  br label %bb88
bb83:
  br label %bb84
bb84:
  %t307 = load ptr, ptr %l26, !tbaa !29
  %t308 = load i64, ptr %l27, !tbaa !24
  %t311 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s21, ptr %s21, ptr %t307, i64 %t308)
  store { i64, ptr } %t311, ptr %l180
  br label %bb85
bb85:
  %t312 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t313 = load ptr, ptr %l25, !tbaa !29
  %t316 = extractvalue { i64, ptr } %t312, 1
  %t317 = extractvalue { i64, ptr } %t312, 0
  %t318 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t317)
  call void @olang_textcopy(ptr %t318, ptr %t316, i64 %t317)
  %t319 = insertvalue { i64, ptr } undef, i64 %t317, 0
  %t320 = insertvalue { i64, ptr } %t319, ptr %t318, 1
  %t322 = extractvalue { i64, ptr } %t320, 0
  %t323 = extractvalue { i64, ptr } %t320, 1
  %t324 = mul i64 %t322, 1
  %t325 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t324)
  call void @llvm.memcpy.p0.p0.i64(ptr %t325, ptr %t323, i64 %t324, i1 false)
  %t326 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t327 = insertvalue { i64, ptr } %t326, ptr %t325, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t313, { i64, ptr } %t327)
  br label %bb86
bb86:
  br label %bb87
bb87:
  %t330 = load i64, ptr %l27, !tbaa !24
  %t332 = add i64 %t330, 1
  store i64 %t332, ptr %l27, !tbaa !24
  br label %bb80
bb88:
  call void @__olang_scope_close(ptr %s21)
  %t334 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t334, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d185, i32 0, i32 1) })
  br label %bb89
bb89:
  %t336 = load i1, ptr %l3, !tbaa !21
  br i1 %t336, label %bb90, label %bb91
bb90:
  %t338 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t338, { i64, ptr } { i64 10, ptr getelementptr inbounds (<{ i64, [10 x i8] }>, ptr @.d186, i32 0, i32 1) })
  br label %bb92
bb91:
  br label %bb93
bb92:
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s26
  %t340 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t340, ptr %l190, !tbaa !27
  %t341 = load i64, ptr %l22, !tbaa !24
  store i64 %t341, ptr %l191, !tbaa !24
  %t342 = load i1, ptr %l3, !tbaa !21
  br i1 %t342, label %bb94, label %bb95
bb94:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d187, i32 0, i32 1) }, ptr %l193, !tbaa !27
  br label %bb96
bb95:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d188, i32 0, i32 1) }, ptr %l193, !tbaa !27
  br label %bb96
bb96:
  %t344 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t345 = extractvalue { i64, ptr } %t344, 1
  %t346 = extractvalue { i64, ptr } %t344, 0
  %t347 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) }, 1
  %t348 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d189, i32 0, i32 1) }, 0
  %t349 = add i64 %t346, %t348
  %t350 = load i64, ptr %l191, !tbaa !24
  %t351 = call i64 @__olang_fmt_i64(ptr null, i64 %t350)
  %t352 = add i64 %t349, %t351
  %t353 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t354 = extractvalue { i64, ptr } %t353, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = add i64 %t352, %t355
  %t357 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t356)
  call void @olang_textcopy(ptr %t357, ptr %t345, i64 %t346)
  %t358 = getelementptr i8, ptr %t357, i64 %t346
  call void @olang_textcopy(ptr %t358, ptr %t347, i64 %t348)
  %t359 = getelementptr i8, ptr %t358, i64 %t348
  %t360 = call i64 @__olang_fmt_i64(ptr %t359, i64 %t350)
  %t361 = getelementptr i8, ptr %t359, i64 %t351
  call void @olang_textcopy(ptr %t361, ptr %t354, i64 %t355)
  %t362 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t363 = insertvalue { i64, ptr } %t362, ptr %t357, 1
  %t365 = extractvalue { i64, ptr } %t363, 0
  %t366 = extractvalue { i64, ptr } %t363, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  %t371 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t372 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t373 = load i64, ptr %l22, !tbaa !24
  %t374 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d190, i32 0, i32 1) }, 1
  %t375 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d190, i32 0, i32 1) }, 0
  %t377 = extractvalue { i64, ptr } %t372, 1
  %t378 = extractvalue { i64, ptr } %t372, 0
  %t379 = add i64 %t375, %t378
  %t380 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d191, i32 0, i32 1) }, 1
  %t381 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d191, i32 0, i32 1) }, 0
  %t382 = add i64 %t379, %t381
  %t384 = call i64 @__olang_fmt_i64(ptr null, i64 %t373)
  %t385 = add i64 %t382, %t384
  %t386 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d192, i32 0, i32 1) }, 1
  %t387 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d192, i32 0, i32 1) }, 0
  %t388 = add i64 %t385, %t387
  %t389 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t388)
  call void @olang_textcopy(ptr %t389, ptr %t374, i64 %t375)
  %t390 = getelementptr i8, ptr %t389, i64 %t375
  call void @olang_textcopy(ptr %t390, ptr %t377, i64 %t378)
  %t391 = getelementptr i8, ptr %t390, i64 %t378
  call void @olang_textcopy(ptr %t391, ptr %t380, i64 %t381)
  %t392 = getelementptr i8, ptr %t391, i64 %t381
  %t393 = call i64 @__olang_fmt_i64(ptr %t392, i64 %t373)
  %t394 = getelementptr i8, ptr %t392, i64 %t384
  call void @olang_textcopy(ptr %t394, ptr %t386, i64 %t387)
  %t395 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t389, 1
  %t398 = extractvalue { i64, ptr } %t396, 0
  %t399 = extractvalue { i64, ptr } %t396, 1
  %t400 = mul i64 %t398, 1
  %t401 = call ptr @__olang_scope_alloc(ptr %s26, i64 %t400)
  call void @llvm.memcpy.p0.p0.i64(ptr %t401, ptr %t399, i64 %t400, i1 false)
  %t402 = insertvalue { i64, ptr } undef, i64 %t398, 0
  %t403 = insertvalue { i64, ptr } %t402, ptr %t401, 1
  %t404 = insertvalue [4 x { i64, ptr }] undef, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d193, i32 0, i32 1) }, 0
  %t406 = insertvalue [4 x { i64, ptr }] %t404, { i64, ptr } %t370, 1
  %t408 = insertvalue [4 x { i64, ptr }] %t406, { i64, ptr } %t371, 2
  %t410 = insertvalue [4 x { i64, ptr }] %t408, { i64, ptr } %t403, 3
  %t412 = call ptr @__olang_scope_alloc_a(ptr %s26, i64 64, i64 8)
  store [4 x { i64, ptr }] %t410, ptr %t412
  store ptr %t412, ptr %l29
  store i64 0, ptr %l30, !tbaa !24
  %t414 = load ptr, ptr %l29
  store i64 4, ptr %l31, !tbaa !24
  br label %bb97
bb97:
  %t417 = load i64, ptr %l30, !tbaa !24
  %t418 = load i64, ptr %l31, !tbaa !24
  %t421 = icmp slt i64 %t417, %t418
  %t423 = xor i1 %t421, true
  br i1 %t423, label %bb98, label %bb99
bb98:
  br label %bb103
bb99:
  br label %bb100
bb100:
  %t425 = load ptr, ptr %l29
  %t426 = load i64, ptr %l30, !tbaa !24
  %t429 = getelementptr [4 x { i64, ptr }], ptr %t425, i64 0, i64 %t426
  %t430 = load { i64, ptr }, ptr %t429, !tbaa !37
  %t432 = load ptr, ptr %l25, !tbaa !29
  %t435 = extractvalue { i64, ptr } %t430, 1
  %t436 = extractvalue { i64, ptr } %t430, 0
  %t437 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t436)
  call void @olang_textcopy(ptr %t437, ptr %t435, i64 %t436)
  %t438 = insertvalue { i64, ptr } undef, i64 %t436, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t437, 1
  %t441 = extractvalue { i64, ptr } %t439, 0
  %t442 = extractvalue { i64, ptr } %t439, 1
  %t443 = mul i64 %t441, 1
  %t444 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t443)
  call void @llvm.memcpy.p0.p0.i64(ptr %t444, ptr %t442, i64 %t443, i1 false)
  %t445 = insertvalue { i64, ptr } undef, i64 %t441, 0
  %t446 = insertvalue { i64, ptr } %t445, ptr %t444, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %t432, { i64, ptr } %t446)
  br label %bb101
bb101:
  br label %bb102
bb102:
  %t449 = load i64, ptr %l30, !tbaa !24
  %t451 = add i64 %t449, 1
  store i64 %t451, ptr %l30, !tbaa !24
  br label %bb97
bb103:
  call void @__olang_scope_close(ptr %s26)
  store ptr %l18, ptr %l218, !tbaa !29
  %t453 = load ptr, ptr %l25, !tbaa !29
  %t455 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %s0, ptr %s0, ptr %t453)
  store { i64, ptr } %t455, ptr %l220
  br label %bb104
bb104:
  %t456 = load ptr, ptr %l218, !tbaa !29
  %t457 = load { i64, ptr }, ptr %l220, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t456, { i64, ptr } %t457)
  br label %bb105
bb105:
  %t458 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t460 = extractvalue { i64, ptr } %t458, 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %l19, i64 %t460)
  br label %bb106
bb106:
  call void @__olang_scope_close(ptr %s17)
  br label %bb107
bb107:
  %t463 = load i64, ptr %l21, !tbaa !24
  %t465 = add i64 %t463, 1
  store i64 %t465, ptr %l21, !tbaa !24
  br label %bb63
bb108:
  %t468 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l18)
  store { i64, ptr } %t468, ptr %l227
  br label %bb109
bb109:
  %t469 = load ptr, ptr %l0, !tbaa !29
  %t471 = call i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %t469)
  store i64 %t471, ptr %l229
  br label %bb110
bb110:
  %t473 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %l19)
  store { i64, ptr } %t473, ptr %l231
  br label %bb111
bb111:
  %t474 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t475 = load i64, ptr %l229, !tbaa !24
  %t476 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t477 = call { { i64, ptr }, { i64, ptr } } @compiler_2fbuild_2eRunAll(ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t474, i64 %t475, { i64, ptr } %t476)
  store { { i64, ptr }, { i64, ptr } } %t477, ptr %l232
  br label %bb112
bb112:
  %t478 = load { { i64, ptr }, { i64, ptr } }, ptr %l232
  store { { i64, ptr }, { i64, ptr } } %t478, ptr %l33
  %t479 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l33, i32 0, i32 0
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !27
  store { i64, ptr } %t480, ptr %l233, !tbaa !27
  %t481 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t482 = extractvalue { i64, ptr } %t481, 0
  store i64 %t482, ptr %l234, !tbaa !24
  %t483 = load i64, ptr %l234, !tbaa !24
  %t484 = mul i64 %t483, 4
  %t485 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t484)
  %t486 = insertvalue { i64, ptr } undef, i64 %t483, 0
  %t487 = insertvalue { i64, ptr } %t486, ptr %t485, 1
  store { i64, ptr } %t487, ptr %l235, !tbaa !27
  %t488 = getelementptr { i64, ptr }, ptr %l235, i32 0, i32 1
  %t489 = load ptr, ptr %t488, !tbaa !27
  %t490 = getelementptr { i64, ptr }, ptr %l233, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = load i64, ptr %l234, !tbaa !24
  %t493 = mul i64 %t492, 4
  call void @llvm.memmove.p0.p0.i64(ptr %t489, ptr %t491, i64 %t493, i1 false)
  %t494 = load { i64, ptr }, ptr %l235, !tbaa !27
  store { i64, ptr } %t494, ptr %l34, !tbaa !27
  %t495 = getelementptr { { i64, ptr }, { i64, ptr } }, ptr %l33, i32 0, i32 1
  %t496 = load { i64, ptr }, ptr %t495, !tbaa !27
  store { i64, ptr } %t496, ptr %l236, !tbaa !27
  %t497 = load { i64, ptr }, ptr %l236, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t497, 0
  store i64 %t498, ptr %l237, !tbaa !24
  %t499 = load i64, ptr %l237, !tbaa !24
  %t500 = mul i64 %t499, 16
  %t501 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t500)
  %t502 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t503 = insertvalue { i64, ptr } %t502, ptr %t501, 1
  store { i64, ptr } %t503, ptr %l238, !tbaa !27
  %t504 = getelementptr { i64, ptr }, ptr %l238, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %l236, i32 0, i32 1
  %t507 = load ptr, ptr %t506, !tbaa !27
  %t508 = load i64, ptr %l237, !tbaa !24
  %t509 = mul i64 %t508, 16
  call void @llvm.memmove.p0.p0.i64(ptr %t505, ptr %t507, i64 %t509, i1 false)
  %t510 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t510, ptr %l35, !tbaa !27
  %t511 = load ptr, ptr %l0, !tbaa !29
  store ptr %t511, ptr %l239, !tbaa !29
  %t512 = load ptr, ptr %l239, !tbaa !29
  %t513 = getelementptr %"compiler/build:Config", ptr %t512, i32 0, i32 23
  %t514 = load i64, ptr %t513, !tbaa !24
  store i64 %t514, ptr %l240, !tbaa !24
  %t516 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %s0, ptr %l18)
  store i64 %t516, ptr %l242
  br label %bb113
bb113:
  %t517 = load i64, ptr %l240, !tbaa !24
  %t518 = load i64, ptr %l242, !tbaa !24
  %t519 = add i64 %t517, %t518
  %t521 = load ptr, ptr %l239, !tbaa !29
  %t522 = getelementptr %"compiler/build:Config", ptr %t521, i32 0, i32 23
  store i64 %t519, ptr %t522, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  %t523 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t525 = extractvalue { i64, ptr } %t523, 0
  store i64 %t525, ptr %l37, !tbaa !24
  store i64 1, ptr %l38, !tbaa !24
  %t527 = load i64, ptr %l37, !tbaa !24
  %t528 = load i64, ptr %l36, !tbaa !24
  %t531 = icmp sgt i64 %t527, %t528
  br i1 %t531, label %bb114, label %bb115
bb114:
  %t533 = load i64, ptr %l38, !tbaa !24
  %t535 = icmp sgt i64 %t533, 0
  br i1 %t535, label %bb116, label %bb117
bb115:
  store i64 0, ptr %l249, !tbaa !24
  br label %bb119
bb116:
  %t537 = load i64, ptr %l37, !tbaa !24
  %t538 = load i64, ptr %l36, !tbaa !24
  %t541 = sub i64 %t537, %t538
  %t542 = load i64, ptr %l38, !tbaa !24
  %t545 = add i64 %t541, %t542
  %t547 = sub i64 %t545, 1
  %t548 = load i64, ptr %l38, !tbaa !24
  %t551 = sdiv i64 %t547, %t548
  store i64 %t551, ptr %l252, !tbaa !24
  br label %bb118
bb117:
  store i64 0, ptr %l252, !tbaa !24
  br label %bb118
bb118:
  %t553 = load i64, ptr %l252, !tbaa !24
  store i64 %t553, ptr %l249, !tbaa !24
  br label %bb119
bb119:
  %t554 = load i64, ptr %l249, !tbaa !24
  store i64 %t554, ptr %l39, !tbaa !24
  store i64 0, ptr %l40, !tbaa !24
  br label %bb120
bb120:
  store %olang.scope zeroinitializer, ptr %s34
  %t555 = load i64, ptr %l40, !tbaa !24
  %t556 = load i64, ptr %l39, !tbaa !24
  %t559 = icmp slt i64 %t555, %t556
  %t561 = xor i1 %t559, true
  br i1 %t561, label %bb121, label %bb122
bb121:
  call void @__olang_scope_close(ptr %s34)
  br label %bb131
bb122:
  br label %bb123
bb123:
  %t563 = load i64, ptr %l36, !tbaa !24
  %t564 = load i64, ptr %l40, !tbaa !24
  %t565 = load i64, ptr %l38, !tbaa !24
  %t568 = mul i64 %t564, %t565
  %t571 = add i64 %t563, %t568
  store i64 %t571, ptr %l41, !tbaa !24
  %t573 = load i64, ptr %l41, !tbaa !24
  %t575 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !27
  %t577 = getelementptr i32, ptr %t576, i64 %t573
  %t578 = load i32, ptr %t577, !tbaa !33
  %t580 = icmp eq i32 %t578, 0
  br i1 %t580, label %bb124, label %bb125
bb124:
  call void @__olang_scope_close(ptr %s34)
  br label %bb130
bb125:
  br label %bb126
bb126:
  %t582 = load i64, ptr %l41, !tbaa !24
  %t584 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t585 = load ptr, ptr %t584, !tbaa !27
  %t586 = getelementptr { i64, ptr }, ptr %t585, i64 %t582
  %t587 = load { i64, ptr }, ptr %t586, !tbaa !37
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t587)
  br label %bb127
bb127:
  %t589 = load ptr, ptr %l5, !tbaa !29
  store ptr %t589, ptr %l275, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t590
  %t591 = getelementptr { i64, [3 x i64] }, ptr %t590, i32 0, i32 0
  store i64 0, ptr %t591
  %t592 = load { i64, [3 x i64] }, ptr %t590
  store { i64, [3 x i64] } %t592, ptr %l276
  %t593 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t594 = load i64, ptr %l41, !tbaa !24
  %t596 = extractvalue { i64, ptr } %t593, 1
  %t597 = extractvalue { i64, ptr } %t593, 0
  %t598 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) }, 1
  %t599 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d194, i32 0, i32 1) }, 0
  %t600 = add i64 %t597, %t599
  %t602 = call i64 @__olang_fmt_i64(ptr null, i64 %t594)
  %t603 = add i64 %t600, %t602
  %t604 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d195, i32 0, i32 1) }, 1
  %t605 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d195, i32 0, i32 1) }, 0
  %t606 = add i64 %t603, %t605
  %t607 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t606)
  call void @olang_textcopy(ptr %t607, ptr %t596, i64 %t597)
  %t608 = getelementptr i8, ptr %t607, i64 %t597
  call void @olang_textcopy(ptr %t608, ptr %t598, i64 %t599)
  %t609 = getelementptr i8, ptr %t608, i64 %t599
  %t610 = call i64 @__olang_fmt_i64(ptr %t609, i64 %t594)
  %t611 = getelementptr i8, ptr %t609, i64 %t602
  call void @olang_textcopy(ptr %t611, ptr %t604, i64 %t605)
  %t612 = insertvalue { i64, ptr } undef, i64 %t606, 0
  %t613 = insertvalue { i64, ptr } %t612, ptr %t607, 1
  %t615 = extractvalue { i64, ptr } %t613, 0
  %t616 = extractvalue { i64, ptr } %t613, 1
  %t617 = mul i64 %t615, 1
  %t618 = call ptr @__olang_scope_alloc(ptr %s34, i64 %t617)
  call void @llvm.memcpy.p0.p0.i64(ptr %t618, ptr %t616, i64 %t617, i1 false)
  %t619 = insertvalue { i64, ptr } undef, i64 %t615, 0
  %t620 = insertvalue { i64, ptr } %t619, ptr %t618, 1
  %t622 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %s34, ptr %s34, { i64, ptr } %t620)
  store %"compiler/diagmsg:Msg" %t622, ptr %l281
  br label %bb128
bb128:
  %t623 = load ptr, ptr %l275, !tbaa !29
  %t624 = load { i64, [3 x i64] }, ptr %l276
  %t625 = load %"compiler/diagmsg:Msg", ptr %l281
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s34, ptr %t623, { i64, [3 x i64] } %t624, %"compiler/diagmsg:Msg" %t625)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s34)
  call void @__olang_scope_close(ptr %s0)
  store i32 65536, ptr %rv
  br label %ret
bb130:
  %t627 = load i64, ptr %l40, !tbaa !24
  %t629 = add i64 %t627, 1
  store i64 %t629, ptr %l40, !tbaa !24
  br label %bb120
bb131:
  store i64 0, ptr %l42, !tbaa !24
  %t632 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %l6)
  store i64 %t632, ptr %l286
  br label %bb132
bb132:
  %t633 = load i64, ptr %l286, !tbaa !24
  store i64 %t633, ptr %l43, !tbaa !24
  store i64 1, ptr %l44, !tbaa !24
  %t634 = load i64, ptr %l43, !tbaa !24
  %t635 = load i64, ptr %l42, !tbaa !24
  %t638 = icmp sgt i64 %t634, %t635
  br i1 %t638, label %bb133, label %bb134
bb133:
  %t640 = load i64, ptr %l44, !tbaa !24
  %t642 = icmp sgt i64 %t640, 0
  br i1 %t642, label %bb135, label %bb136
bb134:
  store i64 0, ptr %l290, !tbaa !24
  br label %bb138
bb135:
  %t644 = load i64, ptr %l43, !tbaa !24
  %t645 = load i64, ptr %l42, !tbaa !24
  %t648 = sub i64 %t644, %t645
  %t649 = load i64, ptr %l44, !tbaa !24
  %t652 = add i64 %t648, %t649
  %t654 = sub i64 %t652, 1
  %t655 = load i64, ptr %l44, !tbaa !24
  %t658 = sdiv i64 %t654, %t655
  store i64 %t658, ptr %l293, !tbaa !24
  br label %bb137
bb136:
  store i64 0, ptr %l293, !tbaa !24
  br label %bb137
bb137:
  %t660 = load i64, ptr %l293, !tbaa !24
  store i64 %t660, ptr %l290, !tbaa !24
  br label %bb138
bb138:
  %t661 = load i64, ptr %l290, !tbaa !24
  store i64 %t661, ptr %l45, !tbaa !24
  store i64 0, ptr %l46, !tbaa !24
  br label %bb139
bb139:
  store %olang.scope zeroinitializer, ptr %s39
  %t662 = load i64, ptr %l46, !tbaa !24
  %t663 = load i64, ptr %l45, !tbaa !24
  %t666 = icmp slt i64 %t662, %t663
  %t668 = xor i1 %t666, true
  br i1 %t668, label %bb140, label %bb141
bb140:
  call void @__olang_scope_close(ptr %s39)
  br label %bb150
bb141:
  br label %bb142
bb142:
  %t670 = load i64, ptr %l42, !tbaa !24
  %t671 = load i64, ptr %l46, !tbaa !24
  %t672 = load i64, ptr %l44, !tbaa !24
  %t675 = mul i64 %t671, %t672
  %t678 = add i64 %t670, %t675
  %t680 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t683 = extractvalue { i64, ptr } %t680, 1
  %t684 = extractvalue { i64, ptr } %t680, 0
  %t685 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d196, i32 0, i32 1) }, 1
  %t686 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d196, i32 0, i32 1) }, 0
  %t687 = add i64 %t684, %t686
  %t689 = call i64 @__olang_fmt_i64(ptr null, i64 %t678)
  %t690 = add i64 %t687, %t689
  %t691 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d197, i32 0, i32 1) }, 1
  %t692 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d197, i32 0, i32 1) }, 0
  %t693 = add i64 %t690, %t692
  %t694 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t693)
  call void @olang_textcopy(ptr %t694, ptr %t683, i64 %t684)
  %t695 = getelementptr i8, ptr %t694, i64 %t684
  call void @olang_textcopy(ptr %t695, ptr %t685, i64 %t686)
  %t696 = getelementptr i8, ptr %t695, i64 %t686
  %t697 = call i64 @__olang_fmt_i64(ptr %t696, i64 %t678)
  %t698 = getelementptr i8, ptr %t696, i64 %t689
  call void @olang_textcopy(ptr %t698, ptr %t691, i64 %t692)
  %t699 = insertvalue { i64, ptr } undef, i64 %t693, 0
  %t700 = insertvalue { i64, ptr } %t699, ptr %t694, 1
  %t702 = extractvalue { i64, ptr } %t700, 0
  %t703 = extractvalue { i64, ptr } %t700, 1
  %t704 = mul i64 %t702, 1
  %t705 = call ptr @__olang_scope_alloc(ptr %s39, i64 %t704)
  call void @llvm.memcpy.p0.p0.i64(ptr %t705, ptr %t703, i64 %t704, i1 false)
  %t706 = insertvalue { i64, ptr } undef, i64 %t702, 0
  %t707 = insertvalue { i64, ptr } %t706, ptr %t705, 1
  %t709 = call i32 @std_2fos_2eRemove(ptr %s39, { i64, ptr } %t707)
  store i32 %t709, ptr %l315
  %t710 = icmp ne i32 %t709, 0
  br i1 %t710, label %bb144, label %ok.711, !prof !99
ok.711:
  br label %bb143
bb143:
  br label %bb148
bb144:
  %t712 = load i32, ptr %l315, !tbaa !23
  %t713 = ashr i32 %t712, 16
  %t715 = icmp eq i32 %t713, 1
  store i1 %t715, ptr %l317, !tbaa !21
  %t716 = load i32, ptr %l315, !tbaa !23
  %t717 = ashr i32 %t716, 16
  %t719 = icmp eq i32 %t717, 1
  br i1 %t719, label %bb145, label %bb146
bb145:
  call void @__olang_errpay_pop()
  br label %bb146
bb146:
  br label %bb147
bb147:
  br label %bb148
bb148:
  call void @__olang_scope_close(ptr %s39)
  br label %bb149
bb149:
  %t721 = load i64, ptr %l46, !tbaa !24
  %t723 = add i64 %t721, 1
  store i64 %t723, ptr %l46, !tbaa !24
  br label %bb139
bb150:
  %t725 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t727 = extractvalue { i64, ptr } %t725, 1
  %t728 = extractvalue { i64, ptr } %t725, 0
  %t729 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d198, i32 0, i32 1) }, 1
  %t730 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d198, i32 0, i32 1) }, 0
  %t731 = add i64 %t728, %t730
  %t732 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t731)
  call void @olang_textcopy(ptr %t732, ptr %t727, i64 %t728)
  %t733 = getelementptr i8, ptr %t732, i64 %t728
  call void @olang_textcopy(ptr %t733, ptr %t729, i64 %t730)
  %t734 = insertvalue { i64, ptr } undef, i64 %t731, 0
  %t735 = insertvalue { i64, ptr } %t734, ptr %t732, 1
  %t737 = extractvalue { i64, ptr } %t735, 0
  %t738 = extractvalue { i64, ptr } %t735, 1
  %t739 = mul i64 %t737, 1
  %t740 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t739)
  call void @llvm.memcpy.p0.p0.i64(ptr %t740, ptr %t738, i64 %t739, i1 false)
  %t741 = insertvalue { i64, ptr } undef, i64 %t737, 0
  %t742 = insertvalue { i64, ptr } %t741, ptr %t740, 1
  %t743 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t745 = extractvalue { i64, ptr } %t743, 1
  %t746 = extractvalue { i64, ptr } %t743, 0
  %t747 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) }, 1
  %t748 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d199, i32 0, i32 1) }, 0
  %t749 = add i64 %t746, %t748
  %t750 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t749)
  call void @olang_textcopy(ptr %t750, ptr %t745, i64 %t746)
  %t751 = getelementptr i8, ptr %t750, i64 %t746
  call void @olang_textcopy(ptr %t751, ptr %t747, i64 %t748)
  %t752 = insertvalue { i64, ptr } undef, i64 %t749, 0
  %t753 = insertvalue { i64, ptr } %t752, ptr %t750, 1
  %t756 = extractvalue { i64, ptr } %t753, 0
  %t757 = extractvalue { i64, ptr } %t753, 1
  %t758 = mul i64 %t756, 1
  %t759 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t758)
  call void @llvm.memcpy.p0.p0.i64(ptr %t759, ptr %t757, i64 %t758, i1 false)
  %t760 = insertvalue { i64, ptr } undef, i64 %t756, 0
  %t761 = insertvalue { i64, ptr } %t760, ptr %t759, 1
  %t764 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t742, { i64, ptr } %t761)
  store i32 %t764, ptr %l329
  %t765 = icmp ne i32 %t764, 0
  br i1 %t765, label %bb152, label %ok.766, !prof !99
ok.766:
  br label %bb151
bb151:
  br label %bb156
bb152:
  %t767 = load i32, ptr %l329, !tbaa !23
  %t768 = ashr i32 %t767, 16
  %t770 = icmp eq i32 %t768, 1
  store i1 %t770, ptr %l331, !tbaa !21
  %t771 = load i32, ptr %l329, !tbaa !23
  %t772 = ashr i32 %t771, 16
  %t774 = icmp eq i32 %t772, 1
  br i1 %t774, label %bb153, label %bb154
bb153:
  call void @__olang_errpay_pop()
  br label %bb154
bb154:
  br label %bb155
bb155:
  br label %bb156
bb156:
  %t776 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t777 = load i1, ptr %l3, !tbaa !21
  %t778 = load ptr, ptr %l4, !tbaa !29
  call void @compiler_2fbuild_2elistFiles(ptr %v2, ptr %v3, { i64, ptr } %t776, i1 %t777, ptr %t778)
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l20 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 6
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d200, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb2:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d201, i32 0, i32 1) }, ptr %l3, !tbaa !27
  br label %bb3
bb3:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 4
  %t9 = load i1, ptr %t8, !tbaa !21
  br i1 %t9, label %bb4, label %bb5
bb4:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d202, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d203, i32 0, i32 1) }, ptr %l6, !tbaa !27
  br label %bb6
bb6:
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Config", ptr %t11, i32 0, i32 5
  %t14 = load i1, ptr %t13, !tbaa !21
  br i1 %t14, label %bb7, label %bb8
bb7:
  store { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d204, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d205, i32 0, i32 1) }, ptr %l9, !tbaa !27
  br label %bb9
bb9:
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 7
  %t19 = load i1, ptr %t18, !tbaa !21
  br i1 %t19, label %bb10, label %bb11
bb10:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d206, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb11:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d207, i32 0, i32 1) }, ptr %l12, !tbaa !27
  br label %bb12
bb12:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"compiler/build:Config", ptr %t21, i32 0, i32 9
  %t24 = load i1, ptr %t23, !tbaa !21
  br i1 %t24, label %bb13, label %bb14
bb13:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d208, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb14:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d209, i32 0, i32 1) }, ptr %l15, !tbaa !27
  br label %bb15
bb15:
  %t26 = load ptr, ptr %l0, !tbaa !29
  %t28 = getelementptr %"compiler/build:Config", ptr %t26, i32 0, i32 10
  %t29 = load { i64, ptr }, ptr %t28, !tbaa !27
  %t31 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t29, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d210, i32 0, i32 1) })
  store i1 %t31, ptr %l18
  br label %bb16
bb16:
  %t32 = load i1, ptr %l18, !tbaa !21
  %t33 = xor i1 %t32, true
  br i1 %t33, label %bb17, label %bb18
bb17:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d211, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb19
bb18:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d212, i32 0, i32 1) }, ptr %l20, !tbaa !27
  br label %bb19
bb19:
  %t35 = load ptr, ptr %l0, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 12
  %t38 = load i1, ptr %t37, !tbaa !21
  br i1 %t38, label %bb20, label %bb21
bb20:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d213, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb22
bb21:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d214, i32 0, i32 1) }, ptr %l23, !tbaa !27
  br label %bb22
bb22:
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/build:Config", ptr %t40, i32 0, i32 13
  %t43 = load i1, ptr %t42, !tbaa !21
  br i1 %t43, label %bb23, label %bb24
bb23:
  store { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d215, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb25
bb24:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d216, i32 0, i32 1) }, ptr %l26, !tbaa !27
  br label %bb25
bb25:
  %t45 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t49 = extractvalue { i64, ptr } %t48, 1
  %t50 = extractvalue { i64, ptr } %t48, 0
  %t51 = add i64 %t47, %t50
  %t52 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t53 = extractvalue { i64, ptr } %t52, 1
  %t54 = extractvalue { i64, ptr } %t52, 0
  %t55 = add i64 %t51, %t54
  %t56 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  %t59 = add i64 %t55, %t58
  %t60 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 1
  %t62 = extractvalue { i64, ptr } %t60, 0
  %t63 = add i64 %t59, %t62
  %t64 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  %t67 = add i64 %t63, %t66
  %t68 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 1
  %t70 = extractvalue { i64, ptr } %t68, 0
  %t71 = add i64 %t67, %t70
  %t72 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = add i64 %t71, %t74
  %t76 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t75)
  call void @olang_textcopy(ptr %t76, ptr %t46, i64 %t47)
  %t77 = getelementptr i8, ptr %t76, i64 %t47
  call void @olang_textcopy(ptr %t77, ptr %t49, i64 %t50)
  %t78 = getelementptr i8, ptr %t77, i64 %t50
  call void @olang_textcopy(ptr %t78, ptr %t53, i64 %t54)
  %t79 = getelementptr i8, ptr %t78, i64 %t54
  call void @olang_textcopy(ptr %t79, ptr %t57, i64 %t58)
  %t80 = getelementptr i8, ptr %t79, i64 %t58
  call void @olang_textcopy(ptr %t80, ptr %t61, i64 %t62)
  %t81 = getelementptr i8, ptr %t80, i64 %t62
  call void @olang_textcopy(ptr %t81, ptr %t65, i64 %t66)
  %t82 = getelementptr i8, ptr %t81, i64 %t66
  call void @olang_textcopy(ptr %t82, ptr %t69, i64 %t70)
  %t83 = getelementptr i8, ptr %t82, i64 %t70
  call void @olang_textcopy(ptr %t83, ptr %t73, i64 %t74)
  %t84 = insertvalue { i64, ptr } undef, i64 %t75, 0
  %t85 = insertvalue { i64, ptr } %t84, ptr %t76, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/text:StringBuilder"
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = getelementptr %"compiler/build:Config", ptr %a0, i32 0, i32 19
  %t4 = load i1, ptr %t3, !tbaa !21
  %t6 = xor i1 %t4, true
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 1
  %t11 = extractvalue { i64, ptr } %t8, 0
  %t12 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t11)
  call void @olang_textcopy(ptr %t12, ptr %t10, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t14, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t16 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t16, ptr %l9
  br label %bb4
bb4:
  %t17 = load %"std/prelude/text:StringBuilder", ptr %l9
  store %"std/prelude/text:StringBuilder" %t17, ptr %l3
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb5
bb5:
  %t20 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 1
  %t21 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d217, i32 0, i32 1) }, 0
  %t23 = extractvalue { i64, ptr } %a1, 1
  %t24 = extractvalue { i64, ptr } %a1, 0
  %t25 = add i64 %t21, %t24
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d218, i32 0, i32 1) }, 0
  %t28 = add i64 %t25, %t27
  %t29 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t28)
  call void @olang_textcopy(ptr %t29, ptr %t20, i64 %t21)
  %t30 = getelementptr i8, ptr %t29, i64 %t21
  call void @olang_textcopy(ptr %t30, ptr %t23, i64 %t24)
  %t31 = getelementptr i8, ptr %t30, i64 %t24
  call void @olang_textcopy(ptr %t31, ptr %t26, i64 %t27)
  %t32 = insertvalue { i64, ptr } undef, i64 %t28, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t29, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  %t36 = extractvalue { i64, ptr } %t33, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t40)
  br label %bb6
bb6:
  %t43 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v2, ptr %l3, { i64, ptr } %t43)
  br label %bb7
bb7:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %l3, i8 27)
  br label %bb8
bb8:
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d219, i32 0, i32 1) })
  br label %bb9
bb9:
  %t49 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v3, ptr %l3)
  store { i64, ptr } %t49, ptr %l20
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t50 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l8 = alloca i1
  %l9 = alloca ptr
  %l10 = alloca { i64, [3 x i64] }
  %l13 = alloca %"compiler/diagmsg:Msg"
  %s1 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t16 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 2
  %t5 = call { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v2, ptr %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l6
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l5
  br label %bb1
bb1:
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t10, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t11 = load i32, ptr %l6, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store ptr %a1, ptr %l9, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t16
  %t17 = getelementptr { i64, [3 x i64] }, ptr %t16, i32 0, i32 0
  store i64 0, ptr %t17
  %t18 = load { i64, [3 x i64] }, ptr %t16
  store { i64, [3 x i64] } %t18, ptr %l10
  %t19 = load ptr, ptr %l0, !tbaa !29
  %t21 = getelementptr %"compiler/build:Config", ptr %t19, i32 0, i32 2
  %t22 = getelementptr %"compiler/target:Target", ptr %t21, i32 0, i32 2
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !27
  %t25 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %s1, { i64, ptr } %t23)
  store %"compiler/diagmsg:Msg" %t25, ptr %l13
  br label %bb4
bb4:
  %t26 = load ptr, ptr %l9, !tbaa !29
  %t27 = load { i64, [3 x i64] }, ptr %l10
  %t28 = load %"compiler/diagmsg:Msg", ptr %l13
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s1, ptr %t26, { i64, [3 x i64] } %t27, %"compiler/diagmsg:Msg" %t28)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t30 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t30, ptr %rv
  br label %ret
bb6:
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t32 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t31, 1
  store { i32, { i64, ptr } } %t32, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v2, ptr %s0, ptr %a2)
  store { i64, ptr } %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t15 = extractvalue { i64, ptr } %a1, 1
  %t16 = extractvalue { i64, ptr } %a1, 0
  %t17 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d220, i32 0, i32 1) }, 1
  %t18 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d220, i32 0, i32 1) }, 0
  %t19 = add i64 %t16, %t18
  %t20 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t19)
  call void @olang_textcopy(ptr %t20, ptr %t15, i64 %t16)
  %t21 = getelementptr i8, ptr %t20, i64 %t16
  call void @olang_textcopy(ptr %t21, ptr %t17, i64 %t18)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t20, 1
  %t25 = extractvalue { i64, ptr } %t23, 0
  %t26 = extractvalue { i64, ptr } %t23, 1
  %t27 = mul i64 %t25, 1
  %t28 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t26, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  %t33 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d221, i32 0, i32 1) }, { i64, ptr } %t30)
  store { i64, ptr } %t33, ptr %l10
  br label %bb3
bb3:
  %t34 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 0
  %t36 = extractvalue { i64, ptr } %t34, 1
  %t37 = mul i64 %t35, 1
  %t38 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t37)
  call void @llvm.memcpy.p0.p0.i64(ptr %t38, ptr %t36, i64 %t37, i1 false)
  %t39 = insertvalue { i64, ptr } undef, i64 %t35, 0
  %t40 = insertvalue { i64, ptr } %t39, ptr %t38, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t40)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/diagmsg:Msg" %a2, ptr %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = load ptr, ptr %l3, !tbaa !29
  call void @compiler_2fbuild_2efileError(ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %t1, %"compiler/diagmsg:Msg" %a2, ptr %t3)
  br label %bb1
bb1:
  %t7 = load ptr, ptr %l3, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v3, ptr %s0, ptr %t7)
  store { i64, ptr } %t9, ptr %l8
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  %t12 = extractvalue { i64, ptr } %t10, 1
  %t13 = mul i64 %t11, 1
  %t14 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t13)
  call void @llvm.memcpy.p0.p0.i64(ptr %t14, ptr %t12, i64 %t13, i1 false)
  %t15 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t16 = insertvalue { i64, ptr } %t15, ptr %t14, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t16)
  br label %bb3
bb3:
  %t19 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t19, 1
  %t22 = extractvalue { i64, ptr } %t19, 0
  %t23 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d222, i32 0, i32 1) }, 1
  %t24 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d222, i32 0, i32 1) }, 0
  %t25 = add i64 %t22, %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t25)
  call void @olang_textcopy(ptr %t26, ptr %t21, i64 %t22)
  %t27 = getelementptr i8, ptr %t26, i64 %t22
  call void @olang_textcopy(ptr %t27, ptr %t23, i64 %t24)
  %t28 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t26, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  %t39 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s0, ptr %s0, ptr %s0, ptr %a0, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d223, i32 0, i32 1) }, { i64, ptr } %t36)
  store { i64, ptr } %t39, ptr %l14
  br label %bb4
bb4:
  %t40 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @compiler_2fbuild_2esayln(ptr %s0, { i64, ptr } %t46)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewant(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, i32 %a3, { i64, ptr } %a4, ptr %a5, { i64, ptr } %a6, i64 %a7) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca { i64, ptr }
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp9 = alloca ptr
  %l10 = alloca i1
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l23 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l25 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l28 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l29 = alloca ptr
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l33 = alloca i1
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l44 = alloca i1
  %l52 = alloca i1
  %l53 = alloca i1
  %l55 = alloca i1
  %l56 = alloca i1
  %l59 = alloca i1
  %l61 = alloca { i64, ptr }
  %l63 = alloca i1
  %l67 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l77 = alloca i64
  %l79 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca i64
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca i1
  %l99 = alloca i1
  %l101 = alloca { i64, ptr }
  %l103 = alloca i1
  %l105 = alloca { i64, ptr }
  %l109 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l120 = alloca i32
  %l122 = alloca i1
  %l126 = alloca i1
  %l130 = alloca i1
  %l133 = alloca i1
  %l141 = alloca i64
  %l142 = alloca i64
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l157 = alloca i1
  %l159 = alloca i1
  %l164 = alloca i1
  %l166 = alloca { i64, ptr }
  %l168 = alloca i64
  %l170 = alloca i64
  %l171 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca i64
  %l179 = alloca { i64, ptr }
  %l180 = alloca i32
  %l185 = alloca i32
  %l187 = alloca i1
  %l190 = alloca { i64, ptr }
  %l191 = alloca %"compiler/diagmsg:Msg"
  %l196 = alloca i1
  %l199 = alloca i32
  %l201 = alloca i1
  %l204 = alloca ptr
  %l205 = alloca { i64, [3 x i64] }
  %l207 = alloca %"compiler/diagmsg:Msg"
  %l209 = alloca { i64, ptr }
  %l210 = alloca i32
  %l212 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l220 = alloca i64
  %l222 = alloca i64
  %l227 = alloca { i64, ptr }
  %l250 = alloca ptr
  %l252 = alloca { i64, ptr }
  %l259 = alloca ptr
  %l261 = alloca { i64, ptr }
  %l264 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  %t553 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store ptr %a5, ptr %l5
  store { i64, ptr } %a6, ptr %l6
  store i64 %a7, ptr %l7
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t3 = trunc i64 4 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eDataFlags(ptr %v0, ptr %s0, ptr %t6)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l25
  br label %bb3
bb2:
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t10 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eCompileFlags(ptr %v0, ptr %v3, ptr %s0, ptr %t9, { i64, ptr } %t10)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l28
  br label %bb4
bb3:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l23
  br label %bb5
bb4:
  %t15 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l28
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l23
  br label %bb5
bb5:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l23
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l8
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l29, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t18, ptr %l30, !tbaa !27
  %t19 = load i32, ptr %l3, !range !{i32 0, i32 5}
  store i32 %t19, ptr %l31
  %t20 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v5, ptr %s0, { i64, ptr } %t20, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d224, i32 0, i32 1) })
  store i1 %t22, ptr %l33
  br label %bb6
bb6:
  %t23 = load i1, ptr %l33, !tbaa !21
  %t24 = xor i1 %t23, true
  br i1 %t24, label %bb7, label %bb8
bb7:
  %t26 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t26, ptr %l35, !tbaa !27
  br label %bb10
bb8:
  %t28 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t30 = call { i64, ptr } @compiler_2fbuild_2eIrHash(ptr %v3, ptr %v5, { i64, ptr } %t28)
  store { i64, ptr } %t30, ptr %l38
  br label %bb9
bb9:
  %t31 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t32 = extractvalue { i64, ptr } %t31, 0
  %t33 = extractvalue { i64, ptr } %t31, 1
  %t34 = mul i64 %t32, 1
  %t35 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t34)
  call void @llvm.memcpy.p0.p0.i64(ptr %t35, ptr %t33, i64 %t34, i1 false)
  %t36 = insertvalue { i64, ptr } undef, i64 %t32, 0
  %t37 = insertvalue { i64, ptr } %t36, ptr %t35, 1
  store { i64, ptr } %t37, ptr %l35, !tbaa !27
  br label %bb10
bb10:
  %t39 = load ptr, ptr %l29, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l30, !tbaa !27
  %t41 = load i32, ptr %l31, !range !{i32 0, i32 5}
  %t42 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t44 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjectPath(ptr %v0, ptr %v2, ptr %v5, ptr %s0, ptr %v6, ptr %t39, { i64, ptr } %t40, i32 %t41, { i64, ptr } %t42, ptr %l8)
  store { i64, ptr } %t44, ptr %l41
  br label %bb11
bb11:
  %t45 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 16, i64 8)
  store ptr %t45, ptr %lp9
  %t46 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t47 = load ptr, ptr %lp9
  store { i64, ptr } %t46, ptr %t47, !tbaa !27
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"compiler/build:Config", ptr %t48, i32 0, i32 13
  %t51 = load i1, ptr %t50, !tbaa !21
  br i1 %t51, label %bb12, label %bb13
bb12:
  %t53 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t55 = trunc i64 4 to i32
  %t56 = icmp eq i32 %t53, %t55
  %t58 = xor i1 %t56, true
  store i1 %t58, ptr %l44, !tbaa !21
  br label %bb14
bb13:
  store i1 false, ptr %l44, !tbaa !21
  br label %bb14
bb14:
  %t60 = load i1, ptr %l44, !tbaa !21
  store i1 %t60, ptr %l10, !tbaa !21
  %t61 = load ptr, ptr %lp9
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !27
  %t64 = load ptr, ptr %l1, !tbaa !29
  %t66 = getelementptr %"compiler/build:compiles", ptr %t64, i32 0, i32 2
  %t70 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v1, ptr %s0, ptr %t66, { i64, ptr } %t62)
  store i1 %t70, ptr %l52
  br label %bb15
bb15:
  %t71 = load i1, ptr %l52, !tbaa !21
  br i1 %t71, label %bb16, label %bb17
bb16:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb27
bb17:
  %t72 = load ptr, ptr %lp9
  %t73 = load { i64, ptr }, ptr %t72, !tbaa !27
  %t75 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t73)
  store i1 %t75, ptr %l55
  br label %bb18
bb18:
  %t76 = load i1, ptr %l55, !tbaa !21
  br i1 %t76, label %bb19, label %bb20
bb19:
  %t77 = load i1, ptr %l10, !tbaa !21
  %t79 = xor i1 %t77, true
  br i1 %t79, label %bb21, label %bb22
bb20:
  store i1 false, ptr %l56, !tbaa !21
  br label %bb26
bb21:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb25
bb22:
  %t81 = load ptr, ptr %lp9
  %t82 = load { i64, ptr }, ptr %t81, !tbaa !27
  %t84 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s0, { i64, ptr } %t82)
  store { i64, ptr } %t84, ptr %l61
  br label %bb23
bb23:
  %t85 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t85, 0
  %t87 = extractvalue { i64, ptr } %t85, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t91)
  store i1 %t93, ptr %l63
  br label %bb24
bb24:
  %t94 = load i1, ptr %l63, !tbaa !21
  store i1 %t94, ptr %l59, !tbaa !21
  br label %bb25
bb25:
  %t95 = load i1, ptr %l59, !tbaa !21
  store i1 %t95, ptr %l56, !tbaa !21
  br label %bb26
bb26:
  %t96 = load i1, ptr %l56, !tbaa !21
  store i1 %t96, ptr %l53, !tbaa !21
  br label %bb27
bb27:
  %t97 = load i1, ptr %l53, !tbaa !21
  br i1 %t97, label %bb28, label %bb29
bb28:
  %t98 = load ptr, ptr %lp9
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t101 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t99, 1
  store { i32, { i64, ptr } } %t101, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t102 = load ptr, ptr %l0, !tbaa !29
  %t104 = getelementptr %"compiler/build:Config", ptr %t102, i32 0, i32 26
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  %t107 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t105, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d225, i32 0, i32 1) })
  store i1 %t107, ptr %l67
  br label %bb31
bb31:
  %t108 = load i1, ptr %l67, !tbaa !21
  %t109 = xor i1 %t108, true
  br i1 %t109, label %bb32, label %bb33
bb32:
  store %olang.scope zeroinitializer, ptr %s2
  %t111 = load i1, ptr %l10, !tbaa !21
  br i1 %t111, label %bb34, label %bb35
bb33:
  br label %bb76
bb34:
  store %olang.scope zeroinitializer, ptr %s3
  %t113 = load ptr, ptr %l0, !tbaa !29
  %t115 = getelementptr %"compiler/build:Config", ptr %t113, i32 0, i32 26
  %t116 = load { i64, ptr }, ptr %t115, !tbaa !27
  store { i64, ptr } %t116, ptr %l71, !tbaa !27
  %t117 = load ptr, ptr %lp9
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t120 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s3, { i64, ptr } %t118)
  store { i64, ptr } %t120, ptr %l73
  br label %bb36
bb35:
  br label %bb51
bb36:
  %t121 = load ptr, ptr %l0, !tbaa !29
  %t123 = getelementptr %"compiler/build:Config", ptr %t121, i32 0, i32 0
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  %t126 = extractvalue { i64, ptr } %t124, 0
  %t128 = add i64 %t126, 1
  store i64 %t128, ptr %l77, !tbaa !24
  %t129 = load ptr, ptr %lp9
  %t130 = load { i64, ptr }, ptr %t129, !tbaa !27
  %t132 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s3, { i64, ptr } %t130)
  store { i64, ptr } %t132, ptr %l79
  br label %bb37
bb37:
  %t133 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t135 = extractvalue { i64, ptr } %t133, 0
  store i64 %t135, ptr %l81, !tbaa !24
  %t136 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  store i64 %t137, ptr %l82, !tbaa !24
  %t138 = load i64, ptr %l77, !tbaa !24
  %t139 = icmp sge i64 %t138, 0
  br i1 %t139, label %bb38, label %bb39
bb38:
  %t141 = load i64, ptr %l77, !tbaa !24
  %t142 = load i64, ptr %l81, !tbaa !24
  %t143 = icmp sle i64 %t141, %t142
  br i1 %t143, label %bb40, label %bb41
bb39:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb40:
  %t145 = load i64, ptr %l81, !tbaa !24
  %t146 = load i64, ptr %l82, !tbaa !24
  %t147 = icmp sle i64 %t145, %t146
  br i1 %t147, label %bb42, label %bb43
bb41:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb42:
  %t149 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t150 = load ptr, ptr %t149, !tbaa !27
  %t151 = load i64, ptr %l77, !tbaa !24
  %t152 = load i64, ptr %l81, !tbaa !24
  %t153 = getelementptr i8, ptr %t150, i64 %t151
  %t154 = sub i64 %t152, %t151
  %t155 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t153, 1
  %t157 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t157, 1
  %t159 = extractvalue { i64, ptr } %t157, 0
  %t160 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d226, i32 0, i32 1) }, 1
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d226, i32 0, i32 1) }, 0
  %t162 = add i64 %t159, %t161
  %t164 = extractvalue { i64, ptr } %t156, 1
  %t165 = extractvalue { i64, ptr } %t156, 0
  %t166 = add i64 %t162, %t165
  %t167 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t166)
  call void @olang_textcopy(ptr %t167, ptr %t158, i64 %t159)
  %t168 = getelementptr i8, ptr %t167, i64 %t159
  call void @olang_textcopy(ptr %t168, ptr %t160, i64 %t161)
  %t169 = getelementptr i8, ptr %t168, i64 %t161
  call void @olang_textcopy(ptr %t169, ptr %t164, i64 %t165)
  %t170 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t171 = insertvalue { i64, ptr } %t170, ptr %t167, 1
  %t173 = extractvalue { i64, ptr } %t171, 0
  %t174 = extractvalue { i64, ptr } %t171, 1
  %t175 = mul i64 %t173, 1
  %t176 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t175)
  call void @llvm.memcpy.p0.p0.i64(ptr %t176, ptr %t174, i64 %t175, i1 false)
  %t177 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t176, 1
  store { i64, ptr } %t178, ptr %l88, !tbaa !27
  %t179 = load ptr, ptr %lp9
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  %t182 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s3, { i64, ptr } %t180)
  store { i64, ptr } %t182, ptr %l90
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_81dfa638548de3d7_ab0731b6a5acba3)
  unreachable
bb44:
  %t183 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t184 = extractvalue { i64, ptr } %t183, 0
  %t185 = extractvalue { i64, ptr } %t183, 1
  %t186 = mul i64 %t184, 1
  %t187 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t186)
  call void @llvm.memcpy.p0.p0.i64(ptr %t187, ptr %t185, i64 %t186, i1 false)
  %t188 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t187, 1
  %t190 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t192 = call i32 @std_2fos_2eLink(ptr %s3, ptr %s3, { i64, ptr } %t190, { i64, ptr } %t189)
  store i32 %t192, ptr %l92
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb46, label %ok.194, !prof !99
ok.194:
  br label %bb45
bb45:
  br label %bb50
bb46:
  %t195 = load i32, ptr %l92, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  store i1 %t198, ptr %l94, !tbaa !21
  %t199 = load i32, ptr %l92, !tbaa !23
  %t200 = ashr i32 %t199, 16
  %t202 = icmp eq i32 %t200, 1
  br i1 %t202, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s3)
  br label %bb51
bb51:
  %t204 = load i1, ptr %l10, !tbaa !21
  %t206 = xor i1 %t204, true
  br i1 %t206, label %bb52, label %bb53
bb52:
  store i1 true, ptr %l99, !tbaa !21
  br label %bb56
bb53:
  %t208 = load ptr, ptr %lp9
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t211 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v6, ptr %s2, { i64, ptr } %t209)
  store { i64, ptr } %t211, ptr %l101
  br label %bb54
bb54:
  %t212 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t213 = extractvalue { i64, ptr } %t212, 0
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = mul i64 %t213, 1
  %t216 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t215)
  call void @llvm.memcpy.p0.p0.i64(ptr %t216, ptr %t214, i64 %t215, i1 false)
  %t217 = insertvalue { i64, ptr } undef, i64 %t213, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  %t220 = call i1 @std_2fos_2eExists(ptr %s2, { i64, ptr } %t218)
  store i1 %t220, ptr %l103
  br label %bb55
bb55:
  %t221 = load i1, ptr %l103, !tbaa !21
  store i1 %t221, ptr %l99, !tbaa !21
  br label %bb56
bb56:
  %t222 = load i1, ptr %l99, !tbaa !21
  br i1 %t222, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t223 = load ptr, ptr %l0, !tbaa !29
  %t225 = getelementptr %"compiler/build:Config", ptr %t223, i32 0, i32 26
  %t226 = load { i64, ptr }, ptr %t225, !tbaa !27
  store { i64, ptr } %t226, ptr %l105, !tbaa !27
  %t227 = load ptr, ptr %l0, !tbaa !29
  %t229 = getelementptr %"compiler/build:Config", ptr %t227, i32 0, i32 0
  %t230 = load { i64, ptr }, ptr %t229, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t230, 0
  %t234 = add i64 %t232, 1
  store i64 %t234, ptr %l109, !tbaa !24
  %t235 = load ptr, ptr %lp9
  %t236 = load { i64, ptr }, ptr %t235, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t236, 0
  store i64 %t238, ptr %l111, !tbaa !24
  %t239 = load ptr, ptr %lp9
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  store i64 %t241, ptr %l112, !tbaa !24
  %t242 = load i64, ptr %l109, !tbaa !24
  %t243 = icmp sge i64 %t242, 0
  br i1 %t243, label %bb59, label %bb60
bb58:
  br label %bb71
bb59:
  %t245 = load i64, ptr %l109, !tbaa !24
  %t246 = load i64, ptr %l111, !tbaa !24
  %t247 = icmp sle i64 %t245, %t246
  br i1 %t247, label %bb61, label %bb62
bb60:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb61:
  %t249 = load i64, ptr %l111, !tbaa !24
  %t250 = load i64, ptr %l112, !tbaa !24
  %t251 = icmp sle i64 %t249, %t250
  br i1 %t251, label %bb63, label %bb64
bb62:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb63:
  %t253 = load ptr, ptr %lp9
  %t254 = getelementptr { i64, ptr }, ptr %t253, i32 0, i32 1
  %t255 = load ptr, ptr %t254, !tbaa !27
  %t256 = load i64, ptr %l109, !tbaa !24
  %t257 = load i64, ptr %l111, !tbaa !24
  %t258 = getelementptr i8, ptr %t255, i64 %t256
  %t259 = sub i64 %t257, %t256
  %t260 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t258, 1
  %t262 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t263 = extractvalue { i64, ptr } %t262, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 1
  %t266 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d227, i32 0, i32 1) }, 0
  %t267 = add i64 %t264, %t266
  %t269 = extractvalue { i64, ptr } %t261, 1
  %t270 = extractvalue { i64, ptr } %t261, 0
  %t271 = add i64 %t267, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t263, i64 %t264)
  %t273 = getelementptr i8, ptr %t272, i64 %t264
  call void @olang_textcopy(ptr %t273, ptr %t265, i64 %t266)
  %t274 = getelementptr i8, ptr %t273, i64 %t266
  call void @olang_textcopy(ptr %t274, ptr %t269, i64 %t270)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t272, 1
  %t278 = extractvalue { i64, ptr } %t276, 0
  %t279 = extractvalue { i64, ptr } %t276, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  %t284 = load ptr, ptr %lp9
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !27
  %t288 = call i32 @std_2fos_2eLink(ptr %s6, ptr %v6, { i64, ptr } %t283, { i64, ptr } %t285)
  store i32 %t288, ptr %l120
  %t289 = icmp ne i32 %t288, 0
  br i1 %t289, label %bb66, label %ok.290, !prof !99
ok.290:
  br label %bb65
bb64:
  call void @__olang_check_failed(ptr @olang_loc_64cef890f5e30dfa_ab05d47f854753c6)
  unreachable
bb65:
  br label %bb70
bb66:
  %t291 = load i32, ptr %l120, !tbaa !23
  %t292 = ashr i32 %t291, 16
  %t294 = icmp eq i32 %t292, 1
  store i1 %t294, ptr %l122, !tbaa !21
  %t295 = load i32, ptr %l120, !tbaa !23
  %t296 = ashr i32 %t295, 16
  %t298 = icmp eq i32 %t296, 1
  br i1 %t298, label %bb67, label %bb68
bb67:
  call void @__olang_errpay_pop()
  br label %bb68
bb68:
  br label %bb69
bb69:
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s6)
  br label %bb71
bb71:
  %t300 = load ptr, ptr %lp9
  %t301 = load { i64, ptr }, ptr %t300, !tbaa !27
  %t303 = call i1 @std_2fos_2eExists(ptr %v6, { i64, ptr } %t301)
  store i1 %t303, ptr %l126
  br label %bb72
bb72:
  %t304 = load i1, ptr %l126, !tbaa !21
  br i1 %t304, label %bb73, label %bb74
bb73:
  %t305 = load ptr, ptr %lp9
  %t306 = load { i64, ptr }, ptr %t305, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t308 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t306, 1
  store { i32, { i64, ptr } } %t308, ptr %rv
  br label %ret
bb74:
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s2)
  br label %bb76
bb76:
  %t309 = load i64, ptr %l7, !tbaa !24
  %t311 = icmp sge i64 %t309, 0
  br i1 %t311, label %bb77, label %bb78
bb77:
  %t313 = load ptr, ptr %l1, !tbaa !29
  %t314 = load ptr, ptr %lp9
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !27
  %t318 = call i1 @compiler_2fbuild_2ecompiler_2fbuild_3acompiles_2eclaim(ptr %v1, ptr %v6, ptr %t313, { i64, ptr } %t315)
  store i1 %t318, ptr %l133
  br label %bb79
bb78:
  store i1 false, ptr %l130, !tbaa !21
  br label %bb80
bb79:
  %t319 = load i1, ptr %l133, !tbaa !21
  %t320 = xor i1 %t319, true
  store i1 %t320, ptr %l130, !tbaa !21
  br label %bb80
bb80:
  %t322 = load i1, ptr %l130, !tbaa !21
  br i1 %t322, label %bb81, label %bb82
bb81:
  %t323 = load ptr, ptr %l1, !tbaa !29
  %t325 = getelementptr %"compiler/build:compiles", ptr %t323, i32 0, i32 8
  %t326 = load i64, ptr %l7, !tbaa !24
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t325, i64 %t326)
  br label %bb83
bb82:
  br label %bb84
bb83:
  %t329 = load ptr, ptr %lp9
  %t330 = load { i64, ptr }, ptr %t329, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t332 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t330, 1
  store { i32, { i64, ptr } } %t332, ptr %rv
  br label %ret
bb84:
  %t333 = load ptr, ptr %lp9
  %t334 = load { i64, ptr }, ptr %t333, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t334, 0
  %t338 = sub i64 %t336, 2
  store i64 %t338, ptr %l141, !tbaa !24
  %t339 = load ptr, ptr %lp9
  %t340 = load { i64, ptr }, ptr %t339, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  store i64 %t341, ptr %l142, !tbaa !24
  %t342 = icmp sge i64 0, 0
  br i1 %t342, label %bb85, label %bb86
bb85:
  %t344 = load i64, ptr %l141, !tbaa !24
  %t345 = icmp sle i64 0, %t344
  br i1 %t345, label %bb87, label %bb88
bb86:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb87:
  %t347 = load i64, ptr %l141, !tbaa !24
  %t348 = load i64, ptr %l142, !tbaa !24
  %t349 = icmp sle i64 %t347, %t348
  br i1 %t349, label %bb89, label %bb90
bb88:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb89:
  %t351 = load ptr, ptr %lp9
  %t352 = getelementptr { i64, ptr }, ptr %t351, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = load i64, ptr %l141, !tbaa !24
  %t355 = getelementptr i8, ptr %t353, i64 0
  %t356 = sub i64 %t354, 0
  %t357 = insertvalue { i64, ptr } undef, i64 %t356, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t355, 1
  %t360 = extractvalue { i64, ptr } %t358, 1
  %t361 = extractvalue { i64, ptr } %t358, 0
  %t362 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 1
  %t363 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d228, i32 0, i32 1) }, 0
  %t364 = add i64 %t361, %t363
  %t365 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t364)
  call void @olang_textcopy(ptr %t365, ptr %t360, i64 %t361)
  %t366 = getelementptr i8, ptr %t365, i64 %t361
  call void @olang_textcopy(ptr %t366, ptr %t362, i64 %t363)
  %t367 = insertvalue { i64, ptr } undef, i64 %t364, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t365, 1
  store { i64, ptr } %t368, ptr %l12, !tbaa !27
  %t370 = load ptr, ptr %l0, !tbaa !29
  %t372 = getelementptr %"compiler/build:Config", ptr %t370, i32 0, i32 0
  %t373 = load { i64, ptr }, ptr %t372, !tbaa !27
  store { i64, ptr } %t373, ptr %l149, !tbaa !27
  %t374 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t374, ptr %l150, !tbaa !27
  %t375 = load i32, ptr %l3, !range !{i32 0, i32 5}
  %t377 = call { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %s0, i32 %t375)
  store { i64, ptr } %t377, ptr %l152
  br label %bb91
bb90:
  call void @__olang_check_failed(ptr @olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5)
  unreachable
bb91:
  %t378 = load ptr, ptr %l0, !tbaa !29
  %t380 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t378)
  store { i64, ptr } %t380, ptr %l154
  br label %bb92
bb92:
  %t381 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t382 = extractvalue { i64, ptr } %t381, 1
  %t383 = extractvalue { i64, ptr } %t381, 0
  %t384 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d229, i32 0, i32 1) }, 1
  %t385 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d229, i32 0, i32 1) }, 0
  %t386 = add i64 %t383, %t385
  %t387 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t388 = extractvalue { i64, ptr } %t387, 1
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t390 = add i64 %t386, %t389
  %t391 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 1
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t394 = add i64 %t390, %t393
  %t395 = load { i64, ptr }, ptr %l154, !tbaa !27
  %t396 = extractvalue { i64, ptr } %t395, 1
  %t397 = extractvalue { i64, ptr } %t395, 0
  %t398 = add i64 %t394, %t397
  %t399 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d230, i32 0, i32 1) }, 1
  %t400 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d230, i32 0, i32 1) }, 0
  %t401 = add i64 %t398, %t400
  %t402 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t401)
  call void @olang_textcopy(ptr %t402, ptr %t382, i64 %t383)
  %t403 = getelementptr i8, ptr %t402, i64 %t383
  call void @olang_textcopy(ptr %t403, ptr %t384, i64 %t385)
  %t404 = getelementptr i8, ptr %t403, i64 %t385
  call void @olang_textcopy(ptr %t404, ptr %t388, i64 %t389)
  %t405 = getelementptr i8, ptr %t404, i64 %t389
  call void @olang_textcopy(ptr %t405, ptr %t392, i64 %t393)
  %t406 = getelementptr i8, ptr %t405, i64 %t393
  call void @olang_textcopy(ptr %t406, ptr %t396, i64 %t397)
  %t407 = getelementptr i8, ptr %t406, i64 %t397
  call void @olang_textcopy(ptr %t407, ptr %t399, i64 %t400)
  %t408 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t402, 1
  store { i64, ptr } %t409, ptr %l13, !tbaa !27
  %t411 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t413 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v2, ptr %s0, { i64, ptr } %t411, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d231, i32 0, i32 1) })
  store i1 %t413, ptr %l157
  br label %bb93
bb93:
  %t414 = load i1, ptr %l157, !tbaa !21
  %t415 = xor i1 %t414, true
  br i1 %t415, label %bb94, label %bb95
bb94:
  %t417 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t419 = load ptr, ptr %l1, !tbaa !29
  %t421 = getelementptr %"compiler/build:compiles", ptr %t419, i32 0, i32 3
  %t425 = call i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v1, ptr %s0, ptr %t421, { i64, ptr } %t417)
  store i1 %t425, ptr %l164
  br label %bb96
bb95:
  store i1 false, ptr %l159, !tbaa !21
  br label %bb97
bb96:
  %t426 = load i1, ptr %l164, !tbaa !21
  %t427 = xor i1 %t426, true
  store i1 %t427, ptr %l159, !tbaa !21
  br label %bb97
bb97:
  %t429 = load i1, ptr %l159, !tbaa !21
  br i1 %t429, label %bb98, label %bb99
bb98:
  %t430 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t430, ptr %l166, !tbaa !27
  %t431 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t432 = extractvalue { i64, ptr } %t431, 0
  %t433 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 0
  store i64 %t434, ptr %l168, !tbaa !24
  %t436 = load i64, ptr %l168, !tbaa !24
  %t437 = icmp eq i64 %t432, %t436
  br i1 %t437, label %bb100, label %bb101
bb99:
  br label %bb103
bb100:
  %t439 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t440 = load ptr, ptr %t439, !tbaa !27
  %t441 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t442 = load ptr, ptr %t441, !tbaa !27
  %t443 = load i64, ptr %l168, !tbaa !24
  %t444 = mul i64 %t443, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t440, ptr %t442, i64 %t444, i1 false)
  br label %bb102
bb101:
  %t445 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t446 = extractvalue { i64, ptr } %t445, 0
  store i64 %t446, ptr %l170, !tbaa !24
  %t447 = load i64, ptr %l170, !tbaa !24
  %t448 = mul i64 %t447, 1
  %t449 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t448)
  %t450 = insertvalue { i64, ptr } undef, i64 %t447, 0
  %t451 = insertvalue { i64, ptr } %t450, ptr %t449, 1
  store { i64, ptr } %t451, ptr %l171, !tbaa !27
  %t452 = getelementptr { i64, ptr }, ptr %l171, i32 0, i32 1
  %t453 = load ptr, ptr %t452, !tbaa !27
  %t454 = getelementptr { i64, ptr }, ptr %l166, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = load i64, ptr %l170, !tbaa !24
  %t457 = mul i64 %t456, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t453, ptr %t455, i64 %t457, i1 false)
  %t458 = load { i64, ptr }, ptr %l171, !tbaa !27
  store { i64, ptr } %t458, ptr %l12, !tbaa !27
  br label %bb102
bb102:
  br label %bb103
bb103:
  %t459 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t463 = sub i64 %t461, 3
  store i64 %t463, ptr %l174, !tbaa !24
  %t464 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t465 = extractvalue { i64, ptr } %t464, 0
  store i64 %t465, ptr %l175, !tbaa !24
  %t466 = icmp sge i64 0, 0
  br i1 %t466, label %bb104, label %bb105
bb104:
  %t468 = load i64, ptr %l174, !tbaa !24
  %t469 = icmp sle i64 0, %t468
  br i1 %t469, label %bb106, label %bb107
bb105:
  call void @__olang_check_failed(ptr @olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688)
  unreachable
bb106:
  %t471 = load i64, ptr %l174, !tbaa !24
  %t472 = load i64, ptr %l175, !tbaa !24
  %t473 = icmp sle i64 %t471, %t472
  br i1 %t473, label %bb108, label %bb109
bb107:
  call void @__olang_check_failed(ptr @olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688)
  unreachable
bb108:
  %t475 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t476 = load ptr, ptr %t475, !tbaa !27
  %t477 = load i64, ptr %l174, !tbaa !24
  %t478 = getelementptr i8, ptr %t476, i64 0
  %t479 = sub i64 %t477, 0
  %t480 = insertvalue { i64, ptr } undef, i64 %t479, 0
  %t481 = insertvalue { i64, ptr } %t480, ptr %t478, 1
  store { i64, ptr } %t481, ptr %l179, !tbaa !27
  %t482 = call i32 @getpid()
  store i32 %t482, ptr %l180
  br label %bb110
bb109:
  call void @__olang_check_failed(ptr @olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688)
  unreachable
bb110:
  %t483 = load { i64, ptr }, ptr %l179, !tbaa !27
  %t484 = extractvalue { i64, ptr } %t483, 1
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t486 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d232, i32 0, i32 1) }, 1
  %t487 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d232, i32 0, i32 1) }, 0
  %t488 = add i64 %t485, %t487
  %t489 = load i32, ptr %l180, !tbaa !23
  %t490 = sext i32 %t489 to i64
  %t491 = call i64 @__olang_fmt_i64(ptr null, i64 %t490)
  %t492 = add i64 %t488, %t491
  %t493 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d233, i32 0, i32 1) }, 1
  %t494 = extractvalue { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d233, i32 0, i32 1) }, 0
  %t495 = add i64 %t492, %t494
  %t496 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t495)
  call void @olang_textcopy(ptr %t496, ptr %t484, i64 %t485)
  %t497 = getelementptr i8, ptr %t496, i64 %t485
  call void @olang_textcopy(ptr %t497, ptr %t486, i64 %t487)
  %t498 = getelementptr i8, ptr %t497, i64 %t487
  %t499 = call i64 @__olang_fmt_i64(ptr %t498, i64 %t490)
  %t500 = getelementptr i8, ptr %t498, i64 %t491
  call void @olang_textcopy(ptr %t500, ptr %t493, i64 %t494)
  %t501 = insertvalue { i64, ptr } undef, i64 %t495, 0
  %t502 = insertvalue { i64, ptr } %t501, ptr %t496, 1
  store { i64, ptr } %t502, ptr %l15, !tbaa !27
  %t504 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t505 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t509 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %v3, { i64, ptr } %t504, { i64, ptr } %t505)
  store i32 %t509, ptr %l185
  %t510 = icmp ne i32 %t509, 0
  br i1 %t510, label %bb112, label %ok.511, !prof !99
ok.511:
  br label %bb111
bb111:
  br label %bb118
bb112:
  %t512 = load i32, ptr %l185, !tbaa !23
  %t513 = ashr i32 %t512, 16
  %t515 = icmp eq i32 %t513, 1
  store i1 %t515, ptr %l187, !tbaa !21
  %t516 = load i32, ptr %l185, !tbaa !23
  %t517 = ashr i32 %t516, 16
  %t519 = icmp eq i32 %t517, 1
  br i1 %t519, label %bb113, label %bb114
bb113:
  call void @__olang_errpay_pop()
  br label %bb114
bb114:
  br label %bb115
bb115:
  store %olang.scope zeroinitializer, ptr %s15
  %t521 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t521, ptr %l190, !tbaa !27
  %t522 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s15)
  store %"compiler/diagmsg:Msg" %t522, ptr %l191
  br label %bb116
bb116:
  %t523 = load ptr, ptr %l5, !tbaa !29
  %t524 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t525 = load %"compiler/diagmsg:Msg", ptr %l191
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s15, ptr %v4, { i64, ptr } %t524, %"compiler/diagmsg:Msg" %t525, ptr %t523)
  br label %bb117
bb117:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t528 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t528, ptr %rv
  br label %ret
bb118:
  %t529 = load ptr, ptr %l0, !tbaa !29
  %t531 = getelementptr %"compiler/build:Config", ptr %t529, i32 0, i32 1
  %t532 = load { i64, ptr }, ptr %t531, !tbaa !27
  %t534 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t532, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d234, i32 0, i32 1) })
  store i1 %t534, ptr %l196
  br label %bb119
bb119:
  %t535 = load i1, ptr %l196, !tbaa !21
  br i1 %t535, label %bb120, label %bb121
bb120:
  store %olang.scope zeroinitializer, ptr %s16
  %t536 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t537 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t540 = call i32 @std_2fos_2eRename(ptr %s0, ptr %s0, { i64, ptr } %t536, { i64, ptr } %t537)
  store i32 %t540, ptr %l199
  %t541 = icmp ne i32 %t540, 0
  br i1 %t541, label %bb123, label %ok.542, !prof !99
ok.542:
  br label %bb122
bb121:
  br label %bb130
bb122:
  br label %bb127
bb123:
  %t543 = load i32, ptr %l199, !tbaa !23
  %t544 = ashr i32 %t543, 16
  %t546 = icmp eq i32 %t544, 1
  store i1 %t546, ptr %l201, !tbaa !21
  %t547 = load i32, ptr %l199, !tbaa !23
  %t548 = ashr i32 %t547, 16
  %t550 = icmp eq i32 %t548, 1
  br i1 %t550, label %bb124, label %bb125
bb124:
  call void @__olang_errpay_pop()
  br label %bb125
bb125:
  br label %bb126
bb126:
  br label %bb127
bb127:
  %t552 = load ptr, ptr %l5, !tbaa !29
  store ptr %t552, ptr %l204, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t553
  %t554 = getelementptr { i64, [3 x i64] }, ptr %t553, i32 0, i32 0
  store i64 0, ptr %t554
  %t555 = load { i64, [3 x i64] }, ptr %t553
  store { i64, [3 x i64] } %t555, ptr %l205
  %t556 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t558 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoClang(ptr %s0, ptr %s16, { i64, ptr } %t556)
  store %"compiler/diagmsg:Msg" %t558, ptr %l207
  br label %bb128
bb128:
  %t559 = load ptr, ptr %l204, !tbaa !29
  %t560 = load { i64, [3 x i64] }, ptr %l205
  %t561 = load %"compiler/diagmsg:Msg", ptr %l207
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s16, ptr %t559, { i64, [3 x i64] } %t560, %"compiler/diagmsg:Msg" %t561)
  br label %bb129
bb129:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t563 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t563, ptr %rv
  br label %ret
bb130:
  %t564 = load ptr, ptr %lp9
  %t565 = load { i64, ptr }, ptr %t564, !tbaa !27
  store { i64, ptr } %t565, ptr %l209, !tbaa !27
  %t566 = call i32 @getpid()
  store i32 %t566, ptr %l210
  br label %bb131
bb131:
  %t567 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t568 = extractvalue { i64, ptr } %t567, 1
  %t569 = extractvalue { i64, ptr } %t567, 0
  %t570 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 1
  %t571 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d235, i32 0, i32 1) }, 0
  %t572 = add i64 %t569, %t571
  %t573 = load i32, ptr %l210, !tbaa !23
  %t574 = sext i32 %t573 to i64
  %t575 = call i64 @__olang_fmt_i64(ptr null, i64 %t574)
  %t576 = add i64 %t572, %t575
  %t577 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d236, i32 0, i32 1) }, 1
  %t578 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d236, i32 0, i32 1) }, 0
  %t579 = add i64 %t576, %t578
  %t580 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t579)
  call void @olang_textcopy(ptr %t580, ptr %t568, i64 %t569)
  %t581 = getelementptr i8, ptr %t580, i64 %t569
  call void @olang_textcopy(ptr %t581, ptr %t570, i64 %t571)
  %t582 = getelementptr i8, ptr %t581, i64 %t571
  %t583 = call i64 @__olang_fmt_i64(ptr %t582, i64 %t574)
  %t584 = getelementptr i8, ptr %t582, i64 %t575
  call void @olang_textcopy(ptr %t584, ptr %t577, i64 %t578)
  %t585 = insertvalue { i64, ptr } undef, i64 %t579, 0
  %t586 = insertvalue { i64, ptr } %t585, ptr %t580, 1
  store { i64, ptr } %t586, ptr %l16, !tbaa !27
  %t588 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v1, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t588, ptr %l212
  br label %bb132
bb132:
  %t589 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l212
  %t590 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t589, ptr %t590
  store ptr %t590, ptr %l17, !tbaa !29
  %t592 = load ptr, ptr %l17, !tbaa !29
  %t593 = load ptr, ptr %l0, !tbaa !29
  %t595 = getelementptr %"compiler/build:Config", ptr %t593, i32 0, i32 1
  %t596 = load { i64, ptr }, ptr %t595, !tbaa !27
  %t598 = extractvalue { i64, ptr } %t596, 1
  %t599 = extractvalue { i64, ptr } %t596, 0
  %t600 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t599)
  call void @olang_textcopy(ptr %t600, ptr %t598, i64 %t599)
  %t601 = insertvalue { i64, ptr } undef, i64 %t599, 0
  %t602 = insertvalue { i64, ptr } %t601, ptr %t600, 1
  %t604 = extractvalue { i64, ptr } %t602, 0
  %t605 = extractvalue { i64, ptr } %t602, 1
  %t606 = mul i64 %t604, 1
  %t607 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t606)
  call void @llvm.memcpy.p0.p0.i64(ptr %t607, ptr %t605, i64 %t606, i1 false)
  %t608 = insertvalue { i64, ptr } undef, i64 %t604, 0
  %t609 = insertvalue { i64, ptr } %t608, ptr %t607, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t592, { i64, ptr } %t609)
  br label %bb133
bb133:
  store ptr %l8, ptr %l18, !tbaa !29
  store i64 0, ptr %l19, !tbaa !24
  br label %bb134
bb134:
  %t613 = load i64, ptr %l19, !tbaa !24
  store i64 %t613, ptr %l220, !tbaa !24
  %t614 = load ptr, ptr %l18, !tbaa !29
  %t616 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t614)
  store i64 %t616, ptr %l222
  br label %bb135
bb135:
  %t617 = load i64, ptr %l220, !tbaa !24
  %t618 = load i64, ptr %l222, !tbaa !24
  %t619 = icmp slt i64 %t617, %t618
  %t621 = xor i1 %t619, true
  br i1 %t621, label %bb136, label %bb137
bb136:
  br label %bb142
bb137:
  br label %bb138
bb138:
  %t623 = load ptr, ptr %l18, !tbaa !29
  %t624 = load i64, ptr %l19, !tbaa !24
  %t627 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t623, i64 %t624)
  store { i64, ptr } %t627, ptr %l227
  br label %bb139
bb139:
  %t628 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t629 = load ptr, ptr %l17, !tbaa !29
  %t632 = extractvalue { i64, ptr } %t628, 1
  %t633 = extractvalue { i64, ptr } %t628, 0
  %t634 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t633)
  call void @olang_textcopy(ptr %t634, ptr %t632, i64 %t633)
  %t635 = insertvalue { i64, ptr } undef, i64 %t633, 0
  %t636 = insertvalue { i64, ptr } %t635, ptr %t634, 1
  %t638 = extractvalue { i64, ptr } %t636, 0
  %t639 = extractvalue { i64, ptr } %t636, 1
  %t640 = mul i64 %t638, 1
  %t641 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t640)
  call void @llvm.memcpy.p0.p0.i64(ptr %t641, ptr %t639, i64 %t640, i1 false)
  %t642 = insertvalue { i64, ptr } undef, i64 %t638, 0
  %t643 = insertvalue { i64, ptr } %t642, ptr %t641, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t629, { i64, ptr } %t643)
  br label %bb140
bb140:
  br label %bb141
bb141:
  %t646 = load i64, ptr %l19, !tbaa !24
  %t648 = add i64 %t646, 1
  store i64 %t648, ptr %l19, !tbaa !24
  br label %bb134
bb142:
  %t650 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t650, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d237, i32 0, i32 1) })
  br label %bb143
bb143:
  %t652 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t652, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d238, i32 0, i32 1) })
  br label %bb144
bb144:
  %t654 = load ptr, ptr %l17, !tbaa !29
  %t655 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t657 = extractvalue { i64, ptr } %t655, 1
  %t658 = extractvalue { i64, ptr } %t655, 0
  %t659 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t658)
  call void @olang_textcopy(ptr %t659, ptr %t657, i64 %t658)
  %t660 = insertvalue { i64, ptr } undef, i64 %t658, 0
  %t661 = insertvalue { i64, ptr } %t660, ptr %t659, 1
  %t663 = extractvalue { i64, ptr } %t661, 0
  %t664 = extractvalue { i64, ptr } %t661, 1
  %t665 = mul i64 %t663, 1
  %t666 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t665)
  call void @llvm.memcpy.p0.p0.i64(ptr %t666, ptr %t664, i64 %t665, i1 false)
  %t667 = insertvalue { i64, ptr } undef, i64 %t663, 0
  %t668 = insertvalue { i64, ptr } %t667, ptr %t666, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t654, { i64, ptr } %t668)
  br label %bb145
bb145:
  %t671 = load ptr, ptr %l17, !tbaa !29
  %t672 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t674 = extractvalue { i64, ptr } %t672, 1
  %t675 = extractvalue { i64, ptr } %t672, 0
  %t676 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t675)
  call void @olang_textcopy(ptr %t676, ptr %t674, i64 %t675)
  %t677 = insertvalue { i64, ptr } undef, i64 %t675, 0
  %t678 = insertvalue { i64, ptr } %t677, ptr %t676, 1
  %t680 = extractvalue { i64, ptr } %t678, 0
  %t681 = extractvalue { i64, ptr } %t678, 1
  %t682 = mul i64 %t680, 1
  %t683 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t682)
  call void @llvm.memcpy.p0.p0.i64(ptr %t683, ptr %t681, i64 %t682, i1 false)
  %t684 = insertvalue { i64, ptr } undef, i64 %t680, 0
  %t685 = insertvalue { i64, ptr } %t684, ptr %t683, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t671, { i64, ptr } %t685)
  br label %bb146
bb146:
  %t688 = load i1, ptr %l10, !tbaa !21
  br i1 %t688, label %bb147, label %bb148
bb147:
  %t690 = load ptr, ptr %l17, !tbaa !29
  %t691 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t692 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d239, i32 0, i32 1) }, 1
  %t693 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d239, i32 0, i32 1) }, 0
  %t695 = extractvalue { i64, ptr } %t691, 1
  %t696 = extractvalue { i64, ptr } %t691, 0
  %t697 = add i64 %t693, %t696
  %t698 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 1
  %t699 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d240, i32 0, i32 1) }, 0
  %t700 = add i64 %t697, %t699
  %t701 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t700)
  call void @olang_textcopy(ptr %t701, ptr %t692, i64 %t693)
  %t702 = getelementptr i8, ptr %t701, i64 %t693
  call void @olang_textcopy(ptr %t702, ptr %t695, i64 %t696)
  %t703 = getelementptr i8, ptr %t702, i64 %t696
  call void @olang_textcopy(ptr %t703, ptr %t698, i64 %t699)
  %t704 = insertvalue { i64, ptr } undef, i64 %t700, 0
  %t705 = insertvalue { i64, ptr } %t704, ptr %t701, 1
  %t707 = extractvalue { i64, ptr } %t705, 0
  %t708 = extractvalue { i64, ptr } %t705, 1
  %t709 = mul i64 %t707, 1
  %t710 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t709)
  call void @llvm.memcpy.p0.p0.i64(ptr %t710, ptr %t708, i64 %t709, i1 false)
  %t711 = insertvalue { i64, ptr } undef, i64 %t707, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t710, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t690, { i64, ptr } %t712)
  br label %bb149
bb148:
  br label %bb150
bb149:
  br label %bb150
bb150:
  %t715 = load ptr, ptr %l1, !tbaa !29
  %t717 = getelementptr %"compiler/build:compiles", ptr %t715, i32 0, i32 0
  store ptr %t717, ptr %l250, !tbaa !29
  %t718 = load ptr, ptr %l17, !tbaa !29
  %t720 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v1, ptr %v1, ptr %t718)
  store { i64, ptr } %t720, ptr %l252
  br label %bb151
bb151:
  %t721 = load ptr, ptr %l250, !tbaa !29
  %t722 = load { i64, ptr }, ptr %l252, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v1, ptr %v1, ptr %t721, { i64, ptr } %t722)
  br label %bb152
bb152:
  %t723 = load ptr, ptr %l1, !tbaa !29
  %t725 = getelementptr %"compiler/build:compiles", ptr %t723, i32 0, i32 1
  %t726 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t728 = extractvalue { i64, ptr } %t726, 1
  %t729 = extractvalue { i64, ptr } %t726, 0
  %t730 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t729)
  call void @olang_textcopy(ptr %t730, ptr %t728, i64 %t729)
  %t731 = insertvalue { i64, ptr } undef, i64 %t729, 0
  %t732 = insertvalue { i64, ptr } %t731, ptr %t730, 1
  %t734 = extractvalue { i64, ptr } %t732, 0
  %t735 = extractvalue { i64, ptr } %t732, 1
  %t736 = mul i64 %t734, 1
  %t737 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t736)
  call void @llvm.memcpy.p0.p0.i64(ptr %t737, ptr %t735, i64 %t736, i1 false)
  %t738 = insertvalue { i64, ptr } undef, i64 %t734, 0
  %t739 = insertvalue { i64, ptr } %t738, ptr %t737, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t725, { i64, ptr } %t739)
  br label %bb153
bb153:
  %t742 = load ptr, ptr %l1, !tbaa !29
  %t744 = getelementptr %"compiler/build:compiles", ptr %t742, i32 0, i32 5
  store ptr %t744, ptr %l259, !tbaa !29
  %t745 = load i1, ptr %l10, !tbaa !21
  br i1 %t745, label %bb154, label %bb155
bb154:
  %t747 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t749 = extractvalue { i64, ptr } %t747, 1
  %t750 = extractvalue { i64, ptr } %t747, 0
  %t751 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d241, i32 0, i32 1) }, 1
  %t752 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d241, i32 0, i32 1) }, 0
  %t753 = add i64 %t750, %t752
  %t754 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t753)
  call void @olang_textcopy(ptr %t754, ptr %t749, i64 %t750)
  %t755 = getelementptr i8, ptr %t754, i64 %t750
  call void @olang_textcopy(ptr %t755, ptr %t751, i64 %t752)
  %t756 = insertvalue { i64, ptr } undef, i64 %t753, 0
  %t757 = insertvalue { i64, ptr } %t756, ptr %t754, 1
  store { i64, ptr } %t757, ptr %l261, !tbaa !27
  br label %bb156
bb155:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d242, i32 0, i32 1) }, ptr %l264, !tbaa !27
  %t759 = load { i64, ptr }, ptr %l264, !tbaa !27
  store { i64, ptr } %t759, ptr %l261, !tbaa !27
  br label %bb156
bb156:
  %t761 = load { i64, ptr }, ptr %l261, !tbaa !27
  %t762 = extractvalue { i64, ptr } %t761, 0
  %t763 = extractvalue { i64, ptr } %t761, 1
  %t764 = mul i64 %t762, 1
  %t765 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t764)
  call void @llvm.memcpy.p0.p0.i64(ptr %t765, ptr %t763, i64 %t764, i1 false)
  %t766 = insertvalue { i64, ptr } undef, i64 %t762, 0
  %t767 = insertvalue { i64, ptr } %t766, ptr %t765, 1
  %t768 = load ptr, ptr %l259, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t768, { i64, ptr } %t767)
  br label %bb157
bb157:
  %t770 = load ptr, ptr %l1, !tbaa !29
  %t772 = getelementptr %"compiler/build:compiles", ptr %t770, i32 0, i32 2
  %t773 = load ptr, ptr %lp9
  %t774 = load { i64, ptr }, ptr %t773, !tbaa !27
  %t776 = extractvalue { i64, ptr } %t774, 1
  %t777 = extractvalue { i64, ptr } %t774, 0
  %t778 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t777)
  call void @olang_textcopy(ptr %t778, ptr %t776, i64 %t777)
  %t779 = insertvalue { i64, ptr } undef, i64 %t777, 0
  %t780 = insertvalue { i64, ptr } %t779, ptr %t778, 1
  %t782 = extractvalue { i64, ptr } %t780, 0
  %t783 = extractvalue { i64, ptr } %t780, 1
  %t784 = mul i64 %t782, 1
  %t785 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t784)
  call void @llvm.memcpy.p0.p0.i64(ptr %t785, ptr %t783, i64 %t784, i1 false)
  %t786 = insertvalue { i64, ptr } undef, i64 %t782, 0
  %t787 = insertvalue { i64, ptr } %t786, ptr %t785, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t772, { i64, ptr } %t787)
  br label %bb158
bb158:
  %t790 = load ptr, ptr %l1, !tbaa !29
  %t792 = getelementptr %"compiler/build:compiles", ptr %t790, i32 0, i32 3
  %t793 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t795 = extractvalue { i64, ptr } %t793, 1
  %t796 = extractvalue { i64, ptr } %t793, 0
  %t797 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t796)
  call void @olang_textcopy(ptr %t797, ptr %t795, i64 %t796)
  %t798 = insertvalue { i64, ptr } undef, i64 %t796, 0
  %t799 = insertvalue { i64, ptr } %t798, ptr %t797, 1
  %t801 = extractvalue { i64, ptr } %t799, 0
  %t802 = extractvalue { i64, ptr } %t799, 1
  %t803 = mul i64 %t801, 1
  %t804 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t803)
  call void @llvm.memcpy.p0.p0.i64(ptr %t804, ptr %t802, i64 %t803, i1 false)
  %t805 = insertvalue { i64, ptr } undef, i64 %t801, 0
  %t806 = insertvalue { i64, ptr } %t805, ptr %t804, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t792, { i64, ptr } %t806)
  br label %bb159
bb159:
  %t809 = load ptr, ptr %l1, !tbaa !29
  %t811 = getelementptr %"compiler/build:compiles", ptr %t809, i32 0, i32 4
  %t812 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t814 = extractvalue { i64, ptr } %t812, 1
  %t815 = extractvalue { i64, ptr } %t812, 0
  %t816 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t815)
  call void @olang_textcopy(ptr %t816, ptr %t814, i64 %t815)
  %t817 = insertvalue { i64, ptr } undef, i64 %t815, 0
  %t818 = insertvalue { i64, ptr } %t817, ptr %t816, 1
  %t820 = extractvalue { i64, ptr } %t818, 0
  %t821 = extractvalue { i64, ptr } %t818, 1
  %t822 = mul i64 %t820, 1
  %t823 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t822)
  call void @llvm.memcpy.p0.p0.i64(ptr %t823, ptr %t821, i64 %t822, i1 false)
  %t824 = insertvalue { i64, ptr } undef, i64 %t820, 0
  %t825 = insertvalue { i64, ptr } %t824, ptr %t823, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t811, { i64, ptr } %t825)
  br label %bb160
bb160:
  %t828 = load ptr, ptr %l1, !tbaa !29
  %t830 = getelementptr %"compiler/build:compiles", ptr %t828, i32 0, i32 6
  %t831 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t833 = extractvalue { i64, ptr } %t831, 0
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v1, ptr %t830, i64 %t833)
  br label %bb161
bb161:
  %t836 = load ptr, ptr %lp9
  %t837 = load { i64, ptr }, ptr %t836, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t839 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t837, 1
  store { i32, { i64, ptr } } %t839, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2ewidth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l7 = alloca i64
  %l10 = alloca i64
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 18
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = icmp sgt i64 %t4, 0
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t8 = load ptr, ptr %l0, !tbaa !29
  %t10 = getelementptr %"compiler/build:Config", ptr %t8, i32 0, i32 18
  %t11 = load i64, ptr %t10, !tbaa !24
  store i64 %t11, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t13 = call i64 @sysconf(i32 84)
  store i64 %t13, ptr %l7
  br label %bb4
bb4:
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %l1, !tbaa !24
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb5, label %bb6
bb5:
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l10, !tbaa !24
  br label %bb7
bb6:
  store i64 1, ptr %l10, !tbaa !24
  br label %bb7
bb7:
  %t21 = load i64, ptr %l10, !tbaa !24
  store i64 %t21, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i64
  %l3 = alloca %"compiler/build:Unit"
  %l6 = alloca i64
  %l8 = alloca i64
  %l13 = alloca %"compiler/build:Unit"
  %l16 = alloca i1
  %l25 = alloca i64
  %l27 = alloca { i64, ptr }
  %l30 = alloca %"compiler/build:Unit"
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Program", ptr %t1, i32 0, i32 0
  store ptr %t3, ptr %l1, !tbaa !29
  store i64 0, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l6, !tbaa !24
  %t6 = load ptr, ptr %l1, !tbaa !29
  %t8 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t6)
  store i64 %t8, ptr %l8
  br label %bb2
bb2:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l8, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb3, label %bb4
bb3:
  br label %bb14
bb4:
  br label %bb5
bb5:
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i64, ptr %l2, !tbaa !24
  %t19 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t15, i64 %t16)
  store %"compiler/build:Unit" %t19, ptr %l13
  br label %bb6
bb6:
  %t20 = load %"compiler/build:Unit", ptr %l13
  store %"compiler/build:Unit" %t20, ptr %l3
  %t21 = getelementptr %"compiler/build:Unit", ptr %l3, i32 0, i32 1
  %t22 = load i32, ptr %t21, !range !{i32 0, i32 5}
  %t24 = trunc i64 1 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb7, label %bb8
bb7:
  store i1 true, ptr %l16, !tbaa !21
  br label %bb9
bb8:
  %t27 = getelementptr %"compiler/build:Unit", ptr %l3, i32 0, i32 1
  %t28 = load i32, ptr %t27, !range !{i32 0, i32 5}
  %t30 = trunc i64 2 to i32
  %t31 = icmp eq i32 %t28, %t30
  store i1 %t31, ptr %l16, !tbaa !21
  br label %bb9
bb9:
  %t33 = load i1, ptr %l16, !tbaa !21
  br i1 %t33, label %bb10, label %bb11
bb10:
  %t34 = getelementptr %"compiler/build:Unit", ptr %l3, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t35, 1
  %t38 = extractvalue { i64, ptr } %t35, 0
  %t39 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t37, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %rv
  br label %ret
bb11:
  br label %bb12
bb12:
  br label %bb13
bb13:
  %t43 = load i64, ptr %l2, !tbaa !24
  %t45 = add i64 %t43, 1
  store i64 %t45, ptr %l2, !tbaa !24
  br label %bb1
bb14:
  %t47 = load ptr, ptr %l0, !tbaa !29
  %t49 = getelementptr %"compiler/build:Program", ptr %t47, i32 0, i32 0
  %t51 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %t49)
  store i64 %t51, ptr %l25
  br label %bb15
bb15:
  %t52 = load i64, ptr %l25, !tbaa !24
  %t53 = icmp sgt i64 %t52, 0
  br i1 %t53, label %bb16, label %bb17
bb16:
  %t55 = load ptr, ptr %l0, !tbaa !29
  %t57 = getelementptr %"compiler/build:Program", ptr %t55, i32 0, i32 0
  %t59 = call %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v0, ptr %t57, i64 0)
  store %"compiler/build:Unit" %t59, ptr %l30
  br label %bb18
bb17:
  store { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d243, i32 0, i32 1) }, ptr %l33, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t60, ptr %l27, !tbaa !27
  br label %bb19
bb18:
  %t62 = getelementptr %"compiler/build:Unit", ptr %l30, i32 0, i32 0
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  store { i64, ptr } %t69, ptr %l27, !tbaa !27
  br label %bb19
bb19:
  %t71 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t71, 0
  store i64 %t72, ptr %l35, !tbaa !24
  %t73 = load i64, ptr %l35, !tbaa !24
  %t74 = mul i64 %t73, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t74)
  %t76 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  store { i64, ptr } %t77, ptr %l36, !tbaa !27
  %t78 = getelementptr { i64, ptr }, ptr %l36, i32 0, i32 1
  %t79 = load ptr, ptr %t78, !tbaa !27
  %t80 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = load i64, ptr %l35, !tbaa !24
  %t83 = mul i64 %t82, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t79, ptr %t81, i64 %t83, i1 false)
  %t84 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t84, ptr %l27, !tbaa !27
  %t85 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t85, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca [8 x i8]
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i64
  %l27 = alloca i64
  %l30 = alloca i64
  %l53 = alloca i64
  %l61 = alloca %"std/prelude/text:StringBuilder"
  %l73 = alloca ptr
  %l74 = alloca i32
  %l75 = alloca i64
  %l76 = alloca i32
  %l77 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Sha256", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t7 = mul i64 %t4, 8
  store i64 %t7, ptr %l1, !tbaa !65
  %t9 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t9, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d244, i32 0, i32 1) })
  br label %bb1
bb1:
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  %t13 = getelementptr %"compiler/build:Sha256", ptr %t11, i32 0, i32 2
  %t14 = load i64, ptr %t13, !tbaa !24
  %t16 = icmp ne i64 %t14, 56
  %t18 = xor i1 %t16, true
  br i1 %t18, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s1)
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t20 = load ptr, ptr %l0, !tbaa !29
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s1, ptr %t20, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d245, i32 0, i32 1) })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb7
bb7:
  br label %bb2
bb8:
  store i64 0, ptr %l3, !tbaa !24
  store i64 8, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  %t23 = load i64, ptr %l3, !tbaa !24
  %t26 = icmp sgt i64 %t22, %t23
  br i1 %t26, label %bb9, label %bb10
bb9:
  %t28 = load i64, ptr %l5, !tbaa !24
  %t30 = icmp sgt i64 %t28, 0
  br i1 %t30, label %bb11, label %bb12
bb10:
  store i64 0, ptr %l27, !tbaa !24
  br label %bb14
bb11:
  %t32 = load i64, ptr %l4, !tbaa !24
  %t33 = load i64, ptr %l3, !tbaa !24
  %t36 = sub i64 %t32, %t33
  %t37 = load i64, ptr %l5, !tbaa !24
  %t40 = add i64 %t36, %t37
  %t42 = sub i64 %t40, 1
  %t43 = load i64, ptr %l5, !tbaa !24
  %t46 = sdiv i64 %t42, %t43
  store i64 %t46, ptr %l30, !tbaa !24
  br label %bb13
bb12:
  store i64 0, ptr %l30, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l30, !tbaa !24
  store i64 %t48, ptr %l27, !tbaa !24
  br label %bb14
bb14:
  %t49 = load i64, ptr %l27, !tbaa !24
  store i64 %t49, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb15
bb15:
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l6, !tbaa !24
  %t54 = icmp slt i64 %t50, %t51
  %t56 = xor i1 %t54, true
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb20
bb17:
  br label %bb18
bb18:
  %t58 = load i64, ptr %l3, !tbaa !24
  %t59 = load i64, ptr %l7, !tbaa !24
  %t60 = load i64, ptr %l5, !tbaa !24
  %t63 = mul i64 %t59, %t60
  %t66 = add i64 %t58, %t63
  store i64 %t66, ptr %l8, !tbaa !24
  %t68 = load i64, ptr %l8, !tbaa !24
  %t69 = load i64, ptr %l1, !tbaa !65
  %t70 = load i64, ptr %l8, !tbaa !24
  %t72 = mul i64 8, %t70
  %t74 = sub i64 56, %t72
  store i64 %t74, ptr %l53, !tbaa !65
  %t77 = load i64, ptr %l53, !tbaa !65
  %t78 = load i64, ptr %l53, !tbaa !65
  %t79 = lshr i64 %t69, %t78
  %t81 = trunc i64 %t79 to i8
  %t84 = getelementptr [8 x i8], ptr %l2, i64 0, i64 %t68
  store i8 %t81, ptr %t84, !tbaa !32
  br label %bb19
bb19:
  %t85 = load i64, ptr %l7, !tbaa !24
  %t87 = add i64 %t85, 1
  store i64 %t87, ptr %l7, !tbaa !24
  br label %bb15
bb20:
  %t89 = load ptr, ptr %l0, !tbaa !29
  %t91 = insertvalue { i64, ptr } undef, i64 8, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %l2, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %s0, ptr %t89, { i64, ptr } %t92)
  br label %bb21
bb21:
  %t95 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t95, ptr %l61
  br label %bb22
bb22:
  %t96 = load %"std/prelude/text:StringBuilder", ptr %l61
  store %"std/prelude/text:StringBuilder" %t96, ptr %l9
  %t97 = load ptr, ptr %l0, !tbaa !29
  %t99 = getelementptr %"compiler/build:Sha256", ptr %t97, i32 0, i32 0
  store ptr %t99, ptr %l10
  store i64 0, ptr %l11, !tbaa !24
  %t101 = load ptr, ptr %l10
  store i64 8, ptr %l12, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s6
  %t104 = load i64, ptr %l11, !tbaa !24
  %t105 = load i64, ptr %l12, !tbaa !24
  %t108 = icmp slt i64 %t104, %t105
  %t110 = xor i1 %t108, true
  br i1 %t110, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s6)
  br label %bb33
bb25:
  br label %bb26
bb26:
  %t112 = load ptr, ptr %l10
  %t113 = load i64, ptr %l11, !tbaa !24
  %t116 = getelementptr [8 x i32], ptr %t112, i64 0, i64 %t113
  %t117 = load i32, ptr %t116, !tbaa !84
  store ptr %l9, ptr %l73, !tbaa !29
  store i32 %t117, ptr %l74, !tbaa !64
  %t120 = call { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %s6, i64 16)
  %t121 = extractvalue { i32, i64 } %t120, 1
  %t122 = extractvalue { i32, i64 } %t120, 0
  store i32 %t122, ptr %l76
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb28, label %ok.124, !prof !99
ok.124:
  store i64 %t121, ptr %l75
  br label %bb27
bb27:
  %t125 = load i32, ptr %l74, !tbaa !64
  %t126 = load i64, ptr %l75, !tbaa !24
  %t127 = call { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %s6, i32 %t125, i64 %t126)
  store { i64, ptr } %t127, ptr %l77
  br label %bb29
bb28:
  call void @__olang_check_failed(ptr @olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58)
  unreachable
bb29:
  %t128 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  %t136 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %s6, ptr %s6, { i64, ptr } %t134, i64 8, i8 48)
  store { i64, ptr } %t136, ptr %l79
  br label %bb30
bb30:
  %t137 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t138 = extractvalue { i64, ptr } %t137, 0
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = mul i64 %t138, 1
  %t141 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t140)
  call void @llvm.memcpy.p0.p0.i64(ptr %t141, ptr %t139, i64 %t140, i1 false)
  %t142 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t144 = load ptr, ptr %l73, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s6, ptr %t144, { i64, ptr } %t143)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  br label %bb32
bb32:
  %t146 = load i64, ptr %l11, !tbaa !24
  %t148 = add i64 %t146, 1
  store i64 %t148, ptr %l11, !tbaa !24
  br label %bb23
bb33:
  %t151 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %l9)
  store { i64, ptr } %t151, ptr %l84
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t152 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t152, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i64
  %l6 = alloca ptr
  %l16 = alloca i1
  %l24 = alloca { i64, ptr }
  %l27 = alloca ptr
  %l57 = alloca { i64, ptr }
  %l60 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i64 0, ptr %l2, !tbaa !24
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = getelementptr %"compiler/build:Sha256", ptr %t6, i32 0, i32 3
  %t8 = load i64, ptr %t7, !tbaa !24
  %t9 = load i64, ptr %l3, !tbaa !24
  %t12 = add i64 %t8, %t9
  %t14 = load ptr, ptr %l6, !tbaa !29
  %t15 = getelementptr %"compiler/build:Sha256", ptr %t14, i32 0, i32 3
  store i64 %t12, ptr %t15, !tbaa !24
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"compiler/build:Sha256", ptr %t16, i32 0, i32 2
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb16
bb3:
  %t23 = load ptr, ptr %l0, !tbaa !29
  %t25 = getelementptr %"compiler/build:Sha256", ptr %t23, i32 0, i32 2
  %t26 = load i64, ptr %t25, !tbaa !24
  %t28 = icmp slt i64 %t26, 64
  br i1 %t28, label %bb4, label %bb5
bb4:
  %t30 = load i64, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l3, !tbaa !24
  %t34 = icmp slt i64 %t30, %t31
  store i1 %t34, ptr %l16, !tbaa !21
  br label %bb6
bb5:
  store i1 false, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t36 = load i1, ptr %l16, !tbaa !21
  %t37 = xor i1 %t36, true
  br i1 %t37, label %bb7, label %bb8
bb7:
  br label %bb11
bb8:
  br label %bb9
bb9:
  %t39 = load ptr, ptr %l0, !tbaa !29
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"compiler/build:Sha256", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t44, ptr %l24, !tbaa !27
  %t45 = load i64, ptr %l2, !tbaa !24
  %t47 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t48 = load ptr, ptr %t47, !tbaa !27
  %t49 = getelementptr i8, ptr %t48, i64 %t45
  %t50 = load i8, ptr %t49, !tbaa !32
  %t53 = getelementptr %"compiler/build:Sha256", ptr %t39, i32 0, i32 1
  %t55 = getelementptr [64 x i8], ptr %t53, i64 0, i64 %t43
  store i8 %t50, ptr %t55, !tbaa !32
  %t56 = load ptr, ptr %l0, !tbaa !29
  store ptr %t56, ptr %l27, !tbaa !29
  %t57 = load ptr, ptr %l27, !tbaa !29
  %t58 = getelementptr %"compiler/build:Sha256", ptr %t57, i32 0, i32 2
  %t59 = load i64, ptr %t58, !tbaa !24
  %t61 = add i64 %t59, 1
  %t63 = load ptr, ptr %l27, !tbaa !29
  %t64 = getelementptr %"compiler/build:Sha256", ptr %t63, i32 0, i32 2
  store i64 %t61, ptr %t64, !tbaa !24
  %t65 = load i64, ptr %l2, !tbaa !24
  %t67 = add i64 %t65, 1
  store i64 %t67, ptr %l2, !tbaa !24
  br label %bb10
bb10:
  br label %bb3
bb11:
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Sha256", ptr %t69, i32 0, i32 2
  %t72 = load i64, ptr %t71, !tbaa !24
  %t74 = icmp slt i64 %t72, 64
  br i1 %t74, label %bb12, label %bb13
bb12:
  br label %ret
bb13:
  br label %bb14
bb14:
  %t76 = load ptr, ptr %l0, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t79 = getelementptr %"compiler/build:Sha256", ptr %t77, i32 0, i32 1
  %t81 = insertvalue { i64, ptr } undef, i64 64, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t79, 1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v0, ptr %t76, { i64, ptr } %t82, i64 0)
  br label %bb15
bb15:
  %t85 = load ptr, ptr %l0, !tbaa !29
  %t87 = getelementptr %"compiler/build:Sha256", ptr %t85, i32 0, i32 2
  store i64 0, ptr %t87, !tbaa !24
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t88 = load i64, ptr %l2, !tbaa !24
  %t90 = add i64 %t88, 64
  %t91 = load i64, ptr %l3, !tbaa !24
  %t94 = icmp sle i64 %t90, %t91
  %t96 = xor i1 %t94, true
  br i1 %t96, label %bb18, label %bb19
bb18:
  br label %bb23
bb19:
  br label %bb20
bb20:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t99 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t100 = load i64, ptr %l2, !tbaa !24
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %t98, { i64, ptr } %t99, i64 %t100)
  br label %bb21
bb21:
  %t104 = load i64, ptr %l2, !tbaa !24
  %t106 = add i64 %t104, 64
  store i64 %t106, ptr %l2, !tbaa !24
  br label %bb22
bb22:
  br label %bb17
bb23:
  br label %bb24
bb24:
  %t108 = load i64, ptr %l2, !tbaa !24
  %t109 = load i64, ptr %l3, !tbaa !24
  %t112 = icmp slt i64 %t108, %t109
  %t114 = xor i1 %t112, true
  br i1 %t114, label %bb25, label %bb26
bb25:
  br label %bb29
bb26:
  br label %bb27
bb27:
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t117 = load ptr, ptr %l0, !tbaa !29
  %t119 = getelementptr %"compiler/build:Sha256", ptr %t117, i32 0, i32 2
  %t120 = load i64, ptr %t119, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t121, ptr %l57, !tbaa !27
  %t122 = load i64, ptr %l2, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l57, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr i8, ptr %t125, i64 %t122
  %t127 = load i8, ptr %t126, !tbaa !32
  %t130 = getelementptr %"compiler/build:Sha256", ptr %t116, i32 0, i32 1
  %t132 = getelementptr [64 x i8], ptr %t130, i64 0, i64 %t120
  store i8 %t127, ptr %t132, !tbaa !32
  %t133 = load ptr, ptr %l0, !tbaa !29
  store ptr %t133, ptr %l60, !tbaa !29
  %t134 = load ptr, ptr %l60, !tbaa !29
  %t135 = getelementptr %"compiler/build:Sha256", ptr %t134, i32 0, i32 2
  %t136 = load i64, ptr %t135, !tbaa !24
  %t138 = add i64 %t136, 1
  %t140 = load ptr, ptr %l60, !tbaa !29
  %t141 = getelementptr %"compiler/build:Sha256", ptr %t140, i32 0, i32 2
  store i64 %t138, ptr %t141, !tbaa !24
  %t142 = load i64, ptr %l2, !tbaa !24
  %t144 = add i64 %t142, 1
  store i64 %t144, ptr %l2, !tbaa !24
  br label %bb28
bb28:
  br label %bb24
bb29:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2ecompress(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca [64 x i32]
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l21 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l24 = alloca i32
  %l25 = alloca i32
  %l26 = alloca i32
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l35 = alloca i32
  %l38 = alloca [64 x i32]
  %l42 = alloca i64
  %l45 = alloca i64
  %l68 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l98 = alloca i64
  %l101 = alloca i64
  %l122 = alloca i32
  %l126 = alloca i32
  %l136 = alloca i32
  %l140 = alloca i32
  %l180 = alloca i64
  %l183 = alloca i64
  %l202 = alloca i32
  %l204 = alloca i32
  %l205 = alloca i32
  %l207 = alloca i32
  %l229 = alloca i32
  %l231 = alloca i32
  %l232 = alloca i32
  %l234 = alloca i32
  %l263 = alloca ptr
  %l267 = alloca ptr
  %l271 = alloca ptr
  %l275 = alloca ptr
  %l279 = alloca ptr
  %l283 = alloca ptr
  %l287 = alloca ptr
  %l291 = alloca ptr
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  br label %fill.4
fill.4:
  br label %fill.1
fill.1:
  %t5 = phi i64 [ 0, %fill.4 ], [ %t6, %fill.2 ]
  %t7 = icmp slt i64 %t5, 64
  br i1 %t7, label %fill.2, label %fill.3
fill.2:
  %t8 = getelementptr [64 x i32], ptr %l38, i64 0, i64 %t5
  store i32 0, ptr %t8
  %t6 = add i64 %t5, 1
  br label %fill.1
fill.3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l38, i64 256, i1 false)
  store i64 0, ptr %l4, !tbaa !24
  store i64 16, ptr %l5, !tbaa !24
  store i64 1, ptr %l6, !tbaa !24
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sgt i64 %t9, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load i64, ptr %l6, !tbaa !24
  %t17 = icmp sgt i64 %t15, 0
  br i1 %t17, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l42, !tbaa !24
  br label %bb6
bb3:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t20 = load i64, ptr %l4, !tbaa !24
  %t23 = sub i64 %t19, %t20
  %t24 = load i64, ptr %l6, !tbaa !24
  %t27 = add i64 %t23, %t24
  %t29 = sub i64 %t27, 1
  %t30 = load i64, ptr %l6, !tbaa !24
  %t33 = sdiv i64 %t29, %t30
  store i64 %t33, ptr %l45, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l45, !tbaa !24
  br label %bb5
bb5:
  %t35 = load i64, ptr %l45, !tbaa !24
  store i64 %t35, ptr %l42, !tbaa !24
  br label %bb6
bb6:
  %t36 = load i64, ptr %l42, !tbaa !24
  store i64 %t36, ptr %l7, !tbaa !24
  store i64 0, ptr %l8, !tbaa !24
  br label %bb7
bb7:
  %t37 = load i64, ptr %l8, !tbaa !24
  %t38 = load i64, ptr %l7, !tbaa !24
  %t41 = icmp slt i64 %t37, %t38
  %t43 = xor i1 %t41, true
  br i1 %t43, label %bb8, label %bb9
bb8:
  br label %bb12
bb9:
  br label %bb10
bb10:
  %t45 = load i64, ptr %l4, !tbaa !24
  %t46 = load i64, ptr %l8, !tbaa !24
  %t47 = load i64, ptr %l6, !tbaa !24
  %t50 = mul i64 %t46, %t47
  %t53 = add i64 %t45, %t50
  store i64 %t53, ptr %l9, !tbaa !24
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = mul i64 %t56, 4
  %t61 = add i64 %a2, %t58
  store i64 %t61, ptr %l10, !tbaa !24
  %t63 = load i64, ptr %l9, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t64, ptr %l68, !tbaa !27
  %t65 = load i64, ptr %l10, !tbaa !24
  %t67 = getelementptr { i64, ptr }, ptr %l68, i32 0, i32 1
  %t68 = load ptr, ptr %t67, !tbaa !27
  %t69 = getelementptr i8, ptr %t68, i64 %t65
  %t70 = load i8, ptr %t69, !tbaa !32
  %t72 = zext i8 %t70 to i32
  %t74 = shl i32 %t72, 24
  %t75 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t75, ptr %l73, !tbaa !27
  %t76 = load i64, ptr %l10, !tbaa !24
  %t78 = add i64 %t76, 1
  %t80 = getelementptr { i64, ptr }, ptr %l73, i32 0, i32 1
  %t81 = load ptr, ptr %t80, !tbaa !27
  %t82 = getelementptr i8, ptr %t81, i64 %t78
  %t83 = load i8, ptr %t82, !tbaa !32
  %t85 = zext i8 %t83 to i32
  %t87 = shl i32 %t85, 16
  %t90 = or i32 %t74, %t87
  %t91 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t91, ptr %l80, !tbaa !27
  %t92 = load i64, ptr %l10, !tbaa !24
  %t94 = add i64 %t92, 2
  %t96 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t97 = load ptr, ptr %t96, !tbaa !27
  %t98 = getelementptr i8, ptr %t97, i64 %t94
  %t99 = load i8, ptr %t98, !tbaa !32
  %t101 = zext i8 %t99 to i32
  %t103 = shl i32 %t101, 8
  %t106 = or i32 %t90, %t103
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l87, !tbaa !27
  %t108 = load i64, ptr %l10, !tbaa !24
  %t110 = add i64 %t108, 3
  %t112 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i8, ptr %t113, i64 %t110
  %t115 = load i8, ptr %t114, !tbaa !32
  %t117 = zext i8 %t115 to i32
  %t120 = or i32 %t106, %t117
  %t123 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t63
  store i32 %t120, ptr %t123, !tbaa !84
  br label %bb11
bb11:
  %t124 = load i64, ptr %l8, !tbaa !24
  %t126 = add i64 %t124, 1
  store i64 %t126, ptr %l8, !tbaa !24
  br label %bb7
bb12:
  store i64 16, ptr %l11, !tbaa !24
  store i64 64, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t128 = load i64, ptr %l12, !tbaa !24
  %t129 = load i64, ptr %l11, !tbaa !24
  %t132 = icmp sgt i64 %t128, %t129
  br i1 %t132, label %bb13, label %bb14
bb13:
  %t134 = load i64, ptr %l13, !tbaa !24
  %t136 = icmp sgt i64 %t134, 0
  br i1 %t136, label %bb15, label %bb16
bb14:
  store i64 0, ptr %l98, !tbaa !24
  br label %bb18
bb15:
  %t138 = load i64, ptr %l12, !tbaa !24
  %t139 = load i64, ptr %l11, !tbaa !24
  %t142 = sub i64 %t138, %t139
  %t143 = load i64, ptr %l13, !tbaa !24
  %t146 = add i64 %t142, %t143
  %t148 = sub i64 %t146, 1
  %t149 = load i64, ptr %l13, !tbaa !24
  %t152 = sdiv i64 %t148, %t149
  store i64 %t152, ptr %l101, !tbaa !24
  br label %bb17
bb16:
  store i64 0, ptr %l101, !tbaa !24
  br label %bb17
bb17:
  %t154 = load i64, ptr %l101, !tbaa !24
  store i64 %t154, ptr %l98, !tbaa !24
  br label %bb18
bb18:
  %t155 = load i64, ptr %l98, !tbaa !24
  store i64 %t155, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb19
bb19:
  %t156 = load i64, ptr %l15, !tbaa !24
  %t157 = load i64, ptr %l14, !tbaa !24
  %t160 = icmp slt i64 %t156, %t157
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb20, label %bb21
bb20:
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t164 = load i64, ptr %l11, !tbaa !24
  %t165 = load i64, ptr %l15, !tbaa !24
  %t166 = load i64, ptr %l13, !tbaa !24
  %t169 = mul i64 %t165, %t166
  %t172 = add i64 %t164, %t169
  store i64 %t172, ptr %l16, !tbaa !24
  %t174 = load i64, ptr %l16, !tbaa !24
  %t176 = sub i64 %t174, 15
  %t178 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t176
  %t179 = load i32, ptr %t178, !tbaa !84
  %t181 = call i32 @compiler_2fbuild_2erotr(i32 %t179, i32 7)
  store i32 %t181, ptr %l122
  br label %bb23
bb23:
  %t182 = load i64, ptr %l16, !tbaa !24
  %t184 = sub i64 %t182, 15
  %t186 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t184
  %t187 = load i32, ptr %t186, !tbaa !84
  %t189 = call i32 @compiler_2fbuild_2erotr(i32 %t187, i32 18)
  store i32 %t189, ptr %l126
  br label %bb24
bb24:
  %t190 = load i32, ptr %l122, !tbaa !64
  %t191 = load i32, ptr %l126, !tbaa !64
  %t192 = xor i32 %t190, %t191
  %t193 = load i64, ptr %l16, !tbaa !24
  %t195 = sub i64 %t193, 15
  %t197 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t195
  %t198 = load i32, ptr %t197, !tbaa !84
  %t200 = lshr i32 %t198, 3
  %t203 = xor i32 %t192, %t200
  store i32 %t203, ptr %l17, !tbaa !64
  %t205 = load i64, ptr %l16, !tbaa !24
  %t207 = sub i64 %t205, 2
  %t209 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t207
  %t210 = load i32, ptr %t209, !tbaa !84
  %t212 = call i32 @compiler_2fbuild_2erotr(i32 %t210, i32 17)
  store i32 %t212, ptr %l136
  br label %bb25
bb25:
  %t213 = load i64, ptr %l16, !tbaa !24
  %t215 = sub i64 %t213, 2
  %t217 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t215
  %t218 = load i32, ptr %t217, !tbaa !84
  %t220 = call i32 @compiler_2fbuild_2erotr(i32 %t218, i32 19)
  store i32 %t220, ptr %l140
  br label %bb26
bb26:
  %t221 = load i32, ptr %l136, !tbaa !64
  %t222 = load i32, ptr %l140, !tbaa !64
  %t223 = xor i32 %t221, %t222
  %t224 = load i64, ptr %l16, !tbaa !24
  %t226 = sub i64 %t224, 2
  %t228 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t226
  %t229 = load i32, ptr %t228, !tbaa !84
  %t231 = lshr i32 %t229, 10
  %t234 = xor i32 %t223, %t231
  %t236 = load i64, ptr %l16, !tbaa !24
  %t237 = load i64, ptr %l16, !tbaa !24
  %t239 = sub i64 %t237, 16
  %t241 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t239
  %t242 = load i32, ptr %t241, !tbaa !84
  %t243 = load i32, ptr %l17, !tbaa !64
  %t246 = add i32 %t242, %t243
  %t247 = load i64, ptr %l16, !tbaa !24
  %t249 = sub i64 %t247, 7
  %t251 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t249
  %t252 = load i32, ptr %t251, !tbaa !84
  %t255 = add i32 %t246, %t252
  %t259 = add i32 %t255, %t234
  %t262 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t236
  store i32 %t259, ptr %t262, !tbaa !84
  br label %bb27
bb27:
  %t263 = load i64, ptr %l15, !tbaa !24
  %t265 = add i64 %t263, 1
  store i64 %t265, ptr %l15, !tbaa !24
  br label %bb19
bb28:
  %t267 = load ptr, ptr %l0, !tbaa !29
  %t269 = getelementptr %"compiler/build:Sha256", ptr %t267, i32 0, i32 0
  %t270 = getelementptr [8 x i32], ptr %t269, i64 0, i64 0
  %t271 = load i32, ptr %t270, !tbaa !84
  store i32 %t271, ptr %l19, !tbaa !64
  %t273 = load ptr, ptr %l0, !tbaa !29
  %t275 = getelementptr %"compiler/build:Sha256", ptr %t273, i32 0, i32 0
  %t276 = getelementptr [8 x i32], ptr %t275, i64 0, i64 1
  %t277 = load i32, ptr %t276, !tbaa !84
  store i32 %t277, ptr %l20, !tbaa !64
  %t279 = load ptr, ptr %l0, !tbaa !29
  %t281 = getelementptr %"compiler/build:Sha256", ptr %t279, i32 0, i32 0
  %t282 = getelementptr [8 x i32], ptr %t281, i64 0, i64 2
  %t283 = load i32, ptr %t282, !tbaa !84
  store i32 %t283, ptr %l21, !tbaa !64
  %t285 = load ptr, ptr %l0, !tbaa !29
  %t287 = getelementptr %"compiler/build:Sha256", ptr %t285, i32 0, i32 0
  %t288 = getelementptr [8 x i32], ptr %t287, i64 0, i64 3
  %t289 = load i32, ptr %t288, !tbaa !84
  store i32 %t289, ptr %l22, !tbaa !64
  %t291 = load ptr, ptr %l0, !tbaa !29
  %t293 = getelementptr %"compiler/build:Sha256", ptr %t291, i32 0, i32 0
  %t294 = getelementptr [8 x i32], ptr %t293, i64 0, i64 4
  %t295 = load i32, ptr %t294, !tbaa !84
  store i32 %t295, ptr %l23, !tbaa !64
  %t297 = load ptr, ptr %l0, !tbaa !29
  %t299 = getelementptr %"compiler/build:Sha256", ptr %t297, i32 0, i32 0
  %t300 = getelementptr [8 x i32], ptr %t299, i64 0, i64 5
  %t301 = load i32, ptr %t300, !tbaa !84
  store i32 %t301, ptr %l24, !tbaa !64
  %t303 = load ptr, ptr %l0, !tbaa !29
  %t305 = getelementptr %"compiler/build:Sha256", ptr %t303, i32 0, i32 0
  %t306 = getelementptr [8 x i32], ptr %t305, i64 0, i64 6
  %t307 = load i32, ptr %t306, !tbaa !84
  store i32 %t307, ptr %l25, !tbaa !64
  %t309 = load ptr, ptr %l0, !tbaa !29
  %t311 = getelementptr %"compiler/build:Sha256", ptr %t309, i32 0, i32 0
  %t312 = getelementptr [8 x i32], ptr %t311, i64 0, i64 7
  %t313 = load i32, ptr %t312, !tbaa !84
  store i32 %t313, ptr %l26, !tbaa !64
  store i64 0, ptr %l27, !tbaa !24
  store i64 64, ptr %l28, !tbaa !24
  store i64 1, ptr %l29, !tbaa !24
  %t315 = load i64, ptr %l28, !tbaa !24
  %t316 = load i64, ptr %l27, !tbaa !24
  %t319 = icmp sgt i64 %t315, %t316
  br i1 %t319, label %bb29, label %bb30
bb29:
  %t321 = load i64, ptr %l29, !tbaa !24
  %t323 = icmp sgt i64 %t321, 0
  br i1 %t323, label %bb31, label %bb32
bb30:
  store i64 0, ptr %l180, !tbaa !24
  br label %bb34
bb31:
  %t325 = load i64, ptr %l28, !tbaa !24
  %t326 = load i64, ptr %l27, !tbaa !24
  %t329 = sub i64 %t325, %t326
  %t330 = load i64, ptr %l29, !tbaa !24
  %t333 = add i64 %t329, %t330
  %t335 = sub i64 %t333, 1
  %t336 = load i64, ptr %l29, !tbaa !24
  %t339 = sdiv i64 %t335, %t336
  store i64 %t339, ptr %l183, !tbaa !24
  br label %bb33
bb32:
  store i64 0, ptr %l183, !tbaa !24
  br label %bb33
bb33:
  %t341 = load i64, ptr %l183, !tbaa !24
  store i64 %t341, ptr %l180, !tbaa !24
  br label %bb34
bb34:
  %t342 = load i64, ptr %l180, !tbaa !24
  store i64 %t342, ptr %l30, !tbaa !24
  store i64 0, ptr %l31, !tbaa !24
  br label %bb35
bb35:
  %t343 = load i64, ptr %l31, !tbaa !24
  %t344 = load i64, ptr %l30, !tbaa !24
  %t347 = icmp slt i64 %t343, %t344
  %t349 = xor i1 %t347, true
  br i1 %t349, label %bb36, label %bb37
bb36:
  br label %bb46
bb37:
  br label %bb38
bb38:
  %t351 = load i64, ptr %l27, !tbaa !24
  %t352 = load i64, ptr %l31, !tbaa !24
  %t353 = load i64, ptr %l29, !tbaa !24
  %t356 = mul i64 %t352, %t353
  %t359 = add i64 %t351, %t356
  store i64 %t359, ptr %l32, !tbaa !24
  %t361 = load i32, ptr %l23, !tbaa !64
  %t363 = call i32 @compiler_2fbuild_2erotr(i32 %t361, i32 6)
  store i32 %t363, ptr %l202
  br label %bb39
bb39:
  %t364 = load i32, ptr %l23, !tbaa !64
  %t366 = call i32 @compiler_2fbuild_2erotr(i32 %t364, i32 11)
  store i32 %t366, ptr %l204
  br label %bb40
bb40:
  %t367 = load i32, ptr %l202, !tbaa !64
  %t368 = load i32, ptr %l204, !tbaa !64
  %t369 = xor i32 %t367, %t368
  store i32 %t369, ptr %l205, !tbaa !64
  %t370 = load i32, ptr %l23, !tbaa !64
  %t372 = call i32 @compiler_2fbuild_2erotr(i32 %t370, i32 25)
  store i32 %t372, ptr %l207
  br label %bb41
bb41:
  %t373 = load i32, ptr %l205, !tbaa !64
  %t374 = load i32, ptr %l207, !tbaa !64
  %t375 = xor i32 %t373, %t374
  %t377 = load i32, ptr %l23, !tbaa !64
  %t378 = load i32, ptr %l24, !tbaa !64
  %t381 = and i32 %t377, %t378
  %t382 = load i32, ptr %l23, !tbaa !64
  %t384 = xor i32 %t382, -1
  %t385 = load i32, ptr %l25, !tbaa !64
  %t388 = and i32 %t384, %t385
  %t391 = xor i32 %t381, %t388
  %t393 = load i32, ptr %l26, !tbaa !64
  %t397 = add i32 %t393, %t375
  %t401 = add i32 %t397, %t391
  %t402 = load i64, ptr %l32, !tbaa !24
  %t404 = getelementptr [64 x i32], ptr @G_2ecompiler_2fbuild_2eShaK, i64 0, i64 %t402
  %t405 = load i32, ptr %t404, !tbaa !84
  %t408 = add i32 %t401, %t405
  %t409 = load i64, ptr %l32, !tbaa !24
  %t411 = getelementptr [64 x i32], ptr %l3, i64 0, i64 %t409
  %t412 = load i32, ptr %t411, !tbaa !84
  %t415 = add i32 %t408, %t412
  store i32 %t415, ptr %l35, !tbaa !64
  %t417 = load i32, ptr %l19, !tbaa !64
  %t419 = call i32 @compiler_2fbuild_2erotr(i32 %t417, i32 2)
  store i32 %t419, ptr %l229
  br label %bb42
bb42:
  %t420 = load i32, ptr %l19, !tbaa !64
  %t422 = call i32 @compiler_2fbuild_2erotr(i32 %t420, i32 13)
  store i32 %t422, ptr %l231
  br label %bb43
bb43:
  %t423 = load i32, ptr %l229, !tbaa !64
  %t424 = load i32, ptr %l231, !tbaa !64
  %t425 = xor i32 %t423, %t424
  store i32 %t425, ptr %l232, !tbaa !64
  %t426 = load i32, ptr %l19, !tbaa !64
  %t428 = call i32 @compiler_2fbuild_2erotr(i32 %t426, i32 22)
  store i32 %t428, ptr %l234
  br label %bb44
bb44:
  %t429 = load i32, ptr %l232, !tbaa !64
  %t430 = load i32, ptr %l234, !tbaa !64
  %t431 = xor i32 %t429, %t430
  %t433 = load i32, ptr %l19, !tbaa !64
  %t434 = load i32, ptr %l20, !tbaa !64
  %t437 = and i32 %t433, %t434
  %t438 = load i32, ptr %l19, !tbaa !64
  %t439 = load i32, ptr %l21, !tbaa !64
  %t442 = and i32 %t438, %t439
  %t445 = xor i32 %t437, %t442
  %t446 = load i32, ptr %l20, !tbaa !64
  %t447 = load i32, ptr %l21, !tbaa !64
  %t450 = and i32 %t446, %t447
  %t453 = xor i32 %t445, %t450
  %t455 = load i32, ptr %l25, !tbaa !64
  store i32 %t455, ptr %l26, !tbaa !64
  %t457 = load i32, ptr %l24, !tbaa !64
  store i32 %t457, ptr %l25, !tbaa !64
  %t459 = load i32, ptr %l23, !tbaa !64
  store i32 %t459, ptr %l24, !tbaa !64
  %t461 = load i32, ptr %l22, !tbaa !64
  %t462 = load i32, ptr %l35, !tbaa !64
  %t465 = add i32 %t461, %t462
  store i32 %t465, ptr %l23, !tbaa !64
  %t467 = load i32, ptr %l21, !tbaa !64
  store i32 %t467, ptr %l22, !tbaa !64
  %t469 = load i32, ptr %l20, !tbaa !64
  store i32 %t469, ptr %l21, !tbaa !64
  %t471 = load i32, ptr %l19, !tbaa !64
  store i32 %t471, ptr %l20, !tbaa !64
  %t473 = load i32, ptr %l35, !tbaa !64
  %t477 = add i32 %t473, %t431
  %t481 = add i32 %t477, %t453
  store i32 %t481, ptr %l19, !tbaa !64
  br label %bb45
bb45:
  %t483 = load i64, ptr %l31, !tbaa !24
  %t485 = add i64 %t483, 1
  store i64 %t485, ptr %l31, !tbaa !24
  br label %bb35
bb46:
  %t487 = load ptr, ptr %l0, !tbaa !29
  store ptr %t487, ptr %l263, !tbaa !29
  %t488 = load ptr, ptr %l263, !tbaa !29
  %t489 = getelementptr %"compiler/build:Sha256", ptr %t488, i32 0, i32 0
  %t490 = getelementptr [8 x i32], ptr %t489, i64 0, i64 0
  %t491 = load i32, ptr %t490, !tbaa !84
  %t492 = load i32, ptr %l19, !tbaa !64
  %t495 = add i32 %t491, %t492
  %t497 = load ptr, ptr %l263, !tbaa !29
  %t498 = getelementptr %"compiler/build:Sha256", ptr %t497, i32 0, i32 0
  %t499 = getelementptr [8 x i32], ptr %t498, i64 0, i64 0
  store i32 %t495, ptr %t499, !tbaa !84
  %t500 = load ptr, ptr %l0, !tbaa !29
  store ptr %t500, ptr %l267, !tbaa !29
  %t501 = load ptr, ptr %l267, !tbaa !29
  %t502 = getelementptr %"compiler/build:Sha256", ptr %t501, i32 0, i32 0
  %t503 = getelementptr [8 x i32], ptr %t502, i64 0, i64 1
  %t504 = load i32, ptr %t503, !tbaa !84
  %t505 = load i32, ptr %l20, !tbaa !64
  %t508 = add i32 %t504, %t505
  %t510 = load ptr, ptr %l267, !tbaa !29
  %t511 = getelementptr %"compiler/build:Sha256", ptr %t510, i32 0, i32 0
  %t512 = getelementptr [8 x i32], ptr %t511, i64 0, i64 1
  store i32 %t508, ptr %t512, !tbaa !84
  %t513 = load ptr, ptr %l0, !tbaa !29
  store ptr %t513, ptr %l271, !tbaa !29
  %t514 = load ptr, ptr %l271, !tbaa !29
  %t515 = getelementptr %"compiler/build:Sha256", ptr %t514, i32 0, i32 0
  %t516 = getelementptr [8 x i32], ptr %t515, i64 0, i64 2
  %t517 = load i32, ptr %t516, !tbaa !84
  %t518 = load i32, ptr %l21, !tbaa !64
  %t521 = add i32 %t517, %t518
  %t523 = load ptr, ptr %l271, !tbaa !29
  %t524 = getelementptr %"compiler/build:Sha256", ptr %t523, i32 0, i32 0
  %t525 = getelementptr [8 x i32], ptr %t524, i64 0, i64 2
  store i32 %t521, ptr %t525, !tbaa !84
  %t526 = load ptr, ptr %l0, !tbaa !29
  store ptr %t526, ptr %l275, !tbaa !29
  %t527 = load ptr, ptr %l275, !tbaa !29
  %t528 = getelementptr %"compiler/build:Sha256", ptr %t527, i32 0, i32 0
  %t529 = getelementptr [8 x i32], ptr %t528, i64 0, i64 3
  %t530 = load i32, ptr %t529, !tbaa !84
  %t531 = load i32, ptr %l22, !tbaa !64
  %t534 = add i32 %t530, %t531
  %t536 = load ptr, ptr %l275, !tbaa !29
  %t537 = getelementptr %"compiler/build:Sha256", ptr %t536, i32 0, i32 0
  %t538 = getelementptr [8 x i32], ptr %t537, i64 0, i64 3
  store i32 %t534, ptr %t538, !tbaa !84
  %t539 = load ptr, ptr %l0, !tbaa !29
  store ptr %t539, ptr %l279, !tbaa !29
  %t540 = load ptr, ptr %l279, !tbaa !29
  %t541 = getelementptr %"compiler/build:Sha256", ptr %t540, i32 0, i32 0
  %t542 = getelementptr [8 x i32], ptr %t541, i64 0, i64 4
  %t543 = load i32, ptr %t542, !tbaa !84
  %t544 = load i32, ptr %l23, !tbaa !64
  %t547 = add i32 %t543, %t544
  %t549 = load ptr, ptr %l279, !tbaa !29
  %t550 = getelementptr %"compiler/build:Sha256", ptr %t549, i32 0, i32 0
  %t551 = getelementptr [8 x i32], ptr %t550, i64 0, i64 4
  store i32 %t547, ptr %t551, !tbaa !84
  %t552 = load ptr, ptr %l0, !tbaa !29
  store ptr %t552, ptr %l283, !tbaa !29
  %t553 = load ptr, ptr %l283, !tbaa !29
  %t554 = getelementptr %"compiler/build:Sha256", ptr %t553, i32 0, i32 0
  %t555 = getelementptr [8 x i32], ptr %t554, i64 0, i64 5
  %t556 = load i32, ptr %t555, !tbaa !84
  %t557 = load i32, ptr %l24, !tbaa !64
  %t560 = add i32 %t556, %t557
  %t562 = load ptr, ptr %l283, !tbaa !29
  %t563 = getelementptr %"compiler/build:Sha256", ptr %t562, i32 0, i32 0
  %t564 = getelementptr [8 x i32], ptr %t563, i64 0, i64 5
  store i32 %t560, ptr %t564, !tbaa !84
  %t565 = load ptr, ptr %l0, !tbaa !29
  store ptr %t565, ptr %l287, !tbaa !29
  %t566 = load ptr, ptr %l287, !tbaa !29
  %t567 = getelementptr %"compiler/build:Sha256", ptr %t566, i32 0, i32 0
  %t568 = getelementptr [8 x i32], ptr %t567, i64 0, i64 6
  %t569 = load i32, ptr %t568, !tbaa !84
  %t570 = load i32, ptr %l25, !tbaa !64
  %t573 = add i32 %t569, %t570
  %t575 = load ptr, ptr %l287, !tbaa !29
  %t576 = getelementptr %"compiler/build:Sha256", ptr %t575, i32 0, i32 0
  %t577 = getelementptr [8 x i32], ptr %t576, i64 0, i64 6
  store i32 %t573, ptr %t577, !tbaa !84
  %t578 = load ptr, ptr %l0, !tbaa !29
  store ptr %t578, ptr %l291, !tbaa !29
  %t579 = load ptr, ptr %l291, !tbaa !29
  %t580 = getelementptr %"compiler/build:Sha256", ptr %t579, i32 0, i32 0
  %t581 = getelementptr [8 x i32], ptr %t580, i64 0, i64 7
  %t582 = load i32, ptr %t581, !tbaa !84
  %t583 = load i32, ptr %l26, !tbaa !64
  %t586 = add i32 %t582, %t583
  %t588 = load ptr, ptr %l291, !tbaa !29
  %t589 = getelementptr %"compiler/build:Sha256", ptr %t588, i32 0, i32 0
  %t590 = getelementptr [8 x i32], ptr %t589, i64 0, i64 7
  store i32 %t586, ptr %t590, !tbaa !84
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fbuild_2ecompiler_2fbuild_3acompiles_2eclaim(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i1
  %l15 = alloca i64
  %l18 = alloca i64
  %l37 = alloca i32
  %l42 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i32
  %l54 = alloca i32
  %l56 = alloca i1
  %l66 = alloca i1
  %l69 = alloca i32
  %l71 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a1, 1
  %t4 = extractvalue { i64, ptr } %a1, 0
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d246, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d246, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  store { i64, ptr } %t11, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  store i64 2, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t13 = load i64, ptr %l4, !tbaa !24
  %t14 = load i64, ptr %l3, !tbaa !24
  %t17 = icmp sgt i64 %t13, %t14
  br i1 %t17, label %bb1, label %bb2
bb1:
  %t19 = load i64, ptr %l5, !tbaa !24
  %t21 = icmp sgt i64 %t19, 0
  br i1 %t21, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l15, !tbaa !24
  br label %bb6
bb3:
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  %t27 = sub i64 %t23, %t24
  %t28 = load i64, ptr %l5, !tbaa !24
  %t31 = add i64 %t27, %t28
  %t33 = sub i64 %t31, 1
  %t34 = load i64, ptr %l5, !tbaa !24
  %t37 = sdiv i64 %t33, %t34
  store i64 %t37, ptr %l18, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l18, !tbaa !24
  br label %bb5
bb5:
  %t39 = load i64, ptr %l18, !tbaa !24
  store i64 %t39, ptr %l15, !tbaa !24
  br label %bb6
bb6:
  %t40 = load i64, ptr %l15, !tbaa !24
  store i64 %t40, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb7
bb7:
  %t41 = load i64, ptr %l7, !tbaa !24
  %t42 = load i64, ptr %l6, !tbaa !24
  %t45 = icmp slt i64 %t41, %t42
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb8, label %bb9
bb8:
  br label %bb44
bb9:
  br label %bb10
bb10:
  %t49 = load i64, ptr %l3, !tbaa !24
  %t50 = load i64, ptr %l7, !tbaa !24
  %t51 = load i64, ptr %l5, !tbaa !24
  %t54 = mul i64 %t50, %t51
  %t57 = add i64 %t49, %t54
  store i64 %t57, ptr %l8, !tbaa !24
  store i1 true, ptr %l9, !tbaa !21
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = call i32 @std_2fos_2eMkDir(ptr %s0, { i64, ptr } %t59)
  store i32 %t61, ptr %l37
  %t62 = icmp ne i32 %t61, 0
  br i1 %t62, label %bb12, label %ok.63, !prof !99
ok.63:
  br label %bb11
bb11:
  br label %bb21
bb12:
  %t64 = load i32, ptr %l37, !tbaa !23
  %t65 = icmp eq i32 %t64, 65537
  br i1 %t65, label %bb13, label %bb14
bb13:
  %t67 = load i32, ptr %l37, !tbaa !23
  %t68 = ashr i32 %t67, 16
  %t70 = icmp eq i32 %t68, 1
  br i1 %t70, label %bb15, label %bb16
bb14:
  %t72 = load i32, ptr %l37, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  store i1 %t75, ptr %l42, !tbaa !21
  %t76 = load i32, ptr %l37, !tbaa !23
  %t77 = ashr i32 %t76, 16
  %t79 = icmp eq i32 %t77, 1
  br i1 %t79, label %bb18, label %bb19
bb15:
  call void @__olang_errpay_pop()
  br label %bb16
bb16:
  br label %bb17
bb17:
  store i1 false, ptr %l9, !tbaa !21
  br label %bb21
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb21:
  %t82 = load i1, ptr %l9, !tbaa !21
  br i1 %t82, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s6
  %t84 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 1
  %t87 = extractvalue { i64, ptr } %t84, 0
  %t88 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d247, i32 0, i32 1) }, 1
  %t89 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d247, i32 0, i32 1) }, 0
  %t90 = add i64 %t87, %t89
  %t91 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t90)
  call void @olang_textcopy(ptr %t91, ptr %t86, i64 %t87)
  %t92 = getelementptr i8, ptr %t91, i64 %t87
  call void @olang_textcopy(ptr %t92, ptr %t88, i64 %t89)
  %t93 = insertvalue { i64, ptr } undef, i64 %t90, 0
  %t94 = insertvalue { i64, ptr } %t93, ptr %t91, 1
  %t96 = extractvalue { i64, ptr } %t94, 0
  %t97 = extractvalue { i64, ptr } %t94, 1
  %t98 = mul i64 %t96, 1
  %t99 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t98)
  call void @llvm.memcpy.p0.p0.i64(ptr %t99, ptr %t97, i64 %t98, i1 false)
  %t100 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t101 = insertvalue { i64, ptr } %t100, ptr %t99, 1
  store { i64, ptr } %t101, ptr %l49, !tbaa !27
  %t102 = call i32 @getpid()
  store i32 %t102, ptr %l50
  br label %bb24
bb23:
  br label %bb32
bb24:
  %t103 = load i32, ptr %l50, !tbaa !23
  %t104 = sext i32 %t103 to i64
  %t105 = call i64 @__olang_fmt_i64(ptr null, i64 %t104)
  %t106 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t105)
  %t107 = call i64 @__olang_fmt_i64(ptr %t106, i64 %t104)
  %t108 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t109 = insertvalue { i64, ptr } %t108, ptr %t106, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = extractvalue { i64, ptr } %t109, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  %t118 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t120 = call i32 @std_2fos_2eWriteFile(ptr %s6, ptr %s6, { i64, ptr } %t118, { i64, ptr } %t117)
  store i32 %t120, ptr %l54
  %t121 = icmp ne i32 %t120, 0
  br i1 %t121, label %bb26, label %ok.122, !prof !99
ok.122:
  br label %bb25
bb25:
  br label %bb30
bb26:
  %t123 = load i32, ptr %l54, !tbaa !23
  %t124 = ashr i32 %t123, 16
  %t126 = icmp eq i32 %t124, 1
  store i1 %t126, ptr %l56, !tbaa !21
  %t127 = load i32, ptr %l54, !tbaa !23
  %t128 = ashr i32 %t127, 16
  %t130 = icmp eq i32 %t128, 1
  br i1 %t130, label %bb27, label %bb28
bb27:
  call void @__olang_errpay_pop()
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t134 = getelementptr %"compiler/build:compiles", ptr %a0, i32 0, i32 7
  %t135 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t135, 1
  %t138 = extractvalue { i64, ptr } %t135, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v0, ptr %t134, { i64, ptr } %t148)
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
bb32:
  %t152 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t154 = call i1 @compiler_2fbuild_2eholderAlive(ptr %s0, { i64, ptr } %t152)
  store i1 %t154, ptr %l66
  br label %bb33
bb33:
  %t155 = load i1, ptr %l66, !tbaa !21
  br i1 %t155, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb35:
  br label %bb36
bb36:
  %t157 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t159 = call i32 @std_2fos_2eRemoveAll(ptr %s0, { i64, ptr } %t157)
  store i32 %t159, ptr %l69
  %t160 = icmp ne i32 %t159, 0
  br i1 %t160, label %bb38, label %ok.161, !prof !99
ok.161:
  br label %bb37
bb37:
  br label %bb42
bb38:
  %t162 = load i32, ptr %l69, !tbaa !23
  %t163 = ashr i32 %t162, 16
  %t165 = icmp eq i32 %t163, 1
  store i1 %t165, ptr %l71, !tbaa !21
  %t166 = load i32, ptr %l69, !tbaa !23
  %t167 = ashr i32 %t166, 16
  %t169 = icmp eq i32 %t167, 1
  br i1 %t169, label %bb39, label %bb40
bb39:
  call void @__olang_errpay_pop()
  br label %bb40
bb40:
  br label %bb41
bb41:
  br label %bb42
bb42:
  br label %bb43
bb43:
  %t171 = load i64, ptr %l7, !tbaa !24
  %t173 = add i64 %t171, 1
  store i64 %t173, ptr %l7, !tbaa !24
  br label %bb7
bb44:
  call void @__olang_scope_close(ptr %s0)
  store i1 true, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i32 @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l28 = alloca ptr
  %l35 = alloca %"compiler/build:Unit"
  %l37 = alloca ptr
  %l45 = alloca %"compiler/build:Unit"
  %l51 = alloca ptr
  %l54 = alloca i32
  %l58 = alloca %"compiler/build:Unit"
  %l60 = alloca ptr
  %l66 = alloca %"compiler/build:Unit"
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l10, !tbaa !29
  %t2 = load ptr, ptr %l10, !tbaa !29
  %t3 = getelementptr %"compiler/build:stubFrontend", ptr %t2, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = add i64 %t4, 1
  %t8 = load ptr, ptr %l10, !tbaa !29
  %t9 = getelementptr %"compiler/build:stubFrontend", ptr %t8, i32 0, i32 1
  store i64 %t6, ptr %t9, !tbaa !24
  %t10 = load ptr, ptr %l3, !tbaa !29
  %t12 = getelementptr %"compiler/build:Config", ptr %t10, i32 0, i32 3
  %t14 = call i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v2, ptr %s0, ptr %t12, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d248, i32 0, i32 1) })
  store i1 %t14, ptr %l15
  br label %bb1
bb1:
  %t15 = load i1, ptr %l15, !tbaa !21
  br i1 %t15, label %bb2, label %bb3
bb2:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t18 = getelementptr %"compiler/build:Config", ptr %t16, i32 0, i32 3
  %t20 = call { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v2, ptr %s0, ptr %s0, ptr %t18, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d249, i32 0, i32 1) })
  store { i64, ptr } %t20, ptr %l19
  br label %bb4
bb3:
  store { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d250, i32 0, i32 1) }, ptr %l16, !tbaa !27
  br label %bb5
bb4:
  %t21 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l16, !tbaa !27
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t30 = load ptr, ptr %l3, !tbaa !29
  %t32 = getelementptr %"compiler/build:Config", ptr %t30, i32 0, i32 2
  %t33 = getelementptr %"compiler/target:Target", ptr %t32, i32 0, i32 5
  %t34 = load { i64, ptr }, ptr %t33, !tbaa !27
  %t35 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d251, i32 0, i32 1) }, 1
  %t36 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d251, i32 0, i32 1) }, 0
  %t38 = extractvalue { i64, ptr } %t34, 1
  %t39 = extractvalue { i64, ptr } %t34, 0
  %t40 = add i64 %t36, %t39
  %t41 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d252, i32 0, i32 1) }, 1
  %t42 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d252, i32 0, i32 1) }, 0
  %t43 = add i64 %t40, %t42
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @olang_textcopy(ptr %t44, ptr %t35, i64 %t36)
  %t45 = getelementptr i8, ptr %t44, i64 %t36
  call void @olang_textcopy(ptr %t45, ptr %t38, i64 %t39)
  %t46 = getelementptr i8, ptr %t45, i64 %t39
  call void @olang_textcopy(ptr %t46, ptr %t41, i64 %t42)
  %t47 = insertvalue { i64, ptr } undef, i64 %t43, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t44, 1
  store { i64, ptr } %t48, ptr %l7, !tbaa !27
  %t50 = load ptr, ptr %l3, !tbaa !29
  %t52 = getelementptr %"compiler/build:Config", ptr %t50, i32 0, i32 2
  %t53 = getelementptr %"compiler/target:Target", ptr %t52, i32 0, i32 1
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !27
  %t55 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d253, i32 0, i32 1) }, 1
  %t56 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d253, i32 0, i32 1) }, 0
  %t58 = extractvalue { i64, ptr } %t54, 1
  %t59 = extractvalue { i64, ptr } %t54, 0
  %t60 = add i64 %t56, %t59
  %t61 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d254, i32 0, i32 1) }, 1
  %t62 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d254, i32 0, i32 1) }, 0
  %t63 = add i64 %t60, %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @olang_textcopy(ptr %t64, ptr %t55, i64 %t56)
  %t65 = getelementptr i8, ptr %t64, i64 %t56
  call void @olang_textcopy(ptr %t65, ptr %t58, i64 %t59)
  %t66 = getelementptr i8, ptr %t65, i64 %t59
  call void @olang_textcopy(ptr %t66, ptr %t61, i64 %t62)
  %t67 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t68 = insertvalue { i64, ptr } %t67, ptr %t64, 1
  store { i64, ptr } %t68, ptr %l8, !tbaa !27
  %t70 = load ptr, ptr %l4, !tbaa !29
  %t72 = getelementptr %"compiler/build:Program", ptr %t70, i32 0, i32 0
  store ptr %t72, ptr %l28, !tbaa !29
  %t73 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t73, 1
  %t78 = extractvalue { i64, ptr } %t73, 0
  %t79 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d255, i32 0, i32 1) }, 1
  %t80 = extractvalue { i64, ptr } { i64 35, ptr getelementptr inbounds (<{ i64, [35 x i8] }>, ptr @.d255, i32 0, i32 1) }, 0
  %t81 = add i64 %t78, %t80
  %t83 = extractvalue { i64, ptr } %t29, 1
  %t84 = extractvalue { i64, ptr } %t29, 0
  %t85 = add i64 %t81, %t84
  %t86 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d256, i32 0, i32 1) }, 1
  %t87 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d256, i32 0, i32 1) }, 0
  %t88 = add i64 %t85, %t87
  %t90 = extractvalue { i64, ptr } %t75, 1
  %t91 = extractvalue { i64, ptr } %t75, 0
  %t92 = add i64 %t88, %t91
  %t93 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t77, i64 %t78)
  %t94 = getelementptr i8, ptr %t93, i64 %t78
  call void @olang_textcopy(ptr %t94, ptr %t79, i64 %t80)
  %t95 = getelementptr i8, ptr %t94, i64 %t80
  call void @olang_textcopy(ptr %t95, ptr %t83, i64 %t84)
  %t96 = getelementptr i8, ptr %t95, i64 %t84
  call void @olang_textcopy(ptr %t96, ptr %t86, i64 %t87)
  %t97 = getelementptr i8, ptr %t96, i64 %t87
  call void @olang_textcopy(ptr %t97, ptr %t90, i64 %t91)
  %t98 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t93, 1
  %t101 = extractvalue { i64, ptr } %t99, 0
  %t102 = extractvalue { i64, ptr } %t99, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  %t109 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d257, i32 0, i32 1) }, i32 0, { i64, ptr } %t106)
  store %"compiler/build:Unit" %t109, ptr %l35
  br label %bb6
bb6:
  %t110 = load ptr, ptr %l28, !tbaa !29
  %t111 = load %"compiler/build:Unit", ptr %l35
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t110, %"compiler/build:Unit" %t111)
  br label %bb7
bb7:
  %t112 = load ptr, ptr %l4, !tbaa !29
  %t114 = getelementptr %"compiler/build:Program", ptr %t112, i32 0, i32 0
  store ptr %t114, ptr %l37, !tbaa !29
  %t115 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t116 = load ptr, ptr %l0, !tbaa !29
  %t118 = getelementptr %"compiler/build:stubFrontend", ptr %t116, i32 0, i32 0
  %t119 = load i64, ptr %t118, !tbaa !24
  %t120 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t115, 1
  %t123 = extractvalue { i64, ptr } %t115, 0
  %t124 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d258, i32 0, i32 1) }, 1
  %t125 = extractvalue { i64, ptr } { i64 36, ptr getelementptr inbounds (<{ i64, [36 x i8] }>, ptr @.d258, i32 0, i32 1) }, 0
  %t126 = add i64 %t123, %t125
  %t128 = call i64 @__olang_fmt_i64(ptr null, i64 %t119)
  %t129 = add i64 %t126, %t128
  %t130 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d259, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d259, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t134 = extractvalue { i64, ptr } %t120, 1
  %t135 = extractvalue { i64, ptr } %t120, 0
  %t136 = add i64 %t132, %t135
  %t137 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t122, i64 %t123)
  %t138 = getelementptr i8, ptr %t137, i64 %t123
  call void @olang_textcopy(ptr %t138, ptr %t124, i64 %t125)
  %t139 = getelementptr i8, ptr %t138, i64 %t125
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t119)
  %t141 = getelementptr i8, ptr %t139, i64 %t128
  call void @olang_textcopy(ptr %t141, ptr %t130, i64 %t131)
  %t142 = getelementptr i8, ptr %t141, i64 %t131
  call void @olang_textcopy(ptr %t142, ptr %t134, i64 %t135)
  %t143 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t144 = insertvalue { i64, ptr } %t143, ptr %t137, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = extractvalue { i64, ptr } %t144, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t154 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d260, i32 0, i32 1) }, i32 0, { i64, ptr } %t151)
  store %"compiler/build:Unit" %t154, ptr %l45
  br label %bb8
bb8:
  %t155 = load ptr, ptr %l37, !tbaa !29
  %t156 = load %"compiler/build:Unit", ptr %l45
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t155, %"compiler/build:Unit" %t156)
  br label %bb9
bb9:
  %t157 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t160 = extractvalue { i64, ptr } %t157, 1
  %t161 = extractvalue { i64, ptr } %t157, 0
  %t162 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d261, i32 0, i32 1) }, 1
  %t163 = extractvalue { i64, ptr } { i64 90, ptr getelementptr inbounds (<{ i64, [90 x i8] }>, ptr @.d261, i32 0, i32 1) }, 0
  %t164 = add i64 %t161, %t163
  %t165 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d262, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 73, ptr getelementptr inbounds (<{ i64, [73 x i8] }>, ptr @.d262, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d263, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 96, ptr getelementptr inbounds (<{ i64, [96 x i8] }>, ptr @.d263, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t171 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d264, i32 0, i32 1) }, 1
  %t172 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d264, i32 0, i32 1) }, 0
  %t173 = add i64 %t170, %t172
  %t175 = extractvalue { i64, ptr } %t158, 1
  %t176 = extractvalue { i64, ptr } %t158, 0
  %t177 = add i64 %t173, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t160, i64 %t161)
  %t179 = getelementptr i8, ptr %t178, i64 %t161
  call void @olang_textcopy(ptr %t179, ptr %t162, i64 %t163)
  %t180 = getelementptr i8, ptr %t179, i64 %t163
  call void @olang_textcopy(ptr %t180, ptr %t165, i64 %t166)
  %t181 = getelementptr i8, ptr %t180, i64 %t166
  call void @olang_textcopy(ptr %t181, ptr %t168, i64 %t169)
  %t182 = getelementptr i8, ptr %t181, i64 %t169
  call void @olang_textcopy(ptr %t182, ptr %t171, i64 %t172)
  %t183 = getelementptr i8, ptr %t182, i64 %t172
  call void @olang_textcopy(ptr %t183, ptr %t175, i64 %t176)
  %t184 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t178, 1
  %t187 = extractvalue { i64, ptr } %t185, 0
  %t188 = extractvalue { i64, ptr } %t185, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l9, !tbaa !27
  %t194 = load ptr, ptr %l4, !tbaa !29
  %t196 = getelementptr %"compiler/build:Program", ptr %t194, i32 0, i32 0
  store ptr %t196, ptr %l51, !tbaa !29
  %t199 = trunc i64 1 to i32
  %t200 = icmp eq i32 %a2, %t199
  br i1 %t200, label %bb10, label %bb11
bb10:
  store i32 1, ptr %l54
  br label %bb12
bb11:
  store i32 2, ptr %l54
  br label %bb12
bb12:
  %t204 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t205 = load i32, ptr %l54, !range !{i32 0, i32 5}
  %t207 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d265, i32 0, i32 1) }, i32 %t205, { i64, ptr } %t204)
  store %"compiler/build:Unit" %t207, ptr %l58
  br label %bb13
bb13:
  %t208 = load ptr, ptr %l51, !tbaa !29
  %t209 = load %"compiler/build:Unit", ptr %l58
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t208, %"compiler/build:Unit" %t209)
  br label %bb14
bb14:
  %t210 = load ptr, ptr %l4, !tbaa !29
  %t212 = getelementptr %"compiler/build:Program", ptr %t210, i32 0, i32 0
  store ptr %t212, ptr %l60, !tbaa !29
  %t213 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t213, 1
  %t217 = extractvalue { i64, ptr } %t213, 0
  %t218 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d266, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 40, ptr getelementptr inbounds (<{ i64, [40 x i8] }>, ptr @.d266, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t222 = extractvalue { i64, ptr } %t214, 1
  %t223 = extractvalue { i64, ptr } %t214, 0
  %t224 = add i64 %t220, %t223
  %t225 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t216, i64 %t217)
  %t226 = getelementptr i8, ptr %t225, i64 %t217
  call void @olang_textcopy(ptr %t226, ptr %t218, i64 %t219)
  %t227 = getelementptr i8, ptr %t226, i64 %t219
  call void @olang_textcopy(ptr %t227, ptr %t222, i64 %t223)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t225, 1
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t232 = extractvalue { i64, ptr } %t229, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t239 = call %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d267, i32 0, i32 1) }, i32 3, { i64, ptr } %t236)
  store %"compiler/build:Unit" %t239, ptr %l66
  br label %bb15
bb15:
  %t240 = load ptr, ptr %l60, !tbaa !29
  %t241 = load %"compiler/build:Unit", ptr %l66
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v3, ptr %v3, ptr %t240, %"compiler/build:Unit" %t241)
  br label %bb16
bb16:
  %t242 = load ptr, ptr %l4, !tbaa !29
  %t243 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t244 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = extractvalue { i64, ptr } %t243, 0
  %t248 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d268, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d268, i32 0, i32 1) }, 0
  %t250 = add i64 %t247, %t249
  %t252 = extractvalue { i64, ptr } %t244, 1
  %t253 = extractvalue { i64, ptr } %t244, 0
  %t254 = add i64 %t250, %t253
  %t255 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t254)
  call void @olang_textcopy(ptr %t255, ptr %t246, i64 %t247)
  %t256 = getelementptr i8, ptr %t255, i64 %t247
  call void @olang_textcopy(ptr %t256, ptr %t248, i64 %t249)
  %t257 = getelementptr i8, ptr %t256, i64 %t249
  call void @olang_textcopy(ptr %t257, ptr %t252, i64 %t253)
  %t258 = insertvalue { i64, ptr } undef, i64 %t254, 0
  %t259 = insertvalue { i64, ptr } %t258, ptr %t255, 1
  %t261 = extractvalue { i64, ptr } %t259, 0
  %t262 = extractvalue { i64, ptr } %t259, 1
  %t263 = mul i64 %t261, 1
  %t264 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t263)
  call void @llvm.memcpy.p0.p0.i64(ptr %t264, ptr %t262, i64 %t263, i1 false)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t264, 1
  %t269 = getelementptr %"compiler/build:Program", ptr %t242, i32 0, i32 1
  store { i64, ptr } %t266, ptr %t269, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t2 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d269, i32 0, i32 1) }, 1
  %t3 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d269, i32 0, i32 1) }, 0
  %t5 = extractvalue { i64, ptr } %a2, 1
  %t6 = extractvalue { i64, ptr } %a2, 0
  %t7 = add i64 %t3, %t6
  %t8 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d270, i32 0, i32 1) }, 1
  %t9 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d270, i32 0, i32 1) }, 0
  %t10 = add i64 %t7, %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t10)
  call void @olang_textcopy(ptr %t11, ptr %t2, i64 %t3)
  %t12 = getelementptr i8, ptr %t11, i64 %t3
  call void @olang_textcopy(ptr %t12, ptr %t5, i64 %t6)
  %t13 = getelementptr i8, ptr %t12, i64 %t6
  call void @olang_textcopy(ptr %t13, ptr %t8, i64 %t9)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t11, 1
  %t17 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t15, 1
  store { i32, { i64, ptr } } %t17, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, i32 } @compiler_2fbuild_2ecompiler_2fbuild_3astubFrontend_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %rv = alloca { i32, i32 }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t3 = extractvalue { i64, ptr } %a2, 0
  %t5 = trunc i64 %t3 to i32
  %t7 = insertvalue { i32, i32 } zeroinitializer, i32 %t5, 1
  store { i32, i32 } %t7, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i32 }, ptr %rv
  ret { i32, i32 } %rr
}

define dso_local void @compiler_2fbuild_2efileError(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/diagmsg:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %l11 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d271, i32 0, i32 1) }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  %t19 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/diagmsg:Msg" %a1)
  store i64 %t19, ptr %l11
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/diagmsg:Msg" %a1, ptr %a2) #0 {
entry:
  %l2 = alloca ptr
  %l6 = alloca i64
  %t9 = alloca { i64, [3 x i64] }, align 8
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v2, ptr %v0, ptr %v2, ptr %t1, { i64, ptr } %a0, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d272, i32 0, i32 1) }, i1 false)
  store i64 %t5, ptr %l6
  br label %bb1
bb1:
  %t6 = load i64, ptr %l6, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t9
  %t10 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 0
  store i64 1, ptr %t10
  %t12 = insertvalue { i64 } undef, i64 %t6, 0
  %t13 = getelementptr { i64, [3 x i64] }, ptr %t9, i32 0, i32 1
  store { i64 } %t12, ptr %t13
  %t14 = load { i64, [3 x i64] }, ptr %t9
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v2, ptr %v1, ptr %t7, { i64, [3 x i64] } %t14, %"compiler/diagmsg:Msg" %a1)
  br label %bb2
bb2:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %s0, ptr %t1)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = mul i64 %t5, 1
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @llvm.memcpy.p0.p0.i64(ptr %t8, ptr %t6, i64 %t7, i1 false)
  %t9 = insertvalue { i64, ptr } undef, i64 %t5, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t10)
  br label %bb2
bb2:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %s0, ptr %t12)
  store { i64, ptr } %t14, ptr %l5
  br label %bb3
bb3:
  %t15 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t21)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ehexOf(ptr %v0, ptr %v1, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca %"compiler/build:Sha256"
  %l2 = alloca %"compiler/build:Sha256"
  %l7 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %s0)
  store %"compiler/build:Sha256" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Sha256", ptr %l2
  store %"compiler/build:Sha256" %t2, ptr %l1
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eWrite(ptr %s0, ptr %v0, ptr %l1, { i64, ptr } %a0)
  br label %bb2
bb2:
  %t8 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aSha256_2eSum(ptr %s0, ptr %v1, ptr %l1)
  store { i64, ptr } %t8, ptr %l7
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t9, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2eholderAlive(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca %"std/os:FileInfo"
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l6 = alloca %"std/os:FileInfo"
  %l7 = alloca i32
  %l9 = alloca i1
  %l13 = alloca i64
  %l19 = alloca { i64, ptr }
  %l23 = alloca { i64, ptr }
  %l24 = alloca i32
  %l26 = alloca i1
  %l32 = alloca i1
  %l38 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l7
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l6
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l6
  store %"std/os:FileInfo" %t8, ptr %l4
  br label %bb6
bb2:
  %t9 = load i32, ptr %l7, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l9, !tbaa !21
  %t13 = load i32, ptr %l7, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t19 = load %"std/os:FileInfo", ptr %l4
  store %"std/os:FileInfo" %t19, ptr %l1
  %t20 = call i64 @std_2ftime_2eWall()
  store i64 %t20, ptr %l13
  br label %bb7
bb7:
  %t21 = getelementptr %"std/os:FileInfo", ptr %l1, i32 0, i32 2
  %t22 = load i64, ptr %t21, !tbaa !24
  %t23 = load i64, ptr %l13, !tbaa !24
  %t25 = sub i64 %t23, %t22
  store i64 %t25, ptr %l2, !tbaa !24
  %t27 = load i64, ptr %l2, !tbaa !24
  %t29 = icmp sgt i64 %t27, 1800000000000
  br i1 %t29, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t32 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t32, 1
  %t35 = extractvalue { i64, ptr } %t32, 0
  %t36 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d273, i32 0, i32 1) }, 1
  %t37 = extractvalue { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d273, i32 0, i32 1) }, 0
  %t38 = add i64 %t35, %t37
  %t39 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t38)
  call void @olang_textcopy(ptr %t39, ptr %t34, i64 %t35)
  %t40 = getelementptr i8, ptr %t39, i64 %t35
  call void @olang_textcopy(ptr %t40, ptr %t36, i64 %t37)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t39, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  %t45 = extractvalue { i64, ptr } %t42, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  %t51 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t49)
  %t52 = extractvalue { i32, { i64, ptr } } %t51, 1
  %t53 = extractvalue { i32, { i64, ptr } } %t51, 0
  store i32 %t53, ptr %l24
  %t54 = icmp ne i32 %t53, 0
  br i1 %t54, label %bb12, label %ok.55, !prof !99
ok.55:
  store { i64, ptr } %t52, ptr %l23
  br label %bb11
bb11:
  %t56 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  br label %bb16
bb12:
  %t57 = load i32, ptr %l24, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l26, !tbaa !21
  %t61 = load i32, ptr %l24, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb13, label %bb14
bb13:
  call void @__olang_errpay_pop()
  br label %bb14
bb14:
  br label %bb15
bb15:
  %t66 = load i64, ptr %l2, !tbaa !24
  %t68 = icmp slt i64 %t66, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t68, ptr %rv
  br label %ret
bb16:
  %t70 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t70, ptr %l3, !tbaa !27
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t71, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d274, i32 0, i32 1) })
  store i1 %t73, ptr %l32
  br label %bb17
bb17:
  %t74 = load i1, ptr %l32, !tbaa !21
  br i1 %t74, label %bb18, label %bb19
bb18:
  %t75 = load i64, ptr %l2, !tbaa !24
  %t77 = icmp slt i64 %t75, 60000000000
  call void @__olang_scope_close(ptr %s0)
  store i1 %t77, ptr %rv
  br label %ret
bb19:
  br label %bb20
bb20:
  %t79 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t80 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d275, i32 0, i32 1) }, 1
  %t81 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d275, i32 0, i32 1) }, 0
  %t83 = extractvalue { i64, ptr } %t79, 1
  %t84 = extractvalue { i64, ptr } %t79, 0
  %t85 = add i64 %t81, %t84
  %t86 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t85)
  call void @olang_textcopy(ptr %t86, ptr %t80, i64 %t81)
  %t87 = getelementptr i8, ptr %t86, i64 %t81
  call void @olang_textcopy(ptr %t87, ptr %t83, i64 %t84)
  %t88 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t86, 1
  %t91 = extractvalue { i64, ptr } %t89, 0
  %t92 = extractvalue { i64, ptr } %t89, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  %t98 = call i1 @std_2fos_2eExists(ptr %s0, { i64, ptr } %t96)
  store i1 %t98, ptr %l38
  br label %bb21
bb21:
  call void @__olang_scope_close(ptr %s0)
  %t99 = load i1, ptr %l38, !tbaa !21
  store i1 %t99, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2ekindSuffix(ptr %v0, i32 %a0) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l20 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca { i64, ptr }
  %rv = alloca { i64, ptr }
  store i32 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !range !{i32 0, i32 5}
  %t3 = trunc i64 0 to i32
  %t4 = icmp eq i32 %t1, %t3
  br i1 %t4, label %bb1, label %bb2
bb1:
  br label %bb3
bb2:
  br label %bb4
bb3:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d276, i32 0, i32 1) }, ptr %l4, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb21
bb4:
  %t8 = load i32, ptr %l0, !range !{i32 0, i32 5}
  %t10 = trunc i64 1 to i32
  %t11 = icmp eq i32 %t8, %t10
  br i1 %t11, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  br label %bb8
bb7:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d277, i32 0, i32 1) }, ptr %l8, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t13, ptr %l1, !tbaa !27
  br label %bb21
bb8:
  %t15 = load i32, ptr %l0, !range !{i32 0, i32 5}
  %t17 = trunc i64 2 to i32
  %t18 = icmp eq i32 %t15, %t17
  br i1 %t18, label %bb9, label %bb10
bb9:
  br label %bb11
bb10:
  br label %bb12
bb11:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d278, i32 0, i32 1) }, ptr %l12, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t20, ptr %l1, !tbaa !27
  br label %bb21
bb12:
  %t22 = load i32, ptr %l0, !range !{i32 0, i32 5}
  %t24 = trunc i64 3 to i32
  %t25 = icmp eq i32 %t22, %t24
  br i1 %t25, label %bb13, label %bb14
bb13:
  br label %bb15
bb14:
  br label %bb16
bb15:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d279, i32 0, i32 1) }, ptr %l16, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t27, ptr %l1, !tbaa !27
  br label %bb21
bb16:
  %t29 = load i32, ptr %l0, !range !{i32 0, i32 5}
  %t31 = trunc i64 4 to i32
  %t32 = icmp eq i32 %t29, %t31
  br i1 %t32, label %bb17, label %bb18
bb17:
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d280, i32 0, i32 1) }, ptr %l20, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t34, ptr %l1, !tbaa !27
  br label %bb21
bb20:
  call void @__olang_check_failed(ptr @olang_loc_7cb1cbeb873878be_a9deaf72b78184ba)
  unreachable
bb21:
  %t36 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l22, !tbaa !24
  %t38 = load i64, ptr %l22, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l23, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l22, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t49, ptr %l1, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t50, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fbuild_2elinkCurrent(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2) #0 {
entry:
  %l3 = alloca { i64, ptr }
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i32
  %l10 = alloca i1
  %l14 = alloca %"std/os:FileInfo"
  %l16 = alloca %"std/os:FileInfo"
  %l17 = alloca i32
  %l19 = alloca i1
  %l29 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v1, ptr %s0, { i64, ptr } %a1)
  %t4 = extractvalue { i32, { i64, ptr } } %t3, 1
  %t5 = extractvalue { i32, { i64, ptr } } %t3, 0
  store i32 %t5, ptr %l8
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store { i64, ptr } %t4, ptr %l7
  br label %bb1
bb1:
  %t8 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t8, ptr %l5, !tbaa !27
  br label %bb6
bb2:
  %t9 = load i32, ptr %l8, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l10, !tbaa !21
  %t13 = load i32, ptr %l8, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb6:
  %t19 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t19, ptr %l3, !tbaa !27
  %t22 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
  %t23 = extractvalue { i32, %"std/os:FileInfo" } %t22, 1
  %t24 = extractvalue { i32, %"std/os:FileInfo" } %t22, 0
  store i32 %t24, ptr %l17
  %t25 = icmp ne i32 %t24, 0
  br i1 %t25, label %bb8, label %ok.26, !prof !99
ok.26:
  store %"std/os:FileInfo" %t23, ptr %l16
  br label %bb7
bb7:
  %t27 = load %"std/os:FileInfo", ptr %l16
  store %"std/os:FileInfo" %t27, ptr %l14
  br label %bb12
bb8:
  %t28 = load i32, ptr %l17, !tbaa !23
  %t29 = ashr i32 %t28, 16
  %t31 = icmp eq i32 %t29, 1
  store i1 %t31, ptr %l19, !tbaa !21
  %t32 = load i32, ptr %l17, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  br i1 %t35, label %bb9, label %bb10
bb9:
  call void @__olang_errpay_pop()
  br label %bb10
bb10:
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s0)
  store i1 false, ptr %rv
  br label %ret
bb12:
  %t38 = load %"std/os:FileInfo", ptr %l14
  store %"std/os:FileInfo" %t38, ptr %l4
  %t39 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t41 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 1
  %t42 = load i64, ptr %t41, !tbaa !24
  %t43 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 2
  %t44 = load i64, ptr %t43, !tbaa !24
  %t46 = extractvalue { i64, ptr } %a2, 1
  %t47 = extractvalue { i64, ptr } %a2, 0
  %t48 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t49 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t50 = add i64 %t47, %t49
  %t52 = call i64 @__olang_fmt_i64(ptr null, i64 %t42)
  %t53 = add i64 %t50, %t52
  %t54 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d281, i32 0, i32 1) }, 1
  %t55 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d281, i32 0, i32 1) }, 0
  %t56 = add i64 %t53, %t55
  %t58 = call i64 @__olang_fmt_i64(ptr null, i64 %t44)
  %t59 = add i64 %t56, %t58
  %t60 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 1
  %t61 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d282, i32 0, i32 1) }, 0
  %t62 = add i64 %t59, %t61
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @olang_textcopy(ptr %t63, ptr %t46, i64 %t47)
  %t64 = getelementptr i8, ptr %t63, i64 %t47
  call void @olang_textcopy(ptr %t64, ptr %t48, i64 %t49)
  %t65 = getelementptr i8, ptr %t64, i64 %t49
  %t66 = call i64 @__olang_fmt_i64(ptr %t65, i64 %t42)
  %t67 = getelementptr i8, ptr %t65, i64 %t52
  call void @olang_textcopy(ptr %t67, ptr %t54, i64 %t55)
  %t68 = getelementptr i8, ptr %t67, i64 %t55
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t44)
  %t70 = getelementptr i8, ptr %t68, i64 %t58
  call void @olang_textcopy(ptr %t70, ptr %t60, i64 %t61)
  %t71 = insertvalue { i64, ptr } undef, i64 %t62, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t63, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t82 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t39, { i64, ptr } %t79)
  store i1 %t82, ptr %l29
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t83 = load i1, ptr %l29, !tbaa !21
  store i1 %t83, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fbuild_2elistFiles(ptr %v0, ptr %v1, { i64, ptr } %a0, i1 %a1, ptr %a2) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l2 = alloca ptr
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i32
  %l18 = alloca i1
  %l31 = alloca { i64, ptr }
  %l43 = alloca i64
  %l45 = alloca i64
  %l50 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i1
  %l66 = alloca { i64, ptr }
  %l67 = alloca i1
  %l68 = alloca i1
  %l70 = alloca i1
  %l71 = alloca i1
  %l73 = alloca i1
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  store { i64, ptr } %a0, ptr %l0
  store ptr %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l12
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t5 = call { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %s0, { i64, ptr } %t3)
  %t6 = extractvalue { i32, { i64, ptr } } %t5, 1
  %t7 = extractvalue { i32, { i64, ptr } } %t5, 0
  store i32 %t7, ptr %l16
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store { i64, ptr } %t6, ptr %l15
  br label %bb2
bb2:
  %t10 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t10, ptr %l13, !tbaa !27
  br label %bb11
bb3:
  %t11 = load i32, ptr %l16, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l18, !tbaa !21
  %t15 = load i32, ptr %l16, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = icmp sge i64 0, 0
  br i1 %t20, label %bb7, label %bb8
bb7:
  %t22 = icmp sle i64 0, 576460752303423487
  br i1 %t22, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_46572e8a3ed1f877_752b2fa47e3744e3)
  unreachable
bb9:
  %t24 = mul i64 0, 16
  %t25 = insertvalue { i64, ptr } undef, i64 0, 0
  %t26 = insertvalue { i64, ptr } %t25, ptr getelementptr (i8, ptr @__olang_empty_array, i64 64), 1
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  br label %bb11
bb10:
  call void @__olang_check_failed(ptr @olang_loc_46572e8a3ed1f877_752b2fa47e3744e3)
  unreachable
bb11:
  %t28 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t28, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t31 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t33 = extractvalue { i64, ptr } %t31, 0
  store i64 %t33, ptr %l7, !tbaa !24
  br label %bb12
bb12:
  %t35 = load i64, ptr %l6, !tbaa !24
  %t36 = load i64, ptr %l7, !tbaa !24
  %t39 = icmp slt i64 %t35, %t36
  %t41 = xor i1 %t39, true
  br i1 %t41, label %bb13, label %bb14
bb13:
  br label %bb18
bb14:
  br label %bb15
bb15:
  %t43 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t43, ptr %l31, !tbaa !27
  %t44 = load i64, ptr %l6, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr { i64, ptr }, ptr %t47, i64 %t44
  %t49 = load { i64, ptr }, ptr %t48, !tbaa !37
  %t53 = extractvalue { i64, ptr } %t49, 1
  %t54 = extractvalue { i64, ptr } %t49, 0
  %t55 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t54)
  call void @olang_textcopy(ptr %t55, ptr %t53, i64 %t54)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  %t59 = extractvalue { i64, ptr } %t57, 0
  %t60 = extractvalue { i64, ptr } %t57, 1
  %t61 = mul i64 %t59, 1
  %t62 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t61)
  call void @llvm.memcpy.p0.p0.i64(ptr %t62, ptr %t60, i64 %t61, i1 false)
  %t63 = insertvalue { i64, ptr } undef, i64 %t59, 0
  %t64 = insertvalue { i64, ptr } %t63, ptr %t62, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t64)
  br label %bb16
bb16:
  br label %bb17
bb17:
  %t67 = load i64, ptr %l6, !tbaa !24
  %t69 = add i64 %t67, 1
  store i64 %t69, ptr %l6, !tbaa !24
  br label %bb12
bb18:
  %t71 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_283, 0
  %t72 = insertvalue { ptr, ptr } %t71, ptr null, 1
  %t75 = extractvalue { ptr, ptr } %t72, 0
  %t76 = extractvalue { ptr, ptr } %t72, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %s0, ptr %s0, ptr %l3, ptr %t75, ptr %t76)
  br label %bb19
bb19:
  store ptr %l3, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb20
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t78 = load i64, ptr %l10, !tbaa !24
  store i64 %t78, ptr %l43, !tbaa !24
  %t79 = load ptr, ptr %l9, !tbaa !29
  %t81 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %s0, ptr %t79)
  store i64 %t81, ptr %l45
  br label %bb21
bb21:
  %t82 = load i64, ptr %l43, !tbaa !24
  %t83 = load i64, ptr %l45, !tbaa !24
  %t84 = icmp slt i64 %t82, %t83
  %t86 = xor i1 %t84, true
  br i1 %t86, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb49
bb23:
  br label %bb24
bb24:
  %t88 = load ptr, ptr %l9, !tbaa !29
  %t89 = load i64, ptr %l10, !tbaa !24
  %t92 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t88, i64 %t89)
  store { i64, ptr } %t92, ptr %l50
  br label %bb25
bb25:
  %t93 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t93, ptr %l11, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d284, i32 0, i32 1) }, ptr %l53, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t98 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s6, { i64, ptr } %t94, { i64, ptr } %t97)
  store i1 %t98, ptr %l54
  br label %bb26
bb26:
  %t99 = load i1, ptr %l54, !tbaa !21
  br i1 %t99, label %bb27, label %bb28
bb27:
  %t100 = load ptr, ptr %l2, !tbaa !29
  %t102 = getelementptr %"compiler/build:Listed", ptr %t100, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t103, 1
  %t107 = extractvalue { i64, ptr } %t103, 0
  %t108 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d285, i32 0, i32 1) }, 1
  %t109 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d285, i32 0, i32 1) }, 0
  %t110 = add i64 %t107, %t109
  %t112 = extractvalue { i64, ptr } %t104, 1
  %t113 = extractvalue { i64, ptr } %t104, 0
  %t114 = add i64 %t110, %t113
  %t115 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t114)
  call void @olang_textcopy(ptr %t115, ptr %t106, i64 %t107)
  %t116 = getelementptr i8, ptr %t115, i64 %t107
  call void @olang_textcopy(ptr %t116, ptr %t108, i64 %t109)
  %t117 = getelementptr i8, ptr %t116, i64 %t109
  call void @olang_textcopy(ptr %t117, ptr %t112, i64 %t113)
  %t118 = insertvalue { i64, ptr } undef, i64 %t114, 0
  %t119 = insertvalue { i64, ptr } %t118, ptr %t115, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  %t122 = extractvalue { i64, ptr } %t119, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t102, { i64, ptr } %t126)
  br label %bb29
bb28:
  br label %bb30
bb29:
  br label %bb30
bb30:
  %t129 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t131 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s6, { i64, ptr } %t129, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d286, i32 0, i32 1) })
  store i1 %t131, ptr %l62
  br label %bb31
bb31:
  %t132 = load i1, ptr %l62, !tbaa !21
  br i1 %t132, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l63, !tbaa !21
  br label %bb35
bb33:
  %t133 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d287, i32 0, i32 1) }, ptr %l66, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t137 = call i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %s0, ptr %s6, { i64, ptr } %t133, { i64, ptr } %t136)
  store i1 %t137, ptr %l67
  br label %bb34
bb34:
  %t138 = load i1, ptr %l67, !tbaa !21
  store i1 %t138, ptr %l63, !tbaa !21
  br label %bb35
bb35:
  %t139 = load i1, ptr %l63, !tbaa !21
  br i1 %t139, label %bb36, label %bb37
bb36:
  store i1 true, ptr %l68, !tbaa !21
  br label %bb39
bb37:
  %t140 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t142 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s6, { i64, ptr } %t140, { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d288, i32 0, i32 1) })
  store i1 %t142, ptr %l70
  br label %bb38
bb38:
  %t143 = load i1, ptr %l70, !tbaa !21
  store i1 %t143, ptr %l68, !tbaa !21
  br label %bb39
bb39:
  %t144 = load i1, ptr %l68, !tbaa !21
  br i1 %t144, label %bb40, label %bb41
bb40:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb41:
  br label %bb42
bb42:
  store i1 %a1, ptr %l71, !tbaa !21
  %t146 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t148 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %s0, ptr %s6, { i64, ptr } %t146, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d289, i32 0, i32 1) })
  store i1 %t148, ptr %l73
  br label %bb43
bb43:
  %t149 = load i1, ptr %l71, !tbaa !21
  %t150 = load i1, ptr %l73, !tbaa !21
  %t151 = icmp eq i1 %t149, %t150
  br i1 %t151, label %bb44, label %bb45
bb44:
  %t153 = load ptr, ptr %l2, !tbaa !29
  %t155 = getelementptr %"compiler/build:Listed", ptr %t153, i32 0, i32 0
  %t156 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t157 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = extractvalue { i64, ptr } %t156, 0
  %t161 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d290, i32 0, i32 1) }, 1
  %t162 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d290, i32 0, i32 1) }, 0
  %t163 = add i64 %t160, %t162
  %t165 = extractvalue { i64, ptr } %t157, 1
  %t166 = extractvalue { i64, ptr } %t157, 0
  %t167 = add i64 %t163, %t166
  %t168 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t167)
  call void @olang_textcopy(ptr %t168, ptr %t159, i64 %t160)
  %t169 = getelementptr i8, ptr %t168, i64 %t160
  call void @olang_textcopy(ptr %t169, ptr %t161, i64 %t162)
  %t170 = getelementptr i8, ptr %t169, i64 %t162
  call void @olang_textcopy(ptr %t170, ptr %t165, i64 %t166)
  %t171 = insertvalue { i64, ptr } undef, i64 %t167, 0
  %t172 = insertvalue { i64, ptr } %t171, ptr %t168, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = extractvalue { i64, ptr } %t172, 1
  %t176 = mul i64 %t174, 1
  %t177 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t176)
  call void @llvm.memcpy.p0.p0.i64(ptr %t177, ptr %t175, i64 %t176, i1 false)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t177, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v1, ptr %v1, ptr %t155, { i64, ptr } %t179)
  br label %bb46
bb45:
  br label %bb47
bb46:
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  br label %bb48
bb48:
  %t182 = load i64, ptr %l10, !tbaa !24
  %t184 = add i64 %t182, 1
  store i64 %t184, ptr %l10, !tbaa !24
  br label %bb20
bb49:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fbuild_2emadeBefore(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i32
  %l9 = alloca i1
  %l15 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d291, i32 0, i32 1) }, 1
  %t6 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d291, i32 0, i32 1) }, 0
  %t7 = add i64 %t4, %t6
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t3, i64 %t4)
  %t9 = getelementptr i8, ptr %t8, i64 %t4
  call void @olang_textcopy(ptr %t9, ptr %t5, i64 %t6)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t8, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t20 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t18)
  %t21 = extractvalue { i32, { i64, ptr } } %t20, 1
  %t22 = extractvalue { i32, { i64, ptr } } %t20, 0
  store i32 %t22, ptr %l7
  %t23 = icmp ne i32 %t22, 0
  br i1 %t23, label %bb2, label %ok.24, !prof !99
ok.24:
  store { i64, ptr } %t21, ptr %l6
  br label %bb1
bb1:
  %t25 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t25, ptr %l2, !tbaa !27
  br label %bb6
bb2:
  %t26 = load i32, ptr %l7, !tbaa !23
  %t27 = ashr i32 %t26, 16
  %t29 = icmp eq i32 %t27, 1
  store i1 %t29, ptr %l9, !tbaa !21
  %t30 = load i32, ptr %l7, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d292, i32 0, i32 1) }, ptr %l2, !tbaa !27
  br label %bb6
bb6:
  %t37 = extractvalue { i64, ptr } %a1, 1
  %t38 = extractvalue { i64, ptr } %a1, 0
  %t39 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d293, i32 0, i32 1) }, 1
  %t40 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d293, i32 0, i32 1) }, 0
  %t41 = add i64 %t38, %t40
  %t42 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t41)
  call void @olang_textcopy(ptr %t42, ptr %t37, i64 %t38)
  %t43 = getelementptr i8, ptr %t42, i64 %t38
  call void @olang_textcopy(ptr %t43, ptr %t39, i64 %t40)
  %t44 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t45 = insertvalue { i64, ptr } %t44, ptr %t42, 1
  %t47 = extractvalue { i64, ptr } %t45, 0
  %t48 = extractvalue { i64, ptr } %t45, 1
  %t49 = mul i64 %t47, 1
  %t50 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t49)
  call void @llvm.memcpy.p0.p0.i64(ptr %t50, ptr %t48, i64 %t49, i1 false)
  %t51 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t52 = insertvalue { i64, ptr } %t51, ptr %t50, 1
  %t53 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t55 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t53, { i64, ptr } %t52)
  store i1 %t55, ptr %l15
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t56 = load i1, ptr %l15, !tbaa !21
  store i1 %t56, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l51 = alloca i64
  %l53 = alloca i64
  %l58 = alloca { i64, ptr }
  %l61 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i1
  %l71 = alloca { i64, ptr }
  %l73 = alloca i64
  %l80 = alloca i1
  %l82 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l19
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l3
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  store i64 %t7, ptr %l6, !tbaa !24
  br label %bb2
bb2:
  %t9 = load i64, ptr %l5, !tbaa !24
  %t10 = load i64, ptr %l6, !tbaa !24
  %t13 = icmp slt i64 %t9, %t10
  %t15 = xor i1 %t13, true
  br i1 %t15, label %bb3, label %bb4
bb3:
  br label %bb8
bb4:
  br label %bb5
bb5:
  %t17 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t17, ptr %l27, !tbaa !27
  %t18 = load i64, ptr %l5, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  %t26 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 1
  %t27 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d294, i32 0, i32 1) }, 0
  %t29 = extractvalue { i64, ptr } %t23, 1
  %t30 = extractvalue { i64, ptr } %t23, 0
  %t31 = add i64 %t27, %t30
  %t32 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d295, i32 0, i32 1) }, 1
  %t33 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d295, i32 0, i32 1) }, 0
  %t34 = add i64 %t31, %t33
  %t35 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t34)
  call void @olang_textcopy(ptr %t35, ptr %t26, i64 %t27)
  %t36 = getelementptr i8, ptr %t35, i64 %t27
  call void @olang_textcopy(ptr %t36, ptr %t29, i64 %t30)
  %t37 = getelementptr i8, ptr %t36, i64 %t30
  call void @olang_textcopy(ptr %t37, ptr %t32, i64 %t33)
  %t38 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t39 = insertvalue { i64, ptr } %t38, ptr %t35, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  %t42 = extractvalue { i64, ptr } %t39, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %s0, ptr %s0, ptr %l3, { i64, ptr } %t46)
  br label %bb6
bb6:
  br label %bb7
bb7:
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = add i64 %t49, 1
  store i64 %t51, ptr %l5, !tbaa !24
  br label %bb2
bb8:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d296, i32 0, i32 1) }, ptr %l36, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t53, ptr %l37, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t55 = extractvalue { i64, ptr } %t54, 0
  store i64 %t55, ptr %l38, !tbaa !24
  %t56 = load i64, ptr %l38, !tbaa !24
  %t57 = mul i64 %t56, 1
  %t58 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t57)
  %t59 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t60 = insertvalue { i64, ptr } %t59, ptr %t58, 1
  store { i64, ptr } %t60, ptr %l39, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %l39, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t64 = load ptr, ptr %t63, !tbaa !27
  %t65 = load i64, ptr %l38, !tbaa !24
  %t66 = mul i64 %t65, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t62, ptr %t64, i64 %t66, i1 false)
  %t67 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t67, ptr %l8, !tbaa !27
  store i64 1073741824, ptr %l9, !tbaa !24
  %t68 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t68, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t72 = extractvalue { i64, ptr } %t70, 0
  store i64 %t72, ptr %l12, !tbaa !24
  br label %bb9
bb9:
  %t74 = load i64, ptr %l11, !tbaa !24
  %t75 = load i64, ptr %l12, !tbaa !24
  %t78 = icmp slt i64 %t74, %t75
  %t80 = xor i1 %t78, true
  br i1 %t80, label %bb10, label %bb11
bb10:
  br label %bb33
bb11:
  br label %bb12
bb12:
  %t82 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t82, ptr %l47, !tbaa !27
  %t83 = load i64, ptr %l11, !tbaa !24
  %t85 = getelementptr { i64, ptr }, ptr %l47, i32 0, i32 1
  %t86 = load ptr, ptr %t85, !tbaa !27
  %t87 = getelementptr { i64, ptr }, ptr %t86, i64 %t83
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !37
  store { i64, ptr } %t88, ptr %l13, !tbaa !27
  store ptr %a2, ptr %l14, !tbaa !29
  store i64 0, ptr %l15, !tbaa !24
  br label %bb13
bb13:
  %t92 = load i64, ptr %l15, !tbaa !24
  store i64 %t92, ptr %l51, !tbaa !24
  %t93 = load ptr, ptr %l14, !tbaa !29
  %t95 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v2, ptr %t93)
  store i64 %t95, ptr %l53
  br label %bb14
bb14:
  %t96 = load i64, ptr %l51, !tbaa !24
  %t97 = load i64, ptr %l53, !tbaa !24
  %t98 = icmp slt i64 %t96, %t97
  %t100 = xor i1 %t98, true
  br i1 %t100, label %bb15, label %bb16
bb15:
  br label %bb31
bb16:
  br label %bb17
bb17:
  %t102 = load ptr, ptr %l14, !tbaa !29
  %t103 = load i64, ptr %l15, !tbaa !24
  %t106 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v2, ptr %v2, ptr %t102, i64 %t103)
  store { i64, ptr } %t106, ptr %l58
  br label %bb18
bb18:
  %t107 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t107, ptr %l16, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t109 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t112 = call i64 @compiler_2fbuild_2ecloseness(ptr %v1, ptr %v2, { i64, ptr } %t108, { i64, ptr } %t109)
  store i64 %t112, ptr %l61
  br label %bb19
bb19:
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l17, !tbaa !24
  %t114 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t115 = load i64, ptr %l17, !tbaa !24
  %t118 = call i1 @compiler_2fmsgs_2eNear(ptr %v1, { i64, ptr } %t114, i64 %t115)
  store i1 %t118, ptr %l64
  br label %bb20
bb20:
  %t119 = load i1, ptr %l64, !tbaa !21
  br i1 %t119, label %bb21, label %bb22
bb21:
  %t120 = load i64, ptr %l17, !tbaa !24
  %t121 = load i64, ptr %l9, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  store i1 %t124, ptr %l65, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l65, !tbaa !21
  br label %bb23
bb23:
  %t126 = load i1, ptr %l65, !tbaa !21
  br i1 %t126, label %bb24, label %bb25
bb24:
  %t127 = load i64, ptr %l17, !tbaa !24
  store i64 %t127, ptr %l9, !tbaa !24
  %t129 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t129, 1
  %t132 = extractvalue { i64, ptr } %t129, 0
  %t133 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t132)
  call void @olang_textcopy(ptr %t133, ptr %t131, i64 %t132)
  %t134 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t133, 1
  store { i64, ptr } %t135, ptr %l71, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t137 = extractvalue { i64, ptr } %t136, 0
  %t138 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 0
  store i64 %t139, ptr %l73, !tbaa !24
  %t141 = load i64, ptr %l73, !tbaa !24
  %t142 = icmp eq i64 %t137, %t141
  br i1 %t142, label %bb26, label %bb27
bb25:
  br label %bb29
bb26:
  %t144 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t145 = load ptr, ptr %t144, !tbaa !27
  %t146 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t147 = load ptr, ptr %t146, !tbaa !27
  %t148 = load i64, ptr %l73, !tbaa !24
  %t149 = mul i64 %t148, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %t147, i64 %t149, i1 false)
  br label %bb28
bb27:
  %t150 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t150, ptr %l8, !tbaa !27
  br label %bb28
bb28:
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t151 = load i64, ptr %l15, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l15, !tbaa !24
  br label %bb13
bb31:
  br label %bb32
bb32:
  %t155 = load i64, ptr %l11, !tbaa !24
  %t157 = add i64 %t155, 1
  store i64 %t157, ptr %l11, !tbaa !24
  br label %bb9
bb33:
  %t159 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t159, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d297, i32 0, i32 1) })
  store i1 %t161, ptr %l80
  br label %bb34
bb34:
  %t162 = load i1, ptr %l80, !tbaa !21
  %t163 = xor i1 %t162, true
  br i1 %t163, label %bb35, label %bb36
bb35:
  %t165 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t166 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d298, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 17, ptr getelementptr inbounds (<{ i64, [17 x i8] }>, ptr @.d298, i32 0, i32 1) }, 0
  %t169 = extractvalue { i64, ptr } %t165, 1
  %t170 = extractvalue { i64, ptr } %t165, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d299, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d299, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t166, i64 %t167)
  %t176 = getelementptr i8, ptr %t175, i64 %t167
  call void @olang_textcopy(ptr %t176, ptr %t169, i64 %t170)
  %t177 = getelementptr i8, ptr %t176, i64 %t170
  call void @olang_textcopy(ptr %t177, ptr %t172, i64 %t173)
  %t178 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t175, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } %t179, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  store { i64, ptr } %t186, ptr %l82, !tbaa !27
  br label %bb37
bb36:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d300, i32 0, i32 1) }, ptr %l82, !tbaa !27
  br label %bb37
bb37:
  %t188 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t188, ptr %l18, !tbaa !27
  store { i64, ptr } %a0, ptr %l86, !tbaa !27
  %t191 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %s0, ptr %s0, ptr %s0, ptr %l3, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d301, i32 0, i32 1) })
  store { i64, ptr } %t191, ptr %l88
  br label %bb38
bb38:
  %t192 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t194 = extractvalue { i64, ptr } %t193, 1
  %t195 = extractvalue { i64, ptr } %t193, 0
  %t196 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d302, i32 0, i32 1) }, 1
  %t197 = extractvalue { i64, ptr } { i64 22, ptr getelementptr inbounds (<{ i64, [22 x i8] }>, ptr @.d302, i32 0, i32 1) }, 0
  %t198 = add i64 %t195, %t197
  %t199 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t200 = extractvalue { i64, ptr } %t199, 1
  %t201 = extractvalue { i64, ptr } %t199, 0
  %t202 = add i64 %t198, %t201
  %t204 = extractvalue { i64, ptr } %t192, 1
  %t205 = extractvalue { i64, ptr } %t192, 0
  %t206 = add i64 %t202, %t205
  %t207 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t206)
  call void @olang_textcopy(ptr %t207, ptr %t194, i64 %t195)
  %t208 = getelementptr i8, ptr %t207, i64 %t195
  call void @olang_textcopy(ptr %t208, ptr %t196, i64 %t197)
  %t209 = getelementptr i8, ptr %t208, i64 %t197
  call void @olang_textcopy(ptr %t209, ptr %t200, i64 %t201)
  %t210 = getelementptr i8, ptr %t209, i64 %t201
  call void @olang_textcopy(ptr %t210, ptr %t204, i64 %t205)
  %t211 = insertvalue { i64, ptr } undef, i64 %t206, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t207, 1
  call void @__olang_scope_close(ptr %s0)
  store { i64, ptr } %t212, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i32 @compiler_2fbuild_2erotr(i32 %a0, i32 %a1) #0 {
entry:
  %l0 = alloca i32
  %l1 = alloca i32
  %l3 = alloca i32
  %l7 = alloca i32
  %rv = alloca i32
  store i32 %a0, ptr %l0
  store i32 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i32, ptr %l0, !tbaa !64
  %t2 = load i32, ptr %l1, !tbaa !64
  store i32 %t2, ptr %l3, !tbaa !64
  %t4 = load i32, ptr %l3, !tbaa !64
  %t5 = load i32, ptr %l3, !tbaa !64
  %t6 = lshr i32 %t1, %t5
  %t7 = load i32, ptr %l0, !tbaa !64
  %t8 = load i32, ptr %l1, !tbaa !64
  %t10 = sub i32 32, %t8
  store i32 %t10, ptr %l7, !tbaa !64
  %t12 = load i32, ptr %l7, !tbaa !64
  %t13 = load i32, ptr %l7, !tbaa !64
  %t14 = shl i32 %t7, %t13
  %t17 = or i32 %t6, %t14
  store i32 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @compiler_2fbuild_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3) #0 {
entry:
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca %"std/os:Output"
  %l8 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i32
  %l13 = alloca i1
  %l14 = alloca %"std/os:Output"
  %l15 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca %"std/os:Output"
  %l20 = alloca i32
  %l22 = alloca i1
  %l25 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l31 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %s2 = alloca %olang.scope
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store ptr %a0, ptr %l4, !tbaa !29
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t3 = load ptr, ptr %l4, !tbaa !29
  %t5 = call { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %t3)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l11
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store i64 %t6, ptr %l10
  br label %bb2
bb2:
  %t10 = load i64, ptr %l10, !tbaa !24
  store i64 %t10, ptr %l8, !tbaa !24
  br label %bb5
bb3:
  %t11 = load i32, ptr %l11, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l13, !tbaa !21
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb13
bb5:
  %t15 = load i64, ptr %l8, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t16, ptr %l15, !tbaa !27
  %t17 = load i64, ptr %l5, !tbaa !24
  %t19 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t20 = load ptr, ptr %t19, !tbaa !27
  %t21 = getelementptr { i64, ptr }, ptr %t20, i64 %t17
  %t22 = load { i64, ptr }, ptr %t21, !tbaa !37
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l18, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t25 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v1, ptr %s2, ptr %s2, ptr %s2, { i64, ptr } %t22, { i64, ptr } %t24, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t26 = extractvalue { i32, %"std/os:Output" } %t25, 1
  %t27 = extractvalue { i32, %"std/os:Output" } %t25, 0
  store i32 %t27, ptr %l20
  %t28 = icmp ne i32 %t27, 0
  br i1 %t28, label %bb7, label %ok.29, !prof !99
ok.29:
  store %"std/os:Output" %t26, ptr %l19
  br label %bb6
bb6:
  %t30 = load %"std/os:Output", ptr %l19
  store %"std/os:Output" %t30, ptr %l14
  br label %bb11
bb7:
  %t31 = load i32, ptr %l20, !tbaa !23
  %t32 = ashr i32 %t31, 16
  %t34 = icmp eq i32 %t32, 1
  store i1 %t34, ptr %l22, !tbaa !21
  %t35 = load i32, ptr %l20, !tbaa !23
  %t36 = ashr i32 %t35, 16
  %t38 = icmp eq i32 %t36, 1
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t40 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t40, ptr %l25, !tbaa !27
  %t41 = load i64, ptr %l5, !tbaa !24
  %t43 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr i32, ptr %t44, i64 %t41
  store i32 127, ptr %t45, !tbaa !33
  %t46 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t46, ptr %l27, !tbaa !27
  %t47 = load i64, ptr %l5, !tbaa !24
  %t48 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t48, ptr %l29, !tbaa !27
  %t49 = load i64, ptr %l5, !tbaa !24
  %t51 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = getelementptr { i64, ptr }, ptr %t52, i64 %t49
  %t54 = load { i64, ptr }, ptr %t53, !tbaa !37
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t56 = load ptr, ptr %t55, !tbaa !27
  %t57 = getelementptr { i64, ptr }, ptr %t56, i64 0
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !37
  %t59 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d303, i32 0, i32 1) }, 1
  %t60 = extractvalue { i64, ptr } { i64 11, ptr getelementptr inbounds (<{ i64, [11 x i8] }>, ptr @.d303, i32 0, i32 1) }, 0
  %t62 = extractvalue { i64, ptr } %t58, 1
  %t63 = extractvalue { i64, ptr } %t58, 0
  %t64 = add i64 %t60, %t63
  %t65 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d304, i32 0, i32 1) }, 0
  %t67 = add i64 %t64, %t66
  %t68 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t59, i64 %t60)
  %t69 = getelementptr i8, ptr %t68, i64 %t60
  call void @olang_textcopy(ptr %t69, ptr %t62, i64 %t63)
  %t70 = getelementptr i8, ptr %t69, i64 %t63
  call void @olang_textcopy(ptr %t70, ptr %t65, i64 %t66)
  %t71 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t68, 1
  %t74 = extractvalue { i64, ptr } %t72, 0
  %t75 = extractvalue { i64, ptr } %t72, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  %t82 = getelementptr { i64, ptr }, ptr %l27, i32 0, i32 1
  %t83 = load ptr, ptr %t82, !tbaa !27
  %t84 = getelementptr { i64, ptr }, ptr %t83, i64 %t47
  store { i64, ptr } %t79, ptr %t84, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb11:
  %t85 = load %"std/os:Output", ptr %l14
  store %"std/os:Output" %t85, ptr %l6
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t86, ptr %l35, !tbaa !27
  %t87 = load i64, ptr %l5, !tbaa !24
  %t88 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 0
  %t89 = load i32, ptr %t88, !tbaa !23
  %t92 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t93 = load ptr, ptr %t92, !tbaa !27
  %t94 = getelementptr i32, ptr %t93, i64 %t87
  store i32 %t89, ptr %t94, !tbaa !33
  %t95 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t95, ptr %l38, !tbaa !27
  %t96 = load i64, ptr %l5, !tbaa !24
  %t97 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 1
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t99 = getelementptr %"std/os:Output", ptr %l6, i32 0, i32 2
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t98, 1
  %t103 = extractvalue { i64, ptr } %t98, 0
  %t105 = extractvalue { i64, ptr } %t100, 1
  %t106 = extractvalue { i64, ptr } %t100, 0
  %t107 = add i64 %t103, %t106
  %t108 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t107)
  call void @olang_textcopy(ptr %t108, ptr %t102, i64 %t103)
  %t109 = getelementptr i8, ptr %t108, i64 %t103
  call void @olang_textcopy(ptr %t109, ptr %t105, i64 %t106)
  %t110 = insertvalue { i64, ptr } undef, i64 %t107, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t108, 1
  %t113 = extractvalue { i64, ptr } %t111, 0
  %t114 = extractvalue { i64, ptr } %t111, 1
  %t115 = mul i64 %t113, 1
  %t116 = call ptr @__olang_scope_alloc(ptr %v3, i64 %t115)
  call void @llvm.memcpy.p0.p0.i64(ptr %t116, ptr %t114, i64 %t115, i1 false)
  %t117 = insertvalue { i64, ptr } undef, i64 %t113, 0
  %t118 = insertvalue { i64, ptr } %t117, ptr %t116, 1
  %t121 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t122 = load ptr, ptr %t121, !tbaa !27
  %t123 = getelementptr { i64, ptr }, ptr %t122, i64 %t96
  store { i64, ptr } %t118, ptr %t123, !tbaa !37
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb12:
  br label %bb1
bb13:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l2 = alloca i32
  %l4 = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = call i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
  store i32 %t3, ptr %l2
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5, !prof !99
ok.5:
  br label %bb1
bb1:
  br label %bb6
bb2:
  %t6 = load i32, ptr %l2, !tbaa !23
  %t7 = ashr i32 %t6, 16
  %t9 = icmp eq i32 %t7, 1
  store i1 %t9, ptr %l4, !tbaa !21
  %t10 = load i32, ptr %l2, !tbaa !23
  %t11 = ashr i32 %t10, 16
  %t13 = icmp eq i32 %t11, 1
  br i1 %t13, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  br label %bb6
bb6:
  br label %ret
ret:
  ret void
}

define dso_local i32 @compiler_2fbuild_2estatusOf(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l1 = alloca [1 x { i64, ptr }]
  %l2 = alloca %"std/os:Output"
  %l3 = alloca %"std/os:Output"
  %l10 = alloca { i64, ptr }
  %l11 = alloca %"std/os:Output"
  %l12 = alloca i32
  %l14 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = extractvalue { i64, ptr } %a0, 1
  %t4 = extractvalue { i64, ptr } %a0, 0
  %t5 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t4)
  call void @olang_textcopy(ptr %t5, ptr %t3, i64 %t4)
  %t6 = insertvalue { i64, ptr } undef, i64 %t4, 0
  %t7 = insertvalue { i64, ptr } %t6, ptr %t5, 1
  %t9 = extractvalue { i64, ptr } %t7, 0
  %t10 = extractvalue { i64, ptr } %t7, 1
  %t11 = mul i64 %t9, 1
  %t12 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t10, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t9, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  %t16 = insertvalue [1 x { i64, ptr }] undef, { i64, ptr } %t14, 0
  store [1 x { i64, ptr }] %t16, ptr %l1
  %t19 = insertvalue { i64, ptr } undef, i64 1, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %l1, 1
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l10, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t23 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t20, { i64, ptr } %t22, i1 true, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t24 = extractvalue { i32, %"std/os:Output" } %t23, 1
  %t25 = extractvalue { i32, %"std/os:Output" } %t23, 0
  store i32 %t25, ptr %l12
  %t26 = icmp ne i32 %t25, 0
  br i1 %t26, label %bb2, label %ok.27, !prof !99
ok.27:
  store %"std/os:Output" %t24, ptr %l11
  br label %bb1
bb1:
  %t28 = load %"std/os:Output", ptr %l11
  store %"std/os:Output" %t28, ptr %l3
  br label %bb6
bb2:
  %t29 = load i32, ptr %l12, !tbaa !23
  %t30 = ashr i32 %t29, 16
  %t32 = icmp eq i32 %t30, 1
  store i1 %t32, ptr %l14, !tbaa !21
  %t33 = load i32, ptr %l12, !tbaa !23
  %t34 = ashr i32 %t33, 16
  %t36 = icmp eq i32 %t34, 1
  br i1 %t36, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  store i32 -1, ptr %rv
  br label %ret
bb6:
  %t39 = load %"std/os:Output", ptr %l3
  store %"std/os:Output" %t39, ptr %l2
  %t40 = getelementptr %"std/os:Output", ptr %l2, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eunbuilt() #0 {
entry:
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store i32 1, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local %"compiler/build:Code" @compiler_2fbuild_3aCode_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %rv = alloca %"compiler/build:Code"
  br label %start
start:
  br label %bb0
bb0:
  %t10 = insertvalue %"compiler/build:Code" undef, { i64, ptr } %a0, 0
  %t12 = insertvalue %"compiler/build:Code" %t10, { i64, ptr } %a1, 1
  %t14 = insertvalue %"compiler/build:Code" %t12, i64 %a2, 2
  %t16 = insertvalue %"compiler/build:Code" %t14, { i64, ptr } %a3, 3
  store %"compiler/build:Code" %t16, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Code", ptr %rv
  ret %"compiler/build:Code" %rr
}

define dso_local void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"compiler/target:Target"
  %l3 = alloca %"compiler/cond:Consts"
  %l10 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/target:Target"
  %l29 = alloca %"compiler/cond:Consts"
  %l30 = alloca %"compiler/build:Config"
  %t3 = alloca %"compiler/cond:Consts", align 8
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d305, i32 0, i32 1) }, ptr %l0, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d306, i32 0, i32 1) }, ptr %l1, !tbaa !27
  %t1 = call %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
  store %"compiler/target:Target" %t1, ptr %l28
  br label %bb1
bb1:
  %t2 = load %"compiler/target:Target", ptr %l28
  store %"compiler/target:Target" %t2, ptr %l2
  call void @compiler_2fcond_3aConsts_2ector(ptr %t3, ptr %v0)
  call void @llvm.memmove.p0.p0.i64(ptr %l29, ptr %t3, i64 224, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l29, i64 224, i1 false)
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d307, i32 0, i32 1) }, ptr %l10, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d308, i32 0, i32 1) }, ptr %l14, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d309, i32 0, i32 1) }, ptr %l21, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d310, i32 0, i32 1) }, ptr %l22, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d311, i32 0, i32 1) }, ptr %l26, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d312, i32 0, i32 1) }, ptr %l27, !tbaa !27
  %t4 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %t4, !tbaa !27
  %t6 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t7, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 2
  %t9 = load %"compiler/target:Target", ptr %l2
  store %"compiler/target:Target" %t9, ptr %t8
  %t10 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 3
  call void @llvm.memmove.p0.p0.i64(ptr %t10, ptr %l3, i64 224, i1 false)
  %t11 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 4
  store i1 false, ptr %t11, !tbaa !21
  %t13 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 5
  store i1 false, ptr %t13, !tbaa !21
  %t15 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 6
  store i1 false, ptr %t15, !tbaa !21
  %t17 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 7
  store i1 false, ptr %t17, !tbaa !21
  %t19 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 8
  store i1 false, ptr %t19, !tbaa !21
  %t21 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 9
  store i1 false, ptr %t21, !tbaa !21
  %t23 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 10
  %t24 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t24, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 11
  store i64 0, ptr %t25, !tbaa !24
  %t27 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 12
  store i1 false, ptr %t27, !tbaa !21
  %t29 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 13
  store i1 false, ptr %t29, !tbaa !21
  %t31 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 14
  %t32 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t32, ptr %t31, !tbaa !27
  %t33 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 15
  store i1 false, ptr %t33, !tbaa !21
  %t35 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 16
  store i1 false, ptr %t35, !tbaa !21
  %t37 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 17
  store i1 false, ptr %t37, !tbaa !21
  %t39 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 18
  store i64 0, ptr %t39, !tbaa !24
  %t41 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 19
  store i1 false, ptr %t41, !tbaa !21
  %t43 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 20
  store i1 false, ptr %t43, !tbaa !21
  %t45 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 21
  %t46 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t46, ptr %t45, !tbaa !27
  %t47 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 22
  %t48 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t48, ptr %t47, !tbaa !27
  %t49 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 23
  store i64 0, ptr %t49, !tbaa !24
  %t51 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 24
  store i64 0, ptr %t51, !tbaa !24
  %t53 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 25
  store i1 false, ptr %t53, !tbaa !21
  %t55 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 26
  %t56 = load { i64, ptr }, ptr %l26, !tbaa !27
  store { i64, ptr } %t56, ptr %t55, !tbaa !27
  %t57 = getelementptr %"compiler/build:Config", ptr %l30, i32 0, i32 27
  %t58 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t58, ptr %t57, !tbaa !27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l30, i64 552, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %rv = alloca %"compiler/build:Listed"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l2
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l3
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  %t5 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  %t6 = insertvalue %"compiler/build:Listed" undef, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, 0
  %t8 = insertvalue %"compiler/build:Listed" %t6, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, 1
  store %"compiler/build:Listed" %t8, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Listed", ptr %rv
  ret %"compiler/build:Listed" %rr
}

define dso_local void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"compiler/build:Program"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d313, i32 0, i32 1) }, ptr %l1, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d314, i32 0, i32 1) }, ptr %l2, !tbaa !27
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l10
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l3
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l4
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d315, i32 0, i32 1) }, ptr %l5, !tbaa !27
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d316, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l12
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l7
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  %t11 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 0
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %t11
  %t13 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 1
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t14, ptr %t13, !tbaa !27
  %t15 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 2
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %t15, !tbaa !27
  %t17 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 3
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t17
  %t19 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 4
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 5
  %t22 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t22, ptr %t21, !tbaa !27
  %t23 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 6
  %t24 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t24, ptr %t23, !tbaa !27
  %t25 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 7
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t25
  %t27 = getelementptr %"compiler/build:Program", ptr %l14, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %t27
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l14, i64 224, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:Sha256" @compiler_2fbuild_3aSha256_2ector(ptr %v0) #0 {
entry:
  %l0 = alloca [8 x i32]
  %l5 = alloca [64 x i8]
  %rv = alloca %"compiler/build:Sha256"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = insertvalue [8 x i32] undef, i32 1779033703, 0
  %t2 = insertvalue [8 x i32] %t1, i32 -1150833019, 1
  %t3 = insertvalue [8 x i32] %t2, i32 1013904242, 2
  %t4 = insertvalue [8 x i32] %t3, i32 -1521486534, 3
  %t5 = insertvalue [8 x i32] %t4, i32 1359893119, 4
  %t6 = insertvalue [8 x i32] %t5, i32 -1694144372, 5
  %t7 = insertvalue [8 x i32] %t6, i32 528734635, 6
  %t8 = insertvalue [8 x i32] %t7, i32 1541459225, 7
  store [8 x i32] %t8, ptr %l0
  br label %fill.13
fill.13:
  br label %fill.10
fill.10:
  %t14 = phi i64 [ 0, %fill.13 ], [ %t15, %fill.11 ]
  %t16 = icmp slt i64 %t14, 64
  br i1 %t16, label %fill.11, label %fill.12
fill.11:
  %t17 = getelementptr [64 x i8], ptr %l5, i64 0, i64 %t14
  store i8 0, ptr %t17
  %t15 = add i64 %t14, 1
  br label %fill.10
fill.12:
  %t18 = load [64 x i8], ptr %l5
  %t19 = load [8 x i32], ptr %l0
  %t20 = insertvalue %"compiler/build:Sha256" undef, [8 x i32] %t19, 0
  %t22 = insertvalue %"compiler/build:Sha256" %t20, [64 x i8] %t18, 1
  %t24 = insertvalue %"compiler/build:Sha256" %t22, i64 0, 2
  %t26 = insertvalue %"compiler/build:Sha256" %t24, i64 0, 3
  store %"compiler/build:Sha256" %t26, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Sha256", ptr %rv
  ret %"compiler/build:Sha256" %rr
}

define dso_local %"compiler/build:Unit" @compiler_2fbuild_3aUnit_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i32 %a1, { i64, ptr } %a2) #0 {
entry:
  %l6 = alloca { i64, ptr }
  %rv = alloca %"compiler/build:Unit"
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d317, i32 0, i32 1) }, ptr %l6, !tbaa !27
  %t8 = insertvalue %"compiler/build:Unit" undef, { i64, ptr } %a0, 0
  %t10 = insertvalue %"compiler/build:Unit" %t8, i32 %a1, 1
  %t12 = insertvalue %"compiler/build:Unit" %t10, { i64, ptr } %a2, 2
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = insertvalue %"compiler/build:Unit" %t12, { i64, ptr } %t13, 3
  store %"compiler/build:Unit" %t14, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:Unit", ptr %rv
  ret %"compiler/build:Unit" %rr
}

define dso_local void @compiler_2fbuild_3acompiles_2ector(ptr %out, ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l3 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l4 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l12 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l13 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l14 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l15 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l16 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca %"compiler/build:compiles"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t1, ptr %l9
  br label %bb1
bb1:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l0
  %t3 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t3, ptr %l10
  br label %bb2
bb2:
  %t4 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l10
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t4, ptr %l1
  %t5 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t5, ptr %l11
  br label %bb3
bb3:
  %t6 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l11
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t6, ptr %l2
  %t7 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t7, ptr %l12
  br label %bb4
bb4:
  %t8 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l12
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t8, ptr %l3
  %t9 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t9, ptr %l13
  br label %bb5
bb5:
  %t10 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l13
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t10, ptr %l4
  %t11 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t11, ptr %l14
  br label %bb6
bb6:
  %t12 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l14
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t12, ptr %l5
  %t13 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t13, ptr %l15
  br label %bb7
bb7:
  %t14 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l15
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t14, ptr %l6
  %t15 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t15, ptr %l16
  br label %bb8
bb8:
  %t16 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l16
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t16, ptr %l7
  %t17 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t17, ptr %l17
  br label %bb9
bb9:
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l17
  %t19 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 0
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %t19
  %t21 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 1
  %t22 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t22, ptr %t21
  %t23 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 2
  %t24 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l2
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t24, ptr %t23
  %t25 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 3
  %t26 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l3
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t26, ptr %t25
  %t27 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 4
  %t28 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l4
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t28, ptr %t27
  %t29 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 5
  %t30 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t30, ptr %t29
  %t31 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 6
  %t32 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l6
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t32, ptr %t31
  %t33 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 7
  %t34 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l7
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t34, ptr %t33
  %t35 = getelementptr %"compiler/build:compiles", ptr %l18, i32 0, i32 8
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %t35
  call void @llvm.memmove.p0.p0.i64(ptr %out, ptr %l18, i64 288, i1 false)
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/build:stubFrontend" @compiler_2fbuild_3astubFrontend_2ector(ptr %v0) #0 {
entry:
  %rv = alloca %"compiler/build:stubFrontend"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = insertvalue %"compiler/build:stubFrontend" undef, i64 0, 0
  %t4 = insertvalue %"compiler/build:stubFrontend" %t2, i64 0, 1
  store %"compiler/build:stubFrontend" %t4, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/build:stubFrontend", ptr %rv
  ret %"compiler/build:stubFrontend" %rr
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 0] }>, align 8
@.d1 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".olang" }>, align 8
declare void @__olang_check_failed(ptr) cold noreturn
@.d2 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"OLANG_TIMES" }>, align 8
declare void @__olang_errpay_pop()
@.d3 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"olang: " }>, align 8
@.d4 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
declare i64 @__olang_fmt_i64(ptr, i64)
@.d5 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c" ms\0A" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d6 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"front" }>, align 8
@.d7 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"lower+emit" }>, align 8
declare i32 @getpid()
@.d8 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
@.d9 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
define available_externally void @__olang_scope_escape(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %un = icmp eq ptr %o, null
  br i1 %un, label %claim, label %done
claim:
  %me = load ptr, ptr @__olang_self
  store atomic ptr %me, ptr %op monotonic, align 8
  br label %done
done:
  ret void
}
define internal i1 @olang_lambda_10(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l2
  %vq0 = getelementptr { { i64, ptr }, ptr }, ptr %env, i32 0, i32 1
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t4 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t5 = load ptr, ptr %t4, !tbaa !27
  %t6 = getelementptr i64, ptr %t5, i64 %a0
  %t7 = load i64, ptr %t6, !tbaa !34
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l6, !tbaa !27
  %t11 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t12 = load ptr, ptr %t11, !tbaa !27
  %t13 = getelementptr i64, ptr %t12, i64 %a1
  %t14 = load i64, ptr %t13, !tbaa !34
  %t17 = icmp sgt i64 %t7, %t14
  store i1 %t17, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare ptr @__olang_standin(ptr)
declare ptr @__olang_worker_get()
declare void @__olang_worker_start(ptr, ptr, ptr, ptr)
define internal ptr @olang_task11(ptr %env) #0 {
entry:
  %f0 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %f1 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %f2 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %f3 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %f4 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %f5 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %f6 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 6
  %f7 = getelementptr { ptr, { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr, ptr }, ptr %env, i32 0, i32 7
  %sc0 = load ptr, ptr %f4
  %sn0 = icmp eq ptr %sc0, null
  %sg0 = load ptr, ptr @__olang_prog_scope
  %ss0 = select i1 %sn0, ptr %sg0, ptr %sc0
  %sc1 = load ptr, ptr %f5
  %sn1 = icmp eq ptr %sc1, null
  %sg1 = load ptr, ptr @__olang_prog_scope
  %ss1 = select i1 %sn1, ptr %sg1, ptr %sc1
  %sc2 = load ptr, ptr %f6
  %sn2 = icmp eq ptr %sc2, null
  %sg2 = load ptr, ptr @__olang_prog_scope
  %ss2 = select i1 %sn2, ptr %sg2, ptr %sc2
  %sc3 = load ptr, ptr %f7
  %sn3 = icmp eq ptr %sc3, null
  %sg3 = load ptr, ptr @__olang_prog_scope
  %ss3 = select i1 %sn3, ptr %sg3, ptr %sc3
  %a0 = load ptr, ptr %f0
  %a1 = load { i64, ptr }, ptr %f1
  %a2 = load { i64, ptr }, ptr %f2
  %a3 = load { i64, ptr }, ptr %f3
  call void @compiler_2fbuild_2erunner(ptr %ss0, ptr %ss1, ptr %ss2, ptr %ss3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
  ret ptr null
}

declare i64 @__olang_join_tasks(ptr)
@.d12 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d13 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"./" }>, align 8
@.d14 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Hangup" }>, align 8
@.d15 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Interrupt" }>, align 8
@.d16 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"Quit" }>, align 8
@.d17 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c"Illegal instruction" }>, align 8
@.d18 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"Trace/breakpoint trap" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"Aborted" }>, align 8
@.d20 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"Bus error" }>, align 8
@.d21 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"Floating point exception" }>, align 8
@.d22 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"Killed" }>, align 8
@.d23 = private constant <{ i64, [18 x i8] }> <{ i64 0, [18 x i8] c"Segmentation fault" }>, align 8
@.d24 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Broken pipe" }>, align 8
@.d25 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"Alarm clock" }>, align 8
@.d26 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"Terminated" }>, align 8
@.d27 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"Unknown signal " }>, align 8
@.d28 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"test" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c": lost track of its build, skipping" }>, align 8
@.d32 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d33 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c": the compiler ended (" }>, align 8
@.d34 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"), skipping" }>, align 8
@.d35 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d37 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d39 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"no listed file has a test named by " }>, align 8
@.d40 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d41 = private constant <{ i64, [62 x i8] }> <{ i64 0, [62 x i8] c"olang: error: the self-hosted compiler cannot build this yet: " }>, align 8
@.d42 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--sysroot=" }>, align 8
@.d45 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d46 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"-D_GNU_SOURCE" }>, align 8
@.d47 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-mllvm" }>, align 8
@.d48 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"-enable-shrink-wrap=false" }>, align 8
@.d49 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"bfloat" }>, align 8
@.d50 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"-mllvm" }>, align 8
@.d51 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"-fast-isel=false" }>, align 8
@.d52 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"-fsave-optimization-record" }>, align 8
@.d53 = private constant <{ i64, [29 x i8] }> <{ i64 0, [29 x i8] c"-foptimization-record-passes=" }>, align 8
@.d54 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d55 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d56 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c" \22frame-pointer\22=\22all\22" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [26 x i8] }> <{ i64 0, [26 x i8] c"-Wl,-plugin-opt,cache-dir=" }>, align 8
@.d59 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/thinlto" }>, align 8
@.d60 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"-Wl,-plugin-opt,-import-instr-limit=" }>, align 8
@.d61 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-shared" }>, align 8
@.d62 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".map" }>, align 8
@.d63 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"{\0A  global:\0A" }>, align 8
@.d64 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"    " }>, align 8
@.d65 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c";\0A" }>, align 8
@.d66 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  local: *;\0A};\0A" }>, align 8
@.d67 = private constant <{ i64, [21 x i8] }> <{ i64 0, [21 x i8] c"-Wl,--version-script=" }>, align 8
@.d68 = private constant <{ i64, [12 x i8] }> <{ i64 0, [12 x i8] c"-Wl,-soname," }>, align 8
@.d69 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d70 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-lm" }>, align 8
@.d71 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-lpthread" }>, align 8
@.d72 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-ldl" }>, align 8
@.d73 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-lrt" }>, align 8
@.d74 = private constant <{ i64, [41 x i8] }> <{ i64 0, [41 x i8] c"-Wl,-plugin-opt=-enable-shrink-wrap=false" }>, align 8
@.d75 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d76 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".link" }>, align 8
@.d77 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d78 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d79 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d80 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d81 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d82 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"--sysroot=" }>, align 8
@.d83 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d84 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-fPIC" }>, align 8
@.d85 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d86 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=fuzzer" }>, align 8
@.d87 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O0" }>, align 8
@.d88 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-g" }>, align 8
@.d89 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d90 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O1" }>, align 8
@.d91 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"-fsanitize=thread" }>, align 8
@.d92 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O2" }>, align 8
@.d93 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-O3" }>, align 8
@.d94 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-flto=thin" }>, align 8
@.d95 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-flto" }>, align 8
@.d96 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d97 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d98 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".o" }>, align 8
@.d99 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d100 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d101 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d102 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d103 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d104 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d105 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d106 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
declare i32 @usleep(i32)
@.d107 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_runtime" }>, align 8
@.d108 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d109 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"olang_dyncall" }>, align 8
@.d110 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"== " }>, align 8
@.d111 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ==" }>, align 8
@.d112 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"36" }>, align 8
@__olang_empty_array = external constant [16 x i64]
@.d113 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"code" }>, align 8
@.d114 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--target=" }>, align 8
@.d115 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d116 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d117 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-S" }>, align 8
@.d118 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-emit-llvm" }>, align 8
@.d119 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-x" }>, align 8
@.d120 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"ir" }>, align 8
@.d121 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"-Xclang" }>, align 8
@.d122 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"-disable-llvm-passes" }>, align 8
@.d123 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d124 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d125 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"--version" }>, align 8
@.d126 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d127 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d128 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d129 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d130 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d131 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c"-max_total_time=" }>, align 8
@.d132 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d133 = private constant <{ i64, [23 x i8] }> <{ i64 0, [23 x i8] c": failing inputs go to " }>, align 8
@.d134 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d135 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"36" }>, align 8
@.d136 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d137 = private constant <{ i64, [16 x i8] }> <{ i64 0, [16 x i8] c": nothing failed" }>, align 8
@.d138 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d139 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"fuzzing " }>, align 8
@.d140 = private constant <{ i64, [28 x i8] }> <{ i64 0, [28 x i8] c": an input failed, saved in " }>, align 8
@.d141 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"/ - 'olang test' replays it" }>, align 8
@.d142 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d143 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d144 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d145 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d146 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d147 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d148 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d149 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d150 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/lib" }>, align 8
@.d151 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".so" }>, align 8
@.d152 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".h" }>, align 8
@.d153 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d154 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d155 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d156 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c" and " }>, align 8
@.d157 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d158 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"-Wl,-plugin-opt,-import-instr-limit=" }>, align 8
@.d159 = private constant <{ i64, [25 x i8] }> <{ i64 0, [25 x i8] c"-Wl,-plugin-opt=emit-llvm" }>, align 8
@.d160 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"-Wl,-plugin-opt=emit-asm" }>, align 8
@.d161 = private constant <{ i64, [37 x i8] }> <{ i64 0, [37 x i8] c"-Wl,-plugin-opt=opt-remarks-filename=" }>, align 8
@.d162 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"/link.yaml" }>, align 8
@.d163 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"-Wl,-plugin-opt=opt-remarks-passes=" }>, align 8
@.d164 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d165 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/code" }>, align 8
@.d166 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-lm" }>, align 8
@.d167 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"-lpthread" }>, align 8
@.d168 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"-ldl" }>, align 8
@.d169 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d170 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"-lffi" }>, align 8
@.d171 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d172 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d173 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d174 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/code" }>, align 8
@.d175 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d176 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/made" }>, align 8
@.d177 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d178 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d179 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d180 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.c181 = private unnamed_addr constant [5 x i8] c"true\00"
@.c182 = private unnamed_addr constant [6 x i8] c"false\00"
@.d183 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d184 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d185 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-S" }>, align 8
@.d186 = private constant <{ i64, [10 x i8] }> <{ i64 0, [10 x i8] c"-emit-llvm" }>, align 8
@.d187 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d188 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c".s" }>, align 8
@.d189 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d190 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"-foptimization-record-file=" }>, align 8
@.d191 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d192 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d193 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d194 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d195 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d196 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"/u" }>, align 8
@.d197 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d198 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/made" }>, align 8
@.d199 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d200 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".race" }>, align 8
@.d201 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d202 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".debug" }>, align 8
@.d203 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d204 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".quick" }>, align 8
@.d205 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d206 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".san" }>, align 8
@.d207 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d208 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".lib" }>, align 8
@.d209 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d210 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d211 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".fuzz" }>, align 8
@.d212 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d213 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".prof" }>, align 8
@.d214 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d215 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".listing" }>, align 8
@.d216 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d217 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"[" }>, align 8
@.d218 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"m" }>, align 8
@.d219 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"[0m" }>, align 8
@.d220 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": semantic errors, skipping" }>, align 8
@.d221 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d222 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": cannot be built, skipping" }>, align 8
@.d223 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d224 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d225 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d226 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d227 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d228 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d229 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d230 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d231 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"olang_" }>, align 8
@.d232 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d233 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c".tmp.ll" }>, align 8
@.d234 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d235 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d236 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".tmp" }>, align 8
@.d237 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-c" }>, align 8
@.d238 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"-o" }>, align 8
@.d239 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"-foptimization-record-file=" }>, align 8
@.d240 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d241 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d242 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare i64 @sysconf(i32)
@.d243 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"a" }>, align 8
@.d244 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 -128] }>, align 8
@.d245 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] [i8 0] }>, align 8
@.d246 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".lock" }>, align 8
@.d247 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d248 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d249 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"N" }>, align 8
@.d250 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"41" }>, align 8
@.d251 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c"attributes #0 = { nounwind " }>, align 8
@.d252 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" }\0A" }>, align 8
@.d253 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c"target triple = \22" }>, align 8
@.d254 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"\22\0A" }>, align 8
@.d255 = private constant <{ i64, [35 x i8] }> <{ i64 0, [35 x i8] c"define i32 @lib_n() #0 {\0A  ret i32 " }>, align 8
@.d256 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d257 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"lib" }>, align 8
@.d258 = private constant <{ i64, [36 x i8] }> <{ i64 0, [36 x i8] c"define i32 @util_k() #0 {\0A  ret i32 " }>, align 8
@.d259 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"\0A}\0A" }>, align 8
@.d260 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"util" }>, align 8
@.d261 = private constant <{ i64, [90 x i8] }> <{ i64 0, [90 x i8] c"declare i32 @lib_n()\0Adeclare i32 @util_k()\0Adeclare i32 @inst_z()\0Adeclare void @olang_rt()\0A" }>, align 8
@.d262 = private constant <{ i64, [73 x i8] }> <{ i64 0, [73 x i8] c"define i32 @main() #0 {\0A  call void @olang_rt()\0A  %a = call i32 @lib_n()\0A" }>, align 8
@.d263 = private constant <{ i64, [96 x i8] }> <{ i64 0, [96 x i8] c"  %b = call i32 @util_k()\0A  %c = call i32 @inst_z()\0A  %s = add i32 %a, %b\0A  %t = add i32 %s, %c\0A" }>, align 8
@.d264 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"  ret i32 %t\0A}\0A" }>, align 8
@.d265 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@.d266 = private constant <{ i64, [40 x i8] }> <{ i64 0, [40 x i8] c"define i32 @inst_z() #0 {\0A  ret i32 0\0A}\0A" }>, align 8
@.d267 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"app" }>, align 8
@.d268 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c"define void @olang_rt() #0 {\0A  ret void\0A}\0A" }>, align 8
@.d269 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"fn " }>, align 8
@.d270 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"()\0A" }>, align 8
@.d271 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d272 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d273 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"/pid" }>, align 8
@.d274 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d275 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"/proc/" }>, align 8
@.d276 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d277 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".main" }>, align 8
@.d278 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".test" }>, align 8
@.d279 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".inst" }>, align 8
@.d280 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".loc" }>, align 8
@.d281 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c" " }>, align 8
@.d282 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define internal i1 @olang_lambda_283(ptr %env, ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l7 = alloca i1
  %l13 = alloca i1
  %l16 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t1, 0
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 0
  %t9 = icmp slt i64 %t3, %t6
  br i1 %t9, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb7
bb2:
  %t11 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t14, 0
  %t19 = icmp eq i64 %t13, %t16
  br i1 %t19, label %bb3, label %bb4
bb3:
  %t21 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t25 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %t21, { i64, ptr } %t22)
  store i1 %t25, ptr %l16
  br label %bb5
bb4:
  store i1 false, ptr %l13, !tbaa !21
  br label %bb6
bb5:
  %t26 = load i1, ptr %l16, !tbaa !21
  store i1 %t26, ptr %l13, !tbaa !21
  br label %bb6
bb6:
  %t27 = load i1, ptr %l13, !tbaa !21
  store i1 %t27, ptr %l7, !tbaa !21
  br label %bb7
bb7:
  %t28 = load i1, ptr %l7, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d284 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d285 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d286 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"made" }>, align 8
@.d287 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".yaml" }>, align 8
@.d288 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c".in.ll" }>, align 8
@.d289 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ll" }>, align 8
@.d290 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d291 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"/made" }>, align 8
@.d292 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d293 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d294 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d295 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"'" }>, align 8
@.d296 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d297 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d298 = private constant <{ i64, [17 x i8] }> <{ i64 0, [17 x i8] c" - did you mean '" }>, align 8
@.d299 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"'?" }>, align 8
@.d300 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d301 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c", " }>, align 8
@.d302 = private constant <{ i64, [22 x i8] }> <{ i64 0, [22 x i8] c": no test is named by " }>, align 8
@.d303 = private constant <{ i64, [11 x i8] }> <{ i64 0, [11 x i8] c"cannot run " }>, align 8
@.d304 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d305 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"build" }>, align 8
@.d306 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d307 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d308 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d309 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d310 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d311 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d312 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d313 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d314 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d315 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d316 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d317 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
@__olang_self = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H858b244a7d569c0419567613de7e1b7d(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEndsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_807a392292b9ae5a_fba630df00719f06 = external constant [0 x i8]
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLetter(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i64 @std_2ftime_2eNow()
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fos_2eExit(i32 %a0)
@olang_loc_1a0af222d89a1264_6ae848cde6020298 = external constant [0 x i8]
@olang_loc_cca858d13f2cc89a_874b1ca570aaca06 = external constant [0 x i8]
@olang_loc_2b4b55182e30c5b8_1dd1254afca8c384 = external constant [0 x i8]
@olang_loc_3fd1be9bff2cc025_306b5f0bb3e84491 = external constant [0 x i8]
@olang_loc_bc625dc042a99e06_c0b5fdead4ea6272 = external constant [0 x i8]
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_2c_20_3f_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare void @std_2fchan_3aChan_3cI64_3e_2ector(ptr %out, ptr %v0, i64 %a0)
declare void @std_2fchan_2eInit_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fchan_2eSend_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_1359a9f97975288c_a8d4abcb606172b0 = external constant [0 x i8]
declare void @std_2fchan_2eClose_3cI64_3e(ptr %v0, ptr %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_84eba90bdad5d702_427cd4b75eaf1c36 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H5dd47b74e50a5f91c0bc89c15be27e45(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H835e186358a312b102cd15b4faa0b451(ptr %v0, ptr %v1, ptr %a0)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2eJoin(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemoveAll(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare i64 @compiler_2fmsgs_2eDistance(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_7d17f382592ac8ef_3cd22268ed245003 = external constant [0 x i8]
declare { i64, ptr } @compiler_2ftarget_2eSysroot(ptr %v0)
declare i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eContains_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_4cf283899a273ea5_54dbe84ebef87a69 = external constant [0 x i8]
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eLen_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %a0)
declare %"compiler/build:Unit" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2eAt_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_ed85b58552229ad2_db88a25435ad515e = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_39c6cdce0ac4fdc7_621aa1b204fc2693 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eClangFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare { i32, %"std/os:Output" } @compiler_2ftarget_2eClangSays(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H2ab12f44ffbd18d099d1f5a69642975a(ptr %v0, ptr %a0)
declare i32 @std_2fos_2eRename(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_3ba7d2bc4f70132e_88e22ea564bfc3e2 = external constant [0 x i8]
declare i32 @std_2fos_2eLink(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aChar_3e_2eReplace_3cstd_2fprelude_2ftext_3aChar_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare { i64, ptr } @std_2ffilepath_2eDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eJoin(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare %"std/os:Output" @std_2fos_3aOutput_2ector(ptr %v0, ptr %v1, ptr %v2, i32 %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cI64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @compiler_2ftarget_2ecompiler_2ftarget_3aTarget_2eRunner(ptr %v0, ptr %v1, ptr %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eTargetNoEmulator(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H0127831368543eff3b7740d7d3240080(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@olang_loc_81dfa638548de3d7_ab0731b6a5acba3 = external constant [0 x i8]
@olang_loc_64cef890f5e30dfa_ab05d47f854753c6 = external constant [0 x i8]
@olang_loc_adf83e678ec27f19_e5a5f2a4f92e5ce5 = external constant [0 x i8]
@olang_loc_d790d12bf07ae06c_96ebe5e6b28bd688 = external constant [0 x i8]
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNoClang(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_3aRadix_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @std_2fprelude_2ftext_2eU32_2eFormat(ptr %v0, i32 %a0, i64 %a1)
@olang_loc_8179dc362f2d1bfc_fef952a35fe3ad58 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2ePadStart(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i8 %a2)
declare i32 @std_2fos_2eMkDir(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eHas(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eRaw(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ePush_3ccompiler_2fbuild_3aUnit_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Unit" %a1)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2ftime_2eWall()
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_7cb1cbeb873878be_a9deaf72b78184ba = external constant [0 x i8]
@olang_loc_46572e8a3ed1f877_752b2fa47e3744e3 = external constant [0 x i8]
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H1642129570dad448bb7dcc47c334de83(ptr %v0, ptr %v1, ptr %a0, ptr %a1c, ptr %a1e)
declare i1 @compiler_2fmsgs_2eNear(ptr %v0, { i64, ptr } %a0, i64 %a1)
declare { i32, i64 } @std_2fchan_2estd_2fchan_3aChan_3cI64_3e_2eNext_3cI64_3e(ptr %v0, ptr %a0)
declare i32 @std_2fio_2ePrint(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintErr(ptr %v0, { i64, ptr } %a0)
declare i32 @std_2fio_2ePrintln(ptr %v0, { i64, ptr } %a0)
declare %"compiler/target:Target" @compiler_2ftarget_3aTarget_2ector(ptr %v0)
declare void @compiler_2fcond_3aConsts_2ector(ptr %out, ptr %v0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aUnit_3e_2ector(ptr %v0, i64 %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2ector(ptr %v0, i64 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eLess(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
