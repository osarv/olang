; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

@olang_loc_20dc38f747c9f0af_bc7597226811d3db = weak_odr constant [54 x i8] c"std/prelude/vec.olang:283: array length out of range\0A\00"
@olang_loc_572d6a725e3d8da_ac8d4b5fe6d55046 = weak_odr constant [54 x i8] c"std/prelude/vec.olang:282: array length out of range\0A\00"
