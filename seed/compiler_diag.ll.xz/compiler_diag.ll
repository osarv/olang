; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"std/prelude/text:StringBuilder" = type { %"std/prelude/list:List<std/prelude/text:Char>" }
%"std/prelude/list:List<std/prelude/text:Char>" = type { ptr }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<std/prelude/text:String&>", %"std/prelude/list:List<Bool>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/diag:record>", %"std/prelude/list:List<compiler/diag:note>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<I64>", %"std/prelude/list:List<compiler/diag:context>", i64, i1, i1, { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"std/prelude/list:List<std/prelude/text:String&>" = type { ptr }
%"std/prelude/list:List<Bool>" = type { ptr }
%"std/prelude/list:List<I64>" = type { ptr }
%"std/prelude/list:List<compiler/diag:record>" = type { ptr }
%"std/prelude/list:List<compiler/diag:note>" = type { ptr }
%"std/prelude/list:List<compiler/diag:context>" = type { ptr }
%"std/prelude/list:List<compiler/diag:Said>" = type { ptr }
%"compiler/diag:record" = type { { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i32, i64, i1 }
%"compiler/diag:Said" = type { { i64, ptr }, i64, i64, { i64, ptr } }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diag:note" = type { i64, { i64, [3 x i64] }, { i64, ptr } }
%"compiler/diag:context" = type { { i64, [3 x i64] }, { i64, ptr } }
@G_2ecompiler_2fdiag_2eChosen = global i64 zeroinitializer
@G_2ecompiler_2fdiag_2eCut = global i64 zeroinitializer
@G_2ecompiler_2fdiag_2eDropped = global i64 zeroinitializer
@G_2ecompiler_2fdiag_2eExcerptAround = global i64 zeroinitializer
@G_2ecompiler_2fdiag_2eExcerptMax = global i64 zeroinitializer
@G_2ecompiler_2fdiag_2ePending = global i64 zeroinitializer
define dso_local void @compiler_2fdiag_2eChosen_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 1, ptr @G_2ecompiler_2fdiag_2eChosen, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i1 @compiler_2fdiag_2eColorWanted() #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i1
  %l2 = alloca i1
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i32
  %l6 = alloca i1
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @std_2fos_2eIsTerminal(i32 1)
  store i1 %t1, ptr %l0
  br label %bb1
bb1:
  %t2 = load i1, ptr %l0, !tbaa !21
  %t3 = xor i1 %t2, true
  store i1 %t3, ptr %l1, !tbaa !21
  %t4 = load i1, ptr %l1, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l2, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t5 = load i1, ptr %l2, !tbaa !21
  store i1 %t5, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t6 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 8, ptr @.d0 })
  %t7 = extractvalue { i32, { i64, ptr } } %t6, 1
  %t8 = extractvalue { i32, { i64, ptr } } %t6, 0
  store i32 %t8, ptr %l5
  %t9 = icmp ne i32 %t8, 0
  br i1 %t9, label %bb6, label %ok.10
ok.10:
  store { i64, ptr } %t7, ptr %l4
  br label %bb5
bb5:
  %t11 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t11, ptr %l3, !tbaa !27
  br label %bb9
bb6:
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t12 = call i1 @compiler_2fdiag_2etermAllowsColor()
  store i1 %t12, ptr %l6
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t13 = load i1, ptr %l6, !tbaa !21
  store i1 %t13, ptr %rv
  br label %ret
bb9:
  store i1 false, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fdiag_2eCut_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 3, ptr @G_2ecompiler_2fdiag_2eCut, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2eDropped_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 2, ptr @G_2ecompiler_2fdiag_2eDropped, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2eExcerptAround_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 70, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2eExcerptMax_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 160, ptr @G_2ecompiler_2fdiag_2eExcerptMax, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i32, { i64, ptr } } @compiler_2fdiag_2eExplain(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i8
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/text:StringBuilder"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i64
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca %"std/prelude/text:StringBuilder"
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i8
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca i1
  %l35 = alloca i8
  %l36 = alloca i8
  %l37 = alloca i8
  %l38 = alloca i8
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"std/prelude/text:StringBuilder"
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i1
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i1
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca i8
  %l66 = alloca i64
  %l67 = alloca i32
  %l68 = alloca { i64, ptr }
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i1
  %l76 = alloca i1
  %l77 = alloca i1
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i1
  %l87 = alloca i1
  %l88 = alloca i1
  %l89 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i8
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca i1
  %l97 = alloca { i64, ptr }
  %l98 = alloca i64
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca i1
  %l102 = alloca i1
  %l103 = alloca { i64, ptr }
  %l104 = alloca i1
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l109 = alloca i1
  %l110 = alloca i64
  %l111 = alloca { i64, ptr }
  %l112 = alloca i64
  %l113 = alloca i1
  %l114 = alloca i1
  %l115 = alloca { i64, ptr }
  %l116 = alloca i64
  %l117 = alloca i8
  %l118 = alloca i1
  %l119 = alloca i1
  %l120 = alloca { i64, ptr }
  %l121 = alloca i64
  %l122 = alloca i8
  %l123 = alloca i1
  %l124 = alloca i1
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca i1
  %l130 = alloca i64
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l133 = alloca i1
  %l134 = alloca i1
  %l135 = alloca { i64, ptr }
  %l136 = alloca i64
  %l137 = alloca i8
  %l138 = alloca i1
  %l139 = alloca ptr
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l144 = alloca i64
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l148 = alloca i64
  %l149 = alloca i1
  %l150 = alloca i1
  %l151 = alloca i1
  %l152 = alloca { i64, ptr }
  %l153 = alloca ptr
  %l154 = alloca i1
  %l155 = alloca i1
  %l156 = alloca { i64, ptr }
  %l157 = alloca i1
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i64
  %l161 = alloca i1
  %l162 = alloca i1
  %l163 = alloca ptr
  %l164 = alloca i64
  %l165 = alloca i64
  %l166 = alloca ptr
  %l167 = alloca { i64, ptr }
  %l168 = alloca i1
  %l169 = alloca i1
  %l170 = alloca i32
  %l171 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca i64
  %l175 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l20
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l20
  store %"std/prelude/text:StringBuilder" %t2, ptr %l2
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l21, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l21, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  store i64 0, ptr %l4, !tbaa !24
  %t5 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t5, ptr %l22, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  store i64 %t7, ptr %l23, !tbaa !24
  %t8 = load i64, ptr %l23, !tbaa !24
  store i64 %t8, ptr %l5, !tbaa !24
  br label %bb2
bb2:
  store %olang.scope zeroinitializer, ptr %s2
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l24, !tbaa !24
  %t10 = load i64, ptr %l5, !tbaa !24
  store i64 %t10, ptr %l25, !tbaa !24
  %t11 = load i64, ptr %l24, !tbaa !24
  %t12 = load i64, ptr %l25, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l26, !tbaa !21
  %t14 = load i1, ptr %l26, !tbaa !21
  %t15 = xor i1 %t14, true
  store i1 %t15, ptr %l27, !tbaa !21
  %t16 = load i1, ptr %l27, !tbaa !21
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_scope_close(ptr %s2)
  br label %bb12
bb4:
  br label %bb5
bb5:
  %t17 = load i64, ptr %l4, !tbaa !24
  store i64 %t17, ptr %l28, !tbaa !24
  %t18 = load i64, ptr %l28, !tbaa !24
  store i64 %t18, ptr %l6, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l29, !tbaa !27
  %t20 = load i64, ptr %l4, !tbaa !24
  store i64 %t20, ptr %l30, !tbaa !24
  %t21 = load i64, ptr %l30, !tbaa !24
  %t22 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t23 = load ptr, ptr %t22, !tbaa !27
  %t24 = getelementptr i8, ptr %t23, i64 %t21
  %t25 = load i8, ptr %t24, !tbaa !32
  store i8 %t25, ptr %l31, !tbaa !22
  %t26 = load i8, ptr %l31, !tbaa !22
  store i8 %t26, ptr %l7, !tbaa !22
  store ptr %l2, ptr %l32, !tbaa !29
  %t27 = load i64, ptr %l6, !tbaa !24
  store i64 %t27, ptr %l33, !tbaa !24
  %t28 = load i64, ptr %l33, !tbaa !24
  %t29 = icmp eq i64 %t28, 0
  store i1 %t29, ptr %l34, !tbaa !21
  %t30 = load i1, ptr %l34, !tbaa !21
  br i1 %t30, label %bb6, label %bb7
bb6:
  %t31 = load i8, ptr %l7, !tbaa !22
  store i8 %t31, ptr %l36, !tbaa !22
  %t32 = load i8, ptr %l36, !tbaa !22
  %t33 = call i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %t32)
  store i8 %t33, ptr %l37
  br label %bb8
bb7:
  %t34 = load i8, ptr %l7, !tbaa !22
  store i8 %t34, ptr %l38, !tbaa !22
  %t35 = load i8, ptr %l38, !tbaa !22
  store i8 %t35, ptr %l35, !tbaa !22
  br label %bb9
bb8:
  %t36 = load i8, ptr %l37, !tbaa !22
  store i8 %t36, ptr %l35, !tbaa !22
  br label %bb9
bb9:
  %t37 = load ptr, ptr %l32, !tbaa !29
  %t38 = load i8, ptr %l35, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t37, i8 %t38)
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  br label %bb11
bb11:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l4, !tbaa !24
  store i64 %t39, ptr %l39, !tbaa !24
  %t40 = load i64, ptr %l39, !tbaa !24
  %t41 = add i64 %t40, 1
  store i64 %t41, ptr %l40, !tbaa !24
  %t42 = load i64, ptr %l40, !tbaa !24
  store i64 %t42, ptr %l4, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb2
bb12:
  call void @__olang_scope_close(ptr %s1)
  store ptr %l2, ptr %l41, !tbaa !29
  %t43 = load ptr, ptr %l41, !tbaa !29
  %t44 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %s0, ptr %t43)
  store { i64, ptr } %t44, ptr %l42
  br label %bb13
bb13:
  %t45 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t45, ptr %l8, !tbaa !27
  %t46 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t46, ptr %l43
  br label %bb14
bb14:
  %t47 = load %"std/prelude/text:StringBuilder", ptr %l43
  store %"std/prelude/text:StringBuilder" %t47, ptr %l9
  %t48 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t48, ptr %l44, !tbaa !27
  %t49 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  store i64 %t50, ptr %l45, !tbaa !24
  %t51 = icmp sge i64 0, 0
  store i1 %t51, ptr %l46, !tbaa !21
  %t52 = load i1, ptr %l46, !tbaa !21
  br i1 %t52, label %bb15, label %bb16
bb15:
  %t53 = icmp sle i64 0, 0
  store i1 %t53, ptr %l47, !tbaa !21
  %t54 = load i1, ptr %l47, !tbaa !21
  br i1 %t54, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb17:
  %t55 = load i64, ptr %l45, !tbaa !24
  %t56 = icmp sle i64 0, %t55
  store i1 %t56, ptr %l48, !tbaa !21
  %t57 = load i1, ptr %l48, !tbaa !21
  br i1 %t57, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb19:
  %t58 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr i8, ptr %t59, i64 0
  %t61 = sub i64 0, 0
  %t62 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t63 = insertvalue { i64, ptr } %t62, ptr %t60, 1
  store { i64, ptr } %t63, ptr %l49, !tbaa !27
  %t64 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t64, ptr %l10, !tbaa !27
  store i1 false, ptr %l11, !tbaa !21
  store i1 false, ptr %l12, !tbaa !21
  store i64 0, ptr %l13, !tbaa !24
  %t65 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t65, ptr %l50, !tbaa !27
  %t66 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t66, ptr %l51, !tbaa !27
  %t67 = load { i64, ptr }, ptr %l51, !tbaa !27
  store { i64, ptr } %t67, ptr %l52, !tbaa !27
  %t68 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  store i64 %t69, ptr %l53, !tbaa !24
  %t70 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t71 = extractvalue { i64, ptr } %t70, 0
  store i64 %t71, ptr %l54, !tbaa !24
  %t72 = icmp sge i64 0, 0
  store i1 %t72, ptr %l55, !tbaa !21
  %t73 = load i1, ptr %l55, !tbaa !21
  br i1 %t73, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @.c1)
  unreachable
bb21:
  %t74 = load i64, ptr %l53, !tbaa !24
  %t75 = icmp sle i64 0, %t74
  store i1 %t75, ptr %l56, !tbaa !21
  %t76 = load i1, ptr %l56, !tbaa !21
  br i1 %t76, label %bb23, label %bb24
bb22:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb23:
  %t77 = load i64, ptr %l53, !tbaa !24
  %t78 = load i64, ptr %l54, !tbaa !24
  %t79 = icmp sle i64 %t77, %t78
  store i1 %t79, ptr %l57, !tbaa !21
  %t80 = load i1, ptr %l57, !tbaa !21
  br i1 %t80, label %bb25, label %bb26
bb24:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb25:
  %t81 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t82 = load ptr, ptr %t81, !tbaa !27
  %t83 = load i64, ptr %l53, !tbaa !24
  %t84 = getelementptr i8, ptr %t82, i64 0
  %t85 = sub i64 %t83, 0
  %t86 = insertvalue { i64, ptr } undef, i64 %t85, 0
  %t87 = insertvalue { i64, ptr } %t86, ptr %t84, 1
  store { i64, ptr } %t87, ptr %l58, !tbaa !27
  %t88 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t88, ptr %l14, !tbaa !27
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c2)
  unreachable
bb27:
  store %olang.scope zeroinitializer, ptr %s4
  %t89 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t89, ptr %l59, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l60, !tbaa !24
  %t92 = load i64, ptr %l60, !tbaa !24
  %t93 = icmp sgt i64 %t92, 0
  store i1 %t93, ptr %l61, !tbaa !21
  %t94 = load i1, ptr %l61, !tbaa !21
  %t95 = xor i1 %t94, true
  store i1 %t95, ptr %l62, !tbaa !21
  %t96 = load i1, ptr %l62, !tbaa !21
  br i1 %t96, label %bb28, label %bb29
bb28:
  call void @__olang_scope_close(ptr %s4)
  br label %bb115
bb29:
  br label %bb30
bb30:
  %t97 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t97, ptr %l64, !tbaa !27
  store i8 10, ptr %l65, !tbaa !22
  %t98 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t99 = load i8, ptr %l65, !tbaa !22
  %t100 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %t98, i8 %t99)
  %t101 = extractvalue { i32, i64 } %t100, 1
  %t102 = extractvalue { i32, i64 } %t100, 0
  store i32 %t102, ptr %l67
  %t103 = icmp ne i32 %t102, 0
  br i1 %t103, label %bb32, label %ok.104
ok.104:
  store i64 %t101, ptr %l66
  br label %bb31
bb31:
  %t105 = load i64, ptr %l66, !tbaa !24
  store i64 %t105, ptr %l63, !tbaa !24
  br label %bb34
bb32:
  br label %bb33
bb33:
  %t106 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t106, ptr %l68, !tbaa !27
  %t107 = load { i64, ptr }, ptr %l68, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t107, 0
  store i64 %t108, ptr %l69, !tbaa !24
  %t109 = load i64, ptr %l69, !tbaa !24
  %t110 = sub i64 %t109, 1
  store i64 %t110, ptr %l70, !tbaa !24
  %t111 = load i64, ptr %l70, !tbaa !24
  store i64 %t111, ptr %l63, !tbaa !24
  br label %bb34
bb34:
  %t112 = load i64, ptr %l63, !tbaa !24
  store i64 %t112, ptr %l15, !tbaa !24
  %t113 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t113, ptr %l71, !tbaa !27
  %t114 = load i64, ptr %l15, !tbaa !24
  store i64 %t114, ptr %l72, !tbaa !24
  %t115 = load i64, ptr %l72, !tbaa !24
  %t116 = add i64 %t115, 1
  store i64 %t116, ptr %l73, !tbaa !24
  %t117 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t117, 0
  store i64 %t118, ptr %l74, !tbaa !24
  %t119 = icmp sge i64 0, 0
  store i1 %t119, ptr %l75, !tbaa !21
  %t120 = load i1, ptr %l75, !tbaa !21
  br i1 %t120, label %bb35, label %bb36
bb35:
  %t121 = load i64, ptr %l73, !tbaa !24
  %t122 = icmp sle i64 0, %t121
  store i1 %t122, ptr %l76, !tbaa !21
  %t123 = load i1, ptr %l76, !tbaa !21
  br i1 %t123, label %bb37, label %bb38
bb36:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb37:
  %t124 = load i64, ptr %l73, !tbaa !24
  %t125 = load i64, ptr %l74, !tbaa !24
  %t126 = icmp sle i64 %t124, %t125
  store i1 %t126, ptr %l77, !tbaa !21
  %t127 = load i1, ptr %l77, !tbaa !21
  br i1 %t127, label %bb39, label %bb40
bb38:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb39:
  %t128 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t129 = load ptr, ptr %t128, !tbaa !27
  %t130 = load i64, ptr %l73, !tbaa !24
  %t131 = getelementptr i8, ptr %t129, i64 0
  %t132 = sub i64 %t130, 0
  %t133 = insertvalue { i64, ptr } undef, i64 %t132, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t131, 1
  store { i64, ptr } %t134, ptr %l78, !tbaa !27
  %t135 = load { i64, ptr }, ptr %l78, !tbaa !27
  store { i64, ptr } %t135, ptr %l16, !tbaa !27
  %t136 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t136, ptr %l79, !tbaa !27
  %t137 = load i64, ptr %l15, !tbaa !24
  store i64 %t137, ptr %l80, !tbaa !24
  %t138 = load i64, ptr %l80, !tbaa !24
  %t139 = add i64 %t138, 1
  store i64 %t139, ptr %l81, !tbaa !24
  %t140 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t140, ptr %l82, !tbaa !27
  %t141 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t141, ptr %l83, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 0
  store i64 %t143, ptr %l84, !tbaa !24
  %t144 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 0
  store i64 %t145, ptr %l85, !tbaa !24
  %t146 = load i64, ptr %l81, !tbaa !24
  %t147 = icmp sge i64 %t146, 0
  store i1 %t147, ptr %l86, !tbaa !21
  %t148 = load i1, ptr %l86, !tbaa !21
  br i1 %t148, label %bb41, label %bb42
bb40:
  call void @__olang_check_failed(ptr @.c3)
  unreachable
bb41:
  %t149 = load i64, ptr %l81, !tbaa !24
  %t150 = load i64, ptr %l84, !tbaa !24
  %t151 = icmp sle i64 %t149, %t150
  store i1 %t151, ptr %l87, !tbaa !21
  %t152 = load i1, ptr %l87, !tbaa !21
  br i1 %t152, label %bb43, label %bb44
bb42:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb43:
  %t153 = load i64, ptr %l84, !tbaa !24
  %t154 = load i64, ptr %l85, !tbaa !24
  %t155 = icmp sle i64 %t153, %t154
  store i1 %t155, ptr %l88, !tbaa !21
  %t156 = load i1, ptr %l88, !tbaa !21
  br i1 %t156, label %bb45, label %bb46
bb44:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb45:
  %t157 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t158 = load ptr, ptr %t157, !tbaa !27
  %t159 = load i64, ptr %l81, !tbaa !24
  %t160 = load i64, ptr %l84, !tbaa !24
  %t161 = getelementptr i8, ptr %t158, i64 %t159
  %t162 = sub i64 %t160, %t159
  %t163 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t164 = insertvalue { i64, ptr } %t163, ptr %t161, 1
  store { i64, ptr } %t164, ptr %l89, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l89, !tbaa !27
  store { i64, ptr } %t165, ptr %l14, !tbaa !27
  %t166 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t166, ptr %l90, !tbaa !27
  %t167 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t168 = call { i64, ptr } @compiler_2fdiag_2eruleIdAt(ptr %v0, { i64, ptr } %t167)
  store { i64, ptr } %t168, ptr %l91
  br label %bb47
bb46:
  call void @__olang_check_failed(ptr @.c4)
  unreachable
bb47:
  %t169 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t169, ptr %l17, !tbaa !27
  %t170 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t170, ptr %l92, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l92, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr i8, ptr %t172, i64 0
  %t174 = load i8, ptr %t173, !tbaa !32
  store i8 %t174, ptr %l93, !tbaa !22
  %t175 = load i8, ptr %l93, !tbaa !22
  %t176 = icmp eq i8 %t175, 35
  store i1 %t176, ptr %l94, !tbaa !21
  %t177 = load i1, ptr %l94, !tbaa !21
  store i1 %t177, ptr %l18, !tbaa !21
  %t178 = load i1, ptr %l11, !tbaa !21
  store i1 %t178, ptr %l95, !tbaa !21
  %t179 = load i1, ptr %l95, !tbaa !21
  br i1 %t179, label %bb48, label %bb49
bb48:
  %t180 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t180, ptr %l97, !tbaa !27
  %t181 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  store i64 %t182, ptr %l98, !tbaa !24
  %t183 = load i64, ptr %l98, !tbaa !24
  %t184 = icmp sgt i64 %t183, 0
  store i1 %t184, ptr %l99, !tbaa !21
  %t185 = load i1, ptr %l99, !tbaa !21
  br i1 %t185, label %bb50, label %bb51
bb49:
  store i1 false, ptr %l96, !tbaa !21
  br label %bb53
bb50:
  store i1 true, ptr %l100, !tbaa !21
  br label %bb52
bb51:
  %t186 = load i1, ptr %l18, !tbaa !21
  store i1 %t186, ptr %l101, !tbaa !21
  %t187 = load i1, ptr %l101, !tbaa !21
  store i1 %t187, ptr %l100, !tbaa !21
  br label %bb52
bb52:
  %t188 = load i1, ptr %l100, !tbaa !21
  store i1 %t188, ptr %l96, !tbaa !21
  br label %bb53
bb53:
  %t189 = load i1, ptr %l96, !tbaa !21
  br i1 %t189, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s5
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  br label %bb115
bb55:
  br label %bb56
bb56:
  %t190 = load i1, ptr %l18, !tbaa !21
  store i1 %t190, ptr %l102, !tbaa !21
  %t191 = load i1, ptr %l102, !tbaa !21
  br i1 %t191, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s6
  %t192 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t192, ptr %l103, !tbaa !27
  %t193 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t193, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb58:
  br label %bb59
bb59:
  %t194 = load i1, ptr %l11, !tbaa !21
  store i1 %t194, ptr %l104, !tbaa !21
  %t195 = load i1, ptr %l104, !tbaa !21
  %t196 = xor i1 %t195, true
  store i1 %t196, ptr %l105, !tbaa !21
  %t197 = load i1, ptr %l105, !tbaa !21
  br i1 %t197, label %bb60, label %bb61
bb60:
  %t198 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t198, ptr %l107, !tbaa !27
  %t199 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t199, ptr %l108, !tbaa !27
  %t200 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t201 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t202 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t200, { i64, ptr } %t201)
  store i1 %t202, ptr %l109
  br label %bb62
bb61:
  store i1 false, ptr %l106, !tbaa !21
  br label %bb63
bb62:
  %t203 = load i1, ptr %l109, !tbaa !21
  store i1 %t203, ptr %l106, !tbaa !21
  br label %bb63
bb63:
  %t204 = load i1, ptr %l106, !tbaa !21
  br i1 %t204, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s7
  store i1 true, ptr %l11, !tbaa !21
  store i1 true, ptr %l12, !tbaa !21
  store i64 0, ptr %l19, !tbaa !24
  br label %bb66
bb65:
  br label %bb98
bb66:
  store %olang.scope zeroinitializer, ptr %s8
  %t205 = load i64, ptr %l19, !tbaa !24
  store i64 %t205, ptr %l110, !tbaa !24
  %t206 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t206, ptr %l111, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t207, 0
  store i64 %t208, ptr %l112, !tbaa !24
  %t209 = load i64, ptr %l110, !tbaa !24
  %t210 = load i64, ptr %l112, !tbaa !24
  %t211 = icmp slt i64 %t209, %t210
  store i1 %t211, ptr %l113, !tbaa !21
  %t212 = load i1, ptr %l113, !tbaa !21
  br i1 %t212, label %bb67, label %bb68
bb67:
  %t213 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t213, ptr %l115, !tbaa !27
  %t214 = load i64, ptr %l19, !tbaa !24
  store i64 %t214, ptr %l116, !tbaa !24
  %t215 = load i64, ptr %l116, !tbaa !24
  %t216 = getelementptr { i64, ptr }, ptr %l115, i32 0, i32 1
  %t217 = load ptr, ptr %t216, !tbaa !27
  %t218 = getelementptr i8, ptr %t217, i64 %t215
  %t219 = load i8, ptr %t218, !tbaa !32
  store i8 %t219, ptr %l117, !tbaa !22
  %t220 = load i8, ptr %l117, !tbaa !22
  %t221 = icmp eq i8 %t220, 35
  store i1 %t221, ptr %l118, !tbaa !21
  %t222 = load i1, ptr %l118, !tbaa !21
  br i1 %t222, label %bb69, label %bb70
bb68:
  store i1 false, ptr %l114, !tbaa !21
  br label %bb72
bb69:
  store i1 true, ptr %l119, !tbaa !21
  br label %bb71
bb70:
  %t223 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t223, ptr %l120, !tbaa !27
  %t224 = load i64, ptr %l19, !tbaa !24
  store i64 %t224, ptr %l121, !tbaa !24
  %t225 = load i64, ptr %l121, !tbaa !24
  %t226 = getelementptr { i64, ptr }, ptr %l120, i32 0, i32 1
  %t227 = load ptr, ptr %t226, !tbaa !27
  %t228 = getelementptr i8, ptr %t227, i64 %t225
  %t229 = load i8, ptr %t228, !tbaa !32
  store i8 %t229, ptr %l122, !tbaa !22
  %t230 = load i8, ptr %l122, !tbaa !22
  %t231 = icmp eq i8 %t230, 32
  store i1 %t231, ptr %l123, !tbaa !21
  %t232 = load i1, ptr %l123, !tbaa !21
  store i1 %t232, ptr %l119, !tbaa !21
  br label %bb71
bb71:
  %t233 = load i1, ptr %l119, !tbaa !21
  store i1 %t233, ptr %l114, !tbaa !21
  br label %bb72
bb72:
  %t234 = load i1, ptr %l114, !tbaa !21
  %t235 = xor i1 %t234, true
  store i1 %t235, ptr %l124, !tbaa !21
  %t236 = load i1, ptr %l124, !tbaa !21
  br i1 %t236, label %bb73, label %bb74
bb73:
  call void @__olang_scope_close(ptr %s8)
  br label %bb77
bb74:
  br label %bb75
bb75:
  %t237 = load i64, ptr %l19, !tbaa !24
  store i64 %t237, ptr %l125, !tbaa !24
  %t238 = load i64, ptr %l125, !tbaa !24
  %t239 = add i64 %t238, 1
  store i64 %t239, ptr %l126, !tbaa !24
  %t240 = load i64, ptr %l126, !tbaa !24
  store i64 %t240, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb76
bb76:
  br label %bb66
bb77:
  %t241 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t241, ptr %l127, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l128, !tbaa !24
  %t244 = load i64, ptr %l128, !tbaa !24
  %t245 = icmp sgt i64 %t244, 0
  store i1 %t245, ptr %l129, !tbaa !21
  %t246 = load i1, ptr %l129, !tbaa !21
  br i1 %t246, label %bb78, label %bb79
bb78:
  store %olang.scope zeroinitializer, ptr %s9
  %t247 = load i64, ptr %l19, !tbaa !24
  store i64 %t247, ptr %l130, !tbaa !24
  %t248 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t248, ptr %l131, !tbaa !27
  %t249 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t250 = extractvalue { i64, ptr } %t249, 0
  store i64 %t250, ptr %l132, !tbaa !24
  %t251 = load i64, ptr %l130, !tbaa !24
  %t252 = load i64, ptr %l132, !tbaa !24
  %t253 = icmp slt i64 %t251, %t252
  store i1 %t253, ptr %l133, !tbaa !21
  %t254 = load i1, ptr %l133, !tbaa !21
  br i1 %t254, label %bb80, label %bb81
bb79:
  br label %bb97
bb80:
  %t255 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t255, ptr %l135, !tbaa !27
  %t256 = load i64, ptr %l19, !tbaa !24
  store i64 %t256, ptr %l136, !tbaa !24
  %t257 = load i64, ptr %l136, !tbaa !24
  %t258 = getelementptr { i64, ptr }, ptr %l135, i32 0, i32 1
  %t259 = load ptr, ptr %t258, !tbaa !27
  %t260 = getelementptr i8, ptr %t259, i64 %t257
  %t261 = load i8, ptr %t260, !tbaa !32
  store i8 %t261, ptr %l137, !tbaa !22
  %t262 = load i8, ptr %l137, !tbaa !22
  %t263 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t262)
  store i1 %t263, ptr %l138
  br label %bb82
bb81:
  store i1 false, ptr %l134, !tbaa !21
  br label %bb83
bb82:
  %t264 = load i1, ptr %l138, !tbaa !21
  store i1 %t264, ptr %l134, !tbaa !21
  br label %bb83
bb83:
  %t265 = load i1, ptr %l134, !tbaa !21
  br i1 %t265, label %bb84, label %bb85
bb84:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l9, ptr %l139, !tbaa !29
  %t266 = call { i64, ptr } @compiler_2fdiag_2esection(ptr %s10)
  store { i64, ptr } %t266, ptr %l140
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t267 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t267, 0
  %t269 = extractvalue { i64, ptr } %t267, 1
  %t270 = mul i64 %t268, 1
  %t271 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t270)
  call void @llvm.memcpy.p0.p0.i64(ptr %t271, ptr %t269, i64 %t270, i1 false)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  store { i64, ptr } %t273, ptr %l141, !tbaa !27
  %t274 = load ptr, ptr %l139, !tbaa !29
  %t275 = load { i64, ptr }, ptr %l141, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s10, ptr %t274, { i64, ptr } %t275)
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s10)
  br label %bb88
bb88:
  store ptr %l9, ptr %l142, !tbaa !29
  %t276 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t276, ptr %l143, !tbaa !27
  %t277 = load i64, ptr %l19, !tbaa !24
  store i64 %t277, ptr %l144, !tbaa !24
  %t278 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t278, ptr %l145, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t279, ptr %l146, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t281 = extractvalue { i64, ptr } %t280, 0
  store i64 %t281, ptr %l147, !tbaa !24
  %t282 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t283 = extractvalue { i64, ptr } %t282, 0
  store i64 %t283, ptr %l148, !tbaa !24
  %t284 = load i64, ptr %l144, !tbaa !24
  %t285 = icmp sge i64 %t284, 0
  store i1 %t285, ptr %l149, !tbaa !21
  %t286 = load i1, ptr %l149, !tbaa !21
  br i1 %t286, label %bb89, label %bb90
bb89:
  %t287 = load i64, ptr %l144, !tbaa !24
  %t288 = load i64, ptr %l147, !tbaa !24
  %t289 = icmp sle i64 %t287, %t288
  store i1 %t289, ptr %l150, !tbaa !21
  %t290 = load i1, ptr %l150, !tbaa !21
  br i1 %t290, label %bb91, label %bb92
bb90:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb91:
  %t291 = load i64, ptr %l147, !tbaa !24
  %t292 = load i64, ptr %l148, !tbaa !24
  %t293 = icmp sle i64 %t291, %t292
  store i1 %t293, ptr %l151, !tbaa !21
  %t294 = load i1, ptr %l151, !tbaa !21
  br i1 %t294, label %bb93, label %bb94
bb92:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb93:
  %t295 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t296 = load ptr, ptr %t295, !tbaa !27
  %t297 = load i64, ptr %l144, !tbaa !24
  %t298 = load i64, ptr %l147, !tbaa !24
  %t299 = getelementptr i8, ptr %t296, i64 %t297
  %t300 = sub i64 %t298, %t297
  %t301 = insertvalue { i64, ptr } undef, i64 %t300, 0
  %t302 = insertvalue { i64, ptr } %t301, ptr %t299, 1
  store { i64, ptr } %t302, ptr %l152, !tbaa !27
  %t303 = load ptr, ptr %l142, !tbaa !29
  %t304 = load { i64, ptr }, ptr %l152, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t303, { i64, ptr } %t304)
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @.c5)
  unreachable
bb95:
  store ptr %l9, ptr %l153, !tbaa !29
  %t305 = load ptr, ptr %l153, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t305, i8 10)
  br label %bb96
bb96:
  call void @__olang_scope_close(ptr %s9)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s7)
  br label %bb98
bb98:
  %t306 = load i1, ptr %l11, !tbaa !21
  store i1 %t306, ptr %l154, !tbaa !21
  %t307 = load i1, ptr %l154, !tbaa !21
  %t308 = xor i1 %t307, true
  store i1 %t308, ptr %l155, !tbaa !21
  %t309 = load i1, ptr %l155, !tbaa !21
  br i1 %t309, label %bb99, label %bb100
bb99:
  store %olang.scope zeroinitializer, ptr %s11
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb100:
  br label %bb101
bb101:
  %t310 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t310, ptr %l156, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t312 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s4, { i64, ptr } %t311, { i64, ptr } { i64 1, ptr @.d6 })
  store i1 %t312, ptr %l157
  br label %bb102
bb102:
  %t313 = load i1, ptr %l157, !tbaa !21
  br i1 %t313, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s12
  %t314 = load i64, ptr %l13, !tbaa !24
  store i64 %t314, ptr %l158, !tbaa !24
  %t315 = load i64, ptr %l158, !tbaa !24
  %t316 = add i64 %t315, 1
  store i64 %t316, ptr %l159, !tbaa !24
  %t317 = load i64, ptr %l159, !tbaa !24
  store i64 %t317, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb104:
  br label %bb105
bb105:
  br label %bb106
bb106:
  store %olang.scope zeroinitializer, ptr %s13
  %t318 = load i64, ptr %l13, !tbaa !24
  store i64 %t318, ptr %l160, !tbaa !24
  %t319 = load i64, ptr %l160, !tbaa !24
  %t320 = icmp sgt i64 %t319, 0
  store i1 %t320, ptr %l161, !tbaa !21
  %t321 = load i1, ptr %l161, !tbaa !21
  %t322 = xor i1 %t321, true
  store i1 %t322, ptr %l162, !tbaa !21
  %t323 = load i1, ptr %l162, !tbaa !21
  br i1 %t323, label %bb107, label %bb108
bb107:
  call void @__olang_scope_close(ptr %s13)
  br label %bb112
bb108:
  br label %bb109
bb109:
  store ptr %l9, ptr %l163, !tbaa !29
  %t324 = load ptr, ptr %l163, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t324, i8 10)
  br label %bb110
bb110:
  %t325 = load i64, ptr %l13, !tbaa !24
  store i64 %t325, ptr %l164, !tbaa !24
  %t326 = load i64, ptr %l164, !tbaa !24
  %t327 = sub i64 %t326, 1
  store i64 %t327, ptr %l165, !tbaa !24
  %t328 = load i64, ptr %l165, !tbaa !24
  store i64 %t328, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb111
bb111:
  br label %bb106
bb112:
  store ptr %l9, ptr %l166, !tbaa !29
  %t329 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t329, ptr %l167, !tbaa !27
  %t330 = load ptr, ptr %l166, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l167, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t330, { i64, ptr } %t331)
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s4)
  br label %bb114
bb114:
  br label %bb27
bb115:
  %t332 = load i1, ptr %l12, !tbaa !21
  store i1 %t332, ptr %l168, !tbaa !21
  %t333 = load i1, ptr %l168, !tbaa !21
  %t334 = xor i1 %t333, true
  store i1 %t334, ptr %l169, !tbaa !21
  %t335 = load i1, ptr %l169, !tbaa !21
  br i1 %t335, label %bb116, label %bb117
bb116:
  store %olang.scope zeroinitializer, ptr %s14
  store i32 65536, ptr %l170, !tbaa !23
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t336 = load i32, ptr %l170, !tbaa !23
  %t337 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 %t336, 0
  store { i32, { i64, ptr } } %t337, ptr %rv
  br label %ret
bb117:
  br label %bb118
bb118:
  store ptr %l9, ptr %l171, !tbaa !29
  %t338 = load ptr, ptr %l171, !tbaa !29
  %t339 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t338)
  store { i64, ptr } %t339, ptr %l172
  br label %bb119
bb119:
  %t340 = load { i64, ptr }, ptr %l172, !tbaa !27
  store { i64, ptr } %t340, ptr %l173, !tbaa !27
  %t341 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 0
  store i64 %t342, ptr %l174, !tbaa !24
  %t343 = load i64, ptr %l174, !tbaa !24
  %t344 = mul i64 %t343, 1
  %t345 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t344)
  %t346 = insertvalue { i64, ptr } undef, i64 %t343, 0
  %t347 = insertvalue { i64, ptr } %t346, ptr %t345, 1
  store { i64, ptr } %t347, ptr %l175, !tbaa !27
  %t348 = getelementptr { i64, ptr }, ptr %l175, i32 0, i32 1
  %t349 = load ptr, ptr %t348, !tbaa !27
  %t350 = getelementptr { i64, ptr }, ptr %l173, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = load i64, ptr %l174, !tbaa !24
  %t353 = mul i64 %t352, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t349, ptr %t351, i64 %t353, i1 false)
  %t354 = load { i64, ptr }, ptr %l175, !tbaa !27
  store { i64, ptr } %t354, ptr %l173, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t355 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t356 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t355, 1
  store { i32, { i64, ptr } } %t356, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local void @compiler_2fdiag_2ePending_2einit() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr @G_2ecompiler_2fdiag_2ePending, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdiag_2eSpecPath(ptr %v0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca i32
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i32
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d7 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l4
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l3
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t6, ptr %l2, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 7, ptr @.d8 }, ptr %l5, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %rv
  br label %ret
bb4:
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l7, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t11 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 1, ptr @.d9 })
  %t12 = extractvalue { i32, i64 } %t11, 1
  %t13 = extractvalue { i32, i64 } %t11, 0
  store i32 %t13, ptr %l9
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb6, label %ok.15
ok.15:
  store i64 %t12, ptr %l8
  br label %bb5
bb5:
  %t16 = load i64, ptr %l8, !tbaa !24
  store i64 %t16, ptr %l6, !tbaa !24
  br label %bb8
bb6:
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store { i64, ptr } { i64 7, ptr @.d10 }, ptr %l10, !tbaa !27
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %rv
  br label %ret
bb8:
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l1, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t19, ptr %l11, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l12, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  store i64 %t22, ptr %l13, !tbaa !24
  %t23 = icmp sge i64 0, 0
  store i1 %t23, ptr %l14, !tbaa !21
  %t24 = load i1, ptr %l14, !tbaa !21
  br i1 %t24, label %bb9, label %bb10
bb9:
  %t25 = load i64, ptr %l12, !tbaa !24
  %t26 = icmp sle i64 0, %t25
  store i1 %t26, ptr %l15, !tbaa !21
  %t27 = load i1, ptr %l15, !tbaa !21
  br i1 %t27, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb11:
  %t28 = load i64, ptr %l12, !tbaa !24
  %t29 = load i64, ptr %l13, !tbaa !24
  %t30 = icmp sle i64 %t28, %t29
  store i1 %t30, ptr %l16, !tbaa !21
  %t31 = load i1, ptr %l16, !tbaa !21
  br i1 %t31, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
bb13:
  %t32 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = load i64, ptr %l12, !tbaa !24
  %t35 = getelementptr i8, ptr %t33, i64 0
  %t36 = sub i64 %t34, 0
  %t37 = insertvalue { i64, ptr } undef, i64 %t36, 0
  %t38 = insertvalue { i64, ptr } %t37, ptr %t35, 1
  store { i64, ptr } %t38, ptr %l17, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t39 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t40 = extractvalue { i64, ptr } %t39, 1
  %t41 = extractvalue { i64, ptr } %t39, 0
  call void @__olang_sb_put(ptr %s3, ptr %t40, i64 %t41)
  %t42 = extractvalue { i64, ptr } { i64 11, ptr @.d12 }, 1
  %t43 = extractvalue { i64, ptr } { i64 11, ptr @.d12 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t42, i64 %t43)
  %t44 = load ptr, ptr %s3
  %t45 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t46 = load i64, ptr %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t44, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l18, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t50 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  %t52 = extractvalue { i64, ptr } %t50, 1
  %t53 = mul i64 %t51, 1
  %t54 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t53)
  call void @llvm.memcpy.p0.p0.i64(ptr %t54, ptr %t52, i64 %t53, i1 false)
  %t55 = insertvalue { i64, ptr } undef, i64 %t51, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t54, 1
  store { i64, ptr } %t56, ptr %l19, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t57 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t57, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @.c11)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAddFile(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca ptr
  %l21 = alloca i64
  %l22 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l4, !tbaa !29
  %t2 = load ptr, ptr %l4, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 1
  store ptr %t3, ptr %l5, !tbaa !29
  %t4 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t4, ptr %l6, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t5 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 1
  %t7 = extractvalue { i64, ptr } %t5, 0
  call void @__olang_sb_put(ptr %s1, ptr %t6, i64 %t7)
  %t8 = load ptr, ptr %s1
  %t9 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t10 = load i64, ptr %t9
  %t11 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t10)
  call void @llvm.memcpy.p0.p0.i64(ptr %t11, ptr %t8, i64 %t10, i1 false)
  %t12 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t13 = insertvalue { i64, ptr } %t12, ptr %t11, 1
  store { i64, ptr } %t13, ptr %l7, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t14 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t15 = extractvalue { i64, ptr } %t14, 0
  %t16 = extractvalue { i64, ptr } %t14, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  %t21 = load ptr, ptr %l5, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l8, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v0, ptr %t21, { i64, ptr } %t22)
  br label %bb1
bb1:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l9, !tbaa !29
  %t24 = load ptr, ptr %l9, !tbaa !29
  %t25 = getelementptr %"compiler/diag:Diagnostics", ptr %t24, i32 0, i32 2
  store ptr %t25, ptr %l10, !tbaa !29
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l11, !tbaa !27
  %t27 = load ptr, ptr %l10, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l11, !tbaa !27
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v2, ptr %t27, { i64, ptr } %t28)
  br label %bb2
bb2:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l12, !tbaa !29
  %t30 = load ptr, ptr %l12, !tbaa !29
  %t31 = getelementptr %"compiler/diag:Diagnostics", ptr %t30, i32 0, i32 3
  store ptr %t31, ptr %l13, !tbaa !29
  %t32 = load i1, ptr %l3, !tbaa !21
  store i1 %t32, ptr %l14, !tbaa !21
  %t33 = load ptr, ptr %l13, !tbaa !29
  %t34 = load i1, ptr %l14, !tbaa !21
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %t33, i1 %t34)
  br label %bb3
bb3:
  %t35 = load ptr, ptr %l0, !tbaa !29
  store ptr %t35, ptr %l15, !tbaa !29
  %t36 = load ptr, ptr %l15, !tbaa !29
  %t37 = getelementptr %"compiler/diag:Diagnostics", ptr %t36, i32 0, i32 5
  store ptr %t37, ptr %l16, !tbaa !29
  %t38 = load ptr, ptr %l16, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t38, i64 -1)
  br label %bb4
bb4:
  %t39 = load ptr, ptr %l0, !tbaa !29
  store ptr %t39, ptr %l17, !tbaa !29
  %t40 = load ptr, ptr %l17, !tbaa !29
  %t41 = getelementptr %"compiler/diag:Diagnostics", ptr %t40, i32 0, i32 6
  store ptr %t41, ptr %l18, !tbaa !29
  %t42 = load ptr, ptr %l18, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t42, i64 0)
  br label %bb5
bb5:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l19, !tbaa !29
  %t44 = load ptr, ptr %l19, !tbaa !29
  %t45 = getelementptr %"compiler/diag:Diagnostics", ptr %t44, i32 0, i32 1
  store ptr %t45, ptr %l20, !tbaa !29
  %t46 = load ptr, ptr %l20, !tbaa !29
  %t47 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t46)
  store i64 %t47, ptr %l21
  br label %bb6
bb6:
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = sub i64 %t48, 1
  store i64 %t49, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i64, ptr %l22, !tbaa !24
  store i64 %t50, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local %"std/prelude/list:List<compiler/diag:Said>" @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eAllSaid(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %lp1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/diag:record"
  %l7 = alloca { i64, [3 x i64] }
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"std/prelude/list:List<compiler/diag:Said>"
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca %"compiler/diag:record"
  %l29 = alloca { i64, [3 x i64] }
  %l30 = alloca { i64, [3 x i64] }
  %l31 = alloca i1
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca ptr
  %l35 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/diag:Said"
  %l44 = alloca { i64, [3 x i64] }
  %l45 = alloca i1
  %l46 = alloca i64
  %l47 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l49 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca { i64, ptr }
  %l55 = alloca %"compiler/diag:Said"
  %l56 = alloca { i64, [3 x i64] }
  %l57 = alloca i1
  %l58 = alloca i64
  %l59 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l63 = alloca i64
  %l64 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca %"compiler/diag:Said"
  %l68 = alloca ptr
  %l69 = alloca { i64, ptr }
  %l70 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l72 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca %"compiler/diag:Said"
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca %"std/prelude/list:List<compiler/diag:Said>"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.builder
  %s5room = alloca [64 x i8], align 8
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.builder
  %s7room = alloca [64 x i8], align 8
  %s8 = alloca %olang.builder
  %s8room = alloca [64 x i8], align 8
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.builder
  %s10room = alloca [64 x i8], align 8
  %s11 = alloca %olang.builder
  %s11room = alloca [64 x i8], align 8
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.builder
  %s13room = alloca [64 x i8], align 8
  %s14 = alloca %olang.builder
  %s14room = alloca [64 x i8], align 8
  %s15 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/diag:Said>"
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/diag:Said>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e(ptr %t1)
  store %"std/prelude/list:List<compiler/diag:Said>" %t2, ptr %l12
  br label %bb1
bb1:
  %t3 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 8, i64 8)
  store ptr %t3, ptr %lp1
  %t4 = load %"std/prelude/list:List<compiler/diag:Said>", ptr %l12
  %t5 = load ptr, ptr %lp1
  store %"std/prelude/list:List<compiler/diag:Said>" %t4, ptr %t5
  store %olang.scope zeroinitializer, ptr %s1
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l13, !tbaa !29
  %t7 = load ptr, ptr %l13, !tbaa !29
  %t8 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ewritten(ptr %v0, ptr %s1, ptr %t7)
  store { i64, ptr } %t8, ptr %l14
  br label %bb2
bb2:
  %t9 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  %t11 = extractvalue { i64, ptr } %t9, 1
  %t12 = mul i64 %t10, 8
  %t13 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t12)
  call void @llvm.memcpy.p0.p0.i64(ptr %t13, ptr %t11, i64 %t12, i1 false)
  %t14 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l15, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t16, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l16, !tbaa !27
  %t18 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 0
  store i64 %t19, ptr %l17, !tbaa !24
  %t20 = load i64, ptr %l17, !tbaa !24
  store i64 %t20, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t21 = load i64, ptr %l3, !tbaa !24
  store i64 %t21, ptr %l18, !tbaa !24
  %t22 = load i64, ptr %l4, !tbaa !24
  store i64 %t22, ptr %l19, !tbaa !24
  %t23 = load i64, ptr %l18, !tbaa !24
  %t24 = load i64, ptr %l19, !tbaa !24
  %t25 = icmp slt i64 %t23, %t24
  store i1 %t25, ptr %l20, !tbaa !21
  %t26 = load i1, ptr %l20, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l21, !tbaa !21
  %t28 = load i1, ptr %l21, !tbaa !21
  br i1 %t28, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb5:
  br label %bb6
bb6:
  %t29 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t29, ptr %l22, !tbaa !27
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l23, !tbaa !24
  %t31 = load i64, ptr %l23, !tbaa !24
  %t32 = getelementptr { i64, ptr }, ptr %l22, i32 0, i32 1
  %t33 = load ptr, ptr %t32, !tbaa !27
  %t34 = getelementptr i64, ptr %t33, i64 %t31
  %t35 = load i64, ptr %t34, !tbaa !34
  store i64 %t35, ptr %l24, !tbaa !24
  %t36 = load i64, ptr %l24, !tbaa !24
  store i64 %t36, ptr %l5, !tbaa !24
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l25, !tbaa !29
  %t38 = load ptr, ptr %l25, !tbaa !29
  %t39 = getelementptr %"compiler/diag:Diagnostics", ptr %t38, i32 0, i32 7
  store ptr %t39, ptr %l26, !tbaa !29
  %t40 = load i64, ptr %l5, !tbaa !24
  store i64 %t40, ptr %l27, !tbaa !24
  %t41 = load ptr, ptr %l26, !tbaa !29
  %t42 = load i64, ptr %l27, !tbaa !24
  %t43 = call %"compiler/diag:record" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t41, i64 %t42)
  store %"compiler/diag:record" %t43, ptr %l28
  br label %bb7
bb7:
  %t44 = load %"compiler/diag:record", ptr %l28
  store %"compiler/diag:record" %t44, ptr %l6
  %t45 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 0
  %t46 = load { i64, [3 x i64] }, ptr %t45
  store { i64, [3 x i64] } %t46, ptr %l29
  %t47 = load { i64, [3 x i64] }, ptr %l29
  store { i64, [3 x i64] } %t47, ptr %l7
  %t48 = load { i64, [3 x i64] }, ptr %l7
  store { i64, [3 x i64] } %t48, ptr %l30
  %t49 = load { i64, [3 x i64] }, ptr %l30
  %t50 = extractvalue { i64, [3 x i64] } %t49, 0
  %t51 = icmp eq i64 %t50, 3
  store i1 %t51, ptr %l31, !tbaa !21
  %t52 = load i1, ptr %l31, !tbaa !21
  br i1 %t52, label %bb8, label %bb9
bb8:
  %t53 = getelementptr { i64, [3 x i64] }, ptr %l7, i32 0, i32 1
  %t54 = getelementptr { i64, i64, i64 }, ptr %t53, i32 0, i32 0
  %t55 = load i64, ptr %t54
  store i64 %t55, ptr %l32, !tbaa !24
  %t56 = load i64, ptr %l32, !tbaa !24
  store i64 %t56, ptr %l8, !tbaa !24
  %t57 = getelementptr { i64, [3 x i64] }, ptr %l7, i32 0, i32 1
  %t58 = getelementptr { i64, i64, i64 }, ptr %t57, i32 0, i32 1
  %t59 = load i64, ptr %t58
  store i64 %t59, ptr %l33, !tbaa !24
  %t60 = load i64, ptr %l33, !tbaa !24
  store i64 %t60, ptr %l9, !tbaa !24
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s3
  %t61 = load ptr, ptr %lp1
  store ptr %t61, ptr %l34, !tbaa !29
  %t62 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 1
  %t63 = load { i64, ptr }, ptr %t62, !tbaa !27
  store { i64, ptr } %t63, ptr %l35, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t64 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 1
  %t66 = extractvalue { i64, ptr } %t64, 0
  call void @__olang_sb_put(ptr %s4, ptr %t65, i64 %t66)
  %t67 = load ptr, ptr %s4
  %t68 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t69 = load i64, ptr %t68
  %t70 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t69)
  call void @llvm.memcpy.p0.p0.i64(ptr %t70, ptr %t67, i64 %t69, i1 false)
  %t71 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t72 = insertvalue { i64, ptr } %t71, ptr %t70, 1
  store { i64, ptr } %t72, ptr %l36, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  %t73 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 0
  %t75 = extractvalue { i64, ptr } %t73, 1
  %t76 = mul i64 %t74, 1
  %t77 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t75, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l37, !tbaa !27
  %t80 = load i64, ptr %l8, !tbaa !24
  store i64 %t80, ptr %l38, !tbaa !24
  %t81 = load i64, ptr %l9, !tbaa !24
  store i64 %t81, ptr %l39, !tbaa !24
  %t82 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  store { i64, ptr } %t83, ptr %l40, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s5
  store ptr %s5room, ptr %s5
  %t84 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t84, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  call void @__olang_sb_put(ptr %s5, ptr %t85, i64 %t86)
  %t87 = load ptr, ptr %s5
  %t88 = getelementptr %olang.builder, ptr %s5, i32 0, i32 1
  %t89 = load i64, ptr %t88
  %t90 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t89)
  call void @llvm.memcpy.p0.p0.i64(ptr %t90, ptr %t87, i64 %t89, i1 false)
  %t91 = insertvalue { i64, ptr } undef, i64 %t89, 0
  %t92 = insertvalue { i64, ptr } %t91, ptr %t90, 1
  store { i64, ptr } %t92, ptr %l41, !tbaa !27
  call void @__olang_sb_done(ptr %s5)
  %t93 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t93, 0
  %t95 = extractvalue { i64, ptr } %t93, 1
  %t96 = mul i64 %t94, 1
  %t97 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t95, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t94, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l42, !tbaa !27
  %t100 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t101 = load i64, ptr %l38, !tbaa !24
  %t102 = load i64, ptr %l39, !tbaa !24
  %t103 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t104 = call %"compiler/diag:Said" @compiler_2fdiag_3aSaid_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t100, i64 %t101, i64 %t102, { i64, ptr } %t103)
  store %"compiler/diag:Said" %t104, ptr %l43
  br label %bb11
bb11:
  %t105 = load ptr, ptr %l34, !tbaa !29
  %t106 = load %"compiler/diag:Said", ptr %l43
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ePush_3ccompiler_2fdiag_3aSaid_3e(ptr %v1, ptr %v1, ptr %t105, %"compiler/diag:Said" %t106)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb28
bb13:
  %t107 = load { i64, [3 x i64] }, ptr %l7
  store { i64, [3 x i64] } %t107, ptr %l44
  %t108 = load { i64, [3 x i64] }, ptr %l44
  %t109 = extractvalue { i64, [3 x i64] } %t108, 0
  %t110 = icmp eq i64 %t109, 2
  store i1 %t110, ptr %l45, !tbaa !21
  %t111 = load i1, ptr %l45, !tbaa !21
  br i1 %t111, label %bb14, label %bb15
bb14:
  %t112 = getelementptr { i64, [3 x i64] }, ptr %l7, i32 0, i32 1
  %t113 = getelementptr { i64, i64 }, ptr %t112, i32 0, i32 0
  %t114 = load i64, ptr %t113
  store i64 %t114, ptr %l46, !tbaa !24
  %t115 = load i64, ptr %l46, !tbaa !24
  store i64 %t115, ptr %l10, !tbaa !24
  br label %bb16
bb15:
  br label %bb19
bb16:
  store %olang.scope zeroinitializer, ptr %s6
  %t116 = load ptr, ptr %lp1
  store ptr %t116, ptr %l47, !tbaa !29
  %t117 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 1
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l48, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s7
  store ptr %s7room, ptr %s7
  %t119 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t120 = extractvalue { i64, ptr } %t119, 1
  %t121 = extractvalue { i64, ptr } %t119, 0
  call void @__olang_sb_put(ptr %s7, ptr %t120, i64 %t121)
  %t122 = load ptr, ptr %s7
  %t123 = getelementptr %olang.builder, ptr %s7, i32 0, i32 1
  %t124 = load i64, ptr %t123
  %t125 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t122, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  store { i64, ptr } %t127, ptr %l49, !tbaa !27
  call void @__olang_sb_done(ptr %s7)
  %t128 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 0
  %t130 = extractvalue { i64, ptr } %t128, 1
  %t131 = mul i64 %t129, 1
  %t132 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t131)
  call void @llvm.memcpy.p0.p0.i64(ptr %t132, ptr %t130, i64 %t131, i1 false)
  %t133 = insertvalue { i64, ptr } undef, i64 %t129, 0
  %t134 = insertvalue { i64, ptr } %t133, ptr %t132, 1
  store { i64, ptr } %t134, ptr %l50, !tbaa !27
  %t135 = load i64, ptr %l10, !tbaa !24
  store i64 %t135, ptr %l51, !tbaa !24
  %t136 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 2
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l52, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s8
  store ptr %s8room, ptr %s8
  %t138 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  call void @__olang_sb_put(ptr %s8, ptr %t139, i64 %t140)
  %t141 = load ptr, ptr %s8
  %t142 = getelementptr %olang.builder, ptr %s8, i32 0, i32 1
  %t143 = load i64, ptr %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t141, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  store { i64, ptr } %t146, ptr %l53, !tbaa !27
  call void @__olang_sb_done(ptr %s8)
  %t147 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l54, !tbaa !27
  %t154 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t155 = load i64, ptr %l51, !tbaa !24
  %t156 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t157 = call %"compiler/diag:Said" @compiler_2fdiag_3aSaid_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t154, i64 %t155, i64 -1, { i64, ptr } %t156)
  store %"compiler/diag:Said" %t157, ptr %l55
  br label %bb17
bb17:
  %t158 = load ptr, ptr %l47, !tbaa !29
  %t159 = load %"compiler/diag:Said", ptr %l55
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ePush_3ccompiler_2fdiag_3aSaid_3e(ptr %v1, ptr %v1, ptr %t158, %"compiler/diag:Said" %t159)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s6)
  br label %bb28
bb19:
  %t160 = load { i64, [3 x i64] }, ptr %l7
  store { i64, [3 x i64] } %t160, ptr %l56
  %t161 = load { i64, [3 x i64] }, ptr %l56
  %t162 = extractvalue { i64, [3 x i64] } %t161, 0
  %t163 = icmp eq i64 %t162, 1
  store i1 %t163, ptr %l57, !tbaa !21
  %t164 = load i1, ptr %l57, !tbaa !21
  br i1 %t164, label %bb20, label %bb21
bb20:
  %t165 = getelementptr { i64, [3 x i64] }, ptr %l7, i32 0, i32 1
  %t166 = getelementptr { i64 }, ptr %t165, i32 0, i32 0
  %t167 = load i64, ptr %t166
  store i64 %t167, ptr %l58, !tbaa !24
  %t168 = load i64, ptr %l58, !tbaa !24
  store i64 %t168, ptr %l11, !tbaa !24
  br label %bb22
bb21:
  br label %bb25
bb22:
  store %olang.scope zeroinitializer, ptr %s9
  %t169 = load ptr, ptr %lp1
  store ptr %t169, ptr %l59, !tbaa !29
  %t170 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 1
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !27
  store { i64, ptr } %t171, ptr %l60, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s10
  store ptr %s10room, ptr %s10
  %t172 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  call void @__olang_sb_put(ptr %s10, ptr %t173, i64 %t174)
  %t175 = load ptr, ptr %s10
  %t176 = getelementptr %olang.builder, ptr %s10, i32 0, i32 1
  %t177 = load i64, ptr %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t175, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l61, !tbaa !27
  call void @__olang_sb_done(ptr %s10)
  %t181 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t182 = extractvalue { i64, ptr } %t181, 0
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = mul i64 %t182, 1
  %t185 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t184)
  call void @llvm.memcpy.p0.p0.i64(ptr %t185, ptr %t183, i64 %t184, i1 false)
  %t186 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  store { i64, ptr } %t187, ptr %l62, !tbaa !27
  %t188 = load i64, ptr %l11, !tbaa !24
  store i64 %t188, ptr %l63, !tbaa !24
  %t189 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  store { i64, ptr } %t190, ptr %l64, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s11
  store ptr %s11room, ptr %s11
  %t191 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 1
  %t193 = extractvalue { i64, ptr } %t191, 0
  call void @__olang_sb_put(ptr %s11, ptr %t192, i64 %t193)
  %t194 = load ptr, ptr %s11
  %t195 = getelementptr %olang.builder, ptr %s11, i32 0, i32 1
  %t196 = load i64, ptr %t195
  %t197 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t196)
  call void @llvm.memcpy.p0.p0.i64(ptr %t197, ptr %t194, i64 %t196, i1 false)
  %t198 = insertvalue { i64, ptr } undef, i64 %t196, 0
  %t199 = insertvalue { i64, ptr } %t198, ptr %t197, 1
  store { i64, ptr } %t199, ptr %l65, !tbaa !27
  call void @__olang_sb_done(ptr %s11)
  %t200 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t201 = extractvalue { i64, ptr } %t200, 0
  %t202 = extractvalue { i64, ptr } %t200, 1
  %t203 = mul i64 %t201, 1
  %t204 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t203)
  call void @llvm.memcpy.p0.p0.i64(ptr %t204, ptr %t202, i64 %t203, i1 false)
  %t205 = insertvalue { i64, ptr } undef, i64 %t201, 0
  %t206 = insertvalue { i64, ptr } %t205, ptr %t204, 1
  store { i64, ptr } %t206, ptr %l66, !tbaa !27
  %t207 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t208 = load i64, ptr %l63, !tbaa !24
  %t209 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t210 = call %"compiler/diag:Said" @compiler_2fdiag_3aSaid_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t207, i64 %t208, i64 -1, { i64, ptr } %t209)
  store %"compiler/diag:Said" %t210, ptr %l67
  br label %bb23
bb23:
  %t211 = load ptr, ptr %l59, !tbaa !29
  %t212 = load %"compiler/diag:Said", ptr %l67
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ePush_3ccompiler_2fdiag_3aSaid_3e(ptr %v1, ptr %v1, ptr %t211, %"compiler/diag:Said" %t212)
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s9)
  br label %bb28
bb25:
  store %olang.scope zeroinitializer, ptr %s12
  %t213 = load ptr, ptr %lp1
  store ptr %t213, ptr %l68, !tbaa !29
  %t214 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 1
  %t215 = load { i64, ptr }, ptr %t214, !tbaa !27
  store { i64, ptr } %t215, ptr %l69, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s13
  store ptr %s13room, ptr %s13
  %t216 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t217 = extractvalue { i64, ptr } %t216, 1
  %t218 = extractvalue { i64, ptr } %t216, 0
  call void @__olang_sb_put(ptr %s13, ptr %t217, i64 %t218)
  %t219 = load ptr, ptr %s13
  %t220 = getelementptr %olang.builder, ptr %s13, i32 0, i32 1
  %t221 = load i64, ptr %t220
  %t222 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t221)
  call void @llvm.memcpy.p0.p0.i64(ptr %t222, ptr %t219, i64 %t221, i1 false)
  %t223 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t222, 1
  store { i64, ptr } %t224, ptr %l70, !tbaa !27
  call void @__olang_sb_done(ptr %s13)
  %t225 = load { i64, ptr }, ptr %l70, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  %t227 = extractvalue { i64, ptr } %t225, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  store { i64, ptr } %t231, ptr %l71, !tbaa !27
  %t232 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 2
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l72, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s14
  store ptr %s14room, ptr %s14
  %t234 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 1
  %t236 = extractvalue { i64, ptr } %t234, 0
  call void @__olang_sb_put(ptr %s14, ptr %t235, i64 %t236)
  %t237 = load ptr, ptr %s14
  %t238 = getelementptr %olang.builder, ptr %s14, i32 0, i32 1
  %t239 = load i64, ptr %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t239)
  call void @llvm.memcpy.p0.p0.i64(ptr %t240, ptr %t237, i64 %t239, i1 false)
  %t241 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t240, 1
  store { i64, ptr } %t242, ptr %l73, !tbaa !27
  call void @__olang_sb_done(ptr %s14)
  %t243 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t244 = extractvalue { i64, ptr } %t243, 0
  %t245 = extractvalue { i64, ptr } %t243, 1
  %t246 = mul i64 %t244, 1
  %t247 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t245, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t244, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  store { i64, ptr } %t249, ptr %l74, !tbaa !27
  %t250 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t251 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t252 = call %"compiler/diag:Said" @compiler_2fdiag_3aSaid_2ector(ptr %v1, ptr %v1, ptr %v1, { i64, ptr } %t250, i64 -1, i64 -1, { i64, ptr } %t251)
  store %"compiler/diag:Said" %t252, ptr %l75
  br label %bb26
bb26:
  %t253 = load ptr, ptr %l68, !tbaa !29
  %t254 = load %"compiler/diag:Said", ptr %l75
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ePush_3ccompiler_2fdiag_3aSaid_3e(ptr %v1, ptr %v1, ptr %t253, %"compiler/diag:Said" %t254)
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s12)
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb29:
  store %olang.scope zeroinitializer, ptr %s15
  %t255 = load i64, ptr %l3, !tbaa !24
  store i64 %t255, ptr %l76, !tbaa !24
  %t256 = load i64, ptr %l76, !tbaa !24
  %t257 = add i64 %t256, 1
  store i64 %t257, ptr %l77, !tbaa !24
  %t258 = load i64, ptr %l77, !tbaa !24
  store i64 %t258, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb3
bb30:
  call void @__olang_scope_close(ptr %s1)
  %t259 = load ptr, ptr %lp1
  %t260 = load %"std/prelude/list:List<compiler/diag:Said>", ptr %t259
  store %"std/prelude/list:List<compiler/diag:Said>" %t260, ptr %l78
  call void @__olang_scope_close(ptr %s0)
  %t261 = load %"std/prelude/list:List<compiler/diag:Said>", ptr %l78
  store %"std/prelude/list:List<compiler/diag:Said>" %t261, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/diag:Said>", ptr %rv
  ret %"std/prelude/list:List<compiler/diag:Said>" %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eChoose(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 10
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fdiag_2eChosen, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t6, i64 %t7, i64 %t8)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextBase(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca ptr
  %l6 = alloca i64
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 13
  %t4 = load i64, ptr %t3, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr %l4, !tbaa !24
  store i64 %t5, ptr %l2, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l5, !tbaa !29
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l6, !tbaa !24
  %t8 = load i64, ptr %l6, !tbaa !24
  %t9 = load ptr, ptr %l5, !tbaa !29
  %t10 = getelementptr %"compiler/diag:Diagnostics", ptr %t9, i32 0, i32 13
  store i64 %t8, ptr %t10, !tbaa !24
  %t11 = load i64, ptr %l2, !tbaa !24
  store i64 %t11, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t12 = load i64, ptr %l7, !tbaa !24
  store i64 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eContextDepth(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 12
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCount(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 7
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eCutOff(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 10
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fdiag_2eCut, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t6, i64 %t7, i64 %t8)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eDrop(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 10
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load i64, ptr @G_2ecompiler_2fdiag_2eDropped, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t7 = load i64, ptr %l4, !tbaa !24
  %t8 = load i64, ptr %l5, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t6, i64 %t7, i64 %t8)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eEndHold(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = call { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %t4)
  %t6 = extractvalue { i32, i64 } %t5, 1
  %t7 = extractvalue { i32, i64 } %t5, 0
  store i32 %t7, ptr %l5
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store i64 %t6, ptr %l4
  br label %bb1
bb1:
  %t10 = load i64, ptr %l4, !tbaa !24
  store i64 %t10, ptr %l1, !tbaa !24
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eError(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca ptr
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca %"compiler/msgs:Msg"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t2, ptr %l4
  %t3 = load %"compiler/msgs:Msg", ptr %l2
  store %"compiler/msgs:Msg" %t3, ptr %l5
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = load { i64, [3 x i64] }, ptr %l4
  %t6 = load %"compiler/msgs:Msg", ptr %l5
  %t7 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ereport(ptr %v0, ptr %v1, ptr %t4, { i64, [3 x i64] } %t5, %"compiler/msgs:Msg" %t6, i1 false)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorOncePerLine(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca ptr
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca %"compiler/msgs:Msg"
  %l6 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t2, ptr %l4
  %t3 = load %"compiler/msgs:Msg", ptr %l2
  store %"compiler/msgs:Msg" %t3, ptr %l5
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = load { i64, [3 x i64] }, ptr %l4
  %t6 = load %"compiler/msgs:Msg", ptr %l5
  %t7 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ereport(ptr %v0, ptr %v1, ptr %t4, { i64, [3 x i64] } %t5, %"compiler/msgs:Msg" %t6, i1 true)
  store i64 %t7, ptr %l6
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t8 = load i64, ptr %l6, !tbaa !24
  store i64 %t8, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorUnheld(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca { i64, ptr }
  %l4 = alloca i64
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca ptr
  %l15 = alloca { i64, [3 x i64] }
  %l16 = alloca %"compiler/msgs:Msg"
  %l17 = alloca i64
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l10, !tbaa !29
  %t4 = load ptr, ptr %l10, !tbaa !29
  %t5 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %s0, ptr %t4)
  store { i64, ptr } %t5, ptr %l11
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t6, ptr %l3, !tbaa !27
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l12, !tbaa !29
  %t8 = load ptr, ptr %l12, !tbaa !29
  %t9 = getelementptr %"compiler/diag:Diagnostics", ptr %t8, i32 0, i32 11
  store ptr %t9, ptr %l13, !tbaa !29
  %t10 = load ptr, ptr %l13, !tbaa !29
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %t10)
  br label %bb2
bb2:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l14, !tbaa !29
  %t12 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t12, ptr %l15
  %t13 = load %"compiler/msgs:Msg", ptr %l2
  store %"compiler/msgs:Msg" %t13, ptr %l16
  %t14 = load ptr, ptr %l14, !tbaa !29
  %t15 = load { i64, [3 x i64] }, ptr %l15
  %t16 = load %"compiler/msgs:Msg", ptr %l16
  %t17 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ereport(ptr %v0, ptr %v1, ptr %t14, { i64, [3 x i64] } %t15, %"compiler/msgs:Msg" %t16, i1 false)
  store i64 %t17, ptr %l17
  br label %bb3
bb3:
  %t18 = load i64, ptr %l17, !tbaa !24
  store i64 %t18, ptr %l4, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t19, ptr %l18, !tbaa !27
  %t20 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t20, ptr %l5, !tbaa !27
  store i64 0, ptr %l6, !tbaa !24
  %t21 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t21, ptr %l19, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l20, !tbaa !24
  store i64 %t24, ptr %l7, !tbaa !24
  br label %bb4
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t25 = load i64, ptr %l6, !tbaa !24
  store i64 %t25, ptr %l21, !tbaa !24
  %t26 = load i64, ptr %l7, !tbaa !24
  store i64 %t26, ptr %l22, !tbaa !24
  %t27 = load i64, ptr %l21, !tbaa !24
  %t28 = load i64, ptr %l22, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l23, !tbaa !21
  %t30 = load i1, ptr %l23, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l24, !tbaa !21
  %t32 = load i1, ptr %l24, !tbaa !21
  br i1 %t32, label %bb5, label %bb6
bb5:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb6:
  br label %bb7
bb7:
  %t33 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t33, ptr %l25, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l26, !tbaa !24
  %t35 = load i64, ptr %l26, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr i64, ptr %t37, i64 %t35
  %t39 = load i64, ptr %t38, !tbaa !34
  store i64 %t39, ptr %l27, !tbaa !24
  %t40 = load i64, ptr %l27, !tbaa !24
  store i64 %t40, ptr %l8, !tbaa !24
  %t41 = load ptr, ptr %l0, !tbaa !29
  store ptr %t41, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l28, !tbaa !29
  %t43 = getelementptr %"compiler/diag:Diagnostics", ptr %t42, i32 0, i32 11
  store ptr %t43, ptr %l29, !tbaa !29
  %t44 = load i64, ptr %l8, !tbaa !24
  store i64 %t44, ptr %l30, !tbaa !24
  %t45 = load ptr, ptr %l29, !tbaa !29
  %t46 = load i64, ptr %l30, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t45, i64 %t46)
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s3
  %t47 = load i64, ptr %l6, !tbaa !24
  store i64 %t47, ptr %l31, !tbaa !24
  %t48 = load i64, ptr %l31, !tbaa !24
  %t49 = add i64 %t48, 1
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l32, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb4
bb10:
  call void @__olang_scope_close(ptr %s1)
  %t51 = load i64, ptr %l4, !tbaa !24
  store i64 %t51, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t52 = load i64, ptr %l33, !tbaa !24
  store i64 %t52, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrorWithin(ptr %v0, ptr %a0, i64 %a1, i64 %a2, i64 %a3, i64 %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca %"compiler/diag:record"
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca ptr
  %l46 = alloca ptr
  %l47 = alloca i64
  %l48 = alloca %"compiler/diag:record"
  %l49 = alloca { i64, [3 x i64] }
  %l50 = alloca { i64, [3 x i64] }
  %l51 = alloca i1
  %l52 = alloca i64
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i1
  %l57 = alloca i1
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca i1
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store i64 %a3, ptr %l3
  store i64 %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load i64, ptr %l4, !tbaa !24
  store i64 %t1, ptr %l15, !tbaa !24
  %t2 = load i64, ptr %l15, !tbaa !24
  store i64 %t2, ptr %l6, !tbaa !24
  store i64 1, ptr %l7, !tbaa !24
  %t3 = load i64, ptr %l6, !tbaa !24
  store i64 %t3, ptr %l16, !tbaa !24
  %t4 = load i64, ptr %l5, !tbaa !24
  store i64 %t4, ptr %l17, !tbaa !24
  %t5 = load i64, ptr %l16, !tbaa !24
  %t6 = load i64, ptr %l17, !tbaa !24
  %t7 = icmp sgt i64 %t5, %t6
  store i1 %t7, ptr %l18, !tbaa !21
  %t8 = load i1, ptr %l18, !tbaa !21
  br i1 %t8, label %bb1, label %bb2
bb1:
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l20, !tbaa !24
  %t10 = load i64, ptr %l20, !tbaa !24
  %t11 = icmp sgt i64 %t10, 0
  store i1 %t11, ptr %l21, !tbaa !21
  %t12 = load i1, ptr %l21, !tbaa !21
  br i1 %t12, label %bb3, label %bb4
bb2:
  store i64 0, ptr %l19, !tbaa !24
  br label %bb6
bb3:
  %t13 = load i64, ptr %l6, !tbaa !24
  store i64 %t13, ptr %l23, !tbaa !24
  %t14 = load i64, ptr %l5, !tbaa !24
  store i64 %t14, ptr %l24, !tbaa !24
  %t15 = load i64, ptr %l23, !tbaa !24
  %t16 = load i64, ptr %l24, !tbaa !24
  %t17 = sub i64 %t15, %t16
  store i64 %t17, ptr %l25, !tbaa !24
  %t18 = load i64, ptr %l7, !tbaa !24
  store i64 %t18, ptr %l26, !tbaa !24
  %t19 = load i64, ptr %l25, !tbaa !24
  %t20 = load i64, ptr %l26, !tbaa !24
  %t21 = add i64 %t19, %t20
  store i64 %t21, ptr %l27, !tbaa !24
  %t22 = load i64, ptr %l27, !tbaa !24
  %t23 = sub i64 %t22, 1
  store i64 %t23, ptr %l28, !tbaa !24
  %t24 = load i64, ptr %l7, !tbaa !24
  store i64 %t24, ptr %l29, !tbaa !24
  %t25 = load i64, ptr %l28, !tbaa !24
  %t26 = load i64, ptr %l29, !tbaa !24
  %t27 = sdiv i64 %t25, %t26
  store i64 %t27, ptr %l30, !tbaa !24
  %t28 = load i64, ptr %l30, !tbaa !24
  store i64 %t28, ptr %l22, !tbaa !24
  br label %bb5
bb4:
  store i64 0, ptr %l22, !tbaa !24
  br label %bb5
bb5:
  %t29 = load i64, ptr %l22, !tbaa !24
  store i64 %t29, ptr %l19, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l19, !tbaa !24
  store i64 %t30, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load i64, ptr %l9, !tbaa !24
  store i64 %t31, ptr %l31, !tbaa !24
  %t32 = load i64, ptr %l8, !tbaa !24
  store i64 %t32, ptr %l32, !tbaa !24
  %t33 = load i64, ptr %l31, !tbaa !24
  %t34 = load i64, ptr %l32, !tbaa !24
  %t35 = icmp slt i64 %t33, %t34
  store i1 %t35, ptr %l33, !tbaa !21
  %t36 = load i1, ptr %l33, !tbaa !21
  %t37 = xor i1 %t36, true
  store i1 %t37, ptr %l34, !tbaa !21
  %t38 = load i1, ptr %l34, !tbaa !21
  br i1 %t38, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb9:
  br label %bb10
bb10:
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l35, !tbaa !24
  %t40 = load i64, ptr %l9, !tbaa !24
  store i64 %t40, ptr %l36, !tbaa !24
  %t41 = load i64, ptr %l7, !tbaa !24
  store i64 %t41, ptr %l37, !tbaa !24
  %t42 = load i64, ptr %l36, !tbaa !24
  %t43 = load i64, ptr %l37, !tbaa !24
  %t44 = mul i64 %t42, %t43
  store i64 %t44, ptr %l38, !tbaa !24
  %t45 = load i64, ptr %l35, !tbaa !24
  %t46 = load i64, ptr %l38, !tbaa !24
  %t47 = add i64 %t45, %t46
  store i64 %t47, ptr %l39, !tbaa !24
  %t48 = load i64, ptr %l39, !tbaa !24
  store i64 %t48, ptr %l10, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  store i64 %t49, ptr %l40, !tbaa !24
  %t50 = load ptr, ptr %l0, !tbaa !29
  store ptr %t50, ptr %l41, !tbaa !29
  %t51 = load ptr, ptr %l41, !tbaa !29
  %t52 = getelementptr %"compiler/diag:Diagnostics", ptr %t51, i32 0, i32 7
  store ptr %t52, ptr %l42, !tbaa !29
  %t53 = load ptr, ptr %l42, !tbaa !29
  %t54 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t53)
  store i64 %t54, ptr %l43
  br label %bb11
bb11:
  %t55 = load i64, ptr %l40, !tbaa !24
  %t56 = load i64, ptr %l43, !tbaa !24
  %t57 = icmp sge i64 %t55, %t56
  store i1 %t57, ptr %l44, !tbaa !21
  %t58 = load i1, ptr %l44, !tbaa !21
  br i1 %t58, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb31
bb13:
  br label %bb14
bb14:
  %t59 = load ptr, ptr %l0, !tbaa !29
  store ptr %t59, ptr %l45, !tbaa !29
  %t60 = load ptr, ptr %l45, !tbaa !29
  %t61 = getelementptr %"compiler/diag:Diagnostics", ptr %t60, i32 0, i32 7
  store ptr %t61, ptr %l46, !tbaa !29
  %t62 = load i64, ptr %l10, !tbaa !24
  store i64 %t62, ptr %l47, !tbaa !24
  %t63 = load ptr, ptr %l46, !tbaa !29
  %t64 = load i64, ptr %l47, !tbaa !24
  %t65 = call %"compiler/diag:record" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t63, i64 %t64)
  store %"compiler/diag:record" %t65, ptr %l48
  br label %bb15
bb15:
  %t66 = load %"compiler/diag:record", ptr %l48
  store %"compiler/diag:record" %t66, ptr %l11
  %t67 = getelementptr %"compiler/diag:record", ptr %l11, i32 0, i32 0
  %t68 = load { i64, [3 x i64] }, ptr %t67
  store { i64, [3 x i64] } %t68, ptr %l49
  %t69 = load { i64, [3 x i64] }, ptr %l49
  store { i64, [3 x i64] } %t69, ptr %l12
  %t70 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t70, ptr %l50
  %t71 = load { i64, [3 x i64] }, ptr %l50
  %t72 = extractvalue { i64, [3 x i64] } %t71, 0
  %t73 = icmp eq i64 %t72, 3
  store i1 %t73, ptr %l51, !tbaa !21
  %t74 = load i1, ptr %l51, !tbaa !21
  br i1 %t74, label %bb16, label %bb17
bb16:
  %t75 = getelementptr { i64, [3 x i64] }, ptr %l12, i32 0, i32 1
  %t76 = getelementptr { i64, i64, i64 }, ptr %t75, i32 0, i32 0
  %t77 = load i64, ptr %t76
  store i64 %t77, ptr %l52, !tbaa !24
  %t78 = load i64, ptr %l52, !tbaa !24
  store i64 %t78, ptr %l13, !tbaa !24
  %t79 = getelementptr { i64, [3 x i64] }, ptr %l12, i32 0, i32 1
  %t80 = getelementptr { i64, i64, i64 }, ptr %t79, i32 0, i32 1
  %t81 = load i64, ptr %t80
  store i64 %t81, ptr %l53, !tbaa !24
  %t82 = load i64, ptr %l53, !tbaa !24
  store i64 %t82, ptr %l14, !tbaa !24
  br label %bb18
bb17:
  br label %bb28
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load i64, ptr %l13, !tbaa !24
  store i64 %t83, ptr %l54, !tbaa !24
  %t84 = load i64, ptr %l1, !tbaa !24
  store i64 %t84, ptr %l55, !tbaa !24
  %t85 = load i64, ptr %l54, !tbaa !24
  %t86 = load i64, ptr %l55, !tbaa !24
  %t87 = icmp eq i64 %t85, %t86
  store i1 %t87, ptr %l56, !tbaa !21
  %t88 = load i1, ptr %l56, !tbaa !21
  br i1 %t88, label %bb19, label %bb20
bb19:
  %t89 = load i64, ptr %l14, !tbaa !24
  store i64 %t89, ptr %l58, !tbaa !24
  %t90 = load i64, ptr %l2, !tbaa !24
  store i64 %t90, ptr %l59, !tbaa !24
  %t91 = load i64, ptr %l58, !tbaa !24
  %t92 = load i64, ptr %l59, !tbaa !24
  %t93 = icmp sge i64 %t91, %t92
  store i1 %t93, ptr %l60, !tbaa !21
  %t94 = load i1, ptr %l60, !tbaa !21
  store i1 %t94, ptr %l57, !tbaa !21
  br label %bb21
bb20:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb21
bb21:
  %t95 = load i1, ptr %l57, !tbaa !21
  br i1 %t95, label %bb22, label %bb23
bb22:
  %t96 = load i64, ptr %l14, !tbaa !24
  store i64 %t96, ptr %l62, !tbaa !24
  %t97 = load i64, ptr %l3, !tbaa !24
  store i64 %t97, ptr %l63, !tbaa !24
  %t98 = load i64, ptr %l62, !tbaa !24
  %t99 = load i64, ptr %l63, !tbaa !24
  %t100 = icmp slt i64 %t98, %t99
  store i1 %t100, ptr %l64, !tbaa !21
  %t101 = load i1, ptr %l64, !tbaa !21
  store i1 %t101, ptr %l61, !tbaa !21
  br label %bb24
bb23:
  store i1 false, ptr %l61, !tbaa !21
  br label %bb24
bb24:
  %t102 = load i1, ptr %l61, !tbaa !21
  br i1 %t102, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 true, ptr %l65, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t103 = load i1, ptr %l65, !tbaa !21
  store i1 %t103, ptr %rv
  br label %ret
bb26:
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s4)
  br label %bb29
bb28:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s2)
  br label %bb30
bb30:
  store %olang.scope zeroinitializer, ptr %s7
  %t104 = load i64, ptr %l9, !tbaa !24
  store i64 %t104, ptr %l66, !tbaa !24
  %t105 = load i64, ptr %l66, !tbaa !24
  %t106 = add i64 %t105, 1
  store i64 %t106, ptr %l67, !tbaa !24
  %t107 = load i64, ptr %l67, !tbaa !24
  store i64 %t107, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb7
bb31:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %l68, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i1, ptr %l68, !tbaa !21
  store i1 %t108, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca ptr
  %l5 = alloca i1
  %l6 = alloca i64
  %l7 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ewritten(ptr %v0, ptr %s0, ptr %t2)
  store { i64, ptr } %t3, ptr %l2
  br label %bb1
bb1:
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t4, 0
  store i64 %t5, ptr %l3, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l4, !tbaa !29
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 19
  %t9 = load i1, ptr %t8, !tbaa !21
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store i64 1, ptr %l6, !tbaa !24
  br label %bb4
bb3:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb4
bb4:
  %t11 = load i64, ptr %l3, !tbaa !24
  %t12 = load i64, ptr %l6, !tbaa !24
  %t13 = add i64 %t11, %t12
  store i64 %t13, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i64, ptr %l7, !tbaa !24
  store i64 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, [3 x i64] }
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 19
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l0, !tbaa !29
  store ptr %t4, ptr %l4, !tbaa !29
  %t5 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t5, ptr %l5
  %t6 = load { i64, [3 x i64] }, ptr %l5
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 16
  store { i64, [3 x i64] } %t6, ptr %t8
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = getelementptr %"compiler/msgs:Msg", ptr %l2, i32 0, i32 1
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l7, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t12 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s1, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s1
  %t16 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l8, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  %t28 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t29 = load ptr, ptr %l6, !tbaa !29
  %t30 = getelementptr %"compiler/diag:Diagnostics", ptr %t29, i32 0, i32 17
  store { i64, ptr } %t28, ptr %t30, !tbaa !27
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l10, !tbaa !29
  %t32 = getelementptr %"compiler/msgs:Msg", ptr %l2, i32 0, i32 2
  %t33 = load { i64, ptr }, ptr %t32, !tbaa !27
  store { i64, ptr } %t33, ptr %l11, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t34 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t35 = extractvalue { i64, ptr } %t34, 1
  %t36 = extractvalue { i64, ptr } %t34, 0
  call void @__olang_sb_put(ptr %s2, ptr %t35, i64 %t36)
  %t37 = load ptr, ptr %s2
  %t38 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t39 = load i64, ptr %t38
  %t40 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t39)
  call void @llvm.memcpy.p0.p0.i64(ptr %t40, ptr %t37, i64 %t39, i1 false)
  %t41 = insertvalue { i64, ptr } undef, i64 %t39, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l12, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t43 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 0
  %t45 = extractvalue { i64, ptr } %t43, 1
  %t46 = mul i64 %t44, 1
  %t47 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t46)
  call void @llvm.memcpy.p0.p0.i64(ptr %t47, ptr %t45, i64 %t46, i1 false)
  %t48 = insertvalue { i64, ptr } undef, i64 %t44, 0
  %t49 = insertvalue { i64, ptr } %t48, ptr %t47, 1
  store { i64, ptr } %t49, ptr %l13, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t51 = load ptr, ptr %l10, !tbaa !29
  %t52 = getelementptr %"compiler/diag:Diagnostics", ptr %t51, i32 0, i32 18
  store { i64, ptr } %t50, ptr %t52, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eForget(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca i1
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca %"compiler/diag:note"
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca ptr
  %l52 = alloca ptr
  %l53 = alloca i64
  %l54 = alloca ptr
  %l55 = alloca ptr
  %l56 = alloca i64
  %l57 = alloca %"compiler/diag:note"
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca ptr
  %l63 = alloca ptr
  %l64 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l9, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l10, !tbaa !29
  %t3 = load ptr, ptr %l10, !tbaa !29
  %t4 = getelementptr %"compiler/diag:Diagnostics", ptr %t3, i32 0, i32 7
  store ptr %t4, ptr %l11, !tbaa !29
  %t5 = load ptr, ptr %l11, !tbaa !29
  %t6 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t5)
  store i64 %t6, ptr %l12
  br label %bb1
bb1:
  %t7 = load i64, ptr %l9, !tbaa !24
  %t8 = load i64, ptr %l12, !tbaa !24
  %t9 = icmp sge i64 %t7, %t8
  store i1 %t9, ptr %l13, !tbaa !21
  %t10 = load i1, ptr %l13, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb3:
  br label %bb4
bb4:
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l14, !tbaa !29
  %t12 = load ptr, ptr %l14, !tbaa !29
  %t13 = getelementptr %"compiler/diag:Diagnostics", ptr %t12, i32 0, i32 7
  store ptr %t13, ptr %l15, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l16, !tbaa !24
  %t15 = load ptr, ptr %l15, !tbaa !29
  %t16 = load i64, ptr %l16, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eTrunc_Hfb0c5ceb44a5ca5b5beffc6b7a3329ef(ptr %v0, ptr %t15, i64 %t16)
  br label %bb5
bb5:
  store i64 0, ptr %l2, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s2
  store i64 0, ptr %l3, !tbaa !24
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l17, !tbaa !29
  %t18 = load ptr, ptr %l17, !tbaa !29
  %t19 = getelementptr %"compiler/diag:Diagnostics", ptr %t18, i32 0, i32 8
  store ptr %t19, ptr %l18, !tbaa !29
  %t20 = load ptr, ptr %l18, !tbaa !29
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t20)
  store i64 %t21, ptr %l19
  br label %bb6
bb6:
  %t22 = load i64, ptr %l19, !tbaa !24
  store i64 %t22, ptr %l4, !tbaa !24
  store i64 1, ptr %l5, !tbaa !24
  %t23 = load i64, ptr %l4, !tbaa !24
  store i64 %t23, ptr %l20, !tbaa !24
  %t24 = load i64, ptr %l3, !tbaa !24
  store i64 %t24, ptr %l21, !tbaa !24
  %t25 = load i64, ptr %l20, !tbaa !24
  %t26 = load i64, ptr %l21, !tbaa !24
  %t27 = icmp sgt i64 %t25, %t26
  store i1 %t27, ptr %l22, !tbaa !21
  %t28 = load i1, ptr %l22, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  %t29 = load i64, ptr %l5, !tbaa !24
  store i64 %t29, ptr %l24, !tbaa !24
  %t30 = load i64, ptr %l24, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  store i1 %t31, ptr %l25, !tbaa !21
  %t32 = load i1, ptr %l25, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb8:
  store i64 0, ptr %l23, !tbaa !24
  br label %bb12
bb9:
  %t33 = load i64, ptr %l4, !tbaa !24
  store i64 %t33, ptr %l27, !tbaa !24
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l28, !tbaa !24
  %t35 = load i64, ptr %l27, !tbaa !24
  %t36 = load i64, ptr %l28, !tbaa !24
  %t37 = sub i64 %t35, %t36
  store i64 %t37, ptr %l29, !tbaa !24
  %t38 = load i64, ptr %l5, !tbaa !24
  store i64 %t38, ptr %l30, !tbaa !24
  %t39 = load i64, ptr %l29, !tbaa !24
  %t40 = load i64, ptr %l30, !tbaa !24
  %t41 = add i64 %t39, %t40
  store i64 %t41, ptr %l31, !tbaa !24
  %t42 = load i64, ptr %l31, !tbaa !24
  %t43 = sub i64 %t42, 1
  store i64 %t43, ptr %l32, !tbaa !24
  %t44 = load i64, ptr %l5, !tbaa !24
  store i64 %t44, ptr %l33, !tbaa !24
  %t45 = load i64, ptr %l32, !tbaa !24
  %t46 = load i64, ptr %l33, !tbaa !24
  %t47 = sdiv i64 %t45, %t46
  store i64 %t47, ptr %l34, !tbaa !24
  %t48 = load i64, ptr %l34, !tbaa !24
  store i64 %t48, ptr %l26, !tbaa !24
  br label %bb11
bb10:
  store i64 0, ptr %l26, !tbaa !24
  br label %bb11
bb11:
  %t49 = load i64, ptr %l26, !tbaa !24
  store i64 %t49, ptr %l23, !tbaa !24
  br label %bb12
bb12:
  %t50 = load i64, ptr %l23, !tbaa !24
  store i64 %t50, ptr %l6, !tbaa !24
  store i64 0, ptr %l7, !tbaa !24
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t51 = load i64, ptr %l7, !tbaa !24
  store i64 %t51, ptr %l35, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l36, !tbaa !24
  %t53 = load i64, ptr %l35, !tbaa !24
  %t54 = load i64, ptr %l36, !tbaa !24
  %t55 = icmp slt i64 %t53, %t54
  store i1 %t55, ptr %l37, !tbaa !21
  %t56 = load i1, ptr %l37, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l38, !tbaa !21
  %t58 = load i1, ptr %l38, !tbaa !21
  br i1 %t58, label %bb14, label %bb15
bb14:
  call void @__olang_scope_close(ptr %s3)
  br label %bb24
bb15:
  br label %bb16
bb16:
  %t59 = load i64, ptr %l3, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  %t60 = load i64, ptr %l7, !tbaa !24
  store i64 %t60, ptr %l40, !tbaa !24
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l41, !tbaa !24
  %t62 = load i64, ptr %l40, !tbaa !24
  %t63 = load i64, ptr %l41, !tbaa !24
  %t64 = mul i64 %t62, %t63
  store i64 %t64, ptr %l42, !tbaa !24
  %t65 = load i64, ptr %l39, !tbaa !24
  %t66 = load i64, ptr %l42, !tbaa !24
  %t67 = add i64 %t65, %t66
  store i64 %t67, ptr %l43, !tbaa !24
  %t68 = load i64, ptr %l43, !tbaa !24
  store i64 %t68, ptr %l8, !tbaa !24
  %t69 = load ptr, ptr %l0, !tbaa !29
  store ptr %t69, ptr %l44, !tbaa !29
  %t70 = load ptr, ptr %l44, !tbaa !29
  %t71 = getelementptr %"compiler/diag:Diagnostics", ptr %t70, i32 0, i32 8
  store ptr %t71, ptr %l45, !tbaa !29
  %t72 = load i64, ptr %l8, !tbaa !24
  store i64 %t72, ptr %l46, !tbaa !24
  %t73 = load ptr, ptr %l45, !tbaa !29
  %t74 = load i64, ptr %l46, !tbaa !24
  %t75 = call %"compiler/diag:note" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t73, i64 %t74)
  store %"compiler/diag:note" %t75, ptr %l47
  br label %bb17
bb17:
  %t76 = getelementptr %"compiler/diag:note", ptr %l47, i32 0, i32 0
  %t77 = load i64, ptr %t76, !tbaa !24
  store i64 %t77, ptr %l48, !tbaa !24
  %t78 = load i64, ptr %l1, !tbaa !24
  store i64 %t78, ptr %l49, !tbaa !24
  %t79 = load i64, ptr %l48, !tbaa !24
  %t80 = load i64, ptr %l49, !tbaa !24
  %t81 = icmp slt i64 %t79, %t80
  store i1 %t81, ptr %l50, !tbaa !21
  %t82 = load i1, ptr %l50, !tbaa !21
  br i1 %t82, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t83 = load ptr, ptr %l0, !tbaa !29
  store ptr %t83, ptr %l51, !tbaa !29
  %t84 = load ptr, ptr %l51, !tbaa !29
  %t85 = getelementptr %"compiler/diag:Diagnostics", ptr %t84, i32 0, i32 8
  store ptr %t85, ptr %l52, !tbaa !29
  %t86 = load i64, ptr %l2, !tbaa !24
  store i64 %t86, ptr %l53, !tbaa !24
  %t87 = load ptr, ptr %l0, !tbaa !29
  store ptr %t87, ptr %l54, !tbaa !29
  %t88 = load ptr, ptr %l54, !tbaa !29
  %t89 = getelementptr %"compiler/diag:Diagnostics", ptr %t88, i32 0, i32 8
  store ptr %t89, ptr %l55, !tbaa !29
  %t90 = load i64, ptr %l8, !tbaa !24
  store i64 %t90, ptr %l56, !tbaa !24
  %t91 = load ptr, ptr %l55, !tbaa !29
  %t92 = load i64, ptr %l56, !tbaa !24
  %t93 = call %"compiler/diag:note" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t91, i64 %t92)
  store %"compiler/diag:note" %t93, ptr %l57
  br label %bb20
bb19:
  br label %bb22
bb20:
  %t94 = load ptr, ptr %l52, !tbaa !29
  %t95 = load i64, ptr %l53, !tbaa !24
  %t96 = load %"compiler/diag:note", ptr %l57
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eSetAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t94, i64 %t95, %"compiler/diag:note" %t96)
  br label %bb21
bb21:
  %t97 = load i64, ptr %l2, !tbaa !24
  store i64 %t97, ptr %l58, !tbaa !24
  %t98 = load i64, ptr %l58, !tbaa !24
  %t99 = add i64 %t98, 1
  store i64 %t99, ptr %l59, !tbaa !24
  %t100 = load i64, ptr %l59, !tbaa !24
  store i64 %t100, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s3)
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t101 = load i64, ptr %l7, !tbaa !24
  store i64 %t101, ptr %l60, !tbaa !24
  %t102 = load i64, ptr %l60, !tbaa !24
  %t103 = add i64 %t102, 1
  store i64 %t103, ptr %l61, !tbaa !24
  %t104 = load i64, ptr %l61, !tbaa !24
  store i64 %t104, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb13
bb24:
  call void @__olang_scope_close(ptr %s2)
  %t105 = load ptr, ptr %l0, !tbaa !29
  store ptr %t105, ptr %l62, !tbaa !29
  %t106 = load ptr, ptr %l62, !tbaa !29
  %t107 = getelementptr %"compiler/diag:Diagnostics", ptr %t106, i32 0, i32 8
  store ptr %t107, ptr %l63, !tbaa !29
  %t108 = load i64, ptr %l2, !tbaa !24
  store i64 %t108, ptr %l64, !tbaa !24
  %t109 = load ptr, ptr %l63, !tbaa !29
  %t110 = load i64, ptr %l64, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eTruncate_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t109, i64 %t110)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHold(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca i64
  %l28 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i64, ptr %l5, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store i64 -1, ptr %l7, !tbaa !24
  br label %bb6
bb3:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l8, !tbaa !29
  %t10 = load ptr, ptr %l8, !tbaa !29
  %t11 = getelementptr %"compiler/diag:Diagnostics", ptr %t10, i32 0, i32 11
  store ptr %t11, ptr %l9, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l10, !tbaa !29
  %t13 = load ptr, ptr %l10, !tbaa !29
  %t14 = getelementptr %"compiler/diag:Diagnostics", ptr %t13, i32 0, i32 11
  store ptr %t14, ptr %l11, !tbaa !29
  %t15 = load ptr, ptr %l11, !tbaa !29
  %t16 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t15)
  store i64 %t16, ptr %l12
  br label %bb4
bb4:
  %t17 = load i64, ptr %l12, !tbaa !24
  %t18 = sub i64 %t17, 1
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load ptr, ptr %l9, !tbaa !29
  %t20 = load i64, ptr %l13, !tbaa !24
  %t21 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t19, i64 %t20)
  store i64 %t21, ptr %l14
  br label %bb5
bb5:
  %t22 = load i64, ptr %l14, !tbaa !24
  store i64 %t22, ptr %l7, !tbaa !24
  br label %bb6
bb6:
  %t23 = load i64, ptr %l7, !tbaa !24
  store i64 %t23, ptr %l1, !tbaa !24
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l15, !tbaa !29
  %t25 = load ptr, ptr %l15, !tbaa !29
  %t26 = getelementptr %"compiler/diag:Diagnostics", ptr %t25, i32 0, i32 9
  store ptr %t26, ptr %l16, !tbaa !29
  %t27 = load i64, ptr %l1, !tbaa !24
  store i64 %t27, ptr %l17, !tbaa !24
  %t28 = load ptr, ptr %l16, !tbaa !29
  %t29 = load i64, ptr %l17, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t28, i64 %t29)
  br label %bb7
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l18, !tbaa !29
  %t31 = load ptr, ptr %l18, !tbaa !29
  %t32 = getelementptr %"compiler/diag:Diagnostics", ptr %t31, i32 0, i32 10
  store ptr %t32, ptr %l19, !tbaa !29
  %t33 = load i64, ptr @G_2ecompiler_2fdiag_2ePending, !tbaa !24
  store i64 %t33, ptr %l20, !tbaa !24
  %t34 = load ptr, ptr %l19, !tbaa !29
  %t35 = load i64, ptr %l20, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t34, i64 %t35)
  br label %bb8
bb8:
  %t36 = load ptr, ptr %l0, !tbaa !29
  store ptr %t36, ptr %l21, !tbaa !29
  %t37 = load ptr, ptr %l21, !tbaa !29
  %t38 = getelementptr %"compiler/diag:Diagnostics", ptr %t37, i32 0, i32 9
  store ptr %t38, ptr %l22, !tbaa !29
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t39)
  store i64 %t40, ptr %l23
  br label %bb9
bb9:
  %t41 = load i64, ptr %l23, !tbaa !24
  %t42 = sub i64 %t41, 1
  store i64 %t42, ptr %l24, !tbaa !24
  %t43 = load i64, ptr %l24, !tbaa !24
  store i64 %t43, ptr %l2, !tbaa !24
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l25, !tbaa !29
  %t45 = load ptr, ptr %l25, !tbaa !29
  %t46 = getelementptr %"compiler/diag:Diagnostics", ptr %t45, i32 0, i32 11
  store ptr %t46, ptr %l26, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l27, !tbaa !24
  %t48 = load ptr, ptr %l26, !tbaa !29
  %t49 = load i64, ptr %l27, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t48, i64 %t49)
  br label %bb10
bb10:
  %t50 = load i64, ptr %l2, !tbaa !24
  store i64 %t50, ptr %l28, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i64, ptr %l28, !tbaa !24
  store i64 %t51, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eHolds(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca %"compiler/diag:record"
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca i1
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca %"compiler/diag:record"
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca i1
  %l42 = alloca i1
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store %olang.scope zeroinitializer, ptr %s1
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l9, !tbaa !29
  %t2 = load ptr, ptr %l9, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 7
  store ptr %t3, ptr %l10, !tbaa !29
  %t4 = load ptr, ptr %l10, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  store i64 0, ptr %l3, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s2
  %t5 = load ptr, ptr %l2, !tbaa !29
  store ptr %t5, ptr %l12, !tbaa !29
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %l13, !tbaa !24
  %t7 = load ptr, ptr %l12, !tbaa !29
  %t8 = load i64, ptr %l13, !tbaa !24
  %t9 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eRunFrom_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t7, i64 %t8)
  %t10 = extractvalue { i32, { i64, ptr } } %t9, 1
  %t11 = extractvalue { i32, { i64, ptr } } %t9, 0
  store i32 %t11, ptr %l15
  %t12 = icmp ne i32 %t11, 0
  br i1 %t12, label %bb3, label %ok.13
ok.13:
  store { i64, ptr } %t10, ptr %l14
  br label %bb2
bb2:
  %t14 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t14, ptr %l11, !tbaa !27
  br label %bb7
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = ashr i32 %t15, 16
  store i32 %t16, ptr %l16, !tbaa !23
  %t17 = load i32, ptr %l16, !tbaa !23
  %t18 = icmp eq i32 %t17, 1
  store i1 %t18, ptr %l17, !tbaa !21
  %t19 = load i1, ptr %l17, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  call void @__olang_check_failed(ptr @.c13)
  unreachable
bb6:
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb7:
  %t20 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t20, ptr %l4, !tbaa !27
  %t21 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t21, ptr %l18, !tbaa !27
  %t22 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t23 = extractvalue { i64, ptr } %t22, 0
  store i64 %t23, ptr %l19, !tbaa !24
  %t24 = load i64, ptr %l19, !tbaa !24
  store i64 %t24, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t25 = load i64, ptr %l6, !tbaa !24
  store i64 %t25, ptr %l20, !tbaa !24
  %t26 = load i64, ptr %l5, !tbaa !24
  store i64 %t26, ptr %l21, !tbaa !24
  %t27 = load i64, ptr %l20, !tbaa !24
  %t28 = load i64, ptr %l21, !tbaa !24
  %t29 = icmp slt i64 %t27, %t28
  store i1 %t29, ptr %l22, !tbaa !21
  %t30 = load i1, ptr %l22, !tbaa !21
  %t31 = xor i1 %t30, true
  store i1 %t31, ptr %l23, !tbaa !21
  %t32 = load i1, ptr %l23, !tbaa !21
  br i1 %t32, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb26
bb10:
  br label %bb11
bb11:
  %t33 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t33, ptr %l24, !tbaa !27
  %t34 = load i64, ptr %l6, !tbaa !24
  store i64 %t34, ptr %l25, !tbaa !24
  %t35 = load i64, ptr %l25, !tbaa !24
  %t36 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t37 = load ptr, ptr %t36, !tbaa !27
  %t38 = getelementptr %"compiler/diag:record", ptr %t37, i64 %t35
  %t39 = load %"compiler/diag:record", ptr %t38
  store %"compiler/diag:record" %t39, ptr %l26
  %t40 = load %"compiler/diag:record", ptr %l26
  store %"compiler/diag:record" %t40, ptr %l7
  %t41 = getelementptr %"compiler/diag:record", ptr %l7, i32 0, i32 4
  %t42 = load i64, ptr %t41, !tbaa !24
  store i64 %t42, ptr %l27, !tbaa !24
  %t43 = load i64, ptr %l27, !tbaa !24
  store i64 %t43, ptr %l8, !tbaa !24
  br label %bb12
bb12:
  store %olang.scope zeroinitializer, ptr %s4
  %t44 = load i64, ptr %l8, !tbaa !24
  store i64 %t44, ptr %l28, !tbaa !24
  %t45 = load i64, ptr %l28, !tbaa !24
  %t46 = icmp sge i64 %t45, 0
  store i1 %t46, ptr %l29, !tbaa !21
  %t47 = load i1, ptr %l29, !tbaa !21
  br i1 %t47, label %bb13, label %bb14
bb13:
  %t48 = load i64, ptr %l8, !tbaa !24
  store i64 %t48, ptr %l31, !tbaa !24
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l32, !tbaa !24
  %t50 = load i64, ptr %l31, !tbaa !24
  %t51 = load i64, ptr %l32, !tbaa !24
  %t52 = icmp ne i64 %t50, %t51
  store i1 %t52, ptr %l33, !tbaa !21
  %t53 = load i1, ptr %l33, !tbaa !21
  store i1 %t53, ptr %l30, !tbaa !21
  br label %bb15
bb14:
  store i1 false, ptr %l30, !tbaa !21
  br label %bb15
bb15:
  %t54 = load i1, ptr %l30, !tbaa !21
  %t55 = xor i1 %t54, true
  store i1 %t55, ptr %l34, !tbaa !21
  %t56 = load i1, ptr %l34, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  call void @__olang_scope_close(ptr %s4)
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t57 = load ptr, ptr %l0, !tbaa !29
  store ptr %t57, ptr %l35, !tbaa !29
  %t58 = load ptr, ptr %l35, !tbaa !29
  %t59 = getelementptr %"compiler/diag:Diagnostics", ptr %t58, i32 0, i32 9
  store ptr %t59, ptr %l36, !tbaa !29
  %t60 = load i64, ptr %l8, !tbaa !24
  store i64 %t60, ptr %l37, !tbaa !24
  %t61 = load ptr, ptr %l36, !tbaa !29
  %t62 = load i64, ptr %l37, !tbaa !24
  %t63 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  store i64 %t63, ptr %l38
  br label %bb19
bb19:
  %t64 = load i64, ptr %l38, !tbaa !24
  store i64 %t64, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb20
bb20:
  br label %bb12
bb21:
  %t65 = load i64, ptr %l8, !tbaa !24
  store i64 %t65, ptr %l39, !tbaa !24
  %t66 = load i64, ptr %l1, !tbaa !24
  store i64 %t66, ptr %l40, !tbaa !24
  %t67 = load i64, ptr %l39, !tbaa !24
  %t68 = load i64, ptr %l40, !tbaa !24
  %t69 = icmp eq i64 %t67, %t68
  store i1 %t69, ptr %l41, !tbaa !21
  %t70 = load i1, ptr %l41, !tbaa !21
  br i1 %t70, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  store i1 true, ptr %l42, !tbaa !21
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t71 = load i1, ptr %l42, !tbaa !21
  store i1 %t71, ptr %rv
  br label %ret
bb23:
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s3)
  br label %bb25
bb25:
  store %olang.scope zeroinitializer, ptr %s6
  %t72 = load i64, ptr %l6, !tbaa !24
  store i64 %t72, ptr %l43, !tbaa !24
  %t73 = load i64, ptr %l43, !tbaa !24
  %t74 = add i64 %t73, 1
  store i64 %t74, ptr %l44, !tbaa !24
  %t75 = load i64, ptr %l44, !tbaa !24
  store i64 %t75, ptr %l6, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb8
bb26:
  %t76 = load i64, ptr %l3, !tbaa !24
  store i64 %t76, ptr %l45, !tbaa !24
  %t77 = load i64, ptr %l5, !tbaa !24
  store i64 %t77, ptr %l46, !tbaa !24
  %t78 = load i64, ptr %l45, !tbaa !24
  %t79 = load i64, ptr %l46, !tbaa !24
  %t80 = add i64 %t78, %t79
  store i64 %t80, ptr %l47, !tbaa !24
  %t81 = load i64, ptr %l47, !tbaa !24
  store i64 %t81, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb27:
  br label %bb1
bb28:
  call void @__olang_scope_close(ptr %s1)
  store i1 false, ptr %l48, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t82 = load i1, ptr %l48, !tbaa !21
  store i1 %t82, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsCut(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 10
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l9, !tbaa !21
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/diag:Diagnostics", ptr %t17, i32 0, i32 10
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t20, i64 %t21)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2fdiag_2eCut, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp eq i64 %t24, %t25
  store i1 %t26, ptr %l16, !tbaa !21
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l10, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsDropped(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca i1
  %l18 = alloca ptr
  %l19 = alloca ptr
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 10
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l9, !tbaa !21
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/diag:Diagnostics", ptr %t17, i32 0, i32 10
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t20, i64 %t21)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb12
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2fdiag_2eDropped, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp eq i64 %t24, %t25
  store i1 %t26, ptr %l16, !tbaa !21
  %t27 = load i1, ptr %l16, !tbaa !21
  br i1 %t27, label %bb8, label %bb9
bb8:
  store i1 true, ptr %l17, !tbaa !21
  br label %bb11
bb9:
  %t28 = load ptr, ptr %l0, !tbaa !29
  store ptr %t28, ptr %l18, !tbaa !29
  %t29 = load ptr, ptr %l18, !tbaa !29
  %t30 = getelementptr %"compiler/diag:Diagnostics", ptr %t29, i32 0, i32 10
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load i64, ptr %l1, !tbaa !24
  store i64 %t31, ptr %l20, !tbaa !24
  %t32 = load ptr, ptr %l19, !tbaa !29
  %t33 = load i64, ptr %l20, !tbaa !24
  %t34 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t32, i64 %t33)
  store i64 %t34, ptr %l21
  br label %bb10
bb10:
  %t35 = load i64, ptr @G_2ecompiler_2fdiag_2eCut, !tbaa !24
  store i64 %t35, ptr %l22, !tbaa !24
  %t36 = load i64, ptr %l21, !tbaa !24
  %t37 = load i64, ptr %l22, !tbaa !24
  %t38 = icmp eq i64 %t36, %t37
  store i1 %t38, ptr %l23, !tbaa !21
  %t39 = load i1, ptr %l23, !tbaa !21
  store i1 %t39, ptr %l17, !tbaa !21
  br label %bb11
bb11:
  %t40 = load i1, ptr %l17, !tbaa !21
  store i1 %t40, ptr %l10, !tbaa !21
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t41 = load i1, ptr %l10, !tbaa !21
  store i1 %t41, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eIsPending(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 10
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l9, !tbaa !21
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/diag:Diagnostics", ptr %t17, i32 0, i32 10
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t20, i64 %t21)
  store i64 %t22, ptr %l14
  br label %bb7
bb6:
  store i1 false, ptr %l10, !tbaa !21
  br label %bb8
bb7:
  %t23 = load i64, ptr @G_2ecompiler_2fdiag_2ePending, !tbaa !24
  store i64 %t23, ptr %l15, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = load i64, ptr %l15, !tbaa !24
  %t26 = icmp eq i64 %t24, %t25
  store i1 %t26, ptr %l16, !tbaa !21
  %t27 = load i1, ptr %l16, !tbaa !21
  store i1 %t27, ptr %l10, !tbaa !21
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i1, ptr %l10, !tbaa !21
  store i1 %t28, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLineAt(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, i64 }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i64
  %l9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i64
  %l14 = alloca ptr
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca { i64, i64 }
  %l18 = alloca i64
  %l19 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l5, !tbaa !24
  %t2 = load i64, ptr %l5, !tbaa !24
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l6, !tbaa !21
  %t4 = load i1, ptr %l6, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l8, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l9, !tbaa !29
  %t7 = load ptr, ptr %l9, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 1
  store ptr %t8, ptr %l10, !tbaa !29
  %t9 = load ptr, ptr %l10, !tbaa !29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l11
  br label %bb3
bb3:
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = load i64, ptr %l11, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l12, !tbaa !21
  %t14 = load i1, ptr %l12, !tbaa !21
  store i1 %t14, ptr %l7, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l7, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t16 = load i64, ptr %l13, !tbaa !24
  store i64 %t16, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t17 = load ptr, ptr %l0, !tbaa !29
  store ptr %t17, ptr %l14, !tbaa !29
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l15, !tbaa !24
  %t19 = load i64, ptr %l2, !tbaa !24
  store i64 %t19, ptr %l16, !tbaa !24
  %t20 = load ptr, ptr %l14, !tbaa !29
  %t21 = load i64, ptr %l15, !tbaa !24
  %t22 = load i64, ptr %l16, !tbaa !24
  %t23 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t20, i64 %t21, i64 %t22)
  store { i64, i64 } %t23, ptr %l17
  br label %bb8
bb8:
  %t24 = load { i64, i64 }, ptr %l17
  store { i64, i64 } %t24, ptr %l3
  %t25 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 0
  %t26 = load i64, ptr %t25, !tbaa !24
  store i64 %t26, ptr %l18, !tbaa !24
  %t27 = load i64, ptr %l18, !tbaa !24
  store i64 %t27, ptr %l4, !tbaa !24
  %t28 = load i64, ptr %l4, !tbaa !24
  store i64 %t28, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i64, ptr %l19, !tbaa !24
  store i64 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eLocate(ptr %v0, ptr %v1, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, i64 }
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca i64
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l12 = alloca i64
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca { i64, ptr }
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca { i64, i64 }
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca ptr
  %l25 = alloca ptr
  %l26 = alloca i64
  %l27 = alloca { i64, ptr }
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l6, !tbaa !24
  %t2 = load i64, ptr %l6, !tbaa !24
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l7, !tbaa !21
  %t4 = load i1, ptr %l7, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l8, !tbaa !21
  br label %bb4
bb2:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l9, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l10, !tbaa !29
  %t7 = load ptr, ptr %l10, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 1
  store ptr %t8, ptr %l11, !tbaa !29
  %t9 = load ptr, ptr %l11, !tbaa !29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l12
  br label %bb3
bb3:
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = load i64, ptr %l12, !tbaa !24
  %t13 = icmp sge i64 %t11, %t12
  store i1 %t13, ptr %l13, !tbaa !21
  %t14 = load i1, ptr %l13, !tbaa !21
  store i1 %t14, ptr %l8, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l8, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 1, ptr @.d14 }, ptr %l14, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t16, ptr %l15, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l16, !tbaa !24
  %t19 = load i64, ptr %l16, !tbaa !24
  %t20 = mul i64 %t19, 1
  %t21 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t20)
  %t22 = insertvalue { i64, ptr } undef, i64 %t19, 0
  %t23 = insertvalue { i64, ptr } %t22, ptr %t21, 1
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t25 = load ptr, ptr %t24, !tbaa !27
  %t26 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t27 = load ptr, ptr %t26, !tbaa !27
  %t28 = load i64, ptr %l16, !tbaa !24
  %t29 = mul i64 %t28, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t25, ptr %t27, i64 %t29, i1 false)
  %t30 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t30, ptr %l15, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  br label %bb7
bb7:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l18, !tbaa !29
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l19, !tbaa !24
  %t34 = load i64, ptr %l2, !tbaa !24
  store i64 %t34, ptr %l20, !tbaa !24
  %t35 = load ptr, ptr %l18, !tbaa !29
  %t36 = load i64, ptr %l19, !tbaa !24
  %t37 = load i64, ptr %l20, !tbaa !24
  %t38 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t35, i64 %t36, i64 %t37)
  store { i64, i64 } %t38, ptr %l21
  br label %bb8
bb8:
  %t39 = load { i64, i64 }, ptr %l21
  store { i64, i64 } %t39, ptr %l3
  %t40 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l22, !tbaa !24
  %t42 = load i64, ptr %l22, !tbaa !24
  store i64 %t42, ptr %l4, !tbaa !24
  %t43 = getelementptr { i64, i64 }, ptr %l3, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l23, !tbaa !24
  %t45 = load i64, ptr %l23, !tbaa !24
  store i64 %t45, ptr %l5, !tbaa !24
  %t46 = load ptr, ptr %l0, !tbaa !29
  store ptr %t46, ptr %l24, !tbaa !29
  %t47 = load ptr, ptr %l24, !tbaa !29
  %t48 = getelementptr %"compiler/diag:Diagnostics", ptr %t47, i32 0, i32 1
  store ptr %t48, ptr %l25, !tbaa !29
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l26, !tbaa !24
  %t50 = load ptr, ptr %l25, !tbaa !29
  %t51 = load i64, ptr %l26, !tbaa !24
  %t52 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t50, i64 %t51)
  store { i64, ptr } %t52, ptr %l27
  br label %bb9
bb9:
  %t53 = load i64, ptr %l4, !tbaa !24
  store i64 %t53, ptr %l28, !tbaa !24
  %t54 = load i64, ptr %l2, !tbaa !24
  store i64 %t54, ptr %l29, !tbaa !24
  %t55 = load i64, ptr %l5, !tbaa !24
  store i64 %t55, ptr %l30, !tbaa !24
  %t56 = load i64, ptr %l29, !tbaa !24
  %t57 = load i64, ptr %l30, !tbaa !24
  %t58 = sub i64 %t56, %t57
  store i64 %t58, ptr %l31, !tbaa !24
  %t59 = load i64, ptr %l31, !tbaa !24
  %t60 = add i64 %t59, 1
  store i64 %t60, ptr %l32, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t61 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t62 = extractvalue { i64, ptr } %t61, 1
  %t63 = extractvalue { i64, ptr } %t61, 0
  call void @__olang_sb_put(ptr %s2, ptr %t62, i64 %t63)
  %t64 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 1
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d15 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t64, i64 %t65)
  %t66 = load i64, ptr %l28, !tbaa !24
  %t67 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t68 = call i64 @__olang_fmt_i64(ptr %t67, i64 %t66)
  call void @__olang_sb_add(ptr %s2, i64 %t68)
  %t69 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 1
  %t70 = extractvalue { i64, ptr } { i64 1, ptr @.d16 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t69, i64 %t70)
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = call ptr @__olang_sb_room(ptr %s2, i64 24)
  %t73 = call i64 @__olang_fmt_i64(ptr %t72, i64 %t71)
  call void @__olang_sb_add(ptr %s2, i64 %t73)
  %t74 = load ptr, ptr %s2
  %t75 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t76 = load i64, ptr %t75
  %t77 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t76)
  call void @llvm.memcpy.p0.p0.i64(ptr %t77, ptr %t74, i64 %t76, i1 false)
  %t78 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t77, 1
  store { i64, ptr } %t79, ptr %l33, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t80 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t80, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eNote(ptr %v0, ptr %v1, ptr %a0, i64 %a1, { i64, [3 x i64] } %a2, %"compiler/msgs:Msg" %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca %"compiler/msgs:Msg"
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, [3 x i64] }
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/diag:note"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  store %"compiler/msgs:Msg" %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l4, !tbaa !24
  %t2 = load i64, ptr %l4, !tbaa !24
  %t3 = icmp slt i64 %t2, 0
  store i1 %t3, ptr %l5, !tbaa !21
  %t4 = load i1, ptr %l5, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb2:
  br label %bb3
bb3:
  %t5 = load ptr, ptr %l0, !tbaa !29
  store ptr %t5, ptr %l6, !tbaa !29
  %t6 = load ptr, ptr %l6, !tbaa !29
  %t7 = getelementptr %"compiler/diag:Diagnostics", ptr %t6, i32 0, i32 8
  store ptr %t7, ptr %l7, !tbaa !29
  %t8 = load i64, ptr %l1, !tbaa !24
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t9, ptr %l9
  %t10 = getelementptr %"compiler/msgs:Msg", ptr %l3, i32 0, i32 2
  %t11 = load { i64, ptr }, ptr %t10, !tbaa !27
  store { i64, ptr } %t11, ptr %l10, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t12 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t13 = extractvalue { i64, ptr } %t12, 1
  %t14 = extractvalue { i64, ptr } %t12, 0
  call void @__olang_sb_put(ptr %s2, ptr %t13, i64 %t14)
  %t15 = load ptr, ptr %s2
  %t16 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t17 = load i64, ptr %t16
  %t18 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t15, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t17, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  store { i64, ptr } %t20, ptr %l11, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  %t21 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l12, !tbaa !27
  %t28 = load i64, ptr %l8, !tbaa !24
  %t29 = load { i64, [3 x i64] }, ptr %l9
  %t30 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t31 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t28, { i64, [3 x i64] } %t29, { i64, ptr } %t30)
  store %"compiler/diag:note" %t31, ptr %l13
  br label %bb4
bb4:
  %t32 = load ptr, ptr %l7, !tbaa !29
  %t33 = load %"compiler/diag:note", ptr %l13
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t32, %"compiler/diag:note" %t33)
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePathOf(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i64
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca i1
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l2, !tbaa !24
  %t2 = load i64, ptr %l2, !tbaa !24
  %t3 = icmp sge i64 %t2, 0
  store i1 %t3, ptr %l3, !tbaa !21
  %t4 = load i1, ptr %l3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t6 = load ptr, ptr %l0, !tbaa !29
  store ptr %t6, ptr %l6, !tbaa !29
  %t7 = load ptr, ptr %l6, !tbaa !29
  %t8 = getelementptr %"compiler/diag:Diagnostics", ptr %t7, i32 0, i32 1
  store ptr %t8, ptr %l7, !tbaa !29
  %t9 = load ptr, ptr %l7, !tbaa !29
  %t10 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t9)
  store i64 %t10, ptr %l8
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb4
bb3:
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = load i64, ptr %l8, !tbaa !24
  %t13 = icmp slt i64 %t11, %t12
  store i1 %t13, ptr %l9, !tbaa !21
  %t14 = load i1, ptr %l9, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb4
bb4:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb5, label %bb6
bb5:
  %t16 = load ptr, ptr %l0, !tbaa !29
  store ptr %t16, ptr %l11, !tbaa !29
  %t17 = load ptr, ptr %l11, !tbaa !29
  %t18 = getelementptr %"compiler/diag:Diagnostics", ptr %t17, i32 0, i32 1
  store ptr %t18, ptr %l12, !tbaa !29
  %t19 = load i64, ptr %l1, !tbaa !24
  store i64 %t19, ptr %l13, !tbaa !24
  %t20 = load ptr, ptr %l12, !tbaa !29
  %t21 = load i64, ptr %l13, !tbaa !24
  %t22 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s0, ptr %t20, i64 %t21)
  store { i64, ptr } %t22, ptr %l14
  br label %bb7
bb6:
  store { i64, ptr } { i64 1, ptr @.d17 }, ptr %l16, !tbaa !27
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t23, ptr %l17, !tbaa !27
  %t24 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t24, ptr %l10, !tbaa !27
  br label %bb8
bb7:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t25 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t25, 1
  %t27 = extractvalue { i64, ptr } %t25, 0
  call void @__olang_sb_put(ptr %s1, ptr %t26, i64 %t27)
  %t28 = load ptr, ptr %s1
  %t29 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t30 = load i64, ptr %t29
  %t31 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t30)
  call void @llvm.memcpy.p0.p0.i64(ptr %t31, ptr %t28, i64 %t30, i1 false)
  %t32 = insertvalue { i64, ptr } undef, i64 %t30, 0
  %t33 = insertvalue { i64, ptr } %t32, ptr %t31, 1
  store { i64, ptr } %t33, ptr %l15, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t34 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t34, ptr %l10, !tbaa !27
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t35 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t35, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePopContext(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"compiler/diag:context"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/diag:context"
  %l5 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 12
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  %t5 = call { i32, %"compiler/diag:context" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ePop_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %s0, ptr %t4)
  %t6 = extractvalue { i32, %"compiler/diag:context" } %t5, 1
  %t7 = extractvalue { i32, %"compiler/diag:context" } %t5, 0
  store i32 %t7, ptr %l5
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb2, label %ok.9
ok.9:
  store %"compiler/diag:context" %t6, ptr %l4
  br label %bb1
bb1:
  %t10 = load %"compiler/diag:context", ptr %l4
  store %"compiler/diag:context" %t10, ptr %l1
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  call void @__olang_scope_close(ptr %s1)
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ePushContext(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, [3 x i64] }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/diag:context"
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.builder
  %s1room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 12
  store ptr %t3, ptr %l4, !tbaa !29
  %t4 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t4, ptr %l5
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s1
  store ptr %s1room, ptr %s1
  %t6 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 1
  %t8 = extractvalue { i64, ptr } %t6, 0
  call void @__olang_sb_put(ptr %s1, ptr %t7, i64 %t8)
  %t9 = load ptr, ptr %s1
  %t10 = getelementptr %olang.builder, ptr %s1, i32 0, i32 1
  %t11 = load i64, ptr %t10
  %t12 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t11)
  call void @llvm.memcpy.p0.p0.i64(ptr %t12, ptr %t9, i64 %t11, i1 false)
  %t13 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l7, !tbaa !27
  call void @__olang_sb_done(ptr %s1)
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  %t17 = extractvalue { i64, ptr } %t15, 1
  %t18 = mul i64 %t16, 1
  %t19 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t18)
  call void @llvm.memcpy.p0.p0.i64(ptr %t19, ptr %t17, i64 %t18, i1 false)
  %t20 = insertvalue { i64, ptr } undef, i64 %t16, 0
  %t21 = insertvalue { i64, ptr } %t20, ptr %t19, 1
  store { i64, ptr } %t21, ptr %l8, !tbaa !27
  %t22 = load { i64, [3 x i64] }, ptr %l5
  %t23 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t24 = call %"compiler/diag:context" @compiler_2fdiag_3acontext_2ector(ptr %v0, ptr %v0, { i64, [3 x i64] } %t22, { i64, ptr } %t23)
  store %"compiler/diag:context" %t24, ptr %l9
  br label %bb1
bb1:
  %t25 = load ptr, ptr %l4, !tbaa !29
  %t26 = load %"compiler/diag:context", ptr %l9
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ePush_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t25, %"compiler/diag:context" %t26)
  br label %bb2
bb2:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRecordCount(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l3 = alloca i64
  %s0 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l1, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 7
  store ptr %t3, ptr %l2, !tbaa !29
  %t4 = load ptr, ptr %l2, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l3
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i64, ptr %l3, !tbaa !24
  store i64 %t6, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eRender(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca %"compiler/diag:record"
  %l7 = alloca ptr
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/diag:note"
  %l13 = alloca %"std/prelude/text:StringBuilder"
  %l14 = alloca ptr
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca %"compiler/diag:record"
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca { i64, [3 x i64] }
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca ptr
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca ptr
  %l39 = alloca i64
  %l40 = alloca { i64, ptr }
  %l41 = alloca i32
  %l42 = alloca i32
  %l43 = alloca i1
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca i1
  %l49 = alloca i1
  %l50 = alloca { i64, ptr }
  %l51 = alloca i64
  %l52 = alloca %"compiler/diag:note"
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i1
  %l56 = alloca ptr
  %l57 = alloca ptr
  %l58 = alloca { i64, [3 x i64] }
  %l59 = alloca { i64, ptr }
  %l60 = alloca i64
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca i1
  %l69 = alloca ptr
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca { i64, [3 x i64] }
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l75 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l77 = alloca { i64, ptr }
  %l78 = alloca { i64, ptr }
  %l79 = alloca ptr
  %l80 = alloca ptr
  %l81 = alloca { i64, ptr }
  %l82 = alloca ptr
  %l83 = alloca ptr
  %l84 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l86 = alloca i64
  %l87 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l13
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l13
  store %"std/prelude/text:StringBuilder" %t2, ptr %l1
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load ptr, ptr %l0, !tbaa !29
  store ptr %t3, ptr %l14, !tbaa !29
  %t4 = load ptr, ptr %l14, !tbaa !29
  %t5 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ewritten(ptr %v0, ptr %s1, ptr %t4)
  store { i64, ptr } %t5, ptr %l15
  br label %bb2
bb2:
  %t6 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t6, 0
  %t8 = extractvalue { i64, ptr } %t6, 1
  %t9 = mul i64 %t7, 8
  %t10 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t9)
  call void @llvm.memcpy.p0.p0.i64(ptr %t10, ptr %t8, i64 %t9, i1 false)
  %t11 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t10, 1
  store { i64, ptr } %t12, ptr %l16, !tbaa !27
  %t13 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t13, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l17, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 0
  store i64 %t16, ptr %l18, !tbaa !24
  %t17 = load i64, ptr %l18, !tbaa !24
  store i64 %t17, ptr %l4, !tbaa !24
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load i64, ptr %l3, !tbaa !24
  store i64 %t18, ptr %l19, !tbaa !24
  %t19 = load i64, ptr %l4, !tbaa !24
  store i64 %t19, ptr %l20, !tbaa !24
  %t20 = load i64, ptr %l19, !tbaa !24
  %t21 = load i64, ptr %l20, !tbaa !24
  %t22 = icmp slt i64 %t20, %t21
  store i1 %t22, ptr %l21, !tbaa !21
  %t23 = load i1, ptr %l21, !tbaa !21
  %t24 = xor i1 %t23, true
  store i1 %t24, ptr %l22, !tbaa !21
  %t25 = load i1, ptr %l22, !tbaa !21
  br i1 %t25, label %bb4, label %bb5
bb4:
  call void @__olang_scope_close(ptr %s2)
  br label %bb29
bb5:
  br label %bb6
bb6:
  %t26 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t26, ptr %l23, !tbaa !27
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l24, !tbaa !24
  %t28 = load i64, ptr %l24, !tbaa !24
  %t29 = getelementptr { i64, ptr }, ptr %l23, i32 0, i32 1
  %t30 = load ptr, ptr %t29, !tbaa !27
  %t31 = getelementptr i64, ptr %t30, i64 %t28
  %t32 = load i64, ptr %t31, !tbaa !34
  store i64 %t32, ptr %l25, !tbaa !24
  %t33 = load i64, ptr %l25, !tbaa !24
  store i64 %t33, ptr %l5, !tbaa !24
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l26, !tbaa !29
  %t35 = load ptr, ptr %l26, !tbaa !29
  %t36 = getelementptr %"compiler/diag:Diagnostics", ptr %t35, i32 0, i32 7
  store ptr %t36, ptr %l27, !tbaa !29
  %t37 = load i64, ptr %l5, !tbaa !24
  store i64 %t37, ptr %l28, !tbaa !24
  %t38 = load ptr, ptr %l27, !tbaa !29
  %t39 = load i64, ptr %l28, !tbaa !24
  %t40 = call %"compiler/diag:record" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t38, i64 %t39)
  store %"compiler/diag:record" %t40, ptr %l29
  br label %bb7
bb7:
  %t41 = load %"compiler/diag:record", ptr %l29
  store %"compiler/diag:record" %t41, ptr %l6
  %t42 = load ptr, ptr %l0, !tbaa !29
  store ptr %t42, ptr %l30, !tbaa !29
  store ptr %l1, ptr %l31, !tbaa !29
  %t43 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 0
  %t44 = load { i64, [3 x i64] }, ptr %t43
  store { i64, [3 x i64] } %t44, ptr %l32
  %t45 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 1
  %t46 = load { i64, ptr }, ptr %t45, !tbaa !27
  store { i64, ptr } %t46, ptr %l33, !tbaa !27
  %t47 = getelementptr %"compiler/diag:record", ptr %l6, i32 0, i32 2
  %t48 = load { i64, ptr }, ptr %t47, !tbaa !27
  store { i64, ptr } %t48, ptr %l34, !tbaa !27
  %t49 = load ptr, ptr %l30, !tbaa !29
  %t50 = load ptr, ptr %l31, !tbaa !29
  %t51 = load { i64, [3 x i64] }, ptr %l32
  %t52 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t53 = load { i64, ptr }, ptr %l34, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputRow(ptr %v0, ptr %s0, ptr %s2, ptr %v0, ptr %v0, ptr %t49, ptr %t50, { i64, [3 x i64] } %t51, { i64, ptr } { i64 5, ptr @.d18 }, { i64, ptr } %t52, { i64, ptr } %t53)
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l35, !tbaa !29
  %t55 = load ptr, ptr %l35, !tbaa !29
  %t56 = getelementptr %"compiler/diag:Diagnostics", ptr %t55, i32 0, i32 8
  store ptr %t56, ptr %l36, !tbaa !29
  %t57 = load ptr, ptr %l36, !tbaa !29
  store ptr %t57, ptr %l7, !tbaa !29
  store i64 0, ptr %l8, !tbaa !24
  br label %bb9
bb9:
  store %olang.scope zeroinitializer, ptr %s4
  %t58 = load ptr, ptr %l7, !tbaa !29
  store ptr %t58, ptr %l38, !tbaa !29
  %t59 = load i64, ptr %l8, !tbaa !24
  store i64 %t59, ptr %l39, !tbaa !24
  %t60 = load ptr, ptr %l38, !tbaa !29
  %t61 = load i64, ptr %l39, !tbaa !24
  %t62 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eRunFrom_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %t60, i64 %t61)
  %t63 = extractvalue { i32, { i64, ptr } } %t62, 1
  %t64 = extractvalue { i32, { i64, ptr } } %t62, 0
  store i32 %t64, ptr %l41
  %t65 = icmp ne i32 %t64, 0
  br i1 %t65, label %bb11, label %ok.66
ok.66:
  store { i64, ptr } %t63, ptr %l40
  br label %bb10
bb10:
  %t67 = load { i64, ptr }, ptr %l40, !tbaa !27
  store { i64, ptr } %t67, ptr %l37, !tbaa !27
  br label %bb15
bb11:
  %t68 = load i32, ptr %l41, !tbaa !23
  %t69 = ashr i32 %t68, 16
  store i32 %t69, ptr %l42, !tbaa !23
  %t70 = load i32, ptr %l42, !tbaa !23
  %t71 = icmp eq i32 %t70, 1
  store i1 %t71, ptr %l43, !tbaa !21
  %t72 = load i1, ptr %l43, !tbaa !21
  br i1 %t72, label %bb12, label %bb13
bb12:
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c19)
  unreachable
bb14:
  call void @__olang_scope_close(ptr %s4)
  br label %bb27
bb15:
  %t73 = load { i64, ptr }, ptr %l37, !tbaa !27
  store { i64, ptr } %t73, ptr %l9, !tbaa !27
  %t74 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t74, ptr %l44, !tbaa !27
  %t75 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  store i64 %t76, ptr %l45, !tbaa !24
  %t77 = load i64, ptr %l45, !tbaa !24
  store i64 %t77, ptr %l10, !tbaa !24
  store i64 0, ptr %l11, !tbaa !24
  br label %bb16
bb16:
  store %olang.scope zeroinitializer, ptr %s5
  %t78 = load i64, ptr %l11, !tbaa !24
  store i64 %t78, ptr %l46, !tbaa !24
  %t79 = load i64, ptr %l10, !tbaa !24
  store i64 %t79, ptr %l47, !tbaa !24
  %t80 = load i64, ptr %l46, !tbaa !24
  %t81 = load i64, ptr %l47, !tbaa !24
  %t82 = icmp slt i64 %t80, %t81
  store i1 %t82, ptr %l48, !tbaa !21
  %t83 = load i1, ptr %l48, !tbaa !21
  %t84 = xor i1 %t83, true
  store i1 %t84, ptr %l49, !tbaa !21
  %t85 = load i1, ptr %l49, !tbaa !21
  br i1 %t85, label %bb17, label %bb18
bb17:
  call void @__olang_scope_close(ptr %s5)
  br label %bb25
bb18:
  br label %bb19
bb19:
  %t86 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t86, ptr %l50, !tbaa !27
  %t87 = load i64, ptr %l11, !tbaa !24
  store i64 %t87, ptr %l51, !tbaa !24
  %t88 = load i64, ptr %l51, !tbaa !24
  %t89 = getelementptr { i64, ptr }, ptr %l50, i32 0, i32 1
  %t90 = load ptr, ptr %t89, !tbaa !27
  %t91 = getelementptr %"compiler/diag:note", ptr %t90, i64 %t88
  %t92 = load %"compiler/diag:note", ptr %t91
  store %"compiler/diag:note" %t92, ptr %l52
  %t93 = load %"compiler/diag:note", ptr %l52
  store %"compiler/diag:note" %t93, ptr %l12
  %t94 = getelementptr %"compiler/diag:note", ptr %l12, i32 0, i32 0
  %t95 = load i64, ptr %t94, !tbaa !24
  store i64 %t95, ptr %l53, !tbaa !24
  %t96 = load i64, ptr %l5, !tbaa !24
  store i64 %t96, ptr %l54, !tbaa !24
  %t97 = load i64, ptr %l53, !tbaa !24
  %t98 = load i64, ptr %l54, !tbaa !24
  %t99 = icmp eq i64 %t97, %t98
  store i1 %t99, ptr %l55, !tbaa !21
  %t100 = load i1, ptr %l55, !tbaa !21
  br i1 %t100, label %bb20, label %bb21
bb20:
  store %olang.scope zeroinitializer, ptr %s6
  %t101 = load ptr, ptr %l0, !tbaa !29
  store ptr %t101, ptr %l56, !tbaa !29
  store ptr %l1, ptr %l57, !tbaa !29
  %t102 = getelementptr %"compiler/diag:note", ptr %l12, i32 0, i32 1
  %t103 = load { i64, [3 x i64] }, ptr %t102
  store { i64, [3 x i64] } %t103, ptr %l58
  %t104 = getelementptr %"compiler/diag:note", ptr %l12, i32 0, i32 2
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l59, !tbaa !27
  %t106 = load ptr, ptr %l56, !tbaa !29
  %t107 = load ptr, ptr %l57, !tbaa !29
  %t108 = load { i64, [3 x i64] }, ptr %l58
  %t109 = load { i64, ptr }, ptr %l59, !tbaa !27
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputRow(ptr %v0, ptr %s0, ptr %s6, ptr %s6, ptr %v0, ptr %t106, ptr %t107, { i64, [3 x i64] } %t108, { i64, ptr } { i64 4, ptr @.d20 }, { i64, ptr } { i64 0, ptr @.d21 }, { i64, ptr } %t109)
  br label %bb22
bb21:
  br label %bb23
bb22:
  call void @__olang_scope_close(ptr %s6)
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s5)
  br label %bb24
bb24:
  store %olang.scope zeroinitializer, ptr %s7
  %t110 = load i64, ptr %l11, !tbaa !24
  store i64 %t110, ptr %l60, !tbaa !24
  %t111 = load i64, ptr %l60, !tbaa !24
  %t112 = add i64 %t111, 1
  store i64 %t112, ptr %l61, !tbaa !24
  %t113 = load i64, ptr %l61, !tbaa !24
  store i64 %t113, ptr %l11, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb16
bb25:
  %t114 = load i64, ptr %l8, !tbaa !24
  store i64 %t114, ptr %l62, !tbaa !24
  %t115 = load i64, ptr %l10, !tbaa !24
  store i64 %t115, ptr %l63, !tbaa !24
  %t116 = load i64, ptr %l62, !tbaa !24
  %t117 = load i64, ptr %l63, !tbaa !24
  %t118 = add i64 %t116, %t117
  store i64 %t118, ptr %l64, !tbaa !24
  %t119 = load i64, ptr %l64, !tbaa !24
  store i64 %t119, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb26
bb26:
  br label %bb9
bb27:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  br label %bb28
bb28:
  store %olang.scope zeroinitializer, ptr %s8
  %t120 = load i64, ptr %l3, !tbaa !24
  store i64 %t120, ptr %l65, !tbaa !24
  %t121 = load i64, ptr %l65, !tbaa !24
  %t122 = add i64 %t121, 1
  store i64 %t122, ptr %l66, !tbaa !24
  %t123 = load i64, ptr %l66, !tbaa !24
  store i64 %t123, ptr %l3, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb3
bb29:
  call void @__olang_scope_close(ptr %s1)
  %t124 = load ptr, ptr %l0, !tbaa !29
  store ptr %t124, ptr %l67, !tbaa !29
  %t125 = load ptr, ptr %l67, !tbaa !29
  %t126 = getelementptr %"compiler/diag:Diagnostics", ptr %t125, i32 0, i32 19
  %t127 = load i1, ptr %t126, !tbaa !21
  store i1 %t127, ptr %l68, !tbaa !21
  %t128 = load i1, ptr %l68, !tbaa !21
  br i1 %t128, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s9
  %t129 = load ptr, ptr %l0, !tbaa !29
  store ptr %t129, ptr %l69, !tbaa !29
  store ptr %l1, ptr %l70, !tbaa !29
  %t130 = load ptr, ptr %l0, !tbaa !29
  store ptr %t130, ptr %l71, !tbaa !29
  %t131 = load ptr, ptr %l71, !tbaa !29
  %t132 = getelementptr %"compiler/diag:Diagnostics", ptr %t131, i32 0, i32 16
  %t133 = load { i64, [3 x i64] }, ptr %t132
  store { i64, [3 x i64] } %t133, ptr %l72
  %t134 = load ptr, ptr %l69, !tbaa !29
  %t135 = load ptr, ptr %l70, !tbaa !29
  %t136 = load { i64, [3 x i64] }, ptr %l72
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputLocation(ptr %v0, ptr %s0, ptr %t134, ptr %t135, { i64, [3 x i64] } %t136)
  br label %bb32
bb31:
  br label %bb37
bb32:
  store ptr %l1, ptr %l73, !tbaa !29
  %t137 = load ptr, ptr %l0, !tbaa !29
  store ptr %t137, ptr %l74, !tbaa !29
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l75, !tbaa !29
  %t139 = load ptr, ptr %l75, !tbaa !29
  %t140 = getelementptr %"compiler/diag:Diagnostics", ptr %t139, i32 0, i32 17
  %t141 = load { i64, ptr }, ptr %t140, !tbaa !27
  store { i64, ptr } %t141, ptr %l76, !tbaa !27
  %t142 = load ptr, ptr %l74, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t144 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eerrorWord(ptr %v0, ptr %v0, ptr %s9, ptr %t142, { i64, ptr } %t143)
  store { i64, ptr } %t144, ptr %l77
  br label %bb33
bb33:
  %t145 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = mul i64 %t146, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t148)
  call void @llvm.memcpy.p0.p0.i64(ptr %t149, ptr %t147, i64 %t148, i1 false)
  %t150 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l78, !tbaa !27
  %t152 = load ptr, ptr %l73, !tbaa !29
  %t153 = load { i64, ptr }, ptr %l78, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s9, ptr %t152, { i64, ptr } %t153)
  br label %bb34
bb34:
  store ptr %l1, ptr %l79, !tbaa !29
  %t154 = load ptr, ptr %l0, !tbaa !29
  store ptr %t154, ptr %l80, !tbaa !29
  %t155 = load ptr, ptr %l80, !tbaa !29
  %t156 = getelementptr %"compiler/diag:Diagnostics", ptr %t155, i32 0, i32 18
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  store { i64, ptr } %t157, ptr %l81, !tbaa !27
  %t158 = load ptr, ptr %l79, !tbaa !29
  %t159 = load { i64, ptr }, ptr %l81, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v0, ptr %t158, { i64, ptr } %t159)
  br label %bb35
bb35:
  store ptr %l1, ptr %l82, !tbaa !29
  %t160 = load ptr, ptr %l82, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t160, i8 10)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s9)
  br label %bb37
bb37:
  store ptr %l1, ptr %l83, !tbaa !29
  %t161 = load ptr, ptr %l83, !tbaa !29
  %t162 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v1, ptr %t161)
  store { i64, ptr } %t162, ptr %l84
  br label %bb38
bb38:
  %t163 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t163, ptr %l85, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l86, !tbaa !24
  %t166 = load i64, ptr %l86, !tbaa !24
  %t167 = mul i64 %t166, 1
  %t168 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t167)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l87, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l87, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l85, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l86, !tbaa !24
  %t176 = mul i64 %t175, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t172, ptr %t174, i64 %t176, i1 false)
  %t177 = load { i64, ptr }, ptr %l87, !tbaa !27
  store { i64, ptr } %t177, ptr %l85, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t178 = load { i64, ptr }, ptr %l85, !tbaa !27
  store { i64, ptr } %t178, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eReopen(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca i64
  %s0 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 11
  store ptr %t3, ptr %l3, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l4, !tbaa !24
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t6 = load i64, ptr %l4, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t5, i64 %t6)
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eSummary(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca ptr
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca ptr
  %l7 = alloca { i64, ptr }
  %l8 = alloca ptr
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l11 = alloca ptr
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l2, !tbaa !29
  %t3 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %t2)
  store i64 %t3, ptr %l3
  br label %bb1
bb1:
  %t4 = load i64, ptr %l3, !tbaa !24
  store i64 %t4, ptr %l1, !tbaa !24
  %t5 = load i64, ptr %l1, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load i64, ptr %l4, !tbaa !24
  %t7 = icmp eq i64 %t6, 0
  store i1 %t7, ptr %l5, !tbaa !21
  %t8 = load i1, ptr %l5, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l6, !tbaa !29
  %t10 = load ptr, ptr %l6, !tbaa !29
  %t11 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t10, { i64, ptr } { i64 1, ptr @.d22 })
  store { i64, ptr } %t11, ptr %l7
  br label %bb4
bb3:
  br label %bb6
bb4:
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l8, !tbaa !29
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t13, { i64, ptr } { i64 1, ptr @.d23 })
  store { i64, ptr } %t14, ptr %l9
  br label %bb5
bb5:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = extractvalue { i64, ptr } %t15, 1
  %t17 = extractvalue { i64, ptr } %t15, 0
  call void @__olang_sb_put(ptr %s2, ptr %t16, i64 %t17)
  %t18 = extractvalue { i64, ptr } { i64 22, ptr @.d24 }, 1
  %t19 = extractvalue { i64, ptr } { i64 22, ptr @.d24 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t18, i64 %t19)
  %t20 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t21 = extractvalue { i64, ptr } %t20, 1
  %t22 = extractvalue { i64, ptr } %t20, 0
  call void @__olang_sb_put(ptr %s2, ptr %t21, i64 %t22)
  %t23 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t24 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t23, i64 %t24)
  %t25 = load ptr, ptr %s2
  %t26 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t27 = load i64, ptr %t26
  %t28 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t27)
  call void @llvm.memcpy.p0.p0.i64(ptr %t28, ptr %t25, i64 %t27, i1 false)
  %t29 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t30 = insertvalue { i64, ptr } %t29, ptr %t28, 1
  store { i64, ptr } %t30, ptr %l10, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t31 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t31, ptr %rv
  br label %ret
bb6:
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l11, !tbaa !29
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t33, { i64, ptr } { i64 4, ptr @.d26 })
  store { i64, ptr } %t34, ptr %l12
  br label %bb7
bb7:
  %t35 = load i64, ptr %l1, !tbaa !24
  store i64 %t35, ptr %l13, !tbaa !24
  %t36 = load i64, ptr %l1, !tbaa !24
  store i64 %t36, ptr %l14, !tbaa !24
  %t37 = load i64, ptr %l14, !tbaa !24
  %t38 = icmp eq i64 %t37, 1
  store i1 %t38, ptr %l15, !tbaa !21
  %t39 = load i1, ptr %l15, !tbaa !21
  br i1 %t39, label %bb8, label %bb9
bb8:
  store { i64, ptr } { i64 0, ptr @.d27 }, ptr %l16, !tbaa !27
  br label %bb10
bb9:
  store { i64, ptr } { i64 1, ptr @.d28 }, ptr %l16, !tbaa !27
  br label %bb10
bb10:
  %t40 = load ptr, ptr %l0, !tbaa !29
  store ptr %t40, ptr %l17, !tbaa !29
  %t41 = load ptr, ptr %l17, !tbaa !29
  %t42 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t41, { i64, ptr } { i64 1, ptr @.d29 })
  store { i64, ptr } %t42, ptr %l18
  br label %bb11
bb11:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t43 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t44 = extractvalue { i64, ptr } %t43, 1
  %t45 = extractvalue { i64, ptr } %t43, 0
  call void @__olang_sb_put(ptr %s3, ptr %t44, i64 %t45)
  %t46 = extractvalue { i64, ptr } { i64 24, ptr @.d30 }, 1
  %t47 = extractvalue { i64, ptr } { i64 24, ptr @.d30 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t46, i64 %t47)
  %t48 = load i64, ptr %l13, !tbaa !24
  %t49 = call ptr @__olang_sb_room(ptr %s3, i64 24)
  %t50 = call i64 @__olang_fmt_i64(ptr %t49, i64 %t48)
  call void @__olang_sb_add(ptr %s3, i64 %t50)
  %t51 = extractvalue { i64, ptr } { i64 6, ptr @.d31 }, 1
  %t52 = extractvalue { i64, ptr } { i64 6, ptr @.d31 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t51, i64 %t52)
  %t53 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t54 = extractvalue { i64, ptr } %t53, 1
  %t55 = extractvalue { i64, ptr } %t53, 0
  call void @__olang_sb_put(ptr %s3, ptr %t54, i64 %t55)
  %t56 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t57 = extractvalue { i64, ptr } %t56, 1
  %t58 = extractvalue { i64, ptr } %t56, 0
  call void @__olang_sb_put(ptr %s3, ptr %t57, i64 %t58)
  %t59 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 1
  %t60 = extractvalue { i64, ptr } { i64 1, ptr @.d32 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t59, i64 %t60)
  %t61 = load ptr, ptr %s3
  %t62 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t63 = load i64, ptr %t62
  %t64 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t61, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t63, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l19, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t67 = load { i64, ptr }, ptr %l19, !tbaa !27
  store { i64, ptr } %t67, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2echosen(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca ptr
  %l8 = alloca ptr
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca ptr
  %l15 = alloca ptr
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l1, !tbaa !24
  store i64 %t1, ptr %l3, !tbaa !24
  %t2 = load i64, ptr %l3, !tbaa !24
  store i64 %t2, ptr %l2, !tbaa !24
  br label %bb1
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t3 = load i64, ptr %l2, !tbaa !24
  store i64 %t3, ptr %l4, !tbaa !24
  %t4 = load i64, ptr %l4, !tbaa !24
  %t5 = icmp sge i64 %t4, 0
  store i1 %t5, ptr %l5, !tbaa !21
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  call void @__olang_scope_close(ptr %s1)
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t9 = load ptr, ptr %l0, !tbaa !29
  store ptr %t9, ptr %l7, !tbaa !29
  %t10 = load ptr, ptr %l7, !tbaa !29
  %t11 = getelementptr %"compiler/diag:Diagnostics", ptr %t10, i32 0, i32 10
  store ptr %t11, ptr %l8, !tbaa !29
  %t12 = load i64, ptr %l2, !tbaa !24
  store i64 %t12, ptr %l9, !tbaa !24
  %t13 = load ptr, ptr %l8, !tbaa !29
  %t14 = load i64, ptr %l9, !tbaa !24
  %t15 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t13, i64 %t14)
  store i64 %t15, ptr %l10
  br label %bb5
bb5:
  %t16 = load i64, ptr @G_2ecompiler_2fdiag_2eChosen, !tbaa !24
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i64, ptr %l10, !tbaa !24
  %t18 = load i64, ptr %l11, !tbaa !24
  %t19 = icmp ne i64 %t17, %t18
  store i1 %t19, ptr %l12, !tbaa !21
  %t20 = load i1, ptr %l12, !tbaa !21
  br i1 %t20, label %bb6, label %bb7
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  store i1 false, ptr %l13, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t21 = load i1, ptr %l13, !tbaa !21
  store i1 %t21, ptr %rv
  br label %ret
bb7:
  br label %bb8
bb8:
  %t22 = load ptr, ptr %l0, !tbaa !29
  store ptr %t22, ptr %l14, !tbaa !29
  %t23 = load ptr, ptr %l14, !tbaa !29
  %t24 = getelementptr %"compiler/diag:Diagnostics", ptr %t23, i32 0, i32 9
  store ptr %t24, ptr %l15, !tbaa !29
  %t25 = load i64, ptr %l2, !tbaa !24
  store i64 %t25, ptr %l16, !tbaa !24
  %t26 = load ptr, ptr %l15, !tbaa !29
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t26, i64 %t27)
  store i64 %t28, ptr %l17
  br label %bb9
bb9:
  %t29 = load i64, ptr %l17, !tbaa !24
  store i64 %t29, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  br label %bb1
bb11:
  store i1 true, ptr %l18, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t30 = load i1, ptr %l18, !tbaa !21
  store i1 %t30, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eerrorWord(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l7 = alloca ptr
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.builder
  %s2room = alloca [64 x i8], align 8
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t1, ptr %l2, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load i64, ptr %l3, !tbaa !24
  %t5 = icmp eq i64 %t4, 0
  store i1 %t5, ptr %l4, !tbaa !21
  %t6 = load i1, ptr %l4, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t7 = load ptr, ptr %l0, !tbaa !29
  store ptr %t7, ptr %l5, !tbaa !29
  %t8 = load ptr, ptr %l5, !tbaa !29
  %t9 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t8, { i64, ptr } { i64 4, ptr @.d33 })
  store { i64, ptr } %t9, ptr %l6
  br label %bb3
bb2:
  br label %bb5
bb3:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l7, !tbaa !29
  %t11 = load ptr, ptr %l7, !tbaa !29
  %t12 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s1, ptr %s1, ptr %t11, { i64, ptr } { i64 1, ptr @.d34 })
  store { i64, ptr } %t12, ptr %l8
  br label %bb4
bb4:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s2
  store ptr %s2room, ptr %s2
  %t13 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t14 = extractvalue { i64, ptr } %t13, 1
  %t15 = extractvalue { i64, ptr } %t13, 0
  call void @__olang_sb_put(ptr %s2, ptr %t14, i64 %t15)
  %t16 = extractvalue { i64, ptr } { i64 6, ptr @.d35 }, 1
  %t17 = extractvalue { i64, ptr } { i64 6, ptr @.d35 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t16, i64 %t17)
  %t18 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t19 = extractvalue { i64, ptr } %t18, 1
  %t20 = extractvalue { i64, ptr } %t18, 0
  call void @__olang_sb_put(ptr %s2, ptr %t19, i64 %t20)
  %t21 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 1
  %t22 = extractvalue { i64, ptr } { i64 1, ptr @.d36 }, 0
  call void @__olang_sb_put(ptr %s2, ptr %t21, i64 %t22)
  %t23 = load ptr, ptr %s2
  %t24 = getelementptr %olang.builder, ptr %s2, i32 0, i32 1
  %t25 = load i64, ptr %t24
  %t26 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t25)
  call void @llvm.memcpy.p0.p0.i64(ptr %t26, ptr %t23, i64 %t25, i1 false)
  %t27 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t28 = insertvalue { i64, ptr } %t27, ptr %t26, 1
  store { i64, ptr } %t28, ptr %l9, !tbaa !27
  call void @__olang_sb_done(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t29 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t29, ptr %rv
  br label %ret
bb5:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l10, !tbaa !29
  %t31 = load ptr, ptr %l10, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t31, { i64, ptr } { i64 4, ptr @.d37 })
  store { i64, ptr } %t32, ptr %l11
  br label %bb6
bb6:
  %t33 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t33, ptr %l12, !tbaa !27
  %t34 = load ptr, ptr %l0, !tbaa !29
  store ptr %t34, ptr %l13, !tbaa !29
  %t35 = load ptr, ptr %l13, !tbaa !29
  %t36 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t35, { i64, ptr } { i64 1, ptr @.d38 })
  store { i64, ptr } %t36, ptr %l14
  br label %bb7
bb7:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t37 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t37, 1
  %t39 = extractvalue { i64, ptr } %t37, 0
  call void @__olang_sb_put(ptr %s3, ptr %t38, i64 %t39)
  %t40 = extractvalue { i64, ptr } { i64 6, ptr @.d39 }, 1
  %t41 = extractvalue { i64, ptr } { i64 6, ptr @.d39 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t40, i64 %t41)
  %t42 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t42, 1
  %t44 = extractvalue { i64, ptr } %t42, 0
  call void @__olang_sb_put(ptr %s3, ptr %t43, i64 %t44)
  %t45 = extractvalue { i64, ptr } { i64 2, ptr @.d40 }, 1
  %t46 = extractvalue { i64, ptr } { i64 2, ptr @.d40 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t45, i64 %t46)
  %t47 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 1
  %t49 = extractvalue { i64, ptr } %t47, 0
  call void @__olang_sb_put(ptr %s3, ptr %t48, i64 %t49)
  %t50 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 1
  %t51 = extractvalue { i64, ptr } { i64 1, ptr @.d41 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t50, i64 %t51)
  %t52 = load ptr, ptr %s3
  %t53 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t54 = load i64, ptr %t53
  %t55 = call ptr @__olang_scope_alloc(ptr %v2, i64 %t54)
  call void @llvm.memcpy.p0.p0.i64(ptr %t55, ptr %t52, i64 %t54, i1 false)
  %t56 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t57 = insertvalue { i64, ptr } %t56, ptr %t55, 1
  store { i64, ptr } %t57, ptr %l15, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t58, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eisLibrary(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca { i64, [3 x i64] }
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca i1
  %l14 = alloca i64
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca i64
  %l18 = alloca i1
  %l19 = alloca { i64, [3 x i64] }
  %l20 = alloca i1
  %l21 = alloca i64
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca i1
  %l26 = alloca { i64, [3 x i64] }
  %l27 = alloca i1
  %l28 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t1, ptr %l5
  %t2 = load { i64, [3 x i64] }, ptr %l5
  %t3 = extractvalue { i64, [3 x i64] } %t2, 0
  %t4 = icmp eq i64 %t3, 1
  store i1 %t4, ptr %l6, !tbaa !21
  %t5 = load i1, ptr %l6, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t7 = getelementptr { i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l7, !tbaa !24
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %l2, !tbaa !24
  br label %bb3
bb2:
  br label %bb5
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = getelementptr %"compiler/diag:Diagnostics", ptr %t11, i32 0, i32 3
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load i64, ptr %l2, !tbaa !24
  store i64 %t13, ptr %l10, !tbaa !24
  %t14 = load ptr, ptr %l9, !tbaa !29
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t16, ptr %l11
  br label %bb4
bb4:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i1, ptr %l11, !tbaa !21
  store i1 %t17, ptr %rv
  br label %ret
bb5:
  %t18 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t18, ptr %l12
  %t19 = load { i64, [3 x i64] }, ptr %l12
  %t20 = extractvalue { i64, [3 x i64] } %t19, 0
  %t21 = icmp eq i64 %t20, 2
  store i1 %t21, ptr %l13, !tbaa !21
  %t22 = load i1, ptr %l13, !tbaa !21
  br i1 %t22, label %bb6, label %bb7
bb6:
  %t23 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t24 = getelementptr { i64, i64 }, ptr %t23, i32 0, i32 0
  %t25 = load i64, ptr %t24
  store i64 %t25, ptr %l14, !tbaa !24
  %t26 = load i64, ptr %l14, !tbaa !24
  store i64 %t26, ptr %l3, !tbaa !24
  br label %bb8
bb7:
  br label %bb10
bb8:
  store %olang.scope zeroinitializer, ptr %s2
  %t27 = load ptr, ptr %l0, !tbaa !29
  store ptr %t27, ptr %l15, !tbaa !29
  %t28 = load ptr, ptr %l15, !tbaa !29
  %t29 = getelementptr %"compiler/diag:Diagnostics", ptr %t28, i32 0, i32 3
  store ptr %t29, ptr %l16, !tbaa !29
  %t30 = load i64, ptr %l3, !tbaa !24
  store i64 %t30, ptr %l17, !tbaa !24
  %t31 = load ptr, ptr %l16, !tbaa !29
  %t32 = load i64, ptr %l17, !tbaa !24
  %t33 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t31, i64 %t32)
  store i1 %t33, ptr %l18
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i1, ptr %l18, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
bb10:
  %t35 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t35, ptr %l19
  %t36 = load { i64, [3 x i64] }, ptr %l19
  %t37 = extractvalue { i64, [3 x i64] } %t36, 0
  %t38 = icmp eq i64 %t37, 3
  store i1 %t38, ptr %l20, !tbaa !21
  %t39 = load i1, ptr %l20, !tbaa !21
  br i1 %t39, label %bb11, label %bb12
bb11:
  %t40 = getelementptr { i64, [3 x i64] }, ptr %l1, i32 0, i32 1
  %t41 = getelementptr { i64, i64, i64 }, ptr %t40, i32 0, i32 0
  %t42 = load i64, ptr %t41
  store i64 %t42, ptr %l21, !tbaa !24
  %t43 = load i64, ptr %l21, !tbaa !24
  store i64 %t43, ptr %l4, !tbaa !24
  br label %bb13
bb12:
  br label %bb15
bb13:
  store %olang.scope zeroinitializer, ptr %s3
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l22, !tbaa !29
  %t45 = load ptr, ptr %l22, !tbaa !29
  %t46 = getelementptr %"compiler/diag:Diagnostics", ptr %t45, i32 0, i32 3
  store ptr %t46, ptr %l23, !tbaa !29
  %t47 = load i64, ptr %l4, !tbaa !24
  store i64 %t47, ptr %l24, !tbaa !24
  %t48 = load ptr, ptr %l23, !tbaa !29
  %t49 = load i64, ptr %l24, !tbaa !24
  %t50 = call i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %t48, i64 %t49)
  store i1 %t50, ptr %l25
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t51 = load i1, ptr %l25, !tbaa !21
  store i1 %t51, ptr %rv
  br label %ret
bb15:
  %t52 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t52, ptr %l26
  %t53 = load { i64, [3 x i64] }, ptr %l26
  %t54 = extractvalue { i64, [3 x i64] } %t53, 0
  %t55 = icmp eq i64 %t54, 0
  store i1 %t55, ptr %l27, !tbaa !21
  %t56 = load i1, ptr %l27, !tbaa !21
  br i1 %t56, label %bb16, label %bb17
bb16:
  br label %bb18
bb17:
  br label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  store i1 false, ptr %l28, !tbaa !21
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i1, ptr %l28, !tbaa !21
  store i1 %t57, ptr %rv
  br label %ret
bb19:
  call void @__olang_check_failed(ptr @.c42)
  unreachable
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i32
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca ptr
  %l22 = alloca i64
  %l23 = alloca ptr
  %l24 = alloca ptr
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca i1
  %l35 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca ptr
  %l40 = alloca i32
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca ptr
  %l45 = alloca ptr
  %l46 = alloca i64
  %l47 = alloca { i64, ptr }
  %l48 = alloca i64
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca i1
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca ptr
  %l68 = alloca ptr
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca i64
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca { i64, i64 }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca { i64, i64 }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l12, !tbaa !29
  %t2 = load ptr, ptr %l12, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 5
  store ptr %t3, ptr %l13, !tbaa !29
  %t4 = load i64, ptr %l1, !tbaa !24
  store i64 %t4, ptr %l14, !tbaa !24
  %t5 = load ptr, ptr %l13, !tbaa !29
  %t6 = load i64, ptr %l14, !tbaa !24
  %t7 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t5, i64 %t6)
  store i64 %t7, ptr %l15
  br label %bb1
bb1:
  %t8 = load i64, ptr %l15, !tbaa !24
  %t9 = icmp slt i64 %t8, 0
  store i1 %t9, ptr %l16, !tbaa !21
  %t10 = load i1, ptr %l16, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l0, !tbaa !29
  store ptr %t11, ptr %l17, !tbaa !29
  %t12 = load ptr, ptr %l17, !tbaa !29
  %t13 = getelementptr %"compiler/diag:Diagnostics", ptr %t12, i32 0, i32 5
  store ptr %t13, ptr %l18, !tbaa !29
  %t14 = load i64, ptr %l1, !tbaa !24
  store i64 %t14, ptr %l19, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l20, !tbaa !29
  %t16 = load ptr, ptr %l20, !tbaa !29
  %t17 = getelementptr %"compiler/diag:Diagnostics", ptr %t16, i32 0, i32 4
  store ptr %t17, ptr %l21, !tbaa !29
  %t18 = load ptr, ptr %l21, !tbaa !29
  %t19 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t18)
  store i64 %t19, ptr %l22
  br label %bb4
bb3:
  br label %bb16
bb4:
  %t20 = load ptr, ptr %l18, !tbaa !29
  %t21 = load i64, ptr %l19, !tbaa !24
  %t22 = load i64, ptr %l22, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t20, i64 %t21, i64 %t22)
  br label %bb5
bb5:
  %t23 = load ptr, ptr %l0, !tbaa !29
  store ptr %t23, ptr %l23, !tbaa !29
  %t24 = load ptr, ptr %l23, !tbaa !29
  %t25 = getelementptr %"compiler/diag:Diagnostics", ptr %t24, i32 0, i32 2
  store ptr %t25, ptr %l24, !tbaa !29
  %t26 = load i64, ptr %l1, !tbaa !24
  store i64 %t26, ptr %l25, !tbaa !24
  %t27 = load ptr, ptr %l24, !tbaa !29
  %t28 = load i64, ptr %l25, !tbaa !24
  %t29 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t27, i64 %t28)
  store { i64, ptr } %t29, ptr %l26
  br label %bb6
bb6:
  %t30 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t31 = call { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v0, ptr %s1, { i64, ptr } %t30)
  store { i64, ptr } %t31, ptr %l27
  br label %bb7
bb7:
  %t32 = load { i64, ptr }, ptr %l27, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t33, ptr %l28, !tbaa !27
  %t34 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t34, ptr %l4, !tbaa !27
  store i64 0, ptr %l5, !tbaa !24
  %t35 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t35, ptr %l29, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l30, !tbaa !24
  %t38 = load i64, ptr %l30, !tbaa !24
  store i64 %t38, ptr %l6, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t39 = load i64, ptr %l5, !tbaa !24
  store i64 %t39, ptr %l31, !tbaa !24
  %t40 = load i64, ptr %l6, !tbaa !24
  store i64 %t40, ptr %l32, !tbaa !24
  %t41 = load i64, ptr %l31, !tbaa !24
  %t42 = load i64, ptr %l32, !tbaa !24
  %t43 = icmp slt i64 %t41, %t42
  store i1 %t43, ptr %l33, !tbaa !21
  %t44 = load i1, ptr %l33, !tbaa !21
  %t45 = xor i1 %t44, true
  store i1 %t45, ptr %l34, !tbaa !21
  %t46 = load i1, ptr %l34, !tbaa !21
  br i1 %t46, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s3)
  br label %bb14
bb10:
  br label %bb11
bb11:
  %t47 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t47, ptr %l35, !tbaa !27
  %t48 = load i64, ptr %l5, !tbaa !24
  store i64 %t48, ptr %l36, !tbaa !24
  %t49 = load i64, ptr %l36, !tbaa !24
  %t50 = getelementptr { i64, ptr }, ptr %l35, i32 0, i32 1
  %t51 = load ptr, ptr %t50, !tbaa !27
  %t52 = getelementptr i32, ptr %t51, i64 %t49
  %t53 = load i32, ptr %t52, !tbaa !33
  store i32 %t53, ptr %l37, !tbaa !23
  %t54 = load i32, ptr %l37, !tbaa !23
  store i32 %t54, ptr %l7, !tbaa !23
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l38, !tbaa !29
  %t56 = load ptr, ptr %l38, !tbaa !29
  %t57 = getelementptr %"compiler/diag:Diagnostics", ptr %t56, i32 0, i32 4
  store ptr %t57, ptr %l39, !tbaa !29
  %t58 = load i32, ptr %l7, !tbaa !23
  store i32 %t58, ptr %l40, !tbaa !23
  %t59 = load i32, ptr %l40, !tbaa !23
  %t60 = sext i32 %t59 to i64
  store i64 %t60, ptr %l41, !tbaa !24
  %t61 = load ptr, ptr %l39, !tbaa !29
  %t62 = load i64, ptr %l41, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %t61, i64 %t62)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb13
bb13:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = load i64, ptr %l5, !tbaa !24
  store i64 %t63, ptr %l42, !tbaa !24
  %t64 = load i64, ptr %l42, !tbaa !24
  %t65 = add i64 %t64, 1
  store i64 %t65, ptr %l43, !tbaa !24
  %t66 = load i64, ptr %l43, !tbaa !24
  store i64 %t66, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s4)
  br label %bb8
bb14:
  call void @__olang_scope_close(ptr %s2)
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l44, !tbaa !29
  %t68 = load ptr, ptr %l44, !tbaa !29
  %t69 = getelementptr %"compiler/diag:Diagnostics", ptr %t68, i32 0, i32 6
  store ptr %t69, ptr %l45, !tbaa !29
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l46, !tbaa !24
  %t71 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t71, ptr %l47, !tbaa !27
  %t72 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  store i64 %t73, ptr %l48, !tbaa !24
  %t74 = load ptr, ptr %l45, !tbaa !29
  %t75 = load i64, ptr %l46, !tbaa !24
  %t76 = load i64, ptr %l48, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %t74, i64 %t75, i64 %t76)
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s1)
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l0, !tbaa !29
  store ptr %t77, ptr %l49, !tbaa !29
  %t78 = load ptr, ptr %l49, !tbaa !29
  %t79 = getelementptr %"compiler/diag:Diagnostics", ptr %t78, i32 0, i32 5
  store ptr %t79, ptr %l50, !tbaa !29
  %t80 = load i64, ptr %l1, !tbaa !24
  store i64 %t80, ptr %l51, !tbaa !24
  %t81 = load ptr, ptr %l50, !tbaa !29
  %t82 = load i64, ptr %l51, !tbaa !24
  %t83 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t81, i64 %t82)
  store i64 %t83, ptr %l52
  br label %bb17
bb17:
  %t84 = load i64, ptr %l52, !tbaa !24
  store i64 %t84, ptr %l8, !tbaa !24
  store i64 0, ptr %l9, !tbaa !24
  %t85 = load ptr, ptr %l0, !tbaa !29
  store ptr %t85, ptr %l53, !tbaa !29
  %t86 = load ptr, ptr %l53, !tbaa !29
  %t87 = getelementptr %"compiler/diag:Diagnostics", ptr %t86, i32 0, i32 6
  store ptr %t87, ptr %l54, !tbaa !29
  %t88 = load i64, ptr %l1, !tbaa !24
  store i64 %t88, ptr %l55, !tbaa !24
  %t89 = load ptr, ptr %l54, !tbaa !29
  %t90 = load i64, ptr %l55, !tbaa !24
  %t91 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t89, i64 %t90)
  store i64 %t91, ptr %l56
  br label %bb18
bb18:
  %t92 = load i64, ptr %l56, !tbaa !24
  %t93 = sub i64 %t92, 1
  store i64 %t93, ptr %l57, !tbaa !24
  %t94 = load i64, ptr %l57, !tbaa !24
  store i64 %t94, ptr %l10, !tbaa !24
  br label %bb19
bb19:
  store %olang.scope zeroinitializer, ptr %s5
  %t95 = load i64, ptr %l9, !tbaa !24
  store i64 %t95, ptr %l58, !tbaa !24
  %t96 = load i64, ptr %l10, !tbaa !24
  store i64 %t96, ptr %l59, !tbaa !24
  %t97 = load i64, ptr %l58, !tbaa !24
  %t98 = load i64, ptr %l59, !tbaa !24
  %t99 = icmp slt i64 %t97, %t98
  store i1 %t99, ptr %l60, !tbaa !21
  %t100 = load i1, ptr %l60, !tbaa !21
  %t101 = xor i1 %t100, true
  store i1 %t101, ptr %l61, !tbaa !21
  %t102 = load i1, ptr %l61, !tbaa !21
  br i1 %t102, label %bb20, label %bb21
bb20:
  call void @__olang_scope_close(ptr %s5)
  br label %bb28
bb21:
  br label %bb22
bb22:
  %t103 = load i64, ptr %l9, !tbaa !24
  store i64 %t103, ptr %l62, !tbaa !24
  %t104 = load i64, ptr %l10, !tbaa !24
  store i64 %t104, ptr %l63, !tbaa !24
  %t105 = load i64, ptr %l62, !tbaa !24
  %t106 = load i64, ptr %l63, !tbaa !24
  %t107 = add i64 %t105, %t106
  store i64 %t107, ptr %l64, !tbaa !24
  %t108 = load i64, ptr %l64, !tbaa !24
  %t109 = add i64 %t108, 1
  store i64 %t109, ptr %l65, !tbaa !24
  %t110 = load i64, ptr %l65, !tbaa !24
  %t111 = sdiv i64 %t110, 2
  store i64 %t111, ptr %l66, !tbaa !24
  %t112 = load i64, ptr %l66, !tbaa !24
  store i64 %t112, ptr %l11, !tbaa !24
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l67, !tbaa !29
  %t114 = load ptr, ptr %l67, !tbaa !29
  %t115 = getelementptr %"compiler/diag:Diagnostics", ptr %t114, i32 0, i32 4
  store ptr %t115, ptr %l68, !tbaa !29
  %t116 = load i64, ptr %l8, !tbaa !24
  store i64 %t116, ptr %l69, !tbaa !24
  %t117 = load i64, ptr %l11, !tbaa !24
  store i64 %t117, ptr %l70, !tbaa !24
  %t118 = load i64, ptr %l69, !tbaa !24
  %t119 = load i64, ptr %l70, !tbaa !24
  %t120 = add i64 %t118, %t119
  store i64 %t120, ptr %l71, !tbaa !24
  %t121 = load ptr, ptr %l68, !tbaa !29
  %t122 = load i64, ptr %l71, !tbaa !24
  %t123 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t121, i64 %t122)
  store i64 %t123, ptr %l72
  br label %bb23
bb23:
  %t124 = load i64, ptr %l2, !tbaa !24
  store i64 %t124, ptr %l73, !tbaa !24
  %t125 = load i64, ptr %l72, !tbaa !24
  %t126 = load i64, ptr %l73, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  store i1 %t127, ptr %l74, !tbaa !21
  %t128 = load i1, ptr %l74, !tbaa !21
  br i1 %t128, label %bb24, label %bb25
bb24:
  store %olang.scope zeroinitializer, ptr %s6
  %t129 = load i64, ptr %l11, !tbaa !24
  store i64 %t129, ptr %l75, !tbaa !24
  %t130 = load i64, ptr %l75, !tbaa !24
  store i64 %t130, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s6)
  br label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s7
  %t131 = load i64, ptr %l11, !tbaa !24
  store i64 %t131, ptr %l76, !tbaa !24
  %t132 = load i64, ptr %l76, !tbaa !24
  %t133 = sub i64 %t132, 1
  store i64 %t133, ptr %l77, !tbaa !24
  %t134 = load i64, ptr %l77, !tbaa !24
  store i64 %t134, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb26
bb26:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb27:
  br label %bb19
bb28:
  %t135 = load i64, ptr %l9, !tbaa !24
  store i64 %t135, ptr %l78, !tbaa !24
  %t136 = load i64, ptr %l78, !tbaa !24
  %t137 = add i64 %t136, 1
  store i64 %t137, ptr %l79, !tbaa !24
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l80, !tbaa !29
  %t139 = load ptr, ptr %l80, !tbaa !29
  %t140 = getelementptr %"compiler/diag:Diagnostics", ptr %t139, i32 0, i32 4
  store ptr %t140, ptr %l81, !tbaa !29
  %t141 = load i64, ptr %l8, !tbaa !24
  store i64 %t141, ptr %l82, !tbaa !24
  %t142 = load i64, ptr %l9, !tbaa !24
  store i64 %t142, ptr %l83, !tbaa !24
  %t143 = load i64, ptr %l82, !tbaa !24
  %t144 = load i64, ptr %l83, !tbaa !24
  %t145 = add i64 %t143, %t144
  store i64 %t145, ptr %l84, !tbaa !24
  %t146 = load ptr, ptr %l81, !tbaa !29
  %t147 = load i64, ptr %l84, !tbaa !24
  %t148 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t146, i64 %t147)
  store i64 %t148, ptr %l85
  br label %bb29
bb29:
  %t149 = load i64, ptr %l79, !tbaa !24
  %t150 = insertvalue { i64, i64 } undef, i64 %t149, 0
  %t151 = load i64, ptr %l85, !tbaa !24
  %t152 = insertvalue { i64, i64 } %t150, i64 %t151, 1
  store { i64, i64 } %t152, ptr %l86
  call void @__olang_scope_close(ptr %s0)
  %t153 = load { i64, i64 }, ptr %l86
  store { i64, i64 } %t153, ptr %rv
  br label %ret
ret:
  %rr = load { i64, i64 }, ptr %rv
  ret { i64, i64 } %rr
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eprogramUse(ptr %v0, ptr %a0, { i64, [3 x i64] } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca i64
  %l3 = alloca ptr
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca i1
  %l6 = alloca i1
  %l7 = alloca i64
  %l8 = alloca ptr
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca ptr
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca ptr
  %l19 = alloca i64
  %l20 = alloca %"compiler/diag:context"
  %l21 = alloca { i64, ptr }
  %l22 = alloca i64
  %l23 = alloca i1
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca i64
  %l29 = alloca %"compiler/diag:context"
  %l30 = alloca { i64, [3 x i64] }
  %l31 = alloca i1
  %l32 = alloca i1
  %l33 = alloca i64
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t2, ptr %l4
  %t3 = load ptr, ptr %l3, !tbaa !29
  %t4 = load { i64, [3 x i64] }, ptr %l4
  %t5 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eisLibrary(ptr %v0, ptr %t3, { i64, [3 x i64] } %t4)
  store i1 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i1, ptr %l5, !tbaa !21
  %t7 = xor i1 %t6, true
  store i1 %t7, ptr %l6, !tbaa !21
  %t8 = load i1, ptr %l6, !tbaa !21
  br i1 %t8, label %bb2, label %bb3
bb2:
  store %olang.scope zeroinitializer, ptr %s1
  store i64 -1, ptr %l7, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t9 = load i64, ptr %l7, !tbaa !24
  store i64 %t9, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  store ptr %t10, ptr %l8, !tbaa !29
  %t11 = load ptr, ptr %l8, !tbaa !29
  %t12 = getelementptr %"compiler/diag:Diagnostics", ptr %t11, i32 0, i32 12
  store ptr %t12, ptr %l9, !tbaa !29
  %t13 = load ptr, ptr %l9, !tbaa !29
  %t14 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %t13)
  store i64 %t14, ptr %l10
  br label %bb5
bb5:
  %t15 = load i64, ptr %l10, !tbaa !24
  %t16 = sub i64 %t15, 1
  store i64 %t16, ptr %l11, !tbaa !24
  %t17 = load i64, ptr %l11, !tbaa !24
  store i64 %t17, ptr %l2, !tbaa !24
  br label %bb6
bb6:
  store %olang.scope zeroinitializer, ptr %s2
  %t18 = load i64, ptr %l2, !tbaa !24
  store i64 %t18, ptr %l12, !tbaa !24
  %t19 = load ptr, ptr %l0, !tbaa !29
  store ptr %t19, ptr %l13, !tbaa !29
  %t20 = load ptr, ptr %l13, !tbaa !29
  %t21 = getelementptr %"compiler/diag:Diagnostics", ptr %t20, i32 0, i32 13
  %t22 = load i64, ptr %t21, !tbaa !24
  store i64 %t22, ptr %l14, !tbaa !24
  %t23 = load i64, ptr %l12, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = icmp sge i64 %t23, %t24
  store i1 %t25, ptr %l15, !tbaa !21
  %t26 = load i1, ptr %l15, !tbaa !21
  %t27 = xor i1 %t26, true
  store i1 %t27, ptr %l16, !tbaa !21
  %t28 = load i1, ptr %l16, !tbaa !21
  br i1 %t28, label %bb7, label %bb8
bb7:
  call void @__olang_scope_close(ptr %s2)
  br label %bb20
bb8:
  br label %bb9
bb9:
  %t29 = load ptr, ptr %l0, !tbaa !29
  store ptr %t29, ptr %l17, !tbaa !29
  %t30 = load ptr, ptr %l17, !tbaa !29
  %t31 = getelementptr %"compiler/diag:Diagnostics", ptr %t30, i32 0, i32 12
  store ptr %t31, ptr %l18, !tbaa !29
  %t32 = load i64, ptr %l2, !tbaa !24
  store i64 %t32, ptr %l19, !tbaa !24
  %t33 = load ptr, ptr %l18, !tbaa !29
  %t34 = load i64, ptr %l19, !tbaa !24
  %t35 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t33, i64 %t34)
  store %"compiler/diag:context" %t35, ptr %l20
  br label %bb10
bb10:
  %t36 = getelementptr %"compiler/diag:context", ptr %l20, i32 0, i32 1
  %t37 = load { i64, ptr }, ptr %t36, !tbaa !27
  store { i64, ptr } %t37, ptr %l21, !tbaa !27
  %t38 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l22, !tbaa !24
  %t40 = load i64, ptr %l22, !tbaa !24
  %t41 = icmp sgt i64 %t40, 0
  store i1 %t41, ptr %l23, !tbaa !21
  %t42 = load i1, ptr %l23, !tbaa !21
  br i1 %t42, label %bb11, label %bb12
bb11:
  %t43 = load ptr, ptr %l0, !tbaa !29
  store ptr %t43, ptr %l25, !tbaa !29
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l26, !tbaa !29
  %t45 = load ptr, ptr %l26, !tbaa !29
  %t46 = getelementptr %"compiler/diag:Diagnostics", ptr %t45, i32 0, i32 12
  store ptr %t46, ptr %l27, !tbaa !29
  %t47 = load i64, ptr %l2, !tbaa !24
  store i64 %t47, ptr %l28, !tbaa !24
  %t48 = load ptr, ptr %l27, !tbaa !29
  %t49 = load i64, ptr %l28, !tbaa !24
  %t50 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t48, i64 %t49)
  store %"compiler/diag:context" %t50, ptr %l29
  br label %bb13
bb12:
  store i1 false, ptr %l24, !tbaa !21
  br label %bb15
bb13:
  %t51 = getelementptr %"compiler/diag:context", ptr %l29, i32 0, i32 0
  %t52 = load { i64, [3 x i64] }, ptr %t51
  store { i64, [3 x i64] } %t52, ptr %l30
  %t53 = load ptr, ptr %l25, !tbaa !29
  %t54 = load { i64, [3 x i64] }, ptr %l30
  %t55 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eisLibrary(ptr %v0, ptr %t53, { i64, [3 x i64] } %t54)
  store i1 %t55, ptr %l31
  br label %bb14
bb14:
  %t56 = load i1, ptr %l31, !tbaa !21
  %t57 = xor i1 %t56, true
  store i1 %t57, ptr %l32, !tbaa !21
  %t58 = load i1, ptr %l32, !tbaa !21
  store i1 %t58, ptr %l24, !tbaa !21
  br label %bb15
bb15:
  %t59 = load i1, ptr %l24, !tbaa !21
  br i1 %t59, label %bb16, label %bb17
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t60 = load i64, ptr %l2, !tbaa !24
  store i64 %t60, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t61 = load i64, ptr %l33, !tbaa !24
  store i64 %t61, ptr %rv
  br label %ret
bb17:
  br label %bb18
bb18:
  %t62 = load i64, ptr %l2, !tbaa !24
  store i64 %t62, ptr %l34, !tbaa !24
  %t63 = load i64, ptr %l34, !tbaa !24
  %t64 = sub i64 %t63, 1
  store i64 %t64, ptr %l35, !tbaa !24
  %t65 = load i64, ptr %l35, !tbaa !24
  store i64 %t65, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb19
bb19:
  br label %bb6
bb20:
  store i64 -1, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t66 = load i64, ptr %l36, !tbaa !24
  store i64 %t66, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputExcerpt(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [3 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca { i64, i64 }
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i1
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca i64
  %l25 = alloca i64
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i64
  %l31 = alloca i64
  %l32 = alloca { i64, [3 x i64] }
  %l33 = alloca i1
  %l34 = alloca i64
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca i64
  %l39 = alloca i64
  %l40 = alloca ptr
  %l41 = alloca ptr
  %l42 = alloca i64
  %l43 = alloca { i64, ptr }
  %l44 = alloca ptr
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca { i64, i64 }
  %l48 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i1
  %l55 = alloca i1
  %l56 = alloca { i64, ptr }
  %l57 = alloca i64
  %l58 = alloca i8
  %l59 = alloca i1
  %l60 = alloca i1
  %l61 = alloca i64
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i1
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i1
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i64
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca i64
  %l81 = alloca i64
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca i64
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca { i64, ptr }
  %l90 = alloca i64
  %l91 = alloca i8
  %l92 = alloca i1
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca i8
  %l97 = alloca i1
  %l98 = alloca i1
  %l99 = alloca { i64, ptr }
  %l100 = alloca i64
  %l101 = alloca i8
  %l102 = alloca i1
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i64
  %l107 = alloca i64
  %l108 = alloca i1
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca i64
  %l115 = alloca i64
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i64
  %l121 = alloca i64
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i1
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i64
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i1
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i64
  %l136 = alloca i64
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i64
  %l140 = alloca i64
  %l141 = alloca i64
  %l142 = alloca i1
  %l143 = alloca i64
  %l144 = alloca ptr
  %l145 = alloca i64
  %l146 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l148 = alloca { i64, ptr }
  %l149 = alloca i64
  %l150 = alloca i64
  %l151 = alloca i1
  %l152 = alloca ptr
  %l153 = alloca i64
  %l154 = alloca i64
  %l155 = alloca i64
  %l156 = alloca i64
  %l157 = alloca i1
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i1
  %l161 = alloca i64
  %l162 = alloca i64
  %l163 = alloca i64
  %l164 = alloca i64
  %l165 = alloca i64
  %l166 = alloca i64
  %l167 = alloca i64
  %l168 = alloca i64
  %l169 = alloca i64
  %l170 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i1
  %l173 = alloca i1
  %l174 = alloca i64
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i64
  %l179 = alloca ptr
  %l180 = alloca { i64, ptr }
  %l181 = alloca i64
  %l182 = alloca i8
  %l183 = alloca i8
  %l184 = alloca i64
  %l185 = alloca i64
  %l186 = alloca i64
  %l187 = alloca i64
  %l188 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca ptr
  %l191 = alloca i64
  %l192 = alloca i64
  %l193 = alloca i1
  %l194 = alloca ptr
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca i64
  %l198 = alloca i1
  %l199 = alloca i1
  %l200 = alloca i64
  %l201 = alloca i64
  %l202 = alloca i1
  %l203 = alloca i1
  %l204 = alloca { i64, ptr }
  %l205 = alloca i64
  %l206 = alloca i8
  %l207 = alloca i1
  %l208 = alloca i1
  %l209 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l211 = alloca i64
  %l212 = alloca i8
  %l213 = alloca i1
  %l214 = alloca i8
  %l215 = alloca i64
  %l216 = alloca i64
  %l217 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l221 = alloca ptr
  %l222 = alloca i64
  %l223 = alloca i64
  %l224 = alloca i64
  %l225 = alloca i64
  %l226 = alloca i1
  %l227 = alloca i1
  %l228 = alloca i64
  %l229 = alloca i64
  %l230 = alloca i1
  %l231 = alloca i1
  %l232 = alloca { i64, ptr }
  %l233 = alloca i64
  %l234 = alloca i8
  %l235 = alloca i1
  %l236 = alloca i1
  %l237 = alloca ptr
  %l238 = alloca i64
  %l239 = alloca i64
  %l240 = alloca ptr
  %l241 = alloca ptr
  %l242 = alloca { i64, ptr }
  %l243 = alloca { i64, ptr }
  %l244 = alloca ptr
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.builder
  %s12room = alloca [64 x i8], align 8
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %s22 = alloca %olang.scope
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i64 0, ptr %l3, !tbaa !24
  store i64 0, ptr %l4, !tbaa !24
  store i64 0, ptr %l5, !tbaa !24
  %t1 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t1, ptr %l32
  %t2 = load { i64, [3 x i64] }, ptr %l32
  %t3 = extractvalue { i64, [3 x i64] } %t2, 0
  %t4 = icmp eq i64 %t3, 3
  store i1 %t4, ptr %l33, !tbaa !21
  %t5 = load i1, ptr %l33, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t7 = getelementptr { i64, i64, i64 }, ptr %t6, i32 0, i32 0
  %t8 = load i64, ptr %t7
  store i64 %t8, ptr %l34, !tbaa !24
  %t9 = load i64, ptr %l34, !tbaa !24
  store i64 %t9, ptr %l6, !tbaa !24
  %t10 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t11 = getelementptr { i64, i64, i64 }, ptr %t10, i32 0, i32 1
  %t12 = load i64, ptr %t11
  store i64 %t12, ptr %l35, !tbaa !24
  %t13 = load i64, ptr %l35, !tbaa !24
  store i64 %t13, ptr %l7, !tbaa !24
  %t14 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t15 = getelementptr { i64, i64, i64 }, ptr %t14, i32 0, i32 2
  %t16 = load i64, ptr %t15
  store i64 %t16, ptr %l36, !tbaa !24
  %t17 = load i64, ptr %l36, !tbaa !24
  store i64 %t17, ptr %l8, !tbaa !24
  br label %bb3
bb2:
  br label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t18 = load i64, ptr %l6, !tbaa !24
  store i64 %t18, ptr %l37, !tbaa !24
  %t19 = load i64, ptr %l37, !tbaa !24
  store i64 %t19, ptr %l3, !tbaa !24
  %t20 = load i64, ptr %l7, !tbaa !24
  store i64 %t20, ptr %l38, !tbaa !24
  %t21 = load i64, ptr %l38, !tbaa !24
  store i64 %t21, ptr %l4, !tbaa !24
  %t22 = load i64, ptr %l8, !tbaa !24
  store i64 %t22, ptr %l39, !tbaa !24
  %t23 = load i64, ptr %l39, !tbaa !24
  store i64 %t23, ptr %l5, !tbaa !24
  call void @__olang_scope_close(ptr %s1)
  br label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb5:
  %t24 = load ptr, ptr %l0, !tbaa !29
  store ptr %t24, ptr %l40, !tbaa !29
  %t25 = load ptr, ptr %l40, !tbaa !29
  %t26 = getelementptr %"compiler/diag:Diagnostics", ptr %t25, i32 0, i32 2
  store ptr %t26, ptr %l41, !tbaa !29
  %t27 = load i64, ptr %l3, !tbaa !24
  store i64 %t27, ptr %l42, !tbaa !24
  %t28 = load ptr, ptr %l41, !tbaa !29
  %t29 = load i64, ptr %l42, !tbaa !24
  %t30 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t28, i64 %t29)
  store { i64, ptr } %t30, ptr %l43
  br label %bb6
bb6:
  %t31 = load { i64, ptr }, ptr %l43, !tbaa !27
  store { i64, ptr } %t31, ptr %l9, !tbaa !27
  %t32 = load ptr, ptr %l0, !tbaa !29
  store ptr %t32, ptr %l44, !tbaa !29
  %t33 = load i64, ptr %l3, !tbaa !24
  store i64 %t33, ptr %l45, !tbaa !24
  %t34 = load i64, ptr %l4, !tbaa !24
  store i64 %t34, ptr %l46, !tbaa !24
  %t35 = load ptr, ptr %l44, !tbaa !29
  %t36 = load i64, ptr %l45, !tbaa !24
  %t37 = load i64, ptr %l46, !tbaa !24
  %t38 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t35, i64 %t36, i64 %t37)
  store { i64, i64 } %t38, ptr %l47
  br label %bb7
bb7:
  %t39 = load { i64, i64 }, ptr %l47
  store { i64, i64 } %t39, ptr %l10
  %t40 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 0
  %t41 = load i64, ptr %t40, !tbaa !24
  store i64 %t41, ptr %l48, !tbaa !24
  %t42 = load i64, ptr %l48, !tbaa !24
  store i64 %t42, ptr %l11, !tbaa !24
  %t43 = getelementptr { i64, i64 }, ptr %l10, i32 0, i32 1
  %t44 = load i64, ptr %t43, !tbaa !24
  store i64 %t44, ptr %l49, !tbaa !24
  %t45 = load i64, ptr %l49, !tbaa !24
  store i64 %t45, ptr %l12, !tbaa !24
  %t46 = load i64, ptr %l4, !tbaa !24
  store i64 %t46, ptr %l50, !tbaa !24
  %t47 = load i64, ptr %l50, !tbaa !24
  store i64 %t47, ptr %l13, !tbaa !24
  br label %bb8
bb8:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load i64, ptr %l13, !tbaa !24
  store i64 %t48, ptr %l51, !tbaa !24
  %t49 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t49, ptr %l52, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t51 = extractvalue { i64, ptr } %t50, 0
  store i64 %t51, ptr %l53, !tbaa !24
  %t52 = load i64, ptr %l51, !tbaa !24
  %t53 = load i64, ptr %l53, !tbaa !24
  %t54 = icmp slt i64 %t52, %t53
  store i1 %t54, ptr %l54, !tbaa !21
  %t55 = load i1, ptr %l54, !tbaa !21
  br i1 %t55, label %bb9, label %bb10
bb9:
  %t56 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t56, ptr %l56, !tbaa !27
  %t57 = load i64, ptr %l13, !tbaa !24
  store i64 %t57, ptr %l57, !tbaa !24
  %t58 = load i64, ptr %l57, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l56, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr i8, ptr %t60, i64 %t58
  %t62 = load i8, ptr %t61, !tbaa !32
  store i8 %t62, ptr %l58, !tbaa !22
  %t63 = load i8, ptr %l58, !tbaa !22
  %t64 = icmp ne i8 %t63, 10
  store i1 %t64, ptr %l59, !tbaa !21
  %t65 = load i1, ptr %l59, !tbaa !21
  store i1 %t65, ptr %l55, !tbaa !21
  br label %bb11
bb10:
  store i1 false, ptr %l55, !tbaa !21
  br label %bb11
bb11:
  %t66 = load i1, ptr %l55, !tbaa !21
  %t67 = xor i1 %t66, true
  store i1 %t67, ptr %l60, !tbaa !21
  %t68 = load i1, ptr %l60, !tbaa !21
  br i1 %t68, label %bb12, label %bb13
bb12:
  call void @__olang_scope_close(ptr %s3)
  br label %bb16
bb13:
  br label %bb14
bb14:
  %t69 = load i64, ptr %l13, !tbaa !24
  store i64 %t69, ptr %l61, !tbaa !24
  %t70 = load i64, ptr %l61, !tbaa !24
  %t71 = add i64 %t70, 1
  store i64 %t71, ptr %l62, !tbaa !24
  %t72 = load i64, ptr %l62, !tbaa !24
  store i64 %t72, ptr %l13, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb15
bb15:
  br label %bb8
bb16:
  store i1 true, ptr %l14, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s4
  %t73 = load i64, ptr %l12, !tbaa !24
  store i64 %t73, ptr %l63, !tbaa !24
  %t74 = load i64, ptr %l63, !tbaa !24
  store i64 %t74, ptr %l15, !tbaa !24
  %t75 = load i64, ptr %l13, !tbaa !24
  store i64 %t75, ptr %l64, !tbaa !24
  %t76 = load i64, ptr %l64, !tbaa !24
  store i64 %t76, ptr %l16, !tbaa !24
  store i64 1, ptr %l17, !tbaa !24
  %t77 = load i64, ptr %l16, !tbaa !24
  store i64 %t77, ptr %l65, !tbaa !24
  %t78 = load i64, ptr %l15, !tbaa !24
  store i64 %t78, ptr %l66, !tbaa !24
  %t79 = load i64, ptr %l65, !tbaa !24
  %t80 = load i64, ptr %l66, !tbaa !24
  %t81 = icmp sgt i64 %t79, %t80
  store i1 %t81, ptr %l67, !tbaa !21
  %t82 = load i1, ptr %l67, !tbaa !21
  br i1 %t82, label %bb17, label %bb18
bb17:
  %t83 = load i64, ptr %l17, !tbaa !24
  store i64 %t83, ptr %l69, !tbaa !24
  %t84 = load i64, ptr %l69, !tbaa !24
  %t85 = icmp sgt i64 %t84, 0
  store i1 %t85, ptr %l70, !tbaa !21
  %t86 = load i1, ptr %l70, !tbaa !21
  br i1 %t86, label %bb19, label %bb20
bb18:
  store i64 0, ptr %l68, !tbaa !24
  br label %bb22
bb19:
  %t87 = load i64, ptr %l16, !tbaa !24
  store i64 %t87, ptr %l72, !tbaa !24
  %t88 = load i64, ptr %l15, !tbaa !24
  store i64 %t88, ptr %l73, !tbaa !24
  %t89 = load i64, ptr %l72, !tbaa !24
  %t90 = load i64, ptr %l73, !tbaa !24
  %t91 = sub i64 %t89, %t90
  store i64 %t91, ptr %l74, !tbaa !24
  %t92 = load i64, ptr %l17, !tbaa !24
  store i64 %t92, ptr %l75, !tbaa !24
  %t93 = load i64, ptr %l74, !tbaa !24
  %t94 = load i64, ptr %l75, !tbaa !24
  %t95 = add i64 %t93, %t94
  store i64 %t95, ptr %l76, !tbaa !24
  %t96 = load i64, ptr %l76, !tbaa !24
  %t97 = sub i64 %t96, 1
  store i64 %t97, ptr %l77, !tbaa !24
  %t98 = load i64, ptr %l17, !tbaa !24
  store i64 %t98, ptr %l78, !tbaa !24
  %t99 = load i64, ptr %l77, !tbaa !24
  %t100 = load i64, ptr %l78, !tbaa !24
  %t101 = sdiv i64 %t99, %t100
  store i64 %t101, ptr %l79, !tbaa !24
  %t102 = load i64, ptr %l79, !tbaa !24
  store i64 %t102, ptr %l71, !tbaa !24
  br label %bb21
bb20:
  store i64 0, ptr %l71, !tbaa !24
  br label %bb21
bb21:
  %t103 = load i64, ptr %l71, !tbaa !24
  store i64 %t103, ptr %l68, !tbaa !24
  br label %bb22
bb22:
  %t104 = load i64, ptr %l68, !tbaa !24
  store i64 %t104, ptr %l18, !tbaa !24
  store i64 0, ptr %l19, !tbaa !24
  br label %bb23
bb23:
  store %olang.scope zeroinitializer, ptr %s5
  %t105 = load i64, ptr %l19, !tbaa !24
  store i64 %t105, ptr %l80, !tbaa !24
  %t106 = load i64, ptr %l18, !tbaa !24
  store i64 %t106, ptr %l81, !tbaa !24
  %t107 = load i64, ptr %l80, !tbaa !24
  %t108 = load i64, ptr %l81, !tbaa !24
  %t109 = icmp slt i64 %t107, %t108
  store i1 %t109, ptr %l82, !tbaa !21
  %t110 = load i1, ptr %l82, !tbaa !21
  %t111 = xor i1 %t110, true
  store i1 %t111, ptr %l83, !tbaa !21
  %t112 = load i1, ptr %l83, !tbaa !21
  br i1 %t112, label %bb24, label %bb25
bb24:
  call void @__olang_scope_close(ptr %s5)
  br label %bb37
bb25:
  br label %bb26
bb26:
  %t113 = load i64, ptr %l15, !tbaa !24
  store i64 %t113, ptr %l84, !tbaa !24
  %t114 = load i64, ptr %l19, !tbaa !24
  store i64 %t114, ptr %l85, !tbaa !24
  %t115 = load i64, ptr %l17, !tbaa !24
  store i64 %t115, ptr %l86, !tbaa !24
  %t116 = load i64, ptr %l85, !tbaa !24
  %t117 = load i64, ptr %l86, !tbaa !24
  %t118 = mul i64 %t116, %t117
  store i64 %t118, ptr %l87, !tbaa !24
  %t119 = load i64, ptr %l84, !tbaa !24
  %t120 = load i64, ptr %l87, !tbaa !24
  %t121 = add i64 %t119, %t120
  store i64 %t121, ptr %l88, !tbaa !24
  %t122 = load i64, ptr %l88, !tbaa !24
  store i64 %t122, ptr %l20, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t123, ptr %l89, !tbaa !27
  %t124 = load i64, ptr %l20, !tbaa !24
  store i64 %t124, ptr %l90, !tbaa !24
  %t125 = load i64, ptr %l90, !tbaa !24
  %t126 = getelementptr { i64, ptr }, ptr %l89, i32 0, i32 1
  %t127 = load ptr, ptr %t126, !tbaa !27
  %t128 = getelementptr i8, ptr %t127, i64 %t125
  %t129 = load i8, ptr %t128, !tbaa !32
  store i8 %t129, ptr %l91, !tbaa !22
  %t130 = load i8, ptr %l91, !tbaa !22
  %t131 = icmp ne i8 %t130, 32
  store i1 %t131, ptr %l92, !tbaa !21
  %t132 = load i1, ptr %l92, !tbaa !21
  br i1 %t132, label %bb27, label %bb28
bb27:
  %t133 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t133, ptr %l94, !tbaa !27
  %t134 = load i64, ptr %l20, !tbaa !24
  store i64 %t134, ptr %l95, !tbaa !24
  %t135 = load i64, ptr %l95, !tbaa !24
  %t136 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t137 = load ptr, ptr %t136, !tbaa !27
  %t138 = getelementptr i8, ptr %t137, i64 %t135
  %t139 = load i8, ptr %t138, !tbaa !32
  store i8 %t139, ptr %l96, !tbaa !22
  %t140 = load i8, ptr %l96, !tbaa !22
  %t141 = icmp ne i8 %t140, 9
  store i1 %t141, ptr %l97, !tbaa !21
  %t142 = load i1, ptr %l97, !tbaa !21
  store i1 %t142, ptr %l93, !tbaa !21
  br label %bb29
bb28:
  store i1 false, ptr %l93, !tbaa !21
  br label %bb29
bb29:
  %t143 = load i1, ptr %l93, !tbaa !21
  br i1 %t143, label %bb30, label %bb31
bb30:
  %t144 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t144, ptr %l99, !tbaa !27
  %t145 = load i64, ptr %l20, !tbaa !24
  store i64 %t145, ptr %l100, !tbaa !24
  %t146 = load i64, ptr %l100, !tbaa !24
  %t147 = getelementptr { i64, ptr }, ptr %l99, i32 0, i32 1
  %t148 = load ptr, ptr %t147, !tbaa !27
  %t149 = getelementptr i8, ptr %t148, i64 %t146
  %t150 = load i8, ptr %t149, !tbaa !32
  store i8 %t150, ptr %l101, !tbaa !22
  %t151 = load i8, ptr %l101, !tbaa !22
  %t152 = icmp ne i8 %t151, 13
  store i1 %t152, ptr %l102, !tbaa !21
  %t153 = load i1, ptr %l102, !tbaa !21
  store i1 %t153, ptr %l98, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l98, !tbaa !21
  br label %bb32
bb32:
  %t154 = load i1, ptr %l98, !tbaa !21
  br i1 %t154, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  store i1 false, ptr %l14, !tbaa !21
  call void @__olang_scope_close(ptr %s6)
  br label %bb35
bb34:
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s5)
  br label %bb36
bb36:
  store %olang.scope zeroinitializer, ptr %s7
  %t155 = load i64, ptr %l19, !tbaa !24
  store i64 %t155, ptr %l103, !tbaa !24
  %t156 = load i64, ptr %l103, !tbaa !24
  %t157 = add i64 %t156, 1
  store i64 %t157, ptr %l104, !tbaa !24
  %t158 = load i64, ptr %l104, !tbaa !24
  store i64 %t158, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s7)
  br label %bb23
bb37:
  call void @__olang_scope_close(ptr %s4)
  %t159 = load i1, ptr %l14, !tbaa !21
  store i1 %t159, ptr %l105, !tbaa !21
  %t160 = load i1, ptr %l105, !tbaa !21
  br i1 %t160, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  br label %ret
bb39:
  br label %bb40
bb40:
  %t161 = load i64, ptr %l5, !tbaa !24
  store i64 %t161, ptr %l106, !tbaa !24
  %t162 = load i64, ptr %l4, !tbaa !24
  store i64 %t162, ptr %l107, !tbaa !24
  %t163 = load i64, ptr %l106, !tbaa !24
  %t164 = load i64, ptr %l107, !tbaa !24
  %t165 = icmp sgt i64 %t163, %t164
  store i1 %t165, ptr %l108, !tbaa !21
  %t166 = load i1, ptr %l108, !tbaa !21
  br i1 %t166, label %bb41, label %bb42
bb41:
  %t167 = load i64, ptr %l5, !tbaa !24
  store i64 %t167, ptr %l110, !tbaa !24
  %t168 = load i64, ptr %l110, !tbaa !24
  store i64 %t168, ptr %l109, !tbaa !24
  br label %bb43
bb42:
  %t169 = load i64, ptr %l4, !tbaa !24
  store i64 %t169, ptr %l111, !tbaa !24
  %t170 = load i64, ptr %l111, !tbaa !24
  %t171 = add i64 %t170, 1
  store i64 %t171, ptr %l112, !tbaa !24
  %t172 = load i64, ptr %l112, !tbaa !24
  store i64 %t172, ptr %l109, !tbaa !24
  br label %bb43
bb43:
  %t173 = load i64, ptr %l109, !tbaa !24
  store i64 %t173, ptr %l21, !tbaa !24
  %t174 = load i64, ptr %l12, !tbaa !24
  store i64 %t174, ptr %l113, !tbaa !24
  %t175 = load i64, ptr %l113, !tbaa !24
  store i64 %t175, ptr %l22, !tbaa !24
  %t176 = load i64, ptr %l13, !tbaa !24
  store i64 %t176, ptr %l114, !tbaa !24
  %t177 = load i64, ptr %l114, !tbaa !24
  store i64 %t177, ptr %l23, !tbaa !24
  %t178 = load i64, ptr %l13, !tbaa !24
  store i64 %t178, ptr %l115, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  store i64 %t179, ptr %l116, !tbaa !24
  %t180 = load i64, ptr %l115, !tbaa !24
  %t181 = load i64, ptr %l116, !tbaa !24
  %t182 = sub i64 %t180, %t181
  store i64 %t182, ptr %l117, !tbaa !24
  %t183 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptMax, !tbaa !24
  store i64 %t183, ptr %l118, !tbaa !24
  %t184 = load i64, ptr %l117, !tbaa !24
  %t185 = load i64, ptr %l118, !tbaa !24
  %t186 = icmp sgt i64 %t184, %t185
  store i1 %t186, ptr %l119, !tbaa !21
  %t187 = load i1, ptr %l119, !tbaa !21
  br i1 %t187, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t188 = load i64, ptr %l4, !tbaa !24
  store i64 %t188, ptr %l120, !tbaa !24
  %t189 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  store i64 %t189, ptr %l121, !tbaa !24
  %t190 = load i64, ptr %l120, !tbaa !24
  %t191 = load i64, ptr %l121, !tbaa !24
  %t192 = sub i64 %t190, %t191
  store i64 %t192, ptr %l122, !tbaa !24
  %t193 = load i64, ptr %l22, !tbaa !24
  store i64 %t193, ptr %l123, !tbaa !24
  %t194 = load i64, ptr %l122, !tbaa !24
  %t195 = load i64, ptr %l123, !tbaa !24
  %t196 = icmp sgt i64 %t194, %t195
  store i1 %t196, ptr %l124, !tbaa !21
  %t197 = load i1, ptr %l124, !tbaa !21
  br i1 %t197, label %bb46, label %bb47
bb45:
  br label %bb55
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t198 = load i64, ptr %l4, !tbaa !24
  store i64 %t198, ptr %l125, !tbaa !24
  %t199 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  store i64 %t199, ptr %l126, !tbaa !24
  %t200 = load i64, ptr %l125, !tbaa !24
  %t201 = load i64, ptr %l126, !tbaa !24
  %t202 = sub i64 %t200, %t201
  store i64 %t202, ptr %l127, !tbaa !24
  %t203 = load i64, ptr %l127, !tbaa !24
  store i64 %t203, ptr %l22, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t204 = load i64, ptr %l21, !tbaa !24
  store i64 %t204, ptr %l128, !tbaa !24
  %t205 = load i64, ptr %l4, !tbaa !24
  store i64 %t205, ptr %l129, !tbaa !24
  %t206 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  store i64 %t206, ptr %l130, !tbaa !24
  %t207 = load i64, ptr %l129, !tbaa !24
  %t208 = load i64, ptr %l130, !tbaa !24
  %t209 = add i64 %t207, %t208
  store i64 %t209, ptr %l131, !tbaa !24
  %t210 = load i64, ptr %l128, !tbaa !24
  %t211 = load i64, ptr %l131, !tbaa !24
  %t212 = icmp slt i64 %t210, %t211
  store i1 %t212, ptr %l132, !tbaa !21
  %t213 = load i1, ptr %l132, !tbaa !21
  br i1 %t213, label %bb49, label %bb50
bb49:
  %t214 = load i64, ptr %l21, !tbaa !24
  store i64 %t214, ptr %l134, !tbaa !24
  %t215 = load i64, ptr %l134, !tbaa !24
  store i64 %t215, ptr %l133, !tbaa !24
  br label %bb51
bb50:
  %t216 = load i64, ptr %l4, !tbaa !24
  store i64 %t216, ptr %l135, !tbaa !24
  %t217 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  store i64 %t217, ptr %l136, !tbaa !24
  %t218 = load i64, ptr %l135, !tbaa !24
  %t219 = load i64, ptr %l136, !tbaa !24
  %t220 = add i64 %t218, %t219
  store i64 %t220, ptr %l137, !tbaa !24
  %t221 = load i64, ptr %l137, !tbaa !24
  store i64 %t221, ptr %l133, !tbaa !24
  br label %bb51
bb51:
  %t222 = load i64, ptr @G_2ecompiler_2fdiag_2eExcerptAround, !tbaa !24
  store i64 %t222, ptr %l138, !tbaa !24
  %t223 = load i64, ptr %l133, !tbaa !24
  %t224 = load i64, ptr %l138, !tbaa !24
  %t225 = add i64 %t223, %t224
  store i64 %t225, ptr %l139, !tbaa !24
  %t226 = load i64, ptr %l139, !tbaa !24
  store i64 %t226, ptr %l24, !tbaa !24
  %t227 = load i64, ptr %l24, !tbaa !24
  store i64 %t227, ptr %l140, !tbaa !24
  %t228 = load i64, ptr %l23, !tbaa !24
  store i64 %t228, ptr %l141, !tbaa !24
  %t229 = load i64, ptr %l140, !tbaa !24
  %t230 = load i64, ptr %l141, !tbaa !24
  %t231 = icmp slt i64 %t229, %t230
  store i1 %t231, ptr %l142, !tbaa !21
  %t232 = load i1, ptr %l142, !tbaa !21
  br i1 %t232, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s11
  %t233 = load i64, ptr %l24, !tbaa !24
  store i64 %t233, ptr %l143, !tbaa !24
  %t234 = load i64, ptr %l143, !tbaa !24
  store i64 %t234, ptr %l23, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb54
bb53:
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s9)
  br label %bb55
bb55:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l144, !tbaa !29
  %t236 = load i64, ptr %l11, !tbaa !24
  store i64 %t236, ptr %l145, !tbaa !24
  %t237 = load i64, ptr %l145, !tbaa !24
  %t238 = call { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %s0, i64 %t237, i64 5, i8 32)
  store { i64, ptr } %t238, ptr %l146
  br label %bb56
bb56:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s12
  store ptr %s12room, ptr %s12
  %t239 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t239, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  call void @__olang_sb_put(ptr %s12, ptr %t240, i64 %t241)
  %t242 = extractvalue { i64, ptr } { i64 3, ptr @.d43 }, 1
  %t243 = extractvalue { i64, ptr } { i64 3, ptr @.d43 }, 0
  call void @__olang_sb_put(ptr %s12, ptr %t242, i64 %t243)
  %t244 = load ptr, ptr %s12
  %t245 = getelementptr %olang.builder, ptr %s12, i32 0, i32 1
  %t246 = load i64, ptr %t245
  %t247 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t246)
  call void @llvm.memcpy.p0.p0.i64(ptr %t247, ptr %t244, i64 %t246, i1 false)
  %t248 = insertvalue { i64, ptr } undef, i64 %t246, 0
  %t249 = insertvalue { i64, ptr } %t248, ptr %t247, 1
  store { i64, ptr } %t249, ptr %l147, !tbaa !27
  call void @__olang_sb_done(ptr %s12)
  %t250 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  store { i64, ptr } %t256, ptr %l148, !tbaa !27
  %t257 = load ptr, ptr %l144, !tbaa !29
  %t258 = load { i64, ptr }, ptr %l148, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t257, { i64, ptr } %t258)
  br label %bb57
bb57:
  %t259 = load i64, ptr %l22, !tbaa !24
  store i64 %t259, ptr %l149, !tbaa !24
  %t260 = load i64, ptr %l12, !tbaa !24
  store i64 %t260, ptr %l150, !tbaa !24
  %t261 = load i64, ptr %l149, !tbaa !24
  %t262 = load i64, ptr %l150, !tbaa !24
  %t263 = icmp sgt i64 %t261, %t262
  store i1 %t263, ptr %l151, !tbaa !21
  %t264 = load i1, ptr %l151, !tbaa !21
  br i1 %t264, label %bb58, label %bb59
bb58:
  store %olang.scope zeroinitializer, ptr %s13
  %t265 = load ptr, ptr %l1, !tbaa !29
  store ptr %t265, ptr %l152, !tbaa !29
  %t266 = load ptr, ptr %l152, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s13, ptr %t266, { i64, ptr } { i64 3, ptr @.d44 })
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s13)
  br label %bb61
bb61:
  store %olang.scope zeroinitializer, ptr %s14
  %t267 = load i64, ptr %l22, !tbaa !24
  store i64 %t267, ptr %l153, !tbaa !24
  %t268 = load i64, ptr %l153, !tbaa !24
  store i64 %t268, ptr %l25, !tbaa !24
  %t269 = load i64, ptr %l23, !tbaa !24
  store i64 %t269, ptr %l154, !tbaa !24
  %t270 = load i64, ptr %l154, !tbaa !24
  store i64 %t270, ptr %l26, !tbaa !24
  store i64 1, ptr %l27, !tbaa !24
  %t271 = load i64, ptr %l26, !tbaa !24
  store i64 %t271, ptr %l155, !tbaa !24
  %t272 = load i64, ptr %l25, !tbaa !24
  store i64 %t272, ptr %l156, !tbaa !24
  %t273 = load i64, ptr %l155, !tbaa !24
  %t274 = load i64, ptr %l156, !tbaa !24
  %t275 = icmp sgt i64 %t273, %t274
  store i1 %t275, ptr %l157, !tbaa !21
  %t276 = load i1, ptr %l157, !tbaa !21
  br i1 %t276, label %bb62, label %bb63
bb62:
  %t277 = load i64, ptr %l27, !tbaa !24
  store i64 %t277, ptr %l159, !tbaa !24
  %t278 = load i64, ptr %l159, !tbaa !24
  %t279 = icmp sgt i64 %t278, 0
  store i1 %t279, ptr %l160, !tbaa !21
  %t280 = load i1, ptr %l160, !tbaa !21
  br i1 %t280, label %bb64, label %bb65
bb63:
  store i64 0, ptr %l158, !tbaa !24
  br label %bb67
bb64:
  %t281 = load i64, ptr %l26, !tbaa !24
  store i64 %t281, ptr %l162, !tbaa !24
  %t282 = load i64, ptr %l25, !tbaa !24
  store i64 %t282, ptr %l163, !tbaa !24
  %t283 = load i64, ptr %l162, !tbaa !24
  %t284 = load i64, ptr %l163, !tbaa !24
  %t285 = sub i64 %t283, %t284
  store i64 %t285, ptr %l164, !tbaa !24
  %t286 = load i64, ptr %l27, !tbaa !24
  store i64 %t286, ptr %l165, !tbaa !24
  %t287 = load i64, ptr %l164, !tbaa !24
  %t288 = load i64, ptr %l165, !tbaa !24
  %t289 = add i64 %t287, %t288
  store i64 %t289, ptr %l166, !tbaa !24
  %t290 = load i64, ptr %l166, !tbaa !24
  %t291 = sub i64 %t290, 1
  store i64 %t291, ptr %l167, !tbaa !24
  %t292 = load i64, ptr %l27, !tbaa !24
  store i64 %t292, ptr %l168, !tbaa !24
  %t293 = load i64, ptr %l167, !tbaa !24
  %t294 = load i64, ptr %l168, !tbaa !24
  %t295 = sdiv i64 %t293, %t294
  store i64 %t295, ptr %l169, !tbaa !24
  %t296 = load i64, ptr %l169, !tbaa !24
  store i64 %t296, ptr %l161, !tbaa !24
  br label %bb66
bb65:
  store i64 0, ptr %l161, !tbaa !24
  br label %bb66
bb66:
  %t297 = load i64, ptr %l161, !tbaa !24
  store i64 %t297, ptr %l158, !tbaa !24
  br label %bb67
bb67:
  %t298 = load i64, ptr %l158, !tbaa !24
  store i64 %t298, ptr %l28, !tbaa !24
  store i64 0, ptr %l29, !tbaa !24
  br label %bb68
bb68:
  store %olang.scope zeroinitializer, ptr %s15
  %t299 = load i64, ptr %l29, !tbaa !24
  store i64 %t299, ptr %l170, !tbaa !24
  %t300 = load i64, ptr %l28, !tbaa !24
  store i64 %t300, ptr %l171, !tbaa !24
  %t301 = load i64, ptr %l170, !tbaa !24
  %t302 = load i64, ptr %l171, !tbaa !24
  %t303 = icmp slt i64 %t301, %t302
  store i1 %t303, ptr %l172, !tbaa !21
  %t304 = load i1, ptr %l172, !tbaa !21
  %t305 = xor i1 %t304, true
  store i1 %t305, ptr %l173, !tbaa !21
  %t306 = load i1, ptr %l173, !tbaa !21
  br i1 %t306, label %bb69, label %bb70
bb69:
  call void @__olang_scope_close(ptr %s15)
  br label %bb75
bb70:
  br label %bb71
bb71:
  %t307 = load i64, ptr %l25, !tbaa !24
  store i64 %t307, ptr %l174, !tbaa !24
  %t308 = load i64, ptr %l29, !tbaa !24
  store i64 %t308, ptr %l175, !tbaa !24
  %t309 = load i64, ptr %l27, !tbaa !24
  store i64 %t309, ptr %l176, !tbaa !24
  %t310 = load i64, ptr %l175, !tbaa !24
  %t311 = load i64, ptr %l176, !tbaa !24
  %t312 = mul i64 %t310, %t311
  store i64 %t312, ptr %l177, !tbaa !24
  %t313 = load i64, ptr %l174, !tbaa !24
  %t314 = load i64, ptr %l177, !tbaa !24
  %t315 = add i64 %t313, %t314
  store i64 %t315, ptr %l178, !tbaa !24
  %t316 = load i64, ptr %l178, !tbaa !24
  store i64 %t316, ptr %l30, !tbaa !24
  %t317 = load ptr, ptr %l1, !tbaa !29
  store ptr %t317, ptr %l179, !tbaa !29
  %t318 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t318, ptr %l180, !tbaa !27
  %t319 = load i64, ptr %l30, !tbaa !24
  store i64 %t319, ptr %l181, !tbaa !24
  %t320 = load i64, ptr %l181, !tbaa !24
  %t321 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t322 = load ptr, ptr %t321, !tbaa !27
  %t323 = getelementptr i8, ptr %t322, i64 %t320
  %t324 = load i8, ptr %t323, !tbaa !32
  store i8 %t324, ptr %l182, !tbaa !22
  %t325 = load i8, ptr %l182, !tbaa !22
  %t326 = call i8 @compiler_2fdiag_2eprintable(i8 %t325)
  store i8 %t326, ptr %l183
  br label %bb72
bb72:
  %t327 = load ptr, ptr %l179, !tbaa !29
  %t328 = load i8, ptr %l183, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t327, i8 %t328)
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s15)
  br label %bb74
bb74:
  store %olang.scope zeroinitializer, ptr %s16
  %t329 = load i64, ptr %l29, !tbaa !24
  store i64 %t329, ptr %l184, !tbaa !24
  %t330 = load i64, ptr %l184, !tbaa !24
  %t331 = add i64 %t330, 1
  store i64 %t331, ptr %l185, !tbaa !24
  %t332 = load i64, ptr %l185, !tbaa !24
  store i64 %t332, ptr %l29, !tbaa !24
  call void @__olang_scope_close(ptr %s16)
  br label %bb68
bb75:
  call void @__olang_scope_close(ptr %s14)
  %t333 = load i64, ptr %l23, !tbaa !24
  store i64 %t333, ptr %l186, !tbaa !24
  %t334 = load i64, ptr %l13, !tbaa !24
  store i64 %t334, ptr %l187, !tbaa !24
  %t335 = load i64, ptr %l186, !tbaa !24
  %t336 = load i64, ptr %l187, !tbaa !24
  %t337 = icmp slt i64 %t335, %t336
  store i1 %t337, ptr %l188, !tbaa !21
  %t338 = load i1, ptr %l188, !tbaa !21
  br i1 %t338, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s17
  %t339 = load ptr, ptr %l1, !tbaa !29
  store ptr %t339, ptr %l189, !tbaa !29
  %t340 = load ptr, ptr %l189, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s17, ptr %t340, { i64, ptr } { i64 3, ptr @.d45 })
  br label %bb78
bb77:
  br label %bb79
bb78:
  call void @__olang_scope_close(ptr %s17)
  br label %bb79
bb79:
  %t341 = load ptr, ptr %l1, !tbaa !29
  store ptr %t341, ptr %l190, !tbaa !29
  %t342 = load ptr, ptr %l190, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t342, { i64, ptr } { i64 9, ptr @.d46 })
  br label %bb80
bb80:
  %t343 = load i64, ptr %l22, !tbaa !24
  store i64 %t343, ptr %l191, !tbaa !24
  %t344 = load i64, ptr %l12, !tbaa !24
  store i64 %t344, ptr %l192, !tbaa !24
  %t345 = load i64, ptr %l191, !tbaa !24
  %t346 = load i64, ptr %l192, !tbaa !24
  %t347 = icmp sgt i64 %t345, %t346
  store i1 %t347, ptr %l193, !tbaa !21
  %t348 = load i1, ptr %l193, !tbaa !21
  br i1 %t348, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s18
  %t349 = load ptr, ptr %l1, !tbaa !29
  store ptr %t349, ptr %l194, !tbaa !29
  %t350 = load ptr, ptr %l194, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s18, ptr %t350, { i64, ptr } { i64 3, ptr @.d47 })
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s18)
  br label %bb84
bb84:
  %t351 = load i64, ptr %l22, !tbaa !24
  store i64 %t351, ptr %l195, !tbaa !24
  %t352 = load i64, ptr %l195, !tbaa !24
  store i64 %t352, ptr %l31, !tbaa !24
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s19
  %t353 = load i64, ptr %l31, !tbaa !24
  store i64 %t353, ptr %l196, !tbaa !24
  %t354 = load i64, ptr %l4, !tbaa !24
  store i64 %t354, ptr %l197, !tbaa !24
  %t355 = load i64, ptr %l196, !tbaa !24
  %t356 = load i64, ptr %l197, !tbaa !24
  %t357 = icmp slt i64 %t355, %t356
  store i1 %t357, ptr %l198, !tbaa !21
  %t358 = load i1, ptr %l198, !tbaa !21
  br i1 %t358, label %bb86, label %bb87
bb86:
  %t359 = load i64, ptr %l31, !tbaa !24
  store i64 %t359, ptr %l200, !tbaa !24
  %t360 = load i64, ptr %l23, !tbaa !24
  store i64 %t360, ptr %l201, !tbaa !24
  %t361 = load i64, ptr %l200, !tbaa !24
  %t362 = load i64, ptr %l201, !tbaa !24
  %t363 = icmp slt i64 %t361, %t362
  store i1 %t363, ptr %l202, !tbaa !21
  %t364 = load i1, ptr %l202, !tbaa !21
  store i1 %t364, ptr %l199, !tbaa !21
  br label %bb88
bb87:
  store i1 false, ptr %l199, !tbaa !21
  br label %bb88
bb88:
  %t365 = load i1, ptr %l199, !tbaa !21
  %t366 = xor i1 %t365, true
  store i1 %t366, ptr %l203, !tbaa !21
  %t367 = load i1, ptr %l203, !tbaa !21
  br i1 %t367, label %bb89, label %bb90
bb89:
  call void @__olang_scope_close(ptr %s19)
  br label %bb101
bb90:
  br label %bb91
bb91:
  %t368 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t368, ptr %l204, !tbaa !27
  %t369 = load i64, ptr %l31, !tbaa !24
  store i64 %t369, ptr %l205, !tbaa !24
  %t370 = load i64, ptr %l205, !tbaa !24
  %t371 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t372 = load ptr, ptr %t371, !tbaa !27
  %t373 = getelementptr i8, ptr %t372, i64 %t370
  %t374 = load i8, ptr %t373, !tbaa !32
  store i8 %t374, ptr %l206, !tbaa !22
  %t375 = load i8, ptr %l206, !tbaa !22
  %t376 = call i1 @compiler_2fdiag_2econtinues(i8 %t375)
  store i1 %t376, ptr %l207
  br label %bb92
bb92:
  %t377 = load i1, ptr %l207, !tbaa !21
  %t378 = xor i1 %t377, true
  store i1 %t378, ptr %l208, !tbaa !21
  %t379 = load i1, ptr %l208, !tbaa !21
  br i1 %t379, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s20
  %t380 = load ptr, ptr %l1, !tbaa !29
  store ptr %t380, ptr %l209, !tbaa !29
  %t381 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t381, ptr %l210, !tbaa !27
  %t382 = load i64, ptr %l31, !tbaa !24
  store i64 %t382, ptr %l211, !tbaa !24
  %t383 = load i64, ptr %l211, !tbaa !24
  %t384 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t385 = load ptr, ptr %t384, !tbaa !27
  %t386 = getelementptr i8, ptr %t385, i64 %t383
  %t387 = load i8, ptr %t386, !tbaa !32
  store i8 %t387, ptr %l212, !tbaa !22
  %t388 = load i8, ptr %l212, !tbaa !22
  %t389 = icmp eq i8 %t388, 9
  store i1 %t389, ptr %l213, !tbaa !21
  %t390 = load i1, ptr %l213, !tbaa !21
  br i1 %t390, label %bb95, label %bb96
bb94:
  br label %bb99
bb95:
  store i8 9, ptr %l214, !tbaa !22
  br label %bb97
bb96:
  store i8 32, ptr %l214, !tbaa !22
  br label %bb97
bb97:
  %t391 = load ptr, ptr %l209, !tbaa !29
  %t392 = load i8, ptr %l214, !tbaa !22
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t391, i8 %t392)
  br label %bb98
bb98:
  call void @__olang_scope_close(ptr %s20)
  br label %bb99
bb99:
  %t393 = load i64, ptr %l31, !tbaa !24
  store i64 %t393, ptr %l215, !tbaa !24
  %t394 = load i64, ptr %l215, !tbaa !24
  %t395 = add i64 %t394, 1
  store i64 %t395, ptr %l216, !tbaa !24
  %t396 = load i64, ptr %l216, !tbaa !24
  store i64 %t396, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb100
bb100:
  br label %bb85
bb101:
  %t397 = load ptr, ptr %l1, !tbaa !29
  store ptr %t397, ptr %l217, !tbaa !29
  %t398 = load ptr, ptr %l0, !tbaa !29
  store ptr %t398, ptr %l218, !tbaa !29
  %t399 = load ptr, ptr %l218, !tbaa !29
  %t400 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t399, { i64, ptr } { i64 4, ptr @.d48 })
  store { i64, ptr } %t400, ptr %l219
  br label %bb102
bb102:
  %t401 = load { i64, ptr }, ptr %l219, !tbaa !27
  %t402 = extractvalue { i64, ptr } %t401, 0
  %t403 = extractvalue { i64, ptr } %t401, 1
  %t404 = mul i64 %t402, 1
  %t405 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t404)
  call void @llvm.memcpy.p0.p0.i64(ptr %t405, ptr %t403, i64 %t404, i1 false)
  %t406 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t407 = insertvalue { i64, ptr } %t406, ptr %t405, 1
  store { i64, ptr } %t407, ptr %l220, !tbaa !27
  %t408 = load ptr, ptr %l217, !tbaa !29
  %t409 = load { i64, ptr }, ptr %l220, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t408, { i64, ptr } %t409)
  br label %bb103
bb103:
  %t410 = load ptr, ptr %l1, !tbaa !29
  store ptr %t410, ptr %l221, !tbaa !29
  %t411 = load ptr, ptr %l221, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t411, i8 94)
  br label %bb104
bb104:
  %t412 = load i64, ptr %l4, !tbaa !24
  store i64 %t412, ptr %l222, !tbaa !24
  %t413 = load i64, ptr %l222, !tbaa !24
  %t414 = add i64 %t413, 1
  store i64 %t414, ptr %l223, !tbaa !24
  %t415 = load i64, ptr %l223, !tbaa !24
  store i64 %t415, ptr %l31, !tbaa !24
  br label %bb105
bb105:
  store %olang.scope zeroinitializer, ptr %s21
  %t416 = load i64, ptr %l31, !tbaa !24
  store i64 %t416, ptr %l224, !tbaa !24
  %t417 = load i64, ptr %l21, !tbaa !24
  store i64 %t417, ptr %l225, !tbaa !24
  %t418 = load i64, ptr %l224, !tbaa !24
  %t419 = load i64, ptr %l225, !tbaa !24
  %t420 = icmp slt i64 %t418, %t419
  store i1 %t420, ptr %l226, !tbaa !21
  %t421 = load i1, ptr %l226, !tbaa !21
  br i1 %t421, label %bb106, label %bb107
bb106:
  %t422 = load i64, ptr %l31, !tbaa !24
  store i64 %t422, ptr %l228, !tbaa !24
  %t423 = load i64, ptr %l23, !tbaa !24
  store i64 %t423, ptr %l229, !tbaa !24
  %t424 = load i64, ptr %l228, !tbaa !24
  %t425 = load i64, ptr %l229, !tbaa !24
  %t426 = icmp slt i64 %t424, %t425
  store i1 %t426, ptr %l230, !tbaa !21
  %t427 = load i1, ptr %l230, !tbaa !21
  store i1 %t427, ptr %l227, !tbaa !21
  br label %bb108
bb107:
  store i1 false, ptr %l227, !tbaa !21
  br label %bb108
bb108:
  %t428 = load i1, ptr %l227, !tbaa !21
  %t429 = xor i1 %t428, true
  store i1 %t429, ptr %l231, !tbaa !21
  %t430 = load i1, ptr %l231, !tbaa !21
  br i1 %t430, label %bb109, label %bb110
bb109:
  call void @__olang_scope_close(ptr %s21)
  br label %bb118
bb110:
  br label %bb111
bb111:
  %t431 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t431, ptr %l232, !tbaa !27
  %t432 = load i64, ptr %l31, !tbaa !24
  store i64 %t432, ptr %l233, !tbaa !24
  %t433 = load i64, ptr %l233, !tbaa !24
  %t434 = getelementptr { i64, ptr }, ptr %l232, i32 0, i32 1
  %t435 = load ptr, ptr %t434, !tbaa !27
  %t436 = getelementptr i8, ptr %t435, i64 %t433
  %t437 = load i8, ptr %t436, !tbaa !32
  store i8 %t437, ptr %l234, !tbaa !22
  %t438 = load i8, ptr %l234, !tbaa !22
  %t439 = call i1 @compiler_2fdiag_2econtinues(i8 %t438)
  store i1 %t439, ptr %l235
  br label %bb112
bb112:
  %t440 = load i1, ptr %l235, !tbaa !21
  %t441 = xor i1 %t440, true
  store i1 %t441, ptr %l236, !tbaa !21
  %t442 = load i1, ptr %l236, !tbaa !21
  br i1 %t442, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s22
  %t443 = load ptr, ptr %l1, !tbaa !29
  store ptr %t443, ptr %l237, !tbaa !29
  %t444 = load ptr, ptr %l237, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t444, i8 126)
  br label %bb115
bb114:
  br label %bb116
bb115:
  call void @__olang_scope_close(ptr %s22)
  br label %bb116
bb116:
  %t445 = load i64, ptr %l31, !tbaa !24
  store i64 %t445, ptr %l238, !tbaa !24
  %t446 = load i64, ptr %l238, !tbaa !24
  %t447 = add i64 %t446, 1
  store i64 %t447, ptr %l239, !tbaa !24
  %t448 = load i64, ptr %l239, !tbaa !24
  store i64 %t448, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s21)
  br label %bb117
bb117:
  br label %bb105
bb118:
  %t449 = load ptr, ptr %l1, !tbaa !29
  store ptr %t449, ptr %l240, !tbaa !29
  %t450 = load ptr, ptr %l0, !tbaa !29
  store ptr %t450, ptr %l241, !tbaa !29
  %t451 = load ptr, ptr %l241, !tbaa !29
  %t452 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t451, { i64, ptr } { i64 1, ptr @.d49 })
  store { i64, ptr } %t452, ptr %l242
  br label %bb119
bb119:
  %t453 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t454 = extractvalue { i64, ptr } %t453, 0
  %t455 = extractvalue { i64, ptr } %t453, 1
  %t456 = mul i64 %t454, 1
  %t457 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t456)
  call void @llvm.memcpy.p0.p0.i64(ptr %t457, ptr %t455, i64 %t456, i1 false)
  %t458 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t457, 1
  store { i64, ptr } %t459, ptr %l243, !tbaa !27
  %t460 = load ptr, ptr %l240, !tbaa !29
  %t461 = load { i64, ptr }, ptr %l243, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t460, { i64, ptr } %t461)
  br label %bb120
bb120:
  %t462 = load ptr, ptr %l1, !tbaa !29
  store ptr %t462, ptr %l244, !tbaa !29
  %t463 = load ptr, ptr %l244, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t463, i8 10)
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputLocation(ptr %v0, ptr %v1, ptr %a0, ptr %a1, { i64, [3 x i64] } %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca { i64, i64 }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, [3 x i64] }
  %l16 = alloca i1
  %l17 = alloca ptr
  %l18 = alloca { i64, [3 x i64] }
  %l19 = alloca i1
  %l20 = alloca i64
  %l21 = alloca ptr
  %l22 = alloca ptr
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca { i64, [3 x i64] }
  %l27 = alloca i1
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca ptr
  %l31 = alloca ptr
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l38 = alloca { i64, [3 x i64] }
  %l39 = alloca i1
  %l40 = alloca i64
  %l41 = alloca i64
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i64
  %l45 = alloca { i64, i64 }
  %l46 = alloca i64
  %l47 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca ptr
  %l51 = alloca i64
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i64
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca ptr
  %l61 = alloca ptr
  %l62 = alloca ptr
  %l63 = alloca { i64, ptr }
  %l64 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  store ptr %t1, ptr %l11, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  store ptr %t2, ptr %l12, !tbaa !29
  %t3 = load ptr, ptr %l12, !tbaa !29
  %t4 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t3, { i64, ptr } { i64 1, ptr @.d50 })
  store { i64, ptr } %t4, ptr %l13
  br label %bb1
bb1:
  %t5 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  %t7 = extractvalue { i64, ptr } %t5, 1
  %t8 = mul i64 %t6, 1
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @llvm.memcpy.p0.p0.i64(ptr %t9, ptr %t7, i64 %t8, i1 false)
  %t10 = insertvalue { i64, ptr } undef, i64 %t6, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l14, !tbaa !27
  %t12 = load ptr, ptr %l11, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t12, { i64, ptr } %t13)
  br label %bb2
bb2:
  %t14 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t14, ptr %l15
  %t15 = load { i64, [3 x i64] }, ptr %l15
  %t16 = extractvalue { i64, [3 x i64] } %t15, 0
  %t17 = icmp eq i64 %t16, 0
  store i1 %t17, ptr %l16, !tbaa !21
  %t18 = load i1, ptr %l16, !tbaa !21
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  br label %bb7
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t19 = load ptr, ptr %l1, !tbaa !29
  store ptr %t19, ptr %l17, !tbaa !29
  %t20 = load ptr, ptr %l17, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t20, { i64, ptr } { i64 5, ptr @.d51 })
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb27
bb7:
  %t21 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t21, ptr %l18
  %t22 = load { i64, [3 x i64] }, ptr %l18
  %t23 = extractvalue { i64, [3 x i64] } %t22, 0
  %t24 = icmp eq i64 %t23, 1
  store i1 %t24, ptr %l19, !tbaa !21
  %t25 = load i1, ptr %l19, !tbaa !21
  br i1 %t25, label %bb8, label %bb9
bb8:
  %t26 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t27 = getelementptr { i64 }, ptr %t26, i32 0, i32 0
  %t28 = load i64, ptr %t27
  store i64 %t28, ptr %l20, !tbaa !24
  %t29 = load i64, ptr %l20, !tbaa !24
  store i64 %t29, ptr %l3, !tbaa !24
  br label %bb10
bb9:
  br label %bb13
bb10:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l21, !tbaa !29
  %t31 = load ptr, ptr %l0, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load ptr, ptr %l22, !tbaa !29
  %t33 = getelementptr %"compiler/diag:Diagnostics", ptr %t32, i32 0, i32 1
  store ptr %t33, ptr %l23, !tbaa !29
  %t34 = load i64, ptr %l3, !tbaa !24
  store i64 %t34, ptr %l24, !tbaa !24
  %t35 = load ptr, ptr %l23, !tbaa !29
  %t36 = load i64, ptr %l24, !tbaa !24
  %t37 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v0, ptr %t35, i64 %t36)
  store { i64, ptr } %t37, ptr %l25
  br label %bb11
bb11:
  %t38 = load ptr, ptr %l21, !tbaa !29
  %t39 = load { i64, ptr }, ptr %l25, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v0, ptr %t38, { i64, ptr } %t39)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  br label %bb27
bb13:
  %t40 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t40, ptr %l26
  %t41 = load { i64, [3 x i64] }, ptr %l26
  %t42 = extractvalue { i64, [3 x i64] } %t41, 0
  %t43 = icmp eq i64 %t42, 2
  store i1 %t43, ptr %l27, !tbaa !21
  %t44 = load i1, ptr %l27, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb14:
  %t45 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t46 = getelementptr { i64, i64 }, ptr %t45, i32 0, i32 0
  %t47 = load i64, ptr %t46
  store i64 %t47, ptr %l28, !tbaa !24
  %t48 = load i64, ptr %l28, !tbaa !24
  store i64 %t48, ptr %l4, !tbaa !24
  %t49 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t50 = getelementptr { i64, i64 }, ptr %t49, i32 0, i32 1
  %t51 = load i64, ptr %t50
  store i64 %t51, ptr %l29, !tbaa !24
  %t52 = load i64, ptr %l29, !tbaa !24
  store i64 %t52, ptr %l5, !tbaa !24
  br label %bb16
bb15:
  br label %bb19
bb16:
  store %olang.scope zeroinitializer, ptr %s3
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  %t54 = load ptr, ptr %l0, !tbaa !29
  store ptr %t54, ptr %l31, !tbaa !29
  %t55 = load ptr, ptr %l31, !tbaa !29
  %t56 = getelementptr %"compiler/diag:Diagnostics", ptr %t55, i32 0, i32 1
  store ptr %t56, ptr %l32, !tbaa !29
  %t57 = load i64, ptr %l4, !tbaa !24
  store i64 %t57, ptr %l33, !tbaa !24
  %t58 = load ptr, ptr %l32, !tbaa !29
  %t59 = load i64, ptr %l33, !tbaa !24
  %t60 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s3, ptr %t58, i64 %t59)
  store { i64, ptr } %t60, ptr %l34
  br label %bb17
bb17:
  %t61 = load i64, ptr %l5, !tbaa !24
  store i64 %t61, ptr %l35, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t62 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t63 = extractvalue { i64, ptr } %t62, 1
  %t64 = extractvalue { i64, ptr } %t62, 0
  call void @__olang_sb_put(ptr %s4, ptr %t63, i64 %t64)
  %t65 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 1
  %t66 = extractvalue { i64, ptr } { i64 1, ptr @.d52 }, 0
  call void @__olang_sb_put(ptr %s4, ptr %t65, i64 %t66)
  %t67 = load i64, ptr %l35, !tbaa !24
  %t68 = call ptr @__olang_sb_room(ptr %s4, i64 24)
  %t69 = call i64 @__olang_fmt_i64(ptr %t68, i64 %t67)
  call void @__olang_sb_add(ptr %s4, i64 %t69)
  %t70 = load ptr, ptr %s4
  %t71 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t72 = load i64, ptr %t71
  %t73 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t72)
  call void @llvm.memcpy.p0.p0.i64(ptr %t73, ptr %t70, i64 %t72, i1 false)
  %t74 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t75 = insertvalue { i64, ptr } %t74, ptr %t73, 1
  store { i64, ptr } %t75, ptr %l36, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  %t76 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t77 = extractvalue { i64, ptr } %t76, 0
  %t78 = extractvalue { i64, ptr } %t76, 1
  %t79 = mul i64 %t77, 1
  %t80 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t79)
  call void @llvm.memcpy.p0.p0.i64(ptr %t80, ptr %t78, i64 %t79, i1 false)
  %t81 = insertvalue { i64, ptr } undef, i64 %t77, 0
  %t82 = insertvalue { i64, ptr } %t81, ptr %t80, 1
  store { i64, ptr } %t82, ptr %l37, !tbaa !27
  %t83 = load ptr, ptr %l30, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l37, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s3, ptr %t83, { i64, ptr } %t84)
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s3)
  br label %bb27
bb19:
  %t85 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t85, ptr %l38
  %t86 = load { i64, [3 x i64] }, ptr %l38
  %t87 = extractvalue { i64, [3 x i64] } %t86, 0
  %t88 = icmp eq i64 %t87, 3
  store i1 %t88, ptr %l39, !tbaa !21
  %t89 = load i1, ptr %l39, !tbaa !21
  br i1 %t89, label %bb20, label %bb21
bb20:
  %t90 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t91 = getelementptr { i64, i64, i64 }, ptr %t90, i32 0, i32 0
  %t92 = load i64, ptr %t91
  store i64 %t92, ptr %l40, !tbaa !24
  %t93 = load i64, ptr %l40, !tbaa !24
  store i64 %t93, ptr %l6, !tbaa !24
  %t94 = getelementptr { i64, [3 x i64] }, ptr %l2, i32 0, i32 1
  %t95 = getelementptr { i64, i64, i64 }, ptr %t94, i32 0, i32 1
  %t96 = load i64, ptr %t95
  store i64 %t96, ptr %l41, !tbaa !24
  %t97 = load i64, ptr %l41, !tbaa !24
  store i64 %t97, ptr %l7, !tbaa !24
  br label %bb22
bb21:
  br label %bb26
bb22:
  store %olang.scope zeroinitializer, ptr %s5
  %t98 = load ptr, ptr %l0, !tbaa !29
  store ptr %t98, ptr %l42, !tbaa !29
  %t99 = load i64, ptr %l6, !tbaa !24
  store i64 %t99, ptr %l43, !tbaa !24
  %t100 = load i64, ptr %l7, !tbaa !24
  store i64 %t100, ptr %l44, !tbaa !24
  %t101 = load ptr, ptr %l42, !tbaa !29
  %t102 = load i64, ptr %l43, !tbaa !24
  %t103 = load i64, ptr %l44, !tbaa !24
  %t104 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t101, i64 %t102, i64 %t103)
  store { i64, i64 } %t104, ptr %l45
  br label %bb23
bb23:
  %t105 = load { i64, i64 }, ptr %l45
  store { i64, i64 } %t105, ptr %l8
  %t106 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 0
  %t107 = load i64, ptr %t106, !tbaa !24
  store i64 %t107, ptr %l46, !tbaa !24
  %t108 = load i64, ptr %l46, !tbaa !24
  store i64 %t108, ptr %l9, !tbaa !24
  %t109 = getelementptr { i64, i64 }, ptr %l8, i32 0, i32 1
  %t110 = load i64, ptr %t109, !tbaa !24
  store i64 %t110, ptr %l47, !tbaa !24
  %t111 = load i64, ptr %l47, !tbaa !24
  store i64 %t111, ptr %l10, !tbaa !24
  %t112 = load ptr, ptr %l1, !tbaa !29
  store ptr %t112, ptr %l48, !tbaa !29
  %t113 = load ptr, ptr %l0, !tbaa !29
  store ptr %t113, ptr %l49, !tbaa !29
  %t114 = load ptr, ptr %l49, !tbaa !29
  %t115 = getelementptr %"compiler/diag:Diagnostics", ptr %t114, i32 0, i32 1
  store ptr %t115, ptr %l50, !tbaa !29
  %t116 = load i64, ptr %l6, !tbaa !24
  store i64 %t116, ptr %l51, !tbaa !24
  %t117 = load ptr, ptr %l50, !tbaa !29
  %t118 = load i64, ptr %l51, !tbaa !24
  %t119 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %s5, ptr %t117, i64 %t118)
  store { i64, ptr } %t119, ptr %l52
  br label %bb24
bb24:
  %t120 = load i64, ptr %l9, !tbaa !24
  store i64 %t120, ptr %l53, !tbaa !24
  %t121 = load i64, ptr %l7, !tbaa !24
  store i64 %t121, ptr %l54, !tbaa !24
  %t122 = load i64, ptr %l10, !tbaa !24
  store i64 %t122, ptr %l55, !tbaa !24
  %t123 = load i64, ptr %l54, !tbaa !24
  %t124 = load i64, ptr %l55, !tbaa !24
  %t125 = sub i64 %t123, %t124
  store i64 %t125, ptr %l56, !tbaa !24
  %t126 = load i64, ptr %l56, !tbaa !24
  %t127 = add i64 %t126, 1
  store i64 %t127, ptr %l57, !tbaa !24
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t128 = load { i64, ptr }, ptr %l52, !tbaa !27
  %t129 = extractvalue { i64, ptr } %t128, 1
  %t130 = extractvalue { i64, ptr } %t128, 0
  call void @__olang_sb_put(ptr %s6, ptr %t129, i64 %t130)
  %t131 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 1
  %t132 = extractvalue { i64, ptr } { i64 1, ptr @.d53 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t131, i64 %t132)
  %t133 = load i64, ptr %l53, !tbaa !24
  %t134 = call ptr @__olang_sb_room(ptr %s6, i64 24)
  %t135 = call i64 @__olang_fmt_i64(ptr %t134, i64 %t133)
  call void @__olang_sb_add(ptr %s6, i64 %t135)
  %t136 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 1
  %t137 = extractvalue { i64, ptr } { i64 1, ptr @.d54 }, 0
  call void @__olang_sb_put(ptr %s6, ptr %t136, i64 %t137)
  %t138 = load i64, ptr %l57, !tbaa !24
  %t139 = call ptr @__olang_sb_room(ptr %s6, i64 24)
  %t140 = call i64 @__olang_fmt_i64(ptr %t139, i64 %t138)
  call void @__olang_sb_add(ptr %s6, i64 %t140)
  %t141 = load ptr, ptr %s6
  %t142 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t143 = load i64, ptr %t142
  %t144 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t141, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  store { i64, ptr } %t146, ptr %l58, !tbaa !27
  call void @__olang_sb_done(ptr %s6)
  %t147 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t147, 0
  %t149 = extractvalue { i64, ptr } %t147, 1
  %t150 = mul i64 %t148, 1
  %t151 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t150)
  call void @llvm.memcpy.p0.p0.i64(ptr %t151, ptr %t149, i64 %t150, i1 false)
  %t152 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t153 = insertvalue { i64, ptr } %t152, ptr %t151, 1
  store { i64, ptr } %t153, ptr %l59, !tbaa !27
  %t154 = load ptr, ptr %l48, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l59, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s5, ptr %t154, { i64, ptr } %t155)
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s5)
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @.c55)
  unreachable
bb27:
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l60, !tbaa !29
  %t157 = load ptr, ptr %l60, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t157, { i64, ptr } { i64 2, ptr @.d56 })
  br label %bb28
bb28:
  %t158 = load ptr, ptr %l1, !tbaa !29
  store ptr %t158, ptr %l61, !tbaa !29
  %t159 = load ptr, ptr %l0, !tbaa !29
  store ptr %t159, ptr %l62, !tbaa !29
  %t160 = load ptr, ptr %l62, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s0, ptr %s0, ptr %t160, { i64, ptr } { i64 1, ptr @.d57 })
  store { i64, ptr } %t161, ptr %l63
  br label %bb29
bb29:
  %t162 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  %t164 = extractvalue { i64, ptr } %t162, 1
  %t165 = mul i64 %t163, 1
  %t166 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t165)
  call void @llvm.memcpy.p0.p0.i64(ptr %t166, ptr %t164, i64 %t165, i1 false)
  %t167 = insertvalue { i64, ptr } undef, i64 %t163, 0
  %t168 = insertvalue { i64, ptr } %t167, ptr %t166, 1
  store { i64, ptr } %t168, ptr %l64, !tbaa !27
  %t169 = load ptr, ptr %l61, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l64, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s0, ptr %t169, { i64, ptr } %t170)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputRow(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, [3 x i64] } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca ptr
  %l7 = alloca ptr
  %l8 = alloca { i64, [3 x i64] }
  %l9 = alloca { i64, ptr }
  %l10 = alloca i1
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca ptr
  %l17 = alloca ptr
  %l18 = alloca { i64, ptr }
  %l19 = alloca ptr
  %l20 = alloca { i64, ptr }
  %l21 = alloca { i64, ptr }
  %l22 = alloca { i64, ptr }
  %l23 = alloca ptr
  %l24 = alloca { i64, ptr }
  %l25 = alloca ptr
  %l26 = alloca ptr
  %l27 = alloca ptr
  %l28 = alloca { i64, [3 x i64] }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, [3 x i64] } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  store { i64, ptr } %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l6, !tbaa !29
  %t2 = load ptr, ptr %l1, !tbaa !29
  store ptr %t2, ptr %l7, !tbaa !29
  %t3 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t3, ptr %l8
  %t4 = load ptr, ptr %l6, !tbaa !29
  %t5 = load ptr, ptr %l7, !tbaa !29
  %t6 = load { i64, [3 x i64] }, ptr %l8
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputLocation(ptr %v0, ptr %v1, ptr %t4, ptr %t5, { i64, [3 x i64] } %t6)
  br label %bb1
bb1:
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l9, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t9 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v2, ptr %s0, { i64, ptr } %t8, { i64, ptr } { i64 5, ptr @.d58 })
  store i1 %t9, ptr %l10
  br label %bb2
bb2:
  %t10 = load i1, ptr %l10, !tbaa !21
  br i1 %t10, label %bb3, label %bb4
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  %t11 = load ptr, ptr %l1, !tbaa !29
  store ptr %t11, ptr %l11, !tbaa !29
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l12, !tbaa !29
  %t13 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t13, ptr %l13, !tbaa !27
  %t14 = load ptr, ptr %l12, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t16 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eerrorWord(ptr %v0, ptr %v3, ptr %s1, ptr %t14, { i64, ptr } %t15)
  store { i64, ptr } %t16, ptr %l14
  br label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t17 = load ptr, ptr %l1, !tbaa !29
  store ptr %t17, ptr %l16, !tbaa !29
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l17, !tbaa !29
  %t19 = load ptr, ptr %l17, !tbaa !29
  %t20 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s2, ptr %s2, ptr %t19, { i64, ptr } { i64 4, ptr @.d59 })
  store { i64, ptr } %t20, ptr %l18
  br label %bb7
bb5:
  %t21 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t22 = extractvalue { i64, ptr } %t21, 0
  %t23 = extractvalue { i64, ptr } %t21, 1
  %t24 = mul i64 %t22, 1
  %t25 = call ptr @__olang_scope_alloc(ptr %s1, i64 %t24)
  call void @llvm.memcpy.p0.p0.i64(ptr %t25, ptr %t23, i64 %t24, i1 false)
  %t26 = insertvalue { i64, ptr } undef, i64 %t22, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t25, 1
  store { i64, ptr } %t27, ptr %l15, !tbaa !27
  %t28 = load ptr, ptr %l11, !tbaa !29
  %t29 = load { i64, ptr }, ptr %l15, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s1, ptr %t28, { i64, ptr } %t29)
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb7:
  %t30 = load ptr, ptr %l0, !tbaa !29
  store ptr %t30, ptr %l19, !tbaa !29
  %t31 = load ptr, ptr %l19, !tbaa !29
  %t32 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %s2, ptr %s2, ptr %t31, { i64, ptr } { i64 1, ptr @.d60 })
  store { i64, ptr } %t32, ptr %l20
  br label %bb8
bb8:
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t33 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t34 = extractvalue { i64, ptr } %t33, 1
  %t35 = extractvalue { i64, ptr } %t33, 0
  call void @__olang_sb_put(ptr %s3, ptr %t34, i64 %t35)
  %t36 = extractvalue { i64, ptr } { i64 5, ptr @.d61 }, 1
  %t37 = extractvalue { i64, ptr } { i64 5, ptr @.d61 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t36, i64 %t37)
  %t38 = load { i64, ptr }, ptr %l20, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 1
  %t40 = extractvalue { i64, ptr } %t38, 0
  call void @__olang_sb_put(ptr %s3, ptr %t39, i64 %t40)
  %t41 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 1
  %t42 = extractvalue { i64, ptr } { i64 1, ptr @.d62 }, 0
  call void @__olang_sb_put(ptr %s3, ptr %t41, i64 %t42)
  %t43 = load ptr, ptr %s3
  %t44 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t45 = load i64, ptr %t44
  %t46 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t45)
  call void @llvm.memcpy.p0.p0.i64(ptr %t46, ptr %t43, i64 %t45, i1 false)
  %t47 = insertvalue { i64, ptr } undef, i64 %t45, 0
  %t48 = insertvalue { i64, ptr } %t47, ptr %t46, 1
  store { i64, ptr } %t48, ptr %l21, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t49 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t50 = extractvalue { i64, ptr } %t49, 0
  %t51 = extractvalue { i64, ptr } %t49, 1
  %t52 = mul i64 %t50, 1
  %t53 = call ptr @__olang_scope_alloc(ptr %s2, i64 %t52)
  call void @llvm.memcpy.p0.p0.i64(ptr %t53, ptr %t51, i64 %t52, i1 false)
  %t54 = insertvalue { i64, ptr } undef, i64 %t50, 0
  %t55 = insertvalue { i64, ptr } %t54, ptr %t53, 1
  store { i64, ptr } %t55, ptr %l22, !tbaa !27
  %t56 = load ptr, ptr %l16, !tbaa !29
  %t57 = load { i64, ptr }, ptr %l22, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %s2, ptr %t56, { i64, ptr } %t57)
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s2)
  br label %bb10
bb10:
  %t58 = load ptr, ptr %l1, !tbaa !29
  store ptr %t58, ptr %l23, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t59, ptr %l24, !tbaa !27
  %t60 = load ptr, ptr %l23, !tbaa !29
  %t61 = load { i64, ptr }, ptr %l24, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v1, ptr %v4, ptr %t60, { i64, ptr } %t61)
  br label %bb11
bb11:
  %t62 = load ptr, ptr %l1, !tbaa !29
  store ptr %t62, ptr %l25, !tbaa !29
  %t63 = load ptr, ptr %l25, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v1, ptr %t63, i8 10)
  br label %bb12
bb12:
  %t64 = load ptr, ptr %l0, !tbaa !29
  store ptr %t64, ptr %l26, !tbaa !29
  %t65 = load ptr, ptr %l1, !tbaa !29
  store ptr %t65, ptr %l27, !tbaa !29
  %t66 = load { i64, [3 x i64] }, ptr %l2
  store { i64, [3 x i64] } %t66, ptr %l28
  %t67 = load ptr, ptr %l26, !tbaa !29
  %t68 = load ptr, ptr %l27, !tbaa !29
  %t69 = load { i64, [3 x i64] }, ptr %l28
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eputExcerpt(ptr %v0, ptr %v1, ptr %t67, ptr %t68, { i64, [3 x i64] } %t69)
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define dso_local i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ereport(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2, i1 %a3) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca %"compiler/msgs:Msg"
  %l3 = alloca i1
  %l4 = alloca i64
  %l5 = alloca { i64, [3 x i64] }
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca i64
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca ptr
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca i1
  %l25 = alloca ptr
  %l26 = alloca i1
  %l27 = alloca i64
  %l28 = alloca ptr
  %l29 = alloca ptr
  %l30 = alloca { i64, [3 x i64] }
  %l31 = alloca i64
  %l32 = alloca i64
  %l33 = alloca i1
  %l34 = alloca { i64, [3 x i64] }
  %l35 = alloca { i64, [3 x i64] }
  %l36 = alloca ptr
  %l37 = alloca ptr
  %l38 = alloca i64
  %l39 = alloca %"compiler/diag:context"
  %l40 = alloca { i64, [3 x i64] }
  %l41 = alloca ptr
  %l42 = alloca ptr
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca ptr
  %l47 = alloca ptr
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l50 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i64
  %l53 = alloca ptr
  %l54 = alloca ptr
  %l55 = alloca { i64, [3 x i64] }
  %l56 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l62 = alloca i32
  %l63 = alloca i64
  %l64 = alloca i1
  %l65 = alloca %"compiler/diag:record"
  %l66 = alloca ptr
  %l67 = alloca ptr
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca ptr
  %l71 = alloca ptr
  %l72 = alloca i64
  %l73 = alloca i64
  %l74 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l77 = alloca i64
  %l78 = alloca { i64, [3 x i64] }
  %l79 = alloca %"compiler/msgs:Msg"
  %l80 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca %"compiler/diag:note"
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca ptr
  %l87 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i1
  %l92 = alloca i64
  %l93 = alloca i64
  %l94 = alloca i1
  %l95 = alloca i64
  %l96 = alloca i64
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca ptr
  %l114 = alloca ptr
  %l115 = alloca i64
  %l116 = alloca %"compiler/diag:context"
  %l117 = alloca { i64, ptr }
  %l118 = alloca i64
  %l119 = alloca i1
  %l120 = alloca i64
  %l121 = alloca i1
  %l122 = alloca i64
  %l123 = alloca i64
  %l124 = alloca i64
  %l125 = alloca i64
  %l126 = alloca i64
  %l127 = alloca i64
  %l128 = alloca i1
  %l129 = alloca i64
  %l130 = alloca i64
  %l131 = alloca i64
  %l132 = alloca i64
  %l133 = alloca ptr
  %l134 = alloca i64
  %l135 = alloca i1
  %l136 = alloca i1
  %l137 = alloca i64
  %l138 = alloca i64
  %l139 = alloca i1
  %l140 = alloca i1
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca i64
  %l144 = alloca %"compiler/diag:context"
  %l145 = alloca { i64, ptr }
  %l146 = alloca i64
  %l147 = alloca i1
  %l148 = alloca i64
  %l149 = alloca i64
  %l150 = alloca i1
  %l151 = alloca i1
  %l152 = alloca i64
  %l153 = alloca i1
  %l154 = alloca ptr
  %l155 = alloca ptr
  %l156 = alloca i64
  %l157 = alloca ptr
  %l158 = alloca ptr
  %l159 = alloca i64
  %l160 = alloca %"compiler/diag:context"
  %l161 = alloca { i64, [3 x i64] }
  %l162 = alloca ptr
  %l163 = alloca ptr
  %l164 = alloca i64
  %l165 = alloca %"compiler/diag:context"
  %l166 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l169 = alloca %"compiler/diag:note"
  %l170 = alloca i64
  %l171 = alloca i64
  %l172 = alloca i64
  %l173 = alloca i64
  %l174 = alloca i64
  %l175 = alloca i1
  %l176 = alloca ptr
  %l177 = alloca ptr
  %l178 = alloca i64
  %l179 = alloca ptr
  %l180 = alloca ptr
  %l181 = alloca i64
  %l182 = alloca %"compiler/diag:context"
  %l183 = alloca { i64, [3 x i64] }
  %l184 = alloca ptr
  %l185 = alloca ptr
  %l186 = alloca i64
  %l187 = alloca %"compiler/diag:context"
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l190 = alloca { i64, ptr }
  %l191 = alloca %"compiler/diag:note"
  %l192 = alloca i64
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.builder
  %s3room = alloca [64 x i8], align 8
  %s4 = alloca %olang.builder
  %s4room = alloca [64 x i8], align 8
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.builder
  %s6room = alloca [64 x i8], align 8
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.builder
  %s15room = alloca [64 x i8], align 8
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.builder
  %s17room = alloca [64 x i8], align 8
  %rv = alloca i64
  store ptr %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store %"compiler/msgs:Msg" %a2, ptr %l2
  store i1 %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l20, !tbaa !29
  %t2 = load ptr, ptr %l20, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 14
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l21, !tbaa !21
  %t5 = load i1, ptr %l21, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = getelementptr %"compiler/msgs:Msg", ptr %l2, i32 0, i32 1
  %t7 = load { i64, ptr }, ptr %t6, !tbaa !27
  store { i64, ptr } %t7, ptr %l23, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t9 = call i1 @compiler_2fdiag_2eisScopeRule(ptr %v1, { i64, ptr } %t8)
  store i1 %t9, ptr %l24
  br label %bb3
bb2:
  store i1 false, ptr %l22, !tbaa !21
  br label %bb4
bb3:
  %t10 = load i1, ptr %l24, !tbaa !21
  store i1 %t10, ptr %l22, !tbaa !21
  br label %bb4
bb4:
  %t11 = load i1, ptr %l22, !tbaa !21
  br i1 %t11, label %bb5, label %bb6
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t12 = load ptr, ptr %l0, !tbaa !29
  store ptr %t12, ptr %l25, !tbaa !29
  %t13 = load ptr, ptr %l25, !tbaa !29
  %t14 = getelementptr %"compiler/diag:Diagnostics", ptr %t13, i32 0, i32 15
  %t15 = load i1, ptr %t14, !tbaa !21
  store i1 %t15, ptr %l26, !tbaa !21
  %t16 = load i1, ptr %l26, !tbaa !21
  br i1 %t16, label %bb7, label %bb8
bb6:
  br label %bb10
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i64 -1, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t17 = load i64, ptr %l27, !tbaa !24
  store i64 %t17, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t18 = load ptr, ptr %l0, !tbaa !29
  store ptr %t18, ptr %l28, !tbaa !29
  %t19 = load ptr, ptr %l28, !tbaa !29
  %t20 = getelementptr %"compiler/diag:Diagnostics", ptr %t19, i32 0, i32 15
  store i1 true, ptr %t20, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  br label %bb10
bb10:
  %t21 = load ptr, ptr %l0, !tbaa !29
  store ptr %t21, ptr %l29, !tbaa !29
  %t22 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t22, ptr %l30
  %t23 = load ptr, ptr %l29, !tbaa !29
  %t24 = load { i64, [3 x i64] }, ptr %l30
  %t25 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eprogramUse(ptr %v0, ptr %t23, { i64, [3 x i64] } %t24)
  store i64 %t25, ptr %l31
  br label %bb11
bb11:
  %t26 = load i64, ptr %l31, !tbaa !24
  store i64 %t26, ptr %l4, !tbaa !24
  %t27 = load i64, ptr %l4, !tbaa !24
  store i64 %t27, ptr %l32, !tbaa !24
  %t28 = load i64, ptr %l32, !tbaa !24
  %t29 = icmp slt i64 %t28, 0
  store i1 %t29, ptr %l33, !tbaa !21
  %t30 = load i1, ptr %l33, !tbaa !21
  br i1 %t30, label %bb12, label %bb13
bb12:
  %t31 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t31, ptr %l35
  %t32 = load { i64, [3 x i64] }, ptr %l35
  store { i64, [3 x i64] } %t32, ptr %l34
  br label %bb15
bb13:
  %t33 = load ptr, ptr %l0, !tbaa !29
  store ptr %t33, ptr %l36, !tbaa !29
  %t34 = load ptr, ptr %l36, !tbaa !29
  %t35 = getelementptr %"compiler/diag:Diagnostics", ptr %t34, i32 0, i32 12
  store ptr %t35, ptr %l37, !tbaa !29
  %t36 = load i64, ptr %l4, !tbaa !24
  store i64 %t36, ptr %l38, !tbaa !24
  %t37 = load ptr, ptr %l37, !tbaa !29
  %t38 = load i64, ptr %l38, !tbaa !24
  %t39 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t37, i64 %t38)
  store %"compiler/diag:context" %t39, ptr %l39
  br label %bb14
bb14:
  %t40 = getelementptr %"compiler/diag:context", ptr %l39, i32 0, i32 0
  %t41 = load { i64, [3 x i64] }, ptr %t40
  store { i64, [3 x i64] } %t41, ptr %l40
  %t42 = load { i64, [3 x i64] }, ptr %l40
  store { i64, [3 x i64] } %t42, ptr %l34
  br label %bb15
bb15:
  %t43 = load { i64, [3 x i64] }, ptr %l34
  store { i64, [3 x i64] } %t43, ptr %l5
  %t44 = load ptr, ptr %l0, !tbaa !29
  store ptr %t44, ptr %l41, !tbaa !29
  %t45 = load ptr, ptr %l41, !tbaa !29
  %t46 = getelementptr %"compiler/diag:Diagnostics", ptr %t45, i32 0, i32 11
  store ptr %t46, ptr %l42, !tbaa !29
  %t47 = load ptr, ptr %l42, !tbaa !29
  %t48 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t47)
  store i64 %t48, ptr %l43
  br label %bb16
bb16:
  %t49 = load i64, ptr %l43, !tbaa !24
  %t50 = icmp eq i64 %t49, 0
  store i1 %t50, ptr %l44, !tbaa !21
  %t51 = load i1, ptr %l44, !tbaa !21
  br i1 %t51, label %bb17, label %bb18
bb17:
  store i64 -1, ptr %l45, !tbaa !24
  br label %bb21
bb18:
  %t52 = load ptr, ptr %l0, !tbaa !29
  store ptr %t52, ptr %l46, !tbaa !29
  %t53 = load ptr, ptr %l46, !tbaa !29
  %t54 = getelementptr %"compiler/diag:Diagnostics", ptr %t53, i32 0, i32 11
  store ptr %t54, ptr %l47, !tbaa !29
  %t55 = load ptr, ptr %l0, !tbaa !29
  store ptr %t55, ptr %l48, !tbaa !29
  %t56 = load ptr, ptr %l48, !tbaa !29
  %t57 = getelementptr %"compiler/diag:Diagnostics", ptr %t56, i32 0, i32 11
  store ptr %t57, ptr %l49, !tbaa !29
  %t58 = load ptr, ptr %l49, !tbaa !29
  %t59 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %t58)
  store i64 %t59, ptr %l50
  br label %bb19
bb19:
  %t60 = load i64, ptr %l50, !tbaa !24
  %t61 = sub i64 %t60, 1
  store i64 %t61, ptr %l51, !tbaa !24
  %t62 = load ptr, ptr %l47, !tbaa !29
  %t63 = load i64, ptr %l51, !tbaa !24
  %t64 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %t62, i64 %t63)
  store i64 %t64, ptr %l52
  br label %bb20
bb20:
  %t65 = load i64, ptr %l52, !tbaa !24
  store i64 %t65, ptr %l45, !tbaa !24
  br label %bb21
bb21:
  %t66 = load i64, ptr %l45, !tbaa !24
  store i64 %t66, ptr %l6, !tbaa !24
  %t67 = load ptr, ptr %l0, !tbaa !29
  store ptr %t67, ptr %l53, !tbaa !29
  %t68 = load ptr, ptr %l53, !tbaa !29
  %t69 = getelementptr %"compiler/diag:Diagnostics", ptr %t68, i32 0, i32 7
  store ptr %t69, ptr %l54, !tbaa !29
  %t70 = load { i64, [3 x i64] }, ptr %l5
  store { i64, [3 x i64] } %t70, ptr %l55
  %t71 = getelementptr %"compiler/msgs:Msg", ptr %l2, i32 0, i32 1
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  store { i64, ptr } %t72, ptr %l56, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s3
  store ptr %s3room, ptr %s3
  %t73 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t74 = extractvalue { i64, ptr } %t73, 1
  %t75 = extractvalue { i64, ptr } %t73, 0
  call void @__olang_sb_put(ptr %s3, ptr %t74, i64 %t75)
  %t76 = load ptr, ptr %s3
  %t77 = getelementptr %olang.builder, ptr %s3, i32 0, i32 1
  %t78 = load i64, ptr %t77
  %t79 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t76, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  store { i64, ptr } %t81, ptr %l57, !tbaa !27
  call void @__olang_sb_done(ptr %s3)
  %t82 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 0
  %t84 = extractvalue { i64, ptr } %t82, 1
  %t85 = mul i64 %t83, 1
  %t86 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t85)
  call void @llvm.memcpy.p0.p0.i64(ptr %t86, ptr %t84, i64 %t85, i1 false)
  %t87 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t88 = insertvalue { i64, ptr } %t87, ptr %t86, 1
  store { i64, ptr } %t88, ptr %l58, !tbaa !27
  %t89 = getelementptr %"compiler/msgs:Msg", ptr %l2, i32 0, i32 2
  %t90 = load { i64, ptr }, ptr %t89, !tbaa !27
  store { i64, ptr } %t90, ptr %l59, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s4
  store ptr %s4room, ptr %s4
  %t91 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t91, 1
  %t93 = extractvalue { i64, ptr } %t91, 0
  call void @__olang_sb_put(ptr %s4, ptr %t92, i64 %t93)
  %t94 = load ptr, ptr %s4
  %t95 = getelementptr %olang.builder, ptr %s4, i32 0, i32 1
  %t96 = load i64, ptr %t95
  %t97 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t96)
  call void @llvm.memcpy.p0.p0.i64(ptr %t97, ptr %t94, i64 %t96, i1 false)
  %t98 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t99 = insertvalue { i64, ptr } %t98, ptr %t97, 1
  store { i64, ptr } %t99, ptr %l60, !tbaa !27
  call void @__olang_sb_done(ptr %s4)
  %t100 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t101 = extractvalue { i64, ptr } %t100, 0
  %t102 = extractvalue { i64, ptr } %t100, 1
  %t103 = mul i64 %t101, 1
  %t104 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t103)
  call void @llvm.memcpy.p0.p0.i64(ptr %t104, ptr %t102, i64 %t103, i1 false)
  %t105 = insertvalue { i64, ptr } undef, i64 %t101, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t104, 1
  store { i64, ptr } %t106, ptr %l61, !tbaa !27
  %t107 = getelementptr %"compiler/msgs:Msg", ptr %l2, i32 0, i32 0
  %t108 = load i32, ptr %t107
  store i32 %t108, ptr %l62
  %t109 = load i64, ptr %l6, !tbaa !24
  store i64 %t109, ptr %l63, !tbaa !24
  %t110 = load i1, ptr %l3, !tbaa !21
  store i1 %t110, ptr %l64, !tbaa !21
  %t111 = load { i64, [3 x i64] }, ptr %l55
  %t112 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t113 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t114 = load i32, ptr %l62
  %t115 = load i64, ptr %l63, !tbaa !24
  %t116 = load i1, ptr %l64, !tbaa !21
  %t117 = call %"compiler/diag:record" @compiler_2fdiag_3arecord_2ector(ptr %v0, ptr %v0, ptr %v0, { i64, [3 x i64] } %t111, { i64, ptr } %t112, { i64, ptr } %t113, i32 %t114, i64 %t115, i1 %t116)
  store %"compiler/diag:record" %t117, ptr %l65
  br label %bb22
bb22:
  %t118 = load ptr, ptr %l54, !tbaa !29
  %t119 = load %"compiler/diag:record", ptr %l65
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t118, %"compiler/diag:record" %t119)
  br label %bb23
bb23:
  %t120 = load ptr, ptr %l0, !tbaa !29
  store ptr %t120, ptr %l66, !tbaa !29
  %t121 = load ptr, ptr %l66, !tbaa !29
  %t122 = getelementptr %"compiler/diag:Diagnostics", ptr %t121, i32 0, i32 7
  store ptr %t122, ptr %l67, !tbaa !29
  %t123 = load ptr, ptr %l67, !tbaa !29
  %t124 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t123)
  store i64 %t124, ptr %l68
  br label %bb24
bb24:
  %t125 = load i64, ptr %l68, !tbaa !24
  %t126 = sub i64 %t125, 1
  store i64 %t126, ptr %l69, !tbaa !24
  %t127 = load i64, ptr %l69, !tbaa !24
  store i64 %t127, ptr %l7, !tbaa !24
  %t128 = load ptr, ptr %l0, !tbaa !29
  store ptr %t128, ptr %l70, !tbaa !29
  %t129 = load ptr, ptr %l70, !tbaa !29
  %t130 = getelementptr %"compiler/diag:Diagnostics", ptr %t129, i32 0, i32 12
  store ptr %t130, ptr %l71, !tbaa !29
  %t131 = load ptr, ptr %l71, !tbaa !29
  %t132 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %t131)
  store i64 %t132, ptr %l72
  br label %bb25
bb25:
  %t133 = load i64, ptr %l72, !tbaa !24
  store i64 %t133, ptr %l8, !tbaa !24
  %t134 = load i64, ptr %l4, !tbaa !24
  store i64 %t134, ptr %l73, !tbaa !24
  %t135 = load i64, ptr %l73, !tbaa !24
  %t136 = icmp sge i64 %t135, 0
  store i1 %t136, ptr %l74, !tbaa !21
  %t137 = load i1, ptr %l74, !tbaa !21
  br i1 %t137, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l75, !tbaa !29
  %t139 = load ptr, ptr %l75, !tbaa !29
  %t140 = getelementptr %"compiler/diag:Diagnostics", ptr %t139, i32 0, i32 8
  store ptr %t140, ptr %l76, !tbaa !29
  %t141 = load i64, ptr %l7, !tbaa !24
  store i64 %t141, ptr %l77, !tbaa !24
  %t142 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t142, ptr %l78
  %t143 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %s5)
  store %"compiler/msgs:Msg" %t143, ptr %l79
  br label %bb28
bb27:
  br label %bb31
bb28:
  %t144 = getelementptr %"compiler/msgs:Msg", ptr %l79, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  store { i64, ptr } %t145, ptr %l80, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s6
  store ptr %s6room, ptr %s6
  %t146 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t146, 1
  %t148 = extractvalue { i64, ptr } %t146, 0
  call void @__olang_sb_put(ptr %s6, ptr %t147, i64 %t148)
  %t149 = load ptr, ptr %s6
  %t150 = getelementptr %olang.builder, ptr %s6, i32 0, i32 1
  %t151 = load i64, ptr %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t151)
  call void @llvm.memcpy.p0.p0.i64(ptr %t152, ptr %t149, i64 %t151, i1 false)
  %t153 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  store { i64, ptr } %t154, ptr %l81, !tbaa !27
  call void @__olang_sb_done(ptr %s6)
  %t155 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t156 = extractvalue { i64, ptr } %t155, 0
  %t157 = extractvalue { i64, ptr } %t155, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l82, !tbaa !27
  %t162 = load i64, ptr %l77, !tbaa !24
  %t163 = load { i64, [3 x i64] }, ptr %l78
  %t164 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t165 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t162, { i64, [3 x i64] } %t163, { i64, ptr } %t164)
  store %"compiler/diag:note" %t165, ptr %l83
  br label %bb29
bb29:
  %t166 = load ptr, ptr %l76, !tbaa !29
  %t167 = load %"compiler/diag:note", ptr %l83
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t166, %"compiler/diag:note" %t167)
  br label %bb30
bb30:
  %t168 = load i64, ptr %l4, !tbaa !24
  store i64 %t168, ptr %l84, !tbaa !24
  %t169 = load i64, ptr %l84, !tbaa !24
  %t170 = add i64 %t169, 1
  store i64 %t170, ptr %l85, !tbaa !24
  %t171 = load i64, ptr %l85, !tbaa !24
  store i64 %t171, ptr %l8, !tbaa !24
  call void @__olang_scope_close(ptr %s5)
  br label %bb31
bb31:
  store i64 -1, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s7
  %t172 = load ptr, ptr %l0, !tbaa !29
  store ptr %t172, ptr %l86, !tbaa !29
  %t173 = load ptr, ptr %l86, !tbaa !29
  %t174 = getelementptr %"compiler/diag:Diagnostics", ptr %t173, i32 0, i32 13
  %t175 = load i64, ptr %t174, !tbaa !24
  store i64 %t175, ptr %l87, !tbaa !24
  %t176 = load i64, ptr %l87, !tbaa !24
  store i64 %t176, ptr %l11, !tbaa !24
  %t177 = load i64, ptr %l8, !tbaa !24
  store i64 %t177, ptr %l88, !tbaa !24
  %t178 = load i64, ptr %l88, !tbaa !24
  store i64 %t178, ptr %l12, !tbaa !24
  store i64 1, ptr %l13, !tbaa !24
  %t179 = load i64, ptr %l12, !tbaa !24
  store i64 %t179, ptr %l89, !tbaa !24
  %t180 = load i64, ptr %l11, !tbaa !24
  store i64 %t180, ptr %l90, !tbaa !24
  %t181 = load i64, ptr %l89, !tbaa !24
  %t182 = load i64, ptr %l90, !tbaa !24
  %t183 = icmp sgt i64 %t181, %t182
  store i1 %t183, ptr %l91, !tbaa !21
  %t184 = load i1, ptr %l91, !tbaa !21
  br i1 %t184, label %bb32, label %bb33
bb32:
  %t185 = load i64, ptr %l13, !tbaa !24
  store i64 %t185, ptr %l93, !tbaa !24
  %t186 = load i64, ptr %l93, !tbaa !24
  %t187 = icmp sgt i64 %t186, 0
  store i1 %t187, ptr %l94, !tbaa !21
  %t188 = load i1, ptr %l94, !tbaa !21
  br i1 %t188, label %bb34, label %bb35
bb33:
  store i64 0, ptr %l92, !tbaa !24
  br label %bb37
bb34:
  %t189 = load i64, ptr %l12, !tbaa !24
  store i64 %t189, ptr %l96, !tbaa !24
  %t190 = load i64, ptr %l11, !tbaa !24
  store i64 %t190, ptr %l97, !tbaa !24
  %t191 = load i64, ptr %l96, !tbaa !24
  %t192 = load i64, ptr %l97, !tbaa !24
  %t193 = sub i64 %t191, %t192
  store i64 %t193, ptr %l98, !tbaa !24
  %t194 = load i64, ptr %l13, !tbaa !24
  store i64 %t194, ptr %l99, !tbaa !24
  %t195 = load i64, ptr %l98, !tbaa !24
  %t196 = load i64, ptr %l99, !tbaa !24
  %t197 = add i64 %t195, %t196
  store i64 %t197, ptr %l100, !tbaa !24
  %t198 = load i64, ptr %l100, !tbaa !24
  %t199 = sub i64 %t198, 1
  store i64 %t199, ptr %l101, !tbaa !24
  %t200 = load i64, ptr %l13, !tbaa !24
  store i64 %t200, ptr %l102, !tbaa !24
  %t201 = load i64, ptr %l101, !tbaa !24
  %t202 = load i64, ptr %l102, !tbaa !24
  %t203 = sdiv i64 %t201, %t202
  store i64 %t203, ptr %l103, !tbaa !24
  %t204 = load i64, ptr %l103, !tbaa !24
  store i64 %t204, ptr %l95, !tbaa !24
  br label %bb36
bb35:
  store i64 0, ptr %l95, !tbaa !24
  br label %bb36
bb36:
  %t205 = load i64, ptr %l95, !tbaa !24
  store i64 %t205, ptr %l92, !tbaa !24
  br label %bb37
bb37:
  %t206 = load i64, ptr %l92, !tbaa !24
  store i64 %t206, ptr %l14, !tbaa !24
  store i64 0, ptr %l15, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s8
  %t207 = load i64, ptr %l15, !tbaa !24
  store i64 %t207, ptr %l104, !tbaa !24
  %t208 = load i64, ptr %l14, !tbaa !24
  store i64 %t208, ptr %l105, !tbaa !24
  %t209 = load i64, ptr %l104, !tbaa !24
  %t210 = load i64, ptr %l105, !tbaa !24
  %t211 = icmp slt i64 %t209, %t210
  store i1 %t211, ptr %l106, !tbaa !21
  %t212 = load i1, ptr %l106, !tbaa !21
  %t213 = xor i1 %t212, true
  store i1 %t213, ptr %l107, !tbaa !21
  %t214 = load i1, ptr %l107, !tbaa !21
  br i1 %t214, label %bb39, label %bb40
bb39:
  call void @__olang_scope_close(ptr %s8)
  br label %bb50
bb40:
  br label %bb41
bb41:
  %t215 = load i64, ptr %l11, !tbaa !24
  store i64 %t215, ptr %l108, !tbaa !24
  %t216 = load i64, ptr %l15, !tbaa !24
  store i64 %t216, ptr %l109, !tbaa !24
  %t217 = load i64, ptr %l13, !tbaa !24
  store i64 %t217, ptr %l110, !tbaa !24
  %t218 = load i64, ptr %l109, !tbaa !24
  %t219 = load i64, ptr %l110, !tbaa !24
  %t220 = mul i64 %t218, %t219
  store i64 %t220, ptr %l111, !tbaa !24
  %t221 = load i64, ptr %l108, !tbaa !24
  %t222 = load i64, ptr %l111, !tbaa !24
  %t223 = add i64 %t221, %t222
  store i64 %t223, ptr %l112, !tbaa !24
  %t224 = load i64, ptr %l112, !tbaa !24
  store i64 %t224, ptr %l16, !tbaa !24
  %t225 = load ptr, ptr %l0, !tbaa !29
  store ptr %t225, ptr %l113, !tbaa !29
  %t226 = load ptr, ptr %l113, !tbaa !29
  %t227 = getelementptr %"compiler/diag:Diagnostics", ptr %t226, i32 0, i32 12
  store ptr %t227, ptr %l114, !tbaa !29
  %t228 = load i64, ptr %l16, !tbaa !24
  store i64 %t228, ptr %l115, !tbaa !24
  %t229 = load ptr, ptr %l114, !tbaa !29
  %t230 = load i64, ptr %l115, !tbaa !24
  %t231 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t229, i64 %t230)
  store %"compiler/diag:context" %t231, ptr %l116
  br label %bb42
bb42:
  %t232 = getelementptr %"compiler/diag:context", ptr %l116, i32 0, i32 1
  %t233 = load { i64, ptr }, ptr %t232, !tbaa !27
  store { i64, ptr } %t233, ptr %l117, !tbaa !27
  %t234 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t235 = extractvalue { i64, ptr } %t234, 0
  store i64 %t235, ptr %l118, !tbaa !24
  %t236 = load i64, ptr %l118, !tbaa !24
  %t237 = icmp eq i64 %t236, 0
  store i1 %t237, ptr %l119, !tbaa !21
  %t238 = load i1, ptr %l119, !tbaa !21
  br i1 %t238, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s9
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb44:
  br label %bb45
bb45:
  %t239 = load i64, ptr %l9, !tbaa !24
  store i64 %t239, ptr %l120, !tbaa !24
  %t240 = load i64, ptr %l120, !tbaa !24
  %t241 = icmp slt i64 %t240, 0
  store i1 %t241, ptr %l121, !tbaa !21
  %t242 = load i1, ptr %l121, !tbaa !21
  br i1 %t242, label %bb46, label %bb47
bb46:
  store %olang.scope zeroinitializer, ptr %s10
  %t243 = load i64, ptr %l16, !tbaa !24
  store i64 %t243, ptr %l122, !tbaa !24
  %t244 = load i64, ptr %l122, !tbaa !24
  store i64 %t244, ptr %l9, !tbaa !24
  call void @__olang_scope_close(ptr %s10)
  br label %bb48
bb47:
  br label %bb48
bb48:
  %t245 = load i64, ptr %l10, !tbaa !24
  store i64 %t245, ptr %l123, !tbaa !24
  %t246 = load i64, ptr %l123, !tbaa !24
  %t247 = add i64 %t246, 1
  store i64 %t247, ptr %l124, !tbaa !24
  %t248 = load i64, ptr %l124, !tbaa !24
  store i64 %t248, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s8)
  br label %bb49
bb49:
  store %olang.scope zeroinitializer, ptr %s11
  %t249 = load i64, ptr %l15, !tbaa !24
  store i64 %t249, ptr %l125, !tbaa !24
  %t250 = load i64, ptr %l125, !tbaa !24
  %t251 = add i64 %t250, 1
  store i64 %t251, ptr %l126, !tbaa !24
  %t252 = load i64, ptr %l126, !tbaa !24
  store i64 %t252, ptr %l15, !tbaa !24
  call void @__olang_scope_close(ptr %s11)
  br label %bb38
bb50:
  call void @__olang_scope_close(ptr %s7)
  %t253 = load i64, ptr %l10, !tbaa !24
  store i64 %t253, ptr %l127, !tbaa !24
  %t254 = load i64, ptr %l127, !tbaa !24
  %t255 = icmp sgt i64 %t254, 3
  store i1 %t255, ptr %l128, !tbaa !21
  %t256 = load i1, ptr %l128, !tbaa !21
  br i1 %t256, label %bb51, label %bb52
bb51:
  store i64 2, ptr %l129, !tbaa !24
  br label %bb53
bb52:
  store i64 3, ptr %l129, !tbaa !24
  br label %bb53
bb53:
  %t257 = load i64, ptr %l129, !tbaa !24
  store i64 %t257, ptr %l17, !tbaa !24
  store i64 0, ptr %l18, !tbaa !24
  %t258 = load i64, ptr %l8, !tbaa !24
  store i64 %t258, ptr %l130, !tbaa !24
  %t259 = load i64, ptr %l130, !tbaa !24
  %t260 = sub i64 %t259, 1
  store i64 %t260, ptr %l131, !tbaa !24
  %t261 = load i64, ptr %l131, !tbaa !24
  store i64 %t261, ptr %l19, !tbaa !24
  br label %bb54
bb54:
  store %olang.scope zeroinitializer, ptr %s12
  %t262 = load i64, ptr %l19, !tbaa !24
  store i64 %t262, ptr %l132, !tbaa !24
  %t263 = load ptr, ptr %l0, !tbaa !29
  store ptr %t263, ptr %l133, !tbaa !29
  %t264 = load ptr, ptr %l133, !tbaa !29
  %t265 = getelementptr %"compiler/diag:Diagnostics", ptr %t264, i32 0, i32 13
  %t266 = load i64, ptr %t265, !tbaa !24
  store i64 %t266, ptr %l134, !tbaa !24
  %t267 = load i64, ptr %l132, !tbaa !24
  %t268 = load i64, ptr %l134, !tbaa !24
  %t269 = icmp sge i64 %t267, %t268
  store i1 %t269, ptr %l135, !tbaa !21
  %t270 = load i1, ptr %l135, !tbaa !21
  br i1 %t270, label %bb55, label %bb56
bb55:
  %t271 = load i64, ptr %l18, !tbaa !24
  store i64 %t271, ptr %l137, !tbaa !24
  %t272 = load i64, ptr %l17, !tbaa !24
  store i64 %t272, ptr %l138, !tbaa !24
  %t273 = load i64, ptr %l137, !tbaa !24
  %t274 = load i64, ptr %l138, !tbaa !24
  %t275 = icmp slt i64 %t273, %t274
  store i1 %t275, ptr %l139, !tbaa !21
  %t276 = load i1, ptr %l139, !tbaa !21
  store i1 %t276, ptr %l136, !tbaa !21
  br label %bb57
bb56:
  store i1 false, ptr %l136, !tbaa !21
  br label %bb57
bb57:
  %t277 = load i1, ptr %l136, !tbaa !21
  %t278 = xor i1 %t277, true
  store i1 %t278, ptr %l140, !tbaa !21
  %t279 = load i1, ptr %l140, !tbaa !21
  br i1 %t279, label %bb58, label %bb59
bb58:
  call void @__olang_scope_close(ptr %s12)
  br label %bb76
bb59:
  br label %bb60
bb60:
  %t280 = load ptr, ptr %l0, !tbaa !29
  store ptr %t280, ptr %l141, !tbaa !29
  %t281 = load ptr, ptr %l141, !tbaa !29
  %t282 = getelementptr %"compiler/diag:Diagnostics", ptr %t281, i32 0, i32 12
  store ptr %t282, ptr %l142, !tbaa !29
  %t283 = load i64, ptr %l19, !tbaa !24
  store i64 %t283, ptr %l143, !tbaa !24
  %t284 = load ptr, ptr %l142, !tbaa !29
  %t285 = load i64, ptr %l143, !tbaa !24
  %t286 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t284, i64 %t285)
  store %"compiler/diag:context" %t286, ptr %l144
  br label %bb61
bb61:
  %t287 = getelementptr %"compiler/diag:context", ptr %l144, i32 0, i32 1
  %t288 = load { i64, ptr }, ptr %t287, !tbaa !27
  store { i64, ptr } %t288, ptr %l145, !tbaa !27
  %t289 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t290 = extractvalue { i64, ptr } %t289, 0
  store i64 %t290, ptr %l146, !tbaa !24
  %t291 = load i64, ptr %l146, !tbaa !24
  %t292 = icmp sgt i64 %t291, 0
  store i1 %t292, ptr %l147, !tbaa !21
  %t293 = load i1, ptr %l147, !tbaa !21
  br i1 %t293, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s13
  %t294 = load i64, ptr %l19, !tbaa !24
  store i64 %t294, ptr %l148, !tbaa !24
  %t295 = load i64, ptr %l9, !tbaa !24
  store i64 %t295, ptr %l149, !tbaa !24
  %t296 = load i64, ptr %l148, !tbaa !24
  %t297 = load i64, ptr %l149, !tbaa !24
  %t298 = icmp eq i64 %t296, %t297
  store i1 %t298, ptr %l150, !tbaa !21
  %t299 = load i1, ptr %l150, !tbaa !21
  br i1 %t299, label %bb64, label %bb65
bb63:
  br label %bb74
bb64:
  %t300 = load i64, ptr %l10, !tbaa !24
  store i64 %t300, ptr %l152, !tbaa !24
  %t301 = load i64, ptr %l152, !tbaa !24
  %t302 = icmp sgt i64 %t301, 3
  store i1 %t302, ptr %l153, !tbaa !21
  %t303 = load i1, ptr %l153, !tbaa !21
  store i1 %t303, ptr %l151, !tbaa !21
  br label %bb66
bb65:
  store i1 false, ptr %l151, !tbaa !21
  br label %bb66
bb66:
  %t304 = load i1, ptr %l151, !tbaa !21
  br i1 %t304, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s14
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s12)
  br label %bb76
bb68:
  br label %bb69
bb69:
  %t305 = load ptr, ptr %l0, !tbaa !29
  store ptr %t305, ptr %l154, !tbaa !29
  %t306 = load ptr, ptr %l154, !tbaa !29
  %t307 = getelementptr %"compiler/diag:Diagnostics", ptr %t306, i32 0, i32 8
  store ptr %t307, ptr %l155, !tbaa !29
  %t308 = load i64, ptr %l7, !tbaa !24
  store i64 %t308, ptr %l156, !tbaa !24
  %t309 = load ptr, ptr %l0, !tbaa !29
  store ptr %t309, ptr %l157, !tbaa !29
  %t310 = load ptr, ptr %l157, !tbaa !29
  %t311 = getelementptr %"compiler/diag:Diagnostics", ptr %t310, i32 0, i32 12
  store ptr %t311, ptr %l158, !tbaa !29
  %t312 = load i64, ptr %l19, !tbaa !24
  store i64 %t312, ptr %l159, !tbaa !24
  %t313 = load ptr, ptr %l158, !tbaa !29
  %t314 = load i64, ptr %l159, !tbaa !24
  %t315 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t313, i64 %t314)
  store %"compiler/diag:context" %t315, ptr %l160
  br label %bb70
bb70:
  %t316 = getelementptr %"compiler/diag:context", ptr %l160, i32 0, i32 0
  %t317 = load { i64, [3 x i64] }, ptr %t316
  store { i64, [3 x i64] } %t317, ptr %l161
  %t318 = load ptr, ptr %l0, !tbaa !29
  store ptr %t318, ptr %l162, !tbaa !29
  %t319 = load ptr, ptr %l162, !tbaa !29
  %t320 = getelementptr %"compiler/diag:Diagnostics", ptr %t319, i32 0, i32 12
  store ptr %t320, ptr %l163, !tbaa !29
  %t321 = load i64, ptr %l19, !tbaa !24
  store i64 %t321, ptr %l164, !tbaa !24
  %t322 = load ptr, ptr %l163, !tbaa !29
  %t323 = load i64, ptr %l164, !tbaa !24
  %t324 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t322, i64 %t323)
  store %"compiler/diag:context" %t324, ptr %l165
  br label %bb71
bb71:
  %t325 = getelementptr %"compiler/diag:context", ptr %l165, i32 0, i32 1
  %t326 = load { i64, ptr }, ptr %t325, !tbaa !27
  store { i64, ptr } %t326, ptr %l166, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s15
  store ptr %s15room, ptr %s15
  %t327 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t328 = extractvalue { i64, ptr } %t327, 1
  %t329 = extractvalue { i64, ptr } %t327, 0
  call void @__olang_sb_put(ptr %s15, ptr %t328, i64 %t329)
  %t330 = load ptr, ptr %s15
  %t331 = getelementptr %olang.builder, ptr %s15, i32 0, i32 1
  %t332 = load i64, ptr %t331
  %t333 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t332)
  call void @llvm.memcpy.p0.p0.i64(ptr %t333, ptr %t330, i64 %t332, i1 false)
  %t334 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  store { i64, ptr } %t335, ptr %l167, !tbaa !27
  call void @__olang_sb_done(ptr %s15)
  %t336 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t336, 0
  %t338 = extractvalue { i64, ptr } %t336, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  store { i64, ptr } %t342, ptr %l168, !tbaa !27
  %t343 = load i64, ptr %l156, !tbaa !24
  %t344 = load { i64, [3 x i64] }, ptr %l161
  %t345 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t346 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t343, { i64, [3 x i64] } %t344, { i64, ptr } %t345)
  store %"compiler/diag:note" %t346, ptr %l169
  br label %bb72
bb72:
  %t347 = load ptr, ptr %l155, !tbaa !29
  %t348 = load %"compiler/diag:note", ptr %l169
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t347, %"compiler/diag:note" %t348)
  br label %bb73
bb73:
  %t349 = load i64, ptr %l18, !tbaa !24
  store i64 %t349, ptr %l170, !tbaa !24
  %t350 = load i64, ptr %l170, !tbaa !24
  %t351 = add i64 %t350, 1
  store i64 %t351, ptr %l171, !tbaa !24
  %t352 = load i64, ptr %l171, !tbaa !24
  store i64 %t352, ptr %l18, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb74
bb74:
  %t353 = load i64, ptr %l19, !tbaa !24
  store i64 %t353, ptr %l172, !tbaa !24
  %t354 = load i64, ptr %l172, !tbaa !24
  %t355 = sub i64 %t354, 1
  store i64 %t355, ptr %l173, !tbaa !24
  %t356 = load i64, ptr %l173, !tbaa !24
  store i64 %t356, ptr %l19, !tbaa !24
  call void @__olang_scope_close(ptr %s12)
  br label %bb75
bb75:
  br label %bb54
bb76:
  %t357 = load i64, ptr %l10, !tbaa !24
  store i64 %t357, ptr %l174, !tbaa !24
  %t358 = load i64, ptr %l174, !tbaa !24
  %t359 = icmp sgt i64 %t358, 3
  store i1 %t359, ptr %l175, !tbaa !21
  %t360 = load i1, ptr %l175, !tbaa !21
  br i1 %t360, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s16
  %t361 = load ptr, ptr %l0, !tbaa !29
  store ptr %t361, ptr %l176, !tbaa !29
  %t362 = load ptr, ptr %l176, !tbaa !29
  %t363 = getelementptr %"compiler/diag:Diagnostics", ptr %t362, i32 0, i32 8
  store ptr %t363, ptr %l177, !tbaa !29
  %t364 = load i64, ptr %l7, !tbaa !24
  store i64 %t364, ptr %l178, !tbaa !24
  %t365 = load ptr, ptr %l0, !tbaa !29
  store ptr %t365, ptr %l179, !tbaa !29
  %t366 = load ptr, ptr %l179, !tbaa !29
  %t367 = getelementptr %"compiler/diag:Diagnostics", ptr %t366, i32 0, i32 12
  store ptr %t367, ptr %l180, !tbaa !29
  %t368 = load i64, ptr %l9, !tbaa !24
  store i64 %t368, ptr %l181, !tbaa !24
  %t369 = load ptr, ptr %l180, !tbaa !29
  %t370 = load i64, ptr %l181, !tbaa !24
  %t371 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t369, i64 %t370)
  store %"compiler/diag:context" %t371, ptr %l182
  br label %bb79
bb78:
  br label %bb83
bb79:
  %t372 = getelementptr %"compiler/diag:context", ptr %l182, i32 0, i32 0
  %t373 = load { i64, [3 x i64] }, ptr %t372
  store { i64, [3 x i64] } %t373, ptr %l183
  %t374 = load ptr, ptr %l0, !tbaa !29
  store ptr %t374, ptr %l184, !tbaa !29
  %t375 = load ptr, ptr %l184, !tbaa !29
  %t376 = getelementptr %"compiler/diag:Diagnostics", ptr %t375, i32 0, i32 12
  store ptr %t376, ptr %l185, !tbaa !29
  %t377 = load i64, ptr %l9, !tbaa !24
  store i64 %t377, ptr %l186, !tbaa !24
  %t378 = load ptr, ptr %l185, !tbaa !29
  %t379 = load i64, ptr %l186, !tbaa !24
  %t380 = call %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v0, ptr %t378, i64 %t379)
  store %"compiler/diag:context" %t380, ptr %l187
  br label %bb80
bb80:
  %t381 = getelementptr %"compiler/diag:context", ptr %l187, i32 0, i32 1
  %t382 = load { i64, ptr }, ptr %t381, !tbaa !27
  store { i64, ptr } %t382, ptr %l188, !tbaa !27
  store %olang.builder { ptr null, i64 0, i64 64, ptr null, ptr null }, ptr %s17
  store ptr %s17room, ptr %s17
  %t383 = load { i64, ptr }, ptr %l188, !tbaa !27
  %t384 = extractvalue { i64, ptr } %t383, 1
  %t385 = extractvalue { i64, ptr } %t383, 0
  call void @__olang_sb_put(ptr %s17, ptr %t384, i64 %t385)
  %t386 = load ptr, ptr %s17
  %t387 = getelementptr %olang.builder, ptr %s17, i32 0, i32 1
  %t388 = load i64, ptr %t387
  %t389 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t388)
  call void @llvm.memcpy.p0.p0.i64(ptr %t389, ptr %t386, i64 %t388, i1 false)
  %t390 = insertvalue { i64, ptr } undef, i64 %t388, 0
  %t391 = insertvalue { i64, ptr } %t390, ptr %t389, 1
  store { i64, ptr } %t391, ptr %l189, !tbaa !27
  call void @__olang_sb_done(ptr %s17)
  %t392 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t393 = extractvalue { i64, ptr } %t392, 0
  %t394 = extractvalue { i64, ptr } %t392, 1
  %t395 = mul i64 %t393, 1
  %t396 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t395)
  call void @llvm.memcpy.p0.p0.i64(ptr %t396, ptr %t394, i64 %t395, i1 false)
  %t397 = insertvalue { i64, ptr } undef, i64 %t393, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  store { i64, ptr } %t398, ptr %l190, !tbaa !27
  %t399 = load i64, ptr %l178, !tbaa !24
  %t400 = load { i64, [3 x i64] }, ptr %l183
  %t401 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t402 = call %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v0, i64 %t399, { i64, [3 x i64] } %t400, { i64, ptr } %t401)
  store %"compiler/diag:note" %t402, ptr %l191
  br label %bb81
bb81:
  %t403 = load ptr, ptr %l177, !tbaa !29
  %t404 = load %"compiler/diag:note", ptr %l191
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v0, ptr %t403, %"compiler/diag:note" %t404)
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s16)
  br label %bb83
bb83:
  %t405 = load i64, ptr %l7, !tbaa !24
  store i64 %t405, ptr %l192, !tbaa !24
  call void @__olang_scope_close(ptr %s0)
  %t406 = load i64, ptr %l192, !tbaa !24
  store i64 %t406, ptr %rv
  br label %ret
ret:
  %rr = load i64, ptr %rv
  ret i64 %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2esgr(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca { i64, ptr }
  %l2 = alloca %"std/prelude/text:StringBuilder"
  %l3 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca i1
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/text:StringBuilder"
  %l11 = alloca ptr
  %l12 = alloca ptr
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca ptr
  %l16 = alloca ptr
  %l17 = alloca { i64, ptr }
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l3, !tbaa !29
  %t2 = load ptr, ptr %l3, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 0
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l4, !tbaa !21
  %t5 = load i1, ptr %l4, !tbaa !21
  %t6 = xor i1 %t5, true
  store i1 %t6, ptr %l5, !tbaa !21
  %t7 = load i1, ptr %l5, !tbaa !21
  br i1 %t7, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  store { i64, ptr } { i64 0, ptr @.d63 }, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t9, 0
  store i64 %t10, ptr %l8, !tbaa !24
  %t11 = load i64, ptr %l8, !tbaa !24
  %t12 = mul i64 %t11, 1
  %t13 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t12)
  %t14 = insertvalue { i64, ptr } undef, i64 %t11, 0
  %t15 = insertvalue { i64, ptr } %t14, ptr %t13, 1
  store { i64, ptr } %t15, ptr %l9, !tbaa !27
  %t16 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t17 = load ptr, ptr %t16, !tbaa !27
  %t18 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = load i64, ptr %l8, !tbaa !24
  %t21 = mul i64 %t20, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t17, ptr %t19, i64 %t21, i1 false)
  %t22 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t22, ptr %l7, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t23 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t23, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t24 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t24, ptr %l10
  br label %bb4
bb4:
  %t25 = load %"std/prelude/text:StringBuilder", ptr %l10
  store %"std/prelude/text:StringBuilder" %t25, ptr %l2
  store ptr %l2, ptr %l11, !tbaa !29
  %t26 = load ptr, ptr %l11, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t26, i8 27)
  br label %bb5
bb5:
  store ptr %l2, ptr %l12, !tbaa !29
  %t27 = load ptr, ptr %l12, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t27, { i64, ptr } { i64 1, ptr @.d64 })
  br label %bb6
bb6:
  store ptr %l2, ptr %l13, !tbaa !29
  %t28 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t28, ptr %l14, !tbaa !27
  %t29 = load ptr, ptr %l13, !tbaa !29
  %t30 = load { i64, ptr }, ptr %l14, !tbaa !27
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %v1, ptr %t29, { i64, ptr } %t30)
  br label %bb7
bb7:
  store ptr %l2, ptr %l15, !tbaa !29
  %t31 = load ptr, ptr %l15, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %s0, ptr %s0, ptr %t31, { i64, ptr } { i64 1, ptr @.d65 })
  br label %bb8
bb8:
  store ptr %l2, ptr %l16, !tbaa !29
  %t32 = load ptr, ptr %l16, !tbaa !29
  %t33 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v2, ptr %t32)
  store { i64, ptr } %t33, ptr %l17
  br label %bb9
bb9:
  %t34 = load { i64, ptr }, ptr %l17, !tbaa !27
  store { i64, ptr } %t34, ptr %l18, !tbaa !27
  %t35 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l19, !tbaa !24
  %t37 = load i64, ptr %l19, !tbaa !24
  %t38 = mul i64 %t37, 1
  %t39 = call ptr @__olang_scope_alloc_zeroed(ptr %v2, i64 %t38)
  %t40 = insertvalue { i64, ptr } undef, i64 %t37, 0
  %t41 = insertvalue { i64, ptr } %t40, ptr %t39, 1
  store { i64, ptr } %t41, ptr %l20, !tbaa !27
  %t42 = getelementptr { i64, ptr }, ptr %l20, i32 0, i32 1
  %t43 = load ptr, ptr %t42, !tbaa !27
  %t44 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t45 = load ptr, ptr %t44, !tbaa !27
  %t46 = load i64, ptr %l19, !tbaa !24
  %t47 = mul i64 %t46, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t43, ptr %t45, i64 %t47, i1 false)
  %t48 = load { i64, ptr }, ptr %l20, !tbaa !27
  store { i64, ptr } %t48, ptr %l18, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t49 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t49, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2ewritten(ptr %v0, ptr %v1, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/prelude/list:List<I64>"
  %l6 = alloca i64
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i64
  %l12 = alloca %"compiler/diag:record"
  %l13 = alloca { i64, [3 x i64] }
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca { i64, i64 }
  %l17 = alloca i64
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i1
  %l23 = alloca ptr
  %l24 = alloca i64
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca %"compiler/diag:record"
  %l30 = alloca { i64, ptr }
  %l31 = alloca i64
  %l32 = alloca ptr
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i64
  %l38 = alloca { i64, ptr }
  %l39 = alloca ptr
  %l40 = alloca ptr
  %l41 = alloca i64
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca { i64, ptr }
  %l46 = alloca i64
  %l47 = alloca i1
  %l48 = alloca i1
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca i1
  %l52 = alloca i1
  %l53 = alloca { i64, ptr }
  %l54 = alloca %"std/prelude/list:List<I64>"
  %l55 = alloca i64
  %l56 = alloca i64
  %l57 = alloca i64
  %l58 = alloca i1
  %l59 = alloca i64
  %l60 = alloca i64
  %l61 = alloca i1
  %l62 = alloca i64
  %l63 = alloca i64
  %l64 = alloca i64
  %l65 = alloca i64
  %l66 = alloca i64
  %l67 = alloca i64
  %l68 = alloca i64
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca i64
  %l72 = alloca i64
  %l73 = alloca i1
  %l74 = alloca i1
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i64
  %l78 = alloca i64
  %l79 = alloca i64
  %l80 = alloca ptr
  %l81 = alloca ptr
  %l82 = alloca i64
  %l83 = alloca %"compiler/diag:record"
  %l84 = alloca i64
  %l85 = alloca i64
  %l86 = alloca { i64, [3 x i64] }
  %l87 = alloca { i64, [3 x i64] }
  %l88 = alloca i1
  %l89 = alloca i64
  %l90 = alloca i64
  %l91 = alloca i64
  %l92 = alloca i64
  %l93 = alloca ptr
  %l94 = alloca i64
  %l95 = alloca i64
  %l96 = alloca { i64, i64 }
  %l97 = alloca i64
  %l98 = alloca i64
  %l99 = alloca i64
  %l100 = alloca i64
  %l101 = alloca i64
  %l102 = alloca i64
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i64
  %l106 = alloca { i64, [3 x i64] }
  %l107 = alloca i1
  %l108 = alloca i64
  %l109 = alloca i64
  %l110 = alloca i64
  %l111 = alloca i64
  %l112 = alloca i64
  %l113 = alloca i64
  %l114 = alloca { i64, [3 x i64] }
  %l115 = alloca i1
  %l116 = alloca i64
  %l117 = alloca i64
  %l118 = alloca i64
  %l119 = alloca ptr
  %l120 = alloca i64
  %l121 = alloca i1
  %l122 = alloca i1
  %l123 = alloca ptr
  %l124 = alloca { i64, ptr }
  %l125 = alloca ptr
  %l126 = alloca i64
  %l127 = alloca { i64, ptr }
  %l128 = alloca i32
  %l129 = alloca i32
  %l130 = alloca i1
  %l131 = alloca { i64, ptr }
  %l132 = alloca i64
  %l133 = alloca i64
  %l134 = alloca i64
  %l135 = alloca i1
  %l136 = alloca i1
  %l137 = alloca { i64, ptr }
  %l138 = alloca i64
  %l139 = alloca i64
  %l140 = alloca ptr
  %l141 = alloca ptr
  %l142 = alloca i64
  %l143 = alloca %"compiler/diag:record"
  %l144 = alloca i64
  %l145 = alloca i64
  %l146 = alloca i64
  %l147 = alloca i64
  %l148 = alloca i1
  %l149 = alloca i1
  %l150 = alloca i64
  %l151 = alloca i64
  %l152 = alloca i64
  %l153 = alloca i64
  %l154 = alloca i1
  %l155 = alloca i1
  %l156 = alloca i64
  %l157 = alloca i64
  %l158 = alloca i64
  %l159 = alloca i64
  %l160 = alloca i1
  %l161 = alloca i1
  %l162 = alloca { i64, ptr }
  %l163 = alloca { i64, ptr }
  %l164 = alloca i1
  %l165 = alloca i1
  %l166 = alloca i1
  %l167 = alloca i1
  %l168 = alloca i1
  %l169 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca i32
  %l172 = alloca ptr
  %l173 = alloca i1
  %l174 = alloca i1
  %l175 = alloca i64
  %l176 = alloca i64
  %l177 = alloca i64
  %l178 = alloca i64
  %l179 = alloca i1
  %l180 = alloca i1
  %l181 = alloca i64
  %l182 = alloca i64
  %l183 = alloca i64
  %l184 = alloca i64
  %l185 = alloca i1
  %l186 = alloca i64
  %l187 = alloca i64
  %l188 = alloca i64
  %l189 = alloca i64
  %l190 = alloca i64
  %l191 = alloca i1
  %l192 = alloca i1
  %l193 = alloca ptr
  %l194 = alloca i64
  %l195 = alloca i64
  %l196 = alloca i64
  %l197 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca i64
  %l200 = alloca i64
  %l201 = alloca i1
  %l202 = alloca i1
  %l203 = alloca { i64, ptr }
  %l204 = alloca ptr
  %l205 = alloca { i64, ptr }
  %l206 = alloca ptr
  %l207 = alloca i64
  %l208 = alloca { i64, ptr }
  %l209 = alloca i32
  %l210 = alloca i32
  %l211 = alloca i1
  %l212 = alloca { i64, ptr }
  %l213 = alloca i64
  %l214 = alloca i64
  %l215 = alloca i64
  %l216 = alloca i1
  %l217 = alloca i1
  %l218 = alloca { i64, ptr }
  %l219 = alloca i64
  %l220 = alloca i64
  %l221 = alloca i64
  %l222 = alloca i64
  %l223 = alloca i64
  %l224 = alloca i64
  %l225 = alloca i1
  %l226 = alloca i64
  %l227 = alloca i64
  %l228 = alloca i64
  %l229 = alloca i64
  %l230 = alloca i64
  %l231 = alloca i64
  %l232 = alloca i64
  %l233 = alloca i64
  %l234 = alloca i64
  %l235 = alloca i64
  %l236 = alloca i64
  %l237 = alloca ptr
  %l238 = alloca { i64, ptr }
  %l239 = alloca { i64, ptr }
  %l240 = alloca { i64, ptr }
  %l241 = alloca { i64, ptr }
  %l242 = alloca { i64, ptr }
  %l243 = alloca { ptr, ptr }
  %l244 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca i64
  %l247 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  %t415 = alloca i64
  %t516 = alloca { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, align 8
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l39, !tbaa !29
  %t2 = load ptr, ptr %l39, !tbaa !29
  %t3 = getelementptr %"compiler/diag:Diagnostics", ptr %t2, i32 0, i32 7
  store ptr %t3, ptr %l40, !tbaa !29
  %t4 = load ptr, ptr %l40, !tbaa !29
  %t5 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %t4)
  store i64 %t5, ptr %l41
  br label %bb1
bb1:
  %t6 = load i64, ptr %l41, !tbaa !24
  store i64 %t6, ptr %l1, !tbaa !24
  %t7 = load i64, ptr %l1, !tbaa !24
  store i64 %t7, ptr %l42, !tbaa !24
  %t8 = load i64, ptr %l42, !tbaa !24
  %t9 = icmp sge i64 %t8, 0
  store i1 %t9, ptr %l43, !tbaa !21
  %t10 = load i1, ptr %l43, !tbaa !21
  br i1 %t10, label %bb2, label %bb3
bb2:
  %t11 = load i64, ptr %l42, !tbaa !24
  %t12 = icmp sle i64 %t11, 1152921504606846975
  store i1 %t12, ptr %l44, !tbaa !21
  %t13 = load i1, ptr %l44, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb3:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb4:
  %t14 = load i64, ptr %l42, !tbaa !24
  %t15 = mul i64 %t14, 8
  %t16 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t15)
  %t17 = insertvalue { i64, ptr } undef, i64 %t14, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  store { i64, ptr } %t18, ptr %l45, !tbaa !27
  %t19 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t19, ptr %l2, !tbaa !27
  %t20 = load i64, ptr %l1, !tbaa !24
  store i64 %t20, ptr %l46, !tbaa !24
  %t21 = load i64, ptr %l46, !tbaa !24
  %t22 = icmp sge i64 %t21, 0
  store i1 %t22, ptr %l47, !tbaa !21
  %t23 = load i1, ptr %l47, !tbaa !21
  br i1 %t23, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c66)
  unreachable
bb6:
  %t24 = load i64, ptr %l46, !tbaa !24
  %t25 = icmp sle i64 %t24, 1152921504606846975
  store i1 %t25, ptr %l48, !tbaa !21
  %t26 = load i1, ptr %l48, !tbaa !21
  br i1 %t26, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb8:
  %t27 = load i64, ptr %l46, !tbaa !24
  %t28 = mul i64 %t27, 8
  %t29 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t28)
  %t30 = insertvalue { i64, ptr } undef, i64 %t27, 0
  %t31 = insertvalue { i64, ptr } %t30, ptr %t29, 1
  store { i64, ptr } %t31, ptr %l49, !tbaa !27
  %t32 = load { i64, ptr }, ptr %l49, !tbaa !27
  store { i64, ptr } %t32, ptr %l3, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l50, !tbaa !24
  %t34 = load i64, ptr %l50, !tbaa !24
  %t35 = icmp sge i64 %t34, 0
  store i1 %t35, ptr %l51, !tbaa !21
  %t36 = load i1, ptr %l51, !tbaa !21
  br i1 %t36, label %bb10, label %bb11
bb9:
  call void @__olang_check_failed(ptr @.c67)
  unreachable
bb10:
  %t37 = load i64, ptr %l50, !tbaa !24
  %t38 = icmp sle i64 %t37, 1152921504606846975
  store i1 %t38, ptr %l52, !tbaa !21
  %t39 = load i1, ptr %l52, !tbaa !21
  br i1 %t39, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb12:
  %t40 = load i64, ptr %l50, !tbaa !24
  %t41 = mul i64 %t40, 8
  %t42 = call ptr @__olang_scope_alloc_zeroed(ptr %s0, i64 %t41)
  %t43 = insertvalue { i64, ptr } undef, i64 %t40, 0
  %t44 = insertvalue { i64, ptr } %t43, ptr %t42, 1
  store { i64, ptr } %t44, ptr %l53, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l53, !tbaa !27
  store { i64, ptr } %t45, ptr %l4, !tbaa !27
  %t46 = load ptr, ptr @__olang_prog_scope
  %t47 = call %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %t46)
  store %"std/prelude/list:List<I64>" %t47, ptr %l54
  br label %bb14
bb13:
  call void @__olang_check_failed(ptr @.c68)
  unreachable
bb14:
  %t48 = load %"std/prelude/list:List<I64>", ptr %l54
  store %"std/prelude/list:List<I64>" %t48, ptr %l5
  store %olang.scope zeroinitializer, ptr %s1
  store i64 0, ptr %l6, !tbaa !24
  %t49 = load i64, ptr %l1, !tbaa !24
  store i64 %t49, ptr %l55, !tbaa !24
  %t50 = load i64, ptr %l55, !tbaa !24
  store i64 %t50, ptr %l7, !tbaa !24
  store i64 1, ptr %l8, !tbaa !24
  %t51 = load i64, ptr %l7, !tbaa !24
  store i64 %t51, ptr %l56, !tbaa !24
  %t52 = load i64, ptr %l6, !tbaa !24
  store i64 %t52, ptr %l57, !tbaa !24
  %t53 = load i64, ptr %l56, !tbaa !24
  %t54 = load i64, ptr %l57, !tbaa !24
  %t55 = icmp sgt i64 %t53, %t54
  store i1 %t55, ptr %l58, !tbaa !21
  %t56 = load i1, ptr %l58, !tbaa !21
  br i1 %t56, label %bb15, label %bb16
bb15:
  %t57 = load i64, ptr %l8, !tbaa !24
  store i64 %t57, ptr %l60, !tbaa !24
  %t58 = load i64, ptr %l60, !tbaa !24
  %t59 = icmp sgt i64 %t58, 0
  store i1 %t59, ptr %l61, !tbaa !21
  %t60 = load i1, ptr %l61, !tbaa !21
  br i1 %t60, label %bb17, label %bb18
bb16:
  store i64 0, ptr %l59, !tbaa !24
  br label %bb20
bb17:
  %t61 = load i64, ptr %l7, !tbaa !24
  store i64 %t61, ptr %l63, !tbaa !24
  %t62 = load i64, ptr %l6, !tbaa !24
  store i64 %t62, ptr %l64, !tbaa !24
  %t63 = load i64, ptr %l63, !tbaa !24
  %t64 = load i64, ptr %l64, !tbaa !24
  %t65 = sub i64 %t63, %t64
  store i64 %t65, ptr %l65, !tbaa !24
  %t66 = load i64, ptr %l8, !tbaa !24
  store i64 %t66, ptr %l66, !tbaa !24
  %t67 = load i64, ptr %l65, !tbaa !24
  %t68 = load i64, ptr %l66, !tbaa !24
  %t69 = add i64 %t67, %t68
  store i64 %t69, ptr %l67, !tbaa !24
  %t70 = load i64, ptr %l67, !tbaa !24
  %t71 = sub i64 %t70, 1
  store i64 %t71, ptr %l68, !tbaa !24
  %t72 = load i64, ptr %l8, !tbaa !24
  store i64 %t72, ptr %l69, !tbaa !24
  %t73 = load i64, ptr %l68, !tbaa !24
  %t74 = load i64, ptr %l69, !tbaa !24
  %t75 = sdiv i64 %t73, %t74
  store i64 %t75, ptr %l70, !tbaa !24
  %t76 = load i64, ptr %l70, !tbaa !24
  store i64 %t76, ptr %l62, !tbaa !24
  br label %bb19
bb18:
  store i64 0, ptr %l62, !tbaa !24
  br label %bb19
bb19:
  %t77 = load i64, ptr %l62, !tbaa !24
  store i64 %t77, ptr %l59, !tbaa !24
  br label %bb20
bb20:
  %t78 = load i64, ptr %l59, !tbaa !24
  store i64 %t78, ptr %l9, !tbaa !24
  store i64 0, ptr %l10, !tbaa !24
  br label %bb21
bb21:
  store %olang.scope zeroinitializer, ptr %s2
  %t79 = load i64, ptr %l10, !tbaa !24
  store i64 %t79, ptr %l71, !tbaa !24
  %t80 = load i64, ptr %l9, !tbaa !24
  store i64 %t80, ptr %l72, !tbaa !24
  %t81 = load i64, ptr %l71, !tbaa !24
  %t82 = load i64, ptr %l72, !tbaa !24
  %t83 = icmp slt i64 %t81, %t82
  store i1 %t83, ptr %l73, !tbaa !21
  %t84 = load i1, ptr %l73, !tbaa !21
  %t85 = xor i1 %t84, true
  store i1 %t85, ptr %l74, !tbaa !21
  %t86 = load i1, ptr %l74, !tbaa !21
  br i1 %t86, label %bb22, label %bb23
bb22:
  call void @__olang_scope_close(ptr %s2)
  br label %bb94
bb23:
  br label %bb24
bb24:
  %t87 = load i64, ptr %l6, !tbaa !24
  store i64 %t87, ptr %l75, !tbaa !24
  %t88 = load i64, ptr %l10, !tbaa !24
  store i64 %t88, ptr %l76, !tbaa !24
  %t89 = load i64, ptr %l8, !tbaa !24
  store i64 %t89, ptr %l77, !tbaa !24
  %t90 = load i64, ptr %l76, !tbaa !24
  %t91 = load i64, ptr %l77, !tbaa !24
  %t92 = mul i64 %t90, %t91
  store i64 %t92, ptr %l78, !tbaa !24
  %t93 = load i64, ptr %l75, !tbaa !24
  %t94 = load i64, ptr %l78, !tbaa !24
  %t95 = add i64 %t93, %t94
  store i64 %t95, ptr %l79, !tbaa !24
  %t96 = load i64, ptr %l79, !tbaa !24
  store i64 %t96, ptr %l11, !tbaa !24
  %t97 = load ptr, ptr %l0, !tbaa !29
  store ptr %t97, ptr %l80, !tbaa !29
  %t98 = load ptr, ptr %l80, !tbaa !29
  %t99 = getelementptr %"compiler/diag:Diagnostics", ptr %t98, i32 0, i32 7
  store ptr %t99, ptr %l81, !tbaa !29
  %t100 = load i64, ptr %l11, !tbaa !24
  store i64 %t100, ptr %l82, !tbaa !24
  %t101 = load ptr, ptr %l81, !tbaa !29
  %t102 = load i64, ptr %l82, !tbaa !24
  %t103 = call %"compiler/diag:record" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t101, i64 %t102)
  store %"compiler/diag:record" %t103, ptr %l83
  br label %bb25
bb25:
  %t104 = load %"compiler/diag:record", ptr %l83
  store %"compiler/diag:record" %t104, ptr %l12
  %t105 = load i64, ptr %l11, !tbaa !24
  store i64 %t105, ptr %l84, !tbaa !24
  %t106 = load i64, ptr %l84, !tbaa !24
  %t107 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t108 = load ptr, ptr %t107, !tbaa !27
  %t109 = getelementptr i64, ptr %t108, i64 %t106
  store i64 -1, ptr %t109, !tbaa !34
  %t110 = load i64, ptr %l11, !tbaa !24
  store i64 %t110, ptr %l85, !tbaa !24
  %t111 = load i64, ptr %l85, !tbaa !24
  %t112 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t113 = load ptr, ptr %t112, !tbaa !27
  %t114 = getelementptr i64, ptr %t113, i64 %t111
  store i64 9223372036854775807, ptr %t114, !tbaa !34
  %t115 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 0
  %t116 = load { i64, [3 x i64] }, ptr %t115
  store { i64, [3 x i64] } %t116, ptr %l86
  %t117 = load { i64, [3 x i64] }, ptr %l86
  store { i64, [3 x i64] } %t117, ptr %l13
  %t118 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t118, ptr %l87
  %t119 = load { i64, [3 x i64] }, ptr %l87
  %t120 = extractvalue { i64, [3 x i64] } %t119, 0
  %t121 = icmp eq i64 %t120, 3
  store i1 %t121, ptr %l88, !tbaa !21
  %t122 = load i1, ptr %l88, !tbaa !21
  br i1 %t122, label %bb26, label %bb27
bb26:
  %t123 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t124 = getelementptr { i64, i64, i64 }, ptr %t123, i32 0, i32 0
  %t125 = load i64, ptr %t124
  store i64 %t125, ptr %l89, !tbaa !24
  %t126 = load i64, ptr %l89, !tbaa !24
  store i64 %t126, ptr %l14, !tbaa !24
  %t127 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t128 = getelementptr { i64, i64, i64 }, ptr %t127, i32 0, i32 1
  %t129 = load i64, ptr %t128
  store i64 %t129, ptr %l90, !tbaa !24
  %t130 = load i64, ptr %l90, !tbaa !24
  store i64 %t130, ptr %l15, !tbaa !24
  br label %bb28
bb27:
  br label %bb30
bb28:
  store %olang.scope zeroinitializer, ptr %s3
  %t131 = load i64, ptr %l11, !tbaa !24
  store i64 %t131, ptr %l91, !tbaa !24
  %t132 = load i64, ptr %l14, !tbaa !24
  store i64 %t132, ptr %l92, !tbaa !24
  %t133 = load i64, ptr %l92, !tbaa !24
  %t134 = load i64, ptr %l91, !tbaa !24
  %t135 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t136 = load ptr, ptr %t135, !tbaa !27
  %t137 = getelementptr i64, ptr %t136, i64 %t134
  store i64 %t133, ptr %t137, !tbaa !34
  %t138 = load ptr, ptr %l0, !tbaa !29
  store ptr %t138, ptr %l93, !tbaa !29
  %t139 = load i64, ptr %l14, !tbaa !24
  store i64 %t139, ptr %l94, !tbaa !24
  %t140 = load i64, ptr %l15, !tbaa !24
  store i64 %t140, ptr %l95, !tbaa !24
  %t141 = load ptr, ptr %l93, !tbaa !29
  %t142 = load i64, ptr %l94, !tbaa !24
  %t143 = load i64, ptr %l95, !tbaa !24
  %t144 = call { i64, i64 } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2elineOf(ptr %v0, ptr %t141, i64 %t142, i64 %t143)
  store { i64, i64 } %t144, ptr %l96
  br label %bb29
bb29:
  %t145 = load { i64, i64 }, ptr %l96
  store { i64, i64 } %t145, ptr %l16
  %t146 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 0
  %t147 = load i64, ptr %t146, !tbaa !24
  store i64 %t147, ptr %l97, !tbaa !24
  %t148 = load i64, ptr %l97, !tbaa !24
  store i64 %t148, ptr %l17, !tbaa !24
  %t149 = getelementptr { i64, i64 }, ptr %l16, i32 0, i32 1
  %t150 = load i64, ptr %t149, !tbaa !24
  store i64 %t150, ptr %l98, !tbaa !24
  %t151 = load i64, ptr %l98, !tbaa !24
  store i64 %t151, ptr %l18, !tbaa !24
  %t152 = load i64, ptr %l11, !tbaa !24
  store i64 %t152, ptr %l99, !tbaa !24
  %t153 = load i64, ptr %l17, !tbaa !24
  store i64 %t153, ptr %l100, !tbaa !24
  %t154 = load i64, ptr %l100, !tbaa !24
  %t155 = load i64, ptr %l99, !tbaa !24
  %t156 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t157 = load ptr, ptr %t156, !tbaa !27
  %t158 = getelementptr i64, ptr %t157, i64 %t155
  store i64 %t154, ptr %t158, !tbaa !34
  %t159 = load i64, ptr %l11, !tbaa !24
  store i64 %t159, ptr %l101, !tbaa !24
  %t160 = load i64, ptr %l15, !tbaa !24
  store i64 %t160, ptr %l102, !tbaa !24
  %t161 = load i64, ptr %l18, !tbaa !24
  store i64 %t161, ptr %l103, !tbaa !24
  %t162 = load i64, ptr %l102, !tbaa !24
  %t163 = load i64, ptr %l103, !tbaa !24
  %t164 = sub i64 %t162, %t163
  store i64 %t164, ptr %l104, !tbaa !24
  %t165 = load i64, ptr %l104, !tbaa !24
  %t166 = add i64 %t165, 1
  store i64 %t166, ptr %l105, !tbaa !24
  %t167 = load i64, ptr %l105, !tbaa !24
  %t168 = load i64, ptr %l101, !tbaa !24
  %t169 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t170 = load ptr, ptr %t169, !tbaa !27
  %t171 = getelementptr i64, ptr %t170, i64 %t168
  store i64 %t167, ptr %t171, !tbaa !34
  call void @__olang_scope_close(ptr %s3)
  br label %bb39
bb30:
  %t172 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t172, ptr %l106
  %t173 = load { i64, [3 x i64] }, ptr %l106
  %t174 = extractvalue { i64, [3 x i64] } %t173, 0
  %t175 = icmp eq i64 %t174, 2
  store i1 %t175, ptr %l107, !tbaa !21
  %t176 = load i1, ptr %l107, !tbaa !21
  br i1 %t176, label %bb31, label %bb32
bb31:
  %t177 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t178 = getelementptr { i64, i64 }, ptr %t177, i32 0, i32 0
  %t179 = load i64, ptr %t178
  store i64 %t179, ptr %l108, !tbaa !24
  %t180 = load i64, ptr %l108, !tbaa !24
  store i64 %t180, ptr %l19, !tbaa !24
  %t181 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t182 = getelementptr { i64, i64 }, ptr %t181, i32 0, i32 1
  %t183 = load i64, ptr %t182
  store i64 %t183, ptr %l109, !tbaa !24
  %t184 = load i64, ptr %l109, !tbaa !24
  store i64 %t184, ptr %l20, !tbaa !24
  br label %bb33
bb32:
  br label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s4
  %t185 = load i64, ptr %l11, !tbaa !24
  store i64 %t185, ptr %l110, !tbaa !24
  %t186 = load i64, ptr %l19, !tbaa !24
  store i64 %t186, ptr %l111, !tbaa !24
  %t187 = load i64, ptr %l111, !tbaa !24
  %t188 = load i64, ptr %l110, !tbaa !24
  %t189 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr i64, ptr %t190, i64 %t188
  store i64 %t187, ptr %t191, !tbaa !34
  %t192 = load i64, ptr %l11, !tbaa !24
  store i64 %t192, ptr %l112, !tbaa !24
  %t193 = load i64, ptr %l20, !tbaa !24
  store i64 %t193, ptr %l113, !tbaa !24
  %t194 = load i64, ptr %l113, !tbaa !24
  %t195 = load i64, ptr %l112, !tbaa !24
  %t196 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t197 = load ptr, ptr %t196, !tbaa !27
  %t198 = getelementptr i64, ptr %t197, i64 %t195
  store i64 %t194, ptr %t198, !tbaa !34
  call void @__olang_scope_close(ptr %s4)
  br label %bb39
bb34:
  %t199 = load { i64, [3 x i64] }, ptr %l13
  store { i64, [3 x i64] } %t199, ptr %l114
  %t200 = load { i64, [3 x i64] }, ptr %l114
  %t201 = extractvalue { i64, [3 x i64] } %t200, 0
  %t202 = icmp eq i64 %t201, 1
  store i1 %t202, ptr %l115, !tbaa !21
  %t203 = load i1, ptr %l115, !tbaa !21
  br i1 %t203, label %bb35, label %bb36
bb35:
  %t204 = getelementptr { i64, [3 x i64] }, ptr %l13, i32 0, i32 1
  %t205 = getelementptr { i64 }, ptr %t204, i32 0, i32 0
  %t206 = load i64, ptr %t205
  store i64 %t206, ptr %l116, !tbaa !24
  %t207 = load i64, ptr %l116, !tbaa !24
  store i64 %t207, ptr %l21, !tbaa !24
  br label %bb37
bb36:
  br label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s5
  %t208 = load i64, ptr %l11, !tbaa !24
  store i64 %t208, ptr %l117, !tbaa !24
  %t209 = load i64, ptr %l21, !tbaa !24
  store i64 %t209, ptr %l118, !tbaa !24
  %t210 = load i64, ptr %l118, !tbaa !24
  %t211 = load i64, ptr %l117, !tbaa !24
  %t212 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t213 = load ptr, ptr %t212, !tbaa !27
  %t214 = getelementptr i64, ptr %t213, i64 %t211
  store i64 %t210, ptr %t214, !tbaa !34
  call void @__olang_scope_close(ptr %s5)
  br label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  call void @__olang_scope_close(ptr %s6)
  br label %bb39
bb39:
  %t215 = load ptr, ptr %l0, !tbaa !29
  store ptr %t215, ptr %l119, !tbaa !29
  %t216 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 4
  %t217 = load i64, ptr %t216, !tbaa !24
  store i64 %t217, ptr %l120, !tbaa !24
  %t218 = load ptr, ptr %l119, !tbaa !29
  %t219 = load i64, ptr %l120, !tbaa !24
  %t220 = call i1 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2echosen(ptr %v0, ptr %t218, i64 %t219)
  store i1 %t220, ptr %l121
  br label %bb40
bb40:
  %t221 = load i1, ptr %l121, !tbaa !21
  %t222 = xor i1 %t221, true
  store i1 %t222, ptr %l122, !tbaa !21
  %t223 = load i1, ptr %l122, !tbaa !21
  br i1 %t223, label %bb41, label %bb42
bb41:
  store %olang.scope zeroinitializer, ptr %s7
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s2)
  br label %bb93
bb42:
  br label %bb43
bb43:
  store i1 false, ptr %l22, !tbaa !21
  store %olang.scope zeroinitializer, ptr %s8
  store ptr %l5, ptr %l123, !tbaa !29
  %t224 = load ptr, ptr %l123, !tbaa !29
  store ptr %t224, ptr %l23, !tbaa !29
  store i64 0, ptr %l24, !tbaa !24
  br label %bb44
bb44:
  store %olang.scope zeroinitializer, ptr %s9
  %t225 = load ptr, ptr %l23, !tbaa !29
  store ptr %t225, ptr %l125, !tbaa !29
  %t226 = load i64, ptr %l24, !tbaa !24
  store i64 %t226, ptr %l126, !tbaa !24
  %t227 = load ptr, ptr %l125, !tbaa !29
  %t228 = load i64, ptr %l126, !tbaa !24
  %t229 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t227, i64 %t228)
  %t230 = extractvalue { i32, { i64, ptr } } %t229, 1
  %t231 = extractvalue { i32, { i64, ptr } } %t229, 0
  store i32 %t231, ptr %l128
  %t232 = icmp ne i32 %t231, 0
  br i1 %t232, label %bb46, label %ok.233
ok.233:
  store { i64, ptr } %t230, ptr %l127
  br label %bb45
bb45:
  %t234 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t234, ptr %l124, !tbaa !27
  br label %bb50
bb46:
  %t235 = load i32, ptr %l128, !tbaa !23
  %t236 = ashr i32 %t235, 16
  store i32 %t236, ptr %l129, !tbaa !23
  %t237 = load i32, ptr %l129, !tbaa !23
  %t238 = icmp eq i32 %t237, 1
  store i1 %t238, ptr %l130, !tbaa !21
  %t239 = load i1, ptr %l130, !tbaa !21
  br i1 %t239, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @.c69)
  unreachable
bb49:
  call void @__olang_scope_close(ptr %s9)
  br label %bb88
bb50:
  %t240 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t240, ptr %l25, !tbaa !27
  %t241 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t241, ptr %l131, !tbaa !27
  %t242 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t243 = extractvalue { i64, ptr } %t242, 0
  store i64 %t243, ptr %l132, !tbaa !24
  %t244 = load i64, ptr %l132, !tbaa !24
  store i64 %t244, ptr %l26, !tbaa !24
  store i64 0, ptr %l27, !tbaa !24
  br label %bb51
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t245 = load i64, ptr %l27, !tbaa !24
  store i64 %t245, ptr %l133, !tbaa !24
  %t246 = load i64, ptr %l26, !tbaa !24
  store i64 %t246, ptr %l134, !tbaa !24
  %t247 = load i64, ptr %l133, !tbaa !24
  %t248 = load i64, ptr %l134, !tbaa !24
  %t249 = icmp slt i64 %t247, %t248
  store i1 %t249, ptr %l135, !tbaa !21
  %t250 = load i1, ptr %l135, !tbaa !21
  %t251 = xor i1 %t250, true
  store i1 %t251, ptr %l136, !tbaa !21
  %t252 = load i1, ptr %l136, !tbaa !21
  br i1 %t252, label %bb52, label %bb53
bb52:
  call void @__olang_scope_close(ptr %s10)
  br label %bb86
bb53:
  br label %bb54
bb54:
  %t253 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t253, ptr %l137, !tbaa !27
  %t254 = load i64, ptr %l27, !tbaa !24
  store i64 %t254, ptr %l138, !tbaa !24
  %t255 = load i64, ptr %l138, !tbaa !24
  %t256 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t257 = load ptr, ptr %t256, !tbaa !27
  %t258 = getelementptr i64, ptr %t257, i64 %t255
  %t259 = load i64, ptr %t258, !tbaa !34
  store i64 %t259, ptr %l139, !tbaa !24
  %t260 = load i64, ptr %l139, !tbaa !24
  store i64 %t260, ptr %l28, !tbaa !24
  %t261 = load ptr, ptr %l0, !tbaa !29
  store ptr %t261, ptr %l140, !tbaa !29
  %t262 = load ptr, ptr %l140, !tbaa !29
  %t263 = getelementptr %"compiler/diag:Diagnostics", ptr %t262, i32 0, i32 7
  store ptr %t263, ptr %l141, !tbaa !29
  %t264 = load i64, ptr %l28, !tbaa !24
  store i64 %t264, ptr %l142, !tbaa !24
  %t265 = load ptr, ptr %l141, !tbaa !29
  %t266 = load i64, ptr %l142, !tbaa !24
  %t267 = call %"compiler/diag:record" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v0, ptr %t265, i64 %t266)
  store %"compiler/diag:record" %t267, ptr %l143
  br label %bb55
bb55:
  %t268 = load %"compiler/diag:record", ptr %l143
  store %"compiler/diag:record" %t268, ptr %l29
  %t269 = load i64, ptr %l28, !tbaa !24
  store i64 %t269, ptr %l144, !tbaa !24
  %t270 = load i64, ptr %l144, !tbaa !24
  %t271 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t272 = load ptr, ptr %t271, !tbaa !27
  %t273 = getelementptr i64, ptr %t272, i64 %t270
  %t274 = load i64, ptr %t273, !tbaa !34
  store i64 %t274, ptr %l145, !tbaa !24
  %t275 = load i64, ptr %l11, !tbaa !24
  store i64 %t275, ptr %l146, !tbaa !24
  %t276 = load i64, ptr %l146, !tbaa !24
  %t277 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr i64, ptr %t278, i64 %t276
  %t280 = load i64, ptr %t279, !tbaa !34
  store i64 %t280, ptr %l147, !tbaa !24
  %t281 = load i64, ptr %l145, !tbaa !24
  %t282 = load i64, ptr %l147, !tbaa !24
  %t283 = icmp eq i64 %t281, %t282
  store i1 %t283, ptr %l148, !tbaa !21
  %t284 = load i1, ptr %l148, !tbaa !21
  br i1 %t284, label %bb56, label %bb57
bb56:
  %t285 = load i64, ptr %l28, !tbaa !24
  store i64 %t285, ptr %l150, !tbaa !24
  %t286 = load i64, ptr %l150, !tbaa !24
  %t287 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t288 = load ptr, ptr %t287, !tbaa !27
  %t289 = getelementptr i64, ptr %t288, i64 %t286
  %t290 = load i64, ptr %t289, !tbaa !34
  store i64 %t290, ptr %l151, !tbaa !24
  %t291 = load i64, ptr %l11, !tbaa !24
  store i64 %t291, ptr %l152, !tbaa !24
  %t292 = load i64, ptr %l152, !tbaa !24
  %t293 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t294 = load ptr, ptr %t293, !tbaa !27
  %t295 = getelementptr i64, ptr %t294, i64 %t292
  %t296 = load i64, ptr %t295, !tbaa !34
  store i64 %t296, ptr %l153, !tbaa !24
  %t297 = load i64, ptr %l151, !tbaa !24
  %t298 = load i64, ptr %l153, !tbaa !24
  %t299 = icmp eq i64 %t297, %t298
  store i1 %t299, ptr %l154, !tbaa !21
  %t300 = load i1, ptr %l154, !tbaa !21
  store i1 %t300, ptr %l149, !tbaa !21
  br label %bb58
bb57:
  store i1 false, ptr %l149, !tbaa !21
  br label %bb58
bb58:
  %t301 = load i1, ptr %l149, !tbaa !21
  br i1 %t301, label %bb59, label %bb60
bb59:
  %t302 = load i64, ptr %l28, !tbaa !24
  store i64 %t302, ptr %l156, !tbaa !24
  %t303 = load i64, ptr %l156, !tbaa !24
  %t304 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t305 = load ptr, ptr %t304, !tbaa !27
  %t306 = getelementptr i64, ptr %t305, i64 %t303
  %t307 = load i64, ptr %t306, !tbaa !34
  store i64 %t307, ptr %l157, !tbaa !24
  %t308 = load i64, ptr %l11, !tbaa !24
  store i64 %t308, ptr %l158, !tbaa !24
  %t309 = load i64, ptr %l158, !tbaa !24
  %t310 = getelementptr { i64, ptr }, ptr %l3, i32 0, i32 1
  %t311 = load ptr, ptr %t310, !tbaa !27
  %t312 = getelementptr i64, ptr %t311, i64 %t309
  %t313 = load i64, ptr %t312, !tbaa !34
  store i64 %t313, ptr %l159, !tbaa !24
  %t314 = load i64, ptr %l157, !tbaa !24
  %t315 = load i64, ptr %l159, !tbaa !24
  %t316 = icmp eq i64 %t314, %t315
  store i1 %t316, ptr %l160, !tbaa !21
  %t317 = load i1, ptr %l160, !tbaa !21
  store i1 %t317, ptr %l155, !tbaa !21
  br label %bb61
bb60:
  store i1 false, ptr %l155, !tbaa !21
  br label %bb61
bb61:
  %t318 = load i1, ptr %l155, !tbaa !21
  br i1 %t318, label %bb62, label %bb63
bb62:
  %t319 = getelementptr %"compiler/diag:record", ptr %l29, i32 0, i32 2
  %t320 = load { i64, ptr }, ptr %t319, !tbaa !27
  store { i64, ptr } %t320, ptr %l162, !tbaa !27
  %t321 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 2
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !27
  store { i64, ptr } %t322, ptr %l163, !tbaa !27
  %t323 = load { i64, ptr }, ptr %l162, !tbaa !27
  %t324 = load { i64, ptr }, ptr %l163, !tbaa !27
  %t325 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v0, { i64, ptr } %t323, { i64, ptr } %t324)
  store i1 %t325, ptr %l164
  br label %bb64
bb63:
  store i1 false, ptr %l161, !tbaa !21
  br label %bb65
bb64:
  %t326 = load i1, ptr %l164, !tbaa !21
  store i1 %t326, ptr %l161, !tbaa !21
  br label %bb65
bb65:
  %t327 = load i1, ptr %l161, !tbaa !21
  br i1 %t327, label %bb66, label %bb67
bb66:
  store %olang.scope zeroinitializer, ptr %s11
  store i1 true, ptr %l22, !tbaa !21
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb67:
  br label %bb68
bb68:
  %t328 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 5
  %t329 = load i1, ptr %t328, !tbaa !21
  store i1 %t329, ptr %l165, !tbaa !21
  %t330 = load i1, ptr %l165, !tbaa !21
  br i1 %t330, label %bb69, label %bb70
bb69:
  %t331 = getelementptr %"compiler/diag:record", ptr %l29, i32 0, i32 5
  %t332 = load i1, ptr %t331, !tbaa !21
  store i1 %t332, ptr %l167, !tbaa !21
  %t333 = load i1, ptr %l167, !tbaa !21
  store i1 %t333, ptr %l166, !tbaa !21
  br label %bb71
bb70:
  store i1 false, ptr %l166, !tbaa !21
  br label %bb71
bb71:
  %t334 = load i1, ptr %l166, !tbaa !21
  br i1 %t334, label %bb72, label %bb73
bb72:
  %t335 = getelementptr %"compiler/diag:record", ptr %l29, i32 0, i32 3
  %t336 = load i32, ptr %t335
  store i32 %t336, ptr %l169
  store ptr %l169, ptr %l170, !tbaa !29
  %t337 = getelementptr %"compiler/diag:record", ptr %l12, i32 0, i32 3
  %t338 = load i32, ptr %t337
  store i32 %t338, ptr %l171
  store ptr %l171, ptr %l172, !tbaa !29
  %t339 = load ptr, ptr %l170, !tbaa !29
  %t340 = load ptr, ptr %l172, !tbaa !29
  %t341 = call i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmsgs_3aDiag(ptr %t339, ptr %t340)
  store i1 %t341, ptr %l173
  br label %bb74
bb73:
  store i1 false, ptr %l168, !tbaa !21
  br label %bb75
bb74:
  %t342 = load i1, ptr %l173, !tbaa !21
  store i1 %t342, ptr %l168, !tbaa !21
  br label %bb75
bb75:
  %t343 = load i1, ptr %l168, !tbaa !21
  br i1 %t343, label %bb76, label %bb77
bb76:
  %t344 = load i64, ptr %l28, !tbaa !24
  store i64 %t344, ptr %l175, !tbaa !24
  %t345 = load i64, ptr %l175, !tbaa !24
  %t346 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t347 = load ptr, ptr %t346, !tbaa !27
  %t348 = getelementptr i64, ptr %t347, i64 %t345
  %t349 = load i64, ptr %t348, !tbaa !34
  store i64 %t349, ptr %l176, !tbaa !24
  %t350 = load i64, ptr %l11, !tbaa !24
  store i64 %t350, ptr %l177, !tbaa !24
  %t351 = load i64, ptr %l177, !tbaa !24
  %t352 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = getelementptr i64, ptr %t353, i64 %t351
  %t355 = load i64, ptr %t354, !tbaa !34
  store i64 %t355, ptr %l178, !tbaa !24
  %t356 = load i64, ptr %l176, !tbaa !24
  %t357 = load i64, ptr %l178, !tbaa !24
  %t358 = icmp eq i64 %t356, %t357
  store i1 %t358, ptr %l179, !tbaa !21
  %t359 = load i1, ptr %l179, !tbaa !21
  store i1 %t359, ptr %l174, !tbaa !21
  br label %bb78
bb77:
  store i1 false, ptr %l174, !tbaa !21
  br label %bb78
bb78:
  %t360 = load i1, ptr %l174, !tbaa !21
  br i1 %t360, label %bb79, label %bb80
bb79:
  %t361 = load i64, ptr %l28, !tbaa !24
  store i64 %t361, ptr %l181, !tbaa !24
  %t362 = load i64, ptr %l181, !tbaa !24
  %t363 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t364 = load ptr, ptr %t363, !tbaa !27
  %t365 = getelementptr i64, ptr %t364, i64 %t362
  %t366 = load i64, ptr %t365, !tbaa !34
  store i64 %t366, ptr %l182, !tbaa !24
  %t367 = load i64, ptr %l11, !tbaa !24
  store i64 %t367, ptr %l183, !tbaa !24
  %t368 = load i64, ptr %l183, !tbaa !24
  %t369 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t370 = load ptr, ptr %t369, !tbaa !27
  %t371 = getelementptr i64, ptr %t370, i64 %t368
  %t372 = load i64, ptr %t371, !tbaa !34
  store i64 %t372, ptr %l184, !tbaa !24
  %t373 = load i64, ptr %l182, !tbaa !24
  %t374 = load i64, ptr %l184, !tbaa !24
  %t375 = icmp eq i64 %t373, %t374
  store i1 %t375, ptr %l185, !tbaa !21
  %t376 = load i1, ptr %l185, !tbaa !21
  store i1 %t376, ptr %l180, !tbaa !21
  br label %bb81
bb80:
  store i1 false, ptr %l180, !tbaa !21
  br label %bb81
bb81:
  %t377 = load i1, ptr %l180, !tbaa !21
  br i1 %t377, label %bb82, label %bb83
bb82:
  store %olang.scope zeroinitializer, ptr %s12
  store i1 true, ptr %l22, !tbaa !21
  call void @__olang_scope_close(ptr %s12)
  br label %bb84
bb83:
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s10)
  br label %bb85
bb85:
  store %olang.scope zeroinitializer, ptr %s13
  %t378 = load i64, ptr %l27, !tbaa !24
  store i64 %t378, ptr %l186, !tbaa !24
  %t379 = load i64, ptr %l186, !tbaa !24
  %t380 = add i64 %t379, 1
  store i64 %t380, ptr %l187, !tbaa !24
  %t381 = load i64, ptr %l187, !tbaa !24
  store i64 %t381, ptr %l27, !tbaa !24
  call void @__olang_scope_close(ptr %s13)
  br label %bb51
bb86:
  %t382 = load i64, ptr %l24, !tbaa !24
  store i64 %t382, ptr %l188, !tbaa !24
  %t383 = load i64, ptr %l26, !tbaa !24
  store i64 %t383, ptr %l189, !tbaa !24
  %t384 = load i64, ptr %l188, !tbaa !24
  %t385 = load i64, ptr %l189, !tbaa !24
  %t386 = add i64 %t384, %t385
  store i64 %t386, ptr %l190, !tbaa !24
  %t387 = load i64, ptr %l190, !tbaa !24
  store i64 %t387, ptr %l24, !tbaa !24
  call void @__olang_scope_close(ptr %s9)
  br label %bb87
bb87:
  br label %bb44
bb88:
  call void @__olang_scope_close(ptr %s8)
  %t388 = load i1, ptr %l22, !tbaa !21
  store i1 %t388, ptr %l191, !tbaa !21
  %t389 = load i1, ptr %l191, !tbaa !21
  %t390 = xor i1 %t389, true
  store i1 %t390, ptr %l192, !tbaa !21
  %t391 = load i1, ptr %l192, !tbaa !21
  br i1 %t391, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s14
  store ptr %l5, ptr %l193, !tbaa !29
  %t392 = load i64, ptr %l11, !tbaa !24
  store i64 %t392, ptr %l194, !tbaa !24
  %t393 = load ptr, ptr %l193, !tbaa !29
  %t394 = load i64, ptr %l194, !tbaa !24
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %s0, ptr %t393, i64 %t394)
  br label %bb91
bb90:
  br label %bb92
bb91:
  call void @__olang_scope_close(ptr %s14)
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s2)
  br label %bb93
bb93:
  store %olang.scope zeroinitializer, ptr %s15
  %t395 = load i64, ptr %l10, !tbaa !24
  store i64 %t395, ptr %l195, !tbaa !24
  %t396 = load i64, ptr %l195, !tbaa !24
  %t397 = add i64 %t396, 1
  store i64 %t397, ptr %l196, !tbaa !24
  %t398 = load i64, ptr %l196, !tbaa !24
  store i64 %t398, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s15)
  br label %bb21
bb94:
  call void @__olang_scope_close(ptr %s1)
  %t399 = load ptr, ptr %l0, !tbaa !29
  store ptr %t399, ptr %l197, !tbaa !29
  %t400 = load ptr, ptr %l197, !tbaa !29
  %t401 = getelementptr %"compiler/diag:Diagnostics", ptr %t400, i32 0, i32 1
  store ptr %t401, ptr %l198, !tbaa !29
  %t402 = load ptr, ptr %l198, !tbaa !29
  %t403 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %t402)
  store i64 %t403, ptr %l199
  br label %bb95
bb95:
  %t404 = load i64, ptr %l199, !tbaa !24
  %t405 = add i64 %t404, 1
  store i64 %t405, ptr %l200, !tbaa !24
  %t406 = load i64, ptr %l200, !tbaa !24
  %t407 = icmp sge i64 %t406, 0
  store i1 %t407, ptr %l201, !tbaa !21
  %t408 = load i1, ptr %l201, !tbaa !21
  br i1 %t408, label %bb96, label %bb97
bb96:
  %t409 = load i64, ptr %l200, !tbaa !24
  %t410 = icmp sle i64 %t409, 1152921504606846975
  store i1 %t410, ptr %l202, !tbaa !21
  %t411 = load i1, ptr %l202, !tbaa !21
  br i1 %t411, label %bb98, label %bb99
bb97:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb98:
  %t412 = load i64, ptr %l200, !tbaa !24
  %t413 = mul i64 %t412, 8
  %t414 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t413)
  store i64 0, ptr %t415
  br label %fill.416
fill.416:
  %t419 = load i64, ptr %t415
  %t420 = icmp slt i64 %t419, %t412
  br i1 %t420, label %fillb.417, label %filld.418
fillb.417:
  %t421 = getelementptr i64, ptr %t414, i64 %t419
  store i64 -1, ptr %t421
  %t422 = add i64 %t419, 1
  store i64 %t422, ptr %t415
  br label %fill.416
filld.418:
  %t423 = insertvalue { i64, ptr } undef, i64 %t412, 0
  %t424 = insertvalue { i64, ptr } %t423, ptr %t414, 1
  store { i64, ptr } %t424, ptr %l203, !tbaa !27
  %t425 = load { i64, ptr }, ptr %l203, !tbaa !27
  store { i64, ptr } %t425, ptr %l30, !tbaa !27
  store i64 0, ptr %l31, !tbaa !24
  store %olang.scope zeroinitializer, ptr %s16
  store ptr %l5, ptr %l204, !tbaa !29
  %t426 = load ptr, ptr %l204, !tbaa !29
  store ptr %t426, ptr %l32, !tbaa !29
  store i64 0, ptr %l33, !tbaa !24
  br label %bb100
bb99:
  call void @__olang_check_failed(ptr @.c70)
  unreachable
bb100:
  store %olang.scope zeroinitializer, ptr %s17
  %t427 = load ptr, ptr %l32, !tbaa !29
  store ptr %t427, ptr %l206, !tbaa !29
  %t428 = load i64, ptr %l33, !tbaa !24
  store i64 %t428, ptr %l207, !tbaa !24
  %t429 = load ptr, ptr %l206, !tbaa !29
  %t430 = load i64, ptr %l207, !tbaa !24
  %t431 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %s0, ptr %t429, i64 %t430)
  %t432 = extractvalue { i32, { i64, ptr } } %t431, 1
  %t433 = extractvalue { i32, { i64, ptr } } %t431, 0
  store i32 %t433, ptr %l209
  %t434 = icmp ne i32 %t433, 0
  br i1 %t434, label %bb102, label %ok.435
ok.435:
  store { i64, ptr } %t432, ptr %l208
  br label %bb101
bb101:
  %t436 = load { i64, ptr }, ptr %l208, !tbaa !27
  store { i64, ptr } %t436, ptr %l205, !tbaa !27
  br label %bb106
bb102:
  %t437 = load i32, ptr %l209, !tbaa !23
  %t438 = ashr i32 %t437, 16
  store i32 %t438, ptr %l210, !tbaa !23
  %t439 = load i32, ptr %l210, !tbaa !23
  %t440 = icmp eq i32 %t439, 1
  store i1 %t440, ptr %l211, !tbaa !21
  %t441 = load i1, ptr %l211, !tbaa !21
  br i1 %t441, label %bb103, label %bb104
bb103:
  br label %bb105
bb104:
  call void @__olang_check_failed(ptr @.c71)
  unreachable
bb105:
  call void @__olang_scope_close(ptr %s17)
  br label %bb117
bb106:
  %t442 = load { i64, ptr }, ptr %l205, !tbaa !27
  store { i64, ptr } %t442, ptr %l34, !tbaa !27
  %t443 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t443, ptr %l212, !tbaa !27
  %t444 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t445 = extractvalue { i64, ptr } %t444, 0
  store i64 %t445, ptr %l213, !tbaa !24
  %t446 = load i64, ptr %l213, !tbaa !24
  store i64 %t446, ptr %l35, !tbaa !24
  store i64 0, ptr %l36, !tbaa !24
  br label %bb107
bb107:
  store %olang.scope zeroinitializer, ptr %s18
  %t447 = load i64, ptr %l36, !tbaa !24
  store i64 %t447, ptr %l214, !tbaa !24
  %t448 = load i64, ptr %l35, !tbaa !24
  store i64 %t448, ptr %l215, !tbaa !24
  %t449 = load i64, ptr %l214, !tbaa !24
  %t450 = load i64, ptr %l215, !tbaa !24
  %t451 = icmp slt i64 %t449, %t450
  store i1 %t451, ptr %l216, !tbaa !21
  %t452 = load i1, ptr %l216, !tbaa !21
  %t453 = xor i1 %t452, true
  store i1 %t453, ptr %l217, !tbaa !21
  %t454 = load i1, ptr %l217, !tbaa !21
  br i1 %t454, label %bb108, label %bb109
bb108:
  call void @__olang_scope_close(ptr %s18)
  br label %bb115
bb109:
  br label %bb110
bb110:
  %t455 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t455, ptr %l218, !tbaa !27
  %t456 = load i64, ptr %l36, !tbaa !24
  store i64 %t456, ptr %l219, !tbaa !24
  %t457 = load i64, ptr %l219, !tbaa !24
  %t458 = getelementptr { i64, ptr }, ptr %l218, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr i64, ptr %t459, i64 %t457
  %t461 = load i64, ptr %t460, !tbaa !34
  store i64 %t461, ptr %l220, !tbaa !24
  %t462 = load i64, ptr %l220, !tbaa !24
  store i64 %t462, ptr %l37, !tbaa !24
  %t463 = load i64, ptr %l37, !tbaa !24
  store i64 %t463, ptr %l221, !tbaa !24
  %t464 = load i64, ptr %l221, !tbaa !24
  %t465 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t466 = load ptr, ptr %t465, !tbaa !27
  %t467 = getelementptr i64, ptr %t466, i64 %t464
  %t468 = load i64, ptr %t467, !tbaa !34
  store i64 %t468, ptr %l222, !tbaa !24
  %t469 = load i64, ptr %l222, !tbaa !24
  %t470 = add i64 %t469, 1
  store i64 %t470, ptr %l223, !tbaa !24
  %t471 = load i64, ptr %l223, !tbaa !24
  %t472 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t473 = load ptr, ptr %t472, !tbaa !27
  %t474 = getelementptr i64, ptr %t473, i64 %t471
  %t475 = load i64, ptr %t474, !tbaa !34
  store i64 %t475, ptr %l224, !tbaa !24
  %t476 = load i64, ptr %l224, !tbaa !24
  %t477 = icmp slt i64 %t476, 0
  store i1 %t477, ptr %l225, !tbaa !21
  %t478 = load i1, ptr %l225, !tbaa !21
  br i1 %t478, label %bb111, label %bb112
bb111:
  store %olang.scope zeroinitializer, ptr %s19
  %t479 = load i64, ptr %l37, !tbaa !24
  store i64 %t479, ptr %l226, !tbaa !24
  %t480 = load i64, ptr %l226, !tbaa !24
  %t481 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t482 = load ptr, ptr %t481, !tbaa !27
  %t483 = getelementptr i64, ptr %t482, i64 %t480
  %t484 = load i64, ptr %t483, !tbaa !34
  store i64 %t484, ptr %l227, !tbaa !24
  %t485 = load i64, ptr %l227, !tbaa !24
  %t486 = add i64 %t485, 1
  store i64 %t486, ptr %l228, !tbaa !24
  %t487 = load i64, ptr %l31, !tbaa !24
  store i64 %t487, ptr %l229, !tbaa !24
  %t488 = load i64, ptr %l229, !tbaa !24
  %t489 = load i64, ptr %l228, !tbaa !24
  %t490 = getelementptr { i64, ptr }, ptr %l30, i32 0, i32 1
  %t491 = load ptr, ptr %t490, !tbaa !27
  %t492 = getelementptr i64, ptr %t491, i64 %t489
  store i64 %t488, ptr %t492, !tbaa !34
  %t493 = load i64, ptr %l31, !tbaa !24
  store i64 %t493, ptr %l230, !tbaa !24
  %t494 = load i64, ptr %l230, !tbaa !24
  %t495 = add i64 %t494, 1
  store i64 %t495, ptr %l231, !tbaa !24
  %t496 = load i64, ptr %l231, !tbaa !24
  store i64 %t496, ptr %l31, !tbaa !24
  call void @__olang_scope_close(ptr %s19)
  br label %bb113
bb112:
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s18)
  br label %bb114
bb114:
  store %olang.scope zeroinitializer, ptr %s20
  %t497 = load i64, ptr %l36, !tbaa !24
  store i64 %t497, ptr %l232, !tbaa !24
  %t498 = load i64, ptr %l232, !tbaa !24
  %t499 = add i64 %t498, 1
  store i64 %t499, ptr %l233, !tbaa !24
  %t500 = load i64, ptr %l233, !tbaa !24
  store i64 %t500, ptr %l36, !tbaa !24
  call void @__olang_scope_close(ptr %s20)
  br label %bb107
bb115:
  %t501 = load i64, ptr %l33, !tbaa !24
  store i64 %t501, ptr %l234, !tbaa !24
  %t502 = load i64, ptr %l35, !tbaa !24
  store i64 %t502, ptr %l235, !tbaa !24
  %t503 = load i64, ptr %l234, !tbaa !24
  %t504 = load i64, ptr %l235, !tbaa !24
  %t505 = add i64 %t503, %t504
  store i64 %t505, ptr %l236, !tbaa !24
  %t506 = load i64, ptr %l236, !tbaa !24
  store i64 %t506, ptr %l33, !tbaa !24
  call void @__olang_scope_close(ptr %s17)
  br label %bb116
bb116:
  br label %bb100
bb117:
  call void @__olang_scope_close(ptr %s16)
  store ptr %l5, ptr %l237, !tbaa !29
  %t507 = load ptr, ptr %l237, !tbaa !29
  %t508 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %s0, ptr %s0, ptr %t507)
  store { i64, ptr } %t508, ptr %l238
  br label %bb118
bb118:
  %t509 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t509, ptr %l38, !tbaa !27
  %t510 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t510, ptr %l239, !tbaa !27
  %t511 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t511, ptr %l240, !tbaa !27
  %t512 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t512, ptr %l241, !tbaa !27
  %t513 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t513, ptr %l242, !tbaa !27
  %t514 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr null, i32 1
  %t515 = ptrtoint ptr %t514 to i64
  %t517 = load { i64, ptr }, ptr %l240, !tbaa !27
  %t518 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t516, i32 0, i32 0
  store { i64, ptr } %t517, ptr %t518, !tbaa !28
  %t519 = load { i64, ptr }, ptr %l241, !tbaa !27
  %t520 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t516, i32 0, i32 1
  store { i64, ptr } %t519, ptr %t520, !tbaa !28
  %t521 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t522 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t516, i32 0, i32 2
  store { i64, ptr } %t521, ptr %t522, !tbaa !28
  %t523 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t516, i32 0, i32 3
  store ptr %s0, ptr %t523, !tbaa !28
  %t524 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t516, i32 0, i32 4
  store ptr %s0, ptr %t524, !tbaa !28
  %t525 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %t516, i32 0, i32 5
  store ptr %s0, ptr %t525, !tbaa !28
  %t526 = insertvalue { ptr, ptr } undef, ptr @olang_lambda_72, 0
  %t527 = insertvalue { ptr, ptr } %t526, ptr %t516, 1
  store { ptr, ptr } %t527, ptr %l243
  %t528 = load { i64, ptr }, ptr %l239, !tbaa !27
  %t529 = load { ptr, ptr }, ptr %l243
  %t530 = extractvalue { ptr, ptr } %t529, 0
  %t531 = extractvalue { ptr, ptr } %t529, 1
  call void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %s0, ptr %s0, { i64, ptr } %t528, ptr %t530, ptr %t531)
  br label %bb119
bb119:
  %t532 = load { i64, ptr }, ptr %l38, !tbaa !27
  store { i64, ptr } %t532, ptr %l244, !tbaa !27
  %t533 = load { i64, ptr }, ptr %l244, !tbaa !27
  store { i64, ptr } %t533, ptr %l245, !tbaa !27
  %t534 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t535 = extractvalue { i64, ptr } %t534, 0
  store i64 %t535, ptr %l246, !tbaa !24
  %t536 = load i64, ptr %l246, !tbaa !24
  %t537 = mul i64 %t536, 8
  %t538 = call ptr @__olang_scope_alloc_zeroed(ptr %v1, i64 %t537)
  %t539 = insertvalue { i64, ptr } undef, i64 %t536, 0
  %t540 = insertvalue { i64, ptr } %t539, ptr %t538, 1
  store { i64, ptr } %t540, ptr %l247, !tbaa !27
  %t541 = getelementptr { i64, ptr }, ptr %l247, i32 0, i32 1
  %t542 = load ptr, ptr %t541, !tbaa !27
  %t543 = getelementptr { i64, ptr }, ptr %l245, i32 0, i32 1
  %t544 = load ptr, ptr %t543, !tbaa !27
  %t545 = load i64, ptr %l246, !tbaa !24
  %t546 = mul i64 %t545, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t542, ptr %t544, i64 %t546, i1 false)
  %t547 = load { i64, ptr }, ptr %l247, !tbaa !27
  store { i64, ptr } %t547, ptr %l245, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t548 = load { i64, ptr }, ptr %l245, !tbaa !27
  store { i64, ptr } %t548, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdiag_2econtinues(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i8
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca i8
  %l6 = alloca i8
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  store i8 %t2, ptr %l2, !tbaa !22
  %t3 = load i8, ptr %l2, !tbaa !22
  %t4 = icmp uge i8 %t3, -128
  store i1 %t4, ptr %l3, !tbaa !21
  %t5 = load i1, ptr %l3, !tbaa !21
  br i1 %t5, label %bb1, label %bb2
bb1:
  %t6 = load i8, ptr %l0, !tbaa !22
  store i8 %t6, ptr %l5, !tbaa !22
  %t7 = load i8, ptr %l5, !tbaa !22
  store i8 %t7, ptr %l6, !tbaa !22
  %t8 = load i8, ptr %l6, !tbaa !22
  %t9 = icmp ult i8 %t8, -64
  store i1 %t9, ptr %l7, !tbaa !21
  %t10 = load i1, ptr %l7, !tbaa !21
  store i1 %t10, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l4, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i1 @compiler_2fdiag_2eisScopeRule(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca i1
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i8
  %l7 = alloca i1
  %l8 = alloca i1
  %l9 = alloca { i64, ptr }
  %l10 = alloca i8
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca { i64, ptr }
  %l14 = alloca i1
  %l15 = alloca i1
  %l16 = alloca { i64, ptr }
  %l17 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l1, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t3 = extractvalue { i64, ptr } %t2, 0
  store i64 %t3, ptr %l2, !tbaa !24
  %t4 = load i64, ptr %l2, !tbaa !24
  %t5 = icmp sge i64 %t4, 2
  store i1 %t5, ptr %l3, !tbaa !21
  %t6 = load i1, ptr %l3, !tbaa !21
  br i1 %t6, label %bb1, label %bb2
bb1:
  %t7 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t7, ptr %l5, !tbaa !27
  %t8 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t9 = load ptr, ptr %t8, !tbaa !27
  %t10 = getelementptr i8, ptr %t9, i64 0
  %t11 = load i8, ptr %t10, !tbaa !32
  store i8 %t11, ptr %l6, !tbaa !22
  %t12 = load i8, ptr %l6, !tbaa !22
  %t13 = icmp eq i8 %t12, 79
  store i1 %t13, ptr %l7, !tbaa !21
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %l4, !tbaa !21
  br label %bb3
bb2:
  store i1 false, ptr %l4, !tbaa !21
  br label %bb3
bb3:
  %t15 = load i1, ptr %l4, !tbaa !21
  br i1 %t15, label %bb4, label %bb5
bb4:
  %t16 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t16, ptr %l9, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l9, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = getelementptr i8, ptr %t18, i64 1
  %t20 = load i8, ptr %t19, !tbaa !32
  store i8 %t20, ptr %l10, !tbaa !22
  %t21 = load i8, ptr %l10, !tbaa !22
  %t22 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t21)
  store i1 %t22, ptr %l11
  br label %bb6
bb5:
  store i1 false, ptr %l8, !tbaa !21
  br label %bb7
bb6:
  %t23 = load i1, ptr %l11, !tbaa !21
  store i1 %t23, ptr %l8, !tbaa !21
  br label %bb7
bb7:
  %t24 = load i1, ptr %l8, !tbaa !21
  br i1 %t24, label %bb8, label %bb9
bb8:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 true, ptr %l12, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i1, ptr %l12, !tbaa !21
  store i1 %t25, ptr %rv
  br label %ret
bb9:
  br label %bb10
bb10:
  %t26 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t26, ptr %l13, !tbaa !27
  %t27 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t28 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t27, { i64, ptr } { i64 3, ptr @.d73 })
  store i1 %t28, ptr %l14
  br label %bb11
bb11:
  %t29 = load i1, ptr %l14, !tbaa !21
  br i1 %t29, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l15, !tbaa !21
  br label %bb15
bb13:
  %t30 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t30, ptr %l16, !tbaa !27
  %t31 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t32 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t31, { i64, ptr } { i64 4, ptr @.d74 })
  store i1 %t32, ptr %l17
  br label %bb14
bb14:
  %t33 = load i1, ptr %l17, !tbaa !21
  store i1 %t33, ptr %l15, !tbaa !21
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i1, ptr %l15, !tbaa !21
  store i1 %t34, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local i8 @compiler_2fdiag_2eprintable(i8 %a0) #0 {
entry:
  %l0 = alloca i8
  %l1 = alloca i8
  %l2 = alloca i1
  %l3 = alloca i8
  %l4 = alloca i8
  %l5 = alloca i8
  %l6 = alloca i1
  %l7 = alloca i1
  %l8 = alloca i8
  %l9 = alloca i8
  %l10 = alloca i1
  %l11 = alloca i8
  %l12 = alloca i8
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i8
  store i8 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i8, ptr %l0, !tbaa !22
  store i8 %t1, ptr %l1, !tbaa !22
  %t2 = load i8, ptr %l1, !tbaa !22
  %t3 = icmp eq i8 %t2, 9
  store i1 %t3, ptr %l2, !tbaa !21
  %t4 = load i1, ptr %l2, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t5 = load i8, ptr %l0, !tbaa !22
  store i8 %t5, ptr %l3, !tbaa !22
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t6 = load i8, ptr %l3, !tbaa !22
  store i8 %t6, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t7 = load i8, ptr %l0, !tbaa !22
  store i8 %t7, ptr %l4, !tbaa !22
  %t8 = load i8, ptr %l4, !tbaa !22
  store i8 %t8, ptr %l5, !tbaa !22
  %t9 = load i8, ptr %l5, !tbaa !22
  %t10 = icmp ult i8 %t9, 32
  store i1 %t10, ptr %l6, !tbaa !21
  %t11 = load i1, ptr %l6, !tbaa !21
  br i1 %t11, label %bb4, label %bb5
bb4:
  store i1 true, ptr %l7, !tbaa !21
  br label %bb6
bb5:
  %t12 = load i8, ptr %l0, !tbaa !22
  store i8 %t12, ptr %l8, !tbaa !22
  %t13 = load i8, ptr %l8, !tbaa !22
  store i8 %t13, ptr %l9, !tbaa !22
  %t14 = load i8, ptr %l9, !tbaa !22
  %t15 = icmp eq i8 %t14, 127
  store i1 %t15, ptr %l10, !tbaa !21
  %t16 = load i1, ptr %l10, !tbaa !21
  store i1 %t16, ptr %l7, !tbaa !21
  br label %bb6
bb6:
  %t17 = load i1, ptr %l7, !tbaa !21
  br i1 %t17, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  store i8 63, ptr %l11, !tbaa !22
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t18 = load i8, ptr %l11, !tbaa !22
  store i8 %t18, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  %t19 = load i8, ptr %l0, !tbaa !22
  store i8 %t19, ptr %l12, !tbaa !22
  call void @__olang_scope_close(ptr %s0)
  %t20 = load i8, ptr %l12, !tbaa !22
  store i8 %t20, ptr %rv
  br label %ret
ret:
  %rr = load i8, ptr %rv
  ret i8 %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2eruleIdAt(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca i1
  %l13 = alloca i1
  %l14 = alloca { i64, ptr }
  %l15 = alloca { i64, ptr }
  %l16 = alloca { i64, ptr }
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l19 = alloca i64
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca i1
  %l23 = alloca { i64, ptr }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca i1
  %l27 = alloca i1
  %l28 = alloca { i64, ptr }
  %l29 = alloca i1
  %l30 = alloca i1
  %l31 = alloca i1
  %l32 = alloca { i64, ptr }
  %l33 = alloca i8
  %l34 = alloca i1
  %l35 = alloca i1
  %l36 = alloca i1
  %l37 = alloca { i64, ptr }
  %l38 = alloca i8
  %l39 = alloca i1
  %l40 = alloca i1
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i1
  %l44 = alloca i1
  %l45 = alloca i1
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l50 = alloca i1
  %l51 = alloca i1
  %l52 = alloca { i64, ptr }
  %l53 = alloca i64
  %l54 = alloca i8
  %l55 = alloca i1
  %l56 = alloca i1
  %l57 = alloca i64
  %l58 = alloca i64
  %l59 = alloca i64
  %l60 = alloca { i64, ptr }
  %l61 = alloca i64
  %l62 = alloca i1
  %l63 = alloca i1
  %l64 = alloca { i64, ptr }
  %l65 = alloca i64
  %l66 = alloca i8
  %l67 = alloca i1
  %l68 = alloca i1
  %l69 = alloca i64
  %l70 = alloca i64
  %l71 = alloca { i64, ptr }
  %l72 = alloca i64
  %l73 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l75 = alloca i64
  %l76 = alloca i64
  %l77 = alloca i1
  %l78 = alloca i1
  %l79 = alloca i1
  %l80 = alloca { i64, ptr }
  %l81 = alloca i1
  %l82 = alloca i1
  %l83 = alloca i1
  %l84 = alloca { i64, ptr }
  %l85 = alloca i64
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l88 = alloca i64
  %l89 = alloca i64
  %l90 = alloca i1
  %l91 = alloca i1
  %l92 = alloca i1
  %l93 = alloca { i64, ptr }
  %l94 = alloca i1
  %l95 = alloca i1
  %l96 = alloca { i64, ptr }
  %l97 = alloca i64
  %l98 = alloca i1
  %l99 = alloca i1
  %l100 = alloca i1
  %l101 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l103 = alloca i64
  %l104 = alloca i64
  %l105 = alloca i1
  %l106 = alloca i1
  %l107 = alloca i1
  %l108 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  store { i64, ptr } %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l3, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t3 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t2, { i64, ptr } { i64 2, ptr @.d75 })
  store i1 %t3, ptr %l4
  br label %bb1
bb1:
  %t4 = load i1, ptr %l4, !tbaa !21
  br i1 %t4, label %bb2, label %bb3
bb2:
  %t5 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t5, ptr %l6, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t6, ptr %l7, !tbaa !27
  %t7 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t7, ptr %l8, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l9, !tbaa !24
  %t10 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t11 = extractvalue { i64, ptr } %t10, 0
  store i64 %t11, ptr %l10, !tbaa !24
  %t12 = icmp sge i64 2, 0
  store i1 %t12, ptr %l11, !tbaa !21
  %t13 = load i1, ptr %l11, !tbaa !21
  br i1 %t13, label %bb4, label %bb5
bb3:
  %t14 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t14, ptr %l15, !tbaa !27
  %t15 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t16, ptr %l17, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t18 = extractvalue { i64, ptr } %t17, 0
  store i64 %t18, ptr %l18, !tbaa !24
  %t19 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t20 = extractvalue { i64, ptr } %t19, 0
  store i64 %t20, ptr %l19, !tbaa !24
  %t21 = icmp sge i64 0, 0
  store i1 %t21, ptr %l20, !tbaa !21
  %t22 = load i1, ptr %l20, !tbaa !21
  br i1 %t22, label %bb10, label %bb11
bb4:
  %t23 = load i64, ptr %l9, !tbaa !24
  %t24 = icmp sle i64 2, %t23
  store i1 %t24, ptr %l12, !tbaa !21
  %t25 = load i1, ptr %l12, !tbaa !21
  br i1 %t25, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb6:
  %t26 = load i64, ptr %l9, !tbaa !24
  %t27 = load i64, ptr %l10, !tbaa !24
  %t28 = icmp sle i64 %t26, %t27
  store i1 %t28, ptr %l13, !tbaa !21
  %t29 = load i1, ptr %l13, !tbaa !21
  br i1 %t29, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb8:
  %t30 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t31 = load ptr, ptr %t30, !tbaa !27
  %t32 = load i64, ptr %l9, !tbaa !24
  %t33 = getelementptr i8, ptr %t31, i64 2
  %t34 = sub i64 %t32, 2
  %t35 = insertvalue { i64, ptr } undef, i64 %t34, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t33, 1
  store { i64, ptr } %t36, ptr %l14, !tbaa !27
  %t37 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t37, ptr %l5, !tbaa !27
  br label %bb16
bb9:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb10:
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sle i64 0, %t38
  store i1 %t39, ptr %l21, !tbaa !21
  %t40 = load i1, ptr %l21, !tbaa !21
  br i1 %t40, label %bb12, label %bb13
bb11:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb12:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l19, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  store i1 %t43, ptr %l22, !tbaa !21
  %t44 = load i1, ptr %l22, !tbaa !21
  br i1 %t44, label %bb14, label %bb15
bb13:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb14:
  %t45 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l18, !tbaa !24
  %t48 = getelementptr i8, ptr %t46, i64 0
  %t49 = sub i64 %t47, 0
  %t50 = insertvalue { i64, ptr } undef, i64 %t49, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t48, 1
  store { i64, ptr } %t51, ptr %l23, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l23, !tbaa !27
  store { i64, ptr } %t52, ptr %l5, !tbaa !27
  br label %bb16
bb15:
  call void @__olang_check_failed(ptr @.c76)
  unreachable
bb16:
  %t53 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t53, ptr %l1, !tbaa !27
  %t54 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t54, ptr %l24, !tbaa !27
  %t55 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t56 = extractvalue { i64, ptr } %t55, 0
  store i64 %t56, ptr %l25, !tbaa !24
  %t57 = load i64, ptr %l25, !tbaa !24
  %t58 = icmp slt i64 %t57, 4
  store i1 %t58, ptr %l26, !tbaa !21
  %t59 = load i1, ptr %l26, !tbaa !21
  br i1 %t59, label %bb17, label %bb18
bb17:
  store i1 true, ptr %l27, !tbaa !21
  br label %bb20
bb18:
  %t60 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t60, ptr %l28, !tbaa !27
  %t61 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t62 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t61, { i64, ptr } { i64 2, ptr @.d77 })
  store i1 %t62, ptr %l29
  br label %bb19
bb19:
  %t63 = load i1, ptr %l29, !tbaa !21
  %t64 = xor i1 %t63, true
  store i1 %t64, ptr %l30, !tbaa !21
  %t65 = load i1, ptr %l30, !tbaa !21
  store i1 %t65, ptr %l27, !tbaa !21
  br label %bb20
bb20:
  %t66 = load i1, ptr %l27, !tbaa !21
  br i1 %t66, label %bb21, label %bb22
bb21:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb24
bb22:
  %t67 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t67, ptr %l32, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = getelementptr i8, ptr %t69, i64 2
  %t71 = load i8, ptr %t70, !tbaa !32
  store i8 %t71, ptr %l33, !tbaa !22
  %t72 = load i8, ptr %l33, !tbaa !22
  %t73 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %t72)
  store i1 %t73, ptr %l34
  br label %bb23
bb23:
  %t74 = load i1, ptr %l34, !tbaa !21
  %t75 = xor i1 %t74, true
  store i1 %t75, ptr %l35, !tbaa !21
  %t76 = load i1, ptr %l35, !tbaa !21
  store i1 %t76, ptr %l31, !tbaa !21
  br label %bb24
bb24:
  %t77 = load i1, ptr %l31, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  store i1 true, ptr %l36, !tbaa !21
  br label %bb28
bb26:
  %t78 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t78, ptr %l37, !tbaa !27
  %t79 = getelementptr { i64, ptr }, ptr %l37, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i8, ptr %t80, i64 3
  %t82 = load i8, ptr %t81, !tbaa !32
  store i8 %t82, ptr %l38, !tbaa !22
  %t83 = load i8, ptr %l38, !tbaa !22
  %t84 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t83)
  store i1 %t84, ptr %l39
  br label %bb27
bb27:
  %t85 = load i1, ptr %l39, !tbaa !21
  %t86 = xor i1 %t85, true
  store i1 %t86, ptr %l40, !tbaa !21
  %t87 = load i1, ptr %l40, !tbaa !21
  store i1 %t87, ptr %l36, !tbaa !21
  br label %bb28
bb28:
  %t88 = load i1, ptr %l36, !tbaa !21
  br i1 %t88, label %bb29, label %bb30
bb29:
  store %olang.scope zeroinitializer, ptr %s1
  %t89 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t89, ptr %l41, !tbaa !27
  %t90 = load { i64, ptr }, ptr %l41, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  store i64 %t91, ptr %l42, !tbaa !24
  %t92 = icmp sge i64 0, 0
  store i1 %t92, ptr %l43, !tbaa !21
  %t93 = load i1, ptr %l43, !tbaa !21
  br i1 %t93, label %bb31, label %bb32
bb30:
  br label %bb37
bb31:
  %t94 = icmp sle i64 0, 0
  store i1 %t94, ptr %l44, !tbaa !21
  %t95 = load i1, ptr %l44, !tbaa !21
  br i1 %t95, label %bb33, label %bb34
bb32:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb33:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = icmp sle i64 0, %t96
  store i1 %t97, ptr %l45, !tbaa !21
  %t98 = load i1, ptr %l45, !tbaa !21
  br i1 %t98, label %bb35, label %bb36
bb34:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb35:
  %t99 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t100 = load ptr, ptr %t99, !tbaa !27
  %t101 = getelementptr i8, ptr %t100, i64 0
  %t102 = sub i64 0, 0
  %t103 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t101, 1
  store { i64, ptr } %t104, ptr %l46, !tbaa !27
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t105 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t105, ptr %rv
  br label %ret
bb36:
  call void @__olang_check_failed(ptr @.c78)
  unreachable
bb37:
  store i64 3, ptr %l2, !tbaa !24
  br label %bb38
bb38:
  store %olang.scope zeroinitializer, ptr %s2
  %t106 = load i64, ptr %l2, !tbaa !24
  store i64 %t106, ptr %l47, !tbaa !24
  %t107 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t107, ptr %l48, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  store i64 %t109, ptr %l49, !tbaa !24
  %t110 = load i64, ptr %l47, !tbaa !24
  %t111 = load i64, ptr %l49, !tbaa !24
  %t112 = icmp slt i64 %t110, %t111
  store i1 %t112, ptr %l50, !tbaa !21
  %t113 = load i1, ptr %l50, !tbaa !21
  br i1 %t113, label %bb39, label %bb40
bb39:
  %t114 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t114, ptr %l52, !tbaa !27
  %t115 = load i64, ptr %l2, !tbaa !24
  store i64 %t115, ptr %l53, !tbaa !24
  %t116 = load i64, ptr %l53, !tbaa !24
  %t117 = getelementptr { i64, ptr }, ptr %l52, i32 0, i32 1
  %t118 = load ptr, ptr %t117, !tbaa !27
  %t119 = getelementptr i8, ptr %t118, i64 %t116
  %t120 = load i8, ptr %t119, !tbaa !32
  store i8 %t120, ptr %l54, !tbaa !22
  %t121 = load i8, ptr %l54, !tbaa !22
  %t122 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %t121)
  store i1 %t122, ptr %l55
  br label %bb41
bb40:
  store i1 false, ptr %l51, !tbaa !21
  br label %bb42
bb41:
  %t123 = load i1, ptr %l55, !tbaa !21
  store i1 %t123, ptr %l51, !tbaa !21
  br label %bb42
bb42:
  %t124 = load i1, ptr %l51, !tbaa !21
  %t125 = xor i1 %t124, true
  store i1 %t125, ptr %l56, !tbaa !21
  %t126 = load i1, ptr %l56, !tbaa !21
  br i1 %t126, label %bb43, label %bb44
bb43:
  call void @__olang_scope_close(ptr %s2)
  br label %bb47
bb44:
  br label %bb45
bb45:
  %t127 = load i64, ptr %l2, !tbaa !24
  store i64 %t127, ptr %l57, !tbaa !24
  %t128 = load i64, ptr %l57, !tbaa !24
  %t129 = add i64 %t128, 1
  store i64 %t129, ptr %l58, !tbaa !24
  %t130 = load i64, ptr %l58, !tbaa !24
  store i64 %t130, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s2)
  br label %bb46
bb46:
  br label %bb38
bb47:
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s3
  %t131 = load i64, ptr %l2, !tbaa !24
  store i64 %t131, ptr %l59, !tbaa !24
  %t132 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t132, ptr %l60, !tbaa !27
  %t133 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 0
  store i64 %t134, ptr %l61, !tbaa !24
  %t135 = load i64, ptr %l59, !tbaa !24
  %t136 = load i64, ptr %l61, !tbaa !24
  %t137 = icmp slt i64 %t135, %t136
  store i1 %t137, ptr %l62, !tbaa !21
  %t138 = load i1, ptr %l62, !tbaa !21
  br i1 %t138, label %bb49, label %bb50
bb49:
  %t139 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t139, ptr %l64, !tbaa !27
  %t140 = load i64, ptr %l2, !tbaa !24
  store i64 %t140, ptr %l65, !tbaa !24
  %t141 = load i64, ptr %l65, !tbaa !24
  %t142 = getelementptr { i64, ptr }, ptr %l64, i32 0, i32 1
  %t143 = load ptr, ptr %t142, !tbaa !27
  %t144 = getelementptr i8, ptr %t143, i64 %t141
  %t145 = load i8, ptr %t144, !tbaa !32
  store i8 %t145, ptr %l66, !tbaa !22
  %t146 = load i8, ptr %l66, !tbaa !22
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %t146)
  store i1 %t147, ptr %l67
  br label %bb51
bb50:
  store i1 false, ptr %l63, !tbaa !21
  br label %bb52
bb51:
  %t148 = load i1, ptr %l67, !tbaa !21
  store i1 %t148, ptr %l63, !tbaa !21
  br label %bb52
bb52:
  %t149 = load i1, ptr %l63, !tbaa !21
  %t150 = xor i1 %t149, true
  store i1 %t150, ptr %l68, !tbaa !21
  %t151 = load i1, ptr %l68, !tbaa !21
  br i1 %t151, label %bb53, label %bb54
bb53:
  call void @__olang_scope_close(ptr %s3)
  br label %bb57
bb54:
  br label %bb55
bb55:
  %t152 = load i64, ptr %l2, !tbaa !24
  store i64 %t152, ptr %l69, !tbaa !24
  %t153 = load i64, ptr %l69, !tbaa !24
  %t154 = add i64 %t153, 1
  store i64 %t154, ptr %l70, !tbaa !24
  %t155 = load i64, ptr %l70, !tbaa !24
  store i64 %t155, ptr %l2, !tbaa !24
  call void @__olang_scope_close(ptr %s3)
  br label %bb56
bb56:
  br label %bb48
bb57:
  %t156 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t156, ptr %l71, !tbaa !27
  %t157 = load i64, ptr %l2, !tbaa !24
  store i64 %t157, ptr %l72, !tbaa !24
  %t158 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t158, ptr %l73, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l73, !tbaa !27
  store { i64, ptr } %t159, ptr %l74, !tbaa !27
  %t160 = load { i64, ptr }, ptr %l74, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  store i64 %t161, ptr %l75, !tbaa !24
  %t162 = load { i64, ptr }, ptr %l71, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 0
  store i64 %t163, ptr %l76, !tbaa !24
  %t164 = load i64, ptr %l72, !tbaa !24
  %t165 = icmp sge i64 %t164, 0
  store i1 %t165, ptr %l77, !tbaa !21
  %t166 = load i1, ptr %l77, !tbaa !21
  br i1 %t166, label %bb58, label %bb59
bb58:
  %t167 = load i64, ptr %l72, !tbaa !24
  %t168 = load i64, ptr %l75, !tbaa !24
  %t169 = icmp sle i64 %t167, %t168
  store i1 %t169, ptr %l78, !tbaa !21
  %t170 = load i1, ptr %l78, !tbaa !21
  br i1 %t170, label %bb60, label %bb61
bb59:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb60:
  %t171 = load i64, ptr %l75, !tbaa !24
  %t172 = load i64, ptr %l76, !tbaa !24
  %t173 = icmp sle i64 %t171, %t172
  store i1 %t173, ptr %l79, !tbaa !21
  %t174 = load i1, ptr %l79, !tbaa !21
  br i1 %t174, label %bb62, label %bb63
bb61:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb62:
  %t175 = getelementptr { i64, ptr }, ptr %l71, i32 0, i32 1
  %t176 = load ptr, ptr %t175, !tbaa !27
  %t177 = load i64, ptr %l72, !tbaa !24
  %t178 = load i64, ptr %l75, !tbaa !24
  %t179 = getelementptr i8, ptr %t176, i64 %t177
  %t180 = sub i64 %t178, %t177
  %t181 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t179, 1
  store { i64, ptr } %t182, ptr %l80, !tbaa !27
  %t183 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t184 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t183, { i64, ptr } { i64 3, ptr @.d80 })
  store i1 %t184, ptr %l81
  br label %bb64
bb63:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb64:
  %t185 = load i1, ptr %l81, !tbaa !21
  %t186 = xor i1 %t185, true
  store i1 %t186, ptr %l82, !tbaa !21
  %t187 = load i1, ptr %l82, !tbaa !21
  br i1 %t187, label %bb65, label %bb66
bb65:
  %t188 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t188, ptr %l84, !tbaa !27
  %t189 = load i64, ptr %l2, !tbaa !24
  store i64 %t189, ptr %l85, !tbaa !24
  %t190 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t190, ptr %l86, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l86, !tbaa !27
  store { i64, ptr } %t191, ptr %l87, !tbaa !27
  %t192 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t192, 0
  store i64 %t193, ptr %l88, !tbaa !24
  %t194 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  store i64 %t195, ptr %l89, !tbaa !24
  %t196 = load i64, ptr %l85, !tbaa !24
  %t197 = icmp sge i64 %t196, 0
  store i1 %t197, ptr %l90, !tbaa !21
  %t198 = load i1, ptr %l90, !tbaa !21
  br i1 %t198, label %bb67, label %bb68
bb66:
  store i1 false, ptr %l83, !tbaa !21
  br label %bb74
bb67:
  %t199 = load i64, ptr %l85, !tbaa !24
  %t200 = load i64, ptr %l88, !tbaa !24
  %t201 = icmp sle i64 %t199, %t200
  store i1 %t201, ptr %l91, !tbaa !21
  %t202 = load i1, ptr %l91, !tbaa !21
  br i1 %t202, label %bb69, label %bb70
bb68:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb69:
  %t203 = load i64, ptr %l88, !tbaa !24
  %t204 = load i64, ptr %l89, !tbaa !24
  %t205 = icmp sle i64 %t203, %t204
  store i1 %t205, ptr %l92, !tbaa !21
  %t206 = load i1, ptr %l92, !tbaa !21
  br i1 %t206, label %bb71, label %bb72
bb70:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb71:
  %t207 = getelementptr { i64, ptr }, ptr %l84, i32 0, i32 1
  %t208 = load ptr, ptr %t207, !tbaa !27
  %t209 = load i64, ptr %l85, !tbaa !24
  %t210 = load i64, ptr %l88, !tbaa !24
  %t211 = getelementptr i8, ptr %t208, i64 %t209
  %t212 = sub i64 %t210, %t209
  %t213 = insertvalue { i64, ptr } undef, i64 %t212, 0
  %t214 = insertvalue { i64, ptr } %t213, ptr %t211, 1
  store { i64, ptr } %t214, ptr %l93, !tbaa !27
  %t215 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t216 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %s0, { i64, ptr } %t215, { i64, ptr } { i64 2, ptr @.d81 })
  store i1 %t216, ptr %l94
  br label %bb73
bb72:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb73:
  %t217 = load i1, ptr %l94, !tbaa !21
  %t218 = xor i1 %t217, true
  store i1 %t218, ptr %l95, !tbaa !21
  %t219 = load i1, ptr %l95, !tbaa !21
  store i1 %t219, ptr %l83, !tbaa !21
  br label %bb74
bb74:
  %t220 = load i1, ptr %l83, !tbaa !21
  br i1 %t220, label %bb75, label %bb76
bb75:
  store %olang.scope zeroinitializer, ptr %s4
  %t221 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t221, ptr %l96, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t223 = extractvalue { i64, ptr } %t222, 0
  store i64 %t223, ptr %l97, !tbaa !24
  %t224 = icmp sge i64 0, 0
  store i1 %t224, ptr %l98, !tbaa !21
  %t225 = load i1, ptr %l98, !tbaa !21
  br i1 %t225, label %bb77, label %bb78
bb76:
  br label %bb83
bb77:
  %t226 = icmp sle i64 0, 0
  store i1 %t226, ptr %l99, !tbaa !21
  %t227 = load i1, ptr %l99, !tbaa !21
  br i1 %t227, label %bb79, label %bb80
bb78:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb79:
  %t228 = load i64, ptr %l97, !tbaa !24
  %t229 = icmp sle i64 0, %t228
  store i1 %t229, ptr %l100, !tbaa !21
  %t230 = load i1, ptr %l100, !tbaa !21
  br i1 %t230, label %bb81, label %bb82
bb80:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb81:
  %t231 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr i8, ptr %t232, i64 0
  %t234 = sub i64 0, 0
  %t235 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t233, 1
  store { i64, ptr } %t236, ptr %l101, !tbaa !27
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t237 = load { i64, ptr }, ptr %l101, !tbaa !27
  store { i64, ptr } %t237, ptr %rv
  br label %ret
bb82:
  call void @__olang_check_failed(ptr @.c79)
  unreachable
bb83:
  %t238 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t238, ptr %l102, !tbaa !27
  %t239 = load i64, ptr %l2, !tbaa !24
  store i64 %t239, ptr %l103, !tbaa !24
  %t240 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t241 = extractvalue { i64, ptr } %t240, 0
  store i64 %t241, ptr %l104, !tbaa !24
  %t242 = icmp sge i64 2, 0
  store i1 %t242, ptr %l105, !tbaa !21
  %t243 = load i1, ptr %l105, !tbaa !21
  br i1 %t243, label %bb84, label %bb85
bb84:
  %t244 = load i64, ptr %l103, !tbaa !24
  %t245 = icmp sle i64 2, %t244
  store i1 %t245, ptr %l106, !tbaa !21
  %t246 = load i1, ptr %l106, !tbaa !21
  br i1 %t246, label %bb86, label %bb87
bb85:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb86:
  %t247 = load i64, ptr %l103, !tbaa !24
  %t248 = load i64, ptr %l104, !tbaa !24
  %t249 = icmp sle i64 %t247, %t248
  store i1 %t249, ptr %l107, !tbaa !21
  %t250 = load i1, ptr %l107, !tbaa !21
  br i1 %t250, label %bb88, label %bb89
bb87:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
bb88:
  %t251 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t252 = load ptr, ptr %t251, !tbaa !27
  %t253 = load i64, ptr %l103, !tbaa !24
  %t254 = getelementptr i8, ptr %t252, i64 2
  %t255 = sub i64 %t253, 2
  %t256 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t254, 1
  store { i64, ptr } %t257, ptr %l108, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t258 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t258, ptr %rv
  br label %ret
bb89:
  call void @__olang_check_failed(ptr @.c82)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local { i64, ptr } @compiler_2fdiag_2esection(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/text:StringBuilder"
  %l1 = alloca %"std/prelude/text:StringBuilder"
  %l2 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i64, ptr }
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %s0)
  store %"std/prelude/text:StringBuilder" %t1, ptr %l1
  br label %bb1
bb1:
  %t2 = load %"std/prelude/text:StringBuilder", ptr %l1
  store %"std/prelude/text:StringBuilder" %t2, ptr %l0
  store ptr %l0, ptr %l2, !tbaa !29
  %t3 = load ptr, ptr %l2, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t3, i8 -62)
  br label %bb2
bb2:
  store ptr %l0, ptr %l3, !tbaa !29
  %t4 = load ptr, ptr %l3, !tbaa !29
  call void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %s0, ptr %t4, i8 -89)
  br label %bb3
bb3:
  store ptr %l0, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t6 = call { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %s0, ptr %v0, ptr %t5)
  store { i64, ptr } %t6, ptr %l5
  br label %bb4
bb4:
  %t7 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t7, ptr %l6, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l7, !tbaa !24
  %t10 = load i64, ptr %l7, !tbaa !24
  %t11 = mul i64 %t10, 1
  %t12 = call ptr @__olang_scope_alloc_zeroed(ptr %v0, i64 %t11)
  %t13 = insertvalue { i64, ptr } undef, i64 %t10, 0
  %t14 = insertvalue { i64, ptr } %t13, ptr %t12, 1
  store { i64, ptr } %t14, ptr %l8, !tbaa !27
  %t15 = getelementptr { i64, ptr }, ptr %l8, i32 0, i32 1
  %t16 = load ptr, ptr %t15, !tbaa !27
  %t17 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t18 = load ptr, ptr %t17, !tbaa !27
  %t19 = load i64, ptr %l7, !tbaa !24
  %t20 = mul i64 %t19, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t16, ptr %t18, i64 %t20, i1 false)
  %t21 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t21, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t22 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t22, ptr %rv
  br label %ret
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

define dso_local i1 @compiler_2fdiag_2etermAllowsColor() #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i1
  %l5 = alloca { i64, ptr }
  %l6 = alloca i1
  %l7 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %s0, ptr %s0, { i64, ptr } { i64 4, ptr @.d83 })
  %t2 = extractvalue { i32, { i64, ptr } } %t1, 1
  %t3 = extractvalue { i32, { i64, ptr } } %t1, 0
  store i32 %t3, ptr %l3
  %t4 = icmp ne i32 %t3, 0
  br i1 %t4, label %bb2, label %ok.5
ok.5:
  store { i64, ptr } %t2, ptr %l2
  br label %bb1
bb1:
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t6, ptr %l1, !tbaa !27
  br label %bb4
bb2:
  br label %bb3
bb3:
  store %olang.scope zeroinitializer, ptr %s1
  store i1 false, ptr %l4, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t7 = load i1, ptr %l4, !tbaa !21
  store i1 %t7, ptr %rv
  br label %ret
bb4:
  %t8 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t8, ptr %l0, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t9, ptr %l5, !tbaa !27
  %t10 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t10, { i64, ptr } { i64 4, ptr @.d84 })
  store i1 %t11, ptr %l6
  br label %bb5
bb5:
  %t12 = load i1, ptr %l6, !tbaa !21
  %t13 = xor i1 %t12, true
  store i1 %t13, ptr %l7, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t14 = load i1, ptr %l7, !tbaa !21
  store i1 %t14, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0) #0 {
entry:
  %l0 = alloca i1
  %l1 = alloca i1
  %l2 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l3 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l4 = alloca %"std/prelude/list:List<Bool>"
  %l5 = alloca %"std/prelude/list:List<I64>"
  %l6 = alloca %"std/prelude/list:List<I64>"
  %l7 = alloca %"std/prelude/list:List<I64>"
  %l8 = alloca %"std/prelude/list:List<compiler/diag:record>"
  %l9 = alloca %"std/prelude/list:List<compiler/diag:note>"
  %l10 = alloca %"std/prelude/list:List<I64>"
  %l11 = alloca %"std/prelude/list:List<I64>"
  %l12 = alloca %"std/prelude/list:List<I64>"
  %l13 = alloca %"std/prelude/list:List<compiler/diag:context>"
  %l14 = alloca i64
  %l15 = alloca i1
  %l16 = alloca i1
  %l17 = alloca { i64, [3 x i64] }
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i1
  %l21 = alloca i1
  %l22 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l23 = alloca %"std/prelude/list:List<std/prelude/text:String&>"
  %l24 = alloca %"std/prelude/list:List<Bool>"
  %l25 = alloca %"std/prelude/list:List<I64>"
  %l26 = alloca %"std/prelude/list:List<I64>"
  %l27 = alloca %"std/prelude/list:List<I64>"
  %l28 = alloca %"std/prelude/list:List<compiler/diag:record>"
  %l29 = alloca %"std/prelude/list:List<compiler/diag:note>"
  %l30 = alloca %"std/prelude/list:List<I64>"
  %l31 = alloca %"std/prelude/list:List<I64>"
  %l32 = alloca %"std/prelude/list:List<I64>"
  %l33 = alloca %"std/prelude/list:List<compiler/diag:context>"
  %l34 = alloca { i64, [3 x i64] }
  %l35 = alloca %"compiler/diag:Diagnostics"
  %s0 = alloca %olang.scope
  %t27 = alloca { i64, [3 x i64] }, align 8
  store i1 %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i1, ptr %l0, !tbaa !21
  store i1 %t1, ptr %l21, !tbaa !21
  %t2 = load i1, ptr %l21, !tbaa !21
  store i1 %t2, ptr %l1, !tbaa !21
  %t3 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t3, ptr %l22
  br label %bb1
bb1:
  %t4 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l22
  store %"std/prelude/list:List<std/prelude/text:String&>" %t4, ptr %l2
  %t5 = call %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<std/prelude/text:String&>" %t5, ptr %l23
  br label %bb2
bb2:
  %t6 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l23
  store %"std/prelude/list:List<std/prelude/text:String&>" %t6, ptr %l3
  %t7 = call %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<Bool>" %t7, ptr %l24
  br label %bb3
bb3:
  %t8 = load %"std/prelude/list:List<Bool>", ptr %l24
  store %"std/prelude/list:List<Bool>" %t8, ptr %l4
  %t9 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<I64>" %t9, ptr %l25
  br label %bb4
bb4:
  %t10 = load %"std/prelude/list:List<I64>", ptr %l25
  store %"std/prelude/list:List<I64>" %t10, ptr %l5
  %t11 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<I64>" %t11, ptr %l26
  br label %bb5
bb5:
  %t12 = load %"std/prelude/list:List<I64>", ptr %l26
  store %"std/prelude/list:List<I64>" %t12, ptr %l6
  %t13 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<I64>" %t13, ptr %l27
  br label %bb6
bb6:
  %t14 = load %"std/prelude/list:List<I64>", ptr %l27
  store %"std/prelude/list:List<I64>" %t14, ptr %l7
  %t15 = call %"std/prelude/list:List<compiler/diag:record>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<compiler/diag:record>" %t15, ptr %l28
  br label %bb7
bb7:
  %t16 = load %"std/prelude/list:List<compiler/diag:record>", ptr %l28
  store %"std/prelude/list:List<compiler/diag:record>" %t16, ptr %l8
  %t17 = call %"std/prelude/list:List<compiler/diag:note>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<compiler/diag:note>" %t17, ptr %l29
  br label %bb8
bb8:
  %t18 = load %"std/prelude/list:List<compiler/diag:note>", ptr %l29
  store %"std/prelude/list:List<compiler/diag:note>" %t18, ptr %l9
  %t19 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<I64>" %t19, ptr %l30
  br label %bb9
bb9:
  %t20 = load %"std/prelude/list:List<I64>", ptr %l30
  store %"std/prelude/list:List<I64>" %t20, ptr %l10
  %t21 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<I64>" %t21, ptr %l31
  br label %bb10
bb10:
  %t22 = load %"std/prelude/list:List<I64>", ptr %l31
  store %"std/prelude/list:List<I64>" %t22, ptr %l11
  %t23 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<I64>" %t23, ptr %l32
  br label %bb11
bb11:
  %t24 = load %"std/prelude/list:List<I64>", ptr %l32
  store %"std/prelude/list:List<I64>" %t24, ptr %l12
  %t25 = call %"std/prelude/list:List<compiler/diag:context>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ector(ptr %v0)
  store %"std/prelude/list:List<compiler/diag:context>" %t25, ptr %l33
  br label %bb12
bb12:
  %t26 = load %"std/prelude/list:List<compiler/diag:context>", ptr %l33
  store %"std/prelude/list:List<compiler/diag:context>" %t26, ptr %l13
  store i64 0, ptr %l14, !tbaa !24
  store i1 false, ptr %l15, !tbaa !21
  store i1 false, ptr %l16, !tbaa !21
  store { i64, [3 x i64] } zeroinitializer, ptr %t27
  %t28 = getelementptr { i64, [3 x i64] }, ptr %t27, i32 0, i32 0
  store i64 0, ptr %t28
  %t29 = load { i64, [3 x i64] }, ptr %t27
  store { i64, [3 x i64] } %t29, ptr %l34
  %t30 = load { i64, [3 x i64] }, ptr %l34
  store { i64, [3 x i64] } %t30, ptr %l17
  store { i64, ptr } { i64 0, ptr @.d85 }, ptr %l18, !tbaa !27
  store { i64, ptr } { i64 0, ptr @.d86 }, ptr %l19, !tbaa !27
  store i1 false, ptr %l20, !tbaa !21
  %t31 = load i1, ptr %l1, !tbaa !21
  %t32 = insertvalue %"compiler/diag:Diagnostics" undef, i1 %t31, 0
  %t33 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l2
  %t34 = insertvalue %"compiler/diag:Diagnostics" %t32, %"std/prelude/list:List<std/prelude/text:String&>" %t33, 1
  %t35 = load %"std/prelude/list:List<std/prelude/text:String&>", ptr %l3
  %t36 = insertvalue %"compiler/diag:Diagnostics" %t34, %"std/prelude/list:List<std/prelude/text:String&>" %t35, 2
  %t37 = load %"std/prelude/list:List<Bool>", ptr %l4
  %t38 = insertvalue %"compiler/diag:Diagnostics" %t36, %"std/prelude/list:List<Bool>" %t37, 3
  %t39 = load %"std/prelude/list:List<I64>", ptr %l5
  %t40 = insertvalue %"compiler/diag:Diagnostics" %t38, %"std/prelude/list:List<I64>" %t39, 4
  %t41 = load %"std/prelude/list:List<I64>", ptr %l6
  %t42 = insertvalue %"compiler/diag:Diagnostics" %t40, %"std/prelude/list:List<I64>" %t41, 5
  %t43 = load %"std/prelude/list:List<I64>", ptr %l7
  %t44 = insertvalue %"compiler/diag:Diagnostics" %t42, %"std/prelude/list:List<I64>" %t43, 6
  %t45 = load %"std/prelude/list:List<compiler/diag:record>", ptr %l8
  %t46 = insertvalue %"compiler/diag:Diagnostics" %t44, %"std/prelude/list:List<compiler/diag:record>" %t45, 7
  %t47 = load %"std/prelude/list:List<compiler/diag:note>", ptr %l9
  %t48 = insertvalue %"compiler/diag:Diagnostics" %t46, %"std/prelude/list:List<compiler/diag:note>" %t47, 8
  %t49 = load %"std/prelude/list:List<I64>", ptr %l10
  %t50 = insertvalue %"compiler/diag:Diagnostics" %t48, %"std/prelude/list:List<I64>" %t49, 9
  %t51 = load %"std/prelude/list:List<I64>", ptr %l11
  %t52 = insertvalue %"compiler/diag:Diagnostics" %t50, %"std/prelude/list:List<I64>" %t51, 10
  %t53 = load %"std/prelude/list:List<I64>", ptr %l12
  %t54 = insertvalue %"compiler/diag:Diagnostics" %t52, %"std/prelude/list:List<I64>" %t53, 11
  %t55 = load %"std/prelude/list:List<compiler/diag:context>", ptr %l13
  %t56 = insertvalue %"compiler/diag:Diagnostics" %t54, %"std/prelude/list:List<compiler/diag:context>" %t55, 12
  %t57 = load i64, ptr %l14, !tbaa !24
  %t58 = insertvalue %"compiler/diag:Diagnostics" %t56, i64 %t57, 13
  %t59 = load i1, ptr %l15, !tbaa !21
  %t60 = insertvalue %"compiler/diag:Diagnostics" %t58, i1 %t59, 14
  %t61 = load i1, ptr %l16, !tbaa !21
  %t62 = insertvalue %"compiler/diag:Diagnostics" %t60, i1 %t61, 15
  %t63 = load { i64, [3 x i64] }, ptr %l17
  %t64 = insertvalue %"compiler/diag:Diagnostics" %t62, { i64, [3 x i64] } %t63, 16
  %t65 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t66 = insertvalue %"compiler/diag:Diagnostics" %t64, { i64, ptr } %t65, 17
  %t67 = load { i64, ptr }, ptr %l19, !tbaa !27
  %t68 = insertvalue %"compiler/diag:Diagnostics" %t66, { i64, ptr } %t67, 18
  %t69 = load i1, ptr %l20, !tbaa !21
  %t70 = insertvalue %"compiler/diag:Diagnostics" %t68, i1 %t69, 19
  store %"compiler/diag:Diagnostics" %t70, ptr %l35
  call void @__olang_scope_close(ptr %s0)
  %t71 = load %"compiler/diag:Diagnostics", ptr %l35
  store %"compiler/diag:Diagnostics" %t71, ptr %out
  br label %ret
ret:
  ret void
}

define dso_local %"compiler/diag:Said" @compiler_2fdiag_3aSaid_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca i64
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca %"compiler/diag:Said"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/diag:Said"
  store { i64, ptr } %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t1, ptr %l8, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t2, ptr %l4, !tbaa !27
  %t3 = load i64, ptr %l1, !tbaa !24
  store i64 %t3, ptr %l9, !tbaa !24
  %t4 = load i64, ptr %l9, !tbaa !24
  store i64 %t4, ptr %l5, !tbaa !24
  %t5 = load i64, ptr %l2, !tbaa !24
  store i64 %t5, ptr %l10, !tbaa !24
  %t6 = load i64, ptr %l10, !tbaa !24
  store i64 %t6, ptr %l6, !tbaa !24
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t7, ptr %l11, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t8, ptr %l7, !tbaa !27
  %t9 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t10 = insertvalue %"compiler/diag:Said" undef, { i64, ptr } %t9, 0
  %t11 = load i64, ptr %l5, !tbaa !24
  %t12 = insertvalue %"compiler/diag:Said" %t10, i64 %t11, 1
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = insertvalue %"compiler/diag:Said" %t12, i64 %t13, 2
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = insertvalue %"compiler/diag:Said" %t14, { i64, ptr } %t15, 3
  store %"compiler/diag:Said" %t16, ptr %l12
  call void @__olang_scope_close(ptr %s0)
  %t17 = load %"compiler/diag:Said", ptr %l12
  store %"compiler/diag:Said" %t17, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:Said", ptr %rv
  ret %"compiler/diag:Said" %rr
}

define dso_local %"compiler/diag:context" @compiler_2fdiag_3acontext_2ector(ptr %v0, ptr %v1, { i64, [3 x i64] } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, [3 x i64] }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, [3 x i64] }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"compiler/diag:context"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/diag:context"
  store { i64, [3 x i64] } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [3 x i64] }, ptr %l0
  store { i64, [3 x i64] } %t1, ptr %l4
  %t2 = load { i64, [3 x i64] }, ptr %l4
  store { i64, [3 x i64] } %t2, ptr %l2
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l5, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t4, ptr %l3, !tbaa !27
  %t5 = load { i64, [3 x i64] }, ptr %l2
  %t6 = insertvalue %"compiler/diag:context" undef, { i64, [3 x i64] } %t5, 0
  %t7 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t8 = insertvalue %"compiler/diag:context" %t6, { i64, ptr } %t7, 1
  store %"compiler/diag:context" %t8, ptr %l6
  call void @__olang_scope_close(ptr %s0)
  %t9 = load %"compiler/diag:context", ptr %l6
  store %"compiler/diag:context" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:context", ptr %rv
  ret %"compiler/diag:context" %rr
}

define dso_local %"compiler/diag:note" @compiler_2fdiag_3anote_2ector(ptr %v0, ptr %v1, i64 %a0, { i64, [3 x i64] } %a1, { i64, ptr } %a2) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca { i64, [3 x i64] }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, [3 x i64] }
  %l5 = alloca { i64, ptr }
  %l6 = alloca i64
  %l7 = alloca { i64, [3 x i64] }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"compiler/diag:note"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/diag:note"
  store i64 %a0, ptr %l0
  store { i64, [3 x i64] } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i64, ptr %l0, !tbaa !24
  store i64 %t1, ptr %l6, !tbaa !24
  %t2 = load i64, ptr %l6, !tbaa !24
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, [3 x i64] }, ptr %l1
  store { i64, [3 x i64] } %t3, ptr %l7
  %t4 = load { i64, [3 x i64] }, ptr %l7
  store { i64, [3 x i64] } %t4, ptr %l4
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l8, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t6, ptr %l5, !tbaa !27
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = insertvalue %"compiler/diag:note" undef, i64 %t7, 0
  %t9 = load { i64, [3 x i64] }, ptr %l4
  %t10 = insertvalue %"compiler/diag:note" %t8, { i64, [3 x i64] } %t9, 1
  %t11 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t12 = insertvalue %"compiler/diag:note" %t10, { i64, ptr } %t11, 2
  store %"compiler/diag:note" %t12, ptr %l9
  call void @__olang_scope_close(ptr %s0)
  %t13 = load %"compiler/diag:note", ptr %l9
  store %"compiler/diag:note" %t13, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:note", ptr %rv
  ret %"compiler/diag:note" %rr
}

define dso_local %"compiler/diag:record" @compiler_2fdiag_3arecord_2ector(ptr %v0, ptr %v1, ptr %v2, { i64, [3 x i64] } %a0, { i64, ptr } %a1, { i64, ptr } %a2, i32 %a3, i64 %a4, i1 %a5) #0 {
entry:
  %l0 = alloca { i64, [3 x i64] }
  %l1 = alloca { i64, ptr }
  %l2 = alloca { i64, ptr }
  %l3 = alloca i32
  %l4 = alloca i64
  %l5 = alloca i1
  %l6 = alloca { i64, [3 x i64] }
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca i32
  %l10 = alloca i64
  %l11 = alloca i1
  %l12 = alloca { i64, [3 x i64] }
  %l13 = alloca { i64, ptr }
  %l14 = alloca { i64, ptr }
  %l15 = alloca i32
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca %"compiler/diag:record"
  %s0 = alloca %olang.scope
  %rv = alloca %"compiler/diag:record"
  store { i64, [3 x i64] } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store i32 %a3, ptr %l3
  store i64 %a4, ptr %l4
  store i1 %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, [3 x i64] }, ptr %l0
  store { i64, [3 x i64] } %t1, ptr %l12
  %t2 = load { i64, [3 x i64] }, ptr %l12
  store { i64, [3 x i64] } %t2, ptr %l6
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  store { i64, ptr } %t3, ptr %l13, !tbaa !27
  %t4 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t4, ptr %l7, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t5, ptr %l14, !tbaa !27
  %t6 = load { i64, ptr }, ptr %l14, !tbaa !27
  store { i64, ptr } %t6, ptr %l8, !tbaa !27
  %t7 = load i32, ptr %l3
  store i32 %t7, ptr %l15
  %t8 = load i32, ptr %l15
  store i32 %t8, ptr %l9
  %t9 = load i64, ptr %l4, !tbaa !24
  store i64 %t9, ptr %l16, !tbaa !24
  %t10 = load i64, ptr %l16, !tbaa !24
  store i64 %t10, ptr %l10, !tbaa !24
  %t11 = load i1, ptr %l5, !tbaa !21
  store i1 %t11, ptr %l17, !tbaa !21
  %t12 = load i1, ptr %l17, !tbaa !21
  store i1 %t12, ptr %l11, !tbaa !21
  %t13 = load { i64, [3 x i64] }, ptr %l6
  %t14 = insertvalue %"compiler/diag:record" undef, { i64, [3 x i64] } %t13, 0
  %t15 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t16 = insertvalue %"compiler/diag:record" %t14, { i64, ptr } %t15, 1
  %t17 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t18 = insertvalue %"compiler/diag:record" %t16, { i64, ptr } %t17, 2
  %t19 = load i32, ptr %l9
  %t20 = insertvalue %"compiler/diag:record" %t18, i32 %t19, 3
  %t21 = load i64, ptr %l10, !tbaa !24
  %t22 = insertvalue %"compiler/diag:record" %t20, i64 %t21, 4
  %t23 = load i1, ptr %l11, !tbaa !21
  %t24 = insertvalue %"compiler/diag:record" %t22, i1 %t23, 5
  store %"compiler/diag:record" %t24, ptr %l18
  call void @__olang_scope_close(ptr %s0)
  %t25 = load %"compiler/diag:record", ptr %l18
  store %"compiler/diag:record" %t25, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/diag:record", ptr %rv
  ret %"compiler/diag:record" %rr
}

define dso_local void @olang_2einit_2ecompiler_2fdiag() #0 {
entry:
  %s0 = alloca %olang.scope
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fdiag_2ePending_2einit()
  br label %bb1
bb1:
  call void @compiler_2fdiag_2eChosen_2einit()
  br label %bb2
bb2:
  call void @compiler_2fdiag_2eDropped_2einit()
  br label %bb3
bb3:
  call void @compiler_2fdiag_2eCut_2einit()
  br label %bb4
bb4:
  call void @compiler_2fdiag_2eExcerptMax_2einit()
  br label %bb5
bb5:
  call void @compiler_2fdiag_2eExcerptAround_2einit()
  br label %bb6
bb6:
  call void @__olang_scope_close(ptr %s0)
  br label %ret
ret:
  ret void
}

define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [8 x i8] c"NO_COLOR"
declare void @__olang_check_failed(ptr)
@.c1 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:653: slice bounds out of range\0A\00"
@.c2 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:656: slice bounds out of range\0A\00"
@.c3 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:659: slice bounds out of range\0A\00"
@.c4 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:660: slice bounds out of range\0A\00"
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.c5 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:676: slice bounds out of range\0A\00"
@.d6 = private constant [1 x i8] c"\0A"
declare noalias ptr @__olang_scope_alloc_zeroed(ptr, i64)
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d7 = private constant [14 x i8] c"/proc/self/exe"
@.d8 = private constant [7 x i8] c"SPEC.md"
@.d9 = private constant [1 x i8] c"/"
@.d10 = private constant [7 x i8] c"SPEC.md"
@.c11 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:618: slice bounds out of range\0A\00"
declare void @__olang_sb_put(ptr, ptr, i64)
@.d12 = private constant [11 x i8] c"/../SPEC.md"
declare void @__olang_sb_done(ptr)
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List<compiler/diag:Said>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<compiler/diag:Said>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<compiler/diag:Said>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<compiler/diag:Said>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<compiler/diag:Said>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<compiler/diag:Said>", ptr %l0
  store %"std/prelude/list:List<compiler/diag:Said>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<compiler/diag:Said>", ptr %rv
  ret %"std/prelude/list:List<compiler/diag:Said>" %rr
}

declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
@.c13 = private unnamed_addr constant [51 x i8] c"compiler/diag.olang:349: reached unreachable code\0A\00"
@.d14 = private constant [1 x i8] c"?"
@.d15 = private constant [1 x i8] c":"
define available_externally ptr @__olang_sb_room(ptr %sb, i64 %need) alwaysinline {
entry:
  %lenp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 1
  %capp = getelementptr { ptr, i64, i64, ptr }, ptr %sb, i32 0, i32 2
  %len = load i64, ptr %lenp
  %cap = load i64, ptr %capp
  %want = add i64 %len, %need
  %fits = icmp ule i64 %want, %cap
  br i1 %fits, label %ok, label %grow
ok:
  %data = load ptr, ptr %sb
  %p = getelementptr i8, ptr %data, i64 %len
  ret ptr %p
grow:
  %g = call ptr @__olang_sb_grow(ptr %sb, i64 %need)
  ret ptr %g
}
declare i64 @__olang_fmt_i64(ptr, i64)
declare void @__olang_sb_add(ptr, i64)
@.d16 = private constant [1 x i8] c":"
@.d17 = private constant [1 x i8] c"?"
@.d18 = private constant [5 x i8] c"error"
@.c19 = private unnamed_addr constant [51 x i8] c"compiler/diag.olang:483: reached unreachable code\0A\00"
@.d20 = private constant [4 x i8] c"note"
@.d21 = private constant [0 x i8] c""
@.d22 = private constant [1 x i8] c"1"
@.d23 = private constant [1 x i8] c"0"
@.d24 = private constant [22 x i8] c"compilation successful"
@.d25 = private constant [1 x i8] c"\0A"
@.d26 = private constant [4 x i8] c"1;31"
@.d27 = private constant [0 x i8] c""
@.d28 = private constant [1 x i8] c"s"
@.d29 = private constant [1 x i8] c"0"
@.d30 = private constant [24 x i8] c"compilation failed with "
@.d31 = private constant [6 x i8] c" error"
@.d32 = private constant [1 x i8] c"\0A"
@.d33 = private constant [4 x i8] c"1;31"
@.d34 = private constant [1 x i8] c"0"
@.d35 = private constant [6 x i8] c"error:"
@.d36 = private constant [1 x i8] c" "
@.d37 = private constant [4 x i8] c"1;31"
@.d38 = private constant [1 x i8] c"0"
@.d39 = private constant [6 x i8] c"error["
@.d40 = private constant [2 x i8] c"]:"
@.d41 = private constant [1 x i8] c" "
@.c42 = private unnamed_addr constant [51 x i8] c"compiler/diag.olang:265: reached unreachable code\0A\00"
@.d43 = private constant [3 x i8] c" | "
@.d44 = private constant [3 x i8] c"..."
@.d45 = private constant [3 x i8] c"..."
@.d46 = private constant [9 x i8] c"\0A      | "
@.d47 = private constant [3 x i8] c"   "
@.d48 = private constant [4 x i8] c"1;32"
@.d49 = private constant [1 x i8] c"0"
@.d50 = private constant [1 x i8] c"1"
@.d51 = private constant [5 x i8] c"olang"
@.d52 = private constant [1 x i8] c":"
@.d53 = private constant [1 x i8] c":"
@.d54 = private constant [1 x i8] c":"
@.c55 = private unnamed_addr constant [51 x i8] c"compiler/diag.olang:535: reached unreachable code\0A\00"
@.d56 = private constant [2 x i8] c": "
@.d57 = private constant [1 x i8] c"0"
@.d58 = private constant [5 x i8] c"error"
@.d59 = private constant [4 x i8] c"1;36"
@.d60 = private constant [1 x i8] c"0"
@.d61 = private constant [5 x i8] c"note:"
@.d62 = private constant [1 x i8] c" "
@.d63 = private constant [0 x i8] c""
@.d64 = private constant [1 x i8] c"["
@.d65 = private constant [1 x i8] c"m"
@.c66 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:397: array length out of range\0A\00"
@.c67 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:398: array length out of range\0A\00"
@.c68 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:399: array length out of range\0A\00"
define linkonce_odr %"std/prelude/list:List<I64>" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cI64_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List<I64>"
  %s0 = alloca %olang.scope
  %rv = alloca %"std/prelude/list:List<I64>"
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %t1)
  store %"std/prelude/list:List<I64>" %t2, ptr %l0
  br label %bb1
bb1:
  call void @__olang_scope_close(ptr %s0)
  %t3 = load %"std/prelude/list:List<I64>", ptr %l0
  store %"std/prelude/list:List<I64>" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List<I64>", ptr %rv
  ret %"std/prelude/list:List<I64>" %rr
}

@.c69 = private unnamed_addr constant [51 x i8] c"compiler/diag.olang:423: reached unreachable code\0A\00"
define linkonce_odr i1 @olang_2eHelperKind_2eEqual_2ecompiler_2fmsgs_3aDiag(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i1
  %s0 = alloca %olang.scope
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i32, ptr %t1
  %t3 = sext i32 %t2 to i64
  store i64 %t3, ptr %l3, !tbaa !24
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load i32, ptr %t4
  %t6 = sext i32 %t5 to i64
  store i64 %t6, ptr %l4, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t9 = icmp eq i64 %t7, %t8
  store i1 %t9, ptr %l5, !tbaa !21
  %t10 = load i1, ptr %l5, !tbaa !21
  br i1 %t10, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb3
bb2:
  br label %bb3
bb3:
  call void @__olang_scope_close(ptr %s0)
  %t11 = load i1, ptr %l2, !tbaa !21
  store i1 %t11, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.c70 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:434: array length out of range\0A\00"
@.c71 = private unnamed_addr constant [51 x i8] c"compiler/diag.olang:436: reached unreachable code\0A\00"
define internal i1 @olang_lambda_72(ptr %env, i64 %a0, i64 %a1) #0 {
entry:
  %l0 = alloca i64
  %l1 = alloca i64
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l5 = alloca { i64, ptr }
  %l6 = alloca { i64, ptr }
  %l7 = alloca i64
  %l8 = alloca i64
  %l9 = alloca i64
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l15 = alloca i64
  %l16 = alloca i64
  %l17 = alloca i1
  %l18 = alloca { i64, ptr }
  %l19 = alloca { i64, ptr }
  %l20 = alloca i64
  %l21 = alloca i64
  %l22 = alloca i64
  %l23 = alloca i64
  %l24 = alloca { i64, ptr }
  %l25 = alloca { i64, ptr }
  %l26 = alloca i64
  %l27 = alloca i64
  %l28 = alloca i64
  %l29 = alloca i64
  %l30 = alloca i1
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca i64
  %l34 = alloca { i64, ptr }
  %l35 = alloca i64
  %l36 = alloca i64
  %l37 = alloca i1
  %l38 = alloca { i64, ptr }
  %l39 = alloca i64
  %l40 = alloca i64
  %l41 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %l44 = alloca i1
  %l45 = alloca i64
  %l46 = alloca i64
  %l47 = alloca i1
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %rv = alloca i1
  store i64 %a0, ptr %l0
  store i64 %a1, ptr %l1
  %cp0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  store { i64, ptr } %cv0, ptr %l2
  %cp1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load { i64, ptr }, ptr %cp1, !tbaa !28
  store { i64, ptr } %cv1, ptr %l3
  %cp2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 2
  %cv2 = load { i64, ptr }, ptr %cp2, !tbaa !28
  store { i64, ptr } %cv2, ptr %l4
  %vq0 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 3
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  %vq1 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 4
  %vr1 = load ptr, ptr %vq1, !tbaa !28
  %vc1 = call ptr @__olang_capture_scope(ptr %vr1)
  %vq2 = getelementptr { { i64, ptr }, { i64, ptr }, { i64, ptr }, ptr, ptr, ptr }, ptr %env, i32 0, i32 5
  %vr2 = load ptr, ptr %vq2, !tbaa !28
  %vc2 = call ptr @__olang_capture_scope(ptr %vr2)
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t1, ptr %l5, !tbaa !27
  %t2 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t2, ptr %l6, !tbaa !27
  %t3 = load i64, ptr %l0, !tbaa !24
  store i64 %t3, ptr %l7, !tbaa !24
  %t4 = load i64, ptr %l7, !tbaa !24
  %t5 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr i64, ptr %t6, i64 %t4
  %t8 = load i64, ptr %t7, !tbaa !34
  store i64 %t8, ptr %l8, !tbaa !24
  %t9 = load i64, ptr %l8, !tbaa !24
  %t10 = add i64 %t9, 1
  store i64 %t10, ptr %l9, !tbaa !24
  %t11 = load i64, ptr %l9, !tbaa !24
  %t12 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr i64, ptr %t13, i64 %t11
  %t15 = load i64, ptr %t14, !tbaa !34
  store i64 %t15, ptr %l10, !tbaa !24
  %t16 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t16, ptr %l11, !tbaa !27
  %t17 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t17, ptr %l12, !tbaa !27
  %t18 = load i64, ptr %l1, !tbaa !24
  store i64 %t18, ptr %l13, !tbaa !24
  %t19 = load i64, ptr %l13, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr i64, ptr %t21, i64 %t19
  %t23 = load i64, ptr %t22, !tbaa !34
  store i64 %t23, ptr %l14, !tbaa !24
  %t24 = load i64, ptr %l14, !tbaa !24
  %t25 = add i64 %t24, 1
  store i64 %t25, ptr %l15, !tbaa !24
  %t26 = load i64, ptr %l15, !tbaa !24
  %t27 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t28 = load ptr, ptr %t27, !tbaa !27
  %t29 = getelementptr i64, ptr %t28, i64 %t26
  %t30 = load i64, ptr %t29, !tbaa !34
  store i64 %t30, ptr %l16, !tbaa !24
  %t31 = load i64, ptr %l10, !tbaa !24
  %t32 = load i64, ptr %l16, !tbaa !24
  %t33 = icmp ne i64 %t31, %t32
  store i1 %t33, ptr %l17, !tbaa !21
  %t34 = load i1, ptr %l17, !tbaa !21
  br i1 %t34, label %bb1, label %bb2
bb1:
  store %olang.scope zeroinitializer, ptr %s1
  %t35 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t35, ptr %l18, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t36, ptr %l19, !tbaa !27
  %t37 = load i64, ptr %l0, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load i64, ptr %l20, !tbaa !24
  %t39 = getelementptr { i64, ptr }, ptr %l19, i32 0, i32 1
  %t40 = load ptr, ptr %t39, !tbaa !27
  %t41 = getelementptr i64, ptr %t40, i64 %t38
  %t42 = load i64, ptr %t41, !tbaa !34
  store i64 %t42, ptr %l21, !tbaa !24
  %t43 = load i64, ptr %l21, !tbaa !24
  %t44 = add i64 %t43, 1
  store i64 %t44, ptr %l22, !tbaa !24
  %t45 = load i64, ptr %l22, !tbaa !24
  %t46 = getelementptr { i64, ptr }, ptr %l18, i32 0, i32 1
  %t47 = load ptr, ptr %t46, !tbaa !27
  %t48 = getelementptr i64, ptr %t47, i64 %t45
  %t49 = load i64, ptr %t48, !tbaa !34
  store i64 %t49, ptr %l23, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t50, ptr %l24, !tbaa !27
  %t51 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t51, ptr %l25, !tbaa !27
  %t52 = load i64, ptr %l1, !tbaa !24
  store i64 %t52, ptr %l26, !tbaa !24
  %t53 = load i64, ptr %l26, !tbaa !24
  %t54 = getelementptr { i64, ptr }, ptr %l25, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = getelementptr i64, ptr %t55, i64 %t53
  %t57 = load i64, ptr %t56, !tbaa !34
  store i64 %t57, ptr %l27, !tbaa !24
  %t58 = load i64, ptr %l27, !tbaa !24
  %t59 = add i64 %t58, 1
  store i64 %t59, ptr %l28, !tbaa !24
  %t60 = load i64, ptr %l28, !tbaa !24
  %t61 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t62 = load ptr, ptr %t61, !tbaa !27
  %t63 = getelementptr i64, ptr %t62, i64 %t60
  %t64 = load i64, ptr %t63, !tbaa !34
  store i64 %t64, ptr %l29, !tbaa !24
  %t65 = load i64, ptr %l23, !tbaa !24
  %t66 = load i64, ptr %l29, !tbaa !24
  %t67 = icmp slt i64 %t65, %t66
  store i1 %t67, ptr %l30, !tbaa !21
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i1, ptr %l30, !tbaa !21
  store i1 %t68, ptr %rv
  br label %ret
bb2:
  br label %bb3
bb3:
  %t69 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t69, ptr %l31, !tbaa !27
  %t70 = load i64, ptr %l0, !tbaa !24
  store i64 %t70, ptr %l32, !tbaa !24
  %t71 = load i64, ptr %l32, !tbaa !24
  %t72 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t73 = load ptr, ptr %t72, !tbaa !27
  %t74 = getelementptr i64, ptr %t73, i64 %t71
  %t75 = load i64, ptr %t74, !tbaa !34
  store i64 %t75, ptr %l33, !tbaa !24
  %t76 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t76, ptr %l34, !tbaa !27
  %t77 = load i64, ptr %l1, !tbaa !24
  store i64 %t77, ptr %l35, !tbaa !24
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t80 = load ptr, ptr %t79, !tbaa !27
  %t81 = getelementptr i64, ptr %t80, i64 %t78
  %t82 = load i64, ptr %t81, !tbaa !34
  store i64 %t82, ptr %l36, !tbaa !24
  %t83 = load i64, ptr %l33, !tbaa !24
  %t84 = load i64, ptr %l36, !tbaa !24
  %t85 = icmp ne i64 %t83, %t84
  store i1 %t85, ptr %l37, !tbaa !21
  %t86 = load i1, ptr %l37, !tbaa !21
  br i1 %t86, label %bb4, label %bb5
bb4:
  store %olang.scope zeroinitializer, ptr %s2
  %t87 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t87, ptr %l38, !tbaa !27
  %t88 = load i64, ptr %l0, !tbaa !24
  store i64 %t88, ptr %l39, !tbaa !24
  %t89 = load i64, ptr %l39, !tbaa !24
  %t90 = getelementptr { i64, ptr }, ptr %l38, i32 0, i32 1
  %t91 = load ptr, ptr %t90, !tbaa !27
  %t92 = getelementptr i64, ptr %t91, i64 %t89
  %t93 = load i64, ptr %t92, !tbaa !34
  store i64 %t93, ptr %l40, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t94, ptr %l41, !tbaa !27
  %t95 = load i64, ptr %l1, !tbaa !24
  store i64 %t95, ptr %l42, !tbaa !24
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = getelementptr { i64, ptr }, ptr %l41, i32 0, i32 1
  %t98 = load ptr, ptr %t97, !tbaa !27
  %t99 = getelementptr i64, ptr %t98, i64 %t96
  %t100 = load i64, ptr %t99, !tbaa !34
  store i64 %t100, ptr %l43, !tbaa !24
  %t101 = load i64, ptr %l40, !tbaa !24
  %t102 = load i64, ptr %l43, !tbaa !24
  %t103 = icmp slt i64 %t101, %t102
  store i1 %t103, ptr %l44, !tbaa !21
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load i1, ptr %l44, !tbaa !21
  store i1 %t104, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t105 = load i64, ptr %l0, !tbaa !24
  store i64 %t105, ptr %l45, !tbaa !24
  %t106 = load i64, ptr %l1, !tbaa !24
  store i64 %t106, ptr %l46, !tbaa !24
  %t107 = load i64, ptr %l45, !tbaa !24
  %t108 = load i64, ptr %l46, !tbaa !24
  %t109 = icmp slt i64 %t107, %t108
  store i1 %t109, ptr %l47, !tbaa !21
  call void @__olang_scope_close(ptr %s0)
  %t110 = load i1, ptr %l47, !tbaa !21
  store i1 %t110, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@.d73 = private constant [3 x i8] c"C2d"
@.d74 = private constant [4 x i8] c"T17c"
@.d75 = private constant [2 x i8] c"- "
@.c76 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:631: slice bounds out of range\0A\00"
@.d77 = private constant [2 x i8] c"**"
@.c78 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:632: slice bounds out of range\0A\00"
@.c79 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:636: slice bounds out of range\0A\00"
@.d80 = private constant [3 x i8] c".**"
@.d81 = private constant [2 x i8] c" ("
@.c82 = private unnamed_addr constant [52 x i8] c"compiler/diag.olang:637: slice bounds out of range\0A\00"
@.d83 = private constant [4 x i8] c"TERM"
@.d84 = private constant [4 x i8] c"dumb"
@.d85 = private constant [0 x i8] c""
@.d86 = private constant [0 x i8] c""
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare ptr @__olang_sb_grow(ptr, i64) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
@__olang_self = external thread_local(initialexec) global ptr
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare i1 @std_2fos_2eIsTerminal(i32 %a0)
declare { i32, { i64, ptr } } @std_2fos_2eEnv(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/text:StringBuilder" @std_2fprelude_2ftext_3aStringBuilder_2ector(ptr %v0)
declare i8 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eToUpper(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePushChar(ptr %v0, ptr %a0, i8 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2eToString(ptr %v0, ptr %v1, ptr %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindByte(ptr %v0, { i64, ptr } %a0, i8 %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsDigit(i8 %a0)
declare void @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aStringBuilder_2ePush(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFindLast(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hf76aba43f2ebbf3524334fc00c6db622(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2ePush_3cBool_3e(ptr %v0, ptr %a0, i1 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePush_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Ha5558dbc633a54c0dd550e0262b6ceae(ptr %v0, ptr %a0)
declare %"compiler/diag:record" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eAt_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ePush_3ccompiler_2fdiag_3aSaid_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:Said" %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eSetAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1, i64 %a2)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eLen_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eLen_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0)
declare { i32, i64 } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2ePop_3cI64_3e(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eToArray_3cI64_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eClear_3cI64_3e(ptr %v0, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eTrunc_Hfb0c5ceb44a5ca5b5beffc6b7a3329ef(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eLen_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0)
declare %"compiler/diag:note" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eSetAt_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1, %"compiler/diag:note" %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eTruncate_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0, i64 %a1)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eLen_3cI64_3e(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eAt_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2eRunFrom_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ePush_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:note" %a1)
declare { i32, %"compiler/diag:context" } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ePop_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ePush_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:context" %a1)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2eRunFrom_3ccompiler_2fdiag_3anote_3e(ptr %v0, ptr %a0, i64 %a1)
declare i1 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cBool_3e_2eAt_3cBool_3e(ptr %v0, ptr %a0, i64 %a1)
declare { i64, ptr } @compiler_2fsource_2eLineStarts(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diag:context" @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2eAt_3ccompiler_2fdiag_3acontext_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i64, ptr } @std_2fprelude_2ftext_2eI64_2ePadStart(ptr %v0, i64 %a0, i64 %a1, i8 %a2)
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2ePush_3ccompiler_2fdiag_3arecord_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/diag:record" %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNoteInLibrary(ptr %v0)
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cI64_3e_2eRunFrom_3cI64_3e(ptr %v0, ptr %a0, i64 %a1)
declare void @std_2fprelude_2farray_2eArray_3cI64_3e_2eSort_3cI64_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eStartsWith(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsUpper(i8 %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aChar_2eIsLower(i8 %a0)
declare %"std/prelude/list:List<std/prelude/text:String&>" @std_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<Bool>" @std_2fprelude_2flist_3aList_3cBool_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<I64>" @std_2fprelude_2flist_3aList_3cI64_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/diag:record>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3arecord_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/diag:note>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3anote_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/diag:context>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3acontext_3e_2ector(ptr %v0)
declare %"std/prelude/list:List<compiler/diag:Said>" @std_2fprelude_2flist_3aList_3ccompiler_2fdiag_3aSaid_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
