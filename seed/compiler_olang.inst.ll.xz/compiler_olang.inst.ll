; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr, i64 }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Listed" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/listing:Inputs" = type { ptr, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1 }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/build:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/explain:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/build:Program"
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i32
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l86 = alloca i32
  %l92 = alloca ptr
  %l95 = alloca i1
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l7, i64 264, i1 false)
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %v3, ptr %a0, { i64, ptr } %t3, i32 1, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l14
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t21)
  store i32 %t23, ptr %l18
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l19
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l18, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l21
  br label %bb13
bb13:
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t40)
  store i32 %t42, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l28, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l31
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l31, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l33, !tbaa !21
  br label %bb24
bb24:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t55)
  store i32 %t57, ptr %l35
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l35, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v3, ptr %v3, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l41
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l40
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l36
  br label %bb31
bb28:
  %t70 = load i32, ptr %l41, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l43, !tbaa !21
  br label %bb29
bb29:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t74)
  store i32 %t76, ptr %l45
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l45, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb32
bb32:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t79, i32 0, i32 10
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb33, label %bb34
bb33:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v1, ptr %s0, ptr %v3, ptr %v2, ptr %v3, ptr %t84, ptr %l4, ptr %l5, { i64, ptr } %t85, ptr %t86)
  store i32 %t92, ptr %l53
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load i32, ptr %l53, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/build:Config", ptr %t94, i32 0, i32 30
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t99, ptr %l56
  br label %bb37
bb37:
  %t100 = load i1, ptr %l56, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb38, label %bb39
bb38:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/build:Config", ptr %t103, i32 0, i32 30
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = extractvalue { i64, ptr } %t106, 0
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t108, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  br label %bb43
bb39:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t119 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t119, ptr %l65
  br label %bb40
bb40:
  %t120 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t126)
  store { i64, ptr } %t128, ptr %l67
  br label %bb41
bb41:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t129)
  store { i64, ptr } %t131, ptr %l69
  br label %bb42
bb42:
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = add i64 %t137, %t140
  %t142 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = add i64 %t141, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t133, i64 %t134)
  %t147 = getelementptr i8, ptr %t146, i64 %t134
  call void @olang_textcopy(ptr %t147, ptr %t135, i64 %t136)
  %t148 = getelementptr i8, ptr %t147, i64 %t136
  call void @olang_textcopy(ptr %t148, ptr %t139, i64 %t140)
  %t149 = getelementptr i8, ptr %t148, i64 %t140
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t146, 1
  store { i64, ptr } %t151, ptr %l58, !tbaa !27
  br label %bb43
bb43:
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t153, ptr %lp6
  %t154 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t155 = load ptr, ptr %lp6
  store { i64, ptr } %t154, ptr %t155, !tbaa !27
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l71, !tbaa !29
  store ptr %l5, ptr %l72, !tbaa !29
  %t157 = load ptr, ptr %lp6
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l73, !tbaa !27
  %t159 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t160, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t162, ptr %l75
  br label %bb44
bb44:
  %t163 = load i1, ptr %l75, !tbaa !21
  %t164 = xor i1 %t163, true
  %t165 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 3
  %t166 = load ptr, ptr %l71, !tbaa !29
  %t167 = load ptr, ptr %l72, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t171 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %v3, ptr %v1, ptr %s0, ptr %s0, ptr %t166, ptr %t167, { i64, ptr } %t168, i1 %t164, ptr %t165, ptr null)
  store i32 %t171, ptr %l78
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb46, label %ok.173, !prof !99
ok.173:
  br label %bb45
bb45:
  br label %bb51
bb46:
  %t174 = load i32, ptr %l78, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  store i1 %t177, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t178 = load ptr, ptr %l3, !tbaa !29
  store ptr %t178, ptr %l81, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 0, ptr %t180
  %t181 = load { i64, [3 x i64] }, ptr %t179
  store { i64, [3 x i64] } %t181, ptr %l82
  %t182 = load ptr, ptr %lp6
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v1, ptr %v3, { i64, ptr } %t183)
  store %"compiler/diagmsg:Msg" %t185, ptr %l84
  br label %bb48
bb48:
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load { i64, [3 x i64] }, ptr %l82
  %t188 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v3, ptr %v3, ptr %t186, { i64, [3 x i64] } %t187, %"compiler/diagmsg:Msg" %t188)
  br label %bb49
bb49:
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t191 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t189)
  store i32 %t191, ptr %l86
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t192 = load i32, ptr %l86, !tbaa !23
  store i32 %t192, ptr %rv
  br label %ret
bb51:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb52
bb52:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t194 = load ptr, ptr %lp6
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t198 = getelementptr %"compiler/build:Config", ptr %t193, i32 0, i32 31
  store { i64, ptr } %t195, ptr %t198, !tbaa !27
  call void @compiler_2fspin_2eEnd()
  br label %bb53
bb53:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/build:Config", ptr %t199, i32 0, i32 29
  %t202 = load i1, ptr %t201, !tbaa !21
  %t204 = xor i1 %t202, true
  br i1 %t204, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l92, !tbaa !29
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/build:Config", ptr %t207, i32 0, i32 30
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s10, { i64, ptr } %t210, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t212, ptr %l95
  br label %bb56
bb55:
  br label %bb63
bb56:
  %t213 = load i1, ptr %l95, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb57, label %bb58
bb57:
  %t216 = load ptr, ptr %lp6
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l97, !tbaa !27
  br label %bb60
bb58:
  %t219 = load ptr, ptr %lp6
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t222 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s10, { i64, ptr } %t220)
  store { i64, ptr } %t222, ptr %l100
  br label %bb59
bb59:
  %t223 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t223, ptr %l97, !tbaa !27
  br label %bb60
bb60:
  %t224 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t226 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = add i64 %t225, %t228
  %t230 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t224, i64 %t225)
  %t231 = getelementptr i8, ptr %t230, i64 %t225
  call void @olang_textcopy(ptr %t231, ptr %t227, i64 %t228)
  %t232 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t230, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = extractvalue { i64, ptr } %t233, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t241 = load ptr, ptr %l92, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t241, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } %t240)
  store { i64, ptr } %t243, ptr %l103
  br label %bb61
bb61:
  %t244 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t250)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l65 = alloca i32
  %l70 = alloca i32
  %l72 = alloca i1
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i32
  %l90 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l8, i64 264, i1 false)
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %v3, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l15
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t21)
  store i32 %t23, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l19, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l22
  br label %bb13
bb13:
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l26
  br label %bb16
bb16:
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t40)
  store i32 %t42, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l29, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l32
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l32, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t55)
  store i32 %t57, ptr %l36
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l36, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v3, ptr %v3, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l42
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l41
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l37
  br label %bb31
bb28:
  %t70 = load i32, ptr %l42, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb29
bb29:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t74)
  store i32 %t76, ptr %l46
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l46, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  %t80 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v3, ptr %v3, ptr %l5, i64 0)
  store { i64, ptr } %t80, ptr %l48
  br label %bb32
bb32:
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 30
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t87, ptr %l51
  br label %bb33
bb33:
  %t88 = load i1, ptr %l51, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v3, ptr %s6, { i64, ptr } %t91)
  %t94 = extractvalue { i32, { i64, ptr } } %t93, 1
  %t95 = extractvalue { i32, { i64, ptr } } %t93, 0
  store i32 %t95, ptr %l56
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb37, label %ok.97, !prof !99
ok.97:
  store { i64, ptr } %t94, ptr %l55
  br label %bb36
bb35:
  br label %bb54
bb36:
  %t98 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t98, ptr %l53, !tbaa !27
  br label %bb44
bb37:
  %t99 = load i32, ptr %l56, !tbaa !23
  %t100 = ashr i32 %t99, 16
  %t102 = icmp eq i32 %t100, 1
  store i1 %t102, ptr %l58, !tbaa !21
  %t103 = load i32, ptr %l56, !tbaa !23
  %t104 = ashr i32 %t103, 16
  %t106 = icmp eq i32 %t104, 1
  br i1 %t106, label %bb38, label %bb39
bb38:
  call void @__olang_errpay_pop()
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t108, ptr %l61, !tbaa !27
  %t109 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t109, ptr %l62
  br label %bb41
bb41:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t112 = load %"compiler/diagmsg:Msg", ptr %l62
  call void @compiler_2fbuild_2efileFatal(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t111, %"compiler/diagmsg:Msg" %t112, ptr %t110)
  br label %bb42
bb42:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t114)
  store i32 %t116, ptr %l65
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load i32, ptr %l65, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb44:
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/build:Config", ptr %t119, i32 0, i32 30
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t127 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t122, { i64, ptr } %t118)
  store i32 %t127, ptr %l70
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb46, label %ok.129, !prof !99
ok.129:
  br label %bb45
bb45:
  br label %bb53
bb46:
  %t130 = load i32, ptr %l70, !tbaa !23
  %t131 = ashr i32 %t130, 16
  %t133 = icmp eq i32 %t131, 1
  store i1 %t133, ptr %l72, !tbaa !21
  %t134 = load i32, ptr %l70, !tbaa !23
  %t135 = ashr i32 %t134, 16
  %t137 = icmp eq i32 %t135, 1
  br i1 %t137, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/build:Config", ptr %t139, i32 0, i32 30
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l76, !tbaa !27
  %t143 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v3)
  store %"compiler/diagmsg:Msg" %t143, ptr %l77
  br label %bb50
bb50:
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t146 = load %"compiler/diagmsg:Msg", ptr %l77
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %v3, ptr %v3, { i64, ptr } %t145, %"compiler/diagmsg:Msg" %t146, ptr %t144)
  br label %bb51
bb51:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t148)
  store i32 %t150, ptr %l80
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t151 = load i32, ptr %l80, !tbaa !23
  store i32 %t151, ptr %rv
  br label %ret
bb53:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/build:Config", ptr %t152, i32 0, i32 30
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb54:
  call void @compiler_2fspin_2eEnd()
  br label %bb55
bb55:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/build:Config", ptr %t157, i32 0, i32 29
  %t160 = load i1, ptr %t159, !tbaa !21
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t169 = extractvalue { i64, ptr } %t165, 1
  %t170 = extractvalue { i64, ptr } %t165, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t166, i64 %t167)
  %t173 = getelementptr i8, ptr %t172, i64 %t167
  call void @olang_textcopy(ptr %t173, ptr %t169, i64 %t170)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t172, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t185 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s9, ptr %s9, ptr %s9, ptr %t164, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l90
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t186 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  call void @compiler_2fbuild_2esayln(ptr %s9, { i64, ptr } %t192)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v4, ptr %s0, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l13
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  br label %bb11
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_251e830707558b33_b2bdace7e2a71047)
  unreachable
bb8:
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l18
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t29)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:FileInfo"
  %l6 = alloca i32
  %l7 = alloca %"std/os:FileInfo"
  %l9 = alloca %"std/os:FileInfo"
  %l10 = alloca i32
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/diagmsg:Msg"
  %l19 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/diagmsg:Msg"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"compiler/diagmsg:Msg"
  %l34 = alloca i32
  %l35 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l52 = alloca i1
  %l60 = alloca { i64, ptr }
  %l65 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l9
  store %"std/os:FileInfo" %t8, ptr %l7
  br label %bb8
bb2:
  %t9 = load i32, ptr %l10, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l12, !tbaa !21
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t24 = load %"compiler/diagmsg:Msg", ptr %l17
  %t26 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t22, { i64, ptr } %t23, %"compiler/diagmsg:Msg" %t24, ptr %t21)
  store i32 %t26, ptr %l19
  br label %bb7
bb7:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb8:
  %t28 = load %"std/os:FileInfo", ptr %l7
  store %"std/os:FileInfo" %t28, ptr %l5
  %t29 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 3}
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l23, !tbaa !27
  %t37 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v3)
  store %"compiler/diagmsg:Msg" %t37, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t41 = load %"compiler/diagmsg:Msg", ptr %l24
  %t43 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t39, { i64, ptr } %t40, %"compiler/diagmsg:Msg" %t41, ptr %t38)
  store i32 %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t46 = load i32, ptr %t45, !range !{i32 0, i32 3}
  %t48 = trunc i64 0 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v3)
  store %"compiler/diagmsg:Msg" %t55, ptr %l32
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t59 = load %"compiler/diagmsg:Msg", ptr %l32
  %t61 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t57, { i64, ptr } %t58, %"compiler/diagmsg:Msg" %t59, ptr %t56)
  store i32 %t61, ptr %l34
  br label %bb17
bb17:
  %t62 = load i32, ptr %l34, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
bb18:
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t73 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v4, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %t64, { i64, ptr } %t65, ptr %t66, ptr %t67)
  %t74 = extractvalue { i32, i32 } %t73, 1
  %t75 = extractvalue { i32, i32 } %t73, 0
  store i32 %t75, ptr %l42
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb20, label %ok.77, !prof !99
ok.77:
  store i32 %t74, ptr %l41
  br label %bb19
bb19:
  %t78 = load i32, ptr %l41, !tbaa !23
  store i32 %t78, ptr %l35, !tbaa !23
  br label %bb29
bb20:
  %t79 = load i32, ptr %l42, !tbaa !23
  %t80 = icmp eq i32 %t79, 65536
  br i1 %t80, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  %t82 = load i32, ptr %l42, !tbaa !23
  %t83 = icmp eq i32 %t82, 65537
  br i1 %t83, label %bb24, label %bb25
bb23:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t91 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v3, ptr %t85, { i64, ptr } %t86, ptr %t87)
  store i32 %t91, ptr %l48
  br label %bb27
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ac43697cc5f2dca0_4dfd3d6081b857d4)
  unreachable
bb26:
  %t92 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t92, ptr %l49
  br label %bb28
bb27:
  %t93 = load i32, ptr %l48, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb28:
  %t94 = load i32, ptr %l49, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb29:
  %t95 = load i32, ptr %l35, !tbaa !23
  store i32 %t95, ptr %l6, !tbaa !23
  %t96 = load i32, ptr %l6, !tbaa !23
  %t98 = icmp eq i32 %t96, 3
  br i1 %t98, label %bb30, label %bb31
bb30:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp sgt i64 %t102, 0
  store i1 %t104, ptr %l52, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l52, !tbaa !21
  br i1 %t106, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/build:Config", ptr %t109, i32 0, i32 24
  %t115 = call { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v2, ptr %v4, ptr %v1, ptr %s6, { i64, ptr } %t107, { i64, ptr } %t108, ptr %t111)
  store { i64, ptr } %t115, ptr %l60
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t116 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  call void @compiler_2fbuild_2esayln(ptr %s6, { i64, ptr } %t122)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  store i32 3, ptr %rv
  br label %ret
bb37:
  %t125 = load i32, ptr %l6, !tbaa !23
  %t127 = icmp eq i32 %t125, 0
  br i1 %t127, label %bb38, label %bb39
bb38:
  store i32 0, ptr %l65, !tbaa !23
  br label %bb40
bb39:
  store i32 1, ptr %l65, !tbaa !23
  br label %bb40
bb40:
  %t129 = load i32, ptr %l65, !tbaa !23
  store i32 %t129, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i32
  %l11 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l25 = alloca ptr
  %l26 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i64, ptr }
  %l31 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca ptr
  %l41 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l43 = alloca i32
  %l46 = alloca ptr
  %l48 = alloca { i64, ptr }
  %l50 = alloca { i64, ptr }
  %l51 = alloca { i64, ptr }
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l58 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l63 = alloca i64
  %l68 = alloca i32
  %l73 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l91 = alloca i32
  %l95 = alloca i32
  %l97 = alloca i1
  %l100 = alloca ptr
  %l101 = alloca { i64, [3 x i64] }
  %l102 = alloca %"compiler/diagmsg:Msg"
  %l104 = alloca i32
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca i32
  %t254 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 23
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t16 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v4, ptr %t6, { i64, ptr } %t7, { i64, ptr } %t8, ptr %t9, ptr %t10)
  %t17 = extractvalue { i32, i32 } %t16, 1
  %t18 = extractvalue { i32, i32 } %t16, 0
  store i32 %t18, ptr %l18
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20, !prof !99
ok.20:
  store i32 %t17, ptr %l17
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t21 = load i32, ptr %l17, !tbaa !23
  store i32 %t21, ptr %l11, !tbaa !23
  br label %bb13
bb4:
  %t22 = load i32, ptr %l18, !tbaa !23
  %t23 = icmp eq i32 %t22, 65536
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t25 = load i32, ptr %l18, !tbaa !23
  %t26 = icmp eq i32 %t25, 65537
  br i1 %t26, label %bb8, label %bb9
bb7:
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t28)
  store i32 %t30, ptr %l22
  br label %bb11
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb10:
  %t31 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t31, ptr %l23
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l22, !tbaa !23
  store i32 %t32, ptr %rv
  br label %ret
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i32, ptr %l23, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i32, ptr %l11, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
bb14:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 29
  store i1 true, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l25, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %s0, ptr %v1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store { i64, ptr } %t39, ptr %l26
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t48 = load ptr, ptr %l25, !tbaa !29
  %t49 = getelementptr %"compiler/build:Config", ptr %t48, i32 0, i32 0
  store { i64, ptr } %t46, ptr %t49, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v2, ptr %s0, { i64, ptr } %t50)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l31
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb17, label %ok.56, !prof !99
ok.56:
  store { i64, ptr } %t53, ptr %l30
  br label %bb16
bb16:
  %t57 = load { i64, ptr }, ptr %l30, !tbaa !27
  store { i64, ptr } %t57, ptr %l28, !tbaa !27
  br label %bb21
bb17:
  %t58 = load i32, ptr %l31, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l28, !tbaa !27
  br label %bb21
bb21:
  %t78 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l37
  br label %bb22
bb22:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l6
  %t81 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t81)
  br label %bb23
bb23:
  store ptr %l6, ptr %l40, !tbaa !29
  %t84 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t85 = extractvalue { i32, { i64, ptr } } %t84, 1
  %t86 = extractvalue { i32, { i64, ptr } } %t84, 0
  store i32 %t86, ptr %l43
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb25, label %ok.88, !prof !99
ok.88:
  store { i64, ptr } %t85, ptr %l42
  br label %bb24
bb24:
  %t89 = load { i64, ptr }, ptr %l42, !tbaa !27
  store { i64, ptr } %t89, ptr %l41, !tbaa !27
  br label %bb29
bb25:
  %t90 = load i32, ptr %l43, !tbaa !23
  %t91 = ashr i32 %t90, 16
  %t93 = icmp eq i32 %t91, 1
  br i1 %t93, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l41, !tbaa !27
  br label %bb29
bb29:
  %t95 = load ptr, ptr %l40, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l41, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t95, { i64, ptr } %t96)
  br label %bb30
bb30:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l46, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/build:Config", ptr %t98, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l48, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t104 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v2, ptr %v2, { i64, ptr } %t102)
  store { i64, ptr } %t104, ptr %l50
  br label %bb31
bb31:
  %t105 = load { i64, ptr }, ptr %l50, !tbaa !27
  %t106 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v2, ptr %s0, { i64, ptr } %t105)
  store { i64, ptr } %t106, ptr %l51
  br label %bb32
bb32:
  %t108 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t108, ptr %l53
  br label %bb33
bb33:
  %t109 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l54, !tbaa !24
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t113 = icmp sle i64 0, 16
  br i1 %t113, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb36:
  %t115 = load i64, ptr %l54, !tbaa !24
  %t116 = icmp sle i64 16, %t115
  br i1 %t116, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb38:
  %t118 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 0
  %t121 = sub i64 16, 0
  %t122 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t120, 1
  store { i64, ptr } %t123, ptr %l58, !tbaa !27
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t124)
  store { i64, ptr } %t126, ptr %l60
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb40:
  %t127 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t128, i64 %t129)
  %t149 = getelementptr i8, ptr %t148, i64 %t129
  call void @olang_textcopy(ptr %t149, ptr %t130, i64 %t131)
  %t150 = getelementptr i8, ptr %t149, i64 %t131
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  call void @olang_textcopy(ptr %t153, ptr %t145, i64 %t146)
  %t154 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t148, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t164 = load ptr, ptr %l46, !tbaa !29
  %t165 = getelementptr %"compiler/build:Config", ptr %t164, i32 0, i32 30
  store { i64, ptr } %t162, ptr %t165, !tbaa !27
  %t166 = call i64 @std_2ftime_2eNow()
  store i64 %t166, ptr %l63
  br label %bb41
bb41:
  %t167 = load i64, ptr %l63, !tbaa !24
  store i64 %t167, ptr %l7, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t176 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t168, ptr %t169, { i64, ptr } %t170, ptr %t171)
  store i32 %t176, ptr %l68
  br label %bb42
bb42:
  %t177 = load i32, ptr %l68, !tbaa !23
  store i32 %t177, ptr %l8, !tbaa !23
  %t178 = load i32, ptr %l8, !tbaa !23
  %t180 = icmp ne i32 %t178, 0
  br i1 %t180, label %bb43, label %bb44
bb43:
  %t182 = load i32, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t182, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t184 = load ptr, ptr %l4, !tbaa !29
  %t186 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v4, ptr %s0, ptr %t184)
  store { i64, ptr } %t186, ptr %l73
  br label %bb46
bb46:
  %t187 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = extractvalue { i64, ptr } %t187, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t193)
  br label %bb47
bb47:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/build:Config", ptr %t195, i32 0, i32 0
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/build:Config", ptr %t199, i32 0, i32 31
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t203 = load i64, ptr @G_2ecompiler_2fbuild_2eRunCacheCap, !tbaa !24
  call void @compiler_2fbuild_2ePrune(ptr %v1, ptr %v1, { i64, ptr } %t198, { i64, ptr } %t202, i64 %t203)
  br label %bb48
bb48:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/build:Config", ptr %t207, i32 0, i32 16
  %t210 = load i1, ptr %t209, !tbaa !21
  br i1 %t210, label %bb49, label %bb50
bb49:
  call void @compiler_2fspin_2eEnd()
  br label %bb51
bb50:
  br label %bb55
bb51:
  %t212 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t212, ptr %l82, !tbaa !27
  %t213 = call i64 @std_2ftime_2eNow()
  store i64 %t213, ptr %l83
  br label %bb52
bb52:
  %t214 = load i64, ptr %l7, !tbaa !24
  %t215 = load i64, ptr %l83, !tbaa !24
  %t217 = sub i64 %t215, %t214
  store i64 %t217, ptr %l85, !tbaa !24
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/build:Config", ptr %t218, i32 0, i32 17
  %t221 = load i64, ptr %t220, !tbaa !24
  %t223 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t221, i64 1)
  store i64 %t223, ptr %l88
  br label %bb53
bb53:
  %t224 = load ptr, ptr %l1, !tbaa !29
  %t226 = getelementptr %"compiler/build:Config", ptr %t224, i32 0, i32 31
  %t227 = load { i64, ptr }, ptr %t226, !tbaa !27
  %t228 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t229 = load i64, ptr %l85, !tbaa !24
  %t230 = load i64, ptr %l88, !tbaa !24
  %t232 = call i32 @compiler_2fmeasure_2eMeasure(ptr %v3, ptr %v1, { i64, ptr } %t228, i64 %t229, i64 %t230, { i64, ptr } %t227)
  store i32 %t232, ptr %l91
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s0)
  %t233 = load i32, ptr %l91, !tbaa !23
  store i32 %t233, ptr %rv
  br label %ret
bb55:
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr %"compiler/build:Config", ptr %t234, i32 0, i32 31
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t241 = call i32 @std_2fos_2eExecInPlace(ptr %v1, ptr %v3, { i64, ptr } %t237, { i64, ptr } %t238)
  store i32 %t241, ptr %l95
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb57, label %ok.243, !prof !99
ok.243:
  br label %bb56
bb56:
  br label %bb64
bb57:
  %t244 = load i32, ptr %l95, !tbaa !23
  %t245 = ashr i32 %t244, 16
  %t247 = icmp eq i32 %t245, 1
  store i1 %t247, ptr %l97, !tbaa !21
  %t248 = load i32, ptr %l95, !tbaa !23
  %t249 = ashr i32 %t248, 16
  %t251 = icmp eq i32 %t249, 1
  br i1 %t251, label %bb58, label %bb59
bb58:
  call void @__olang_errpay_pop()
  br label %bb59
bb59:
  br label %bb60
bb60:
  store %olang.scope zeroinitializer, ptr %s8
  %t253 = load ptr, ptr %l4, !tbaa !29
  store ptr %t253, ptr %l100, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t254
  %t255 = getelementptr { i64, [3 x i64] }, ptr %t254, i32 0, i32 0
  store i64 0, ptr %t255
  %t256 = load { i64, [3 x i64] }, ptr %t254
  store { i64, [3 x i64] } %t256, ptr %l101
  %t257 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s8, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t257, ptr %l102
  br label %bb61
bb61:
  %t258 = load ptr, ptr %l100, !tbaa !29
  %t259 = load { i64, [3 x i64] }, ptr %l101
  %t260 = load %"compiler/diagmsg:Msg", ptr %l102
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t258, { i64, [3 x i64] } %t259, %"compiler/diagmsg:Msg" %t260)
  br label %bb62
bb62:
  %t261 = load ptr, ptr %l4, !tbaa !29
  %t263 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t261)
  store i32 %t263, ptr %l104
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t264 = load i32, ptr %l104, !tbaa !23
  store i32 %t264, ptr %rv
  br label %ret
bb64:
  call void @__olang_check_failed(ptr @olang_loc_3e7cb8585e177347_844f5af656df9c9b)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/build:Listed" } @compiler_2fbuild_2eListed_2eListingCode_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i64
  %l31 = alloca i32
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/build:Listed"
  %l53 = alloca i32
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i32
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l89 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/build:Listed" }
  store ptr %a1, ptr %l1
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a2, i32 1, ptr %t3, ptr %t4, ptr %t5)
  store i32 %t12, ptr %l18
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t23, 0
  store { i32, %"compiler/build:Listed" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v4, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb4
bb4:
  %t29 = load i64, ptr %l21, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/build:Program", ptr %t32, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v3, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb7
bb7:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/build:Listed" } %t42, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t47 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v4, ptr %t43, ptr %t44)
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb13, label %ok.49, !prof !99
ok.49:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t50 = load i32, ptr %l31, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t58, 0
  store { i32, %"compiler/build:Listed" } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/build:Config", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v3, ptr %s0, ptr %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t74)
  store { i64, ptr } %t76, ptr %l38
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t77)
  store { i64, ptr } %t79, ptr %l40
  br label %bb17
bb17:
  %t80 = load i1, ptr %l3, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t83, i64 %t84)
  %t101 = getelementptr i8, ptr %t100, i64 %t84
  call void @olang_textcopy(ptr %t101, ptr %t85, i64 %t86)
  %t102 = getelementptr i8, ptr %t101, i64 %t86
  call void @olang_textcopy(ptr %t102, ptr %t89, i64 %t90)
  %t103 = getelementptr i8, ptr %t102, i64 %t90
  call void @olang_textcopy(ptr %t103, ptr %t93, i64 %t94)
  %t104 = getelementptr i8, ptr %t103, i64 %t94
  call void @olang_textcopy(ptr %t104, ptr %t97, i64 %t98)
  %t105 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t100, 1
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t107, ptr %lp6
  %t109 = load ptr, ptr %lp6
  store { i64, ptr } %t106, ptr %t109, !tbaa !27
  %t110 = call %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v5)
  store %"compiler/build:Listed" %t110, ptr %l44
  br label %bb21
bb21:
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 64, i64 8)
  store ptr %t111, ptr %lp7
  %t112 = load %"compiler/build:Listed", ptr %l44
  %t113 = load ptr, ptr %lp7
  store %"compiler/build:Listed" %t112, ptr %t113
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 5
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb22, label %bb23
bb22:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t121 = load ptr, ptr %lp6
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t123 = load i1, ptr %l3, !tbaa !21
  %t124 = load ptr, ptr %lp7
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t132 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %v4, ptr %t119, ptr %t120, { i64, ptr } %t122, i1 %t123, ptr %t124, ptr %t125)
  store i32 %t132, ptr %l53
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb25, label %ok.134, !prof !99
ok.134:
  br label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb26
bb25:
  %t135 = load i32, ptr %l53, !tbaa !23
  %t136 = lshr i32 %t135, 16
  %t137 = and i32 %t135, 65535
  %t138 = icmp eq i32 %t136, 1
  %t139 = select i1 %t138, i32 1, i32 0
  %t140 = icmp eq i32 %t135, 0
  %t141 = shl i32 %t139, 16
  %t142 = or i32 %t141, %t137
  %t143 = select i1 %t140, i32 0, i32 %t142
  call void @__olang_scope_close(ptr %s0)
  %t145 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t143, 0
  store { i32, %"compiler/build:Listed" } %t145, ptr %rv
  br label %ret
bb26:
  %t146 = load ptr, ptr %lp7
  %t147 = load %"compiler/build:Listed", ptr %t146
  call void @__olang_scope_close(ptr %s0)
  %t149 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t147, 1
  store { i32, %"compiler/build:Listed" } %t149, ptr %rv
  br label %ret
bb27:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t152 = load ptr, ptr %l5, !tbaa !29
  %t156 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %v3, ptr %v4, ptr %v4, ptr %t150, ptr %t151, ptr %t152)
  %t157 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t156, 1
  %t158 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t156, 0
  store i32 %t158, ptr %l61
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb29, label %ok.160, !prof !99
ok.160:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l60
  br label %bb28
bb28:
  %t161 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l56
  br label %bb30
bb29:
  %t162 = load i32, ptr %l61, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  call void @__olang_scope_close(ptr %s0)
  %t172 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t170, 0
  store { i32, %"compiler/build:Listed" } %t172, ptr %rv
  br label %ret
bb30:
  %t173 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %l8
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb31
bb31:
  store ptr %l8, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t175 = load i64, ptr %l10, !tbaa !24
  store i64 %t175, ptr %l64, !tbaa !24
  %t176 = load ptr, ptr %l9, !tbaa !29
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t176)
  store i64 %t178, ptr %l66
  br label %bb33
bb33:
  %t179 = load i64, ptr %l64, !tbaa !24
  %t180 = load i64, ptr %l66, !tbaa !24
  %t181 = icmp slt i64 %t179, %t180
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb35:
  br label %bb36
bb36:
  %t185 = load ptr, ptr %l9, !tbaa !29
  %t186 = load i64, ptr %l10, !tbaa !24
  %t189 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v4, ptr %v4, ptr %t185, i64 %t186)
  store { i64, ptr } %t189, ptr %l71
  br label %bb37
bb37:
  %t190 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t190, ptr %l11, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t193 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v4, ptr %s5, { i64, ptr } %t191)
  store { i64, ptr } %t193, ptr %l73
  br label %bb38
bb38:
  %t194 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t202 = call i1 @std_2fos_2eExists(ptr %s5, { i64, ptr } %t200)
  store i1 %t202, ptr %l75
  br label %bb39
bb39:
  %t203 = load i1, ptr %l75, !tbaa !21
  br i1 %t203, label %bb40, label %bb41
bb40:
  %t204 = load ptr, ptr %lp7
  %t205 = getelementptr %"compiler/build:Listed", ptr %t204, i32 0, i32 1
  store ptr %t205, ptr %l76, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v4, ptr %v5, { i64, ptr } %t206)
  store { i64, ptr } %t208, ptr %l78
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t209 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t216 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v5, ptr %v5, ptr %t216, { i64, ptr } %t215)
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  %t218 = load i64, ptr %l10, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t223 = load ptr, ptr %l4, !tbaa !29
  %t224 = load ptr, ptr %lp6
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t226 = load i1, ptr %l3, !tbaa !21
  %t227 = load ptr, ptr %lp7
  %t228 = load ptr, ptr %l5, !tbaa !29
  %t236 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v1, ptr %v4, ptr %v3, ptr %v4, ptr %v5, ptr %v4, ptr %t222, ptr %l8, ptr %t223, { i64, ptr } %t225, i1 %t226, ptr %t227, ptr %t228)
  store i32 %t236, ptr %l89
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb48, label %ok.238, !prof !99
ok.238:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t239 = load i32, ptr %l89, !tbaa !23
  %t240 = lshr i32 %t239, 16
  %t241 = and i32 %t239, 65535
  %t242 = icmp eq i32 %t240, 1
  %t243 = select i1 %t242, i32 1, i32 0
  %t244 = icmp eq i32 %t239, 0
  %t245 = shl i32 %t243, 16
  %t246 = or i32 %t245, %t241
  %t247 = select i1 %t244, i32 0, i32 %t246
  call void @__olang_scope_close(ptr %s0)
  %t249 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t247, 0
  store { i32, %"compiler/build:Listed" } %t249, ptr %rv
  br label %ret
bb49:
  %t250 = load ptr, ptr %lp7
  %t251 = load %"compiler/build:Listed", ptr %t250
  call void @__olang_scope_close(ptr %s0)
  %t253 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t251, 1
  store { i32, %"compiler/build:Listed" } %t253, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/build:Listed" }, ptr %rv
  ret { i32, %"compiler/build:Listed" } %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i32
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i32
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l66 = alloca { i64, ptr }
  %l71 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l88 = alloca { i64, ptr }
  %l89 = alloca i64
  %l91 = alloca i64
  %l94 = alloca i64
  %l98 = alloca { i64, ptr }
  %l101 = alloca { i64, ptr }
  %l103 = alloca i32
  %l104 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l112 = alloca { i64, ptr }
  %l119 = alloca ptr
  %l123 = alloca { i64, ptr }
  %l128 = alloca { i64, ptr }
  %l137 = alloca { i64, ptr }
  %l147 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l156 = alloca { i64, ptr }
  %l157 = alloca i32
  %l159 = alloca i1
  %l162 = alloca ptr
  %l163 = alloca { i64, [3 x i64] }
  %l164 = alloca %"compiler/diagmsg:Msg"
  %l166 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t320 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 29
  store i1 true, ptr %t3, !tbaa !21
  %t4 = call i64 @std_2ftime_2eNow()
  store i64 %t4, ptr %l27
  br label %bb1
bb1:
  %t5 = load i64, ptr %l27, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t7, { i64, ptr } %t8, ptr %t9)
  store i32 %t14, ptr %l32
  br label %bb2
bb2:
  %t15 = load i32, ptr %l32, !tbaa !23
  store i32 %t15, ptr %l6, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb3
bb3:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t18 = icmp ne i32 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t20, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t26 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v4, ptr %s0, ptr %t22, ptr %t23)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l40
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb8, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l39
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t31, ptr %l36, !tbaa !27
  br label %bb11
bb8:
  %t32 = load i32, ptr %l40, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t36)
  store i32 %t38, ptr %l44
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l44, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t40, ptr %l7, !tbaa !27
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/build:Config", ptr %t41, i32 0, i32 16
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l47
  br label %bb14
bb13:
  br label %bb42
bb14:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l8
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t48, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l11, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t62 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t62, ptr %l55, !tbaa !27
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %t66, i64 %t63
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s3, ptr %s0, ptr %l8, { i64, ptr } %t68)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  store ptr %l8, ptr %l62, !tbaa !29
  %t77 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t79 = extractvalue { i64, ptr } %t77, 0
  %t81 = icmp eq i64 %t79, 0
  br i1 %t81, label %bb22, label %bb23
bb22:
  %t83 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 1
  %t86 = extractvalue { i64, ptr } %t83, 0
  %t87 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t86)
  call void @olang_textcopy(ptr %t87, ptr %t85, i64 %t86)
  %t88 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  store { i64, ptr } %t89, ptr %l66, !tbaa !27
  br label %bb25
bb23:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/build:Config", ptr %t91, i32 0, i32 31
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t96 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s3, { i64, ptr } %t94)
  store { i64, ptr } %t96, ptr %l71
  br label %bb24
bb24:
  %t97 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t97, ptr %l66, !tbaa !27
  br label %bb25
bb25:
  %t98 = load { i64, ptr }, ptr %l66, !tbaa !27
  %t99 = extractvalue { i64, ptr } %t98, 0
  %t100 = extractvalue { i64, ptr } %t98, 1
  %t101 = mul i64 %t99, 1
  %t102 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t101)
  call void @llvm.memcpy.p0.p0.i64(ptr %t102, ptr %t100, i64 %t101, i1 false)
  %t103 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t104 = insertvalue { i64, ptr } %t103, ptr %t102, 1
  %t105 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s3, ptr %s3, ptr %t105, { i64, ptr } %t104)
  br label %bb26
bb26:
  %t107 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t107, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t109 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 0
  store i64 %t111, ptr %l15, !tbaa !24
  br label %bb27
bb27:
  %t113 = load i64, ptr %l14, !tbaa !24
  %t114 = load i64, ptr %l15, !tbaa !24
  %t117 = icmp slt i64 %t113, %t114
  %t119 = xor i1 %t117, true
  br i1 %t119, label %bb28, label %bb29
bb28:
  br label %bb33
bb29:
  br label %bb30
bb30:
  %t121 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t121, ptr %l80, !tbaa !27
  %t122 = load i64, ptr %l14, !tbaa !24
  %t124 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t125 = load ptr, ptr %t124, !tbaa !27
  %t126 = getelementptr { i64, ptr }, ptr %t125, i64 %t122
  %t127 = load { i64, ptr }, ptr %t126, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s3, ptr %v3, ptr %l8, { i64, ptr } %t127)
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t132 = load i64, ptr %l14, !tbaa !24
  %t134 = add i64 %t132, 1
  store i64 %t134, ptr %l14, !tbaa !24
  br label %bb27
bb33:
  %t137 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s3, ptr %s3, ptr %l8)
  store { i64, ptr } %t137, ptr %l88
  br label %bb34
bb34:
  %t138 = call i64 @std_2ftime_2eNow()
  store i64 %t138, ptr %l89
  br label %bb35
bb35:
  %t139 = load i64, ptr %l5, !tbaa !24
  %t140 = load i64, ptr %l89, !tbaa !24
  %t142 = sub i64 %t140, %t139
  store i64 %t142, ptr %l91, !tbaa !24
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/build:Config", ptr %t143, i32 0, i32 17
  %t146 = load i64, ptr %t145, !tbaa !24
  %t148 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t146, i64 1)
  store i64 %t148, ptr %l94
  br label %bb36
bb36:
  %t149 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t149, 0
  %t153 = icmp eq i64 %t151, 0
  br i1 %t153, label %bb37, label %bb38
bb37:
  %t155 = load ptr, ptr %l1, !tbaa !29
  %t157 = getelementptr %"compiler/build:Config", ptr %t155, i32 0, i32 31
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t160 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s3, { i64, ptr } %t158)
  store { i64, ptr } %t160, ptr %l101
  br label %bb39
bb38:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d20, i32 0, i32 1) }, ptr %l98, !tbaa !27
  br label %bb40
bb39:
  %t161 = load { i64, ptr }, ptr %l101, !tbaa !27
  %t162 = extractvalue { i64, ptr } %t161, 0
  %t163 = extractvalue { i64, ptr } %t161, 1
  %t164 = mul i64 %t162, 1
  %t165 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t164)
  call void @llvm.memcpy.p0.p0.i64(ptr %t165, ptr %t163, i64 %t164, i1 false)
  %t166 = insertvalue { i64, ptr } undef, i64 %t162, 0
  %t167 = insertvalue { i64, ptr } %t166, ptr %t165, 1
  store { i64, ptr } %t167, ptr %l98, !tbaa !27
  br label %bb40
bb40:
  %t169 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t170 = load i64, ptr %l91, !tbaa !24
  %t171 = load i64, ptr %l94, !tbaa !24
  %t172 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t173 = call i32 @compiler_2fmeasure_2eMeasure(ptr %s3, ptr %s3, { i64, ptr } %t169, i64 %t170, i64 %t171, { i64, ptr } %t172)
  store i32 %t173, ptr %l103
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t174 = load i32, ptr %l103, !tbaa !23
  store i32 %t174, ptr %rv
  br label %ret
bb42:
  %t175 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t175, ptr %l104
  br label %bb43
bb43:
  %t176 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l104
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t176, ptr %l17
  %t177 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t177, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t179 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t181 = extractvalue { i64, ptr } %t179, 0
  store i64 %t181, ptr %l20, !tbaa !24
  br label %bb44
bb44:
  %t183 = load i64, ptr %l19, !tbaa !24
  %t184 = load i64, ptr %l20, !tbaa !24
  %t187 = icmp slt i64 %t183, %t184
  %t189 = xor i1 %t187, true
  br i1 %t189, label %bb45, label %bb46
bb45:
  br label %bb50
bb46:
  br label %bb47
bb47:
  %t191 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t191, ptr %l112, !tbaa !27
  %t192 = load i64, ptr %l19, !tbaa !24
  %t194 = getelementptr { i64, ptr }, ptr %l112, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = getelementptr { i64, ptr }, ptr %t195, i64 %t192
  %t197 = load { i64, ptr }, ptr %t196, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t197)
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t202 = load i64, ptr %l19, !tbaa !24
  %t204 = add i64 %t202, 1
  store i64 %t204, ptr %l19, !tbaa !24
  br label %bb44
bb50:
  store ptr %l17, ptr %l119, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t208 = extractvalue { i64, ptr } %t206, 0
  %t210 = icmp eq i64 %t208, 0
  br i1 %t210, label %bb51, label %bb52
bb51:
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = extractvalue { i64, ptr } %t212, 0
  %t216 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t214, i64 %t215)
  %t217 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t218 = insertvalue { i64, ptr } %t217, ptr %t216, 1
  store { i64, ptr } %t218, ptr %l123, !tbaa !27
  br label %bb54
bb52:
  %t220 = load ptr, ptr %l1, !tbaa !29
  %t222 = getelementptr %"compiler/build:Config", ptr %t220, i32 0, i32 31
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  %t225 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t223)
  store { i64, ptr } %t225, ptr %l128
  br label %bb53
bb53:
  %t226 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t226, ptr %l123, !tbaa !27
  br label %bb54
bb54:
  %t227 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t228 = extractvalue { i64, ptr } %t227, 0
  %t229 = extractvalue { i64, ptr } %t227, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  %t234 = load ptr, ptr %l119, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t234, { i64, ptr } %t233)
  br label %bb55
bb55:
  %t236 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t236, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t238 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t240 = extractvalue { i64, ptr } %t238, 0
  store i64 %t240, ptr %l24, !tbaa !24
  br label %bb56
bb56:
  %t242 = load i64, ptr %l23, !tbaa !24
  %t243 = load i64, ptr %l24, !tbaa !24
  %t246 = icmp slt i64 %t242, %t243
  %t248 = xor i1 %t246, true
  br i1 %t248, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t250 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t250, ptr %l137, !tbaa !27
  %t251 = load i64, ptr %l23, !tbaa !24
  %t253 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t254 = load ptr, ptr %t253, !tbaa !27
  %t255 = getelementptr { i64, ptr }, ptr %t254, i64 %t251
  %t256 = load { i64, ptr }, ptr %t255, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %v3, ptr %l17, { i64, ptr } %t256)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t261 = load i64, ptr %l23, !tbaa !24
  %t263 = add i64 %t261, 1
  store i64 %t263, ptr %l23, !tbaa !24
  br label %bb56
bb62:
  %t265 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t269 = icmp eq i64 %t267, 0
  br i1 %t269, label %bb63, label %bb64
bb63:
  %t271 = load ptr, ptr %l1, !tbaa !29
  %t273 = getelementptr %"compiler/build:Config", ptr %t271, i32 0, i32 31
  %t274 = load { i64, ptr }, ptr %t273, !tbaa !27
  %t276 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t274)
  store { i64, ptr } %t276, ptr %l150
  br label %bb65
bb64:
  %t277 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %t278, i64 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !37
  %t282 = extractvalue { i64, ptr } %t280, 1
  %t283 = extractvalue { i64, ptr } %t280, 0
  %t284 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t283)
  call void @olang_textcopy(ptr %t284, ptr %t282, i64 %t283)
  %t285 = insertvalue { i64, ptr } undef, i64 %t283, 0
  %t286 = insertvalue { i64, ptr } %t285, ptr %t284, 1
  %t288 = extractvalue { i64, ptr } %t286, 0
  %t289 = extractvalue { i64, ptr } %t286, 1
  %t290 = mul i64 %t288, 1
  %t291 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t290)
  call void @llvm.memcpy.p0.p0.i64(ptr %t291, ptr %t289, i64 %t290, i1 false)
  %t292 = insertvalue { i64, ptr } undef, i64 %t288, 0
  %t293 = insertvalue { i64, ptr } %t292, ptr %t291, 1
  store { i64, ptr } %t293, ptr %l147, !tbaa !27
  br label %bb66
bb65:
  %t295 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t296 = extractvalue { i64, ptr } %t295, 0
  %t297 = extractvalue { i64, ptr } %t295, 1
  %t298 = mul i64 %t296, 1
  %t299 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t298)
  call void @llvm.memcpy.p0.p0.i64(ptr %t299, ptr %t297, i64 %t298, i1 false)
  %t300 = insertvalue { i64, ptr } undef, i64 %t296, 0
  %t301 = insertvalue { i64, ptr } %t300, ptr %t299, 1
  store { i64, ptr } %t301, ptr %l147, !tbaa !27
  br label %bb66
bb66:
  %t304 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t304, ptr %l156
  br label %bb67
bb67:
  %t305 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t306 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t307 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t305, { i64, ptr } %t306)
  store i32 %t307, ptr %l157
  %t308 = icmp ne i32 %t307, 0
  br i1 %t308, label %bb69, label %ok.309, !prof !99
ok.309:
  br label %bb68
bb68:
  br label %bb76
bb69:
  %t310 = load i32, ptr %l157, !tbaa !23
  %t311 = ashr i32 %t310, 16
  %t313 = icmp eq i32 %t311, 1
  store i1 %t313, ptr %l159, !tbaa !21
  %t314 = load i32, ptr %l157, !tbaa !23
  %t315 = ashr i32 %t314, 16
  %t317 = icmp eq i32 %t315, 1
  br i1 %t317, label %bb70, label %bb71
bb70:
  call void @__olang_errpay_pop()
  br label %bb71
bb71:
  br label %bb72
bb72:
  store %olang.scope zeroinitializer, ptr %s19
  %t319 = load ptr, ptr %l4, !tbaa !29
  store ptr %t319, ptr %l162, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t320
  %t321 = getelementptr { i64, [3 x i64] }, ptr %t320, i32 0, i32 0
  store i64 0, ptr %t321
  %t322 = load { i64, [3 x i64] }, ptr %t320
  store { i64, [3 x i64] } %t322, ptr %l163
  %t323 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s19, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d21, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t323, ptr %l164
  br label %bb73
bb73:
  %t324 = load ptr, ptr %l162, !tbaa !29
  %t325 = load { i64, [3 x i64] }, ptr %l163
  %t326 = load %"compiler/diagmsg:Msg", ptr %l164
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t324, { i64, [3 x i64] } %t325, %"compiler/diagmsg:Msg" %t326)
  br label %bb74
bb74:
  %t327 = load ptr, ptr %l4, !tbaa !29
  %t329 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t327)
  store i32 %t329, ptr %l166
  br label %bb75
bb75:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t330 = load i32, ptr %l166, !tbaa !23
  store i32 %t330, ptr %rv
  br label %ret
bb76:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/os:FileInfo"
  %l7 = alloca i1
  %l8 = alloca %"compiler/build:Program"
  %l9 = alloca { i32, { i64, ptr } }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/build:Program"
  %lp14 = alloca ptr
  %l15 = alloca { i32, { i64, ptr } }
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/os:FileInfo"
  %l25 = alloca %"std/os:FileInfo"
  %l26 = alloca i32
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"compiler/diagmsg:Msg"
  %l50 = alloca i32
  %l52 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca %"compiler/build:Program"
  %l63 = alloca { i32, { i64, ptr } }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l83 = alloca %"compiler/build:Program"
  %l86 = alloca %"compiler/diag:Diagnostics"
  %l93 = alloca { i32, { i64, ptr } }
  %l95 = alloca { i64, ptr }
  %l96 = alloca i64
  %l97 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l106 = alloca { i64, ptr }
  %l107 = alloca i32
  %l109 = alloca i1
  %l111 = alloca i32
  %l114 = alloca i1
  %l116 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l124 = alloca { i64, ptr }
  %l131 = alloca ptr
  %l133 = alloca { i64, ptr }
  %l138 = alloca i32
  %l141 = alloca ptr
  %l142 = alloca ptr
  %l143 = alloca { i64, ptr }
  %l144 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca { i64, ptr }
  %l147 = alloca i64
  %l150 = alloca i32
  %l154 = alloca i32
  %l162 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t75 = alloca %"compiler/build:Program", align 8
  %t137 = alloca %"compiler/build:Program", align 8
  %t142 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = load i64, ptr %l22, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t3)
  %t6 = extractvalue { i32, %"std/os:FileInfo" } %t5, 1
  %t7 = extractvalue { i32, %"std/os:FileInfo" } %t5, 0
  store i32 %t7, ptr %l26
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store %"std/os:FileInfo" %t6, ptr %l25
  br label %bb2
bb2:
  %t10 = load %"std/os:FileInfo", ptr %l25
  store %"std/os:FileInfo" %t10, ptr %l23
  br label %bb9
bb3:
  %t11 = load i32, ptr %l26, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l28, !tbaa !21
  %t15 = load i32, ptr %l26, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l32, !tbaa !27
  %t22 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t22, ptr %l33
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t26 = load %"compiler/diagmsg:Msg", ptr %l33
  %t28 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t24, { i64, ptr } %t25, %"compiler/diagmsg:Msg" %t26, ptr %t23)
  store i32 %t28, ptr %l35
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l35, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb9:
  %t30 = load %"std/os:FileInfo", ptr %l23
  store %"std/os:FileInfo" %t30, ptr %l6
  %t31 = getelementptr %"std/os:FileInfo", ptr %l6, i32 0, i32 0
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 3}
  %t34 = trunc i64 1 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l38, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l39, !tbaa !27
  %t39 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v3)
  store %"compiler/diagmsg:Msg" %t39, ptr %l40
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load ptr, ptr %l38, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t43 = load %"compiler/diagmsg:Msg", ptr %l40
  %t45 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t41, { i64, ptr } %t42, %"compiler/diagmsg:Msg" %t43, ptr %t40)
  store i32 %t45, ptr %l42
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i32, ptr %l42, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = getelementptr %"std/os:FileInfo", ptr %l6, i32 0, i32 0
  %t48 = load i32, ptr %t47, !range !{i32 0, i32 3}
  %t50 = trunc i64 0 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l46, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l47, !tbaa !27
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v3)
  store %"compiler/diagmsg:Msg" %t57, ptr %l48
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load ptr, ptr %l46, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t61 = load %"compiler/diagmsg:Msg", ptr %l48
  %t63 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t59, { i64, ptr } %t60, %"compiler/diagmsg:Msg" %t61, ptr %t58)
  store i32 %t63, ptr %l50
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i32, ptr %l50, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = call i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2esplitsTests(ptr %v1, ptr %t65)
  store i1 %t67, ptr %l52
  br label %bb20
bb20:
  %t68 = load i1, ptr %l52, !tbaa !21
  store i1 %t68, ptr %l7, !tbaa !21
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l53, !tbaa !29
  %t70 = load i1, ptr %l7, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i64 1, ptr %l55, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb23
bb23:
  %t72 = load i64, ptr %l55, !tbaa !24
  %t73 = load ptr, ptr %l53, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 25
  store i64 %t72, ptr %t74, !tbaa !24
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t75, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t75, i64 264, i1 false)
  br label %bb24
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l56, i64 264, i1 false)
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = load i1, ptr %l7, !tbaa !21
  %t87 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %s0, ptr %s0, ptr %t76, ptr %t77, { i64, ptr } %t78, ptr %t79, ptr %l8, i1 %t80)
  store { i32, { i64, ptr } } %t87, ptr %l63
  br label %bb25
bb25:
  %t88 = load { i32, { i64, ptr } }, ptr %l63
  store { i32, { i64, ptr } } %t88, ptr %l9
  %t89 = getelementptr { i32, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  store i32 %t90, ptr %l10, !tbaa !23
  %t92 = getelementptr { i32, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l65, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l66, !tbaa !24
  %t96 = load i64, ptr %l66, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l67, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l66, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t107, ptr %l11, !tbaa !27
  %t108 = load i32, ptr %l10, !tbaa !23
  %t110 = icmp sge i32 %t108, 0
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = load i32, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t114 = load i1, ptr %l7, !tbaa !21
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 8
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t116)
  store i64 %t118, ptr %l74
  br label %bb31
bb30:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb32
bb31:
  %t119 = load i64, ptr %l74, !tbaa !24
  %t120 = icmp sgt i64 %t119, 0
  store i1 %t120, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t122 = load i1, ptr %l72, !tbaa !21
  store i1 %t122, ptr %l7, !tbaa !21
  %t123 = load i1, ptr %l7, !tbaa !21
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/build:Config", ptr %t127, i32 0, i32 25
  store i64 0, ptr %t129, !tbaa !24
  br label %bb35
bb34:
  br label %bb35
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l79, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t130, ptr %l12, !tbaa !27
  %t132 = load i1, ptr %l7, !tbaa !21
  br i1 %t132, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/build:Config", ptr %t134, i32 0, i32 6
  store i1 true, ptr %t136, !tbaa !21
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t137, ptr %s6)
  call void @llvm.memmove.p0.p0.i64(ptr %l83, ptr %t137, i64 264, i1 false)
  br label %bb38
bb37:
  br label %bb44
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l83, i64 264, i1 false)
  %t138 = load ptr, ptr %l1, !tbaa !29
  %t140 = getelementptr %"compiler/build:Config", ptr %t138, i32 0, i32 28
  %t141 = load i1, ptr %t140, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t142, ptr %v1, i1 %t141)
  call void @llvm.memmove.p0.p0.i64(ptr %l86, ptr %t142, i64 704, i1 false)
  br label %bb39
bb39:
  %t144 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 704, i64 8)
  store ptr %t144, ptr %lp14
  %t145 = load ptr, ptr %lp14
  call void @llvm.memmove.p0.p0.i64(ptr %t145, ptr %l86, i64 704, i1 false)
  %t146 = load ptr, ptr %l1, !tbaa !29
  %t147 = load ptr, ptr %l0, !tbaa !29
  %t148 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t149 = load ptr, ptr %lp14
  %t150 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 8
  %t157 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eraceBinary_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %v0, ptr %v2, ptr %v1, ptr %s6, ptr %s0, ptr %s6, ptr %t146, ptr %t147, { i64, ptr } %t148, ptr %t149, ptr %l13, ptr %t150)
  store { i32, { i64, ptr } } %t157, ptr %l93
  br label %bb40
bb40:
  %t158 = load { i32, { i64, ptr } }, ptr %l93
  store { i32, { i64, ptr } } %t158, ptr %l15
  %t159 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t160 = load i32, ptr %t159, !tbaa !23
  store i32 %t160, ptr %l10, !tbaa !23
  %t162 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 1
  %t163 = load { i64, ptr }, ptr %t162, !tbaa !27
  store { i64, ptr } %t163, ptr %l95, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t165 = extractvalue { i64, ptr } %t164, 0
  store i64 %t165, ptr %l96, !tbaa !24
  %t166 = load i64, ptr %l96, !tbaa !24
  %t167 = mul i64 %t166, 1
  %t168 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t167)
  %t169 = insertvalue { i64, ptr } undef, i64 %t166, 0
  %t170 = insertvalue { i64, ptr } %t169, ptr %t168, 1
  store { i64, ptr } %t170, ptr %l97, !tbaa !27
  %t171 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t172 = load ptr, ptr %t171, !tbaa !27
  %t173 = getelementptr { i64, ptr }, ptr %l95, i32 0, i32 1
  %t174 = load ptr, ptr %t173, !tbaa !27
  %t175 = load i64, ptr %l96, !tbaa !24
  %t176 = mul i64 %t175, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t172, ptr %t174, i64 %t176, i1 false)
  %t177 = load { i64, ptr }, ptr %l97, !tbaa !27
  store { i64, ptr } %t177, ptr %l12, !tbaa !27
  %t178 = load i32, ptr %l10, !tbaa !23
  %t180 = icmp sge i32 %t178, 0
  br i1 %t180, label %bb41, label %bb42
bb41:
  %t182 = load i32, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t182, ptr %rv
  br label %ret
bb42:
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  br label %bb44
bb44:
  call void @compiler_2fspin_2eEnd()
  br label %bb45
bb45:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t185 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v1, ptr %v2, ptr %t184, { i64, ptr } %t185)
  br label %bb46
bb46:
  %t188 = load ptr, ptr %l1, !tbaa !29
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t192 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v3, ptr %s0, ptr %t188, ptr %t189)
  %t193 = extractvalue { i32, { i64, ptr } } %t192, 1
  %t194 = extractvalue { i32, { i64, ptr } } %t192, 0
  store i32 %t194, ptr %l107
  %t195 = icmp ne i32 %t194, 0
  br i1 %t195, label %bb48, label %ok.196, !prof !99
ok.196:
  store { i64, ptr } %t193, ptr %l106
  br label %bb47
bb47:
  %t197 = load { i64, ptr }, ptr %l106, !tbaa !27
  store { i64, ptr } %t197, ptr %l103, !tbaa !27
  br label %bb51
bb48:
  %t198 = load i32, ptr %l107, !tbaa !23
  %t199 = ashr i32 %t198, 16
  %t201 = icmp eq i32 %t199, 1
  store i1 %t201, ptr %l109, !tbaa !21
  br label %bb49
bb49:
  %t202 = load ptr, ptr %l3, !tbaa !29
  %t204 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t202)
  store i32 %t204, ptr %l111
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t205 = load i32, ptr %l111, !tbaa !23
  store i32 %t205, ptr %rv
  br label %ret
bb51:
  %t206 = load { i64, ptr }, ptr %l103, !tbaa !27
  store { i64, ptr } %t206, ptr %l16, !tbaa !27
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/build:Config", ptr %t207, i32 0, i32 12
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t210, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t212, ptr %l114
  br label %bb52
bb52:
  %t213 = load i1, ptr %l114, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s9
  %t216 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t216, ptr %l116
  br label %bb55
bb54:
  br label %bb66
bb55:
  %t217 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l116
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t217, ptr %l17
  %t218 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t218, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t220 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t222 = extractvalue { i64, ptr } %t220, 0
  store i64 %t222, ptr %l20, !tbaa !24
  br label %bb56
bb56:
  %t224 = load i64, ptr %l19, !tbaa !24
  %t225 = load i64, ptr %l20, !tbaa !24
  %t228 = icmp slt i64 %t224, %t225
  %t230 = xor i1 %t228, true
  br i1 %t230, label %bb57, label %bb58
bb57:
  br label %bb62
bb58:
  br label %bb59
bb59:
  %t232 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t232, ptr %l124, !tbaa !27
  %t233 = load i64, ptr %l19, !tbaa !24
  %t235 = getelementptr { i64, ptr }, ptr %l124, i32 0, i32 1
  %t236 = load ptr, ptr %t235, !tbaa !27
  %t237 = getelementptr { i64, ptr }, ptr %t236, i64 %t233
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s9, ptr %s0, ptr %l17, { i64, ptr } %t238)
  br label %bb60
bb60:
  br label %bb61
bb61:
  %t243 = load i64, ptr %l19, !tbaa !24
  %t245 = add i64 %t243, 1
  store i64 %t245, ptr %l19, !tbaa !24
  br label %bb56
bb62:
  store ptr %l17, ptr %l131, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t249 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s9, { i64, ptr } %t247)
  store { i64, ptr } %t249, ptr %l133
  br label %bb63
bb63:
  %t250 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t257 = load ptr, ptr %l131, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s9, ptr %s9, ptr %t257, { i64, ptr } %t256)
  br label %bb64
bb64:
  %t259 = load ptr, ptr %l1, !tbaa !29
  %t263 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v1, ptr %s9, ptr %s0, ptr %t259, ptr %l17, ptr %l8)
  store i32 %t263, ptr %l138
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t264 = load i32, ptr %l138, !tbaa !23
  store i32 %t264, ptr %rv
  br label %ret
bb66:
  %t265 = load i1, ptr %l7, !tbaa !21
  %t267 = xor i1 %t265, true
  br i1 %t267, label %bb67, label %bb68
bb67:
  store %olang.scope zeroinitializer, ptr %s13
  %t269 = load ptr, ptr %l1, !tbaa !29
  store ptr %t269, ptr %l141, !tbaa !29
  %t270 = load ptr, ptr %l1, !tbaa !29
  store ptr %t270, ptr %l142, !tbaa !29
  %t271 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t271, ptr %l143, !tbaa !27
  %t272 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t272, ptr %l144, !tbaa !27
  %t273 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t273, ptr %l145, !tbaa !27
  %t274 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t274, ptr %l146, !tbaa !27
  %t275 = call i64 @std_2ftime_2eNow()
  store i64 %t275, ptr %l147
  br label %bb69
bb68:
  br label %bb72
bb69:
  %t276 = load i64, ptr %l5, !tbaa !24
  %t277 = load i64, ptr %l147, !tbaa !24
  %t279 = sub i64 %t277, %t276
  %t280 = load ptr, ptr %l142, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t282 = load { i64, ptr }, ptr %l144, !tbaa !27
  %t283 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t284 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t286 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v4, ptr %s13, ptr %t280, { i64, ptr } %t281, { i64, ptr } %t282, { i64, ptr } %t283, { i64, ptr } %t284, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, i64 %t279)
  store i32 %t286, ptr %l150
  br label %bb70
bb70:
  %t287 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t288 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t289 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 7
  %t290 = load ptr, ptr %l141, !tbaa !29
  %t291 = load i32, ptr %l150, !tbaa !23
  %t295 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v1, ptr %v2, ptr %v4, ptr %s0, ptr %t290, i32 %t291, { i64, ptr } %t287, { i64, ptr } %t288, ptr %t289)
  store i32 %t295, ptr %l154
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t296 = load i32, ptr %l154, !tbaa !23
  store i32 %t296, ptr %rv
  br label %ret
bb72:
  %t297 = load ptr, ptr %l1, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t303 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 7
  %t311 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunParts(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %v2, ptr %v4, ptr %s0, ptr %t297, { i64, ptr } %t298, { i64, ptr } %t299, { i64, ptr } %t300, { i64, ptr } %t301, { i64, ptr } %t302, ptr %t303)
  store i32 %t311, ptr %l162
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t312 = load i32, ptr %l162, !tbaa !23
  store i32 %t312, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eraceBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca { i32, { i64, ptr } }
  %l8 = alloca i32
  %lp9 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i32, { i64, ptr } }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 5
  store i1 false, ptr %t11, !tbaa !21
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 25
  store i64 2, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l17
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l19
  br label %bb1
bb1:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = getelementptr %"compiler/build:Config", ptr %t22, i32 0, i32 26
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %t23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/build:Config", ptr %t24, i32 0, i32 3
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eSetBool(ptr %v0, ptr %s0, ptr %t26, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, i1 true)
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %s0, ptr %t28, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, i1 false)
  store { i32, { i64, ptr } } %t38, ptr %l27
  br label %bb3
bb3:
  %t39 = load { i32, { i64, ptr } }, ptr %l27
  store { i32, { i64, ptr } } %t39, ptr %l7
  %t40 = getelementptr { i32, { i64, ptr } }, ptr %l7, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l8, !tbaa !23
  %t43 = getelementptr { i32, { i64, ptr } }, ptr %l7, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l30, !tbaa !24
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l31, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 16, i64 8)
  store ptr %t58, ptr %lp9
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = load ptr, ptr %lp9
  store { i64, ptr } %t59, ptr %t60, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/build:Config", ptr %t61, i32 0, i32 6
  store i1 false, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i1, ptr %l6, !tbaa !21
  %t68 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 5
  store i1 %t65, ptr %t68, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Config", ptr %t69, i32 0, i32 3
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eSetBool(ptr %v0, ptr %s0, ptr %t71, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d26, i32 0, i32 1) }, i1 false)
  br label %bb4
bb4:
  %t73 = load i32, ptr %l8, !tbaa !23
  %t74 = load ptr, ptr %lp9
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t77 = insertvalue { i32, { i64, ptr } } undef, i32 %t73, 0
  %t79 = insertvalue { i32, { i64, ptr } } %t77, { i64, ptr } %t75, 1
  call void @__olang_scope_close(ptr %s0)
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp7 = alloca ptr
  %l14 = alloca i32
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i32, { i64, ptr } }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i32, { i64, ptr } }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i64
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i32, { i64, ptr } }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l53 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i32, { i64, ptr } }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca i32
  %l72 = alloca i1
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i32, { i64, ptr } }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i32
  %l88 = alloca i1
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i32, { i64, ptr } }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l111 = alloca i1
  %l115 = alloca i32
  %l117 = alloca i1
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i32, { i64, ptr } }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v1, ptr %v2, ptr %v0, ptr %v4, ptr %v3, ptr %a1, { i64, ptr } %t2, i32 2, ptr %t3, ptr %t4, ptr %t5)
  store i32 %t12, ptr %l14
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  br label %bb1
bb1:
  br label %bb11
bb2:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb6, label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v2, ptr %v3, ptr %t21, { i64, ptr } %t22, ptr %t23)
  store i32 %t27, ptr %l20
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d427f69e0d58601c_ef1499a0f9cee590)
  unreachable
bb8:
  %t28 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t28, ptr %l27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t30 = load i32, ptr %l20, !tbaa !23
  %t31 = insertvalue { i32, { i64, ptr } } undef, i32 %t30, 0
  %t33 = insertvalue { i32, { i64, ptr } } %t31, { i64, ptr } %t29, 1
  store { i32, { i64, ptr } } %t33, ptr %l23
  %t34 = getelementptr { i32, { i64, ptr } }, ptr %l23, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l24, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = getelementptr { i32, { i64, ptr } }, ptr %l23, i32 0, i32 1
  store { i64, ptr } %t49, ptr %t50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i32, { i64, ptr } }, ptr %l23
  store { i32, { i64, ptr } } %t51, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t53 = load i32, ptr %l27, !tbaa !23
  %t54 = insertvalue { i32, { i64, ptr } } undef, i32 %t53, 0
  %t56 = insertvalue { i32, { i64, ptr } } %t54, { i64, ptr } %t52, 1
  store { i32, { i64, ptr } } %t56, ptr %l30
  %t57 = getelementptr { i32, { i64, ptr } }, ptr %l30, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l32, !tbaa !24
  %t61 = load i64, ptr %l32, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l33, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = mul i64 %t70, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t73 = getelementptr { i32, { i64, ptr } }, ptr %l30, i32 0, i32 1
  store { i64, ptr } %t72, ptr %t73, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i32, { i64, ptr } }, ptr %l30
  store { i32, { i64, ptr } } %t74, ptr %rv
  br label %ret
bb11:
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t75)
  store i64 %t77, ptr %l35
  br label %bb12
bb12:
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = icmp sgt i64 %t78, 0
  br i1 %t79, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb16
bb14:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/build:Program", ptr %t81, i32 0, i32 0
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t83)
  store i64 %t85, ptr %l40
  br label %bb15
bb15:
  %t86 = load i64, ptr %l40, !tbaa !24
  %t87 = icmp eq i64 %t86, 0
  store i1 %t87, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t89 = load i1, ptr %l37, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v2, ptr %v3, ptr %t90, { i64, ptr } %t91, ptr %t92)
  store i32 %t96, ptr %l45
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t98 = load i32, ptr %l45, !tbaa !23
  %t99 = insertvalue { i32, { i64, ptr } } undef, i32 %t98, 0
  %t101 = insertvalue { i32, { i64, ptr } } %t99, { i64, ptr } %t97, 1
  store { i32, { i64, ptr } } %t101, ptr %l48
  %t102 = getelementptr { i32, { i64, ptr } }, ptr %l48, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l49, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l50, !tbaa !24
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l51, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t118 = getelementptr { i32, { i64, ptr } }, ptr %l48, i32 0, i32 1
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i32, { i64, ptr } }, ptr %l48
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
bb20:
  br i1 %a5, label %bb21, label %bb22
bb21:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/build:Program", ptr %t122, i32 0, i32 9
  %t125 = load i64, ptr %t124, !tbaa !24
  %t127 = icmp eq i64 %t125, 0
  store i1 %t127, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t129 = load i1, ptr %l53, !tbaa !21
  br i1 %t129, label %bb24, label %bb25
bb24:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = getelementptr %"compiler/build:Program", ptr %t130, i32 0, i32 8
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t132)
  store i64 %t134, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb27
bb26:
  %t135 = load i64, ptr %l60, !tbaa !24
  %t136 = icmp sgt i64 %t135, 0
  store i1 %t136, ptr %l57, !tbaa !21
  br label %bb27
bb27:
  %t138 = load i1, ptr %l57, !tbaa !21
  br i1 %t138, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t140 = insertvalue { i32, { i64, ptr } } undef, i32 -2, 0
  %t142 = insertvalue { i32, { i64, ptr } } %t140, { i64, ptr } %t139, 1
  store { i32, { i64, ptr } } %t142, ptr %l64
  %t143 = getelementptr { i32, { i64, ptr } }, ptr %l64, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l65, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l66, !tbaa !24
  %t147 = load i64, ptr %l66, !tbaa !24
  %t148 = mul i64 %t147, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l67, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l66, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t159 = getelementptr { i32, { i64, ptr } }, ptr %l64, i32 0, i32 1
  store { i64, ptr } %t158, ptr %t159, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t160 = load { i32, { i64, ptr } }, ptr %l64
  store { i32, { i64, ptr } } %t160, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t165 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v3, ptr %t161, ptr %t162)
  store i32 %t165, ptr %l70
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb32, label %ok.167, !prof !99
ok.167:
  br label %bb31
bb31:
  br label %bb35
bb32:
  %t168 = load i32, ptr %l70, !tbaa !23
  %t169 = ashr i32 %t168, 16
  %t171 = icmp eq i32 %t169, 1
  store i1 %t171, ptr %l72, !tbaa !21
  br label %bb33
bb33:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t172)
  store i32 %t174, ptr %l74
  br label %bb34
bb34:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l75, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t176 = load i32, ptr %l74, !tbaa !23
  %t177 = insertvalue { i32, { i64, ptr } } undef, i32 %t176, 0
  %t179 = insertvalue { i32, { i64, ptr } } %t177, { i64, ptr } %t175, 1
  store { i32, { i64, ptr } } %t179, ptr %l77
  %t180 = getelementptr { i32, { i64, ptr } }, ptr %l77, i32 0, i32 1
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l78, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  store i64 %t183, ptr %l79, !tbaa !24
  %t184 = load i64, ptr %l79, !tbaa !24
  %t185 = mul i64 %t184, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t185)
  %t187 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l80, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l79, !tbaa !24
  %t194 = mul i64 %t193, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t190, ptr %t192, i64 %t194, i1 false)
  %t195 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t196 = getelementptr { i32, { i64, ptr } }, ptr %l77, i32 0, i32 1
  store { i64, ptr } %t195, ptr %t196, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t197 = load { i32, { i64, ptr } }, ptr %l77
  store { i32, { i64, ptr } } %t197, ptr %rv
  br label %ret
bb35:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t204 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v4, ptr %v3, ptr %v3, ptr %t198, ptr %t199, ptr %t200)
  %t205 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t204, 1
  %t206 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t204, 0
  store i32 %t206, ptr %l86
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb37, label %ok.208, !prof !99
ok.208:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l85
  br label %bb36
bb36:
  %t209 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l81
  br label %bb40
bb37:
  %t210 = load i32, ptr %l86, !tbaa !23
  %t211 = ashr i32 %t210, 16
  %t213 = icmp eq i32 %t211, 1
  store i1 %t213, ptr %l88, !tbaa !21
  br label %bb38
bb38:
  %t214 = load ptr, ptr %l3, !tbaa !29
  %t216 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t214)
  store i32 %t216, ptr %l90
  br label %bb39
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d32, i32 0, i32 1) }, ptr %l91, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t218 = load i32, ptr %l90, !tbaa !23
  %t219 = insertvalue { i32, { i64, ptr } } undef, i32 %t218, 0
  %t221 = insertvalue { i32, { i64, ptr } } %t219, { i64, ptr } %t217, 1
  store { i32, { i64, ptr } } %t221, ptr %l93
  %t222 = getelementptr { i32, { i64, ptr } }, ptr %l93, i32 0, i32 1
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l94, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l95, !tbaa !24
  %t226 = load i64, ptr %l95, !tbaa !24
  %t227 = mul i64 %t226, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t227)
  %t229 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  store { i64, ptr } %t230, ptr %l96, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l95, !tbaa !24
  %t236 = mul i64 %t235, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %t234, i64 %t236, i1 false)
  %t237 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t238 = getelementptr { i32, { i64, ptr } }, ptr %l93, i32 0, i32 1
  store { i64, ptr } %t237, ptr %t238, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t239 = load { i32, { i64, ptr } }, ptr %l93
  store { i32, { i64, ptr } } %t239, ptr %rv
  br label %ret
bb40:
  %t240 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t240, ptr %l6
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d33, i32 0, i32 1) })
  br label %bb41
bb41:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/build:Config", ptr %t241, i32 0, i32 0
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  store { i64, ptr } %t244, ptr %l98, !tbaa !27
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v4, ptr %s0, ptr %t245)
  store { i64, ptr } %t247, ptr %l100
  br label %bb42
bb42:
  %t248 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 0
  %t250 = extractvalue { i64, ptr } %t248, 1
  %t251 = mul i64 %t249, 1
  %t252 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t251)
  call void @llvm.memcpy.p0.p0.i64(ptr %t252, ptr %t250, i64 %t251, i1 false)
  %t253 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t256 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t254)
  store { i64, ptr } %t256, ptr %l102
  br label %bb43
bb43:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t257)
  store { i64, ptr } %t259, ptr %l104
  br label %bb44
bb44:
  %t260 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t261, i64 %t262)
  %t278 = getelementptr i8, ptr %t277, i64 %t262
  call void @olang_textcopy(ptr %t278, ptr %t263, i64 %t264)
  %t279 = getelementptr i8, ptr %t278, i64 %t264
  call void @olang_textcopy(ptr %t279, ptr %t267, i64 %t268)
  %t280 = getelementptr i8, ptr %t279, i64 %t268
  call void @olang_textcopy(ptr %t280, ptr %t270, i64 %t271)
  %t281 = getelementptr i8, ptr %t280, i64 %t271
  call void @olang_textcopy(ptr %t281, ptr %t274, i64 %t275)
  %t282 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t277, 1
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 16, i64 8)
  store ptr %t284, ptr %lp7
  %t286 = load ptr, ptr %lp7
  store { i64, ptr } %t283, ptr %t286, !tbaa !27
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l106, !tbaa !29
  store ptr %l6, ptr %l107, !tbaa !29
  %t288 = load ptr, ptr %lp7
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  store { i64, ptr } %t289, ptr %l108, !tbaa !27
  %t290 = load ptr, ptr %l4, !tbaa !29
  %t292 = getelementptr %"compiler/build:Program", ptr %t290, i32 0, i32 2
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  %t295 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t293, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d36, i32 0, i32 1) })
  store i1 %t295, ptr %l111
  br label %bb45
bb45:
  %t296 = load i1, ptr %l111, !tbaa !21
  %t297 = xor i1 %t296, true
  %t298 = load ptr, ptr %l4, !tbaa !29
  %t300 = getelementptr %"compiler/build:Program", ptr %t298, i32 0, i32 3
  %t301 = load ptr, ptr %l106, !tbaa !29
  %t302 = load ptr, ptr %l107, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t306 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v3, ptr %v5, ptr %v4, ptr %s0, ptr %t301, ptr %t302, { i64, ptr } %t303, i1 %t297, ptr %t300, ptr null)
  store i32 %t306, ptr %l115
  %t307 = icmp ne i32 %t306, 0
  br i1 %t307, label %bb47, label %ok.308, !prof !99
ok.308:
  br label %bb46
bb46:
  br label %bb51
bb47:
  %t309 = load i32, ptr %l115, !tbaa !23
  %t310 = ashr i32 %t309, 16
  %t312 = icmp eq i32 %t310, 1
  store i1 %t312, ptr %l117, !tbaa !21
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 1
  %t317 = extractvalue { i64, ptr } %t314, 0
  %t318 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t320 = add i64 %t317, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t316, i64 %t317)
  %t322 = getelementptr i8, ptr %t321, i64 %t317
  call void @olang_textcopy(ptr %t322, ptr %t318, i64 %t319)
  %t323 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t321, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = extractvalue { i64, ptr } %t324, 1
  %t328 = mul i64 %t326, 1
  %t329 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t328)
  call void @llvm.memcpy.p0.p0.i64(ptr %t329, ptr %t327, i64 %t328, i1 false)
  %t330 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  %t334 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %t313, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d38, i32 0, i32 1) }, { i64, ptr } %t331)
  store { i64, ptr } %t334, ptr %l122
  br label %bb49
bb49:
  %t335 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  call void @compiler_2fbuild_2esayln(ptr %s8, { i64, ptr } %t341)
  br label %bb50
bb50:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d39, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t344 = insertvalue { i32, { i64, ptr } } undef, i32 1, 0
  %t346 = insertvalue { i32, { i64, ptr } } %t344, { i64, ptr } %t343, 1
  store { i32, { i64, ptr } } %t346, ptr %l126
  %t347 = getelementptr { i32, { i64, ptr } }, ptr %l126, i32 0, i32 1
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  store { i64, ptr } %t348, ptr %l127, !tbaa !27
  %t349 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  store i64 %t350, ptr %l128, !tbaa !24
  %t351 = load i64, ptr %l128, !tbaa !24
  %t352 = mul i64 %t351, 1
  %t353 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t352)
  %t354 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  store { i64, ptr } %t355, ptr %l129, !tbaa !27
  %t356 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !27
  %t358 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = load i64, ptr %l128, !tbaa !24
  %t361 = mul i64 %t360, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t357, ptr %t359, i64 %t361, i1 false)
  %t362 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t363 = getelementptr { i32, { i64, ptr } }, ptr %l126, i32 0, i32 1
  store { i64, ptr } %t362, ptr %t363, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t364 = load { i32, { i64, ptr } }, ptr %l126
  store { i32, { i64, ptr } } %t364, ptr %rv
  br label %ret
bb51:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d40, i32 0, i32 1) })
  br label %bb52
bb52:
  %t365 = load ptr, ptr %lp7
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  %t367 = insertvalue { i32, { i64, ptr } } undef, i32 -1, 0
  %t369 = insertvalue { i32, { i64, ptr } } %t367, { i64, ptr } %t366, 1
  call void @__olang_scope_close(ptr %s0)
  store { i32, { i64, ptr } } %t369, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca %"compiler/build:Program"
  %l7 = alloca %"compiler/build:Listed"
  %l12 = alloca %"compiler/build:Program"
  %l13 = alloca %"compiler/build:Listed"
  %l20 = alloca %"compiler/build:Listed"
  %l21 = alloca i32
  %l25 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca %"compiler/listing:Inputs"
  %l40 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t12 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 18
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t4, i32 0, i32 19
  store { i64, ptr } %a3, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 29
  store i1 true, ptr %t11, !tbaa !21
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t12, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t12, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l12, i64 264, i1 false)
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i1, ptr %l4, !tbaa !21
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t24 = call { i32, %"compiler/build:Listed" } @compiler_2fbuild_2eListed_2eListingCode_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %v4, ptr %s0, ptr %a0, ptr %t14, { i64, ptr } %a2, i1 %t16, ptr %l6, ptr %t17)
  %t25 = extractvalue { i32, %"compiler/build:Listed" } %t24, 1
  %t26 = extractvalue { i32, %"compiler/build:Listed" } %t24, 0
  store i32 %t26, ptr %l21
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb3, label %ok.28, !prof !99
ok.28:
  store %"compiler/build:Listed" %t25, ptr %l20
  br label %bb2
bb2:
  %t29 = load %"compiler/build:Listed", ptr %l20
  store %"compiler/build:Listed" %t29, ptr %l13
  br label %bb11
bb3:
  %t30 = load i32, ptr %l21, !tbaa !23
  %t31 = icmp eq i32 %t30, 65536
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t33 = load i32, ptr %l21, !tbaa !23
  %t34 = icmp eq i32 %t33, 65537
  br i1 %t34, label %bb7, label %bb8
bb6:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t36)
  store i32 %t38, ptr %l25
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4ce37e8669e18741_b51ffe42b73135c5)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l25, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
bb11:
  %t41 = load %"compiler/build:Listed", ptr %l13
  store %"compiler/build:Listed" %t41, ptr %l7
  store ptr %l6, ptr %l27, !tbaa !29
  store ptr %l7, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = load i1, ptr %l4, !tbaa !21
  %t46 = call { i64, ptr } @compiler_2flisting_2ehow(ptr %v1, ptr %s0, ptr %t42, i1 %t43)
  store { i64, ptr } %t46, ptr %l31
  br label %bb12
bb12:
  %t47 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l32, !tbaa !27
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = load i1, ptr %l4, !tbaa !21
  %t58 = call { i64, ptr } @compiler_2flisting_2ecommentOf(ptr %v1, ptr %s0, ptr %t54, i1 %t55)
  store { i64, ptr } %t58, ptr %l35
  br label %bb13
bb13:
  %t59 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load i1, ptr %l4, !tbaa !21
  %t67 = load ptr, ptr %l27, !tbaa !29
  %t68 = load ptr, ptr %l28, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t72 = call %"compiler/listing:Inputs" @compiler_2flisting_3aInputs_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t67, ptr %t68, { i64, ptr } %t69, { i64, ptr } %t65, i1 %t66)
  store %"compiler/listing:Inputs" %t72, ptr %l38
  br label %bb14
bb14:
  %t74 = call { i64, ptr } @compiler_2flisting_2eRender(ptr %s0, ptr %s0, ptr %l38)
  store { i64, ptr } %t74, ptr %l40
  br label %bb15
bb15:
  %t75 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t76 = extractvalue { i64, ptr } %t75, 0
  %t77 = extractvalue { i64, ptr } %t75, 1
  %t78 = mul i64 %t76, 1
  %t79 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t78)
  call void @llvm.memcpy.p0.p0.i64(ptr %t79, ptr %t77, i64 %t78, i1 false)
  %t80 = insertvalue { i64, ptr } undef, i64 %t76, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t79, 1
  call void @compiler_2flisting_2esay(ptr %s0, { i64, ptr } %t81)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i32
  %l5 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2folang_2erunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb2
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2erunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/diag:Diagnostics"
  %l16 = alloca %"compiler/build:Config"
  %l18 = alloca %"compiler/olang:CommandLine"
  %l22 = alloca %"compiler/olang:CommandLine"
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca i32
  %l31 = alloca i1
  %l35 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i32
  %l54 = alloca i1
  %l58 = alloca { i64, ptr }
  %l60 = alloca i1
  %l62 = alloca i64
  %l64 = alloca { i64, ptr }
  %l66 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l75 = alloca { i64, ptr }
  %l77 = alloca i32
  %l81 = alloca i1
  %l83 = alloca i1
  %l85 = alloca ptr
  %l86 = alloca ptr
  %l88 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca i1
  %l93 = alloca i32
  %l98 = alloca i64
  %l100 = alloca ptr
  %l101 = alloca ptr
  %l103 = alloca { i64, ptr }
  %l106 = alloca i32
  %l107 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l111 = alloca i32
  %l113 = alloca i1
  %l115 = alloca i32
  %l117 = alloca i32
  %l122 = alloca i32
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i32
  %l130 = alloca i1
  %l133 = alloca { i64, ptr }
  %l137 = alloca i1
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l143 = alloca i32
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l152 = alloca i32
  %l157 = alloca { i64, ptr }
  %l161 = alloca i32
  %l166 = alloca { i64, ptr }
  %l168 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l172 = alloca i32
  %l177 = alloca i32
  %l181 = alloca ptr
  %l182 = alloca { i64, ptr }
  %l183 = alloca { i64, ptr }
  %l184 = alloca i32
  %l186 = alloca i1
  %l189 = alloca { i64, ptr }
  %l193 = alloca i32
  %l195 = alloca { i64, ptr }
  %l201 = alloca { i64, ptr }
  %l204 = alloca i32
  %l210 = alloca { i64, ptr }
  %l213 = alloca i32
  %l217 = alloca ptr
  %l218 = alloca ptr
  %l219 = alloca { i64, ptr }
  %l220 = alloca { i64, ptr }
  %l222 = alloca { i64, ptr }
  %l224 = alloca i32
  %l228 = alloca ptr
  %l229 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l231 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l235 = alloca i32
  %l241 = alloca i32
  %l245 = alloca i1
  %l247 = alloca { i64, ptr }
  %l248 = alloca { i64, ptr }
  %l249 = alloca i32
  %l251 = alloca i1
  %l254 = alloca { i64, ptr }
  %l259 = alloca i32
  %l264 = alloca { i64, ptr }
  %l266 = alloca i32
  %l271 = alloca { i64, ptr }
  %l275 = alloca i32
  %l279 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l281 = alloca { i64, ptr }
  %l286 = alloca i64
  %l288 = alloca i64
  %l293 = alloca { i64, ptr }
  %l298 = alloca ptr
  %l299 = alloca ptr
  %l300 = alloca { i64, ptr }
  %l301 = alloca { i64, ptr }
  %l303 = alloca { i64, ptr }
  %l305 = alloca i32
  %l309 = alloca i1
  %l311 = alloca ptr
  %l312 = alloca ptr
  %l313 = alloca { i64, ptr }
  %l314 = alloca { i64, ptr }
  %l315 = alloca ptr
  %l317 = alloca { i64, ptr }
  %l318 = alloca i32
  %l322 = alloca ptr
  %l323 = alloca ptr
  %l324 = alloca { i64, ptr }
  %l325 = alloca { i64, ptr }
  %l326 = alloca ptr
  %l328 = alloca { i64, ptr }
  %l329 = alloca i32
  %l330 = alloca { i64, ptr }
  %l331 = alloca { i64, ptr }
  %l332 = alloca i32
  %l334 = alloca i1
  %l337 = alloca { i64, ptr }
  %l341 = alloca ptr
  %l342 = alloca { i64, ptr }
  %l344 = alloca { i64, ptr }
  %l345 = alloca { i64, ptr }
  %l347 = alloca { i64, ptr }
  %l348 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s14 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  %t10 = alloca %"compiler/olang:CommandLine", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l14
  br label %bb1
bb1:
  %t3 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t2, i64 704, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l15, i64 704, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t4, i64 672, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 672, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 28
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %t10, ptr %v0, ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  store i32 %t14, ptr %l23
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t10, i64 248, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l22, i64 248, i1 false)
  br label %bb8
bb5:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t22 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t22, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l27, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l18, i64 248, i1 false)
  %t24 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb11
bb10:
  %t31 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t36 = icmp eq i64 %t32, %t33
  store i1 %t36, ptr %l31, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb14
bb13:
  %t39 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2folang_2eNotebook, !tbaa !24
  %t44 = icmp eq i64 %t40, %t41
  store i1 %t44, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l35, !tbaa !21
  %t47 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 25
  store i1 %t46, ptr %t47, !tbaa !21
  %t48 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t53 = icmp eq i64 %t49, %t50
  br i1 %t53, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t58 = extractvalue { i32, { i64, ptr } } %t57, 1
  %t59 = extractvalue { i32, { i64, ptr } } %t57, 0
  store i32 %t59, ptr %l46
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb18, label %ok.61, !prof !99
ok.61:
  store { i64, ptr } %t58, ptr %l45
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t62 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t62, ptr %l42, !tbaa !27
  br label %bb21
bb18:
  %t63 = load i32, ptr %l46, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t68 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t68, ptr %l50
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i32, ptr %l50, !tbaa !23
  store i32 %t69, ptr %rv
  br label %ret
bb21:
  %t70 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t73 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t70)
  store i32 %t73, ptr %l52
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load i32, ptr %l52, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb23:
  %t76 = call i1 @compiler_2folang_2ewaits(ptr %v0, ptr %l4)
  store i1 %t76, ptr %l54
  br label %bb24
bb24:
  %t77 = load i1, ptr %l54, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t83 = icmp eq i64 %t79, %t80
  br i1 %t83, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l58, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d42, i32 0, i32 1) }, ptr %l58, !tbaa !27
  br label %bb29
bb29:
  %t85 = load { i64, ptr }, ptr %l58, !tbaa !27
  call void @compiler_2fspin_2eBegin(ptr %s4, { i64, ptr } %t85)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  %t87 = call i1 @compiler_2folang_2eanalyzes(ptr %v0, ptr %l4)
  store i1 %t87, ptr %l60
  br label %bb32
bb32:
  %t88 = load i1, ptr %l60, !tbaa !21
  br i1 %t88, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s5
  %t89 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t91 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t89)
  store i64 %t91, ptr %l62
  br label %bb35
bb34:
  br label %bb41
bb35:
  %t92 = load i64, ptr %l62, !tbaa !24
  %t93 = icmp sgt i64 %t92, 0
  br i1 %t93, label %bb36, label %bb37
bb36:
  %t95 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t97 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %s5, ptr %t95, i64 0)
  store { i64, ptr } %t97, ptr %l66
  br label %bb38
bb37:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d43, i32 0, i32 1) }, ptr %l64, !tbaa !27
  br label %bb39
bb38:
  %t98 = load { i64, ptr }, ptr %l66, !tbaa !27
  store { i64, ptr } %t98, ptr %l64, !tbaa !27
  br label %bb39
bb39:
  %t99 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t100 = call { i64, ptr } @compiler_2fbuild_2eAnalysisDir(ptr %s5, ptr %s0, { i64, ptr } %t99)
  store { i64, ptr } %t100, ptr %l67
  br label %bb40
bb40:
  %t101 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t101, 0
  %t103 = extractvalue { i64, ptr } %t101, 1
  %t104 = mul i64 %t102, 1
  %t105 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t104)
  call void @llvm.memcpy.p0.p0.i64(ptr %t105, ptr %t103, i64 %t104, i1 false)
  %t106 = insertvalue { i64, ptr } undef, i64 %t102, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t105, 1
  %t109 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 0
  store { i64, ptr } %t107, ptr %t109, !tbaa !27
  call void @__olang_scope_close(ptr %s5)
  br label %bb41
bb41:
  %t110 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t111 = load i64, ptr %t110, !tbaa !24
  %t112 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t115 = icmp eq i64 %t111, %t112
  br i1 %t115, label %bb42, label %bb43
bb42:
  %t117 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 11
  %t118 = load i1, ptr %t117, !tbaa !21
  store i1 %t118, ptr %l72, !tbaa !21
  br label %bb44
bb43:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb44
bb44:
  %t120 = load i1, ptr %l72, !tbaa !21
  br i1 %t120, label %bb45, label %bb46
bb45:
  %t121 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t123 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t121, i64 0)
  store { i64, ptr } %t123, ptr %l75
  br label %bb47
bb46:
  br label %bb49
bb47:
  %t124 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t126 = call i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %s0, { i64, ptr } %t124, ptr %l3)
  store i32 %t126, ptr %l77
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s0)
  %t127 = load i32, ptr %l77, !tbaa !23
  store i32 %t127, ptr %rv
  br label %ret
bb49:
  %t128 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t129 = load i64, ptr %t128, !tbaa !24
  %t130 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t133 = icmp eq i64 %t129, %t130
  br i1 %t133, label %bb50, label %bb51
bb50:
  %t135 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t136 = load { i64, ptr }, ptr %t135, !tbaa !27
  %t138 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t136, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store i1 %t138, ptr %l83
  br label %bb52
bb51:
  store i1 false, ptr %l81, !tbaa !21
  br label %bb53
bb52:
  %t139 = load i1, ptr %l83, !tbaa !21
  %t140 = xor i1 %t139, true
  store i1 %t140, ptr %l81, !tbaa !21
  br label %bb53
bb53:
  %t142 = load i1, ptr %l81, !tbaa !21
  br i1 %t142, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s7
  %t143 = load ptr, ptr %l1, !tbaa !29
  store ptr %t143, ptr %l85, !tbaa !29
  store ptr %l3, ptr %l86, !tbaa !29
  %t144 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t146 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t144, i64 0)
  store { i64, ptr } %t146, ptr %l88
  br label %bb56
bb55:
  br label %bb59
bb56:
  %t147 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l89, !tbaa !27
  %t149 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t152 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s7, { i64, ptr } %t150, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d45, i32 0, i32 1) })
  store i1 %t152, ptr %l91
  br label %bb57
bb57:
  %t153 = load ptr, ptr %l85, !tbaa !29
  %t154 = load ptr, ptr %l86, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t156 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t157 = load i1, ptr %l91, !tbaa !21
  %t159 = call i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t153, ptr %t154, { i64, ptr } %t155, { i64, ptr } %t156, i1 %t157, ptr %l2)
  store i32 %t159, ptr %l93
  br label %bb58
bb58:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t160 = load i32, ptr %l93, !tbaa !23
  store i32 %t160, ptr %rv
  br label %ret
bb59:
  %t161 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t162 = load i64, ptr %t161, !tbaa !24
  %t163 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t166 = icmp eq i64 %t162, %t163
  br i1 %t166, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s8
  %t168 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t170 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t168)
  store i64 %t170, ptr %l98
  br label %bb62
bb61:
  br label %bb74
bb62:
  %t171 = load i64, ptr %l98, !tbaa !24
  %t172 = icmp eq i64 %t171, 1
  br i1 %t172, label %bb63, label %bb64
bb63:
  %t174 = load ptr, ptr %l1, !tbaa !29
  store ptr %t174, ptr %l100, !tbaa !29
  store ptr %l3, ptr %l101, !tbaa !29
  %t175 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t177 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t175, i64 0)
  store { i64, ptr } %t177, ptr %l103
  br label %bb65
bb64:
  br label %bb67
bb65:
  %t178 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t179 = load { i64, ptr }, ptr %t178, !tbaa !27
  %t180 = load ptr, ptr %l100, !tbaa !29
  %t181 = load ptr, ptr %l101, !tbaa !29
  %t182 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t185 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t180, ptr %t181, { i64, ptr } %t182, { i64, ptr } %t179, ptr %l2)
  store i32 %t185, ptr %l106
  br label %bb66
bb66:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t186 = load i32, ptr %l106, !tbaa !23
  store i32 %t186, ptr %rv
  br label %ret
bb67:
  %t187 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t188 = load { i64, ptr }, ptr %t187, !tbaa !27
  %t191 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %s0, ptr %s8, { i64, ptr } %t188, ptr %l2)
  %t192 = extractvalue { i32, { i64, ptr } } %t191, 1
  %t193 = extractvalue { i32, { i64, ptr } } %t191, 0
  store i32 %t193, ptr %l111
  %t194 = icmp ne i32 %t193, 0
  br i1 %t194, label %bb69, label %ok.195, !prof !99
ok.195:
  store { i64, ptr } %t192, ptr %l110
  br label %bb68
bb68:
  %t196 = load { i64, ptr }, ptr %l110, !tbaa !27
  store { i64, ptr } %t196, ptr %l107, !tbaa !27
  br label %bb72
bb69:
  %t197 = load i32, ptr %l111, !tbaa !23
  %t198 = ashr i32 %t197, 16
  %t200 = icmp eq i32 %t198, 1
  store i1 %t200, ptr %l113, !tbaa !21
  br label %bb70
bb70:
  %t202 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t202, ptr %l115
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t203 = load i32, ptr %l115, !tbaa !23
  store i32 %t203, ptr %rv
  br label %ret
bb72:
  %t204 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t207 = call i32 @compiler_2folang_2ewrite(ptr %s8, { i64, ptr } %t204)
  store i32 %t207, ptr %l117
  br label %bb73
bb73:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t208 = load i32, ptr %l117, !tbaa !23
  store i32 %t208, ptr %rv
  br label %ret
bb74:
  %t209 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  br i1 %t214, label %bb75, label %bb76
bb75:
  %t217 = call i32 @compiler_2folang_2eformat(ptr %v0, ptr %l4)
  store i32 %t217, ptr %l122
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t218 = load i32, ptr %l122, !tbaa !23
  store i32 %t218, ptr %rv
  br label %ret
bb78:
  %t219 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t220 = load i64, ptr %t219, !tbaa !24
  %t221 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t224 = icmp eq i64 %t220, %t221
  br i1 %t224, label %bb79, label %bb80
bb79:
  store %olang.scope zeroinitializer, ptr %s12
  %t226 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s12, ptr %s12, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d46, i32 0, i32 1) })
  %t227 = extractvalue { i32, { i64, ptr } } %t226, 1
  %t228 = extractvalue { i32, { i64, ptr } } %t226, 0
  store i32 %t228, ptr %l128
  %t229 = icmp ne i32 %t228, 0
  br i1 %t229, label %bb82, label %ok.230, !prof !99
ok.230:
  store { i64, ptr } %t227, ptr %l127
  br label %bb81
bb80:
  br label %bb90
bb81:
  %t231 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t231, ptr %l126, !tbaa !27
  br label %bb86
bb82:
  %t232 = load i32, ptr %l128, !tbaa !23
  %t233 = ashr i32 %t232, 16
  %t235 = icmp eq i32 %t233, 1
  store i1 %t235, ptr %l130, !tbaa !21
  %t236 = load i32, ptr %l128, !tbaa !23
  %t237 = ashr i32 %t236, 16
  %t239 = icmp eq i32 %t237, 1
  br i1 %t239, label %bb83, label %bb84
bb83:
  call void @__olang_errpay_pop()
  br label %bb84
bb84:
  br label %bb85
bb85:
  %t241 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t241, ptr %l133, !tbaa !27
  %t242 = getelementptr { i64, ptr }, ptr %l133, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %t243, i64 0
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !37
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = extractvalue { i64, ptr } %t245, 0
  %t249 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t247, i64 %t248)
  %t250 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  store { i64, ptr } %t258, ptr %l126, !tbaa !27
  br label %bb86
bb86:
  %t260 = load { i64, ptr }, ptr %l126, !tbaa !27
  store { i64, ptr } %t260, ptr %l7, !tbaa !27
  %t261 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t262 = load i1, ptr %t261, !tbaa !21
  store i1 %t262, ptr %l137, !tbaa !21
  %t263 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t265 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t263)
  store { i64, ptr } %t265, ptr %l139
  br label %bb87
bb87:
  %t266 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t266, ptr %l140, !tbaa !27
  %t267 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s12)
  store { i64, ptr } %t267, ptr %l141
  br label %bb88
bb88:
  %t268 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t269 = extractvalue { i64, ptr } %t268, 0
  %t270 = extractvalue { i64, ptr } %t268, 1
  %t271 = mul i64 %t269, 1
  %t272 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t271)
  call void @llvm.memcpy.p0.p0.i64(ptr %t272, ptr %t270, i64 %t271, i1 false)
  %t273 = insertvalue { i64, ptr } undef, i64 %t269, 0
  %t274 = insertvalue { i64, ptr } %t273, ptr %t272, 1
  %t275 = load i1, ptr %l137, !tbaa !21
  %t276 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t277 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t279 = call i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %s12, ptr %s12, i1 %t275, { i64, ptr } %t276, { i64, ptr } %t277, { i64, ptr } %t274)
  store i32 %t279, ptr %l143
  br label %bb89
bb89:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t280 = load i32, ptr %l143, !tbaa !23
  store i32 %t280, ptr %rv
  br label %ret
bb90:
  %t281 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t282 = load i64, ptr %t281, !tbaa !24
  %t283 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t286 = icmp eq i64 %t282, %t283
  br i1 %t286, label %bb91, label %bb92
bb91:
  store %olang.scope zeroinitializer, ptr %s14
  %t288 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t290 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t288, i64 0)
  store { i64, ptr } %t290, ptr %l148
  br label %bb93
bb92:
  br label %bb96
bb93:
  %t291 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  store { i64, ptr } %t292, ptr %l149, !tbaa !27
  %t293 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s14)
  store { i64, ptr } %t293, ptr %l150
  br label %bb94
bb94:
  %t294 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t295 = extractvalue { i64, ptr } %t294, 0
  %t296 = extractvalue { i64, ptr } %t294, 1
  %t297 = mul i64 %t295, 1
  %t298 = call ptr @__olang_scope_alloc(ptr %s14, i64 %t297)
  call void @llvm.memcpy.p0.p0.i64(ptr %t298, ptr %t296, i64 %t297, i1 false)
  %t299 = insertvalue { i64, ptr } undef, i64 %t295, 0
  %t300 = insertvalue { i64, ptr } %t299, ptr %t298, 1
  %t301 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t302 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t304 = call i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v0, ptr %s14, { i64, ptr } %t301, { i64, ptr } %t302, { i64, ptr } %t300)
  store i32 %t304, ptr %l152
  br label %bb95
bb95:
  call void @__olang_scope_close(ptr %s14)
  call void @__olang_scope_close(ptr %s0)
  %t305 = load i32, ptr %l152, !tbaa !23
  store i32 %t305, ptr %rv
  br label %ret
bb96:
  %t306 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t307 = load i64, ptr %t306, !tbaa !24
  %t308 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t311 = icmp eq i64 %t307, %t308
  br i1 %t311, label %bb97, label %bb98
bb97:
  %t313 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t315 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t313)
  store { i64, ptr } %t315, ptr %l157
  br label %bb99
bb98:
  br label %bb101
bb99:
  %t316 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !27
  %t318 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 10
  %t319 = load { i64, ptr }, ptr %t318, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l157, !tbaa !27
  %t324 = call i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t320, { i64, ptr } %t317, { i64, ptr } %t319, ptr %l3)
  store i32 %t324, ptr %l161
  br label %bb100
bb100:
  call void @__olang_scope_close(ptr %s0)
  %t325 = load i32, ptr %l161, !tbaa !23
  store i32 %t325, ptr %rv
  br label %ret
bb101:
  %t326 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t327 = load i64, ptr %t326, !tbaa !24
  %t328 = load i64, ptr @G_2ecompiler_2folang_2eApi, !tbaa !24
  %t331 = icmp eq i64 %t327, %t328
  br i1 %t331, label %bb102, label %bb103
bb102:
  %t333 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t335 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t333, i64 0)
  store { i64, ptr } %t335, ptr %l166
  br label %bb104
bb103:
  br label %bb108
bb104:
  %t336 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t338 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t336, i64 1)
  store { i64, ptr } %t338, ptr %l168
  br label %bb105
bb105:
  %t339 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t341 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t339, i64 2)
  store { i64, ptr } %t341, ptr %l170
  br label %bb106
bb106:
  %t342 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l168, !tbaa !27
  %t344 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t346 = call i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t342, { i64, ptr } %t343, { i64, ptr } %t344, ptr %l3)
  store i32 %t346, ptr %l172
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  %t347 = load i32, ptr %l172, !tbaa !23
  store i32 %t347, ptr %rv
  br label %ret
bb108:
  %t348 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t349 = load i64, ptr %t348, !tbaa !24
  %t350 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t353 = icmp eq i64 %t349, %t350
  br i1 %t353, label %bb109, label %bb110
bb109:
  %t356 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t356, ptr %l177
  br label %bb111
bb110:
  br label %bb112
bb111:
  call void @__olang_scope_close(ptr %s0)
  %t357 = load i32, ptr %l177, !tbaa !23
  store i32 %t357, ptr %rv
  br label %ret
bb112:
  %t358 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t359 = load i64, ptr %t358, !tbaa !24
  %t360 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t363 = icmp eq i64 %t359, %t360
  br i1 %t363, label %bb113, label %bb114
bb113:
  store %olang.scope zeroinitializer, ptr %s18
  store ptr %l3, ptr %l181, !tbaa !29
  %t365 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s18, ptr %s18, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d47, i32 0, i32 1) })
  %t366 = extractvalue { i32, { i64, ptr } } %t365, 1
  %t367 = extractvalue { i32, { i64, ptr } } %t365, 0
  store i32 %t367, ptr %l184
  %t368 = icmp ne i32 %t367, 0
  br i1 %t368, label %bb116, label %ok.369, !prof !99
ok.369:
  store { i64, ptr } %t366, ptr %l183
  br label %bb115
bb114:
  br label %bb122
bb115:
  %t370 = load { i64, ptr }, ptr %l183, !tbaa !27
  store { i64, ptr } %t370, ptr %l182, !tbaa !27
  br label %bb120
bb116:
  %t371 = load i32, ptr %l184, !tbaa !23
  %t372 = ashr i32 %t371, 16
  %t374 = icmp eq i32 %t372, 1
  store i1 %t374, ptr %l186, !tbaa !21
  %t375 = load i32, ptr %l184, !tbaa !23
  %t376 = ashr i32 %t375, 16
  %t378 = icmp eq i32 %t376, 1
  br i1 %t378, label %bb117, label %bb118
bb117:
  call void @__olang_errpay_pop()
  br label %bb118
bb118:
  br label %bb119
bb119:
  %t380 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t380, ptr %l189, !tbaa !27
  %t381 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t382 = load ptr, ptr %t381, !tbaa !27
  %t383 = getelementptr { i64, ptr }, ptr %t382, i64 0
  %t384 = load { i64, ptr }, ptr %t383, !tbaa !37
  %t386 = extractvalue { i64, ptr } %t384, 1
  %t387 = extractvalue { i64, ptr } %t384, 0
  %t388 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t387)
  call void @olang_textcopy(ptr %t388, ptr %t386, i64 %t387)
  %t389 = insertvalue { i64, ptr } undef, i64 %t387, 0
  %t390 = insertvalue { i64, ptr } %t389, ptr %t388, 1
  %t392 = extractvalue { i64, ptr } %t390, 0
  %t393 = extractvalue { i64, ptr } %t390, 1
  %t394 = mul i64 %t392, 1
  %t395 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t394)
  call void @llvm.memcpy.p0.p0.i64(ptr %t395, ptr %t393, i64 %t394, i1 false)
  %t396 = insertvalue { i64, ptr } undef, i64 %t392, 0
  %t397 = insertvalue { i64, ptr } %t396, ptr %t395, 1
  store { i64, ptr } %t397, ptr %l182, !tbaa !27
  br label %bb120
bb120:
  %t399 = load ptr, ptr %l181, !tbaa !29
  %t400 = load { i64, ptr }, ptr %l182, !tbaa !27
  %t401 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s18, ptr %t399, { i64, ptr } %t400)
  store i32 %t401, ptr %l193
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t402 = load i32, ptr %l193, !tbaa !23
  store i32 %t402, ptr %rv
  br label %ret
bb122:
  %t403 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t405 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t403)
  store { i64, ptr } %t405, ptr %l195
  br label %bb123
bb123:
  %t406 = load { i64, ptr }, ptr %l195, !tbaa !27
  store { i64, ptr } %t406, ptr %l8, !tbaa !27
  %t407 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t408 = load i64, ptr %t407, !tbaa !24
  %t409 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t412 = icmp eq i64 %t408, %t409
  br i1 %t412, label %bb124, label %bb125
bb124:
  %t414 = load ptr, ptr %l1, !tbaa !29
  %t415 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t415, ptr %l201, !tbaa !27
  %t416 = getelementptr { i64, ptr }, ptr %l201, i32 0, i32 1
  %t417 = load ptr, ptr %t416, !tbaa !27
  %t418 = getelementptr { i64, ptr }, ptr %t417, i64 0
  %t419 = load { i64, ptr }, ptr %t418, !tbaa !37
  %t424 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %t414, ptr %l3, { i64, ptr } %t419, ptr %l2)
  store i32 %t424, ptr %l204
  br label %bb126
bb125:
  br label %bb127
bb126:
  call void @__olang_scope_close(ptr %s0)
  %t425 = load i32, ptr %l204, !tbaa !23
  store i32 %t425, ptr %rv
  br label %ret
bb127:
  %t426 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t427 = load i64, ptr %t426, !tbaa !24
  %t428 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t431 = icmp eq i64 %t427, %t428
  br i1 %t431, label %bb128, label %bb129
bb128:
  %t433 = load ptr, ptr %l1, !tbaa !29
  %t434 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t434, ptr %l210, !tbaa !27
  %t435 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t436 = load ptr, ptr %t435, !tbaa !27
  %t437 = getelementptr { i64, ptr }, ptr %t436, i64 0
  %t438 = load { i64, ptr }, ptr %t437, !tbaa !37
  %t443 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %t433, ptr %l3, { i64, ptr } %t438, ptr %l2)
  store i32 %t443, ptr %l213
  br label %bb130
bb129:
  br label %bb131
bb130:
  call void @__olang_scope_close(ptr %s0)
  %t444 = load i32, ptr %l213, !tbaa !23
  store i32 %t444, ptr %rv
  br label %ret
bb131:
  %t445 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t446 = load i64, ptr %t445, !tbaa !24
  %t447 = load i64, ptr @G_2ecompiler_2folang_2eRunBuilt, !tbaa !24
  %t450 = icmp eq i64 %t446, %t447
  br i1 %t450, label %bb132, label %bb133
bb132:
  %t452 = load ptr, ptr %l1, !tbaa !29
  store ptr %t452, ptr %l217, !tbaa !29
  store ptr %l3, ptr %l218, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t453, ptr %l219, !tbaa !27
  %t454 = getelementptr { i64, ptr }, ptr %l219, i32 0, i32 1
  %t455 = load ptr, ptr %t454, !tbaa !27
  %t456 = getelementptr { i64, ptr }, ptr %t455, i64 0
  %t457 = load { i64, ptr }, ptr %t456, !tbaa !37
  store { i64, ptr } %t457, ptr %l220, !tbaa !27
  %t458 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t460 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t458)
  store { i64, ptr } %t460, ptr %l222
  br label %bb134
bb133:
  br label %bb136
bb134:
  %t461 = load ptr, ptr %l217, !tbaa !29
  %t462 = load ptr, ptr %l218, !tbaa !29
  %t463 = load { i64, ptr }, ptr %l220, !tbaa !27
  %t464 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t466 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t461, ptr %t462, { i64, ptr } %t463, { i64, ptr } %t464, ptr %l2)
  store i32 %t466, ptr %l224
  br label %bb135
bb135:
  call void @__olang_scope_close(ptr %s0)
  %t467 = load i32, ptr %l224, !tbaa !23
  store i32 %t467, ptr %rv
  br label %ret
bb136:
  %t468 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t469 = load i64, ptr %t468, !tbaa !24
  %t470 = load i64, ptr @G_2ecompiler_2folang_2eProfile, !tbaa !24
  %t473 = icmp eq i64 %t469, %t470
  br i1 %t473, label %bb137, label %bb138
bb137:
  %t475 = load ptr, ptr %l1, !tbaa !29
  store ptr %t475, ptr %l228, !tbaa !29
  store ptr %l3, ptr %l229, !tbaa !29
  %t476 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t476, ptr %l230, !tbaa !27
  %t477 = getelementptr { i64, ptr }, ptr %l230, i32 0, i32 1
  %t478 = load ptr, ptr %t477, !tbaa !27
  %t479 = getelementptr { i64, ptr }, ptr %t478, i64 0
  %t480 = load { i64, ptr }, ptr %t479, !tbaa !37
  store { i64, ptr } %t480, ptr %l231, !tbaa !27
  %t481 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t483 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t481)
  store { i64, ptr } %t483, ptr %l233
  br label %bb139
bb138:
  br label %bb141
bb139:
  %t484 = load ptr, ptr %l228, !tbaa !29
  %t485 = load ptr, ptr %l229, !tbaa !29
  %t486 = load { i64, ptr }, ptr %l231, !tbaa !27
  %t487 = load { i64, ptr }, ptr %l233, !tbaa !27
  %t489 = call i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t484, ptr %t485, { i64, ptr } %t486, { i64, ptr } %t487, ptr %l2)
  store i32 %t489, ptr %l235
  br label %bb140
bb140:
  call void @__olang_scope_close(ptr %s0)
  %t490 = load i32, ptr %l235, !tbaa !23
  store i32 %t490, ptr %rv
  br label %ret
bb141:
  %t491 = insertvalue { ptr, ptr } undef, ptr @compiler_2folang_2ebuildCell_fv_fn_28std_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_2c_20Array_3_H1276486710fe3f33d55b88d9cfddba68, 0
  %t492 = insertvalue { ptr, ptr } %t491, ptr null, 1
  store { ptr, ptr } %t492, ptr @G_2ecompiler_2fcells_2eBuilder
  %t496 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 13
  %t497 = load i1, ptr %t496, !tbaa !21
  br i1 %t497, label %bb142, label %bb143
bb142:
  %t500 = call i32 @compiler_2fprompt_2eRun(ptr %s0, ptr %l3)
  store i32 %t500, ptr %l241
  br label %bb144
bb143:
  br label %bb145
bb144:
  call void @__olang_scope_close(ptr %s0)
  %t501 = load i32, ptr %l241, !tbaa !23
  store i32 %t501, ptr %rv
  br label %ret
bb145:
  %t502 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t503 = load i64, ptr %t502, !tbaa !24
  %t504 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t507 = icmp eq i64 %t503, %t504
  br i1 %t507, label %bb146, label %bb147
bb146:
  %t509 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 14
  %t510 = load i1, ptr %t509, !tbaa !21
  store i1 %t510, ptr %l245, !tbaa !21
  br label %bb148
bb147:
  store i1 false, ptr %l245, !tbaa !21
  br label %bb148
bb148:
  %t512 = load i1, ptr %l245, !tbaa !21
  br i1 %t512, label %bb149, label %bb150
bb149:
  store %olang.scope zeroinitializer, ptr %s25
  %t513 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s25, ptr %s25, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d48, i32 0, i32 1) })
  %t514 = extractvalue { i32, { i64, ptr } } %t513, 1
  %t515 = extractvalue { i32, { i64, ptr } } %t513, 0
  store i32 %t515, ptr %l249
  %t516 = icmp ne i32 %t515, 0
  br i1 %t516, label %bb152, label %ok.517, !prof !99
ok.517:
  store { i64, ptr } %t514, ptr %l248
  br label %bb151
bb150:
  br label %bb158
bb151:
  %t518 = load { i64, ptr }, ptr %l248, !tbaa !27
  store { i64, ptr } %t518, ptr %l247, !tbaa !27
  br label %bb156
bb152:
  %t519 = load i32, ptr %l249, !tbaa !23
  %t520 = ashr i32 %t519, 16
  %t522 = icmp eq i32 %t520, 1
  store i1 %t522, ptr %l251, !tbaa !21
  %t523 = load i32, ptr %l249, !tbaa !23
  %t524 = ashr i32 %t523, 16
  %t526 = icmp eq i32 %t524, 1
  br i1 %t526, label %bb153, label %bb154
bb153:
  call void @__olang_errpay_pop()
  br label %bb154
bb154:
  br label %bb155
bb155:
  %t528 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t528, ptr %l254, !tbaa !27
  %t529 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t530 = load ptr, ptr %t529, !tbaa !27
  %t531 = getelementptr { i64, ptr }, ptr %t530, i64 0
  %t532 = load { i64, ptr }, ptr %t531, !tbaa !37
  %t534 = extractvalue { i64, ptr } %t532, 1
  %t535 = extractvalue { i64, ptr } %t532, 0
  %t536 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t535)
  call void @olang_textcopy(ptr %t536, ptr %t534, i64 %t535)
  %t537 = insertvalue { i64, ptr } undef, i64 %t535, 0
  %t538 = insertvalue { i64, ptr } %t537, ptr %t536, 1
  %t540 = extractvalue { i64, ptr } %t538, 0
  %t541 = extractvalue { i64, ptr } %t538, 1
  %t542 = mul i64 %t540, 1
  %t543 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t542)
  call void @llvm.memcpy.p0.p0.i64(ptr %t543, ptr %t541, i64 %t542, i1 false)
  %t544 = insertvalue { i64, ptr } undef, i64 %t540, 0
  %t545 = insertvalue { i64, ptr } %t544, ptr %t543, 1
  store { i64, ptr } %t545, ptr %l247, !tbaa !27
  br label %bb156
bb156:
  %t547 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t549 = call i32 @compiler_2fjupyter_2eInstall(ptr %s25, ptr %s0, { i64, ptr } %t547, ptr %l3)
  store i32 %t549, ptr %l259
  br label %bb157
bb157:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  %t550 = load i32, ptr %l259, !tbaa !23
  store i32 %t550, ptr %rv
  br label %ret
bb158:
  %t551 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t552 = load i64, ptr %t551, !tbaa !24
  %t553 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t556 = icmp eq i64 %t552, %t553
  br i1 %t556, label %bb159, label %bb160
bb159:
  %t558 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t558, ptr %l264, !tbaa !27
  %t559 = getelementptr { i64, ptr }, ptr %l264, i32 0, i32 1
  %t560 = load ptr, ptr %t559, !tbaa !27
  %t561 = getelementptr { i64, ptr }, ptr %t560, i64 0
  %t562 = load { i64, ptr }, ptr %t561, !tbaa !37
  %t565 = call i32 @compiler_2fjupyter_2eServe(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t562)
  store i32 %t565, ptr %l266
  br label %bb161
bb160:
  br label %bb162
bb161:
  call void @__olang_scope_close(ptr %s0)
  %t566 = load i32, ptr %l266, !tbaa !23
  store i32 %t566, ptr %rv
  br label %ret
bb162:
  %t567 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t568 = load i64, ptr %t567, !tbaa !24
  %t569 = load i64, ptr @G_2ecompiler_2folang_2eNotebook, !tbaa !24
  %t572 = icmp eq i64 %t568, %t569
  br i1 %t572, label %bb163, label %bb164
bb163:
  %t574 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t574, ptr %l271, !tbaa !27
  %t575 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t576 = load ptr, ptr %t575, !tbaa !27
  %t577 = getelementptr { i64, ptr }, ptr %t576, i64 1
  %t578 = load { i64, ptr }, ptr %t577, !tbaa !37
  %t579 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t580 = load { i64, ptr }, ptr %t579, !tbaa !27
  %t581 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 15
  %t582 = load i1, ptr %t581, !tbaa !21
  %t587 = call i32 @compiler_2fnotebook_2eRun(ptr %s0, ptr %v0, ptr %v0, ptr %l3, { i64, ptr } %t578, { i64, ptr } %t580, i1 %t582)
  store i32 %t587, ptr %l275
  br label %bb165
bb164:
  br label %bb166
bb165:
  call void @__olang_scope_close(ptr %s0)
  %t588 = load i32, ptr %l275, !tbaa !23
  store i32 %t588, ptr %rv
  br label %ret
bb166:
  %t589 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t590 = load i64, ptr %t589, !tbaa !24
  %t591 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t594 = icmp eq i64 %t590, %t591
  br i1 %t594, label %bb167, label %bb168
bb167:
  %t596 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t596, ptr %l279
  br label %bb169
bb168:
  br label %bb182
bb169:
  %t597 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store ptr %t597, ptr %lp9
  %t598 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l279
  %t599 = load ptr, ptr %lp9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t598, ptr %t599
  %t600 = load ptr, ptr %lp9
  %t601 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t601, ptr %l281, !tbaa !27
  %t602 = getelementptr { i64, ptr }, ptr %l281, i32 0, i32 1
  %t603 = load ptr, ptr %t602, !tbaa !27
  %t604 = getelementptr { i64, ptr }, ptr %t603, i64 0
  %t605 = load { i64, ptr }, ptr %t604, !tbaa !37
  %t607 = extractvalue { i64, ptr } %t605, 1
  %t608 = extractvalue { i64, ptr } %t605, 0
  %t609 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t608)
  call void @olang_textcopy(ptr %t609, ptr %t607, i64 %t608)
  %t610 = insertvalue { i64, ptr } undef, i64 %t608, 0
  %t611 = insertvalue { i64, ptr } %t610, ptr %t609, 1
  %t613 = extractvalue { i64, ptr } %t611, 0
  %t614 = extractvalue { i64, ptr } %t611, 1
  %t615 = mul i64 %t613, 1
  %t616 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t615)
  call void @llvm.memcpy.p0.p0.i64(ptr %t616, ptr %t614, i64 %t615, i1 false)
  %t617 = insertvalue { i64, ptr } undef, i64 %t613, 0
  %t618 = insertvalue { i64, ptr } %t617, ptr %t616, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t600, { i64, ptr } %t618)
  br label %bb170
bb170:
  %t621 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  store ptr %t621, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb171
bb171:
  %t623 = load i64, ptr %l11, !tbaa !24
  store i64 %t623, ptr %l286, !tbaa !24
  %t624 = load ptr, ptr %l10, !tbaa !29
  %t626 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t624)
  store i64 %t626, ptr %l288
  br label %bb172
bb172:
  %t627 = load i64, ptr %l286, !tbaa !24
  %t628 = load i64, ptr %l288, !tbaa !24
  %t629 = icmp slt i64 %t627, %t628
  %t631 = xor i1 %t629, true
  br i1 %t631, label %bb173, label %bb174
bb173:
  br label %bb179
bb174:
  br label %bb175
bb175:
  %t633 = load ptr, ptr %l10, !tbaa !29
  %t634 = load i64, ptr %l11, !tbaa !24
  %t637 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t633, i64 %t634)
  store { i64, ptr } %t637, ptr %l293
  br label %bb176
bb176:
  %t638 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t639 = load ptr, ptr %lp9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %v0, ptr %t639, { i64, ptr } %t638)
  br label %bb177
bb177:
  br label %bb178
bb178:
  %t643 = load i64, ptr %l11, !tbaa !24
  %t645 = add i64 %t643, 1
  store i64 %t645, ptr %l11, !tbaa !24
  br label %bb171
bb179:
  %t647 = load ptr, ptr %l1, !tbaa !29
  store ptr %t647, ptr %l298, !tbaa !29
  store ptr %l3, ptr %l299, !tbaa !29
  %t648 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t648, ptr %l300, !tbaa !27
  %t649 = getelementptr { i64, ptr }, ptr %l300, i32 0, i32 1
  %t650 = load ptr, ptr %t649, !tbaa !27
  %t651 = getelementptr { i64, ptr }, ptr %t650, i64 0
  %t652 = load { i64, ptr }, ptr %t651, !tbaa !37
  store { i64, ptr } %t652, ptr %l301, !tbaa !27
  %t653 = load ptr, ptr %lp9
  %t655 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t653)
  store { i64, ptr } %t655, ptr %l303
  br label %bb180
bb180:
  %t656 = load ptr, ptr %l298, !tbaa !29
  %t657 = load ptr, ptr %l299, !tbaa !29
  %t658 = load { i64, ptr }, ptr %l301, !tbaa !27
  %t659 = load { i64, ptr }, ptr %l303, !tbaa !27
  %t661 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %s0, ptr %t656, ptr %t657, { i64, ptr } %t658, { i64, ptr } %t659, ptr %l2)
  store i32 %t661, ptr %l305
  br label %bb181
bb181:
  call void @__olang_scope_close(ptr %s0)
  %t662 = load i32, ptr %l305, !tbaa !23
  store i32 %t662, ptr %rv
  br label %ret
bb182:
  %t663 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t665 = extractvalue { i64, ptr } %t663, 0
  %t667 = icmp eq i64 %t665, 1
  br i1 %t667, label %bb183, label %bb184
bb183:
  %t669 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 23
  %t670 = load i1, ptr %t669, !tbaa !21
  store i1 %t670, ptr %l309, !tbaa !21
  br label %bb185
bb184:
  store i1 false, ptr %l309, !tbaa !21
  br label %bb185
bb185:
  %t672 = load i1, ptr %l309, !tbaa !21
  br i1 %t672, label %bb186, label %bb187
bb186:
  %t673 = load ptr, ptr %l1, !tbaa !29
  store ptr %t673, ptr %l311, !tbaa !29
  store ptr %l3, ptr %l312, !tbaa !29
  %t674 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t674, ptr %l313, !tbaa !27
  %t675 = getelementptr { i64, ptr }, ptr %l313, i32 0, i32 1
  %t676 = load ptr, ptr %t675, !tbaa !27
  %t677 = getelementptr { i64, ptr }, ptr %t676, i64 0
  %t678 = load { i64, ptr }, ptr %t677, !tbaa !37
  store { i64, ptr } %t678, ptr %l314, !tbaa !27
  store ptr %l2, ptr %l315, !tbaa !29
  %t679 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t681 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t679)
  store { i64, ptr } %t681, ptr %l317
  br label %bb188
bb187:
  br label %bb190
bb188:
  %t682 = load ptr, ptr %l311, !tbaa !29
  %t683 = load ptr, ptr %l312, !tbaa !29
  %t684 = load { i64, ptr }, ptr %l314, !tbaa !27
  %t685 = load ptr, ptr %l315, !tbaa !29
  %t686 = load { i64, ptr }, ptr %l317, !tbaa !27
  %t687 = call i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %t682, ptr %t683, { i64, ptr } %t684, ptr %t685, { i64, ptr } %t686)
  store i32 %t687, ptr %l318
  br label %bb189
bb189:
  call void @__olang_scope_close(ptr %s0)
  %t688 = load i32, ptr %l318, !tbaa !23
  store i32 %t688, ptr %rv
  br label %ret
bb190:
  %t689 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t691 = extractvalue { i64, ptr } %t689, 0
  %t693 = icmp eq i64 %t691, 1
  br i1 %t693, label %bb191, label %bb192
bb191:
  %t695 = load ptr, ptr %l1, !tbaa !29
  store ptr %t695, ptr %l322, !tbaa !29
  store ptr %l3, ptr %l323, !tbaa !29
  %t696 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t696, ptr %l324, !tbaa !27
  %t697 = getelementptr { i64, ptr }, ptr %l324, i32 0, i32 1
  %t698 = load ptr, ptr %t697, !tbaa !27
  %t699 = getelementptr { i64, ptr }, ptr %t698, i64 0
  %t700 = load { i64, ptr }, ptr %t699, !tbaa !37
  store { i64, ptr } %t700, ptr %l325, !tbaa !27
  store ptr %l2, ptr %l326, !tbaa !29
  %t701 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t703 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t701)
  store { i64, ptr } %t703, ptr %l328
  br label %bb193
bb192:
  br label %bb195
bb193:
  %t704 = load ptr, ptr %l322, !tbaa !29
  %t705 = load ptr, ptr %l323, !tbaa !29
  %t706 = load { i64, ptr }, ptr %l325, !tbaa !27
  %t707 = load ptr, ptr %l326, !tbaa !29
  %t708 = load { i64, ptr }, ptr %l328, !tbaa !27
  %t709 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %t704, ptr %t705, { i64, ptr } %t706, ptr %t707, { i64, ptr } %t708)
  store i32 %t709, ptr %l329
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s0)
  %t710 = load i32, ptr %l329, !tbaa !23
  store i32 %t710, ptr %rv
  br label %ret
bb195:
  %t711 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d49, i32 0, i32 1) })
  %t712 = extractvalue { i32, { i64, ptr } } %t711, 1
  %t713 = extractvalue { i32, { i64, ptr } } %t711, 0
  store i32 %t713, ptr %l332
  %t714 = icmp ne i32 %t713, 0
  br i1 %t714, label %bb197, label %ok.715, !prof !99
ok.715:
  store { i64, ptr } %t712, ptr %l331
  br label %bb196
bb196:
  %t716 = load { i64, ptr }, ptr %l331, !tbaa !27
  store { i64, ptr } %t716, ptr %l330, !tbaa !27
  br label %bb201
bb197:
  %t717 = load i32, ptr %l332, !tbaa !23
  %t718 = ashr i32 %t717, 16
  %t720 = icmp eq i32 %t718, 1
  store i1 %t720, ptr %l334, !tbaa !21
  %t721 = load i32, ptr %l332, !tbaa !23
  %t722 = ashr i32 %t721, 16
  %t724 = icmp eq i32 %t722, 1
  br i1 %t724, label %bb198, label %bb199
bb198:
  call void @__olang_errpay_pop()
  br label %bb199
bb199:
  br label %bb200
bb200:
  %t726 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t726, ptr %l337, !tbaa !27
  %t727 = getelementptr { i64, ptr }, ptr %l337, i32 0, i32 1
  %t728 = load ptr, ptr %t727, !tbaa !27
  %t729 = getelementptr { i64, ptr }, ptr %t728, i64 0
  %t730 = load { i64, ptr }, ptr %t729, !tbaa !37
  %t732 = extractvalue { i64, ptr } %t730, 1
  %t733 = extractvalue { i64, ptr } %t730, 0
  %t734 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t733)
  call void @olang_textcopy(ptr %t734, ptr %t732, i64 %t733)
  %t735 = insertvalue { i64, ptr } undef, i64 %t733, 0
  %t736 = insertvalue { i64, ptr } %t735, ptr %t734, 1
  %t738 = extractvalue { i64, ptr } %t736, 0
  %t739 = extractvalue { i64, ptr } %t736, 1
  %t740 = mul i64 %t738, 1
  %t741 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t740)
  call void @llvm.memcpy.p0.p0.i64(ptr %t741, ptr %t739, i64 %t740, i1 false)
  %t742 = insertvalue { i64, ptr } undef, i64 %t738, 0
  %t743 = insertvalue { i64, ptr } %t742, ptr %t741, 1
  store { i64, ptr } %t743, ptr %l330, !tbaa !27
  br label %bb201
bb201:
  %t745 = load { i64, ptr }, ptr %l330, !tbaa !27
  store ptr %l3, ptr %l341, !tbaa !29
  store { i64, ptr } %t745, ptr %l342, !tbaa !27
  %t747 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 6
  %t749 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t747)
  store { i64, ptr } %t749, ptr %l344
  br label %bb202
bb202:
  %t750 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t750, ptr %l345, !tbaa !27
  %t751 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t753 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t751)
  store { i64, ptr } %t753, ptr %l347
  br label %bb203
bb203:
  %t754 = load ptr, ptr %l341, !tbaa !29
  %t755 = load { i64, ptr }, ptr %l342, !tbaa !27
  %t756 = load { i64, ptr }, ptr %l344, !tbaa !27
  %t757 = load { i64, ptr }, ptr %l345, !tbaa !27
  %t758 = load { i64, ptr }, ptr %l347, !tbaa !27
  %t759 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %v0, ptr %v0, ptr %v0, ptr %t754, { i64, ptr } %t755, { i64, ptr } %t756, { i64, ptr } %t757, { i64, ptr } %t758)
  store i32 %t759, ptr %l348
  br label %bb204
bb204:
  call void @__olang_scope_close(ptr %s0)
  %t760 = load i32, ptr %l348, !tbaa !23
  store i32 %t760, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca %"compiler/profile:Profile"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/profile:Places"
  %l25 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca { i64, [3 x i64] }
  %l43 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l66 = alloca i1
  %l71 = alloca i32
  %l73 = alloca i1
  %l81 = alloca i32
  %l84 = alloca ptr
  %l85 = alloca { i64, [3 x i64] }
  %l86 = alloca %"compiler/diagmsg:Msg"
  %l88 = alloca i32
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l92 = alloca i32
  %l94 = alloca i1
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l104 = alloca %"compiler/profile:Profile"
  %l107 = alloca %"compiler/profile:Profile"
  %l108 = alloca i32
  %l110 = alloca i1
  %l115 = alloca { i64, ptr }
  %l118 = alloca %"compiler/profile:Places"
  %l122 = alloca { i64, ptr }
  %l125 = alloca i1
  %l126 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l133 = alloca i32
  %l135 = alloca i1
  %l143 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t67 = alloca { i64, [3 x i64] }, align 8
  %t222 = alloca { i64, [3 x i64] }, align 8
  %t332 = alloca %"compiler/profile:Places", align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 30
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 30
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) }, ptr %t14, !tbaa !27
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 29
  store i1 true, ptr %t17, !tbaa !21
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/build:Config", ptr %t18, i32 0, i32 14
  store i1 true, ptr %t20, !tbaa !21
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t29 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t22, { i64, ptr } %t23, ptr %t24)
  store i32 %t29, ptr %l25
  br label %bb1
bb1:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb2
bb2:
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t35, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/build:Config", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t52)
  store i32 %t54, ptr %l33
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb7, label %ok.56, !prof !99
ok.56:
  br label %bb6
bb6:
  br label %bb14
bb7:
  %t57 = load i32, ptr %l33, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l35, !tbaa !21
  %t61 = load i32, ptr %l33, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  store %olang.scope zeroinitializer, ptr %s4
  %t66 = load ptr, ptr %l4, !tbaa !29
  store ptr %t66, ptr %l38, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [3 x i64] }, ptr %t67, i32 0, i32 0
  store i64 0, ptr %t68
  %t69 = load { i64, [3 x i64] }, ptr %t67
  store { i64, [3 x i64] } %t69, ptr %l39
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t71 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t74 = extractvalue { i64, ptr } %t70, 1
  %t75 = extractvalue { i64, ptr } %t70, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t74, i64 %t75)
  %t82 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t80, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s4, ptr %v4, { i64, ptr } %t91)
  store %"compiler/diagmsg:Msg" %t93, ptr %l43
  br label %bb11
bb11:
  %t94 = load ptr, ptr %l38, !tbaa !29
  %t95 = load { i64, [3 x i64] }, ptr %l39
  %t96 = load %"compiler/diagmsg:Msg", ptr %l43
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t94, { i64, [3 x i64] } %t95, %"compiler/diagmsg:Msg" %t96)
  br label %bb12
bb12:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t99 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t97)
  store i32 %t99, ptr %l45
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i32, ptr %l45, !tbaa !23
  store i32 %t100, ptr %rv
  br label %ret
bb14:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/build:Config", ptr %t101, i32 0, i32 31
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %v1, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l48
  br label %bb15
bb15:
  %t107 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t107, ptr %l8, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t110 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t108, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d54, i32 0, i32 1) })
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l52
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb17, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l51
  br label %bb16
bb16:
  %t115 = load i64, ptr %l51, !tbaa !24
  store i64 %t115, ptr %l49, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l49, !tbaa !24
  br label %bb19
bb19:
  %t120 = load i64, ptr %l49, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t121, ptr %l55, !tbaa !27
  store i64 %t120, ptr %l56, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l57, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t127 = load i64, ptr %l56, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb22:
  %t130 = load i64, ptr %l56, !tbaa !24
  %t131 = load i64, ptr %l57, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb24:
  %t134 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l56, !tbaa !24
  %t137 = getelementptr i8, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l8, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = extractvalue { i64, ptr } %t142, 0
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t151 = extractvalue { i64, ptr } %t143, 1
  %t152 = extractvalue { i64, ptr } %t143, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t145, i64 %t146)
  %t158 = getelementptr i8, ptr %t157, i64 %t146
  call void @olang_textcopy(ptr %t158, ptr %t147, i64 %t148)
  %t159 = getelementptr i8, ptr %t158, i64 %t148
  call void @olang_textcopy(ptr %t159, ptr %t151, i64 %t152)
  %t160 = getelementptr i8, ptr %t159, i64 %t152
  call void @olang_textcopy(ptr %t160, ptr %t154, i64 %t155)
  %t161 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t157, 1
  store { i64, ptr } %t162, ptr %l10, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t164, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d57, i32 0, i32 1) })
  store i1 %t166, ptr %l66
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb26:
  %t167 = load i1, ptr %l66, !tbaa !21
  br i1 %t167, label %bb27, label %bb28
bb27:
  %t168 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = extractvalue { i64, ptr } %t168, 0
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d58, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t177 = extractvalue { i64, ptr } %t169, 1
  %t178 = extractvalue { i64, ptr } %t169, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t171, i64 %t172)
  %t184 = getelementptr i8, ptr %t183, i64 %t172
  call void @olang_textcopy(ptr %t184, ptr %t173, i64 %t174)
  %t185 = getelementptr i8, ptr %t184, i64 %t174
  call void @olang_textcopy(ptr %t185, ptr %t177, i64 %t178)
  %t186 = getelementptr i8, ptr %t185, i64 %t178
  call void @olang_textcopy(ptr %t186, ptr %t180, i64 %t181)
  %t187 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t183, 1
  store { i64, ptr } %t188, ptr %l5, !tbaa !27
  br label %bb29
bb28:
  br label %bb29
bb29:
  %t190 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t192 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t190)
  store i32 %t192, ptr %l71
  %t193 = icmp ne i32 %t192, 0
  br i1 %t193, label %bb31, label %ok.194, !prof !99
ok.194:
  br label %bb30
bb30:
  br label %bb35
bb31:
  %t195 = load i32, ptr %l71, !tbaa !23
  %t196 = ashr i32 %t195, 16
  %t198 = icmp eq i32 %t196, 1
  store i1 %t198, ptr %l73, !tbaa !21
  %t199 = load i32, ptr %l71, !tbaa !23
  %t200 = ashr i32 %t199, 16
  %t202 = icmp eq i32 %t200, 1
  br i1 %t202, label %bb32, label %bb33
bb32:
  call void @__olang_errpay_pop()
  br label %bb33
bb33:
  br label %bb34
bb34:
  br label %bb35
bb35:
  %t204 = load ptr, ptr %l1, !tbaa !29
  %t206 = getelementptr %"compiler/build:Config", ptr %t204, i32 0, i32 31
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t210 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t215 = call i32 @compiler_2fprofile_2erunProfiled(ptr %v1, ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t207, { i64, ptr } %t208, { i64, ptr } %a3, { i64, ptr } %t210)
  store i32 %t215, ptr %l81
  br label %bb36
bb36:
  %t216 = load i32, ptr %l81, !tbaa !23
  store i32 %t216, ptr %l6, !tbaa !23
  %t217 = load i32, ptr %l6, !tbaa !23
  %t219 = icmp slt i32 %t217, 0
  br i1 %t219, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s10
  %t221 = load ptr, ptr %l4, !tbaa !29
  store ptr %t221, ptr %l84, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t222
  %t223 = getelementptr { i64, [3 x i64] }, ptr %t222, i32 0, i32 0
  store i64 0, ptr %t223
  %t224 = load { i64, [3 x i64] }, ptr %t222
  store { i64, [3 x i64] } %t224, ptr %l85
  %t225 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s10, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d60, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t225, ptr %l86
  br label %bb39
bb38:
  br label %bb42
bb39:
  %t226 = load ptr, ptr %l84, !tbaa !29
  %t227 = load { i64, [3 x i64] }, ptr %l85
  %t228 = load %"compiler/diagmsg:Msg", ptr %l86
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t226, { i64, [3 x i64] } %t227, %"compiler/diagmsg:Msg" %t228)
  br label %bb40
bb40:
  %t229 = load ptr, ptr %l4, !tbaa !29
  %t231 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t229)
  store i32 %t231, ptr %l88
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t232 = load i32, ptr %l88, !tbaa !23
  store i32 %t232, ptr %rv
  br label %ret
bb42:
  %t233 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t235 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t233)
  %t236 = extractvalue { i32, { i64, ptr } } %t235, 1
  %t237 = extractvalue { i32, { i64, ptr } } %t235, 0
  store i32 %t237, ptr %l92
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb44, label %ok.239, !prof !99
ok.239:
  store { i64, ptr } %t236, ptr %l91
  br label %bb43
bb43:
  %t240 = load { i64, ptr }, ptr %l91, !tbaa !27
  store { i64, ptr } %t240, ptr %l89, !tbaa !27
  br label %bb50
bb44:
  %t241 = load i32, ptr %l92, !tbaa !23
  %t242 = ashr i32 %t241, 16
  %t244 = icmp eq i32 %t242, 1
  store i1 %t244, ptr %l94, !tbaa !21
  %t245 = load i32, ptr %l92, !tbaa !23
  %t246 = ashr i32 %t245, 16
  %t248 = icmp eq i32 %t246, 1
  br i1 %t248, label %bb45, label %bb46
bb45:
  call void @__olang_errpay_pop()
  br label %bb46
bb46:
  br label %bb47
bb47:
  store %olang.scope zeroinitializer, ptr %s11
  %t250 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t250, ptr %l97, !tbaa !27
  %t251 = load i32, ptr %l6, !tbaa !23
  %t253 = sub i32 %t251, 128
  %t255 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t253)
  store { i64, ptr } %t255, ptr %l100
  br label %bb48
bb48:
  %t256 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t257 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t258 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t259 = extractvalue { i64, ptr } %t258, 1
  %t260 = extractvalue { i64, ptr } %t258, 0
  %t261 = add i64 %t257, %t260
  %t262 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t263 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t264 = add i64 %t261, %t263
  %t265 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t266 = extractvalue { i64, ptr } %t265, 1
  %t267 = extractvalue { i64, ptr } %t265, 0
  %t268 = add i64 %t264, %t267
  %t269 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t270 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t271 = add i64 %t268, %t270
  %t272 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t271)
  call void @olang_textcopy(ptr %t272, ptr %t256, i64 %t257)
  %t273 = getelementptr i8, ptr %t272, i64 %t257
  call void @olang_textcopy(ptr %t273, ptr %t259, i64 %t260)
  %t274 = getelementptr i8, ptr %t273, i64 %t260
  call void @olang_textcopy(ptr %t274, ptr %t262, i64 %t263)
  %t275 = getelementptr i8, ptr %t274, i64 %t263
  call void @olang_textcopy(ptr %t275, ptr %t266, i64 %t267)
  %t276 = getelementptr i8, ptr %t275, i64 %t267
  call void @olang_textcopy(ptr %t276, ptr %t269, i64 %t270)
  %t277 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t272, 1
  %t280 = extractvalue { i64, ptr } %t278, 0
  %t281 = extractvalue { i64, ptr } %t278, 1
  %t282 = mul i64 %t280, 1
  %t283 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t282)
  call void @llvm.memcpy.p0.p0.i64(ptr %t283, ptr %t281, i64 %t282, i1 false)
  %t284 = insertvalue { i64, ptr } undef, i64 %t280, 0
  %t285 = insertvalue { i64, ptr } %t284, ptr %t283, 1
  call void @compiler_2fprofile_2esay(ptr %s11, { i64, ptr } %t285)
  br label %bb49
bb49:
  %t287 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t287, ptr %rv
  br label %ret
bb50:
  %t289 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t293 = call { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t289)
  %t294 = extractvalue { i32, %"compiler/profile:Profile" } %t293, 1
  %t295 = extractvalue { i32, %"compiler/profile:Profile" } %t293, 0
  store i32 %t295, ptr %l108
  %t296 = icmp ne i32 %t295, 0
  br i1 %t296, label %bb52, label %ok.297, !prof !99
ok.297:
  store %"compiler/profile:Profile" %t294, ptr %l107
  br label %bb51
bb51:
  %t298 = load %"compiler/profile:Profile", ptr %l107
  store %"compiler/profile:Profile" %t298, ptr %l104
  br label %bb55
bb52:
  %t299 = load i32, ptr %l108, !tbaa !23
  %t300 = ashr i32 %t299, 16
  %t302 = icmp eq i32 %t300, 1
  store i1 %t302, ptr %l110, !tbaa !21
  br label %bb53
bb53:
  store %olang.scope zeroinitializer, ptr %s13
  %t303 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t304 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d64, i32 0, i32 1) }, 1
  %t305 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d64, i32 0, i32 1) }, 0
  %t307 = extractvalue { i64, ptr } %t303, 1
  %t308 = extractvalue { i64, ptr } %t303, 0
  %t309 = add i64 %t305, %t308
  %t310 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d65, i32 0, i32 1) }, 1
  %t311 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d65, i32 0, i32 1) }, 0
  %t312 = add i64 %t309, %t311
  %t313 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t312)
  call void @olang_textcopy(ptr %t313, ptr %t304, i64 %t305)
  %t314 = getelementptr i8, ptr %t313, i64 %t305
  call void @olang_textcopy(ptr %t314, ptr %t307, i64 %t308)
  %t315 = getelementptr i8, ptr %t314, i64 %t308
  call void @olang_textcopy(ptr %t315, ptr %t310, i64 %t311)
  %t316 = insertvalue { i64, ptr } undef, i64 %t312, 0
  %t317 = insertvalue { i64, ptr } %t316, ptr %t313, 1
  %t319 = extractvalue { i64, ptr } %t317, 0
  %t320 = extractvalue { i64, ptr } %t317, 1
  %t321 = mul i64 %t319, 1
  %t322 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t321)
  call void @llvm.memcpy.p0.p0.i64(ptr %t322, ptr %t320, i64 %t321, i1 false)
  %t323 = insertvalue { i64, ptr } undef, i64 %t319, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t322, 1
  call void @compiler_2fprofile_2esay(ptr %s13, { i64, ptr } %t324)
  br label %bb54
bb54:
  %t326 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t326, ptr %rv
  br label %ret
bb55:
  %t328 = load %"compiler/profile:Profile", ptr %l104
  store %"compiler/profile:Profile" %t328, ptr %l12
  %t329 = call { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %s0)
  store { i64, ptr } %t329, ptr %l115
  br label %bb56
bb56:
  %t330 = load { i64, ptr }, ptr %l115, !tbaa !27
  store { i64, ptr } %t330, ptr %l13, !tbaa !27
  %t331 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fprofile_2ePlaces_2eResolve(ptr %t332, ptr %s0, ptr %s0, ptr %s0, ptr %l12, { i64, ptr } %t331)
  call void @llvm.memmove.p0.p0.i64(ptr %l118, ptr %t332, i64 272, i1 false)
  br label %bb57
bb57:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l118, i64 272, i1 false)
  %t335 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t339 = call { i64, ptr } @compiler_2fprofile_2eReport(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t335, ptr %l12, ptr %l14)
  store { i64, ptr } %t339, ptr %l122
  br label %bb58
bb58:
  %t340 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  %t342 = extractvalue { i64, ptr } %t340, 1
  %t343 = mul i64 %t341, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t343)
  call void @llvm.memcpy.p0.p0.i64(ptr %t344, ptr %t342, i64 %t343, i1 false)
  %t345 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t346)
  br label %bb59
bb59:
  %t348 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t350 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t348, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d66, i32 0, i32 1) })
  store i1 %t350, ptr %l125
  br label %bb60
bb60:
  %t351 = load i1, ptr %l125, !tbaa !21
  br i1 %t351, label %bb61, label %bb62
bb61:
  store %olang.scope zeroinitializer, ptr %s15
  call void @compiler_2fprofile_2esay(ptr %s15, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d67, i32 0, i32 1) })
  br label %bb63
bb62:
  br label %bb64
bb63:
  call void @__olang_scope_close(ptr %s15)
  br label %bb64
bb64:
  %t352 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t352, ptr %l126, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t357 = call { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t353, ptr %l12, ptr %l14)
  store { i64, ptr } %t357, ptr %l130
  br label %bb65
bb65:
  %t358 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = extractvalue { i64, ptr } %t358, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  %t366 = load { i64, ptr }, ptr %l126, !tbaa !27
  %t368 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t366, { i64, ptr } %t365)
  store i32 %t368, ptr %l133
  %t369 = icmp ne i32 %t368, 0
  br i1 %t369, label %bb67, label %ok.370, !prof !99
ok.370:
  br label %bb66
bb66:
  br label %bb72
bb67:
  %t371 = load i32, ptr %l133, !tbaa !23
  %t372 = ashr i32 %t371, 16
  %t374 = icmp eq i32 %t372, 1
  store i1 %t374, ptr %l135, !tbaa !21
  %t375 = load i32, ptr %l133, !tbaa !23
  %t376 = ashr i32 %t375, 16
  %t378 = icmp eq i32 %t376, 1
  br i1 %t378, label %bb68, label %bb69
bb68:
  call void @__olang_errpay_pop()
  br label %bb69
bb69:
  br label %bb70
bb70:
  store %olang.scope zeroinitializer, ptr %s16
  %t380 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t381 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t384 = extractvalue { i64, ptr } %t380, 1
  %t385 = extractvalue { i64, ptr } %t380, 0
  %t386 = add i64 %t382, %t385
  %t387 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t388 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t389 = add i64 %t386, %t388
  %t390 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t389)
  call void @olang_textcopy(ptr %t390, ptr %t381, i64 %t382)
  %t391 = getelementptr i8, ptr %t390, i64 %t382
  call void @olang_textcopy(ptr %t391, ptr %t384, i64 %t385)
  %t392 = getelementptr i8, ptr %t391, i64 %t385
  call void @olang_textcopy(ptr %t392, ptr %t387, i64 %t388)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t390, 1
  %t396 = extractvalue { i64, ptr } %t394, 0
  %t397 = extractvalue { i64, ptr } %t394, 1
  %t398 = mul i64 %t396, 1
  %t399 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t398)
  call void @llvm.memcpy.p0.p0.i64(ptr %t399, ptr %t397, i64 %t398, i1 false)
  %t400 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t401 = insertvalue { i64, ptr } %t400, ptr %t399, 1
  call void @compiler_2fprofile_2esay(ptr %s16, { i64, ptr } %t401)
  br label %bb71
bb71:
  %t403 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t403, ptr %rv
  br label %ret
bb72:
  %t405 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t407 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t405)
  store { i64, ptr } %t407, ptr %l143
  br label %bb73
bb73:
  %t408 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t410 = load { i64, ptr }, ptr %l143, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 1
  %t415 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d71, i32 0, i32 1) }, 0
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t408, i64 %t409)
  %t418 = getelementptr i8, ptr %t417, i64 %t409
  call void @olang_textcopy(ptr %t418, ptr %t411, i64 %t412)
  %t419 = getelementptr i8, ptr %t418, i64 %t412
  call void @olang_textcopy(ptr %t419, ptr %t414, i64 %t415)
  %t420 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t421 = insertvalue { i64, ptr } %t420, ptr %t417, 1
  %t423 = extractvalue { i64, ptr } %t421, 0
  %t424 = extractvalue { i64, ptr } %t421, 1
  %t425 = mul i64 %t423, 1
  %t426 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t425)
  call void @llvm.memcpy.p0.p0.i64(ptr %t426, ptr %t424, i64 %t425, i1 false)
  %t427 = insertvalue { i64, ptr } undef, i64 %t423, 0
  %t428 = insertvalue { i64, ptr } %t427, ptr %t426, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t428)
  br label %bb74
bb74:
  %t430 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t430, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePutLn_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStdout, !tbaa !23
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d72, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t4, i64 %t5)
  %t10 = getelementptr i8, ptr %t9, i64 %t5
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t23 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t1, { i64, ptr } %t20)
  store i32 %t23, ptr %l6
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb2, label %ok.25, !prof !99
ok.25:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, i64 } @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eFindIndex_3cstd_2f_H0cdaf28864c9da4990596b1986b376a0_clone1_olang_lambda_9922(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l15 = alloca { i64, ptr }
  %l18 = alloca i1
  %l21 = alloca i1
  %rv = alloca { i32, i64 }
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load i64, ptr %l3, !tbaa !24
  store i64 %t15, ptr %l5, !tbaa !24
  %t17 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t17, ptr %l15, !tbaa !27
  %t18 = load i64, ptr %l3, !tbaa !24
  %t20 = getelementptr { i64, ptr }, ptr %l15, i32 0, i32 1
  %t21 = load ptr, ptr %t20, !tbaa !27
  %t22 = getelementptr { i64, ptr }, ptr %t21, i64 %t18
  %t23 = load { i64, ptr }, ptr %t22, !tbaa !37
  %t28 = extractvalue { ptr, ptr } %pg1, 1
  %t30 = call i1 @olang_lambda_73(ptr %t28, ptr %v0, { i64, ptr } %t23)
  store i1 %t30, ptr %l21
  br label %bb5
bb5:
  %t31 = load i1, ptr %l21, !tbaa !21
  store i1 %t31, ptr %l18, !tbaa !21
  br label %bb6
bb6:
  %t32 = load i1, ptr %l18, !tbaa !21
  br i1 %t32, label %bb7, label %bb8
bb7:
  %t33 = load i64, ptr %l5, !tbaa !24
  %t35 = insertvalue { i32, i64 } zeroinitializer, i64 %t33, 1
  store { i32, i64 } %t35, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t36 = load i64, ptr %l3, !tbaa !24
  %t38 = add i64 %t36, 1
  store i64 %t38, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  %t41 = insertvalue { i32, i64 } zeroinitializer, i32 65536, 0
  store { i32, i64 } %t41, ptr %rv
  br label %ret
ret:
  %rr = load { i32, i64 }, ptr %rv
  ret { i32, i64 } %rr
}

define dso_local i1 @std_2fprelude_2farray_2eArray_3cstd_2fprelude_2ftext_3aString_26_3e_2eSome_3cstd_2fprelu_H83fc947e980a7768a96047c3a0b10532_clone1_olang_lambda_9920(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1c, ptr %a1e) #0 {
entry:
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca i64
  %l13 = alloca { i64, ptr }
  %l16 = alloca i1
  %l19 = alloca i1
  %rv = alloca i1
  %pf1 = insertvalue { ptr, ptr } undef, ptr %a1c, 0
  %pg1 = insertvalue { ptr, ptr } %pf1, ptr %a1e, 1
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %a0, ptr %l2, !tbaa !27
  store i64 0, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = extractvalue { i64, ptr } %t3, 0
  store i64 %t5, ptr %l4, !tbaa !24
  br label %bb1
bb1:
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = load i64, ptr %l4, !tbaa !24
  %t11 = icmp slt i64 %t7, %t8
  %t13 = xor i1 %t11, true
  br i1 %t13, label %bb2, label %bb3
bb2:
  br label %bb11
bb3:
  br label %bb4
bb4:
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l13, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l13, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, ptr }, ptr %t19, i64 %t16
  %t21 = load { i64, ptr }, ptr %t20, !tbaa !37
  %t26 = extractvalue { ptr, ptr } %pg1, 1
  %t28 = call i1 @olang_lambda_74(ptr %t26, ptr %v0, { i64, ptr } %t21)
  store i1 %t28, ptr %l19
  br label %bb5
bb5:
  %t29 = load i1, ptr %l19, !tbaa !21
  store i1 %t29, ptr %l16, !tbaa !21
  br label %bb6
bb6:
  %t30 = load i1, ptr %l16, !tbaa !21
  br i1 %t30, label %bb7, label %bb8
bb7:
  store i1 true, ptr %rv
  br label %ret
bb8:
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t32 = load i64, ptr %l3, !tbaa !24
  %t34 = add i64 %t32, 1
  store i64 %t34, ptr %l3, !tbaa !24
  br label %bb1
bb11:
  store i1 false, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_H260c71ae77815ec4b6e333189d6723ff(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l16 = alloca i1
  %l19 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l28 = alloca i64
  %l31 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H03e9ef1e4e2bd9eb7da3015597022b10(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t25 = getelementptr { i64, ptr }, ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %t26, i64 %t21
  %t28 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %t27
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" zeroinitializer, ptr %t27
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t28, ptr %l19
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l1, !tbaa !24
  br label %bb1
bb10:
  store i64 0, ptr %l2, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t33, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb16
bb13:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb16
bb16:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t86, i32 0, i32 2
  %t91 = getelementptr { i64, ptr }, ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i64, ptr %t92, i64 %t84
  store i64 -1, ptr %t93, !tbaa !34
  br label %bb21
bb21:
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l6, !tbaa !24
  br label %bb17
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t98, i32 0, i32 3
  store i64 0, ptr %t100, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t101, i32 0, i32 4
  store i64 0, ptr %t103, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t104, i32 0, i32 5
  store i64 -1, ptr %t106, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2ePush_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Code" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l16 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eroom_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %t15, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t32 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t34 = getelementptr { i64, ptr }, ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/build:Code", ptr %t35, i64 %t28
  store %"compiler/build:Code" %a1, ptr %t36
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l16, !tbaa !29
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t38, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = add i64 %t40, 1
  %t44 = load ptr, ptr %l16, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  store i64 %t42, ptr %t45, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eroom_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/build:Code", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 56
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/build:Code", ptr %t105, i64 %t102
  %t107 = load %"compiler/build:Code", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/build:Code", ptr %t111, i64 %t109
  store %"compiler/build:Code" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eRef_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/emit:Reused", ptr %t7, i64 %a1
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/explain:Code" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2eAt_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/explain:Code"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/explain:Code", ptr %t7, i64 %a1
  %t9 = load %"compiler/explain:Code", ptr %t8
  store %"compiler/explain:Code" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/explain:Code", ptr %rv
  ret %"compiler/explain:Code" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2eLen_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aMark_3e_2eEq_3ccompiler_2ftyped_3aMark_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l5, !tbaa !24
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sle i64 0, %t12
  br i1 %t13, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sle i64 %t15, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t19, i32 0, i32 0
  %t21 = getelementptr { i64, ptr }, ptr %t20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t22, i64 0
  %t25 = sub i64 %t23, 0
  %t26 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  store ptr %l9, ptr %l10
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l11, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l13, !tbaa !24
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l14, !tbaa !24
  %t37 = icmp sge i64 0, 0
  br i1 %t37, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb7:
  %t39 = load i64, ptr %l13, !tbaa !24
  %t40 = icmp sle i64 0, %t39
  br i1 %t40, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb9:
  %t42 = load i64, ptr %l13, !tbaa !24
  %t43 = load i64, ptr %l14, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  br i1 %t44, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb11:
  %t46 = load ptr, ptr %l11, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 0
  %t48 = getelementptr { i64, ptr }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l13, !tbaa !24
  %t51 = getelementptr { i64, [1 x i64] }, ptr %t49, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  store { i64, ptr } %t54, ptr %l18, !tbaa !27
  %t55 = load ptr, ptr %l10
  %t57 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e_26(ptr %t55, ptr %l18)
  store i1 %t57, ptr %l20
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb13:
  %t58 = load i1, ptr %l20, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"run" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d15 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ir" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".asm" }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/listing/" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d20 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d21 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"RaceBuild" }>, align 8
@.d26 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"RaceBuild" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d33 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d34 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d35 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_test" }>, align 8
@.d36 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d37 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": native compilation failed" }>, align 8
@.d38 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d39 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d40 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d41 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"running tools" }>, align 8
@.d42 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"compiling" }>, align 8
@.d43 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d44 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d45 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-ir" }>, align 8
@.d46 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d47 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
define linkonce_odr i32 @compiler_2folang_2ebuildCell_fv_fn_28std_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_2c_20Array_3_H1276486710fe3f33d55b88d9cfddba68(ptr %env, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7) #0 {
entry:
  %r = call i32 @compiler_2folang_2ebuildCell(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7)
  ret i32 %r
}

@.d48 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d49 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/profile" }>, align 8
@.d52 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"its profile's directory " }>, align 8
@.d53 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot be made" }>, align 8
@.d54 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d56 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".samples" }>, align 8
@.d57 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d58 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d59 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d60 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d61 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d62 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" wrote no profile - it ended by a signal (" }>, align 8
@.d63 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d64 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d65 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is not a profile this compiler writes\0A" }>, align 8
@.d66 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d67 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"olang profile: no llvm-symbolizer found beside clang or on PATH - functions named by their addresses\0A" }>, align 8
@.d68 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d69 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be written\0A" }>, align 8
@.d70 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"flame graph: " }>, align 8
@.d71 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d72 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define internal i1 @olang_lambda_73(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, i64, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, i64, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i64, ptr %cp1, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, i64, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %cv0, ptr %l4, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %t6, i64 %cv1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !37
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %vc0, { i64, ptr } %a0, { i64, ptr } %t8)
  store i1 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load i1, ptr %l7, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define internal i1 @olang_lambda_74(ptr %env, ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l4 = alloca { i64, ptr }
  %l7 = alloca i1
  %rv = alloca i1
  %cp0 = getelementptr { { i64, ptr }, i64, ptr }, ptr %env, i32 0, i32 0
  %cv0 = load { i64, ptr }, ptr %cp0, !tbaa !28
  %cp1 = getelementptr { { i64, ptr }, i64, ptr }, ptr %env, i32 0, i32 1
  %cv1 = load i64, ptr %cp1, !tbaa !28
  %vq0 = getelementptr { { i64, ptr }, i64, ptr }, ptr %env, i32 0, i32 2
  %vr0 = load ptr, ptr %vq0, !tbaa !28
  %vc0 = call ptr @__olang_capture_scope(ptr %vr0)
  br label %start
start:
  br label %bb0
bb0:
  store { i64, ptr } %cv0, ptr %l4, !tbaa !27
  %t5 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t6 = load ptr, ptr %t5, !tbaa !27
  %t7 = getelementptr { i64, ptr }, ptr %t6, i64 %cv1
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !37
  %t11 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %vc0, { i64, ptr } %a0, { i64, ptr } %t8)
  store i1 %t11, ptr %l7
  br label %bb1
bb1:
  %t12 = load i1, ptr %l7, !tbaa !21
  store i1 %t12, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define available_externally ptr @__olang_capture_scope(ptr %s) alwaysinline {
entry:
  %isprog = icmp eq ptr %s, null
  br i1 %isprog, label %prog, label %mine
prog:
  %p = load ptr, ptr @__olang_prog_scope
  ret ptr %p
mine:
  %m = call ptr @__olang_scope_mine(ptr %s)
  ret ptr %m
}
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb8
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t15, i64 %t13
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, [1 x i64] }, ptr %t19, i64 %t17
  %t23 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aMark(ptr %t16, ptr %t20)
  store i1 %t23, ptr %l10
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb7, label %bb1
bb7:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t25, 1
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb3
bb8:
  %t27 = load i1, ptr %l2, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_prog_scope = external thread_local(initialexec) global ptr
define available_externally ptr @__olang_scope_mine(ptr %s) alwaysinline {
entry:
  %op = getelementptr %olang.scope, ptr %s, i32 0, i32 3
  %o = load atomic ptr, ptr %op monotonic, align 8
  %me = load ptr, ptr @__olang_self
  %own = icmp eq ptr %o, %me
  br i1 %own, label %mine, label %slow
mine:
  ret ptr %s
slow:
  %r = call ptr @__olang_scope_mine_slow(ptr %s)
  ret ptr %r
}
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aMark(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 6}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 6}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 2, label %bb4 ]
bb3:
  br label %bb6
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb5, label %bb1
bb5:
  br label %bb3
bb6:
  %t22 = load i1, ptr %l2, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

@__olang_self = external thread_local(initialexec) global ptr
declare ptr @__olang_scope_mine_slow(ptr) noinline
declare void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare void @compiler_2fspin_2eEnd()
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/diagmsg:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_251e830707558b33_b2bdace7e2a71047 = external constant [0 x i8]
declare void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/diagmsg:Msg" %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_ac43697cc5f2dca0_4dfd3d6081b857d4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_d52a764a2d9743a3_d3f0603066c4fb17 = external constant [0 x i8]
declare i64 @std_2ftime_2eNow()
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fbuild_2eRunCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2ePrune(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @compiler_2fmeasure_2eMeasure(ptr %v0, ptr %v1, { i64, ptr } %a0, i64 %a1, i64 %a2, { i64, ptr } %a3)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_3e7cb8585e177347_844f5af656df9c9b = external constant [0 x i8]
declare %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, ptr %a6)
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
declare i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2esplitsTests(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, i64 %a6)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, ptr %a6)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eSetBool(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_d427f69e0d58601c_ef1499a0f9cee590 = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eFinish(ptr %v0, ptr %a0)
@olang_loc_4ce37e8669e18741_b51ffe42b73135c5 = external constant [0 x i8]
declare { i64, ptr } @compiler_2flisting_2ehow(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare { i64, ptr } @compiler_2flisting_2ecommentOf(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/listing:Inputs" @compiler_2flisting_3aInputs_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4)
declare { i64, ptr } @compiler_2flisting_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2flisting_2esay(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eJupyter = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0F\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eNotebook = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2folang_2ewaits(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eFix = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fspin_2eBegin(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2folang_2eanalyzes(ptr %v0, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eAnalysisDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@G_2ecompiler_2folang_2eBindgen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eApi = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRunBuilt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eProfile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eBuilder = external global { ptr, ptr }
declare i32 @compiler_2fprompt_2eRun(ptr %v0, ptr %a0)
declare i32 @compiler_2fjupyter_2eInstall(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare i32 @compiler_2fjupyter_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fnotebook_2eRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2308270aeb54ce5f_1121c256bef46e33 = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0)
declare void @compiler_2fprofile_2ePlaces_2eResolve(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
@G_2estd_2fio_2eStdout = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H03e9ef1e4e2bd9eb7da3015597022b10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_42020986585537b2_4c4b240152eb3e56 = external constant [0 x i8]
@olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f = external constant [0 x i8]
declare i32 @compiler_2folang_2ebuildCell(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
