; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Program" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr } }
%"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"std/prelude/list:listState.9783095779ea18337775adeb6569839d" = type { { i64, ptr }, { i64, ptr }, i64, i64, { i64, ptr }, i64, i64, i64 }
%"compiler/emit:Object" = type { { i64, ptr }, i32, { i64, ptr }, i64 }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/build:Program"
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i32
  %l36 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i32
  %l45 = alloca i32
  %l48 = alloca i1
  %l50 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l57 = alloca { i64, ptr }
  %l59 = alloca { i64, ptr }
  %l61 = alloca { i64, ptr }
  %l63 = alloca ptr
  %l64 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l67 = alloca i1
  %l69 = alloca i32
  %l72 = alloca ptr
  %l73 = alloca { i64, [3 x i64] }
  %l75 = alloca %"compiler/msgs:Msg"
  %l77 = alloca i32
  %l85 = alloca ptr
  %l88 = alloca i1
  %l90 = alloca { i64, ptr }
  %l93 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  %t163 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Program", ptr %l7
  store %"compiler/build:Program" %t2, ptr %l4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, i32 1, ptr %t5, ptr %l4, ptr %t6)
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  %t17 = icmp eq i32 %t16, 65536
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  %t20 = icmp eq i32 %t19, 65537
  br i1 %t20, label %bb7, label %bb8
bb6:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l18
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  %t25 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t25, ptr %l19
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l18, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb12:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l21
  br label %bb13
bb13:
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t34 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t34)
  store i64 %t36, ptr %l25
  br label %bb16
bb16:
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i32, ptr %l28, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb21:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t45, ptr %t46)
  store i32 %t49, ptr %l31
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb23, label %ok.51
ok.51:
  br label %bb22
bb22:
  br label %bb28
bb23:
  %t52 = load i32, ptr %l31, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_13a46f17cfa63227_b1895594948889cb)
  unreachable
bb26:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t57)
  store i32 %t59, ptr %l35
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load i32, ptr %l35, !tbaa !23
  store i32 %t60, ptr %rv
  br label %ret
bb28:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t66 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t61, ptr %l4, ptr %t62)
  %t67 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 1
  %t68 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 0
  store i32 %t68, ptr %l41
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb30, label %ok.70
ok.70:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l40
  br label %bb29
bb29:
  %t71 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l36
  br label %bb35
bb30:
  %t72 = load i32, ptr %l41, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_fd88121d790f24ac_3e6efb3076496690)
  unreachable
bb33:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t77)
  store i32 %t79, ptr %l45
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l45, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb35:
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr @.d0 })
  br label %bb36
bb36:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 13
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr @.d1 })
  store i1 %t87, ptr %l48
  br label %bb37
bb37:
  %t88 = load i1, ptr %l48, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb38, label %bb39
bb38:
  %t91 = load ptr, ptr %l1, !tbaa !29
  %t93 = getelementptr %"compiler/build:Config", ptr %t91, i32 0, i32 13
  %t94 = load { i64, ptr }, ptr %t93, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 1
  %t97 = extractvalue { i64, ptr } %t94, 0
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  call void @olang_textcopy(ptr %t98, ptr %t96, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t97, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l50, !tbaa !27
  br label %bb43
bb39:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t104 = getelementptr %"compiler/build:Config", ptr %t102, i32 0, i32 0
  %t105 = load { i64, ptr }, ptr %t104, !tbaa !27
  store { i64, ptr } %t105, ptr %l55, !tbaa !27
  %t107 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t107, ptr %l57
  br label %bb40
bb40:
  %t108 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t108, 0
  %t110 = extractvalue { i64, ptr } %t108, 1
  %t111 = mul i64 %t109, 1
  %t112 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t111)
  call void @llvm.memcpy.p0.p0.i64(ptr %t112, ptr %t110, i64 %t111, i1 false)
  %t113 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t114 = insertvalue { i64, ptr } %t113, ptr %t112, 1
  %t116 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t114)
  store { i64, ptr } %t116, ptr %l59
  br label %bb41
bb41:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t117)
  store { i64, ptr } %t119, ptr %l61
  br label %bb42
bb42:
  %t120 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 1
  %t122 = extractvalue { i64, ptr } %t120, 0
  %t123 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 1
  %t124 = extractvalue { i64, ptr } { i64 1, ptr @.d2 }, 0
  %t125 = add i64 %t122, %t124
  %t126 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t127 = extractvalue { i64, ptr } %t126, 1
  %t128 = extractvalue { i64, ptr } %t126, 0
  %t129 = add i64 %t125, %t128
  %t130 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t131 = extractvalue { i64, ptr } %t130, 1
  %t132 = extractvalue { i64, ptr } %t130, 0
  %t133 = add i64 %t129, %t132
  %t134 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t133)
  call void @olang_textcopy(ptr %t134, ptr %t121, i64 %t122)
  %t135 = getelementptr i8, ptr %t134, i64 %t122
  call void @olang_textcopy(ptr %t135, ptr %t123, i64 %t124)
  %t136 = getelementptr i8, ptr %t135, i64 %t124
  call void @olang_textcopy(ptr %t136, ptr %t127, i64 %t128)
  %t137 = getelementptr i8, ptr %t136, i64 %t128
  call void @olang_textcopy(ptr %t137, ptr %t131, i64 %t132)
  %t138 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t134, 1
  store { i64, ptr } %t139, ptr %l50, !tbaa !27
  br label %bb43
bb43:
  %t141 = load { i64, ptr }, ptr %l50, !tbaa !27
  store { i64, ptr } %t141, ptr %l6, !tbaa !27
  %t142 = load ptr, ptr %l1, !tbaa !29
  store ptr %t142, ptr %l63, !tbaa !29
  store ptr %l5, ptr %l64, !tbaa !29
  %t143 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t143, ptr %l65, !tbaa !27
  %t144 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 2
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t147 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t145, { i64, ptr } { i64 0, ptr @.d3 })
  store i1 %t147, ptr %l67
  br label %bb44
bb44:
  %t148 = load i1, ptr %l67, !tbaa !21
  %t149 = xor i1 %t148, true
  %t150 = load ptr, ptr %l63, !tbaa !29
  %t151 = load ptr, ptr %l64, !tbaa !29
  %t152 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t154 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %t150, ptr %t151, { i64, ptr } %t152, i1 %t149)
  store i32 %t154, ptr %l69
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb46, label %ok.156
ok.156:
  br label %bb45
bb45:
  br label %bb53
bb46:
  %t157 = load i32, ptr %l69, !tbaa !23
  %t158 = ashr i32 %t157, 16
  %t160 = icmp eq i32 %t158, 1
  br i1 %t160, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_a50415520eaa75d_89ededae97ad6121)
  unreachable
bb49:
  store %olang.scope zeroinitializer, ptr %s8
  %t162 = load ptr, ptr %l3, !tbaa !29
  store ptr %t162, ptr %l72, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t163
  %t164 = getelementptr { i64, [3 x i64] }, ptr %t163, i32 0, i32 0
  store i64 0, ptr %t164
  %t165 = load { i64, [3 x i64] }, ptr %t163
  store { i64, [3 x i64] } %t165, ptr %l73
  %t166 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t168 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s8, { i64, ptr } %t166)
  store %"compiler/msgs:Msg" %t168, ptr %l75
  br label %bb50
bb50:
  %t169 = load ptr, ptr %l72, !tbaa !29
  %t170 = load { i64, [3 x i64] }, ptr %l73
  %t171 = load %"compiler/msgs:Msg", ptr %l75
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s8, ptr %t169, { i64, [3 x i64] } %t170, %"compiler/msgs:Msg" %t171)
  br label %bb51
bb51:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t172)
  store i32 %t174, ptr %l77
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t175 = load i32, ptr %l77, !tbaa !23
  store i32 %t175, ptr %rv
  br label %ret
bb53:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr @.d4 })
  br label %bb54
bb54:
  %t176 = load ptr, ptr %l1, !tbaa !29
  %t177 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t179 = extractvalue { i64, ptr } %t177, 1
  %t180 = extractvalue { i64, ptr } %t177, 0
  %t181 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t180)
  call void @olang_textcopy(ptr %t181, ptr %t179, i64 %t180)
  %t182 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t193 = getelementptr %"compiler/build:Config", ptr %t176, i32 0, i32 14
  store { i64, ptr } %t190, ptr %t193, !tbaa !27
  %t194 = load ptr, ptr %l1, !tbaa !29
  %t196 = getelementptr %"compiler/build:Config", ptr %t194, i32 0, i32 12
  %t197 = load i1, ptr %t196, !tbaa !21
  %t199 = xor i1 %t197, true
  br i1 %t199, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t201 = load ptr, ptr %l1, !tbaa !29
  store ptr %t201, ptr %l85, !tbaa !29
  %t202 = load ptr, ptr %l1, !tbaa !29
  %t204 = getelementptr %"compiler/build:Config", ptr %t202, i32 0, i32 13
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  %t207 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s10, { i64, ptr } %t205, { i64, ptr } { i64 0, ptr @.d5 })
  store i1 %t207, ptr %l88
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t208 = load i1, ptr %l88, !tbaa !21
  %t209 = xor i1 %t208, true
  br i1 %t209, label %bb58, label %bb59
bb58:
  %t211 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t211, ptr %l90, !tbaa !27
  br label %bb61
bb59:
  %t213 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t215 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s10, { i64, ptr } %t213)
  store { i64, ptr } %t215, ptr %l93
  br label %bb60
bb60:
  %t216 = load { i64, ptr }, ptr %l93, !tbaa !27
  store { i64, ptr } %t216, ptr %l90, !tbaa !27
  br label %bb61
bb61:
  %t217 = extractvalue { i64, ptr } { i64 6, ptr @.d6 }, 1
  %t218 = extractvalue { i64, ptr } { i64 6, ptr @.d6 }, 0
  %t219 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t220 = extractvalue { i64, ptr } %t219, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = add i64 %t218, %t221
  %t223 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t222)
  call void @olang_textcopy(ptr %t223, ptr %t217, i64 %t218)
  %t224 = getelementptr i8, ptr %t223, i64 %t218
  call void @olang_textcopy(ptr %t224, ptr %t220, i64 %t221)
  %t225 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t223, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = extractvalue { i64, ptr } %t226, 1
  %t230 = mul i64 %t228, 1
  %t231 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t230)
  call void @llvm.memcpy.p0.p0.i64(ptr %t231, ptr %t229, i64 %t230, i1 false)
  %t232 = insertvalue { i64, ptr } undef, i64 %t228, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t231, 1
  %t234 = load ptr, ptr %l85, !tbaa !29
  %t236 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t234, { i64, ptr } { i64 2, ptr @.d7 }, { i64, ptr } %t233)
  store { i64, ptr } %t236, ptr %l96
  br label %bb62
bb62:
  %t237 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t238 = extractvalue { i64, ptr } %t237, 0
  %t239 = extractvalue { i64, ptr } %t237, 1
  %t240 = mul i64 %t238, 1
  %t241 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t240)
  call void @llvm.memcpy.p0.p0.i64(ptr %t241, ptr %t239, i64 %t240, i1 false)
  %t242 = insertvalue { i64, ptr } undef, i64 %t238, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t241, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t243)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca i32
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i32
  %l68 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i32
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Program", ptr %l8
  store %"compiler/build:Program" %t2, ptr %l4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t5, ptr %l4, ptr %t6)
  store i32 %t13, ptr %l15
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t16 = load i32, ptr %l15, !tbaa !23
  %t17 = icmp eq i32 %t16, 65536
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = icmp eq i32 %t19, 65537
  br i1 %t20, label %bb7, label %bb8
bb6:
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  %t25 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t25, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l20, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb12:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i64, ptr %l22, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t34 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb16
bb16:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i32, ptr %l29, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb21:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t45, ptr %t46)
  store i32 %t49, ptr %l32
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb23, label %ok.51
ok.51:
  br label %bb22
bb22:
  br label %bb28
bb23:
  %t52 = load i32, ptr %l32, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2f392dba8d9257c8_60d4d2a55ada0794)
  unreachable
bb26:
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t57)
  store i32 %t59, ptr %l36
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load i32, ptr %l36, !tbaa !23
  store i32 %t60, ptr %rv
  br label %ret
bb28:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t66 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t61, ptr %l4, ptr %t62)
  %t67 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 1
  %t68 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 0
  store i32 %t68, ptr %l42
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb30, label %ok.70
ok.70:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l41
  br label %bb29
bb29:
  %t71 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l37
  br label %bb35
bb30:
  %t72 = load i32, ptr %l42, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_21ac6a2bf5030ca3_5f4b05cf8c14a9cf)
  unreachable
bb33:
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t77)
  store i32 %t79, ptr %l46
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l46, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb35:
  %t81 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l5
  %t83 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store { i64, ptr } %t83, ptr %l48
  br label %bb36
bb36:
  %t84 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/build:Config", ptr %t85, i32 0, i32 13
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t88, { i64, ptr } { i64 0, ptr @.d8 })
  store i1 %t90, ptr %l51
  br label %bb37
bb37:
  %t91 = load i1, ptr %l51, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s6, { i64, ptr } %t94)
  %t97 = extractvalue { i32, { i64, ptr } } %t96, 1
  %t98 = extractvalue { i32, { i64, ptr } } %t96, 0
  store i32 %t98, ptr %l56
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb41, label %ok.100
ok.100:
  store { i64, ptr } %t97, ptr %l55
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t101 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t101, ptr %l53, !tbaa !27
  br label %bb48
bb41:
  %t102 = load i32, ptr %l56, !tbaa !23
  %t103 = ashr i32 %t102, 16
  %t105 = icmp eq i32 %t103, 1
  br i1 %t105, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6e425cae5aa6eba2_2e2cf5e273de798e)
  unreachable
bb44:
  store %olang.scope zeroinitializer, ptr %s7
  %t107 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t107, ptr %l59, !tbaa !27
  %t108 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s7)
  store %"compiler/msgs:Msg" %t108, ptr %l60
  br label %bb45
bb45:
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t111 = load %"compiler/msgs:Msg", ptr %l60
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s7, ptr %v1, { i64, ptr } %t110, %"compiler/msgs:Msg" %t111, ptr %t109)
  br label %bb46
bb46:
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t113)
  store i32 %t115, ptr %l63
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load i32, ptr %l63, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb48:
  %t117 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/build:Config", ptr %t118, i32 0, i32 13
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t126 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t121, { i64, ptr } %t117)
  store i32 %t126, ptr %l68
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb50, label %ok.128
ok.128:
  br label %bb49
bb49:
  br label %bb57
bb50:
  %t129 = load i32, ptr %l68, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_d8d1abb67d19f675_1213066b6aae1069)
  unreachable
bb53:
  store %olang.scope zeroinitializer, ptr %s8
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/build:Config", ptr %t134, i32 0, i32 13
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l72, !tbaa !27
  %t138 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s8)
  store %"compiler/msgs:Msg" %t138, ptr %l73
  br label %bb54
bb54:
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t141 = load %"compiler/msgs:Msg", ptr %l73
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s8, ptr %v1, { i64, ptr } %t140, %"compiler/msgs:Msg" %t141, ptr %t139)
  br label %bb55
bb55:
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t143)
  store i32 %t145, ptr %l76
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t146 = load i32, ptr %l76, !tbaa !23
  store i32 %t146, ptr %rv
  br label %ret
bb57:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/build:Config", ptr %t147, i32 0, i32 13
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = extractvalue { i64, ptr } %t150, 0
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t152, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb58:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/build:Config", ptr %t165, i32 0, i32 12
  %t168 = load i1, ptr %t167, !tbaa !21
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t174 = extractvalue { i64, ptr } { i64 6, ptr @.d9 }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr @.d9 }, 0
  %t177 = extractvalue { i64, ptr } %t173, 1
  %t178 = extractvalue { i64, ptr } %t173, 0
  %t179 = add i64 %t175, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t174, i64 %t175)
  %t181 = getelementptr i8, ptr %t180, i64 %t175
  call void @olang_textcopy(ptr %t181, ptr %t177, i64 %t178)
  %t182 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t193 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t172, { i64, ptr } { i64 2, ptr @.d10 }, { i64, ptr } %t190)
  store { i64, ptr } %t193, ptr %l88
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t194 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t200)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l13
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  br label %bb11
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_251e830707558b33_b2bdace7e2a71047)
  unreachable
bb8:
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l18
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t29)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15
ok.15:
  store i32 %t12, ptr %l11
  br label %bb1
bb1:
  %t16 = load i32, ptr %l11, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb11
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb8:
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l17
  br label %bb10
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load i32, ptr %l5, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca { i64, ptr }
  %l8 = alloca i64
  %l9 = alloca i64
  %l16 = alloca i32
  %l20 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l32 = alloca { i64, ptr }
  %l43 = alloca { i64, ptr }
  %l44 = alloca { i64, ptr }
  %l46 = alloca { i64, ptr }
  %l47 = alloca i32
  %l50 = alloca ptr
  %l51 = alloca { i64, [3 x i64] }
  %l52 = alloca %"compiler/msgs:Msg"
  %l54 = alloca i32
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t107 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 12
  store i1 true, ptr %t3, !tbaa !21
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t5, { i64, ptr } %t6, ptr %t7)
  store i32 %t12, ptr %l16
  br label %bb1
bb1:
  %t13 = load i32, ptr %l16, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  %t14 = load i32, ptr %l5, !tbaa !23
  %t16 = icmp ne i32 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr @__olang_prog_scope
  %t21 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t20)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t21, ptr %l20
  br label %bb5
bb5:
  %t22 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l20
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t22, ptr %l6
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t25 = extractvalue { i64, ptr } %t23, 1
  %t26 = extractvalue { i64, ptr } %t23, 0
  %t27 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t26)
  call void @olang_textcopy(ptr %t27, ptr %t25, i64 %t26)
  %t28 = insertvalue { i64, ptr } undef, i64 %t26, 0
  %t29 = insertvalue { i64, ptr } %t28, ptr %t27, 1
  %t31 = extractvalue { i64, ptr } %t29, 0
  %t32 = extractvalue { i64, ptr } %t29, 1
  %t33 = mul i64 %t31, 1
  %t34 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t33)
  call void @llvm.memcpy.p0.p0.i64(ptr %t34, ptr %t32, i64 %t33, i1 false)
  %t35 = insertvalue { i64, ptr } undef, i64 %t31, 0
  %t36 = insertvalue { i64, ptr } %t35, ptr %t34, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t36)
  br label %bb6
bb6:
  store { i64, ptr } %a3, ptr %l7, !tbaa !27
  store i64 0, ptr %l8, !tbaa !24
  %t41 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t43 = extractvalue { i64, ptr } %t41, 0
  store i64 %t43, ptr %l9, !tbaa !24
  br label %bb7
bb7:
  store %olang.scope zeroinitializer, ptr %s4
  %t45 = load i64, ptr %l8, !tbaa !24
  %t46 = load i64, ptr %l9, !tbaa !24
  %t49 = icmp slt i64 %t45, %t46
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb8, label %bb9
bb8:
  call void @__olang_scope_close(ptr %s4)
  br label %bb13
bb9:
  br label %bb10
bb10:
  %t53 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t53, ptr %l32, !tbaa !27
  %t54 = load i64, ptr %l8, !tbaa !24
  %t56 = getelementptr { i64, ptr }, ptr %l32, i32 0, i32 1
  %t57 = load ptr, ptr %t56, !tbaa !27
  %t58 = getelementptr { i64, ptr }, ptr %t57, i64 %t54
  %t59 = load { i64, ptr }, ptr %t58, !tbaa !37
  %t63 = extractvalue { i64, ptr } %t59, 1
  %t64 = extractvalue { i64, ptr } %t59, 0
  %t65 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t64)
  call void @olang_textcopy(ptr %t65, ptr %t63, i64 %t64)
  %t66 = insertvalue { i64, ptr } undef, i64 %t64, 0
  %t67 = insertvalue { i64, ptr } %t66, ptr %t65, 1
  %t69 = extractvalue { i64, ptr } %t67, 0
  %t70 = extractvalue { i64, ptr } %t67, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t74)
  br label %bb11
bb11:
  call void @__olang_scope_close(ptr %s4)
  br label %bb12
bb12:
  %t77 = load i64, ptr %l8, !tbaa !24
  %t79 = add i64 %t77, 1
  store i64 %t79, ptr %l8, !tbaa !24
  br label %bb7
bb13:
  %t81 = load ptr, ptr %l1, !tbaa !29
  %t83 = getelementptr %"compiler/build:Config", ptr %t81, i32 0, i32 14
  %t84 = load { i64, ptr }, ptr %t83, !tbaa !27
  %t86 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t84)
  store { i64, ptr } %t86, ptr %l43
  br label %bb14
bb14:
  %t87 = load { i64, ptr }, ptr %l43, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  %t89 = extractvalue { i64, ptr } %t87, 1
  %t90 = mul i64 %t88, 1
  %t91 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t90)
  call void @llvm.memcpy.p0.p0.i64(ptr %t91, ptr %t89, i64 %t90, i1 false)
  %t92 = insertvalue { i64, ptr } undef, i64 %t88, 0
  %t93 = insertvalue { i64, ptr } %t92, ptr %t91, 1
  store { i64, ptr } %t93, ptr %l44, !tbaa !27
  %t95 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t95, ptr %l46
  br label %bb15
bb15:
  %t96 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t98 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t96, { i64, ptr } %t97)
  store i32 %t98, ptr %l47
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb17, label %ok.100
ok.100:
  br label %bb16
bb16:
  br label %bb24
bb17:
  %t101 = load i32, ptr %l47, !tbaa !23
  %t102 = ashr i32 %t101, 16
  %t104 = icmp eq i32 %t102, 1
  br i1 %t104, label %bb18, label %bb19
bb18:
  br label %bb20
bb19:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
bb20:
  store %olang.scope zeroinitializer, ptr %s7
  %t106 = load ptr, ptr %l4, !tbaa !29
  store ptr %t106, ptr %l50, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t107
  %t108 = getelementptr { i64, [3 x i64] }, ptr %t107, i32 0, i32 0
  store i64 0, ptr %t108
  %t109 = load { i64, [3 x i64] }, ptr %t107
  store { i64, [3 x i64] } %t109, ptr %l51
  %t110 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s7, ptr %s7, { i64, ptr } { i64 20, ptr @.d11 })
  store %"compiler/msgs:Msg" %t110, ptr %l52
  br label %bb21
bb21:
  %t111 = load ptr, ptr %l50, !tbaa !29
  %t112 = load { i64, [3 x i64] }, ptr %l51
  %t113 = load %"compiler/msgs:Msg", ptr %l52
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s7, ptr %t111, { i64, [3 x i64] } %t112, %"compiler/msgs:Msg" %t113)
  br label %bb22
bb22:
  %t114 = load ptr, ptr %l4, !tbaa !29
  %t116 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t114)
  store i32 %t116, ptr %l54
  br label %bb23
bb23:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load i32, ptr %l54, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb24:
  call void @__olang_check_failed(ptr @olang_loc_364d74b8359cbf4c_14a2aae798044118)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca %"compiler/build:Program"
  %l6 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/os:Output"
  %l9 = alloca %"std/os:FileInfo"
  %l11 = alloca %"std/os:FileInfo"
  %l12 = alloca i32
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/msgs:Msg"
  %l19 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/msgs:Msg"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"compiler/msgs:Msg"
  %l34 = alloca i32
  %l35 = alloca %"compiler/build:Program"
  %l42 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l51 = alloca i64
  %l53 = alloca i1
  %l55 = alloca i64
  %l60 = alloca i32
  %l63 = alloca i32
  %l67 = alloca i32
  %l68 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l72 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l73 = alloca i32
  %l77 = alloca i32
  %l79 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l85 = alloca { i64, ptr }
  %l87 = alloca ptr
  %l88 = alloca ptr
  %l89 = alloca { i64, ptr }
  %l91 = alloca i1
  %l93 = alloca i32
  %l100 = alloca { i64, ptr }
  %l110 = alloca { i64, ptr }
  %l112 = alloca %"std/os:Output"
  %l114 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l120 = alloca %"std/os:Output"
  %l121 = alloca i32
  %l127 = alloca ptr
  %l128 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l138 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l12
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l11
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l11
  store %"std/os:FileInfo" %t8, ptr %l9
  br label %bb8
bb2:
  %t9 = load i32, ptr %l12, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_44996bcc7c9bda8_515f8c8db8b0565c)
  unreachable
bb5:
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l15, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l16, !tbaa !27
  %t16 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t16, ptr %l17
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l15, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t20 = load %"compiler/msgs:Msg", ptr %l17
  %t22 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s1, ptr %v1, ptr %t18, { i64, ptr } %t19, %"compiler/msgs:Msg" %t20, ptr %t17)
  store i32 %t22, ptr %l19
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l19, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  %t24 = load %"std/os:FileInfo", ptr %l9
  store %"std/os:FileInfo" %t24, ptr %l4
  %t25 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l22, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l23, !tbaa !27
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s2)
  store %"compiler/msgs:Msg" %t33, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l22, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t37 = load %"compiler/msgs:Msg", ptr %l24
  %t39 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s2, ptr %v1, ptr %t35, { i64, ptr } %t36, %"compiler/msgs:Msg" %t37, ptr %t34)
  store i32 %t39, ptr %l26
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l26, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
bb13:
  %t41 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 0
  %t42 = load i32, ptr %t41
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l30, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t50, ptr %l31, !tbaa !27
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %s3)
  store %"compiler/msgs:Msg" %t51, ptr %l32
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load ptr, ptr %l30, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t55 = load %"compiler/msgs:Msg", ptr %l32
  %t57 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s3, ptr %v1, ptr %t53, { i64, ptr } %t54, %"compiler/msgs:Msg" %t55, ptr %t52)
  store i32 %t57, ptr %l34
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l34, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t59, ptr %l35
  br label %bb19
bb19:
  %t60 = load %"compiler/build:Program", ptr %l35
  store %"compiler/build:Program" %t60, ptr %l5
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t71 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t62, i32 2, ptr %t63, ptr %l5, ptr %t64)
  store i32 %t71, ptr %l42
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb21, label %ok.73
ok.73:
  br label %bb20
bb20:
  br label %bb30
bb21:
  %t74 = load i32, ptr %l42, !tbaa !23
  %t75 = icmp eq i32 %t74, 65536
  br i1 %t75, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  %t77 = load i32, ptr %l42, !tbaa !23
  %t78 = icmp eq i32 %t77, 65537
  br i1 %t78, label %bb25, label %bb26
bb24:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t80, { i64, ptr } %t81, ptr %t82)
  store i32 %t86, ptr %l48
  br label %bb28
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_fd149271c6cb7c79_e880786eedc8ef8d)
  unreachable
bb27:
  %t87 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t87, ptr %l49
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i32, ptr %l48, !tbaa !23
  store i32 %t88, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load i32, ptr %l49, !tbaa !23
  store i32 %t89, ptr %rv
  br label %ret
bb30:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t90)
  store i64 %t92, ptr %l51
  br label %bb31
bb31:
  %t93 = load i64, ptr %l51, !tbaa !24
  %t94 = icmp sgt i64 %t93, 0
  br i1 %t94, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l53, !tbaa !21
  br label %bb35
bb33:
  %t96 = getelementptr %"compiler/build:Program", ptr %l5, i32 0, i32 0
  %t98 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t96)
  store i64 %t98, ptr %l55
  br label %bb34
bb34:
  %t99 = load i64, ptr %l55, !tbaa !24
  %t100 = icmp eq i64 %t99, 0
  store i1 %t100, ptr %l53, !tbaa !21
  br label %bb35
bb35:
  %t102 = load i1, ptr %l53, !tbaa !21
  br i1 %t102, label %bb36, label %bb37
bb36:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t109 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t103, { i64, ptr } %t104, ptr %t105)
  store i32 %t109, ptr %l60
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load i32, ptr %l60, !tbaa !23
  store i32 %t110, ptr %rv
  br label %ret
bb39:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t115 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t111, ptr %t112)
  store i32 %t115, ptr %l63
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb41, label %ok.117
ok.117:
  br label %bb40
bb40:
  br label %bb46
bb41:
  %t118 = load i32, ptr %l63, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  br i1 %t121, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7f8a5722dd9e6c02_a4d5bfca52fd95f6)
  unreachable
bb44:
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t125 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t123)
  store i32 %t125, ptr %l67
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load i32, ptr %l67, !tbaa !23
  store i32 %t126, ptr %rv
  br label %ret
bb46:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t128 = load ptr, ptr %l3, !tbaa !29
  %t132 = call { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t127, ptr %l5, ptr %t128)
  %t133 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t132, 1
  %t134 = extractvalue { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } %t132, 0
  store i32 %t134, ptr %l73
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb48, label %ok.136
ok.136:
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l72
  br label %bb47
bb47:
  %t137 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l72
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %l68
  br label %bb53
bb48:
  %t138 = load i32, ptr %l73, !tbaa !23
  %t139 = ashr i32 %t138, 16
  %t141 = icmp eq i32 %t139, 1
  br i1 %t141, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_43dc44123b4c1d83_8d4d1e4381628e97)
  unreachable
bb51:
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t143)
  store i32 %t145, ptr %l77
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t146 = load i32, ptr %l77, !tbaa !23
  store i32 %t146, ptr %rv
  br label %ret
bb53:
  %t147 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l68
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l6
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr @.d12 })
  br label %bb54
bb54:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr %"compiler/build:Config", ptr %t148, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  store { i64, ptr } %t151, ptr %l79, !tbaa !27
  %t153 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t153, ptr %l81
  br label %bb55
bb55:
  %t154 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t160)
  store { i64, ptr } %t162, ptr %l83
  br label %bb56
bb56:
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t163)
  store { i64, ptr } %t165, ptr %l85
  br label %bb57
bb57:
  %t166 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 1
  %t170 = extractvalue { i64, ptr } { i64 1, ptr @.d13 }, 0
  %t171 = add i64 %t168, %t170
  %t172 = load { i64, ptr }, ptr %l83, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 5, ptr @.d14 }, 1
  %t177 = extractvalue { i64, ptr } { i64 5, ptr @.d14 }, 0
  %t178 = add i64 %t175, %t177
  %t179 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t167, i64 %t168)
  %t184 = getelementptr i8, ptr %t183, i64 %t168
  call void @olang_textcopy(ptr %t184, ptr %t169, i64 %t170)
  %t185 = getelementptr i8, ptr %t184, i64 %t170
  call void @olang_textcopy(ptr %t185, ptr %t173, i64 %t174)
  %t186 = getelementptr i8, ptr %t185, i64 %t174
  call void @olang_textcopy(ptr %t186, ptr %t176, i64 %t177)
  %t187 = getelementptr i8, ptr %t186, i64 %t177
  call void @olang_textcopy(ptr %t187, ptr %t180, i64 %t181)
  %t188 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t183, 1
  store { i64, ptr } %t189, ptr %l7, !tbaa !27
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l87, !tbaa !29
  store ptr %l6, ptr %l88, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t192, ptr %l89, !tbaa !27
  %t193 = getelementptr %"compiler/build:Program", ptr %l5, i32 0, i32 2
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t196 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t194, { i64, ptr } { i64 0, ptr @.d15 })
  store i1 %t196, ptr %l91
  br label %bb58
bb58:
  %t197 = load i1, ptr %l91, !tbaa !21
  %t198 = xor i1 %t197, true
  %t199 = load ptr, ptr %l87, !tbaa !29
  %t200 = load ptr, ptr %l88, !tbaa !29
  %t201 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t203 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %t199, ptr %t200, { i64, ptr } %t201, i1 %t198)
  store i32 %t203, ptr %l93
  %t204 = icmp ne i32 %t203, 0
  br i1 %t204, label %bb60, label %ok.205
ok.205:
  br label %bb59
bb59:
  br label %bb66
bb60:
  %t206 = load i32, ptr %l93, !tbaa !23
  %t207 = ashr i32 %t206, 16
  %t209 = icmp eq i32 %t207, 1
  br i1 %t209, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_2a07f4f1ea94dfe4_2b76d13ec2f0d080)
  unreachable
bb63:
  store %olang.scope zeroinitializer, ptr %s10
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t214 = extractvalue { i64, ptr } %t212, 1
  %t215 = extractvalue { i64, ptr } %t212, 0
  %t216 = extractvalue { i64, ptr } { i64 27, ptr @.d16 }, 1
  %t217 = extractvalue { i64, ptr } { i64 27, ptr @.d16 }, 0
  %t218 = add i64 %t215, %t217
  %t219 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t218)
  call void @olang_textcopy(ptr %t219, ptr %t214, i64 %t215)
  %t220 = getelementptr i8, ptr %t219, i64 %t215
  call void @olang_textcopy(ptr %t220, ptr %t216, i64 %t217)
  %t221 = insertvalue { i64, ptr } undef, i64 %t218, 0
  %t222 = insertvalue { i64, ptr } %t221, ptr %t219, 1
  %t224 = extractvalue { i64, ptr } %t222, 0
  %t225 = extractvalue { i64, ptr } %t222, 1
  %t226 = mul i64 %t224, 1
  %t227 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t226)
  call void @llvm.memcpy.p0.p0.i64(ptr %t227, ptr %t225, i64 %t226, i1 false)
  %t228 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t229 = insertvalue { i64, ptr } %t228, ptr %t227, 1
  %t232 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t211, { i64, ptr } { i64 2, ptr @.d17 }, { i64, ptr } %t229)
  store { i64, ptr } %t232, ptr %l100
  br label %bb64
bb64:
  %t233 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 0
  %t235 = extractvalue { i64, ptr } %t233, 1
  %t236 = mul i64 %t234, 1
  %t237 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t236)
  call void @llvm.memcpy.p0.p0.i64(ptr %t237, ptr %t235, i64 %t236, i1 false)
  %t238 = insertvalue { i64, ptr } undef, i64 %t234, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t237, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t239)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb66:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr @.d18 })
  br label %bb67
bb67:
  %t242 = load ptr, ptr %l1, !tbaa !29
  %t244 = getelementptr %"compiler/build:Config", ptr %t242, i32 0, i32 12
  %t245 = load i1, ptr %t244, !tbaa !21
  %t247 = xor i1 %t245, true
  br i1 %t247, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s12
  %t249 = load ptr, ptr %l1, !tbaa !29
  %t250 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t251 = extractvalue { i64, ptr } { i64 3, ptr @.d19 }, 1
  %t252 = extractvalue { i64, ptr } { i64 3, ptr @.d19 }, 0
  %t254 = extractvalue { i64, ptr } %t250, 1
  %t255 = extractvalue { i64, ptr } %t250, 0
  %t256 = add i64 %t252, %t255
  %t257 = extractvalue { i64, ptr } { i64 3, ptr @.d20 }, 1
  %t258 = extractvalue { i64, ptr } { i64 3, ptr @.d20 }, 0
  %t259 = add i64 %t256, %t258
  %t260 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t259)
  call void @olang_textcopy(ptr %t260, ptr %t251, i64 %t252)
  %t261 = getelementptr i8, ptr %t260, i64 %t252
  call void @olang_textcopy(ptr %t261, ptr %t254, i64 %t255)
  %t262 = getelementptr i8, ptr %t261, i64 %t255
  call void @olang_textcopy(ptr %t262, ptr %t257, i64 %t258)
  %t263 = insertvalue { i64, ptr } undef, i64 %t259, 0
  %t264 = insertvalue { i64, ptr } %t263, ptr %t260, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = extractvalue { i64, ptr } %t264, 1
  %t268 = mul i64 %t266, 1
  %t269 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t268)
  call void @llvm.memcpy.p0.p0.i64(ptr %t269, ptr %t267, i64 %t268, i1 false)
  %t270 = insertvalue { i64, ptr } undef, i64 %t266, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  %t274 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s12, ptr %s12, ptr %s12, ptr %t249, { i64, ptr } { i64 2, ptr @.d21 }, { i64, ptr } %t271)
  store { i64, ptr } %t274, ptr %l110
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t275 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t276 = extractvalue { i64, ptr } %t275, 0
  %t277 = extractvalue { i64, ptr } %t275, 1
  %t278 = mul i64 %t276, 1
  %t279 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t278)
  call void @llvm.memcpy.p0.p0.i64(ptr %t279, ptr %t277, i64 %t278, i1 false)
  %t280 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t281 = insertvalue { i64, ptr } %t280, ptr %t279, 1
  call void @compiler_2fbuild_2esayln(ptr %s12, { i64, ptr } %t281)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s12)
  br label %bb72
bb72:
  %t283 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t285 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t283)
  store { i64, ptr } %t285, ptr %l114
  br label %bb73
bb73:
  %t286 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t287 = extractvalue { i64, ptr } %t286, 0
  %t288 = extractvalue { i64, ptr } %t286, 1
  %t289 = mul i64 %t287, 1
  %t290 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t289)
  call void @llvm.memcpy.p0.p0.i64(ptr %t290, ptr %t288, i64 %t289, i1 false)
  %t291 = insertvalue { i64, ptr } undef, i64 %t287, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  %t294 = insertvalue [1 x { i64, ptr }] undef, { i64, ptr } %t292, 0
  %t296 = load ptr, ptr @__olang_prog_scope
  %t297 = call ptr @__olang_scope_alloc(ptr %t296, i64 16)
  store [1 x { i64, ptr }] %t294, ptr %t297
  %t298 = insertvalue { i64, ptr } undef, i64 1, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  %t301 = extractvalue { i64, ptr } %t299, 0
  %t302 = extractvalue { i64, ptr } %t299, 1
  %t303 = mul i64 %t301, 16
  %t304 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t303)
  call void @llvm.memcpy.p0.p0.i64(ptr %t304, ptr %t302, i64 %t303, i1 false)
  %t305 = insertvalue { i64, ptr } undef, i64 %t301, 0
  %t306 = insertvalue { i64, ptr } %t305, ptr %t304, 1
  store { i64, ptr } { i64 0, ptr @.d22 }, ptr %l119, !tbaa !27
  %t308 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t309 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t306, { i64, ptr } %t308, i1 false, { i64, ptr } { i64 0, ptr @.d23 })
  %t310 = extractvalue { i32, %"std/os:Output" } %t309, 1
  %t311 = extractvalue { i32, %"std/os:Output" } %t309, 0
  store i32 %t311, ptr %l121
  %t312 = icmp ne i32 %t311, 0
  br i1 %t312, label %bb75, label %ok.313
ok.313:
  store %"std/os:Output" %t310, ptr %l120
  br label %bb74
bb74:
  %t314 = load %"std/os:Output", ptr %l120
  store %"std/os:Output" %t314, ptr %l112
  br label %bb79
bb75:
  %t315 = load i32, ptr %l121, !tbaa !23
  %t316 = ashr i32 %t315, 16
  %t318 = icmp eq i32 %t316, 1
  br i1 %t318, label %bb76, label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_check_failed(ptr @olang_loc_6ec8a2aa167ef9d5_ad6e2c605b8bb111)
  unreachable
bb78:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb79:
  %t321 = load %"std/os:Output", ptr %l112
  store %"std/os:Output" %t321, ptr %l8
  %t322 = getelementptr %"std/os:Output", ptr %l8, i32 0, i32 0
  %t323 = load i32, ptr %t322, !tbaa !23
  %t325 = icmp sgt i32 %t323, 128
  br i1 %t325, label %bb80, label %bb81
bb80:
  store %olang.scope zeroinitializer, ptr %s15
  %t327 = load ptr, ptr %l1, !tbaa !29
  store ptr %t327, ptr %l127, !tbaa !29
  %t328 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t328, ptr %l128, !tbaa !27
  %t329 = getelementptr %"std/os:Output", ptr %l8, i32 0, i32 0
  %t330 = load i32, ptr %t329, !tbaa !23
  %t332 = sub i32 %t330, 128
  %t334 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s15, i32 %t332)
  store { i64, ptr } %t334, ptr %l131
  br label %bb82
bb81:
  br label %bb85
bb82:
  %t335 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } { i64 31, ptr @.d24 }, 1
  %t339 = extractvalue { i64, ptr } { i64 31, ptr @.d24 }, 0
  %t340 = add i64 %t337, %t339
  %t341 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t342 = extractvalue { i64, ptr } %t341, 1
  %t343 = extractvalue { i64, ptr } %t341, 0
  %t344 = add i64 %t340, %t343
  %t345 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 1
  %t346 = extractvalue { i64, ptr } { i64 1, ptr @.d25 }, 0
  %t347 = add i64 %t344, %t346
  %t348 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t347)
  call void @olang_textcopy(ptr %t348, ptr %t336, i64 %t337)
  %t349 = getelementptr i8, ptr %t348, i64 %t337
  call void @olang_textcopy(ptr %t349, ptr %t338, i64 %t339)
  %t350 = getelementptr i8, ptr %t349, i64 %t339
  call void @olang_textcopy(ptr %t350, ptr %t342, i64 %t343)
  %t351 = getelementptr i8, ptr %t350, i64 %t343
  call void @olang_textcopy(ptr %t351, ptr %t345, i64 %t346)
  %t352 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t348, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = extractvalue { i64, ptr } %t353, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  %t361 = load ptr, ptr %l127, !tbaa !29
  %t363 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s15, ptr %s15, ptr %s15, ptr %t361, { i64, ptr } { i64 2, ptr @.d26 }, { i64, ptr } %t360)
  store { i64, ptr } %t363, ptr %l134
  br label %bb83
bb83:
  %t364 = load { i64, ptr }, ptr %l134, !tbaa !27
  %t365 = extractvalue { i64, ptr } %t364, 0
  %t366 = extractvalue { i64, ptr } %t364, 1
  %t367 = mul i64 %t365, 1
  %t368 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t367)
  call void @llvm.memcpy.p0.p0.i64(ptr %t368, ptr %t366, i64 %t367, i1 false)
  %t369 = insertvalue { i64, ptr } undef, i64 %t365, 0
  %t370 = insertvalue { i64, ptr } %t369, ptr %t368, 1
  call void @compiler_2fbuild_2esayln(ptr %s15, { i64, ptr } %t370)
  br label %bb84
bb84:
  call void @__olang_scope_close(ptr %s15)
  br label %bb85
bb85:
  %t372 = getelementptr %"std/os:Output", ptr %l8, i32 0, i32 0
  %t373 = load i32, ptr %t372, !tbaa !23
  %t375 = icmp eq i32 %t373, 0
  br i1 %t375, label %bb86, label %bb87
bb86:
  store i32 0, ptr %l138, !tbaa !23
  br label %bb88
bb87:
  store i32 1, ptr %l138, !tbaa !23
  br label %bb88
bb88:
  call void @__olang_scope_close(ptr %s0)
  %t377 = load i32, ptr %l138, !tbaa !23
  store i32 %t377, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l16 = alloca i1
  %l17 = alloca %"compiler/diag:Diagnostics"
  %l18 = alloca %"compiler/build:Config"
  %l20 = alloca %"compiler/olang:CommandLine"
  %l24 = alloca %"compiler/olang:CommandLine"
  %l25 = alloca i32
  %l29 = alloca i32
  %l33 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l37 = alloca i32
  %l41 = alloca i32
  %l43 = alloca i32
  %l48 = alloca i64
  %l50 = alloca ptr
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l56 = alloca i32
  %l57 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l61 = alloca i32
  %l65 = alloca i32
  %l67 = alloca i32
  %l72 = alloca i32
  %l77 = alloca { i64, ptr }
  %l81 = alloca i32
  %l86 = alloca i32
  %l90 = alloca ptr
  %l91 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l93 = alloca i32
  %l96 = alloca { i64, ptr }
  %l100 = alloca i32
  %l102 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca i32
  %l117 = alloca { i64, ptr }
  %l120 = alloca i32
  %l124 = alloca ptr
  %l125 = alloca ptr
  %l126 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l129 = alloca { i64, ptr }
  %l131 = alloca i32
  %l135 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l137 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l145 = alloca { i64, ptr }
  %l146 = alloca i32
  %l155 = alloca { i64, ptr }
  %l167 = alloca ptr
  %l168 = alloca ptr
  %l169 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l172 = alloca { i64, ptr }
  %l174 = alloca i32
  %l180 = alloca { i64, ptr }
  %l183 = alloca i32
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l186 = alloca i32
  %l189 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l198 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l16
  br label %bb1
bb1:
  %t3 = load i1, ptr %l16, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l17, ptr %t2, i64 200, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l17, i64 200, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %t4, i64 328, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l18, i64 328, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 11
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  %t14 = extractvalue { i32, %"compiler/olang:CommandLine" } %t13, 1
  %t15 = extractvalue { i32, %"compiler/olang:CommandLine" } %t13, 0
  store i32 %t15, ptr %l25
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17
ok.17:
  store %"compiler/olang:CommandLine" %t14, ptr %l24
  br label %bb4
bb4:
  %t18 = load %"compiler/olang:CommandLine", ptr %l24
  store %"compiler/olang:CommandLine" %t18, ptr %l20
  br label %bb10
bb5:
  %t19 = load i32, ptr %l25, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_edee8f0aed3cec_fa0c04393fa4bb00)
  unreachable
bb8:
  %t25 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t25, ptr %l29
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l29, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb10:
  %t27 = load %"compiler/olang:CommandLine", ptr %l20
  store %"compiler/olang:CommandLine" %t27, ptr %l4
  %t28 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %s0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t38 = extractvalue { i32, { i64, ptr } } %t37, 1
  %t39 = extractvalue { i32, { i64, ptr } } %t37, 0
  store i32 %t39, ptr %l37
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb14, label %ok.41
ok.41:
  store { i64, ptr } %t38, ptr %l36
  br label %bb13
bb12:
  br label %bb21
bb13:
  %t42 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t42, ptr %l33, !tbaa !27
  br label %bb19
bb14:
  %t43 = load i32, ptr %l37, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  br i1 %t46, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_73743ad8a26b819d_7c035f5ad83f9b91)
  unreachable
bb17:
  %t49 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t49, ptr %l41
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i32, ptr %l41, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb19:
  %t51 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t54 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t51)
  store i32 %t54, ptr %l43
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i32, ptr %l43, !tbaa !23
  store i32 %t55, ptr %rv
  br label %ret
bb21:
  %t56 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t65 = call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t63)
  store i64 %t65, ptr %l48
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t66 = load i64, ptr %l48, !tbaa !24
  %t67 = icmp eq i64 %t66, 1
  br i1 %t67, label %bb25, label %bb26
bb25:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l50, !tbaa !29
  store ptr %l3, ptr %l51, !tbaa !29
  %t70 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t72 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %s0, ptr %s0, ptr %t70, i64 0)
  store { i64, ptr } %t72, ptr %l53
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t73 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l50, !tbaa !29
  %t76 = load ptr, ptr %l51, !tbaa !29
  %t77 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t80 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t75, ptr %t76, { i64, ptr } %t77, { i64, ptr } %t74, ptr %l2)
  store i32 %t80, ptr %l56
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i32, ptr %l56, !tbaa !23
  store i32 %t81, ptr %rv
  br label %ret
bb29:
  %t82 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t86 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %s0, ptr %s0, ptr %s4, { i64, ptr } %t83, ptr %l2)
  %t87 = extractvalue { i32, { i64, ptr } } %t86, 1
  %t88 = extractvalue { i32, { i64, ptr } } %t86, 0
  store i32 %t88, ptr %l61
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb31, label %ok.90
ok.90:
  store { i64, ptr } %t87, ptr %l60
  br label %bb30
bb30:
  %t91 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t91, ptr %l57, !tbaa !27
  br label %bb36
bb31:
  %t92 = load i32, ptr %l61, !tbaa !23
  %t93 = ashr i32 %t92, 16
  %t95 = icmp eq i32 %t93, 1
  br i1 %t95, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_1ed22c7d3ed33c86_4a77ed05ffa3b9fa)
  unreachable
bb34:
  %t98 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t98, ptr %l65
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load i32, ptr %l65, !tbaa !23
  store i32 %t99, ptr %rv
  br label %ret
bb36:
  %t100 = load { i64, ptr }, ptr %l57, !tbaa !27
  %t103 = call i32 @compiler_2folang_2ewrite(ptr %s4, { i64, ptr } %t100)
  store i32 %t103, ptr %l67
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load i32, ptr %l67, !tbaa !23
  store i32 %t104, ptr %rv
  br label %ret
bb38:
  %t105 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t110 = icmp eq i64 %t106, %t107
  br i1 %t110, label %bb39, label %bb40
bb39:
  %t113 = call i32 @compiler_2folang_2eformat(ptr %s0, ptr %l4)
  store i32 %t113, ptr %l72
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t114 = load i32, ptr %l72, !tbaa !23
  store i32 %t114, ptr %rv
  br label %ret
bb42:
  %t115 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t120 = icmp eq i64 %t116, %t117
  br i1 %t120, label %bb43, label %bb44
bb43:
  %t122 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t124 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %t122)
  store { i64, ptr } %t124, ptr %l77
  br label %bb45
bb44:
  br label %bb47
bb45:
  %t125 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t127 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t128 = load { i64, ptr }, ptr %t127, !tbaa !27
  %t129 = load { i64, ptr }, ptr %l77, !tbaa !27
  %t133 = call i32 @compiler_2fsession_2eDocMode(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t129, { i64, ptr } %t126, { i64, ptr } %t128, ptr %l3)
  store i32 %t133, ptr %l81
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t134 = load i32, ptr %l81, !tbaa !23
  store i32 %t134, ptr %rv
  br label %ret
bb47:
  %t135 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t136 = load i64, ptr %t135, !tbaa !24
  %t137 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t140 = icmp eq i64 %t136, %t137
  br i1 %t140, label %bb48, label %bb49
bb48:
  %t143 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t143, ptr %l86
  br label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t144 = load i32, ptr %l86, !tbaa !23
  store i32 %t144, ptr %rv
  br label %ret
bb51:
  %t145 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t146 = load i64, ptr %t145, !tbaa !24
  %t147 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t150 = icmp eq i64 %t146, %t147
  br i1 %t150, label %bb52, label %bb53
bb52:
  store %olang.scope zeroinitializer, ptr %s10
  store ptr %l3, ptr %l90, !tbaa !29
  %t152 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s10, ptr %s10, { i64, ptr } { i64 14, ptr @.d27 })
  %t153 = extractvalue { i32, { i64, ptr } } %t152, 1
  %t154 = extractvalue { i32, { i64, ptr } } %t152, 0
  store i32 %t154, ptr %l93
  %t155 = icmp ne i32 %t154, 0
  br i1 %t155, label %bb55, label %ok.156
ok.156:
  store { i64, ptr } %t153, ptr %l92
  br label %bb54
bb53:
  br label %bb61
bb54:
  %t157 = load { i64, ptr }, ptr %l92, !tbaa !27
  store { i64, ptr } %t157, ptr %l91, !tbaa !27
  br label %bb59
bb55:
  %t158 = load i32, ptr %l93, !tbaa !23
  %t159 = ashr i32 %t158, 16
  %t161 = icmp eq i32 %t159, 1
  br i1 %t161, label %bb56, label %bb57
bb56:
  br label %bb58
bb57:
  call void @__olang_check_failed(ptr @olang_loc_d3277a20ab134767_f91655e31439de7b)
  unreachable
bb58:
  %t163 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t163, ptr %l96, !tbaa !27
  %t164 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t165 = load ptr, ptr %t164, !tbaa !27
  %t166 = getelementptr { i64, ptr }, ptr %t165, i64 0
  %t167 = load { i64, ptr }, ptr %t166, !tbaa !37
  %t169 = extractvalue { i64, ptr } %t167, 1
  %t170 = extractvalue { i64, ptr } %t167, 0
  %t171 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t170)
  call void @olang_textcopy(ptr %t171, ptr %t169, i64 %t170)
  %t172 = insertvalue { i64, ptr } undef, i64 %t170, 0
  %t173 = insertvalue { i64, ptr } %t172, ptr %t171, 1
  %t175 = extractvalue { i64, ptr } %t173, 0
  %t176 = extractvalue { i64, ptr } %t173, 1
  %t177 = mul i64 %t175, 1
  %t178 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t177)
  call void @llvm.memcpy.p0.p0.i64(ptr %t178, ptr %t176, i64 %t177, i1 false)
  %t179 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t180 = insertvalue { i64, ptr } %t179, ptr %t178, 1
  store { i64, ptr } %t180, ptr %l91, !tbaa !27
  br label %bb59
bb59:
  %t182 = load ptr, ptr %l90, !tbaa !29
  %t183 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t184 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s10, ptr %t182, { i64, ptr } %t183)
  store i32 %t184, ptr %l100
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t185 = load i32, ptr %l100, !tbaa !23
  store i32 %t185, ptr %rv
  br label %ret
bb61:
  %t186 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t188 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %t186)
  store { i64, ptr } %t188, ptr %l102
  br label %bb62
bb62:
  %t189 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t189, ptr %l7, !tbaa !27
  %t190 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t191 = load i64, ptr %t190, !tbaa !24
  %t192 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t195 = icmp eq i64 %t191, %t192
  br i1 %t195, label %bb63, label %bb64
bb63:
  %t197 = load ptr, ptr %l1, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t198, ptr %l108, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l108, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = getelementptr { i64, ptr }, ptr %t200, i64 0
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !37
  %t207 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t197, ptr %l3, { i64, ptr } %t202, ptr %l2)
  store i32 %t207, ptr %l111
  br label %bb65
bb64:
  br label %bb66
bb65:
  call void @__olang_scope_close(ptr %s0)
  %t208 = load i32, ptr %l111, !tbaa !23
  store i32 %t208, ptr %rv
  br label %ret
bb66:
  %t209 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  br i1 %t214, label %bb67, label %bb68
bb67:
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t217 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t217, ptr %l117, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l117, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %t219, i64 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !37
  %t226 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t216, ptr %l3, { i64, ptr } %t221, ptr %l2)
  store i32 %t226, ptr %l120
  br label %bb69
bb68:
  br label %bb70
bb69:
  call void @__olang_scope_close(ptr %s0)
  %t227 = load i32, ptr %l120, !tbaa !23
  store i32 %t227, ptr %rv
  br label %ret
bb70:
  %t228 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t229 = load i64, ptr %t228, !tbaa !24
  %t230 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t233 = icmp eq i64 %t229, %t230
  br i1 %t233, label %bb71, label %bb72
bb71:
  %t235 = load ptr, ptr %l1, !tbaa !29
  store ptr %t235, ptr %l124, !tbaa !29
  store ptr %l3, ptr %l125, !tbaa !29
  %t236 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t236, ptr %l126, !tbaa !27
  %t237 = getelementptr { i64, ptr }, ptr %l126, i32 0, i32 1
  %t238 = load ptr, ptr %t237, !tbaa !27
  %t239 = getelementptr { i64, ptr }, ptr %t238, i64 0
  %t240 = load { i64, ptr }, ptr %t239, !tbaa !37
  store { i64, ptr } %t240, ptr %l127, !tbaa !27
  %t241 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 4
  %t243 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %t241)
  store { i64, ptr } %t243, ptr %l129
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t244 = load ptr, ptr %l124, !tbaa !29
  %t245 = load ptr, ptr %l125, !tbaa !29
  %t246 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t249 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t244, ptr %t245, { i64, ptr } %t246, { i64, ptr } %t247, ptr %l2)
  store i32 %t249, ptr %l131
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  %t250 = load i32, ptr %l131, !tbaa !23
  store i32 %t250, ptr %rv
  br label %ret
bb75:
  %t251 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t252 = load i64, ptr %t251, !tbaa !24
  %t253 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t256 = icmp eq i64 %t252, %t253
  br i1 %t256, label %bb76, label %bb77
bb76:
  store %olang.scope zeroinitializer, ptr %s15
  %t258 = load ptr, ptr @__olang_prog_scope
  %t259 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %t258)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t259, ptr %l135
  br label %bb78
bb77:
  br label %bb98
bb78:
  %t260 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l135
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t260, ptr %l8
  %t261 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t261, ptr %l137, !tbaa !27
  %t262 = getelementptr { i64, ptr }, ptr %l137, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %t263, i64 0
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !37
  %t267 = extractvalue { i64, ptr } %t265, 1
  %t268 = extractvalue { i64, ptr } %t265, 0
  %t269 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t268)
  call void @olang_textcopy(ptr %t269, ptr %t267, i64 %t268)
  %t270 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t271 = insertvalue { i64, ptr } %t270, ptr %t269, 1
  %t273 = extractvalue { i64, ptr } %t271, 0
  %t274 = extractvalue { i64, ptr } %t271, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %s15, ptr %s15, ptr %l8, { i64, ptr } %t278)
  br label %bb79
bb79:
  %t281 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 4
  store ptr %t281, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb80
bb80:
  store %olang.scope zeroinitializer, ptr %s18
  %t283 = load ptr, ptr %l9, !tbaa !29
  %t284 = load i64, ptr %l10, !tbaa !24
  %t287 = call { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %s0, ptr %t283, i64 %t284)
  %t288 = extractvalue { i32, { i64, ptr } } %t287, 1
  %t289 = extractvalue { i32, { i64, ptr } } %t287, 0
  store i32 %t289, ptr %l146
  %t290 = icmp ne i32 %t289, 0
  br i1 %t290, label %bb82, label %ok.291
ok.291:
  store { i64, ptr } %t288, ptr %l145
  br label %bb81
bb81:
  %t292 = load { i64, ptr }, ptr %l145, !tbaa !27
  store { i64, ptr } %t292, ptr %l142, !tbaa !27
  br label %bb86
bb82:
  %t293 = load i32, ptr %l146, !tbaa !23
  %t294 = ashr i32 %t293, 16
  %t296 = icmp eq i32 %t294, 1
  br i1 %t296, label %bb83, label %bb84
bb83:
  br label %bb85
bb84:
  call void @__olang_check_failed(ptr @olang_loc_9b283db8f21a3c50_1ff4bf88356440dc)
  unreachable
bb85:
  call void @__olang_scope_close(ptr %s18)
  br label %bb95
bb86:
  %t298 = load { i64, ptr }, ptr %l142, !tbaa !27
  store { i64, ptr } %t298, ptr %l11, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t301 = extractvalue { i64, ptr } %t299, 0
  store i64 %t301, ptr %l12, !tbaa !24
  store i64 0, ptr %l13, !tbaa !24
  br label %bb87
bb87:
  store %olang.scope zeroinitializer, ptr %s19
  %t303 = load i64, ptr %l13, !tbaa !24
  %t304 = load i64, ptr %l12, !tbaa !24
  %t307 = icmp slt i64 %t303, %t304
  %t309 = xor i1 %t307, true
  br i1 %t309, label %bb88, label %bb89
bb88:
  call void @__olang_scope_close(ptr %s19)
  br label %bb93
bb89:
  br label %bb90
bb90:
  %t311 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t311, ptr %l155, !tbaa !27
  %t312 = load i64, ptr %l13, !tbaa !24
  %t314 = getelementptr { i64, ptr }, ptr %l155, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr { i64, ptr }, ptr %t315, i64 %t312
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !37
  %t321 = extractvalue { i64, ptr } %t317, 1
  %t322 = extractvalue { i64, ptr } %t317, 0
  %t323 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t322)
  call void @olang_textcopy(ptr %t323, ptr %t321, i64 %t322)
  %t324 = insertvalue { i64, ptr } undef, i64 %t322, 0
  %t325 = insertvalue { i64, ptr } %t324, ptr %t323, 1
  %t327 = extractvalue { i64, ptr } %t325, 0
  %t328 = extractvalue { i64, ptr } %t325, 1
  %t329 = mul i64 %t327, 1
  %t330 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t329)
  call void @llvm.memcpy.p0.p0.i64(ptr %t330, ptr %t328, i64 %t329, i1 false)
  %t331 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t332 = insertvalue { i64, ptr } %t331, ptr %t330, 1
  call void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %s15, ptr %s15, ptr %l8, { i64, ptr } %t332)
  br label %bb91
bb91:
  call void @__olang_scope_close(ptr %s19)
  br label %bb92
bb92:
  %t335 = load i64, ptr %l13, !tbaa !24
  %t337 = add i64 %t335, 1
  store i64 %t337, ptr %l13, !tbaa !24
  br label %bb87
bb93:
  %t339 = load i64, ptr %l10, !tbaa !24
  %t340 = load i64, ptr %l12, !tbaa !24
  %t343 = add i64 %t339, %t340
  store i64 %t343, ptr %l10, !tbaa !24
  call void @__olang_scope_close(ptr %s18)
  br label %bb94
bb94:
  br label %bb80
bb95:
  %t345 = load ptr, ptr %l1, !tbaa !29
  store ptr %t345, ptr %l167, !tbaa !29
  store ptr %l3, ptr %l168, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t346, ptr %l169, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %t348, i64 0
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !37
  store { i64, ptr } %t350, ptr %l170, !tbaa !27
  %t352 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s15, ptr %s15, ptr %l8)
  store { i64, ptr } %t352, ptr %l172
  br label %bb96
bb96:
  %t353 = load ptr, ptr %l167, !tbaa !29
  %t354 = load ptr, ptr %l168, !tbaa !29
  %t355 = load { i64, ptr }, ptr %l170, !tbaa !27
  %t356 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t358 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s15, ptr %t353, ptr %t354, { i64, ptr } %t355, { i64, ptr } %t356, ptr %l2)
  store i32 %t358, ptr %l174
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t359 = load i32, ptr %l174, !tbaa !23
  store i32 %t359, ptr %rv
  br label %ret
bb98:
  %t360 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t362 = extractvalue { i64, ptr } %t360, 0
  %t364 = icmp eq i64 %t362, 1
  br i1 %t364, label %bb99, label %bb100
bb99:
  %t366 = load ptr, ptr %l1, !tbaa !29
  %t367 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t367, ptr %l180, !tbaa !27
  %t368 = getelementptr { i64, ptr }, ptr %l180, i32 0, i32 1
  %t369 = load ptr, ptr %t368, !tbaa !27
  %t370 = getelementptr { i64, ptr }, ptr %t369, i64 0
  %t371 = load { i64, ptr }, ptr %t370, !tbaa !37
  %t376 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t366, ptr %l3, { i64, ptr } %t371, ptr %l2)
  store i32 %t376, ptr %l183
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_scope_close(ptr %s0)
  %t377 = load i32, ptr %l183, !tbaa !23
  store i32 %t377, ptr %rv
  br label %ret
bb102:
  %t378 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr @.d28 })
  %t379 = extractvalue { i32, { i64, ptr } } %t378, 1
  %t380 = extractvalue { i32, { i64, ptr } } %t378, 0
  store i32 %t380, ptr %l186
  %t381 = icmp ne i32 %t380, 0
  br i1 %t381, label %bb104, label %ok.382
ok.382:
  store { i64, ptr } %t379, ptr %l185
  br label %bb103
bb103:
  %t383 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t383, ptr %l184, !tbaa !27
  br label %bb108
bb104:
  %t384 = load i32, ptr %l186, !tbaa !23
  %t385 = ashr i32 %t384, 16
  %t387 = icmp eq i32 %t385, 1
  br i1 %t387, label %bb105, label %bb106
bb105:
  br label %bb107
bb106:
  call void @__olang_check_failed(ptr @olang_loc_50c080632384d1e1_b715ab696a7cda0d)
  unreachable
bb107:
  %t389 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t389, ptr %l189, !tbaa !27
  %t390 = getelementptr { i64, ptr }, ptr %l189, i32 0, i32 1
  %t391 = load ptr, ptr %t390, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %t391, i64 0
  %t393 = load { i64, ptr }, ptr %t392, !tbaa !37
  %t395 = extractvalue { i64, ptr } %t393, 1
  %t396 = extractvalue { i64, ptr } %t393, 0
  %t397 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t396)
  call void @olang_textcopy(ptr %t397, ptr %t395, i64 %t396)
  %t398 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  store { i64, ptr } %t406, ptr %l184, !tbaa !27
  br label %bb108
bb108:
  %t408 = load { i64, ptr }, ptr %l184, !tbaa !27
  store ptr %l3, ptr %l193, !tbaa !29
  store { i64, ptr } %t408, ptr %l194, !tbaa !27
  %t410 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t412 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %s0, ptr %s0, ptr %t410)
  store { i64, ptr } %t412, ptr %l196
  br label %bb109
bb109:
  %t413 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t414 = load ptr, ptr %l193, !tbaa !29
  %t415 = load { i64, ptr }, ptr %l194, !tbaa !27
  %t416 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t418 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t414, { i64, ptr } %t415, { i64, ptr } %t416, { i64, ptr } %t413)
  store i32 %t418, ptr %l198
  br label %bb110
bb110:
  call void @__olang_scope_close(ptr %s0)
  %t419 = load i32, ptr %l198, !tbaa !23
  store i32 %t419, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2femit_3aObject_3e_2eRunFrom_3ccompiler_2femit_3aObject_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %l1 = alloca i64
  %l2 = alloca ptr
  %l9 = alloca i1
  %l17 = alloca { i64, ptr }
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l26 = alloca ptr
  %l30 = alloca i64
  %l34 = alloca { i64, ptr }
  %rv = alloca { i32, { i64, ptr } }
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t3 = getelementptr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %a0, i32 0, i32 0
  %t4 = load ptr, ptr %t3, !tbaa !29
  store ptr %t4, ptr %l2, !tbaa !29
  %t6 = load i64, ptr %l1, !tbaa !24
  %t7 = load ptr, ptr %l2, !tbaa !29
  %t9 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t7, i32 0, i32 7
  %t10 = load i64, ptr %t9, !tbaa !24
  %t13 = icmp sge i64 %t6, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  store i1 true, ptr %l9, !tbaa !21
  br label %bb3
bb2:
  %t15 = load i64, ptr %l1, !tbaa !24
  %t17 = icmp slt i64 %t15, 0
  store i1 %t17, ptr %l9, !tbaa !21
  br label %bb3
bb3:
  %t19 = load i1, ptr %l9, !tbaa !21
  br i1 %t19, label %bb4, label %bb5
bb4:
  %t21 = insertvalue { i32, { i64, ptr } } zeroinitializer, i32 65536, 0
  store { i32, { i64, ptr } } %t21, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l2, !tbaa !29
  %t24 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t22, i32 0, i32 2
  %t25 = load i64, ptr %t24, !tbaa !24
  %t27 = icmp eq i64 %t25, 1
  br i1 %t27, label %bb7, label %bb8
bb7:
  %t29 = load ptr, ptr %l2, !tbaa !29
  %t31 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t29, i32 0, i32 1
  %t32 = load { i64, ptr }, ptr %t31, !tbaa !27
  store { i64, ptr } %t32, ptr %l17, !tbaa !27
  %t33 = load i64, ptr %l1, !tbaa !24
  store i64 %t33, ptr %l18, !tbaa !24
  %t34 = load ptr, ptr %l2, !tbaa !29
  %t36 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t34, i32 0, i32 5
  %t37 = load i64, ptr %t36, !tbaa !24
  store i64 %t37, ptr %l20, !tbaa !24
  %t38 = load { i64, ptr }, ptr %l17, !tbaa !27
  %t39 = extractvalue { i64, ptr } %t38, 0
  store i64 %t39, ptr %l21, !tbaa !24
  %t40 = load i64, ptr %l18, !tbaa !24
  %t41 = icmp sge i64 %t40, 0
  br i1 %t41, label %bb9, label %bb10
bb8:
  br label %bb15
bb9:
  %t43 = load i64, ptr %l18, !tbaa !24
  %t44 = load i64, ptr %l20, !tbaa !24
  %t45 = icmp sle i64 %t43, %t44
  br i1 %t45, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_f9ae395f44564124_2a4ae2287bd25598)
  unreachable
bb11:
  %t47 = load i64, ptr %l20, !tbaa !24
  %t48 = load i64, ptr %l21, !tbaa !24
  %t49 = icmp sle i64 %t47, %t48
  br i1 %t49, label %bb13, label %bb14
bb12:
  call void @__olang_check_failed(ptr @olang_loc_f9ae395f44564124_2a4ae2287bd25598)
  unreachable
bb13:
  %t51 = getelementptr { i64, ptr }, ptr %l17, i32 0, i32 1
  %t52 = load ptr, ptr %t51, !tbaa !27
  %t53 = load i64, ptr %l18, !tbaa !24
  %t54 = load i64, ptr %l20, !tbaa !24
  %t55 = getelementptr %"compiler/emit:Object", ptr %t52, i64 %t53
  %t56 = sub i64 %t54, %t53
  %t57 = insertvalue { i64, ptr } undef, i64 %t56, 0
  %t58 = insertvalue { i64, ptr } %t57, ptr %t55, 1
  %t60 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t58, 1
  store { i32, { i64, ptr } } %t60, ptr %rv
  br label %ret
bb14:
  call void @__olang_check_failed(ptr @olang_loc_f9ae395f44564124_2a4ae2287bd25598)
  unreachable
bb15:
  %t61 = load ptr, ptr %l2, !tbaa !29
  store ptr %t61, ptr %l26, !tbaa !29
  %t62 = load i64, ptr %l1, !tbaa !24
  %t63 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t66 = add i64 %t62, %t63
  %t68 = call i64 @std_2fprelude_2flist_2ehighBit(i64 %t66)
  store i64 %t68, ptr %l30
  br label %bb16
bb16:
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunkLog, !tbaa !24
  %t70 = load i64, ptr %l30, !tbaa !24
  %t72 = sub i64 %t70, %t69
  %t73 = load i64, ptr %l1, !tbaa !24
  %t74 = load ptr, ptr %l26, !tbaa !29
  %t77 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2femit_3aObject_3e_2e_H3b54a90ae949ae1602b60e2d0b7e82b6(ptr %v0, ptr %t74, i64 %t72, i64 %t73)
  store { i64, ptr } %t77, ptr %l34
  br label %bb17
bb17:
  %t78 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t79 = insertvalue { i32, { i64, ptr } } zeroinitializer, { i64, ptr } %t78, 1
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3ccompiler_2flower_3aGap_3e_2eLen_3ccompiler_2flower_3aGap_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3ccompiler_2femit_3aObject_3e_2e_H3b54a90ae949ae1602b60e2d0b7e82b6(ptr %v0, ptr %a0, i64 %a1, i64 %a2) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l10 = alloca { i64, ptr }
  %l11 = alloca { i64, ptr }
  %l16 = alloca i64
  %l18 = alloca i64
  %l20 = alloca i64
  %l21 = alloca i64
  %l28 = alloca { i64, ptr }
  %l29 = alloca { i64, ptr }
  %l34 = alloca i64
  %l36 = alloca i64
  %l39 = alloca { i64, ptr }
  %l42 = alloca i64
  %l43 = alloca i64
  %rv = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  store i64 %a2, ptr %l2
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t2, i32 0, i32 2
  %t5 = load i64, ptr %t4, !tbaa !24
  %t7 = sub i64 %t5, 1
  %t10 = icmp eq i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t13 = load i64, ptr %l1, !tbaa !24
  %t16 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t12, i64 %t13)
  store { i64, ptr } %t16, ptr %l10
  br label %bb3
bb2:
  br label %bb10
bb3:
  %t17 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t17, ptr %l11, !tbaa !27
  %t18 = load i64, ptr %l2, !tbaa !24
  %t19 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t22 = add i64 %t18, %t19
  %t23 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t24 = load i64, ptr %l1, !tbaa !24
  store i64 %t24, ptr %l16, !tbaa !24
  %t26 = load i64, ptr %l16, !tbaa !24
  %t27 = load i64, ptr %l16, !tbaa !24
  %t28 = shl i64 %t23, %t27
  %t31 = sub i64 %t22, %t28
  store i64 %t31, ptr %l18, !tbaa !24
  %t32 = load ptr, ptr %l0, !tbaa !29
  %t34 = getelementptr %"std/prelude/list:listState.9783095779ea18337775adeb6569839d", ptr %t32, i32 0, i32 5
  %t35 = load i64, ptr %t34, !tbaa !24
  store i64 %t35, ptr %l20, !tbaa !24
  %t36 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l21, !tbaa !24
  %t38 = load i64, ptr %l18, !tbaa !24
  %t39 = icmp sge i64 %t38, 0
  br i1 %t39, label %bb4, label %bb5
bb4:
  %t41 = load i64, ptr %l18, !tbaa !24
  %t42 = load i64, ptr %l20, !tbaa !24
  %t43 = icmp sle i64 %t41, %t42
  br i1 %t43, label %bb6, label %bb7
bb5:
  call void @__olang_check_failed(ptr @olang_loc_2ce16293fd874efe_ee839ffb494569fa)
  unreachable
bb6:
  %t45 = load i64, ptr %l20, !tbaa !24
  %t46 = load i64, ptr %l21, !tbaa !24
  %t47 = icmp sle i64 %t45, %t46
  br i1 %t47, label %bb8, label %bb9
bb7:
  call void @__olang_check_failed(ptr @olang_loc_2ce16293fd874efe_ee839ffb494569fa)
  unreachable
bb8:
  %t49 = getelementptr { i64, ptr }, ptr %l11, i32 0, i32 1
  %t50 = load ptr, ptr %t49, !tbaa !27
  %t51 = load i64, ptr %l18, !tbaa !24
  %t52 = load i64, ptr %l20, !tbaa !24
  %t53 = getelementptr %"compiler/emit:Object", ptr %t50, i64 %t51
  %t54 = sub i64 %t52, %t51
  %t55 = insertvalue { i64, ptr } undef, i64 %t54, 0
  %t56 = insertvalue { i64, ptr } %t55, ptr %t53, 1
  store { i64, ptr } %t56, ptr %rv
  br label %ret
bb9:
  call void @__olang_check_failed(ptr @olang_loc_2ce16293fd874efe_ee839ffb494569fa)
  unreachable
bb10:
  %t58 = load ptr, ptr %l0, !tbaa !29
  %t59 = load i64, ptr %l1, !tbaa !24
  %t62 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t58, i64 %t59)
  store { i64, ptr } %t62, ptr %l28
  br label %bb11
bb11:
  %t63 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t63, ptr %l29, !tbaa !27
  %t64 = load i64, ptr %l2, !tbaa !24
  %t65 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t68 = add i64 %t64, %t65
  %t69 = load i64, ptr @G_2estd_2fprelude_2flist_2efirstChunk, !tbaa !24
  %t70 = load i64, ptr %l1, !tbaa !24
  store i64 %t70, ptr %l34, !tbaa !24
  %t72 = load i64, ptr %l34, !tbaa !24
  %t73 = load i64, ptr %l34, !tbaa !24
  %t74 = shl i64 %t69, %t73
  %t77 = sub i64 %t68, %t74
  store i64 %t77, ptr %l36, !tbaa !24
  %t78 = load ptr, ptr %l0, !tbaa !29
  %t79 = load i64, ptr %l1, !tbaa !24
  %t82 = call { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %t78, i64 %t79)
  store { i64, ptr } %t82, ptr %l39
  br label %bb12
bb12:
  %t83 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t83, 0
  store i64 %t86, ptr %l42, !tbaa !24
  %t87 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t88 = extractvalue { i64, ptr } %t87, 0
  store i64 %t88, ptr %l43, !tbaa !24
  %t89 = load i64, ptr %l36, !tbaa !24
  %t90 = icmp sge i64 %t89, 0
  br i1 %t90, label %bb13, label %bb14
bb13:
  %t92 = load i64, ptr %l36, !tbaa !24
  %t93 = load i64, ptr %l42, !tbaa !24
  %t94 = icmp sle i64 %t92, %t93
  br i1 %t94, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_d200b8d2ab9dd17b_b944da2a7f03fd7)
  unreachable
bb15:
  %t96 = load i64, ptr %l42, !tbaa !24
  %t97 = load i64, ptr %l43, !tbaa !24
  %t98 = icmp sle i64 %t96, %t97
  br i1 %t98, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_d200b8d2ab9dd17b_b944da2a7f03fd7)
  unreachable
bb17:
  %t100 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t101 = load ptr, ptr %t100, !tbaa !27
  %t102 = load i64, ptr %l36, !tbaa !24
  %t103 = load i64, ptr %l42, !tbaa !24
  %t104 = getelementptr %"compiler/emit:Object", ptr %t101, i64 %t102
  %t105 = sub i64 %t103, %t102
  %t106 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t107 = insertvalue { i64, ptr } %t106, ptr %t104, 1
  store { i64, ptr } %t107, ptr %rv
  br label %ret
bb18:
  call void @__olang_check_failed(ptr @olang_loc_d200b8d2ab9dd17b_b944da2a7f03fd7)
  unreachable
ret:
  %rr = load { i64, ptr }, ptr %rv
  ret { i64, ptr } %rr
}

declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
chunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant [7 x i8] c"compile"
@.d1 = private constant [0 x i8] c""
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant [1 x i8] c"/"
@.d3 = private constant [0 x i8] c""
@.d4 = private constant [4 x i8] c"link"
@.d5 = private constant [0 x i8] c""
@.d6 = private constant [6 x i8] c"built "
@.d7 = private constant [2 x i8] c"32"
@.d8 = private constant [0 x i8] c""
@.d9 = private constant [6 x i8] c"built "
@.d10 = private constant [2 x i8] c"32"
@__olang_prog_scope = external thread_local(initialexec) global ptr
define linkonce_odr %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @olang_2eHelperKind_2eZero_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0) #0 {
entry:
  %l0 = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  %rv = alloca %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b"
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr @__olang_prog_scope
  %t2 = call %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %t1)
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t2, ptr %l0
  br label %bb1
bb1:
  %t3 = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l0
  store %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %t3, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %rv
  ret %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" %rr
}

@.d11 = private constant [20 x i8] c"it cannot be started"
@.d12 = private constant [7 x i8] c"compile"
@.d13 = private constant [1 x i8] c"/"
@.d14 = private constant [5 x i8] c"_test"
@.d15 = private constant [0 x i8] c""
@.d16 = private constant [27 x i8] c": native compilation failed"
@.d17 = private constant [2 x i8] c"31"
@.d18 = private constant [4 x i8] c"link"
@.d19 = private constant [3 x i8] c"== "
@.d20 = private constant [3 x i8] c" =="
@.d21 = private constant [2 x i8] c"36"
@.d22 = private constant [0 x i8] c""
@.d23 = private constant [0 x i8] c""
@.d24 = private constant [31 x i8] c": the tests ended by a signal ("
@.d25 = private constant [1 x i8] c")"
@.d26 = private constant [2 x i8] c"31"
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d27 = private constant [14 x i8] c"/proc/self/exe"
@.d28 = private constant [14 x i8] c"/proc/self/exe"
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13a46f17cfa63227_b1895594948889cb = external constant [0 x i8]
declare { i32, %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_fd88121d790f24ac_3e6efb3076496690 = external constant [0 x i8]
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3)
@olang_loc_a50415520eaa75d_89ededae97ad6121 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
@olang_loc_2f392dba8d9257c8_60d4d2a55ada0794 = external constant [0 x i8]
@olang_loc_21ac6a2bf5030ca3_5f4b05cf8c14a9cf = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_H5e66fc73e1e965bc4ea2c131abc7fefe(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_6e425cae5aa6eba2_2e2cf5e273de798e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d8d1abb67d19f675_1213066b6aae1069 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_251e830707558b33_b2bdace7e2a71047 = external constant [0 x i8]
declare void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare void @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H4617403f451c76bf50031911a8c62431(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aStri_H1fc9d0b25cf85ea9c9cfd7459be8ea8d(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_364d74b8359cbf4c_14a2aae798044118 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_44996bcc7c9bda8_515f8c8db8b0565c = external constant [0 x i8]
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_fd149271c6cb7c79_e880786eedc8ef8d = external constant [0 x i8]
@olang_loc_7f8a5722dd9e6c02_a4d5bfca52fd95f6 = external constant [0 x i8]
@olang_loc_43dc44123b4c1d83_8d4d1e4381628e97 = external constant [0 x i8]
@olang_loc_2a07f4f1ea94dfe4_2b76d13ec2f0d080 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_6ec8a2aa167ef9d5_ad6e2c605b8bb111 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
@olang_loc_edee8f0aed3cec_fa0c04393fa4bb00 = external constant [0 x i8]
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_73743ad8a26b819d_7c035f5ad83f9b91 = external constant [0 x i8]
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_1ed22c7d3ed33c86_4a77ed05ffa3b9fa = external constant [0 x i8]
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d3277a20ab134767_f91655e31439de7b = external constant [0 x i8]
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fprelude_2flist_2estd_2fprelude_2flist_3aList_3cstd_2fprelude_2ftext_3aString_26_3e_Hfabcb4ab830a5416feda1aea3d8bba10(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_9b283db8f21a3c50_1ff4bf88356440dc = external constant [0 x i8]
@olang_loc_50c080632384d1e1_b715ab696a7cda0d = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@olang_loc_f9ae395f44564124_2a4ae2287bd25598 = external constant [0 x i8]
@G_2estd_2fprelude_2flist_2efirstChunk = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i64 @std_2fprelude_2flist_2ehighBit(i64 %a0)
@G_2estd_2fprelude_2flist_2efirstChunkLog = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\03\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @std_2fprelude_2flist_2estd_2fprelude_2flist_3alistState_3cU64_3e_2echunk_3cU64_3e(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_2ce16293fd874efe_ee839ffb494569fa = external constant [0 x i8]
@olang_loc_d200b8d2ab9dd17b_b944da2a7f03fd7 = external constant [0 x i8]
declare %"std/prelude/list:List.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2flist_3aList_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
