; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1 }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/scope:Gap" = type { i64, %"compiler/source:Span", { i64, ptr } }
%"compiler/source:Span" = type { i32, i32 }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/build:Program"
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i32
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/msgs:Msg"
  %l86 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca i1
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  %t176 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t1, i64 192, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l7, i64 192, i1 false)
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t3, i32 1, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l14
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l18
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l19
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l18, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t27)
  store i64 %t29, ptr %l21
  br label %bb13
bb13:
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t40)
  store i32 %t42, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l28, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l31
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l31, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l33, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t55)
  store i32 %t57, ptr %l35
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l35, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l41
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l40
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l36
  br label %bb31
bb28:
  %t70 = load i32, ptr %l41, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l43, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t74)
  store i32 %t76, ptr %l45
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l45, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb32
bb32:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t79, i32 0, i32 9
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb33, label %bb34
bb33:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v1, ptr %t84, ptr %l4, ptr %l5, { i64, ptr } %t85, ptr %t86)
  store i32 %t92, ptr %l53
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load i32, ptr %l53, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/build:Config", ptr %t94, i32 0, i32 18
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t99, ptr %l56
  br label %bb37
bb37:
  %t100 = load i1, ptr %l56, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb38, label %bb39
bb38:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/build:Config", ptr %t103, i32 0, i32 18
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = extractvalue { i64, ptr } %t106, 0
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t108, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  br label %bb43
bb39:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t119 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t119, ptr %l65
  br label %bb40
bb40:
  %t120 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t126)
  store { i64, ptr } %t128, ptr %l67
  br label %bb41
bb41:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t129)
  store { i64, ptr } %t131, ptr %l69
  br label %bb42
bb42:
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = add i64 %t137, %t140
  %t142 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = add i64 %t141, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t133, i64 %t134)
  %t147 = getelementptr i8, ptr %t146, i64 %t134
  call void @olang_textcopy(ptr %t147, ptr %t135, i64 %t136)
  %t148 = getelementptr i8, ptr %t147, i64 %t136
  call void @olang_textcopy(ptr %t148, ptr %t139, i64 %t140)
  %t149 = getelementptr i8, ptr %t148, i64 %t140
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t146, 1
  store { i64, ptr } %t151, ptr %l58, !tbaa !27
  br label %bb43
bb43:
  %t153 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t153, ptr %l6, !tbaa !27
  %t154 = load ptr, ptr %l1, !tbaa !29
  store ptr %t154, ptr %l71, !tbaa !29
  store ptr %l5, ptr %l72, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t155, ptr %l73, !tbaa !27
  %t156 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 2
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t157, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t159, ptr %l75
  br label %bb44
bb44:
  %t160 = load i1, ptr %l75, !tbaa !21
  %t161 = xor i1 %t160, true
  %t162 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 3
  %t163 = load ptr, ptr %l71, !tbaa !29
  %t164 = load ptr, ptr %l72, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t168 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t163, ptr %t164, { i64, ptr } %t165, i1 %t161, ptr %t162, ptr null)
  store i32 %t168, ptr %l78
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb46, label %ok.170, !prof !99
ok.170:
  br label %bb45
bb45:
  br label %bb51
bb46:
  %t171 = load i32, ptr %l78, !tbaa !23
  %t172 = ashr i32 %t171, 16
  %t174 = icmp eq i32 %t172, 1
  store i1 %t174, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s9
  %t175 = load ptr, ptr %l3, !tbaa !29
  store ptr %t175, ptr %l81, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t178 = load { i64, [3 x i64] }, ptr %t176
  store { i64, [3 x i64] } %t178, ptr %l82
  %t179 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t181 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s9, { i64, ptr } %t179)
  store %"compiler/msgs:Msg" %t181, ptr %l84
  br label %bb48
bb48:
  %t182 = load ptr, ptr %l81, !tbaa !29
  %t183 = load { i64, [3 x i64] }, ptr %l82
  %t184 = load %"compiler/msgs:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s9, ptr %t182, { i64, [3 x i64] } %t183, %"compiler/msgs:Msg" %t184)
  br label %bb49
bb49:
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t185)
  store i32 %t187, ptr %l86
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t188 = load i32, ptr %l86, !tbaa !23
  store i32 %t188, ptr %rv
  br label %ret
bb51:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb52
bb52:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = extractvalue { i64, ptr } %t190, 0
  %t194 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t193)
  call void @olang_textcopy(ptr %t194, ptr %t192, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = extractvalue { i64, ptr } %t196, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t206 = getelementptr %"compiler/build:Config", ptr %t189, i32 0, i32 19
  store { i64, ptr } %t203, ptr %t206, !tbaa !27
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/build:Config", ptr %t207, i32 0, i32 17
  %t210 = load i1, ptr %t209, !tbaa !21
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l94, !tbaa !29
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/build:Config", ptr %t215, i32 0, i32 18
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s11, { i64, ptr } %t218, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t220, ptr %l97
  br label %bb55
bb54:
  br label %bb62
bb55:
  %t221 = load i1, ptr %l97, !tbaa !21
  %t222 = xor i1 %t221, true
  br i1 %t222, label %bb56, label %bb57
bb56:
  %t224 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t224, ptr %l99, !tbaa !27
  br label %bb59
bb57:
  %t226 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t228 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s11, { i64, ptr } %t226)
  store { i64, ptr } %t228, ptr %l102
  br label %bb58
bb58:
  %t229 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t229, ptr %l99, !tbaa !27
  br label %bb59
bb59:
  %t230 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t232 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = getelementptr i8, ptr %t236, i64 %t231
  call void @olang_textcopy(ptr %t237, ptr %t233, i64 %t234)
  %t238 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t236, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = extractvalue { i64, ptr } %t239, 1
  %t243 = mul i64 %t241, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t247 = load ptr, ptr %l94, !tbaa !29
  %t249 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s11, ptr %s11, ptr %s11, ptr %t247, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } %t246)
  store { i64, ptr } %t249, ptr %l105
  br label %bb60
bb60:
  %t250 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t256)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i32
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t1, i64 192, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l8, i64 192, i1 false)
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l15
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t21)
  store i32 %t23, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l19, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t27)
  store i64 %t29, ptr %l22
  br label %bb13
bb13:
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l26
  br label %bb16
bb16:
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t40)
  store i32 %t42, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l29, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l32
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l32, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t55)
  store i32 %t57, ptr %l36
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l36, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l42
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l41
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l37
  br label %bb31
bb28:
  %t70 = load i32, ptr %l42, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t74)
  store i32 %t76, ptr %l46
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l46, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  %t80 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store { i64, ptr } %t80, ptr %l48
  br label %bb32
bb32:
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 18
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t87, ptr %l51
  br label %bb33
bb33:
  %t88 = load i1, ptr %l51, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s6, { i64, ptr } %t91)
  %t94 = extractvalue { i32, { i64, ptr } } %t93, 1
  %t95 = extractvalue { i32, { i64, ptr } } %t93, 0
  store i32 %t95, ptr %l56
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb37, label %ok.97, !prof !99
ok.97:
  store { i64, ptr } %t94, ptr %l55
  br label %bb36
bb35:
  br label %bb50
bb36:
  %t98 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t98, ptr %l53, !tbaa !27
  br label %bb42
bb37:
  %t99 = load i32, ptr %l56, !tbaa !23
  %t100 = ashr i32 %t99, 16
  %t102 = icmp eq i32 %t100, 1
  store i1 %t102, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s7
  %t103 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t103, ptr %l59, !tbaa !27
  %t104 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s7)
  store %"compiler/msgs:Msg" %t104, ptr %l60
  br label %bb39
bb39:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t107 = load %"compiler/msgs:Msg", ptr %l60
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s7, ptr %v1, { i64, ptr } %t106, %"compiler/msgs:Msg" %t107, ptr %t105)
  br label %bb40
bb40:
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t111 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t109)
  store i32 %t111, ptr %l63
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t112 = load i32, ptr %l63, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
bb42:
  %t113 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 18
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t122 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t117, { i64, ptr } %t113)
  store i32 %t122, ptr %l68
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb44, label %ok.124, !prof !99
ok.124:
  br label %bb43
bb43:
  br label %bb49
bb44:
  %t125 = load i32, ptr %l68, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  store i1 %t128, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s8
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/build:Config", ptr %t129, i32 0, i32 18
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l72, !tbaa !27
  %t133 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s8)
  store %"compiler/msgs:Msg" %t133, ptr %l73
  br label %bb46
bb46:
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t136 = load %"compiler/msgs:Msg", ptr %l73
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s8, ptr %v1, { i64, ptr } %t135, %"compiler/msgs:Msg" %t136, ptr %t134)
  br label %bb47
bb47:
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t138)
  store i32 %t140, ptr %l76
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l76, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
bb49:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/build:Config", ptr %t142, i32 0, i32 18
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t147, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/build:Config", ptr %t160, i32 0, i32 17
  %t163 = load i1, ptr %t162, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t172 = extractvalue { i64, ptr } %t168, 1
  %t173 = extractvalue { i64, ptr } %t168, 0
  %t174 = add i64 %t170, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t169, i64 %t170)
  %t176 = getelementptr i8, ptr %t175, i64 %t170
  call void @olang_textcopy(ptr %t176, ptr %t172, i64 %t173)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t188 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t167, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t185)
  store { i64, ptr } %t188, ptr %l88
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t189 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = extractvalue { i64, ptr } %t189, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t195)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l13
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  br label %bb11
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_251e830707558b33_b2bdace7e2a71047)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l18
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t29)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store i32 %t12, ptr %l11
  br label %bb1
bb1:
  %t16 = load i32, ptr %l11, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb11
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l17
  br label %bb10
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load i32, ptr %l5, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l31 = alloca i1
  %l33 = alloca i32
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca { i64, [3 x i64] }
  %l96 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i32
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t205 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 17
  store i1 true, ptr %t3, !tbaa !21
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t5, { i64, ptr } %t6, ptr %t7)
  store i32 %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load i32, ptr %l21, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  %t14 = load i32, ptr %l5, !tbaa !23
  %t16 = icmp ne i32 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v1, ptr %s0, ptr %t20, ptr %t21)
  %t25 = extractvalue { i32, { i64, ptr } } %t24, 1
  %t26 = extractvalue { i32, { i64, ptr } } %t24, 0
  store i32 %t26, ptr %l29
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb6, label %ok.28, !prof !99
ok.28:
  store { i64, ptr } %t25, ptr %l28
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  br label %bb9
bb6:
  %t30 = load i32, ptr %l29, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  store i1 %t33, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t34)
  store i32 %t36, ptr %l33
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i32, ptr %l33, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb9:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l6, !tbaa !27
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l34
  br label %bb10
bb10:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l7
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t55, ptr %l42, !tbaa !27
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %t59, i64 %t56
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t65 = extractvalue { i64, ptr } %t61, 1
  %t66 = extractvalue { i64, ptr } %t61, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t76)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l9, !tbaa !24
  br label %bb11
bb17:
  store ptr %l7, ptr %l51, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l55, !tbaa !27
  br label %bb21
bb19:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Config", ptr %t97, i32 0, i32 19
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l60
  br label %bb20
bb20:
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t103, ptr %l55, !tbaa !27
  br label %bb21
bb21:
  %t104 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t111, { i64, ptr } %t110)
  br label %bb22
bb22:
  store { i64, ptr } %a3, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t127 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %t131, i64 %t128
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !37
  %t137 = extractvalue { i64, ptr } %t133, 1
  %t138 = extractvalue { i64, ptr } %t133, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t148)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l13, !tbaa !24
  br label %bb23
bb29:
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = icmp eq i64 %t157, 0
  br i1 %t159, label %bb30, label %bb31
bb30:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/build:Config", ptr %t161, i32 0, i32 19
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t164)
  store { i64, ptr } %t166, ptr %l84
  br label %bb32
bb31:
  %t167 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %t168, i64 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !37
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = extractvalue { i64, ptr } %t170, 0
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t172, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l81, !tbaa !27
  br label %bb33
bb32:
  %t185 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l81, !tbaa !27
  br label %bb33
bb33:
  %t194 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t194, ptr %l90
  br label %bb34
bb34:
  %t195 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t197 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t195, { i64, ptr } %t196)
  store i32 %t197, ptr %l91
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb36, label %ok.199, !prof !99
ok.199:
  br label %bb35
bb35:
  br label %bb41
bb36:
  %t200 = load i32, ptr %l91, !tbaa !23
  %t201 = ashr i32 %t200, 16
  %t203 = icmp eq i32 %t201, 1
  store i1 %t203, ptr %l93, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t204 = load ptr, ptr %l4, !tbaa !29
  store ptr %t204, ptr %l94, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t207 = load { i64, [3 x i64] }, ptr %t205
  store { i64, [3 x i64] } %t207, ptr %l95
  %t208 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s13, ptr %s13, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t208, ptr %l96
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l94, !tbaa !29
  %t210 = load { i64, [3 x i64] }, ptr %l95
  %t211 = load %"compiler/msgs:Msg", ptr %l96
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s13, ptr %t209, { i64, [3 x i64] } %t210, %"compiler/msgs:Msg" %t211)
  br label %bb39
bb39:
  %t212 = load ptr, ptr %l4, !tbaa !29
  %t214 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t212)
  store i32 %t214, ptr %l98
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t215 = load i32, ptr %l98, !tbaa !23
  store i32 %t215, ptr %rv
  br label %ret
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:FileInfo"
  %l6 = alloca %"compiler/build:Program"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"std/os:Output"
  %l20 = alloca %"std/os:FileInfo"
  %l22 = alloca %"std/os:FileInfo"
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i32
  %l46 = alloca %"compiler/build:Program"
  %l53 = alloca i32
  %l59 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i1
  %l78 = alloca i32
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i32
  %l86 = alloca i1
  %l88 = alloca i32
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l102 = alloca i1
  %l105 = alloca i32
  %l107 = alloca i1
  %l112 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i32
  %l130 = alloca i1
  %l132 = alloca i32
  %l133 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l141 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l156 = alloca i1
  %l161 = alloca i32
  %l169 = alloca { i64, ptr }
  %l178 = alloca %"std/os:Output"
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca %"std/os:Output"
  %l183 = alloca i32
  %l185 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l200 = alloca i1
  %l207 = alloca { i64, ptr }
  %l212 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca i32
  %t58 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l23
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l22
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l22
  store %"std/os:FileInfo" %t8, ptr %l20
  br label %bb6
bb2:
  %t9 = load i32, ptr %l23, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l26, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l27, !tbaa !27
  %t15 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t15, ptr %l28
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t19 = load %"compiler/msgs:Msg", ptr %l28
  %t21 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s1, ptr %v1, ptr %t17, { i64, ptr } %t18, %"compiler/msgs:Msg" %t19, ptr %t16)
  store i32 %t21, ptr %l30
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l30, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load %"std/os:FileInfo", ptr %l20
  store %"std/os:FileInfo" %t23, ptr %l5
  %t24 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 3}
  %t27 = trunc i64 1 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l33, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l34, !tbaa !27
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s2)
  store %"compiler/msgs:Msg" %t32, ptr %l35
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l33, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t36 = load %"compiler/msgs:Msg", ptr %l35
  %t38 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s2, ptr %v1, ptr %t34, { i64, ptr } %t35, %"compiler/msgs:Msg" %t36, ptr %t33)
  store i32 %t38, ptr %l37
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l37, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 3}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l41, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l42, !tbaa !27
  %t50 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %s3)
  store %"compiler/msgs:Msg" %t50, ptr %l43
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = load %"compiler/msgs:Msg", ptr %l43
  %t56 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s3, ptr %v1, ptr %t52, { i64, ptr } %t53, %"compiler/msgs:Msg" %t54, ptr %t51)
  store i32 %t56, ptr %l45
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i32, ptr %l45, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
bb16:
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t58, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t58, i64 192, i1 false)
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l46, i64 192, i1 false)
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t69 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t60, i32 2, ptr %t61, ptr %l6, ptr %t62)
  store i32 %t69, ptr %l53
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb19, label %ok.71, !prof !99
ok.71:
  br label %bb18
bb18:
  br label %bb28
bb19:
  %t72 = load i32, ptr %l53, !tbaa !23
  %t73 = icmp eq i32 %t72, 65536
  br i1 %t73, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  %t75 = load i32, ptr %l53, !tbaa !23
  %t76 = icmp eq i32 %t75, 65537
  br i1 %t76, label %bb23, label %bb24
bb22:
  call void @__olang_ert_req_clear()
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t84 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t78, { i64, ptr } %t79, ptr %t80)
  store i32 %t84, ptr %l59
  br label %bb26
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_44996bcc7c9bda8_515f8c8db8b0565c)
  unreachable
bb25:
  call void @__olang_ert_req_clear()
  %t85 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t85, ptr %l60
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t86 = load i32, ptr %l59, !tbaa !23
  store i32 %t86, ptr %rv
  br label %ret
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i32, ptr %l60, !tbaa !23
  store i32 %t87, ptr %rv
  br label %ret
bb28:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t88)
  store i64 %t90, ptr %l62
  br label %bb29
bb29:
  %t91 = load i64, ptr %l62, !tbaa !24
  %t92 = icmp sgt i64 %t91, 0
  br i1 %t92, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb33
bb31:
  %t94 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 0
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t94)
  store i64 %t96, ptr %l66
  br label %bb32
bb32:
  %t97 = load i64, ptr %l66, !tbaa !24
  %t98 = icmp eq i64 %t97, 0
  store i1 %t98, ptr %l64, !tbaa !21
  br label %bb33
bb33:
  %t100 = load i1, ptr %l64, !tbaa !21
  br i1 %t100, label %bb34, label %bb35
bb34:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t107 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t101, { i64, ptr } %t102, ptr %t103)
  store i32 %t107, ptr %l71
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i32, ptr %l71, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
bb37:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t113 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t109, ptr %t110)
  store i32 %t113, ptr %l74
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb39, label %ok.115, !prof !99
ok.115:
  br label %bb38
bb38:
  br label %bb42
bb39:
  %t116 = load i32, ptr %l74, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  store i1 %t119, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  %t120 = load ptr, ptr %l3, !tbaa !29
  %t122 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t120)
  store i32 %t122, ptr %l78
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l78, !tbaa !23
  store i32 %t123, ptr %rv
  br label %ret
bb42:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t125 = load ptr, ptr %l3, !tbaa !29
  %t129 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t124, ptr %l6, ptr %t125)
  %t130 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t129, 1
  %t131 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t129, 0
  store i32 %t131, ptr %l84
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb44, label %ok.133, !prof !99
ok.133:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l83
  br label %bb43
bb43:
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l79
  br label %bb47
bb44:
  %t135 = load i32, ptr %l84, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l86, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t141 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t139)
  store i32 %t141, ptr %l88
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t142 = load i32, ptr %l88, !tbaa !23
  store i32 %t142, ptr %rv
  br label %ret
bb47:
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l7
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb48
bb48:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr %"compiler/build:Config", ptr %t144, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l90, !tbaa !27
  %t149 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t149, ptr %l92
  br label %bb49
bb49:
  %t150 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t158 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t156)
  store { i64, ptr } %t158, ptr %l94
  br label %bb50
bb50:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t159)
  store { i64, ptr } %t161, ptr %l96
  br label %bb51
bb51:
  %t162 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t163, i64 %t164)
  %t180 = getelementptr i8, ptr %t179, i64 %t164
  call void @olang_textcopy(ptr %t180, ptr %t165, i64 %t166)
  %t181 = getelementptr i8, ptr %t180, i64 %t166
  call void @olang_textcopy(ptr %t181, ptr %t169, i64 %t170)
  %t182 = getelementptr i8, ptr %t181, i64 %t170
  call void @olang_textcopy(ptr %t182, ptr %t172, i64 %t173)
  %t183 = getelementptr i8, ptr %t182, i64 %t173
  call void @olang_textcopy(ptr %t183, ptr %t176, i64 %t177)
  %t184 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t179, 1
  store { i64, ptr } %t185, ptr %l8, !tbaa !27
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l98, !tbaa !29
  store ptr %l7, ptr %l99, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t188, ptr %l100, !tbaa !27
  %t189 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t190, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t192, ptr %l102
  br label %bb52
bb52:
  %t193 = load i1, ptr %l102, !tbaa !21
  %t194 = xor i1 %t193, true
  %t195 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 3
  %t196 = load ptr, ptr %l98, !tbaa !29
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t201 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t196, ptr %t197, { i64, ptr } %t198, i1 %t194, ptr %t195, ptr null)
  store i32 %t201, ptr %l105
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb54, label %ok.203, !prof !99
ok.203:
  br label %bb53
bb53:
  br label %bb58
bb54:
  %t204 = load i32, ptr %l105, !tbaa !23
  %t205 = ashr i32 %t204, 16
  %t207 = icmp eq i32 %t205, 1
  store i1 %t207, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s10
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = extractvalue { i64, ptr } %t209, 0
  %t213 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t211, i64 %t212)
  %t217 = getelementptr i8, ptr %t216, i64 %t212
  call void @olang_textcopy(ptr %t217, ptr %t213, i64 %t214)
  %t218 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t216, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = extractvalue { i64, ptr } %t219, 1
  %t223 = mul i64 %t221, 1
  %t224 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t229 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t208, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, { i64, ptr } %t226)
  store { i64, ptr } %t229, ptr %l112
  br label %bb56
bb56:
  %t230 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t236)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb58:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb59
bb59:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t241 = getelementptr %"compiler/build:Config", ptr %t239, i32 0, i32 17
  %t242 = load i1, ptr %t241, !tbaa !21
  %t244 = xor i1 %t242, true
  br i1 %t244, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t246 = load ptr, ptr %l1, !tbaa !29
  %t247 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t248 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t249 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t251 = extractvalue { i64, ptr } %t247, 1
  %t252 = extractvalue { i64, ptr } %t247, 0
  %t253 = add i64 %t249, %t252
  %t254 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t255 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t256 = add i64 %t253, %t255
  %t257 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t256)
  call void @olang_textcopy(ptr %t257, ptr %t248, i64 %t249)
  %t258 = getelementptr i8, ptr %t257, i64 %t249
  call void @olang_textcopy(ptr %t258, ptr %t251, i64 %t252)
  %t259 = getelementptr i8, ptr %t258, i64 %t252
  call void @olang_textcopy(ptr %t259, ptr %t254, i64 %t255)
  %t260 = insertvalue { i64, ptr } undef, i64 %t256, 0
  %t261 = insertvalue { i64, ptr } %t260, ptr %t257, 1
  %t263 = extractvalue { i64, ptr } %t261, 0
  %t264 = extractvalue { i64, ptr } %t261, 1
  %t265 = mul i64 %t263, 1
  %t266 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t265)
  call void @llvm.memcpy.p0.p0.i64(ptr %t266, ptr %t264, i64 %t265, i1 false)
  %t267 = insertvalue { i64, ptr } undef, i64 %t263, 0
  %t268 = insertvalue { i64, ptr } %t267, ptr %t266, 1
  %t271 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s12, ptr %s12, ptr %s12, ptr %t246, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } %t268)
  store { i64, ptr } %t271, ptr %l122
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t272 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 0
  %t274 = extractvalue { i64, ptr } %t272, 1
  %t275 = mul i64 %t273, 1
  %t276 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t275)
  call void @llvm.memcpy.p0.p0.i64(ptr %t276, ptr %t274, i64 %t275, i1 false)
  %t277 = insertvalue { i64, ptr } undef, i64 %t273, 0
  %t278 = insertvalue { i64, ptr } %t277, ptr %t276, 1
  call void @compiler_2fbuild_2esayln(ptr %s12, { i64, ptr } %t278)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t281 = load ptr, ptr %l3, !tbaa !29
  %t284 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v1, ptr %s0, ptr %t280, ptr %t281)
  %t285 = extractvalue { i32, { i64, ptr } } %t284, 1
  %t286 = extractvalue { i32, { i64, ptr } } %t284, 0
  store i32 %t286, ptr %l128
  %t287 = icmp ne i32 %t286, 0
  br i1 %t287, label %bb66, label %ok.288, !prof !99
ok.288:
  store { i64, ptr } %t285, ptr %l127
  br label %bb65
bb65:
  %t289 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t289, ptr %l124, !tbaa !27
  br label %bb69
bb66:
  %t290 = load i32, ptr %l128, !tbaa !23
  %t291 = ashr i32 %t290, 16
  %t293 = icmp eq i32 %t291, 1
  store i1 %t293, ptr %l130, !tbaa !21
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  %t294 = load ptr, ptr %l3, !tbaa !29
  %t296 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t294)
  store i32 %t296, ptr %l132
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t297 = load i32, ptr %l132, !tbaa !23
  store i32 %t297, ptr %rv
  br label %ret
bb69:
  %t298 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t298, ptr %l9, !tbaa !27
  %t299 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t299, ptr %l133
  br label %bb70
bb70:
  %t300 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l133
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t300, ptr %l10
  %t301 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t301, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t303 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t305 = extractvalue { i64, ptr } %t303, 0
  store i64 %t305, ptr %l13, !tbaa !24
  br label %bb71
bb71:
  %t307 = load i64, ptr %l12, !tbaa !24
  %t308 = load i64, ptr %l13, !tbaa !24
  %t311 = icmp slt i64 %t307, %t308
  %t313 = xor i1 %t311, true
  br i1 %t313, label %bb72, label %bb73
bb72:
  br label %bb77
bb73:
  br label %bb74
bb74:
  %t315 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t315, ptr %l141, !tbaa !27
  %t316 = load i64, ptr %l12, !tbaa !24
  %t318 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t319 = load ptr, ptr %t318, !tbaa !27
  %t320 = getelementptr { i64, ptr }, ptr %t319, i64 %t316
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !37
  %t325 = extractvalue { i64, ptr } %t321, 1
  %t326 = extractvalue { i64, ptr } %t321, 0
  %t327 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t326)
  call void @olang_textcopy(ptr %t327, ptr %t325, i64 %t326)
  %t328 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t329 = insertvalue { i64, ptr } %t328, ptr %t327, 1
  %t331 = extractvalue { i64, ptr } %t329, 0
  %t332 = extractvalue { i64, ptr } %t329, 1
  %t333 = mul i64 %t331, 1
  %t334 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t333)
  call void @llvm.memcpy.p0.p0.i64(ptr %t334, ptr %t332, i64 %t333, i1 false)
  %t335 = insertvalue { i64, ptr } undef, i64 %t331, 0
  %t336 = insertvalue { i64, ptr } %t335, ptr %t334, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t336)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t339 = load i64, ptr %l12, !tbaa !24
  %t341 = add i64 %t339, 1
  store i64 %t341, ptr %l12, !tbaa !24
  br label %bb71
bb77:
  store ptr %l10, ptr %l150, !tbaa !29
  %t343 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t345 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t343)
  store { i64, ptr } %t345, ptr %l152
  br label %bb78
bb78:
  %t346 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t347 = extractvalue { i64, ptr } %t346, 0
  %t348 = extractvalue { i64, ptr } %t346, 1
  %t349 = mul i64 %t347, 1
  %t350 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t349)
  call void @llvm.memcpy.p0.p0.i64(ptr %t350, ptr %t348, i64 %t349, i1 false)
  %t351 = insertvalue { i64, ptr } undef, i64 %t347, 0
  %t352 = insertvalue { i64, ptr } %t351, ptr %t350, 1
  %t353 = load ptr, ptr %l150, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t353, { i64, ptr } %t352)
  br label %bb79
bb79:
  %t355 = load ptr, ptr %l1, !tbaa !29
  %t357 = getelementptr %"compiler/build:Config", ptr %t355, i32 0, i32 10
  %t358 = load { i64, ptr }, ptr %t357, !tbaa !27
  %t360 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t358, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t360, ptr %l156
  br label %bb80
bb80:
  %t361 = load i1, ptr %l156, !tbaa !21
  %t362 = xor i1 %t361, true
  br i1 %t362, label %bb81, label %bb82
bb81:
  %t364 = load ptr, ptr %l1, !tbaa !29
  %t368 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v1, ptr %s0, ptr %s0, ptr %t364, ptr %l10, ptr %l6)
  store i32 %t368, ptr %l161
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t369 = load i32, ptr %l161, !tbaa !23
  store i32 %t369, ptr %rv
  br label %ret
bb84:
  %t370 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t370, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t372 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  store i64 %t374, ptr %l17, !tbaa !24
  br label %bb85
bb85:
  %t376 = load i64, ptr %l16, !tbaa !24
  %t377 = load i64, ptr %l17, !tbaa !24
  %t380 = icmp slt i64 %t376, %t377
  %t382 = xor i1 %t380, true
  br i1 %t382, label %bb86, label %bb87
bb86:
  br label %bb91
bb87:
  br label %bb88
bb88:
  %t384 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t384, ptr %l169, !tbaa !27
  %t385 = load i64, ptr %l16, !tbaa !24
  %t387 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t388 = load ptr, ptr %t387, !tbaa !27
  %t389 = getelementptr { i64, ptr }, ptr %t388, i64 %t385
  %t390 = load { i64, ptr }, ptr %t389, !tbaa !37
  %t394 = extractvalue { i64, ptr } %t390, 1
  %t395 = extractvalue { i64, ptr } %t390, 0
  %t396 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t395)
  call void @olang_textcopy(ptr %t396, ptr %t394, i64 %t395)
  %t397 = insertvalue { i64, ptr } undef, i64 %t395, 0
  %t398 = insertvalue { i64, ptr } %t397, ptr %t396, 1
  %t400 = extractvalue { i64, ptr } %t398, 0
  %t401 = extractvalue { i64, ptr } %t398, 1
  %t402 = mul i64 %t400, 1
  %t403 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t402)
  call void @llvm.memcpy.p0.p0.i64(ptr %t403, ptr %t401, i64 %t402, i1 false)
  %t404 = insertvalue { i64, ptr } undef, i64 %t400, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t405)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t408 = load i64, ptr %l16, !tbaa !24
  %t410 = add i64 %t408, 1
  store i64 %t410, ptr %l16, !tbaa !24
  br label %bb85
bb91:
  %t413 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t413, ptr %l180
  br label %bb92
bb92:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l181, !tbaa !27
  %t414 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t416 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t414, { i64, ptr } %t415, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  %t417 = extractvalue { i32, %"std/os:Output" } %t416, 1
  %t418 = extractvalue { i32, %"std/os:Output" } %t416, 0
  store i32 %t418, ptr %l183
  %t419 = icmp ne i32 %t418, 0
  br i1 %t419, label %bb94, label %ok.420, !prof !99
ok.420:
  store %"std/os:Output" %t417, ptr %l182
  br label %bb93
bb93:
  %t421 = load %"std/os:Output", ptr %l182
  store %"std/os:Output" %t421, ptr %l178
  br label %bb96
bb94:
  %t422 = load i32, ptr %l183, !tbaa !23
  %t423 = ashr i32 %t422, 16
  %t425 = icmp eq i32 %t423, 1
  store i1 %t425, ptr %l185, !tbaa !21
  br label %bb95
bb95:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb96:
  %t427 = load %"std/os:Output", ptr %l178
  store %"std/os:Output" %t427, ptr %l19
  %t428 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t429 = load i32, ptr %t428, !tbaa !23
  %t431 = icmp sgt i32 %t429, 128
  br i1 %t431, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s25
  %t433 = load ptr, ptr %l1, !tbaa !29
  store ptr %t433, ptr %l189, !tbaa !29
  %t434 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t434, ptr %l190, !tbaa !27
  %t435 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t436 = load i32, ptr %t435, !tbaa !23
  %t438 = sub i32 %t436, 128
  %t440 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s25, i32 %t438)
  store { i64, ptr } %t440, ptr %l193
  br label %bb99
bb98:
  br label %bb102
bb99:
  %t441 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t442 = extractvalue { i64, ptr } %t441, 1
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t445 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t446 = add i64 %t443, %t445
  %t447 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t447, 1
  %t449 = extractvalue { i64, ptr } %t447, 0
  %t450 = add i64 %t446, %t449
  %t451 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t452 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t453 = add i64 %t450, %t452
  %t454 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t453)
  call void @olang_textcopy(ptr %t454, ptr %t442, i64 %t443)
  %t455 = getelementptr i8, ptr %t454, i64 %t443
  call void @olang_textcopy(ptr %t455, ptr %t444, i64 %t445)
  %t456 = getelementptr i8, ptr %t455, i64 %t445
  call void @olang_textcopy(ptr %t456, ptr %t448, i64 %t449)
  %t457 = getelementptr i8, ptr %t456, i64 %t449
  call void @olang_textcopy(ptr %t457, ptr %t451, i64 %t452)
  %t458 = insertvalue { i64, ptr } undef, i64 %t453, 0
  %t459 = insertvalue { i64, ptr } %t458, ptr %t454, 1
  %t461 = extractvalue { i64, ptr } %t459, 0
  %t462 = extractvalue { i64, ptr } %t459, 1
  %t463 = mul i64 %t461, 1
  %t464 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t463)
  call void @llvm.memcpy.p0.p0.i64(ptr %t464, ptr %t462, i64 %t463, i1 false)
  %t465 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr %t464, 1
  %t467 = load ptr, ptr %l189, !tbaa !29
  %t469 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s25, ptr %s25, ptr %s25, ptr %t467, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, { i64, ptr } %t466)
  store { i64, ptr } %t469, ptr %l196
  br label %bb100
bb100:
  %t470 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t470, 0
  %t472 = extractvalue { i64, ptr } %t470, 1
  %t473 = mul i64 %t471, 1
  %t474 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t473)
  call void @llvm.memcpy.p0.p0.i64(ptr %t474, ptr %t472, i64 %t473, i1 false)
  %t475 = insertvalue { i64, ptr } undef, i64 %t471, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t474, 1
  call void @compiler_2fbuild_2esayln(ptr %s25, { i64, ptr } %t476)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s25)
  br label %bb102
bb102:
  %t478 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t479 = load i32, ptr %t478, !tbaa !23
  %t481 = icmp eq i32 %t479, 3
  br i1 %t481, label %bb103, label %bb104
bb103:
  %t483 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t485 = extractvalue { i64, ptr } %t483, 0
  %t487 = icmp sgt i64 %t485, 0
  store i1 %t487, ptr %l200, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb105
bb105:
  %t489 = load i1, ptr %l200, !tbaa !21
  br i1 %t489, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s27
  %t490 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t491 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t492 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 7
  %t496 = call { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v2, ptr %v3, ptr %s0, ptr %s27, { i64, ptr } %t490, { i64, ptr } %t491, ptr %t492)
  store { i64, ptr } %t496, ptr %l207
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t497 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t498 = extractvalue { i64, ptr } %t497, 0
  %t499 = extractvalue { i64, ptr } %t497, 1
  %t500 = mul i64 %t498, 1
  %t501 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t500)
  call void @llvm.memcpy.p0.p0.i64(ptr %t501, ptr %t499, i64 %t500, i1 false)
  %t502 = insertvalue { i64, ptr } undef, i64 %t498, 0
  %t503 = insertvalue { i64, ptr } %t502, ptr %t501, 1
  call void @compiler_2fbuild_2esayln(ptr %s27, { i64, ptr } %t503)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store i32 3, ptr %rv
  br label %ret
bb110:
  %t506 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t507 = load i32, ptr %t506, !tbaa !23
  %t509 = icmp eq i32 %t507, 0
  br i1 %t509, label %bb111, label %bb112
bb111:
  store i32 0, ptr %l212, !tbaa !23
  br label %bb113
bb112:
  store i32 1, ptr %l212, !tbaa !23
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s0)
  %t511 = load i32, ptr %l212, !tbaa !23
  store i32 %t511, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/diag:Diagnostics"
  %l16 = alloca %"compiler/build:Config"
  %l18 = alloca %"compiler/olang:CommandLine"
  %l22 = alloca %"compiler/olang:CommandLine"
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l48 = alloca { i64, ptr }
  %l50 = alloca i32
  %l55 = alloca i64
  %l57 = alloca ptr
  %l58 = alloca ptr
  %l60 = alloca { i64, ptr }
  %l63 = alloca i32
  %l64 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l68 = alloca i32
  %l70 = alloca i1
  %l72 = alloca i32
  %l74 = alloca i32
  %l79 = alloca i32
  %l83 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l85 = alloca i32
  %l87 = alloca i1
  %l88 = alloca { i64, ptr }
  %l92 = alloca i1
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca i32
  %l103 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %l107 = alloca i32
  %l112 = alloca { i64, ptr }
  %l116 = alloca i32
  %l121 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l125 = alloca { i64, ptr }
  %l127 = alloca i32
  %l132 = alloca i32
  %l136 = alloca ptr
  %l137 = alloca { i64, ptr }
  %l138 = alloca { i64, ptr }
  %l139 = alloca i32
  %l141 = alloca i1
  %l142 = alloca { i64, ptr }
  %l146 = alloca i32
  %l148 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l157 = alloca i32
  %l163 = alloca { i64, ptr }
  %l166 = alloca i32
  %l170 = alloca ptr
  %l171 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l175 = alloca { i64, ptr }
  %l177 = alloca i32
  %l181 = alloca ptr
  %l182 = alloca ptr
  %l183 = alloca { i64, ptr }
  %l184 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l188 = alloca i32
  %l192 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l194 = alloca { i64, ptr }
  %l199 = alloca i64
  %l201 = alloca i64
  %l206 = alloca { i64, ptr }
  %l213 = alloca ptr
  %l214 = alloca ptr
  %l215 = alloca { i64, ptr }
  %l216 = alloca { i64, ptr }
  %l218 = alloca { i64, ptr }
  %l220 = alloca i32
  %l224 = alloca ptr
  %l225 = alloca ptr
  %l226 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l228 = alloca ptr
  %l230 = alloca { i64, ptr }
  %l231 = alloca i32
  %l232 = alloca { i64, ptr }
  %l233 = alloca { i64, ptr }
  %l234 = alloca i32
  %l236 = alloca i1
  %l237 = alloca { i64, ptr }
  %l241 = alloca ptr
  %l242 = alloca { i64, ptr }
  %l244 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l247 = alloca { i64, ptr }
  %l248 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s21 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  %t10 = alloca %"compiler/olang:CommandLine", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l14
  br label %bb1
bb1:
  %t3 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t2, i64 512, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l15, i64 512, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t4, i64 528, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 528, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 16
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i32 @compiler_2folang_2ePrepare(ptr %t10, ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  store i32 %t14, ptr %l23
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t10, i64 224, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l22, i64 224, i1 false)
  br label %bb8
bb5:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  %t22 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t22, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l27, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l18, i64 224, i1 false)
  %t24 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  br i1 %t29, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %s0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t34 = extractvalue { i32, { i64, ptr } } %t33, 1
  %t35 = extractvalue { i32, { i64, ptr } } %t33, 0
  store i32 %t35, ptr %l35
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb12, label %ok.37, !prof !99
ok.37:
  store { i64, ptr } %t34, ptr %l34
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t38 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  br label %bb15
bb12:
  %t39 = load i32, ptr %l35, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  store i1 %t42, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  %t44 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t44, ptr %l39
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i32, ptr %l39, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t49 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t46)
  store i32 %t49, ptr %l41
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i32, ptr %l41, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb17:
  %t51 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t56 = icmp eq i64 %t52, %t53
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 11
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l45, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l45, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  %t62 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t64 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t62, i64 0)
  store { i64, ptr } %t64, ptr %l48
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t65 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t67 = call i32 @compiler_2fsession_2eCapsMode(ptr %s0, ptr %s0, { i64, ptr } %t65, ptr %l3)
  store i32 %t67, ptr %l50
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %rv
  br label %ret
bb25:
  %t69 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t74 = icmp eq i64 %t70, %t71
  br i1 %t74, label %bb26, label %bb27
bb26:
  store %olang.scope zeroinitializer, ptr %s5
  %t76 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t78 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t76)
  store i64 %t78, ptr %l55
  br label %bb28
bb27:
  br label %bb40
bb28:
  %t79 = load i64, ptr %l55, !tbaa !24
  %t80 = icmp eq i64 %t79, 1
  br i1 %t80, label %bb29, label %bb30
bb29:
  %t82 = load ptr, ptr %l1, !tbaa !29
  store ptr %t82, ptr %l57, !tbaa !29
  store ptr %l3, ptr %l58, !tbaa !29
  %t83 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t85 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t83, i64 0)
  store { i64, ptr } %t85, ptr %l60
  br label %bb31
bb30:
  br label %bb33
bb31:
  %t86 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t87 = load { i64, ptr }, ptr %t86, !tbaa !27
  %t88 = load ptr, ptr %l57, !tbaa !29
  %t89 = load ptr, ptr %l58, !tbaa !29
  %t90 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t93 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t88, ptr %t89, { i64, ptr } %t90, { i64, ptr } %t87, ptr %l2)
  store i32 %t93, ptr %l63
  br label %bb32
bb32:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i32, ptr %l63, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb33:
  %t95 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t96 = load { i64, ptr }, ptr %t95, !tbaa !27
  %t99 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %s0, ptr %s0, ptr %s5, { i64, ptr } %t96, ptr %l2)
  %t100 = extractvalue { i32, { i64, ptr } } %t99, 1
  %t101 = extractvalue { i32, { i64, ptr } } %t99, 0
  store i32 %t101, ptr %l68
  %t102 = icmp ne i32 %t101, 0
  br i1 %t102, label %bb35, label %ok.103, !prof !99
ok.103:
  store { i64, ptr } %t100, ptr %l67
  br label %bb34
bb34:
  %t104 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t104, ptr %l64, !tbaa !27
  br label %bb38
bb35:
  %t105 = load i32, ptr %l68, !tbaa !23
  %t106 = ashr i32 %t105, 16
  %t108 = icmp eq i32 %t106, 1
  store i1 %t108, ptr %l70, !tbaa !21
  br label %bb36
bb36:
  call void @__olang_ert_req_clear()
  %t110 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t110, ptr %l72
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i32, ptr %l72, !tbaa !23
  store i32 %t111, ptr %rv
  br label %ret
bb38:
  %t112 = load { i64, ptr }, ptr %l64, !tbaa !27
  %t115 = call i32 @compiler_2folang_2ewrite(ptr %s5, { i64, ptr } %t112)
  store i32 %t115, ptr %l74
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load i32, ptr %l74, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb40:
  %t117 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t118 = load i64, ptr %t117, !tbaa !24
  %t119 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t122 = icmp eq i64 %t118, %t119
  br i1 %t122, label %bb41, label %bb42
bb41:
  %t125 = call i32 @compiler_2folang_2eformat(ptr %s0, ptr %l4)
  store i32 %t125, ptr %l79
  br label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load i32, ptr %l79, !tbaa !23
  store i32 %t126, ptr %rv
  br label %ret
bb44:
  %t127 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t128 = load i64, ptr %t127, !tbaa !24
  %t129 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t132 = icmp eq i64 %t128, %t129
  br i1 %t132, label %bb45, label %bb46
bb45:
  store %olang.scope zeroinitializer, ptr %s9
  %t134 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s9, ptr %s9, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d28, i32 0, i32 1) })
  %t135 = extractvalue { i32, { i64, ptr } } %t134, 1
  %t136 = extractvalue { i32, { i64, ptr } } %t134, 0
  store i32 %t136, ptr %l85
  %t137 = icmp ne i32 %t136, 0
  br i1 %t137, label %bb48, label %ok.138, !prof !99
ok.138:
  store { i64, ptr } %t135, ptr %l84
  br label %bb47
bb46:
  br label %bb54
bb47:
  %t139 = load { i64, ptr }, ptr %l84, !tbaa !27
  store { i64, ptr } %t139, ptr %l83, !tbaa !27
  br label %bb50
bb48:
  %t140 = load i32, ptr %l85, !tbaa !23
  %t141 = ashr i32 %t140, 16
  %t143 = icmp eq i32 %t141, 1
  store i1 %t143, ptr %l87, !tbaa !21
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  %t144 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t144, ptr %l88, !tbaa !27
  %t145 = getelementptr { i64, ptr }, ptr %l88, i32 0, i32 1
  %t146 = load ptr, ptr %t145, !tbaa !27
  %t147 = getelementptr { i64, ptr }, ptr %t146, i64 0
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !37
  %t150 = extractvalue { i64, ptr } %t148, 1
  %t151 = extractvalue { i64, ptr } %t148, 0
  %t152 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t150, i64 %t151)
  %t153 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t152, 1
  %t156 = extractvalue { i64, ptr } %t154, 0
  %t157 = extractvalue { i64, ptr } %t154, 1
  %t158 = mul i64 %t156, 1
  %t159 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t158)
  call void @llvm.memcpy.p0.p0.i64(ptr %t159, ptr %t157, i64 %t158, i1 false)
  %t160 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t161 = insertvalue { i64, ptr } %t160, ptr %t159, 1
  store { i64, ptr } %t161, ptr %l83, !tbaa !27
  br label %bb50
bb50:
  %t163 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t163, ptr %l7, !tbaa !27
  %t164 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t165 = load i1, ptr %t164, !tbaa !21
  store i1 %t165, ptr %l92, !tbaa !21
  %t166 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t168 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t166)
  store { i64, ptr } %t168, ptr %l94
  br label %bb51
bb51:
  %t169 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t169, ptr %l95, !tbaa !27
  %t170 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s9)
  store { i64, ptr } %t170, ptr %l96
  br label %bb52
bb52:
  %t171 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t171, 0
  %t173 = extractvalue { i64, ptr } %t171, 1
  %t174 = mul i64 %t172, 1
  %t175 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t174)
  call void @llvm.memcpy.p0.p0.i64(ptr %t175, ptr %t173, i64 %t174, i1 false)
  %t176 = insertvalue { i64, ptr } undef, i64 %t172, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  %t178 = load i1, ptr %l92, !tbaa !21
  %t179 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t180 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t182 = call i32 @compiler_2ffix_2eFiles(ptr %s0, ptr %s9, ptr %s9, i1 %t178, { i64, ptr } %t179, { i64, ptr } %t180, { i64, ptr } %t177)
  store i32 %t182, ptr %l98
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t183 = load i32, ptr %l98, !tbaa !23
  store i32 %t183, ptr %rv
  br label %ret
bb54:
  %t184 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t185 = load i64, ptr %t184, !tbaa !24
  %t186 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t189 = icmp eq i64 %t185, %t186
  br i1 %t189, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s11
  %t191 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t193 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t191, i64 0)
  store { i64, ptr } %t193, ptr %l103
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t194 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  store { i64, ptr } %t195, ptr %l104, !tbaa !27
  %t196 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s11)
  store { i64, ptr } %t196, ptr %l105
  br label %bb58
bb58:
  %t197 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t198 = extractvalue { i64, ptr } %t197, 0
  %t199 = extractvalue { i64, ptr } %t197, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t204 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t205 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t207 = call i32 @compiler_2fbindgen_2eRun(ptr %s0, ptr %s0, ptr %s11, { i64, ptr } %t204, { i64, ptr } %t205, { i64, ptr } %t203)
  store i32 %t207, ptr %l107
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t208 = load i32, ptr %l107, !tbaa !23
  store i32 %t208, ptr %rv
  br label %ret
bb60:
  %t209 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t210 = load i64, ptr %t209, !tbaa !24
  %t211 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t214 = icmp eq i64 %t210, %t211
  br i1 %t214, label %bb61, label %bb62
bb61:
  %t216 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t218 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t216)
  store { i64, ptr } %t218, ptr %l112
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t219 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t221 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 10
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t223 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t227 = call i32 @compiler_2fsession_2eDocMode(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t223, { i64, ptr } %t220, { i64, ptr } %t222, ptr %l3)
  store i32 %t227, ptr %l116
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t228 = load i32, ptr %l116, !tbaa !23
  store i32 %t228, ptr %rv
  br label %ret
bb65:
  %t229 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t230 = load i64, ptr %t229, !tbaa !24
  %t231 = load i64, ptr @G_2ecompiler_2folang_2eApi, !tbaa !24
  %t234 = icmp eq i64 %t230, %t231
  br i1 %t234, label %bb66, label %bb67
bb66:
  %t236 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t238 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t236, i64 0)
  store { i64, ptr } %t238, ptr %l121
  br label %bb68
bb67:
  br label %bb72
bb68:
  %t239 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t241 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t239, i64 1)
  store { i64, ptr } %t241, ptr %l123
  br label %bb69
bb69:
  %t242 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t244 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t242, i64 2)
  store { i64, ptr } %t244, ptr %l125
  br label %bb70
bb70:
  %t245 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t246 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t247 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t249 = call i32 @compiler_2fapi_2eMode(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t245, { i64, ptr } %t246, { i64, ptr } %t247, ptr %l3)
  store i32 %t249, ptr %l127
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s0)
  %t250 = load i32, ptr %l127, !tbaa !23
  store i32 %t250, ptr %rv
  br label %ret
bb72:
  %t251 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t252 = load i64, ptr %t251, !tbaa !24
  %t253 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t256 = icmp eq i64 %t252, %t253
  br i1 %t256, label %bb73, label %bb74
bb73:
  %t259 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t259, ptr %l132
  br label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_scope_close(ptr %s0)
  %t260 = load i32, ptr %l132, !tbaa !23
  store i32 %t260, ptr %rv
  br label %ret
bb76:
  %t261 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t262 = load i64, ptr %t261, !tbaa !24
  %t263 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t266 = icmp eq i64 %t262, %t263
  br i1 %t266, label %bb77, label %bb78
bb77:
  store %olang.scope zeroinitializer, ptr %s15
  store ptr %l3, ptr %l136, !tbaa !29
  %t268 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s15, ptr %s15, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t269 = extractvalue { i32, { i64, ptr } } %t268, 1
  %t270 = extractvalue { i32, { i64, ptr } } %t268, 0
  store i32 %t270, ptr %l139
  %t271 = icmp ne i32 %t270, 0
  br i1 %t271, label %bb80, label %ok.272, !prof !99
ok.272:
  store { i64, ptr } %t269, ptr %l138
  br label %bb79
bb78:
  br label %bb84
bb79:
  %t273 = load { i64, ptr }, ptr %l138, !tbaa !27
  store { i64, ptr } %t273, ptr %l137, !tbaa !27
  br label %bb82
bb80:
  %t274 = load i32, ptr %l139, !tbaa !23
  %t275 = ashr i32 %t274, 16
  %t277 = icmp eq i32 %t275, 1
  store i1 %t277, ptr %l141, !tbaa !21
  br label %bb81
bb81:
  call void @__olang_ert_req_clear()
  %t278 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t278, ptr %l142, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %l142, i32 0, i32 1
  %t280 = load ptr, ptr %t279, !tbaa !27
  %t281 = getelementptr { i64, ptr }, ptr %t280, i64 0
  %t282 = load { i64, ptr }, ptr %t281, !tbaa !37
  %t284 = extractvalue { i64, ptr } %t282, 1
  %t285 = extractvalue { i64, ptr } %t282, 0
  %t286 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t284, i64 %t285)
  %t287 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t288 = insertvalue { i64, ptr } %t287, ptr %t286, 1
  %t290 = extractvalue { i64, ptr } %t288, 0
  %t291 = extractvalue { i64, ptr } %t288, 1
  %t292 = mul i64 %t290, 1
  %t293 = call ptr @__olang_scope_alloc(ptr %s15, i64 %t292)
  call void @llvm.memcpy.p0.p0.i64(ptr %t293, ptr %t291, i64 %t292, i1 false)
  %t294 = insertvalue { i64, ptr } undef, i64 %t290, 0
  %t295 = insertvalue { i64, ptr } %t294, ptr %t293, 1
  store { i64, ptr } %t295, ptr %l137, !tbaa !27
  br label %bb82
bb82:
  %t297 = load ptr, ptr %l136, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t299 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s15, ptr %t297, { i64, ptr } %t298)
  store i32 %t299, ptr %l146
  br label %bb83
bb83:
  call void @__olang_scope_close(ptr %s15)
  call void @__olang_scope_close(ptr %s0)
  %t300 = load i32, ptr %l146, !tbaa !23
  store i32 %t300, ptr %rv
  br label %ret
bb84:
  %t301 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t303 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t301)
  store { i64, ptr } %t303, ptr %l148
  br label %bb85
bb85:
  %t304 = load { i64, ptr }, ptr %l148, !tbaa !27
  store { i64, ptr } %t304, ptr %l8, !tbaa !27
  %t305 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t306 = load i64, ptr %t305, !tbaa !24
  %t307 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t310 = icmp eq i64 %t306, %t307
  br i1 %t310, label %bb86, label %bb87
bb86:
  %t312 = load ptr, ptr %l1, !tbaa !29
  %t313 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t313, ptr %l154, !tbaa !27
  %t314 = getelementptr { i64, ptr }, ptr %l154, i32 0, i32 1
  %t315 = load ptr, ptr %t314, !tbaa !27
  %t316 = getelementptr { i64, ptr }, ptr %t315, i64 0
  %t317 = load { i64, ptr }, ptr %t316, !tbaa !37
  %t322 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t312, ptr %l3, { i64, ptr } %t317, ptr %l2)
  store i32 %t322, ptr %l157
  br label %bb88
bb87:
  br label %bb89
bb88:
  call void @__olang_scope_close(ptr %s0)
  %t323 = load i32, ptr %l157, !tbaa !23
  store i32 %t323, ptr %rv
  br label %ret
bb89:
  %t324 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t325 = load i64, ptr %t324, !tbaa !24
  %t326 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t329 = icmp eq i64 %t325, %t326
  br i1 %t329, label %bb90, label %bb91
bb90:
  %t331 = load ptr, ptr %l1, !tbaa !29
  %t332 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t332, ptr %l163, !tbaa !27
  %t333 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t334 = load ptr, ptr %t333, !tbaa !27
  %t335 = getelementptr { i64, ptr }, ptr %t334, i64 0
  %t336 = load { i64, ptr }, ptr %t335, !tbaa !37
  %t341 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t331, ptr %l3, { i64, ptr } %t336, ptr %l2)
  store i32 %t341, ptr %l166
  br label %bb92
bb91:
  br label %bb93
bb92:
  call void @__olang_scope_close(ptr %s0)
  %t342 = load i32, ptr %l166, !tbaa !23
  store i32 %t342, ptr %rv
  br label %ret
bb93:
  %t343 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t344 = load i64, ptr %t343, !tbaa !24
  %t345 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t348 = icmp eq i64 %t344, %t345
  br i1 %t348, label %bb94, label %bb95
bb94:
  %t350 = load ptr, ptr %l1, !tbaa !29
  store ptr %t350, ptr %l170, !tbaa !29
  store ptr %l3, ptr %l171, !tbaa !29
  %t351 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t351, ptr %l172, !tbaa !27
  %t352 = getelementptr { i64, ptr }, ptr %l172, i32 0, i32 1
  %t353 = load ptr, ptr %t352, !tbaa !27
  %t354 = getelementptr { i64, ptr }, ptr %t353, i64 0
  %t355 = load { i64, ptr }, ptr %t354, !tbaa !37
  store { i64, ptr } %t355, ptr %l173, !tbaa !27
  %t356 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t358 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t356)
  store { i64, ptr } %t358, ptr %l175
  br label %bb96
bb95:
  br label %bb98
bb96:
  %t359 = load ptr, ptr %l170, !tbaa !29
  %t360 = load ptr, ptr %l171, !tbaa !29
  %t361 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t362 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t364 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t359, ptr %t360, { i64, ptr } %t361, { i64, ptr } %t362, ptr %l2)
  store i32 %t364, ptr %l177
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s0)
  %t365 = load i32, ptr %l177, !tbaa !23
  store i32 %t365, ptr %rv
  br label %ret
bb98:
  %t366 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t367 = load i64, ptr %t366, !tbaa !24
  %t368 = load i64, ptr @G_2ecompiler_2folang_2eProfile, !tbaa !24
  %t371 = icmp eq i64 %t367, %t368
  br i1 %t371, label %bb99, label %bb100
bb99:
  %t373 = load ptr, ptr %l1, !tbaa !29
  store ptr %t373, ptr %l181, !tbaa !29
  store ptr %l3, ptr %l182, !tbaa !29
  %t374 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t374, ptr %l183, !tbaa !27
  %t375 = getelementptr { i64, ptr }, ptr %l183, i32 0, i32 1
  %t376 = load ptr, ptr %t375, !tbaa !27
  %t377 = getelementptr { i64, ptr }, ptr %t376, i64 0
  %t378 = load { i64, ptr }, ptr %t377, !tbaa !37
  store { i64, ptr } %t378, ptr %l184, !tbaa !27
  %t379 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t381 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t379)
  store { i64, ptr } %t381, ptr %l186
  br label %bb101
bb100:
  br label %bb103
bb101:
  %t382 = load ptr, ptr %l181, !tbaa !29
  %t383 = load ptr, ptr %l182, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l184, !tbaa !27
  %t385 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t387 = call i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t382, ptr %t383, { i64, ptr } %t384, { i64, ptr } %t385, ptr %l2)
  store i32 %t387, ptr %l188
  br label %bb102
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t388 = load i32, ptr %l188, !tbaa !23
  store i32 %t388, ptr %rv
  br label %ret
bb103:
  %t389 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t390 = load i64, ptr %t389, !tbaa !24
  %t391 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t394 = icmp eq i64 %t390, %t391
  br i1 %t394, label %bb104, label %bb105
bb104:
  store %olang.scope zeroinitializer, ptr %s21
  %t396 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s21, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t396, ptr %l192
  br label %bb106
bb105:
  br label %bb119
bb106:
  %t397 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l192
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t397, ptr %l9
  %t398 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t398, ptr %l194, !tbaa !27
  %t399 = getelementptr { i64, ptr }, ptr %l194, i32 0, i32 1
  %t400 = load ptr, ptr %t399, !tbaa !27
  %t401 = getelementptr { i64, ptr }, ptr %t400, i64 0
  %t402 = load { i64, ptr }, ptr %t401, !tbaa !37
  %t404 = extractvalue { i64, ptr } %t402, 1
  %t405 = extractvalue { i64, ptr } %t402, 0
  %t406 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t405)
  call void @olang_textcopy(ptr %t406, ptr %t404, i64 %t405)
  %t407 = insertvalue { i64, ptr } undef, i64 %t405, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t406, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s21, ptr %s21, ptr %l9, { i64, ptr } %t415)
  br label %bb107
bb107:
  %t418 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  store ptr %t418, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb108
bb108:
  %t420 = load i64, ptr %l11, !tbaa !24
  store i64 %t420, ptr %l199, !tbaa !24
  %t421 = load ptr, ptr %l10, !tbaa !29
  %t423 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t421)
  store i64 %t423, ptr %l201
  br label %bb109
bb109:
  %t424 = load i64, ptr %l199, !tbaa !24
  %t425 = load i64, ptr %l201, !tbaa !24
  %t426 = icmp slt i64 %t424, %t425
  %t428 = xor i1 %t426, true
  br i1 %t428, label %bb110, label %bb111
bb110:
  br label %bb116
bb111:
  br label %bb112
bb112:
  %t430 = load ptr, ptr %l10, !tbaa !29
  %t431 = load i64, ptr %l11, !tbaa !24
  %t434 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t430, i64 %t431)
  store { i64, ptr } %t434, ptr %l206
  br label %bb113
bb113:
  %t435 = load { i64, ptr }, ptr %l206, !tbaa !27
  %t438 = extractvalue { i64, ptr } %t435, 1
  %t439 = extractvalue { i64, ptr } %t435, 0
  %t440 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t439)
  call void @olang_textcopy(ptr %t440, ptr %t438, i64 %t439)
  %t441 = insertvalue { i64, ptr } undef, i64 %t439, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  %t444 = extractvalue { i64, ptr } %t442, 0
  %t445 = extractvalue { i64, ptr } %t442, 1
  %t446 = mul i64 %t444, 1
  %t447 = call ptr @__olang_scope_alloc(ptr %s21, i64 %t446)
  call void @llvm.memcpy.p0.p0.i64(ptr %t447, ptr %t445, i64 %t446, i1 false)
  %t448 = insertvalue { i64, ptr } undef, i64 %t444, 0
  %t449 = insertvalue { i64, ptr } %t448, ptr %t447, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s21, ptr %s21, ptr %l9, { i64, ptr } %t449)
  br label %bb114
bb114:
  br label %bb115
bb115:
  %t452 = load i64, ptr %l11, !tbaa !24
  %t454 = add i64 %t452, 1
  store i64 %t454, ptr %l11, !tbaa !24
  br label %bb108
bb116:
  %t456 = load ptr, ptr %l1, !tbaa !29
  store ptr %t456, ptr %l213, !tbaa !29
  store ptr %l3, ptr %l214, !tbaa !29
  %t457 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t457, ptr %l215, !tbaa !27
  %t458 = getelementptr { i64, ptr }, ptr %l215, i32 0, i32 1
  %t459 = load ptr, ptr %t458, !tbaa !27
  %t460 = getelementptr { i64, ptr }, ptr %t459, i64 0
  %t461 = load { i64, ptr }, ptr %t460, !tbaa !37
  store { i64, ptr } %t461, ptr %l216, !tbaa !27
  %t463 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s21, ptr %s21, ptr %l9)
  store { i64, ptr } %t463, ptr %l218
  br label %bb117
bb117:
  %t464 = load ptr, ptr %l213, !tbaa !29
  %t465 = load ptr, ptr %l214, !tbaa !29
  %t466 = load { i64, ptr }, ptr %l216, !tbaa !27
  %t467 = load { i64, ptr }, ptr %l218, !tbaa !27
  %t469 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s21, ptr %t464, ptr %t465, { i64, ptr } %t466, { i64, ptr } %t467, ptr %l2)
  store i32 %t469, ptr %l220
  br label %bb118
bb118:
  call void @__olang_scope_close(ptr %s21)
  call void @__olang_scope_close(ptr %s0)
  %t470 = load i32, ptr %l220, !tbaa !23
  store i32 %t470, ptr %rv
  br label %ret
bb119:
  %t471 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t473 = extractvalue { i64, ptr } %t471, 0
  %t475 = icmp eq i64 %t473, 1
  br i1 %t475, label %bb120, label %bb121
bb120:
  %t477 = load ptr, ptr %l1, !tbaa !29
  store ptr %t477, ptr %l224, !tbaa !29
  store ptr %l3, ptr %l225, !tbaa !29
  %t478 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t478, ptr %l226, !tbaa !27
  %t479 = getelementptr { i64, ptr }, ptr %l226, i32 0, i32 1
  %t480 = load ptr, ptr %t479, !tbaa !27
  %t481 = getelementptr { i64, ptr }, ptr %t480, i64 0
  %t482 = load { i64, ptr }, ptr %t481, !tbaa !37
  store { i64, ptr } %t482, ptr %l227, !tbaa !27
  store ptr %l2, ptr %l228, !tbaa !29
  %t483 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t485 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t483)
  store { i64, ptr } %t485, ptr %l230
  br label %bb122
bb121:
  br label %bb124
bb122:
  %t486 = load ptr, ptr %l224, !tbaa !29
  %t487 = load ptr, ptr %l225, !tbaa !29
  %t488 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t489 = load ptr, ptr %l228, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l230, !tbaa !27
  %t491 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t486, ptr %t487, { i64, ptr } %t488, ptr %t489, { i64, ptr } %t490)
  store i32 %t491, ptr %l231
  br label %bb123
bb123:
  call void @__olang_scope_close(ptr %s0)
  %t492 = load i32, ptr %l231, !tbaa !23
  store i32 %t492, ptr %rv
  br label %ret
bb124:
  %t493 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t494 = extractvalue { i32, { i64, ptr } } %t493, 1
  %t495 = extractvalue { i32, { i64, ptr } } %t493, 0
  store i32 %t495, ptr %l234
  %t496 = icmp ne i32 %t495, 0
  br i1 %t496, label %bb126, label %ok.497, !prof !99
ok.497:
  store { i64, ptr } %t494, ptr %l233
  br label %bb125
bb125:
  %t498 = load { i64, ptr }, ptr %l233, !tbaa !27
  store { i64, ptr } %t498, ptr %l232, !tbaa !27
  br label %bb128
bb126:
  %t499 = load i32, ptr %l234, !tbaa !23
  %t500 = ashr i32 %t499, 16
  %t502 = icmp eq i32 %t500, 1
  store i1 %t502, ptr %l236, !tbaa !21
  br label %bb127
bb127:
  call void @__olang_ert_req_clear()
  %t503 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t503, ptr %l237, !tbaa !27
  %t504 = getelementptr { i64, ptr }, ptr %l237, i32 0, i32 1
  %t505 = load ptr, ptr %t504, !tbaa !27
  %t506 = getelementptr { i64, ptr }, ptr %t505, i64 0
  %t507 = load { i64, ptr }, ptr %t506, !tbaa !37
  %t509 = extractvalue { i64, ptr } %t507, 1
  %t510 = extractvalue { i64, ptr } %t507, 0
  %t511 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t510)
  call void @olang_textcopy(ptr %t511, ptr %t509, i64 %t510)
  %t512 = insertvalue { i64, ptr } undef, i64 %t510, 0
  %t513 = insertvalue { i64, ptr } %t512, ptr %t511, 1
  %t515 = extractvalue { i64, ptr } %t513, 0
  %t516 = extractvalue { i64, ptr } %t513, 1
  %t517 = mul i64 %t515, 1
  %t518 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t517)
  call void @llvm.memcpy.p0.p0.i64(ptr %t518, ptr %t516, i64 %t517, i1 false)
  %t519 = insertvalue { i64, ptr } undef, i64 %t515, 0
  %t520 = insertvalue { i64, ptr } %t519, ptr %t518, 1
  store { i64, ptr } %t520, ptr %l232, !tbaa !27
  br label %bb128
bb128:
  %t522 = load { i64, ptr }, ptr %l232, !tbaa !27
  store ptr %l3, ptr %l241, !tbaa !29
  store { i64, ptr } %t522, ptr %l242, !tbaa !27
  %t524 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 6
  %t526 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t524)
  store { i64, ptr } %t526, ptr %l244
  br label %bb129
bb129:
  %t527 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t527, ptr %l245, !tbaa !27
  %t528 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t530 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t528)
  store { i64, ptr } %t530, ptr %l247
  br label %bb130
bb130:
  %t531 = load ptr, ptr %l241, !tbaa !29
  %t532 = load { i64, ptr }, ptr %l242, !tbaa !27
  %t533 = load { i64, ptr }, ptr %l244, !tbaa !27
  %t534 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t535 = load { i64, ptr }, ptr %l247, !tbaa !27
  %t536 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t531, { i64, ptr } %t532, { i64, ptr } %t533, { i64, ptr } %t534, { i64, ptr } %t535)
  store i32 %t536, ptr %l248
  br label %bb131
bb131:
  call void @__olang_scope_close(ptr %s0)
  %t537 = load i32, ptr %l248, !tbaa !23
  store i32 %t537, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca %"compiler/profile:Profile"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/profile:Places"
  %l25 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, [3 x i64] }
  %l41 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i32
  %l74 = alloca i1
  %l80 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca { i64, [3 x i64] }
  %l85 = alloca %"compiler/msgs:Msg"
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l101 = alloca %"compiler/profile:Profile"
  %l104 = alloca %"compiler/profile:Profile"
  %l105 = alloca i32
  %l107 = alloca i1
  %l112 = alloca { i64, ptr }
  %l115 = alloca %"compiler/profile:Places"
  %l119 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l130 = alloca i32
  %l132 = alloca i1
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t62 = alloca { i64, [3 x i64] }, align 8
  %t226 = alloca { i64, [3 x i64] }, align 8
  %t331 = alloca %"compiler/profile:Places", align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 18
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 18
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t14, !tbaa !27
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 17
  store i1 true, ptr %t17, !tbaa !21
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/build:Config", ptr %t18, i32 0, i32 12
  store i1 true, ptr %t20, !tbaa !21
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t29 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t22, { i64, ptr } %t23, ptr %t24)
  store i32 %t29, ptr %l25
  br label %bb1
bb1:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb2, label %bb3
bb2:
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t35, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/build:Config", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t52)
  store i32 %t54, ptr %l33
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb6, label %ok.56, !prof !99
ok.56:
  br label %bb5
bb5:
  br label %bb11
bb6:
  %t57 = load i32, ptr %l33, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t64 = load { i64, [3 x i64] }, ptr %t62
  store { i64, [3 x i64] } %t64, ptr %l37
  %t65 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t66 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t69 = extractvalue { i64, ptr } %t65, 1
  %t70 = extractvalue { i64, ptr } %t65, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t66, i64 %t67)
  %t76 = getelementptr i8, ptr %t75, i64 %t67
  call void @olang_textcopy(ptr %t76, ptr %t69, i64 %t70)
  %t77 = getelementptr i8, ptr %t76, i64 %t70
  call void @olang_textcopy(ptr %t77, ptr %t72, i64 %t73)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t75, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s4, ptr %s4, { i64, ptr } %t86)
  store %"compiler/msgs:Msg" %t88, ptr %l41
  br label %bb8
bb8:
  %t89 = load ptr, ptr %l36, !tbaa !29
  %t90 = load { i64, [3 x i64] }, ptr %l37
  %t91 = load %"compiler/msgs:Msg", ptr %l41
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s4, ptr %t89, { i64, [3 x i64] } %t90, %"compiler/msgs:Msg" %t91)
  br label %bb9
bb9:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = call i32 @compiler_2fbuild_2eFinish(ptr %v1, ptr %t92)
  store i32 %t94, ptr %l43
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i32, ptr %l43, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb11:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 19
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, { i64, ptr } %t99)
  store { i64, ptr } %t101, ptr %l46
  br label %bb12
bb12:
  %t102 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t103, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  %t106 = extractvalue { i32, i64 } %t105, 1
  %t107 = extractvalue { i32, i64 } %t105, 0
  store i32 %t107, ptr %l50
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb14, label %ok.109, !prof !99
ok.109:
  store i64 %t106, ptr %l49
  br label %bb13
bb13:
  %t110 = load i64, ptr %l49, !tbaa !24
  store i64 %t110, ptr %l47, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l47, !tbaa !24
  br label %bb16
bb16:
  %t115 = load i64, ptr %l47, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t116, ptr %l53, !tbaa !27
  store i64 %t115, ptr %l54, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l55, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = load i64, ptr %l54, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb19:
  %t125 = load i64, ptr %l54, !tbaa !24
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb21:
  %t129 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l54, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  store { i64, ptr } %t135, ptr %l8, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t137, 1
  %t141 = extractvalue { i64, ptr } %t137, 0
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = extractvalue { i64, ptr } %t138, 1
  %t147 = extractvalue { i64, ptr } %t138, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t142, i64 %t143)
  %t154 = getelementptr i8, ptr %t153, i64 %t143
  call void @olang_textcopy(ptr %t154, ptr %t146, i64 %t147)
  %t155 = getelementptr i8, ptr %t154, i64 %t147
  call void @olang_textcopy(ptr %t155, ptr %t149, i64 %t150)
  %t156 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t152, 1
  store { i64, ptr } %t157, ptr %l10, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t159, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t161, ptr %l64
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb23:
  %t162 = load i1, ptr %l64, !tbaa !21
  br i1 %t162, label %bb24, label %bb25
bb24:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = extractvalue { i64, ptr } %t163, 0
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t172 = extractvalue { i64, ptr } %t164, 1
  %t173 = extractvalue { i64, ptr } %t164, 0
  %t174 = add i64 %t170, %t173
  %t175 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t166, i64 %t167)
  %t179 = getelementptr i8, ptr %t178, i64 %t167
  call void @olang_textcopy(ptr %t179, ptr %t168, i64 %t169)
  %t180 = getelementptr i8, ptr %t179, i64 %t169
  call void @olang_textcopy(ptr %t180, ptr %t172, i64 %t173)
  %t181 = getelementptr i8, ptr %t180, i64 %t173
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t178, 1
  store { i64, ptr } %t183, ptr %l67, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l69, !tbaa !24
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = icmp eq i64 %t185, %t189
  br i1 %t190, label %bb26, label %bb27
bb25:
  br label %bb29
bb26:
  %t192 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l69, !tbaa !24
  %t197 = mul i64 %t196, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %t195, i64 %t197, i1 false)
  br label %bb28
bb27:
  %t198 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t198, ptr %l5, !tbaa !27
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t199 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t201 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t199)
  store i32 %t201, ptr %l72
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb31, label %ok.203, !prof !99
ok.203:
  br label %bb30
bb30:
  br label %bb33
bb31:
  %t204 = load i32, ptr %l72, !tbaa !23
  %t205 = ashr i32 %t204, 16
  %t207 = icmp eq i32 %t205, 1
  store i1 %t207, ptr %l74, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  br label %bb33
bb33:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/build:Config", ptr %t208, i32 0, i32 19
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t219 = call i32 @compiler_2fprofile_2erunProfiled(ptr %v1, ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t211, { i64, ptr } %t212, { i64, ptr } %a3, { i64, ptr } %t214)
  store i32 %t219, ptr %l80
  br label %bb34
bb34:
  %t220 = load i32, ptr %l80, !tbaa !23
  store i32 %t220, ptr %l6, !tbaa !23
  %t221 = load i32, ptr %l6, !tbaa !23
  %t223 = icmp slt i32 %t221, 0
  br i1 %t223, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t225 = load ptr, ptr %l4, !tbaa !29
  store ptr %t225, ptr %l83, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 0
  store i64 0, ptr %t227
  %t228 = load { i64, [3 x i64] }, ptr %t226
  store { i64, [3 x i64] } %t228, ptr %l84
  %t229 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s10, ptr %s10, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t229, ptr %l85
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t230 = load ptr, ptr %l83, !tbaa !29
  %t231 = load { i64, [3 x i64] }, ptr %l84
  %t232 = load %"compiler/msgs:Msg", ptr %l85
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s10, ptr %t230, { i64, [3 x i64] } %t231, %"compiler/msgs:Msg" %t232)
  br label %bb38
bb38:
  %t233 = load ptr, ptr %l4, !tbaa !29
  %t235 = call i32 @compiler_2fbuild_2eFinish(ptr %v1, ptr %t233)
  store i32 %t235, ptr %l87
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t236 = load i32, ptr %l87, !tbaa !23
  store i32 %t236, ptr %rv
  br label %ret
bb40:
  %t237 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t239 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t237)
  %t240 = extractvalue { i32, { i64, ptr } } %t239, 1
  %t241 = extractvalue { i32, { i64, ptr } } %t239, 0
  store i32 %t241, ptr %l91
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb42, label %ok.243, !prof !99
ok.243:
  store { i64, ptr } %t240, ptr %l90
  br label %bb41
bb41:
  %t244 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t244, ptr %l88, !tbaa !27
  br label %bb46
bb42:
  %t245 = load i32, ptr %l91, !tbaa !23
  %t246 = ashr i32 %t245, 16
  %t248 = icmp eq i32 %t246, 1
  store i1 %t248, ptr %l93, !tbaa !21
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t249, ptr %l94, !tbaa !27
  %t250 = load i32, ptr %l6, !tbaa !23
  %t252 = sub i32 %t250, 128
  %t254 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t252)
  store { i64, ptr } %t254, ptr %l97
  br label %bb44
bb44:
  %t255 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t257 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t255, i64 %t256)
  %t272 = getelementptr i8, ptr %t271, i64 %t256
  call void @olang_textcopy(ptr %t272, ptr %t258, i64 %t259)
  %t273 = getelementptr i8, ptr %t272, i64 %t259
  call void @olang_textcopy(ptr %t273, ptr %t261, i64 %t262)
  %t274 = getelementptr i8, ptr %t273, i64 %t262
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t271, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } %t277, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  call void @compiler_2fprofile_2esay(ptr %s11, { i64, ptr } %t284)
  br label %bb45
bb45:
  %t286 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t286, ptr %rv
  br label %ret
bb46:
  %t288 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t292 = call { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t288)
  %t293 = extractvalue { i32, %"compiler/profile:Profile" } %t292, 1
  %t294 = extractvalue { i32, %"compiler/profile:Profile" } %t292, 0
  store i32 %t294, ptr %l105
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb48, label %ok.296, !prof !99
ok.296:
  store %"compiler/profile:Profile" %t293, ptr %l104
  br label %bb47
bb47:
  %t297 = load %"compiler/profile:Profile", ptr %l104
  store %"compiler/profile:Profile" %t297, ptr %l101
  br label %bb51
bb48:
  %t298 = load i32, ptr %l105, !tbaa !23
  %t299 = ashr i32 %t298, 16
  %t301 = icmp eq i32 %t299, 1
  store i1 %t301, ptr %l107, !tbaa !21
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t303 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t306 = extractvalue { i64, ptr } %t302, 1
  %t307 = extractvalue { i64, ptr } %t302, 0
  %t308 = add i64 %t304, %t307
  %t309 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t303, i64 %t304)
  %t313 = getelementptr i8, ptr %t312, i64 %t304
  call void @olang_textcopy(ptr %t313, ptr %t306, i64 %t307)
  %t314 = getelementptr i8, ptr %t313, i64 %t307
  call void @olang_textcopy(ptr %t314, ptr %t309, i64 %t310)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t312, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  call void @compiler_2fprofile_2esay(ptr %s13, { i64, ptr } %t323)
  br label %bb50
bb50:
  %t325 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t325, ptr %rv
  br label %ret
bb51:
  %t327 = load %"compiler/profile:Profile", ptr %l101
  store %"compiler/profile:Profile" %t327, ptr %l12
  %t328 = call { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %s0)
  store { i64, ptr } %t328, ptr %l112
  br label %bb52
bb52:
  %t329 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t329, ptr %l13, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fprofile_2eResolve(ptr %t331, ptr %s0, ptr %s0, ptr %s0, ptr %l12, { i64, ptr } %t330)
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %t331, i64 272, i1 false)
  br label %bb53
bb53:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l115, i64 272, i1 false)
  %t334 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t338 = call { i64, ptr } @compiler_2fprofile_2eReport(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t334, ptr %l12, ptr %l14)
  store { i64, ptr } %t338, ptr %l119
  br label %bb54
bb54:
  %t339 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  %t341 = extractvalue { i64, ptr } %t339, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t345)
  br label %bb55
bb55:
  %t347 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t349 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t347, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t349, ptr %l122
  br label %bb56
bb56:
  %t350 = load i1, ptr %l122, !tbaa !21
  br i1 %t350, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s15
  call void @compiler_2fprofile_2esay(ptr %s15, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s15)
  br label %bb60
bb60:
  %t351 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t351, ptr %l123, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t356 = call { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t352, ptr %l12, ptr %l14)
  store { i64, ptr } %t356, ptr %l127
  br label %bb61
bb61:
  %t357 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t360 = extractvalue { i64, ptr } %t357, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t365 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t367 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t365, { i64, ptr } %t364)
  store i32 %t367, ptr %l130
  %t368 = icmp ne i32 %t367, 0
  br i1 %t368, label %bb63, label %ok.369, !prof !99
ok.369:
  br label %bb62
bb62:
  br label %bb66
bb63:
  %t370 = load i32, ptr %l130, !tbaa !23
  %t371 = ashr i32 %t370, 16
  %t373 = icmp eq i32 %t371, 1
  store i1 %t373, ptr %l132, !tbaa !21
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s16
  %t374 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t375 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t378 = extractvalue { i64, ptr } %t374, 1
  %t379 = extractvalue { i64, ptr } %t374, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t384 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t383)
  call void @olang_textcopy(ptr %t384, ptr %t375, i64 %t376)
  %t385 = getelementptr i8, ptr %t384, i64 %t376
  call void @olang_textcopy(ptr %t385, ptr %t378, i64 %t379)
  %t386 = getelementptr i8, ptr %t385, i64 %t379
  call void @olang_textcopy(ptr %t386, ptr %t381, i64 %t382)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t384, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  call void @compiler_2fprofile_2esay(ptr %s16, { i64, ptr } %t395)
  br label %bb65
bb65:
  %t397 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t397, ptr %rv
  br label %ret
bb66:
  %t399 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t401 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t399)
  store { i64, ptr } %t401, ptr %l138
  br label %bb67
bb67:
  %t402 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t403 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t404 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = add i64 %t403, %t406
  %t408 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t410 = add i64 %t407, %t409
  %t411 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t410)
  call void @olang_textcopy(ptr %t411, ptr %t402, i64 %t403)
  %t412 = getelementptr i8, ptr %t411, i64 %t403
  call void @olang_textcopy(ptr %t412, ptr %t405, i64 %t406)
  %t413 = getelementptr i8, ptr %t412, i64 %t406
  call void @olang_textcopy(ptr %t413, ptr %t408, i64 %t409)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t411, 1
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t418 = extractvalue { i64, ptr } %t415, 1
  %t419 = mul i64 %t417, 1
  %t420 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t418, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t422)
  br label %bb68
bb68:
  %t424 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t424, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eRef_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/emit:Reused", ptr %t7, i64 %a1
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/scope:Gap" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eAt_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/scope:Gap"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/scope:Gap", ptr %t7, i64 %a1
  %t9 = load %"compiler/scope:Gap", ptr %t8
  store %"compiler/scope:Gap" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/scope:Gap", ptr %rv
  ret %"compiler/scope:Gap" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fscope_3aGap_3e_2eLen_3ccompiler_2fscope_3aGap_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_ert_req_clear()
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d11 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_test" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": native compilation failed" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"== " }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ==" }>, align 8
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"36" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c": the tests ended by a signal (" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d28 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d30 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/profile" }>, align 8
@.d33 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"its profile's directory " }>, align 8
@.d34 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot be made" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d37 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".samples" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d40 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d41 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d42 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d43 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" wrote no profile - it ended by a signal (" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d45 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d46 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is not a profile this compiler writes\0A" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"olang profile: no llvm-symbolizer found beside clang or on PATH - functions named by their addresses\0A" }>, align 8
@.d49 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d50 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be written\0A" }>, align 8
@.d51 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"flame graph: " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_251e830707558b33_b2bdace7e2a71047 = external constant [0 x i8]
declare void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_44996bcc7c9bda8_515f8c8db8b0565c = external constant [0 x i8]
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2ePrepare(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eFix = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@G_2ecompiler_2folang_2eBindgen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eApi = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eProfile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2eFinish(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2308270aeb54ce5f_1121c256bef46e33 = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0)
declare void @compiler_2fprofile_2eResolve(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
