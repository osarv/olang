; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, { i64, ptr }, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Listed" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/listing:Inputs" = type { ptr, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr } }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"compiler/build:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/explain:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/build:Program"
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i32
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l86 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca i1
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  %t176 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t1, i64 224, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l7, i64 224, i1 false)
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %v3, ptr %a0, { i64, ptr } %t3, i32 1, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l14
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t21)
  store i32 %t23, ptr %l18
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l19
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l18, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l21
  br label %bb13
bb13:
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t40)
  store i32 %t42, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l28, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l31
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l31, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l33, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t55)
  store i32 %t57, ptr %l35
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l35, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v3, ptr %s0, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l41
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l40
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l36
  br label %bb31
bb28:
  %t70 = load i32, ptr %l41, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l43, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t74)
  store i32 %t76, ptr %l45
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l45, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb32
bb32:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t79, i32 0, i32 9
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb33, label %bb34
bb33:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v3, ptr %t84, ptr %l4, ptr %l5, { i64, ptr } %t85, ptr %t86)
  store i32 %t92, ptr %l53
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load i32, ptr %l53, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/build:Config", ptr %t94, i32 0, i32 21
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t99, ptr %l56
  br label %bb37
bb37:
  %t100 = load i1, ptr %l56, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb38, label %bb39
bb38:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/build:Config", ptr %t103, i32 0, i32 21
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = extractvalue { i64, ptr } %t106, 0
  %t110 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t108, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  br label %bb43
bb39:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t119 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t119, ptr %l65
  br label %bb40
bb40:
  %t120 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t126)
  store { i64, ptr } %t128, ptr %l67
  br label %bb41
bb41:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t129)
  store { i64, ptr } %t131, ptr %l69
  br label %bb42
bb42:
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = add i64 %t137, %t140
  %t142 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = add i64 %t141, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t133, i64 %t134)
  %t147 = getelementptr i8, ptr %t146, i64 %t134
  call void @olang_textcopy(ptr %t147, ptr %t135, i64 %t136)
  %t148 = getelementptr i8, ptr %t147, i64 %t136
  call void @olang_textcopy(ptr %t148, ptr %t139, i64 %t140)
  %t149 = getelementptr i8, ptr %t148, i64 %t140
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t146, 1
  store { i64, ptr } %t151, ptr %l58, !tbaa !27
  br label %bb43
bb43:
  %t153 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t153, ptr %l6, !tbaa !27
  %t154 = load ptr, ptr %l1, !tbaa !29
  store ptr %t154, ptr %l71, !tbaa !29
  store ptr %l5, ptr %l72, !tbaa !29
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t155, ptr %l73, !tbaa !27
  %t156 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 2
  %t157 = load { i64, ptr }, ptr %t156, !tbaa !27
  %t159 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t157, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t159, ptr %l75
  br label %bb44
bb44:
  %t160 = load i1, ptr %l75, !tbaa !21
  %t161 = xor i1 %t160, true
  %t162 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 3
  %t163 = load ptr, ptr %l71, !tbaa !29
  %t164 = load ptr, ptr %l72, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t168 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t163, ptr %t164, { i64, ptr } %t165, i1 %t161, ptr %t162, ptr null)
  store i32 %t168, ptr %l78
  %t169 = icmp ne i32 %t168, 0
  br i1 %t169, label %bb46, label %ok.170, !prof !99
ok.170:
  br label %bb45
bb45:
  br label %bb51
bb46:
  %t171 = load i32, ptr %l78, !tbaa !23
  %t172 = ashr i32 %t171, 16
  %t174 = icmp eq i32 %t172, 1
  store i1 %t174, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s9
  %t175 = load ptr, ptr %l3, !tbaa !29
  store ptr %t175, ptr %l81, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t176
  %t177 = getelementptr { i64, [3 x i64] }, ptr %t176, i32 0, i32 0
  store i64 0, ptr %t177
  %t178 = load { i64, [3 x i64] }, ptr %t176
  store { i64, [3 x i64] } %t178, ptr %l82
  %t179 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t181 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s9, { i64, ptr } %t179)
  store %"compiler/diagmsg:Msg" %t181, ptr %l84
  br label %bb48
bb48:
  %t182 = load ptr, ptr %l81, !tbaa !29
  %t183 = load { i64, [3 x i64] }, ptr %l82
  %t184 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v3, ptr %s9, ptr %t182, { i64, [3 x i64] } %t183, %"compiler/diagmsg:Msg" %t184)
  br label %bb49
bb49:
  %t185 = load ptr, ptr %l3, !tbaa !29
  %t187 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t185)
  store i32 %t187, ptr %l86
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t188 = load i32, ptr %l86, !tbaa !23
  store i32 %t188, ptr %rv
  br label %ret
bb51:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb52
bb52:
  %t189 = load ptr, ptr %l1, !tbaa !29
  %t190 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = extractvalue { i64, ptr } %t190, 0
  %t194 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t193)
  call void @olang_textcopy(ptr %t194, ptr %t192, i64 %t193)
  %t195 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  %t198 = extractvalue { i64, ptr } %t196, 0
  %t199 = extractvalue { i64, ptr } %t196, 1
  %t200 = mul i64 %t198, 1
  %t201 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t200)
  call void @llvm.memcpy.p0.p0.i64(ptr %t201, ptr %t199, i64 %t200, i1 false)
  %t202 = insertvalue { i64, ptr } undef, i64 %t198, 0
  %t203 = insertvalue { i64, ptr } %t202, ptr %t201, 1
  %t206 = getelementptr %"compiler/build:Config", ptr %t189, i32 0, i32 22
  store { i64, ptr } %t203, ptr %t206, !tbaa !27
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/build:Config", ptr %t207, i32 0, i32 20
  %t210 = load i1, ptr %t209, !tbaa !21
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t214 = load ptr, ptr %l1, !tbaa !29
  store ptr %t214, ptr %l94, !tbaa !29
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t217 = getelementptr %"compiler/build:Config", ptr %t215, i32 0, i32 21
  %t218 = load { i64, ptr }, ptr %t217, !tbaa !27
  %t220 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s11, { i64, ptr } %t218, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t220, ptr %l97
  br label %bb55
bb54:
  br label %bb62
bb55:
  %t221 = load i1, ptr %l97, !tbaa !21
  %t222 = xor i1 %t221, true
  br i1 %t222, label %bb56, label %bb57
bb56:
  %t224 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t224, ptr %l99, !tbaa !27
  br label %bb59
bb57:
  %t226 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t228 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s11, { i64, ptr } %t226)
  store { i64, ptr } %t228, ptr %l102
  br label %bb58
bb58:
  %t229 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t229, ptr %l99, !tbaa !27
  br label %bb59
bb59:
  %t230 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t231 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t232 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t233 = extractvalue { i64, ptr } %t232, 1
  %t234 = extractvalue { i64, ptr } %t232, 0
  %t235 = add i64 %t231, %t234
  %t236 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t235)
  call void @olang_textcopy(ptr %t236, ptr %t230, i64 %t231)
  %t237 = getelementptr i8, ptr %t236, i64 %t231
  call void @olang_textcopy(ptr %t237, ptr %t233, i64 %t234)
  %t238 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t239 = insertvalue { i64, ptr } %t238, ptr %t236, 1
  %t241 = extractvalue { i64, ptr } %t239, 0
  %t242 = extractvalue { i64, ptr } %t239, 1
  %t243 = mul i64 %t241, 1
  %t244 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t243)
  call void @llvm.memcpy.p0.p0.i64(ptr %t244, ptr %t242, i64 %t243, i1 false)
  %t245 = insertvalue { i64, ptr } undef, i64 %t241, 0
  %t246 = insertvalue { i64, ptr } %t245, ptr %t244, 1
  %t247 = load ptr, ptr %l94, !tbaa !29
  %t249 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s11, ptr %s11, ptr %s11, ptr %t247, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } %t246)
  store { i64, ptr } %t249, ptr %l105
  br label %bb60
bb60:
  %t250 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t251 = extractvalue { i64, ptr } %t250, 0
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = mul i64 %t251, 1
  %t254 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t253)
  call void @llvm.memcpy.p0.p0.i64(ptr %t254, ptr %t252, i64 %t253, i1 false)
  %t255 = insertvalue { i64, ptr } undef, i64 %t251, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t256)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/diagmsg:Msg"
  %l63 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/diagmsg:Msg"
  %l76 = alloca i32
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t1, i64 224, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l8, i64 224, i1 false)
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %v3, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l15
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t21)
  store i32 %t23, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l19, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l22
  br label %bb13
bb13:
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l26
  br label %bb16
bb16:
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t40)
  store i32 %t42, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l29, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l32
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l32, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t55)
  store i32 %t57, ptr %l36
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l36, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v3, ptr %s0, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l42
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l41
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l37
  br label %bb31
bb28:
  %t70 = load i32, ptr %l42, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t74)
  store i32 %t76, ptr %l46
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l46, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  %t80 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store { i64, ptr } %t80, ptr %l48
  br label %bb32
bb32:
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 21
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t87, ptr %l51
  br label %bb33
bb33:
  %t88 = load i1, ptr %l51, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s6, { i64, ptr } %t91)
  %t94 = extractvalue { i32, { i64, ptr } } %t93, 1
  %t95 = extractvalue { i32, { i64, ptr } } %t93, 0
  store i32 %t95, ptr %l56
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb37, label %ok.97, !prof !99
ok.97:
  store { i64, ptr } %t94, ptr %l55
  br label %bb36
bb35:
  br label %bb50
bb36:
  %t98 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t98, ptr %l53, !tbaa !27
  br label %bb42
bb37:
  %t99 = load i32, ptr %l56, !tbaa !23
  %t100 = ashr i32 %t99, 16
  %t102 = icmp eq i32 %t100, 1
  store i1 %t102, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s7
  %t103 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t103, ptr %l59, !tbaa !27
  %t104 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s7)
  store %"compiler/diagmsg:Msg" %t104, ptr %l60
  br label %bb39
bb39:
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t106 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t107 = load %"compiler/diagmsg:Msg", ptr %l60
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s7, ptr %v3, { i64, ptr } %t106, %"compiler/diagmsg:Msg" %t107, ptr %t105)
  br label %bb40
bb40:
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t111 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t109)
  store i32 %t111, ptr %l63
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t112 = load i32, ptr %l63, !tbaa !23
  store i32 %t112, ptr %rv
  br label %ret
bb42:
  %t113 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 21
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  %t122 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t117, { i64, ptr } %t113)
  store i32 %t122, ptr %l68
  %t123 = icmp ne i32 %t122, 0
  br i1 %t123, label %bb44, label %ok.124, !prof !99
ok.124:
  br label %bb43
bb43:
  br label %bb49
bb44:
  %t125 = load i32, ptr %l68, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  store i1 %t128, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s8
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = getelementptr %"compiler/build:Config", ptr %t129, i32 0, i32 21
  %t132 = load { i64, ptr }, ptr %t131, !tbaa !27
  store { i64, ptr } %t132, ptr %l72, !tbaa !27
  %t133 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s8)
  store %"compiler/diagmsg:Msg" %t133, ptr %l73
  br label %bb46
bb46:
  %t134 = load ptr, ptr %l3, !tbaa !29
  %t135 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t136 = load %"compiler/diagmsg:Msg", ptr %l73
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s8, ptr %v3, { i64, ptr } %t135, %"compiler/diagmsg:Msg" %t136, ptr %t134)
  br label %bb47
bb47:
  %t138 = load ptr, ptr %l3, !tbaa !29
  %t140 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t138)
  store i32 %t140, ptr %l76
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t141 = load i32, ptr %l76, !tbaa !23
  store i32 %t141, ptr %rv
  br label %ret
bb49:
  %t142 = load ptr, ptr %l1, !tbaa !29
  %t144 = getelementptr %"compiler/build:Config", ptr %t142, i32 0, i32 21
  %t145 = load { i64, ptr }, ptr %t144, !tbaa !27
  %t147 = extractvalue { i64, ptr } %t145, 1
  %t148 = extractvalue { i64, ptr } %t145, 0
  %t149 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t147, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  %t153 = extractvalue { i64, ptr } %t151, 0
  %t154 = extractvalue { i64, ptr } %t151, 1
  %t155 = mul i64 %t153, 1
  %t156 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t155)
  call void @llvm.memcpy.p0.p0.i64(ptr %t156, ptr %t154, i64 %t155, i1 false)
  %t157 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t158 = insertvalue { i64, ptr } %t157, ptr %t156, 1
  store { i64, ptr } %t158, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = getelementptr %"compiler/build:Config", ptr %t160, i32 0, i32 20
  %t163 = load i1, ptr %t162, !tbaa !21
  %t165 = xor i1 %t163, true
  br i1 %t165, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t167 = load ptr, ptr %l1, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t169 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t172 = extractvalue { i64, ptr } %t168, 1
  %t173 = extractvalue { i64, ptr } %t168, 0
  %t174 = add i64 %t170, %t173
  %t175 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t169, i64 %t170)
  %t176 = getelementptr i8, ptr %t175, i64 %t170
  call void @olang_textcopy(ptr %t176, ptr %t172, i64 %t173)
  %t177 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t178 = insertvalue { i64, ptr } %t177, ptr %t175, 1
  %t180 = extractvalue { i64, ptr } %t178, 0
  %t181 = extractvalue { i64, ptr } %t178, 1
  %t182 = mul i64 %t180, 1
  %t183 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t182)
  call void @llvm.memcpy.p0.p0.i64(ptr %t183, ptr %t181, i64 %t182, i1 false)
  %t184 = insertvalue { i64, ptr } undef, i64 %t180, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t183, 1
  %t188 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t167, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t185)
  store { i64, ptr } %t188, ptr %l88
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t189 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = extractvalue { i64, ptr } %t189, 1
  %t192 = mul i64 %t190, 1
  %t193 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t192)
  call void @llvm.memcpy.p0.p0.i64(ptr %t193, ptr %t191, i64 %t192, i1 false)
  %t194 = insertvalue { i64, ptr } undef, i64 %t190, 0
  %t195 = insertvalue { i64, ptr } %t194, ptr %t193, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t195)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v4, ptr %s0, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l13
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  br label %bb11
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_251e830707558b33_b2bdace7e2a71047)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l18
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t29)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:FileInfo"
  %l6 = alloca i32
  %l7 = alloca %"std/os:FileInfo"
  %l9 = alloca %"std/os:FileInfo"
  %l10 = alloca i32
  %l12 = alloca i1
  %l13 = alloca ptr
  %l14 = alloca { i64, ptr }
  %l15 = alloca %"compiler/diagmsg:Msg"
  %l17 = alloca i32
  %l20 = alloca ptr
  %l21 = alloca { i64, ptr }
  %l22 = alloca %"compiler/diagmsg:Msg"
  %l24 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"compiler/diagmsg:Msg"
  %l32 = alloca i32
  %l33 = alloca i32
  %l39 = alloca i32
  %l40 = alloca i32
  %l46 = alloca i32
  %l47 = alloca i32
  %l50 = alloca i1
  %l54 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l58 = alloca { i64, ptr }
  %l63 = alloca i32
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l9
  store %"std/os:FileInfo" %t8, ptr %l7
  br label %bb6
bb2:
  %t9 = load i32, ptr %l10, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l12, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l13, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l14, !tbaa !27
  %t15 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/diagmsg:Msg" %t15, ptr %l15
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l13, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l14, !tbaa !27
  %t19 = load %"compiler/diagmsg:Msg", ptr %l15
  %t21 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s1, ptr %v3, ptr %t17, { i64, ptr } %t18, %"compiler/diagmsg:Msg" %t19, ptr %t16)
  store i32 %t21, ptr %l17
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  %t22 = load i32, ptr %l17, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load %"std/os:FileInfo", ptr %l7
  store %"std/os:FileInfo" %t23, ptr %l5
  %t24 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 3}
  %t27 = trunc i64 1 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l20, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l21, !tbaa !27
  %t32 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s2)
  store %"compiler/diagmsg:Msg" %t32, ptr %l22
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l20, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t36 = load %"compiler/diagmsg:Msg", ptr %l22
  %t38 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s2, ptr %v3, ptr %t34, { i64, ptr } %t35, %"compiler/diagmsg:Msg" %t36, ptr %t33)
  store i32 %t38, ptr %l24
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  %t39 = load i32, ptr %l24, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 3}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l28, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l29, !tbaa !27
  %t50 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %s3)
  store %"compiler/diagmsg:Msg" %t50, ptr %l30
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load ptr, ptr %l28, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t54 = load %"compiler/diagmsg:Msg", ptr %l30
  %t56 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s3, ptr %v3, ptr %t52, { i64, ptr } %t53, %"compiler/diagmsg:Msg" %t54, ptr %t51)
  store i32 %t56, ptr %l32
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  %t57 = load i32, ptr %l32, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
bb16:
  %t59 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t60 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t68 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v4, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %t59, { i64, ptr } %t60, ptr %t61, ptr %t62)
  %t69 = extractvalue { i32, i32 } %t68, 1
  %t70 = extractvalue { i32, i32 } %t68, 0
  store i32 %t70, ptr %l40
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb18, label %ok.72, !prof !99
ok.72:
  store i32 %t69, ptr %l39
  br label %bb17
bb17:
  %t73 = load i32, ptr %l39, !tbaa !23
  store i32 %t73, ptr %l33, !tbaa !23
  br label %bb27
bb18:
  %t74 = load i32, ptr %l40, !tbaa !23
  %t75 = icmp eq i32 %t74, 65536
  br i1 %t75, label %bb19, label %bb20
bb19:
  br label %bb21
bb20:
  %t77 = load i32, ptr %l40, !tbaa !23
  %t78 = icmp eq i32 %t77, 65537
  br i1 %t78, label %bb22, label %bb23
bb21:
  call void @__olang_ert_req_clear()
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v3, ptr %t80, { i64, ptr } %t81, ptr %t82)
  store i32 %t86, ptr %l46
  br label %bb25
bb22:
  br label %bb24
bb23:
  call void @__olang_check_failed(ptr @olang_loc_ac43697cc5f2dca0_4dfd3d6081b857d4)
  unreachable
bb24:
  call void @__olang_ert_req_clear()
  %t87 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t87, ptr %l47
  br label %bb26
bb25:
  %t88 = load i32, ptr %l46, !tbaa !23
  store i32 %t88, ptr %rv
  br label %ret
bb26:
  %t89 = load i32, ptr %l47, !tbaa !23
  store i32 %t89, ptr %rv
  br label %ret
bb27:
  %t90 = load i32, ptr %l33, !tbaa !23
  store i32 %t90, ptr %l6, !tbaa !23
  %t91 = load i32, ptr %l6, !tbaa !23
  %t93 = icmp eq i32 %t91, 3
  br i1 %t93, label %bb28, label %bb29
bb28:
  %t95 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t95, 0
  %t99 = icmp sgt i64 %t97, 0
  store i1 %t99, ptr %l50, !tbaa !21
  br label %bb30
bb29:
  store i1 false, ptr %l50, !tbaa !21
  br label %bb30
bb30:
  %t101 = load i1, ptr %l50, !tbaa !21
  br i1 %t101, label %bb31, label %bb32
bb31:
  store %olang.scope zeroinitializer, ptr %s6
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t102, ptr %l54, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t103, ptr %l55, !tbaa !27
  %t104 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s6, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t104, ptr %l56
  br label %bb33
bb32:
  br label %bb36
bb33:
  %t105 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  %t106 = call ptr @__olang_scope_alloc_a(ptr %s6, i64 32, i64 8)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t105, ptr %t106
  %t107 = load { i64, ptr }, ptr %l54, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t110 = call { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v2, ptr %v4, ptr %s6, ptr %s6, { i64, ptr } %t107, { i64, ptr } %t108, ptr %t106)
  store { i64, ptr } %t110, ptr %l58
  br label %bb34
bb34:
  %t111 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t112 = extractvalue { i64, ptr } %t111, 0
  %t113 = extractvalue { i64, ptr } %t111, 1
  %t114 = mul i64 %t112, 1
  %t115 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t114)
  call void @llvm.memcpy.p0.p0.i64(ptr %t115, ptr %t113, i64 %t114, i1 false)
  %t116 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t117 = insertvalue { i64, ptr } %t116, ptr %t115, 1
  call void @compiler_2fbuild_2esayln(ptr %s6, { i64, ptr } %t117)
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s6)
  store i32 3, ptr %rv
  br label %ret
bb36:
  %t120 = load i32, ptr %l6, !tbaa !23
  %t122 = icmp eq i32 %t120, 0
  br i1 %t122, label %bb37, label %bb38
bb37:
  store i32 0, ptr %l63, !tbaa !23
  br label %bb39
bb38:
  store i32 1, ptr %l63, !tbaa !23
  br label %bb39
bb39:
  %t124 = load i32, ptr %l63, !tbaa !23
  store i32 %t124, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v4, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store i32 %t12, ptr %l11
  br label %bb1
bb1:
  %t16 = load i32, ptr %l11, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb11
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l17
  br label %bb10
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load i32, ptr %l5, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/build:Listed" } @compiler_2fbuild_2eListed_2eListingCode_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %l6 = alloca { i64, ptr }
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i64
  %l31 = alloca i32
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/build:Listed"
  %l53 = alloca i32
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i32
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l89 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/build:Listed" }
  store ptr %a1, ptr %l1
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a2, i32 1, ptr %t3, ptr %t4, ptr %t5)
  store i32 %t12, ptr %l18
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t23, 0
  store { i32, %"compiler/build:Listed" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v4, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb4
bb4:
  %t29 = load i64, ptr %l21, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/build:Program", ptr %t32, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v3, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb7
bb7:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/build:Listed" } %t42, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t47 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v4, ptr %t43, ptr %t44)
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb13, label %ok.49, !prof !99
ok.49:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t50 = load i32, ptr %l31, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t58, 0
  store { i32, %"compiler/build:Listed" } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/build:Config", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v3, ptr %s0, ptr %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t74)
  store { i64, ptr } %t76, ptr %l38
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t77)
  store { i64, ptr } %t79, ptr %l40
  br label %bb17
bb17:
  %t80 = load i1, ptr %l3, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t83, i64 %t84)
  %t101 = getelementptr i8, ptr %t100, i64 %t84
  call void @olang_textcopy(ptr %t101, ptr %t85, i64 %t86)
  %t102 = getelementptr i8, ptr %t101, i64 %t86
  call void @olang_textcopy(ptr %t102, ptr %t89, i64 %t90)
  %t103 = getelementptr i8, ptr %t102, i64 %t90
  call void @olang_textcopy(ptr %t103, ptr %t93, i64 %t94)
  %t104 = getelementptr i8, ptr %t103, i64 %t94
  call void @olang_textcopy(ptr %t104, ptr %t97, i64 %t98)
  %t105 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t100, 1
  store { i64, ptr } %t106, ptr %l6, !tbaa !27
  %t108 = call %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v5)
  store %"compiler/build:Listed" %t108, ptr %l44
  br label %bb21
bb21:
  %t109 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 64, i64 8)
  store ptr %t109, ptr %lp7
  %t110 = load %"compiler/build:Listed", ptr %l44
  %t111 = load ptr, ptr %lp7
  store %"compiler/build:Listed" %t110, ptr %t111
  %t112 = load ptr, ptr %l1, !tbaa !29
  %t114 = getelementptr %"compiler/build:Config", ptr %t112, i32 0, i32 5
  %t115 = load i1, ptr %t114, !tbaa !21
  br i1 %t115, label %bb22, label %bb23
bb22:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t118 = load ptr, ptr %l4, !tbaa !29
  %t119 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t120 = load i1, ptr %l3, !tbaa !21
  %t121 = load ptr, ptr %lp7
  %t122 = load ptr, ptr %l5, !tbaa !29
  %t129 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v1, ptr %v3, ptr %s0, ptr %v5, ptr %v4, ptr %t117, ptr %t118, { i64, ptr } %t119, i1 %t120, ptr %t121, ptr %t122)
  store i32 %t129, ptr %l53
  %t130 = icmp ne i32 %t129, 0
  br i1 %t130, label %bb25, label %ok.131, !prof !99
ok.131:
  br label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb26
bb25:
  %t132 = load i32, ptr %l53, !tbaa !23
  %t133 = lshr i32 %t132, 16
  %t134 = and i32 %t132, 65535
  %t135 = icmp eq i32 %t133, 1
  %t136 = select i1 %t135, i32 1, i32 0
  %t137 = icmp eq i32 %t132, 0
  %t138 = shl i32 %t136, 16
  %t139 = or i32 %t138, %t134
  %t140 = select i1 %t137, i32 0, i32 %t139
  call void @__olang_scope_close(ptr %s0)
  %t142 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t140, 0
  store { i32, %"compiler/build:Listed" } %t142, ptr %rv
  br label %ret
bb26:
  %t143 = load ptr, ptr %lp7
  %t144 = load %"compiler/build:Listed", ptr %t143
  call void @__olang_scope_close(ptr %s0)
  %t146 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t144, 1
  store { i32, %"compiler/build:Listed" } %t146, ptr %rv
  br label %ret
bb27:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t148 = load ptr, ptr %l4, !tbaa !29
  %t149 = load ptr, ptr %l5, !tbaa !29
  %t153 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %v3, ptr %v4, ptr %s0, ptr %t147, ptr %t148, ptr %t149)
  %t154 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t153, 1
  %t155 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t153, 0
  store i32 %t155, ptr %l61
  %t156 = icmp ne i32 %t155, 0
  br i1 %t156, label %bb29, label %ok.157, !prof !99
ok.157:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t154, ptr %l60
  br label %bb28
bb28:
  %t158 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t158, ptr %l56
  br label %bb30
bb29:
  %t159 = load i32, ptr %l61, !tbaa !23
  %t160 = lshr i32 %t159, 16
  %t161 = and i32 %t159, 65535
  %t162 = icmp eq i32 %t160, 1
  %t163 = select i1 %t162, i32 1, i32 0
  %t164 = icmp eq i32 %t159, 0
  %t165 = shl i32 %t163, 16
  %t166 = or i32 %t165, %t161
  %t167 = select i1 %t164, i32 0, i32 %t166
  call void @__olang_scope_close(ptr %s0)
  %t169 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t167, 0
  store { i32, %"compiler/build:Listed" } %t169, ptr %rv
  br label %ret
bb30:
  %t170 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t170, ptr %l8
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d14, i32 0, i32 1) })
  br label %bb31
bb31:
  store ptr %l8, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t172 = load i64, ptr %l10, !tbaa !24
  store i64 %t172, ptr %l64, !tbaa !24
  %t173 = load ptr, ptr %l9, !tbaa !29
  %t175 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t173)
  store i64 %t175, ptr %l66
  br label %bb33
bb33:
  %t176 = load i64, ptr %l64, !tbaa !24
  %t177 = load i64, ptr %l66, !tbaa !24
  %t178 = icmp slt i64 %t176, %t177
  %t180 = xor i1 %t178, true
  br i1 %t180, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb35:
  br label %bb36
bb36:
  %t182 = load ptr, ptr %l9, !tbaa !29
  %t183 = load i64, ptr %l10, !tbaa !24
  %t186 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t182, i64 %t183)
  store { i64, ptr } %t186, ptr %l71
  br label %bb37
bb37:
  %t187 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t187, ptr %l11, !tbaa !27
  %t188 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t190 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %s0, ptr %s5, { i64, ptr } %t188)
  store { i64, ptr } %t190, ptr %l73
  br label %bb38
bb38:
  %t191 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = call i1 @std_2fos_2eExists(ptr %s5, { i64, ptr } %t197)
  store i1 %t199, ptr %l75
  br label %bb39
bb39:
  %t200 = load i1, ptr %l75, !tbaa !21
  br i1 %t200, label %bb40, label %bb41
bb40:
  %t201 = load ptr, ptr %lp7
  %t202 = getelementptr %"compiler/build:Listed", ptr %t201, i32 0, i32 1
  store ptr %t202, ptr %l76, !tbaa !29
  %t203 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t205 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %s0, ptr %v5, { i64, ptr } %t203)
  store { i64, ptr } %t205, ptr %l78
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t206 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t207 = extractvalue { i64, ptr } %t206, 0
  %t208 = extractvalue { i64, ptr } %t206, 1
  %t209 = mul i64 %t207, 1
  %t210 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t209)
  call void @llvm.memcpy.p0.p0.i64(ptr %t210, ptr %t208, i64 %t209, i1 false)
  %t211 = insertvalue { i64, ptr } undef, i64 %t207, 0
  %t212 = insertvalue { i64, ptr } %t211, ptr %t210, 1
  %t213 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v5, ptr %v5, ptr %t213, { i64, ptr } %t212)
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  %t215 = load i64, ptr %l10, !tbaa !24
  %t217 = add i64 %t215, 1
  store i64 %t217, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t220 = load ptr, ptr %l4, !tbaa !29
  %t221 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t222 = load i1, ptr %l3, !tbaa !21
  %t223 = load ptr, ptr %lp7
  %t224 = load ptr, ptr %l5, !tbaa !29
  %t232 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v1, ptr %s0, ptr %v3, ptr %s0, ptr %v5, ptr %v4, ptr %t219, ptr %l8, ptr %t220, { i64, ptr } %t221, i1 %t222, ptr %t223, ptr %t224)
  store i32 %t232, ptr %l89
  %t233 = icmp ne i32 %t232, 0
  br i1 %t233, label %bb48, label %ok.234, !prof !99
ok.234:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t235 = load i32, ptr %l89, !tbaa !23
  %t236 = lshr i32 %t235, 16
  %t237 = and i32 %t235, 65535
  %t238 = icmp eq i32 %t236, 1
  %t239 = select i1 %t238, i32 1, i32 0
  %t240 = icmp eq i32 %t235, 0
  %t241 = shl i32 %t239, 16
  %t242 = or i32 %t241, %t237
  %t243 = select i1 %t240, i32 0, i32 %t242
  call void @__olang_scope_close(ptr %s0)
  %t245 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t243, 0
  store { i32, %"compiler/build:Listed" } %t245, ptr %rv
  br label %ret
bb49:
  %t246 = load ptr, ptr %lp7
  %t247 = load %"compiler/build:Listed", ptr %t246
  call void @__olang_scope_close(ptr %s0)
  %t249 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t247, 1
  store { i32, %"compiler/build:Listed" } %t249, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/build:Listed" }, ptr %rv
  ret { i32, %"compiler/build:Listed" } %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l31 = alloca i1
  %l33 = alloca i32
  %l34 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca { i64, [3 x i64] }
  %l96 = alloca %"compiler/diagmsg:Msg"
  %l98 = alloca i32
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t205 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 20
  store i1 true, ptr %t3, !tbaa !21
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t5, { i64, ptr } %t6, ptr %t7)
  store i32 %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load i32, ptr %l21, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  %t14 = load i32, ptr %l5, !tbaa !23
  %t16 = icmp ne i32 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v4, ptr %s0, ptr %t20, ptr %t21)
  %t25 = extractvalue { i32, { i64, ptr } } %t24, 1
  %t26 = extractvalue { i32, { i64, ptr } } %t24, 0
  store i32 %t26, ptr %l29
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb6, label %ok.28, !prof !99
ok.28:
  store { i64, ptr } %t25, ptr %l28
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  br label %bb9
bb6:
  %t30 = load i32, ptr %l29, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  store i1 %t33, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t34)
  store i32 %t36, ptr %l33
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i32, ptr %l33, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb9:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l6, !tbaa !27
  %t39 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t39, ptr %l34
  br label %bb10
bb10:
  %t40 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l34
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t40, ptr %l7
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t55, ptr %l42, !tbaa !27
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %t59, i64 %t56
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t65 = extractvalue { i64, ptr } %t61, 1
  %t66 = extractvalue { i64, ptr } %t61, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t76)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l9, !tbaa !24
  br label %bb11
bb17:
  store ptr %l7, ptr %l51, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l55, !tbaa !27
  br label %bb21
bb19:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Config", ptr %t97, i32 0, i32 22
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l60
  br label %bb20
bb20:
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t103, ptr %l55, !tbaa !27
  br label %bb21
bb21:
  %t104 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t111, { i64, ptr } %t110)
  br label %bb22
bb22:
  store { i64, ptr } %a3, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t127 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %t131, i64 %t128
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !37
  %t137 = extractvalue { i64, ptr } %t133, 1
  %t138 = extractvalue { i64, ptr } %t133, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t148)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l13, !tbaa !24
  br label %bb23
bb29:
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = icmp eq i64 %t157, 0
  br i1 %t159, label %bb30, label %bb31
bb30:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/build:Config", ptr %t161, i32 0, i32 22
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t164)
  store { i64, ptr } %t166, ptr %l84
  br label %bb32
bb31:
  %t167 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %t168, i64 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !37
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = extractvalue { i64, ptr } %t170, 0
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t172, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l81, !tbaa !27
  br label %bb33
bb32:
  %t185 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l81, !tbaa !27
  br label %bb33
bb33:
  %t194 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t194, ptr %l90
  br label %bb34
bb34:
  %t195 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t197 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t195, { i64, ptr } %t196)
  store i32 %t197, ptr %l91
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb36, label %ok.199, !prof !99
ok.199:
  br label %bb35
bb35:
  br label %bb41
bb36:
  %t200 = load i32, ptr %l91, !tbaa !23
  %t201 = ashr i32 %t200, 16
  %t203 = icmp eq i32 %t201, 1
  store i1 %t203, ptr %l93, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t204 = load ptr, ptr %l4, !tbaa !29
  store ptr %t204, ptr %l94, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t207 = load { i64, [3 x i64] }, ptr %t205
  store { i64, [3 x i64] } %t207, ptr %l95
  %t208 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s13, ptr %s13, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t208, ptr %l96
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l94, !tbaa !29
  %t210 = load { i64, [3 x i64] }, ptr %l95
  %t211 = load %"compiler/diagmsg:Msg", ptr %l96
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s13, ptr %t209, { i64, [3 x i64] } %t210, %"compiler/diagmsg:Msg" %t211)
  br label %bb39
bb39:
  %t212 = load ptr, ptr %l4, !tbaa !29
  %t214 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t212)
  store i32 %t214, ptr %l98
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t215 = load i32, ptr %l98, !tbaa !23
  store i32 %t215, ptr %rv
  br label %ret
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:FileInfo"
  %l6 = alloca %"compiler/build:Program"
  %l7 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"std/os:Output"
  %l20 = alloca %"std/os:FileInfo"
  %l22 = alloca %"std/os:FileInfo"
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/diagmsg:Msg"
  %l30 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca %"compiler/diagmsg:Msg"
  %l37 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca i32
  %l46 = alloca %"compiler/build:Program"
  %l53 = alloca i32
  %l59 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i1
  %l78 = alloca i32
  %l79 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l83 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l84 = alloca i32
  %l86 = alloca i1
  %l88 = alloca i32
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l102 = alloca i1
  %l105 = alloca i32
  %l107 = alloca i1
  %l112 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca i32
  %l123 = alloca i1
  %l125 = alloca i32
  %l126 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l134 = alloca { i64, ptr }
  %l143 = alloca ptr
  %l145 = alloca { i64, ptr }
  %l149 = alloca i1
  %l154 = alloca i32
  %l162 = alloca { i64, ptr }
  %l171 = alloca %"std/os:Output"
  %l173 = alloca { i64, ptr }
  %l174 = alloca { i64, ptr }
  %l175 = alloca %"std/os:Output"
  %l176 = alloca i32
  %l178 = alloca i1
  %l182 = alloca ptr
  %l183 = alloca { i64, ptr }
  %l186 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l193 = alloca i1
  %l200 = alloca { i64, ptr }
  %l205 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s23 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %rv = alloca i32
  %t58 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l23
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l22
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l22
  store %"std/os:FileInfo" %t8, ptr %l20
  br label %bb6
bb2:
  %t9 = load i32, ptr %l23, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l26, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l27, !tbaa !27
  %t15 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/diagmsg:Msg" %t15, ptr %l28
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t19 = load %"compiler/diagmsg:Msg", ptr %l28
  %t21 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s1, ptr %v3, ptr %t17, { i64, ptr } %t18, %"compiler/diagmsg:Msg" %t19, ptr %t16)
  store i32 %t21, ptr %l30
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l30, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load %"std/os:FileInfo", ptr %l20
  store %"std/os:FileInfo" %t23, ptr %l5
  %t24 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 3}
  %t27 = trunc i64 1 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l33, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l34, !tbaa !27
  %t32 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s2)
  store %"compiler/diagmsg:Msg" %t32, ptr %l35
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l33, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t36 = load %"compiler/diagmsg:Msg", ptr %l35
  %t38 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s2, ptr %v3, ptr %t34, { i64, ptr } %t35, %"compiler/diagmsg:Msg" %t36, ptr %t33)
  store i32 %t38, ptr %l37
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l37, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 3}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l41, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l42, !tbaa !27
  %t50 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %s3)
  store %"compiler/diagmsg:Msg" %t50, ptr %l43
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = load %"compiler/diagmsg:Msg", ptr %l43
  %t56 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s3, ptr %v3, ptr %t52, { i64, ptr } %t53, %"compiler/diagmsg:Msg" %t54, ptr %t51)
  store i32 %t56, ptr %l45
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i32, ptr %l45, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
bb16:
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t58, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l46, ptr %t58, i64 224, i1 false)
  br label %bb17
bb17:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l46, i64 224, i1 false)
  %t60 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t69 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %v3, ptr %a0, { i64, ptr } %t60, i32 2, ptr %t61, ptr %l6, ptr %t62)
  store i32 %t69, ptr %l53
  %t70 = icmp ne i32 %t69, 0
  br i1 %t70, label %bb19, label %ok.71, !prof !99
ok.71:
  br label %bb18
bb18:
  br label %bb28
bb19:
  %t72 = load i32, ptr %l53, !tbaa !23
  %t73 = icmp eq i32 %t72, 65536
  br i1 %t73, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  %t75 = load i32, ptr %l53, !tbaa !23
  %t76 = icmp eq i32 %t75, 65537
  br i1 %t76, label %bb23, label %bb24
bb22:
  call void @__olang_ert_req_clear()
  %t78 = load ptr, ptr %l1, !tbaa !29
  %t79 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t80 = load ptr, ptr %l3, !tbaa !29
  %t84 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v3, ptr %t78, { i64, ptr } %t79, ptr %t80)
  store i32 %t84, ptr %l59
  br label %bb26
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_44996bcc7c9bda8_515f8c8db8b0565c)
  unreachable
bb25:
  call void @__olang_ert_req_clear()
  %t85 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t85, ptr %l60
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t86 = load i32, ptr %l59, !tbaa !23
  store i32 %t86, ptr %rv
  br label %ret
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i32, ptr %l60, !tbaa !23
  store i32 %t87, ptr %rv
  br label %ret
bb28:
  %t88 = load ptr, ptr %l3, !tbaa !29
  %t90 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t88)
  store i64 %t90, ptr %l62
  br label %bb29
bb29:
  %t91 = load i64, ptr %l62, !tbaa !24
  %t92 = icmp sgt i64 %t91, 0
  br i1 %t92, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb33
bb31:
  %t94 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 0
  %t96 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t94)
  store i64 %t96, ptr %l66
  br label %bb32
bb32:
  %t97 = load i64, ptr %l66, !tbaa !24
  %t98 = icmp eq i64 %t97, 0
  store i1 %t98, ptr %l64, !tbaa !21
  br label %bb33
bb33:
  %t100 = load i1, ptr %l64, !tbaa !21
  br i1 %t100, label %bb34, label %bb35
bb34:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t103 = load ptr, ptr %l3, !tbaa !29
  %t107 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v3, ptr %t101, { i64, ptr } %t102, ptr %t103)
  store i32 %t107, ptr %l71
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t108 = load i32, ptr %l71, !tbaa !23
  store i32 %t108, ptr %rv
  br label %ret
bb37:
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t113 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t109, ptr %t110)
  store i32 %t113, ptr %l74
  %t114 = icmp ne i32 %t113, 0
  br i1 %t114, label %bb39, label %ok.115, !prof !99
ok.115:
  br label %bb38
bb38:
  br label %bb42
bb39:
  %t116 = load i32, ptr %l74, !tbaa !23
  %t117 = ashr i32 %t116, 16
  %t119 = icmp eq i32 %t117, 1
  store i1 %t119, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  %t120 = load ptr, ptr %l3, !tbaa !29
  %t122 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t120)
  store i32 %t122, ptr %l78
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t123 = load i32, ptr %l78, !tbaa !23
  store i32 %t123, ptr %rv
  br label %ret
bb42:
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t125 = load ptr, ptr %l3, !tbaa !29
  %t129 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v3, ptr %s0, ptr %t124, ptr %l6, ptr %t125)
  %t130 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t129, 1
  %t131 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t129, 0
  store i32 %t131, ptr %l84
  %t132 = icmp ne i32 %t131, 0
  br i1 %t132, label %bb44, label %ok.133, !prof !99
ok.133:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t130, ptr %l83
  br label %bb43
bb43:
  %t134 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l83
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t134, ptr %l79
  br label %bb47
bb44:
  %t135 = load i32, ptr %l84, !tbaa !23
  %t136 = ashr i32 %t135, 16
  %t138 = icmp eq i32 %t136, 1
  store i1 %t138, ptr %l86, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t141 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t139)
  store i32 %t141, ptr %l88
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t142 = load i32, ptr %l88, !tbaa !23
  store i32 %t142, ptr %rv
  br label %ret
bb47:
  %t143 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l79
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t143, ptr %l7
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d16, i32 0, i32 1) })
  br label %bb48
bb48:
  %t144 = load ptr, ptr %l1, !tbaa !29
  %t146 = getelementptr %"compiler/build:Config", ptr %t144, i32 0, i32 0
  %t147 = load { i64, ptr }, ptr %t146, !tbaa !27
  store { i64, ptr } %t147, ptr %l90, !tbaa !27
  %t149 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t149, ptr %l92
  br label %bb49
bb49:
  %t150 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t151 = extractvalue { i64, ptr } %t150, 0
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = mul i64 %t151, 1
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @llvm.memcpy.p0.p0.i64(ptr %t154, ptr %t152, i64 %t153, i1 false)
  %t155 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t158 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t156)
  store { i64, ptr } %t158, ptr %l94
  br label %bb50
bb50:
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t161 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t159)
  store { i64, ptr } %t161, ptr %l96
  br label %bb51
bb51:
  %t162 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t163 = extractvalue { i64, ptr } %t162, 1
  %t164 = extractvalue { i64, ptr } %t162, 0
  %t165 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 1
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d17, i32 0, i32 1) }, 0
  %t167 = add i64 %t164, %t166
  %t168 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t169 = extractvalue { i64, ptr } %t168, 1
  %t170 = extractvalue { i64, ptr } %t168, 0
  %t171 = add i64 %t167, %t170
  %t172 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t173 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t174 = add i64 %t171, %t173
  %t175 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t176 = extractvalue { i64, ptr } %t175, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = add i64 %t174, %t177
  %t179 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t178)
  call void @olang_textcopy(ptr %t179, ptr %t163, i64 %t164)
  %t180 = getelementptr i8, ptr %t179, i64 %t164
  call void @olang_textcopy(ptr %t180, ptr %t165, i64 %t166)
  %t181 = getelementptr i8, ptr %t180, i64 %t166
  call void @olang_textcopy(ptr %t181, ptr %t169, i64 %t170)
  %t182 = getelementptr i8, ptr %t181, i64 %t170
  call void @olang_textcopy(ptr %t182, ptr %t172, i64 %t173)
  %t183 = getelementptr i8, ptr %t182, i64 %t173
  call void @olang_textcopy(ptr %t183, ptr %t176, i64 %t177)
  %t184 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t185 = insertvalue { i64, ptr } %t184, ptr %t179, 1
  store { i64, ptr } %t185, ptr %l8, !tbaa !27
  %t187 = load ptr, ptr %l1, !tbaa !29
  store ptr %t187, ptr %l98, !tbaa !29
  store ptr %l7, ptr %l99, !tbaa !29
  %t188 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t188, ptr %l100, !tbaa !27
  %t189 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 2
  %t190 = load { i64, ptr }, ptr %t189, !tbaa !27
  %t192 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t190, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d19, i32 0, i32 1) })
  store i1 %t192, ptr %l102
  br label %bb52
bb52:
  %t193 = load i1, ptr %l102, !tbaa !21
  %t194 = xor i1 %t193, true
  %t195 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 3
  %t196 = load ptr, ptr %l98, !tbaa !29
  %t197 = load ptr, ptr %l99, !tbaa !29
  %t198 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t201 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t196, ptr %t197, { i64, ptr } %t198, i1 %t194, ptr %t195, ptr null)
  store i32 %t201, ptr %l105
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb54, label %ok.203, !prof !99
ok.203:
  br label %bb53
bb53:
  br label %bb58
bb54:
  %t204 = load i32, ptr %l105, !tbaa !23
  %t205 = ashr i32 %t204, 16
  %t207 = icmp eq i32 %t205, 1
  store i1 %t207, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s10
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t209 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = extractvalue { i64, ptr } %t209, 0
  %t213 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t214 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t215 = add i64 %t212, %t214
  %t216 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t215)
  call void @olang_textcopy(ptr %t216, ptr %t211, i64 %t212)
  %t217 = getelementptr i8, ptr %t216, i64 %t212
  call void @olang_textcopy(ptr %t217, ptr %t213, i64 %t214)
  %t218 = insertvalue { i64, ptr } undef, i64 %t215, 0
  %t219 = insertvalue { i64, ptr } %t218, ptr %t216, 1
  %t221 = extractvalue { i64, ptr } %t219, 0
  %t222 = extractvalue { i64, ptr } %t219, 1
  %t223 = mul i64 %t221, 1
  %t224 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t223)
  call void @llvm.memcpy.p0.p0.i64(ptr %t224, ptr %t222, i64 %t223, i1 false)
  %t225 = insertvalue { i64, ptr } undef, i64 %t221, 0
  %t226 = insertvalue { i64, ptr } %t225, ptr %t224, 1
  %t229 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t208, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } %t226)
  store { i64, ptr } %t229, ptr %l112
  br label %bb56
bb56:
  %t230 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t236)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb58:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d22, i32 0, i32 1) })
  br label %bb59
bb59:
  %t239 = load ptr, ptr %l1, !tbaa !29
  %t240 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v1, ptr %v2, ptr %t239, { i64, ptr } %t240)
  br label %bb60
bb60:
  %t243 = load ptr, ptr %l1, !tbaa !29
  %t244 = load ptr, ptr %l3, !tbaa !29
  %t247 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v3, ptr %s0, ptr %t243, ptr %t244)
  %t248 = extractvalue { i32, { i64, ptr } } %t247, 1
  %t249 = extractvalue { i32, { i64, ptr } } %t247, 0
  store i32 %t249, ptr %l121
  %t250 = icmp ne i32 %t249, 0
  br i1 %t250, label %bb62, label %ok.251, !prof !99
ok.251:
  store { i64, ptr } %t248, ptr %l120
  br label %bb61
bb61:
  %t252 = load { i64, ptr }, ptr %l120, !tbaa !27
  store { i64, ptr } %t252, ptr %l117, !tbaa !27
  br label %bb65
bb62:
  %t253 = load i32, ptr %l121, !tbaa !23
  %t254 = ashr i32 %t253, 16
  %t256 = icmp eq i32 %t254, 1
  store i1 %t256, ptr %l123, !tbaa !21
  br label %bb63
bb63:
  call void @__olang_ert_req_clear()
  %t257 = load ptr, ptr %l3, !tbaa !29
  %t259 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t257)
  store i32 %t259, ptr %l125
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t260 = load i32, ptr %l125, !tbaa !23
  store i32 %t260, ptr %rv
  br label %ret
bb65:
  %t261 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t261, ptr %l9, !tbaa !27
  %t262 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t262, ptr %l126
  br label %bb66
bb66:
  %t263 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l126
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t263, ptr %l10
  %t264 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t264, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t266 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t268 = extractvalue { i64, ptr } %t266, 0
  store i64 %t268, ptr %l13, !tbaa !24
  br label %bb67
bb67:
  %t270 = load i64, ptr %l12, !tbaa !24
  %t271 = load i64, ptr %l13, !tbaa !24
  %t274 = icmp slt i64 %t270, %t271
  %t276 = xor i1 %t274, true
  br i1 %t276, label %bb68, label %bb69
bb68:
  br label %bb73
bb69:
  br label %bb70
bb70:
  %t278 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t278, ptr %l134, !tbaa !27
  %t279 = load i64, ptr %l12, !tbaa !24
  %t281 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t282 = load ptr, ptr %t281, !tbaa !27
  %t283 = getelementptr { i64, ptr }, ptr %t282, i64 %t279
  %t284 = load { i64, ptr }, ptr %t283, !tbaa !37
  %t288 = extractvalue { i64, ptr } %t284, 1
  %t289 = extractvalue { i64, ptr } %t284, 0
  %t290 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t289)
  call void @olang_textcopy(ptr %t290, ptr %t288, i64 %t289)
  %t291 = insertvalue { i64, ptr } undef, i64 %t289, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t290, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t299)
  br label %bb71
bb71:
  br label %bb72
bb72:
  %t302 = load i64, ptr %l12, !tbaa !24
  %t304 = add i64 %t302, 1
  store i64 %t304, ptr %l12, !tbaa !24
  br label %bb67
bb73:
  store ptr %l10, ptr %l143, !tbaa !29
  %t306 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t308 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t306)
  store { i64, ptr } %t308, ptr %l145
  br label %bb74
bb74:
  %t309 = load { i64, ptr }, ptr %l145, !tbaa !27
  %t310 = extractvalue { i64, ptr } %t309, 0
  %t311 = extractvalue { i64, ptr } %t309, 1
  %t312 = mul i64 %t310, 1
  %t313 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t312)
  call void @llvm.memcpy.p0.p0.i64(ptr %t313, ptr %t311, i64 %t312, i1 false)
  %t314 = insertvalue { i64, ptr } undef, i64 %t310, 0
  %t315 = insertvalue { i64, ptr } %t314, ptr %t313, 1
  %t316 = load ptr, ptr %l143, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t316, { i64, ptr } %t315)
  br label %bb75
bb75:
  %t318 = load ptr, ptr %l1, !tbaa !29
  %t320 = getelementptr %"compiler/build:Config", ptr %t318, i32 0, i32 10
  %t321 = load { i64, ptr }, ptr %t320, !tbaa !27
  %t323 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t321, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  store i1 %t323, ptr %l149
  br label %bb76
bb76:
  %t324 = load i1, ptr %l149, !tbaa !21
  %t325 = xor i1 %t324, true
  br i1 %t325, label %bb77, label %bb78
bb77:
  %t327 = load ptr, ptr %l1, !tbaa !29
  %t331 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v1, ptr %s0, ptr %s0, ptr %t327, ptr %l10, ptr %l6)
  store i32 %t331, ptr %l154
  br label %bb79
bb78:
  br label %bb80
bb79:
  call void @__olang_scope_close(ptr %s0)
  %t332 = load i32, ptr %l154, !tbaa !23
  store i32 %t332, ptr %rv
  br label %ret
bb80:
  %t333 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t333, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t335 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t337 = extractvalue { i64, ptr } %t335, 0
  store i64 %t337, ptr %l17, !tbaa !24
  br label %bb81
bb81:
  %t339 = load i64, ptr %l16, !tbaa !24
  %t340 = load i64, ptr %l17, !tbaa !24
  %t343 = icmp slt i64 %t339, %t340
  %t345 = xor i1 %t343, true
  br i1 %t345, label %bb82, label %bb83
bb82:
  br label %bb87
bb83:
  br label %bb84
bb84:
  %t347 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t347, ptr %l162, !tbaa !27
  %t348 = load i64, ptr %l16, !tbaa !24
  %t350 = getelementptr { i64, ptr }, ptr %l162, i32 0, i32 1
  %t351 = load ptr, ptr %t350, !tbaa !27
  %t352 = getelementptr { i64, ptr }, ptr %t351, i64 %t348
  %t353 = load { i64, ptr }, ptr %t352, !tbaa !37
  %t357 = extractvalue { i64, ptr } %t353, 1
  %t358 = extractvalue { i64, ptr } %t353, 0
  %t359 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t358)
  call void @olang_textcopy(ptr %t359, ptr %t357, i64 %t358)
  %t360 = insertvalue { i64, ptr } undef, i64 %t358, 0
  %t361 = insertvalue { i64, ptr } %t360, ptr %t359, 1
  %t363 = extractvalue { i64, ptr } %t361, 0
  %t364 = extractvalue { i64, ptr } %t361, 1
  %t365 = mul i64 %t363, 1
  %t366 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t365)
  call void @llvm.memcpy.p0.p0.i64(ptr %t366, ptr %t364, i64 %t365, i1 false)
  %t367 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t368 = insertvalue { i64, ptr } %t367, ptr %t366, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t368)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t371 = load i64, ptr %l16, !tbaa !24
  %t373 = add i64 %t371, 1
  store i64 %t373, ptr %l16, !tbaa !24
  br label %bb81
bb87:
  %t376 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t376, ptr %l173
  br label %bb88
bb88:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) }, ptr %l174, !tbaa !27
  %t377 = load { i64, ptr }, ptr %l173, !tbaa !27
  %t378 = load { i64, ptr }, ptr %l174, !tbaa !27
  %t379 = call { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t377, { i64, ptr } %t378, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d25, i32 0, i32 1) })
  %t380 = extractvalue { i32, %"std/os:Output" } %t379, 1
  %t381 = extractvalue { i32, %"std/os:Output" } %t379, 0
  store i32 %t381, ptr %l176
  %t382 = icmp ne i32 %t381, 0
  br i1 %t382, label %bb90, label %ok.383, !prof !99
ok.383:
  store %"std/os:Output" %t380, ptr %l175
  br label %bb89
bb89:
  %t384 = load %"std/os:Output", ptr %l175
  store %"std/os:Output" %t384, ptr %l171
  br label %bb92
bb90:
  %t385 = load i32, ptr %l176, !tbaa !23
  %t386 = ashr i32 %t385, 16
  %t388 = icmp eq i32 %t386, 1
  store i1 %t388, ptr %l178, !tbaa !21
  br label %bb91
bb91:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb92:
  %t390 = load %"std/os:Output", ptr %l171
  store %"std/os:Output" %t390, ptr %l19
  %t391 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t392 = load i32, ptr %t391, !tbaa !23
  %t394 = icmp sgt i32 %t392, 128
  br i1 %t394, label %bb93, label %bb94
bb93:
  store %olang.scope zeroinitializer, ptr %s23
  %t396 = load ptr, ptr %l1, !tbaa !29
  store ptr %t396, ptr %l182, !tbaa !29
  %t397 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t397, ptr %l183, !tbaa !27
  %t398 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t399 = load i32, ptr %t398, !tbaa !23
  %t401 = sub i32 %t399, 128
  %t403 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s23, i32 %t401)
  store { i64, ptr } %t403, ptr %l186
  br label %bb95
bb94:
  br label %bb98
bb95:
  %t404 = load { i64, ptr }, ptr %l183, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t408 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t409 = add i64 %t406, %t408
  %t410 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t411 = extractvalue { i64, ptr } %t410, 1
  %t412 = extractvalue { i64, ptr } %t410, 0
  %t413 = add i64 %t409, %t412
  %t414 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 1
  %t415 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d27, i32 0, i32 1) }, 0
  %t416 = add i64 %t413, %t415
  %t417 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t416)
  call void @olang_textcopy(ptr %t417, ptr %t405, i64 %t406)
  %t418 = getelementptr i8, ptr %t417, i64 %t406
  call void @olang_textcopy(ptr %t418, ptr %t407, i64 %t408)
  %t419 = getelementptr i8, ptr %t418, i64 %t408
  call void @olang_textcopy(ptr %t419, ptr %t411, i64 %t412)
  %t420 = getelementptr i8, ptr %t419, i64 %t412
  call void @olang_textcopy(ptr %t420, ptr %t414, i64 %t415)
  %t421 = insertvalue { i64, ptr } undef, i64 %t416, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t417, 1
  %t424 = extractvalue { i64, ptr } %t422, 0
  %t425 = extractvalue { i64, ptr } %t422, 1
  %t426 = mul i64 %t424, 1
  %t427 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t426)
  call void @llvm.memcpy.p0.p0.i64(ptr %t427, ptr %t425, i64 %t426, i1 false)
  %t428 = insertvalue { i64, ptr } undef, i64 %t424, 0
  %t429 = insertvalue { i64, ptr } %t428, ptr %t427, 1
  %t430 = load ptr, ptr %l182, !tbaa !29
  %t432 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s23, ptr %s23, ptr %s23, ptr %t430, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d28, i32 0, i32 1) }, { i64, ptr } %t429)
  store { i64, ptr } %t432, ptr %l189
  br label %bb96
bb96:
  %t433 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t434 = extractvalue { i64, ptr } %t433, 0
  %t435 = extractvalue { i64, ptr } %t433, 1
  %t436 = mul i64 %t434, 1
  %t437 = call ptr @__olang_scope_alloc(ptr %s23, i64 %t436)
  call void @llvm.memcpy.p0.p0.i64(ptr %t437, ptr %t435, i64 %t436, i1 false)
  %t438 = insertvalue { i64, ptr } undef, i64 %t434, 0
  %t439 = insertvalue { i64, ptr } %t438, ptr %t437, 1
  call void @compiler_2fbuild_2esayln(ptr %s23, { i64, ptr } %t439)
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s23)
  br label %bb98
bb98:
  %t441 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t442 = load i32, ptr %t441, !tbaa !23
  %t444 = icmp eq i32 %t442, 3
  br i1 %t444, label %bb99, label %bb100
bb99:
  %t446 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t448 = extractvalue { i64, ptr } %t446, 0
  %t450 = icmp sgt i64 %t448, 0
  store i1 %t450, ptr %l193, !tbaa !21
  br label %bb101
bb100:
  store i1 false, ptr %l193, !tbaa !21
  br label %bb101
bb101:
  %t452 = load i1, ptr %l193, !tbaa !21
  br i1 %t452, label %bb102, label %bb103
bb102:
  store %olang.scope zeroinitializer, ptr %s25
  %t453 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t454 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t455 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 7
  %t459 = call { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v2, ptr %v4, ptr %s0, ptr %s25, { i64, ptr } %t453, { i64, ptr } %t454, ptr %t455)
  store { i64, ptr } %t459, ptr %l200
  br label %bb104
bb103:
  br label %bb106
bb104:
  %t460 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t461 = extractvalue { i64, ptr } %t460, 0
  %t462 = extractvalue { i64, ptr } %t460, 1
  %t463 = mul i64 %t461, 1
  %t464 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t463)
  call void @llvm.memcpy.p0.p0.i64(ptr %t464, ptr %t462, i64 %t463, i1 false)
  %t465 = insertvalue { i64, ptr } undef, i64 %t461, 0
  %t466 = insertvalue { i64, ptr } %t465, ptr %t464, 1
  call void @compiler_2fbuild_2esayln(ptr %s25, { i64, ptr } %t466)
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s25)
  call void @__olang_scope_close(ptr %s0)
  store i32 3, ptr %rv
  br label %ret
bb106:
  %t469 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t470 = load i32, ptr %t469, !tbaa !23
  %t472 = icmp eq i32 %t470, 0
  br i1 %t472, label %bb107, label %bb108
bb107:
  store i32 0, ptr %l205, !tbaa !23
  br label %bb109
bb108:
  store i32 1, ptr %l205, !tbaa !23
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s0)
  %t474 = load i32, ptr %l205, !tbaa !23
  store i32 %t474, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca %"compiler/build:Program"
  %l7 = alloca %"compiler/build:Listed"
  %l14 = alloca %"compiler/build:Program"
  %l15 = alloca %"compiler/build:Listed"
  %l22 = alloca %"compiler/build:Listed"
  %l23 = alloca i32
  %l27 = alloca i32
  %l29 = alloca ptr
  %l30 = alloca ptr
  %l33 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l37 = alloca { i64, ptr }
  %l40 = alloca %"compiler/listing:Inputs"
  %l42 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t25 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 13
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t7 = extractvalue { i64, ptr } %a3, 1
  %t8 = extractvalue { i64, ptr } %a3, 0
  %t9 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t7, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  %t13 = extractvalue { i64, ptr } %t11, 0
  %t14 = extractvalue { i64, ptr } %t11, 1
  %t15 = mul i64 %t13, 1
  %t16 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t15)
  call void @llvm.memcpy.p0.p0.i64(ptr %t16, ptr %t14, i64 %t15, i1 false)
  %t17 = insertvalue { i64, ptr } undef, i64 %t13, 0
  %t18 = insertvalue { i64, ptr } %t17, ptr %t16, 1
  %t21 = getelementptr %"compiler/build:Config", ptr %t4, i32 0, i32 14
  store { i64, ptr } %t18, ptr %t21, !tbaa !27
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t24 = getelementptr %"compiler/build:Config", ptr %t22, i32 0, i32 20
  store i1 true, ptr %t24, !tbaa !21
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t25, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %t25, i64 224, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l14, i64 224, i1 false)
  %t27 = load ptr, ptr %l1, !tbaa !29
  %t29 = load i1, ptr %l4, !tbaa !21
  %t30 = load ptr, ptr %l5, !tbaa !29
  %t37 = call { i32, %"compiler/build:Listed" } @compiler_2fbuild_2eListed_2eListingCode_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %v4, ptr %s0, ptr %a0, ptr %t27, { i64, ptr } %a2, i1 %t29, ptr %l6, ptr %t30)
  %t38 = extractvalue { i32, %"compiler/build:Listed" } %t37, 1
  %t39 = extractvalue { i32, %"compiler/build:Listed" } %t37, 0
  store i32 %t39, ptr %l23
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb3, label %ok.41, !prof !99
ok.41:
  store %"compiler/build:Listed" %t38, ptr %l22
  br label %bb2
bb2:
  %t42 = load %"compiler/build:Listed", ptr %l22
  store %"compiler/build:Listed" %t42, ptr %l15
  br label %bb11
bb3:
  %t43 = load i32, ptr %l23, !tbaa !23
  %t44 = icmp eq i32 %t43, 65536
  br i1 %t44, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t46 = load i32, ptr %l23, !tbaa !23
  %t47 = icmp eq i32 %t46, 65537
  br i1 %t47, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t49 = load ptr, ptr %l5, !tbaa !29
  %t51 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t49)
  store i32 %t51, ptr %l27
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4ce37e8669e18741_b51ffe42b73135c5)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i32, ptr %l27, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
bb11:
  %t54 = load %"compiler/build:Listed", ptr %l15
  store %"compiler/build:Listed" %t54, ptr %l7
  store ptr %l6, ptr %l29, !tbaa !29
  store ptr %l7, ptr %l30, !tbaa !29
  %t55 = load ptr, ptr %l1, !tbaa !29
  %t56 = load i1, ptr %l4, !tbaa !21
  %t59 = call { i64, ptr } @compiler_2flisting_2ehow(ptr %v1, ptr %s0, ptr %t55, i1 %t56)
  store { i64, ptr } %t59, ptr %l33
  br label %bb12
bb12:
  %t60 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t61 = extractvalue { i64, ptr } %t60, 0
  %t62 = extractvalue { i64, ptr } %t60, 1
  %t63 = mul i64 %t61, 1
  %t64 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t63)
  call void @llvm.memcpy.p0.p0.i64(ptr %t64, ptr %t62, i64 %t63, i1 false)
  %t65 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t66 = insertvalue { i64, ptr } %t65, ptr %t64, 1
  store { i64, ptr } %t66, ptr %l34, !tbaa !27
  %t67 = load ptr, ptr %l1, !tbaa !29
  %t68 = load i1, ptr %l4, !tbaa !21
  %t71 = call { i64, ptr } @compiler_2flisting_2ecommentOf(ptr %v1, ptr %s0, ptr %t67, i1 %t68)
  store { i64, ptr } %t71, ptr %l37
  br label %bb13
bb13:
  %t72 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t73 = extractvalue { i64, ptr } %t72, 0
  %t74 = extractvalue { i64, ptr } %t72, 1
  %t75 = mul i64 %t73, 1
  %t76 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t75)
  call void @llvm.memcpy.p0.p0.i64(ptr %t76, ptr %t74, i64 %t75, i1 false)
  %t77 = insertvalue { i64, ptr } undef, i64 %t73, 0
  %t78 = insertvalue { i64, ptr } %t77, ptr %t76, 1
  %t79 = load i1, ptr %l4, !tbaa !21
  %t80 = load ptr, ptr %l29, !tbaa !29
  %t81 = load ptr, ptr %l30, !tbaa !29
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t85 = call %"compiler/listing:Inputs" @compiler_2flisting_3aInputs_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t80, ptr %t81, { i64, ptr } %t82, { i64, ptr } %t78, i1 %t79)
  store %"compiler/listing:Inputs" %t85, ptr %l40
  br label %bb14
bb14:
  %t86 = load %"compiler/listing:Inputs", ptr %l40
  %t87 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 56, i64 8)
  store %"compiler/listing:Inputs" %t86, ptr %t87
  %t89 = call { i64, ptr } @compiler_2flisting_2eRender(ptr %s0, ptr %s0, ptr %t87)
  store { i64, ptr } %t89, ptr %l42
  br label %bb15
bb15:
  %t90 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t90, 0
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = mul i64 %t91, 1
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @llvm.memcpy.p0.p0.i64(ptr %t94, ptr %t92, i64 %t93, i1 false)
  %t95 = insertvalue { i64, ptr } undef, i64 %t91, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  call void @compiler_2flisting_2esay(ptr %s0, { i64, ptr } %t96)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/diag:Diagnostics"
  %l16 = alloca %"compiler/build:Config"
  %l18 = alloca %"compiler/olang:CommandLine"
  %l22 = alloca %"compiler/olang:CommandLine"
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i32
  %l45 = alloca i1
  %l48 = alloca { i64, ptr }
  %l50 = alloca i32
  %l54 = alloca i1
  %l56 = alloca i1
  %l58 = alloca ptr
  %l59 = alloca ptr
  %l61 = alloca { i64, ptr }
  %l62 = alloca { i64, ptr }
  %l64 = alloca i1
  %l66 = alloca i32
  %l71 = alloca i64
  %l73 = alloca ptr
  %l74 = alloca ptr
  %l76 = alloca { i64, ptr }
  %l79 = alloca i32
  %l80 = alloca { i64, ptr }
  %l83 = alloca { i64, ptr }
  %l84 = alloca i32
  %l86 = alloca i1
  %l88 = alloca i32
  %l90 = alloca i32
  %l95 = alloca i32
  %l99 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i32
  %l103 = alloca i1
  %l104 = alloca { i64, ptr }
  %l108 = alloca i1
  %l110 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca { i64, ptr }
  %l114 = alloca i32
  %l119 = alloca { i64, ptr }
  %l120 = alloca { i64, ptr }
  %l121 = alloca { i64, ptr }
  %l123 = alloca i32
  %l128 = alloca { i64, ptr }
  %l132 = alloca i32
  %l137 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l141 = alloca { i64, ptr }
  %l143 = alloca i32
  %l148 = alloca i32
  %l152 = alloca ptr
  %l153 = alloca { i64, ptr }
  %l154 = alloca { i64, ptr }
  %l155 = alloca i32
  %l157 = alloca i1
  %l158 = alloca { i64, ptr }
  %l162 = alloca i32
  %l164 = alloca { i64, ptr }
  %l170 = alloca { i64, ptr }
  %l173 = alloca i32
  %l179 = alloca { i64, ptr }
  %l182 = alloca i32
  %l186 = alloca ptr
  %l187 = alloca ptr
  %l188 = alloca { i64, ptr }
  %l189 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l193 = alloca i32
  %l197 = alloca ptr
  %l198 = alloca ptr
  %l199 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l202 = alloca { i64, ptr }
  %l204 = alloca i32
  %l208 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l210 = alloca { i64, ptr }
  %l215 = alloca i64
  %l217 = alloca i64
  %l222 = alloca { i64, ptr }
  %l229 = alloca ptr
  %l230 = alloca ptr
  %l231 = alloca { i64, ptr }
  %l232 = alloca { i64, ptr }
  %l234 = alloca { i64, ptr }
  %l236 = alloca i32
  %l240 = alloca i1
  %l242 = alloca ptr
  %l243 = alloca ptr
  %l244 = alloca { i64, ptr }
  %l245 = alloca { i64, ptr }
  %l246 = alloca ptr
  %l248 = alloca { i64, ptr }
  %l249 = alloca i32
  %l253 = alloca ptr
  %l254 = alloca ptr
  %l255 = alloca { i64, ptr }
  %l256 = alloca { i64, ptr }
  %l257 = alloca ptr
  %l259 = alloca { i64, ptr }
  %l260 = alloca i32
  %l261 = alloca { i64, ptr }
  %l262 = alloca { i64, ptr }
  %l263 = alloca i32
  %l265 = alloca i1
  %l266 = alloca { i64, ptr }
  %l270 = alloca ptr
  %l271 = alloca { i64, ptr }
  %l273 = alloca { i64, ptr }
  %l274 = alloca { i64, ptr }
  %l276 = alloca { i64, ptr }
  %l277 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %s22 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  %t10 = alloca %"compiler/olang:CommandLine", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l14
  br label %bb1
bb1:
  %t3 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t2, i64 544, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l15, i64 544, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t4, i64 552, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 552, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 19
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %t10, ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  store i32 %t14, ptr %l23
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t10, i64 240, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l22, i64 240, i1 false)
  br label %bb8
bb5:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  %t22 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t22, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l27, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l18, i64 240, i1 false)
  %t24 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  br i1 %t29, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t33 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %s0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t34 = extractvalue { i32, { i64, ptr } } %t33, 1
  %t35 = extractvalue { i32, { i64, ptr } } %t33, 0
  store i32 %t35, ptr %l35
  %t36 = icmp ne i32 %t35, 0
  br i1 %t36, label %bb12, label %ok.37, !prof !99
ok.37:
  store { i64, ptr } %t34, ptr %l34
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t38 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t38, ptr %l31, !tbaa !27
  br label %bb15
bb12:
  %t39 = load i32, ptr %l35, !tbaa !23
  %t40 = ashr i32 %t39, 16
  %t42 = icmp eq i32 %t40, 1
  store i1 %t42, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  %t44 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t44, ptr %l39
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t45 = load i32, ptr %l39, !tbaa !23
  store i32 %t45, ptr %rv
  br label %ret
bb15:
  %t46 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t49 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t46)
  store i32 %t49, ptr %l41
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i32, ptr %l41, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb17:
  %t51 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t52 = load i64, ptr %t51, !tbaa !24
  %t53 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t56 = icmp eq i64 %t52, %t53
  br i1 %t56, label %bb18, label %bb19
bb18:
  %t58 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 11
  %t59 = load i1, ptr %t58, !tbaa !21
  store i1 %t59, ptr %l45, !tbaa !21
  br label %bb20
bb19:
  store i1 false, ptr %l45, !tbaa !21
  br label %bb20
bb20:
  %t61 = load i1, ptr %l45, !tbaa !21
  br i1 %t61, label %bb21, label %bb22
bb21:
  %t62 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t64 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t62, i64 0)
  store { i64, ptr } %t64, ptr %l48
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t65 = load { i64, ptr }, ptr %l48, !tbaa !27
  %t67 = call i32 @compiler_2fsession_2eCapsMode(ptr %s0, ptr %s0, { i64, ptr } %t65, ptr %l3)
  store i32 %t67, ptr %l50
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s0)
  %t68 = load i32, ptr %l50, !tbaa !23
  store i32 %t68, ptr %rv
  br label %ret
bb25:
  %t69 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t70 = load i64, ptr %t69, !tbaa !24
  %t71 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t74 = icmp eq i64 %t70, %t71
  br i1 %t74, label %bb26, label %bb27
bb26:
  %t76 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t77 = load { i64, ptr }, ptr %t76, !tbaa !27
  %t79 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t77, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) })
  store i1 %t79, ptr %l56
  br label %bb28
bb27:
  store i1 false, ptr %l54, !tbaa !21
  br label %bb29
bb28:
  %t80 = load i1, ptr %l56, !tbaa !21
  %t81 = xor i1 %t80, true
  store i1 %t81, ptr %l54, !tbaa !21
  br label %bb29
bb29:
  %t83 = load i1, ptr %l54, !tbaa !21
  br i1 %t83, label %bb30, label %bb31
bb30:
  store %olang.scope zeroinitializer, ptr %s5
  %t84 = load ptr, ptr %l1, !tbaa !29
  store ptr %t84, ptr %l58, !tbaa !29
  store ptr %l3, ptr %l59, !tbaa !29
  %t85 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t87 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t85, i64 0)
  store { i64, ptr } %t87, ptr %l61
  br label %bb32
bb31:
  br label %bb35
bb32:
  %t88 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t89 = load { i64, ptr }, ptr %t88, !tbaa !27
  store { i64, ptr } %t89, ptr %l62, !tbaa !27
  %t90 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t91 = load { i64, ptr }, ptr %t90, !tbaa !27
  %t93 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s5, { i64, ptr } %t91, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d30, i32 0, i32 1) })
  store i1 %t93, ptr %l64
  br label %bb33
bb33:
  %t94 = load ptr, ptr %l58, !tbaa !29
  %t95 = load ptr, ptr %l59, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t98 = load i1, ptr %l64, !tbaa !21
  %t100 = call i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t94, ptr %t95, { i64, ptr } %t96, { i64, ptr } %t97, i1 %t98, ptr %l2)
  store i32 %t100, ptr %l66
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s5)
  call void @__olang_scope_close(ptr %s0)
  %t101 = load i32, ptr %l66, !tbaa !23
  store i32 %t101, ptr %rv
  br label %ret
bb35:
  %t102 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  br i1 %t107, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t109 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t111 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t109)
  store i64 %t111, ptr %l71
  br label %bb38
bb37:
  br label %bb50
bb38:
  %t112 = load i64, ptr %l71, !tbaa !24
  %t113 = icmp eq i64 %t112, 1
  br i1 %t113, label %bb39, label %bb40
bb39:
  %t115 = load ptr, ptr %l1, !tbaa !29
  store ptr %t115, ptr %l73, !tbaa !29
  store ptr %l3, ptr %l74, !tbaa !29
  %t116 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t118 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t116, i64 0)
  store { i64, ptr } %t118, ptr %l76
  br label %bb41
bb40:
  br label %bb43
bb41:
  %t119 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  %t121 = load ptr, ptr %l73, !tbaa !29
  %t122 = load ptr, ptr %l74, !tbaa !29
  %t123 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t126 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t121, ptr %t122, { i64, ptr } %t123, { i64, ptr } %t120, ptr %l2)
  store i32 %t126, ptr %l79
  br label %bb42
bb42:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t127 = load i32, ptr %l79, !tbaa !23
  store i32 %t127, ptr %rv
  br label %ret
bb43:
  %t128 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t129 = load { i64, ptr }, ptr %t128, !tbaa !27
  %t132 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %s0, ptr %s0, ptr %s6, { i64, ptr } %t129, ptr %l2)
  %t133 = extractvalue { i32, { i64, ptr } } %t132, 1
  %t134 = extractvalue { i32, { i64, ptr } } %t132, 0
  store i32 %t134, ptr %l84
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb45, label %ok.136, !prof !99
ok.136:
  store { i64, ptr } %t133, ptr %l83
  br label %bb44
bb44:
  %t137 = load { i64, ptr }, ptr %l83, !tbaa !27
  store { i64, ptr } %t137, ptr %l80, !tbaa !27
  br label %bb48
bb45:
  %t138 = load i32, ptr %l84, !tbaa !23
  %t139 = ashr i32 %t138, 16
  %t141 = icmp eq i32 %t139, 1
  store i1 %t141, ptr %l86, !tbaa !21
  br label %bb46
bb46:
  call void @__olang_ert_req_clear()
  %t143 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t143, ptr %l88
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t144 = load i32, ptr %l88, !tbaa !23
  store i32 %t144, ptr %rv
  br label %ret
bb48:
  %t145 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t148 = call i32 @compiler_2folang_2ewrite(ptr %s6, { i64, ptr } %t145)
  store i32 %t148, ptr %l90
  br label %bb49
bb49:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t149 = load i32, ptr %l90, !tbaa !23
  store i32 %t149, ptr %rv
  br label %ret
bb50:
  %t150 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t151 = load i64, ptr %t150, !tbaa !24
  %t152 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t155 = icmp eq i64 %t151, %t152
  br i1 %t155, label %bb51, label %bb52
bb51:
  %t158 = call i32 @compiler_2folang_2eformat(ptr %s0, ptr %l4)
  store i32 %t158, ptr %l95
  br label %bb53
bb52:
  br label %bb54
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t159 = load i32, ptr %l95, !tbaa !23
  store i32 %t159, ptr %rv
  br label %ret
bb54:
  %t160 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t161 = load i64, ptr %t160, !tbaa !24
  %t162 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t165 = icmp eq i64 %t161, %t162
  br i1 %t165, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t167 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s10, ptr %s10, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d31, i32 0, i32 1) })
  %t168 = extractvalue { i32, { i64, ptr } } %t167, 1
  %t169 = extractvalue { i32, { i64, ptr } } %t167, 0
  store i32 %t169, ptr %l101
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb58, label %ok.171, !prof !99
ok.171:
  store { i64, ptr } %t168, ptr %l100
  br label %bb57
bb56:
  br label %bb64
bb57:
  %t172 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t172, ptr %l99, !tbaa !27
  br label %bb60
bb58:
  %t173 = load i32, ptr %l101, !tbaa !23
  %t174 = ashr i32 %t173, 16
  %t176 = icmp eq i32 %t174, 1
  store i1 %t176, ptr %l103, !tbaa !21
  br label %bb59
bb59:
  call void @__olang_ert_req_clear()
  %t177 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t177, ptr %l104, !tbaa !27
  %t178 = getelementptr { i64, ptr }, ptr %l104, i32 0, i32 1
  %t179 = load ptr, ptr %t178, !tbaa !27
  %t180 = getelementptr { i64, ptr }, ptr %t179, i64 0
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !37
  %t183 = extractvalue { i64, ptr } %t181, 1
  %t184 = extractvalue { i64, ptr } %t181, 0
  %t185 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t184)
  call void @olang_textcopy(ptr %t185, ptr %t183, i64 %t184)
  %t186 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t187 = insertvalue { i64, ptr } %t186, ptr %t185, 1
  %t189 = extractvalue { i64, ptr } %t187, 0
  %t190 = extractvalue { i64, ptr } %t187, 1
  %t191 = mul i64 %t189, 1
  %t192 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t191)
  call void @llvm.memcpy.p0.p0.i64(ptr %t192, ptr %t190, i64 %t191, i1 false)
  %t193 = insertvalue { i64, ptr } undef, i64 %t189, 0
  %t194 = insertvalue { i64, ptr } %t193, ptr %t192, 1
  store { i64, ptr } %t194, ptr %l99, !tbaa !27
  br label %bb60
bb60:
  %t196 = load { i64, ptr }, ptr %l99, !tbaa !27
  store { i64, ptr } %t196, ptr %l7, !tbaa !27
  %t197 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t198 = load i1, ptr %t197, !tbaa !21
  store i1 %t198, ptr %l108, !tbaa !21
  %t199 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t201 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t199)
  store { i64, ptr } %t201, ptr %l110
  br label %bb61
bb61:
  %t202 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t202, ptr %l111, !tbaa !27
  %t203 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s10)
  store { i64, ptr } %t203, ptr %l112
  br label %bb62
bb62:
  %t204 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t205 = extractvalue { i64, ptr } %t204, 0
  %t206 = extractvalue { i64, ptr } %t204, 1
  %t207 = mul i64 %t205, 1
  %t208 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t207)
  call void @llvm.memcpy.p0.p0.i64(ptr %t208, ptr %t206, i64 %t207, i1 false)
  %t209 = insertvalue { i64, ptr } undef, i64 %t205, 0
  %t210 = insertvalue { i64, ptr } %t209, ptr %t208, 1
  %t211 = load i1, ptr %l108, !tbaa !21
  %t212 = load { i64, ptr }, ptr %l110, !tbaa !27
  %t213 = load { i64, ptr }, ptr %l111, !tbaa !27
  %t215 = call i32 @compiler_2ffix_2eFiles(ptr %s0, ptr %s10, ptr %s10, i1 %t211, { i64, ptr } %t212, { i64, ptr } %t213, { i64, ptr } %t210)
  store i32 %t215, ptr %l114
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t216 = load i32, ptr %l114, !tbaa !23
  store i32 %t216, ptr %rv
  br label %ret
bb64:
  %t217 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t218 = load i64, ptr %t217, !tbaa !24
  %t219 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t222 = icmp eq i64 %t218, %t219
  br i1 %t222, label %bb65, label %bb66
bb65:
  store %olang.scope zeroinitializer, ptr %s12
  %t224 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t226 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t224, i64 0)
  store { i64, ptr } %t226, ptr %l119
  br label %bb67
bb66:
  br label %bb70
bb67:
  %t227 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t228 = load { i64, ptr }, ptr %t227, !tbaa !27
  store { i64, ptr } %t228, ptr %l120, !tbaa !27
  %t229 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s12)
  store { i64, ptr } %t229, ptr %l121
  br label %bb68
bb68:
  %t230 = load { i64, ptr }, ptr %l121, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t230, 0
  %t232 = extractvalue { i64, ptr } %t230, 1
  %t233 = mul i64 %t231, 1
  %t234 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t233)
  call void @llvm.memcpy.p0.p0.i64(ptr %t234, ptr %t232, i64 %t233, i1 false)
  %t235 = insertvalue { i64, ptr } undef, i64 %t231, 0
  %t236 = insertvalue { i64, ptr } %t235, ptr %t234, 1
  %t237 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t238 = load { i64, ptr }, ptr %l120, !tbaa !27
  %t240 = call i32 @compiler_2fbindgen_2eRun(ptr %s0, ptr %s0, ptr %s12, { i64, ptr } %t237, { i64, ptr } %t238, { i64, ptr } %t236)
  store i32 %t240, ptr %l123
  br label %bb69
bb69:
  call void @__olang_scope_close(ptr %s12)
  call void @__olang_scope_close(ptr %s0)
  %t241 = load i32, ptr %l123, !tbaa !23
  store i32 %t241, ptr %rv
  br label %ret
bb70:
  %t242 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t243 = load i64, ptr %t242, !tbaa !24
  %t244 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t247 = icmp eq i64 %t243, %t244
  br i1 %t247, label %bb71, label %bb72
bb71:
  %t249 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t251 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t249)
  store { i64, ptr } %t251, ptr %l128
  br label %bb73
bb72:
  br label %bb75
bb73:
  %t252 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t253 = load { i64, ptr }, ptr %t252, !tbaa !27
  %t254 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 10
  %t255 = load { i64, ptr }, ptr %t254, !tbaa !27
  %t256 = load { i64, ptr }, ptr %l128, !tbaa !27
  %t260 = call i32 @compiler_2fsession_2eDocMode(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t256, { i64, ptr } %t253, { i64, ptr } %t255, ptr %l3)
  store i32 %t260, ptr %l132
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s0)
  %t261 = load i32, ptr %l132, !tbaa !23
  store i32 %t261, ptr %rv
  br label %ret
bb75:
  %t262 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t263 = load i64, ptr %t262, !tbaa !24
  %t264 = load i64, ptr @G_2ecompiler_2folang_2eApi, !tbaa !24
  %t267 = icmp eq i64 %t263, %t264
  br i1 %t267, label %bb76, label %bb77
bb76:
  %t269 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t271 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t269, i64 0)
  store { i64, ptr } %t271, ptr %l137
  br label %bb78
bb77:
  br label %bb82
bb78:
  %t272 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t274 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t272, i64 1)
  store { i64, ptr } %t274, ptr %l139
  br label %bb79
bb79:
  %t275 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t277 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t275, i64 2)
  store { i64, ptr } %t277, ptr %l141
  br label %bb80
bb80:
  %t278 = load { i64, ptr }, ptr %l137, !tbaa !27
  %t279 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t280 = load { i64, ptr }, ptr %l141, !tbaa !27
  %t282 = call i32 @compiler_2fapi_2eMode(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t278, { i64, ptr } %t279, { i64, ptr } %t280, ptr %l3)
  store i32 %t282, ptr %l143
  br label %bb81
bb81:
  call void @__olang_scope_close(ptr %s0)
  %t283 = load i32, ptr %l143, !tbaa !23
  store i32 %t283, ptr %rv
  br label %ret
bb82:
  %t284 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t285 = load i64, ptr %t284, !tbaa !24
  %t286 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t289 = icmp eq i64 %t285, %t286
  br i1 %t289, label %bb83, label %bb84
bb83:
  %t292 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t292, ptr %l148
  br label %bb85
bb84:
  br label %bb86
bb85:
  call void @__olang_scope_close(ptr %s0)
  %t293 = load i32, ptr %l148, !tbaa !23
  store i32 %t293, ptr %rv
  br label %ret
bb86:
  %t294 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t295 = load i64, ptr %t294, !tbaa !24
  %t296 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t299 = icmp eq i64 %t295, %t296
  br i1 %t299, label %bb87, label %bb88
bb87:
  store %olang.scope zeroinitializer, ptr %s16
  store ptr %l3, ptr %l152, !tbaa !29
  %t301 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s16, ptr %s16, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d32, i32 0, i32 1) })
  %t302 = extractvalue { i32, { i64, ptr } } %t301, 1
  %t303 = extractvalue { i32, { i64, ptr } } %t301, 0
  store i32 %t303, ptr %l155
  %t304 = icmp ne i32 %t303, 0
  br i1 %t304, label %bb90, label %ok.305, !prof !99
ok.305:
  store { i64, ptr } %t302, ptr %l154
  br label %bb89
bb88:
  br label %bb94
bb89:
  %t306 = load { i64, ptr }, ptr %l154, !tbaa !27
  store { i64, ptr } %t306, ptr %l153, !tbaa !27
  br label %bb92
bb90:
  %t307 = load i32, ptr %l155, !tbaa !23
  %t308 = ashr i32 %t307, 16
  %t310 = icmp eq i32 %t308, 1
  store i1 %t310, ptr %l157, !tbaa !21
  br label %bb91
bb91:
  call void @__olang_ert_req_clear()
  %t311 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t311, ptr %l158, !tbaa !27
  %t312 = getelementptr { i64, ptr }, ptr %l158, i32 0, i32 1
  %t313 = load ptr, ptr %t312, !tbaa !27
  %t314 = getelementptr { i64, ptr }, ptr %t313, i64 0
  %t315 = load { i64, ptr }, ptr %t314, !tbaa !37
  %t317 = extractvalue { i64, ptr } %t315, 1
  %t318 = extractvalue { i64, ptr } %t315, 0
  %t319 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t318)
  call void @olang_textcopy(ptr %t319, ptr %t317, i64 %t318)
  %t320 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t321 = insertvalue { i64, ptr } %t320, ptr %t319, 1
  %t323 = extractvalue { i64, ptr } %t321, 0
  %t324 = extractvalue { i64, ptr } %t321, 1
  %t325 = mul i64 %t323, 1
  %t326 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t325)
  call void @llvm.memcpy.p0.p0.i64(ptr %t326, ptr %t324, i64 %t325, i1 false)
  %t327 = insertvalue { i64, ptr } undef, i64 %t323, 0
  %t328 = insertvalue { i64, ptr } %t327, ptr %t326, 1
  store { i64, ptr } %t328, ptr %l153, !tbaa !27
  br label %bb92
bb92:
  %t330 = load ptr, ptr %l152, !tbaa !29
  %t331 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t332 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s16, ptr %t330, { i64, ptr } %t331)
  store i32 %t332, ptr %l162
  br label %bb93
bb93:
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  %t333 = load i32, ptr %l162, !tbaa !23
  store i32 %t333, ptr %rv
  br label %ret
bb94:
  %t334 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t336 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t334)
  store { i64, ptr } %t336, ptr %l164
  br label %bb95
bb95:
  %t337 = load { i64, ptr }, ptr %l164, !tbaa !27
  store { i64, ptr } %t337, ptr %l8, !tbaa !27
  %t338 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t339 = load i64, ptr %t338, !tbaa !24
  %t340 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t343 = icmp eq i64 %t339, %t340
  br i1 %t343, label %bb96, label %bb97
bb96:
  %t345 = load ptr, ptr %l1, !tbaa !29
  %t346 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t346, ptr %l170, !tbaa !27
  %t347 = getelementptr { i64, ptr }, ptr %l170, i32 0, i32 1
  %t348 = load ptr, ptr %t347, !tbaa !27
  %t349 = getelementptr { i64, ptr }, ptr %t348, i64 0
  %t350 = load { i64, ptr }, ptr %t349, !tbaa !37
  %t355 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t345, ptr %l3, { i64, ptr } %t350, ptr %l2)
  store i32 %t355, ptr %l173
  br label %bb98
bb97:
  br label %bb99
bb98:
  call void @__olang_scope_close(ptr %s0)
  %t356 = load i32, ptr %l173, !tbaa !23
  store i32 %t356, ptr %rv
  br label %ret
bb99:
  %t357 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t358 = load i64, ptr %t357, !tbaa !24
  %t359 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t362 = icmp eq i64 %t358, %t359
  br i1 %t362, label %bb100, label %bb101
bb100:
  %t364 = load ptr, ptr %l1, !tbaa !29
  %t365 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t365, ptr %l179, !tbaa !27
  %t366 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t367 = load ptr, ptr %t366, !tbaa !27
  %t368 = getelementptr { i64, ptr }, ptr %t367, i64 0
  %t369 = load { i64, ptr }, ptr %t368, !tbaa !37
  %t374 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t364, ptr %l3, { i64, ptr } %t369, ptr %l2)
  store i32 %t374, ptr %l182
  br label %bb102
bb101:
  br label %bb103
bb102:
  call void @__olang_scope_close(ptr %s0)
  %t375 = load i32, ptr %l182, !tbaa !23
  store i32 %t375, ptr %rv
  br label %ret
bb103:
  %t376 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t377 = load i64, ptr %t376, !tbaa !24
  %t378 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t381 = icmp eq i64 %t377, %t378
  br i1 %t381, label %bb104, label %bb105
bb104:
  %t383 = load ptr, ptr %l1, !tbaa !29
  store ptr %t383, ptr %l186, !tbaa !29
  store ptr %l3, ptr %l187, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t384, ptr %l188, !tbaa !27
  %t385 = getelementptr { i64, ptr }, ptr %l188, i32 0, i32 1
  %t386 = load ptr, ptr %t385, !tbaa !27
  %t387 = getelementptr { i64, ptr }, ptr %t386, i64 0
  %t388 = load { i64, ptr }, ptr %t387, !tbaa !37
  store { i64, ptr } %t388, ptr %l189, !tbaa !27
  %t389 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t391 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t389)
  store { i64, ptr } %t391, ptr %l191
  br label %bb106
bb105:
  br label %bb108
bb106:
  %t392 = load ptr, ptr %l186, !tbaa !29
  %t393 = load ptr, ptr %l187, !tbaa !29
  %t394 = load { i64, ptr }, ptr %l189, !tbaa !27
  %t395 = load { i64, ptr }, ptr %l191, !tbaa !27
  %t397 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t392, ptr %t393, { i64, ptr } %t394, { i64, ptr } %t395, ptr %l2)
  store i32 %t397, ptr %l193
  br label %bb107
bb107:
  call void @__olang_scope_close(ptr %s0)
  %t398 = load i32, ptr %l193, !tbaa !23
  store i32 %t398, ptr %rv
  br label %ret
bb108:
  %t399 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t400 = load i64, ptr %t399, !tbaa !24
  %t401 = load i64, ptr @G_2ecompiler_2folang_2eProfile, !tbaa !24
  %t404 = icmp eq i64 %t400, %t401
  br i1 %t404, label %bb109, label %bb110
bb109:
  %t406 = load ptr, ptr %l1, !tbaa !29
  store ptr %t406, ptr %l197, !tbaa !29
  store ptr %l3, ptr %l198, !tbaa !29
  %t407 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t407, ptr %l199, !tbaa !27
  %t408 = getelementptr { i64, ptr }, ptr %l199, i32 0, i32 1
  %t409 = load ptr, ptr %t408, !tbaa !27
  %t410 = getelementptr { i64, ptr }, ptr %t409, i64 0
  %t411 = load { i64, ptr }, ptr %t410, !tbaa !37
  store { i64, ptr } %t411, ptr %l200, !tbaa !27
  %t412 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t414 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t412)
  store { i64, ptr } %t414, ptr %l202
  br label %bb111
bb110:
  br label %bb113
bb111:
  %t415 = load ptr, ptr %l197, !tbaa !29
  %t416 = load ptr, ptr %l198, !tbaa !29
  %t417 = load { i64, ptr }, ptr %l200, !tbaa !27
  %t418 = load { i64, ptr }, ptr %l202, !tbaa !27
  %t420 = call i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t415, ptr %t416, { i64, ptr } %t417, { i64, ptr } %t418, ptr %l2)
  store i32 %t420, ptr %l204
  br label %bb112
bb112:
  call void @__olang_scope_close(ptr %s0)
  %t421 = load i32, ptr %l204, !tbaa !23
  store i32 %t421, ptr %rv
  br label %ret
bb113:
  %t422 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t423 = load i64, ptr %t422, !tbaa !24
  %t424 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t427 = icmp eq i64 %t423, %t424
  br i1 %t427, label %bb114, label %bb115
bb114:
  store %olang.scope zeroinitializer, ptr %s22
  %t429 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s22, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t429, ptr %l208
  br label %bb116
bb115:
  br label %bb129
bb116:
  %t430 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l208
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t430, ptr %l9
  %t431 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t431, ptr %l210, !tbaa !27
  %t432 = getelementptr { i64, ptr }, ptr %l210, i32 0, i32 1
  %t433 = load ptr, ptr %t432, !tbaa !27
  %t434 = getelementptr { i64, ptr }, ptr %t433, i64 0
  %t435 = load { i64, ptr }, ptr %t434, !tbaa !37
  %t437 = extractvalue { i64, ptr } %t435, 1
  %t438 = extractvalue { i64, ptr } %t435, 0
  %t439 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t438)
  call void @olang_textcopy(ptr %t439, ptr %t437, i64 %t438)
  %t440 = insertvalue { i64, ptr } undef, i64 %t438, 0
  %t441 = insertvalue { i64, ptr } %t440, ptr %t439, 1
  %t443 = extractvalue { i64, ptr } %t441, 0
  %t444 = extractvalue { i64, ptr } %t441, 1
  %t445 = mul i64 %t443, 1
  %t446 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t445)
  call void @llvm.memcpy.p0.p0.i64(ptr %t446, ptr %t444, i64 %t445, i1 false)
  %t447 = insertvalue { i64, ptr } undef, i64 %t443, 0
  %t448 = insertvalue { i64, ptr } %t447, ptr %t446, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s22, ptr %s22, ptr %l9, { i64, ptr } %t448)
  br label %bb117
bb117:
  %t451 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  store ptr %t451, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb118
bb118:
  %t453 = load i64, ptr %l11, !tbaa !24
  store i64 %t453, ptr %l215, !tbaa !24
  %t454 = load ptr, ptr %l10, !tbaa !29
  %t456 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t454)
  store i64 %t456, ptr %l217
  br label %bb119
bb119:
  %t457 = load i64, ptr %l215, !tbaa !24
  %t458 = load i64, ptr %l217, !tbaa !24
  %t459 = icmp slt i64 %t457, %t458
  %t461 = xor i1 %t459, true
  br i1 %t461, label %bb120, label %bb121
bb120:
  br label %bb126
bb121:
  br label %bb122
bb122:
  %t463 = load ptr, ptr %l10, !tbaa !29
  %t464 = load i64, ptr %l11, !tbaa !24
  %t467 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %s0, ptr %s0, ptr %t463, i64 %t464)
  store { i64, ptr } %t467, ptr %l222
  br label %bb123
bb123:
  %t468 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t471 = extractvalue { i64, ptr } %t468, 1
  %t472 = extractvalue { i64, ptr } %t468, 0
  %t473 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t472)
  call void @olang_textcopy(ptr %t473, ptr %t471, i64 %t472)
  %t474 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t475 = insertvalue { i64, ptr } %t474, ptr %t473, 1
  %t477 = extractvalue { i64, ptr } %t475, 0
  %t478 = extractvalue { i64, ptr } %t475, 1
  %t479 = mul i64 %t477, 1
  %t480 = call ptr @__olang_scope_alloc(ptr %s22, i64 %t479)
  call void @llvm.memcpy.p0.p0.i64(ptr %t480, ptr %t478, i64 %t479, i1 false)
  %t481 = insertvalue { i64, ptr } undef, i64 %t477, 0
  %t482 = insertvalue { i64, ptr } %t481, ptr %t480, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s22, ptr %s22, ptr %l9, { i64, ptr } %t482)
  br label %bb124
bb124:
  br label %bb125
bb125:
  %t485 = load i64, ptr %l11, !tbaa !24
  %t487 = add i64 %t485, 1
  store i64 %t487, ptr %l11, !tbaa !24
  br label %bb118
bb126:
  %t489 = load ptr, ptr %l1, !tbaa !29
  store ptr %t489, ptr %l229, !tbaa !29
  store ptr %l3, ptr %l230, !tbaa !29
  %t490 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t490, ptr %l231, !tbaa !27
  %t491 = getelementptr { i64, ptr }, ptr %l231, i32 0, i32 1
  %t492 = load ptr, ptr %t491, !tbaa !27
  %t493 = getelementptr { i64, ptr }, ptr %t492, i64 0
  %t494 = load { i64, ptr }, ptr %t493, !tbaa !37
  store { i64, ptr } %t494, ptr %l232, !tbaa !27
  %t496 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s22, ptr %s22, ptr %l9)
  store { i64, ptr } %t496, ptr %l234
  br label %bb127
bb127:
  %t497 = load ptr, ptr %l229, !tbaa !29
  %t498 = load ptr, ptr %l230, !tbaa !29
  %t499 = load { i64, ptr }, ptr %l232, !tbaa !27
  %t500 = load { i64, ptr }, ptr %l234, !tbaa !27
  %t502 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s22, ptr %s0, ptr %t497, ptr %t498, { i64, ptr } %t499, { i64, ptr } %t500, ptr %l2)
  store i32 %t502, ptr %l236
  br label %bb128
bb128:
  call void @__olang_scope_close(ptr %s22)
  call void @__olang_scope_close(ptr %s0)
  %t503 = load i32, ptr %l236, !tbaa !23
  store i32 %t503, ptr %rv
  br label %ret
bb129:
  %t504 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t506 = extractvalue { i64, ptr } %t504, 0
  %t508 = icmp eq i64 %t506, 1
  br i1 %t508, label %bb130, label %bb131
bb130:
  %t510 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 17
  %t511 = load i1, ptr %t510, !tbaa !21
  store i1 %t511, ptr %l240, !tbaa !21
  br label %bb132
bb131:
  store i1 false, ptr %l240, !tbaa !21
  br label %bb132
bb132:
  %t513 = load i1, ptr %l240, !tbaa !21
  br i1 %t513, label %bb133, label %bb134
bb133:
  %t514 = load ptr, ptr %l1, !tbaa !29
  store ptr %t514, ptr %l242, !tbaa !29
  store ptr %l3, ptr %l243, !tbaa !29
  %t515 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t515, ptr %l244, !tbaa !27
  %t516 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t517 = load ptr, ptr %t516, !tbaa !27
  %t518 = getelementptr { i64, ptr }, ptr %t517, i64 0
  %t519 = load { i64, ptr }, ptr %t518, !tbaa !37
  store { i64, ptr } %t519, ptr %l245, !tbaa !27
  store ptr %l2, ptr %l246, !tbaa !29
  %t520 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t522 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t520)
  store { i64, ptr } %t522, ptr %l248
  br label %bb135
bb134:
  br label %bb137
bb135:
  %t523 = load ptr, ptr %l242, !tbaa !29
  %t524 = load ptr, ptr %l243, !tbaa !29
  %t525 = load { i64, ptr }, ptr %l245, !tbaa !27
  %t526 = load ptr, ptr %l246, !tbaa !29
  %t527 = load { i64, ptr }, ptr %l248, !tbaa !27
  %t528 = call i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t523, ptr %t524, { i64, ptr } %t525, ptr %t526, { i64, ptr } %t527)
  store i32 %t528, ptr %l249
  br label %bb136
bb136:
  call void @__olang_scope_close(ptr %s0)
  %t529 = load i32, ptr %l249, !tbaa !23
  store i32 %t529, ptr %rv
  br label %ret
bb137:
  %t530 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t532 = extractvalue { i64, ptr } %t530, 0
  %t534 = icmp eq i64 %t532, 1
  br i1 %t534, label %bb138, label %bb139
bb138:
  %t536 = load ptr, ptr %l1, !tbaa !29
  store ptr %t536, ptr %l253, !tbaa !29
  store ptr %l3, ptr %l254, !tbaa !29
  %t537 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t537, ptr %l255, !tbaa !27
  %t538 = getelementptr { i64, ptr }, ptr %l255, i32 0, i32 1
  %t539 = load ptr, ptr %t538, !tbaa !27
  %t540 = getelementptr { i64, ptr }, ptr %t539, i64 0
  %t541 = load { i64, ptr }, ptr %t540, !tbaa !37
  store { i64, ptr } %t541, ptr %l256, !tbaa !27
  store ptr %l2, ptr %l257, !tbaa !29
  %t542 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t544 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t542)
  store { i64, ptr } %t544, ptr %l259
  br label %bb140
bb139:
  br label %bb142
bb140:
  %t545 = load ptr, ptr %l253, !tbaa !29
  %t546 = load ptr, ptr %l254, !tbaa !29
  %t547 = load { i64, ptr }, ptr %l256, !tbaa !27
  %t548 = load ptr, ptr %l257, !tbaa !29
  %t549 = load { i64, ptr }, ptr %l259, !tbaa !27
  %t550 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t545, ptr %t546, { i64, ptr } %t547, ptr %t548, { i64, ptr } %t549)
  store i32 %t550, ptr %l260
  br label %bb141
bb141:
  call void @__olang_scope_close(ptr %s0)
  %t551 = load i32, ptr %l260, !tbaa !23
  store i32 %t551, ptr %rv
  br label %ret
bb142:
  %t552 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d33, i32 0, i32 1) })
  %t553 = extractvalue { i32, { i64, ptr } } %t552, 1
  %t554 = extractvalue { i32, { i64, ptr } } %t552, 0
  store i32 %t554, ptr %l263
  %t555 = icmp ne i32 %t554, 0
  br i1 %t555, label %bb144, label %ok.556, !prof !99
ok.556:
  store { i64, ptr } %t553, ptr %l262
  br label %bb143
bb143:
  %t557 = load { i64, ptr }, ptr %l262, !tbaa !27
  store { i64, ptr } %t557, ptr %l261, !tbaa !27
  br label %bb146
bb144:
  %t558 = load i32, ptr %l263, !tbaa !23
  %t559 = ashr i32 %t558, 16
  %t561 = icmp eq i32 %t559, 1
  store i1 %t561, ptr %l265, !tbaa !21
  br label %bb145
bb145:
  call void @__olang_ert_req_clear()
  %t562 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t562, ptr %l266, !tbaa !27
  %t563 = getelementptr { i64, ptr }, ptr %l266, i32 0, i32 1
  %t564 = load ptr, ptr %t563, !tbaa !27
  %t565 = getelementptr { i64, ptr }, ptr %t564, i64 0
  %t566 = load { i64, ptr }, ptr %t565, !tbaa !37
  %t568 = extractvalue { i64, ptr } %t566, 1
  %t569 = extractvalue { i64, ptr } %t566, 0
  %t570 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t569)
  call void @olang_textcopy(ptr %t570, ptr %t568, i64 %t569)
  %t571 = insertvalue { i64, ptr } undef, i64 %t569, 0
  %t572 = insertvalue { i64, ptr } %t571, ptr %t570, 1
  %t574 = extractvalue { i64, ptr } %t572, 0
  %t575 = extractvalue { i64, ptr } %t572, 1
  %t576 = mul i64 %t574, 1
  %t577 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t576)
  call void @llvm.memcpy.p0.p0.i64(ptr %t577, ptr %t575, i64 %t576, i1 false)
  %t578 = insertvalue { i64, ptr } undef, i64 %t574, 0
  %t579 = insertvalue { i64, ptr } %t578, ptr %t577, 1
  store { i64, ptr } %t579, ptr %l261, !tbaa !27
  br label %bb146
bb146:
  %t581 = load { i64, ptr }, ptr %l261, !tbaa !27
  store ptr %l3, ptr %l270, !tbaa !29
  store { i64, ptr } %t581, ptr %l271, !tbaa !27
  %t583 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 6
  %t585 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t583)
  store { i64, ptr } %t585, ptr %l273
  br label %bb147
bb147:
  %t586 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t586, ptr %l274, !tbaa !27
  %t587 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t589 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t587)
  store { i64, ptr } %t589, ptr %l276
  br label %bb148
bb148:
  %t590 = load ptr, ptr %l270, !tbaa !29
  %t591 = load { i64, ptr }, ptr %l271, !tbaa !27
  %t592 = load { i64, ptr }, ptr %l273, !tbaa !27
  %t593 = load { i64, ptr }, ptr %l274, !tbaa !27
  %t594 = load { i64, ptr }, ptr %l276, !tbaa !27
  %t595 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t590, { i64, ptr } %t591, { i64, ptr } %t592, { i64, ptr } %t593, { i64, ptr } %t594)
  store i32 %t595, ptr %l277
  br label %bb149
bb149:
  call void @__olang_scope_close(ptr %s0)
  %t596 = load i32, ptr %l277, !tbaa !23
  store i32 %t596, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca %"compiler/profile:Profile"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/profile:Places"
  %l25 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, [3 x i64] }
  %l41 = alloca %"compiler/diagmsg:Msg"
  %l43 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i32
  %l74 = alloca i1
  %l80 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca { i64, [3 x i64] }
  %l85 = alloca %"compiler/diagmsg:Msg"
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l101 = alloca %"compiler/profile:Profile"
  %l104 = alloca %"compiler/profile:Profile"
  %l105 = alloca i32
  %l107 = alloca i1
  %l112 = alloca { i64, ptr }
  %l115 = alloca %"compiler/profile:Places"
  %l119 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l130 = alloca i32
  %l132 = alloca i1
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t62 = alloca { i64, [3 x i64] }, align 8
  %t226 = alloca { i64, [3 x i64] }, align 8
  %t331 = alloca %"compiler/profile:Places", align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 21
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 21
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d34, i32 0, i32 1) }, ptr %t14, !tbaa !27
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 20
  store i1 true, ptr %t17, !tbaa !21
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/build:Config", ptr %t18, i32 0, i32 12
  store i1 true, ptr %t20, !tbaa !21
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t29 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t22, { i64, ptr } %t23, ptr %t24)
  store i32 %t29, ptr %l25
  br label %bb1
bb1:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb2, label %bb3
bb2:
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t35, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/build:Config", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d35, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d35, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t52)
  store i32 %t54, ptr %l33
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb6, label %ok.56, !prof !99
ok.56:
  br label %bb5
bb5:
  br label %bb11
bb6:
  %t57 = load i32, ptr %l33, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t64 = load { i64, [3 x i64] }, ptr %t62
  store { i64, [3 x i64] } %t64, ptr %l37
  %t65 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t66 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t69 = extractvalue { i64, ptr } %t65, 1
  %t70 = extractvalue { i64, ptr } %t65, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t66, i64 %t67)
  %t76 = getelementptr i8, ptr %t75, i64 %t67
  call void @olang_textcopy(ptr %t76, ptr %t69, i64 %t70)
  %t77 = getelementptr i8, ptr %t76, i64 %t70
  call void @olang_textcopy(ptr %t77, ptr %t72, i64 %t73)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t75, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s4, ptr %s4, { i64, ptr } %t86)
  store %"compiler/diagmsg:Msg" %t88, ptr %l41
  br label %bb8
bb8:
  %t89 = load ptr, ptr %l36, !tbaa !29
  %t90 = load { i64, [3 x i64] }, ptr %l37
  %t91 = load %"compiler/diagmsg:Msg", ptr %l41
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s4, ptr %t89, { i64, [3 x i64] } %t90, %"compiler/diagmsg:Msg" %t91)
  br label %bb9
bb9:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t92)
  store i32 %t94, ptr %l43
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i32, ptr %l43, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb11:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 22
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %v1, { i64, ptr } %t99)
  store { i64, ptr } %t101, ptr %l46
  br label %bb12
bb12:
  %t102 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t103, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d38, i32 0, i32 1) })
  %t106 = extractvalue { i32, i64 } %t105, 1
  %t107 = extractvalue { i32, i64 } %t105, 0
  store i32 %t107, ptr %l50
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb14, label %ok.109, !prof !99
ok.109:
  store i64 %t106, ptr %l49
  br label %bb13
bb13:
  %t110 = load i64, ptr %l49, !tbaa !24
  store i64 %t110, ptr %l47, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l47, !tbaa !24
  br label %bb16
bb16:
  %t115 = load i64, ptr %l47, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t116, ptr %l53, !tbaa !27
  store i64 %t115, ptr %l54, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l55, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = load i64, ptr %l54, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb19:
  %t125 = load i64, ptr %l54, !tbaa !24
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb21:
  %t129 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l54, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  store { i64, ptr } %t135, ptr %l8, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t137, 1
  %t141 = extractvalue { i64, ptr } %t137, 0
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = extractvalue { i64, ptr } %t138, 1
  %t147 = extractvalue { i64, ptr } %t138, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t142, i64 %t143)
  %t154 = getelementptr i8, ptr %t153, i64 %t143
  call void @olang_textcopy(ptr %t154, ptr %t146, i64 %t147)
  %t155 = getelementptr i8, ptr %t154, i64 %t147
  call void @olang_textcopy(ptr %t155, ptr %t149, i64 %t150)
  %t156 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t152, 1
  store { i64, ptr } %t157, ptr %l10, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t159, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store i1 %t161, ptr %l64
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb23:
  %t162 = load i1, ptr %l64, !tbaa !21
  br i1 %t162, label %bb24, label %bb25
bb24:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = extractvalue { i64, ptr } %t163, 0
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t172 = extractvalue { i64, ptr } %t164, 1
  %t173 = extractvalue { i64, ptr } %t164, 0
  %t174 = add i64 %t170, %t173
  %t175 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t166, i64 %t167)
  %t179 = getelementptr i8, ptr %t178, i64 %t167
  call void @olang_textcopy(ptr %t179, ptr %t168, i64 %t169)
  %t180 = getelementptr i8, ptr %t179, i64 %t169
  call void @olang_textcopy(ptr %t180, ptr %t172, i64 %t173)
  %t181 = getelementptr i8, ptr %t180, i64 %t173
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t178, 1
  store { i64, ptr } %t183, ptr %l67, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l69, !tbaa !24
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = icmp eq i64 %t185, %t189
  br i1 %t190, label %bb26, label %bb27
bb25:
  br label %bb29
bb26:
  %t192 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l69, !tbaa !24
  %t197 = mul i64 %t196, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %t195, i64 %t197, i1 false)
  br label %bb28
bb27:
  %t198 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t198, ptr %l5, !tbaa !27
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t199 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t201 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t199)
  store i32 %t201, ptr %l72
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb31, label %ok.203, !prof !99
ok.203:
  br label %bb30
bb30:
  br label %bb33
bb31:
  %t204 = load i32, ptr %l72, !tbaa !23
  %t205 = ashr i32 %t204, 16
  %t207 = icmp eq i32 %t205, 1
  store i1 %t207, ptr %l74, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  br label %bb33
bb33:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/build:Config", ptr %t208, i32 0, i32 22
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t219 = call i32 @compiler_2fprofile_2erunProfiled(ptr %v1, ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t211, { i64, ptr } %t212, { i64, ptr } %a3, { i64, ptr } %t214)
  store i32 %t219, ptr %l80
  br label %bb34
bb34:
  %t220 = load i32, ptr %l80, !tbaa !23
  store i32 %t220, ptr %l6, !tbaa !23
  %t221 = load i32, ptr %l6, !tbaa !23
  %t223 = icmp slt i32 %t221, 0
  br i1 %t223, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t225 = load ptr, ptr %l4, !tbaa !29
  store ptr %t225, ptr %l83, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 0
  store i64 0, ptr %t227
  %t228 = load { i64, [3 x i64] }, ptr %t226
  store { i64, [3 x i64] } %t228, ptr %l84
  %t229 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s10, ptr %s10, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d44, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t229, ptr %l85
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t230 = load ptr, ptr %l83, !tbaa !29
  %t231 = load { i64, [3 x i64] }, ptr %l84
  %t232 = load %"compiler/diagmsg:Msg", ptr %l85
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %s10, ptr %t230, { i64, [3 x i64] } %t231, %"compiler/diagmsg:Msg" %t232)
  br label %bb38
bb38:
  %t233 = load ptr, ptr %l4, !tbaa !29
  %t235 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t233)
  store i32 %t235, ptr %l87
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t236 = load i32, ptr %l87, !tbaa !23
  store i32 %t236, ptr %rv
  br label %ret
bb40:
  %t237 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t239 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t237)
  %t240 = extractvalue { i32, { i64, ptr } } %t239, 1
  %t241 = extractvalue { i32, { i64, ptr } } %t239, 0
  store i32 %t241, ptr %l91
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb42, label %ok.243, !prof !99
ok.243:
  store { i64, ptr } %t240, ptr %l90
  br label %bb41
bb41:
  %t244 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t244, ptr %l88, !tbaa !27
  br label %bb46
bb42:
  %t245 = load i32, ptr %l91, !tbaa !23
  %t246 = ashr i32 %t245, 16
  %t248 = icmp eq i32 %t246, 1
  store i1 %t248, ptr %l93, !tbaa !21
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t249, ptr %l94, !tbaa !27
  %t250 = load i32, ptr %l6, !tbaa !23
  %t252 = sub i32 %t250, 128
  %t254 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t252)
  store { i64, ptr } %t254, ptr %l97
  br label %bb44
bb44:
  %t255 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t257 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d47, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t255, i64 %t256)
  %t272 = getelementptr i8, ptr %t271, i64 %t256
  call void @olang_textcopy(ptr %t272, ptr %t258, i64 %t259)
  %t273 = getelementptr i8, ptr %t272, i64 %t259
  call void @olang_textcopy(ptr %t273, ptr %t261, i64 %t262)
  %t274 = getelementptr i8, ptr %t273, i64 %t262
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t271, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } %t277, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  call void @compiler_2fprofile_2esay(ptr %s11, { i64, ptr } %t284)
  br label %bb45
bb45:
  %t286 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t286, ptr %rv
  br label %ret
bb46:
  %t288 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t292 = call { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t288)
  %t293 = extractvalue { i32, %"compiler/profile:Profile" } %t292, 1
  %t294 = extractvalue { i32, %"compiler/profile:Profile" } %t292, 0
  store i32 %t294, ptr %l105
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb48, label %ok.296, !prof !99
ok.296:
  store %"compiler/profile:Profile" %t293, ptr %l104
  br label %bb47
bb47:
  %t297 = load %"compiler/profile:Profile", ptr %l104
  store %"compiler/profile:Profile" %t297, ptr %l101
  br label %bb51
bb48:
  %t298 = load i32, ptr %l105, !tbaa !23
  %t299 = ashr i32 %t298, 16
  %t301 = icmp eq i32 %t299, 1
  store i1 %t301, ptr %l107, !tbaa !21
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t303 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d48, i32 0, i32 1) }, 0
  %t306 = extractvalue { i64, ptr } %t302, 1
  %t307 = extractvalue { i64, ptr } %t302, 0
  %t308 = add i64 %t304, %t307
  %t309 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t303, i64 %t304)
  %t313 = getelementptr i8, ptr %t312, i64 %t304
  call void @olang_textcopy(ptr %t313, ptr %t306, i64 %t307)
  %t314 = getelementptr i8, ptr %t313, i64 %t307
  call void @olang_textcopy(ptr %t314, ptr %t309, i64 %t310)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t312, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  call void @compiler_2fprofile_2esay(ptr %s13, { i64, ptr } %t323)
  br label %bb50
bb50:
  %t325 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t325, ptr %rv
  br label %ret
bb51:
  %t327 = load %"compiler/profile:Profile", ptr %l101
  store %"compiler/profile:Profile" %t327, ptr %l12
  %t328 = call { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %s0)
  store { i64, ptr } %t328, ptr %l112
  br label %bb52
bb52:
  %t329 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t329, ptr %l13, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fprofile_2ePlaces_2eResolve(ptr %t331, ptr %s0, ptr %s0, ptr %s0, ptr %l12, { i64, ptr } %t330)
  call void @llvm.memmove.p0.p0.i64(ptr %l115, ptr %t331, i64 272, i1 false)
  br label %bb53
bb53:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l115, i64 272, i1 false)
  %t334 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t338 = call { i64, ptr } @compiler_2fprofile_2eReport(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t334, ptr %l12, ptr %l14)
  store { i64, ptr } %t338, ptr %l119
  br label %bb54
bb54:
  %t339 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t340 = extractvalue { i64, ptr } %t339, 0
  %t341 = extractvalue { i64, ptr } %t339, 1
  %t342 = mul i64 %t340, 1
  %t343 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t342)
  call void @llvm.memcpy.p0.p0.i64(ptr %t343, ptr %t341, i64 %t342, i1 false)
  %t344 = insertvalue { i64, ptr } undef, i64 %t340, 0
  %t345 = insertvalue { i64, ptr } %t344, ptr %t343, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t345)
  br label %bb55
bb55:
  %t347 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t349 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t347, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d50, i32 0, i32 1) })
  store i1 %t349, ptr %l122
  br label %bb56
bb56:
  %t350 = load i1, ptr %l122, !tbaa !21
  br i1 %t350, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s15
  call void @compiler_2fprofile_2esay(ptr %s15, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d51, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s15)
  br label %bb60
bb60:
  %t351 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t351, ptr %l123, !tbaa !27
  %t352 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t356 = call { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t352, ptr %l12, ptr %l14)
  store { i64, ptr } %t356, ptr %l127
  br label %bb61
bb61:
  %t357 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t359 = extractvalue { i64, ptr } %t357, 0
  %t360 = extractvalue { i64, ptr } %t357, 1
  %t361 = mul i64 %t359, 1
  %t362 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t361)
  call void @llvm.memcpy.p0.p0.i64(ptr %t362, ptr %t360, i64 %t361, i1 false)
  %t363 = insertvalue { i64, ptr } undef, i64 %t359, 0
  %t364 = insertvalue { i64, ptr } %t363, ptr %t362, 1
  %t365 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t367 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t365, { i64, ptr } %t364)
  store i32 %t367, ptr %l130
  %t368 = icmp ne i32 %t367, 0
  br i1 %t368, label %bb63, label %ok.369, !prof !99
ok.369:
  br label %bb62
bb62:
  br label %bb66
bb63:
  %t370 = load i32, ptr %l130, !tbaa !23
  %t371 = ashr i32 %t370, 16
  %t373 = icmp eq i32 %t371, 1
  store i1 %t373, ptr %l132, !tbaa !21
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s16
  %t374 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t375 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t376 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t378 = extractvalue { i64, ptr } %t374, 1
  %t379 = extractvalue { i64, ptr } %t374, 0
  %t380 = add i64 %t376, %t379
  %t381 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t382 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t383 = add i64 %t380, %t382
  %t384 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t383)
  call void @olang_textcopy(ptr %t384, ptr %t375, i64 %t376)
  %t385 = getelementptr i8, ptr %t384, i64 %t376
  call void @olang_textcopy(ptr %t385, ptr %t378, i64 %t379)
  %t386 = getelementptr i8, ptr %t385, i64 %t379
  call void @olang_textcopy(ptr %t386, ptr %t381, i64 %t382)
  %t387 = insertvalue { i64, ptr } undef, i64 %t383, 0
  %t388 = insertvalue { i64, ptr } %t387, ptr %t384, 1
  %t390 = extractvalue { i64, ptr } %t388, 0
  %t391 = extractvalue { i64, ptr } %t388, 1
  %t392 = mul i64 %t390, 1
  %t393 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t392)
  call void @llvm.memcpy.p0.p0.i64(ptr %t393, ptr %t391, i64 %t392, i1 false)
  %t394 = insertvalue { i64, ptr } undef, i64 %t390, 0
  %t395 = insertvalue { i64, ptr } %t394, ptr %t393, 1
  call void @compiler_2fprofile_2esay(ptr %s16, { i64, ptr } %t395)
  br label %bb65
bb65:
  %t397 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t397, ptr %rv
  br label %ret
bb66:
  %t399 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t401 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t399)
  store { i64, ptr } %t401, ptr %l138
  br label %bb67
bb67:
  %t402 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t403 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t404 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t405 = extractvalue { i64, ptr } %t404, 1
  %t406 = extractvalue { i64, ptr } %t404, 0
  %t407 = add i64 %t403, %t406
  %t408 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 1
  %t409 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d55, i32 0, i32 1) }, 0
  %t410 = add i64 %t407, %t409
  %t411 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t410)
  call void @olang_textcopy(ptr %t411, ptr %t402, i64 %t403)
  %t412 = getelementptr i8, ptr %t411, i64 %t403
  call void @olang_textcopy(ptr %t412, ptr %t405, i64 %t406)
  %t413 = getelementptr i8, ptr %t412, i64 %t406
  call void @olang_textcopy(ptr %t413, ptr %t408, i64 %t409)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t411, 1
  %t417 = extractvalue { i64, ptr } %t415, 0
  %t418 = extractvalue { i64, ptr } %t415, 1
  %t419 = mul i64 %t417, 1
  %t420 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t419)
  call void @llvm.memcpy.p0.p0.i64(ptr %t420, ptr %t418, i64 %t419, i1 false)
  %t421 = insertvalue { i64, ptr } undef, i64 %t417, 0
  %t422 = insertvalue { i64, ptr } %t421, ptr %t420, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t422)
  br label %bb68
bb68:
  %t424 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t424, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2ePush_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Code" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l16 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eroom_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %t15, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t32 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t34 = getelementptr { i64, ptr }, ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/build:Code", ptr %t35, i64 %t28
  store %"compiler/build:Code" %a1, ptr %t36
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l16, !tbaa !29
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t38, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = add i64 %t40, 1
  %t44 = load ptr, ptr %l16, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  store i64 %t42, ptr %t45, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eroom_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/build:Code", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 56
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/build:Code", ptr %t105, i64 %t102
  %t107 = load %"compiler/build:Code", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/build:Code", ptr %t111, i64 %t109
  store %"compiler/build:Code" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eRef_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/emit:Reused", ptr %t7, i64 %a1
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/explain:Code" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2eAt_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/explain:Code"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/explain:Code", ptr %t7, i64 %a1
  %t9 = load %"compiler/explain:Code", ptr %t8
  store %"compiler/explain:Code" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/explain:Code", ptr %rv
  ret %"compiler/explain:Code" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2eLen_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_ert_req_clear()
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ir" }>, align 8
@.d12 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".asm" }>, align 8
@.d13 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/listing/" }>, align 8
@.d14 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d15 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d16 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d17 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d18 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_test" }>, align 8
@.d19 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d20 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": native compilation failed" }>, align 8
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d22 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d26 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c": the tests ended by a signal (" }>, align 8
@.d27 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d28 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-ir" }>, align 8
@.d31 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d32 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d33 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d34 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d35 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/profile" }>, align 8
@.d36 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"its profile's directory " }>, align 8
@.d37 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot be made" }>, align 8
@.d38 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d40 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".samples" }>, align 8
@.d41 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d42 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d43 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d44 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d45 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d46 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" wrote no profile - it ended by a signal (" }>, align 8
@.d47 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d48 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d49 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is not a profile this compiler writes\0A" }>, align 8
@.d50 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d51 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"olang profile: no llvm-symbolizer found beside clang or on PATH - functions named by their addresses\0A" }>, align 8
@.d52 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d53 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be written\0A" }>, align 8
@.d54 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"flame graph: " }>, align 8
@.d55 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/diagmsg:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_251e830707558b33_b2bdace7e2a71047 = external constant [0 x i8]
declare void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/diagmsg:Msg" %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_ac43697cc5f2dca0_4dfd3d6081b857d4 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, ptr %a6)
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
@olang_loc_44996bcc7c9bda8_515f8c8db8b0565c = external constant [0 x i8]
declare void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i32, %"std/os:Output" } @std_2fos_2eOutput_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare i32 @compiler_2fbuild_2eFinish(ptr %v0, ptr %a0)
@olang_loc_4ce37e8669e18741_b51ffe42b73135c5 = external constant [0 x i8]
declare { i64, ptr } @compiler_2flisting_2ehow(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare { i64, ptr } @compiler_2flisting_2ecommentOf(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/listing:Inputs" @compiler_2flisting_3aInputs_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4)
declare { i64, ptr } @compiler_2flisting_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2flisting_2esay(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eFix = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@G_2ecompiler_2folang_2eBindgen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eApi = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eProfile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2308270aeb54ce5f_1121c256bef46e33 = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0)
declare void @compiler_2fprofile_2ePlaces_2eResolve(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
@olang_loc_42020986585537b2_4c4b240152eb3e56 = external constant [0 x i8]

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
