; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1, i1 }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/prelude/map:Map.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/build:Program"
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i32
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/msgs:Msg"
  %l86 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca i1
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  %t177 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Program", ptr %l7
  store %"compiler/build:Program" %t2, ptr %l4
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t4, i32 1, ptr %t5, ptr %l4, ptr %t6)
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  %t17 = icmp eq i32 %t16, 65536
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  %t20 = icmp eq i32 %t19, 65537
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l18
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t25 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t25, ptr %l19
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l18, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb12:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l21
  br label %bb13
bb13:
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t34 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t34)
  store i64 %t36, ptr %l25
  br label %bb16
bb16:
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i32, ptr %l28, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb21:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t45, ptr %t46)
  store i32 %t49, ptr %l31
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb23, label %ok.51, !prof !99
ok.51:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t52 = load i32, ptr %l31, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  store i1 %t55, ptr %l33, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t56)
  store i32 %t58, ptr %l35
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i32, ptr %l35, !tbaa !23
  store i32 %t59, ptr %rv
  br label %ret
bb26:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t65 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t60, ptr %l4, ptr %t61)
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t65, 1
  %t67 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t65, 0
  store i32 %t67, ptr %l41
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb28, label %ok.69, !prof !99
ok.69:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l40
  br label %bb27
bb27:
  %t70 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l36
  br label %bb31
bb28:
  %t71 = load i32, ptr %l41, !tbaa !23
  %t72 = ashr i32 %t71, 16
  %t74 = icmp eq i32 %t72, 1
  store i1 %t74, ptr %l43, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t75)
  store i32 %t77, ptr %l45
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load i32, ptr %l45, !tbaa !23
  store i32 %t78, ptr %rv
  br label %ret
bb31:
  %t79 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb32
bb32:
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t82 = getelementptr %"compiler/build:Config", ptr %t80, i32 0, i32 9
  %t83 = load i1, ptr %t82, !tbaa !21
  br i1 %t83, label %bb33, label %bb34
bb33:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t93 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v1, ptr %t85, ptr %l4, ptr %l5, { i64, ptr } %t86, ptr %t87)
  store i32 %t93, ptr %l53
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t94 = load i32, ptr %l53, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb36:
  %t95 = load ptr, ptr %l1, !tbaa !29
  %t97 = getelementptr %"compiler/build:Config", ptr %t95, i32 0, i32 18
  %t98 = load { i64, ptr }, ptr %t97, !tbaa !27
  %t100 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t98, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t100, ptr %l56
  br label %bb37
bb37:
  %t101 = load i1, ptr %l56, !tbaa !21
  %t102 = xor i1 %t101, true
  br i1 %t102, label %bb38, label %bb39
bb38:
  %t104 = load ptr, ptr %l1, !tbaa !29
  %t106 = getelementptr %"compiler/build:Config", ptr %t104, i32 0, i32 18
  %t107 = load { i64, ptr }, ptr %t106, !tbaa !27
  %t109 = extractvalue { i64, ptr } %t107, 1
  %t110 = extractvalue { i64, ptr } %t107, 0
  %t111 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t110)
  call void @olang_textcopy(ptr %t111, ptr %t109, i64 %t110)
  %t112 = insertvalue { i64, ptr } undef, i64 %t110, 0
  %t113 = insertvalue { i64, ptr } %t112, ptr %t111, 1
  store { i64, ptr } %t113, ptr %l58, !tbaa !27
  br label %bb43
bb39:
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/build:Config", ptr %t115, i32 0, i32 0
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  store { i64, ptr } %t118, ptr %l63, !tbaa !27
  %t120 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t120, ptr %l65
  br label %bb40
bb40:
  %t121 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t122 = extractvalue { i64, ptr } %t121, 0
  %t123 = extractvalue { i64, ptr } %t121, 1
  %t124 = mul i64 %t122, 1
  %t125 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t124)
  call void @llvm.memcpy.p0.p0.i64(ptr %t125, ptr %t123, i64 %t124, i1 false)
  %t126 = insertvalue { i64, ptr } undef, i64 %t122, 0
  %t127 = insertvalue { i64, ptr } %t126, ptr %t125, 1
  %t129 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t127)
  store { i64, ptr } %t129, ptr %l67
  br label %bb41
bb41:
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t130)
  store { i64, ptr } %t132, ptr %l69
  br label %bb42
bb42:
  %t133 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t138 = add i64 %t135, %t137
  %t139 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t139, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = add i64 %t138, %t141
  %t143 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t144 = extractvalue { i64, ptr } %t143, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = add i64 %t142, %t145
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @olang_textcopy(ptr %t147, ptr %t134, i64 %t135)
  %t148 = getelementptr i8, ptr %t147, i64 %t135
  call void @olang_textcopy(ptr %t148, ptr %t136, i64 %t137)
  %t149 = getelementptr i8, ptr %t148, i64 %t137
  call void @olang_textcopy(ptr %t149, ptr %t140, i64 %t141)
  %t150 = getelementptr i8, ptr %t149, i64 %t141
  call void @olang_textcopy(ptr %t150, ptr %t144, i64 %t145)
  %t151 = insertvalue { i64, ptr } undef, i64 %t146, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t147, 1
  store { i64, ptr } %t152, ptr %l58, !tbaa !27
  br label %bb43
bb43:
  %t154 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t154, ptr %l6, !tbaa !27
  %t155 = load ptr, ptr %l1, !tbaa !29
  store ptr %t155, ptr %l71, !tbaa !29
  store ptr %l5, ptr %l72, !tbaa !29
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t156, ptr %l73, !tbaa !27
  %t157 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 2
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  %t160 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t158, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t160, ptr %l75
  br label %bb44
bb44:
  %t161 = load i1, ptr %l75, !tbaa !21
  %t162 = xor i1 %t161, true
  %t163 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 3
  %t164 = load ptr, ptr %l71, !tbaa !29
  %t165 = load ptr, ptr %l72, !tbaa !29
  %t166 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t169 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t164, ptr %t165, { i64, ptr } %t166, i1 %t162, ptr %t163, ptr null)
  store i32 %t169, ptr %l78
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb46, label %ok.171, !prof !99
ok.171:
  br label %bb45
bb45:
  br label %bb51
bb46:
  %t172 = load i32, ptr %l78, !tbaa !23
  %t173 = ashr i32 %t172, 16
  %t175 = icmp eq i32 %t173, 1
  store i1 %t175, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s9
  %t176 = load ptr, ptr %l3, !tbaa !29
  store ptr %t176, ptr %l81, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t177
  %t178 = getelementptr { i64, [3 x i64] }, ptr %t177, i32 0, i32 0
  store i64 0, ptr %t178
  %t179 = load { i64, [3 x i64] }, ptr %t177
  store { i64, [3 x i64] } %t179, ptr %l82
  %t180 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t182 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s9, { i64, ptr } %t180)
  store %"compiler/msgs:Msg" %t182, ptr %l84
  br label %bb48
bb48:
  %t183 = load ptr, ptr %l81, !tbaa !29
  %t184 = load { i64, [3 x i64] }, ptr %l82
  %t185 = load %"compiler/msgs:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s9, ptr %t183, { i64, [3 x i64] } %t184, %"compiler/msgs:Msg" %t185)
  br label %bb49
bb49:
  %t186 = load ptr, ptr %l3, !tbaa !29
  %t188 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t186)
  store i32 %t188, ptr %l86
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t189 = load i32, ptr %l86, !tbaa !23
  store i32 %t189, ptr %rv
  br label %ret
bb51:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb52
bb52:
  %t190 = load ptr, ptr %l1, !tbaa !29
  %t191 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = extractvalue { i64, ptr } %t191, 0
  %t195 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t194)
  call void @olang_textcopy(ptr %t195, ptr %t193, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t194, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t199 = extractvalue { i64, ptr } %t197, 0
  %t200 = extractvalue { i64, ptr } %t197, 1
  %t201 = mul i64 %t199, 1
  %t202 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t201)
  call void @llvm.memcpy.p0.p0.i64(ptr %t202, ptr %t200, i64 %t201, i1 false)
  %t203 = insertvalue { i64, ptr } undef, i64 %t199, 0
  %t204 = insertvalue { i64, ptr } %t203, ptr %t202, 1
  %t207 = getelementptr %"compiler/build:Config", ptr %t190, i32 0, i32 19
  store { i64, ptr } %t204, ptr %t207, !tbaa !27
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/build:Config", ptr %t208, i32 0, i32 17
  %t211 = load i1, ptr %t210, !tbaa !21
  %t213 = xor i1 %t211, true
  br i1 %t213, label %bb53, label %bb54
bb53:
  store %olang.scope zeroinitializer, ptr %s11
  %t215 = load ptr, ptr %l1, !tbaa !29
  store ptr %t215, ptr %l94, !tbaa !29
  %t216 = load ptr, ptr %l1, !tbaa !29
  %t218 = getelementptr %"compiler/build:Config", ptr %t216, i32 0, i32 18
  %t219 = load { i64, ptr }, ptr %t218, !tbaa !27
  %t221 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s11, { i64, ptr } %t219, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t221, ptr %l97
  br label %bb55
bb54:
  br label %bb62
bb55:
  %t222 = load i1, ptr %l97, !tbaa !21
  %t223 = xor i1 %t222, true
  br i1 %t223, label %bb56, label %bb57
bb56:
  %t225 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t225, ptr %l99, !tbaa !27
  br label %bb59
bb57:
  %t227 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t229 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s11, { i64, ptr } %t227)
  store { i64, ptr } %t229, ptr %l102
  br label %bb58
bb58:
  %t230 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t230, ptr %l99, !tbaa !27
  br label %bb59
bb59:
  %t231 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t232 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t233 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t234 = extractvalue { i64, ptr } %t233, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = add i64 %t232, %t235
  %t237 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t236)
  call void @olang_textcopy(ptr %t237, ptr %t231, i64 %t232)
  %t238 = getelementptr i8, ptr %t237, i64 %t232
  call void @olang_textcopy(ptr %t238, ptr %t234, i64 %t235)
  %t239 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t237, 1
  %t242 = extractvalue { i64, ptr } %t240, 0
  %t243 = extractvalue { i64, ptr } %t240, 1
  %t244 = mul i64 %t242, 1
  %t245 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t244)
  call void @llvm.memcpy.p0.p0.i64(ptr %t245, ptr %t243, i64 %t244, i1 false)
  %t246 = insertvalue { i64, ptr } undef, i64 %t242, 0
  %t247 = insertvalue { i64, ptr } %t246, ptr %t245, 1
  %t248 = load ptr, ptr %l94, !tbaa !29
  %t250 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s11, ptr %s11, ptr %s11, ptr %t248, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } %t247)
  store { i64, ptr } %t250, ptr %l105
  br label %bb60
bb60:
  %t251 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t252 = extractvalue { i64, ptr } %t251, 0
  %t253 = extractvalue { i64, ptr } %t251, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t257)
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s11)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca i1
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i32
  %l68 = alloca i32
  %l70 = alloca i1
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i32
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Program", ptr %l8
  store %"compiler/build:Program" %t2, ptr %l4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t5, ptr %l4, ptr %t6)
  store i32 %t13, ptr %l15
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15, !prof !99
ok.15:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t16 = load i32, ptr %l15, !tbaa !23
  %t17 = icmp eq i32 %t16, 65536
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = icmp eq i32 %t19, 65537
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t25 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t25, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l20, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb12:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i64, ptr %l22, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t34 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb16
bb16:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i32, ptr %l29, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb21:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t45, ptr %t46)
  store i32 %t49, ptr %l32
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb23, label %ok.51, !prof !99
ok.51:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t52 = load i32, ptr %l32, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  store i1 %t55, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  call void @__olang_ert_req_clear()
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t58 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t56)
  store i32 %t58, ptr %l36
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t59 = load i32, ptr %l36, !tbaa !23
  store i32 %t59, ptr %rv
  br label %ret
bb26:
  %t60 = load ptr, ptr %l1, !tbaa !29
  %t61 = load ptr, ptr %l3, !tbaa !29
  %t65 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t60, ptr %l4, ptr %t61)
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t65, 1
  %t67 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t65, 0
  store i32 %t67, ptr %l42
  %t68 = icmp ne i32 %t67, 0
  br i1 %t68, label %bb28, label %ok.69, !prof !99
ok.69:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t66, ptr %l41
  br label %bb27
bb27:
  %t70 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t70, ptr %l37
  br label %bb31
bb28:
  %t71 = load i32, ptr %l42, !tbaa !23
  %t72 = ashr i32 %t71, 16
  %t74 = icmp eq i32 %t72, 1
  store i1 %t74, ptr %l44, !tbaa !21
  br label %bb29
bb29:
  call void @__olang_ert_req_clear()
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t75)
  store i32 %t77, ptr %l46
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t78 = load i32, ptr %l46, !tbaa !23
  store i32 %t78, ptr %rv
  br label %ret
bb31:
  %t79 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t79, ptr %l5
  %t81 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store { i64, ptr } %t81, ptr %l48
  br label %bb32
bb32:
  %t82 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t82, ptr %l6, !tbaa !27
  %t83 = load ptr, ptr %l1, !tbaa !29
  %t85 = getelementptr %"compiler/build:Config", ptr %t83, i32 0, i32 18
  %t86 = load { i64, ptr }, ptr %t85, !tbaa !27
  %t88 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t86, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t88, ptr %l51
  br label %bb33
bb33:
  %t89 = load i1, ptr %l51, !tbaa !21
  %t90 = xor i1 %t89, true
  br i1 %t90, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t92 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t94 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s6, { i64, ptr } %t92)
  %t95 = extractvalue { i32, { i64, ptr } } %t94, 1
  %t96 = extractvalue { i32, { i64, ptr } } %t94, 0
  store i32 %t96, ptr %l56
  %t97 = icmp ne i32 %t96, 0
  br i1 %t97, label %bb37, label %ok.98, !prof !99
ok.98:
  store { i64, ptr } %t95, ptr %l55
  br label %bb36
bb35:
  br label %bb50
bb36:
  %t99 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t99, ptr %l53, !tbaa !27
  br label %bb42
bb37:
  %t100 = load i32, ptr %l56, !tbaa !23
  %t101 = ashr i32 %t100, 16
  %t103 = icmp eq i32 %t101, 1
  store i1 %t103, ptr %l58, !tbaa !21
  br label %bb38
bb38:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s7
  %t104 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t104, ptr %l59, !tbaa !27
  %t105 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s7)
  store %"compiler/msgs:Msg" %t105, ptr %l60
  br label %bb39
bb39:
  %t106 = load ptr, ptr %l3, !tbaa !29
  %t107 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t108 = load %"compiler/msgs:Msg", ptr %l60
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s7, ptr %v1, { i64, ptr } %t107, %"compiler/msgs:Msg" %t108, ptr %t106)
  br label %bb40
bb40:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t112 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t110)
  store i32 %t112, ptr %l63
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t113 = load i32, ptr %l63, !tbaa !23
  store i32 %t113, ptr %rv
  br label %ret
bb42:
  %t114 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t115 = load ptr, ptr %l1, !tbaa !29
  %t117 = getelementptr %"compiler/build:Config", ptr %t115, i32 0, i32 18
  %t118 = load { i64, ptr }, ptr %t117, !tbaa !27
  %t123 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t118, { i64, ptr } %t114)
  store i32 %t123, ptr %l68
  %t124 = icmp ne i32 %t123, 0
  br i1 %t124, label %bb44, label %ok.125, !prof !99
ok.125:
  br label %bb43
bb43:
  br label %bb49
bb44:
  %t126 = load i32, ptr %l68, !tbaa !23
  %t127 = ashr i32 %t126, 16
  %t129 = icmp eq i32 %t127, 1
  store i1 %t129, ptr %l70, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s8
  %t130 = load ptr, ptr %l1, !tbaa !29
  %t132 = getelementptr %"compiler/build:Config", ptr %t130, i32 0, i32 18
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !27
  store { i64, ptr } %t133, ptr %l72, !tbaa !27
  %t134 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s8)
  store %"compiler/msgs:Msg" %t134, ptr %l73
  br label %bb46
bb46:
  %t135 = load ptr, ptr %l3, !tbaa !29
  %t136 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t137 = load %"compiler/msgs:Msg", ptr %l73
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s8, ptr %v1, { i64, ptr } %t136, %"compiler/msgs:Msg" %t137, ptr %t135)
  br label %bb47
bb47:
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t141 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t139)
  store i32 %t141, ptr %l76
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t142 = load i32, ptr %l76, !tbaa !23
  store i32 %t142, ptr %rv
  br label %ret
bb49:
  %t143 = load ptr, ptr %l1, !tbaa !29
  %t145 = getelementptr %"compiler/build:Config", ptr %t143, i32 0, i32 18
  %t146 = load { i64, ptr }, ptr %t145, !tbaa !27
  %t148 = extractvalue { i64, ptr } %t146, 1
  %t149 = extractvalue { i64, ptr } %t146, 0
  %t150 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t149)
  call void @olang_textcopy(ptr %t150, ptr %t148, i64 %t149)
  %t151 = insertvalue { i64, ptr } undef, i64 %t149, 0
  %t152 = insertvalue { i64, ptr } %t151, ptr %t150, 1
  %t154 = extractvalue { i64, ptr } %t152, 0
  %t155 = extractvalue { i64, ptr } %t152, 1
  %t156 = mul i64 %t154, 1
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @llvm.memcpy.p0.p0.i64(ptr %t157, ptr %t155, i64 %t156, i1 false)
  %t158 = insertvalue { i64, ptr } undef, i64 %t154, 0
  %t159 = insertvalue { i64, ptr } %t158, ptr %t157, 1
  store { i64, ptr } %t159, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb50
bb50:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/build:Config", ptr %t161, i32 0, i32 17
  %t164 = load i1, ptr %t163, !tbaa !21
  %t166 = xor i1 %t164, true
  br i1 %t166, label %bb51, label %bb52
bb51:
  store %olang.scope zeroinitializer, ptr %s10
  %t168 = load ptr, ptr %l1, !tbaa !29
  %t169 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t170 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t171 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t173 = extractvalue { i64, ptr } %t169, 1
  %t174 = extractvalue { i64, ptr } %t169, 0
  %t175 = add i64 %t171, %t174
  %t176 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t175)
  call void @olang_textcopy(ptr %t176, ptr %t170, i64 %t171)
  %t177 = getelementptr i8, ptr %t176, i64 %t171
  call void @olang_textcopy(ptr %t177, ptr %t173, i64 %t174)
  %t178 = insertvalue { i64, ptr } undef, i64 %t175, 0
  %t179 = insertvalue { i64, ptr } %t178, ptr %t176, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = extractvalue { i64, ptr } %t179, 1
  %t183 = mul i64 %t181, 1
  %t184 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t183)
  call void @llvm.memcpy.p0.p0.i64(ptr %t184, ptr %t182, i64 %t183, i1 false)
  %t185 = insertvalue { i64, ptr } undef, i64 %t181, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t184, 1
  %t189 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t168, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t186)
  store { i64, ptr } %t189, ptr %l88
  br label %bb53
bb52:
  br label %bb55
bb53:
  %t190 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t191 = extractvalue { i64, ptr } %t190, 0
  %t192 = extractvalue { i64, ptr } %t190, 1
  %t193 = mul i64 %t191, 1
  %t194 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t193)
  call void @llvm.memcpy.p0.p0.i64(ptr %t194, ptr %t192, i64 %t193, i1 false)
  %t195 = insertvalue { i64, ptr } undef, i64 %t191, 0
  %t196 = insertvalue { i64, ptr } %t195, ptr %t194, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t196)
  br label %bb54
bb54:
  call void @__olang_scope_close(ptr %s10)
  br label %bb55
bb55:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l13
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  br label %bb11
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_251e830707558b33_b2bdace7e2a71047)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l18
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t29)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store i32 %t12, ptr %l11
  br label %bb1
bb1:
  %t16 = load i32, ptr %l11, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb11
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l17
  br label %bb10
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load i32, ptr %l5, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l31 = alloca i1
  %l33 = alloca i32
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca ptr
  %l95 = alloca { i64, [3 x i64] }
  %l96 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i32
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t205 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 17
  store i1 true, ptr %t3, !tbaa !21
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t5, { i64, ptr } %t6, ptr %t7)
  store i32 %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load i32, ptr %l21, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  %t14 = load i32, ptr %l5, !tbaa !23
  %t16 = icmp ne i32 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v1, ptr %s0, ptr %t20, ptr %t21)
  %t25 = extractvalue { i32, { i64, ptr } } %t24, 1
  %t26 = extractvalue { i32, { i64, ptr } } %t24, 0
  store i32 %t26, ptr %l29
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb6, label %ok.28, !prof !99
ok.28:
  store { i64, ptr } %t25, ptr %l28
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  br label %bb9
bb6:
  %t30 = load i32, ptr %l29, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  store i1 %t33, ptr %l31, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  %t34 = load ptr, ptr %l4, !tbaa !29
  %t36 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t34)
  store i32 %t36, ptr %l33
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t37 = load i32, ptr %l33, !tbaa !23
  store i32 %t37, ptr %rv
  br label %ret
bb9:
  %t38 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t38, ptr %l6, !tbaa !27
  %t39 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t39, ptr %l34
  br label %bb10
bb10:
  %t40 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l7
  %t41 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t41, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t43 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t45 = extractvalue { i64, ptr } %t43, 0
  store i64 %t45, ptr %l10, !tbaa !24
  br label %bb11
bb11:
  %t47 = load i64, ptr %l9, !tbaa !24
  %t48 = load i64, ptr %l10, !tbaa !24
  %t51 = icmp slt i64 %t47, %t48
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb12, label %bb13
bb12:
  br label %bb17
bb13:
  br label %bb14
bb14:
  %t55 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t55, ptr %l42, !tbaa !27
  %t56 = load i64, ptr %l9, !tbaa !24
  %t58 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t59 = load ptr, ptr %t58, !tbaa !27
  %t60 = getelementptr { i64, ptr }, ptr %t59, i64 %t56
  %t61 = load { i64, ptr }, ptr %t60, !tbaa !37
  %t65 = extractvalue { i64, ptr } %t61, 1
  %t66 = extractvalue { i64, ptr } %t61, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t76)
  br label %bb15
bb15:
  br label %bb16
bb16:
  %t79 = load i64, ptr %l9, !tbaa !24
  %t81 = add i64 %t79, 1
  store i64 %t81, ptr %l9, !tbaa !24
  br label %bb11
bb17:
  store ptr %l7, ptr %l51, !tbaa !29
  %t83 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t85 = extractvalue { i64, ptr } %t83, 0
  %t87 = icmp eq i64 %t85, 0
  br i1 %t87, label %bb18, label %bb19
bb18:
  %t89 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t91 = extractvalue { i64, ptr } %t89, 1
  %t92 = extractvalue { i64, ptr } %t89, 0
  %t93 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t92)
  call void @olang_textcopy(ptr %t93, ptr %t91, i64 %t92)
  %t94 = insertvalue { i64, ptr } undef, i64 %t92, 0
  %t95 = insertvalue { i64, ptr } %t94, ptr %t93, 1
  store { i64, ptr } %t95, ptr %l55, !tbaa !27
  br label %bb21
bb19:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Config", ptr %t97, i32 0, i32 19
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t100)
  store { i64, ptr } %t102, ptr %l60
  br label %bb20
bb20:
  %t103 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t103, ptr %l55, !tbaa !27
  br label %bb21
bb21:
  %t104 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  %t106 = extractvalue { i64, ptr } %t104, 1
  %t107 = mul i64 %t105, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t107)
  call void @llvm.memcpy.p0.p0.i64(ptr %t108, ptr %t106, i64 %t107, i1 false)
  %t109 = insertvalue { i64, ptr } undef, i64 %t105, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  %t111 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t111, { i64, ptr } %t110)
  br label %bb22
bb22:
  store { i64, ptr } %a3, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t115 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t115, 0
  store i64 %t117, ptr %l14, !tbaa !24
  br label %bb23
bb23:
  %t119 = load i64, ptr %l13, !tbaa !24
  %t120 = load i64, ptr %l14, !tbaa !24
  %t123 = icmp slt i64 %t119, %t120
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb24, label %bb25
bb24:
  br label %bb29
bb25:
  br label %bb26
bb26:
  %t127 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t127, ptr %l69, !tbaa !27
  %t128 = load i64, ptr %l13, !tbaa !24
  %t130 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %t131, i64 %t128
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !37
  %t137 = extractvalue { i64, ptr } %t133, 1
  %t138 = extractvalue { i64, ptr } %t133, 0
  %t139 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t138)
  call void @olang_textcopy(ptr %t139, ptr %t137, i64 %t138)
  %t140 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t141 = insertvalue { i64, ptr } %t140, ptr %t139, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = extractvalue { i64, ptr } %t141, 1
  %t145 = mul i64 %t143, 1
  %t146 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t145)
  call void @llvm.memcpy.p0.p0.i64(ptr %t146, ptr %t144, i64 %t145, i1 false)
  %t147 = insertvalue { i64, ptr } undef, i64 %t143, 0
  %t148 = insertvalue { i64, ptr } %t147, ptr %t146, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t148)
  br label %bb27
bb27:
  br label %bb28
bb28:
  %t151 = load i64, ptr %l13, !tbaa !24
  %t153 = add i64 %t151, 1
  store i64 %t153, ptr %l13, !tbaa !24
  br label %bb23
bb29:
  %t155 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t159 = icmp eq i64 %t157, 0
  br i1 %t159, label %bb30, label %bb31
bb30:
  %t161 = load ptr, ptr %l1, !tbaa !29
  %t163 = getelementptr %"compiler/build:Config", ptr %t161, i32 0, i32 19
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t166 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t164)
  store { i64, ptr } %t166, ptr %l84
  br label %bb32
bb31:
  %t167 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t168 = load ptr, ptr %t167, !tbaa !27
  %t169 = getelementptr { i64, ptr }, ptr %t168, i64 0
  %t170 = load { i64, ptr }, ptr %t169, !tbaa !37
  %t172 = extractvalue { i64, ptr } %t170, 1
  %t173 = extractvalue { i64, ptr } %t170, 0
  %t174 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t173)
  call void @olang_textcopy(ptr %t174, ptr %t172, i64 %t173)
  %t175 = insertvalue { i64, ptr } undef, i64 %t173, 0
  %t176 = insertvalue { i64, ptr } %t175, ptr %t174, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = extractvalue { i64, ptr } %t176, 1
  %t180 = mul i64 %t178, 1
  %t181 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t180)
  call void @llvm.memcpy.p0.p0.i64(ptr %t181, ptr %t179, i64 %t180, i1 false)
  %t182 = insertvalue { i64, ptr } undef, i64 %t178, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t181, 1
  store { i64, ptr } %t183, ptr %l81, !tbaa !27
  br label %bb33
bb32:
  %t185 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t186 = extractvalue { i64, ptr } %t185, 0
  %t187 = extractvalue { i64, ptr } %t185, 1
  %t188 = mul i64 %t186, 1
  %t189 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t188)
  call void @llvm.memcpy.p0.p0.i64(ptr %t189, ptr %t187, i64 %t188, i1 false)
  %t190 = insertvalue { i64, ptr } undef, i64 %t186, 0
  %t191 = insertvalue { i64, ptr } %t190, ptr %t189, 1
  store { i64, ptr } %t191, ptr %l81, !tbaa !27
  br label %bb33
bb33:
  %t194 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t194, ptr %l90
  br label %bb34
bb34:
  %t195 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t196 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t197 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t195, { i64, ptr } %t196)
  store i32 %t197, ptr %l91
  %t198 = icmp ne i32 %t197, 0
  br i1 %t198, label %bb36, label %ok.199, !prof !99
ok.199:
  br label %bb35
bb35:
  br label %bb41
bb36:
  %t200 = load i32, ptr %l91, !tbaa !23
  %t201 = ashr i32 %t200, 16
  %t203 = icmp eq i32 %t201, 1
  store i1 %t203, ptr %l93, !tbaa !21
  br label %bb37
bb37:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t204 = load ptr, ptr %l4, !tbaa !29
  store ptr %t204, ptr %l94, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t205
  %t206 = getelementptr { i64, [3 x i64] }, ptr %t205, i32 0, i32 0
  store i64 0, ptr %t206
  %t207 = load { i64, [3 x i64] }, ptr %t205
  store { i64, [3 x i64] } %t207, ptr %l95
  %t208 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s13, ptr %s13, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t208, ptr %l96
  br label %bb38
bb38:
  %t209 = load ptr, ptr %l94, !tbaa !29
  %t210 = load { i64, [3 x i64] }, ptr %l95
  %t211 = load %"compiler/msgs:Msg", ptr %l96
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s13, ptr %t209, { i64, [3 x i64] } %t210, %"compiler/msgs:Msg" %t211)
  br label %bb39
bb39:
  %t212 = load ptr, ptr %l4, !tbaa !29
  %t214 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t212)
  store i32 %t214, ptr %l98
  br label %bb40
bb40:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t215 = load i32, ptr %l98, !tbaa !23
  store i32 %t215, ptr %rv
  br label %ret
bb41:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:FileInfo"
  %l6 = alloca %"compiler/build:Program"
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca { i64, ptr }
  %l10 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l11 = alloca { i64, ptr }
  %l12 = alloca i64
  %l13 = alloca i64
  %l15 = alloca { i64, ptr }
  %l16 = alloca i64
  %l17 = alloca i64
  %l19 = alloca %"std/os:Output"
  %l20 = alloca %"std/os:FileInfo"
  %l22 = alloca %"std/os:FileInfo"
  %l23 = alloca i32
  %l25 = alloca i1
  %l26 = alloca ptr
  %l27 = alloca { i64, ptr }
  %l28 = alloca %"compiler/msgs:Msg"
  %l30 = alloca i32
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l35 = alloca %"compiler/msgs:Msg"
  %l37 = alloca i32
  %l41 = alloca ptr
  %l42 = alloca { i64, ptr }
  %l43 = alloca %"compiler/msgs:Msg"
  %l45 = alloca i32
  %l46 = alloca %"compiler/build:Program"
  %l53 = alloca i32
  %l59 = alloca i32
  %l60 = alloca i32
  %l62 = alloca i64
  %l64 = alloca i1
  %l66 = alloca i64
  %l71 = alloca i32
  %l74 = alloca i32
  %l76 = alloca i1
  %l78 = alloca i32
  %l79 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l83 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l84 = alloca i32
  %l86 = alloca i1
  %l88 = alloca i32
  %l90 = alloca { i64, ptr }
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca ptr
  %l99 = alloca ptr
  %l100 = alloca { i64, ptr }
  %l102 = alloca i1
  %l105 = alloca i32
  %l107 = alloca i1
  %l112 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i32
  %l130 = alloca i1
  %l132 = alloca i32
  %l133 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l141 = alloca { i64, ptr }
  %l150 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l156 = alloca i1
  %l161 = alloca i32
  %l169 = alloca { i64, ptr }
  %l178 = alloca %"std/os:Output"
  %l180 = alloca { i64, ptr }
  %l181 = alloca { i64, ptr }
  %l182 = alloca %"std/os:Output"
  %l183 = alloca i32
  %l185 = alloca i1
  %l189 = alloca ptr
  %l190 = alloca { i64, ptr }
  %l193 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l200 = alloca i1
  %l207 = alloca { i64, ptr }
  %l212 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s25 = alloca %olang.scope
  %s27 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l23
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l22
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l22
  store %"std/os:FileInfo" %t8, ptr %l20
  br label %bb6
bb2:
  %t9 = load i32, ptr %l23, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l25, !tbaa !21
  br label %bb3
bb3:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t13 = load ptr, ptr %l1, !tbaa !29
  store ptr %t13, ptr %l26, !tbaa !29
  %t14 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t14, ptr %l27, !tbaa !27
  %t15 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t15, ptr %l28
  br label %bb4
bb4:
  %t16 = load ptr, ptr %l3, !tbaa !29
  %t17 = load ptr, ptr %l26, !tbaa !29
  %t18 = load { i64, ptr }, ptr %l27, !tbaa !27
  %t19 = load %"compiler/msgs:Msg", ptr %l28
  %t21 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s1, ptr %v1, ptr %t17, { i64, ptr } %t18, %"compiler/msgs:Msg" %t19, ptr %t16)
  store i32 %t21, ptr %l30
  br label %bb5
bb5:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t22 = load i32, ptr %l30, !tbaa !23
  store i32 %t22, ptr %rv
  br label %ret
bb6:
  %t23 = load %"std/os:FileInfo", ptr %l20
  store %"std/os:FileInfo" %t23, ptr %l5
  %t24 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t25 = load i32, ptr %t24, !range !{i32 0, i32 3}
  %t27 = trunc i64 1 to i32
  %t28 = icmp eq i32 %t25, %t27
  br i1 %t28, label %bb7, label %bb8
bb7:
  store %olang.scope zeroinitializer, ptr %s2
  %t30 = load ptr, ptr %l1, !tbaa !29
  store ptr %t30, ptr %l33, !tbaa !29
  %t31 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t31, ptr %l34, !tbaa !27
  %t32 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s2)
  store %"compiler/msgs:Msg" %t32, ptr %l35
  br label %bb9
bb8:
  br label %bb11
bb9:
  %t33 = load ptr, ptr %l3, !tbaa !29
  %t34 = load ptr, ptr %l33, !tbaa !29
  %t35 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t36 = load %"compiler/msgs:Msg", ptr %l35
  %t38 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s2, ptr %v1, ptr %t34, { i64, ptr } %t35, %"compiler/msgs:Msg" %t36, ptr %t33)
  store i32 %t38, ptr %l37
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l37, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t41 = load i32, ptr %t40, !range !{i32 0, i32 3}
  %t43 = trunc i64 0 to i32
  %t44 = icmp eq i32 %t41, %t43
  %t46 = xor i1 %t44, true
  br i1 %t46, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t48 = load ptr, ptr %l1, !tbaa !29
  store ptr %t48, ptr %l41, !tbaa !29
  %t49 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t49, ptr %l42, !tbaa !27
  %t50 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %s3)
  store %"compiler/msgs:Msg" %t50, ptr %l43
  br label %bb14
bb13:
  br label %bb16
bb14:
  %t51 = load ptr, ptr %l3, !tbaa !29
  %t52 = load ptr, ptr %l41, !tbaa !29
  %t53 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t54 = load %"compiler/msgs:Msg", ptr %l43
  %t56 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s3, ptr %v1, ptr %t52, { i64, ptr } %t53, %"compiler/msgs:Msg" %t54, ptr %t51)
  store i32 %t56, ptr %l45
  br label %bb15
bb15:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t57 = load i32, ptr %l45, !tbaa !23
  store i32 %t57, ptr %rv
  br label %ret
bb16:
  %t58 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t58, ptr %l46
  br label %bb17
bb17:
  %t59 = load %"compiler/build:Program", ptr %l46
  store %"compiler/build:Program" %t59, ptr %l6
  %t61 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t62 = load ptr, ptr %l1, !tbaa !29
  %t63 = load ptr, ptr %l3, !tbaa !29
  %t70 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t61, i32 2, ptr %t62, ptr %l6, ptr %t63)
  store i32 %t70, ptr %l53
  %t71 = icmp ne i32 %t70, 0
  br i1 %t71, label %bb19, label %ok.72, !prof !99
ok.72:
  br label %bb18
bb18:
  br label %bb28
bb19:
  %t73 = load i32, ptr %l53, !tbaa !23
  %t74 = icmp eq i32 %t73, 65536
  br i1 %t74, label %bb20, label %bb21
bb20:
  br label %bb22
bb21:
  %t76 = load i32, ptr %l53, !tbaa !23
  %t77 = icmp eq i32 %t76, 65537
  br i1 %t77, label %bb23, label %bb24
bb22:
  call void @__olang_ert_req_clear()
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t80 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t81 = load ptr, ptr %l3, !tbaa !29
  %t85 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t79, { i64, ptr } %t80, ptr %t81)
  store i32 %t85, ptr %l59
  br label %bb26
bb23:
  br label %bb25
bb24:
  call void @__olang_check_failed(ptr @olang_loc_44996bcc7c9bda8_515f8c8db8b0565c)
  unreachable
bb25:
  call void @__olang_ert_req_clear()
  %t86 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t86, ptr %l60
  br label %bb27
bb26:
  call void @__olang_scope_close(ptr %s0)
  %t87 = load i32, ptr %l59, !tbaa !23
  store i32 %t87, ptr %rv
  br label %ret
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i32, ptr %l60, !tbaa !23
  store i32 %t88, ptr %rv
  br label %ret
bb28:
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t91 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t89)
  store i64 %t91, ptr %l62
  br label %bb29
bb29:
  %t92 = load i64, ptr %l62, !tbaa !24
  %t93 = icmp sgt i64 %t92, 0
  br i1 %t93, label %bb30, label %bb31
bb30:
  store i1 true, ptr %l64, !tbaa !21
  br label %bb33
bb31:
  %t95 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 0
  %t97 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t95)
  store i64 %t97, ptr %l66
  br label %bb32
bb32:
  %t98 = load i64, ptr %l66, !tbaa !24
  %t99 = icmp eq i64 %t98, 0
  store i1 %t99, ptr %l64, !tbaa !21
  br label %bb33
bb33:
  %t101 = load i1, ptr %l64, !tbaa !21
  br i1 %t101, label %bb34, label %bb35
bb34:
  %t102 = load ptr, ptr %l1, !tbaa !29
  %t103 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t104 = load ptr, ptr %l3, !tbaa !29
  %t108 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t102, { i64, ptr } %t103, ptr %t104)
  store i32 %t108, ptr %l71
  br label %bb36
bb35:
  br label %bb37
bb36:
  call void @__olang_scope_close(ptr %s0)
  %t109 = load i32, ptr %l71, !tbaa !23
  store i32 %t109, ptr %rv
  br label %ret
bb37:
  %t110 = load ptr, ptr %l1, !tbaa !29
  %t111 = load ptr, ptr %l3, !tbaa !29
  %t114 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t110, ptr %t111)
  store i32 %t114, ptr %l74
  %t115 = icmp ne i32 %t114, 0
  br i1 %t115, label %bb39, label %ok.116, !prof !99
ok.116:
  br label %bb38
bb38:
  br label %bb42
bb39:
  %t117 = load i32, ptr %l74, !tbaa !23
  %t118 = ashr i32 %t117, 16
  %t120 = icmp eq i32 %t118, 1
  store i1 %t120, ptr %l76, !tbaa !21
  br label %bb40
bb40:
  call void @__olang_ert_req_clear()
  %t121 = load ptr, ptr %l3, !tbaa !29
  %t123 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t121)
  store i32 %t123, ptr %l78
  br label %bb41
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t124 = load i32, ptr %l78, !tbaa !23
  store i32 %t124, ptr %rv
  br label %ret
bb42:
  %t125 = load ptr, ptr %l1, !tbaa !29
  %t126 = load ptr, ptr %l3, !tbaa !29
  %t130 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t125, ptr %l6, ptr %t126)
  %t131 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t130, 1
  %t132 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t130, 0
  store i32 %t132, ptr %l84
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb44, label %ok.134, !prof !99
ok.134:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t131, ptr %l83
  br label %bb43
bb43:
  %t135 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l83
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t135, ptr %l79
  br label %bb47
bb44:
  %t136 = load i32, ptr %l84, !tbaa !23
  %t137 = ashr i32 %t136, 16
  %t139 = icmp eq i32 %t137, 1
  store i1 %t139, ptr %l86, !tbaa !21
  br label %bb45
bb45:
  call void @__olang_ert_req_clear()
  %t140 = load ptr, ptr %l3, !tbaa !29
  %t142 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t140)
  store i32 %t142, ptr %l88
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s0)
  %t143 = load i32, ptr %l88, !tbaa !23
  store i32 %t143, ptr %rv
  br label %ret
bb47:
  %t144 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l79
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t144, ptr %l7
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb48
bb48:
  %t145 = load ptr, ptr %l1, !tbaa !29
  %t147 = getelementptr %"compiler/build:Config", ptr %t145, i32 0, i32 0
  %t148 = load { i64, ptr }, ptr %t147, !tbaa !27
  store { i64, ptr } %t148, ptr %l90, !tbaa !27
  %t150 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t150, ptr %l92
  br label %bb49
bb49:
  %t151 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t151, 0
  %t153 = extractvalue { i64, ptr } %t151, 1
  %t154 = mul i64 %t152, 1
  %t155 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t154)
  call void @llvm.memcpy.p0.p0.i64(ptr %t155, ptr %t153, i64 %t154, i1 false)
  %t156 = insertvalue { i64, ptr } undef, i64 %t152, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t155, 1
  %t159 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t157)
  store { i64, ptr } %t159, ptr %l94
  br label %bb50
bb50:
  %t160 = load ptr, ptr %l1, !tbaa !29
  %t162 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t160)
  store { i64, ptr } %t162, ptr %l96
  br label %bb51
bb51:
  %t163 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t164 = extractvalue { i64, ptr } %t163, 1
  %t165 = extractvalue { i64, ptr } %t163, 0
  %t166 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t168 = add i64 %t165, %t167
  %t169 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t170 = extractvalue { i64, ptr } %t169, 1
  %t171 = extractvalue { i64, ptr } %t169, 0
  %t172 = add i64 %t168, %t171
  %t173 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t176 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t177 = extractvalue { i64, ptr } %t176, 1
  %t178 = extractvalue { i64, ptr } %t176, 0
  %t179 = add i64 %t175, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t164, i64 %t165)
  %t181 = getelementptr i8, ptr %t180, i64 %t165
  call void @olang_textcopy(ptr %t181, ptr %t166, i64 %t167)
  %t182 = getelementptr i8, ptr %t181, i64 %t167
  call void @olang_textcopy(ptr %t182, ptr %t170, i64 %t171)
  %t183 = getelementptr i8, ptr %t182, i64 %t171
  call void @olang_textcopy(ptr %t183, ptr %t173, i64 %t174)
  %t184 = getelementptr i8, ptr %t183, i64 %t174
  call void @olang_textcopy(ptr %t184, ptr %t177, i64 %t178)
  %t185 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t186 = insertvalue { i64, ptr } %t185, ptr %t180, 1
  store { i64, ptr } %t186, ptr %l8, !tbaa !27
  %t188 = load ptr, ptr %l1, !tbaa !29
  store ptr %t188, ptr %l98, !tbaa !29
  store ptr %l7, ptr %l99, !tbaa !29
  %t189 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t189, ptr %l100, !tbaa !27
  %t190 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 2
  %t191 = load { i64, ptr }, ptr %t190, !tbaa !27
  %t193 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t191, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t193, ptr %l102
  br label %bb52
bb52:
  %t194 = load i1, ptr %l102, !tbaa !21
  %t195 = xor i1 %t194, true
  %t196 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 3
  %t197 = load ptr, ptr %l98, !tbaa !29
  %t198 = load ptr, ptr %l99, !tbaa !29
  %t199 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t202 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t197, ptr %t198, { i64, ptr } %t199, i1 %t195, ptr %t196, ptr null)
  store i32 %t202, ptr %l105
  %t203 = icmp ne i32 %t202, 0
  br i1 %t203, label %bb54, label %ok.204, !prof !99
ok.204:
  br label %bb53
bb53:
  br label %bb58
bb54:
  %t205 = load i32, ptr %l105, !tbaa !23
  %t206 = ashr i32 %t205, 16
  %t208 = icmp eq i32 %t206, 1
  store i1 %t208, ptr %l107, !tbaa !21
  br label %bb55
bb55:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s10
  %t209 = load ptr, ptr %l1, !tbaa !29
  %t210 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t212 = extractvalue { i64, ptr } %t210, 1
  %t213 = extractvalue { i64, ptr } %t210, 0
  %t214 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t215 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t216 = add i64 %t213, %t215
  %t217 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t216)
  call void @olang_textcopy(ptr %t217, ptr %t212, i64 %t213)
  %t218 = getelementptr i8, ptr %t217, i64 %t213
  call void @olang_textcopy(ptr %t218, ptr %t214, i64 %t215)
  %t219 = insertvalue { i64, ptr } undef, i64 %t216, 0
  %t220 = insertvalue { i64, ptr } %t219, ptr %t217, 1
  %t222 = extractvalue { i64, ptr } %t220, 0
  %t223 = extractvalue { i64, ptr } %t220, 1
  %t224 = mul i64 %t222, 1
  %t225 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t224)
  call void @llvm.memcpy.p0.p0.i64(ptr %t225, ptr %t223, i64 %t224, i1 false)
  %t226 = insertvalue { i64, ptr } undef, i64 %t222, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  %t230 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t209, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, { i64, ptr } %t227)
  store { i64, ptr } %t230, ptr %l112
  br label %bb56
bb56:
  %t231 = load { i64, ptr }, ptr %l112, !tbaa !27
  %t232 = extractvalue { i64, ptr } %t231, 0
  %t233 = extractvalue { i64, ptr } %t231, 1
  %t234 = mul i64 %t232, 1
  %t235 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t234)
  call void @llvm.memcpy.p0.p0.i64(ptr %t235, ptr %t233, i64 %t234, i1 false)
  %t236 = insertvalue { i64, ptr } undef, i64 %t232, 0
  %t237 = insertvalue { i64, ptr } %t236, ptr %t235, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t237)
  br label %bb57
bb57:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb58:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb59
bb59:
  %t240 = load ptr, ptr %l1, !tbaa !29
  %t242 = getelementptr %"compiler/build:Config", ptr %t240, i32 0, i32 17
  %t243 = load i1, ptr %t242, !tbaa !21
  %t245 = xor i1 %t243, true
  br i1 %t245, label %bb60, label %bb61
bb60:
  store %olang.scope zeroinitializer, ptr %s12
  %t247 = load ptr, ptr %l1, !tbaa !29
  %t248 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t249 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t250 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t252 = extractvalue { i64, ptr } %t248, 1
  %t253 = extractvalue { i64, ptr } %t248, 0
  %t254 = add i64 %t250, %t253
  %t255 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t257 = add i64 %t254, %t256
  %t258 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t257)
  call void @olang_textcopy(ptr %t258, ptr %t249, i64 %t250)
  %t259 = getelementptr i8, ptr %t258, i64 %t250
  call void @olang_textcopy(ptr %t259, ptr %t252, i64 %t253)
  %t260 = getelementptr i8, ptr %t259, i64 %t253
  call void @olang_textcopy(ptr %t260, ptr %t255, i64 %t256)
  %t261 = insertvalue { i64, ptr } undef, i64 %t257, 0
  %t262 = insertvalue { i64, ptr } %t261, ptr %t258, 1
  %t264 = extractvalue { i64, ptr } %t262, 0
  %t265 = extractvalue { i64, ptr } %t262, 1
  %t266 = mul i64 %t264, 1
  %t267 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t266)
  call void @llvm.memcpy.p0.p0.i64(ptr %t267, ptr %t265, i64 %t266, i1 false)
  %t268 = insertvalue { i64, ptr } undef, i64 %t264, 0
  %t269 = insertvalue { i64, ptr } %t268, ptr %t267, 1
  %t272 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s12, ptr %s12, ptr %s12, ptr %t247, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } %t269)
  store { i64, ptr } %t272, ptr %l122
  br label %bb62
bb61:
  br label %bb64
bb62:
  %t273 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 0
  %t275 = extractvalue { i64, ptr } %t273, 1
  %t276 = mul i64 %t274, 1
  %t277 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t276)
  call void @llvm.memcpy.p0.p0.i64(ptr %t277, ptr %t275, i64 %t276, i1 false)
  %t278 = insertvalue { i64, ptr } undef, i64 %t274, 0
  %t279 = insertvalue { i64, ptr } %t278, ptr %t277, 1
  call void @compiler_2fbuild_2esayln(ptr %s12, { i64, ptr } %t279)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s12)
  br label %bb64
bb64:
  %t281 = load ptr, ptr %l1, !tbaa !29
  %t282 = load ptr, ptr %l3, !tbaa !29
  %t285 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v1, ptr %s0, ptr %t281, ptr %t282)
  %t286 = extractvalue { i32, { i64, ptr } } %t285, 1
  %t287 = extractvalue { i32, { i64, ptr } } %t285, 0
  store i32 %t287, ptr %l128
  %t288 = icmp ne i32 %t287, 0
  br i1 %t288, label %bb66, label %ok.289, !prof !99
ok.289:
  store { i64, ptr } %t286, ptr %l127
  br label %bb65
bb65:
  %t290 = load { i64, ptr }, ptr %l127, !tbaa !27
  store { i64, ptr } %t290, ptr %l124, !tbaa !27
  br label %bb69
bb66:
  %t291 = load i32, ptr %l128, !tbaa !23
  %t292 = ashr i32 %t291, 16
  %t294 = icmp eq i32 %t292, 1
  store i1 %t294, ptr %l130, !tbaa !21
  br label %bb67
bb67:
  call void @__olang_ert_req_clear()
  %t295 = load ptr, ptr %l3, !tbaa !29
  %t297 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t295)
  store i32 %t297, ptr %l132
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t298 = load i32, ptr %l132, !tbaa !23
  store i32 %t298, ptr %rv
  br label %ret
bb69:
  %t299 = load { i64, ptr }, ptr %l124, !tbaa !27
  store { i64, ptr } %t299, ptr %l9, !tbaa !27
  %t300 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t300, ptr %l133
  br label %bb70
bb70:
  %t301 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l133
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t301, ptr %l10
  %t302 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t302, ptr %l11, !tbaa !27
  store i64 0, ptr %l12, !tbaa !24
  %t304 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t306 = extractvalue { i64, ptr } %t304, 0
  store i64 %t306, ptr %l13, !tbaa !24
  br label %bb71
bb71:
  %t308 = load i64, ptr %l12, !tbaa !24
  %t309 = load i64, ptr %l13, !tbaa !24
  %t312 = icmp slt i64 %t308, %t309
  %t314 = xor i1 %t312, true
  br i1 %t314, label %bb72, label %bb73
bb72:
  br label %bb77
bb73:
  br label %bb74
bb74:
  %t316 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t316, ptr %l141, !tbaa !27
  %t317 = load i64, ptr %l12, !tbaa !24
  %t319 = getelementptr { i64, ptr }, ptr %l141, i32 0, i32 1
  %t320 = load ptr, ptr %t319, !tbaa !27
  %t321 = getelementptr { i64, ptr }, ptr %t320, i64 %t317
  %t322 = load { i64, ptr }, ptr %t321, !tbaa !37
  %t326 = extractvalue { i64, ptr } %t322, 1
  %t327 = extractvalue { i64, ptr } %t322, 0
  %t328 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t327)
  call void @olang_textcopy(ptr %t328, ptr %t326, i64 %t327)
  %t329 = insertvalue { i64, ptr } undef, i64 %t327, 0
  %t330 = insertvalue { i64, ptr } %t329, ptr %t328, 1
  %t332 = extractvalue { i64, ptr } %t330, 0
  %t333 = extractvalue { i64, ptr } %t330, 1
  %t334 = mul i64 %t332, 1
  %t335 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t334)
  call void @llvm.memcpy.p0.p0.i64(ptr %t335, ptr %t333, i64 %t334, i1 false)
  %t336 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t337 = insertvalue { i64, ptr } %t336, ptr %t335, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t337)
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t340 = load i64, ptr %l12, !tbaa !24
  %t342 = add i64 %t340, 1
  store i64 %t342, ptr %l12, !tbaa !24
  br label %bb71
bb77:
  store ptr %l10, ptr %l150, !tbaa !29
  %t344 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t346 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t344)
  store { i64, ptr } %t346, ptr %l152
  br label %bb78
bb78:
  %t347 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t348 = extractvalue { i64, ptr } %t347, 0
  %t349 = extractvalue { i64, ptr } %t347, 1
  %t350 = mul i64 %t348, 1
  %t351 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t350)
  call void @llvm.memcpy.p0.p0.i64(ptr %t351, ptr %t349, i64 %t350, i1 false)
  %t352 = insertvalue { i64, ptr } undef, i64 %t348, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  %t354 = load ptr, ptr %l150, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t354, { i64, ptr } %t353)
  br label %bb79
bb79:
  %t356 = load ptr, ptr %l1, !tbaa !29
  %t358 = getelementptr %"compiler/build:Config", ptr %t356, i32 0, i32 10
  %t359 = load { i64, ptr }, ptr %t358, !tbaa !27
  %t361 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t359, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t361, ptr %l156
  br label %bb80
bb80:
  %t362 = load i1, ptr %l156, !tbaa !21
  %t363 = xor i1 %t362, true
  br i1 %t363, label %bb81, label %bb82
bb81:
  %t365 = load ptr, ptr %l1, !tbaa !29
  %t369 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v1, ptr %s0, ptr %s0, ptr %t365, ptr %l10, ptr %l6)
  store i32 %t369, ptr %l161
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t370 = load i32, ptr %l161, !tbaa !23
  store i32 %t370, ptr %rv
  br label %ret
bb84:
  %t371 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t371, ptr %l15, !tbaa !27
  store i64 0, ptr %l16, !tbaa !24
  %t373 = load { i64, ptr }, ptr %l15, !tbaa !27
  %t375 = extractvalue { i64, ptr } %t373, 0
  store i64 %t375, ptr %l17, !tbaa !24
  br label %bb85
bb85:
  %t377 = load i64, ptr %l16, !tbaa !24
  %t378 = load i64, ptr %l17, !tbaa !24
  %t381 = icmp slt i64 %t377, %t378
  %t383 = xor i1 %t381, true
  br i1 %t383, label %bb86, label %bb87
bb86:
  br label %bb91
bb87:
  br label %bb88
bb88:
  %t385 = load { i64, ptr }, ptr %l15, !tbaa !27
  store { i64, ptr } %t385, ptr %l169, !tbaa !27
  %t386 = load i64, ptr %l16, !tbaa !24
  %t388 = getelementptr { i64, ptr }, ptr %l169, i32 0, i32 1
  %t389 = load ptr, ptr %t388, !tbaa !27
  %t390 = getelementptr { i64, ptr }, ptr %t389, i64 %t386
  %t391 = load { i64, ptr }, ptr %t390, !tbaa !37
  %t395 = extractvalue { i64, ptr } %t391, 1
  %t396 = extractvalue { i64, ptr } %t391, 0
  %t397 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t396)
  call void @olang_textcopy(ptr %t397, ptr %t395, i64 %t396)
  %t398 = insertvalue { i64, ptr } undef, i64 %t396, 0
  %t399 = insertvalue { i64, ptr } %t398, ptr %t397, 1
  %t401 = extractvalue { i64, ptr } %t399, 0
  %t402 = extractvalue { i64, ptr } %t399, 1
  %t403 = mul i64 %t401, 1
  %t404 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t403)
  call void @llvm.memcpy.p0.p0.i64(ptr %t404, ptr %t402, i64 %t403, i1 false)
  %t405 = insertvalue { i64, ptr } undef, i64 %t401, 0
  %t406 = insertvalue { i64, ptr } %t405, ptr %t404, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l10, { i64, ptr } %t406)
  br label %bb89
bb89:
  br label %bb90
bb90:
  %t409 = load i64, ptr %l16, !tbaa !24
  %t411 = add i64 %t409, 1
  store i64 %t411, ptr %l16, !tbaa !24
  br label %bb85
bb91:
  %t414 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l10)
  store { i64, ptr } %t414, ptr %l180
  br label %bb92
bb92:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, ptr %l181, !tbaa !27
  %t415 = load { i64, ptr }, ptr %l180, !tbaa !27
  %t416 = load { i64, ptr }, ptr %l181, !tbaa !27
  %t417 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t415, { i64, ptr } %t416, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d24, i32 0, i32 1) })
  %t418 = extractvalue { i32, %"std/os:Output" } %t417, 1
  %t419 = extractvalue { i32, %"std/os:Output" } %t417, 0
  store i32 %t419, ptr %l183
  %t420 = icmp ne i32 %t419, 0
  br i1 %t420, label %bb94, label %ok.421, !prof !99
ok.421:
  store %"std/os:Output" %t418, ptr %l182
  br label %bb93
bb93:
  %t422 = load %"std/os:Output", ptr %l182
  store %"std/os:Output" %t422, ptr %l178
  br label %bb96
bb94:
  %t423 = load i32, ptr %l183, !tbaa !23
  %t424 = ashr i32 %t423, 16
  %t426 = icmp eq i32 %t424, 1
  store i1 %t426, ptr %l185, !tbaa !21
  br label %bb95
bb95:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb96:
  %t428 = load %"std/os:Output", ptr %l178
  store %"std/os:Output" %t428, ptr %l19
  %t429 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t430 = load i32, ptr %t429, !tbaa !23
  %t432 = icmp sgt i32 %t430, 128
  br i1 %t432, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s25
  %t434 = load ptr, ptr %l1, !tbaa !29
  store ptr %t434, ptr %l189, !tbaa !29
  %t435 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t435, ptr %l190, !tbaa !27
  %t436 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t437 = load i32, ptr %t436, !tbaa !23
  %t439 = sub i32 %t437, 128
  %t441 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s25, i32 %t439)
  store { i64, ptr } %t441, ptr %l193
  br label %bb99
bb98:
  br label %bb102
bb99:
  %t442 = load { i64, ptr }, ptr %l190, !tbaa !27
  %t443 = extractvalue { i64, ptr } %t442, 1
  %t444 = extractvalue { i64, ptr } %t442, 0
  %t445 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t446 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t447 = add i64 %t444, %t446
  %t448 = load { i64, ptr }, ptr %l193, !tbaa !27
  %t449 = extractvalue { i64, ptr } %t448, 1
  %t450 = extractvalue { i64, ptr } %t448, 0
  %t451 = add i64 %t447, %t450
  %t452 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 1
  %t453 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d26, i32 0, i32 1) }, 0
  %t454 = add i64 %t451, %t453
  %t455 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t454)
  call void @olang_textcopy(ptr %t455, ptr %t443, i64 %t444)
  %t456 = getelementptr i8, ptr %t455, i64 %t444
  call void @olang_textcopy(ptr %t456, ptr %t445, i64 %t446)
  %t457 = getelementptr i8, ptr %t456, i64 %t446
  call void @olang_textcopy(ptr %t457, ptr %t449, i64 %t450)
  %t458 = getelementptr i8, ptr %t457, i64 %t450
  call void @olang_textcopy(ptr %t458, ptr %t452, i64 %t453)
  %t459 = insertvalue { i64, ptr } undef, i64 %t454, 0
  %t460 = insertvalue { i64, ptr } %t459, ptr %t455, 1
  %t462 = extractvalue { i64, ptr } %t460, 0
  %t463 = extractvalue { i64, ptr } %t460, 1
  %t464 = mul i64 %t462, 1
  %t465 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t464)
  call void @llvm.memcpy.p0.p0.i64(ptr %t465, ptr %t463, i64 %t464, i1 false)
  %t466 = insertvalue { i64, ptr } undef, i64 %t462, 0
  %t467 = insertvalue { i64, ptr } %t466, ptr %t465, 1
  %t468 = load ptr, ptr %l189, !tbaa !29
  %t470 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s25, ptr %s25, ptr %s25, ptr %t468, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d27, i32 0, i32 1) }, { i64, ptr } %t467)
  store { i64, ptr } %t470, ptr %l196
  br label %bb100
bb100:
  %t471 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t472 = extractvalue { i64, ptr } %t471, 0
  %t473 = extractvalue { i64, ptr } %t471, 1
  %t474 = mul i64 %t472, 1
  %t475 = call ptr @__olang_scope_alloc(ptr %s25, i64 %t474)
  call void @llvm.memcpy.p0.p0.i64(ptr %t475, ptr %t473, i64 %t474, i1 false)
  %t476 = insertvalue { i64, ptr } undef, i64 %t472, 0
  %t477 = insertvalue { i64, ptr } %t476, ptr %t475, 1
  call void @compiler_2fbuild_2esayln(ptr %s25, { i64, ptr } %t477)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s25)
  br label %bb102
bb102:
  %t479 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t480 = load i32, ptr %t479, !tbaa !23
  %t482 = icmp eq i32 %t480, 3
  br i1 %t482, label %bb103, label %bb104
bb103:
  %t484 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t486 = extractvalue { i64, ptr } %t484, 0
  %t488 = icmp sgt i64 %t486, 0
  store i1 %t488, ptr %l200, !tbaa !21
  br label %bb105
bb104:
  store i1 false, ptr %l200, !tbaa !21
  br label %bb105
bb105:
  %t490 = load i1, ptr %l200, !tbaa !21
  br i1 %t490, label %bb106, label %bb107
bb106:
  store %olang.scope zeroinitializer, ptr %s27
  %t491 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t492 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t493 = getelementptr %"compiler/build:Program", ptr %l6, i32 0, i32 7
  %t497 = call { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v2, ptr %v3, ptr %s0, ptr %s27, { i64, ptr } %t491, { i64, ptr } %t492, ptr %t493)
  store { i64, ptr } %t497, ptr %l207
  br label %bb108
bb107:
  br label %bb110
bb108:
  %t498 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t499 = extractvalue { i64, ptr } %t498, 0
  %t500 = extractvalue { i64, ptr } %t498, 1
  %t501 = mul i64 %t499, 1
  %t502 = call ptr @__olang_scope_alloc(ptr %s27, i64 %t501)
  call void @llvm.memcpy.p0.p0.i64(ptr %t502, ptr %t500, i64 %t501, i1 false)
  %t503 = insertvalue { i64, ptr } undef, i64 %t499, 0
  %t504 = insertvalue { i64, ptr } %t503, ptr %t502, 1
  call void @compiler_2fbuild_2esayln(ptr %s27, { i64, ptr } %t504)
  br label %bb109
bb109:
  call void @__olang_scope_close(ptr %s27)
  call void @__olang_scope_close(ptr %s0)
  store i32 3, ptr %rv
  br label %ret
bb110:
  %t507 = getelementptr %"std/os:Output", ptr %l19, i32 0, i32 0
  %t508 = load i32, ptr %t507, !tbaa !23
  %t510 = icmp eq i32 %t508, 0
  br i1 %t510, label %bb111, label %bb112
bb111:
  store i32 0, ptr %l212, !tbaa !23
  br label %bb113
bb112:
  store i32 1, ptr %l212, !tbaa !23
  br label %bb113
bb113:
  call void @__olang_scope_close(ptr %s0)
  %t512 = load i32, ptr %l212, !tbaa !23
  store i32 %t512, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/diag:Diagnostics"
  %l16 = alloca %"compiler/build:Config"
  %l18 = alloca %"compiler/olang:CommandLine"
  %l22 = alloca %"compiler/olang:CommandLine"
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l37 = alloca i1
  %l39 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l61 = alloca i1
  %l63 = alloca i32
  %l65 = alloca i32
  %l70 = alloca i32
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l78 = alloca i1
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca i32
  %l103 = alloca { i64, ptr }
  %l107 = alloca i32
  %l112 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i32
  %l121 = alloca i1
  %l122 = alloca { i64, ptr }
  %l126 = alloca i32
  %l128 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l137 = alloca i32
  %l143 = alloca { i64, ptr }
  %l146 = alloca i32
  %l150 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca i32
  %l161 = alloca ptr
  %l162 = alloca ptr
  %l163 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l166 = alloca { i64, ptr }
  %l168 = alloca i32
  %l172 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l174 = alloca { i64, ptr }
  %l179 = alloca i64
  %l181 = alloca i64
  %l186 = alloca { i64, ptr }
  %l193 = alloca ptr
  %l194 = alloca ptr
  %l195 = alloca { i64, ptr }
  %l196 = alloca { i64, ptr }
  %l198 = alloca { i64, ptr }
  %l200 = alloca i32
  %l204 = alloca ptr
  %l205 = alloca ptr
  %l206 = alloca { i64, ptr }
  %l207 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l210 = alloca { i64, ptr }
  %l211 = alloca i32
  %l212 = alloca { i64, ptr }
  %l213 = alloca { i64, ptr }
  %l214 = alloca i32
  %l216 = alloca i1
  %l217 = alloca { i64, ptr }
  %l221 = alloca ptr
  %l222 = alloca { i64, ptr }
  %l224 = alloca { i64, ptr }
  %l225 = alloca { i64, ptr }
  %l227 = alloca { i64, ptr }
  %l228 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s19 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l14
  br label %bb1
bb1:
  %t3 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t2, i64 200, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l15, i64 200, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t4, i64 360, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 360, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 16
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  %t14 = extractvalue { i32, %"compiler/olang:CommandLine" } %t13, 1
  %t15 = extractvalue { i32, %"compiler/olang:CommandLine" } %t13, 0
  store i32 %t15, ptr %l23
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17, !prof !99
ok.17:
  store %"compiler/olang:CommandLine" %t14, ptr %l22
  br label %bb4
bb4:
  %t18 = load %"compiler/olang:CommandLine", ptr %l22
  store %"compiler/olang:CommandLine" %t18, ptr %l18
  br label %bb8
bb5:
  %t19 = load i32, ptr %l23, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  store i1 %t22, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  call void @__olang_ert_req_clear()
  %t24 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t24, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l27, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb8:
  %t26 = load %"compiler/olang:CommandLine", ptr %l18
  store %"compiler/olang:CommandLine" %t26, ptr %l4
  %t27 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t28 = load i64, ptr %t27, !tbaa !24
  %t29 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t32 = icmp eq i64 %t28, %t29
  br i1 %t32, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t36 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %s0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t37 = extractvalue { i32, { i64, ptr } } %t36, 1
  %t38 = extractvalue { i32, { i64, ptr } } %t36, 0
  store i32 %t38, ptr %l35
  %t39 = icmp ne i32 %t38, 0
  br i1 %t39, label %bb12, label %ok.40, !prof !99
ok.40:
  store { i64, ptr } %t37, ptr %l34
  br label %bb11
bb10:
  br label %bb17
bb11:
  %t41 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t41, ptr %l31, !tbaa !27
  br label %bb15
bb12:
  %t42 = load i32, ptr %l35, !tbaa !23
  %t43 = ashr i32 %t42, 16
  %t45 = icmp eq i32 %t43, 1
  store i1 %t45, ptr %l37, !tbaa !21
  br label %bb13
bb13:
  call void @__olang_ert_req_clear()
  %t47 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t47, ptr %l39
  br label %bb14
bb14:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t48 = load i32, ptr %l39, !tbaa !23
  store i32 %t48, ptr %rv
  br label %ret
bb15:
  %t49 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t52 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t49)
  store i32 %t52, ptr %l41
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t53 = load i32, ptr %l41, !tbaa !23
  store i32 %t53, ptr %rv
  br label %ret
bb17:
  %t54 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t55 = load i64, ptr %t54, !tbaa !24
  %t56 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t59 = icmp eq i64 %t55, %t56
  br i1 %t59, label %bb18, label %bb19
bb18:
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t63 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t61)
  store i64 %t63, ptr %l46
  br label %bb20
bb19:
  br label %bb32
bb20:
  %t64 = load i64, ptr %l46, !tbaa !24
  %t65 = icmp eq i64 %t64, 1
  br i1 %t65, label %bb21, label %bb22
bb21:
  %t67 = load ptr, ptr %l1, !tbaa !29
  store ptr %t67, ptr %l48, !tbaa !29
  store ptr %l3, ptr %l49, !tbaa !29
  %t68 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t70 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t68, i64 0)
  store { i64, ptr } %t70, ptr %l51
  br label %bb23
bb22:
  br label %bb25
bb23:
  %t71 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t72 = load { i64, ptr }, ptr %t71, !tbaa !27
  %t73 = load ptr, ptr %l48, !tbaa !29
  %t74 = load ptr, ptr %l49, !tbaa !29
  %t75 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t78 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t73, ptr %t74, { i64, ptr } %t75, { i64, ptr } %t72, ptr %l2)
  store i32 %t78, ptr %l54
  br label %bb24
bb24:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t79 = load i32, ptr %l54, !tbaa !23
  store i32 %t79, ptr %rv
  br label %ret
bb25:
  %t80 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t81 = load { i64, ptr }, ptr %t80, !tbaa !27
  %t84 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %s0, ptr %s0, ptr %s4, { i64, ptr } %t81, ptr %l2)
  %t85 = extractvalue { i32, { i64, ptr } } %t84, 1
  %t86 = extractvalue { i32, { i64, ptr } } %t84, 0
  store i32 %t86, ptr %l59
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb27, label %ok.88, !prof !99
ok.88:
  store { i64, ptr } %t85, ptr %l58
  br label %bb26
bb26:
  %t89 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t89, ptr %l55, !tbaa !27
  br label %bb30
bb27:
  %t90 = load i32, ptr %l59, !tbaa !23
  %t91 = ashr i32 %t90, 16
  %t93 = icmp eq i32 %t91, 1
  store i1 %t93, ptr %l61, !tbaa !21
  br label %bb28
bb28:
  call void @__olang_ert_req_clear()
  %t95 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t95, ptr %l63
  br label %bb29
bb29:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t96 = load i32, ptr %l63, !tbaa !23
  store i32 %t96, ptr %rv
  br label %ret
bb30:
  %t97 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t100 = call i32 @compiler_2folang_2ewrite(ptr %s4, { i64, ptr } %t97)
  store i32 %t100, ptr %l65
  br label %bb31
bb31:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t101 = load i32, ptr %l65, !tbaa !23
  store i32 %t101, ptr %rv
  br label %ret
bb32:
  %t102 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t103 = load i64, ptr %t102, !tbaa !24
  %t104 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t107 = icmp eq i64 %t103, %t104
  br i1 %t107, label %bb33, label %bb34
bb33:
  %t110 = call i32 @compiler_2folang_2eformat(ptr %s0, ptr %l4)
  store i32 %t110, ptr %l70
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t111 = load i32, ptr %l70, !tbaa !23
  store i32 %t111, ptr %rv
  br label %ret
bb36:
  %t112 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t113 = load i64, ptr %t112, !tbaa !24
  %t114 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t117 = icmp eq i64 %t113, %t114
  br i1 %t117, label %bb37, label %bb38
bb37:
  store %olang.scope zeroinitializer, ptr %s8
  %t119 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s8, ptr %s8, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d28, i32 0, i32 1) })
  %t120 = extractvalue { i32, { i64, ptr } } %t119, 1
  %t121 = extractvalue { i32, { i64, ptr } } %t119, 0
  store i32 %t121, ptr %l76
  %t122 = icmp ne i32 %t121, 0
  br i1 %t122, label %bb40, label %ok.123, !prof !99
ok.123:
  store { i64, ptr } %t120, ptr %l75
  br label %bb39
bb38:
  br label %bb46
bb39:
  %t124 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t124, ptr %l74, !tbaa !27
  br label %bb42
bb40:
  %t125 = load i32, ptr %l76, !tbaa !23
  %t126 = ashr i32 %t125, 16
  %t128 = icmp eq i32 %t126, 1
  store i1 %t128, ptr %l78, !tbaa !21
  br label %bb41
bb41:
  call void @__olang_ert_req_clear()
  %t129 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t129, ptr %l79, !tbaa !27
  %t130 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t131 = load ptr, ptr %t130, !tbaa !27
  %t132 = getelementptr { i64, ptr }, ptr %t131, i64 0
  %t133 = load { i64, ptr }, ptr %t132, !tbaa !37
  %t135 = extractvalue { i64, ptr } %t133, 1
  %t136 = extractvalue { i64, ptr } %t133, 0
  %t137 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t136)
  call void @olang_textcopy(ptr %t137, ptr %t135, i64 %t136)
  %t138 = insertvalue { i64, ptr } undef, i64 %t136, 0
  %t139 = insertvalue { i64, ptr } %t138, ptr %t137, 1
  %t141 = extractvalue { i64, ptr } %t139, 0
  %t142 = extractvalue { i64, ptr } %t139, 1
  %t143 = mul i64 %t141, 1
  %t144 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t143)
  call void @llvm.memcpy.p0.p0.i64(ptr %t144, ptr %t142, i64 %t143, i1 false)
  %t145 = insertvalue { i64, ptr } undef, i64 %t141, 0
  %t146 = insertvalue { i64, ptr } %t145, ptr %t144, 1
  store { i64, ptr } %t146, ptr %l74, !tbaa !27
  br label %bb42
bb42:
  %t148 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t148, ptr %l7, !tbaa !27
  %t149 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t150 = load i1, ptr %t149, !tbaa !21
  store i1 %t150, ptr %l83, !tbaa !21
  %t151 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t153 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t151)
  store { i64, ptr } %t153, ptr %l85
  br label %bb43
bb43:
  %t154 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t154, ptr %l86, !tbaa !27
  %t155 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s8)
  store { i64, ptr } %t155, ptr %l87
  br label %bb44
bb44:
  %t156 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t157 = extractvalue { i64, ptr } %t156, 0
  %t158 = extractvalue { i64, ptr } %t156, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t163 = load i1, ptr %l83, !tbaa !21
  %t164 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t165 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t167 = call i32 @compiler_2ffix_2eFiles(ptr %s0, ptr %s8, ptr %s8, i1 %t163, { i64, ptr } %t164, { i64, ptr } %t165, { i64, ptr } %t162)
  store i32 %t167, ptr %l89
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t168 = load i32, ptr %l89, !tbaa !23
  store i32 %t168, ptr %rv
  br label %ret
bb46:
  %t169 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t170 = load i64, ptr %t169, !tbaa !24
  %t171 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t174 = icmp eq i64 %t170, %t171
  br i1 %t174, label %bb47, label %bb48
bb47:
  store %olang.scope zeroinitializer, ptr %s10
  %t176 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t178 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t176, i64 0)
  store { i64, ptr } %t178, ptr %l94
  br label %bb49
bb48:
  br label %bb52
bb49:
  %t179 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t180 = load { i64, ptr }, ptr %t179, !tbaa !27
  store { i64, ptr } %t180, ptr %l95, !tbaa !27
  %t181 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s10)
  store { i64, ptr } %t181, ptr %l96
  br label %bb50
bb50:
  %t182 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  %t184 = extractvalue { i64, ptr } %t182, 1
  %t185 = mul i64 %t183, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t185)
  call void @llvm.memcpy.p0.p0.i64(ptr %t186, ptr %t184, i64 %t185, i1 false)
  %t187 = insertvalue { i64, ptr } undef, i64 %t183, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  %t189 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t190 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t192 = call i32 @compiler_2fbindgen_2eRun(ptr %s0, ptr %s0, ptr %s10, { i64, ptr } %t189, { i64, ptr } %t190, { i64, ptr } %t188)
  store i32 %t192, ptr %l98
  br label %bb51
bb51:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t193 = load i32, ptr %l98, !tbaa !23
  store i32 %t193, ptr %rv
  br label %ret
bb52:
  %t194 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t195 = load i64, ptr %t194, !tbaa !24
  %t196 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t199 = icmp eq i64 %t195, %t196
  br i1 %t199, label %bb53, label %bb54
bb53:
  %t201 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t203 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t201)
  store { i64, ptr } %t203, ptr %l103
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t204 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t205 = load { i64, ptr }, ptr %t204, !tbaa !27
  %t206 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 10
  %t207 = load { i64, ptr }, ptr %t206, !tbaa !27
  %t208 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t212 = call i32 @compiler_2fsession_2eDocMode(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t208, { i64, ptr } %t205, { i64, ptr } %t207, ptr %l3)
  store i32 %t212, ptr %l107
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s0)
  %t213 = load i32, ptr %l107, !tbaa !23
  store i32 %t213, ptr %rv
  br label %ret
bb57:
  %t214 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t215 = load i64, ptr %t214, !tbaa !24
  %t216 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t219 = icmp eq i64 %t215, %t216
  br i1 %t219, label %bb58, label %bb59
bb58:
  %t222 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t222, ptr %l112
  br label %bb60
bb59:
  br label %bb61
bb60:
  call void @__olang_scope_close(ptr %s0)
  %t223 = load i32, ptr %l112, !tbaa !23
  store i32 %t223, ptr %rv
  br label %ret
bb61:
  %t224 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t225 = load i64, ptr %t224, !tbaa !24
  %t226 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t229 = icmp eq i64 %t225, %t226
  br i1 %t229, label %bb62, label %bb63
bb62:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l3, ptr %l116, !tbaa !29
  %t231 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s13, ptr %s13, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t232 = extractvalue { i32, { i64, ptr } } %t231, 1
  %t233 = extractvalue { i32, { i64, ptr } } %t231, 0
  store i32 %t233, ptr %l119
  %t234 = icmp ne i32 %t233, 0
  br i1 %t234, label %bb65, label %ok.235, !prof !99
ok.235:
  store { i64, ptr } %t232, ptr %l118
  br label %bb64
bb63:
  br label %bb69
bb64:
  %t236 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t236, ptr %l117, !tbaa !27
  br label %bb67
bb65:
  %t237 = load i32, ptr %l119, !tbaa !23
  %t238 = ashr i32 %t237, 16
  %t240 = icmp eq i32 %t238, 1
  store i1 %t240, ptr %l121, !tbaa !21
  br label %bb66
bb66:
  call void @__olang_ert_req_clear()
  %t241 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t241, ptr %l122, !tbaa !27
  %t242 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t243 = load ptr, ptr %t242, !tbaa !27
  %t244 = getelementptr { i64, ptr }, ptr %t243, i64 0
  %t245 = load { i64, ptr }, ptr %t244, !tbaa !37
  %t247 = extractvalue { i64, ptr } %t245, 1
  %t248 = extractvalue { i64, ptr } %t245, 0
  %t249 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t248)
  call void @olang_textcopy(ptr %t249, ptr %t247, i64 %t248)
  %t250 = insertvalue { i64, ptr } undef, i64 %t248, 0
  %t251 = insertvalue { i64, ptr } %t250, ptr %t249, 1
  %t253 = extractvalue { i64, ptr } %t251, 0
  %t254 = extractvalue { i64, ptr } %t251, 1
  %t255 = mul i64 %t253, 1
  %t256 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t255)
  call void @llvm.memcpy.p0.p0.i64(ptr %t256, ptr %t254, i64 %t255, i1 false)
  %t257 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t258 = insertvalue { i64, ptr } %t257, ptr %t256, 1
  store { i64, ptr } %t258, ptr %l117, !tbaa !27
  br label %bb67
bb67:
  %t260 = load ptr, ptr %l116, !tbaa !29
  %t261 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t262 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s13, ptr %t260, { i64, ptr } %t261)
  store i32 %t262, ptr %l126
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t263 = load i32, ptr %l126, !tbaa !23
  store i32 %t263, ptr %rv
  br label %ret
bb69:
  %t264 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t266 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t264)
  store { i64, ptr } %t266, ptr %l128
  br label %bb70
bb70:
  %t267 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t267, ptr %l8, !tbaa !27
  %t268 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t269 = load i64, ptr %t268, !tbaa !24
  %t270 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t273 = icmp eq i64 %t269, %t270
  br i1 %t273, label %bb71, label %bb72
bb71:
  %t275 = load ptr, ptr %l1, !tbaa !29
  %t276 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t276, ptr %l134, !tbaa !27
  %t277 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t278 = load ptr, ptr %t277, !tbaa !27
  %t279 = getelementptr { i64, ptr }, ptr %t278, i64 0
  %t280 = load { i64, ptr }, ptr %t279, !tbaa !37
  %t285 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t275, ptr %l3, { i64, ptr } %t280, ptr %l2)
  store i32 %t285, ptr %l137
  br label %bb73
bb72:
  br label %bb74
bb73:
  call void @__olang_scope_close(ptr %s0)
  %t286 = load i32, ptr %l137, !tbaa !23
  store i32 %t286, ptr %rv
  br label %ret
bb74:
  %t287 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t288 = load i64, ptr %t287, !tbaa !24
  %t289 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t292 = icmp eq i64 %t288, %t289
  br i1 %t292, label %bb75, label %bb76
bb75:
  %t294 = load ptr, ptr %l1, !tbaa !29
  %t295 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t295, ptr %l143, !tbaa !27
  %t296 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t297 = load ptr, ptr %t296, !tbaa !27
  %t298 = getelementptr { i64, ptr }, ptr %t297, i64 0
  %t299 = load { i64, ptr }, ptr %t298, !tbaa !37
  %t304 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t294, ptr %l3, { i64, ptr } %t299, ptr %l2)
  store i32 %t304, ptr %l146
  br label %bb77
bb76:
  br label %bb78
bb77:
  call void @__olang_scope_close(ptr %s0)
  %t305 = load i32, ptr %l146, !tbaa !23
  store i32 %t305, ptr %rv
  br label %ret
bb78:
  %t306 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t307 = load i64, ptr %t306, !tbaa !24
  %t308 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t311 = icmp eq i64 %t307, %t308
  br i1 %t311, label %bb79, label %bb80
bb79:
  %t313 = load ptr, ptr %l1, !tbaa !29
  store ptr %t313, ptr %l150, !tbaa !29
  store ptr %l3, ptr %l151, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t314, ptr %l152, !tbaa !27
  %t315 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t316 = load ptr, ptr %t315, !tbaa !27
  %t317 = getelementptr { i64, ptr }, ptr %t316, i64 0
  %t318 = load { i64, ptr }, ptr %t317, !tbaa !37
  store { i64, ptr } %t318, ptr %l153, !tbaa !27
  %t319 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t321 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t319)
  store { i64, ptr } %t321, ptr %l155
  br label %bb81
bb80:
  br label %bb83
bb81:
  %t322 = load ptr, ptr %l150, !tbaa !29
  %t323 = load ptr, ptr %l151, !tbaa !29
  %t324 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t325 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t327 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t322, ptr %t323, { i64, ptr } %t324, { i64, ptr } %t325, ptr %l2)
  store i32 %t327, ptr %l157
  br label %bb82
bb82:
  call void @__olang_scope_close(ptr %s0)
  %t328 = load i32, ptr %l157, !tbaa !23
  store i32 %t328, ptr %rv
  br label %ret
bb83:
  %t329 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t330 = load i64, ptr %t329, !tbaa !24
  %t331 = load i64, ptr @G_2ecompiler_2folang_2eProfile, !tbaa !24
  %t334 = icmp eq i64 %t330, %t331
  br i1 %t334, label %bb84, label %bb85
bb84:
  %t336 = load ptr, ptr %l1, !tbaa !29
  store ptr %t336, ptr %l161, !tbaa !29
  store ptr %l3, ptr %l162, !tbaa !29
  %t337 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t337, ptr %l163, !tbaa !27
  %t338 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t339 = load ptr, ptr %t338, !tbaa !27
  %t340 = getelementptr { i64, ptr }, ptr %t339, i64 0
  %t341 = load { i64, ptr }, ptr %t340, !tbaa !37
  store { i64, ptr } %t341, ptr %l164, !tbaa !27
  %t342 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t344 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t342)
  store { i64, ptr } %t344, ptr %l166
  br label %bb86
bb85:
  br label %bb88
bb86:
  %t345 = load ptr, ptr %l161, !tbaa !29
  %t346 = load ptr, ptr %l162, !tbaa !29
  %t347 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t348 = load { i64, ptr }, ptr %l166, !tbaa !27
  %t350 = call i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t345, ptr %t346, { i64, ptr } %t347, { i64, ptr } %t348, ptr %l2)
  store i32 %t350, ptr %l168
  br label %bb87
bb87:
  call void @__olang_scope_close(ptr %s0)
  %t351 = load i32, ptr %l168, !tbaa !23
  store i32 %t351, ptr %rv
  br label %ret
bb88:
  %t352 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t353 = load i64, ptr %t352, !tbaa !24
  %t354 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t357 = icmp eq i64 %t353, %t354
  br i1 %t357, label %bb89, label %bb90
bb89:
  store %olang.scope zeroinitializer, ptr %s19
  %t359 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s19, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t359, ptr %l172
  br label %bb91
bb90:
  br label %bb104
bb91:
  %t360 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l172
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t360, ptr %l9
  %t361 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t361, ptr %l174, !tbaa !27
  %t362 = getelementptr { i64, ptr }, ptr %l174, i32 0, i32 1
  %t363 = load ptr, ptr %t362, !tbaa !27
  %t364 = getelementptr { i64, ptr }, ptr %t363, i64 0
  %t365 = load { i64, ptr }, ptr %t364, !tbaa !37
  %t367 = extractvalue { i64, ptr } %t365, 1
  %t368 = extractvalue { i64, ptr } %t365, 0
  %t369 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t368)
  call void @olang_textcopy(ptr %t369, ptr %t367, i64 %t368)
  %t370 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t371 = insertvalue { i64, ptr } %t370, ptr %t369, 1
  %t373 = extractvalue { i64, ptr } %t371, 0
  %t374 = extractvalue { i64, ptr } %t371, 1
  %t375 = mul i64 %t373, 1
  %t376 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t375)
  call void @llvm.memcpy.p0.p0.i64(ptr %t376, ptr %t374, i64 %t375, i1 false)
  %t377 = insertvalue { i64, ptr } undef, i64 %t373, 0
  %t378 = insertvalue { i64, ptr } %t377, ptr %t376, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s19, ptr %s19, ptr %l9, { i64, ptr } %t378)
  br label %bb92
bb92:
  %t381 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  store ptr %t381, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb93
bb93:
  %t383 = load i64, ptr %l11, !tbaa !24
  store i64 %t383, ptr %l179, !tbaa !24
  %t384 = load ptr, ptr %l10, !tbaa !29
  %t386 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t384)
  store i64 %t386, ptr %l181
  br label %bb94
bb94:
  %t387 = load i64, ptr %l179, !tbaa !24
  %t388 = load i64, ptr %l181, !tbaa !24
  %t389 = icmp slt i64 %t387, %t388
  %t391 = xor i1 %t389, true
  br i1 %t391, label %bb95, label %bb96
bb95:
  br label %bb101
bb96:
  br label %bb97
bb97:
  %t393 = load ptr, ptr %l10, !tbaa !29
  %t394 = load i64, ptr %l11, !tbaa !24
  %t397 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t393, i64 %t394)
  store { i64, ptr } %t397, ptr %l186
  br label %bb98
bb98:
  %t398 = load { i64, ptr }, ptr %l186, !tbaa !27
  %t401 = extractvalue { i64, ptr } %t398, 1
  %t402 = extractvalue { i64, ptr } %t398, 0
  %t403 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t402)
  call void @olang_textcopy(ptr %t403, ptr %t401, i64 %t402)
  %t404 = insertvalue { i64, ptr } undef, i64 %t402, 0
  %t405 = insertvalue { i64, ptr } %t404, ptr %t403, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = extractvalue { i64, ptr } %t405, 1
  %t409 = mul i64 %t407, 1
  %t410 = call ptr @__olang_scope_alloc(ptr %s19, i64 %t409)
  call void @llvm.memcpy.p0.p0.i64(ptr %t410, ptr %t408, i64 %t409, i1 false)
  %t411 = insertvalue { i64, ptr } undef, i64 %t407, 0
  %t412 = insertvalue { i64, ptr } %t411, ptr %t410, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s19, ptr %s19, ptr %l9, { i64, ptr } %t412)
  br label %bb99
bb99:
  br label %bb100
bb100:
  %t415 = load i64, ptr %l11, !tbaa !24
  %t417 = add i64 %t415, 1
  store i64 %t417, ptr %l11, !tbaa !24
  br label %bb93
bb101:
  %t419 = load ptr, ptr %l1, !tbaa !29
  store ptr %t419, ptr %l193, !tbaa !29
  store ptr %l3, ptr %l194, !tbaa !29
  %t420 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t420, ptr %l195, !tbaa !27
  %t421 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t422 = load ptr, ptr %t421, !tbaa !27
  %t423 = getelementptr { i64, ptr }, ptr %t422, i64 0
  %t424 = load { i64, ptr }, ptr %t423, !tbaa !37
  store { i64, ptr } %t424, ptr %l196, !tbaa !27
  %t426 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s19, ptr %s19, ptr %l9)
  store { i64, ptr } %t426, ptr %l198
  br label %bb102
bb102:
  %t427 = load ptr, ptr %l193, !tbaa !29
  %t428 = load ptr, ptr %l194, !tbaa !29
  %t429 = load { i64, ptr }, ptr %l196, !tbaa !27
  %t430 = load { i64, ptr }, ptr %l198, !tbaa !27
  %t432 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s19, ptr %t427, ptr %t428, { i64, ptr } %t429, { i64, ptr } %t430, ptr %l2)
  store i32 %t432, ptr %l200
  br label %bb103
bb103:
  call void @__olang_scope_close(ptr %s19)
  call void @__olang_scope_close(ptr %s0)
  %t433 = load i32, ptr %l200, !tbaa !23
  store i32 %t433, ptr %rv
  br label %ret
bb104:
  %t434 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t436 = extractvalue { i64, ptr } %t434, 0
  %t438 = icmp eq i64 %t436, 1
  br i1 %t438, label %bb105, label %bb106
bb105:
  %t440 = load ptr, ptr %l1, !tbaa !29
  store ptr %t440, ptr %l204, !tbaa !29
  store ptr %l3, ptr %l205, !tbaa !29
  %t441 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t441, ptr %l206, !tbaa !27
  %t442 = getelementptr { i64, ptr }, ptr %l206, i32 0, i32 1
  %t443 = load ptr, ptr %t442, !tbaa !27
  %t444 = getelementptr { i64, ptr }, ptr %t443, i64 0
  %t445 = load { i64, ptr }, ptr %t444, !tbaa !37
  store { i64, ptr } %t445, ptr %l207, !tbaa !27
  store ptr %l2, ptr %l208, !tbaa !29
  %t446 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t448 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t446)
  store { i64, ptr } %t448, ptr %l210
  br label %bb107
bb106:
  br label %bb109
bb107:
  %t449 = load ptr, ptr %l204, !tbaa !29
  %t450 = load ptr, ptr %l205, !tbaa !29
  %t451 = load { i64, ptr }, ptr %l207, !tbaa !27
  %t452 = load ptr, ptr %l208, !tbaa !29
  %t453 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t454 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t449, ptr %t450, { i64, ptr } %t451, ptr %t452, { i64, ptr } %t453)
  store i32 %t454, ptr %l211
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s0)
  %t455 = load i32, ptr %l211, !tbaa !23
  store i32 %t455, ptr %rv
  br label %ret
bb109:
  %t456 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d30, i32 0, i32 1) })
  %t457 = extractvalue { i32, { i64, ptr } } %t456, 1
  %t458 = extractvalue { i32, { i64, ptr } } %t456, 0
  store i32 %t458, ptr %l214
  %t459 = icmp ne i32 %t458, 0
  br i1 %t459, label %bb111, label %ok.460, !prof !99
ok.460:
  store { i64, ptr } %t457, ptr %l213
  br label %bb110
bb110:
  %t461 = load { i64, ptr }, ptr %l213, !tbaa !27
  store { i64, ptr } %t461, ptr %l212, !tbaa !27
  br label %bb113
bb111:
  %t462 = load i32, ptr %l214, !tbaa !23
  %t463 = ashr i32 %t462, 16
  %t465 = icmp eq i32 %t463, 1
  store i1 %t465, ptr %l216, !tbaa !21
  br label %bb112
bb112:
  call void @__olang_ert_req_clear()
  %t466 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t466, ptr %l217, !tbaa !27
  %t467 = getelementptr { i64, ptr }, ptr %l217, i32 0, i32 1
  %t468 = load ptr, ptr %t467, !tbaa !27
  %t469 = getelementptr { i64, ptr }, ptr %t468, i64 0
  %t470 = load { i64, ptr }, ptr %t469, !tbaa !37
  %t472 = extractvalue { i64, ptr } %t470, 1
  %t473 = extractvalue { i64, ptr } %t470, 0
  %t474 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t473)
  call void @olang_textcopy(ptr %t474, ptr %t472, i64 %t473)
  %t475 = insertvalue { i64, ptr } undef, i64 %t473, 0
  %t476 = insertvalue { i64, ptr } %t475, ptr %t474, 1
  %t478 = extractvalue { i64, ptr } %t476, 0
  %t479 = extractvalue { i64, ptr } %t476, 1
  %t480 = mul i64 %t478, 1
  %t481 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t480)
  call void @llvm.memcpy.p0.p0.i64(ptr %t481, ptr %t479, i64 %t480, i1 false)
  %t482 = insertvalue { i64, ptr } undef, i64 %t478, 0
  %t483 = insertvalue { i64, ptr } %t482, ptr %t481, 1
  store { i64, ptr } %t483, ptr %l212, !tbaa !27
  br label %bb113
bb113:
  %t485 = load { i64, ptr }, ptr %l212, !tbaa !27
  store ptr %l3, ptr %l221, !tbaa !29
  store { i64, ptr } %t485, ptr %l222, !tbaa !27
  %t487 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 6
  %t489 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t487)
  store { i64, ptr } %t489, ptr %l224
  br label %bb114
bb114:
  %t490 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t490, ptr %l225, !tbaa !27
  %t491 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t493 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t491)
  store { i64, ptr } %t493, ptr %l227
  br label %bb115
bb115:
  %t494 = load ptr, ptr %l221, !tbaa !29
  %t495 = load { i64, ptr }, ptr %l222, !tbaa !27
  %t496 = load { i64, ptr }, ptr %l224, !tbaa !27
  %t497 = load { i64, ptr }, ptr %l225, !tbaa !27
  %t498 = load { i64, ptr }, ptr %l227, !tbaa !27
  %t499 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t494, { i64, ptr } %t495, { i64, ptr } %t496, { i64, ptr } %t497, { i64, ptr } %t498)
  store i32 %t499, ptr %l228
  br label %bb116
bb116:
  call void @__olang_scope_close(ptr %s0)
  %t500 = load i32, ptr %l228, !tbaa !23
  store i32 %t500, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca %"compiler/profile:Profile"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/profile:Places"
  %l25 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i1
  %l36 = alloca ptr
  %l37 = alloca { i64, [3 x i64] }
  %l41 = alloca %"compiler/msgs:Msg"
  %l43 = alloca i32
  %l46 = alloca { i64, ptr }
  %l47 = alloca i64
  %l49 = alloca i64
  %l50 = alloca i32
  %l53 = alloca { i64, ptr }
  %l54 = alloca i64
  %l55 = alloca i64
  %l64 = alloca i1
  %l67 = alloca { i64, ptr }
  %l69 = alloca i64
  %l72 = alloca i32
  %l74 = alloca i1
  %l80 = alloca i32
  %l83 = alloca ptr
  %l84 = alloca { i64, [3 x i64] }
  %l85 = alloca %"compiler/msgs:Msg"
  %l87 = alloca i32
  %l88 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l93 = alloca i1
  %l94 = alloca { i64, ptr }
  %l97 = alloca { i64, ptr }
  %l101 = alloca %"compiler/profile:Profile"
  %l104 = alloca %"compiler/profile:Profile"
  %l105 = alloca i32
  %l107 = alloca i1
  %l112 = alloca { i64, ptr }
  %l115 = alloca %"compiler/profile:Places"
  %l119 = alloca { i64, ptr }
  %l122 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca { i64, ptr }
  %l130 = alloca i32
  %l132 = alloca i1
  %l138 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t62 = alloca { i64, [3 x i64] }, align 8
  %t226 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 18
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 18
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %t14, !tbaa !27
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 17
  store i1 true, ptr %t17, !tbaa !21
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/build:Config", ptr %t18, i32 0, i32 12
  store i1 true, ptr %t20, !tbaa !21
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t29 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t22, { i64, ptr } %t23, ptr %t24)
  store i32 %t29, ptr %l25
  br label %bb1
bb1:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb2, label %bb3
bb2:
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t35, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/build:Config", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d32, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t52)
  store i32 %t54, ptr %l33
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb6, label %ok.56, !prof !99
ok.56:
  br label %bb5
bb5:
  br label %bb11
bb6:
  %t57 = load i32, ptr %l33, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l35, !tbaa !21
  br label %bb7
bb7:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s4
  %t61 = load ptr, ptr %l4, !tbaa !29
  store ptr %t61, ptr %l36, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t62
  %t63 = getelementptr { i64, [3 x i64] }, ptr %t62, i32 0, i32 0
  store i64 0, ptr %t63
  %t64 = load { i64, [3 x i64] }, ptr %t62
  store { i64, [3 x i64] } %t64, ptr %l37
  %t65 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t66 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t67 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t69 = extractvalue { i64, ptr } %t65, 1
  %t70 = extractvalue { i64, ptr } %t65, 0
  %t71 = add i64 %t67, %t70
  %t72 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t73 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t74 = add i64 %t71, %t73
  %t75 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t74)
  call void @olang_textcopy(ptr %t75, ptr %t66, i64 %t67)
  %t76 = getelementptr i8, ptr %t75, i64 %t67
  call void @olang_textcopy(ptr %t76, ptr %t69, i64 %t70)
  %t77 = getelementptr i8, ptr %t76, i64 %t70
  call void @olang_textcopy(ptr %t77, ptr %t72, i64 %t73)
  %t78 = insertvalue { i64, ptr } undef, i64 %t74, 0
  %t79 = insertvalue { i64, ptr } %t78, ptr %t75, 1
  %t81 = extractvalue { i64, ptr } %t79, 0
  %t82 = extractvalue { i64, ptr } %t79, 1
  %t83 = mul i64 %t81, 1
  %t84 = call ptr @__olang_scope_alloc(ptr %s4, i64 %t83)
  call void @llvm.memcpy.p0.p0.i64(ptr %t84, ptr %t82, i64 %t83, i1 false)
  %t85 = insertvalue { i64, ptr } undef, i64 %t81, 0
  %t86 = insertvalue { i64, ptr } %t85, ptr %t84, 1
  %t88 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s4, ptr %s4, { i64, ptr } %t86)
  store %"compiler/msgs:Msg" %t88, ptr %l41
  br label %bb8
bb8:
  %t89 = load ptr, ptr %l36, !tbaa !29
  %t90 = load { i64, [3 x i64] }, ptr %l37
  %t91 = load %"compiler/msgs:Msg", ptr %l41
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s4, ptr %t89, { i64, [3 x i64] } %t90, %"compiler/msgs:Msg" %t91)
  br label %bb9
bb9:
  %t92 = load ptr, ptr %l4, !tbaa !29
  %t94 = call i32 @compiler_2fbuild_2eFinish(ptr %v1, ptr %t92)
  store i32 %t94, ptr %l43
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t95 = load i32, ptr %l43, !tbaa !23
  store i32 %t95, ptr %rv
  br label %ret
bb11:
  %t96 = load ptr, ptr %l1, !tbaa !29
  %t98 = getelementptr %"compiler/build:Config", ptr %t96, i32 0, i32 19
  %t99 = load { i64, ptr }, ptr %t98, !tbaa !27
  %t101 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, { i64, ptr } %t99)
  store { i64, ptr } %t101, ptr %l46
  br label %bb12
bb12:
  %t102 = load { i64, ptr }, ptr %l46, !tbaa !27
  store { i64, ptr } %t102, ptr %l8, !tbaa !27
  %t103 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t105 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t103, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d35, i32 0, i32 1) })
  %t106 = extractvalue { i32, i64 } %t105, 1
  %t107 = extractvalue { i32, i64 } %t105, 0
  store i32 %t107, ptr %l50
  %t108 = icmp ne i32 %t107, 0
  br i1 %t108, label %bb14, label %ok.109, !prof !99
ok.109:
  store i64 %t106, ptr %l49
  br label %bb13
bb13:
  %t110 = load i64, ptr %l49, !tbaa !24
  store i64 %t110, ptr %l47, !tbaa !24
  br label %bb16
bb14:
  br label %bb15
bb15:
  call void @__olang_ert_req_clear()
  %t111 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t113 = extractvalue { i64, ptr } %t111, 0
  store i64 %t113, ptr %l47, !tbaa !24
  br label %bb16
bb16:
  %t115 = load i64, ptr %l47, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t116, ptr %l53, !tbaa !27
  store i64 %t115, ptr %l54, !tbaa !24
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = extractvalue { i64, ptr } %t118, 0
  store i64 %t119, ptr %l55, !tbaa !24
  %t120 = icmp sge i64 0, 0
  br i1 %t120, label %bb17, label %bb18
bb17:
  %t122 = load i64, ptr %l54, !tbaa !24
  %t123 = icmp sle i64 0, %t122
  br i1 %t123, label %bb19, label %bb20
bb18:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb19:
  %t125 = load i64, ptr %l54, !tbaa !24
  %t126 = load i64, ptr %l55, !tbaa !24
  %t127 = icmp sle i64 %t125, %t126
  br i1 %t127, label %bb21, label %bb22
bb20:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb21:
  %t129 = getelementptr { i64, ptr }, ptr %l53, i32 0, i32 1
  %t130 = load ptr, ptr %t129, !tbaa !27
  %t131 = load i64, ptr %l54, !tbaa !24
  %t132 = getelementptr i8, ptr %t130, i64 0
  %t133 = sub i64 %t131, 0
  %t134 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t135 = insertvalue { i64, ptr } %t134, ptr %t132, 1
  store { i64, ptr } %t135, ptr %l8, !tbaa !27
  %t137 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t138 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t140 = extractvalue { i64, ptr } %t137, 1
  %t141 = extractvalue { i64, ptr } %t137, 0
  %t142 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t143 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t144 = add i64 %t141, %t143
  %t146 = extractvalue { i64, ptr } %t138, 1
  %t147 = extractvalue { i64, ptr } %t138, 0
  %t148 = add i64 %t144, %t147
  %t149 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 1
  %t150 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d37, i32 0, i32 1) }, 0
  %t151 = add i64 %t148, %t150
  %t152 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t151)
  call void @olang_textcopy(ptr %t152, ptr %t140, i64 %t141)
  %t153 = getelementptr i8, ptr %t152, i64 %t141
  call void @olang_textcopy(ptr %t153, ptr %t142, i64 %t143)
  %t154 = getelementptr i8, ptr %t153, i64 %t143
  call void @olang_textcopy(ptr %t154, ptr %t146, i64 %t147)
  %t155 = getelementptr i8, ptr %t154, i64 %t147
  call void @olang_textcopy(ptr %t155, ptr %t149, i64 %t150)
  %t156 = insertvalue { i64, ptr } undef, i64 %t151, 0
  %t157 = insertvalue { i64, ptr } %t156, ptr %t152, 1
  store { i64, ptr } %t157, ptr %l10, !tbaa !27
  %t159 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t161 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t159, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) })
  store i1 %t161, ptr %l64
  br label %bb23
bb22:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb23:
  %t162 = load i1, ptr %l64, !tbaa !21
  br i1 %t162, label %bb24, label %bb25
bb24:
  %t163 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t166 = extractvalue { i64, ptr } %t163, 1
  %t167 = extractvalue { i64, ptr } %t163, 0
  %t168 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 1
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d39, i32 0, i32 1) }, 0
  %t170 = add i64 %t167, %t169
  %t172 = extractvalue { i64, ptr } %t164, 1
  %t173 = extractvalue { i64, ptr } %t164, 0
  %t174 = add i64 %t170, %t173
  %t175 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 1
  %t176 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d40, i32 0, i32 1) }, 0
  %t177 = add i64 %t174, %t176
  %t178 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t177)
  call void @olang_textcopy(ptr %t178, ptr %t166, i64 %t167)
  %t179 = getelementptr i8, ptr %t178, i64 %t167
  call void @olang_textcopy(ptr %t179, ptr %t168, i64 %t169)
  %t180 = getelementptr i8, ptr %t179, i64 %t169
  call void @olang_textcopy(ptr %t180, ptr %t172, i64 %t173)
  %t181 = getelementptr i8, ptr %t180, i64 %t173
  call void @olang_textcopy(ptr %t181, ptr %t175, i64 %t176)
  %t182 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t178, 1
  store { i64, ptr } %t183, ptr %l67, !tbaa !27
  %t184 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t185 = extractvalue { i64, ptr } %t184, 0
  %t186 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  store i64 %t187, ptr %l69, !tbaa !24
  %t189 = load i64, ptr %l69, !tbaa !24
  %t190 = icmp eq i64 %t185, %t189
  br i1 %t190, label %bb26, label %bb27
bb25:
  br label %bb29
bb26:
  %t192 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t193 = load ptr, ptr %t192, !tbaa !27
  %t194 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t195 = load ptr, ptr %t194, !tbaa !27
  %t196 = load i64, ptr %l69, !tbaa !24
  %t197 = mul i64 %t196, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t193, ptr %t195, i64 %t197, i1 false)
  br label %bb28
bb27:
  %t198 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t198, ptr %l5, !tbaa !27
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t199 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t201 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t199)
  store i32 %t201, ptr %l72
  %t202 = icmp ne i32 %t201, 0
  br i1 %t202, label %bb31, label %ok.203, !prof !99
ok.203:
  br label %bb30
bb30:
  br label %bb33
bb31:
  %t204 = load i32, ptr %l72, !tbaa !23
  %t205 = ashr i32 %t204, 16
  %t207 = icmp eq i32 %t205, 1
  store i1 %t207, ptr %l74, !tbaa !21
  br label %bb32
bb32:
  call void @__olang_ert_req_clear()
  br label %bb33
bb33:
  %t208 = load ptr, ptr %l1, !tbaa !29
  %t210 = getelementptr %"compiler/build:Config", ptr %t208, i32 0, i32 19
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t214 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t219 = call i32 @compiler_2fprofile_2erunProfiled(ptr %v1, ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t211, { i64, ptr } %t212, { i64, ptr } %a3, { i64, ptr } %t214)
  store i32 %t219, ptr %l80
  br label %bb34
bb34:
  %t220 = load i32, ptr %l80, !tbaa !23
  store i32 %t220, ptr %l6, !tbaa !23
  %t221 = load i32, ptr %l6, !tbaa !23
  %t223 = icmp slt i32 %t221, 0
  br i1 %t223, label %bb35, label %bb36
bb35:
  store %olang.scope zeroinitializer, ptr %s10
  %t225 = load ptr, ptr %l4, !tbaa !29
  store ptr %t225, ptr %l83, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t226
  %t227 = getelementptr { i64, [3 x i64] }, ptr %t226, i32 0, i32 0
  store i64 0, ptr %t227
  %t228 = load { i64, [3 x i64] }, ptr %t226
  store { i64, [3 x i64] } %t228, ptr %l84
  %t229 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s10, ptr %s10, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d41, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t229, ptr %l85
  br label %bb37
bb36:
  br label %bb40
bb37:
  %t230 = load ptr, ptr %l83, !tbaa !29
  %t231 = load { i64, [3 x i64] }, ptr %l84
  %t232 = load %"compiler/msgs:Msg", ptr %l85
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s10, ptr %t230, { i64, [3 x i64] } %t231, %"compiler/msgs:Msg" %t232)
  br label %bb38
bb38:
  %t233 = load ptr, ptr %l4, !tbaa !29
  %t235 = call i32 @compiler_2fbuild_2eFinish(ptr %v1, ptr %t233)
  store i32 %t235, ptr %l87
  br label %bb39
bb39:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t236 = load i32, ptr %l87, !tbaa !23
  store i32 %t236, ptr %rv
  br label %ret
bb40:
  %t237 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t239 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t237)
  %t240 = extractvalue { i32, { i64, ptr } } %t239, 1
  %t241 = extractvalue { i32, { i64, ptr } } %t239, 0
  store i32 %t241, ptr %l91
  %t242 = icmp ne i32 %t241, 0
  br i1 %t242, label %bb42, label %ok.243, !prof !99
ok.243:
  store { i64, ptr } %t240, ptr %l90
  br label %bb41
bb41:
  %t244 = load { i64, ptr }, ptr %l90, !tbaa !27
  store { i64, ptr } %t244, ptr %l88, !tbaa !27
  br label %bb46
bb42:
  %t245 = load i32, ptr %l91, !tbaa !23
  %t246 = ashr i32 %t245, 16
  %t248 = icmp eq i32 %t246, 1
  store i1 %t248, ptr %l93, !tbaa !21
  br label %bb43
bb43:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s11
  %t249 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t249, ptr %l94, !tbaa !27
  %t250 = load i32, ptr %l6, !tbaa !23
  %t252 = sub i32 %t250, 128
  %t254 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t252)
  store { i64, ptr } %t254, ptr %l97
  br label %bb44
bb44:
  %t255 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d42, i32 0, i32 1) }, 1
  %t256 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d42, i32 0, i32 1) }, 0
  %t257 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t258 = extractvalue { i64, ptr } %t257, 1
  %t259 = extractvalue { i64, ptr } %t257, 0
  %t260 = add i64 %t256, %t259
  %t261 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d43, i32 0, i32 1) }, 1
  %t262 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d43, i32 0, i32 1) }, 0
  %t263 = add i64 %t260, %t262
  %t264 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t265 = extractvalue { i64, ptr } %t264, 1
  %t266 = extractvalue { i64, ptr } %t264, 0
  %t267 = add i64 %t263, %t266
  %t268 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 1
  %t269 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d44, i32 0, i32 1) }, 0
  %t270 = add i64 %t267, %t269
  %t271 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t270)
  call void @olang_textcopy(ptr %t271, ptr %t255, i64 %t256)
  %t272 = getelementptr i8, ptr %t271, i64 %t256
  call void @olang_textcopy(ptr %t272, ptr %t258, i64 %t259)
  %t273 = getelementptr i8, ptr %t272, i64 %t259
  call void @olang_textcopy(ptr %t273, ptr %t261, i64 %t262)
  %t274 = getelementptr i8, ptr %t273, i64 %t262
  call void @olang_textcopy(ptr %t274, ptr %t265, i64 %t266)
  %t275 = getelementptr i8, ptr %t274, i64 %t266
  call void @olang_textcopy(ptr %t275, ptr %t268, i64 %t269)
  %t276 = insertvalue { i64, ptr } undef, i64 %t270, 0
  %t277 = insertvalue { i64, ptr } %t276, ptr %t271, 1
  %t279 = extractvalue { i64, ptr } %t277, 0
  %t280 = extractvalue { i64, ptr } %t277, 1
  %t281 = mul i64 %t279, 1
  %t282 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t281)
  call void @llvm.memcpy.p0.p0.i64(ptr %t282, ptr %t280, i64 %t281, i1 false)
  %t283 = insertvalue { i64, ptr } undef, i64 %t279, 0
  %t284 = insertvalue { i64, ptr } %t283, ptr %t282, 1
  call void @compiler_2fprofile_2esay(ptr %s11, { i64, ptr } %t284)
  br label %bb45
bb45:
  %t286 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t286, ptr %rv
  br label %ret
bb46:
  %t288 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t292 = call { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t288)
  %t293 = extractvalue { i32, %"compiler/profile:Profile" } %t292, 1
  %t294 = extractvalue { i32, %"compiler/profile:Profile" } %t292, 0
  store i32 %t294, ptr %l105
  %t295 = icmp ne i32 %t294, 0
  br i1 %t295, label %bb48, label %ok.296, !prof !99
ok.296:
  store %"compiler/profile:Profile" %t293, ptr %l104
  br label %bb47
bb47:
  %t297 = load %"compiler/profile:Profile", ptr %l104
  store %"compiler/profile:Profile" %t297, ptr %l101
  br label %bb51
bb48:
  %t298 = load i32, ptr %l105, !tbaa !23
  %t299 = ashr i32 %t298, 16
  %t301 = icmp eq i32 %t299, 1
  store i1 %t301, ptr %l107, !tbaa !21
  br label %bb49
bb49:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t302 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t303 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, 1
  %t304 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d45, i32 0, i32 1) }, 0
  %t306 = extractvalue { i64, ptr } %t302, 1
  %t307 = extractvalue { i64, ptr } %t302, 0
  %t308 = add i64 %t304, %t307
  %t309 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d46, i32 0, i32 1) }, 1
  %t310 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d46, i32 0, i32 1) }, 0
  %t311 = add i64 %t308, %t310
  %t312 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t311)
  call void @olang_textcopy(ptr %t312, ptr %t303, i64 %t304)
  %t313 = getelementptr i8, ptr %t312, i64 %t304
  call void @olang_textcopy(ptr %t313, ptr %t306, i64 %t307)
  %t314 = getelementptr i8, ptr %t313, i64 %t307
  call void @olang_textcopy(ptr %t314, ptr %t309, i64 %t310)
  %t315 = insertvalue { i64, ptr } undef, i64 %t311, 0
  %t316 = insertvalue { i64, ptr } %t315, ptr %t312, 1
  %t318 = extractvalue { i64, ptr } %t316, 0
  %t319 = extractvalue { i64, ptr } %t316, 1
  %t320 = mul i64 %t318, 1
  %t321 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t320)
  call void @llvm.memcpy.p0.p0.i64(ptr %t321, ptr %t319, i64 %t320, i1 false)
  %t322 = insertvalue { i64, ptr } undef, i64 %t318, 0
  %t323 = insertvalue { i64, ptr } %t322, ptr %t321, 1
  call void @compiler_2fprofile_2esay(ptr %s13, { i64, ptr } %t323)
  br label %bb50
bb50:
  %t325 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t325, ptr %rv
  br label %ret
bb51:
  %t327 = load %"compiler/profile:Profile", ptr %l101
  store %"compiler/profile:Profile" %t327, ptr %l12
  %t328 = call { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %s0)
  store { i64, ptr } %t328, ptr %l112
  br label %bb52
bb52:
  %t329 = load { i64, ptr }, ptr %l112, !tbaa !27
  store { i64, ptr } %t329, ptr %l13, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t333 = call %"compiler/profile:Places" @compiler_2fprofile_2eResolve(ptr %s0, ptr %s0, ptr %s0, ptr %l12, { i64, ptr } %t330)
  store %"compiler/profile:Places" %t333, ptr %l115
  br label %bb53
bb53:
  %t334 = load %"compiler/profile:Places", ptr %l115
  store %"compiler/profile:Places" %t334, ptr %l14
  %t335 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t339 = call { i64, ptr } @compiler_2fprofile_2eReport(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t335, ptr %l12, ptr %l14)
  store { i64, ptr } %t339, ptr %l119
  br label %bb54
bb54:
  %t340 = load { i64, ptr }, ptr %l119, !tbaa !27
  %t341 = extractvalue { i64, ptr } %t340, 0
  %t342 = extractvalue { i64, ptr } %t340, 1
  %t343 = mul i64 %t341, 1
  %t344 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t343)
  call void @llvm.memcpy.p0.p0.i64(ptr %t344, ptr %t342, i64 %t343, i1 false)
  %t345 = insertvalue { i64, ptr } undef, i64 %t341, 0
  %t346 = insertvalue { i64, ptr } %t345, ptr %t344, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t346)
  br label %bb55
bb55:
  %t348 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t350 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t348, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d47, i32 0, i32 1) })
  store i1 %t350, ptr %l122
  br label %bb56
bb56:
  %t351 = load i1, ptr %l122, !tbaa !21
  br i1 %t351, label %bb57, label %bb58
bb57:
  store %olang.scope zeroinitializer, ptr %s15
  call void @compiler_2fprofile_2esay(ptr %s15, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d48, i32 0, i32 1) })
  br label %bb59
bb58:
  br label %bb60
bb59:
  call void @__olang_scope_close(ptr %s15)
  br label %bb60
bb60:
  %t352 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t352, ptr %l123, !tbaa !27
  %t353 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t357 = call { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t353, ptr %l12, ptr %l14)
  store { i64, ptr } %t357, ptr %l127
  br label %bb61
bb61:
  %t358 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t360 = extractvalue { i64, ptr } %t358, 0
  %t361 = extractvalue { i64, ptr } %t358, 1
  %t362 = mul i64 %t360, 1
  %t363 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t362)
  call void @llvm.memcpy.p0.p0.i64(ptr %t363, ptr %t361, i64 %t362, i1 false)
  %t364 = insertvalue { i64, ptr } undef, i64 %t360, 0
  %t365 = insertvalue { i64, ptr } %t364, ptr %t363, 1
  %t366 = load { i64, ptr }, ptr %l123, !tbaa !27
  %t368 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t366, { i64, ptr } %t365)
  store i32 %t368, ptr %l130
  %t369 = icmp ne i32 %t368, 0
  br i1 %t369, label %bb63, label %ok.370, !prof !99
ok.370:
  br label %bb62
bb62:
  br label %bb66
bb63:
  %t371 = load i32, ptr %l130, !tbaa !23
  %t372 = ashr i32 %t371, 16
  %t374 = icmp eq i32 %t372, 1
  store i1 %t374, ptr %l132, !tbaa !21
  br label %bb64
bb64:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s16
  %t375 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t376 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t377 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t379 = extractvalue { i64, ptr } %t375, 1
  %t380 = extractvalue { i64, ptr } %t375, 0
  %t381 = add i64 %t377, %t380
  %t382 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t383 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t384 = add i64 %t381, %t383
  %t385 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t376, i64 %t377)
  %t386 = getelementptr i8, ptr %t385, i64 %t377
  call void @olang_textcopy(ptr %t386, ptr %t379, i64 %t380)
  %t387 = getelementptr i8, ptr %t386, i64 %t380
  call void @olang_textcopy(ptr %t387, ptr %t382, i64 %t383)
  %t388 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t389 = insertvalue { i64, ptr } %t388, ptr %t385, 1
  %t391 = extractvalue { i64, ptr } %t389, 0
  %t392 = extractvalue { i64, ptr } %t389, 1
  %t393 = mul i64 %t391, 1
  %t394 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t393)
  call void @llvm.memcpy.p0.p0.i64(ptr %t394, ptr %t392, i64 %t393, i1 false)
  %t395 = insertvalue { i64, ptr } undef, i64 %t391, 0
  %t396 = insertvalue { i64, ptr } %t395, ptr %t394, 1
  call void @compiler_2fprofile_2esay(ptr %s16, { i64, ptr } %t396)
  br label %bb65
bb65:
  %t398 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t398, ptr %rv
  br label %ret
bb66:
  %t400 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t402 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t400)
  store { i64, ptr } %t402, ptr %l138
  br label %bb67
bb67:
  %t403 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t404 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t405 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t406 = extractvalue { i64, ptr } %t405, 1
  %t407 = extractvalue { i64, ptr } %t405, 0
  %t408 = add i64 %t404, %t407
  %t409 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 1
  %t410 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) }, 0
  %t411 = add i64 %t408, %t410
  %t412 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t411)
  call void @olang_textcopy(ptr %t412, ptr %t403, i64 %t404)
  %t413 = getelementptr i8, ptr %t412, i64 %t404
  call void @olang_textcopy(ptr %t413, ptr %t406, i64 %t407)
  %t414 = getelementptr i8, ptr %t413, i64 %t407
  call void @olang_textcopy(ptr %t414, ptr %t409, i64 %t410)
  %t415 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t412, 1
  %t418 = extractvalue { i64, ptr } %t416, 0
  %t419 = extractvalue { i64, ptr } %t416, 1
  %t420 = mul i64 %t418, 1
  %t421 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t420)
  call void @llvm.memcpy.p0.p0.i64(ptr %t421, ptr %t419, i64 %t420, i1 false)
  %t422 = insertvalue { i64, ptr } undef, i64 %t418, 0
  %t423 = insertvalue { i64, ptr } %t422, ptr %t421, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t423)
  br label %bb68
bb68:
  %t425 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t425, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

declare void @__olang_ert_req_clear()
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d11 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_test" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": native compilation failed" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"== " }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ==" }>, align 8
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"36" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d25 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c": the tests ended by a signal (" }>, align 8
@.d26 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d27 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d28 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d30 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/profile" }>, align 8
@.d33 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"its profile's directory " }>, align 8
@.d34 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot be made" }>, align 8
@.d35 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d36 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d37 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".samples" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d40 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d41 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d42 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d43 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" wrote no profile - it ended by a signal (" }>, align 8
@.d44 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d45 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d46 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is not a profile this compiler writes\0A" }>, align 8
@.d47 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d48 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"olang profile: no llvm-symbolizer found beside clang or on PATH - functions named by their addresses\0A" }>, align 8
@.d49 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d50 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be written\0A" }>, align 8
@.d51 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"flame graph: " }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
declare %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_251e830707558b33_b2bdace7e2a71047 = external constant [0 x i8]
declare void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_44996bcc7c9bda8_515f8c8db8b0565c = external constant [0 x i8]
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eFix = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@G_2ecompiler_2folang_2eBindgen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eProfile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2eFinish(ptr %v0, ptr %a0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2308270aeb54ce5f_1121c256bef46e33 = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0)
declare %"compiler/profile:Places" @compiler_2fprofile_2eResolve(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
