; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64, ptr }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.slotscope = type { %olang.scope, i64, [8 x ptr] }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" = type { { i64, ptr }, i64, i64 }
%"compiler/diagmsg:Msg" = type { i32, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, { i64, ptr }, i64, i1, i1, i1, i64, i1, { i64, ptr }, i1, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"compiler/build:Listed" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i1, i1, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" }
%"compiler/listing:Inputs" = type { ptr, ptr, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr }, { i64, ptr }, i1, { i64, ptr }, i1, { i64, ptr }, i1, i1, i1 }
%"compiler/profile:Profile" = type { i64, i64, i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", { i64, ptr } }
%"compiler/profile:Places" = type { %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" }
%"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i64, i64 }
%"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" = type { { i64, ptr }, { i64, ptr } }
%"compiler/build:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
%"compiler/emit:Reused" = type { i64, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64, i1, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", i64 }
%"compiler/explain:Code" = type { { i64, ptr }, { i64, ptr }, i64, { i64, ptr } }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp6 = alloca ptr
  %l7 = alloca %"compiler/build:Program"
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i32
  %l31 = alloca i32
  %l33 = alloca i1
  %l35 = alloca i32
  %l36 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l40 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca i32
  %l43 = alloca i1
  %l45 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i32
  %l80 = alloca i1
  %l81 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/diagmsg:Msg"
  %l86 = alloca i32
  %l92 = alloca ptr
  %l95 = alloca i1
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  %t179 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l7, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l7, i64 264, i1 false)
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %v3, ptr %a0, { i64, ptr } %t3, i32 1, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l14
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t21)
  store i32 %t23, ptr %l18
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l19
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l18, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l21
  br label %bb13
bb13:
  %t30 = load i64, ptr %l21, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l25
  br label %bb16
bb16:
  %t36 = load i64, ptr %l25, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l23, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t40)
  store i32 %t42, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l28, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l31
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l31, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l33, !tbaa !21
  br label %bb24
bb24:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t55)
  store i32 %t57, ptr %l35
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l35, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v3, ptr %v3, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l41
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l40
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l40
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l36
  br label %bb31
bb28:
  %t70 = load i32, ptr %l41, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l43, !tbaa !21
  br label %bb29
bb29:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t74)
  store i32 %t76, ptr %l45
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l45, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l36
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb32
bb32:
  %t79 = load ptr, ptr %l1, !tbaa !29
  %t81 = getelementptr %"compiler/build:Config", ptr %t79, i32 0, i32 9
  %t82 = load i1, ptr %t81, !tbaa !21
  br i1 %t82, label %bb33, label %bb34
bb33:
  %t84 = load ptr, ptr %l1, !tbaa !29
  %t85 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t86 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v1, ptr %s0, ptr %v3, ptr %v2, ptr %v3, ptr %t84, ptr %l4, ptr %l5, { i64, ptr } %t85, ptr %t86)
  store i32 %t92, ptr %l53
  br label %bb35
bb34:
  br label %bb36
bb35:
  call void @__olang_scope_close(ptr %s0)
  %t93 = load i32, ptr %l53, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb36:
  %t94 = load ptr, ptr %l1, !tbaa !29
  %t96 = getelementptr %"compiler/build:Config", ptr %t94, i32 0, i32 29
  %t97 = load { i64, ptr }, ptr %t96, !tbaa !27
  %t99 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t97, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t99, ptr %l56
  br label %bb37
bb37:
  %t100 = load i1, ptr %l56, !tbaa !21
  %t101 = xor i1 %t100, true
  br i1 %t101, label %bb38, label %bb39
bb38:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t105 = getelementptr %"compiler/build:Config", ptr %t103, i32 0, i32 29
  %t106 = load { i64, ptr }, ptr %t105, !tbaa !27
  %t108 = extractvalue { i64, ptr } %t106, 1
  %t109 = extractvalue { i64, ptr } %t106, 0
  %t110 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t109)
  call void @olang_textcopy(ptr %t110, ptr %t108, i64 %t109)
  %t111 = insertvalue { i64, ptr } undef, i64 %t109, 0
  %t112 = insertvalue { i64, ptr } %t111, ptr %t110, 1
  store { i64, ptr } %t112, ptr %l58, !tbaa !27
  br label %bb43
bb39:
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 0
  %t117 = load { i64, ptr }, ptr %t116, !tbaa !27
  store { i64, ptr } %t117, ptr %l63, !tbaa !27
  %t119 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t119, ptr %l65
  br label %bb40
bb40:
  %t120 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t121 = extractvalue { i64, ptr } %t120, 0
  %t122 = extractvalue { i64, ptr } %t120, 1
  %t123 = mul i64 %t121, 1
  %t124 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t123)
  call void @llvm.memcpy.p0.p0.i64(ptr %t124, ptr %t122, i64 %t123, i1 false)
  %t125 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t126 = insertvalue { i64, ptr } %t125, ptr %t124, 1
  %t128 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t126)
  store { i64, ptr } %t128, ptr %l67
  br label %bb41
bb41:
  %t129 = load ptr, ptr %l1, !tbaa !29
  %t131 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t129)
  store { i64, ptr } %t131, ptr %l69
  br label %bb42
bb42:
  %t132 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t133 = extractvalue { i64, ptr } %t132, 1
  %t134 = extractvalue { i64, ptr } %t132, 0
  %t135 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t136 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t137 = add i64 %t134, %t136
  %t138 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t139 = extractvalue { i64, ptr } %t138, 1
  %t140 = extractvalue { i64, ptr } %t138, 0
  %t141 = add i64 %t137, %t140
  %t142 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t143 = extractvalue { i64, ptr } %t142, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = add i64 %t141, %t144
  %t146 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t145)
  call void @olang_textcopy(ptr %t146, ptr %t133, i64 %t134)
  %t147 = getelementptr i8, ptr %t146, i64 %t134
  call void @olang_textcopy(ptr %t147, ptr %t135, i64 %t136)
  %t148 = getelementptr i8, ptr %t147, i64 %t136
  call void @olang_textcopy(ptr %t148, ptr %t139, i64 %t140)
  %t149 = getelementptr i8, ptr %t148, i64 %t140
  call void @olang_textcopy(ptr %t149, ptr %t143, i64 %t144)
  %t150 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t146, 1
  store { i64, ptr } %t151, ptr %l58, !tbaa !27
  br label %bb43
bb43:
  %t153 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 16, i64 8)
  store ptr %t153, ptr %lp6
  %t154 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t155 = load ptr, ptr %lp6
  store { i64, ptr } %t154, ptr %t155, !tbaa !27
  %t156 = load ptr, ptr %l1, !tbaa !29
  store ptr %t156, ptr %l71, !tbaa !29
  store ptr %l5, ptr %l72, !tbaa !29
  %t157 = load ptr, ptr %lp6
  %t158 = load { i64, ptr }, ptr %t157, !tbaa !27
  store { i64, ptr } %t158, ptr %l73, !tbaa !27
  %t159 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t160, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t162, ptr %l75
  br label %bb44
bb44:
  %t163 = load i1, ptr %l75, !tbaa !21
  %t164 = xor i1 %t163, true
  %t165 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 3
  %t166 = load ptr, ptr %l71, !tbaa !29
  %t167 = load ptr, ptr %l72, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t171 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %v3, ptr %v1, ptr %s0, ptr %s0, ptr %t166, ptr %t167, { i64, ptr } %t168, i1 %t164, ptr %t165, ptr null)
  store i32 %t171, ptr %l78
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb46, label %ok.173, !prof !99
ok.173:
  br label %bb45
bb45:
  br label %bb51
bb46:
  %t174 = load i32, ptr %l78, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  store i1 %t177, ptr %l80, !tbaa !21
  br label %bb47
bb47:
  %t178 = load ptr, ptr %l3, !tbaa !29
  store ptr %t178, ptr %l81, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t179
  %t180 = getelementptr { i64, [3 x i64] }, ptr %t179, i32 0, i32 0
  store i64 0, ptr %t180
  %t181 = load { i64, [3 x i64] }, ptr %t179
  store { i64, [3 x i64] } %t181, ptr %l82
  %t182 = load ptr, ptr %lp6
  %t183 = load { i64, ptr }, ptr %t182, !tbaa !27
  %t185 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v1, ptr %v3, { i64, ptr } %t183)
  store %"compiler/diagmsg:Msg" %t185, ptr %l84
  br label %bb48
bb48:
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load { i64, [3 x i64] }, ptr %l82
  %t188 = load %"compiler/diagmsg:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v3, ptr %v3, ptr %t186, { i64, [3 x i64] } %t187, %"compiler/diagmsg:Msg" %t188)
  br label %bb49
bb49:
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t191 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t189)
  store i32 %t191, ptr %l86
  br label %bb50
bb50:
  call void @__olang_scope_close(ptr %s0)
  %t192 = load i32, ptr %l86, !tbaa !23
  store i32 %t192, ptr %rv
  br label %ret
bb51:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb52
bb52:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t194 = load ptr, ptr %lp6
  %t195 = load { i64, ptr }, ptr %t194, !tbaa !27
  %t198 = getelementptr %"compiler/build:Config", ptr %t193, i32 0, i32 30
  store { i64, ptr } %t195, ptr %t198, !tbaa !27
  call void @compiler_2fspin_2eEnd()
  br label %bb53
bb53:
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/build:Config", ptr %t199, i32 0, i32 28
  %t202 = load i1, ptr %t201, !tbaa !21
  %t204 = xor i1 %t202, true
  br i1 %t204, label %bb54, label %bb55
bb54:
  store %olang.scope zeroinitializer, ptr %s10
  %t206 = load ptr, ptr %l1, !tbaa !29
  store ptr %t206, ptr %l92, !tbaa !29
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/build:Config", ptr %t207, i32 0, i32 29
  %t210 = load { i64, ptr }, ptr %t209, !tbaa !27
  %t212 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s10, { i64, ptr } %t210, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t212, ptr %l95
  br label %bb56
bb55:
  br label %bb63
bb56:
  %t213 = load i1, ptr %l95, !tbaa !21
  %t214 = xor i1 %t213, true
  br i1 %t214, label %bb57, label %bb58
bb57:
  %t216 = load ptr, ptr %lp6
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  store { i64, ptr } %t217, ptr %l97, !tbaa !27
  br label %bb60
bb58:
  %t219 = load ptr, ptr %lp6
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !27
  %t222 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s10, { i64, ptr } %t220)
  store { i64, ptr } %t222, ptr %l100
  br label %bb59
bb59:
  %t223 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t223, ptr %l97, !tbaa !27
  br label %bb60
bb60:
  %t224 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t225 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t226 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t227 = extractvalue { i64, ptr } %t226, 1
  %t228 = extractvalue { i64, ptr } %t226, 0
  %t229 = add i64 %t225, %t228
  %t230 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t229)
  call void @olang_textcopy(ptr %t230, ptr %t224, i64 %t225)
  %t231 = getelementptr i8, ptr %t230, i64 %t225
  call void @olang_textcopy(ptr %t231, ptr %t227, i64 %t228)
  %t232 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t233 = insertvalue { i64, ptr } %t232, ptr %t230, 1
  %t235 = extractvalue { i64, ptr } %t233, 0
  %t236 = extractvalue { i64, ptr } %t233, 1
  %t237 = mul i64 %t235, 1
  %t238 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t237)
  call void @llvm.memcpy.p0.p0.i64(ptr %t238, ptr %t236, i64 %t237, i1 false)
  %t239 = insertvalue { i64, ptr } undef, i64 %t235, 0
  %t240 = insertvalue { i64, ptr } %t239, ptr %t238, 1
  %t241 = load ptr, ptr %l92, !tbaa !29
  %t243 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t241, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } %t240)
  store { i64, ptr } %t243, ptr %l103
  br label %bb61
bb61:
  %t244 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t250)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l34 = alloca i1
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l41 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l42 = alloca i32
  %l44 = alloca i1
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l58 = alloca i1
  %l61 = alloca { i64, ptr }
  %l62 = alloca %"compiler/diagmsg:Msg"
  %l65 = alloca i32
  %l70 = alloca i32
  %l72 = alloca i1
  %l76 = alloca { i64, ptr }
  %l77 = alloca %"compiler/diagmsg:Msg"
  %l80 = alloca i32
  %l90 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %rv = alloca i32
  %t1 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t1, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %t1, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l8, i64 264, i1 false)
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %v3, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t4, ptr %l4, ptr %t5)
  store i32 %t12, ptr %l15
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb3, label %ok.14, !prof !99
ok.14:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t15 = load i32, ptr %l15, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t18 = load i32, ptr %l15, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb7, label %bb8
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t23 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t21)
  store i32 %t23, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  %t24 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t24, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t25 = load i32, ptr %l19, !tbaa !23
  store i32 %t25, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l20, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb12:
  %t27 = load ptr, ptr %l3, !tbaa !29
  %t29 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t27)
  store i64 %t29, ptr %l22
  br label %bb13
bb13:
  %t30 = load i64, ptr %l22, !tbaa !24
  %t31 = icmp sgt i64 %t30, 0
  br i1 %t31, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t33 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t35 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t33)
  store i64 %t35, ptr %l26
  br label %bb16
bb16:
  %t36 = load i64, ptr %l26, !tbaa !24
  %t37 = icmp eq i64 %t36, 0
  store i1 %t37, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t39 = load i1, ptr %l24, !tbaa !21
  br i1 %t39, label %bb18, label %bb19
bb18:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t42 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t40)
  store i32 %t42, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t43 = load i32, ptr %l29, !tbaa !23
  store i32 %t43, ptr %rv
  br label %ret
bb21:
  %t44 = load ptr, ptr %l1, !tbaa !29
  %t45 = load ptr, ptr %l3, !tbaa !29
  %t48 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v3, ptr %t44, ptr %t45)
  store i32 %t48, ptr %l32
  %t49 = icmp ne i32 %t48, 0
  br i1 %t49, label %bb23, label %ok.50, !prof !99
ok.50:
  br label %bb22
bb22:
  br label %bb26
bb23:
  %t51 = load i32, ptr %l32, !tbaa !23
  %t52 = ashr i32 %t51, 16
  %t54 = icmp eq i32 %t52, 1
  store i1 %t54, ptr %l34, !tbaa !21
  br label %bb24
bb24:
  %t55 = load ptr, ptr %l3, !tbaa !29
  %t57 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t55)
  store i32 %t57, ptr %l36
  br label %bb25
bb25:
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l36, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb26:
  %t59 = load ptr, ptr %l1, !tbaa !29
  %t60 = load ptr, ptr %l3, !tbaa !29
  %t64 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v3, ptr %v3, ptr %t59, ptr %l4, ptr %t60)
  %t65 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 1
  %t66 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t64, 0
  store i32 %t66, ptr %l42
  %t67 = icmp ne i32 %t66, 0
  br i1 %t67, label %bb28, label %ok.68, !prof !99
ok.68:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t65, ptr %l41
  br label %bb27
bb27:
  %t69 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l41
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t69, ptr %l37
  br label %bb31
bb28:
  %t70 = load i32, ptr %l42, !tbaa !23
  %t71 = ashr i32 %t70, 16
  %t73 = icmp eq i32 %t71, 1
  store i1 %t73, ptr %l44, !tbaa !21
  br label %bb29
bb29:
  %t74 = load ptr, ptr %l3, !tbaa !29
  %t76 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t74)
  store i32 %t76, ptr %l46
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s0)
  %t77 = load i32, ptr %l46, !tbaa !23
  store i32 %t77, ptr %rv
  br label %ret
bb31:
  %t78 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l37
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t78, ptr %l5
  %t80 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v3, ptr %v3, ptr %l5, i64 0)
  store { i64, ptr } %t80, ptr %l48
  br label %bb32
bb32:
  %t81 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t81, ptr %l6, !tbaa !27
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 29
  %t85 = load { i64, ptr }, ptr %t84, !tbaa !27
  %t87 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t85, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t87, ptr %l51
  br label %bb33
bb33:
  %t88 = load i1, ptr %l51, !tbaa !21
  %t89 = xor i1 %t88, true
  br i1 %t89, label %bb34, label %bb35
bb34:
  store %olang.scope zeroinitializer, ptr %s6
  %t91 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t93 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v3, ptr %s6, { i64, ptr } %t91)
  %t94 = extractvalue { i32, { i64, ptr } } %t93, 1
  %t95 = extractvalue { i32, { i64, ptr } } %t93, 0
  store i32 %t95, ptr %l56
  %t96 = icmp ne i32 %t95, 0
  br i1 %t96, label %bb37, label %ok.97, !prof !99
ok.97:
  store { i64, ptr } %t94, ptr %l55
  br label %bb36
bb35:
  br label %bb54
bb36:
  %t98 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t98, ptr %l53, !tbaa !27
  br label %bb44
bb37:
  %t99 = load i32, ptr %l56, !tbaa !23
  %t100 = ashr i32 %t99, 16
  %t102 = icmp eq i32 %t100, 1
  store i1 %t102, ptr %l58, !tbaa !21
  %t103 = load i32, ptr %l56, !tbaa !23
  %t104 = ashr i32 %t103, 16
  %t106 = icmp eq i32 %t104, 1
  br i1 %t106, label %bb38, label %bb39
bb38:
  call void @__olang_errpay_pop()
  br label %bb39
bb39:
  br label %bb40
bb40:
  %t108 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t108, ptr %l61, !tbaa !27
  %t109 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t109, ptr %l62
  br label %bb41
bb41:
  %t110 = load ptr, ptr %l3, !tbaa !29
  %t111 = load { i64, ptr }, ptr %l61, !tbaa !27
  %t112 = load %"compiler/diagmsg:Msg", ptr %l62
  call void @compiler_2fbuild_2efileFatal(ptr %v3, ptr %v3, ptr %v3, { i64, ptr } %t111, %"compiler/diagmsg:Msg" %t112, ptr %t110)
  br label %bb42
bb42:
  %t114 = load ptr, ptr %l3, !tbaa !29
  %t116 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t114)
  store i32 %t116, ptr %l65
  br label %bb43
bb43:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t117 = load i32, ptr %l65, !tbaa !23
  store i32 %t117, ptr %rv
  br label %ret
bb44:
  %t118 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t121 = getelementptr %"compiler/build:Config", ptr %t119, i32 0, i32 29
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t127 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t122, { i64, ptr } %t118)
  store i32 %t127, ptr %l70
  %t128 = icmp ne i32 %t127, 0
  br i1 %t128, label %bb46, label %ok.129, !prof !99
ok.129:
  br label %bb45
bb45:
  br label %bb53
bb46:
  %t130 = load i32, ptr %l70, !tbaa !23
  %t131 = ashr i32 %t130, 16
  %t133 = icmp eq i32 %t131, 1
  store i1 %t133, ptr %l72, !tbaa !21
  %t134 = load i32, ptr %l70, !tbaa !23
  %t135 = ashr i32 %t134, 16
  %t137 = icmp eq i32 %t135, 1
  br i1 %t137, label %bb47, label %bb48
bb47:
  call void @__olang_errpay_pop()
  br label %bb48
bb48:
  br label %bb49
bb49:
  %t139 = load ptr, ptr %l1, !tbaa !29
  %t141 = getelementptr %"compiler/build:Config", ptr %t139, i32 0, i32 29
  %t142 = load { i64, ptr }, ptr %t141, !tbaa !27
  store { i64, ptr } %t142, ptr %l76, !tbaa !27
  %t143 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v3)
  store %"compiler/diagmsg:Msg" %t143, ptr %l77
  br label %bb50
bb50:
  %t144 = load ptr, ptr %l3, !tbaa !29
  %t145 = load { i64, ptr }, ptr %l76, !tbaa !27
  %t146 = load %"compiler/diagmsg:Msg", ptr %l77
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %v3, ptr %v3, { i64, ptr } %t145, %"compiler/diagmsg:Msg" %t146, ptr %t144)
  br label %bb51
bb51:
  %t148 = load ptr, ptr %l3, !tbaa !29
  %t150 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t148)
  store i32 %t150, ptr %l80
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t151 = load i32, ptr %l80, !tbaa !23
  store i32 %t151, ptr %rv
  br label %ret
bb53:
  %t152 = load ptr, ptr %l1, !tbaa !29
  %t154 = getelementptr %"compiler/build:Config", ptr %t152, i32 0, i32 29
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  store { i64, ptr } %t155, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb54
bb54:
  call void @compiler_2fspin_2eEnd()
  br label %bb55
bb55:
  %t157 = load ptr, ptr %l1, !tbaa !29
  %t159 = getelementptr %"compiler/build:Config", ptr %t157, i32 0, i32 28
  %t160 = load i1, ptr %t159, !tbaa !21
  %t162 = xor i1 %t160, true
  br i1 %t162, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t164 = load ptr, ptr %l1, !tbaa !29
  %t165 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t166 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t167 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t169 = extractvalue { i64, ptr } %t165, 1
  %t170 = extractvalue { i64, ptr } %t165, 0
  %t171 = add i64 %t167, %t170
  %t172 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t171)
  call void @olang_textcopy(ptr %t172, ptr %t166, i64 %t167)
  %t173 = getelementptr i8, ptr %t172, i64 %t167
  call void @olang_textcopy(ptr %t173, ptr %t169, i64 %t170)
  %t174 = insertvalue { i64, ptr } undef, i64 %t171, 0
  %t175 = insertvalue { i64, ptr } %t174, ptr %t172, 1
  %t177 = extractvalue { i64, ptr } %t175, 0
  %t178 = extractvalue { i64, ptr } %t175, 1
  %t179 = mul i64 %t177, 1
  %t180 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t179)
  call void @llvm.memcpy.p0.p0.i64(ptr %t180, ptr %t178, i64 %t179, i1 false)
  %t181 = insertvalue { i64, ptr } undef, i64 %t177, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  %t185 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s9, ptr %s9, ptr %s9, ptr %t164, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t182)
  store { i64, ptr } %t185, ptr %l90
  br label %bb58
bb57:
  br label %bb60
bb58:
  %t186 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  call void @compiler_2fbuild_2esayln(ptr %s9, { i64, ptr } %t192)
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s9)
  br label %bb60
bb60:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v4, ptr %s0, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l13
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15, !prof !99
ok.15:
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  br label %bb11
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_251e830707558b33_b2bdace7e2a71047)
  unreachable
bb8:
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l18
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t29)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca %"std/os:FileInfo"
  %l6 = alloca i32
  %l7 = alloca %"std/os:FileInfo"
  %l9 = alloca %"std/os:FileInfo"
  %l10 = alloca i32
  %l12 = alloca i1
  %l15 = alloca ptr
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"compiler/diagmsg:Msg"
  %l19 = alloca i32
  %l22 = alloca ptr
  %l23 = alloca { i64, ptr }
  %l24 = alloca %"compiler/diagmsg:Msg"
  %l26 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca %"compiler/diagmsg:Msg"
  %l34 = alloca i32
  %l35 = alloca i32
  %l41 = alloca i32
  %l42 = alloca i32
  %l48 = alloca i32
  %l49 = alloca i32
  %l52 = alloca i1
  %l60 = alloca { i64, ptr }
  %l65 = alloca i32
  %s6 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l10
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7, !prof !99
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l9
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l9
  store %"std/os:FileInfo" %t8, ptr %l7
  br label %bb8
bb2:
  %t9 = load i32, ptr %l10, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  store i1 %t12, ptr %l12, !tbaa !21
  %t13 = load i32, ptr %l10, !tbaa !23
  %t14 = ashr i32 %t13, 16
  %t16 = icmp eq i32 %t14, 1
  br i1 %t16, label %bb3, label %bb4
bb3:
  call void @__olang_errpay_pop()
  br label %bb4
bb4:
  br label %bb5
bb5:
  %t18 = load ptr, ptr %l1, !tbaa !29
  store ptr %t18, ptr %l15, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t19, ptr %l16, !tbaa !27
  %t20 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t20, ptr %l17
  br label %bb6
bb6:
  %t21 = load ptr, ptr %l3, !tbaa !29
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t24 = load %"compiler/diagmsg:Msg", ptr %l17
  %t26 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t22, { i64, ptr } %t23, %"compiler/diagmsg:Msg" %t24, ptr %t21)
  store i32 %t26, ptr %l19
  br label %bb7
bb7:
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb8:
  %t28 = load %"std/os:FileInfo", ptr %l7
  store %"std/os:FileInfo" %t28, ptr %l5
  %t29 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t30 = load i32, ptr %t29, !range !{i32 0, i32 3}
  %t32 = trunc i64 1 to i32
  %t33 = icmp eq i32 %t30, %t32
  br i1 %t33, label %bb9, label %bb10
bb9:
  %t35 = load ptr, ptr %l1, !tbaa !29
  store ptr %t35, ptr %l22, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t36, ptr %l23, !tbaa !27
  %t37 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v3)
  store %"compiler/diagmsg:Msg" %t37, ptr %l24
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t38 = load ptr, ptr %l3, !tbaa !29
  %t39 = load ptr, ptr %l22, !tbaa !29
  %t40 = load { i64, ptr }, ptr %l23, !tbaa !27
  %t41 = load %"compiler/diagmsg:Msg", ptr %l24
  %t43 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t39, { i64, ptr } %t40, %"compiler/diagmsg:Msg" %t41, ptr %t38)
  store i32 %t43, ptr %l26
  br label %bb12
bb12:
  %t44 = load i32, ptr %l26, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb13:
  %t45 = getelementptr %"std/os:FileInfo", ptr %l5, i32 0, i32 0
  %t46 = load i32, ptr %t45, !range !{i32 0, i32 3}
  %t48 = trunc i64 0 to i32
  %t49 = icmp eq i32 %t46, %t48
  %t51 = xor i1 %t49, true
  br i1 %t51, label %bb14, label %bb15
bb14:
  %t53 = load ptr, ptr %l1, !tbaa !29
  store ptr %t53, ptr %l30, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t54, ptr %l31, !tbaa !27
  %t55 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v3)
  store %"compiler/diagmsg:Msg" %t55, ptr %l32
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t56 = load ptr, ptr %l3, !tbaa !29
  %t57 = load ptr, ptr %l30, !tbaa !29
  %t58 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t59 = load %"compiler/diagmsg:Msg", ptr %l32
  %t61 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t57, { i64, ptr } %t58, %"compiler/diagmsg:Msg" %t59, ptr %t56)
  store i32 %t61, ptr %l34
  br label %bb17
bb17:
  %t62 = load i32, ptr %l34, !tbaa !23
  store i32 %t62, ptr %rv
  br label %ret
bb18:
  %t64 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t66 = load ptr, ptr %l1, !tbaa !29
  %t67 = load ptr, ptr %l3, !tbaa !29
  %t73 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v4, ptr %v1, ptr %v3, ptr %a0, { i64, ptr } %t64, { i64, ptr } %t65, ptr %t66, ptr %t67)
  %t74 = extractvalue { i32, i32 } %t73, 1
  %t75 = extractvalue { i32, i32 } %t73, 0
  store i32 %t75, ptr %l42
  %t76 = icmp ne i32 %t75, 0
  br i1 %t76, label %bb20, label %ok.77, !prof !99
ok.77:
  store i32 %t74, ptr %l41
  br label %bb19
bb19:
  %t78 = load i32, ptr %l41, !tbaa !23
  store i32 %t78, ptr %l35, !tbaa !23
  br label %bb29
bb20:
  %t79 = load i32, ptr %l42, !tbaa !23
  %t80 = icmp eq i32 %t79, 65536
  br i1 %t80, label %bb21, label %bb22
bb21:
  br label %bb23
bb22:
  %t82 = load i32, ptr %l42, !tbaa !23
  %t83 = icmp eq i32 %t82, 65537
  br i1 %t83, label %bb24, label %bb25
bb23:
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t86 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t87 = load ptr, ptr %l3, !tbaa !29
  %t91 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v3, ptr %t85, { i64, ptr } %t86, ptr %t87)
  store i32 %t91, ptr %l48
  br label %bb27
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_ac43697cc5f2dca0_4dfd3d6081b857d4)
  unreachable
bb26:
  %t92 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t92, ptr %l49
  br label %bb28
bb27:
  %t93 = load i32, ptr %l48, !tbaa !23
  store i32 %t93, ptr %rv
  br label %ret
bb28:
  %t94 = load i32, ptr %l49, !tbaa !23
  store i32 %t94, ptr %rv
  br label %ret
bb29:
  %t95 = load i32, ptr %l35, !tbaa !23
  store i32 %t95, ptr %l6, !tbaa !23
  %t96 = load i32, ptr %l6, !tbaa !23
  %t98 = icmp eq i32 %t96, 3
  br i1 %t98, label %bb30, label %bb31
bb30:
  %t100 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t102 = extractvalue { i64, ptr } %t100, 0
  %t104 = icmp sgt i64 %t102, 0
  store i1 %t104, ptr %l52, !tbaa !21
  br label %bb32
bb31:
  store i1 false, ptr %l52, !tbaa !21
  br label %bb32
bb32:
  %t106 = load i1, ptr %l52, !tbaa !21
  br i1 %t106, label %bb33, label %bb34
bb33:
  store %olang.scope zeroinitializer, ptr %s6
  %t107 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t109 = load ptr, ptr %l1, !tbaa !29
  %t111 = getelementptr %"compiler/build:Config", ptr %t109, i32 0, i32 23
  %t115 = call { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v2, ptr %v4, ptr %v1, ptr %s6, { i64, ptr } %t107, { i64, ptr } %t108, ptr %t111)
  store { i64, ptr } %t115, ptr %l60
  br label %bb35
bb34:
  br label %bb37
bb35:
  %t116 = load { i64, ptr }, ptr %l60, !tbaa !27
  %t117 = extractvalue { i64, ptr } %t116, 0
  %t118 = extractvalue { i64, ptr } %t116, 1
  %t119 = mul i64 %t117, 1
  %t120 = call ptr @__olang_scope_alloc(ptr %s6, i64 %t119)
  call void @llvm.memcpy.p0.p0.i64(ptr %t120, ptr %t118, i64 %t119, i1 false)
  %t121 = insertvalue { i64, ptr } undef, i64 %t117, 0
  %t122 = insertvalue { i64, ptr } %t121, ptr %t120, 1
  call void @compiler_2fbuild_2esayln(ptr %s6, { i64, ptr } %t122)
  br label %bb36
bb36:
  call void @__olang_scope_close(ptr %s6)
  store i32 3, ptr %rv
  br label %ret
bb37:
  %t125 = load i32, ptr %l6, !tbaa !23
  %t127 = icmp eq i32 %t125, 0
  br i1 %t127, label %bb38, label %bb39
bb38:
  store i32 0, ptr %l65, !tbaa !23
  br label %bb40
bb39:
  store i32 1, ptr %l65, !tbaa !23
  br label %bb40
bb40:
  %t129 = load i32, ptr %l65, !tbaa !23
  store i32 %t129, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l7 = alloca i64
  %l8 = alloca i32
  %l9 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l16 = alloca i32
  %l22 = alloca i32
  %l23 = alloca i32
  %l27 = alloca i32
  %l28 = alloca i32
  %l30 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l33 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l36 = alloca i32
  %l42 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l45 = alloca ptr
  %l46 = alloca { i64, ptr }
  %l47 = alloca { i64, ptr }
  %l48 = alloca i32
  %l51 = alloca ptr
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i64
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l68 = alloca i64
  %l73 = alloca i32
  %l78 = alloca { i64, ptr }
  %l87 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l91 = alloca { i64, ptr }
  %l94 = alloca i64
  %l95 = alloca i64
  %l106 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l115 = alloca i64
  %l117 = alloca i64
  %l120 = alloca i64
  %l121 = alloca i32
  %l125 = alloca i32
  %l127 = alloca i1
  %l130 = alloca ptr
  %l131 = alloca { i64, [3 x i64] }
  %l132 = alloca %"compiler/diagmsg:Msg"
  %l134 = alloca i32
  %s0 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %rv = alloca i32
  %t309 = alloca { i64, [3 x i64] }, align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 22
  %t4 = load i1, ptr %t3, !tbaa !21
  br i1 %t4, label %bb1, label %bb2
bb1:
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t7 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t8 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t10 = load ptr, ptr %l4, !tbaa !29
  %t16 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %v4, ptr %t6, { i64, ptr } %t7, { i64, ptr } %t8, ptr %t9, ptr %t10)
  %t17 = extractvalue { i32, i32 } %t16, 1
  %t18 = extractvalue { i32, i32 } %t16, 0
  store i32 %t18, ptr %l23
  %t19 = icmp ne i32 %t18, 0
  br i1 %t19, label %bb4, label %ok.20, !prof !99
ok.20:
  store i32 %t17, ptr %l22
  br label %bb3
bb2:
  br label %bb14
bb3:
  %t21 = load i32, ptr %l22, !tbaa !23
  store i32 %t21, ptr %l16, !tbaa !23
  br label %bb13
bb4:
  %t22 = load i32, ptr %l23, !tbaa !23
  %t23 = icmp eq i32 %t22, 65536
  br i1 %t23, label %bb5, label %bb6
bb5:
  br label %bb7
bb6:
  %t25 = load i32, ptr %l23, !tbaa !23
  %t26 = icmp eq i32 %t25, 65537
  br i1 %t26, label %bb8, label %bb9
bb7:
  %t28 = load ptr, ptr %l4, !tbaa !29
  %t30 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t28)
  store i32 %t30, ptr %l27
  br label %bb11
bb8:
  br label %bb10
bb9:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb10:
  %t31 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t31, ptr %l28
  br label %bb12
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t32 = load i32, ptr %l27, !tbaa !23
  store i32 %t32, ptr %rv
  br label %ret
bb12:
  call void @__olang_scope_close(ptr %s0)
  %t33 = load i32, ptr %l28, !tbaa !23
  store i32 %t33, ptr %rv
  br label %ret
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t34 = load i32, ptr %l16, !tbaa !23
  store i32 %t34, ptr %rv
  br label %ret
bb14:
  %t35 = load ptr, ptr %l1, !tbaa !29
  %t37 = getelementptr %"compiler/build:Config", ptr %t35, i32 0, i32 28
  store i1 true, ptr %t37, !tbaa !21
  %t38 = load ptr, ptr %l1, !tbaa !29
  store ptr %t38, ptr %l30, !tbaa !29
  %t39 = call { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v1, ptr %v1, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store { i64, ptr } %t39, ptr %l31
  br label %bb15
bb15:
  %t40 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t41 = extractvalue { i64, ptr } %t40, 0
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = mul i64 %t41, 1
  %t44 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t43)
  call void @llvm.memcpy.p0.p0.i64(ptr %t44, ptr %t42, i64 %t43, i1 false)
  %t45 = insertvalue { i64, ptr } undef, i64 %t41, 0
  %t46 = insertvalue { i64, ptr } %t45, ptr %t44, 1
  %t48 = load ptr, ptr %l30, !tbaa !29
  %t49 = getelementptr %"compiler/build:Config", ptr %t48, i32 0, i32 0
  store { i64, ptr } %t46, ptr %t49, !tbaa !27
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t52 = call { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v2, ptr %s0, { i64, ptr } %t50)
  %t53 = extractvalue { i32, { i64, ptr } } %t52, 1
  %t54 = extractvalue { i32, { i64, ptr } } %t52, 0
  store i32 %t54, ptr %l36
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb17, label %ok.56, !prof !99
ok.56:
  store { i64, ptr } %t53, ptr %l35
  br label %bb16
bb16:
  %t57 = load { i64, ptr }, ptr %l35, !tbaa !27
  store { i64, ptr } %t57, ptr %l33, !tbaa !27
  br label %bb21
bb17:
  %t58 = load i32, ptr %l36, !tbaa !23
  %t59 = ashr i32 %t58, 16
  %t61 = icmp eq i32 %t59, 1
  br i1 %t61, label %bb18, label %bb19
bb18:
  call void @__olang_errpay_pop()
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t63 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t63, 1
  %t66 = extractvalue { i64, ptr } %t63, 0
  %t67 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t66)
  call void @olang_textcopy(ptr %t67, ptr %t65, i64 %t66)
  %t68 = insertvalue { i64, ptr } undef, i64 %t66, 0
  %t69 = insertvalue { i64, ptr } %t68, ptr %t67, 1
  %t71 = extractvalue { i64, ptr } %t69, 0
  %t72 = extractvalue { i64, ptr } %t69, 1
  %t73 = mul i64 %t71, 1
  %t74 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t73)
  call void @llvm.memcpy.p0.p0.i64(ptr %t74, ptr %t72, i64 %t73, i1 false)
  %t75 = insertvalue { i64, ptr } undef, i64 %t71, 0
  %t76 = insertvalue { i64, ptr } %t75, ptr %t74, 1
  store { i64, ptr } %t76, ptr %l33, !tbaa !27
  br label %bb21
bb21:
  %t78 = load { i64, ptr }, ptr %l33, !tbaa !27
  store { i64, ptr } %t78, ptr %l5, !tbaa !27
  %t79 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t79, ptr %l42
  br label %bb22
bb22:
  %t80 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l42
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t80, ptr %l6
  %t81 = load { i64, ptr }, ptr %l5, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l6, { i64, ptr } %t81)
  br label %bb23
bb23:
  store ptr %l6, ptr %l45, !tbaa !29
  %t84 = call { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %s0)
  %t85 = extractvalue { i32, { i64, ptr } } %t84, 1
  %t86 = extractvalue { i32, { i64, ptr } } %t84, 0
  store i32 %t86, ptr %l48
  %t87 = icmp ne i32 %t86, 0
  br i1 %t87, label %bb25, label %ok.88, !prof !99
ok.88:
  store { i64, ptr } %t85, ptr %l47
  br label %bb24
bb24:
  %t89 = load { i64, ptr }, ptr %l47, !tbaa !27
  store { i64, ptr } %t89, ptr %l46, !tbaa !27
  br label %bb29
bb25:
  %t90 = load i32, ptr %l48, !tbaa !23
  %t91 = ashr i32 %t90, 16
  %t93 = icmp eq i32 %t91, 1
  br i1 %t93, label %bb26, label %bb27
bb26:
  call void @__olang_errpay_pop()
  br label %bb27
bb27:
  br label %bb28
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d12, i32 0, i32 1) }, ptr %l46, !tbaa !27
  br label %bb29
bb29:
  %t95 = load ptr, ptr %l45, !tbaa !29
  %t96 = load { i64, ptr }, ptr %l46, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t95, { i64, ptr } %t96)
  br label %bb30
bb30:
  %t97 = load ptr, ptr %l1, !tbaa !29
  store ptr %t97, ptr %l51, !tbaa !29
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/build:Config", ptr %t98, i32 0, i32 0
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  store { i64, ptr } %t101, ptr %l53, !tbaa !27
  %t102 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t104 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v2, ptr %v2, { i64, ptr } %t102)
  store { i64, ptr } %t104, ptr %l55
  br label %bb31
bb31:
  %t105 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t106 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v2, ptr %s0, { i64, ptr } %t105)
  store { i64, ptr } %t106, ptr %l56
  br label %bb32
bb32:
  %t108 = call { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %s0, ptr %s0, ptr %l6)
  store { i64, ptr } %t108, ptr %l58
  br label %bb33
bb33:
  %t109 = load { i64, ptr }, ptr %l58, !tbaa !27
  %t110 = extractvalue { i64, ptr } %t109, 0
  store i64 %t110, ptr %l59, !tbaa !24
  %t111 = icmp sge i64 0, 0
  br i1 %t111, label %bb34, label %bb35
bb34:
  %t113 = icmp sle i64 0, 16
  br i1 %t113, label %bb36, label %bb37
bb35:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb36:
  %t115 = load i64, ptr %l59, !tbaa !24
  %t116 = icmp sle i64 16, %t115
  br i1 %t116, label %bb38, label %bb39
bb37:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb38:
  %t118 = getelementptr { i64, ptr }, ptr %l58, i32 0, i32 1
  %t119 = load ptr, ptr %t118, !tbaa !27
  %t120 = getelementptr i8, ptr %t119, i64 0
  %t121 = sub i64 16, 0
  %t122 = insertvalue { i64, ptr } undef, i64 %t121, 0
  %t123 = insertvalue { i64, ptr } %t122, ptr %t120, 1
  store { i64, ptr } %t123, ptr %l63, !tbaa !27
  %t124 = load ptr, ptr %l1, !tbaa !29
  %t126 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t124)
  store { i64, ptr } %t126, ptr %l65
  br label %bb40
bb39:
  call void @__olang_check_failed(ptr @olang_loc_d52a764a2d9743a3_d3f0603066c4fb17)
  unreachable
bb40:
  %t127 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t128 = extractvalue { i64, ptr } %t127, 1
  %t129 = extractvalue { i64, ptr } %t127, 0
  %t130 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t131 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t132 = add i64 %t129, %t131
  %t133 = load { i64, ptr }, ptr %l56, !tbaa !27
  %t134 = extractvalue { i64, ptr } %t133, 1
  %t135 = extractvalue { i64, ptr } %t133, 0
  %t136 = add i64 %t132, %t135
  %t137 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t139 = add i64 %t136, %t138
  %t140 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t141 = extractvalue { i64, ptr } %t140, 1
  %t142 = extractvalue { i64, ptr } %t140, 0
  %t143 = add i64 %t139, %t142
  %t144 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t144, 1
  %t146 = extractvalue { i64, ptr } %t144, 0
  %t147 = add i64 %t143, %t146
  %t148 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t147)
  call void @olang_textcopy(ptr %t148, ptr %t128, i64 %t129)
  %t149 = getelementptr i8, ptr %t148, i64 %t129
  call void @olang_textcopy(ptr %t149, ptr %t130, i64 %t131)
  %t150 = getelementptr i8, ptr %t149, i64 %t131
  call void @olang_textcopy(ptr %t150, ptr %t134, i64 %t135)
  %t151 = getelementptr i8, ptr %t150, i64 %t135
  call void @olang_textcopy(ptr %t151, ptr %t137, i64 %t138)
  %t152 = getelementptr i8, ptr %t151, i64 %t138
  call void @olang_textcopy(ptr %t152, ptr %t141, i64 %t142)
  %t153 = getelementptr i8, ptr %t152, i64 %t142
  call void @olang_textcopy(ptr %t153, ptr %t145, i64 %t146)
  %t154 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t155 = insertvalue { i64, ptr } %t154, ptr %t148, 1
  %t157 = extractvalue { i64, ptr } %t155, 0
  %t158 = extractvalue { i64, ptr } %t155, 1
  %t159 = mul i64 %t157, 1
  %t160 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t159)
  call void @llvm.memcpy.p0.p0.i64(ptr %t160, ptr %t158, i64 %t159, i1 false)
  %t161 = insertvalue { i64, ptr } undef, i64 %t157, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t160, 1
  %t164 = load ptr, ptr %l51, !tbaa !29
  %t165 = getelementptr %"compiler/build:Config", ptr %t164, i32 0, i32 29
  store { i64, ptr } %t162, ptr %t165, !tbaa !27
  %t166 = call i64 @std_2ftime_2eNow()
  store i64 %t166, ptr %l68
  br label %bb41
bb41:
  %t167 = load i64, ptr %l68, !tbaa !24
  store i64 %t167, ptr %l7, !tbaa !24
  %t168 = load ptr, ptr %l0, !tbaa !29
  %t169 = load ptr, ptr %l1, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t171 = load ptr, ptr %l4, !tbaa !29
  %t176 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %t168, ptr %t169, { i64, ptr } %t170, ptr %t171)
  store i32 %t176, ptr %l73
  br label %bb42
bb42:
  %t177 = load i32, ptr %l73, !tbaa !23
  store i32 %t177, ptr %l8, !tbaa !23
  %t178 = load i32, ptr %l8, !tbaa !23
  %t180 = icmp ne i32 %t178, 0
  br i1 %t180, label %bb43, label %bb44
bb43:
  %t182 = load i32, ptr %l8, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t182, ptr %rv
  br label %ret
bb44:
  br label %bb45
bb45:
  %t184 = load ptr, ptr %l4, !tbaa !29
  %t186 = call { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v4, ptr %s0, ptr %t184)
  store { i64, ptr } %t186, ptr %l78
  br label %bb46
bb46:
  %t187 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t188 = extractvalue { i64, ptr } %t187, 0
  %t189 = extractvalue { i64, ptr } %t187, 1
  %t190 = mul i64 %t188, 1
  %t191 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t190)
  call void @llvm.memcpy.p0.p0.i64(ptr %t191, ptr %t189, i64 %t190, i1 false)
  %t192 = insertvalue { i64, ptr } undef, i64 %t188, 0
  %t193 = insertvalue { i64, ptr } %t192, ptr %t191, 1
  call void @compiler_2fbuild_2esayErr(ptr %s0, { i64, ptr } %t193)
  br label %bb47
bb47:
  %t195 = load ptr, ptr %l1, !tbaa !29
  %t197 = getelementptr %"compiler/build:Config", ptr %t195, i32 0, i32 0
  %t198 = load { i64, ptr }, ptr %t197, !tbaa !27
  %t199 = load ptr, ptr %l1, !tbaa !29
  %t201 = getelementptr %"compiler/build:Config", ptr %t199, i32 0, i32 30
  %t202 = load { i64, ptr }, ptr %t201, !tbaa !27
  %t203 = load i64, ptr @G_2ecompiler_2fbuild_2eRunCacheCap, !tbaa !24
  call void @compiler_2fbuild_2eprune(ptr %v1, ptr %v1, { i64, ptr } %t198, { i64, ptr } %t202, i64 %t203)
  br label %bb48
bb48:
  %t207 = load ptr, ptr %l1, !tbaa !29
  %t209 = getelementptr %"compiler/build:Config", ptr %t207, i32 0, i32 15
  %t210 = load i1, ptr %t209, !tbaa !21
  br i1 %t210, label %bb49, label %bb50
bb49:
  store %olang.scope zeroinitializer, ptr %s7
  call void @compiler_2fspin_2eEnd()
  br label %bb51
bb50:
  br label %bb71
bb51:
  %t212 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s7, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t212, ptr %l87
  br label %bb52
bb52:
  %t213 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l87
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t213, ptr %l9
  %t214 = load ptr, ptr %l1, !tbaa !29
  %t216 = getelementptr %"compiler/build:Config", ptr %t214, i32 0, i32 30
  %t217 = load { i64, ptr }, ptr %t216, !tbaa !27
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s7, ptr %v1, ptr %l9, { i64, ptr } %t217)
  br label %bb53
bb53:
  %t220 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t220, ptr %l91, !tbaa !27
  %t221 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t224 = extractvalue { i64, ptr } %t221, 0
  store i64 %t224, ptr %l94, !tbaa !24
  %t225 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t226 = extractvalue { i64, ptr } %t225, 0
  store i64 %t226, ptr %l95, !tbaa !24
  %t227 = icmp sge i64 1, 0
  br i1 %t227, label %bb54, label %bb55
bb54:
  %t229 = load i64, ptr %l94, !tbaa !24
  %t230 = icmp sle i64 1, %t229
  br i1 %t230, label %bb56, label %bb57
bb55:
  call void @__olang_check_failed(ptr @olang_loc_6165e91575c84e88_fb0586f2b3992fac)
  unreachable
bb56:
  %t232 = load i64, ptr %l94, !tbaa !24
  %t233 = load i64, ptr %l95, !tbaa !24
  %t234 = icmp sle i64 %t232, %t233
  br i1 %t234, label %bb58, label %bb59
bb57:
  call void @__olang_check_failed(ptr @olang_loc_6165e91575c84e88_fb0586f2b3992fac)
  unreachable
bb58:
  %t236 = getelementptr { i64, ptr }, ptr %l91, i32 0, i32 1
  %t237 = load ptr, ptr %t236, !tbaa !27
  %t238 = load i64, ptr %l94, !tbaa !24
  %t239 = getelementptr { i64, ptr }, ptr %t237, i64 1
  %t240 = sub i64 %t238, 1
  %t241 = insertvalue { i64, ptr } undef, i64 %t240, 0
  %t242 = insertvalue { i64, ptr } %t241, ptr %t239, 1
  store { i64, ptr } %t242, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t244 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t246 = extractvalue { i64, ptr } %t244, 0
  store i64 %t246, ptr %l12, !tbaa !24
  br label %bb60
bb59:
  call void @__olang_check_failed(ptr @olang_loc_6165e91575c84e88_fb0586f2b3992fac)
  unreachable
bb60:
  %t248 = load i64, ptr %l11, !tbaa !24
  %t249 = load i64, ptr %l12, !tbaa !24
  %t252 = icmp slt i64 %t248, %t249
  %t254 = xor i1 %t252, true
  br i1 %t254, label %bb61, label %bb62
bb61:
  br label %bb66
bb62:
  br label %bb63
bb63:
  %t256 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t256, ptr %l106, !tbaa !27
  %t257 = load i64, ptr %l11, !tbaa !24
  %t259 = getelementptr { i64, ptr }, ptr %l106, i32 0, i32 1
  %t260 = load ptr, ptr %t259, !tbaa !27
  %t261 = getelementptr { i64, ptr }, ptr %t260, i64 %t257
  %t262 = load { i64, ptr }, ptr %t261, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s7, ptr %v3, ptr %l9, { i64, ptr } %t262)
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t267 = load i64, ptr %l11, !tbaa !24
  %t269 = add i64 %t267, 1
  store i64 %t269, ptr %l11, !tbaa !24
  br label %bb60
bb66:
  %t272 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s7, ptr %s7, ptr %l9)
  store { i64, ptr } %t272, ptr %l114
  br label %bb67
bb67:
  %t273 = call i64 @std_2ftime_2eNow()
  store i64 %t273, ptr %l115
  br label %bb68
bb68:
  %t274 = load i64, ptr %l7, !tbaa !24
  %t275 = load i64, ptr %l115, !tbaa !24
  %t277 = sub i64 %t275, %t274
  store i64 %t277, ptr %l117, !tbaa !24
  %t278 = load ptr, ptr %l1, !tbaa !29
  %t280 = getelementptr %"compiler/build:Config", ptr %t278, i32 0, i32 16
  %t281 = load i64, ptr %t280, !tbaa !24
  %t283 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t281, i64 1)
  store i64 %t283, ptr %l120
  br label %bb69
bb69:
  %t284 = load { i64, ptr }, ptr %l114, !tbaa !27
  %t285 = load i64, ptr %l117, !tbaa !24
  %t286 = load i64, ptr %l120, !tbaa !24
  %t287 = call i32 @compiler_2fmeasure_2eMeasure(ptr %s7, { i64, ptr } %t284, i64 %t285, i64 %t286)
  store i32 %t287, ptr %l121
  br label %bb70
bb70:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t288 = load i32, ptr %l121, !tbaa !23
  store i32 %t288, ptr %rv
  br label %ret
bb71:
  %t289 = load ptr, ptr %l1, !tbaa !29
  %t291 = getelementptr %"compiler/build:Config", ptr %t289, i32 0, i32 30
  %t292 = load { i64, ptr }, ptr %t291, !tbaa !27
  %t293 = load { i64, ptr }, ptr %l3, !tbaa !27
  %t296 = call i32 @std_2fos_2eExecInPlace(ptr %v1, ptr %v3, { i64, ptr } %t292, { i64, ptr } %t293)
  store i32 %t296, ptr %l125
  %t297 = icmp ne i32 %t296, 0
  br i1 %t297, label %bb73, label %ok.298, !prof !99
ok.298:
  br label %bb72
bb72:
  br label %bb80
bb73:
  %t299 = load i32, ptr %l125, !tbaa !23
  %t300 = ashr i32 %t299, 16
  %t302 = icmp eq i32 %t300, 1
  store i1 %t302, ptr %l127, !tbaa !21
  %t303 = load i32, ptr %l125, !tbaa !23
  %t304 = ashr i32 %t303, 16
  %t306 = icmp eq i32 %t304, 1
  br i1 %t306, label %bb74, label %bb75
bb74:
  call void @__olang_errpay_pop()
  br label %bb75
bb75:
  br label %bb76
bb76:
  %t308 = load ptr, ptr %l4, !tbaa !29
  store ptr %t308, ptr %l130, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t309
  %t310 = getelementptr { i64, [3 x i64] }, ptr %t309, i32 0, i32 0
  store i64 0, ptr %t310
  %t311 = load { i64, [3 x i64] }, ptr %t309
  store { i64, [3 x i64] } %t311, ptr %l131
  %t312 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v4, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t312, ptr %l132
  br label %bb77
bb77:
  %t313 = load ptr, ptr %l130, !tbaa !29
  %t314 = load { i64, [3 x i64] }, ptr %l131
  %t315 = load %"compiler/diagmsg:Msg", ptr %l132
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t313, { i64, [3 x i64] } %t314, %"compiler/diagmsg:Msg" %t315)
  br label %bb78
bb78:
  %t316 = load ptr, ptr %l4, !tbaa !29
  %t318 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t316)
  store i32 %t318, ptr %l134
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s0)
  %t319 = load i32, ptr %l134, !tbaa !23
  store i32 %t319, ptr %rv
  br label %ret
bb80:
  call void @__olang_check_failed(ptr @olang_loc_52ef5e06ac377ee6_47cc3810ffe2829a)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, %"compiler/build:Listed" } @compiler_2fbuild_2eListed_2eListingCode_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca i1
  %l4 = alloca ptr
  %l5 = alloca ptr
  %lp6 = alloca ptr
  %lp7 = alloca ptr
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca ptr
  %l10 = alloca i64
  %l11 = alloca { i64, ptr }
  %l18 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l26 = alloca i64
  %l31 = alloca i32
  %l34 = alloca { i64, ptr }
  %l36 = alloca { i64, ptr }
  %l38 = alloca { i64, ptr }
  %l40 = alloca { i64, ptr }
  %l42 = alloca { i64, ptr }
  %l44 = alloca %"compiler/build:Listed"
  %l53 = alloca i32
  %l56 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l60 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l61 = alloca i32
  %l64 = alloca i64
  %l66 = alloca i64
  %l71 = alloca { i64, ptr }
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l89 = alloca i32
  %s0 = alloca %olang.scope
  %s5 = alloca %olang.scope
  %rv = alloca { i32, %"compiler/build:Listed" }
  store ptr %a1, ptr %l1
  store i1 %a3, ptr %l3
  store ptr %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l5, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a2, i32 1, ptr %t3, ptr %t4, ptr %t5)
  store i32 %t12, ptr %l18
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t15 = load i32, ptr %l18, !tbaa !23
  %t16 = lshr i32 %t15, 16
  %t17 = and i32 %t15, 65535
  %t18 = icmp eq i32 %t16, 1
  %t19 = select i1 %t18, i32 1, i32 0
  %t20 = icmp eq i32 %t15, 0
  %t21 = shl i32 %t19, 16
  %t22 = or i32 %t21, %t17
  %t23 = select i1 %t20, i32 0, i32 %t22
  call void @__olang_scope_close(ptr %s0)
  %t25 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t23, 0
  store { i32, %"compiler/build:Listed" } %t25, ptr %rv
  br label %ret
bb3:
  %t26 = load ptr, ptr %l5, !tbaa !29
  %t28 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v4, ptr %t26)
  store i64 %t28, ptr %l21
  br label %bb4
bb4:
  %t29 = load i64, ptr %l21, !tbaa !24
  %t30 = icmp sgt i64 %t29, 0
  br i1 %t30, label %bb5, label %bb6
bb5:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb8
bb6:
  %t32 = load ptr, ptr %l4, !tbaa !29
  %t34 = getelementptr %"compiler/build:Program", ptr %t32, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v3, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb7
bb7:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb8
bb8:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb9, label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t42 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 65536, 0
  store { i32, %"compiler/build:Listed" } %t42, ptr %rv
  br label %ret
bb10:
  br label %bb11
bb11:
  %t43 = load ptr, ptr %l1, !tbaa !29
  %t44 = load ptr, ptr %l5, !tbaa !29
  %t47 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v4, ptr %t43, ptr %t44)
  store i32 %t47, ptr %l31
  %t48 = icmp ne i32 %t47, 0
  br i1 %t48, label %bb13, label %ok.49, !prof !99
ok.49:
  br label %bb12
bb12:
  br label %bb14
bb13:
  %t50 = load i32, ptr %l31, !tbaa !23
  %t51 = lshr i32 %t50, 16
  %t52 = and i32 %t50, 65535
  %t53 = icmp eq i32 %t51, 1
  %t54 = select i1 %t53, i32 1, i32 0
  %t55 = icmp eq i32 %t50, 0
  %t56 = shl i32 %t54, 16
  %t57 = or i32 %t56, %t52
  %t58 = select i1 %t55, i32 0, i32 %t57
  call void @__olang_scope_close(ptr %s0)
  %t60 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t58, 0
  store { i32, %"compiler/build:Listed" } %t60, ptr %rv
  br label %ret
bb14:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t63 = getelementptr %"compiler/build:Config", ptr %t61, i32 0, i32 0
  %t64 = load { i64, ptr }, ptr %t63, !tbaa !27
  store { i64, ptr } %t64, ptr %l34, !tbaa !27
  %t65 = load ptr, ptr %l4, !tbaa !29
  %t67 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v3, ptr %s0, ptr %t65)
  store { i64, ptr } %t67, ptr %l36
  br label %bb15
bb15:
  %t68 = load { i64, ptr }, ptr %l36, !tbaa !27
  %t69 = extractvalue { i64, ptr } %t68, 0
  %t70 = extractvalue { i64, ptr } %t68, 1
  %t71 = mul i64 %t69, 1
  %t72 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t71)
  call void @llvm.memcpy.p0.p0.i64(ptr %t72, ptr %t70, i64 %t71, i1 false)
  %t73 = insertvalue { i64, ptr } undef, i64 %t69, 0
  %t74 = insertvalue { i64, ptr } %t73, ptr %t72, 1
  %t76 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t74)
  store { i64, ptr } %t76, ptr %l38
  br label %bb16
bb16:
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t77)
  store { i64, ptr } %t79, ptr %l40
  br label %bb17
bb17:
  %t80 = load i1, ptr %l3, !tbaa !21
  br i1 %t80, label %bb18, label %bb19
bb18:
  store { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d16, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb19:
  store { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d17, i32 0, i32 1) }, ptr %l42, !tbaa !27
  br label %bb20
bb20:
  %t82 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t83 = extractvalue { i64, ptr } %t82, 1
  %t84 = extractvalue { i64, ptr } %t82, 0
  %t85 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 1
  %t86 = extractvalue { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d18, i32 0, i32 1) }, 0
  %t87 = add i64 %t84, %t86
  %t88 = load { i64, ptr }, ptr %l38, !tbaa !27
  %t89 = extractvalue { i64, ptr } %t88, 1
  %t90 = extractvalue { i64, ptr } %t88, 0
  %t91 = add i64 %t87, %t90
  %t92 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t93 = extractvalue { i64, ptr } %t92, 1
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t95 = add i64 %t91, %t94
  %t96 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t97 = extractvalue { i64, ptr } %t96, 1
  %t98 = extractvalue { i64, ptr } %t96, 0
  %t99 = add i64 %t95, %t98
  %t100 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t99)
  call void @olang_textcopy(ptr %t100, ptr %t83, i64 %t84)
  %t101 = getelementptr i8, ptr %t100, i64 %t84
  call void @olang_textcopy(ptr %t101, ptr %t85, i64 %t86)
  %t102 = getelementptr i8, ptr %t101, i64 %t86
  call void @olang_textcopy(ptr %t102, ptr %t89, i64 %t90)
  %t103 = getelementptr i8, ptr %t102, i64 %t90
  call void @olang_textcopy(ptr %t103, ptr %t93, i64 %t94)
  %t104 = getelementptr i8, ptr %t103, i64 %t94
  call void @olang_textcopy(ptr %t104, ptr %t97, i64 %t98)
  %t105 = insertvalue { i64, ptr } undef, i64 %t99, 0
  %t106 = insertvalue { i64, ptr } %t105, ptr %t100, 1
  %t107 = call ptr @__olang_scope_alloc_a(ptr %v4, i64 16, i64 8)
  store ptr %t107, ptr %lp6
  %t109 = load ptr, ptr %lp6
  store { i64, ptr } %t106, ptr %t109, !tbaa !27
  %t110 = call %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v5)
  store %"compiler/build:Listed" %t110, ptr %l44
  br label %bb21
bb21:
  %t111 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 64, i64 8)
  store ptr %t111, ptr %lp7
  %t112 = load %"compiler/build:Listed", ptr %l44
  %t113 = load ptr, ptr %lp7
  store %"compiler/build:Listed" %t112, ptr %t113
  %t114 = load ptr, ptr %l1, !tbaa !29
  %t116 = getelementptr %"compiler/build:Config", ptr %t114, i32 0, i32 5
  %t117 = load i1, ptr %t116, !tbaa !21
  br i1 %t117, label %bb22, label %bb23
bb22:
  %t119 = load ptr, ptr %l1, !tbaa !29
  %t120 = load ptr, ptr %l4, !tbaa !29
  %t121 = load ptr, ptr %lp6
  %t122 = load { i64, ptr }, ptr %t121, !tbaa !27
  %t123 = load i1, ptr %l3, !tbaa !21
  %t124 = load ptr, ptr %lp7
  %t125 = load ptr, ptr %l5, !tbaa !29
  %t132 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v1, ptr %v3, ptr %v4, ptr %v5, ptr %v4, ptr %t119, ptr %t120, { i64, ptr } %t122, i1 %t123, ptr %t124, ptr %t125)
  store i32 %t132, ptr %l53
  %t133 = icmp ne i32 %t132, 0
  br i1 %t133, label %bb25, label %ok.134, !prof !99
ok.134:
  br label %bb24
bb23:
  br label %bb27
bb24:
  br label %bb26
bb25:
  %t135 = load i32, ptr %l53, !tbaa !23
  %t136 = lshr i32 %t135, 16
  %t137 = and i32 %t135, 65535
  %t138 = icmp eq i32 %t136, 1
  %t139 = select i1 %t138, i32 1, i32 0
  %t140 = icmp eq i32 %t135, 0
  %t141 = shl i32 %t139, 16
  %t142 = or i32 %t141, %t137
  %t143 = select i1 %t140, i32 0, i32 %t142
  call void @__olang_scope_close(ptr %s0)
  %t145 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t143, 0
  store { i32, %"compiler/build:Listed" } %t145, ptr %rv
  br label %ret
bb26:
  %t146 = load ptr, ptr %lp7
  %t147 = load %"compiler/build:Listed", ptr %t146
  call void @__olang_scope_close(ptr %s0)
  %t149 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t147, 1
  store { i32, %"compiler/build:Listed" } %t149, ptr %rv
  br label %ret
bb27:
  %t150 = load ptr, ptr %l1, !tbaa !29
  %t151 = load ptr, ptr %l4, !tbaa !29
  %t152 = load ptr, ptr %l5, !tbaa !29
  %t156 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %v3, ptr %v4, ptr %v4, ptr %t150, ptr %t151, ptr %t152)
  %t157 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t156, 1
  %t158 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t156, 0
  store i32 %t158, ptr %l61
  %t159 = icmp ne i32 %t158, 0
  br i1 %t159, label %bb29, label %ok.160, !prof !99
ok.160:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t157, ptr %l60
  br label %bb28
bb28:
  %t161 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l60
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t161, ptr %l56
  br label %bb30
bb29:
  %t162 = load i32, ptr %l61, !tbaa !23
  %t163 = lshr i32 %t162, 16
  %t164 = and i32 %t162, 65535
  %t165 = icmp eq i32 %t163, 1
  %t166 = select i1 %t165, i32 1, i32 0
  %t167 = icmp eq i32 %t162, 0
  %t168 = shl i32 %t166, 16
  %t169 = or i32 %t168, %t164
  %t170 = select i1 %t167, i32 0, i32 %t169
  call void @__olang_scope_close(ptr %s0)
  %t172 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t170, 0
  store { i32, %"compiler/build:Listed" } %t172, ptr %rv
  br label %ret
bb30:
  %t173 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l56
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t173, ptr %l8
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d19, i32 0, i32 1) })
  br label %bb31
bb31:
  store ptr %l8, ptr %l9, !tbaa !29
  store i64 0, ptr %l10, !tbaa !24
  br label %bb32
bb32:
  store %olang.scope zeroinitializer, ptr %s5
  %t175 = load i64, ptr %l10, !tbaa !24
  store i64 %t175, ptr %l64, !tbaa !24
  %t176 = load ptr, ptr %l9, !tbaa !29
  %t178 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t176)
  store i64 %t178, ptr %l66
  br label %bb33
bb33:
  %t179 = load i64, ptr %l64, !tbaa !24
  %t180 = load i64, ptr %l66, !tbaa !24
  %t181 = icmp slt i64 %t179, %t180
  %t183 = xor i1 %t181, true
  br i1 %t183, label %bb34, label %bb35
bb34:
  call void @__olang_scope_close(ptr %s5)
  br label %bb46
bb35:
  br label %bb36
bb36:
  %t185 = load ptr, ptr %l9, !tbaa !29
  %t186 = load i64, ptr %l10, !tbaa !24
  %t189 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v4, ptr %v4, ptr %t185, i64 %t186)
  store { i64, ptr } %t189, ptr %l71
  br label %bb37
bb37:
  %t190 = load { i64, ptr }, ptr %l71, !tbaa !27
  store { i64, ptr } %t190, ptr %l11, !tbaa !27
  %t191 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t193 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v4, ptr %s5, { i64, ptr } %t191)
  store { i64, ptr } %t193, ptr %l73
  br label %bb38
bb38:
  %t194 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s5, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t202 = call i1 @std_2fos_2eExists(ptr %s5, { i64, ptr } %t200)
  store i1 %t202, ptr %l75
  br label %bb39
bb39:
  %t203 = load i1, ptr %l75, !tbaa !21
  br i1 %t203, label %bb40, label %bb41
bb40:
  %t204 = load ptr, ptr %lp7
  %t205 = getelementptr %"compiler/build:Listed", ptr %t204, i32 0, i32 1
  store ptr %t205, ptr %l76, !tbaa !29
  %t206 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t208 = call { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v4, ptr %v5, { i64, ptr } %t206)
  store { i64, ptr } %t208, ptr %l78
  br label %bb42
bb41:
  br label %bb44
bb42:
  %t209 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t210 = extractvalue { i64, ptr } %t209, 0
  %t211 = extractvalue { i64, ptr } %t209, 1
  %t212 = mul i64 %t210, 1
  %t213 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t212)
  call void @llvm.memcpy.p0.p0.i64(ptr %t213, ptr %t211, i64 %t212, i1 false)
  %t214 = insertvalue { i64, ptr } undef, i64 %t210, 0
  %t215 = insertvalue { i64, ptr } %t214, ptr %t213, 1
  %t216 = load ptr, ptr %l76, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v5, ptr %v5, ptr %t216, { i64, ptr } %t215)
  br label %bb43
bb43:
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s5)
  br label %bb45
bb45:
  %t218 = load i64, ptr %l10, !tbaa !24
  %t220 = add i64 %t218, 1
  store i64 %t220, ptr %l10, !tbaa !24
  br label %bb32
bb46:
  %t222 = load ptr, ptr %l1, !tbaa !29
  %t223 = load ptr, ptr %l4, !tbaa !29
  %t224 = load ptr, ptr %lp6
  %t225 = load { i64, ptr }, ptr %t224, !tbaa !27
  %t226 = load i1, ptr %l3, !tbaa !21
  %t227 = load ptr, ptr %lp7
  %t228 = load ptr, ptr %l5, !tbaa !29
  %t236 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v1, ptr %v4, ptr %v3, ptr %v4, ptr %v5, ptr %v4, ptr %t222, ptr %l8, ptr %t223, { i64, ptr } %t225, i1 %t226, ptr %t227, ptr %t228)
  store i32 %t236, ptr %l89
  %t237 = icmp ne i32 %t236, 0
  br i1 %t237, label %bb48, label %ok.238, !prof !99
ok.238:
  br label %bb47
bb47:
  br label %bb49
bb48:
  %t239 = load i32, ptr %l89, !tbaa !23
  %t240 = lshr i32 %t239, 16
  %t241 = and i32 %t239, 65535
  %t242 = icmp eq i32 %t240, 1
  %t243 = select i1 %t242, i32 1, i32 0
  %t244 = icmp eq i32 %t239, 0
  %t245 = shl i32 %t243, 16
  %t246 = or i32 %t245, %t241
  %t247 = select i1 %t244, i32 0, i32 %t246
  call void @__olang_scope_close(ptr %s0)
  %t249 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, i32 %t247, 0
  store { i32, %"compiler/build:Listed" } %t249, ptr %rv
  br label %ret
bb49:
  %t250 = load ptr, ptr %lp7
  %t251 = load %"compiler/build:Listed", ptr %t250
  call void @__olang_scope_close(ptr %s0)
  %t253 = insertvalue { i32, %"compiler/build:Listed" } zeroinitializer, %"compiler/build:Listed" %t251, 1
  store { i32, %"compiler/build:Listed" } %t253, ptr %rv
  br label %ret
ret:
  %rr = load { i32, %"compiler/build:Listed" }, ptr %rv
  ret { i32, %"compiler/build:Listed" } %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i64
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l9 = alloca { i64, ptr }
  %l10 = alloca i64
  %l11 = alloca i64
  %l13 = alloca { i64, ptr }
  %l14 = alloca i64
  %l15 = alloca i64
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca { i64, ptr }
  %l23 = alloca i64
  %l24 = alloca i64
  %l27 = alloca i64
  %l32 = alloca i32
  %l36 = alloca { i64, ptr }
  %l39 = alloca { i64, ptr }
  %l40 = alloca i32
  %l42 = alloca i1
  %l44 = alloca i32
  %l47 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l55 = alloca { i64, ptr }
  %l62 = alloca ptr
  %l65 = alloca { i64, ptr }
  %l74 = alloca { i64, ptr }
  %l82 = alloca { i64, ptr }
  %l83 = alloca i64
  %l85 = alloca i64
  %l88 = alloca i64
  %l89 = alloca i32
  %l90 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l98 = alloca { i64, ptr }
  %l105 = alloca ptr
  %l109 = alloca { i64, ptr }
  %l114 = alloca { i64, ptr }
  %l123 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l136 = alloca { i64, ptr }
  %l142 = alloca { i64, ptr }
  %l143 = alloca i32
  %l145 = alloca i1
  %l148 = alloca ptr
  %l149 = alloca { i64, [3 x i64] }
  %l150 = alloca %"compiler/diagmsg:Msg"
  %l152 = alloca i32
  %s0 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %rv = alloca i32
  %t284 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store { i64, ptr } %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 28
  store i1 true, ptr %t3, !tbaa !21
  %t4 = call i64 @std_2ftime_2eNow()
  store i64 %t4, ptr %l27
  br label %bb1
bb1:
  %t5 = load i64, ptr %l27, !tbaa !24
  store i64 %t5, ptr %l5, !tbaa !24
  %t7 = load ptr, ptr %l1, !tbaa !29
  %t8 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t9 = load ptr, ptr %l4, !tbaa !29
  %t14 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t7, { i64, ptr } %t8, ptr %t9)
  store i32 %t14, ptr %l32
  br label %bb2
bb2:
  %t15 = load i32, ptr %l32, !tbaa !23
  store i32 %t15, ptr %l6, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb3
bb3:
  %t16 = load i32, ptr %l6, !tbaa !23
  %t18 = icmp ne i32 %t16, 0
  br i1 %t18, label %bb4, label %bb5
bb4:
  %t20 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t20, ptr %rv
  br label %ret
bb5:
  br label %bb6
bb6:
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t26 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v4, ptr %s0, ptr %t22, ptr %t23)
  %t27 = extractvalue { i32, { i64, ptr } } %t26, 1
  %t28 = extractvalue { i32, { i64, ptr } } %t26, 0
  store i32 %t28, ptr %l40
  %t29 = icmp ne i32 %t28, 0
  br i1 %t29, label %bb8, label %ok.30, !prof !99
ok.30:
  store { i64, ptr } %t27, ptr %l39
  br label %bb7
bb7:
  %t31 = load { i64, ptr }, ptr %l39, !tbaa !27
  store { i64, ptr } %t31, ptr %l36, !tbaa !27
  br label %bb11
bb8:
  %t32 = load i32, ptr %l40, !tbaa !23
  %t33 = ashr i32 %t32, 16
  %t35 = icmp eq i32 %t33, 1
  store i1 %t35, ptr %l42, !tbaa !21
  br label %bb9
bb9:
  %t36 = load ptr, ptr %l4, !tbaa !29
  %t38 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t36)
  store i32 %t38, ptr %l44
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t39 = load i32, ptr %l44, !tbaa !23
  store i32 %t39, ptr %rv
  br label %ret
bb11:
  %t40 = load { i64, ptr }, ptr %l36, !tbaa !27
  store { i64, ptr } %t40, ptr %l7, !tbaa !27
  %t41 = load ptr, ptr %l1, !tbaa !29
  %t43 = getelementptr %"compiler/build:Config", ptr %t41, i32 0, i32 15
  %t44 = load i1, ptr %t43, !tbaa !21
  br i1 %t44, label %bb12, label %bb13
bb12:
  store %olang.scope zeroinitializer, ptr %s3
  %t46 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s3, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t46, ptr %l47
  br label %bb14
bb13:
  br label %bb35
bb14:
  %t47 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l47
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t47, ptr %l8
  %t48 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t48, ptr %l9, !tbaa !27
  store i64 0, ptr %l10, !tbaa !24
  %t50 = load { i64, ptr }, ptr %l9, !tbaa !27
  %t52 = extractvalue { i64, ptr } %t50, 0
  store i64 %t52, ptr %l11, !tbaa !24
  br label %bb15
bb15:
  %t54 = load i64, ptr %l10, !tbaa !24
  %t55 = load i64, ptr %l11, !tbaa !24
  %t58 = icmp slt i64 %t54, %t55
  %t60 = xor i1 %t58, true
  br i1 %t60, label %bb16, label %bb17
bb16:
  br label %bb21
bb17:
  br label %bb18
bb18:
  %t62 = load { i64, ptr }, ptr %l9, !tbaa !27
  store { i64, ptr } %t62, ptr %l55, !tbaa !27
  %t63 = load i64, ptr %l10, !tbaa !24
  %t65 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t66 = load ptr, ptr %t65, !tbaa !27
  %t67 = getelementptr { i64, ptr }, ptr %t66, i64 %t63
  %t68 = load { i64, ptr }, ptr %t67, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s3, ptr %s0, ptr %l8, { i64, ptr } %t68)
  br label %bb19
bb19:
  br label %bb20
bb20:
  %t73 = load i64, ptr %l10, !tbaa !24
  %t75 = add i64 %t73, 1
  store i64 %t75, ptr %l10, !tbaa !24
  br label %bb15
bb21:
  store ptr %l8, ptr %l62, !tbaa !29
  %t77 = load ptr, ptr %l1, !tbaa !29
  %t79 = getelementptr %"compiler/build:Config", ptr %t77, i32 0, i32 30
  %t80 = load { i64, ptr }, ptr %t79, !tbaa !27
  %t82 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s3, { i64, ptr } %t80)
  store { i64, ptr } %t82, ptr %l65
  br label %bb22
bb22:
  %t83 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t84 = extractvalue { i64, ptr } %t83, 0
  %t85 = extractvalue { i64, ptr } %t83, 1
  %t86 = mul i64 %t84, 1
  %t87 = call ptr @__olang_scope_alloc(ptr %s3, i64 %t86)
  call void @llvm.memcpy.p0.p0.i64(ptr %t87, ptr %t85, i64 %t86, i1 false)
  %t88 = insertvalue { i64, ptr } undef, i64 %t84, 0
  %t89 = insertvalue { i64, ptr } %t88, ptr %t87, 1
  %t90 = load ptr, ptr %l62, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s3, ptr %s3, ptr %t90, { i64, ptr } %t89)
  br label %bb23
bb23:
  %t92 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t92, ptr %l13, !tbaa !27
  store i64 0, ptr %l14, !tbaa !24
  %t94 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t96 = extractvalue { i64, ptr } %t94, 0
  store i64 %t96, ptr %l15, !tbaa !24
  br label %bb24
bb24:
  %t98 = load i64, ptr %l14, !tbaa !24
  %t99 = load i64, ptr %l15, !tbaa !24
  %t102 = icmp slt i64 %t98, %t99
  %t104 = xor i1 %t102, true
  br i1 %t104, label %bb25, label %bb26
bb25:
  br label %bb30
bb26:
  br label %bb27
bb27:
  %t106 = load { i64, ptr }, ptr %l13, !tbaa !27
  store { i64, ptr } %t106, ptr %l74, !tbaa !27
  %t107 = load i64, ptr %l14, !tbaa !24
  %t109 = getelementptr { i64, ptr }, ptr %l74, i32 0, i32 1
  %t110 = load ptr, ptr %t109, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %t110, i64 %t107
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s3, ptr %v3, ptr %l8, { i64, ptr } %t112)
  br label %bb28
bb28:
  br label %bb29
bb29:
  %t117 = load i64, ptr %l14, !tbaa !24
  %t119 = add i64 %t117, 1
  store i64 %t119, ptr %l14, !tbaa !24
  br label %bb24
bb30:
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s3, ptr %s3, ptr %l8)
  store { i64, ptr } %t122, ptr %l82
  br label %bb31
bb31:
  %t123 = call i64 @std_2ftime_2eNow()
  store i64 %t123, ptr %l83
  br label %bb32
bb32:
  %t124 = load i64, ptr %l5, !tbaa !24
  %t125 = load i64, ptr %l83, !tbaa !24
  %t127 = sub i64 %t125, %t124
  store i64 %t127, ptr %l85, !tbaa !24
  %t128 = load ptr, ptr %l1, !tbaa !29
  %t130 = getelementptr %"compiler/build:Config", ptr %t128, i32 0, i32 16
  %t131 = load i64, ptr %t130, !tbaa !24
  %t133 = call i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %t131, i64 1)
  store i64 %t133, ptr %l88
  br label %bb33
bb33:
  %t134 = load { i64, ptr }, ptr %l82, !tbaa !27
  %t135 = load i64, ptr %l85, !tbaa !24
  %t136 = load i64, ptr %l88, !tbaa !24
  %t137 = call i32 @compiler_2fmeasure_2eMeasure(ptr %s3, { i64, ptr } %t134, i64 %t135, i64 %t136)
  store i32 %t137, ptr %l89
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t138 = load i32, ptr %l89, !tbaa !23
  store i32 %t138, ptr %rv
  br label %ret
bb35:
  %t139 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t139, ptr %l90
  br label %bb36
bb36:
  %t140 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l90
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t140, ptr %l17
  %t141 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t141, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t143 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t143, 0
  store i64 %t145, ptr %l20, !tbaa !24
  br label %bb37
bb37:
  %t147 = load i64, ptr %l19, !tbaa !24
  %t148 = load i64, ptr %l20, !tbaa !24
  %t151 = icmp slt i64 %t147, %t148
  %t153 = xor i1 %t151, true
  br i1 %t153, label %bb38, label %bb39
bb38:
  br label %bb43
bb39:
  br label %bb40
bb40:
  %t155 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t155, ptr %l98, !tbaa !27
  %t156 = load i64, ptr %l19, !tbaa !24
  %t158 = getelementptr { i64, ptr }, ptr %l98, i32 0, i32 1
  %t159 = load ptr, ptr %t158, !tbaa !27
  %t160 = getelementptr { i64, ptr }, ptr %t159, i64 %t156
  %t161 = load { i64, ptr }, ptr %t160, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l17, { i64, ptr } %t161)
  br label %bb41
bb41:
  br label %bb42
bb42:
  %t166 = load i64, ptr %l19, !tbaa !24
  %t168 = add i64 %t166, 1
  store i64 %t168, ptr %l19, !tbaa !24
  br label %bb37
bb43:
  store ptr %l17, ptr %l105, !tbaa !29
  %t170 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t172 = extractvalue { i64, ptr } %t170, 0
  %t174 = icmp eq i64 %t172, 0
  br i1 %t174, label %bb44, label %bb45
bb44:
  %t176 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t176, 1
  %t179 = extractvalue { i64, ptr } %t176, 0
  %t180 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t178, i64 %t179)
  %t181 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t182 = insertvalue { i64, ptr } %t181, ptr %t180, 1
  store { i64, ptr } %t182, ptr %l109, !tbaa !27
  br label %bb47
bb45:
  %t184 = load ptr, ptr %l1, !tbaa !29
  %t186 = getelementptr %"compiler/build:Config", ptr %t184, i32 0, i32 30
  %t187 = load { i64, ptr }, ptr %t186, !tbaa !27
  %t189 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t187)
  store { i64, ptr } %t189, ptr %l114
  br label %bb46
bb46:
  %t190 = load { i64, ptr }, ptr %l114, !tbaa !27
  store { i64, ptr } %t190, ptr %l109, !tbaa !27
  br label %bb47
bb47:
  %t191 = load { i64, ptr }, ptr %l109, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  %t193 = extractvalue { i64, ptr } %t191, 1
  %t194 = mul i64 %t192, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t194)
  call void @llvm.memcpy.p0.p0.i64(ptr %t195, ptr %t193, i64 %t194, i1 false)
  %t196 = insertvalue { i64, ptr } undef, i64 %t192, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  %t198 = load ptr, ptr %l105, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t198, { i64, ptr } %t197)
  br label %bb48
bb48:
  %t200 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t200, ptr %l22, !tbaa !27
  store i64 0, ptr %l23, !tbaa !24
  %t202 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t204 = extractvalue { i64, ptr } %t202, 0
  store i64 %t204, ptr %l24, !tbaa !24
  br label %bb49
bb49:
  %t206 = load i64, ptr %l23, !tbaa !24
  %t207 = load i64, ptr %l24, !tbaa !24
  %t210 = icmp slt i64 %t206, %t207
  %t212 = xor i1 %t210, true
  br i1 %t212, label %bb50, label %bb51
bb50:
  br label %bb55
bb51:
  br label %bb52
bb52:
  %t214 = load { i64, ptr }, ptr %l22, !tbaa !27
  store { i64, ptr } %t214, ptr %l123, !tbaa !27
  %t215 = load i64, ptr %l23, !tbaa !24
  %t217 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t218 = load ptr, ptr %t217, !tbaa !27
  %t219 = getelementptr { i64, ptr }, ptr %t218, i64 %t215
  %t220 = load { i64, ptr }, ptr %t219, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %v3, ptr %l17, { i64, ptr } %t220)
  br label %bb53
bb53:
  br label %bb54
bb54:
  %t225 = load i64, ptr %l23, !tbaa !24
  %t227 = add i64 %t225, 1
  store i64 %t227, ptr %l23, !tbaa !24
  br label %bb49
bb55:
  %t229 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t231 = extractvalue { i64, ptr } %t229, 0
  %t233 = icmp eq i64 %t231, 0
  br i1 %t233, label %bb56, label %bb57
bb56:
  %t235 = load ptr, ptr %l1, !tbaa !29
  %t237 = getelementptr %"compiler/build:Config", ptr %t235, i32 0, i32 30
  %t238 = load { i64, ptr }, ptr %t237, !tbaa !27
  %t240 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t238)
  store { i64, ptr } %t240, ptr %l136
  br label %bb58
bb57:
  %t241 = getelementptr { i64, ptr }, ptr %l7, i32 0, i32 1
  %t242 = load ptr, ptr %t241, !tbaa !27
  %t243 = getelementptr { i64, ptr }, ptr %t242, i64 0
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !37
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = extractvalue { i64, ptr } %t244, 0
  %t248 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t247)
  call void @olang_textcopy(ptr %t248, ptr %t246, i64 %t247)
  %t249 = insertvalue { i64, ptr } undef, i64 %t247, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t252 = extractvalue { i64, ptr } %t250, 0
  %t253 = extractvalue { i64, ptr } %t250, 1
  %t254 = mul i64 %t252, 1
  %t255 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t254)
  call void @llvm.memcpy.p0.p0.i64(ptr %t255, ptr %t253, i64 %t254, i1 false)
  %t256 = insertvalue { i64, ptr } undef, i64 %t252, 0
  %t257 = insertvalue { i64, ptr } %t256, ptr %t255, 1
  store { i64, ptr } %t257, ptr %l133, !tbaa !27
  br label %bb59
bb58:
  %t259 = load { i64, ptr }, ptr %l136, !tbaa !27
  %t260 = extractvalue { i64, ptr } %t259, 0
  %t261 = extractvalue { i64, ptr } %t259, 1
  %t262 = mul i64 %t260, 1
  %t263 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t262)
  call void @llvm.memcpy.p0.p0.i64(ptr %t263, ptr %t261, i64 %t262, i1 false)
  %t264 = insertvalue { i64, ptr } undef, i64 %t260, 0
  %t265 = insertvalue { i64, ptr } %t264, ptr %t263, 1
  store { i64, ptr } %t265, ptr %l133, !tbaa !27
  br label %bb59
bb59:
  %t268 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l17)
  store { i64, ptr } %t268, ptr %l142
  br label %bb60
bb60:
  %t269 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t270 = load { i64, ptr }, ptr %l142, !tbaa !27
  %t271 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t269, { i64, ptr } %t270)
  store i32 %t271, ptr %l143
  %t272 = icmp ne i32 %t271, 0
  br i1 %t272, label %bb62, label %ok.273, !prof !99
ok.273:
  br label %bb61
bb61:
  br label %bb69
bb62:
  %t274 = load i32, ptr %l143, !tbaa !23
  %t275 = ashr i32 %t274, 16
  %t277 = icmp eq i32 %t275, 1
  store i1 %t277, ptr %l145, !tbaa !21
  %t278 = load i32, ptr %l143, !tbaa !23
  %t279 = ashr i32 %t278, 16
  %t281 = icmp eq i32 %t279, 1
  br i1 %t281, label %bb63, label %bb64
bb63:
  call void @__olang_errpay_pop()
  br label %bb64
bb64:
  br label %bb65
bb65:
  %t283 = load ptr, ptr %l4, !tbaa !29
  store ptr %t283, ptr %l148, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t284
  %t285 = getelementptr { i64, [3 x i64] }, ptr %t284, i32 0, i32 0
  store i64 0, ptr %t285
  %t286 = load { i64, [3 x i64] }, ptr %t284
  store { i64, [3 x i64] } %t286, ptr %l149
  %t287 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v4, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d20, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t287, ptr %l150
  br label %bb66
bb66:
  %t288 = load ptr, ptr %l148, !tbaa !29
  %t289 = load { i64, [3 x i64] }, ptr %l149
  %t290 = load %"compiler/diagmsg:Msg", ptr %l150
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t288, { i64, [3 x i64] } %t289, %"compiler/diagmsg:Msg" %t290)
  br label %bb67
bb67:
  %t291 = load ptr, ptr %l4, !tbaa !29
  %t293 = call i32 @compiler_2fbuild_2efinish(ptr %v4, ptr %t291)
  store i32 %t293, ptr %l152
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t294 = load i32, ptr %l152, !tbaa !23
  store i32 %t294, ptr %rv
  br label %ret
bb69:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, { i64, ptr } %a4) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca { i64, ptr }
  %l5 = alloca i64
  %l6 = alloca %"std/os:FileInfo"
  %l7 = alloca i1
  %l8 = alloca %"compiler/build:Program"
  %l9 = alloca { i32, { i64, ptr } }
  %l10 = alloca i32
  %l11 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca %"compiler/build:Program"
  %lp14 = alloca ptr
  %l15 = alloca { i32, { i64, ptr } }
  %l16 = alloca { i64, ptr }
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l18 = alloca { i64, ptr }
  %l19 = alloca i64
  %l20 = alloca i64
  %l22 = alloca i64
  %l23 = alloca %"std/os:FileInfo"
  %l25 = alloca %"std/os:FileInfo"
  %l26 = alloca i32
  %l28 = alloca i1
  %l31 = alloca ptr
  %l32 = alloca { i64, ptr }
  %l33 = alloca %"compiler/diagmsg:Msg"
  %l35 = alloca i32
  %l38 = alloca ptr
  %l39 = alloca { i64, ptr }
  %l40 = alloca %"compiler/diagmsg:Msg"
  %l42 = alloca i32
  %l46 = alloca ptr
  %l47 = alloca { i64, ptr }
  %l48 = alloca %"compiler/diagmsg:Msg"
  %l50 = alloca i32
  %l52 = alloca i1
  %l53 = alloca ptr
  %l55 = alloca i64
  %l56 = alloca %"compiler/build:Program"
  %l63 = alloca { i32, { i64, ptr } }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l72 = alloca i1
  %l74 = alloca i64
  %l79 = alloca { i64, ptr }
  %l80 = alloca { i64, ptr }
  %l81 = alloca i64
  %l82 = alloca { i64, ptr }
  %l85 = alloca %"compiler/build:Program"
  %l88 = alloca %"compiler/diag:Diagnostics"
  %l95 = alloca { i32, { i64, ptr } }
  %l97 = alloca { i64, ptr }
  %l99 = alloca i64
  %l101 = alloca i64
  %l102 = alloca { i64, ptr }
  %l108 = alloca { i64, ptr }
  %l111 = alloca { i64, ptr }
  %l112 = alloca i32
  %l114 = alloca i1
  %l116 = alloca i32
  %l119 = alloca i1
  %l121 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l129 = alloca { i64, ptr }
  %l136 = alloca ptr
  %l138 = alloca { i64, ptr }
  %l143 = alloca i32
  %l146 = alloca ptr
  %l147 = alloca ptr
  %l148 = alloca { i64, ptr }
  %l149 = alloca { i64, ptr }
  %l150 = alloca { i64, ptr }
  %l151 = alloca { i64, ptr }
  %l152 = alloca i64
  %l155 = alloca i32
  %l159 = alloca i32
  %l167 = alloca i32
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t75 = alloca %"compiler/build:Program", align 8
  %t150 = alloca %"compiler/build:Program", align 8
  %t155 = alloca %"compiler/diag:Diagnostics", align 8
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store { i64, ptr } %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i64 @std_2ftime_2eNow()
  store i64 %t1, ptr %l22
  br label %bb1
bb1:
  %t2 = load i64, ptr %l22, !tbaa !24
  store i64 %t2, ptr %l5, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = call { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v2, { i64, ptr } %t3)
  %t6 = extractvalue { i32, %"std/os:FileInfo" } %t5, 1
  %t7 = extractvalue { i32, %"std/os:FileInfo" } %t5, 0
  store i32 %t7, ptr %l26
  %t8 = icmp ne i32 %t7, 0
  br i1 %t8, label %bb3, label %ok.9, !prof !99
ok.9:
  store %"std/os:FileInfo" %t6, ptr %l25
  br label %bb2
bb2:
  %t10 = load %"std/os:FileInfo", ptr %l25
  store %"std/os:FileInfo" %t10, ptr %l23
  br label %bb9
bb3:
  %t11 = load i32, ptr %l26, !tbaa !23
  %t12 = ashr i32 %t11, 16
  %t14 = icmp eq i32 %t12, 1
  store i1 %t14, ptr %l28, !tbaa !21
  %t15 = load i32, ptr %l26, !tbaa !23
  %t16 = ashr i32 %t15, 16
  %t18 = icmp eq i32 %t16, 1
  br i1 %t18, label %bb4, label %bb5
bb4:
  call void @__olang_errpay_pop()
  br label %bb5
bb5:
  br label %bb6
bb6:
  %t20 = load ptr, ptr %l1, !tbaa !29
  store ptr %t20, ptr %l31, !tbaa !29
  %t21 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t21, ptr %l32, !tbaa !27
  %t22 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v3)
  store %"compiler/diagmsg:Msg" %t22, ptr %l33
  br label %bb7
bb7:
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t24 = load ptr, ptr %l31, !tbaa !29
  %t25 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t26 = load %"compiler/diagmsg:Msg", ptr %l33
  %t28 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t24, { i64, ptr } %t25, %"compiler/diagmsg:Msg" %t26, ptr %t23)
  store i32 %t28, ptr %l35
  br label %bb8
bb8:
  call void @__olang_scope_close(ptr %s0)
  %t29 = load i32, ptr %l35, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
bb9:
  %t30 = load %"std/os:FileInfo", ptr %l23
  store %"std/os:FileInfo" %t30, ptr %l6
  %t31 = getelementptr %"std/os:FileInfo", ptr %l6, i32 0, i32 0
  %t32 = load i32, ptr %t31, !range !{i32 0, i32 3}
  %t34 = trunc i64 1 to i32
  %t35 = icmp eq i32 %t32, %t34
  br i1 %t35, label %bb10, label %bb11
bb10:
  %t37 = load ptr, ptr %l1, !tbaa !29
  store ptr %t37, ptr %l38, !tbaa !29
  %t38 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t38, ptr %l39, !tbaa !27
  %t39 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v3)
  store %"compiler/diagmsg:Msg" %t39, ptr %l40
  br label %bb12
bb11:
  br label %bb14
bb12:
  %t40 = load ptr, ptr %l3, !tbaa !29
  %t41 = load ptr, ptr %l38, !tbaa !29
  %t42 = load { i64, ptr }, ptr %l39, !tbaa !27
  %t43 = load %"compiler/diagmsg:Msg", ptr %l40
  %t45 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t41, { i64, ptr } %t42, %"compiler/diagmsg:Msg" %t43, ptr %t40)
  store i32 %t45, ptr %l42
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t46 = load i32, ptr %l42, !tbaa !23
  store i32 %t46, ptr %rv
  br label %ret
bb14:
  %t47 = getelementptr %"std/os:FileInfo", ptr %l6, i32 0, i32 0
  %t48 = load i32, ptr %t47, !range !{i32 0, i32 3}
  %t50 = trunc i64 0 to i32
  %t51 = icmp eq i32 %t48, %t50
  %t53 = xor i1 %t51, true
  br i1 %t53, label %bb15, label %bb16
bb15:
  %t55 = load ptr, ptr %l1, !tbaa !29
  store ptr %t55, ptr %l46, !tbaa !29
  %t56 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t56, ptr %l47, !tbaa !27
  %t57 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v3)
  store %"compiler/diagmsg:Msg" %t57, ptr %l48
  br label %bb17
bb16:
  br label %bb19
bb17:
  %t58 = load ptr, ptr %l3, !tbaa !29
  %t59 = load ptr, ptr %l46, !tbaa !29
  %t60 = load { i64, ptr }, ptr %l47, !tbaa !27
  %t61 = load %"compiler/diagmsg:Msg", ptr %l48
  %t63 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %v3, ptr %v3, ptr %t59, { i64, ptr } %t60, %"compiler/diagmsg:Msg" %t61, ptr %t58)
  store i32 %t63, ptr %l50
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s0)
  %t64 = load i32, ptr %l50, !tbaa !23
  store i32 %t64, ptr %rv
  br label %ret
bb19:
  %t65 = load ptr, ptr %l1, !tbaa !29
  %t67 = call i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2esplitsTests(ptr %v1, ptr %t65)
  store i1 %t67, ptr %l52
  br label %bb20
bb20:
  %t68 = load i1, ptr %l52, !tbaa !21
  store i1 %t68, ptr %l7, !tbaa !21
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l53, !tbaa !29
  %t70 = load i1, ptr %l7, !tbaa !21
  br i1 %t70, label %bb21, label %bb22
bb21:
  store i64 1, ptr %l55, !tbaa !24
  br label %bb23
bb22:
  store i64 0, ptr %l55, !tbaa !24
  br label %bb23
bb23:
  %t72 = load i64, ptr %l55, !tbaa !24
  %t73 = load ptr, ptr %l53, !tbaa !29
  %t74 = getelementptr %"compiler/build:Config", ptr %t73, i32 0, i32 24
  store i64 %t72, ptr %t74, !tbaa !24
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t75, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l56, ptr %t75, i64 264, i1 false)
  br label %bb24
bb24:
  call void @llvm.memmove.p0.p0.i64(ptr %l8, ptr %l56, i64 264, i1 false)
  %t76 = load ptr, ptr %l1, !tbaa !29
  %t77 = load ptr, ptr %l0, !tbaa !29
  %t78 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t79 = load ptr, ptr %l3, !tbaa !29
  %t80 = load i1, ptr %l7, !tbaa !21
  %t87 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %v0, ptr %v2, ptr %v3, ptr %s0, ptr %s0, ptr %t76, ptr %t77, { i64, ptr } %t78, ptr %t79, ptr %l8, i1 %t80)
  store { i32, { i64, ptr } } %t87, ptr %l63
  br label %bb25
bb25:
  %t88 = load { i32, { i64, ptr } }, ptr %l63
  store { i32, { i64, ptr } } %t88, ptr %l9
  %t89 = getelementptr { i32, { i64, ptr } }, ptr %l9, i32 0, i32 0
  %t90 = load i32, ptr %t89, !tbaa !23
  store i32 %t90, ptr %l10, !tbaa !23
  %t92 = getelementptr { i32, { i64, ptr } }, ptr %l9, i32 0, i32 1
  %t93 = load { i64, ptr }, ptr %t92, !tbaa !27
  store { i64, ptr } %t93, ptr %l65, !tbaa !27
  %t94 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t95 = extractvalue { i64, ptr } %t94, 0
  store i64 %t95, ptr %l66, !tbaa !24
  %t96 = load i64, ptr %l66, !tbaa !24
  %t97 = mul i64 %t96, 1
  %t98 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t97)
  %t99 = insertvalue { i64, ptr } undef, i64 %t96, 0
  %t100 = insertvalue { i64, ptr } %t99, ptr %t98, 1
  store { i64, ptr } %t100, ptr %l67, !tbaa !27
  %t101 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t102 = load ptr, ptr %t101, !tbaa !27
  %t103 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t104 = load ptr, ptr %t103, !tbaa !27
  %t105 = load i64, ptr %l66, !tbaa !24
  %t106 = mul i64 %t105, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t102, ptr %t104, i64 %t106, i1 false)
  %t107 = load { i64, ptr }, ptr %l67, !tbaa !27
  store { i64, ptr } %t107, ptr %l11, !tbaa !27
  %t108 = load i32, ptr %l10, !tbaa !23
  %t110 = icmp sge i32 %t108, 0
  br i1 %t110, label %bb26, label %bb27
bb26:
  %t112 = load i32, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t112, ptr %rv
  br label %ret
bb27:
  br label %bb28
bb28:
  %t114 = load i1, ptr %l7, !tbaa !21
  br i1 %t114, label %bb29, label %bb30
bb29:
  %t116 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 8
  %t118 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t116)
  store i64 %t118, ptr %l74
  br label %bb31
bb30:
  store i1 false, ptr %l72, !tbaa !21
  br label %bb32
bb31:
  %t119 = load i64, ptr %l74, !tbaa !24
  %t120 = icmp sgt i64 %t119, 0
  store i1 %t120, ptr %l72, !tbaa !21
  br label %bb32
bb32:
  %t122 = load i1, ptr %l72, !tbaa !21
  store i1 %t122, ptr %l7, !tbaa !21
  %t123 = load i1, ptr %l7, !tbaa !21
  %t125 = xor i1 %t123, true
  br i1 %t125, label %bb33, label %bb34
bb33:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t129 = getelementptr %"compiler/build:Config", ptr %t127, i32 0, i32 24
  store i64 0, ptr %t129, !tbaa !24
  br label %bb35
bb34:
  br label %bb35
bb35:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d21, i32 0, i32 1) }, ptr %l79, !tbaa !27
  %t130 = load { i64, ptr }, ptr %l79, !tbaa !27
  store { i64, ptr } %t130, ptr %l80, !tbaa !27
  %t131 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t132 = extractvalue { i64, ptr } %t131, 0
  store i64 %t132, ptr %l81, !tbaa !24
  %t133 = load i64, ptr %l81, !tbaa !24
  %t134 = mul i64 %t133, 1
  %t135 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t134)
  %t136 = insertvalue { i64, ptr } undef, i64 %t133, 0
  %t137 = insertvalue { i64, ptr } %t136, ptr %t135, 1
  store { i64, ptr } %t137, ptr %l82, !tbaa !27
  %t138 = getelementptr { i64, ptr }, ptr %l82, i32 0, i32 1
  %t139 = load ptr, ptr %t138, !tbaa !27
  %t140 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t141 = load ptr, ptr %t140, !tbaa !27
  %t142 = load i64, ptr %l81, !tbaa !24
  %t143 = mul i64 %t142, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t139, ptr %t141, i64 %t143, i1 false)
  %t144 = load { i64, ptr }, ptr %l82, !tbaa !27
  store { i64, ptr } %t144, ptr %l12, !tbaa !27
  %t145 = load i1, ptr %l7, !tbaa !21
  br i1 %t145, label %bb36, label %bb37
bb36:
  store %olang.scope zeroinitializer, ptr %s6
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/build:Config", ptr %t147, i32 0, i32 6
  store i1 true, ptr %t149, !tbaa !21
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t150, ptr %s6)
  call void @llvm.memmove.p0.p0.i64(ptr %l85, ptr %t150, i64 264, i1 false)
  br label %bb38
bb37:
  br label %bb47
bb38:
  call void @llvm.memmove.p0.p0.i64(ptr %l13, ptr %l85, i64 264, i1 false)
  %t151 = load ptr, ptr %l1, !tbaa !29
  %t153 = getelementptr %"compiler/build:Config", ptr %t151, i32 0, i32 27
  %t154 = load i1, ptr %t153, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t155, ptr %v1, i1 %t154)
  call void @llvm.memmove.p0.p0.i64(ptr %l88, ptr %t155, i64 704, i1 false)
  br label %bb39
bb39:
  %t157 = call ptr @__olang_scope_alloc_a(ptr %v1, i64 704, i64 8)
  store ptr %t157, ptr %lp14
  %t158 = load ptr, ptr %lp14
  call void @llvm.memmove.p0.p0.i64(ptr %t158, ptr %l88, i64 704, i1 false)
  %t159 = load ptr, ptr %l1, !tbaa !29
  %t160 = load ptr, ptr %l0, !tbaa !29
  %t161 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t162 = load ptr, ptr %lp14
  %t163 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 8
  %t170 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eraceBinary_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %v0, ptr %v2, ptr %v1, ptr %s6, ptr %s0, ptr %s6, ptr %t159, ptr %t160, { i64, ptr } %t161, ptr %t162, ptr %l13, ptr %t163)
  store { i32, { i64, ptr } } %t170, ptr %l95
  br label %bb40
bb40:
  %t171 = load { i32, { i64, ptr } }, ptr %l95
  store { i32, { i64, ptr } } %t171, ptr %l15
  %t172 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 0
  %t173 = load i32, ptr %t172, !tbaa !23
  store i32 %t173, ptr %l10, !tbaa !23
  %t175 = getelementptr { i32, { i64, ptr } }, ptr %l15, i32 0, i32 1
  %t176 = load { i64, ptr }, ptr %t175, !tbaa !27
  store { i64, ptr } %t176, ptr %l97, !tbaa !27
  %t177 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t178 = extractvalue { i64, ptr } %t177, 0
  %t179 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 0
  store i64 %t180, ptr %l99, !tbaa !24
  %t182 = load i64, ptr %l99, !tbaa !24
  %t183 = icmp eq i64 %t178, %t182
  br i1 %t183, label %bb41, label %bb42
bb41:
  %t185 = getelementptr { i64, ptr }, ptr %l12, i32 0, i32 1
  %t186 = load ptr, ptr %t185, !tbaa !27
  %t187 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t188 = load ptr, ptr %t187, !tbaa !27
  %t189 = load i64, ptr %l99, !tbaa !24
  %t190 = mul i64 %t189, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t186, ptr %t188, i64 %t190, i1 false)
  br label %bb43
bb42:
  %t191 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l101, !tbaa !24
  %t193 = load i64, ptr %l101, !tbaa !24
  %t194 = mul i64 %t193, 1
  %t195 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t194)
  %t196 = insertvalue { i64, ptr } undef, i64 %t193, 0
  %t197 = insertvalue { i64, ptr } %t196, ptr %t195, 1
  store { i64, ptr } %t197, ptr %l102, !tbaa !27
  %t198 = getelementptr { i64, ptr }, ptr %l102, i32 0, i32 1
  %t199 = load ptr, ptr %t198, !tbaa !27
  %t200 = getelementptr { i64, ptr }, ptr %l97, i32 0, i32 1
  %t201 = load ptr, ptr %t200, !tbaa !27
  %t202 = load i64, ptr %l101, !tbaa !24
  %t203 = mul i64 %t202, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t199, ptr %t201, i64 %t203, i1 false)
  %t204 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t204, ptr %l12, !tbaa !27
  br label %bb43
bb43:
  %t205 = load i32, ptr %l10, !tbaa !23
  %t207 = icmp sge i32 %t205, 0
  br i1 %t207, label %bb44, label %bb45
bb44:
  %t209 = load i32, ptr %l10, !tbaa !23
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t209, ptr %rv
  br label %ret
bb45:
  br label %bb46
bb46:
  call void @__olang_scope_close(ptr %s6)
  br label %bb47
bb47:
  call void @compiler_2fspin_2eEnd()
  br label %bb48
bb48:
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t212 = load { i64, ptr }, ptr %l2, !tbaa !27
  call void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v1, ptr %v2, ptr %t211, { i64, ptr } %t212)
  br label %bb49
bb49:
  %t215 = load ptr, ptr %l1, !tbaa !29
  %t216 = load ptr, ptr %l3, !tbaa !29
  %t219 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v3, ptr %s0, ptr %t215, ptr %t216)
  %t220 = extractvalue { i32, { i64, ptr } } %t219, 1
  %t221 = extractvalue { i32, { i64, ptr } } %t219, 0
  store i32 %t221, ptr %l112
  %t222 = icmp ne i32 %t221, 0
  br i1 %t222, label %bb51, label %ok.223, !prof !99
ok.223:
  store { i64, ptr } %t220, ptr %l111
  br label %bb50
bb50:
  %t224 = load { i64, ptr }, ptr %l111, !tbaa !27
  store { i64, ptr } %t224, ptr %l108, !tbaa !27
  br label %bb54
bb51:
  %t225 = load i32, ptr %l112, !tbaa !23
  %t226 = ashr i32 %t225, 16
  %t228 = icmp eq i32 %t226, 1
  store i1 %t228, ptr %l114, !tbaa !21
  br label %bb52
bb52:
  %t229 = load ptr, ptr %l3, !tbaa !29
  %t231 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t229)
  store i32 %t231, ptr %l116
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s0)
  %t232 = load i32, ptr %l116, !tbaa !23
  store i32 %t232, ptr %rv
  br label %ret
bb54:
  %t233 = load { i64, ptr }, ptr %l108, !tbaa !27
  store { i64, ptr } %t233, ptr %l16, !tbaa !27
  %t234 = load ptr, ptr %l1, !tbaa !29
  %t236 = getelementptr %"compiler/build:Config", ptr %t234, i32 0, i32 11
  %t237 = load { i64, ptr }, ptr %t236, !tbaa !27
  %t239 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t237, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) })
  store i1 %t239, ptr %l119
  br label %bb55
bb55:
  %t240 = load i1, ptr %l119, !tbaa !21
  %t241 = xor i1 %t240, true
  br i1 %t241, label %bb56, label %bb57
bb56:
  store %olang.scope zeroinitializer, ptr %s9
  %t243 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s9, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t243, ptr %l121
  br label %bb58
bb57:
  br label %bb69
bb58:
  %t244 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l121
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t244, ptr %l17
  %t245 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t245, ptr %l18, !tbaa !27
  store i64 0, ptr %l19, !tbaa !24
  %t247 = load { i64, ptr }, ptr %l18, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t247, 0
  store i64 %t249, ptr %l20, !tbaa !24
  br label %bb59
bb59:
  %t251 = load i64, ptr %l19, !tbaa !24
  %t252 = load i64, ptr %l20, !tbaa !24
  %t255 = icmp slt i64 %t251, %t252
  %t257 = xor i1 %t255, true
  br i1 %t257, label %bb60, label %bb61
bb60:
  br label %bb65
bb61:
  br label %bb62
bb62:
  %t259 = load { i64, ptr }, ptr %l18, !tbaa !27
  store { i64, ptr } %t259, ptr %l129, !tbaa !27
  %t260 = load i64, ptr %l19, !tbaa !24
  %t262 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t263 = load ptr, ptr %t262, !tbaa !27
  %t264 = getelementptr { i64, ptr }, ptr %t263, i64 %t260
  %t265 = load { i64, ptr }, ptr %t264, !tbaa !37
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s9, ptr %s0, ptr %l17, { i64, ptr } %t265)
  br label %bb63
bb63:
  br label %bb64
bb64:
  %t270 = load i64, ptr %l19, !tbaa !24
  %t272 = add i64 %t270, 1
  store i64 %t272, ptr %l19, !tbaa !24
  br label %bb59
bb65:
  store ptr %l17, ptr %l136, !tbaa !29
  %t274 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t276 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s9, { i64, ptr } %t274)
  store { i64, ptr } %t276, ptr %l138
  br label %bb66
bb66:
  %t277 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 0
  %t279 = extractvalue { i64, ptr } %t277, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s9, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  %t284 = load ptr, ptr %l136, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s9, ptr %s9, ptr %t284, { i64, ptr } %t283)
  br label %bb67
bb67:
  %t286 = load ptr, ptr %l1, !tbaa !29
  %t290 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v1, ptr %s9, ptr %s0, ptr %t286, ptr %l17, ptr %l8)
  store i32 %t290, ptr %l143
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t291 = load i32, ptr %l143, !tbaa !23
  store i32 %t291, ptr %rv
  br label %ret
bb69:
  %t292 = load i1, ptr %l7, !tbaa !21
  %t294 = xor i1 %t292, true
  br i1 %t294, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s13
  %t296 = load ptr, ptr %l1, !tbaa !29
  store ptr %t296, ptr %l146, !tbaa !29
  %t297 = load ptr, ptr %l1, !tbaa !29
  store ptr %t297, ptr %l147, !tbaa !29
  %t298 = load { i64, ptr }, ptr %l16, !tbaa !27
  store { i64, ptr } %t298, ptr %l148, !tbaa !27
  %t299 = load { i64, ptr }, ptr %l11, !tbaa !27
  store { i64, ptr } %t299, ptr %l149, !tbaa !27
  %t300 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t300, ptr %l150, !tbaa !27
  %t301 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t301, ptr %l151, !tbaa !27
  %t302 = call i64 @std_2ftime_2eNow()
  store i64 %t302, ptr %l152
  br label %bb72
bb71:
  br label %bb75
bb72:
  %t303 = load i64, ptr %l5, !tbaa !24
  %t304 = load i64, ptr %l152, !tbaa !24
  %t306 = sub i64 %t304, %t303
  %t307 = load ptr, ptr %l147, !tbaa !29
  %t308 = load { i64, ptr }, ptr %l148, !tbaa !27
  %t309 = load { i64, ptr }, ptr %l149, !tbaa !27
  %t310 = load { i64, ptr }, ptr %l150, !tbaa !27
  %t311 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t313 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v4, ptr %s13, ptr %t307, { i64, ptr } %t308, { i64, ptr } %t309, { i64, ptr } %t310, { i64, ptr } %t311, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) }, i64 %t306)
  store i32 %t313, ptr %l155
  br label %bb73
bb73:
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t315 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t316 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 7
  %t317 = load ptr, ptr %l146, !tbaa !29
  %t318 = load i32, ptr %l155, !tbaa !23
  %t322 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v1, ptr %v2, ptr %v4, ptr %s0, ptr %t317, i32 %t318, { i64, ptr } %t314, { i64, ptr } %t315, ptr %t316)
  store i32 %t322, ptr %l159
  br label %bb74
bb74:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t323 = load i32, ptr %l159, !tbaa !23
  store i32 %t323, ptr %rv
  br label %ret
bb75:
  %t324 = load ptr, ptr %l1, !tbaa !29
  %t325 = load { i64, ptr }, ptr %l16, !tbaa !27
  %t326 = load { i64, ptr }, ptr %l11, !tbaa !27
  %t327 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t328 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t329 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t330 = getelementptr %"compiler/build:Program", ptr %l8, i32 0, i32 7
  %t338 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunParts(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %v2, ptr %v4, ptr %s0, ptr %t324, { i64, ptr } %t325, { i64, ptr } %t326, { i64, ptr } %t327, { i64, ptr } %t328, { i64, ptr } %t329, ptr %t330)
  store i32 %t338, ptr %l167
  br label %bb76
bb76:
  call void @__olang_scope_close(ptr %s0)
  %t339 = load i32, ptr %l167, !tbaa !23
  store i32 %t339, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eraceBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, ptr %a5) #0 {
entry:
  %l0 = alloca ptr
  %l6 = alloca i1
  %l7 = alloca { i32, { i64, ptr } }
  %l8 = alloca i32
  %lp9 = alloca ptr
  %l15 = alloca ptr
  %l17 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l19 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l27 = alloca { i32, { i64, ptr } }
  %l29 = alloca { i64, ptr }
  %l30 = alloca i64
  %l31 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 5
  %t4 = load i1, ptr %t3, !tbaa !21
  store i1 %t4, ptr %l6, !tbaa !21
  %t6 = load ptr, ptr %l0, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t6, i32 0, i32 6
  store i1 true, ptr %t8, !tbaa !21
  %t9 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 5
  store i1 false, ptr %t11, !tbaa !21
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 24
  store i64 2, ptr %t14, !tbaa !24
  %t15 = load ptr, ptr %l0, !tbaa !29
  store ptr %t15, ptr %l15, !tbaa !29
  %t18 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a5
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t18, ptr %l17
  %t20 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %l17)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %l19
  br label %bb1
bb1:
  %t21 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l19
  %t22 = load ptr, ptr %l15, !tbaa !29
  %t23 = getelementptr %"compiler/build:Config", ptr %t22, i32 0, i32 25
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t21, ptr %t23
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t26 = getelementptr %"compiler/build:Config", ptr %t24, i32 0, i32 3
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eSetBool(ptr %v0, ptr %s0, ptr %t26, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d24, i32 0, i32 1) }, i1 true)
  br label %bb2
bb2:
  %t28 = load ptr, ptr %l0, !tbaa !29
  %t38 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %s0, ptr %t28, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, i1 false)
  store { i32, { i64, ptr } } %t38, ptr %l27
  br label %bb3
bb3:
  %t39 = load { i32, { i64, ptr } }, ptr %l27
  store { i32, { i64, ptr } } %t39, ptr %l7
  %t40 = getelementptr { i32, { i64, ptr } }, ptr %l7, i32 0, i32 0
  %t41 = load i32, ptr %t40, !tbaa !23
  store i32 %t41, ptr %l8, !tbaa !23
  %t43 = getelementptr { i32, { i64, ptr } }, ptr %l7, i32 0, i32 1
  %t44 = load { i64, ptr }, ptr %t43, !tbaa !27
  store { i64, ptr } %t44, ptr %l29, !tbaa !27
  %t45 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t45, 0
  store i64 %t46, ptr %l30, !tbaa !24
  %t47 = load i64, ptr %l30, !tbaa !24
  %t48 = mul i64 %t47, 1
  %t49 = call ptr @__olang_scope_alloc(ptr %v6, i64 %t48)
  %t50 = insertvalue { i64, ptr } undef, i64 %t47, 0
  %t51 = insertvalue { i64, ptr } %t50, ptr %t49, 1
  store { i64, ptr } %t51, ptr %l31, !tbaa !27
  %t52 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t53 = load ptr, ptr %t52, !tbaa !27
  %t54 = getelementptr { i64, ptr }, ptr %l29, i32 0, i32 1
  %t55 = load ptr, ptr %t54, !tbaa !27
  %t56 = load i64, ptr %l30, !tbaa !24
  %t57 = mul i64 %t56, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t53, ptr %t55, i64 %t57, i1 false)
  %t58 = call ptr @__olang_scope_alloc_a(ptr %v6, i64 16, i64 8)
  store ptr %t58, ptr %lp9
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = load ptr, ptr %lp9
  store { i64, ptr } %t59, ptr %t60, !tbaa !27
  %t61 = load ptr, ptr %l0, !tbaa !29
  %t63 = getelementptr %"compiler/build:Config", ptr %t61, i32 0, i32 6
  store i1 false, ptr %t63, !tbaa !21
  %t64 = load ptr, ptr %l0, !tbaa !29
  %t65 = load i1, ptr %l6, !tbaa !21
  %t68 = getelementptr %"compiler/build:Config", ptr %t64, i32 0, i32 5
  store i1 %t65, ptr %t68, !tbaa !21
  %t69 = load ptr, ptr %l0, !tbaa !29
  %t71 = getelementptr %"compiler/build:Config", ptr %t69, i32 0, i32 3
  call void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eSetBool(ptr %v0, ptr %s0, ptr %t71, { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d25, i32 0, i32 1) }, i1 false)
  br label %bb4
bb4:
  %t73 = load i32, ptr %l8, !tbaa !23
  %t74 = load ptr, ptr %lp9
  %t75 = load { i64, ptr }, ptr %t74, !tbaa !27
  %t77 = insertvalue { i32, { i64, ptr } } undef, i32 %t73, 0
  %t79 = insertvalue { i32, { i64, ptr } } %t77, { i64, ptr } %t75, 1
  call void @__olang_scope_close(ptr %s0)
  store { i32, { i64, ptr } } %t79, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestBinary_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3, ptr %a4, i1 %a5) #0 {
entry:
  %l0 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca ptr
  %l6 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %lp7 = alloca ptr
  %l14 = alloca i32
  %l20 = alloca i32
  %l21 = alloca { i64, ptr }
  %l23 = alloca { i32, { i64, ptr } }
  %l24 = alloca { i64, ptr }
  %l25 = alloca i64
  %l26 = alloca { i64, ptr }
  %l27 = alloca i32
  %l28 = alloca { i64, ptr }
  %l30 = alloca { i32, { i64, ptr } }
  %l31 = alloca { i64, ptr }
  %l32 = alloca i64
  %l33 = alloca { i64, ptr }
  %l35 = alloca i64
  %l37 = alloca i1
  %l40 = alloca i64
  %l45 = alloca i32
  %l46 = alloca { i64, ptr }
  %l48 = alloca { i32, { i64, ptr } }
  %l49 = alloca { i64, ptr }
  %l50 = alloca i64
  %l51 = alloca { i64, ptr }
  %l53 = alloca i1
  %l57 = alloca i1
  %l60 = alloca i64
  %l62 = alloca { i64, ptr }
  %l64 = alloca { i32, { i64, ptr } }
  %l65 = alloca { i64, ptr }
  %l66 = alloca i64
  %l67 = alloca { i64, ptr }
  %l70 = alloca i32
  %l72 = alloca i1
  %l74 = alloca i32
  %l75 = alloca { i64, ptr }
  %l77 = alloca { i32, { i64, ptr } }
  %l78 = alloca { i64, ptr }
  %l79 = alloca i64
  %l80 = alloca { i64, ptr }
  %l81 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l85 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l86 = alloca i32
  %l88 = alloca i1
  %l90 = alloca i32
  %l91 = alloca { i64, ptr }
  %l93 = alloca { i32, { i64, ptr } }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i64
  %l96 = alloca { i64, ptr }
  %l98 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l104 = alloca { i64, ptr }
  %l106 = alloca ptr
  %l107 = alloca ptr
  %l108 = alloca { i64, ptr }
  %l111 = alloca i1
  %l115 = alloca i32
  %l117 = alloca i1
  %l122 = alloca { i64, ptr }
  %l124 = alloca { i64, ptr }
  %l126 = alloca { i32, { i64, ptr } }
  %l127 = alloca { i64, ptr }
  %l128 = alloca i64
  %l129 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %rv = alloca { i32, { i64, ptr } }
  store ptr %a0, ptr %l0
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t2 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = load ptr, ptr %l0, !tbaa !29
  %t4 = load ptr, ptr %l4, !tbaa !29
  %t5 = load ptr, ptr %l3, !tbaa !29
  %t12 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v1, ptr %v2, ptr %v0, ptr %v4, ptr %v3, ptr %a1, { i64, ptr } %t2, i32 2, ptr %t3, ptr %t4, ptr %t5)
  store i32 %t12, ptr %l14
  %t13 = icmp ne i32 %t12, 0
  br i1 %t13, label %bb2, label %ok.14, !prof !99
ok.14:
  br label %bb1
bb1:
  br label %bb11
bb2:
  %t15 = load i32, ptr %l14, !tbaa !23
  %t16 = icmp eq i32 %t15, 65536
  br i1 %t16, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t18 = load i32, ptr %l14, !tbaa !23
  %t19 = icmp eq i32 %t18, 65537
  br i1 %t19, label %bb6, label %bb7
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t22 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t23 = load ptr, ptr %l3, !tbaa !29
  %t27 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v2, ptr %v3, ptr %t21, { i64, ptr } %t22, ptr %t23)
  store i32 %t27, ptr %l20
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_d427f69e0d58601c_ef1499a0f9cee590)
  unreachable
bb8:
  %t28 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t28, ptr %l27
  br label %bb10
bb9:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d26, i32 0, i32 1) }, ptr %l21, !tbaa !27
  %t29 = load { i64, ptr }, ptr %l21, !tbaa !27
  %t30 = load i32, ptr %l20, !tbaa !23
  %t31 = insertvalue { i32, { i64, ptr } } undef, i32 %t30, 0
  %t33 = insertvalue { i32, { i64, ptr } } %t31, { i64, ptr } %t29, 1
  store { i32, { i64, ptr } } %t33, ptr %l23
  %t34 = getelementptr { i32, { i64, ptr } }, ptr %l23, i32 0, i32 1
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  store { i64, ptr } %t35, ptr %l24, !tbaa !27
  %t36 = load { i64, ptr }, ptr %l24, !tbaa !27
  %t37 = extractvalue { i64, ptr } %t36, 0
  store i64 %t37, ptr %l25, !tbaa !24
  %t38 = load i64, ptr %l25, !tbaa !24
  %t39 = mul i64 %t38, 1
  %t40 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t39)
  %t41 = insertvalue { i64, ptr } undef, i64 %t38, 0
  %t42 = insertvalue { i64, ptr } %t41, ptr %t40, 1
  store { i64, ptr } %t42, ptr %l26, !tbaa !27
  %t43 = getelementptr { i64, ptr }, ptr %l26, i32 0, i32 1
  %t44 = load ptr, ptr %t43, !tbaa !27
  %t45 = getelementptr { i64, ptr }, ptr %l24, i32 0, i32 1
  %t46 = load ptr, ptr %t45, !tbaa !27
  %t47 = load i64, ptr %l25, !tbaa !24
  %t48 = mul i64 %t47, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t44, ptr %t46, i64 %t48, i1 false)
  %t49 = load { i64, ptr }, ptr %l26, !tbaa !27
  %t50 = getelementptr { i32, { i64, ptr } }, ptr %l23, i32 0, i32 1
  store { i64, ptr } %t49, ptr %t50, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t51 = load { i32, { i64, ptr } }, ptr %l23
  store { i32, { i64, ptr } } %t51, ptr %rv
  br label %ret
bb10:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d27, i32 0, i32 1) }, ptr %l28, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l28, !tbaa !27
  %t53 = load i32, ptr %l27, !tbaa !23
  %t54 = insertvalue { i32, { i64, ptr } } undef, i32 %t53, 0
  %t56 = insertvalue { i32, { i64, ptr } } %t54, { i64, ptr } %t52, 1
  store { i32, { i64, ptr } } %t56, ptr %l30
  %t57 = getelementptr { i32, { i64, ptr } }, ptr %l30, i32 0, i32 1
  %t58 = load { i64, ptr }, ptr %t57, !tbaa !27
  store { i64, ptr } %t58, ptr %l31, !tbaa !27
  %t59 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  store i64 %t60, ptr %l32, !tbaa !24
  %t61 = load i64, ptr %l32, !tbaa !24
  %t62 = mul i64 %t61, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t62)
  %t64 = insertvalue { i64, ptr } undef, i64 %t61, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  store { i64, ptr } %t65, ptr %l33, !tbaa !27
  %t66 = getelementptr { i64, ptr }, ptr %l33, i32 0, i32 1
  %t67 = load ptr, ptr %t66, !tbaa !27
  %t68 = getelementptr { i64, ptr }, ptr %l31, i32 0, i32 1
  %t69 = load ptr, ptr %t68, !tbaa !27
  %t70 = load i64, ptr %l32, !tbaa !24
  %t71 = mul i64 %t70, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t67, ptr %t69, i64 %t71, i1 false)
  %t72 = load { i64, ptr }, ptr %l33, !tbaa !27
  %t73 = getelementptr { i32, { i64, ptr } }, ptr %l30, i32 0, i32 1
  store { i64, ptr } %t72, ptr %t73, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t74 = load { i32, { i64, ptr } }, ptr %l30
  store { i32, { i64, ptr } } %t74, ptr %rv
  br label %ret
bb11:
  %t75 = load ptr, ptr %l3, !tbaa !29
  %t77 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v3, ptr %t75)
  store i64 %t77, ptr %l35
  br label %bb12
bb12:
  %t78 = load i64, ptr %l35, !tbaa !24
  %t79 = icmp sgt i64 %t78, 0
  br i1 %t79, label %bb13, label %bb14
bb13:
  store i1 true, ptr %l37, !tbaa !21
  br label %bb16
bb14:
  %t81 = load ptr, ptr %l4, !tbaa !29
  %t83 = getelementptr %"compiler/build:Program", ptr %t81, i32 0, i32 0
  %t85 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t83)
  store i64 %t85, ptr %l40
  br label %bb15
bb15:
  %t86 = load i64, ptr %l40, !tbaa !24
  %t87 = icmp eq i64 %t86, 0
  store i1 %t87, ptr %l37, !tbaa !21
  br label %bb16
bb16:
  %t89 = load i1, ptr %l37, !tbaa !21
  br i1 %t89, label %bb17, label %bb18
bb17:
  %t90 = load ptr, ptr %l0, !tbaa !29
  %t91 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = load ptr, ptr %l3, !tbaa !29
  %t96 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v2, ptr %v3, ptr %t90, { i64, ptr } %t91, ptr %t92)
  store i32 %t96, ptr %l45
  br label %bb19
bb18:
  br label %bb20
bb19:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d28, i32 0, i32 1) }, ptr %l46, !tbaa !27
  %t97 = load { i64, ptr }, ptr %l46, !tbaa !27
  %t98 = load i32, ptr %l45, !tbaa !23
  %t99 = insertvalue { i32, { i64, ptr } } undef, i32 %t98, 0
  %t101 = insertvalue { i32, { i64, ptr } } %t99, { i64, ptr } %t97, 1
  store { i32, { i64, ptr } } %t101, ptr %l48
  %t102 = getelementptr { i32, { i64, ptr } }, ptr %l48, i32 0, i32 1
  %t103 = load { i64, ptr }, ptr %t102, !tbaa !27
  store { i64, ptr } %t103, ptr %l49, !tbaa !27
  %t104 = load { i64, ptr }, ptr %l49, !tbaa !27
  %t105 = extractvalue { i64, ptr } %t104, 0
  store i64 %t105, ptr %l50, !tbaa !24
  %t106 = load i64, ptr %l50, !tbaa !24
  %t107 = mul i64 %t106, 1
  %t108 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t107)
  %t109 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t110 = insertvalue { i64, ptr } %t109, ptr %t108, 1
  store { i64, ptr } %t110, ptr %l51, !tbaa !27
  %t111 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t112 = load ptr, ptr %t111, !tbaa !27
  %t113 = getelementptr { i64, ptr }, ptr %l49, i32 0, i32 1
  %t114 = load ptr, ptr %t113, !tbaa !27
  %t115 = load i64, ptr %l50, !tbaa !24
  %t116 = mul i64 %t115, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t112, ptr %t114, i64 %t116, i1 false)
  %t117 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t118 = getelementptr { i32, { i64, ptr } }, ptr %l48, i32 0, i32 1
  store { i64, ptr } %t117, ptr %t118, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t119 = load { i32, { i64, ptr } }, ptr %l48
  store { i32, { i64, ptr } } %t119, ptr %rv
  br label %ret
bb20:
  br i1 %a5, label %bb21, label %bb22
bb21:
  %t122 = load ptr, ptr %l4, !tbaa !29
  %t124 = getelementptr %"compiler/build:Program", ptr %t122, i32 0, i32 9
  %t125 = load i64, ptr %t124, !tbaa !24
  %t127 = icmp eq i64 %t125, 0
  store i1 %t127, ptr %l53, !tbaa !21
  br label %bb23
bb22:
  store i1 false, ptr %l53, !tbaa !21
  br label %bb23
bb23:
  %t129 = load i1, ptr %l53, !tbaa !21
  br i1 %t129, label %bb24, label %bb25
bb24:
  %t130 = load ptr, ptr %l4, !tbaa !29
  %t132 = getelementptr %"compiler/build:Program", ptr %t130, i32 0, i32 8
  %t134 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v4, ptr %t132)
  store i64 %t134, ptr %l60
  br label %bb26
bb25:
  store i1 false, ptr %l57, !tbaa !21
  br label %bb27
bb26:
  %t135 = load i64, ptr %l60, !tbaa !24
  %t136 = icmp sgt i64 %t135, 0
  store i1 %t136, ptr %l57, !tbaa !21
  br label %bb27
bb27:
  %t138 = load i1, ptr %l57, !tbaa !21
  br i1 %t138, label %bb28, label %bb29
bb28:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d29, i32 0, i32 1) }, ptr %l62, !tbaa !27
  %t139 = load { i64, ptr }, ptr %l62, !tbaa !27
  %t140 = insertvalue { i32, { i64, ptr } } undef, i32 -2, 0
  %t142 = insertvalue { i32, { i64, ptr } } %t140, { i64, ptr } %t139, 1
  store { i32, { i64, ptr } } %t142, ptr %l64
  %t143 = getelementptr { i32, { i64, ptr } }, ptr %l64, i32 0, i32 1
  %t144 = load { i64, ptr }, ptr %t143, !tbaa !27
  store { i64, ptr } %t144, ptr %l65, !tbaa !27
  %t145 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 0
  store i64 %t146, ptr %l66, !tbaa !24
  %t147 = load i64, ptr %l66, !tbaa !24
  %t148 = mul i64 %t147, 1
  %t149 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t148)
  %t150 = insertvalue { i64, ptr } undef, i64 %t147, 0
  %t151 = insertvalue { i64, ptr } %t150, ptr %t149, 1
  store { i64, ptr } %t151, ptr %l67, !tbaa !27
  %t152 = getelementptr { i64, ptr }, ptr %l67, i32 0, i32 1
  %t153 = load ptr, ptr %t152, !tbaa !27
  %t154 = getelementptr { i64, ptr }, ptr %l65, i32 0, i32 1
  %t155 = load ptr, ptr %t154, !tbaa !27
  %t156 = load i64, ptr %l66, !tbaa !24
  %t157 = mul i64 %t156, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t153, ptr %t155, i64 %t157, i1 false)
  %t158 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t159 = getelementptr { i32, { i64, ptr } }, ptr %l64, i32 0, i32 1
  store { i64, ptr } %t158, ptr %t159, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t160 = load { i32, { i64, ptr } }, ptr %l64
  store { i32, { i64, ptr } } %t160, ptr %rv
  br label %ret
bb29:
  br label %bb30
bb30:
  %t161 = load ptr, ptr %l0, !tbaa !29
  %t162 = load ptr, ptr %l3, !tbaa !29
  %t165 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v3, ptr %t161, ptr %t162)
  store i32 %t165, ptr %l70
  %t166 = icmp ne i32 %t165, 0
  br i1 %t166, label %bb32, label %ok.167, !prof !99
ok.167:
  br label %bb31
bb31:
  br label %bb35
bb32:
  %t168 = load i32, ptr %l70, !tbaa !23
  %t169 = ashr i32 %t168, 16
  %t171 = icmp eq i32 %t169, 1
  store i1 %t171, ptr %l72, !tbaa !21
  br label %bb33
bb33:
  %t172 = load ptr, ptr %l3, !tbaa !29
  %t174 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t172)
  store i32 %t174, ptr %l74
  br label %bb34
bb34:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d30, i32 0, i32 1) }, ptr %l75, !tbaa !27
  %t175 = load { i64, ptr }, ptr %l75, !tbaa !27
  %t176 = load i32, ptr %l74, !tbaa !23
  %t177 = insertvalue { i32, { i64, ptr } } undef, i32 %t176, 0
  %t179 = insertvalue { i32, { i64, ptr } } %t177, { i64, ptr } %t175, 1
  store { i32, { i64, ptr } } %t179, ptr %l77
  %t180 = getelementptr { i32, { i64, ptr } }, ptr %l77, i32 0, i32 1
  %t181 = load { i64, ptr }, ptr %t180, !tbaa !27
  store { i64, ptr } %t181, ptr %l78, !tbaa !27
  %t182 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t183 = extractvalue { i64, ptr } %t182, 0
  store i64 %t183, ptr %l79, !tbaa !24
  %t184 = load i64, ptr %l79, !tbaa !24
  %t185 = mul i64 %t184, 1
  %t186 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t185)
  %t187 = insertvalue { i64, ptr } undef, i64 %t184, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t186, 1
  store { i64, ptr } %t188, ptr %l80, !tbaa !27
  %t189 = getelementptr { i64, ptr }, ptr %l80, i32 0, i32 1
  %t190 = load ptr, ptr %t189, !tbaa !27
  %t191 = getelementptr { i64, ptr }, ptr %l78, i32 0, i32 1
  %t192 = load ptr, ptr %t191, !tbaa !27
  %t193 = load i64, ptr %l79, !tbaa !24
  %t194 = mul i64 %t193, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t190, ptr %t192, i64 %t194, i1 false)
  %t195 = load { i64, ptr }, ptr %l80, !tbaa !27
  %t196 = getelementptr { i32, { i64, ptr } }, ptr %l77, i32 0, i32 1
  store { i64, ptr } %t195, ptr %t196, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t197 = load { i32, { i64, ptr } }, ptr %l77
  store { i32, { i64, ptr } } %t197, ptr %rv
  br label %ret
bb35:
  %t198 = load ptr, ptr %l0, !tbaa !29
  %t199 = load ptr, ptr %l4, !tbaa !29
  %t200 = load ptr, ptr %l3, !tbaa !29
  %t204 = call { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v4, ptr %v3, ptr %v3, ptr %t198, ptr %t199, ptr %t200)
  %t205 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t204, 1
  %t206 = extractvalue { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } %t204, 0
  store i32 %t206, ptr %l86
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb37, label %ok.208, !prof !99
ok.208:
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t205, ptr %l85
  br label %bb36
bb36:
  %t209 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l85
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t209, ptr %l81
  br label %bb40
bb37:
  %t210 = load i32, ptr %l86, !tbaa !23
  %t211 = ashr i32 %t210, 16
  %t213 = icmp eq i32 %t211, 1
  store i1 %t213, ptr %l88, !tbaa !21
  br label %bb38
bb38:
  %t214 = load ptr, ptr %l3, !tbaa !29
  %t216 = call i32 @compiler_2fbuild_2efinish(ptr %v3, ptr %t214)
  store i32 %t216, ptr %l90
  br label %bb39
bb39:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d31, i32 0, i32 1) }, ptr %l91, !tbaa !27
  %t217 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t218 = load i32, ptr %l90, !tbaa !23
  %t219 = insertvalue { i32, { i64, ptr } } undef, i32 %t218, 0
  %t221 = insertvalue { i32, { i64, ptr } } %t219, { i64, ptr } %t217, 1
  store { i32, { i64, ptr } } %t221, ptr %l93
  %t222 = getelementptr { i32, { i64, ptr } }, ptr %l93, i32 0, i32 1
  %t223 = load { i64, ptr }, ptr %t222, !tbaa !27
  store { i64, ptr } %t223, ptr %l94, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t225 = extractvalue { i64, ptr } %t224, 0
  store i64 %t225, ptr %l95, !tbaa !24
  %t226 = load i64, ptr %l95, !tbaa !24
  %t227 = mul i64 %t226, 1
  %t228 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t227)
  %t229 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t230 = insertvalue { i64, ptr } %t229, ptr %t228, 1
  store { i64, ptr } %t230, ptr %l96, !tbaa !27
  %t231 = getelementptr { i64, ptr }, ptr %l96, i32 0, i32 1
  %t232 = load ptr, ptr %t231, !tbaa !27
  %t233 = getelementptr { i64, ptr }, ptr %l94, i32 0, i32 1
  %t234 = load ptr, ptr %t233, !tbaa !27
  %t235 = load i64, ptr %l95, !tbaa !24
  %t236 = mul i64 %t235, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t232, ptr %t234, i64 %t236, i1 false)
  %t237 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t238 = getelementptr { i32, { i64, ptr } }, ptr %l93, i32 0, i32 1
  store { i64, ptr } %t237, ptr %t238, !tbaa !27
  call void @__olang_scope_close(ptr %s0)
  %t239 = load { i32, { i64, ptr } }, ptr %l93
  store { i32, { i64, ptr } } %t239, ptr %rv
  br label %ret
bb40:
  %t240 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l81
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t240, ptr %l6
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d32, i32 0, i32 1) })
  br label %bb41
bb41:
  %t241 = load ptr, ptr %l0, !tbaa !29
  %t243 = getelementptr %"compiler/build:Config", ptr %t241, i32 0, i32 0
  %t244 = load { i64, ptr }, ptr %t243, !tbaa !27
  store { i64, ptr } %t244, ptr %l98, !tbaa !27
  %t245 = load ptr, ptr %l4, !tbaa !29
  %t247 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v4, ptr %s0, ptr %t245)
  store { i64, ptr } %t247, ptr %l100
  br label %bb42
bb42:
  %t248 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t249 = extractvalue { i64, ptr } %t248, 0
  %t250 = extractvalue { i64, ptr } %t248, 1
  %t251 = mul i64 %t249, 1
  %t252 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t251)
  call void @llvm.memcpy.p0.p0.i64(ptr %t252, ptr %t250, i64 %t251, i1 false)
  %t253 = insertvalue { i64, ptr } undef, i64 %t249, 0
  %t254 = insertvalue { i64, ptr } %t253, ptr %t252, 1
  %t256 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t254)
  store { i64, ptr } %t256, ptr %l102
  br label %bb43
bb43:
  %t257 = load ptr, ptr %l0, !tbaa !29
  %t259 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %s0, ptr %t257)
  store { i64, ptr } %t259, ptr %l104
  br label %bb44
bb44:
  %t260 = load { i64, ptr }, ptr %l98, !tbaa !27
  %t261 = extractvalue { i64, ptr } %t260, 1
  %t262 = extractvalue { i64, ptr } %t260, 0
  %t263 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 1
  %t264 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d33, i32 0, i32 1) }, 0
  %t265 = add i64 %t262, %t264
  %t266 = load { i64, ptr }, ptr %l102, !tbaa !27
  %t267 = extractvalue { i64, ptr } %t266, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = add i64 %t265, %t268
  %t270 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d34, i32 0, i32 1) }, 0
  %t272 = add i64 %t269, %t271
  %t273 = load { i64, ptr }, ptr %l104, !tbaa !27
  %t274 = extractvalue { i64, ptr } %t273, 1
  %t275 = extractvalue { i64, ptr } %t273, 0
  %t276 = add i64 %t272, %t275
  %t277 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t276)
  call void @olang_textcopy(ptr %t277, ptr %t261, i64 %t262)
  %t278 = getelementptr i8, ptr %t277, i64 %t262
  call void @olang_textcopy(ptr %t278, ptr %t263, i64 %t264)
  %t279 = getelementptr i8, ptr %t278, i64 %t264
  call void @olang_textcopy(ptr %t279, ptr %t267, i64 %t268)
  %t280 = getelementptr i8, ptr %t279, i64 %t268
  call void @olang_textcopy(ptr %t280, ptr %t270, i64 %t271)
  %t281 = getelementptr i8, ptr %t280, i64 %t271
  call void @olang_textcopy(ptr %t281, ptr %t274, i64 %t275)
  %t282 = insertvalue { i64, ptr } undef, i64 %t276, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t277, 1
  %t284 = call ptr @__olang_scope_alloc_a(ptr %v5, i64 16, i64 8)
  store ptr %t284, ptr %lp7
  %t286 = load ptr, ptr %lp7
  store { i64, ptr } %t283, ptr %t286, !tbaa !27
  %t287 = load ptr, ptr %l0, !tbaa !29
  store ptr %t287, ptr %l106, !tbaa !29
  store ptr %l6, ptr %l107, !tbaa !29
  %t288 = load ptr, ptr %lp7
  %t289 = load { i64, ptr }, ptr %t288, !tbaa !27
  store { i64, ptr } %t289, ptr %l108, !tbaa !27
  %t290 = load ptr, ptr %l4, !tbaa !29
  %t292 = getelementptr %"compiler/build:Program", ptr %t290, i32 0, i32 2
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  %t295 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v4, ptr %s0, { i64, ptr } %t293, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d35, i32 0, i32 1) })
  store i1 %t295, ptr %l111
  br label %bb45
bb45:
  %t296 = load i1, ptr %l111, !tbaa !21
  %t297 = xor i1 %t296, true
  %t298 = load ptr, ptr %l4, !tbaa !29
  %t300 = getelementptr %"compiler/build:Program", ptr %t298, i32 0, i32 3
  %t301 = load ptr, ptr %l106, !tbaa !29
  %t302 = load ptr, ptr %l107, !tbaa !29
  %t303 = load { i64, ptr }, ptr %l108, !tbaa !27
  %t306 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v3, ptr %v5, ptr %v4, ptr %s0, ptr %t301, ptr %t302, { i64, ptr } %t303, i1 %t297, ptr %t300, ptr null)
  store i32 %t306, ptr %l115
  %t307 = icmp ne i32 %t306, 0
  br i1 %t307, label %bb47, label %ok.308, !prof !99
ok.308:
  br label %bb46
bb46:
  br label %bb51
bb47:
  %t309 = load i32, ptr %l115, !tbaa !23
  %t310 = ashr i32 %t309, 16
  %t312 = icmp eq i32 %t310, 1
  store i1 %t312, ptr %l117, !tbaa !21
  br label %bb48
bb48:
  store %olang.scope zeroinitializer, ptr %s8
  %t313 = load ptr, ptr %l0, !tbaa !29
  %t314 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t316 = extractvalue { i64, ptr } %t314, 1
  %t317 = extractvalue { i64, ptr } %t314, 0
  %t318 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d36, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d36, i32 0, i32 1) }, 0
  %t320 = add i64 %t317, %t319
  %t321 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t320)
  call void @olang_textcopy(ptr %t321, ptr %t316, i64 %t317)
  %t322 = getelementptr i8, ptr %t321, i64 %t317
  call void @olang_textcopy(ptr %t322, ptr %t318, i64 %t319)
  %t323 = insertvalue { i64, ptr } undef, i64 %t320, 0
  %t324 = insertvalue { i64, ptr } %t323, ptr %t321, 1
  %t326 = extractvalue { i64, ptr } %t324, 0
  %t327 = extractvalue { i64, ptr } %t324, 1
  %t328 = mul i64 %t326, 1
  %t329 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t328)
  call void @llvm.memcpy.p0.p0.i64(ptr %t329, ptr %t327, i64 %t328, i1 false)
  %t330 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t329, 1
  %t334 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %s8, ptr %s8, ptr %s8, ptr %t313, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d37, i32 0, i32 1) }, { i64, ptr } %t331)
  store { i64, ptr } %t334, ptr %l122
  br label %bb49
bb49:
  %t335 = load { i64, ptr }, ptr %l122, !tbaa !27
  %t336 = extractvalue { i64, ptr } %t335, 0
  %t337 = extractvalue { i64, ptr } %t335, 1
  %t338 = mul i64 %t336, 1
  %t339 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t338)
  call void @llvm.memcpy.p0.p0.i64(ptr %t339, ptr %t337, i64 %t338, i1 false)
  %t340 = insertvalue { i64, ptr } undef, i64 %t336, 0
  %t341 = insertvalue { i64, ptr } %t340, ptr %t339, 1
  call void @compiler_2fbuild_2esayln(ptr %s8, { i64, ptr } %t341)
  br label %bb50
bb50:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d38, i32 0, i32 1) }, ptr %l124, !tbaa !27
  %t343 = load { i64, ptr }, ptr %l124, !tbaa !27
  %t344 = insertvalue { i32, { i64, ptr } } undef, i32 1, 0
  %t346 = insertvalue { i32, { i64, ptr } } %t344, { i64, ptr } %t343, 1
  store { i32, { i64, ptr } } %t346, ptr %l126
  %t347 = getelementptr { i32, { i64, ptr } }, ptr %l126, i32 0, i32 1
  %t348 = load { i64, ptr }, ptr %t347, !tbaa !27
  store { i64, ptr } %t348, ptr %l127, !tbaa !27
  %t349 = load { i64, ptr }, ptr %l127, !tbaa !27
  %t350 = extractvalue { i64, ptr } %t349, 0
  store i64 %t350, ptr %l128, !tbaa !24
  %t351 = load i64, ptr %l128, !tbaa !24
  %t352 = mul i64 %t351, 1
  %t353 = call ptr @__olang_scope_alloc(ptr %v5, i64 %t352)
  %t354 = insertvalue { i64, ptr } undef, i64 %t351, 0
  %t355 = insertvalue { i64, ptr } %t354, ptr %t353, 1
  store { i64, ptr } %t355, ptr %l129, !tbaa !27
  %t356 = getelementptr { i64, ptr }, ptr %l129, i32 0, i32 1
  %t357 = load ptr, ptr %t356, !tbaa !27
  %t358 = getelementptr { i64, ptr }, ptr %l127, i32 0, i32 1
  %t359 = load ptr, ptr %t358, !tbaa !27
  %t360 = load i64, ptr %l128, !tbaa !24
  %t361 = mul i64 %t360, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t357, ptr %t359, i64 %t361, i1 false)
  %t362 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t363 = getelementptr { i32, { i64, ptr } }, ptr %l126, i32 0, i32 1
  store { i64, ptr } %t362, ptr %t363, !tbaa !27
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t364 = load { i32, { i64, ptr } }, ptr %l126
  store { i32, { i64, ptr } } %t364, ptr %rv
  br label %ret
bb51:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d39, i32 0, i32 1) })
  br label %bb52
bb52:
  %t365 = load ptr, ptr %lp7
  %t366 = load { i64, ptr }, ptr %t365, !tbaa !27
  %t367 = insertvalue { i32, { i64, ptr } } undef, i32 -1, 0
  %t369 = insertvalue { i32, { i64, ptr } } %t367, { i64, ptr } %t366, 1
  call void @__olang_scope_close(ptr %s0)
  store { i32, { i64, ptr } } %t369, ptr %rv
  br label %ret
ret:
  %rr = load { i32, { i64, ptr } }, ptr %rv
  ret { i32, { i64, ptr } } %rr
}

define dso_local i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4, ptr %a5) #0 {
entry:
  %l1 = alloca ptr
  %l4 = alloca i1
  %l5 = alloca ptr
  %l6 = alloca %"compiler/build:Program"
  %l7 = alloca %"compiler/build:Listed"
  %l12 = alloca %"compiler/build:Program"
  %l13 = alloca %"compiler/build:Listed"
  %l20 = alloca %"compiler/build:Listed"
  %l21 = alloca i32
  %l25 = alloca i32
  %l27 = alloca ptr
  %l28 = alloca ptr
  %l31 = alloca { i64, ptr }
  %l32 = alloca { i64, ptr }
  %l35 = alloca { i64, ptr }
  %l38 = alloca %"compiler/listing:Inputs"
  %l40 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %rv = alloca i32
  %t12 = alloca %"compiler/build:Program", align 8
  store ptr %a1, ptr %l1
  store i1 %a4, ptr %l4
  store ptr %a5, ptr %l5
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 17
  store i1 true, ptr %t3, !tbaa !21
  %t4 = load ptr, ptr %l1, !tbaa !29
  %t8 = getelementptr %"compiler/build:Config", ptr %t4, i32 0, i32 18
  store { i64, ptr } %a3, ptr %t8, !tbaa !27
  %t9 = load ptr, ptr %l1, !tbaa !29
  %t11 = getelementptr %"compiler/build:Config", ptr %t9, i32 0, i32 28
  store i1 true, ptr %t11, !tbaa !21
  call void @compiler_2fbuild_3aProgram_2ector(ptr %t12, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l12, ptr %t12, i64 264, i1 false)
  br label %bb1
bb1:
  call void @llvm.memmove.p0.p0.i64(ptr %l6, ptr %l12, i64 264, i1 false)
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t16 = load i1, ptr %l4, !tbaa !21
  %t17 = load ptr, ptr %l5, !tbaa !29
  %t24 = call { i32, %"compiler/build:Listed" } @compiler_2fbuild_2eListed_2eListingCode_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %s0, ptr %v4, ptr %s0, ptr %a0, ptr %t14, { i64, ptr } %a2, i1 %t16, ptr %l6, ptr %t17)
  %t25 = extractvalue { i32, %"compiler/build:Listed" } %t24, 1
  %t26 = extractvalue { i32, %"compiler/build:Listed" } %t24, 0
  store i32 %t26, ptr %l21
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb3, label %ok.28, !prof !99
ok.28:
  store %"compiler/build:Listed" %t25, ptr %l20
  br label %bb2
bb2:
  %t29 = load %"compiler/build:Listed", ptr %l20
  store %"compiler/build:Listed" %t29, ptr %l13
  br label %bb11
bb3:
  %t30 = load i32, ptr %l21, !tbaa !23
  %t31 = icmp eq i32 %t30, 65536
  br i1 %t31, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t33 = load i32, ptr %l21, !tbaa !23
  %t34 = icmp eq i32 %t33, 65537
  br i1 %t34, label %bb7, label %bb8
bb6:
  %t36 = load ptr, ptr %l5, !tbaa !29
  %t38 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t36)
  store i32 %t38, ptr %l25
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4ce37e8669e18741_b51ffe42b73135c5)
  unreachable
bb9:
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l25, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
bb11:
  %t41 = load %"compiler/build:Listed", ptr %l13
  store %"compiler/build:Listed" %t41, ptr %l7
  store ptr %l6, ptr %l27, !tbaa !29
  store ptr %l7, ptr %l28, !tbaa !29
  %t42 = load ptr, ptr %l1, !tbaa !29
  %t43 = load i1, ptr %l4, !tbaa !21
  %t46 = call { i64, ptr } @compiler_2flisting_2ehow(ptr %v1, ptr %s0, ptr %t42, i1 %t43)
  store { i64, ptr } %t46, ptr %l31
  br label %bb12
bb12:
  %t47 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t48 = extractvalue { i64, ptr } %t47, 0
  %t49 = extractvalue { i64, ptr } %t47, 1
  %t50 = mul i64 %t48, 1
  %t51 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t50)
  call void @llvm.memcpy.p0.p0.i64(ptr %t51, ptr %t49, i64 %t50, i1 false)
  %t52 = insertvalue { i64, ptr } undef, i64 %t48, 0
  %t53 = insertvalue { i64, ptr } %t52, ptr %t51, 1
  store { i64, ptr } %t53, ptr %l32, !tbaa !27
  %t54 = load ptr, ptr %l1, !tbaa !29
  %t55 = load i1, ptr %l4, !tbaa !21
  %t58 = call { i64, ptr } @compiler_2flisting_2ecommentOf(ptr %v1, ptr %s0, ptr %t54, i1 %t55)
  store { i64, ptr } %t58, ptr %l35
  br label %bb13
bb13:
  %t59 = load { i64, ptr }, ptr %l35, !tbaa !27
  %t60 = extractvalue { i64, ptr } %t59, 0
  %t61 = extractvalue { i64, ptr } %t59, 1
  %t62 = mul i64 %t60, 1
  %t63 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t62)
  call void @llvm.memcpy.p0.p0.i64(ptr %t63, ptr %t61, i64 %t62, i1 false)
  %t64 = insertvalue { i64, ptr } undef, i64 %t60, 0
  %t65 = insertvalue { i64, ptr } %t64, ptr %t63, 1
  %t66 = load i1, ptr %l4, !tbaa !21
  %t67 = load ptr, ptr %l27, !tbaa !29
  %t68 = load ptr, ptr %l28, !tbaa !29
  %t69 = load { i64, ptr }, ptr %l32, !tbaa !27
  %t72 = call %"compiler/listing:Inputs" @compiler_2flisting_3aInputs_2ector(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t67, ptr %t68, { i64, ptr } %t69, { i64, ptr } %t65, i1 %t66)
  store %"compiler/listing:Inputs" %t72, ptr %l38
  br label %bb14
bb14:
  %t73 = load %"compiler/listing:Inputs", ptr %l38
  %t74 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 56, i64 8)
  store %"compiler/listing:Inputs" %t73, ptr %t74
  %t76 = call { i64, ptr } @compiler_2flisting_2eRender(ptr %s0, ptr %s0, ptr %t74)
  store { i64, ptr } %t76, ptr %l40
  br label %bb15
bb15:
  %t77 = load { i64, ptr }, ptr %l40, !tbaa !27
  %t78 = extractvalue { i64, ptr } %t77, 0
  %t79 = extractvalue { i64, ptr } %t77, 1
  %t80 = mul i64 %t78, 1
  %t81 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t80)
  call void @llvm.memcpy.p0.p0.i64(ptr %t81, ptr %t79, i64 %t80, i1 false)
  %t82 = insertvalue { i64, ptr } undef, i64 %t78, 0
  %t83 = insertvalue { i64, ptr } %t82, ptr %t81, 1
  call void @compiler_2flisting_2esay(ptr %s0, { i64, ptr } %t83)
  br label %bb16
bb16:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l2 = alloca i32
  %l5 = alloca i32
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  %t5 = call i32 @compiler_2folang_2erunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
  store i32 %t5, ptr %l5
  br label %bb1
bb1:
  %t6 = load i32, ptr %l5, !tbaa !23
  store i32 %t6, ptr %l2, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb2
bb2:
  %t7 = load i32, ptr %l2, !tbaa !23
  store i32 %t7, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2erunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %lp9 = alloca ptr
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/diag:Diagnostics"
  %l16 = alloca %"compiler/build:Config"
  %l18 = alloca %"compiler/olang:CommandLine"
  %l22 = alloca %"compiler/olang:CommandLine"
  %l23 = alloca i32
  %l25 = alloca i1
  %l27 = alloca i32
  %l31 = alloca i1
  %l35 = alloca i1
  %l42 = alloca { i64, ptr }
  %l45 = alloca { i64, ptr }
  %l46 = alloca i32
  %l48 = alloca i1
  %l50 = alloca i32
  %l52 = alloca i32
  %l54 = alloca i1
  %l58 = alloca { i64, ptr }
  %l62 = alloca i1
  %l65 = alloca { i64, ptr }
  %l67 = alloca i32
  %l71 = alloca i1
  %l73 = alloca i1
  %l75 = alloca ptr
  %l76 = alloca ptr
  %l78 = alloca { i64, ptr }
  %l79 = alloca { i64, ptr }
  %l81 = alloca i1
  %l83 = alloca i32
  %l88 = alloca i64
  %l90 = alloca ptr
  %l91 = alloca ptr
  %l93 = alloca { i64, ptr }
  %l96 = alloca i32
  %l97 = alloca { i64, ptr }
  %l100 = alloca { i64, ptr }
  %l101 = alloca i32
  %l103 = alloca i1
  %l105 = alloca i32
  %l107 = alloca i32
  %l112 = alloca i32
  %l116 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l118 = alloca i32
  %l120 = alloca i1
  %l123 = alloca { i64, ptr }
  %l127 = alloca i1
  %l129 = alloca { i64, ptr }
  %l130 = alloca { i64, ptr }
  %l131 = alloca { i64, ptr }
  %l133 = alloca i32
  %l138 = alloca { i64, ptr }
  %l139 = alloca { i64, ptr }
  %l140 = alloca { i64, ptr }
  %l142 = alloca i32
  %l147 = alloca { i64, ptr }
  %l151 = alloca i32
  %l156 = alloca { i64, ptr }
  %l158 = alloca { i64, ptr }
  %l160 = alloca { i64, ptr }
  %l162 = alloca i32
  %l167 = alloca i32
  %l171 = alloca ptr
  %l172 = alloca { i64, ptr }
  %l173 = alloca { i64, ptr }
  %l174 = alloca i32
  %l176 = alloca i1
  %l179 = alloca { i64, ptr }
  %l183 = alloca i32
  %l185 = alloca { i64, ptr }
  %l191 = alloca { i64, ptr }
  %l194 = alloca i32
  %l200 = alloca { i64, ptr }
  %l203 = alloca i32
  %l207 = alloca ptr
  %l208 = alloca ptr
  %l209 = alloca { i64, ptr }
  %l210 = alloca { i64, ptr }
  %l212 = alloca { i64, ptr }
  %l214 = alloca i32
  %l218 = alloca ptr
  %l219 = alloca ptr
  %l220 = alloca { i64, ptr }
  %l221 = alloca { i64, ptr }
  %l223 = alloca { i64, ptr }
  %l225 = alloca i32
  %l231 = alloca i32
  %l235 = alloca i1
  %l237 = alloca { i64, ptr }
  %l238 = alloca { i64, ptr }
  %l239 = alloca i32
  %l241 = alloca i1
  %l244 = alloca { i64, ptr }
  %l249 = alloca i32
  %l254 = alloca { i64, ptr }
  %l256 = alloca i32
  %l261 = alloca { i64, ptr }
  %l265 = alloca i32
  %l269 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l271 = alloca { i64, ptr }
  %l276 = alloca i64
  %l278 = alloca i64
  %l283 = alloca { i64, ptr }
  %l288 = alloca ptr
  %l289 = alloca ptr
  %l290 = alloca { i64, ptr }
  %l291 = alloca { i64, ptr }
  %l293 = alloca { i64, ptr }
  %l295 = alloca i32
  %l299 = alloca i1
  %l301 = alloca ptr
  %l302 = alloca ptr
  %l303 = alloca { i64, ptr }
  %l304 = alloca { i64, ptr }
  %l305 = alloca ptr
  %l307 = alloca { i64, ptr }
  %l308 = alloca i32
  %l312 = alloca ptr
  %l313 = alloca ptr
  %l314 = alloca { i64, ptr }
  %l315 = alloca { i64, ptr }
  %l316 = alloca ptr
  %l318 = alloca { i64, ptr }
  %l319 = alloca i32
  %l320 = alloca { i64, ptr }
  %l321 = alloca { i64, ptr }
  %l322 = alloca i32
  %l324 = alloca i1
  %l327 = alloca { i64, ptr }
  %l331 = alloca ptr
  %l332 = alloca { i64, ptr }
  %l334 = alloca { i64, ptr }
  %l335 = alloca { i64, ptr }
  %l337 = alloca { i64, ptr }
  %l338 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s17 = alloca %olang.scope
  %s24 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  %t10 = alloca %"compiler/olang:CommandLine", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l14
  br label %bb1
bb1:
  %t3 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t2, i64 704, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l15, i64 704, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t4, i64 640, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 640, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 27
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t14 = call i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %t10, ptr %v0, ptr %s0, ptr %s0, ptr %v0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  store i32 %t14, ptr %l23
  %t15 = icmp ne i32 %t14, 0
  br i1 %t15, label %bb5, label %ok.16, !prof !99
ok.16:
  call void @llvm.memmove.p0.p0.i64(ptr %l22, ptr %t10, i64 248, i1 false)
  br label %bb4
bb4:
  call void @llvm.memmove.p0.p0.i64(ptr %l18, ptr %l22, i64 248, i1 false)
  br label %bb8
bb5:
  %t17 = load i32, ptr %l23, !tbaa !23
  %t18 = ashr i32 %t17, 16
  %t20 = icmp eq i32 %t18, 1
  store i1 %t20, ptr %l25, !tbaa !21
  br label %bb6
bb6:
  %t22 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t22, ptr %l27
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l27, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  call void @llvm.memmove.p0.p0.i64(ptr %l4, ptr %l18, i64 248, i1 false)
  %t24 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t25 = load i64, ptr %t24, !tbaa !24
  %t26 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t29 = icmp eq i64 %t25, %t26
  br i1 %t29, label %bb9, label %bb10
bb9:
  store i1 true, ptr %l31, !tbaa !21
  br label %bb11
bb10:
  %t31 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t32 = load i64, ptr %t31, !tbaa !24
  %t33 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t36 = icmp eq i64 %t32, %t33
  store i1 %t36, ptr %l31, !tbaa !21
  br label %bb11
bb11:
  %t38 = load i1, ptr %l31, !tbaa !21
  br i1 %t38, label %bb12, label %bb13
bb12:
  store i1 true, ptr %l35, !tbaa !21
  br label %bb14
bb13:
  %t39 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t40 = load i64, ptr %t39, !tbaa !24
  %t41 = load i64, ptr @G_2ecompiler_2folang_2eNotebook, !tbaa !24
  %t44 = icmp eq i64 %t40, %t41
  store i1 %t44, ptr %l35, !tbaa !21
  br label %bb14
bb14:
  %t46 = load i1, ptr %l35, !tbaa !21
  %t47 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 25
  store i1 %t46, ptr %t47, !tbaa !21
  %t48 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t49 = load i64, ptr %t48, !tbaa !24
  %t50 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t53 = icmp eq i64 %t49, %t50
  br i1 %t53, label %bb15, label %bb16
bb15:
  store %olang.scope zeroinitializer, ptr %s2
  %t57 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t58 = extractvalue { i32, { i64, ptr } } %t57, 1
  %t59 = extractvalue { i32, { i64, ptr } } %t57, 0
  store i32 %t59, ptr %l46
  %t60 = icmp ne i32 %t59, 0
  br i1 %t60, label %bb18, label %ok.61, !prof !99
ok.61:
  store { i64, ptr } %t58, ptr %l45
  br label %bb17
bb16:
  br label %bb23
bb17:
  %t62 = load { i64, ptr }, ptr %l45, !tbaa !27
  store { i64, ptr } %t62, ptr %l42, !tbaa !27
  br label %bb21
bb18:
  %t63 = load i32, ptr %l46, !tbaa !23
  %t64 = ashr i32 %t63, 16
  %t66 = icmp eq i32 %t64, 1
  store i1 %t66, ptr %l48, !tbaa !21
  br label %bb19
bb19:
  %t68 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t68, ptr %l50
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t69 = load i32, ptr %l50, !tbaa !23
  store i32 %t69, ptr %rv
  br label %ret
bb21:
  %t70 = load { i64, ptr }, ptr %l42, !tbaa !27
  %t73 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t70)
  store i32 %t73, ptr %l52
  br label %bb22
bb22:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t74 = load i32, ptr %l52, !tbaa !23
  store i32 %t74, ptr %rv
  br label %ret
bb23:
  %t76 = call i1 @compiler_2folang_2ewaits(ptr %v0, ptr %l4)
  store i1 %t76, ptr %l54
  br label %bb24
bb24:
  %t77 = load i1, ptr %l54, !tbaa !21
  br i1 %t77, label %bb25, label %bb26
bb25:
  store %olang.scope zeroinitializer, ptr %s4
  %t78 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t79 = load i64, ptr %t78, !tbaa !24
  %t80 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t83 = icmp eq i64 %t79, %t80
  br i1 %t83, label %bb27, label %bb28
bb26:
  br label %bb31
bb27:
  store { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d40, i32 0, i32 1) }, ptr %l58, !tbaa !27
  br label %bb29
bb28:
  store { i64, ptr } { i64 9, ptr getelementptr inbounds (<{ i64, [9 x i8] }>, ptr @.d41, i32 0, i32 1) }, ptr %l58, !tbaa !27
  br label %bb29
bb29:
  %t85 = load { i64, ptr }, ptr %l58, !tbaa !27
  call void @compiler_2fspin_2eBegin(ptr %s4, { i64, ptr } %t85)
  br label %bb30
bb30:
  call void @__olang_scope_close(ptr %s4)
  br label %bb31
bb31:
  %t86 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t87 = load i64, ptr %t86, !tbaa !24
  %t88 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t91 = icmp eq i64 %t87, %t88
  br i1 %t91, label %bb32, label %bb33
bb32:
  %t93 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 11
  %t94 = load i1, ptr %t93, !tbaa !21
  store i1 %t94, ptr %l62, !tbaa !21
  br label %bb34
bb33:
  store i1 false, ptr %l62, !tbaa !21
  br label %bb34
bb34:
  %t96 = load i1, ptr %l62, !tbaa !21
  br i1 %t96, label %bb35, label %bb36
bb35:
  %t97 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t99 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t97, i64 0)
  store { i64, ptr } %t99, ptr %l65
  br label %bb37
bb36:
  br label %bb39
bb37:
  %t100 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t102 = call i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %s0, { i64, ptr } %t100, ptr %l3)
  store i32 %t102, ptr %l67
  br label %bb38
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t103 = load i32, ptr %l67, !tbaa !23
  store i32 %t103, ptr %rv
  br label %ret
bb39:
  %t104 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t105 = load i64, ptr %t104, !tbaa !24
  %t106 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t109 = icmp eq i64 %t105, %t106
  br i1 %t109, label %bb40, label %bb41
bb40:
  %t111 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t112 = load { i64, ptr }, ptr %t111, !tbaa !27
  %t114 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s0, { i64, ptr } %t112, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d42, i32 0, i32 1) })
  store i1 %t114, ptr %l73
  br label %bb42
bb41:
  store i1 false, ptr %l71, !tbaa !21
  br label %bb43
bb42:
  %t115 = load i1, ptr %l73, !tbaa !21
  %t116 = xor i1 %t115, true
  store i1 %t116, ptr %l71, !tbaa !21
  br label %bb43
bb43:
  %t118 = load i1, ptr %l71, !tbaa !21
  br i1 %t118, label %bb44, label %bb45
bb44:
  store %olang.scope zeroinitializer, ptr %s6
  %t119 = load ptr, ptr %l1, !tbaa !29
  store ptr %t119, ptr %l75, !tbaa !29
  store ptr %l3, ptr %l76, !tbaa !29
  %t120 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t122 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t120, i64 0)
  store { i64, ptr } %t122, ptr %l78
  br label %bb46
bb45:
  br label %bb49
bb46:
  %t123 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t124 = load { i64, ptr }, ptr %t123, !tbaa !27
  store { i64, ptr } %t124, ptr %l79, !tbaa !27
  %t125 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 12
  %t126 = load { i64, ptr }, ptr %t125, !tbaa !27
  %t128 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %s6, { i64, ptr } %t126, { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d43, i32 0, i32 1) })
  store i1 %t128, ptr %l81
  br label %bb47
bb47:
  %t129 = load ptr, ptr %l75, !tbaa !29
  %t130 = load ptr, ptr %l76, !tbaa !29
  %t131 = load { i64, ptr }, ptr %l78, !tbaa !27
  %t132 = load { i64, ptr }, ptr %l79, !tbaa !27
  %t133 = load i1, ptr %l81, !tbaa !21
  %t135 = call i32 @compiler_2flisting_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t129, ptr %t130, { i64, ptr } %t131, { i64, ptr } %t132, i1 %t133, ptr %l2)
  store i32 %t135, ptr %l83
  br label %bb48
bb48:
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t136 = load i32, ptr %l83, !tbaa !23
  store i32 %t136, ptr %rv
  br label %ret
bb49:
  %t137 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t138 = load i64, ptr %t137, !tbaa !24
  %t139 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t142 = icmp eq i64 %t138, %t139
  br i1 %t142, label %bb50, label %bb51
bb50:
  store %olang.scope zeroinitializer, ptr %s7
  %t144 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t146 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t144)
  store i64 %t146, ptr %l88
  br label %bb52
bb51:
  br label %bb64
bb52:
  %t147 = load i64, ptr %l88, !tbaa !24
  %t148 = icmp eq i64 %t147, 1
  br i1 %t148, label %bb53, label %bb54
bb53:
  %t150 = load ptr, ptr %l1, !tbaa !29
  store ptr %t150, ptr %l90, !tbaa !29
  store ptr %l3, ptr %l91, !tbaa !29
  %t151 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t153 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t151, i64 0)
  store { i64, ptr } %t153, ptr %l93
  br label %bb55
bb54:
  br label %bb57
bb55:
  %t154 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t155 = load { i64, ptr }, ptr %t154, !tbaa !27
  %t156 = load ptr, ptr %l90, !tbaa !29
  %t157 = load ptr, ptr %l91, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l93, !tbaa !27
  %t161 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t156, ptr %t157, { i64, ptr } %t158, { i64, ptr } %t155, ptr %l2)
  store i32 %t161, ptr %l96
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t162 = load i32, ptr %l96, !tbaa !23
  store i32 %t162, ptr %rv
  br label %ret
bb57:
  %t163 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t164 = load { i64, ptr }, ptr %t163, !tbaa !27
  %t167 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %s0, ptr %s7, { i64, ptr } %t164, ptr %l2)
  %t168 = extractvalue { i32, { i64, ptr } } %t167, 1
  %t169 = extractvalue { i32, { i64, ptr } } %t167, 0
  store i32 %t169, ptr %l101
  %t170 = icmp ne i32 %t169, 0
  br i1 %t170, label %bb59, label %ok.171, !prof !99
ok.171:
  store { i64, ptr } %t168, ptr %l100
  br label %bb58
bb58:
  %t172 = load { i64, ptr }, ptr %l100, !tbaa !27
  store { i64, ptr } %t172, ptr %l97, !tbaa !27
  br label %bb62
bb59:
  %t173 = load i32, ptr %l101, !tbaa !23
  %t174 = ashr i32 %t173, 16
  %t176 = icmp eq i32 %t174, 1
  store i1 %t176, ptr %l103, !tbaa !21
  br label %bb60
bb60:
  %t178 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t178, ptr %l105
  br label %bb61
bb61:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t179 = load i32, ptr %l105, !tbaa !23
  store i32 %t179, ptr %rv
  br label %ret
bb62:
  %t180 = load { i64, ptr }, ptr %l97, !tbaa !27
  %t183 = call i32 @compiler_2folang_2ewrite(ptr %s7, { i64, ptr } %t180)
  store i32 %t183, ptr %l107
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s0)
  %t184 = load i32, ptr %l107, !tbaa !23
  store i32 %t184, ptr %rv
  br label %ret
bb64:
  %t185 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t186 = load i64, ptr %t185, !tbaa !24
  %t187 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t190 = icmp eq i64 %t186, %t187
  br i1 %t190, label %bb65, label %bb66
bb65:
  %t193 = call i32 @compiler_2folang_2eformat(ptr %v0, ptr %l4)
  store i32 %t193, ptr %l112
  br label %bb67
bb66:
  br label %bb68
bb67:
  call void @__olang_scope_close(ptr %s0)
  %t194 = load i32, ptr %l112, !tbaa !23
  store i32 %t194, ptr %rv
  br label %ret
bb68:
  %t195 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t196 = load i64, ptr %t195, !tbaa !24
  %t197 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t200 = icmp eq i64 %t196, %t197
  br i1 %t200, label %bb69, label %bb70
bb69:
  store %olang.scope zeroinitializer, ptr %s11
  %t202 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s11, ptr %s11, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d44, i32 0, i32 1) })
  %t203 = extractvalue { i32, { i64, ptr } } %t202, 1
  %t204 = extractvalue { i32, { i64, ptr } } %t202, 0
  store i32 %t204, ptr %l118
  %t205 = icmp ne i32 %t204, 0
  br i1 %t205, label %bb72, label %ok.206, !prof !99
ok.206:
  store { i64, ptr } %t203, ptr %l117
  br label %bb71
bb70:
  br label %bb80
bb71:
  %t207 = load { i64, ptr }, ptr %l117, !tbaa !27
  store { i64, ptr } %t207, ptr %l116, !tbaa !27
  br label %bb76
bb72:
  %t208 = load i32, ptr %l118, !tbaa !23
  %t209 = ashr i32 %t208, 16
  %t211 = icmp eq i32 %t209, 1
  store i1 %t211, ptr %l120, !tbaa !21
  %t212 = load i32, ptr %l118, !tbaa !23
  %t213 = ashr i32 %t212, 16
  %t215 = icmp eq i32 %t213, 1
  br i1 %t215, label %bb73, label %bb74
bb73:
  call void @__olang_errpay_pop()
  br label %bb74
bb74:
  br label %bb75
bb75:
  %t217 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t217, ptr %l123, !tbaa !27
  %t218 = getelementptr { i64, ptr }, ptr %l123, i32 0, i32 1
  %t219 = load ptr, ptr %t218, !tbaa !27
  %t220 = getelementptr { i64, ptr }, ptr %t219, i64 0
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !37
  %t223 = extractvalue { i64, ptr } %t221, 1
  %t224 = extractvalue { i64, ptr } %t221, 0
  %t225 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t224)
  call void @olang_textcopy(ptr %t225, ptr %t223, i64 %t224)
  %t226 = insertvalue { i64, ptr } undef, i64 %t224, 0
  %t227 = insertvalue { i64, ptr } %t226, ptr %t225, 1
  %t229 = extractvalue { i64, ptr } %t227, 0
  %t230 = extractvalue { i64, ptr } %t227, 1
  %t231 = mul i64 %t229, 1
  %t232 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t231)
  call void @llvm.memcpy.p0.p0.i64(ptr %t232, ptr %t230, i64 %t231, i1 false)
  %t233 = insertvalue { i64, ptr } undef, i64 %t229, 0
  %t234 = insertvalue { i64, ptr } %t233, ptr %t232, 1
  store { i64, ptr } %t234, ptr %l116, !tbaa !27
  br label %bb76
bb76:
  %t236 = load { i64, ptr }, ptr %l116, !tbaa !27
  store { i64, ptr } %t236, ptr %l7, !tbaa !27
  %t237 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t238 = load i1, ptr %t237, !tbaa !21
  store i1 %t238, ptr %l127, !tbaa !21
  %t239 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t241 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t239)
  store { i64, ptr } %t241, ptr %l129
  br label %bb77
bb77:
  %t242 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t242, ptr %l130, !tbaa !27
  %t243 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s11)
  store { i64, ptr } %t243, ptr %l131
  br label %bb78
bb78:
  %t244 = load { i64, ptr }, ptr %l131, !tbaa !27
  %t245 = extractvalue { i64, ptr } %t244, 0
  %t246 = extractvalue { i64, ptr } %t244, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load i1, ptr %l127, !tbaa !21
  %t252 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t253 = load { i64, ptr }, ptr %l130, !tbaa !27
  %t255 = call i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %s11, ptr %s11, i1 %t251, { i64, ptr } %t252, { i64, ptr } %t253, { i64, ptr } %t250)
  store i32 %t255, ptr %l133
  br label %bb79
bb79:
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  %t256 = load i32, ptr %l133, !tbaa !23
  store i32 %t256, ptr %rv
  br label %ret
bb80:
  %t257 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t258 = load i64, ptr %t257, !tbaa !24
  %t259 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t262 = icmp eq i64 %t258, %t259
  br i1 %t262, label %bb81, label %bb82
bb81:
  store %olang.scope zeroinitializer, ptr %s13
  %t264 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t266 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t264, i64 0)
  store { i64, ptr } %t266, ptr %l138
  br label %bb83
bb82:
  br label %bb86
bb83:
  %t267 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t268 = load { i64, ptr }, ptr %t267, !tbaa !27
  store { i64, ptr } %t268, ptr %l139, !tbaa !27
  %t269 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s13)
  store { i64, ptr } %t269, ptr %l140
  br label %bb84
bb84:
  %t270 = load { i64, ptr }, ptr %l140, !tbaa !27
  %t271 = extractvalue { i64, ptr } %t270, 0
  %t272 = extractvalue { i64, ptr } %t270, 1
  %t273 = mul i64 %t271, 1
  %t274 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t273)
  call void @llvm.memcpy.p0.p0.i64(ptr %t274, ptr %t272, i64 %t273, i1 false)
  %t275 = insertvalue { i64, ptr } undef, i64 %t271, 0
  %t276 = insertvalue { i64, ptr } %t275, ptr %t274, 1
  %t277 = load { i64, ptr }, ptr %l138, !tbaa !27
  %t278 = load { i64, ptr }, ptr %l139, !tbaa !27
  %t280 = call i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v0, ptr %s13, { i64, ptr } %t277, { i64, ptr } %t278, { i64, ptr } %t276)
  store i32 %t280, ptr %l142
  br label %bb85
bb85:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t281 = load i32, ptr %l142, !tbaa !23
  store i32 %t281, ptr %rv
  br label %ret
bb86:
  %t282 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t283 = load i64, ptr %t282, !tbaa !24
  %t284 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t287 = icmp eq i64 %t283, %t284
  br i1 %t287, label %bb87, label %bb88
bb87:
  %t289 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t291 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t289)
  store { i64, ptr } %t291, ptr %l147
  br label %bb89
bb88:
  br label %bb91
bb89:
  %t292 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 3
  %t293 = load { i64, ptr }, ptr %t292, !tbaa !27
  %t294 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 10
  %t295 = load { i64, ptr }, ptr %t294, !tbaa !27
  %t296 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t300 = call i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t296, { i64, ptr } %t293, { i64, ptr } %t295, ptr %l3)
  store i32 %t300, ptr %l151
  br label %bb90
bb90:
  call void @__olang_scope_close(ptr %s0)
  %t301 = load i32, ptr %l151, !tbaa !23
  store i32 %t301, ptr %rv
  br label %ret
bb91:
  %t302 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t303 = load i64, ptr %t302, !tbaa !24
  %t304 = load i64, ptr @G_2ecompiler_2folang_2eApi, !tbaa !24
  %t307 = icmp eq i64 %t303, %t304
  br i1 %t307, label %bb92, label %bb93
bb92:
  %t309 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t311 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t309, i64 0)
  store { i64, ptr } %t311, ptr %l156
  br label %bb94
bb93:
  br label %bb98
bb94:
  %t312 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t314 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t312, i64 1)
  store { i64, ptr } %t314, ptr %l158
  br label %bb95
bb95:
  %t315 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t317 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t315, i64 2)
  store { i64, ptr } %t317, ptr %l160
  br label %bb96
bb96:
  %t318 = load { i64, ptr }, ptr %l156, !tbaa !27
  %t319 = load { i64, ptr }, ptr %l158, !tbaa !27
  %t320 = load { i64, ptr }, ptr %l160, !tbaa !27
  %t322 = call i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v0, ptr %v0, ptr %s0, { i64, ptr } %t318, { i64, ptr } %t319, { i64, ptr } %t320, ptr %l3)
  store i32 %t322, ptr %l162
  br label %bb97
bb97:
  call void @__olang_scope_close(ptr %s0)
  %t323 = load i32, ptr %l162, !tbaa !23
  store i32 %t323, ptr %rv
  br label %ret
bb98:
  %t324 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t325 = load i64, ptr %t324, !tbaa !24
  %t326 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t329 = icmp eq i64 %t325, %t326
  br i1 %t329, label %bb99, label %bb100
bb99:
  %t332 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t332, ptr %l167
  br label %bb101
bb100:
  br label %bb102
bb101:
  call void @__olang_scope_close(ptr %s0)
  %t333 = load i32, ptr %l167, !tbaa !23
  store i32 %t333, ptr %rv
  br label %ret
bb102:
  %t334 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t335 = load i64, ptr %t334, !tbaa !24
  %t336 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t339 = icmp eq i64 %t335, %t336
  br i1 %t339, label %bb103, label %bb104
bb103:
  store %olang.scope zeroinitializer, ptr %s17
  store ptr %l3, ptr %l171, !tbaa !29
  %t341 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s17, ptr %s17, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d45, i32 0, i32 1) })
  %t342 = extractvalue { i32, { i64, ptr } } %t341, 1
  %t343 = extractvalue { i32, { i64, ptr } } %t341, 0
  store i32 %t343, ptr %l174
  %t344 = icmp ne i32 %t343, 0
  br i1 %t344, label %bb106, label %ok.345, !prof !99
ok.345:
  store { i64, ptr } %t342, ptr %l173
  br label %bb105
bb104:
  br label %bb112
bb105:
  %t346 = load { i64, ptr }, ptr %l173, !tbaa !27
  store { i64, ptr } %t346, ptr %l172, !tbaa !27
  br label %bb110
bb106:
  %t347 = load i32, ptr %l174, !tbaa !23
  %t348 = ashr i32 %t347, 16
  %t350 = icmp eq i32 %t348, 1
  store i1 %t350, ptr %l176, !tbaa !21
  %t351 = load i32, ptr %l174, !tbaa !23
  %t352 = ashr i32 %t351, 16
  %t354 = icmp eq i32 %t352, 1
  br i1 %t354, label %bb107, label %bb108
bb107:
  call void @__olang_errpay_pop()
  br label %bb108
bb108:
  br label %bb109
bb109:
  %t356 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t356, ptr %l179, !tbaa !27
  %t357 = getelementptr { i64, ptr }, ptr %l179, i32 0, i32 1
  %t358 = load ptr, ptr %t357, !tbaa !27
  %t359 = getelementptr { i64, ptr }, ptr %t358, i64 0
  %t360 = load { i64, ptr }, ptr %t359, !tbaa !37
  %t362 = extractvalue { i64, ptr } %t360, 1
  %t363 = extractvalue { i64, ptr } %t360, 0
  %t364 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t363)
  call void @olang_textcopy(ptr %t364, ptr %t362, i64 %t363)
  %t365 = insertvalue { i64, ptr } undef, i64 %t363, 0
  %t366 = insertvalue { i64, ptr } %t365, ptr %t364, 1
  %t368 = extractvalue { i64, ptr } %t366, 0
  %t369 = extractvalue { i64, ptr } %t366, 1
  %t370 = mul i64 %t368, 1
  %t371 = call ptr @__olang_scope_alloc(ptr %s17, i64 %t370)
  call void @llvm.memcpy.p0.p0.i64(ptr %t371, ptr %t369, i64 %t370, i1 false)
  %t372 = insertvalue { i64, ptr } undef, i64 %t368, 0
  %t373 = insertvalue { i64, ptr } %t372, ptr %t371, 1
  store { i64, ptr } %t373, ptr %l172, !tbaa !27
  br label %bb110
bb110:
  %t375 = load ptr, ptr %l171, !tbaa !29
  %t376 = load { i64, ptr }, ptr %l172, !tbaa !27
  %t377 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s17, ptr %t375, { i64, ptr } %t376)
  store i32 %t377, ptr %l183
  br label %bb111
bb111:
  call void @__olang_scope_close(ptr %s17)
  call void @__olang_scope_close(ptr %s0)
  %t378 = load i32, ptr %l183, !tbaa !23
  store i32 %t378, ptr %rv
  br label %ret
bb112:
  %t379 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t381 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t379)
  store { i64, ptr } %t381, ptr %l185
  br label %bb113
bb113:
  %t382 = load { i64, ptr }, ptr %l185, !tbaa !27
  store { i64, ptr } %t382, ptr %l8, !tbaa !27
  %t383 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t384 = load i64, ptr %t383, !tbaa !24
  %t385 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t388 = icmp eq i64 %t384, %t385
  br i1 %t388, label %bb114, label %bb115
bb114:
  %t390 = load ptr, ptr %l1, !tbaa !29
  %t391 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t391, ptr %l191, !tbaa !27
  %t392 = getelementptr { i64, ptr }, ptr %l191, i32 0, i32 1
  %t393 = load ptr, ptr %t392, !tbaa !27
  %t394 = getelementptr { i64, ptr }, ptr %t393, i64 0
  %t395 = load { i64, ptr }, ptr %t394, !tbaa !37
  %t400 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %t390, ptr %l3, { i64, ptr } %t395, ptr %l2)
  store i32 %t400, ptr %l194
  br label %bb116
bb115:
  br label %bb117
bb116:
  call void @__olang_scope_close(ptr %s0)
  %t401 = load i32, ptr %l194, !tbaa !23
  store i32 %t401, ptr %rv
  br label %ret
bb117:
  %t402 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t403 = load i64, ptr %t402, !tbaa !24
  %t404 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t407 = icmp eq i64 %t403, %t404
  br i1 %t407, label %bb118, label %bb119
bb118:
  %t409 = load ptr, ptr %l1, !tbaa !29
  %t410 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t410, ptr %l200, !tbaa !27
  %t411 = getelementptr { i64, ptr }, ptr %l200, i32 0, i32 1
  %t412 = load ptr, ptr %t411, !tbaa !27
  %t413 = getelementptr { i64, ptr }, ptr %t412, i64 0
  %t414 = load { i64, ptr }, ptr %t413, !tbaa !37
  %t419 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %t409, ptr %l3, { i64, ptr } %t414, ptr %l2)
  store i32 %t419, ptr %l203
  br label %bb120
bb119:
  br label %bb121
bb120:
  call void @__olang_scope_close(ptr %s0)
  %t420 = load i32, ptr %l203, !tbaa !23
  store i32 %t420, ptr %rv
  br label %ret
bb121:
  %t421 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t422 = load i64, ptr %t421, !tbaa !24
  %t423 = load i64, ptr @G_2ecompiler_2folang_2eRunBuilt, !tbaa !24
  %t426 = icmp eq i64 %t422, %t423
  br i1 %t426, label %bb122, label %bb123
bb122:
  %t428 = load ptr, ptr %l1, !tbaa !29
  store ptr %t428, ptr %l207, !tbaa !29
  store ptr %l3, ptr %l208, !tbaa !29
  %t429 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t429, ptr %l209, !tbaa !27
  %t430 = getelementptr { i64, ptr }, ptr %l209, i32 0, i32 1
  %t431 = load ptr, ptr %t430, !tbaa !27
  %t432 = getelementptr { i64, ptr }, ptr %t431, i64 0
  %t433 = load { i64, ptr }, ptr %t432, !tbaa !37
  store { i64, ptr } %t433, ptr %l210, !tbaa !27
  %t434 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t436 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t434)
  store { i64, ptr } %t436, ptr %l212
  br label %bb124
bb123:
  br label %bb126
bb124:
  %t437 = load ptr, ptr %l207, !tbaa !29
  %t438 = load ptr, ptr %l208, !tbaa !29
  %t439 = load { i64, ptr }, ptr %l210, !tbaa !27
  %t440 = load { i64, ptr }, ptr %l212, !tbaa !27
  %t442 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t437, ptr %t438, { i64, ptr } %t439, { i64, ptr } %t440, ptr %l2)
  store i32 %t442, ptr %l214
  br label %bb125
bb125:
  call void @__olang_scope_close(ptr %s0)
  %t443 = load i32, ptr %l214, !tbaa !23
  store i32 %t443, ptr %rv
  br label %ret
bb126:
  %t444 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t445 = load i64, ptr %t444, !tbaa !24
  %t446 = load i64, ptr @G_2ecompiler_2folang_2eProfile, !tbaa !24
  %t449 = icmp eq i64 %t445, %t446
  br i1 %t449, label %bb127, label %bb128
bb127:
  %t451 = load ptr, ptr %l1, !tbaa !29
  store ptr %t451, ptr %l218, !tbaa !29
  store ptr %l3, ptr %l219, !tbaa !29
  %t452 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t452, ptr %l220, !tbaa !27
  %t453 = getelementptr { i64, ptr }, ptr %l220, i32 0, i32 1
  %t454 = load ptr, ptr %t453, !tbaa !27
  %t455 = getelementptr { i64, ptr }, ptr %t454, i64 0
  %t456 = load { i64, ptr }, ptr %t455, !tbaa !37
  store { i64, ptr } %t456, ptr %l221, !tbaa !27
  %t457 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t459 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t457)
  store { i64, ptr } %t459, ptr %l223
  br label %bb129
bb128:
  br label %bb131
bb129:
  %t460 = load ptr, ptr %l218, !tbaa !29
  %t461 = load ptr, ptr %l219, !tbaa !29
  %t462 = load { i64, ptr }, ptr %l221, !tbaa !27
  %t463 = load { i64, ptr }, ptr %l223, !tbaa !27
  %t465 = call i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %v0, ptr %s0, ptr %t460, ptr %t461, { i64, ptr } %t462, { i64, ptr } %t463, ptr %l2)
  store i32 %t465, ptr %l225
  br label %bb130
bb130:
  call void @__olang_scope_close(ptr %s0)
  %t466 = load i32, ptr %l225, !tbaa !23
  store i32 %t466, ptr %rv
  br label %ret
bb131:
  %t467 = insertvalue { ptr, ptr } undef, ptr @compiler_2folang_2ebuildCell_fv_fn_28std_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_2c_20Array_3_H1276486710fe3f33d55b88d9cfddba68, 0
  %t468 = insertvalue { ptr, ptr } %t467, ptr null, 1
  store { ptr, ptr } %t468, ptr @G_2ecompiler_2fcells_2eBuilder
  %t472 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 13
  %t473 = load i1, ptr %t472, !tbaa !21
  br i1 %t473, label %bb132, label %bb133
bb132:
  %t476 = call i32 @compiler_2fprompt_2eRun(ptr %s0, ptr %l3)
  store i32 %t476, ptr %l231
  br label %bb134
bb133:
  br label %bb135
bb134:
  call void @__olang_scope_close(ptr %s0)
  %t477 = load i32, ptr %l231, !tbaa !23
  store i32 %t477, ptr %rv
  br label %ret
bb135:
  %t478 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t479 = load i64, ptr %t478, !tbaa !24
  %t480 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t483 = icmp eq i64 %t479, %t480
  br i1 %t483, label %bb136, label %bb137
bb136:
  %t485 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 14
  %t486 = load i1, ptr %t485, !tbaa !21
  store i1 %t486, ptr %l235, !tbaa !21
  br label %bb138
bb137:
  store i1 false, ptr %l235, !tbaa !21
  br label %bb138
bb138:
  %t488 = load i1, ptr %l235, !tbaa !21
  br i1 %t488, label %bb139, label %bb140
bb139:
  store %olang.scope zeroinitializer, ptr %s24
  %t489 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s24, ptr %s24, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d46, i32 0, i32 1) })
  %t490 = extractvalue { i32, { i64, ptr } } %t489, 1
  %t491 = extractvalue { i32, { i64, ptr } } %t489, 0
  store i32 %t491, ptr %l239
  %t492 = icmp ne i32 %t491, 0
  br i1 %t492, label %bb142, label %ok.493, !prof !99
ok.493:
  store { i64, ptr } %t490, ptr %l238
  br label %bb141
bb140:
  br label %bb148
bb141:
  %t494 = load { i64, ptr }, ptr %l238, !tbaa !27
  store { i64, ptr } %t494, ptr %l237, !tbaa !27
  br label %bb146
bb142:
  %t495 = load i32, ptr %l239, !tbaa !23
  %t496 = ashr i32 %t495, 16
  %t498 = icmp eq i32 %t496, 1
  store i1 %t498, ptr %l241, !tbaa !21
  %t499 = load i32, ptr %l239, !tbaa !23
  %t500 = ashr i32 %t499, 16
  %t502 = icmp eq i32 %t500, 1
  br i1 %t502, label %bb143, label %bb144
bb143:
  call void @__olang_errpay_pop()
  br label %bb144
bb144:
  br label %bb145
bb145:
  %t504 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t504, ptr %l244, !tbaa !27
  %t505 = getelementptr { i64, ptr }, ptr %l244, i32 0, i32 1
  %t506 = load ptr, ptr %t505, !tbaa !27
  %t507 = getelementptr { i64, ptr }, ptr %t506, i64 0
  %t508 = load { i64, ptr }, ptr %t507, !tbaa !37
  %t510 = extractvalue { i64, ptr } %t508, 1
  %t511 = extractvalue { i64, ptr } %t508, 0
  %t512 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t511)
  call void @olang_textcopy(ptr %t512, ptr %t510, i64 %t511)
  %t513 = insertvalue { i64, ptr } undef, i64 %t511, 0
  %t514 = insertvalue { i64, ptr } %t513, ptr %t512, 1
  %t516 = extractvalue { i64, ptr } %t514, 0
  %t517 = extractvalue { i64, ptr } %t514, 1
  %t518 = mul i64 %t516, 1
  %t519 = call ptr @__olang_scope_alloc(ptr %s24, i64 %t518)
  call void @llvm.memcpy.p0.p0.i64(ptr %t519, ptr %t517, i64 %t518, i1 false)
  %t520 = insertvalue { i64, ptr } undef, i64 %t516, 0
  %t521 = insertvalue { i64, ptr } %t520, ptr %t519, 1
  store { i64, ptr } %t521, ptr %l237, !tbaa !27
  br label %bb146
bb146:
  %t523 = load { i64, ptr }, ptr %l237, !tbaa !27
  %t525 = call i32 @compiler_2fjupyter_2eInstall(ptr %s24, ptr %s0, { i64, ptr } %t523, ptr %l3)
  store i32 %t525, ptr %l249
  br label %bb147
bb147:
  call void @__olang_scope_close(ptr %s24)
  call void @__olang_scope_close(ptr %s0)
  %t526 = load i32, ptr %l249, !tbaa !23
  store i32 %t526, ptr %rv
  br label %ret
bb148:
  %t527 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t528 = load i64, ptr %t527, !tbaa !24
  %t529 = load i64, ptr @G_2ecompiler_2folang_2eJupyter, !tbaa !24
  %t532 = icmp eq i64 %t528, %t529
  br i1 %t532, label %bb149, label %bb150
bb149:
  %t534 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t534, ptr %l254, !tbaa !27
  %t535 = getelementptr { i64, ptr }, ptr %l254, i32 0, i32 1
  %t536 = load ptr, ptr %t535, !tbaa !27
  %t537 = getelementptr { i64, ptr }, ptr %t536, i64 0
  %t538 = load { i64, ptr }, ptr %t537, !tbaa !37
  %t541 = call i32 @compiler_2fjupyter_2eServe(ptr %s0, ptr %v0, ptr %l3, { i64, ptr } %t538)
  store i32 %t541, ptr %l256
  br label %bb151
bb150:
  br label %bb152
bb151:
  call void @__olang_scope_close(ptr %s0)
  %t542 = load i32, ptr %l256, !tbaa !23
  store i32 %t542, ptr %rv
  br label %ret
bb152:
  %t543 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t544 = load i64, ptr %t543, !tbaa !24
  %t545 = load i64, ptr @G_2ecompiler_2folang_2eNotebook, !tbaa !24
  %t548 = icmp eq i64 %t544, %t545
  br i1 %t548, label %bb153, label %bb154
bb153:
  %t550 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t550, ptr %l261, !tbaa !27
  %t551 = getelementptr { i64, ptr }, ptr %l261, i32 0, i32 1
  %t552 = load ptr, ptr %t551, !tbaa !27
  %t553 = getelementptr { i64, ptr }, ptr %t552, i64 1
  %t554 = load { i64, ptr }, ptr %t553, !tbaa !37
  %t555 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t556 = load { i64, ptr }, ptr %t555, !tbaa !27
  %t557 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 15
  %t558 = load i1, ptr %t557, !tbaa !21
  %t563 = call i32 @compiler_2fnotebook_2eRun(ptr %s0, ptr %v0, ptr %v0, ptr %l3, { i64, ptr } %t554, { i64, ptr } %t556, i1 %t558)
  store i32 %t563, ptr %l265
  br label %bb155
bb154:
  br label %bb156
bb155:
  call void @__olang_scope_close(ptr %s0)
  %t564 = load i32, ptr %l265, !tbaa !23
  store i32 %t564, ptr %rv
  br label %ret
bb156:
  %t565 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t566 = load i64, ptr %t565, !tbaa !24
  %t567 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t570 = icmp eq i64 %t566, %t567
  br i1 %t570, label %bb157, label %bb158
bb157:
  %t572 = call %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t572, ptr %l269
  br label %bb159
bb158:
  br label %bb172
bb159:
  %t573 = call ptr @__olang_scope_alloc_a(ptr %s0, i64 32, i64 8)
  store ptr %t573, ptr %lp9
  %t574 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l269
  %t575 = load ptr, ptr %lp9
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t574, ptr %t575
  %t576 = load ptr, ptr %lp9
  %t577 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t577, ptr %l271, !tbaa !27
  %t578 = getelementptr { i64, ptr }, ptr %l271, i32 0, i32 1
  %t579 = load ptr, ptr %t578, !tbaa !27
  %t580 = getelementptr { i64, ptr }, ptr %t579, i64 0
  %t581 = load { i64, ptr }, ptr %t580, !tbaa !37
  %t583 = extractvalue { i64, ptr } %t581, 1
  %t584 = extractvalue { i64, ptr } %t581, 0
  %t585 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t584)
  call void @olang_textcopy(ptr %t585, ptr %t583, i64 %t584)
  %t586 = insertvalue { i64, ptr } undef, i64 %t584, 0
  %t587 = insertvalue { i64, ptr } %t586, ptr %t585, 1
  %t589 = extractvalue { i64, ptr } %t587, 0
  %t590 = extractvalue { i64, ptr } %t587, 1
  %t591 = mul i64 %t589, 1
  %t592 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t591)
  call void @llvm.memcpy.p0.p0.i64(ptr %t592, ptr %t590, i64 %t591, i1 false)
  %t593 = insertvalue { i64, ptr } undef, i64 %t589, 0
  %t594 = insertvalue { i64, ptr } %t593, ptr %t592, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t576, { i64, ptr } %t594)
  br label %bb160
bb160:
  %t597 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  store ptr %t597, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb161
bb161:
  %t599 = load i64, ptr %l11, !tbaa !24
  store i64 %t599, ptr %l276, !tbaa !24
  %t600 = load ptr, ptr %l10, !tbaa !29
  %t602 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %t600)
  store i64 %t602, ptr %l278
  br label %bb162
bb162:
  %t603 = load i64, ptr %l276, !tbaa !24
  %t604 = load i64, ptr %l278, !tbaa !24
  %t605 = icmp slt i64 %t603, %t604
  %t607 = xor i1 %t605, true
  br i1 %t607, label %bb163, label %bb164
bb163:
  br label %bb169
bb164:
  br label %bb165
bb165:
  %t609 = load ptr, ptr %l10, !tbaa !29
  %t610 = load i64, ptr %l11, !tbaa !24
  %t613 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v0, ptr %t609, i64 %t610)
  store { i64, ptr } %t613, ptr %l283
  br label %bb166
bb166:
  %t614 = load { i64, ptr }, ptr %l283, !tbaa !27
  %t615 = load ptr, ptr %lp9
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %v0, ptr %t615, { i64, ptr } %t614)
  br label %bb167
bb167:
  br label %bb168
bb168:
  %t619 = load i64, ptr %l11, !tbaa !24
  %t621 = add i64 %t619, 1
  store i64 %t621, ptr %l11, !tbaa !24
  br label %bb161
bb169:
  %t623 = load ptr, ptr %l1, !tbaa !29
  store ptr %t623, ptr %l288, !tbaa !29
  store ptr %l3, ptr %l289, !tbaa !29
  %t624 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t624, ptr %l290, !tbaa !27
  %t625 = getelementptr { i64, ptr }, ptr %l290, i32 0, i32 1
  %t626 = load ptr, ptr %t625, !tbaa !27
  %t627 = getelementptr { i64, ptr }, ptr %t626, i64 0
  %t628 = load { i64, ptr }, ptr %t627, !tbaa !37
  store { i64, ptr } %t628, ptr %l291, !tbaa !27
  %t629 = load ptr, ptr %lp9
  %t631 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t629)
  store { i64, ptr } %t631, ptr %l293
  br label %bb170
bb170:
  %t632 = load ptr, ptr %l288, !tbaa !29
  %t633 = load ptr, ptr %l289, !tbaa !29
  %t634 = load { i64, ptr }, ptr %l291, !tbaa !27
  %t635 = load { i64, ptr }, ptr %l293, !tbaa !27
  %t637 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %s0, ptr %t632, ptr %t633, { i64, ptr } %t634, { i64, ptr } %t635, ptr %l2)
  store i32 %t637, ptr %l295
  br label %bb171
bb171:
  call void @__olang_scope_close(ptr %s0)
  %t638 = load i32, ptr %l295, !tbaa !23
  store i32 %t638, ptr %rv
  br label %ret
bb172:
  %t639 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t641 = extractvalue { i64, ptr } %t639, 0
  %t643 = icmp eq i64 %t641, 1
  br i1 %t643, label %bb173, label %bb174
bb173:
  %t645 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 22
  %t646 = load i1, ptr %t645, !tbaa !21
  store i1 %t646, ptr %l299, !tbaa !21
  br label %bb175
bb174:
  store i1 false, ptr %l299, !tbaa !21
  br label %bb175
bb175:
  %t648 = load i1, ptr %l299, !tbaa !21
  br i1 %t648, label %bb176, label %bb177
bb176:
  %t649 = load ptr, ptr %l1, !tbaa !29
  store ptr %t649, ptr %l301, !tbaa !29
  store ptr %l3, ptr %l302, !tbaa !29
  %t650 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t650, ptr %l303, !tbaa !27
  %t651 = getelementptr { i64, ptr }, ptr %l303, i32 0, i32 1
  %t652 = load ptr, ptr %t651, !tbaa !27
  %t653 = getelementptr { i64, ptr }, ptr %t652, i64 0
  %t654 = load { i64, ptr }, ptr %t653, !tbaa !37
  store { i64, ptr } %t654, ptr %l304, !tbaa !27
  store ptr %l2, ptr %l305, !tbaa !29
  %t655 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t657 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t655)
  store { i64, ptr } %t657, ptr %l307
  br label %bb178
bb177:
  br label %bb180
bb178:
  %t658 = load ptr, ptr %l301, !tbaa !29
  %t659 = load ptr, ptr %l302, !tbaa !29
  %t660 = load { i64, ptr }, ptr %l304, !tbaa !27
  %t661 = load ptr, ptr %l305, !tbaa !29
  %t662 = load { i64, ptr }, ptr %l307, !tbaa !27
  %t663 = call i32 @compiler_2fbuild_2eInterpretTests_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %t658, ptr %t659, { i64, ptr } %t660, ptr %t661, { i64, ptr } %t662)
  store i32 %t663, ptr %l308
  br label %bb179
bb179:
  call void @__olang_scope_close(ptr %s0)
  %t664 = load i32, ptr %l308, !tbaa !23
  store i32 %t664, ptr %rv
  br label %ret
bb180:
  %t665 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t667 = extractvalue { i64, ptr } %t665, 0
  %t669 = icmp eq i64 %t667, 1
  br i1 %t669, label %bb181, label %bb182
bb181:
  %t671 = load ptr, ptr %l1, !tbaa !29
  store ptr %t671, ptr %l312, !tbaa !29
  store ptr %l3, ptr %l313, !tbaa !29
  %t672 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t672, ptr %l314, !tbaa !27
  %t673 = getelementptr { i64, ptr }, ptr %l314, i32 0, i32 1
  %t674 = load ptr, ptr %t673, !tbaa !27
  %t675 = getelementptr { i64, ptr }, ptr %t674, i64 0
  %t676 = load { i64, ptr }, ptr %t675, !tbaa !37
  store { i64, ptr } %t676, ptr %l315, !tbaa !27
  store ptr %l2, ptr %l316, !tbaa !29
  %t677 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t679 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t677)
  store { i64, ptr } %t679, ptr %l318
  br label %bb183
bb182:
  br label %bb185
bb183:
  %t680 = load ptr, ptr %l312, !tbaa !29
  %t681 = load ptr, ptr %l313, !tbaa !29
  %t682 = load { i64, ptr }, ptr %l315, !tbaa !27
  %t683 = load ptr, ptr %l316, !tbaa !29
  %t684 = load { i64, ptr }, ptr %l318, !tbaa !27
  %t685 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %v0, ptr %s0, ptr %v0, ptr %t680, ptr %t681, { i64, ptr } %t682, ptr %t683, { i64, ptr } %t684)
  store i32 %t685, ptr %l319
  br label %bb184
bb184:
  call void @__olang_scope_close(ptr %s0)
  %t686 = load i32, ptr %l319, !tbaa !23
  store i32 %t686, ptr %rv
  br label %ret
bb185:
  %t687 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d47, i32 0, i32 1) })
  %t688 = extractvalue { i32, { i64, ptr } } %t687, 1
  %t689 = extractvalue { i32, { i64, ptr } } %t687, 0
  store i32 %t689, ptr %l322
  %t690 = icmp ne i32 %t689, 0
  br i1 %t690, label %bb187, label %ok.691, !prof !99
ok.691:
  store { i64, ptr } %t688, ptr %l321
  br label %bb186
bb186:
  %t692 = load { i64, ptr }, ptr %l321, !tbaa !27
  store { i64, ptr } %t692, ptr %l320, !tbaa !27
  br label %bb191
bb187:
  %t693 = load i32, ptr %l322, !tbaa !23
  %t694 = ashr i32 %t693, 16
  %t696 = icmp eq i32 %t694, 1
  store i1 %t696, ptr %l324, !tbaa !21
  %t697 = load i32, ptr %l322, !tbaa !23
  %t698 = ashr i32 %t697, 16
  %t700 = icmp eq i32 %t698, 1
  br i1 %t700, label %bb188, label %bb189
bb188:
  call void @__olang_errpay_pop()
  br label %bb189
bb189:
  br label %bb190
bb190:
  %t702 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t702, ptr %l327, !tbaa !27
  %t703 = getelementptr { i64, ptr }, ptr %l327, i32 0, i32 1
  %t704 = load ptr, ptr %t703, !tbaa !27
  %t705 = getelementptr { i64, ptr }, ptr %t704, i64 0
  %t706 = load { i64, ptr }, ptr %t705, !tbaa !37
  %t708 = extractvalue { i64, ptr } %t706, 1
  %t709 = extractvalue { i64, ptr } %t706, 0
  %t710 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t709)
  call void @olang_textcopy(ptr %t710, ptr %t708, i64 %t709)
  %t711 = insertvalue { i64, ptr } undef, i64 %t709, 0
  %t712 = insertvalue { i64, ptr } %t711, ptr %t710, 1
  %t714 = extractvalue { i64, ptr } %t712, 0
  %t715 = extractvalue { i64, ptr } %t712, 1
  %t716 = mul i64 %t714, 1
  %t717 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t716)
  call void @llvm.memcpy.p0.p0.i64(ptr %t717, ptr %t715, i64 %t716, i1 false)
  %t718 = insertvalue { i64, ptr } undef, i64 %t714, 0
  %t719 = insertvalue { i64, ptr } %t718, ptr %t717, 1
  store { i64, ptr } %t719, ptr %l320, !tbaa !27
  br label %bb191
bb191:
  %t721 = load { i64, ptr }, ptr %l320, !tbaa !27
  store ptr %l3, ptr %l331, !tbaa !29
  store { i64, ptr } %t721, ptr %l332, !tbaa !27
  %t723 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 6
  %t725 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t723)
  store { i64, ptr } %t725, ptr %l334
  br label %bb192
bb192:
  %t726 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t726, ptr %l335, !tbaa !27
  %t727 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t729 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v0, ptr %t727)
  store { i64, ptr } %t729, ptr %l337
  br label %bb193
bb193:
  %t730 = load ptr, ptr %l331, !tbaa !29
  %t731 = load { i64, ptr }, ptr %l332, !tbaa !27
  %t732 = load { i64, ptr }, ptr %l334, !tbaa !27
  %t733 = load { i64, ptr }, ptr %l335, !tbaa !27
  %t734 = load { i64, ptr }, ptr %l337, !tbaa !27
  %t735 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %v0, ptr %v0, ptr %v0, ptr %t730, { i64, ptr } %t731, { i64, ptr } %t732, { i64, ptr } %t733, { i64, ptr } %t734)
  store i32 %t735, ptr %l338
  br label %bb194
bb194:
  call void @__olang_scope_close(ptr %s0)
  %t736 = load i32, ptr %l338, !tbaa !23
  store i32 %t736, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fprofile_2eRun_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca { i64, ptr }
  %l6 = alloca i32
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l10 = alloca { i64, ptr }
  %l12 = alloca %"compiler/profile:Profile"
  %l13 = alloca { i64, ptr }
  %l14 = alloca %"compiler/profile:Places"
  %l25 = alloca i32
  %l33 = alloca i32
  %l35 = alloca i1
  %l38 = alloca ptr
  %l39 = alloca { i64, [3 x i64] }
  %l43 = alloca %"compiler/diagmsg:Msg"
  %l45 = alloca i32
  %l48 = alloca { i64, ptr }
  %l49 = alloca i64
  %l51 = alloca i64
  %l52 = alloca i32
  %l55 = alloca { i64, ptr }
  %l56 = alloca i64
  %l57 = alloca i64
  %l66 = alloca i1
  %l69 = alloca { i64, ptr }
  %l71 = alloca i64
  %l74 = alloca i32
  %l76 = alloca i1
  %l84 = alloca i32
  %l87 = alloca ptr
  %l88 = alloca { i64, [3 x i64] }
  %l89 = alloca %"compiler/diagmsg:Msg"
  %l91 = alloca i32
  %l92 = alloca { i64, ptr }
  %l94 = alloca { i64, ptr }
  %l95 = alloca i32
  %l97 = alloca i1
  %l100 = alloca { i64, ptr }
  %l103 = alloca { i64, ptr }
  %l107 = alloca %"compiler/profile:Profile"
  %l110 = alloca %"compiler/profile:Profile"
  %l111 = alloca i32
  %l113 = alloca i1
  %l118 = alloca { i64, ptr }
  %l121 = alloca %"compiler/profile:Places"
  %l125 = alloca { i64, ptr }
  %l128 = alloca i1
  %l129 = alloca { i64, ptr }
  %l133 = alloca { i64, ptr }
  %l136 = alloca i32
  %l138 = alloca i1
  %l146 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s15 = alloca %olang.scope
  %s16 = alloca %olang.scope
  %rv = alloca i32
  %t67 = alloca { i64, [3 x i64] }, align 8
  %t236 = alloca { i64, [3 x i64] }, align 8
  %t346 = alloca %"compiler/profile:Places", align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 29
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t4, 1
  %t7 = extractvalue { i64, ptr } %t4, 0
  %t8 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t7)
  call void @olang_textcopy(ptr %t8, ptr %t6, i64 %t7)
  %t9 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t10 = insertvalue { i64, ptr } %t9, ptr %t8, 1
  store { i64, ptr } %t10, ptr %l5, !tbaa !27
  %t12 = load ptr, ptr %l1, !tbaa !29
  %t14 = getelementptr %"compiler/build:Config", ptr %t12, i32 0, i32 29
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d48, i32 0, i32 1) }, ptr %t14, !tbaa !27
  %t15 = load ptr, ptr %l1, !tbaa !29
  %t17 = getelementptr %"compiler/build:Config", ptr %t15, i32 0, i32 28
  store i1 true, ptr %t17, !tbaa !21
  %t18 = load ptr, ptr %l1, !tbaa !29
  %t20 = getelementptr %"compiler/build:Config", ptr %t18, i32 0, i32 13
  store i1 true, ptr %t20, !tbaa !21
  %t22 = load ptr, ptr %l1, !tbaa !29
  %t23 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t24 = load ptr, ptr %l4, !tbaa !29
  %t29 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v4, ptr %a0, ptr %t22, { i64, ptr } %t23, ptr %t24)
  store i32 %t29, ptr %l25
  br label %bb1
bb1:
  %t30 = load i32, ptr %l25, !tbaa !23
  store i32 %t30, ptr %l6, !tbaa !23
  call void @compiler_2fspin_2eEnd()
  br label %bb2
bb2:
  %t31 = load i32, ptr %l6, !tbaa !23
  %t33 = icmp ne i32 %t31, 0
  br i1 %t33, label %bb3, label %bb4
bb3:
  %t35 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t35, ptr %rv
  br label %ret
bb4:
  br label %bb5
bb5:
  %t37 = load ptr, ptr %l1, !tbaa !29
  %t39 = getelementptr %"compiler/build:Config", ptr %t37, i32 0, i32 0
  %t40 = load { i64, ptr }, ptr %t39, !tbaa !27
  %t42 = extractvalue { i64, ptr } %t40, 1
  %t43 = extractvalue { i64, ptr } %t40, 0
  %t44 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 1
  %t45 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d49, i32 0, i32 1) }, 0
  %t46 = add i64 %t43, %t45
  %t47 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t46)
  call void @olang_textcopy(ptr %t47, ptr %t42, i64 %t43)
  %t48 = getelementptr i8, ptr %t47, i64 %t43
  call void @olang_textcopy(ptr %t48, ptr %t44, i64 %t45)
  %t49 = insertvalue { i64, ptr } undef, i64 %t46, 0
  %t50 = insertvalue { i64, ptr } %t49, ptr %t47, 1
  store { i64, ptr } %t50, ptr %l7, !tbaa !27
  %t52 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t54 = call i32 @std_2fos_2eMkDirAll(ptr %s0, { i64, ptr } %t52)
  store i32 %t54, ptr %l33
  %t55 = icmp ne i32 %t54, 0
  br i1 %t55, label %bb7, label %ok.56, !prof !99
ok.56:
  br label %bb6
bb6:
  br label %bb14
bb7:
  %t57 = load i32, ptr %l33, !tbaa !23
  %t58 = ashr i32 %t57, 16
  %t60 = icmp eq i32 %t58, 1
  store i1 %t60, ptr %l35, !tbaa !21
  %t61 = load i32, ptr %l33, !tbaa !23
  %t62 = ashr i32 %t61, 16
  %t64 = icmp eq i32 %t62, 1
  br i1 %t64, label %bb8, label %bb9
bb8:
  call void @__olang_errpay_pop()
  br label %bb9
bb9:
  br label %bb10
bb10:
  %t66 = load ptr, ptr %l4, !tbaa !29
  store ptr %t66, ptr %l38, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t67
  %t68 = getelementptr { i64, [3 x i64] }, ptr %t67, i32 0, i32 0
  store i64 0, ptr %t68
  %t69 = load { i64, [3 x i64] }, ptr %t67
  store { i64, [3 x i64] } %t69, ptr %l39
  %t70 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t71 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d50, i32 0, i32 1) }, 1
  %t72 = extractvalue { i64, ptr } { i64 24, ptr getelementptr inbounds (<{ i64, [24 x i8] }>, ptr @.d50, i32 0, i32 1) }, 0
  %t74 = extractvalue { i64, ptr } %t70, 1
  %t75 = extractvalue { i64, ptr } %t70, 0
  %t76 = add i64 %t72, %t75
  %t77 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 1
  %t78 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d51, i32 0, i32 1) }, 0
  %t79 = add i64 %t76, %t78
  %t80 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t79)
  call void @olang_textcopy(ptr %t80, ptr %t71, i64 %t72)
  %t81 = getelementptr i8, ptr %t80, i64 %t72
  call void @olang_textcopy(ptr %t81, ptr %t74, i64 %t75)
  %t82 = getelementptr i8, ptr %t81, i64 %t75
  call void @olang_textcopy(ptr %t82, ptr %t77, i64 %t78)
  %t83 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t84 = insertvalue { i64, ptr } %t83, ptr %t80, 1
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t87 = extractvalue { i64, ptr } %t84, 1
  %t88 = mul i64 %t86, 1
  %t89 = call ptr @__olang_scope_alloc(ptr %v4, i64 %t88)
  call void @llvm.memcpy.p0.p0.i64(ptr %t89, ptr %t87, i64 %t88, i1 false)
  %t90 = insertvalue { i64, ptr } undef, i64 %t86, 0
  %t91 = insertvalue { i64, ptr } %t90, ptr %t89, 1
  %t93 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v4, ptr %v4, { i64, ptr } %t91)
  store %"compiler/diagmsg:Msg" %t93, ptr %l43
  br label %bb11
bb11:
  %t94 = load ptr, ptr %l38, !tbaa !29
  %t95 = load { i64, [3 x i64] }, ptr %l39
  %t96 = load %"compiler/diagmsg:Msg", ptr %l43
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t94, { i64, [3 x i64] } %t95, %"compiler/diagmsg:Msg" %t96)
  br label %bb12
bb12:
  %t97 = load ptr, ptr %l4, !tbaa !29
  %t99 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t97)
  store i32 %t99, ptr %l45
  br label %bb13
bb13:
  call void @__olang_scope_close(ptr %s0)
  %t100 = load i32, ptr %l45, !tbaa !23
  store i32 %t100, ptr %rv
  br label %ret
bb14:
  %t101 = load ptr, ptr %l1, !tbaa !29
  %t103 = getelementptr %"compiler/build:Config", ptr %t101, i32 0, i32 30
  %t104 = load { i64, ptr }, ptr %t103, !tbaa !27
  %t106 = call { i64, ptr } @std_2ffilepath_2eBase(ptr %v1, ptr %v1, { i64, ptr } %t104)
  store { i64, ptr } %t106, ptr %l48
  br label %bb15
bb15:
  %t107 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t107, ptr %l8, !tbaa !27
  %t108 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t110 = call { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v1, ptr %s0, { i64, ptr } %t108, { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d52, i32 0, i32 1) })
  %t111 = extractvalue { i32, i64 } %t110, 1
  %t112 = extractvalue { i32, i64 } %t110, 0
  store i32 %t112, ptr %l52
  %t113 = icmp ne i32 %t112, 0
  br i1 %t113, label %bb17, label %ok.114, !prof !99
ok.114:
  store i64 %t111, ptr %l51
  br label %bb16
bb16:
  %t115 = load i64, ptr %l51, !tbaa !24
  store i64 %t115, ptr %l49, !tbaa !24
  br label %bb19
bb17:
  br label %bb18
bb18:
  %t116 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l49, !tbaa !24
  br label %bb19
bb19:
  %t120 = load i64, ptr %l49, !tbaa !24
  %t121 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t121, ptr %l55, !tbaa !27
  store i64 %t120, ptr %l56, !tbaa !24
  %t123 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  store i64 %t124, ptr %l57, !tbaa !24
  %t125 = icmp sge i64 0, 0
  br i1 %t125, label %bb20, label %bb21
bb20:
  %t127 = load i64, ptr %l56, !tbaa !24
  %t128 = icmp sle i64 0, %t127
  br i1 %t128, label %bb22, label %bb23
bb21:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb22:
  %t130 = load i64, ptr %l56, !tbaa !24
  %t131 = load i64, ptr %l57, !tbaa !24
  %t132 = icmp sle i64 %t130, %t131
  br i1 %t132, label %bb24, label %bb25
bb23:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb24:
  %t134 = getelementptr { i64, ptr }, ptr %l55, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = load i64, ptr %l56, !tbaa !24
  %t137 = getelementptr i8, ptr %t135, i64 0
  %t138 = sub i64 %t136, 0
  %t139 = insertvalue { i64, ptr } undef, i64 %t138, 0
  %t140 = insertvalue { i64, ptr } %t139, ptr %t137, 1
  store { i64, ptr } %t140, ptr %l8, !tbaa !27
  %t142 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t143 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = extractvalue { i64, ptr } %t142, 0
  %t147 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 1
  %t148 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d53, i32 0, i32 1) }, 0
  %t149 = add i64 %t146, %t148
  %t151 = extractvalue { i64, ptr } %t143, 1
  %t152 = extractvalue { i64, ptr } %t143, 0
  %t153 = add i64 %t149, %t152
  %t154 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 1
  %t155 = extractvalue { i64, ptr } { i64 8, ptr getelementptr inbounds (<{ i64, [8 x i8] }>, ptr @.d54, i32 0, i32 1) }, 0
  %t156 = add i64 %t153, %t155
  %t157 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t156)
  call void @olang_textcopy(ptr %t157, ptr %t145, i64 %t146)
  %t158 = getelementptr i8, ptr %t157, i64 %t146
  call void @olang_textcopy(ptr %t158, ptr %t147, i64 %t148)
  %t159 = getelementptr i8, ptr %t158, i64 %t148
  call void @olang_textcopy(ptr %t159, ptr %t151, i64 %t152)
  %t160 = getelementptr i8, ptr %t159, i64 %t152
  call void @olang_textcopy(ptr %t160, ptr %t154, i64 %t155)
  %t161 = insertvalue { i64, ptr } undef, i64 %t156, 0
  %t162 = insertvalue { i64, ptr } %t161, ptr %t157, 1
  store { i64, ptr } %t162, ptr %l10, !tbaa !27
  %t164 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t166 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t164, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d55, i32 0, i32 1) })
  store i1 %t166, ptr %l66
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2308270aeb54ce5f_1121c256bef46e33)
  unreachable
bb26:
  %t167 = load i1, ptr %l66, !tbaa !21
  br i1 %t167, label %bb27, label %bb28
bb27:
  %t168 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t171 = extractvalue { i64, ptr } %t168, 1
  %t172 = extractvalue { i64, ptr } %t168, 0
  %t173 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 1
  %t174 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d56, i32 0, i32 1) }, 0
  %t175 = add i64 %t172, %t174
  %t177 = extractvalue { i64, ptr } %t169, 1
  %t178 = extractvalue { i64, ptr } %t169, 0
  %t179 = add i64 %t175, %t178
  %t180 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 1
  %t181 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d57, i32 0, i32 1) }, 0
  %t182 = add i64 %t179, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t171, i64 %t172)
  %t184 = getelementptr i8, ptr %t183, i64 %t172
  call void @olang_textcopy(ptr %t184, ptr %t173, i64 %t174)
  %t185 = getelementptr i8, ptr %t184, i64 %t174
  call void @olang_textcopy(ptr %t185, ptr %t177, i64 %t178)
  %t186 = getelementptr i8, ptr %t185, i64 %t178
  call void @olang_textcopy(ptr %t186, ptr %t180, i64 %t181)
  %t187 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t188 = insertvalue { i64, ptr } %t187, ptr %t183, 1
  store { i64, ptr } %t188, ptr %l69, !tbaa !27
  %t189 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t190 = extractvalue { i64, ptr } %t189, 0
  %t191 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t192 = extractvalue { i64, ptr } %t191, 0
  store i64 %t192, ptr %l71, !tbaa !24
  %t194 = load i64, ptr %l71, !tbaa !24
  %t195 = icmp eq i64 %t190, %t194
  br i1 %t195, label %bb29, label %bb30
bb28:
  br label %bb32
bb29:
  %t197 = getelementptr { i64, ptr }, ptr %l5, i32 0, i32 1
  %t198 = load ptr, ptr %t197, !tbaa !27
  %t199 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t200 = load ptr, ptr %t199, !tbaa !27
  %t201 = load i64, ptr %l71, !tbaa !24
  %t202 = mul i64 %t201, 1
  call void @llvm.memmove.p0.p0.i64(ptr %t198, ptr %t200, i64 %t202, i1 false)
  br label %bb31
bb30:
  %t203 = load { i64, ptr }, ptr %l69, !tbaa !27
  store { i64, ptr } %t203, ptr %l5, !tbaa !27
  br label %bb31
bb31:
  br label %bb32
bb32:
  %t204 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t206 = call i32 @std_2fos_2eRemove(ptr %s0, { i64, ptr } %t204)
  store i32 %t206, ptr %l74
  %t207 = icmp ne i32 %t206, 0
  br i1 %t207, label %bb34, label %ok.208, !prof !99
ok.208:
  br label %bb33
bb33:
  br label %bb38
bb34:
  %t209 = load i32, ptr %l74, !tbaa !23
  %t210 = ashr i32 %t209, 16
  %t212 = icmp eq i32 %t210, 1
  store i1 %t212, ptr %l76, !tbaa !21
  %t213 = load i32, ptr %l74, !tbaa !23
  %t214 = ashr i32 %t213, 16
  %t216 = icmp eq i32 %t214, 1
  br i1 %t216, label %bb35, label %bb36
bb35:
  call void @__olang_errpay_pop()
  br label %bb36
bb36:
  br label %bb37
bb37:
  br label %bb38
bb38:
  %t218 = load ptr, ptr %l1, !tbaa !29
  %t220 = getelementptr %"compiler/build:Config", ptr %t218, i32 0, i32 30
  %t221 = load { i64, ptr }, ptr %t220, !tbaa !27
  %t222 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t224 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t229 = call i32 @compiler_2fprofile_2erunProfiled(ptr %v1, ptr %v2, ptr %v3, ptr %s0, { i64, ptr } %t221, { i64, ptr } %t222, { i64, ptr } %a3, { i64, ptr } %t224)
  store i32 %t229, ptr %l84
  br label %bb39
bb39:
  %t230 = load i32, ptr %l84, !tbaa !23
  store i32 %t230, ptr %l6, !tbaa !23
  %t231 = load i32, ptr %l6, !tbaa !23
  %t233 = icmp slt i32 %t231, 0
  br i1 %t233, label %bb40, label %bb41
bb40:
  %t235 = load ptr, ptr %l4, !tbaa !29
  store ptr %t235, ptr %l87, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t236
  %t237 = getelementptr { i64, [3 x i64] }, ptr %t236, i32 0, i32 0
  store i64 0, ptr %t237
  %t238 = load { i64, [3 x i64] }, ptr %t236
  store { i64, [3 x i64] } %t238, ptr %l88
  %t239 = call %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v4, ptr %v4, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d58, i32 0, i32 1) })
  store %"compiler/diagmsg:Msg" %t239, ptr %l89
  br label %bb42
bb41:
  br label %bb45
bb42:
  %t240 = load ptr, ptr %l87, !tbaa !29
  %t241 = load { i64, [3 x i64] }, ptr %l88
  %t242 = load %"compiler/diagmsg:Msg", ptr %l89
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v4, ptr %v4, ptr %t240, { i64, [3 x i64] } %t241, %"compiler/diagmsg:Msg" %t242)
  br label %bb43
bb43:
  %t243 = load ptr, ptr %l4, !tbaa !29
  %t245 = call i32 @compiler_2fbuild_2eFinish(ptr %v4, ptr %t243)
  store i32 %t245, ptr %l91
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s0)
  %t246 = load i32, ptr %l91, !tbaa !23
  store i32 %t246, ptr %rv
  br label %ret
bb45:
  %t247 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t249 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s0, { i64, ptr } %t247)
  %t250 = extractvalue { i32, { i64, ptr } } %t249, 1
  %t251 = extractvalue { i32, { i64, ptr } } %t249, 0
  store i32 %t251, ptr %l95
  %t252 = icmp ne i32 %t251, 0
  br i1 %t252, label %bb47, label %ok.253, !prof !99
ok.253:
  store { i64, ptr } %t250, ptr %l94
  br label %bb46
bb46:
  %t254 = load { i64, ptr }, ptr %l94, !tbaa !27
  store { i64, ptr } %t254, ptr %l92, !tbaa !27
  br label %bb53
bb47:
  %t255 = load i32, ptr %l95, !tbaa !23
  %t256 = ashr i32 %t255, 16
  %t258 = icmp eq i32 %t256, 1
  store i1 %t258, ptr %l97, !tbaa !21
  %t259 = load i32, ptr %l95, !tbaa !23
  %t260 = ashr i32 %t259, 16
  %t262 = icmp eq i32 %t260, 1
  br i1 %t262, label %bb48, label %bb49
bb48:
  call void @__olang_errpay_pop()
  br label %bb49
bb49:
  br label %bb50
bb50:
  store %olang.scope zeroinitializer, ptr %s11
  %t264 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t264, ptr %l100, !tbaa !27
  %t265 = load i32, ptr %l6, !tbaa !23
  %t267 = sub i32 %t265, 128
  %t269 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s11, i32 %t267)
  store { i64, ptr } %t269, ptr %l103
  br label %bb51
bb51:
  %t270 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d59, i32 0, i32 1) }, 1
  %t271 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d59, i32 0, i32 1) }, 0
  %t272 = load { i64, ptr }, ptr %l100, !tbaa !27
  %t273 = extractvalue { i64, ptr } %t272, 1
  %t274 = extractvalue { i64, ptr } %t272, 0
  %t275 = add i64 %t271, %t274
  %t276 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d60, i32 0, i32 1) }, 1
  %t277 = extractvalue { i64, ptr } { i64 42, ptr getelementptr inbounds (<{ i64, [42 x i8] }>, ptr @.d60, i32 0, i32 1) }, 0
  %t278 = add i64 %t275, %t277
  %t279 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t280 = extractvalue { i64, ptr } %t279, 1
  %t281 = extractvalue { i64, ptr } %t279, 0
  %t282 = add i64 %t278, %t281
  %t283 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) }, 1
  %t284 = extractvalue { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d61, i32 0, i32 1) }, 0
  %t285 = add i64 %t282, %t284
  %t286 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t285)
  call void @olang_textcopy(ptr %t286, ptr %t270, i64 %t271)
  %t287 = getelementptr i8, ptr %t286, i64 %t271
  call void @olang_textcopy(ptr %t287, ptr %t273, i64 %t274)
  %t288 = getelementptr i8, ptr %t287, i64 %t274
  call void @olang_textcopy(ptr %t288, ptr %t276, i64 %t277)
  %t289 = getelementptr i8, ptr %t288, i64 %t277
  call void @olang_textcopy(ptr %t289, ptr %t280, i64 %t281)
  %t290 = getelementptr i8, ptr %t289, i64 %t281
  call void @olang_textcopy(ptr %t290, ptr %t283, i64 %t284)
  %t291 = insertvalue { i64, ptr } undef, i64 %t285, 0
  %t292 = insertvalue { i64, ptr } %t291, ptr %t286, 1
  %t294 = extractvalue { i64, ptr } %t292, 0
  %t295 = extractvalue { i64, ptr } %t292, 1
  %t296 = mul i64 %t294, 1
  %t297 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t296)
  call void @llvm.memcpy.p0.p0.i64(ptr %t297, ptr %t295, i64 %t296, i1 false)
  %t298 = insertvalue { i64, ptr } undef, i64 %t294, 0
  %t299 = insertvalue { i64, ptr } %t298, ptr %t297, 1
  call void @compiler_2fprofile_2esay(ptr %s11, { i64, ptr } %t299)
  br label %bb52
bb52:
  %t301 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s11)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t301, ptr %rv
  br label %ret
bb53:
  %t303 = load { i64, ptr }, ptr %l92, !tbaa !27
  %t307 = call { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %s0, ptr %s0, { i64, ptr } %t303)
  %t308 = extractvalue { i32, %"compiler/profile:Profile" } %t307, 1
  %t309 = extractvalue { i32, %"compiler/profile:Profile" } %t307, 0
  store i32 %t309, ptr %l111
  %t310 = icmp ne i32 %t309, 0
  br i1 %t310, label %bb55, label %ok.311, !prof !99
ok.311:
  store %"compiler/profile:Profile" %t308, ptr %l110
  br label %bb54
bb54:
  %t312 = load %"compiler/profile:Profile", ptr %l110
  store %"compiler/profile:Profile" %t312, ptr %l107
  br label %bb58
bb55:
  %t313 = load i32, ptr %l111, !tbaa !23
  %t314 = ashr i32 %t313, 16
  %t316 = icmp eq i32 %t314, 1
  store i1 %t316, ptr %l113, !tbaa !21
  br label %bb56
bb56:
  store %olang.scope zeroinitializer, ptr %s13
  %t317 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t318 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 1
  %t319 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d62, i32 0, i32 1) }, 0
  %t321 = extractvalue { i64, ptr } %t317, 1
  %t322 = extractvalue { i64, ptr } %t317, 0
  %t323 = add i64 %t319, %t322
  %t324 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d63, i32 0, i32 1) }, 1
  %t325 = extractvalue { i64, ptr } { i64 39, ptr getelementptr inbounds (<{ i64, [39 x i8] }>, ptr @.d63, i32 0, i32 1) }, 0
  %t326 = add i64 %t323, %t325
  %t327 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t326)
  call void @olang_textcopy(ptr %t327, ptr %t318, i64 %t319)
  %t328 = getelementptr i8, ptr %t327, i64 %t319
  call void @olang_textcopy(ptr %t328, ptr %t321, i64 %t322)
  %t329 = getelementptr i8, ptr %t328, i64 %t322
  call void @olang_textcopy(ptr %t329, ptr %t324, i64 %t325)
  %t330 = insertvalue { i64, ptr } undef, i64 %t326, 0
  %t331 = insertvalue { i64, ptr } %t330, ptr %t327, 1
  %t333 = extractvalue { i64, ptr } %t331, 0
  %t334 = extractvalue { i64, ptr } %t331, 1
  %t335 = mul i64 %t333, 1
  %t336 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t335)
  call void @llvm.memcpy.p0.p0.i64(ptr %t336, ptr %t334, i64 %t335, i1 false)
  %t337 = insertvalue { i64, ptr } undef, i64 %t333, 0
  %t338 = insertvalue { i64, ptr } %t337, ptr %t336, 1
  call void @compiler_2fprofile_2esay(ptr %s13, { i64, ptr } %t338)
  br label %bb57
bb57:
  %t340 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t340, ptr %rv
  br label %ret
bb58:
  %t342 = load %"compiler/profile:Profile", ptr %l107
  store %"compiler/profile:Profile" %t342, ptr %l12
  %t343 = call { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %s0)
  store { i64, ptr } %t343, ptr %l118
  br label %bb59
bb59:
  %t344 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t344, ptr %l13, !tbaa !27
  %t345 = load { i64, ptr }, ptr %l13, !tbaa !27
  call void @compiler_2fprofile_2ePlaces_2eResolve(ptr %t346, ptr %s0, ptr %s0, ptr %s0, ptr %l12, { i64, ptr } %t345)
  call void @llvm.memmove.p0.p0.i64(ptr %l121, ptr %t346, i64 272, i1 false)
  br label %bb60
bb60:
  call void @llvm.memmove.p0.p0.i64(ptr %l14, ptr %l121, i64 272, i1 false)
  %t349 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t353 = call { i64, ptr } @compiler_2fprofile_2eReport(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t349, ptr %l12, ptr %l14)
  store { i64, ptr } %t353, ptr %l125
  br label %bb61
bb61:
  %t354 = load { i64, ptr }, ptr %l125, !tbaa !27
  %t355 = extractvalue { i64, ptr } %t354, 0
  %t356 = extractvalue { i64, ptr } %t354, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t360)
  br label %bb62
bb62:
  %t362 = load { i64, ptr }, ptr %l13, !tbaa !27
  %t364 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t362, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d64, i32 0, i32 1) })
  store i1 %t364, ptr %l128
  br label %bb63
bb63:
  %t365 = load i1, ptr %l128, !tbaa !21
  br i1 %t365, label %bb64, label %bb65
bb64:
  store %olang.scope zeroinitializer, ptr %s15
  call void @compiler_2fprofile_2esay(ptr %s15, { i64, ptr } { i64 101, ptr getelementptr inbounds (<{ i64, [101 x i8] }>, ptr @.d65, i32 0, i32 1) })
  br label %bb66
bb65:
  br label %bb67
bb66:
  call void @__olang_scope_close(ptr %s15)
  br label %bb67
bb67:
  %t366 = load { i64, ptr }, ptr %l5, !tbaa !27
  store { i64, ptr } %t366, ptr %l129, !tbaa !27
  %t367 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t371 = call { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v1, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t367, ptr %l12, ptr %l14)
  store { i64, ptr } %t371, ptr %l133
  br label %bb68
bb68:
  %t372 = load { i64, ptr }, ptr %l133, !tbaa !27
  %t374 = extractvalue { i64, ptr } %t372, 0
  %t375 = extractvalue { i64, ptr } %t372, 1
  %t376 = mul i64 %t374, 1
  %t377 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t376)
  call void @llvm.memcpy.p0.p0.i64(ptr %t377, ptr %t375, i64 %t376, i1 false)
  %t378 = insertvalue { i64, ptr } undef, i64 %t374, 0
  %t379 = insertvalue { i64, ptr } %t378, ptr %t377, 1
  %t380 = load { i64, ptr }, ptr %l129, !tbaa !27
  %t382 = call i32 @std_2fos_2eWriteFile(ptr %s0, ptr %s0, { i64, ptr } %t380, { i64, ptr } %t379)
  store i32 %t382, ptr %l136
  %t383 = icmp ne i32 %t382, 0
  br i1 %t383, label %bb70, label %ok.384, !prof !99
ok.384:
  br label %bb69
bb69:
  br label %bb75
bb70:
  %t385 = load i32, ptr %l136, !tbaa !23
  %t386 = ashr i32 %t385, 16
  %t388 = icmp eq i32 %t386, 1
  store i1 %t388, ptr %l138, !tbaa !21
  %t389 = load i32, ptr %l136, !tbaa !23
  %t390 = ashr i32 %t389, 16
  %t392 = icmp eq i32 %t390, 1
  br i1 %t392, label %bb71, label %bb72
bb71:
  call void @__olang_errpay_pop()
  br label %bb72
bb72:
  br label %bb73
bb73:
  store %olang.scope zeroinitializer, ptr %s16
  %t394 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t395 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d66, i32 0, i32 1) }, 1
  %t396 = extractvalue { i64, ptr } { i64 15, ptr getelementptr inbounds (<{ i64, [15 x i8] }>, ptr @.d66, i32 0, i32 1) }, 0
  %t398 = extractvalue { i64, ptr } %t394, 1
  %t399 = extractvalue { i64, ptr } %t394, 0
  %t400 = add i64 %t396, %t399
  %t401 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d67, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 19, ptr getelementptr inbounds (<{ i64, [19 x i8] }>, ptr @.d67, i32 0, i32 1) }, 0
  %t403 = add i64 %t400, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t395, i64 %t396)
  %t405 = getelementptr i8, ptr %t404, i64 %t396
  call void @olang_textcopy(ptr %t405, ptr %t398, i64 %t399)
  %t406 = getelementptr i8, ptr %t405, i64 %t399
  call void @olang_textcopy(ptr %t406, ptr %t401, i64 %t402)
  %t407 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t408 = insertvalue { i64, ptr } %t407, ptr %t404, 1
  %t410 = extractvalue { i64, ptr } %t408, 0
  %t411 = extractvalue { i64, ptr } %t408, 1
  %t412 = mul i64 %t410, 1
  %t413 = call ptr @__olang_scope_alloc(ptr %s16, i64 %t412)
  call void @llvm.memcpy.p0.p0.i64(ptr %t413, ptr %t411, i64 %t412, i1 false)
  %t414 = insertvalue { i64, ptr } undef, i64 %t410, 0
  %t415 = insertvalue { i64, ptr } %t414, ptr %t413, 1
  call void @compiler_2fprofile_2esay(ptr %s16, { i64, ptr } %t415)
  br label %bb74
bb74:
  %t417 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s16)
  call void @__olang_scope_close(ptr %s0)
  store i32 %t417, ptr %rv
  br label %ret
bb75:
  %t419 = load { i64, ptr }, ptr %l5, !tbaa !27
  %t421 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t419)
  store { i64, ptr } %t421, ptr %l146
  br label %bb76
bb76:
  %t422 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d68, i32 0, i32 1) }, 1
  %t423 = extractvalue { i64, ptr } { i64 13, ptr getelementptr inbounds (<{ i64, [13 x i8] }>, ptr @.d68, i32 0, i32 1) }, 0
  %t424 = load { i64, ptr }, ptr %l146, !tbaa !27
  %t425 = extractvalue { i64, ptr } %t424, 1
  %t426 = extractvalue { i64, ptr } %t424, 0
  %t427 = add i64 %t423, %t426
  %t428 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 1
  %t429 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d69, i32 0, i32 1) }, 0
  %t430 = add i64 %t427, %t429
  %t431 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t430)
  call void @olang_textcopy(ptr %t431, ptr %t422, i64 %t423)
  %t432 = getelementptr i8, ptr %t431, i64 %t423
  call void @olang_textcopy(ptr %t432, ptr %t425, i64 %t426)
  %t433 = getelementptr i8, ptr %t432, i64 %t426
  call void @olang_textcopy(ptr %t433, ptr %t428, i64 %t429)
  %t434 = insertvalue { i64, ptr } undef, i64 %t430, 0
  %t435 = insertvalue { i64, ptr } %t434, ptr %t431, 1
  %t437 = extractvalue { i64, ptr } %t435, 0
  %t438 = extractvalue { i64, ptr } %t435, 1
  %t439 = mul i64 %t437, 1
  %t440 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t439)
  call void @llvm.memcpy.p0.p0.i64(ptr %t440, ptr %t438, i64 %t439, i1 false)
  %t441 = insertvalue { i64, ptr } undef, i64 %t437, 0
  %t442 = insertvalue { i64, ptr } %t441, ptr %t440, 1
  call void @compiler_2fprofile_2esay(ptr %s0, { i64, ptr } %t442)
  br label %bb77
bb77:
  %t444 = load i32, ptr %l6, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t444, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @std_2fio_2ePutLine_3cstd_2fprelude_2ftext_3aString_26_3e(ptr %v0, { i64, ptr } %a0) #0 {
entry:
  %l6 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load i32, ptr @G_2estd_2fio_2eStdout, !tbaa !23
  %t4 = extractvalue { i64, ptr } %a0, 1
  %t5 = extractvalue { i64, ptr } %a0, 0
  %t6 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 1
  %t7 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d70, i32 0, i32 1) }, 0
  %t8 = add i64 %t5, %t7
  %t9 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t8)
  call void @olang_textcopy(ptr %t9, ptr %t4, i64 %t5)
  %t10 = getelementptr i8, ptr %t9, i64 %t5
  call void @olang_textcopy(ptr %t10, ptr %t6, i64 %t7)
  %t11 = insertvalue { i64, ptr } undef, i64 %t8, 0
  %t12 = insertvalue { i64, ptr } %t11, ptr %t9, 1
  %t15 = extractvalue { i64, ptr } %t12, 0
  %t16 = extractvalue { i64, ptr } %t12, 1
  %t17 = mul i64 %t15, 1
  %t18 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t17)
  call void @llvm.memcpy.p0.p0.i64(ptr %t18, ptr %t16, i64 %t17, i1 false)
  %t19 = insertvalue { i64, ptr } undef, i64 %t15, 0
  %t20 = insertvalue { i64, ptr } %t19, ptr %t18, 1
  %t23 = call i32 @std_2fio_2eWrite(ptr %s0, i32 %t1, { i64, ptr } %t20)
  store i32 %t23, ptr %l6
  %t24 = icmp ne i32 %t23, 0
  br i1 %t24, label %bb2, label %ok.25, !prof !99
ok.25:
  br label %bb1
bb1:
  br label %bb3
bb2:
  %t26 = load i32, ptr %l6, !tbaa !23
  %t27 = lshr i32 %t26, 16
  %t28 = and i32 %t26, 65535
  %t29 = icmp eq i32 %t27, 1
  %t30 = select i1 %t29, i32 1, i32 0
  %t31 = icmp eq i32 %t26, 0
  %t32 = shl i32 %t30, 16
  %t33 = or i32 %t32, %t28
  %t34 = select i1 %t31, i32 0, i32 %t33
  call void @__olang_scope_close(ptr %s0)
  store i32 %t34, ptr %rv
  br label %ret
bb3:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local void @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_2c_20std_H260c71ae77815ec4b6e333189d6723ff(ptr %v0, ptr %a0) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca i64
  %l4 = alloca i64
  %l5 = alloca i64
  %l6 = alloca i64
  %l16 = alloca i1
  %l19 = alloca %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15"
  %l28 = alloca i64
  %l31 = alloca i64
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t1, i32 0, i32 3
  %t4 = load i64, ptr %t3, !tbaa !24
  %t6 = sub i64 %t4, 1
  store i64 %t6, ptr %l1, !tbaa !24
  br label %bb1
bb1:
  %t8 = load i64, ptr %l1, !tbaa !24
  %t10 = icmp sge i64 %t8, 0
  %t12 = xor i1 %t10, true
  br i1 %t12, label %bb2, label %bb3
bb2:
  br label %bb10
bb3:
  br label %bb4
bb4:
  %t14 = load ptr, ptr %l0, !tbaa !29
  %t15 = load i64, ptr %l1, !tbaa !24
  %t18 = call i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H068cfedf7407289d149ee3c6f4c8aa20(ptr %v0, ptr %t14, i64 %t15)
  store i1 %t18, ptr %l16
  br label %bb5
bb5:
  %t19 = load i1, ptr %l16, !tbaa !21
  br i1 %t19, label %bb6, label %bb7
bb6:
  %t20 = load ptr, ptr %l0, !tbaa !29
  %t21 = load i64, ptr %l1, !tbaa !24
  %t23 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t20, i32 0, i32 0
  %t25 = getelementptr { i64, ptr }, ptr %t23, i32 0, i32 1
  %t26 = load ptr, ptr %t25, !tbaa !27
  %t27 = getelementptr %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %t26, i64 %t21
  %t28 = load %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15", ptr %t27
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" zeroinitializer, ptr %t27
  store %"std/prelude/map:MapEntry.c7dad01dbd7dd6cd22e9701676806c15" %t28, ptr %l19
  br label %bb8
bb7:
  br label %bb8
bb8:
  br label %bb9
bb9:
  %t29 = load i64, ptr %l1, !tbaa !24
  %t31 = sub i64 %t29, 1
  store i64 %t31, ptr %l1, !tbaa !24
  br label %bb1
bb10:
  store i64 0, ptr %l2, !tbaa !24
  %t33 = load ptr, ptr %l0, !tbaa !29
  %t35 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t33, i32 0, i32 2
  %t36 = load { i64, ptr }, ptr %t35, !tbaa !27
  %t38 = extractvalue { i64, ptr } %t36, 0
  store i64 %t38, ptr %l3, !tbaa !24
  store i64 1, ptr %l4, !tbaa !24
  %t40 = load i64, ptr %l3, !tbaa !24
  %t41 = load i64, ptr %l2, !tbaa !24
  %t44 = icmp sgt i64 %t40, %t41
  br i1 %t44, label %bb11, label %bb12
bb11:
  %t46 = load i64, ptr %l4, !tbaa !24
  %t48 = icmp sgt i64 %t46, 0
  br i1 %t48, label %bb13, label %bb14
bb12:
  store i64 0, ptr %l28, !tbaa !24
  br label %bb16
bb13:
  %t50 = load i64, ptr %l3, !tbaa !24
  %t51 = load i64, ptr %l2, !tbaa !24
  %t54 = sub i64 %t50, %t51
  %t55 = load i64, ptr %l4, !tbaa !24
  %t58 = add i64 %t54, %t55
  %t60 = sub i64 %t58, 1
  %t61 = load i64, ptr %l4, !tbaa !24
  %t64 = sdiv i64 %t60, %t61
  store i64 %t64, ptr %l31, !tbaa !24
  br label %bb15
bb14:
  store i64 0, ptr %l31, !tbaa !24
  br label %bb15
bb15:
  %t66 = load i64, ptr %l31, !tbaa !24
  store i64 %t66, ptr %l28, !tbaa !24
  br label %bb16
bb16:
  %t67 = load i64, ptr %l28, !tbaa !24
  store i64 %t67, ptr %l5, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb17
bb17:
  %t68 = load i64, ptr %l6, !tbaa !24
  %t69 = load i64, ptr %l5, !tbaa !24
  %t72 = icmp slt i64 %t68, %t69
  %t74 = xor i1 %t72, true
  br i1 %t74, label %bb18, label %bb19
bb18:
  br label %bb22
bb19:
  br label %bb20
bb20:
  %t76 = load i64, ptr %l2, !tbaa !24
  %t77 = load i64, ptr %l6, !tbaa !24
  %t78 = load i64, ptr %l4, !tbaa !24
  %t81 = mul i64 %t77, %t78
  %t84 = add i64 %t76, %t81
  %t86 = load ptr, ptr %l0, !tbaa !29
  %t89 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t86, i32 0, i32 2
  %t91 = getelementptr { i64, ptr }, ptr %t89, i32 0, i32 1
  %t92 = load ptr, ptr %t91, !tbaa !27
  %t93 = getelementptr i64, ptr %t92, i64 %t84
  store i64 -1, ptr %t93, !tbaa !34
  br label %bb21
bb21:
  %t94 = load i64, ptr %l6, !tbaa !24
  %t96 = add i64 %t94, 1
  store i64 %t96, ptr %l6, !tbaa !24
  br label %bb17
bb22:
  %t98 = load ptr, ptr %l0, !tbaa !29
  %t100 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t98, i32 0, i32 3
  store i64 0, ptr %t100, !tbaa !24
  %t101 = load ptr, ptr %l0, !tbaa !29
  %t103 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t101, i32 0, i32 4
  store i64 0, ptr %t103, !tbaa !24
  %t104 = load ptr, ptr %l0, !tbaa !29
  %t106 = getelementptr %"std/prelude/map:Map.38ecd5291a2eac158a479efae74bd262", ptr %t104, i32 0, i32 5
  store i64 -1, ptr %t106, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2ePush_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, %"compiler/build:Code" %a1) #0 {
entry:
  %l0 = alloca ptr
  %l16 = alloca ptr
  store ptr %a0, ptr %l0
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t1, i32 0, i32 1
  %t4 = load i64, ptr %t3, !tbaa !24
  %t5 = load ptr, ptr %l0, !tbaa !29
  %t7 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t5, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t10 = extractvalue { i64, ptr } %t8, 0
  %t13 = icmp eq i64 %t4, %t10
  br i1 %t13, label %bb1, label %bb2
bb1:
  %t15 = load ptr, ptr %l0, !tbaa !29
  %t16 = load ptr, ptr %l0, !tbaa !29
  %t18 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t16, i32 0, i32 1
  %t19 = load i64, ptr %t18, !tbaa !24
  %t21 = add i64 %t19, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eroom_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %t15, i64 %t21)
  br label %bb3
bb2:
  br label %bb4
bb3:
  br label %bb4
bb4:
  %t24 = load ptr, ptr %l0, !tbaa !29
  %t25 = load ptr, ptr %l0, !tbaa !29
  %t27 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t25, i32 0, i32 1
  %t28 = load i64, ptr %t27, !tbaa !24
  %t32 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t24, i32 0, i32 0
  %t34 = getelementptr { i64, ptr }, ptr %t32, i32 0, i32 1
  %t35 = load ptr, ptr %t34, !tbaa !27
  %t36 = getelementptr %"compiler/build:Code", ptr %t35, i64 %t28
  store %"compiler/build:Code" %a1, ptr %t36
  %t37 = load ptr, ptr %l0, !tbaa !29
  store ptr %t37, ptr %l16, !tbaa !29
  %t38 = load ptr, ptr %l16, !tbaa !29
  %t39 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t38, i32 0, i32 1
  %t40 = load i64, ptr %t39, !tbaa !24
  %t42 = add i64 %t40, 1
  %t44 = load ptr, ptr %l16, !tbaa !29
  %t45 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t44, i32 0, i32 1
  store i64 %t42, ptr %t45, !tbaa !24
  br label %ret
ret:
  ret void
}

define dso_local void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fbuild_3aCode_3e_2eroom_3ccompiler_2fbuild_3aCode_3e(ptr %v0, ptr %a0, i64 %a1) noinline cold #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca i64
  %l2 = alloca i64
  %l3 = alloca { i64, ptr }
  %l4 = alloca { i64, ptr }
  %l6 = alloca i64
  %l16 = alloca i64
  %l33 = alloca ptr
  %l34 = alloca { i64, ptr }
  %l36 = alloca i64
  %l37 = alloca i64
  %l44 = alloca { i64, ptr }
  %l45 = alloca i64
  %l51 = alloca { i64, ptr }
  store ptr %a0, ptr %l0
  store i64 %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load i64, ptr %l1, !tbaa !24
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 0
  %t5 = load { i64, ptr }, ptr %t4, !tbaa !27
  %t7 = extractvalue { i64, ptr } %t5, 0
  %t10 = icmp sle i64 %t1, %t7
  br i1 %t10, label %bb1, label %bb2
bb1:
  br label %ret
bb2:
  br label %bb3
bb3:
  %t12 = load ptr, ptr %l0, !tbaa !29
  %t14 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t12, i32 0, i32 0
  %t15 = load { i64, ptr }, ptr %t14, !tbaa !27
  %t17 = extractvalue { i64, ptr } %t15, 0
  %t19 = icmp slt i64 %t17, 4
  br i1 %t19, label %bb4, label %bb5
bb4:
  store i64 8, ptr %l16, !tbaa !24
  br label %bb6
bb5:
  %t21 = load ptr, ptr %l0, !tbaa !29
  %t23 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t21, i32 0, i32 0
  %t24 = load { i64, ptr }, ptr %t23, !tbaa !27
  %t26 = extractvalue { i64, ptr } %t24, 0
  %t28 = mul i64 %t26, 2
  store i64 %t28, ptr %l16, !tbaa !24
  br label %bb6
bb6:
  %t30 = load i64, ptr %l16, !tbaa !24
  store i64 %t30, ptr %l2, !tbaa !24
  %t31 = load i64, ptr %l2, !tbaa !24
  %t32 = load i64, ptr %l1, !tbaa !24
  %t35 = icmp slt i64 %t31, %t32
  br i1 %t35, label %bb7, label %bb8
bb7:
  %t37 = load i64, ptr %l1, !tbaa !24
  store i64 %t37, ptr %l2, !tbaa !24
  br label %bb9
bb8:
  br label %bb9
bb9:
  %t39 = load i64, ptr %l2, !tbaa !24
  %t40 = load ptr, ptr %l0, !tbaa !29
  %t42 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t40, i32 0, i32 2
  %t43 = load i64, ptr %t42, !tbaa !24
  %t46 = icmp slt i64 %t39, %t43
  br i1 %t46, label %bb10, label %bb11
bb10:
  %t48 = load ptr, ptr %l0, !tbaa !29
  %t50 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t48, i32 0, i32 2
  %t51 = load i64, ptr %t50, !tbaa !24
  store i64 %t51, ptr %l2, !tbaa !24
  br label %bb12
bb11:
  br label %bb12
bb12:
  %t53 = load ptr, ptr %l0, !tbaa !29
  %t55 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t53, i32 0, i32 0
  %t56 = load { i64, ptr }, ptr %t55, !tbaa !27
  store { i64, ptr } %t56, ptr %l3, !tbaa !27
  %t58 = load ptr, ptr %l0, !tbaa !29
  store ptr %t58, ptr %l33, !tbaa !29
  %t59 = load { i64, ptr }, ptr %l3, !tbaa !27
  store { i64, ptr } %t59, ptr %l34, !tbaa !27
  %t60 = load ptr, ptr %l0, !tbaa !29
  %t62 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t60, i32 0, i32 1
  %t63 = load i64, ptr %t62, !tbaa !24
  store i64 %t63, ptr %l36, !tbaa !24
  %t64 = load { i64, ptr }, ptr %l34, !tbaa !27
  %t65 = extractvalue { i64, ptr } %t64, 0
  store i64 %t65, ptr %l37, !tbaa !24
  %t66 = icmp sge i64 0, 0
  br i1 %t66, label %bb13, label %bb14
bb13:
  %t68 = load i64, ptr %l36, !tbaa !24
  %t69 = icmp sle i64 0, %t68
  br i1 %t69, label %bb15, label %bb16
bb14:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb15:
  %t71 = load i64, ptr %l36, !tbaa !24
  %t72 = load i64, ptr %l37, !tbaa !24
  %t73 = icmp sle i64 %t71, %t72
  br i1 %t73, label %bb17, label %bb18
bb16:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb17:
  %t75 = getelementptr { i64, ptr }, ptr %l34, i32 0, i32 1
  %t76 = load ptr, ptr %t75, !tbaa !27
  %t77 = load i64, ptr %l36, !tbaa !24
  %t78 = getelementptr %"compiler/build:Code", ptr %t76, i64 0
  %t79 = sub i64 %t77, 0
  %t80 = insertvalue { i64, ptr } undef, i64 %t79, 0
  %t81 = insertvalue { i64, ptr } %t80, ptr %t78, 1
  store { i64, ptr } %t81, ptr %l4, !tbaa !27
  %t83 = load i64, ptr %l2, !tbaa !24
  %t87 = mul i64 %t83, 56
  %t88 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t87)
  %t89 = insertvalue { i64, ptr } undef, i64 %t83, 0
  %t90 = insertvalue { i64, ptr } %t89, ptr %t88, 1
  store { i64, ptr } %t90, ptr %l44, !tbaa !27
  store i64 0, ptr %l45, !tbaa !24
  store i64 0, ptr %l6, !tbaa !24
  br label %bb19
bb18:
  call void @__olang_check_failed(ptr @olang_loc_42020986585537b2_4c4b240152eb3e56)
  unreachable
bb19:
  %t91 = load i64, ptr %l6, !tbaa !24
  %t92 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t94 = extractvalue { i64, ptr } %t92, 0
  %t97 = icmp slt i64 %t91, %t94
  %t99 = xor i1 %t97, true
  br i1 %t99, label %bb20, label %bb21
bb20:
  br label %bb24
bb21:
  br label %bb22
bb22:
  %t101 = load { i64, ptr }, ptr %l4, !tbaa !27
  store { i64, ptr } %t101, ptr %l51, !tbaa !27
  %t102 = load i64, ptr %l6, !tbaa !24
  %t104 = getelementptr { i64, ptr }, ptr %l51, i32 0, i32 1
  %t105 = load ptr, ptr %t104, !tbaa !27
  %t106 = getelementptr %"compiler/build:Code", ptr %t105, i64 %t102
  %t107 = load %"compiler/build:Code", ptr %t106
  %t109 = load i64, ptr %l45, !tbaa !24
  %t110 = getelementptr { i64, ptr }, ptr %l44, i32 0, i32 1
  %t111 = load ptr, ptr %t110, !tbaa !27
  %t112 = getelementptr %"compiler/build:Code", ptr %t111, i64 %t109
  store %"compiler/build:Code" %t107, ptr %t112
  %t113 = load i64, ptr %l45, !tbaa !24
  %t114 = add i64 %t113, 1
  store i64 %t114, ptr %l45, !tbaa !24
  br label %bb23
bb23:
  %t115 = load i64, ptr %l6, !tbaa !24
  %t117 = add i64 %t115, 1
  store i64 %t117, ptr %l6, !tbaa !24
  br label %bb19
bb24:
  %t119 = load { i64, ptr }, ptr %l44, !tbaa !27
  %t120 = load ptr, ptr %l33, !tbaa !29
  %t121 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t120, i32 0, i32 0
  store { i64, ptr } %t119, ptr %t121, !tbaa !27
  %t122 = load { i64, ptr }, ptr %l3, !tbaa !27
  br label %ret
ret:
  ret void
}

define dso_local ptr @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2femit_3aReused_3e_2eRef_3ccompiler_2femit_3aReused_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca ptr
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/emit:Reused", ptr %t7, i64 %a1
  store ptr %t8, ptr %rv
  br label %ret
ret:
  %rr = load ptr, ptr %rv
  ret ptr %rr
}

define dso_local %"compiler/explain:Code" @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2eAt_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %v1, ptr %a0, i64 %a1) #0 {
entry:
  %rv = alloca %"compiler/explain:Code"
  br label %start
start:
  br label %bb0
bb0:
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0, i32 0, i32 0
  %t6 = getelementptr { i64, ptr }, ptr %t4, i32 0, i32 1
  %t7 = load ptr, ptr %t6, !tbaa !27
  %t8 = getelementptr %"compiler/explain:Code", ptr %t7, i64 %a1
  %t9 = load %"compiler/explain:Code", ptr %t8
  store %"compiler/explain:Code" %t9, ptr %rv
  br label %ret
ret:
  %rr = load %"compiler/explain:Code", ptr %rv
  ret %"compiler/explain:Code" %rr
}

define dso_local i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2fexplain_3aCode_3e_2eLen_3ccompiler_2fexplain_3aCode_3e(ptr %v0, ptr %a0) #0 {
entry:
  %r = tail call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
  ret i64 %r
}

define dso_local i1 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3ccompiler_2ftyped_3aMark_3e_2eEq_3ccompiler_2ftyped_3aMark_3e(ptr %v0, ptr %v1, ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca ptr
  %l4 = alloca i64
  %l5 = alloca i64
  %l9 = alloca { i64, ptr }
  %l10 = alloca ptr
  %l11 = alloca ptr
  %l13 = alloca i64
  %l14 = alloca i64
  %l18 = alloca { i64, ptr }
  %l20 = alloca i1
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  %t1 = load ptr, ptr %l0, !tbaa !29
  store ptr %t1, ptr %l2, !tbaa !29
  %t2 = load ptr, ptr %l0, !tbaa !29
  %t4 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t2, i32 0, i32 1
  %t5 = load i64, ptr %t4, !tbaa !24
  store i64 %t5, ptr %l4, !tbaa !24
  %t6 = load ptr, ptr %l2, !tbaa !29
  %t7 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t6, i32 0, i32 0
  %t8 = load { i64, ptr }, ptr %t7, !tbaa !27
  %t9 = extractvalue { i64, ptr } %t8, 0
  store i64 %t9, ptr %l5, !tbaa !24
  %t10 = icmp sge i64 0, 0
  br i1 %t10, label %bb1, label %bb2
bb1:
  %t12 = load i64, ptr %l4, !tbaa !24
  %t13 = icmp sle i64 0, %t12
  br i1 %t13, label %bb3, label %bb4
bb2:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb3:
  %t15 = load i64, ptr %l4, !tbaa !24
  %t16 = load i64, ptr %l5, !tbaa !24
  %t17 = icmp sle i64 %t15, %t16
  br i1 %t17, label %bb5, label %bb6
bb4:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb5:
  %t19 = load ptr, ptr %l2, !tbaa !29
  %t20 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t19, i32 0, i32 0
  %t21 = getelementptr { i64, ptr }, ptr %t20, i32 0, i32 1
  %t22 = load ptr, ptr %t21, !tbaa !27
  %t23 = load i64, ptr %l4, !tbaa !24
  %t24 = getelementptr { i64, [1 x i64] }, ptr %t22, i64 0
  %t25 = sub i64 %t23, 0
  %t26 = insertvalue { i64, ptr } undef, i64 %t25, 0
  %t27 = insertvalue { i64, ptr } %t26, ptr %t24, 1
  store { i64, ptr } %t27, ptr %l9, !tbaa !27
  store ptr %l9, ptr %l10
  %t28 = load ptr, ptr %l1, !tbaa !29
  store ptr %t28, ptr %l11, !tbaa !29
  %t29 = load ptr, ptr %l1, !tbaa !29
  %t31 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t29, i32 0, i32 1
  %t32 = load i64, ptr %t31, !tbaa !24
  store i64 %t32, ptr %l13, !tbaa !24
  %t33 = load ptr, ptr %l11, !tbaa !29
  %t34 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t33, i32 0, i32 0
  %t35 = load { i64, ptr }, ptr %t34, !tbaa !27
  %t36 = extractvalue { i64, ptr } %t35, 0
  store i64 %t36, ptr %l14, !tbaa !24
  %t37 = icmp sge i64 0, 0
  br i1 %t37, label %bb7, label %bb8
bb6:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb7:
  %t39 = load i64, ptr %l13, !tbaa !24
  %t40 = icmp sle i64 0, %t39
  br i1 %t40, label %bb9, label %bb10
bb8:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb9:
  %t42 = load i64, ptr %l13, !tbaa !24
  %t43 = load i64, ptr %l14, !tbaa !24
  %t44 = icmp sle i64 %t42, %t43
  br i1 %t44, label %bb11, label %bb12
bb10:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb11:
  %t46 = load ptr, ptr %l11, !tbaa !29
  %t47 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %t46, i32 0, i32 0
  %t48 = getelementptr { i64, ptr }, ptr %t47, i32 0, i32 1
  %t49 = load ptr, ptr %t48, !tbaa !27
  %t50 = load i64, ptr %l13, !tbaa !24
  %t51 = getelementptr { i64, [1 x i64] }, ptr %t49, i64 0
  %t52 = sub i64 %t50, 0
  %t53 = insertvalue { i64, ptr } undef, i64 %t52, 0
  %t54 = insertvalue { i64, ptr } %t53, ptr %t51, 1
  store { i64, ptr } %t54, ptr %l18, !tbaa !27
  %t55 = load ptr, ptr %l10
  %t57 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e_26(ptr %t55, ptr %l18)
  store i1 %t57, ptr %l20
  br label %bb13
bb12:
  call void @__olang_check_failed(ptr @olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f)
  unreachable
bb13:
  %t58 = load i1, ptr %l20, !tbaa !21
  store i1 %t58, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
declare void @__olang_check_failed(ptr) cold noreturn
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln) alwaysinline {
entry:
  ; every allocation is rounded up to 8 bytes so the NEXT one starts 8-aligned. The bump offset is a
  ; raw byte sum, so without this a 12-byte "Array<I32>(3)" left the following allocation at offset 12 -
  ; fine for an i32 but misaligned for any i64 or pointer field, which is UB at the LLVM level even
  ; where the hardware tolerates it. Latent before; the dtor nodes below (24 bytes, three pointers,
  ; one per registered instance) made it near-certain to be hit. The chunk's own data area is
  ; already 64-aligned (O8a): the chunk is, and its header is 64 bytes.
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  ; E10: an allocation of nothing still gets storage of its own, so two of them are two instances (an empty array
  ; made twice, a struct with no fields built twice) - a zero size bumped nothing, and handed both the same address
  %size0 = icmp eq i64 %size8, 0
  %size = select i1 %size0, i64 8, i64 %size8
  %alnm1 = sub i64 %aln, 1
  %alnmask = sub i64 0, %aln
  ; every offset is a multiple of 8 already (every size is), so an 8-aligned allocation - every aggregate, and every
  ; array under 32 bytes, decided while compiling where the size is known - takes the offset as it is
  %round = icmp ugt i64 %aln, 8
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %headnull = icmp eq ptr %head, null
  br i1 %headnull, label %needchunk, label %checkspace
checkspace:
  %csusedptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 1
  %csused = load i64, ptr %csusedptr, !tbaa !60
  %cscapptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 2
  %cscap = load i64, ptr %cscapptr, !tbaa !60
  %csup = add i64 %csused, %alnm1
  %csrounded = and i64 %csup, %alnmask
  %csaligned = select i1 %round, i64 %csrounded, i64 %csused
  %remaining = sub i64 %cscap, %csaligned
  %fits = icmp uge i64 %remaining, %size
  br i1 %fits, label %bump, label %needchunk
  ; the common case, complete in itself: the offset just computed, bumped
bump:
  %dataptr = getelementptr %olang.chunk, ptr %head, i32 1
  %result = getelementptr i8, ptr %dataptr, i64 %csaligned
  %newused = add i64 %csaligned, %size
  store i64 %newused, ptr %csusedptr, !tbaa !60
  ; B19b: a benchmark build counts what this thread allocates - here and at the slow path's own bump, so each
  ; allocation is counted once wherever it is made (a region's and a forwarded scope's come back through here)
; @bench %bna = load i64, ptr @__olang_bench_allocs
; @bench %bna1 = add i64 %bna, 1
; @bench store i64 %bna1, ptr @__olang_bench_allocs
; @bench %bnb = load i64, ptr @__olang_bench_bytes
; @bench %bnb1 = add i64 %bnb, %size
; @bench store i64 %bnb1, ptr @__olang_bench_bytes
  ret ptr %result
needchunk:
  %slow = tail call ptr @__olang_scope_alloc_slow(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %slow
}
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
declare void @__olang_errpay_pop()
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d11 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"run" }>, align 8
@.d12 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d14 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"-" }>, align 8
@.d15 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d16 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c".ir" }>, align 8
@.d17 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c".asm" }>, align 8
@.d18 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"/listing/" }>, align 8
@.d19 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d20 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d21 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define linkonce_odr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @olang_2emir_2eHelperKind_2eCopy_2estd_2fprelude_2fvec_3aVec_3cI64_3e(ptr %v0, ptr %a0) #0 {
entry:
  %l1 = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  %l2 = alloca { i64, ptr }
  %l3 = alloca i64
  %l4 = alloca { i64, ptr }
  %rv = alloca %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44"
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %a0
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t2, ptr %l1
  %t3 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  %t4 = load { i64, ptr }, ptr %t3, !tbaa !27
  store { i64, ptr } %t4, ptr %l2, !tbaa !27
  %t5 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t6 = extractvalue { i64, ptr } %t5, 0
  store i64 %t6, ptr %l3, !tbaa !24
  %t7 = load i64, ptr %l3, !tbaa !24
  %t8 = mul i64 %t7, 8
  %t9 = call ptr @__olang_scope_alloc(ptr %v0, i64 %t8)
  %t10 = insertvalue { i64, ptr } undef, i64 %t7, 0
  %t11 = insertvalue { i64, ptr } %t10, ptr %t9, 1
  store { i64, ptr } %t11, ptr %l4, !tbaa !27
  %t12 = getelementptr { i64, ptr }, ptr %l4, i32 0, i32 1
  %t13 = load ptr, ptr %t12, !tbaa !27
  %t14 = getelementptr { i64, ptr }, ptr %l2, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = load i64, ptr %l3, !tbaa !24
  %t17 = mul i64 %t16, 8
  call void @llvm.memmove.p0.p0.i64(ptr %t13, ptr %t15, i64 %t17, i1 false)
  %t18 = load { i64, ptr }, ptr %l4, !tbaa !27
  %t19 = getelementptr %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1, i32 0, i32 0
  store { i64, ptr } %t18, ptr %t19, !tbaa !27
  %t20 = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %l1
  store %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %t20, ptr %rv
  br label %ret
ret:
  %rr = load %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44", ptr %rv
  ret %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" %rr
}

@.d24 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"RaceBuild" }>, align 8
@.d25 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"RaceBuild" }>, align 8
@.d26 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d27 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d28 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d29 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d30 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d31 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d32 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d33 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d34 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_test" }>, align 8
@.d35 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d36 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": native compilation failed" }>, align 8
@.d37 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d38 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d39 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d40 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"running tools" }>, align 8
@.d41 = private constant <{ i64, [9 x i8] }> <{ i64 0, [9 x i8] c"compiling" }>, align 8
@.d42 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d43 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"-ir" }>, align 8
@.d44 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d45 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
define linkonce_odr i32 @compiler_2folang_2ebuildCell_fv_fn_28std_2fprelude_2ftext_3aString_26_2c_20std_2fprelude_2ftext_3aString_26_2c_20Array_3_H1276486710fe3f33d55b88d9cfddba68(ptr %env, ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7) #0 {
entry:
  %r = call i32 @compiler_2folang_2ebuildCell(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7)
  ret i32 %r
}

@.d46 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d47 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d48 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d49 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c"/profile" }>, align 8
@.d50 = private constant <{ i64, [24 x i8] }> <{ i64 0, [24 x i8] c"its profile's directory " }>, align 8
@.d51 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c" cannot be made" }>, align 8
@.d52 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"." }>, align 8
@.d53 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d54 = private constant <{ i64, [8 x i8] }> <{ i64 0, [8 x i8] c".samples" }>, align 8
@.d55 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d56 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d57 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c".html" }>, align 8
@.d58 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d59 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d60 = private constant <{ i64, [42 x i8] }> <{ i64 0, [42 x i8] c" wrote no profile - it ended by a signal (" }>, align 8
@.d61 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c")\0A" }>, align 8
@.d62 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d63 = private constant <{ i64, [39 x i8] }> <{ i64 0, [39 x i8] c" is not a profile this compiler writes\0A" }>, align 8
@.d64 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d65 = private constant <{ i64, [101 x i8] }> <{ i64 0, [101 x i8] c"olang profile: no llvm-symbolizer found beside clang or on PATH - functions named by their addresses\0A" }>, align 8
@.d66 = private constant <{ i64, [15 x i8] }> <{ i64 0, [15 x i8] c"olang profile: " }>, align 8
@.d67 = private constant <{ i64, [19 x i8] }> <{ i64 0, [19 x i8] c" cannot be written\0A" }>, align 8
@.d68 = private constant <{ i64, [13 x i8] }> <{ i64 0, [13 x i8] c"flame graph: " }>, align 8
@.d69 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
@.d70 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"\0A" }>, align 8
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e_26(ptr %a0, ptr %a1) #0 {
entry:
  %l6 = alloca i1
  %rv = alloca i1
  br label %start
start:
  br label %bb0
bb0:
  %t2 = load { i64, ptr }, ptr %a0, !tbaa !27
  %t4 = load { i64, ptr }, ptr %a1, !tbaa !27
  %t9 = call i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e({ i64, ptr } %t2, { i64, ptr } %t4)
  store i1 %t9, ptr %l6
  br label %bb1
bb1:
  %t10 = load i1, ptr %l6, !tbaa !21
  store i1 %t10, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_slow(ptr, i64, i64) noinline
define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2eArray_3ccompiler_2ftyped_3aMark_3e({ i64, ptr } %a0, { i64, ptr } %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca { i64, ptr }
  %l2 = alloca i1
  %l3 = alloca i64
  %l6 = alloca i64
  %l10 = alloca i1
  %rv = alloca i1
  store { i64, ptr } %a0, ptr %l0
  store { i64, ptr } %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t2 = extractvalue { i64, ptr } %t1, 0
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load { i64, ptr }, ptr %l1, !tbaa !27
  %t4 = extractvalue { i64, ptr } %t3, 0
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb8
bb2:
  store i64 0, ptr %l6, !tbaa !24
  br label %bb3
bb3:
  %t9 = load i64, ptr %l6, !tbaa !24
  %t10 = load i64, ptr %l3, !tbaa !24
  %t11 = icmp slt i64 %t9, %t10
  br i1 %t11, label %bb4, label %bb5
bb4:
  %t13 = load i64, ptr %l6, !tbaa !24
  %t14 = getelementptr { i64, ptr }, ptr %l0, i32 0, i32 1
  %t15 = load ptr, ptr %t14, !tbaa !27
  %t16 = getelementptr { i64, [1 x i64] }, ptr %t15, i64 %t13
  %t17 = load i64, ptr %l6, !tbaa !24
  %t18 = getelementptr { i64, ptr }, ptr %l1, i32 0, i32 1
  %t19 = load ptr, ptr %t18, !tbaa !27
  %t20 = getelementptr { i64, [1 x i64] }, ptr %t19, i64 %t17
  %t23 = call i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aMark(ptr %t16, ptr %t20)
  store i1 %t23, ptr %l10
  br label %bb6
bb5:
  br label %bb8
bb6:
  %t24 = load i1, ptr %l10, !tbaa !21
  br i1 %t24, label %bb7, label %bb1
bb7:
  %t25 = load i64, ptr %l6, !tbaa !24
  %t26 = add i64 %t25, 1
  store i64 %t26, ptr %l6, !tbaa !24
  br label %bb3
bb8:
  %t27 = load i1, ptr %l2, !tbaa !21
  store i1 %t27, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

define linkonce_odr i1 @olang_2emir_2eHelperKind_2eEqual_2ecompiler_2ftyped_3aMark(ptr %a0, ptr %a1) #0 {
entry:
  %l0 = alloca ptr
  %l1 = alloca ptr
  %l2 = alloca i1
  %l3 = alloca i64
  %rv = alloca i1
  store ptr %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store i1 true, ptr %l2, !tbaa !21
  %t1 = load ptr, ptr %l0, !tbaa !29
  %t2 = load i64, ptr %t1, !range !{i64 0, i64 6}
  store i64 %t2, ptr %l3, !tbaa !24
  %t3 = load ptr, ptr %l1, !tbaa !29
  %t4 = load i64, ptr %t3, !range !{i64 0, i64 6}
  %t5 = load i64, ptr %l3, !tbaa !24
  %t7 = icmp eq i64 %t5, %t4
  br i1 %t7, label %bb2, label %bb1
bb1:
  store i1 false, ptr %l2, !tbaa !21
  br label %bb6
bb2:
  %t9 = load i64, ptr %l3, !tbaa !24
  switch i64 %t9, label %bb3 [ i64 2, label %bb4 ]
bb3:
  br label %bb6
bb4:
  %t10 = load ptr, ptr %l0, !tbaa !29
  %t11 = getelementptr { i64, [1 x i64] }, ptr %t10, i32 0, i32 1
  %t12 = getelementptr { i32 }, ptr %t11, i32 0, i32 0
  %t13 = load i32, ptr %t12
  %t14 = load ptr, ptr %l1, !tbaa !29
  %t15 = getelementptr { i64, [1 x i64] }, ptr %t14, i32 0, i32 1
  %t16 = getelementptr { i32 }, ptr %t15, i32 0, i32 0
  %t17 = load i32, ptr %t16
  %t20 = icmp eq i32 %t13, %t17
  br i1 %t20, label %bb5, label %bb1
bb5:
  br label %bb3
bb6:
  %t22 = load i1, ptr %l2, !tbaa !21
  store i1 %t22, ptr %rv
  br label %ret
ret:
  %rr = load i1, ptr %rv
  ret i1 %rr
}

declare void @compiler_2fbuild_3aProgram_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
declare { i32, %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/diagmsg:Msg" %a2)
declare void @compiler_2fspin_2eEnd()
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H43a0c2f426a671129c7ac3eefd9ac274(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/diagmsg:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_251e830707558b33_b2bdace7e2a71047 = external constant [0 x i8]
declare void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"std/os:FileInfo" } @std_2fos_2eFileInfo_2eStat(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/diagmsg:Msg" %a2, ptr %a3)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_ac43697cc5f2dca0_4dfd3d6081b857d4 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2enoTestNamed(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eCacheDir(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i32, { i64, ptr } } @std_2fos_2eRealPath(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare %"std/prelude/vec:Vec.64e7ca1f48df489627458d7bcd916e44" @std_2fprelude_2fvec_3aVec_3cU64_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i32, { i64, ptr } } @std_2fos_2eCwd(ptr %v0)
declare { i64, ptr } @std_2ffilepath_2eBase(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2eHashOf(ptr %v0, ptr %v1, ptr %a0)
@olang_loc_d52a764a2d9743a3_d3f0603066c4fb17 = external constant [0 x i8]
declare i64 @std_2ftime_2eNow()
declare { i64, ptr } @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eWarnings(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2fbuild_2esayErr(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2fbuild_2eRunCacheCap = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\40\00\00\00\00" }>, align 8
declare void @compiler_2fbuild_2eprune(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1, i64 %a2)
@olang_loc_6165e91575c84e88_fb0586f2b3992fac = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
declare i64 @std_2fprelude_2fnumber_2eI64_2eMax_3cI64_3e(i64 %a0, i64 %a1)
declare i32 @compiler_2fmeasure_2eMeasure(ptr %v0, { i64, ptr } %a0, i64 %a1, i64 %a2)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare %"compiler/diagmsg:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_52ef5e06ac377ee6_47cc3810ffe2829a = external constant [0 x i8]
declare %"compiler/build:Listed" @compiler_2fbuild_3aListed_2ector(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistQuick(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
declare { i64, ptr } @compiler_2fbuild_2eRemarksOf(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare i1 @std_2fos_2eExists(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elistLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, i1 %a4, ptr %a5, ptr %a6)
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
declare i1 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2esplitsTests(ptr %v0, ptr %a0)
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eTestHeader(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2efuzzRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunTests(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, i64 %a6)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2etestsEnded(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, i32 %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunParts(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, { i64, ptr } %a5, ptr %a6)
declare void @compiler_2fcond_2ecompiler_2fcond_3aConsts_2eSetBool(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1, i1 %a2)
@olang_loc_d427f69e0d58601c_ef1499a0f9cee590 = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eFinish(ptr %v0, ptr %a0)
@olang_loc_4ce37e8669e18741_b51ffe42b73135c5 = external constant [0 x i8]
declare { i64, ptr } @compiler_2flisting_2ehow(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare { i64, ptr } @compiler_2flisting_2ecommentOf(ptr %v0, ptr %v1, ptr %a0, i1 %a1)
declare %"compiler/listing:Inputs" @compiler_2flisting_3aInputs_2ector(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, i1 %a4)
declare { i64, ptr } @compiler_2flisting_2eRender(ptr %v0, ptr %v1, ptr %a0)
declare void @compiler_2flisting_2esay(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare i32 @compiler_2folang_2eCommandLine_2ePrepare(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eJupyter = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0F\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eNotebook = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\10\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
declare i1 @compiler_2folang_2ewaits(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eFix = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare void @compiler_2fspin_2eBegin(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eCapsMode(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@G_2ecompiler_2folang_2eBindgen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eApi = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0E\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fapi_2eMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRunBuilt = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eProfile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0D\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2fcells_2eBuilder = external global { ptr, ptr }
declare i32 @compiler_2fprompt_2eRun(ptr %v0, ptr %a0)
declare i32 @compiler_2fjupyter_2eInstall(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1)
declare i32 @compiler_2fjupyter_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare i32 @compiler_2fnotebook_2eRun(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, i1 %a3)
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4)
declare i32 @std_2fos_2eMkDirAll(ptr %v0, { i64, ptr } %a0)
declare { i32, i64 } @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eFind(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_2308270aeb54ce5f_1121c256bef46e33 = external constant [0 x i8]
declare i32 @std_2fos_2eRemove(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fprofile_2erunProfiled(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare void @compiler_2fprofile_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, %"compiler/profile:Profile" } @compiler_2fprofile_2eProfile_2eRead(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fprofile_2eSymbolizer(ptr %v0)
declare void @compiler_2fprofile_2ePlaces_2eResolve(ptr %out, ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fprofile_2eReport(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
declare { i64, ptr } @compiler_2fprofile_2eFlameGraph(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
@G_2estd_2fio_2eStdout = available_externally constant <{ [4 x i8] }> <{ [4 x i8] c"\01\00\00\00" }>, align 8
declare i32 @std_2fio_2eWrite(ptr %v0, i32 %a0, { i64, ptr } %a1)
declare i1 @std_2fprelude_2fmap_2estd_2fprelude_2fmap_3aMap_3cstd_2fprelude_2ftext_3aString_26_2c_20_H068cfedf7407289d149ee3c6f4c8aa20(ptr %v0, ptr %a0, i64 %a1)
@olang_loc_42020986585537b2_4c4b240152eb3e56 = external constant [0 x i8]
@olang_loc_97cf5ae9e8f78f7b_c02d850957d8f30f = external constant [0 x i8]
declare i32 @compiler_2folang_2ebuildCell(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %v5, ptr %v6, ptr %v7, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3, { i64, ptr } %a4, ptr %a5, ptr %a6, ptr %a7)

!20 = !{!"olang"}
!99 = !{!"branch_weights", i32 1, i32 2000}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" nounwind }
