; olang - emitted by the self-hosted compiler (compiler/emit.olang)
target triple = "x86_64-pc-linux-gnu"

%olang.chunk = type { ptr, i64, i64, i64, i64, i64, ptr, i64 }
%olang.pool = type { [128 x ptr], i128, i64, i64, i64 }
%olang.dtornode = type { ptr, ptr, ptr, ptr, ptr }
%olang.unwind = type { ptr, ptr, ptr }
%olang.task = type { ptr, i64, ptr, i64 }
%olang.worker = type { ptr, ptr, ptr, i64, ptr, [40 x i8], [48 x i8] }
%olang.merge = type { ptr, ptr }
%olang.scope = type { ptr, ptr, ptr, ptr, ptr, ptr, ptr }
%olang.region = type { %olang.scope, %olang.scope, ptr, ptr, ptr, ptr, ptr }
%olang.stackrun = type { ptr, ptr, i32, i32, ptr, ptr }
%olang.builder = type { ptr, i64, i64, ptr, ptr }
%"compiler/build:Program" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr } }
%"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" = type { ptr }
%"compiler/msgs:Msg" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/build:Config" = type { { i64, ptr }, { i64, ptr }, %"compiler/target:Target", %"compiler/cond:Consts", i1, i1, i1, i1, i1, i1, i1, i1, i64, i1, i1, { i64, ptr }, { i64, ptr }, i64, i64, i1, { i64, ptr }, { i64, ptr } }
%"compiler/target:Target" = type { { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, { i64, ptr }, i64, i1, i1 }
%"compiler/cond:Consts" = type { %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" }
%"std/os:FileInfo" = type { i32, i64, i64 }
%"std/os:Output" = type { i32, { i64, ptr }, { i64, ptr } }
%"compiler/diag:Diagnostics" = type { i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", i64, i1, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, [3 x i64] }, { i64, ptr }, { i64, ptr }, i1 }
%"compiler/olang:CommandLine" = type { i64, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, i1, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", { i64, ptr }, { i64, ptr }, i1, { i64, ptr } }
define dso_local i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"compiler/build:Program"
  %l14 = alloca i32
  %l18 = alloca i32
  %l19 = alloca i32
  %l21 = alloca i64
  %l23 = alloca i1
  %l25 = alloca i64
  %l28 = alloca i32
  %l31 = alloca i32
  %l35 = alloca i32
  %l36 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l40 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca i32
  %l45 = alloca i32
  %l53 = alloca i32
  %l56 = alloca i1
  %l58 = alloca { i64, ptr }
  %l63 = alloca { i64, ptr }
  %l65 = alloca { i64, ptr }
  %l67 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l71 = alloca ptr
  %l72 = alloca ptr
  %l73 = alloca { i64, ptr }
  %l75 = alloca i1
  %l78 = alloca i32
  %l81 = alloca ptr
  %l82 = alloca { i64, [3 x i64] }
  %l84 = alloca %"compiler/msgs:Msg"
  %l86 = alloca i32
  %l94 = alloca ptr
  %l97 = alloca i1
  %l99 = alloca { i64, ptr }
  %l102 = alloca { i64, ptr }
  %l105 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s9 = alloca %olang.scope
  %s11 = alloca %olang.scope
  %rv = alloca i32
  %t180 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t1, ptr %l7
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Program", ptr %l7
  store %"compiler/build:Program" %t2, ptr %l4
  %t4 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t4, i32 1, ptr %t5, ptr %l4, ptr %t6)
  store i32 %t13, ptr %l14
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t16 = load i32, ptr %l14, !tbaa !23
  %t17 = icmp eq i32 %t16, 65536
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l14, !tbaa !23
  %t20 = icmp eq i32 %t19, 65537
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l18
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_4cd8465f442ebc46_73c7e9f900a2458a)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t25 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t25, ptr %l19
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l18, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l19, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb12:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l21
  br label %bb13
bb13:
  %t31 = load i64, ptr %l21, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l23, !tbaa !21
  br label %bb17
bb15:
  %t34 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t34)
  store i64 %t36, ptr %l25
  br label %bb16
bb16:
  %t37 = load i64, ptr %l25, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l23, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l23, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l28
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i32, ptr %l28, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb21:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t45, ptr %t46)
  store i32 %t49, ptr %l31
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb23, label %ok.51
ok.51:
  br label %bb22
bb22:
  br label %bb28
bb23:
  %t52 = load i32, ptr %l31, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_13a46f17cfa63227_b1895594948889cb)
  unreachable
bb26:
  call void @__olang_ert_req_clear()
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t57)
  store i32 %t59, ptr %l35
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load i32, ptr %l35, !tbaa !23
  store i32 %t60, ptr %rv
  br label %ret
bb28:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t66 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t61, ptr %l4, ptr %t62)
  %t67 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 1
  %t68 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 0
  store i32 %t68, ptr %l41
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb30, label %ok.70
ok.70:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l40
  br label %bb29
bb29:
  %t71 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l40
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l36
  br label %bb35
bb30:
  %t72 = load i32, ptr %l41, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_fd88121d790f24ac_3e6efb3076496690)
  unreachable
bb33:
  call void @__olang_ert_req_clear()
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t77)
  store i32 %t79, ptr %l45
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l45, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb35:
  %t81 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l36
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l5
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d0, i32 0, i32 1) })
  br label %bb36
bb36:
  %t82 = load ptr, ptr %l1, !tbaa !29
  %t84 = getelementptr %"compiler/build:Config", ptr %t82, i32 0, i32 9
  %t85 = load i1, ptr %t84, !tbaa !21
  br i1 %t85, label %bb37, label %bb38
bb37:
  %t87 = load ptr, ptr %l1, !tbaa !29
  %t88 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t89 = load ptr, ptr %l3, !tbaa !29
  %t95 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v1, ptr %s0, ptr %s0, ptr %v2, ptr %v1, ptr %t87, ptr %l4, ptr %l5, { i64, ptr } %t88, ptr %t89)
  store i32 %t95, ptr %l53
  br label %bb39
bb38:
  br label %bb40
bb39:
  call void @__olang_scope_close(ptr %s0)
  %t96 = load i32, ptr %l53, !tbaa !23
  store i32 %t96, ptr %rv
  br label %ret
bb40:
  %t97 = load ptr, ptr %l1, !tbaa !29
  %t99 = getelementptr %"compiler/build:Config", ptr %t97, i32 0, i32 15
  %t100 = load { i64, ptr }, ptr %t99, !tbaa !27
  %t102 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t100, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d1, i32 0, i32 1) })
  store i1 %t102, ptr %l56
  br label %bb41
bb41:
  %t103 = load i1, ptr %l56, !tbaa !21
  %t104 = xor i1 %t103, true
  br i1 %t104, label %bb42, label %bb43
bb42:
  %t106 = load ptr, ptr %l1, !tbaa !29
  %t108 = getelementptr %"compiler/build:Config", ptr %t106, i32 0, i32 15
  %t109 = load { i64, ptr }, ptr %t108, !tbaa !27
  %t111 = extractvalue { i64, ptr } %t109, 1
  %t112 = extractvalue { i64, ptr } %t109, 0
  %t113 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t112)
  call void @olang_textcopy(ptr %t113, ptr %t111, i64 %t112)
  %t114 = insertvalue { i64, ptr } undef, i64 %t112, 0
  %t115 = insertvalue { i64, ptr } %t114, ptr %t113, 1
  store { i64, ptr } %t115, ptr %l58, !tbaa !27
  br label %bb47
bb43:
  %t117 = load ptr, ptr %l1, !tbaa !29
  %t119 = getelementptr %"compiler/build:Config", ptr %t117, i32 0, i32 0
  %t120 = load { i64, ptr }, ptr %t119, !tbaa !27
  store { i64, ptr } %t120, ptr %l63, !tbaa !27
  %t122 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l4)
  store { i64, ptr } %t122, ptr %l65
  br label %bb44
bb44:
  %t123 = load { i64, ptr }, ptr %l65, !tbaa !27
  %t124 = extractvalue { i64, ptr } %t123, 0
  %t125 = extractvalue { i64, ptr } %t123, 1
  %t126 = mul i64 %t124, 1
  %t127 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t126)
  call void @llvm.memcpy.p0.p0.i64(ptr %t127, ptr %t125, i64 %t126, i1 false)
  %t128 = insertvalue { i64, ptr } undef, i64 %t124, 0
  %t129 = insertvalue { i64, ptr } %t128, ptr %t127, 1
  %t131 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t129)
  store { i64, ptr } %t131, ptr %l67
  br label %bb45
bb45:
  %t132 = load ptr, ptr %l1, !tbaa !29
  %t134 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t132)
  store { i64, ptr } %t134, ptr %l69
  br label %bb46
bb46:
  %t135 = load { i64, ptr }, ptr %l63, !tbaa !27
  %t136 = extractvalue { i64, ptr } %t135, 1
  %t137 = extractvalue { i64, ptr } %t135, 0
  %t138 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 1
  %t139 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d2, i32 0, i32 1) }, 0
  %t140 = add i64 %t137, %t139
  %t141 = load { i64, ptr }, ptr %l67, !tbaa !27
  %t142 = extractvalue { i64, ptr } %t141, 1
  %t143 = extractvalue { i64, ptr } %t141, 0
  %t144 = add i64 %t140, %t143
  %t145 = load { i64, ptr }, ptr %l69, !tbaa !27
  %t146 = extractvalue { i64, ptr } %t145, 1
  %t147 = extractvalue { i64, ptr } %t145, 0
  %t148 = add i64 %t144, %t147
  %t149 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t148)
  call void @olang_textcopy(ptr %t149, ptr %t136, i64 %t137)
  %t150 = getelementptr i8, ptr %t149, i64 %t137
  call void @olang_textcopy(ptr %t150, ptr %t138, i64 %t139)
  %t151 = getelementptr i8, ptr %t150, i64 %t139
  call void @olang_textcopy(ptr %t151, ptr %t142, i64 %t143)
  %t152 = getelementptr i8, ptr %t151, i64 %t143
  call void @olang_textcopy(ptr %t152, ptr %t146, i64 %t147)
  %t153 = insertvalue { i64, ptr } undef, i64 %t148, 0
  %t154 = insertvalue { i64, ptr } %t153, ptr %t149, 1
  store { i64, ptr } %t154, ptr %l58, !tbaa !27
  br label %bb47
bb47:
  %t156 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t156, ptr %l6, !tbaa !27
  %t157 = load ptr, ptr %l1, !tbaa !29
  store ptr %t157, ptr %l71, !tbaa !29
  store ptr %l5, ptr %l72, !tbaa !29
  %t158 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t158, ptr %l73, !tbaa !27
  %t159 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 2
  %t160 = load { i64, ptr }, ptr %t159, !tbaa !27
  %t162 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t160, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d3, i32 0, i32 1) })
  store i1 %t162, ptr %l75
  br label %bb48
bb48:
  %t163 = load i1, ptr %l75, !tbaa !21
  %t164 = xor i1 %t163, true
  %t165 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 3
  %t166 = load ptr, ptr %l71, !tbaa !29
  %t167 = load ptr, ptr %l72, !tbaa !29
  %t168 = load { i64, ptr }, ptr %l73, !tbaa !27
  %t171 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t166, ptr %t167, { i64, ptr } %t168, i1 %t164, ptr %t165, ptr null)
  store i32 %t171, ptr %l78
  %t172 = icmp ne i32 %t171, 0
  br i1 %t172, label %bb50, label %ok.173
ok.173:
  br label %bb49
bb49:
  br label %bb57
bb50:
  %t174 = load i32, ptr %l78, !tbaa !23
  %t175 = ashr i32 %t174, 16
  %t177 = icmp eq i32 %t175, 1
  br i1 %t177, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_a50415520eaa75d_89ededae97ad6121)
  unreachable
bb53:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s9
  %t179 = load ptr, ptr %l3, !tbaa !29
  store ptr %t179, ptr %l81, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t180
  %t181 = getelementptr { i64, [3 x i64] }, ptr %t180, i32 0, i32 0
  store i64 0, ptr %t181
  %t182 = load { i64, [3 x i64] }, ptr %t180
  store { i64, [3 x i64] } %t182, ptr %l82
  %t183 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t185 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %s0, ptr %s9, { i64, ptr } %t183)
  store %"compiler/msgs:Msg" %t185, ptr %l84
  br label %bb54
bb54:
  %t186 = load ptr, ptr %l81, !tbaa !29
  %t187 = load { i64, [3 x i64] }, ptr %l82
  %t188 = load %"compiler/msgs:Msg", ptr %l84
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s9, ptr %t186, { i64, [3 x i64] } %t187, %"compiler/msgs:Msg" %t188)
  br label %bb55
bb55:
  %t189 = load ptr, ptr %l3, !tbaa !29
  %t191 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t189)
  store i32 %t191, ptr %l86
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s9)
  call void @__olang_scope_close(ptr %s0)
  %t192 = load i32, ptr %l86, !tbaa !23
  store i32 %t192, ptr %rv
  br label %ret
bb57:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d4, i32 0, i32 1) })
  br label %bb58
bb58:
  %t193 = load ptr, ptr %l1, !tbaa !29
  %t194 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = extractvalue { i64, ptr } %t194, 0
  %t198 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t197)
  call void @olang_textcopy(ptr %t198, ptr %t196, i64 %t197)
  %t199 = insertvalue { i64, ptr } undef, i64 %t197, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  %t202 = extractvalue { i64, ptr } %t200, 0
  %t203 = extractvalue { i64, ptr } %t200, 1
  %t204 = mul i64 %t202, 1
  %t205 = call ptr @__olang_scope_alloc(ptr %v1, i64 %t204)
  call void @llvm.memcpy.p0.p0.i64(ptr %t205, ptr %t203, i64 %t204, i1 false)
  %t206 = insertvalue { i64, ptr } undef, i64 %t202, 0
  %t207 = insertvalue { i64, ptr } %t206, ptr %t205, 1
  %t210 = getelementptr %"compiler/build:Config", ptr %t193, i32 0, i32 16
  store { i64, ptr } %t207, ptr %t210, !tbaa !27
  %t211 = load ptr, ptr %l1, !tbaa !29
  %t213 = getelementptr %"compiler/build:Config", ptr %t211, i32 0, i32 14
  %t214 = load i1, ptr %t213, !tbaa !21
  %t216 = xor i1 %t214, true
  br i1 %t216, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s11
  %t218 = load ptr, ptr %l1, !tbaa !29
  store ptr %t218, ptr %l94, !tbaa !29
  %t219 = load ptr, ptr %l1, !tbaa !29
  %t221 = getelementptr %"compiler/build:Config", ptr %t219, i32 0, i32 15
  %t222 = load { i64, ptr }, ptr %t221, !tbaa !27
  %t224 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s11, { i64, ptr } %t222, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d5, i32 0, i32 1) })
  store i1 %t224, ptr %l97
  br label %bb61
bb60:
  br label %bb68
bb61:
  %t225 = load i1, ptr %l97, !tbaa !21
  %t226 = xor i1 %t225, true
  br i1 %t226, label %bb62, label %bb63
bb62:
  %t228 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t228, ptr %l99, !tbaa !27
  br label %bb65
bb63:
  %t230 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t232 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s11, { i64, ptr } %t230)
  store { i64, ptr } %t232, ptr %l102
  br label %bb64
bb64:
  %t233 = load { i64, ptr }, ptr %l102, !tbaa !27
  store { i64, ptr } %t233, ptr %l99, !tbaa !27
  br label %bb65
bb65:
  %t234 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 1
  %t235 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d6, i32 0, i32 1) }, 0
  %t236 = load { i64, ptr }, ptr %l99, !tbaa !27
  %t237 = extractvalue { i64, ptr } %t236, 1
  %t238 = extractvalue { i64, ptr } %t236, 0
  %t239 = add i64 %t235, %t238
  %t240 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t239)
  call void @olang_textcopy(ptr %t240, ptr %t234, i64 %t235)
  %t241 = getelementptr i8, ptr %t240, i64 %t235
  call void @olang_textcopy(ptr %t241, ptr %t237, i64 %t238)
  %t242 = insertvalue { i64, ptr } undef, i64 %t239, 0
  %t243 = insertvalue { i64, ptr } %t242, ptr %t240, 1
  %t245 = extractvalue { i64, ptr } %t243, 0
  %t246 = extractvalue { i64, ptr } %t243, 1
  %t247 = mul i64 %t245, 1
  %t248 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t247)
  call void @llvm.memcpy.p0.p0.i64(ptr %t248, ptr %t246, i64 %t247, i1 false)
  %t249 = insertvalue { i64, ptr } undef, i64 %t245, 0
  %t250 = insertvalue { i64, ptr } %t249, ptr %t248, 1
  %t251 = load ptr, ptr %l94, !tbaa !29
  %t253 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s11, ptr %s11, ptr %s11, ptr %t251, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d7, i32 0, i32 1) }, { i64, ptr } %t250)
  store { i64, ptr } %t253, ptr %l105
  br label %bb66
bb66:
  %t254 = load { i64, ptr }, ptr %l105, !tbaa !27
  %t255 = extractvalue { i64, ptr } %t254, 0
  %t256 = extractvalue { i64, ptr } %t254, 1
  %t257 = mul i64 %t255, 1
  %t258 = call ptr @__olang_scope_alloc(ptr %s11, i64 %t257)
  call void @llvm.memcpy.p0.p0.i64(ptr %t258, ptr %t256, i64 %t257, i1 false)
  %t259 = insertvalue { i64, ptr } undef, i64 %t255, 0
  %t260 = insertvalue { i64, ptr } %t259, ptr %t258, 1
  call void @compiler_2fbuild_2esayln(ptr %s11, { i64, ptr } %t260)
  br label %bb67
bb67:
  call void @__olang_scope_close(ptr %s11)
  br label %bb68
bb68:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l3 = alloca ptr
  %l4 = alloca %"compiler/build:Program"
  %l5 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l6 = alloca { i64, ptr }
  %l8 = alloca %"compiler/build:Program"
  %l15 = alloca i32
  %l19 = alloca i32
  %l20 = alloca i32
  %l22 = alloca i64
  %l24 = alloca i1
  %l26 = alloca i64
  %l29 = alloca i32
  %l32 = alloca i32
  %l36 = alloca i32
  %l37 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l41 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca i32
  %l46 = alloca i32
  %l48 = alloca { i64, ptr }
  %l51 = alloca i1
  %l53 = alloca { i64, ptr }
  %l55 = alloca { i64, ptr }
  %l56 = alloca i32
  %l59 = alloca { i64, ptr }
  %l60 = alloca %"compiler/msgs:Msg"
  %l63 = alloca i32
  %l68 = alloca i32
  %l72 = alloca { i64, ptr }
  %l73 = alloca %"compiler/msgs:Msg"
  %l76 = alloca i32
  %l88 = alloca { i64, ptr }
  %s0 = alloca %olang.scope
  %s6 = alloca %olang.scope
  %s7 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t1, ptr %l8
  br label %bb1
bb1:
  %t2 = load %"compiler/build:Program", ptr %l8
  store %"compiler/build:Program" %t2, ptr %l4
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load ptr, ptr %l3, !tbaa !29
  %t13 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, i32 0, ptr %t5, ptr %l4, ptr %t6)
  store i32 %t13, ptr %l15
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb3, label %ok.15
ok.15:
  br label %bb2
bb2:
  br label %bb12
bb3:
  %t16 = load i32, ptr %l15, !tbaa !23
  %t17 = icmp eq i32 %t16, 65536
  br i1 %t17, label %bb4, label %bb5
bb4:
  br label %bb6
bb5:
  %t19 = load i32, ptr %l15, !tbaa !23
  %t20 = icmp eq i32 %t19, 65537
  br i1 %t20, label %bb7, label %bb8
bb6:
  call void @__olang_ert_req_clear()
  %t22 = load ptr, ptr %l3, !tbaa !29
  %t24 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t22)
  store i32 %t24, ptr %l19
  br label %bb10
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_539f96ece49ac99_8ec4d6c22ed03845)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t25 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t25, ptr %l20
  br label %bb11
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l19, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb11:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l20, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb12:
  %t28 = load ptr, ptr %l3, !tbaa !29
  %t30 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t28)
  store i64 %t30, ptr %l22
  br label %bb13
bb13:
  %t31 = load i64, ptr %l22, !tbaa !24
  %t32 = icmp sgt i64 %t31, 0
  br i1 %t32, label %bb14, label %bb15
bb14:
  store i1 true, ptr %l24, !tbaa !21
  br label %bb17
bb15:
  %t34 = getelementptr %"compiler/build:Program", ptr %l4, i32 0, i32 0
  %t36 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t34)
  store i64 %t36, ptr %l26
  br label %bb16
bb16:
  %t37 = load i64, ptr %l26, !tbaa !24
  %t38 = icmp eq i64 %t37, 0
  store i1 %t38, ptr %l24, !tbaa !21
  br label %bb17
bb17:
  %t40 = load i1, ptr %l24, !tbaa !21
  br i1 %t40, label %bb18, label %bb19
bb18:
  %t41 = load ptr, ptr %l3, !tbaa !29
  %t43 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t41)
  store i32 %t43, ptr %l29
  br label %bb20
bb19:
  br label %bb21
bb20:
  call void @__olang_scope_close(ptr %s0)
  %t44 = load i32, ptr %l29, !tbaa !23
  store i32 %t44, ptr %rv
  br label %ret
bb21:
  %t45 = load ptr, ptr %l1, !tbaa !29
  %t46 = load ptr, ptr %l3, !tbaa !29
  %t49 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t45, ptr %t46)
  store i32 %t49, ptr %l32
  %t50 = icmp ne i32 %t49, 0
  br i1 %t50, label %bb23, label %ok.51
ok.51:
  br label %bb22
bb22:
  br label %bb28
bb23:
  %t52 = load i32, ptr %l32, !tbaa !23
  %t53 = ashr i32 %t52, 16
  %t55 = icmp eq i32 %t53, 1
  br i1 %t55, label %bb24, label %bb25
bb24:
  br label %bb26
bb25:
  call void @__olang_check_failed(ptr @olang_loc_2f392dba8d9257c8_60d4d2a55ada0794)
  unreachable
bb26:
  call void @__olang_ert_req_clear()
  %t57 = load ptr, ptr %l3, !tbaa !29
  %t59 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t57)
  store i32 %t59, ptr %l36
  br label %bb27
bb27:
  call void @__olang_scope_close(ptr %s0)
  %t60 = load i32, ptr %l36, !tbaa !23
  store i32 %t60, ptr %rv
  br label %ret
bb28:
  %t61 = load ptr, ptr %l1, !tbaa !29
  %t62 = load ptr, ptr %l3, !tbaa !29
  %t66 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t61, ptr %l4, ptr %t62)
  %t67 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 1
  %t68 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t66, 0
  store i32 %t68, ptr %l42
  %t69 = icmp ne i32 %t68, 0
  br i1 %t69, label %bb30, label %ok.70
ok.70:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t67, ptr %l41
  br label %bb29
bb29:
  %t71 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l41
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t71, ptr %l37
  br label %bb35
bb30:
  %t72 = load i32, ptr %l42, !tbaa !23
  %t73 = ashr i32 %t72, 16
  %t75 = icmp eq i32 %t73, 1
  br i1 %t75, label %bb31, label %bb32
bb31:
  br label %bb33
bb32:
  call void @__olang_check_failed(ptr @olang_loc_21ac6a2bf5030ca3_5f4b05cf8c14a9cf)
  unreachable
bb33:
  call void @__olang_ert_req_clear()
  %t77 = load ptr, ptr %l3, !tbaa !29
  %t79 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t77)
  store i32 %t79, ptr %l46
  br label %bb34
bb34:
  call void @__olang_scope_close(ptr %s0)
  %t80 = load i32, ptr %l46, !tbaa !23
  store i32 %t80, ptr %rv
  br label %ret
bb35:
  %t81 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l37
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t81, ptr %l5
  %t83 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %l5, i64 0)
  store { i64, ptr } %t83, ptr %l48
  br label %bb36
bb36:
  %t84 = load { i64, ptr }, ptr %l48, !tbaa !27
  store { i64, ptr } %t84, ptr %l6, !tbaa !27
  %t85 = load ptr, ptr %l1, !tbaa !29
  %t87 = getelementptr %"compiler/build:Config", ptr %t85, i32 0, i32 15
  %t88 = load { i64, ptr }, ptr %t87, !tbaa !27
  %t90 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v1, ptr %s0, { i64, ptr } %t88, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d8, i32 0, i32 1) })
  store i1 %t90, ptr %l51
  br label %bb37
bb37:
  %t91 = load i1, ptr %l51, !tbaa !21
  %t92 = xor i1 %t91, true
  br i1 %t92, label %bb38, label %bb39
bb38:
  store %olang.scope zeroinitializer, ptr %s6
  %t94 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t96 = call { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %s0, ptr %s6, { i64, ptr } %t94)
  %t97 = extractvalue { i32, { i64, ptr } } %t96, 1
  %t98 = extractvalue { i32, { i64, ptr } } %t96, 0
  store i32 %t98, ptr %l56
  %t99 = icmp ne i32 %t98, 0
  br i1 %t99, label %bb41, label %ok.100
ok.100:
  store { i64, ptr } %t97, ptr %l55
  br label %bb40
bb39:
  br label %bb58
bb40:
  %t101 = load { i64, ptr }, ptr %l55, !tbaa !27
  store { i64, ptr } %t101, ptr %l53, !tbaa !27
  br label %bb48
bb41:
  %t102 = load i32, ptr %l56, !tbaa !23
  %t103 = ashr i32 %t102, 16
  %t105 = icmp eq i32 %t103, 1
  br i1 %t105, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_6e425cae5aa6eba2_2e2cf5e273de798e)
  unreachable
bb44:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s7
  %t107 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t107, ptr %l59, !tbaa !27
  %t108 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s7)
  store %"compiler/msgs:Msg" %t108, ptr %l60
  br label %bb45
bb45:
  %t109 = load ptr, ptr %l3, !tbaa !29
  %t110 = load { i64, ptr }, ptr %l59, !tbaa !27
  %t111 = load %"compiler/msgs:Msg", ptr %l60
  call void @compiler_2fbuild_2efileFatal(ptr %s0, ptr %s7, ptr %v1, { i64, ptr } %t110, %"compiler/msgs:Msg" %t111, ptr %t109)
  br label %bb46
bb46:
  %t113 = load ptr, ptr %l3, !tbaa !29
  %t115 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t113)
  store i32 %t115, ptr %l63
  br label %bb47
bb47:
  call void @__olang_scope_close(ptr %s7)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t116 = load i32, ptr %l63, !tbaa !23
  store i32 %t116, ptr %rv
  br label %ret
bb48:
  %t117 = load { i64, ptr }, ptr %l53, !tbaa !27
  %t118 = load ptr, ptr %l1, !tbaa !29
  %t120 = getelementptr %"compiler/build:Config", ptr %t118, i32 0, i32 15
  %t121 = load { i64, ptr }, ptr %t120, !tbaa !27
  %t126 = call i32 @std_2fos_2eWriteFile(ptr %v1, ptr %s6, { i64, ptr } %t121, { i64, ptr } %t117)
  store i32 %t126, ptr %l68
  %t127 = icmp ne i32 %t126, 0
  br i1 %t127, label %bb50, label %ok.128
ok.128:
  br label %bb49
bb49:
  br label %bb57
bb50:
  %t129 = load i32, ptr %l68, !tbaa !23
  %t130 = ashr i32 %t129, 16
  %t132 = icmp eq i32 %t130, 1
  br i1 %t132, label %bb51, label %bb52
bb51:
  br label %bb53
bb52:
  call void @__olang_check_failed(ptr @olang_loc_d8d1abb67d19f675_1213066b6aae1069)
  unreachable
bb53:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s8
  %t134 = load ptr, ptr %l1, !tbaa !29
  %t136 = getelementptr %"compiler/build:Config", ptr %t134, i32 0, i32 15
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !27
  store { i64, ptr } %t137, ptr %l72, !tbaa !27
  %t138 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %s8)
  store %"compiler/msgs:Msg" %t138, ptr %l73
  br label %bb54
bb54:
  %t139 = load ptr, ptr %l3, !tbaa !29
  %t140 = load { i64, ptr }, ptr %l72, !tbaa !27
  %t141 = load %"compiler/msgs:Msg", ptr %l73
  call void @compiler_2fbuild_2efileFatal(ptr %v1, ptr %s8, ptr %v1, { i64, ptr } %t140, %"compiler/msgs:Msg" %t141, ptr %t139)
  br label %bb55
bb55:
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t143)
  store i32 %t145, ptr %l76
  br label %bb56
bb56:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s6)
  call void @__olang_scope_close(ptr %s0)
  %t146 = load i32, ptr %l76, !tbaa !23
  store i32 %t146, ptr %rv
  br label %ret
bb57:
  %t147 = load ptr, ptr %l1, !tbaa !29
  %t149 = getelementptr %"compiler/build:Config", ptr %t147, i32 0, i32 15
  %t150 = load { i64, ptr }, ptr %t149, !tbaa !27
  %t152 = extractvalue { i64, ptr } %t150, 1
  %t153 = extractvalue { i64, ptr } %t150, 0
  %t154 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t153)
  call void @olang_textcopy(ptr %t154, ptr %t152, i64 %t153)
  %t155 = insertvalue { i64, ptr } undef, i64 %t153, 0
  %t156 = insertvalue { i64, ptr } %t155, ptr %t154, 1
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t159 = extractvalue { i64, ptr } %t156, 1
  %t160 = mul i64 %t158, 1
  %t161 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t160)
  call void @llvm.memcpy.p0.p0.i64(ptr %t161, ptr %t159, i64 %t160, i1 false)
  %t162 = insertvalue { i64, ptr } undef, i64 %t158, 0
  %t163 = insertvalue { i64, ptr } %t162, ptr %t161, 1
  store { i64, ptr } %t163, ptr %l6, !tbaa !27
  call void @__olang_scope_close(ptr %s6)
  br label %bb58
bb58:
  %t165 = load ptr, ptr %l1, !tbaa !29
  %t167 = getelementptr %"compiler/build:Config", ptr %t165, i32 0, i32 14
  %t168 = load i1, ptr %t167, !tbaa !21
  %t170 = xor i1 %t168, true
  br i1 %t170, label %bb59, label %bb60
bb59:
  store %olang.scope zeroinitializer, ptr %s10
  %t172 = load ptr, ptr %l1, !tbaa !29
  %t173 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t174 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 1
  %t175 = extractvalue { i64, ptr } { i64 6, ptr getelementptr inbounds (<{ i64, [6 x i8] }>, ptr @.d9, i32 0, i32 1) }, 0
  %t177 = extractvalue { i64, ptr } %t173, 1
  %t178 = extractvalue { i64, ptr } %t173, 0
  %t179 = add i64 %t175, %t178
  %t180 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t179)
  call void @olang_textcopy(ptr %t180, ptr %t174, i64 %t175)
  %t181 = getelementptr i8, ptr %t180, i64 %t175
  call void @olang_textcopy(ptr %t181, ptr %t177, i64 %t178)
  %t182 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t183 = insertvalue { i64, ptr } %t182, ptr %t180, 1
  %t185 = extractvalue { i64, ptr } %t183, 0
  %t186 = extractvalue { i64, ptr } %t183, 1
  %t187 = mul i64 %t185, 1
  %t188 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t187)
  call void @llvm.memcpy.p0.p0.i64(ptr %t188, ptr %t186, i64 %t187, i1 false)
  %t189 = insertvalue { i64, ptr } undef, i64 %t185, 0
  %t190 = insertvalue { i64, ptr } %t189, ptr %t188, 1
  %t193 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t172, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d10, i32 0, i32 1) }, { i64, ptr } %t190)
  store { i64, ptr } %t193, ptr %l88
  br label %bb61
bb60:
  br label %bb63
bb61:
  %t194 = load { i64, ptr }, ptr %l88, !tbaa !27
  %t195 = extractvalue { i64, ptr } %t194, 0
  %t196 = extractvalue { i64, ptr } %t194, 1
  %t197 = mul i64 %t195, 1
  %t198 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t197)
  call void @llvm.memcpy.p0.p0.i64(ptr %t198, ptr %t196, i64 %t197, i1 false)
  %t199 = insertvalue { i64, ptr } undef, i64 %t195, 0
  %t200 = insertvalue { i64, ptr } %t199, ptr %t198, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t200)
  br label %bb62
bb62:
  call void @__olang_scope_close(ptr %s10)
  br label %bb63
bb63:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l6 = alloca { i64, ptr }
  %l12 = alloca { i64, ptr }
  %l13 = alloca i32
  %l17 = alloca i32
  %l18 = alloca i32
  %s0 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, { i64, ptr } } %t11, 1
  %t13 = extractvalue { i32, { i64, ptr } } %t11, 0
  store i32 %t13, ptr %l13
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15
ok.15:
  store { i64, ptr } %t12, ptr %l12
  br label %bb1
bb1:
  %t16 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t16, ptr %l6, !tbaa !27
  br label %bb11
bb2:
  %t17 = load i32, ptr %l13, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l13, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l17
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_251e830707558b33_b2bdace7e2a71047)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l18
  br label %bb10
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t27 = load i32, ptr %l17, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t28 = load i32, ptr %l18, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load { i64, ptr }, ptr %l6, !tbaa !27
  call void @compiler_2fbuild_2esay(ptr %s0, { i64, ptr } %t29)
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s0)
  store i32 0, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l4 = alloca ptr
  %l5 = alloca i32
  %l11 = alloca i32
  %l12 = alloca i32
  %l16 = alloca i32
  %l17 = alloca i32
  %rv = alloca i32
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  %t5 = load ptr, ptr %l4, !tbaa !29
  %t11 = call { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v2, ptr %v3, ptr %v1, ptr %a0, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a1, ptr %t5)
  %t12 = extractvalue { i32, i32 } %t11, 1
  %t13 = extractvalue { i32, i32 } %t11, 0
  store i32 %t13, ptr %l12
  %t14 = icmp ne i32 %t13, 0
  br i1 %t14, label %bb2, label %ok.15
ok.15:
  store i32 %t12, ptr %l11
  br label %bb1
bb1:
  %t16 = load i32, ptr %l11, !tbaa !23
  store i32 %t16, ptr %l5, !tbaa !23
  br label %bb11
bb2:
  %t17 = load i32, ptr %l12, !tbaa !23
  %t18 = icmp eq i32 %t17, 65536
  br i1 %t18, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  %t20 = load i32, ptr %l12, !tbaa !23
  %t21 = icmp eq i32 %t20, 65537
  br i1 %t21, label %bb6, label %bb7
bb5:
  call void @__olang_ert_req_clear()
  %t23 = load ptr, ptr %l4, !tbaa !29
  %t25 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t23)
  store i32 %t25, ptr %l16
  br label %bb9
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t26 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t26, ptr %l17
  br label %bb10
bb9:
  %t27 = load i32, ptr %l16, !tbaa !23
  store i32 %t27, ptr %rv
  br label %ret
bb10:
  %t28 = load i32, ptr %l17, !tbaa !23
  store i32 %t28, ptr %rv
  br label %ret
bb11:
  %t29 = load i32, ptr %l5, !tbaa !23
  store i32 %t29, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, { i64, ptr } %a2, { i64, ptr } %a3, ptr %a4) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l4 = alloca ptr
  %l5 = alloca i32
  %l6 = alloca { i64, ptr }
  %l7 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l8 = alloca { i64, ptr }
  %l9 = alloca i64
  %l10 = alloca i64
  %l12 = alloca { i64, ptr }
  %l13 = alloca i64
  %l14 = alloca i64
  %l21 = alloca i32
  %l25 = alloca { i64, ptr }
  %l28 = alloca { i64, ptr }
  %l29 = alloca i32
  %l33 = alloca i32
  %l34 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l42 = alloca { i64, ptr }
  %l51 = alloca ptr
  %l55 = alloca { i64, ptr }
  %l60 = alloca { i64, ptr }
  %l69 = alloca { i64, ptr }
  %l81 = alloca { i64, ptr }
  %l84 = alloca { i64, ptr }
  %l90 = alloca { i64, ptr }
  %l91 = alloca i32
  %l94 = alloca ptr
  %l95 = alloca { i64, [3 x i64] }
  %l96 = alloca %"compiler/msgs:Msg"
  %l98 = alloca i32
  %s0 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %rv = alloca i32
  %t207 = alloca { i64, [3 x i64] }, align 8
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a4, ptr %l4
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load ptr, ptr %l1, !tbaa !29
  %t3 = getelementptr %"compiler/build:Config", ptr %t1, i32 0, i32 14
  store i1 true, ptr %t3, !tbaa !21
  %t5 = load ptr, ptr %l1, !tbaa !29
  %t6 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t7 = load ptr, ptr %l4, !tbaa !29
  %t12 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %t5, { i64, ptr } %t6, ptr %t7)
  store i32 %t12, ptr %l21
  br label %bb1
bb1:
  %t13 = load i32, ptr %l21, !tbaa !23
  store i32 %t13, ptr %l5, !tbaa !23
  %t14 = load i32, ptr %l5, !tbaa !23
  %t16 = icmp ne i32 %t14, 0
  br i1 %t16, label %bb2, label %bb3
bb2:
  %t18 = load i32, ptr %l5, !tbaa !23
  call void @__olang_scope_close(ptr %s0)
  store i32 %t18, ptr %rv
  br label %ret
bb3:
  br label %bb4
bb4:
  %t20 = load ptr, ptr %l1, !tbaa !29
  %t21 = load ptr, ptr %l4, !tbaa !29
  %t24 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v1, ptr %s0, ptr %t20, ptr %t21)
  %t25 = extractvalue { i32, { i64, ptr } } %t24, 1
  %t26 = extractvalue { i32, { i64, ptr } } %t24, 0
  store i32 %t26, ptr %l29
  %t27 = icmp ne i32 %t26, 0
  br i1 %t27, label %bb6, label %ok.28
ok.28:
  store { i64, ptr } %t25, ptr %l28
  br label %bb5
bb5:
  %t29 = load { i64, ptr }, ptr %l28, !tbaa !27
  store { i64, ptr } %t29, ptr %l25, !tbaa !27
  br label %bb11
bb6:
  %t30 = load i32, ptr %l29, !tbaa !23
  %t31 = ashr i32 %t30, 16
  %t33 = icmp eq i32 %t31, 1
  br i1 %t33, label %bb7, label %bb8
bb7:
  br label %bb9
bb8:
  call void @__olang_check_failed(ptr @olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9)
  unreachable
bb9:
  call void @__olang_ert_req_clear()
  %t35 = load ptr, ptr %l4, !tbaa !29
  %t37 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t35)
  store i32 %t37, ptr %l33
  br label %bb10
bb10:
  call void @__olang_scope_close(ptr %s0)
  %t38 = load i32, ptr %l33, !tbaa !23
  store i32 %t38, ptr %rv
  br label %ret
bb11:
  %t39 = load { i64, ptr }, ptr %l25, !tbaa !27
  store { i64, ptr } %t39, ptr %l6, !tbaa !27
  %t40 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t40, ptr %l34
  br label %bb12
bb12:
  %t41 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l34
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t41, ptr %l7
  %t42 = load { i64, ptr }, ptr %l6, !tbaa !27
  store { i64, ptr } %t42, ptr %l8, !tbaa !27
  store i64 0, ptr %l9, !tbaa !24
  %t44 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t46 = extractvalue { i64, ptr } %t44, 0
  store i64 %t46, ptr %l10, !tbaa !24
  br label %bb13
bb13:
  %t48 = load i64, ptr %l9, !tbaa !24
  %t49 = load i64, ptr %l10, !tbaa !24
  %t52 = icmp slt i64 %t48, %t49
  %t54 = xor i1 %t52, true
  br i1 %t54, label %bb14, label %bb15
bb14:
  br label %bb19
bb15:
  br label %bb16
bb16:
  %t56 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t56, ptr %l42, !tbaa !27
  %t57 = load i64, ptr %l9, !tbaa !24
  %t59 = getelementptr { i64, ptr }, ptr %l42, i32 0, i32 1
  %t60 = load ptr, ptr %t59, !tbaa !27
  %t61 = getelementptr { i64, ptr }, ptr %t60, i64 %t57
  %t62 = load { i64, ptr }, ptr %t61, !tbaa !37
  %t66 = extractvalue { i64, ptr } %t62, 1
  %t67 = extractvalue { i64, ptr } %t62, 0
  %t68 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t67)
  call void @olang_textcopy(ptr %t68, ptr %t66, i64 %t67)
  %t69 = insertvalue { i64, ptr } undef, i64 %t67, 0
  %t70 = insertvalue { i64, ptr } %t69, ptr %t68, 1
  %t72 = extractvalue { i64, ptr } %t70, 0
  %t73 = extractvalue { i64, ptr } %t70, 1
  %t74 = mul i64 %t72, 1
  %t75 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t74)
  call void @llvm.memcpy.p0.p0.i64(ptr %t75, ptr %t73, i64 %t74, i1 false)
  %t76 = insertvalue { i64, ptr } undef, i64 %t72, 0
  %t77 = insertvalue { i64, ptr } %t76, ptr %t75, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t77)
  br label %bb17
bb17:
  br label %bb18
bb18:
  %t80 = load i64, ptr %l9, !tbaa !24
  %t82 = add i64 %t80, 1
  store i64 %t82, ptr %l9, !tbaa !24
  br label %bb13
bb19:
  store ptr %l7, ptr %l51, !tbaa !29
  %t84 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t86 = extractvalue { i64, ptr } %t84, 0
  %t88 = icmp eq i64 %t86, 0
  br i1 %t88, label %bb20, label %bb21
bb20:
  %t90 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t92 = extractvalue { i64, ptr } %t90, 1
  %t93 = extractvalue { i64, ptr } %t90, 0
  %t94 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t93)
  call void @olang_textcopy(ptr %t94, ptr %t92, i64 %t93)
  %t95 = insertvalue { i64, ptr } undef, i64 %t93, 0
  %t96 = insertvalue { i64, ptr } %t95, ptr %t94, 1
  store { i64, ptr } %t96, ptr %l55, !tbaa !27
  br label %bb23
bb21:
  %t98 = load ptr, ptr %l1, !tbaa !29
  %t100 = getelementptr %"compiler/build:Config", ptr %t98, i32 0, i32 16
  %t101 = load { i64, ptr }, ptr %t100, !tbaa !27
  %t103 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t101)
  store { i64, ptr } %t103, ptr %l60
  br label %bb22
bb22:
  %t104 = load { i64, ptr }, ptr %l60, !tbaa !27
  store { i64, ptr } %t104, ptr %l55, !tbaa !27
  br label %bb23
bb23:
  %t105 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t106 = extractvalue { i64, ptr } %t105, 0
  %t107 = extractvalue { i64, ptr } %t105, 1
  %t108 = mul i64 %t106, 1
  %t109 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t108)
  call void @llvm.memcpy.p0.p0.i64(ptr %t109, ptr %t107, i64 %t108, i1 false)
  %t110 = insertvalue { i64, ptr } undef, i64 %t106, 0
  %t111 = insertvalue { i64, ptr } %t110, ptr %t109, 1
  %t112 = load ptr, ptr %l51, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t112, { i64, ptr } %t111)
  br label %bb24
bb24:
  store { i64, ptr } %a3, ptr %l12, !tbaa !27
  store i64 0, ptr %l13, !tbaa !24
  %t116 = load { i64, ptr }, ptr %l12, !tbaa !27
  %t118 = extractvalue { i64, ptr } %t116, 0
  store i64 %t118, ptr %l14, !tbaa !24
  br label %bb25
bb25:
  %t120 = load i64, ptr %l13, !tbaa !24
  %t121 = load i64, ptr %l14, !tbaa !24
  %t124 = icmp slt i64 %t120, %t121
  %t126 = xor i1 %t124, true
  br i1 %t126, label %bb26, label %bb27
bb26:
  br label %bb31
bb27:
  br label %bb28
bb28:
  %t128 = load { i64, ptr }, ptr %l12, !tbaa !27
  store { i64, ptr } %t128, ptr %l69, !tbaa !27
  %t129 = load i64, ptr %l13, !tbaa !24
  %t131 = getelementptr { i64, ptr }, ptr %l69, i32 0, i32 1
  %t132 = load ptr, ptr %t131, !tbaa !27
  %t133 = getelementptr { i64, ptr }, ptr %t132, i64 %t129
  %t134 = load { i64, ptr }, ptr %t133, !tbaa !37
  %t138 = extractvalue { i64, ptr } %t134, 1
  %t139 = extractvalue { i64, ptr } %t134, 0
  %t140 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t139)
  call void @olang_textcopy(ptr %t140, ptr %t138, i64 %t139)
  %t141 = insertvalue { i64, ptr } undef, i64 %t139, 0
  %t142 = insertvalue { i64, ptr } %t141, ptr %t140, 1
  %t144 = extractvalue { i64, ptr } %t142, 0
  %t145 = extractvalue { i64, ptr } %t142, 1
  %t146 = mul i64 %t144, 1
  %t147 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t146)
  call void @llvm.memcpy.p0.p0.i64(ptr %t147, ptr %t145, i64 %t146, i1 false)
  %t148 = insertvalue { i64, ptr } undef, i64 %t144, 0
  %t149 = insertvalue { i64, ptr } %t148, ptr %t147, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l7, { i64, ptr } %t149)
  br label %bb29
bb29:
  br label %bb30
bb30:
  %t152 = load i64, ptr %l13, !tbaa !24
  %t154 = add i64 %t152, 1
  store i64 %t154, ptr %l13, !tbaa !24
  br label %bb25
bb31:
  %t156 = load { i64, ptr }, ptr %l6, !tbaa !27
  %t158 = extractvalue { i64, ptr } %t156, 0
  %t160 = icmp eq i64 %t158, 0
  br i1 %t160, label %bb32, label %bb33
bb32:
  %t162 = load ptr, ptr %l1, !tbaa !29
  %t164 = getelementptr %"compiler/build:Config", ptr %t162, i32 0, i32 16
  %t165 = load { i64, ptr }, ptr %t164, !tbaa !27
  %t167 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %v1, ptr %s0, { i64, ptr } %t165)
  store { i64, ptr } %t167, ptr %l84
  br label %bb34
bb33:
  %t168 = getelementptr { i64, ptr }, ptr %l6, i32 0, i32 1
  %t169 = load ptr, ptr %t168, !tbaa !27
  %t170 = getelementptr { i64, ptr }, ptr %t169, i64 0
  %t171 = load { i64, ptr }, ptr %t170, !tbaa !37
  %t173 = extractvalue { i64, ptr } %t171, 1
  %t174 = extractvalue { i64, ptr } %t171, 0
  %t175 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t174)
  call void @olang_textcopy(ptr %t175, ptr %t173, i64 %t174)
  %t176 = insertvalue { i64, ptr } undef, i64 %t174, 0
  %t177 = insertvalue { i64, ptr } %t176, ptr %t175, 1
  %t179 = extractvalue { i64, ptr } %t177, 0
  %t180 = extractvalue { i64, ptr } %t177, 1
  %t181 = mul i64 %t179, 1
  %t182 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t181)
  call void @llvm.memcpy.p0.p0.i64(ptr %t182, ptr %t180, i64 %t181, i1 false)
  %t183 = insertvalue { i64, ptr } undef, i64 %t179, 0
  %t184 = insertvalue { i64, ptr } %t183, ptr %t182, 1
  store { i64, ptr } %t184, ptr %l81, !tbaa !27
  br label %bb35
bb34:
  %t186 = load { i64, ptr }, ptr %l84, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  store { i64, ptr } %t192, ptr %l81, !tbaa !27
  br label %bb35
bb35:
  %t195 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l7)
  store { i64, ptr } %t195, ptr %l90
  br label %bb36
bb36:
  %t196 = load { i64, ptr }, ptr %l81, !tbaa !27
  %t197 = load { i64, ptr }, ptr %l90, !tbaa !27
  %t198 = call i32 @std_2fos_2eExecInPlace(ptr %s0, ptr %s0, { i64, ptr } %t196, { i64, ptr } %t197)
  store i32 %t198, ptr %l91
  %t199 = icmp ne i32 %t198, 0
  br i1 %t199, label %bb38, label %ok.200
ok.200:
  br label %bb37
bb37:
  br label %bb45
bb38:
  %t201 = load i32, ptr %l91, !tbaa !23
  %t202 = ashr i32 %t201, 16
  %t204 = icmp eq i32 %t202, 1
  br i1 %t204, label %bb39, label %bb40
bb39:
  br label %bb41
bb40:
  call void @__olang_check_failed(ptr @olang_loc_364d74b8359cbf4c_14a2aae798044118)
  unreachable
bb41:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s13
  %t206 = load ptr, ptr %l4, !tbaa !29
  store ptr %t206, ptr %l94, !tbaa !29
  store { i64, [3 x i64] } zeroinitializer, ptr %t207
  %t208 = getelementptr { i64, [3 x i64] }, ptr %t207, i32 0, i32 0
  store i64 0, ptr %t208
  %t209 = load { i64, [3 x i64] }, ptr %t207
  store { i64, [3 x i64] } %t209, ptr %l95
  %t210 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %s13, ptr %s13, { i64, ptr } { i64 20, ptr getelementptr inbounds (<{ i64, [20 x i8] }>, ptr @.d11, i32 0, i32 1) })
  store %"compiler/msgs:Msg" %t210, ptr %l96
  br label %bb42
bb42:
  %t211 = load ptr, ptr %l94, !tbaa !29
  %t212 = load { i64, [3 x i64] }, ptr %l95
  %t213 = load %"compiler/msgs:Msg", ptr %l96
  call void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v1, ptr %s13, ptr %t211, { i64, [3 x i64] } %t212, %"compiler/msgs:Msg" %t213)
  br label %bb43
bb43:
  %t214 = load ptr, ptr %l4, !tbaa !29
  %t216 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t214)
  store i32 %t216, ptr %l98
  br label %bb44
bb44:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t217 = load i32, ptr %l98, !tbaa !23
  store i32 %t217, ptr %rv
  br label %ret
bb45:
  call void @__olang_check_failed(ptr @olang_loc_b2c1daa0212e0b47_776a2518c14c6833)
  unreachable
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1, { i64, ptr } %a2, ptr %a3) #0 {
entry:
  %l1 = alloca ptr
  %l2 = alloca { i64, ptr }
  %l3 = alloca ptr
  %l4 = alloca %"std/os:FileInfo"
  %l5 = alloca %"compiler/build:Program"
  %l6 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca { i64, ptr }
  %l11 = alloca i64
  %l12 = alloca i64
  %l14 = alloca %"std/os:Output"
  %l15 = alloca %"std/os:FileInfo"
  %l17 = alloca %"std/os:FileInfo"
  %l18 = alloca i32
  %l21 = alloca ptr
  %l22 = alloca { i64, ptr }
  %l23 = alloca %"compiler/msgs:Msg"
  %l25 = alloca i32
  %l28 = alloca ptr
  %l29 = alloca { i64, ptr }
  %l30 = alloca %"compiler/msgs:Msg"
  %l32 = alloca i32
  %l36 = alloca ptr
  %l37 = alloca { i64, ptr }
  %l38 = alloca %"compiler/msgs:Msg"
  %l40 = alloca i32
  %l41 = alloca %"compiler/build:Program"
  %l48 = alloca i32
  %l54 = alloca i32
  %l55 = alloca i32
  %l57 = alloca i64
  %l59 = alloca i1
  %l61 = alloca i64
  %l66 = alloca i32
  %l69 = alloca i32
  %l73 = alloca i32
  %l74 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l78 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l79 = alloca i32
  %l83 = alloca i32
  %l85 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca { i64, ptr }
  %l91 = alloca { i64, ptr }
  %l93 = alloca ptr
  %l94 = alloca ptr
  %l95 = alloca { i64, ptr }
  %l97 = alloca i1
  %l100 = alloca i32
  %l107 = alloca { i64, ptr }
  %l117 = alloca { i64, ptr }
  %l119 = alloca { i64, ptr }
  %l122 = alloca { i64, ptr }
  %l123 = alloca i32
  %l127 = alloca i32
  %l128 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l136 = alloca { i64, ptr }
  %l145 = alloca ptr
  %l147 = alloca { i64, ptr }
  %l149 = alloca %"std/os:Output"
  %l151 = alloca { i64, ptr }
  %l152 = alloca { i64, ptr }
  %l153 = alloca %"std/os:Output"
  %l154 = alloca i32
  %l160 = alloca ptr
  %l161 = alloca { i64, ptr }
  %l164 = alloca { i64, ptr }
  %l167 = alloca { i64, ptr }
  %l171 = alloca i32
  %s0 = alloca %olang.scope
  %s1 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s3 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s12 = alloca %olang.scope
  %s20 = alloca %olang.scope
  %rv = alloca i32
  store ptr %a1, ptr %l1
  store { i64, ptr } %a2, ptr %l2
  store ptr %a3, ptr %l3
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t3 = call { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v2, { i64, ptr } %t1)
  %t4 = extractvalue { i32, %"std/os:FileInfo" } %t3, 1
  %t5 = extractvalue { i32, %"std/os:FileInfo" } %t3, 0
  store i32 %t5, ptr %l18
  %t6 = icmp ne i32 %t5, 0
  br i1 %t6, label %bb2, label %ok.7
ok.7:
  store %"std/os:FileInfo" %t4, ptr %l17
  br label %bb1
bb1:
  %t8 = load %"std/os:FileInfo", ptr %l17
  store %"std/os:FileInfo" %t8, ptr %l15
  br label %bb8
bb2:
  %t9 = load i32, ptr %l18, !tbaa !23
  %t10 = ashr i32 %t9, 16
  %t12 = icmp eq i32 %t10, 1
  br i1 %t12, label %bb3, label %bb4
bb3:
  br label %bb5
bb4:
  call void @__olang_check_failed(ptr @olang_loc_44996bcc7c9bda8_515f8c8db8b0565c)
  unreachable
bb5:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s1
  %t14 = load ptr, ptr %l1, !tbaa !29
  store ptr %t14, ptr %l21, !tbaa !29
  %t15 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t15, ptr %l22, !tbaa !27
  %t16 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %s1)
  store %"compiler/msgs:Msg" %t16, ptr %l23
  br label %bb6
bb6:
  %t17 = load ptr, ptr %l3, !tbaa !29
  %t18 = load ptr, ptr %l21, !tbaa !29
  %t19 = load { i64, ptr }, ptr %l22, !tbaa !27
  %t20 = load %"compiler/msgs:Msg", ptr %l23
  %t22 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s1, ptr %v1, ptr %t18, { i64, ptr } %t19, %"compiler/msgs:Msg" %t20, ptr %t17)
  store i32 %t22, ptr %l25
  br label %bb7
bb7:
  call void @__olang_scope_close(ptr %s1)
  call void @__olang_scope_close(ptr %s0)
  %t23 = load i32, ptr %l25, !tbaa !23
  store i32 %t23, ptr %rv
  br label %ret
bb8:
  %t24 = load %"std/os:FileInfo", ptr %l15
  store %"std/os:FileInfo" %t24, ptr %l4
  %t25 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 0
  %t26 = load i32, ptr %t25
  %t28 = trunc i64 1 to i32
  %t29 = icmp eq i32 %t26, %t28
  br i1 %t29, label %bb9, label %bb10
bb9:
  store %olang.scope zeroinitializer, ptr %s2
  %t31 = load ptr, ptr %l1, !tbaa !29
  store ptr %t31, ptr %l28, !tbaa !29
  %t32 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t32, ptr %l29, !tbaa !27
  %t33 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %s2)
  store %"compiler/msgs:Msg" %t33, ptr %l30
  br label %bb11
bb10:
  br label %bb13
bb11:
  %t34 = load ptr, ptr %l3, !tbaa !29
  %t35 = load ptr, ptr %l28, !tbaa !29
  %t36 = load { i64, ptr }, ptr %l29, !tbaa !27
  %t37 = load %"compiler/msgs:Msg", ptr %l30
  %t39 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s2, ptr %v1, ptr %t35, { i64, ptr } %t36, %"compiler/msgs:Msg" %t37, ptr %t34)
  store i32 %t39, ptr %l32
  br label %bb12
bb12:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t40 = load i32, ptr %l32, !tbaa !23
  store i32 %t40, ptr %rv
  br label %ret
bb13:
  %t41 = getelementptr %"std/os:FileInfo", ptr %l4, i32 0, i32 0
  %t42 = load i32, ptr %t41
  %t44 = trunc i64 0 to i32
  %t45 = icmp eq i32 %t42, %t44
  %t47 = xor i1 %t45, true
  br i1 %t47, label %bb14, label %bb15
bb14:
  store %olang.scope zeroinitializer, ptr %s3
  %t49 = load ptr, ptr %l1, !tbaa !29
  store ptr %t49, ptr %l36, !tbaa !29
  %t50 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t50, ptr %l37, !tbaa !27
  %t51 = call %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %s3)
  store %"compiler/msgs:Msg" %t51, ptr %l38
  br label %bb16
bb15:
  br label %bb18
bb16:
  %t52 = load ptr, ptr %l3, !tbaa !29
  %t53 = load ptr, ptr %l36, !tbaa !29
  %t54 = load { i64, ptr }, ptr %l37, !tbaa !27
  %t55 = load %"compiler/msgs:Msg", ptr %l38
  %t57 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v1, ptr %v2, ptr %s3, ptr %v1, ptr %t53, { i64, ptr } %t54, %"compiler/msgs:Msg" %t55, ptr %t52)
  store i32 %t57, ptr %l40
  br label %bb17
bb17:
  call void @__olang_scope_close(ptr %s3)
  call void @__olang_scope_close(ptr %s0)
  %t58 = load i32, ptr %l40, !tbaa !23
  store i32 %t58, ptr %rv
  br label %ret
bb18:
  %t59 = call %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %s0)
  store %"compiler/build:Program" %t59, ptr %l41
  br label %bb19
bb19:
  %t60 = load %"compiler/build:Program", ptr %l41
  store %"compiler/build:Program" %t60, ptr %l5
  %t62 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t63 = load ptr, ptr %l1, !tbaa !29
  %t64 = load ptr, ptr %l3, !tbaa !29
  %t71 = call i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v2, ptr %v1, ptr %s0, ptr %a0, { i64, ptr } %t62, i32 2, ptr %t63, ptr %l5, ptr %t64)
  store i32 %t71, ptr %l48
  %t72 = icmp ne i32 %t71, 0
  br i1 %t72, label %bb21, label %ok.73
ok.73:
  br label %bb20
bb20:
  br label %bb30
bb21:
  %t74 = load i32, ptr %l48, !tbaa !23
  %t75 = icmp eq i32 %t74, 65536
  br i1 %t75, label %bb22, label %bb23
bb22:
  br label %bb24
bb23:
  %t77 = load i32, ptr %l48, !tbaa !23
  %t78 = icmp eq i32 %t77, 65537
  br i1 %t78, label %bb25, label %bb26
bb24:
  call void @__olang_ert_req_clear()
  %t80 = load ptr, ptr %l1, !tbaa !29
  %t81 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t82 = load ptr, ptr %l3, !tbaa !29
  %t86 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t80, { i64, ptr } %t81, ptr %t82)
  store i32 %t86, ptr %l54
  br label %bb28
bb25:
  br label %bb27
bb26:
  call void @__olang_check_failed(ptr @olang_loc_fd149271c6cb7c79_e880786eedc8ef8d)
  unreachable
bb27:
  call void @__olang_ert_req_clear()
  %t87 = call i32 @compiler_2fbuild_2eunbuilt()
  store i32 %t87, ptr %l55
  br label %bb29
bb28:
  call void @__olang_scope_close(ptr %s0)
  %t88 = load i32, ptr %l54, !tbaa !23
  store i32 %t88, ptr %rv
  br label %ret
bb29:
  call void @__olang_scope_close(ptr %s0)
  %t89 = load i32, ptr %l55, !tbaa !23
  store i32 %t89, ptr %rv
  br label %ret
bb30:
  %t90 = load ptr, ptr %l3, !tbaa !29
  %t92 = call i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v1, ptr %t90)
  store i64 %t92, ptr %l57
  br label %bb31
bb31:
  %t93 = load i64, ptr %l57, !tbaa !24
  %t94 = icmp sgt i64 %t93, 0
  br i1 %t94, label %bb32, label %bb33
bb32:
  store i1 true, ptr %l59, !tbaa !21
  br label %bb35
bb33:
  %t96 = getelementptr %"compiler/build:Program", ptr %l5, i32 0, i32 0
  %t98 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t96)
  store i64 %t98, ptr %l61
  br label %bb34
bb34:
  %t99 = load i64, ptr %l61, !tbaa !24
  %t100 = icmp eq i64 %t99, 0
  store i1 %t100, ptr %l59, !tbaa !21
  br label %bb35
bb35:
  %t102 = load i1, ptr %l59, !tbaa !21
  br i1 %t102, label %bb36, label %bb37
bb36:
  %t103 = load ptr, ptr %l1, !tbaa !29
  %t104 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t105 = load ptr, ptr %l3, !tbaa !29
  %t109 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v1, ptr %v2, ptr %v1, ptr %t103, { i64, ptr } %t104, ptr %t105)
  store i32 %t109, ptr %l66
  br label %bb38
bb37:
  br label %bb39
bb38:
  call void @__olang_scope_close(ptr %s0)
  %t110 = load i32, ptr %l66, !tbaa !23
  store i32 %t110, ptr %rv
  br label %ret
bb39:
  %t111 = load ptr, ptr %l1, !tbaa !29
  %t112 = load ptr, ptr %l3, !tbaa !29
  %t115 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v1, ptr %v1, ptr %t111, ptr %t112)
  store i32 %t115, ptr %l69
  %t116 = icmp ne i32 %t115, 0
  br i1 %t116, label %bb41, label %ok.117
ok.117:
  br label %bb40
bb40:
  br label %bb46
bb41:
  %t118 = load i32, ptr %l69, !tbaa !23
  %t119 = ashr i32 %t118, 16
  %t121 = icmp eq i32 %t119, 1
  br i1 %t121, label %bb42, label %bb43
bb42:
  br label %bb44
bb43:
  call void @__olang_check_failed(ptr @olang_loc_7f8a5722dd9e6c02_a4d5bfca52fd95f6)
  unreachable
bb44:
  call void @__olang_ert_req_clear()
  %t123 = load ptr, ptr %l3, !tbaa !29
  %t125 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t123)
  store i32 %t125, ptr %l73
  br label %bb45
bb45:
  call void @__olang_scope_close(ptr %s0)
  %t126 = load i32, ptr %l73, !tbaa !23
  store i32 %t126, ptr %rv
  br label %ret
bb46:
  %t127 = load ptr, ptr %l1, !tbaa !29
  %t128 = load ptr, ptr %l3, !tbaa !29
  %t132 = call { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v1, ptr %s0, ptr %v1, ptr %s0, ptr %t127, ptr %l5, ptr %t128)
  %t133 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t132, 1
  %t134 = extractvalue { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } %t132, 0
  store i32 %t134, ptr %l79
  %t135 = icmp ne i32 %t134, 0
  br i1 %t135, label %bb48, label %ok.136
ok.136:
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t133, ptr %l78
  br label %bb47
bb47:
  %t137 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l78
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t137, ptr %l74
  br label %bb53
bb48:
  %t138 = load i32, ptr %l79, !tbaa !23
  %t139 = ashr i32 %t138, 16
  %t141 = icmp eq i32 %t139, 1
  br i1 %t141, label %bb49, label %bb50
bb49:
  br label %bb51
bb50:
  call void @__olang_check_failed(ptr @olang_loc_43dc44123b4c1d83_8d4d1e4381628e97)
  unreachable
bb51:
  call void @__olang_ert_req_clear()
  %t143 = load ptr, ptr %l3, !tbaa !29
  %t145 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t143)
  store i32 %t145, ptr %l83
  br label %bb52
bb52:
  call void @__olang_scope_close(ptr %s0)
  %t146 = load i32, ptr %l83, !tbaa !23
  store i32 %t146, ptr %rv
  br label %ret
bb53:
  %t147 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l74
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t147, ptr %l6
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 7, ptr getelementptr inbounds (<{ i64, [7 x i8] }>, ptr @.d12, i32 0, i32 1) })
  br label %bb54
bb54:
  %t148 = load ptr, ptr %l1, !tbaa !29
  %t150 = getelementptr %"compiler/build:Config", ptr %t148, i32 0, i32 0
  %t151 = load { i64, ptr }, ptr %t150, !tbaa !27
  store { i64, ptr } %t151, ptr %l85, !tbaa !27
  %t153 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %s0, ptr %s0, ptr %l5)
  store { i64, ptr } %t153, ptr %l87
  br label %bb55
bb55:
  %t154 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t155 = extractvalue { i64, ptr } %t154, 0
  %t156 = extractvalue { i64, ptr } %t154, 1
  %t157 = mul i64 %t155, 1
  %t158 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t157)
  call void @llvm.memcpy.p0.p0.i64(ptr %t158, ptr %t156, i64 %t157, i1 false)
  %t159 = insertvalue { i64, ptr } undef, i64 %t155, 0
  %t160 = insertvalue { i64, ptr } %t159, ptr %t158, 1
  %t162 = call { i64, ptr } @compiler_2fbuild_2eReadable(ptr %s0, ptr %s0, { i64, ptr } %t160)
  store { i64, ptr } %t162, ptr %l89
  br label %bb56
bb56:
  %t163 = load ptr, ptr %l1, !tbaa !29
  %t165 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v1, ptr %s0, ptr %t163)
  store { i64, ptr } %t165, ptr %l91
  br label %bb57
bb57:
  %t166 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t167 = extractvalue { i64, ptr } %t166, 1
  %t168 = extractvalue { i64, ptr } %t166, 0
  %t169 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 1
  %t170 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d13, i32 0, i32 1) }, 0
  %t171 = add i64 %t168, %t170
  %t172 = load { i64, ptr }, ptr %l89, !tbaa !27
  %t173 = extractvalue { i64, ptr } %t172, 1
  %t174 = extractvalue { i64, ptr } %t172, 0
  %t175 = add i64 %t171, %t174
  %t176 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 1
  %t177 = extractvalue { i64, ptr } { i64 5, ptr getelementptr inbounds (<{ i64, [5 x i8] }>, ptr @.d14, i32 0, i32 1) }, 0
  %t178 = add i64 %t175, %t177
  %t179 = load { i64, ptr }, ptr %l91, !tbaa !27
  %t180 = extractvalue { i64, ptr } %t179, 1
  %t181 = extractvalue { i64, ptr } %t179, 0
  %t182 = add i64 %t178, %t181
  %t183 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t182)
  call void @olang_textcopy(ptr %t183, ptr %t167, i64 %t168)
  %t184 = getelementptr i8, ptr %t183, i64 %t168
  call void @olang_textcopy(ptr %t184, ptr %t169, i64 %t170)
  %t185 = getelementptr i8, ptr %t184, i64 %t170
  call void @olang_textcopy(ptr %t185, ptr %t173, i64 %t174)
  %t186 = getelementptr i8, ptr %t185, i64 %t174
  call void @olang_textcopy(ptr %t186, ptr %t176, i64 %t177)
  %t187 = getelementptr i8, ptr %t186, i64 %t177
  call void @olang_textcopy(ptr %t187, ptr %t180, i64 %t181)
  %t188 = insertvalue { i64, ptr } undef, i64 %t182, 0
  %t189 = insertvalue { i64, ptr } %t188, ptr %t183, 1
  store { i64, ptr } %t189, ptr %l7, !tbaa !27
  %t191 = load ptr, ptr %l1, !tbaa !29
  store ptr %t191, ptr %l93, !tbaa !29
  store ptr %l6, ptr %l94, !tbaa !29
  %t192 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t192, ptr %l95, !tbaa !27
  %t193 = getelementptr %"compiler/build:Program", ptr %l5, i32 0, i32 2
  %t194 = load { i64, ptr }, ptr %t193, !tbaa !27
  %t196 = call i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %s0, ptr %s0, { i64, ptr } %t194, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d15, i32 0, i32 1) })
  store i1 %t196, ptr %l97
  br label %bb58
bb58:
  %t197 = load i1, ptr %l97, !tbaa !21
  %t198 = xor i1 %t197, true
  %t199 = getelementptr %"compiler/build:Program", ptr %l5, i32 0, i32 3
  %t200 = load ptr, ptr %l93, !tbaa !29
  %t201 = load ptr, ptr %l94, !tbaa !29
  %t202 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t205 = call i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t200, ptr %t201, { i64, ptr } %t202, i1 %t198, ptr %t199, ptr null)
  store i32 %t205, ptr %l100
  %t206 = icmp ne i32 %t205, 0
  br i1 %t206, label %bb60, label %ok.207
ok.207:
  br label %bb59
bb59:
  br label %bb66
bb60:
  %t208 = load i32, ptr %l100, !tbaa !23
  %t209 = ashr i32 %t208, 16
  %t211 = icmp eq i32 %t209, 1
  br i1 %t211, label %bb61, label %bb62
bb61:
  br label %bb63
bb62:
  call void @__olang_check_failed(ptr @olang_loc_2a07f4f1ea94dfe4_2b76d13ec2f0d080)
  unreachable
bb63:
  call void @__olang_ert_req_clear()
  store %olang.scope zeroinitializer, ptr %s10
  %t213 = load ptr, ptr %l1, !tbaa !29
  %t214 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t216 = extractvalue { i64, ptr } %t214, 1
  %t217 = extractvalue { i64, ptr } %t214, 0
  %t218 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d16, i32 0, i32 1) }, 1
  %t219 = extractvalue { i64, ptr } { i64 27, ptr getelementptr inbounds (<{ i64, [27 x i8] }>, ptr @.d16, i32 0, i32 1) }, 0
  %t220 = add i64 %t217, %t219
  %t221 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t220)
  call void @olang_textcopy(ptr %t221, ptr %t216, i64 %t217)
  %t222 = getelementptr i8, ptr %t221, i64 %t217
  call void @olang_textcopy(ptr %t222, ptr %t218, i64 %t219)
  %t223 = insertvalue { i64, ptr } undef, i64 %t220, 0
  %t224 = insertvalue { i64, ptr } %t223, ptr %t221, 1
  %t226 = extractvalue { i64, ptr } %t224, 0
  %t227 = extractvalue { i64, ptr } %t224, 1
  %t228 = mul i64 %t226, 1
  %t229 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t228)
  call void @llvm.memcpy.p0.p0.i64(ptr %t229, ptr %t227, i64 %t228, i1 false)
  %t230 = insertvalue { i64, ptr } undef, i64 %t226, 0
  %t231 = insertvalue { i64, ptr } %t230, ptr %t229, 1
  %t234 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s10, ptr %s10, ptr %s10, ptr %t213, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d17, i32 0, i32 1) }, { i64, ptr } %t231)
  store { i64, ptr } %t234, ptr %l107
  br label %bb64
bb64:
  %t235 = load { i64, ptr }, ptr %l107, !tbaa !27
  %t236 = extractvalue { i64, ptr } %t235, 0
  %t237 = extractvalue { i64, ptr } %t235, 1
  %t238 = mul i64 %t236, 1
  %t239 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t238)
  call void @llvm.memcpy.p0.p0.i64(ptr %t239, ptr %t237, i64 %t238, i1 false)
  %t240 = insertvalue { i64, ptr } undef, i64 %t236, 0
  %t241 = insertvalue { i64, ptr } %t240, ptr %t239, 1
  call void @compiler_2fbuild_2esayln(ptr %s10, { i64, ptr } %t241)
  br label %bb65
bb65:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb66:
  call void @compiler_2fbuild_2ePhase(ptr %s0, { i64, ptr } { i64 4, ptr getelementptr inbounds (<{ i64, [4 x i8] }>, ptr @.d18, i32 0, i32 1) })
  br label %bb67
bb67:
  %t244 = load ptr, ptr %l1, !tbaa !29
  %t246 = getelementptr %"compiler/build:Config", ptr %t244, i32 0, i32 14
  %t247 = load i1, ptr %t246, !tbaa !21
  %t249 = xor i1 %t247, true
  br i1 %t249, label %bb68, label %bb69
bb68:
  store %olang.scope zeroinitializer, ptr %s12
  %t251 = load ptr, ptr %l1, !tbaa !29
  %t252 = load { i64, ptr }, ptr %l2, !tbaa !27
  %t253 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 1
  %t254 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d19, i32 0, i32 1) }, 0
  %t256 = extractvalue { i64, ptr } %t252, 1
  %t257 = extractvalue { i64, ptr } %t252, 0
  %t258 = add i64 %t254, %t257
  %t259 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 1
  %t260 = extractvalue { i64, ptr } { i64 3, ptr getelementptr inbounds (<{ i64, [3 x i8] }>, ptr @.d20, i32 0, i32 1) }, 0
  %t261 = add i64 %t258, %t260
  %t262 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t261)
  call void @olang_textcopy(ptr %t262, ptr %t253, i64 %t254)
  %t263 = getelementptr i8, ptr %t262, i64 %t254
  call void @olang_textcopy(ptr %t263, ptr %t256, i64 %t257)
  %t264 = getelementptr i8, ptr %t263, i64 %t257
  call void @olang_textcopy(ptr %t264, ptr %t259, i64 %t260)
  %t265 = insertvalue { i64, ptr } undef, i64 %t261, 0
  %t266 = insertvalue { i64, ptr } %t265, ptr %t262, 1
  %t268 = extractvalue { i64, ptr } %t266, 0
  %t269 = extractvalue { i64, ptr } %t266, 1
  %t270 = mul i64 %t268, 1
  %t271 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t270)
  call void @llvm.memcpy.p0.p0.i64(ptr %t271, ptr %t269, i64 %t270, i1 false)
  %t272 = insertvalue { i64, ptr } undef, i64 %t268, 0
  %t273 = insertvalue { i64, ptr } %t272, ptr %t271, 1
  %t276 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s12, ptr %s12, ptr %s12, ptr %t251, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d21, i32 0, i32 1) }, { i64, ptr } %t273)
  store { i64, ptr } %t276, ptr %l117
  br label %bb70
bb69:
  br label %bb72
bb70:
  %t277 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t278 = extractvalue { i64, ptr } %t277, 0
  %t279 = extractvalue { i64, ptr } %t277, 1
  %t280 = mul i64 %t278, 1
  %t281 = call ptr @__olang_scope_alloc(ptr %s12, i64 %t280)
  call void @llvm.memcpy.p0.p0.i64(ptr %t281, ptr %t279, i64 %t280, i1 false)
  %t282 = insertvalue { i64, ptr } undef, i64 %t278, 0
  %t283 = insertvalue { i64, ptr } %t282, ptr %t281, 1
  call void @compiler_2fbuild_2esayln(ptr %s12, { i64, ptr } %t283)
  br label %bb71
bb71:
  call void @__olang_scope_close(ptr %s12)
  br label %bb72
bb72:
  %t285 = load ptr, ptr %l1, !tbaa !29
  %t286 = load ptr, ptr %l3, !tbaa !29
  %t289 = call { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v1, ptr %v1, ptr %s0, ptr %t285, ptr %t286)
  %t290 = extractvalue { i32, { i64, ptr } } %t289, 1
  %t291 = extractvalue { i32, { i64, ptr } } %t289, 0
  store i32 %t291, ptr %l123
  %t292 = icmp ne i32 %t291, 0
  br i1 %t292, label %bb74, label %ok.293
ok.293:
  store { i64, ptr } %t290, ptr %l122
  br label %bb73
bb73:
  %t294 = load { i64, ptr }, ptr %l122, !tbaa !27
  store { i64, ptr } %t294, ptr %l119, !tbaa !27
  br label %bb79
bb74:
  %t295 = load i32, ptr %l123, !tbaa !23
  %t296 = ashr i32 %t295, 16
  %t298 = icmp eq i32 %t296, 1
  br i1 %t298, label %bb75, label %bb76
bb75:
  br label %bb77
bb76:
  call void @__olang_check_failed(ptr @olang_loc_6ec8a2aa167ef9d5_ad6e2c605b8bb111)
  unreachable
bb77:
  call void @__olang_ert_req_clear()
  %t300 = load ptr, ptr %l3, !tbaa !29
  %t302 = call i32 @compiler_2fbuild_2efinish(ptr %v1, ptr %t300)
  store i32 %t302, ptr %l127
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s0)
  %t303 = load i32, ptr %l127, !tbaa !23
  store i32 %t303, ptr %rv
  br label %ret
bb79:
  %t304 = load { i64, ptr }, ptr %l119, !tbaa !27
  store { i64, ptr } %t304, ptr %l8, !tbaa !27
  %t305 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s0, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t305, ptr %l128
  br label %bb80
bb80:
  %t306 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l128
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t306, ptr %l9
  %t307 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t307, ptr %l10, !tbaa !27
  store i64 0, ptr %l11, !tbaa !24
  %t309 = load { i64, ptr }, ptr %l10, !tbaa !27
  %t311 = extractvalue { i64, ptr } %t309, 0
  store i64 %t311, ptr %l12, !tbaa !24
  br label %bb81
bb81:
  %t313 = load i64, ptr %l11, !tbaa !24
  %t314 = load i64, ptr %l12, !tbaa !24
  %t317 = icmp slt i64 %t313, %t314
  %t319 = xor i1 %t317, true
  br i1 %t319, label %bb82, label %bb83
bb82:
  br label %bb87
bb83:
  br label %bb84
bb84:
  %t321 = load { i64, ptr }, ptr %l10, !tbaa !27
  store { i64, ptr } %t321, ptr %l136, !tbaa !27
  %t322 = load i64, ptr %l11, !tbaa !24
  %t324 = getelementptr { i64, ptr }, ptr %l136, i32 0, i32 1
  %t325 = load ptr, ptr %t324, !tbaa !27
  %t326 = getelementptr { i64, ptr }, ptr %t325, i64 %t322
  %t327 = load { i64, ptr }, ptr %t326, !tbaa !37
  %t331 = extractvalue { i64, ptr } %t327, 1
  %t332 = extractvalue { i64, ptr } %t327, 0
  %t333 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t332)
  call void @olang_textcopy(ptr %t333, ptr %t331, i64 %t332)
  %t334 = insertvalue { i64, ptr } undef, i64 %t332, 0
  %t335 = insertvalue { i64, ptr } %t334, ptr %t333, 1
  %t337 = extractvalue { i64, ptr } %t335, 0
  %t338 = extractvalue { i64, ptr } %t335, 1
  %t339 = mul i64 %t337, 1
  %t340 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t339)
  call void @llvm.memcpy.p0.p0.i64(ptr %t340, ptr %t338, i64 %t339, i1 false)
  %t341 = insertvalue { i64, ptr } undef, i64 %t337, 0
  %t342 = insertvalue { i64, ptr } %t341, ptr %t340, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %l9, { i64, ptr } %t342)
  br label %bb85
bb85:
  br label %bb86
bb86:
  %t345 = load i64, ptr %l11, !tbaa !24
  %t347 = add i64 %t345, 1
  store i64 %t347, ptr %l11, !tbaa !24
  br label %bb81
bb87:
  store ptr %l9, ptr %l145, !tbaa !29
  %t349 = load { i64, ptr }, ptr %l7, !tbaa !27
  %t351 = call { i64, ptr } @compiler_2fbuild_2eShown(ptr %s0, ptr %s0, { i64, ptr } %t349)
  store { i64, ptr } %t351, ptr %l147
  br label %bb88
bb88:
  %t352 = load { i64, ptr }, ptr %l147, !tbaa !27
  %t353 = extractvalue { i64, ptr } %t352, 0
  %t354 = extractvalue { i64, ptr } %t352, 1
  %t355 = mul i64 %t353, 1
  %t356 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t355)
  call void @llvm.memcpy.p0.p0.i64(ptr %t356, ptr %t354, i64 %t355, i1 false)
  %t357 = insertvalue { i64, ptr } undef, i64 %t353, 0
  %t358 = insertvalue { i64, ptr } %t357, ptr %t356, 1
  %t359 = load ptr, ptr %l145, !tbaa !29
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s0, ptr %s0, ptr %t359, { i64, ptr } %t358)
  br label %bb89
bb89:
  %t362 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %l9)
  store { i64, ptr } %t362, ptr %l151
  br label %bb90
bb90:
  store { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d22, i32 0, i32 1) }, ptr %l152, !tbaa !27
  %t363 = load { i64, ptr }, ptr %l151, !tbaa !27
  %t364 = load { i64, ptr }, ptr %l152, !tbaa !27
  %t365 = call { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t363, { i64, ptr } %t364, i1 false, { i64, ptr } { i64 0, ptr getelementptr inbounds (<{ i64, [0 x i8] }>, ptr @.d23, i32 0, i32 1) })
  %t366 = extractvalue { i32, %"std/os:Output" } %t365, 1
  %t367 = extractvalue { i32, %"std/os:Output" } %t365, 0
  store i32 %t367, ptr %l154
  %t368 = icmp ne i32 %t367, 0
  br i1 %t368, label %bb92, label %ok.369
ok.369:
  store %"std/os:Output" %t366, ptr %l153
  br label %bb91
bb91:
  %t370 = load %"std/os:Output", ptr %l153
  store %"std/os:Output" %t370, ptr %l149
  br label %bb96
bb92:
  %t371 = load i32, ptr %l154, !tbaa !23
  %t372 = ashr i32 %t371, 16
  %t374 = icmp eq i32 %t372, 1
  br i1 %t374, label %bb93, label %bb94
bb93:
  br label %bb95
bb94:
  call void @__olang_check_failed(ptr @olang_loc_a06ec74d5ac7679e_7be2ba0b82efcf7a)
  unreachable
bb95:
  call void @__olang_ert_req_clear()
  call void @__olang_scope_close(ptr %s0)
  store i32 1, ptr %rv
  br label %ret
bb96:
  %t377 = load %"std/os:Output", ptr %l149
  store %"std/os:Output" %t377, ptr %l14
  %t378 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t379 = load i32, ptr %t378, !tbaa !23
  %t381 = icmp sgt i32 %t379, 128
  br i1 %t381, label %bb97, label %bb98
bb97:
  store %olang.scope zeroinitializer, ptr %s20
  %t383 = load ptr, ptr %l1, !tbaa !29
  store ptr %t383, ptr %l160, !tbaa !29
  %t384 = load { i64, ptr }, ptr %l2, !tbaa !27
  store { i64, ptr } %t384, ptr %l161, !tbaa !27
  %t385 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t386 = load i32, ptr %t385, !tbaa !23
  %t388 = sub i32 %t386, 128
  %t390 = call { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %s20, i32 %t388)
  store { i64, ptr } %t390, ptr %l164
  br label %bb99
bb98:
  br label %bb102
bb99:
  %t391 = load { i64, ptr }, ptr %l161, !tbaa !27
  %t392 = extractvalue { i64, ptr } %t391, 1
  %t393 = extractvalue { i64, ptr } %t391, 0
  %t394 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d24, i32 0, i32 1) }, 1
  %t395 = extractvalue { i64, ptr } { i64 31, ptr getelementptr inbounds (<{ i64, [31 x i8] }>, ptr @.d24, i32 0, i32 1) }, 0
  %t396 = add i64 %t393, %t395
  %t397 = load { i64, ptr }, ptr %l164, !tbaa !27
  %t398 = extractvalue { i64, ptr } %t397, 1
  %t399 = extractvalue { i64, ptr } %t397, 0
  %t400 = add i64 %t396, %t399
  %t401 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 1
  %t402 = extractvalue { i64, ptr } { i64 1, ptr getelementptr inbounds (<{ i64, [1 x i8] }>, ptr @.d25, i32 0, i32 1) }, 0
  %t403 = add i64 %t400, %t402
  %t404 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t403)
  call void @olang_textcopy(ptr %t404, ptr %t392, i64 %t393)
  %t405 = getelementptr i8, ptr %t404, i64 %t393
  call void @olang_textcopy(ptr %t405, ptr %t394, i64 %t395)
  %t406 = getelementptr i8, ptr %t405, i64 %t395
  call void @olang_textcopy(ptr %t406, ptr %t398, i64 %t399)
  %t407 = getelementptr i8, ptr %t406, i64 %t399
  call void @olang_textcopy(ptr %t407, ptr %t401, i64 %t402)
  %t408 = insertvalue { i64, ptr } undef, i64 %t403, 0
  %t409 = insertvalue { i64, ptr } %t408, ptr %t404, 1
  %t411 = extractvalue { i64, ptr } %t409, 0
  %t412 = extractvalue { i64, ptr } %t409, 1
  %t413 = mul i64 %t411, 1
  %t414 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t413)
  call void @llvm.memcpy.p0.p0.i64(ptr %t414, ptr %t412, i64 %t413, i1 false)
  %t415 = insertvalue { i64, ptr } undef, i64 %t411, 0
  %t416 = insertvalue { i64, ptr } %t415, ptr %t414, 1
  %t417 = load ptr, ptr %l160, !tbaa !29
  %t419 = call { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v1, ptr %s20, ptr %s20, ptr %s20, ptr %t417, { i64, ptr } { i64 2, ptr getelementptr inbounds (<{ i64, [2 x i8] }>, ptr @.d26, i32 0, i32 1) }, { i64, ptr } %t416)
  store { i64, ptr } %t419, ptr %l167
  br label %bb100
bb100:
  %t420 = load { i64, ptr }, ptr %l167, !tbaa !27
  %t421 = extractvalue { i64, ptr } %t420, 0
  %t422 = extractvalue { i64, ptr } %t420, 1
  %t423 = mul i64 %t421, 1
  %t424 = call ptr @__olang_scope_alloc(ptr %s20, i64 %t423)
  call void @llvm.memcpy.p0.p0.i64(ptr %t424, ptr %t422, i64 %t423, i1 false)
  %t425 = insertvalue { i64, ptr } undef, i64 %t421, 0
  %t426 = insertvalue { i64, ptr } %t425, ptr %t424, 1
  call void @compiler_2fbuild_2esayln(ptr %s20, { i64, ptr } %t426)
  br label %bb101
bb101:
  call void @__olang_scope_close(ptr %s20)
  br label %bb102
bb102:
  %t428 = getelementptr %"std/os:Output", ptr %l14, i32 0, i32 0
  %t429 = load i32, ptr %t428, !tbaa !23
  %t431 = icmp eq i32 %t429, 0
  br i1 %t431, label %bb103, label %bb104
bb103:
  store i32 0, ptr %l171, !tbaa !23
  br label %bb105
bb104:
  store i32 1, ptr %l171, !tbaa !23
  br label %bb105
bb105:
  call void @__olang_scope_close(ptr %s0)
  %t433 = load i32, ptr %l171, !tbaa !23
  store i32 %t433, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

define dso_local i32 @compiler_2folang_2eRunWith_3ccompiler_2folang_3aPasses_3e(ptr %v0, ptr %v1, { i64, ptr } %a0, ptr %a1) #0 {
entry:
  %l0 = alloca { i64, ptr }
  %l1 = alloca ptr
  %l2 = alloca %"compiler/diag:Diagnostics"
  %l3 = alloca %"compiler/build:Config"
  %l4 = alloca %"compiler/olang:CommandLine"
  %l7 = alloca { i64, ptr }
  %l8 = alloca { i64, ptr }
  %l9 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l10 = alloca ptr
  %l11 = alloca i64
  %l14 = alloca i1
  %l15 = alloca %"compiler/diag:Diagnostics"
  %l16 = alloca %"compiler/build:Config"
  %l18 = alloca %"compiler/olang:CommandLine"
  %l22 = alloca %"compiler/olang:CommandLine"
  %l23 = alloca i32
  %l27 = alloca i32
  %l31 = alloca { i64, ptr }
  %l34 = alloca { i64, ptr }
  %l35 = alloca i32
  %l39 = alloca i32
  %l41 = alloca i32
  %l46 = alloca i64
  %l48 = alloca ptr
  %l49 = alloca ptr
  %l51 = alloca { i64, ptr }
  %l54 = alloca i32
  %l55 = alloca { i64, ptr }
  %l58 = alloca { i64, ptr }
  %l59 = alloca i32
  %l63 = alloca i32
  %l65 = alloca i32
  %l70 = alloca i32
  %l74 = alloca { i64, ptr }
  %l75 = alloca { i64, ptr }
  %l76 = alloca i32
  %l79 = alloca { i64, ptr }
  %l83 = alloca i1
  %l85 = alloca { i64, ptr }
  %l86 = alloca { i64, ptr }
  %l87 = alloca { i64, ptr }
  %l89 = alloca i32
  %l94 = alloca { i64, ptr }
  %l95 = alloca { i64, ptr }
  %l96 = alloca { i64, ptr }
  %l98 = alloca i32
  %l103 = alloca { i64, ptr }
  %l107 = alloca i32
  %l112 = alloca i32
  %l116 = alloca ptr
  %l117 = alloca { i64, ptr }
  %l118 = alloca { i64, ptr }
  %l119 = alloca i32
  %l122 = alloca { i64, ptr }
  %l126 = alloca i32
  %l128 = alloca { i64, ptr }
  %l134 = alloca { i64, ptr }
  %l137 = alloca i32
  %l143 = alloca { i64, ptr }
  %l146 = alloca i32
  %l150 = alloca ptr
  %l151 = alloca ptr
  %l152 = alloca { i64, ptr }
  %l153 = alloca { i64, ptr }
  %l155 = alloca { i64, ptr }
  %l157 = alloca i32
  %l161 = alloca %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b"
  %l163 = alloca { i64, ptr }
  %l168 = alloca i64
  %l170 = alloca i64
  %l175 = alloca { i64, ptr }
  %l182 = alloca ptr
  %l183 = alloca ptr
  %l184 = alloca { i64, ptr }
  %l185 = alloca { i64, ptr }
  %l187 = alloca { i64, ptr }
  %l189 = alloca i32
  %l195 = alloca { i64, ptr }
  %l198 = alloca i32
  %l199 = alloca { i64, ptr }
  %l200 = alloca { i64, ptr }
  %l201 = alloca i32
  %l204 = alloca { i64, ptr }
  %l208 = alloca ptr
  %l209 = alloca { i64, ptr }
  %l211 = alloca { i64, ptr }
  %l213 = alloca i32
  %s0 = alloca %olang.scope
  %s2 = alloca %olang.scope
  %s4 = alloca %olang.scope
  %s8 = alloca %olang.scope
  %s10 = alloca %olang.scope
  %s13 = alloca %olang.scope
  %s18 = alloca %olang.scope
  %rv = alloca i32
  %t2 = alloca %"compiler/diag:Diagnostics", align 8
  %t4 = alloca %"compiler/build:Config", align 8
  store { i64, ptr } %a0, ptr %l0
  store ptr %a1, ptr %l1
  br label %start
start:
  br label %bb0
bb0:
  store %olang.scope zeroinitializer, ptr %s0
  %t1 = call i1 @compiler_2fdiag_2eColorWanted()
  store i1 %t1, ptr %l14
  br label %bb1
bb1:
  %t3 = load i1, ptr %l14, !tbaa !21
  call void @compiler_2fdiag_3aDiagnostics_2ector(ptr %t2, ptr %s0, i1 %t3)
  call void @llvm.memmove.p0.p0.i64(ptr %l15, ptr %t2, i64 200, i1 false)
  br label %bb2
bb2:
  call void @llvm.memmove.p0.p0.i64(ptr %l2, ptr %l15, i64 200, i1 false)
  call void @compiler_2fbuild_3aConfig_2ector(ptr %t4, ptr %s0)
  call void @llvm.memmove.p0.p0.i64(ptr %l16, ptr %t4, i64 328, i1 false)
  br label %bb3
bb3:
  call void @llvm.memmove.p0.p0.i64(ptr %l3, ptr %l16, i64 328, i1 false)
  %t5 = getelementptr %"compiler/diag:Diagnostics", ptr %l2, i32 0, i32 0
  %t6 = load i1, ptr %t5, !tbaa !21
  %t8 = getelementptr %"compiler/build:Config", ptr %l3, i32 0, i32 13
  store i1 %t6, ptr %t8, !tbaa !21
  %t9 = load { i64, ptr }, ptr %l0, !tbaa !27
  %t13 = call { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t9, ptr %l3, ptr %l2)
  %t14 = extractvalue { i32, %"compiler/olang:CommandLine" } %t13, 1
  %t15 = extractvalue { i32, %"compiler/olang:CommandLine" } %t13, 0
  store i32 %t15, ptr %l23
  %t16 = icmp ne i32 %t15, 0
  br i1 %t16, label %bb5, label %ok.17
ok.17:
  store %"compiler/olang:CommandLine" %t14, ptr %l22
  br label %bb4
bb4:
  %t18 = load %"compiler/olang:CommandLine", ptr %l22
  store %"compiler/olang:CommandLine" %t18, ptr %l18
  br label %bb10
bb5:
  %t19 = load i32, ptr %l23, !tbaa !23
  %t20 = ashr i32 %t19, 16
  %t22 = icmp eq i32 %t20, 1
  br i1 %t22, label %bb6, label %bb7
bb6:
  br label %bb8
bb7:
  call void @__olang_check_failed(ptr @olang_loc_edee8f0aed3cec_fa0c04393fa4bb00)
  unreachable
bb8:
  call void @__olang_ert_req_clear()
  %t25 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t25, ptr %l27
  br label %bb9
bb9:
  call void @__olang_scope_close(ptr %s0)
  %t26 = load i32, ptr %l27, !tbaa !23
  store i32 %t26, ptr %rv
  br label %ret
bb10:
  %t27 = load %"compiler/olang:CommandLine", ptr %l18
  store %"compiler/olang:CommandLine" %t27, ptr %l4
  %t28 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t29 = load i64, ptr %t28, !tbaa !24
  %t30 = load i64, ptr @G_2ecompiler_2folang_2eHelp, !tbaa !24
  %t33 = icmp eq i64 %t29, %t30
  br i1 %t33, label %bb11, label %bb12
bb11:
  store %olang.scope zeroinitializer, ptr %s2
  %t37 = call { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %s0, ptr %s0, ptr %s2, ptr %l4, ptr %l2)
  %t38 = extractvalue { i32, { i64, ptr } } %t37, 1
  %t39 = extractvalue { i32, { i64, ptr } } %t37, 0
  store i32 %t39, ptr %l35
  %t40 = icmp ne i32 %t39, 0
  br i1 %t40, label %bb14, label %ok.41
ok.41:
  store { i64, ptr } %t38, ptr %l34
  br label %bb13
bb12:
  br label %bb21
bb13:
  %t42 = load { i64, ptr }, ptr %l34, !tbaa !27
  store { i64, ptr } %t42, ptr %l31, !tbaa !27
  br label %bb19
bb14:
  %t43 = load i32, ptr %l35, !tbaa !23
  %t44 = ashr i32 %t43, 16
  %t46 = icmp eq i32 %t44, 1
  br i1 %t46, label %bb15, label %bb16
bb15:
  br label %bb17
bb16:
  call void @__olang_check_failed(ptr @olang_loc_73743ad8a26b819d_7c035f5ad83f9b91)
  unreachable
bb17:
  call void @__olang_ert_req_clear()
  %t49 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t49, ptr %l39
  br label %bb18
bb18:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t50 = load i32, ptr %l39, !tbaa !23
  store i32 %t50, ptr %rv
  br label %ret
bb19:
  %t51 = load { i64, ptr }, ptr %l31, !tbaa !27
  %t54 = call i32 @compiler_2folang_2ewrite(ptr %s2, { i64, ptr } %t51)
  store i32 %t54, ptr %l41
  br label %bb20
bb20:
  call void @__olang_scope_close(ptr %s2)
  call void @__olang_scope_close(ptr %s0)
  %t55 = load i32, ptr %l41, !tbaa !23
  store i32 %t55, ptr %rv
  br label %ret
bb21:
  %t56 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t57 = load i64, ptr %t56, !tbaa !24
  %t58 = load i64, ptr @G_2ecompiler_2folang_2eExplain, !tbaa !24
  %t61 = icmp eq i64 %t57, %t58
  br i1 %t61, label %bb22, label %bb23
bb22:
  store %olang.scope zeroinitializer, ptr %s4
  %t63 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t65 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t63)
  store i64 %t65, ptr %l46
  br label %bb24
bb23:
  br label %bb38
bb24:
  %t66 = load i64, ptr %l46, !tbaa !24
  %t67 = icmp eq i64 %t66, 1
  br i1 %t67, label %bb25, label %bb26
bb25:
  %t69 = load ptr, ptr %l1, !tbaa !29
  store ptr %t69, ptr %l48, !tbaa !29
  store ptr %l3, ptr %l49, !tbaa !29
  %t70 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t72 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t70, i64 0)
  store { i64, ptr } %t72, ptr %l51
  br label %bb27
bb26:
  br label %bb29
bb27:
  %t73 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t74 = load { i64, ptr }, ptr %t73, !tbaa !27
  %t75 = load ptr, ptr %l48, !tbaa !29
  %t76 = load ptr, ptr %l49, !tbaa !29
  %t77 = load { i64, ptr }, ptr %l51, !tbaa !27
  %t80 = call i32 @compiler_2fbuild_2eExplain_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t75, ptr %t76, { i64, ptr } %t77, { i64, ptr } %t74, ptr %l2)
  store i32 %t80, ptr %l54
  br label %bb28
bb28:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t81 = load i32, ptr %l54, !tbaa !23
  store i32 %t81, ptr %rv
  br label %ret
bb29:
  %t82 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t83 = load { i64, ptr }, ptr %t82, !tbaa !27
  %t86 = call { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %s0, ptr %s0, ptr %s4, { i64, ptr } %t83, ptr %l2)
  %t87 = extractvalue { i32, { i64, ptr } } %t86, 1
  %t88 = extractvalue { i32, { i64, ptr } } %t86, 0
  store i32 %t88, ptr %l59
  %t89 = icmp ne i32 %t88, 0
  br i1 %t89, label %bb31, label %ok.90
ok.90:
  store { i64, ptr } %t87, ptr %l58
  br label %bb30
bb30:
  %t91 = load { i64, ptr }, ptr %l58, !tbaa !27
  store { i64, ptr } %t91, ptr %l55, !tbaa !27
  br label %bb36
bb31:
  %t92 = load i32, ptr %l59, !tbaa !23
  %t93 = ashr i32 %t92, 16
  %t95 = icmp eq i32 %t93, 1
  br i1 %t95, label %bb32, label %bb33
bb32:
  br label %bb34
bb33:
  call void @__olang_check_failed(ptr @olang_loc_1ed22c7d3ed33c86_4a77ed05ffa3b9fa)
  unreachable
bb34:
  call void @__olang_ert_req_clear()
  %t98 = call i32 @compiler_2folang_2esaid(ptr %s0, ptr %l2)
  store i32 %t98, ptr %l63
  br label %bb35
bb35:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t99 = load i32, ptr %l63, !tbaa !23
  store i32 %t99, ptr %rv
  br label %ret
bb36:
  %t100 = load { i64, ptr }, ptr %l55, !tbaa !27
  %t103 = call i32 @compiler_2folang_2ewrite(ptr %s4, { i64, ptr } %t100)
  store i32 %t103, ptr %l65
  br label %bb37
bb37:
  call void @__olang_scope_close(ptr %s4)
  call void @__olang_scope_close(ptr %s0)
  %t104 = load i32, ptr %l65, !tbaa !23
  store i32 %t104, ptr %rv
  br label %ret
bb38:
  %t105 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t106 = load i64, ptr %t105, !tbaa !24
  %t107 = load i64, ptr @G_2ecompiler_2folang_2eFormat, !tbaa !24
  %t110 = icmp eq i64 %t106, %t107
  br i1 %t110, label %bb39, label %bb40
bb39:
  %t113 = call i32 @compiler_2folang_2eformat(ptr %s0, ptr %l4)
  store i32 %t113, ptr %l70
  br label %bb41
bb40:
  br label %bb42
bb41:
  call void @__olang_scope_close(ptr %s0)
  %t114 = load i32, ptr %l70, !tbaa !23
  store i32 %t114, ptr %rv
  br label %ret
bb42:
  %t115 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t116 = load i64, ptr %t115, !tbaa !24
  %t117 = load i64, ptr @G_2ecompiler_2folang_2eFix, !tbaa !24
  %t120 = icmp eq i64 %t116, %t117
  br i1 %t120, label %bb43, label %bb44
bb43:
  store %olang.scope zeroinitializer, ptr %s8
  %t122 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s8, ptr %s8, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d27, i32 0, i32 1) })
  %t123 = extractvalue { i32, { i64, ptr } } %t122, 1
  %t124 = extractvalue { i32, { i64, ptr } } %t122, 0
  store i32 %t124, ptr %l76
  %t125 = icmp ne i32 %t124, 0
  br i1 %t125, label %bb46, label %ok.126
ok.126:
  store { i64, ptr } %t123, ptr %l75
  br label %bb45
bb44:
  br label %bb54
bb45:
  %t127 = load { i64, ptr }, ptr %l75, !tbaa !27
  store { i64, ptr } %t127, ptr %l74, !tbaa !27
  br label %bb50
bb46:
  %t128 = load i32, ptr %l76, !tbaa !23
  %t129 = ashr i32 %t128, 16
  %t131 = icmp eq i32 %t129, 1
  br i1 %t131, label %bb47, label %bb48
bb47:
  br label %bb49
bb48:
  call void @__olang_check_failed(ptr @olang_loc_d3277a20ab134767_f91655e31439de7b)
  unreachable
bb49:
  call void @__olang_ert_req_clear()
  %t133 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t133, ptr %l79, !tbaa !27
  %t134 = getelementptr { i64, ptr }, ptr %l79, i32 0, i32 1
  %t135 = load ptr, ptr %t134, !tbaa !27
  %t136 = getelementptr { i64, ptr }, ptr %t135, i64 0
  %t137 = load { i64, ptr }, ptr %t136, !tbaa !37
  %t139 = extractvalue { i64, ptr } %t137, 1
  %t140 = extractvalue { i64, ptr } %t137, 0
  %t141 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t140)
  call void @olang_textcopy(ptr %t141, ptr %t139, i64 %t140)
  %t142 = insertvalue { i64, ptr } undef, i64 %t140, 0
  %t143 = insertvalue { i64, ptr } %t142, ptr %t141, 1
  %t145 = extractvalue { i64, ptr } %t143, 0
  %t146 = extractvalue { i64, ptr } %t143, 1
  %t147 = mul i64 %t145, 1
  %t148 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t147)
  call void @llvm.memcpy.p0.p0.i64(ptr %t148, ptr %t146, i64 %t147, i1 false)
  %t149 = insertvalue { i64, ptr } undef, i64 %t145, 0
  %t150 = insertvalue { i64, ptr } %t149, ptr %t148, 1
  store { i64, ptr } %t150, ptr %l74, !tbaa !27
  br label %bb50
bb50:
  %t152 = load { i64, ptr }, ptr %l74, !tbaa !27
  store { i64, ptr } %t152, ptr %l7, !tbaa !27
  %t153 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 8
  %t154 = load i1, ptr %t153, !tbaa !21
  store i1 %t154, ptr %l83, !tbaa !21
  %t155 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t157 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t155)
  store { i64, ptr } %t157, ptr %l85
  br label %bb51
bb51:
  %t158 = load { i64, ptr }, ptr %l7, !tbaa !27
  store { i64, ptr } %t158, ptr %l86, !tbaa !27
  %t159 = call { i64, ptr } @compiler_2fload_2eStdDir(ptr %s8)
  store { i64, ptr } %t159, ptr %l87
  br label %bb52
bb52:
  %t160 = load { i64, ptr }, ptr %l87, !tbaa !27
  %t161 = extractvalue { i64, ptr } %t160, 0
  %t162 = extractvalue { i64, ptr } %t160, 1
  %t163 = mul i64 %t161, 1
  %t164 = call ptr @__olang_scope_alloc(ptr %s8, i64 %t163)
  call void @llvm.memcpy.p0.p0.i64(ptr %t164, ptr %t162, i64 %t163, i1 false)
  %t165 = insertvalue { i64, ptr } undef, i64 %t161, 0
  %t166 = insertvalue { i64, ptr } %t165, ptr %t164, 1
  %t167 = load i1, ptr %l83, !tbaa !21
  %t168 = load { i64, ptr }, ptr %l85, !tbaa !27
  %t169 = load { i64, ptr }, ptr %l86, !tbaa !27
  %t171 = call i32 @compiler_2ffix_2eFiles(ptr %s0, ptr %s8, ptr %s8, i1 %t167, { i64, ptr } %t168, { i64, ptr } %t169, { i64, ptr } %t166)
  store i32 %t171, ptr %l89
  br label %bb53
bb53:
  call void @__olang_scope_close(ptr %s8)
  call void @__olang_scope_close(ptr %s0)
  %t172 = load i32, ptr %l89, !tbaa !23
  store i32 %t172, ptr %rv
  br label %ret
bb54:
  %t173 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t174 = load i64, ptr %t173, !tbaa !24
  %t175 = load i64, ptr @G_2ecompiler_2folang_2eBindgen, !tbaa !24
  %t178 = icmp eq i64 %t174, %t175
  br i1 %t178, label %bb55, label %bb56
bb55:
  store %olang.scope zeroinitializer, ptr %s10
  %t180 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t182 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t180, i64 0)
  store { i64, ptr } %t182, ptr %l94
  br label %bb57
bb56:
  br label %bb60
bb57:
  %t183 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 7
  %t184 = load { i64, ptr }, ptr %t183, !tbaa !27
  store { i64, ptr } %t184, ptr %l95, !tbaa !27
  %t185 = call { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %s10)
  store { i64, ptr } %t185, ptr %l96
  br label %bb58
bb58:
  %t186 = load { i64, ptr }, ptr %l96, !tbaa !27
  %t187 = extractvalue { i64, ptr } %t186, 0
  %t188 = extractvalue { i64, ptr } %t186, 1
  %t189 = mul i64 %t187, 1
  %t190 = call ptr @__olang_scope_alloc(ptr %s10, i64 %t189)
  call void @llvm.memcpy.p0.p0.i64(ptr %t190, ptr %t188, i64 %t189, i1 false)
  %t191 = insertvalue { i64, ptr } undef, i64 %t187, 0
  %t192 = insertvalue { i64, ptr } %t191, ptr %t190, 1
  %t193 = load { i64, ptr }, ptr %l94, !tbaa !27
  %t194 = load { i64, ptr }, ptr %l95, !tbaa !27
  %t196 = call i32 @compiler_2fbindgen_2eRun(ptr %s0, ptr %s0, ptr %s10, { i64, ptr } %t193, { i64, ptr } %t194, { i64, ptr } %t192)
  store i32 %t196, ptr %l98
  br label %bb59
bb59:
  call void @__olang_scope_close(ptr %s10)
  call void @__olang_scope_close(ptr %s0)
  %t197 = load i32, ptr %l98, !tbaa !23
  store i32 %t197, ptr %rv
  br label %ret
bb60:
  %t198 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t199 = load i64, ptr %t198, !tbaa !24
  %t200 = load i64, ptr @G_2ecompiler_2folang_2eDoc, !tbaa !24
  %t203 = icmp eq i64 %t199, %t200
  br i1 %t203, label %bb61, label %bb62
bb61:
  %t205 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t207 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t205)
  store { i64, ptr } %t207, ptr %l103
  br label %bb63
bb62:
  br label %bb65
bb63:
  %t208 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 2
  %t209 = load { i64, ptr }, ptr %t208, !tbaa !27
  %t210 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 9
  %t211 = load { i64, ptr }, ptr %t210, !tbaa !27
  %t212 = load { i64, ptr }, ptr %l103, !tbaa !27
  %t216 = call i32 @compiler_2fsession_2eDocMode(ptr %s0, ptr %s0, ptr %s0, ptr %s0, { i64, ptr } %t212, { i64, ptr } %t209, { i64, ptr } %t211, ptr %l3)
  store i32 %t216, ptr %l107
  br label %bb64
bb64:
  call void @__olang_scope_close(ptr %s0)
  %t217 = load i32, ptr %l107, !tbaa !23
  store i32 %t217, ptr %rv
  br label %ret
bb65:
  %t218 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t219 = load i64, ptr %t218, !tbaa !24
  %t220 = load i64, ptr @G_2ecompiler_2folang_2eLsp, !tbaa !24
  %t223 = icmp eq i64 %t219, %t220
  br i1 %t223, label %bb66, label %bb67
bb66:
  %t226 = call i32 @compiler_2flsp_2eServe(ptr %s0, ptr %l3)
  store i32 %t226, ptr %l112
  br label %bb68
bb67:
  br label %bb69
bb68:
  call void @__olang_scope_close(ptr %s0)
  %t227 = load i32, ptr %l112, !tbaa !23
  store i32 %t227, ptr %rv
  br label %ret
bb69:
  %t228 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t229 = load i64, ptr %t228, !tbaa !24
  %t230 = load i64, ptr @G_2ecompiler_2folang_2eMcp, !tbaa !24
  %t233 = icmp eq i64 %t229, %t230
  br i1 %t233, label %bb70, label %bb71
bb70:
  store %olang.scope zeroinitializer, ptr %s13
  store ptr %l3, ptr %l116, !tbaa !29
  %t235 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s13, ptr %s13, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d28, i32 0, i32 1) })
  %t236 = extractvalue { i32, { i64, ptr } } %t235, 1
  %t237 = extractvalue { i32, { i64, ptr } } %t235, 0
  store i32 %t237, ptr %l119
  %t238 = icmp ne i32 %t237, 0
  br i1 %t238, label %bb73, label %ok.239
ok.239:
  store { i64, ptr } %t236, ptr %l118
  br label %bb72
bb71:
  br label %bb79
bb72:
  %t240 = load { i64, ptr }, ptr %l118, !tbaa !27
  store { i64, ptr } %t240, ptr %l117, !tbaa !27
  br label %bb77
bb73:
  %t241 = load i32, ptr %l119, !tbaa !23
  %t242 = ashr i32 %t241, 16
  %t244 = icmp eq i32 %t242, 1
  br i1 %t244, label %bb74, label %bb75
bb74:
  br label %bb76
bb75:
  call void @__olang_check_failed(ptr @olang_loc_9b283db8f21a3c50_1ff4bf88356440dc)
  unreachable
bb76:
  call void @__olang_ert_req_clear()
  %t246 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t246, ptr %l122, !tbaa !27
  %t247 = getelementptr { i64, ptr }, ptr %l122, i32 0, i32 1
  %t248 = load ptr, ptr %t247, !tbaa !27
  %t249 = getelementptr { i64, ptr }, ptr %t248, i64 0
  %t250 = load { i64, ptr }, ptr %t249, !tbaa !37
  %t252 = extractvalue { i64, ptr } %t250, 1
  %t253 = extractvalue { i64, ptr } %t250, 0
  %t254 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t253)
  call void @olang_textcopy(ptr %t254, ptr %t252, i64 %t253)
  %t255 = insertvalue { i64, ptr } undef, i64 %t253, 0
  %t256 = insertvalue { i64, ptr } %t255, ptr %t254, 1
  %t258 = extractvalue { i64, ptr } %t256, 0
  %t259 = extractvalue { i64, ptr } %t256, 1
  %t260 = mul i64 %t258, 1
  %t261 = call ptr @__olang_scope_alloc(ptr %s13, i64 %t260)
  call void @llvm.memcpy.p0.p0.i64(ptr %t261, ptr %t259, i64 %t260, i1 false)
  %t262 = insertvalue { i64, ptr } undef, i64 %t258, 0
  %t263 = insertvalue { i64, ptr } %t262, ptr %t261, 1
  store { i64, ptr } %t263, ptr %l117, !tbaa !27
  br label %bb77
bb77:
  %t265 = load ptr, ptr %l116, !tbaa !29
  %t266 = load { i64, ptr }, ptr %l117, !tbaa !27
  %t267 = call i32 @compiler_2fmcp_2eServe(ptr %s0, ptr %s13, ptr %t265, { i64, ptr } %t266)
  store i32 %t267, ptr %l126
  br label %bb78
bb78:
  call void @__olang_scope_close(ptr %s13)
  call void @__olang_scope_close(ptr %s0)
  %t268 = load i32, ptr %l126, !tbaa !23
  store i32 %t268, ptr %rv
  br label %ret
bb79:
  %t269 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 1
  %t271 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t269)
  store { i64, ptr } %t271, ptr %l128
  br label %bb80
bb80:
  %t272 = load { i64, ptr }, ptr %l128, !tbaa !27
  store { i64, ptr } %t272, ptr %l8, !tbaa !27
  %t273 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t274 = load i64, ptr %t273, !tbaa !24
  %t275 = load i64, ptr @G_2ecompiler_2folang_2eCompile, !tbaa !24
  %t278 = icmp eq i64 %t274, %t275
  br i1 %t278, label %bb81, label %bb82
bb81:
  %t280 = load ptr, ptr %l1, !tbaa !29
  %t281 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t281, ptr %l134, !tbaa !27
  %t282 = getelementptr { i64, ptr }, ptr %l134, i32 0, i32 1
  %t283 = load ptr, ptr %t282, !tbaa !27
  %t284 = getelementptr { i64, ptr }, ptr %t283, i64 0
  %t285 = load { i64, ptr }, ptr %t284, !tbaa !37
  %t290 = call i32 @compiler_2fbuild_2eCompile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t280, ptr %l3, { i64, ptr } %t285, ptr %l2)
  store i32 %t290, ptr %l137
  br label %bb83
bb82:
  br label %bb84
bb83:
  call void @__olang_scope_close(ptr %s0)
  %t291 = load i32, ptr %l137, !tbaa !23
  store i32 %t291, ptr %rv
  br label %ret
bb84:
  %t292 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t293 = load i64, ptr %t292, !tbaa !24
  %t294 = load i64, ptr @G_2ecompiler_2folang_2eBuild, !tbaa !24
  %t297 = icmp eq i64 %t293, %t294
  br i1 %t297, label %bb85, label %bb86
bb85:
  %t299 = load ptr, ptr %l1, !tbaa !29
  %t300 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t300, ptr %l143, !tbaa !27
  %t301 = getelementptr { i64, ptr }, ptr %l143, i32 0, i32 1
  %t302 = load ptr, ptr %t301, !tbaa !27
  %t303 = getelementptr { i64, ptr }, ptr %t302, i64 0
  %t304 = load { i64, ptr }, ptr %t303, !tbaa !37
  %t309 = call i32 @compiler_2fbuild_2eBuildProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t299, ptr %l3, { i64, ptr } %t304, ptr %l2)
  store i32 %t309, ptr %l146
  br label %bb87
bb86:
  br label %bb88
bb87:
  call void @__olang_scope_close(ptr %s0)
  %t310 = load i32, ptr %l146, !tbaa !23
  store i32 %t310, ptr %rv
  br label %ret
bb88:
  %t311 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t312 = load i64, ptr %t311, !tbaa !24
  %t313 = load i64, ptr @G_2ecompiler_2folang_2eRun, !tbaa !24
  %t316 = icmp eq i64 %t312, %t313
  br i1 %t316, label %bb89, label %bb90
bb89:
  %t318 = load ptr, ptr %l1, !tbaa !29
  store ptr %t318, ptr %l150, !tbaa !29
  store ptr %l3, ptr %l151, !tbaa !29
  %t319 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t319, ptr %l152, !tbaa !27
  %t320 = getelementptr { i64, ptr }, ptr %l152, i32 0, i32 1
  %t321 = load ptr, ptr %t320, !tbaa !27
  %t322 = getelementptr { i64, ptr }, ptr %t321, i64 0
  %t323 = load { i64, ptr }, ptr %t322, !tbaa !37
  store { i64, ptr } %t323, ptr %l153, !tbaa !27
  %t324 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 4
  %t326 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t324)
  store { i64, ptr } %t326, ptr %l155
  br label %bb91
bb90:
  br label %bb93
bb91:
  %t327 = load ptr, ptr %l150, !tbaa !29
  %t328 = load ptr, ptr %l151, !tbaa !29
  %t329 = load { i64, ptr }, ptr %l153, !tbaa !27
  %t330 = load { i64, ptr }, ptr %l155, !tbaa !27
  %t332 = call i32 @compiler_2fbuild_2eRunProgram_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s0, ptr %t327, ptr %t328, { i64, ptr } %t329, { i64, ptr } %t330, ptr %l2)
  store i32 %t332, ptr %l157
  br label %bb92
bb92:
  call void @__olang_scope_close(ptr %s0)
  %t333 = load i32, ptr %l157, !tbaa !23
  store i32 %t333, ptr %rv
  br label %ret
bb93:
  %t334 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 0
  %t335 = load i64, ptr %t334, !tbaa !24
  %t336 = load i64, ptr @G_2ecompiler_2folang_2eInterp, !tbaa !24
  %t339 = icmp eq i64 %t335, %t336
  br i1 %t339, label %bb94, label %bb95
bb94:
  store %olang.scope zeroinitializer, ptr %s18
  %t341 = call %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %s18, i64 0)
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t341, ptr %l161
  br label %bb96
bb95:
  br label %bb109
bb96:
  %t342 = load %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b", ptr %l161
  store %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" %t342, ptr %l9
  %t343 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t343, ptr %l163, !tbaa !27
  %t344 = getelementptr { i64, ptr }, ptr %l163, i32 0, i32 1
  %t345 = load ptr, ptr %t344, !tbaa !27
  %t346 = getelementptr { i64, ptr }, ptr %t345, i64 0
  %t347 = load { i64, ptr }, ptr %t346, !tbaa !37
  %t349 = extractvalue { i64, ptr } %t347, 1
  %t350 = extractvalue { i64, ptr } %t347, 0
  %t351 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t350)
  call void @olang_textcopy(ptr %t351, ptr %t349, i64 %t350)
  %t352 = insertvalue { i64, ptr } undef, i64 %t350, 0
  %t353 = insertvalue { i64, ptr } %t352, ptr %t351, 1
  %t355 = extractvalue { i64, ptr } %t353, 0
  %t356 = extractvalue { i64, ptr } %t353, 1
  %t357 = mul i64 %t355, 1
  %t358 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t357)
  call void @llvm.memcpy.p0.p0.i64(ptr %t358, ptr %t356, i64 %t357, i1 false)
  %t359 = insertvalue { i64, ptr } undef, i64 %t355, 0
  %t360 = insertvalue { i64, ptr } %t359, ptr %t358, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s18, ptr %s18, ptr %l9, { i64, ptr } %t360)
  br label %bb97
bb97:
  %t363 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 4
  store ptr %t363, ptr %l10, !tbaa !29
  store i64 0, ptr %l11, !tbaa !24
  br label %bb98
bb98:
  %t365 = load i64, ptr %l11, !tbaa !24
  store i64 %t365, ptr %l168, !tbaa !24
  %t366 = load ptr, ptr %l10, !tbaa !29
  %t368 = call i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %s0, ptr %t366)
  store i64 %t368, ptr %l170
  br label %bb99
bb99:
  %t369 = load i64, ptr %l168, !tbaa !24
  %t370 = load i64, ptr %l170, !tbaa !24
  %t371 = icmp slt i64 %t369, %t370
  %t373 = xor i1 %t371, true
  br i1 %t373, label %bb100, label %bb101
bb100:
  br label %bb106
bb101:
  br label %bb102
bb102:
  %t375 = load ptr, ptr %l10, !tbaa !29
  %t376 = load i64, ptr %l11, !tbaa !24
  %t379 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %s0, ptr %s0, ptr %t375, i64 %t376)
  store { i64, ptr } %t379, ptr %l175
  br label %bb103
bb103:
  %t380 = load { i64, ptr }, ptr %l175, !tbaa !27
  %t383 = extractvalue { i64, ptr } %t380, 1
  %t384 = extractvalue { i64, ptr } %t380, 0
  %t385 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t384)
  call void @olang_textcopy(ptr %t385, ptr %t383, i64 %t384)
  %t386 = insertvalue { i64, ptr } undef, i64 %t384, 0
  %t387 = insertvalue { i64, ptr } %t386, ptr %t385, 1
  %t389 = extractvalue { i64, ptr } %t387, 0
  %t390 = extractvalue { i64, ptr } %t387, 1
  %t391 = mul i64 %t389, 1
  %t392 = call ptr @__olang_scope_alloc(ptr %s18, i64 %t391)
  call void @llvm.memcpy.p0.p0.i64(ptr %t392, ptr %t390, i64 %t391, i1 false)
  %t393 = insertvalue { i64, ptr } undef, i64 %t389, 0
  %t394 = insertvalue { i64, ptr } %t393, ptr %t392, 1
  call void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %s18, ptr %s18, ptr %l9, { i64, ptr } %t394)
  br label %bb104
bb104:
  br label %bb105
bb105:
  %t397 = load i64, ptr %l11, !tbaa !24
  %t399 = add i64 %t397, 1
  store i64 %t399, ptr %l11, !tbaa !24
  br label %bb98
bb106:
  %t401 = load ptr, ptr %l1, !tbaa !29
  store ptr %t401, ptr %l182, !tbaa !29
  store ptr %l3, ptr %l183, !tbaa !29
  %t402 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t402, ptr %l184, !tbaa !27
  %t403 = getelementptr { i64, ptr }, ptr %l184, i32 0, i32 1
  %t404 = load ptr, ptr %t403, !tbaa !27
  %t405 = getelementptr { i64, ptr }, ptr %t404, i64 0
  %t406 = load { i64, ptr }, ptr %t405, !tbaa !37
  store { i64, ptr } %t406, ptr %l185, !tbaa !27
  %t408 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s18, ptr %s18, ptr %l9)
  store { i64, ptr } %t408, ptr %l187
  br label %bb107
bb107:
  %t409 = load ptr, ptr %l182, !tbaa !29
  %t410 = load ptr, ptr %l183, !tbaa !29
  %t411 = load { i64, ptr }, ptr %l185, !tbaa !27
  %t412 = load { i64, ptr }, ptr %l187, !tbaa !27
  %t414 = call i32 @compiler_2fbuild_2eInterpret_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %s18, ptr %t409, ptr %t410, { i64, ptr } %t411, { i64, ptr } %t412, ptr %l2)
  store i32 %t414, ptr %l189
  br label %bb108
bb108:
  call void @__olang_scope_close(ptr %s18)
  call void @__olang_scope_close(ptr %s0)
  %t415 = load i32, ptr %l189, !tbaa !23
  store i32 %t415, ptr %rv
  br label %ret
bb109:
  %t416 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t418 = extractvalue { i64, ptr } %t416, 0
  %t420 = icmp eq i64 %t418, 1
  br i1 %t420, label %bb110, label %bb111
bb110:
  %t422 = load ptr, ptr %l1, !tbaa !29
  %t423 = load { i64, ptr }, ptr %l8, !tbaa !27
  store { i64, ptr } %t423, ptr %l195, !tbaa !27
  %t424 = getelementptr { i64, ptr }, ptr %l195, i32 0, i32 1
  %t425 = load ptr, ptr %t424, !tbaa !27
  %t426 = getelementptr { i64, ptr }, ptr %t425, i64 0
  %t427 = load { i64, ptr }, ptr %t426, !tbaa !37
  %t432 = call i32 @compiler_2fbuild_2eTestFile_3ccompiler_2folang_3aPasses_3e(ptr %v1, ptr %s0, ptr %s0, ptr %t422, ptr %l3, { i64, ptr } %t427, ptr %l2)
  store i32 %t432, ptr %l198
  br label %bb112
bb111:
  br label %bb113
bb112:
  call void @__olang_scope_close(ptr %s0)
  %t433 = load i32, ptr %l198, !tbaa !23
  store i32 %t433, ptr %rv
  br label %ret
bb113:
  %t434 = call { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %s0, ptr %s0, { i64, ptr } { i64 14, ptr getelementptr inbounds (<{ i64, [14 x i8] }>, ptr @.d29, i32 0, i32 1) })
  %t435 = extractvalue { i32, { i64, ptr } } %t434, 1
  %t436 = extractvalue { i32, { i64, ptr } } %t434, 0
  store i32 %t436, ptr %l201
  %t437 = icmp ne i32 %t436, 0
  br i1 %t437, label %bb115, label %ok.438
ok.438:
  store { i64, ptr } %t435, ptr %l200
  br label %bb114
bb114:
  %t439 = load { i64, ptr }, ptr %l200, !tbaa !27
  store { i64, ptr } %t439, ptr %l199, !tbaa !27
  br label %bb119
bb115:
  %t440 = load i32, ptr %l201, !tbaa !23
  %t441 = ashr i32 %t440, 16
  %t443 = icmp eq i32 %t441, 1
  br i1 %t443, label %bb116, label %bb117
bb116:
  br label %bb118
bb117:
  call void @__olang_check_failed(ptr @olang_loc_50c080632384d1e1_b715ab696a7cda0d)
  unreachable
bb118:
  call void @__olang_ert_req_clear()
  %t445 = load { i64, ptr }, ptr %l0, !tbaa !27
  store { i64, ptr } %t445, ptr %l204, !tbaa !27
  %t446 = getelementptr { i64, ptr }, ptr %l204, i32 0, i32 1
  %t447 = load ptr, ptr %t446, !tbaa !27
  %t448 = getelementptr { i64, ptr }, ptr %t447, i64 0
  %t449 = load { i64, ptr }, ptr %t448, !tbaa !37
  %t451 = extractvalue { i64, ptr } %t449, 1
  %t452 = extractvalue { i64, ptr } %t449, 0
  %t453 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t452)
  call void @olang_textcopy(ptr %t453, ptr %t451, i64 %t452)
  %t454 = insertvalue { i64, ptr } undef, i64 %t452, 0
  %t455 = insertvalue { i64, ptr } %t454, ptr %t453, 1
  %t457 = extractvalue { i64, ptr } %t455, 0
  %t458 = extractvalue { i64, ptr } %t455, 1
  %t459 = mul i64 %t457, 1
  %t460 = call ptr @__olang_scope_alloc(ptr %s0, i64 %t459)
  call void @llvm.memcpy.p0.p0.i64(ptr %t460, ptr %t458, i64 %t459, i1 false)
  %t461 = insertvalue { i64, ptr } undef, i64 %t457, 0
  %t462 = insertvalue { i64, ptr } %t461, ptr %t460, 1
  store { i64, ptr } %t462, ptr %l199, !tbaa !27
  br label %bb119
bb119:
  %t464 = load { i64, ptr }, ptr %l199, !tbaa !27
  store ptr %l3, ptr %l208, !tbaa !29
  store { i64, ptr } %t464, ptr %l209, !tbaa !27
  %t466 = getelementptr %"compiler/olang:CommandLine", ptr %l4, i32 0, i32 5
  %t468 = call { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %s0, ptr %s0, ptr %t466)
  store { i64, ptr } %t468, ptr %l211
  br label %bb120
bb120:
  %t469 = load { i64, ptr }, ptr %l8, !tbaa !27
  %t470 = load ptr, ptr %l208, !tbaa !29
  %t471 = load { i64, ptr }, ptr %l209, !tbaa !27
  %t472 = load { i64, ptr }, ptr %l211, !tbaa !27
  %t474 = call i32 @compiler_2fbuild_2eTestFiles(ptr %s0, ptr %s0, ptr %s0, ptr %s0, ptr %t470, { i64, ptr } %t471, { i64, ptr } %t472, { i64, ptr } %t469)
  store i32 %t474, ptr %l213
  br label %bb121
bb121:
  call void @__olang_scope_close(ptr %s0)
  %t475 = load i32, ptr %l213, !tbaa !23
  store i32 %t475, ptr %rv
  br label %ret
ret:
  %rr = load i32, ptr %rv
  ret i32 %rr
}

declare void @__olang_ert_req_clear()
declare void @__olang_check_failed(ptr)
define available_externally void @__olang_scope_close(ptr %scope) alwaysinline {
entry:
  %fptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 4
  %f = load ptr, ptr %fptr, !tbaa !59
  %hasf = icmp ne ptr %f, null
  br i1 %hasf, label %parts, label %start
parts:
  %pdp = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  %pd = load ptr, ptr %pdp, !tbaa !59
  %php = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %ph = load ptr, ptr %php, !tbaa !59
  %ptp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %pt = load ptr, ptr %ptp, !tbaa !59
  %folded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %f, ptr %pd, ptr %ph, ptr %pt)
  %fd = extractvalue { ptr, ptr, ptr } %folded, 0
  store ptr %fd, ptr %pdp, !tbaa !59
  call void @__olang_dtor_head(ptr %fd, ptr %pdp)
  %fh = extractvalue { ptr, ptr, ptr } %folded, 1
  store ptr %fh, ptr %php, !tbaa !59
  %ft = extractvalue { ptr, ptr, ptr } %folded, 2
  store ptr %ft, ptr %ptp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %start
start:
  %dheadptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 1
  br label %dloop
  ; C9a: a destructor's own top level is this scope - its instance's, alive until every destructor has run - so
  ; what it builds through its instance's fields lives where they lead, and is reclaimed with the rest below. A
  ; destructor it registered there (a value it built) runs as it returns, as one in a function's own scope would,
  ; before the next of this scope's: registering puts it at the head of the list, ahead of what is left.
  ; Each node is taken off the list before its destructor runs, so the list always holds exactly what is left to
  ; run: a destructor that leaves by a failed check while a test runs (S18) leaves the rest here, and the unwind's
  ; close of this same scope (__olang_unwind_to) runs them - each destructor still exactly once (C10)
dloop:
  %dcur = load ptr, ptr %dheadptr, !tbaa !59
  %dempty = icmp eq ptr %dcur, null
  br i1 %dempty, label %chunks, label %dcall
dcall:
  %dnextptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 0
  %dnext = load ptr, ptr %dnextptr
  store ptr %dnext, ptr %dheadptr, !tbaa !59
  %dhasnext = icmp ne ptr %dnext, null
  br i1 %dhasnext, label %dfixpp, label %drun
dfixpp:
  %dnpp = getelementptr %olang.dtornode, ptr %dnext, i32 0, i32 3
  store ptr %dheadptr, ptr %dnpp
  br label %drun
drun:
  %instptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 1
  %inst = load ptr, ptr %instptr
  %fnptr = getelementptr %olang.dtornode, ptr %dcur, i32 0, i32 2
  %fn = load ptr, ptr %fnptr
  call void %fn(ptr %inst, ptr %scope)
  ; no free: the node lives in this scope's own arena and goes back to the pool with its chunk below.
  ; ...and what a task the destructor spawned built here, in a part of this scope it made while the destructor ran
  ; (P2), is folded in as the destructor returns - its join has waited for every such task - its destructors ahead
  ; of the ones the destructor registered itself, as the parts at entry are ahead of the scope's own
  %wp = load atomic ptr, ptr %fptr acquire, align 8
  %haswp = icmp ne ptr %wp, null
  br i1 %haswp, label %dparts, label %dloop
dparts:
  %wdh = load ptr, ptr %dheadptr, !tbaa !59
  %whp = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %wh = load ptr, ptr %whp, !tbaa !59
  %wtp = getelementptr %olang.scope, ptr %scope, i32 0, i32 2
  %wt = load ptr, ptr %wtp, !tbaa !59
  %wfolded = call { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr %wp, ptr %wdh, ptr %wh, ptr %wt)
  %wfd = extractvalue { ptr, ptr, ptr } %wfolded, 0
  store ptr %wfd, ptr %dheadptr, !tbaa !59
  call void @__olang_dtor_head(ptr %wfd, ptr %dheadptr)
  %wfh = extractvalue { ptr, ptr, ptr } %wfolded, 1
  store ptr %wfh, ptr %whp, !tbaa !59
  %wft = extractvalue { ptr, ptr, ptr } %wfolded, 2
  store ptr %wft, ptr %wtp, !tbaa !59
  store ptr null, ptr %fptr, !tbaa !59
  br label %dloop
  ; the regions made in this scope (O8d), after its destructors - which may read what this scope's objects hold there -
  ; and before its chunks: given the list, not the header, so the header does not escape into the call
chunks:
  %kidsptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 6
  %kids = load ptr, ptr %kidsptr, !tbaa !59
  %haskids = icmp ne ptr %kids, null
  br i1 %haskids, label %closekids, label %ownchunks
closekids:
  store ptr null, ptr %kidsptr, !tbaa !59
  call void @__olang_close_kids(ptr %kids)
  br label %ownchunks
ownchunks:
  %headptr = getelementptr %olang.scope, ptr %scope, i32 0, i32 0
  %head = load ptr, ptr %headptr, !tbaa !59
  %empty = icmp eq ptr %head, null
  br i1 %empty, label %done, label %give
  ; every chunk to the pool, out of line, so that what is left here is small; and this is always inlined, so a
  ; scope's header never escapes into a call and one allocating nothing on a path costs nothing there - its header
  ; kept in registers, the close folded away (LLVM's own estimate put it past the threshold for a cold call, and a
  ; loop's body scope then cost two stores and two tests every pass). The tail needs no reset: it is read only
  ; while the list is not empty, and set when the list next stops being empty
give:
  store ptr null, ptr %headptr, !tbaa !59
  ; -s: no chunk a scope gives back is reused at once - it is poisoned and held out of reach for a while
  ; one 4KB chunk, and no spare: it becomes the spare, here
  %hnextptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 0
  %hnext = load ptr, ptr %hnextptr
  %single = icmp eq ptr %hnext, null
  %hclassptr = getelementptr %olang.chunk, ptr %head, i32 0, i32 5
  %hclass = load i64, ptr %hclassptr
  %hsmall = icmp eq i64 %hclass, 0
  %spare = load ptr, ptr @__olang_pool_spare
  %nospare = icmp eq ptr %spare, null
  %one = and i1 %single, %hsmall
  %quick = and i1 %one, %nospare
  br i1 %quick, label %tospare, label %list
tospare:
  store ptr %head, ptr @__olang_pool_spare
  br label %done
list:
  call void @__olang_pool_give_list(ptr %head)
  br label %done
done:
  ret void
}
@.d0 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d1 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
define available_externally noalias ptr @__olang_scope_alloc(ptr %scope, i64 %rawsize) alwaysinline {
entry:
  %sizeup = add i64 %rawsize, 7
  %size8 = and i64 %sizeup, -8
  %a32 = icmp uge i64 %size8, 32
  %a64 = icmp uge i64 %size8, 64
  %alnA = select i1 %a32, i64 32, i64 8
  %aln = select i1 %a64, i64 64, i64 %alnA
  %p = call ptr @__olang_scope_alloc_a(ptr %scope, i64 %rawsize, i64 %aln)
  ret ptr %p
}
define linkonce_odr hidden void @olang_textcopy(ptr %d, ptr %s, i64 %n) alwaysinline {
entry:
  %big = icmp ugt i64 %n, 16
  br i1 %big, label %call, label %s8
call:
  call void @llvm.memcpy.p0.p0.i64(ptr %d, ptr %s, i64 %n, i1 false)
  ret void
s8:
  %ge8 = icmp uge i64 %n, 8
  br i1 %ge8, label %w8, label %s4
w8:
  %e8 = sub i64 %n, 8
  %a8 = load i64, ptr %s, align 1
  %sb8 = getelementptr i8, ptr %s, i64 %e8
  %b8 = load i64, ptr %sb8, align 1
  store i64 %a8, ptr %d, align 1
  %db8 = getelementptr i8, ptr %d, i64 %e8
  store i64 %b8, ptr %db8, align 1
  ret void
s4:
  %ge4 = icmp uge i64 %n, 4
  br i1 %ge4, label %w4, label %s1
w4:
  %e4 = sub i64 %n, 4
  %a4 = load i32, ptr %s, align 1
  %sb4 = getelementptr i8, ptr %s, i64 %e4
  %b4 = load i32, ptr %sb4, align 1
  store i32 %a4, ptr %d, align 1
  %db4 = getelementptr i8, ptr %d, i64 %e4
  store i32 %b4, ptr %db4, align 1
  ret void
s1:
  %none = icmp eq i64 %n, 0
  br i1 %none, label %done, label %w1
w1:
  %h = lshr i64 %n, 1
  %e1 = sub i64 %n, 1
  %a1 = load i8, ptr %s
  %sh = getelementptr i8, ptr %s, i64 %h
  %m1 = load i8, ptr %sh
  %se = getelementptr i8, ptr %s, i64 %e1
  %z1 = load i8, ptr %se
  store i8 %a1, ptr %d
  %dh = getelementptr i8, ptr %d, i64 %h
  store i8 %m1, ptr %dh
  %de = getelementptr i8, ptr %d, i64 %e1
  store i8 %z1, ptr %de
  br label %done
done:
  ret void
}
declare void @llvm.memcpy.p0.p0.i64(ptr, ptr, i64, i1)
@.d2 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d3 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d4 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d5 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d6 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d7 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d8 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d9 = private constant <{ i64, [6 x i8] }> <{ i64 0, [6 x i8] c"built " }>, align 8
@.d10 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"32" }>, align 8
@.d11 = private constant <{ i64, [20 x i8] }> <{ i64 0, [20 x i8] c"it cannot be started" }>, align 8
@.d12 = private constant <{ i64, [7 x i8] }> <{ i64 0, [7 x i8] c"compile" }>, align 8
@.d13 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c"/" }>, align 8
@.d14 = private constant <{ i64, [5 x i8] }> <{ i64 0, [5 x i8] c"_test" }>, align 8
@.d15 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d16 = private constant <{ i64, [27 x i8] }> <{ i64 0, [27 x i8] c": native compilation failed" }>, align 8
@.d17 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
@.d18 = private constant <{ i64, [4 x i8] }> <{ i64 0, [4 x i8] c"link" }>, align 8
@.d19 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c"== " }>, align 8
@.d20 = private constant <{ i64, [3 x i8] }> <{ i64 0, [3 x i8] c" ==" }>, align 8
@.d21 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"36" }>, align 8
@.d22 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d23 = private constant <{ i64, [0 x i8] }> <{ i64 0, [0 x i8] c"" }>, align 8
@.d24 = private constant <{ i64, [31 x i8] }> <{ i64 0, [31 x i8] c": the tests ended by a signal (" }>, align 8
@.d25 = private constant <{ i64, [1 x i8] }> <{ i64 0, [1 x i8] c")" }>, align 8
@.d26 = private constant <{ i64, [2 x i8] }> <{ i64 0, [2 x i8] c"31" }>, align 8
declare void @llvm.memmove.p0.p0.i64(ptr, ptr, i64, i1)
@.d27 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d28 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
@.d29 = private constant <{ i64, [14 x i8] }> <{ i64 0, [14 x i8] c"/proc/self/exe" }>, align 8
declare { ptr, ptr, ptr } @__olang_scope_fold_parts(ptr, ptr, ptr, ptr) noinline
define available_externally void @__olang_dtor_head(ptr %node, ptr %at) alwaysinline {
entry:
  %has = icmp ne ptr %node, null
  br i1 %has, label %fix, label %done
fix:
  %ppp = getelementptr %olang.dtornode, ptr %node, i32 0, i32 3
  store ptr %at, ptr %ppp
  br label %done
done:
  ret void
}
declare void @__olang_close_kids(ptr) noinline
@__olang_pool_spare = external thread_local(initialexec) global ptr
declare void @__olang_pool_give_list(ptr) noinline
declare noalias ptr @__olang_scope_alloc_a(ptr, i64, i64)
declare %"compiler/build:Program" @compiler_2fbuild_3aProgram_2ector(ptr %v0)
declare i32 @compiler_2folang_2ecompiler_2folang_3aPasses_2eAnalyze(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, i32 %a2, ptr %a3, ptr %a4, ptr %a5)
declare i32 @compiler_2fbuild_2efinish(ptr %v0, ptr %a0)
@olang_loc_4cd8465f442ebc46_73c7e9f900a2458a = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eunbuilt()
declare i64 @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eErrors(ptr %v0, ptr %a0)
declare i64 @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cU64_3e_2eLen_3cU64_3e(ptr %v0, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eensureDir(ptr %v0, ptr %v1, ptr %a0, ptr %a1)
@olang_loc_13a46f17cfa63227_b1895594948889cb = external constant [0 x i8]
declare { i32, %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eObjects(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, ptr %a1, ptr %a2)
@olang_loc_fd88121d790f24ac_3e6efb3076496690 = external constant [0 x i8]
declare void @compiler_2fbuild_2ePhase(ptr %v0, { i64, ptr } %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2elibrary(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, ptr %a2, { i64, ptr } %a3, ptr %a4)
declare i1 @std_2fprelude_2ftext_2estd_2fprelude_2ftext_3aString_2eEq(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aProgram_2erootIdentity(ptr %v0, ptr %v1, ptr %a0)
declare { i64, ptr } @compiler_2fbuild_2eReadable(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2emodeSuffix(ptr %v0, ptr %v1, ptr %a0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eLink(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, ptr %a1, { i64, ptr } %a2, i1 %a3, ptr %a4, ptr %a5)
@olang_loc_a50415520eaa75d_89ededae97ad6121 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eLinkFailed(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare void @compiler_2fdiag_2ecompiler_2fdiag_3aDiagnostics_2eFatal(ptr %v0, ptr %v1, ptr %a0, { i64, [3 x i64] } %a1, %"compiler/msgs:Msg" %a2)
declare { i64, ptr } @compiler_2fbuild_2eShown(ptr %v0, ptr %v1, { i64, ptr } %a0)
declare { i64, ptr } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2epaint(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2)
declare void @compiler_2fbuild_2esayln(ptr %v0, { i64, ptr } %a0)
@olang_loc_539f96ece49ac99_8ec4d6c22ed03845 = external constant [0 x i8]
@olang_loc_2f392dba8d9257c8_60d4d2a55ada0794 = external constant [0 x i8]
@olang_loc_21ac6a2bf5030ca3_5f4b05cf8c14a9cf = external constant [0 x i8]
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cstd_2fprelude_2ftext_3aString_26_3e_2e_H2711111a2c34fd187b8c2034b3d60e52(ptr %v0, ptr %v1, ptr %a0, i64 %a1)
declare { i32, { i64, ptr } } @std_2fos_2eReadFile(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_6e425cae5aa6eba2_2e2cf5e273de798e = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotOpen(ptr %v0)
declare void @compiler_2fbuild_2efileFatal(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, %"compiler/msgs:Msg" %a1, ptr %a2)
declare i32 @std_2fos_2eWriteFile(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_d8d1abb67d19f675_1213066b6aae1069 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eOutputCannotWrite(ptr %v0)
declare { i32, { i64, ptr } } @compiler_2folang_2ecompiler_2folang_3aPasses_2eExplain(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %v4, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_251e830707558b33_b2bdace7e2a71047 = external constant [0 x i8]
declare void @compiler_2fbuild_2esay(ptr %v0, { i64, ptr } %a0)
declare { i32, i32 } @compiler_2folang_2ecompiler_2folang_3aPasses_2eInterpret(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3, ptr %a4)
@olang_loc_6ff5f1cbdf8b017d_cabbfa25d1d462b1 = external constant [0 x i8]
declare { i32, { i64, ptr } } @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2erunner(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_e43b1413a2a1997d_89f9fa2bec5137e9 = external constant [0 x i8]
declare %"std/prelude/vec:Vec.6ce2052386e1f5dfc75915f9e44d8f1b" @std_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString_26_3e_26_3e_2ector(ptr %v0, i64 %a0)
declare void @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__Hdba28025cac729fb3c994cc5728b4c22(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
declare { i64, ptr } @std_2fprelude_2fvec_2estd_2fprelude_2fvec_3aVec_3cArray_3cstd_2fprelude_2ftext_3aString__H90cd95196748a565d72dba99b0550122(ptr %v0, ptr %v1, ptr %a0)
declare i32 @std_2fos_2eExecInPlace(ptr %v0, ptr %v1, { i64, ptr } %a0, { i64, ptr } %a1)
@olang_loc_364d74b8359cbf4c_14a2aae798044118 = external constant [0 x i8]
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eCannotRun(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_b2c1daa0212e0b47_776a2518c14c6833 = external constant [0 x i8]
declare { i32, %"std/os:FileInfo" } @std_2fos_2eStat(ptr %v0, { i64, ptr } %a0)
@olang_loc_44996bcc7c9bda8_515f8c8db8b0565c = external constant [0 x i8]
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eunusable(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, %"compiler/msgs:Msg" %a2, ptr %a3)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eIsDirectory(ptr %v0)
declare %"compiler/msgs:Msg" @compiler_2fmsgs_2eNotRegular(ptr %v0)
declare i32 @compiler_2fbuild_2ecompiler_2fbuild_3aConfig_2eskipped(ptr %v0, ptr %v1, ptr %v2, ptr %a0, { i64, ptr } %a1, ptr %a2)
@olang_loc_fd149271c6cb7c79_e880786eedc8ef8d = external constant [0 x i8]
@olang_loc_7f8a5722dd9e6c02_a4d5bfca52fd95f6 = external constant [0 x i8]
@olang_loc_43dc44123b4c1d83_8d4d1e4381628e97 = external constant [0 x i8]
@olang_loc_2a07f4f1ea94dfe4_2b76d13ec2f0d080 = external constant [0 x i8]
@olang_loc_6ec8a2aa167ef9d5_ad6e2c605b8bb111 = external constant [0 x i8]
declare { i32, %"std/os:Output" } @std_2fos_2eExec(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, i1 %a2, { i64, ptr } %a3)
@olang_loc_a06ec74d5ac7679e_7be2ba0b82efcf7a = external constant [0 x i8]
declare { i64, ptr } @compiler_2fbuild_2eSignalName(ptr %v0, i32 %a0)
declare i1 @compiler_2fdiag_2eColorWanted()
declare void @compiler_2fdiag_3aDiagnostics_2ector(ptr %out, ptr %v0, i1 %a0)
declare void @compiler_2fbuild_3aConfig_2ector(ptr %out, ptr %v0)
declare { i32, %"compiler/olang:CommandLine" } @compiler_2folang_2ePrepare(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, ptr %a1, ptr %a2)
@olang_loc_edee8f0aed3cec_fa0c04393fa4bb00 = external constant [0 x i8]
declare i32 @compiler_2folang_2esaid(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eHelp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\07\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2ehelp(ptr %v0, ptr %v1, ptr %v2, ptr %a0, ptr %a1)
@olang_loc_73743ad8a26b819d_7c035f5ad83f9b91 = external constant [0 x i8]
declare i32 @compiler_2folang_2ewrite(ptr %v0, { i64, ptr } %a0)
@G_2ecompiler_2folang_2eExplain = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\06\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @compiler_2folang_2eexplainRule(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, ptr %a1)
@olang_loc_1ed22c7d3ed33c86_4a77ed05ffa3b9fa = external constant [0 x i8]
@G_2ecompiler_2folang_2eFormat = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\05\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2folang_2eformat(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eFix = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0B\00\00\00\00\00\00\00" }>, align 8
declare { i32, { i64, ptr } } @std_2fos_2eReadLink(ptr %v0, ptr %v1, { i64, ptr } %a0)
@olang_loc_d3277a20ab134767_f91655e31439de7b = external constant [0 x i8]
declare { i64, ptr } @compiler_2fload_2eStdDir(ptr %v0)
declare i32 @compiler_2ffix_2eFiles(ptr %v0, ptr %v1, ptr %v2, i1 %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)
@G_2ecompiler_2folang_2eBindgen = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0C\00\00\00\00\00\00\00" }>, align 8
declare { i64, ptr } @compiler_2ftarget_2eFindClang(ptr %v0)
declare i32 @compiler_2fbindgen_2eRun(ptr %v0, ptr %v1, ptr %v2, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2)
@G_2ecompiler_2folang_2eDoc = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\08\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2fsession_2eDocMode(ptr %v0, ptr %v1, ptr %v2, ptr %v3, { i64, ptr } %a0, { i64, ptr } %a1, { i64, ptr } %a2, ptr %a3)
@G_2ecompiler_2folang_2eLsp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\09\00\00\00\00\00\00\00" }>, align 8
declare i32 @compiler_2flsp_2eServe(ptr %v0, ptr %a0)
@G_2ecompiler_2folang_2eMcp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\0A\00\00\00\00\00\00\00" }>, align 8
@olang_loc_9b283db8f21a3c50_1ff4bf88356440dc = external constant [0 x i8]
declare i32 @compiler_2fmcp_2eServe(ptr %v0, ptr %v1, ptr %a0, { i64, ptr } %a1)
@G_2ecompiler_2folang_2eCompile = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\02\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eBuild = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\01\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eRun = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\00\00\00\00\00\00\00\00" }>, align 8
@G_2ecompiler_2folang_2eInterp = available_externally constant <{ [8 x i8] }> <{ [8 x i8] c"\04\00\00\00\00\00\00\00" }>, align 8
@olang_loc_50c080632384d1e1_b715ab696a7cda0d = external constant [0 x i8]
declare i32 @compiler_2fbuild_2eTestFiles(ptr %v0, ptr %v1, ptr %v2, ptr %v3, ptr %a0, { i64, ptr } %a1, { i64, ptr } %a2, { i64, ptr } %a3)

!20 = !{!"olang"}
!49 = !{!"scopehdr", !20, i64 0}
!50 = !{!"chunkhdr", !20, i64 0}
!59 = !{!49, !49, i64 0}
!60 = !{!50, !50, i64 0}
!17 = !{!"arraydesc", !20, i64 0}
!18 = !{!"closure", !20, i64 0}
!47 = !{!"arraydesc[]", !20, i64 0}
!19 = !{!"ref", !20, i64 0}
!48 = !{!"ref[]", !20, i64 0}
!29 = !{!19, !19, i64 0}
!39 = !{!48, !48, i64 0}
!27 = !{!17, !17, i64 0}
!28 = !{!18, !18, i64 0}
!37 = !{!47, !47, i64 0}
!11 = !{!"bool", !20, i64 0}
!21 = !{!11, !11, i64 0}
!41 = !{!"bool[]", !20, i64 0}
!31 = !{!41, !41, i64 0}
!51 = !{!"i8", !20, i64 0}
!61 = !{!51, !51, i64 0}
!91 = !{!"i8[]", !20, i64 0}
!81 = !{!91, !91, i64 0}
!52 = !{!"i16", !20, i64 0}
!62 = !{!52, !52, i64 0}
!92 = !{!"i16[]", !20, i64 0}
!82 = !{!92, !92, i64 0}
!13 = !{!"int32", !20, i64 0}
!23 = !{!13, !13, i64 0}
!43 = !{!"int32[]", !20, i64 0}
!33 = !{!43, !43, i64 0}
!14 = !{!"int64", !20, i64 0}
!24 = !{!14, !14, i64 0}
!44 = !{!"int64[]", !20, i64 0}
!34 = !{!44, !44, i64 0}
!12 = !{!"byte", !20, i64 0}
!22 = !{!12, !12, i64 0}
!42 = !{!"byte[]", !20, i64 0}
!32 = !{!42, !42, i64 0}
!53 = !{!"u16", !20, i64 0}
!63 = !{!53, !53, i64 0}
!93 = !{!"u16[]", !20, i64 0}
!83 = !{!93, !93, i64 0}
!54 = !{!"u32", !20, i64 0}
!64 = !{!54, !54, i64 0}
!94 = !{!"u32[]", !20, i64 0}
!84 = !{!94, !94, i64 0}
!55 = !{!"u64", !20, i64 0}
!65 = !{!55, !55, i64 0}
!95 = !{!"u64[]", !20, i64 0}
!85 = !{!95, !95, i64 0}
!56 = !{!"f16", !20, i64 0}
!66 = !{!56, !56, i64 0}
!96 = !{!"f16[]", !20, i64 0}
!86 = !{!96, !96, i64 0}
!57 = !{!"bf16", !20, i64 0}
!67 = !{!57, !57, i64 0}
!97 = !{!"bf16[]", !20, i64 0}
!87 = !{!97, !97, i64 0}
!15 = !{!"float32", !20, i64 0}
!25 = !{!15, !15, i64 0}
!45 = !{!"float32[]", !20, i64 0}
!35 = !{!45, !45, i64 0}
!16 = !{!"float64", !20, i64 0}
!26 = !{!16, !16, i64 0}
!46 = !{!"float64[]", !20, i64 0}
!36 = !{!46, !46, i64 0}

attributes #0 = { null_pointer_is_valid "target-cpu"="x86-64" "target-features"="+cmov,+cx8,+fxsr,+mmx,+sse,+sse2,+x87" "prefer-vector-width"="128" }
